import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const PORT = 3000;

// Shared Gemini client utility with required User-Agent telemetry
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// API: Health & Node Telemetry
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'SYNCHRONIZED',
    node: 'DEKANTIAN-KÖNIGSBERG-01',
    geminiEnabled: Boolean(aiClient),
    timestamp: new Date().toISOString(),
  });
});

// API: Propose Reasoning via Gemini (Section 24: Gemini 3.7 / 3.8 Flash role - Semantic analysis, concept extraction, argument reconstruction, counterargument generation)
app.post('/api/propose', async (req: Request, res: Response) => {
  const { propositionText } = req.body;
  if (!propositionText || typeof propositionText !== 'string') {
    res.status(400).json({ error: 'Missing propositionText' });
    return;
  }

  if (aiClient) {
    try {
      const prompt = `You are the reasoning assistant for DEKANTIAN, an enterprise-grade Kantian Epistemic Consensus Engine.
Analyze this proposition for structural input into the deterministic validation engine.
Proposition: "${propositionText}"

Return a JSON object with:
1. "subject": The primary cognitive object/concept.
2. "predicate": The property or relation asserted.
3. "judgementClass": "ANALYTIC" (predicate contained in concept) or "SYNTHETIC" (amplifies concept via experience).
4. "origin": "A_PRIORI" or "A_POSTERIORI".
5. "boundaryDomain": "EMPIRICAL_PHENOMENA", "FORMAL_STRUCTURES", "CONCEPTUAL_OBJECTS", or "METAPHYSICAL_CLAIMS".
6. "categories": {"quantity": "UNITY"|"PLURALITY"|"TOTALITY", "quality": "REALITY"|"NEGATION"|"LIMITATION", "relation": "SUBSTANCE"|"CAUSALITY"|"COMMUNITY", "modality": "POSSIBILITY"|"EXISTENCE"|"NECESSITY", "explanation": string}
7. "transcendentalQuestion": What must be true of the conditions of experience for this to be known?
8. "hiddenAssumptions": Array of 2 strings identifying hidden presuppositions.
9. "counterargument": The strongest possible epistemic counter-hypothesis or falsification scenario.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2,
        },
      });

      const parsed = JSON.parse(response.text?.trim() || '{}');
      res.json({ proposal: parsed, source: 'GEMINI_REASONING_ASSISTANT' });
      return;
    } catch (err: any) {
      console.warn('Gemini proposal failed, falling back to deterministic engine:', err?.message);
    }
  }

  // Deterministic fallback if Gemini is offline or not configured
  res.json({
    proposal: {
      fallback: true,
      message: 'Processed via built-in deterministic Kantian pipeline.',
    },
    source: 'DETERMINISTIC_EPISTEMIC_COMPILER',
  });
});

// API: Epistemic Query / Natural Language Interface (Section 40)
app.post('/api/query', async (req: Request, res: Response) => {
  const { query, stateSummary } = req.body;
  if (!query) {
    res.status(400).json({ error: 'Missing query' });
    return;
  }

  if (aiClient) {
    try {
      const prompt = `You are DEKANTIAN, an epistemic validator node. Answer this interrogation strictly based on Kantian epistemology and current state context.
Do NOT speak like a chatbot. Speak like an epistemic validation node reporting verifiable conditions, boundaries of experience, and canonical ledger status.

Current State Context: ${JSON.stringify(stateSummary || {})}
User Query: "${query}"`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          temperature: 0.3,
        },
      });

      res.json({ answer: response.text });
      return;
    } catch (err: any) {
      console.warn('Query generation fallback:', err?.message);
    }
  }

  res.json({
    answer: `EPISTEMIC NODE QUERY RECORD: "${query}"\n\nCanonical consensus ledger currently tracks validated empirical phenomena, analytic tautologies, and dialectical antinomies. All propositions are evaluated against the conditions of possible experience. Use /state, /block, or /antinomies for detailed telemetry.`,
  });
});

// Vite middleware in dev or static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[DEKANTIAN] Epistemic Validator Node running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
