import React, { useState } from 'react';
import { EpistemicValidator } from '../types/epistemic';
import { 
  Shield, 
  AlertOctagon, 
  Award, 
  CheckCircle2, 
  Activity, 
  Zap, 
  RotateCcw,
  Sliders
} from 'lucide-react';

interface ValidatorSetViewProps {
  validators: EpistemicValidator[];
  onSlashValidator: (validatorId: string, reason: string) => void;
}

export const ValidatorSetView: React.FC<ValidatorSetViewProps> = ({
  validators,
  onSlashValidator
}) => {
  const [selectedValId, setSelectedValId] = useState<string | null>(null);
  const [slashReason, setSlashReason] = useState('Certified a proposition with fatal internal contradiction.');

  const handleSlash = (valId: string) => {
    onSlashValidator(valId, slashReason);
    setSelectedValId(null);
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Title Banner */}
      <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center space-x-2 text-sm font-bold text-[#f8fafc] uppercase tracking-wider mb-1">
              <Shield className="w-4 h-4 text-cyan-400" />
              <span>EPISTEMIC STAKE & VALIDATOR QUORUM (SECTION 30 & 31)</span>
            </div>
            <p className="text-xs text-[#8a93a6] font-sans">
              Validators do not stake monetary tokens. They stake reputation, domain authority, and predictive accuracy. Fatal contradictions or category errors result in permanent epistemic slashing.
            </p>
          </div>

          <div className="text-xs text-[#cbd5e1] bg-[#161922] px-3 py-1.5 rounded border border-[#252936]">
            ACTIVE VALIDATORS: <strong className="text-emerald-400">{validators.filter(v => v.active).length} / 8</strong>
          </div>
        </div>
      </div>

      {/* Validators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {validators.map(val => (
          <div
            key={val.id}
            className="p-4 bg-[#141722] border border-[#252936] rounded-lg text-xs flex flex-col justify-between hover:border-[#384055] transition-all"
          >
            <div>
              {/* Header */}
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-[#f1f5f9] truncate" title={val.name}>
                  {val.name}
                </span>
                <span className="px-2 py-0.5 text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded font-bold">
                  ACTIVE
                </span>
              </div>

              <div className="text-[11px] text-[#64748b] mb-3">
                TYPE: <span className="text-[#94a3b8]">{val.type}</span>
              </div>

              {/* Reputation Metric */}
              <div className="space-y-2 mb-4 bg-[#0c0d12] p-2.5 rounded border border-[#1e222e]">
                <div>
                  <div className="flex justify-between text-[10px] text-[#8a93a6] mb-1">
                    <span>EPISTEMIC REPUTATION</span>
                    <span className="text-cyan-400 font-bold">{(val.reputation * 100).toFixed(1)}%</span>
                  </div>
                  <div className="h-1.5 bg-[#161922] rounded overflow-hidden">
                    <div
                      className="h-full bg-cyan-400 transition-all duration-300"
                      style={{ width: `${val.reputation * 100}%` }}
                    />
                  </div>
                </div>

                <div className="flex justify-between text-[10px] text-[#8a93a6] pt-1">
                  <span>VOTING WEIGHT:</span>
                  <span className="text-amber-300 font-bold">{val.baseWeight.toFixed(2)}x</span>
                </div>

                <div className="flex justify-between text-[10px] text-[#8a93a6]">
                  <span>ATTESTATIONS ISSUED:</span>
                  <span className="text-[#f1f5f9]">{val.attestationsCount}</span>
                </div>

                <div className="flex justify-between text-[10px] text-[#8a93a6]">
                  <span>SLASHING PENALTIES:</span>
                  <span className={val.slashedCount > 0 ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                    {val.slashedCount}
                  </span>
                </div>
              </div>
            </div>

            {/* Slashing Button */}
            <div className="pt-2 border-t border-[#1e222e]">
              <button
                onClick={() => setSelectedValId(val.id)}
                className="w-full py-1.5 bg-rose-950/20 hover:bg-rose-900/40 text-rose-400 border border-rose-500/30 hover:border-rose-500/50 rounded text-[11px] flex items-center justify-center space-x-1 cursor-pointer transition-colors"
                title="Test epistemic slashing penalty"
              >
                <AlertOctagon className="w-3.5 h-3.5" />
                <span>Execute Epistemic Slash</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Slashing Confirmation Modal */}
      {selectedValId && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141722] border border-rose-500/50 rounded-lg p-5 max-w-md w-full text-xs space-y-4 shadow-2xl">
            <div className="flex items-center space-x-2 text-rose-400 font-bold text-sm uppercase">
              <AlertOctagon className="w-5 h-5" />
              <span>DISCIPLINARY EPISTEMIC SLASHING PROTOCOL</span>
            </div>

            <p className="text-[#cbd5e1] leading-relaxed">
              You are about to slash validator <strong className="text-white">{validators.find(v => v.id === selectedValId)?.name}</strong>.
              This will permanently reduce its voting weight by 0.35x, deduct reputation by 25%, and log an irreversible disciplinary event in the state ledger.
            </p>

            <div>
              <label className="text-[#8a93a6] text-[10px] block mb-1">VIOLATION GROUNDS</label>
              <input
                type="text"
                value={slashReason}
                onChange={e => setSlashReason(e.target.value)}
                className="w-full bg-[#0c0d12] border border-[#252936] text-xs text-[#f1f5f9] p-2 rounded focus:outline-none focus:border-rose-500"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setSelectedValId(null)}
                className="px-3 py-1.5 text-xs text-[#8a93a6] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSlash(selectedValId)}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded cursor-pointer transition-colors shadow-lg shadow-rose-900/40"
              >
                Commit Slashing Penalty
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
