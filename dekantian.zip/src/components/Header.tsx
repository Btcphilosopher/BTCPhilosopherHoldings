import React from 'react';
import { 
  Shield, 
  Activity, 
  Layers, 
  GitBranch, 
  Scale, 
  Terminal, 
  Share2, 
  PlusCircle, 
  CheckCircle2, 
  Boxes,
  Lock
} from 'lucide-react';
import { NodeTelemetry } from '../types/epistemic';
import { formatHash } from '../engine/crypto';

interface HeaderProps {
  telemetry: NodeTelemetry;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenNewClaimModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  telemetry,
  activeTab,
  setActiveTab,
  onOpenNewClaimModal
}) => {
  const tabs = [
    { id: 'dashboard', label: 'VALIDATOR NODE', icon: Activity },
    { id: 'blocks', label: 'EPISTEMIC BLOCKS', icon: Boxes },
    { id: 'consensus', label: 'LIVE CONSENSUS', icon: Layers },
    { id: 'forks', label: 'FORK CHOICE', icon: GitBranch },
    { id: 'antinomies', label: 'ANTINOMIES', icon: Scale },
    { id: 'graph', label: 'KNOWLEDGE GRAPH', icon: Share2 },
    { id: 'terminal', label: 'TERMINAL CLI', icon: Terminal },
    { id: 'validators', label: 'VALIDATOR STAKES', icon: Shield },
  ];

  return (
    <header className="border-b border-[#252936] bg-[#0f1117]/95 backdrop-blur sticky top-0 z-40">
      {/* Top Node Telemetry Ribbon */}
      <div className="px-4 py-2 border-b border-[#1e222e] flex flex-wrap items-center justify-between text-xs text-[#8a93a6] gap-2 font-mono">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-[#e1e4ea] font-semibold tracking-wider">NODE ONLINE</span>
            <span className="text-emerald-400 font-mono">● {telemetry.syncPercentage}% SYNCHRONIZED</span>
          </div>
          <span className="text-[#32384a]">|</span>
          <div>
            <span className="text-[#64748b]">ID:</span>{' '}
            <span className="text-[#cbd5e1]">{telemetry.nodeName}</span>
          </div>
          <span className="text-[#32384a]">|</span>
          <div>
            <span className="text-[#64748b]">STATE ROOT:</span>{' '}
            <span className="text-amber-400 font-mono tracking-tight" title={telemetry.stateHash}>
              {formatHash(telemetry.stateHash)}
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div>
            <span className="text-[#64748b]">BLOCK HEIGHT:</span>{' '}
            <span className="text-[#e2e8f0] font-bold">#{telemetry.currentBlockHeight.toLocaleString()}</span>
          </div>
          <span className="text-[#32384a]">|</span>
          <div>
            <span className="text-[#64748b]">HEALTH:</span>{' '}
            <span className="text-emerald-400 font-semibold">{telemetry.epistemicHealth}%</span>
          </div>
          <span className="text-[#32384a]">|</span>
          <div className="flex items-center space-x-1 text-[#94a3b8]">
            <Lock className="w-3 h-3 text-cyan-400" />
            <span className="text-cyan-400 font-medium">BFT CONSENSUS</span>
          </div>
        </div>
      </div>

      {/* Main Bar with Branding & Navigation Tabs */}
      <div className="px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded bg-gradient-to-br from-amber-500/20 via-zinc-800 to-cyan-500/20 border border-amber-500/30 flex items-center justify-center text-amber-300 font-bold text-lg tracking-tighter">
            ΔK
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base font-bold tracking-widest text-[#f8fafc] uppercase font-mono">
                DEKANTIAN
              </h1>
              <span className="px-1.5 py-0.5 text-[10px] uppercase font-mono tracking-wider bg-amber-500/10 text-amber-300 border border-amber-500/25 rounded">
                v2.6 PoS Validator
              </span>
            </div>
            <p className="text-[11px] text-[#8a93a6] font-sans">
              Kantian Epistemic Consensus & Knowledge Validation Engine
            </p>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onOpenNewClaimModal}
            className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs tracking-wider uppercase rounded transition-colors flex items-center space-x-1.5 shadow-sm shadow-amber-500/20 cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 text-black" />
            <span>Propose Proposition</span>
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <nav className="px-4 flex space-x-1 overflow-x-auto border-t border-[#1e222e] scrollbar-none">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2.5 text-xs font-mono tracking-wider flex items-center space-x-2 border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'border-amber-400 text-amber-300 bg-amber-400/5 font-semibold'
                  : 'border-transparent text-[#8a93a6] hover:text-[#e2e8f0] hover:border-[#32384a]'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-[#64748b]'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
