import React, { useState, useMemo } from 'react';
import { KnowledgeGraphNode, KnowledgeGraphEdge, PropositionClaim } from '../types/epistemic';
import { EpistemicLedgerStore } from '../engine/epistemicStore';
import { Share2, Info, Filter, Eye, Layers } from 'lucide-react';

interface KnowledgeGraphViewProps {
  onSelectClaim: (claim: PropositionClaim) => void;
}

export const KnowledgeGraphView: React.FC<KnowledgeGraphViewProps> = ({ onSelectClaim }) => {
  const { nodes, edges } = useMemo(() => EpistemicLedgerStore.getKnowledgeGraph(), []);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(nodes[0]?.id || null);
  const [filterType, setFilterType] = useState<string>('ALL');

  const selectedNode = nodes.find(n => n.id === selectedNodeId);

  // Position nodes radially or in layered bands for clean SVG rendering
  const positionedNodes = useMemo(() => {
    const total = nodes.length;
    const centerX = 380;
    const centerY = 260;
    const radiusMap: { [type: string]: number } = {
      'CLAIM': 100,
      'CONCEPT': 180,
      'EVIDENCE': 240,
      'ASSUMPTION': 240,
      'SOURCE': 240,
      'CONDITION': 240
    };

    return nodes.map((node, i) => {
      const radius = radiusMap[node.type] || 180;
      const angle = (i / total) * 2 * Math.PI;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      return { ...node, x, y };
    });
  }, [nodes]);

  const nodeMap = useMemo(() => {
    const map = new Map<string, typeof positionedNodes[0]>();
    positionedNodes.forEach(n => map.set(n.id, n));
    return map;
  }, [positionedNodes]);

  const filteredNodes = positionedNodes.filter(n => filterType === 'ALL' || n.type === filterType);

  const incidentEdges = edges.filter(
    e => e.source === selectedNodeId || e.target === selectedNodeId
  );

  const getNodeColor = (type: string) => {
    switch (type) {
      case 'CLAIM': return '#38bdf8'; // cyan
      case 'CONCEPT': return '#fbbf24'; // amber
      case 'EVIDENCE': return '#34d399'; // emerald
      case 'ASSUMPTION': return '#c084fc'; // purple
      default: return '#94a3b8';
    }
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Top Banner */}
      <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center space-x-2 text-sm font-bold text-[#f8fafc] uppercase tracking-wider mb-1">
              <Share2 className="w-4 h-4 text-cyan-400" />
              <span>EPISTEMIC KNOWLEDGE GRAPH (SECTION 22)</span>
            </div>
            <p className="text-xs text-[#8a93a6] font-sans">
              Graph database abstraction mapping claims, concepts, empirical evidence, and conditions with immutable provenance.
            </p>
          </div>

          {/* Filter Chips */}
          <div className="flex items-center space-x-1 text-[10px]">
            {['ALL', 'CLAIM', 'CONCEPT', 'EVIDENCE', 'ASSUMPTION'].map(t => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                  filterType === t 
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 font-bold' 
                    : 'bg-[#161922] text-[#8a93a6] hover:text-[#cbd5e1]'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Visual Graph and Node Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* SVG Graph View (8 cols) */}
        <div className="lg:col-span-8 p-3 bg-[#0c0d12] border border-[#252936] rounded-lg overflow-hidden flex items-center justify-center">
          <svg
            viewBox="0 0 760 520"
            className="w-full h-auto max-h-[520px] select-none"
          >
            <defs>
              <marker
                id="arrowhead"
                markerWidth="6"
                markerHeight="4"
                refX="16"
                refY="2"
                orient="auto"
              >
                <polygon points="0 0, 6 2, 0 4" fill="#475569" />
              </marker>
            </defs>

            {/* Edges */}
            {edges.map(edge => {
              const src = nodeMap.get(edge.source);
              const tgt = nodeMap.get(edge.target);
              if (!src || !tgt) return null;

              const isHighlighted = edge.source === selectedNodeId || edge.target === selectedNodeId;

              return (
                <g key={edge.id}>
                  <line
                    x1={src.x}
                    y1={src.y}
                    x2={tgt.x}
                    y2={tgt.y}
                    stroke={isHighlighted ? '#f59e0b' : '#222736'}
                    strokeWidth={isHighlighted ? 2 : 1}
                    strokeDasharray={edge.relation === 'DEPENDS_ON' ? '3 3' : undefined}
                    markerEnd="url(#arrowhead)"
                  />
                </g>
              );
            })}

            {/* Nodes */}
            {filteredNodes.map(node => {
              const isSelected = node.id === selectedNodeId;
              const color = getNodeColor(node.type);

              return (
                <g
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className="cursor-pointer group"
                >
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={isSelected ? 16 : node.type === 'CLAIM' ? 14 : 10}
                    fill={isSelected ? color : '#131620'}
                    stroke={color}
                    strokeWidth={isSelected ? 3 : 1.5}
                    className="transition-all duration-150"
                  />
                  <text
                    x={node.x}
                    y={(node.y || 0) + 24}
                    textAnchor="middle"
                    fill={isSelected ? '#f8fafc' : '#94a3b8'}
                    fontSize={isSelected ? 10 : 9}
                    fontWeight={isSelected ? 'bold' : 'normal'}
                    className="font-mono pointer-events-none"
                  >
                    {node.label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Node Provenance Inspector (4 cols) */}
        <div className="lg:col-span-4 p-4 bg-[#11131a] border border-[#252936] rounded-lg text-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#252936]">
            <span className="font-bold text-[#f8fafc] uppercase tracking-wider">NODE INSPECTOR</span>
            {selectedNode && (
              <span
                className="px-2 py-0.5 rounded text-[10px] font-bold"
                style={{
                  backgroundColor: `${getNodeColor(selectedNode.type)}20`,
                  color: getNodeColor(selectedNode.type),
                  border: `1px solid ${getNodeColor(selectedNode.type)}40`
                }}
              >
                {selectedNode.type}
              </span>
            )}
          </div>

          {selectedNode ? (
            <>
              <div>
                <span className="text-[#64748b] text-[10px] block font-bold uppercase">IDENTIFIER</span>
                <span className="text-[#f1f5f9] font-mono">{selectedNode.id}</span>
              </div>

              <div>
                <span className="text-[#64748b] text-[10px] block font-bold uppercase">LABEL</span>
                <p className="text-[#e2e8f0] font-medium leading-relaxed bg-[#0c0d12] p-2 rounded border border-[#1e222e]">
                  {selectedNode.label}
                </p>
              </div>

              {selectedNode.category && (
                <div>
                  <span className="text-[#64748b] text-[10px] block font-bold uppercase">CATEGORY / DOMAIN</span>
                  <span className="text-amber-300 font-semibold">{selectedNode.category}</span>
                </div>
              )}

              {/* Connected Edges */}
              <div className="pt-2 border-t border-[#1e222e]">
                <span className="text-[#8a93a6] text-[10px] block font-bold uppercase mb-2">
                  INCIDENT EDGES ({incidentEdges.length})
                </span>
                <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1 text-[11px]">
                  {incidentEdges.map(edge => (
                    <div key={edge.id} className="p-2 bg-[#161922] border border-[#1e222e] rounded">
                      <div className="flex justify-between text-[10px] text-[#64748b]">
                        <span className="text-cyan-400 font-bold">{edge.relation}</span>
                        <span>wt: {edge.weight}</span>
                      </div>
                      <div className="text-[#94a3b8] truncate mt-0.5">
                        {edge.source === selectedNode.id ? `→ ${edge.target}` : `← ${edge.source}`}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <p className="text-[#8a93a6]">Select any node in the graph to inspect provenance.</p>
          )}
        </div>
      </div>
    </div>
  );
};
