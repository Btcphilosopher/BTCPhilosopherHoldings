import React, { useState } from 'react';
import { 
  NodeTelemetry, 
  PropositionClaim, 
  EpistemicLedgerEvent 
} from '../types/epistemic';
import { PropositionValidator } from './PropositionValidator';
import { formatHash } from '../engine/crypto';
import { 
  Activity, 
  Boxes, 
  ShieldCheck, 
  AlertTriangle, 
  XCircle, 
  Layers, 
  Cpu, 
  ArrowRight, 
  Clock, 
  Sparkles,
  FileText,
  Search,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';

interface DashboardOverviewProps {
  telemetry: NodeTelemetry;
  propositions: PropositionClaim[];
  ledgerEvents: EpistemicLedgerEvent[];
  selectedClaim: PropositionClaim;
  onSelectClaim: (claim: PropositionClaim) => void;
  onSubmitProposition: (text: string, evidence?: any) => void;
  onReviseClaim: (claimId: string, newText: string) => void;
  onNavigateToTab: (tab: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  telemetry,
  propositions,
  ledgerEvents,
  selectedClaim,
  onSelectClaim,
  onSubmitProposition,
  onReviseClaim,
  onNavigateToTab
}) => {
  const [quickInput, setQuickInput] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const presets = [
    {
      label: 'Bitcoin Observation',
      text: 'The price of Bitcoin increased during the observation period.',
      type: 'Empirical'
    },
    {
      label: 'Macro Causation',
      text: 'Interest rates caused investment to fall.',
      type: 'Causal'
    },
    {
      label: 'Analytic Identity',
      text: 'All bachelors are unmarried.',
      type: 'Analytic'
    },
    {
      label: 'Metaphysical Boundary',
      text: 'Reality as it is in itself possesses mathematical symmetry independently of every possible condition of human experience.',
      type: 'Metaphysical'
    },
    {
      label: 'Cosmological Antinomy',
      text: 'The universe has a beginning in time, and is limited as regards space.',
      type: 'Antinomy'
    }
  ];

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    onSubmitProposition(quickInput.trim());
    setQuickInput('');
  };

  const filteredPropositions = propositions.filter(p => {
    const matchesFilter = statusFilter === 'ALL' || p.status === statusFilter;
    const matchesSearch = searchQuery === '' || 
      p.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.boundaryDomain.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6 font-mono">
      {/* 1. TOP VALIDATOR NODE STATUS GRID (Section 32 / 47) */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {/* Block Height */}
        <div className="p-3 bg-[#131620] border border-[#252936] rounded-md relative overflow-hidden">
          <div className="flex items-center justify-between text-[#8a93a6] text-[11px] mb-1">
            <span>STATE BLOCK</span>
            <Boxes className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-lg font-bold text-[#f8fafc]">
            #{telemetry.currentBlockHeight.toLocaleString()}
          </div>
          <div className="text-[10px] text-cyan-400 mt-1 flex items-center space-x-1">
            <span>SYNC 99.98%</span>
          </div>
        </div>

        {/* Canonical Finalized */}
        <div className="p-3 bg-[#131620] border border-[#252936] rounded-md relative overflow-hidden">
          <div className="flex items-center justify-between text-[#8a93a6] text-[11px] mb-1">
            <span>FINALIZED</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-lg font-bold text-emerald-400">
            {telemetry.finalizedCount} <span className="text-xs text-[#8a93a6]">claims</span>
          </div>
          <div className="text-[10px] text-emerald-500/80 mt-1">
            CANONICAL KNOWLEDGE
          </div>
        </div>

        {/* Justified */}
        <div className="p-3 bg-[#131620] border border-[#252936] rounded-md relative overflow-hidden">
          <div className="flex items-center justify-between text-[#8a93a6] text-[11px] mb-1">
            <span>JUSTIFIED</span>
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-lg font-bold text-cyan-300">
            {telemetry.justifiedCount} <span className="text-xs text-[#8a93a6]">claims</span>
          </div>
          <div className="text-[10px] text-[#8a93a6] mt-1">
            QUORUM CONFIRMED
          </div>
        </div>

        {/* Conditional / Unresolved */}
        <div className="p-3 bg-[#131620] border border-[#252936] rounded-md relative overflow-hidden">
          <div className="flex items-center justify-between text-[#8a93a6] text-[11px] mb-1">
            <span>UNRESOLVED</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-lg font-bold text-amber-400">
            {telemetry.unresolvedContradictionsCount} <span className="text-xs text-[#8a93a6]">claims</span>
          </div>
          <div className="text-[10px] text-amber-400/80 mt-1">
            CONDITIONAL BOUNDS
          </div>
        </div>

        {/* Dialectical Antinomies */}
        <div className="p-3 bg-[#131620] border border-[#252936] rounded-md relative overflow-hidden">
          <div className="flex items-center justify-between text-[#8a93a6] text-[11px] mb-1">
            <span>ANTINOMIES</span>
            <Layers className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-lg font-bold text-purple-300">
            {telemetry.antinomiesCount} <span className="text-xs text-[#8a93a6]">detected</span>
          </div>
          <div className="text-[10px] text-purple-400/80 mt-1">
            REASON BOUNDARIES
          </div>
        </div>

        {/* Epistemic Health */}
        <div className="p-3 bg-[#131620] border border-[#252936] rounded-md relative overflow-hidden">
          <div className="flex items-center justify-between text-[#8a93a6] text-[11px] mb-1">
            <span>EPISTEMIC HEALTH</span>
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-lg font-bold text-[#f8fafc]">
            {telemetry.epistemicHealth}%
          </div>
          <div className="text-[10px] text-emerald-400 mt-1">
            0 UNCHECKED FALSIFICATIONS
          </div>
        </div>
      </div>

      {/* 2. PROPOSITION INGESTION CONSOLE */}
      <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2 text-xs text-amber-400 font-semibold tracking-wider uppercase">
            <Cpu className="w-4 h-4" />
            <span>SUBMIT CLAIM FOR EPISTEMIC CONSENSUS VALIDATION</span>
          </div>
          <span className="text-[10px] text-[#64748b]">PROPOSAL → KANTIAN DECOMPOSITION → ATTESTATIONS → CANONICAL LEDGER</span>
        </div>

        <form onSubmit={handleQuickSubmit} className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={quickInput}
              onChange={e => setQuickInput(e.target.value)}
              placeholder='Enter proposition e.g., "Copper conducts electricity under standard atmospheric pressure."'
              className="flex-1 bg-[#161922] border border-[#32384a] text-sm text-[#f1f5f9] px-3 py-2.5 rounded focus:outline-none focus:border-amber-400 placeholder-[#475569]"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs uppercase tracking-wider rounded transition-colors flex items-center justify-center space-x-2 cursor-pointer shadow-sm shadow-amber-500/20"
            >
              <span>Ingest & Validate</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[11px]">
            <span className="text-[#64748b]">LOAD TEST CASE:</span>
            {presets.map((preset, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setQuickInput(preset.text)}
                className="px-2 py-0.5 bg-[#161922] hover:bg-[#202534] border border-[#2a3040] hover:border-amber-400/40 text-[#cbd5e1] rounded transition-colors cursor-pointer"
              >
                {preset.label} <span className="text-[#64748b]">({preset.type})</span>
              </button>
            ))}
          </div>
        </form>
      </div>

      {/* 3. MAIN WORKSPACE: LEFT = CLAIM FEED & TICKER, RIGHT = ACTIVE PROPOSITION INSPECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols): Knowledge Ledger Propositions & Events */}
        <div className="lg:col-span-5 space-y-4">
          {/* Claims List Header */}
          <div className="p-3 bg-[#11131a] border border-[#252936] rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#f1f5f9] flex items-center space-x-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                <span>EPISTEMIC LEDGER ({filteredPropositions.length})</span>
              </h3>

              {/* Status Filter Chips */}
              <div className="flex space-x-1 text-[10px]">
                {['ALL', 'FINALIZED', 'CONDITIONAL'].map(filter => (
                  <button
                    key={filter}
                    onClick={() => setStatusFilter(filter)}
                    className={`px-2 py-0.5 rounded cursor-pointer ${
                      statusFilter === filter 
                        ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40 font-bold' 
                        : 'bg-[#161922] text-[#8a93a6] hover:text-[#e2e8f0]'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            {/* Search Input */}
            <div className="relative mb-3">
              <Search className="w-3.5 h-3.5 text-[#64748b] absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Filter propositions by text or domain..."
                className="w-full bg-[#161922] border border-[#252936] text-xs text-[#e2e8f0] pl-8 pr-3 py-1.5 rounded focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Proposition Cards */}
            <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
              {filteredPropositions.map(prop => {
                const isSelected = selectedClaim?.id === prop.id;
                return (
                  <div
                    key={prop.id}
                    onClick={() => onSelectClaim(prop)}
                    className={`p-3 rounded border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#1a1e2b] border-amber-400/60 shadow-md shadow-black/40'
                        : 'bg-[#151822] border-[#252936] hover:border-[#384055] hover:bg-[#181c28]'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] text-[#8a93a6] mb-1">
                      <span className="text-[#f1f5f9] font-bold">{prop.id}</span>
                      <span className="text-cyan-400">Block #{prop.blockId}</span>
                      <span className="text-zinc-400">v{prop.version}</span>
                    </div>

                    <p className="text-xs text-[#e2e8f0] font-sans font-medium line-clamp-2 leading-relaxed mb-2">
                      "{prop.text}"
                    </p>

                    <div className="flex items-center justify-between text-[10px] pt-1.5 border-t border-[#1e222e]">
                      <span className="text-[#64748b]">{prop.boundaryDomain}</span>
                      <span className={`font-semibold ${
                        prop.status === 'FINALIZED' ? 'text-emerald-400' :
                        prop.status === 'JUSTIFIED' ? 'text-cyan-400' :
                        prop.status === 'CONDITIONAL' ? 'text-amber-400' : 'text-rose-400'
                      }`}>
                        {prop.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Append-Only Ledger Audit Feed (Section 5) */}
          <div className="p-3 bg-[#11131a] border border-[#252936] rounded-lg">
            <div className="flex items-center justify-between text-xs text-[#8a93a6] mb-2 font-bold">
              <span className="flex items-center space-x-1.5 text-zinc-300">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>APPEND-ONLY STATE LEDGER EVENTS</span>
              </span>
              <span className="text-[10px] text-[#64748b]">IMMUTABLE LOG</span>
            </div>

            <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1 text-[11px]">
              {ledgerEvents.slice(0, 8).map(evt => (
                <div key={evt.id} className="p-2 bg-[#161922] border border-[#1e222e] rounded flex items-start space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0 mt-1.5"></span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between text-[10px] text-[#64748b]">
                      <span className="text-cyan-400 font-semibold">{evt.type}</span>
                      <span>{new Date(evt.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-[#cbd5e1] truncate mt-0.5">{evt.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Full Epistemic Decomposition of Selected Proposition */}
        <div className="lg:col-span-7">
          {selectedClaim ? (
            <PropositionValidator
              claim={selectedClaim}
              onRevise={onReviseClaim}
              onSelectClaim={onSelectClaim}
              onNavigateToFork={() => onNavigateToTab('forks')}
              onNavigateToAntinomy={() => onNavigateToTab('antinomies')}
            />
          ) : (
            <div className="p-12 text-center text-[#8a93a6] bg-[#11131a] border border-[#252936] rounded-lg">
              <Boxes className="w-8 h-8 text-[#32384a] mx-auto mb-2" />
              <p>Select a proposition from the ledger to inspect epistemic conditions.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
