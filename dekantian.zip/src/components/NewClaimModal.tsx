import React, { useState } from 'react';
import { X, Plus, Sparkles, FileText, FlaskConical } from 'lucide-react';

interface NewClaimModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (text: string, evidence?: any) => void;
}

export const NewClaimModal: React.FC<NewClaimModalProps> = ({
  isOpen,
  onClose,
  onSubmit
}) => {
  const [claimText, setClaimText] = useState('');
  const [attachEvidence, setAttachEvidence] = useState(false);
  const [evidenceTitle, setEvidenceTitle] = useState('');
  const [evidenceProvenance, setEvidenceProvenance] = useState('');
  const [evidenceAuthor, setEvidenceAuthor] = useState('');
  const [evidenceContent, setEvidenceContent] = useState('');
  const [evidenceReliability, setEvidenceReliability] = useState('0.92');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!claimText.trim()) return;

    let evidencePayload = undefined;
    if (attachEvidence && evidenceTitle.trim()) {
      evidencePayload = {
        title: evidenceTitle.trim(),
        sourceProvenance: evidenceProvenance.trim() || 'Direct Laboratory Observation',
        author: evidenceAuthor.trim() || 'Investigator',
        content: evidenceContent.trim() || 'Observed empirical metric confirmed under standard conditions.',
        reliability: parseFloat(evidenceReliability) || 0.90
      };
    }

    onSubmit(claimText.trim(), evidencePayload);
    onClose();
    setClaimText('');
    setAttachEvidence(false);
    setEvidenceTitle('');
    setEvidenceContent('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 font-mono">
      <div className="bg-[#11131a] border border-[#252936] rounded-lg p-5 max-w-xl w-full text-xs space-y-4 shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#252936]">
          <div className="flex items-center space-x-2 text-sm font-bold text-[#f8fafc] uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>PROPOSE PROPOSITION FOR EPISTEMIC RATIFICATION</span>
          </div>
          <button
            onClick={onClose}
            className="text-[#64748b] hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="text-[#8a93a6] text-[10px] block font-bold uppercase mb-1">
              PROPOSITION STATEMENT
            </label>
            <textarea
              value={claimText}
              onChange={e => setClaimText(e.target.value)}
              placeholder="e.g., Quantitative easing increases commercial bank excess reserves during liquidity trap regimes."
              className="w-full h-20 bg-[#161922] border border-[#252936] text-xs text-[#f1f5f9] p-2.5 rounded focus:outline-none focus:border-amber-400"
              required
            />
            <p className="text-[10px] text-[#64748b] mt-1">
              Will be decomposed through Kant's 4 categories, 8 independent validators, and tested against conditions of possible experience.
            </p>
          </div>

          {/* Toggle Empirical Evidence */}
          <div className="pt-2 border-t border-[#1e222e]">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center space-x-2 cursor-pointer text-[#cbd5e1]">
                <input
                  type="checkbox"
                  checked={attachEvidence}
                  onChange={e => setAttachEvidence(e.target.checked)}
                  className="rounded border-[#32384a] text-amber-500 focus:ring-0"
                />
                <span className="font-bold text-[11px] text-cyan-300">ATTACH EMPIRICAL EVIDENCE / EXPERIMENTAL DATASET</span>
              </label>
            </div>

            {attachEvidence && (
              <div className="space-y-2 bg-[#0c0d12] p-3 rounded border border-[#252936]">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[#64748b] text-[10px] block">SOURCE TITLE / CITATION</label>
                    <input
                      type="text"
                      value={evidenceTitle}
                      onChange={e => setEvidenceTitle(e.target.value)}
                      placeholder="e.g., Federal Reserve H.4.1 Release"
                      className="w-full bg-[#161922] border border-[#252936] text-xs text-[#f1f5f9] p-1.5 rounded focus:outline-none focus:border-cyan-400"
                      required={attachEvidence}
                    />
                  </div>
                  <div>
                    <label className="text-[#64748b] text-[10px] block">PROVENANCE / REPOSITORY</label>
                    <input
                      type="text"
                      value={evidenceProvenance}
                      onChange={e => setEvidenceProvenance(e.target.value)}
                      placeholder="e.g., FRED St. Louis / NIST"
                      className="w-full bg-[#161922] border border-[#252936] text-xs text-[#f1f5f9] p-1.5 rounded focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[#64748b] text-[10px] block">AUTHOR / INSTITUTION</label>
                    <input
                      type="text"
                      value={evidenceAuthor}
                      onChange={e => setEvidenceAuthor(e.target.value)}
                      placeholder="e.g., Board of Governors"
                      className="w-full bg-[#161922] border border-[#252936] text-xs text-[#f1f5f9] p-1.5 rounded focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="text-[#64748b] text-[10px] block">RELIABILITY METRIC (0.0 - 1.0)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0.1"
                      max="1.0"
                      value={evidenceReliability}
                      onChange={e => setEvidenceReliability(e.target.value)}
                      className="w-full bg-[#161922] border border-[#252936] text-xs text-[#f1f5f9] p-1.5 rounded focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[#64748b] text-[10px] block">EMPIRICAL CONTENT / OBSERVATION SUMMARY</label>
                  <textarea
                    value={evidenceContent}
                    onChange={e => setEvidenceContent(e.target.value)}
                    placeholder="Enter raw measurements or primary text..."
                    className="w-full h-14 bg-[#161922] border border-[#252936] text-xs text-[#f1f5f9] p-1.5 rounded focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-2 pt-3 border-t border-[#1e222e]">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-[#8a93a6] hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs uppercase tracking-wider rounded cursor-pointer transition-colors shadow-sm shadow-amber-500/20"
            >
              Commit Proposition
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
