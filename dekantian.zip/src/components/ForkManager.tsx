import React, { useState } from 'react';
import { EpistemicFork } from '../types/epistemic';
import { ForkEngine } from '../engine/fork';
import { 
  GitBranch, 
  CheckCircle2, 
  ShieldCheck, 
  Layers, 
  Plus, 
  HelpCircle,
  TrendingUp,
  Award,
  AlertCircle
} from 'lucide-react';

interface ForkManagerProps {
  forks: EpistemicFork[];
  onUpdateForks: (updatedForks: EpistemicFork[]) => void;
}

export const ForkManager: React.FC<ForkManagerProps> = ({
  forks,
  onUpdateForks
}) => {
  const [activeForkId, setActiveForkId] = useState<string>(forks[0]?.id || '');
  const [isProposingBranch, setIsProposingBranch] = useState(false);
  const [newBranchLabel, setNewBranchLabel] = useState('');
  const [newBranchText, setNewBranchText] = useState('');
  const [newBranchSummary, setNewBranchSummary] = useState('');

  const currentFork = forks.find(f => f.id === activeForkId) || forks[0];

  const handleSelectCanonical = (forkId: string, branchId: string) => {
    const updated = forks.map(f => {
      if (f.id === forkId) {
        return ForkEngine.selectCanonicalBranch(f, branchId);
      }
      return f;
    });
    onUpdateForks(updated);
  };

  const handleAddBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranchLabel.trim() || !newBranchText.trim() || !currentFork) return;

    const newBranch = {
      id: `branch-${Date.now().toString(36)}`,
      label: newBranchLabel.trim(),
      claimText: newBranchText.trim(),
      epistemicWeight: 0.785,
      evidenceScore: 0.80,
      logicalCoherence: 0.90,
      explanatoryPower: 0.82,
      isCanonical: false,
      advocateValidator: 'LINGUISTIC_VALIDATOR',
      argumentSummary: newBranchSummary.trim() || 'Alternative theoretical framework proposed by peer node.'
    };

    const updated = forks.map(f => {
      if (f.id === currentFork.id) {
        return {
          ...f,
          branches: [...f.branches, newBranch]
        };
      }
      return f;
    });

    onUpdateForks(updated);
    setNewBranchLabel('');
    setNewBranchText('');
    setNewBranchSummary('');
    setIsProposingBranch(false);
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Header Banner */}
      <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center space-x-2 text-sm font-bold text-[#f8fafc] uppercase tracking-wider mb-1">
              <GitBranch className="w-4 h-4 text-amber-400" />
              <span>EPISTEMIC FORK CHOICE & COMPETING INTERPRETATIONS (SECTION 11)</span>
            </div>
            <p className="text-xs text-[#8a93a6] font-sans">
              Preserving rival theories rather than prematurely collapsing uncertainty. The network maintains multiple candidate interpretations and transparently calculates canonical weight.
            </p>
          </div>

          <button
            onClick={() => setIsProposingBranch(!isProposingBranch)}
            className="px-3 py-1.5 bg-[#1e222e] hover:bg-[#282f40] text-amber-300 border border-amber-500/30 rounded text-xs flex items-center space-x-1.5 cursor-pointer transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Propose Competing Branch</span>
          </button>
        </div>
      </div>

      {/* Fork Selector Tabs */}
      <div className="flex space-x-2 overflow-x-auto pb-1">
        {forks.map(fork => {
          const isSelected = fork.id === currentFork?.id;
          return (
            <button
              key={fork.id}
              onClick={() => setActiveForkId(fork.id)}
              className={`px-3 py-2 text-xs rounded border transition-all text-left cursor-pointer whitespace-nowrap ${
                isSelected
                  ? 'bg-[#1a1e2b] border-amber-400 text-amber-300 font-bold shadow-sm'
                  : 'bg-[#141722] border-[#252936] text-[#8a93a6] hover:text-[#cbd5e1] hover:border-[#384055]'
              }`}
            >
              <div className="font-bold truncate">{fork.name}</div>
              <div className="text-[10px] text-[#64748b] mt-0.5">{fork.branches.length} BRANCHES</div>
            </button>
          );
        })}
      </div>

      {/* Competing Branch Submission Form */}
      {isProposingBranch && currentFork && (
        <form onSubmit={handleAddBranch} className="p-4 bg-[#141722] border border-amber-500/40 rounded-lg text-xs space-y-3">
          <div className="text-xs font-bold text-amber-400 uppercase flex items-center space-x-1">
            <Plus className="w-4 h-4" />
            <span>PROPOSE ALTERNATIVE BRANCH FOR: {currentFork.name}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="text-[#8a93a6] text-[10px] block mb-1">BRANCH LABEL</label>
              <input
                type="text"
                value={newBranchLabel}
                onChange={e => setNewBranchLabel(e.target.value)}
                placeholder="e.g., Branch Delta (Institutional Friction Primacy)"
                className="w-full bg-[#0c0d12] border border-[#252936] text-xs text-[#f1f5f9] p-2 rounded focus:outline-none focus:border-amber-400"
                required
              />
            </div>
            <div>
              <label className="text-[#8a93a6] text-[10px] block mb-1">ARGUMENT SUMMARY / EVIDENCE RATIONALE</label>
              <input
                type="text"
                value={newBranchSummary}
                onChange={e => setNewBranchSummary(e.target.value)}
                placeholder="Explain the causal identification or conceptual advantage..."
                className="w-full bg-[#0c0d12] border border-[#252936] text-xs text-[#f1f5f9] p-2 rounded focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div>
            <label className="text-[#8a93a6] text-[10px] block mb-1">PROPOSITION CLAIM TEXT</label>
            <textarea
              value={newBranchText}
              onChange={e => setNewBranchText(e.target.value)}
              placeholder="Full text of the competing proposition..."
              className="w-full h-18 bg-[#0c0d12] border border-[#252936] text-xs text-[#f1f5f9] p-2 rounded focus:outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="flex justify-end space-x-2 pt-1">
            <button
              type="button"
              onClick={() => setIsProposingBranch(false)}
              className="px-3 py-1.5 text-xs text-[#8a93a6] hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs rounded cursor-pointer transition-colors"
            >
              Register Candidate Branch
            </button>
          </div>
        </form>
      )}

      {/* Selected Fork Detailed Branches */}
      {currentFork && (
        <div className="space-y-4">
          <div className="p-3 bg-[#131620] border border-[#252936] rounded-md text-xs">
            <div className="text-[#64748b] text-[10px] uppercase font-bold mb-0.5">DIVERGENCE RATIONALE</div>
            <p className="text-[#cbd5e1] leading-relaxed">{currentFork.divergenceReason}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentFork.branches.map(branch => {
              const isCanonical = branch.isCanonical;
              return (
                <div
                  key={branch.id}
                  className={`p-4 rounded-lg border text-xs flex flex-col justify-between transition-all ${
                    isCanonical
                      ? 'bg-[#181d2c] border-emerald-500/60 shadow-lg shadow-emerald-950/20 ring-1 ring-emerald-500/30'
                      : 'bg-[#131620] border-[#252936] hover:border-[#384055]'
                  }`}
                >
                  <div>
                    {/* Top Status */}
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-[#f8fafc] text-xs">{branch.label}</span>
                      {isCanonical ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center space-x-1">
                          <Award className="w-3 h-3" />
                          <span>CANONICAL</span>
                        </span>
                      ) : (
                        <span className="text-[10px] text-[#64748b] uppercase">COMPETING BRANCH</span>
                      )}
                    </div>

                    {/* Proposition Text */}
                    <blockquote className="text-xs font-sans text-[#e2e8f0] bg-[#0c0d12] p-2.5 rounded border border-[#1e222e] leading-relaxed mb-3">
                      "{branch.claimText}"
                    </blockquote>

                    {/* Rationale */}
                    <p className="text-[11px] text-[#94a3b8] mb-4 leading-relaxed">
                      {branch.argumentSummary}
                    </p>

                    {/* Weight Metrics Bar */}
                    <div className="space-y-2 pt-3 border-t border-[#1e222e] text-[11px]">
                      <div>
                        <div className="flex justify-between text-[#8a93a6] mb-0.5 text-[10px]">
                          <span>EVIDENCE WEIGHT</span>
                          <span className="text-emerald-400 font-bold">{(branch.evidenceScore * 100).toFixed(0)}%</span>
                        </div>
                        <div className="h-1.5 bg-[#0c0d12] rounded overflow-hidden">
                          <div
                            className="h-full bg-emerald-400"
                            style={{ width: `${branch.evidenceScore * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[#8a93a6] mb-0.5 text-[10px]">
                          <span>LOGICAL COHERENCE</span>
                          <span className="text-cyan-400 font-bold">{(branch.logicalCoherence * 100).toFixed(0)}%</span>
                        </div>
                        <div className="h-1.5 bg-[#0c0d12] rounded overflow-hidden">
                          <div
                            className="h-full bg-cyan-400"
                            style={{ width: `${branch.logicalCoherence * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[#8a93a6] mb-0.5 text-[10px]">
                          <span>EXPLANATORY POWER</span>
                          <span className="text-purple-400 font-bold">{(branch.explanatoryPower * 100).toFixed(0)}%</span>
                        </div>
                        <div className="h-1.5 bg-[#0c0d12] rounded overflow-hidden">
                          <div
                            className="h-full bg-purple-400"
                            style={{ width: `${branch.explanatoryPower * 100}%` }}
                          />
                        </div>
                      </div>

                      <div className="pt-2 flex items-center justify-between text-xs">
                        <span className="text-[#8a93a6] font-bold">EPISTEMIC STAKE:</span>
                        <span className="text-amber-400 font-bold text-sm">
                          {branch.epistemicWeight.toFixed(3)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Canonical Selection Action */}
                  <div className="mt-4 pt-3 border-t border-[#1e222e]">
                    {isCanonical ? (
                      <div className="text-center text-[11px] text-emerald-400 font-bold py-1 flex items-center justify-center space-x-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>CURRENT CANONICAL CHOICE</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleSelectCanonical(currentFork.id, branch.id)}
                        className="w-full py-1.5 bg-[#1e222e] hover:bg-[#282f40] text-[#cbd5e1] hover:text-white border border-[#32384a] rounded text-xs transition-colors cursor-pointer"
                      >
                        Elevate to Canonical Choice
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
