import React, { useState } from 'react';
import { 
  PropositionClaim, 
  Attestation, 
  AttestationDecision 
} from '../types/epistemic';
import { formatHash } from '../engine/crypto';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  HelpCircle, 
  Layers, 
  Scale, 
  Clock, 
  Cpu, 
  FlaskConical, 
  BookOpen, 
  GitCommit, 
  BarChart3, 
  ShieldCheck, 
  ExternalLink,
  Edit3,
  Hash,
  ChevronDown,
  ChevronUp,
  Info
} from 'lucide-react';

interface PropositionValidatorProps {
  claim: PropositionClaim;
  onRevise: (claimId: string, newText: string) => void;
  onSelectClaim: (claim: PropositionClaim) => void;
  onNavigateToFork?: () => void;
  onNavigateToAntinomy?: () => void;
}

export const PropositionValidator: React.FC<PropositionValidatorProps> = ({
  claim,
  onRevise,
  onNavigateToFork,
  onNavigateToAntinomy
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'pipeline' | 'validators' | 'transcendental' | 'consensus' | 'evidence'>('pipeline');
  const [isRevising, setIsRevising] = useState(false);
  const [revisionText, setRevisionText] = useState(claim.text);
  const [expandedSection, setExpandedSection] = useState<string | null>('categories');

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'FINALIZED':
        return (
          <span className="px-2.5 py-1 text-xs font-mono font-semibold rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center space-x-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>CANONICAL FINALIZED</span>
          </span>
        );
      case 'JUSTIFIED':
        return (
          <span className="px-2.5 py-1 text-xs font-mono font-semibold rounded bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 flex items-center space-x-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>JUSTIFIED BELIEF</span>
          </span>
        );
      case 'CONDITIONAL':
        return (
          <span className="px-2.5 py-1 text-xs font-mono font-semibold rounded bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center space-x-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>CONDITIONAL CONSENSUS</span>
          </span>
        );
      case 'CONTRADICTED':
      case 'REJECTED':
        return (
          <span className="px-2.5 py-1 text-xs font-mono font-semibold rounded bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center space-x-1">
            <XCircle className="w-3.5 h-3.5" />
            <span>CONTRADICTION VIOLATION</span>
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 text-xs font-mono font-semibold rounded bg-zinc-700/40 text-zinc-300 border border-zinc-600/40 flex items-center space-x-1">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>PENDING ATTESTATIONS</span>
          </span>
        );
    }
  };

  const getDecisionBadge = (decision: AttestationDecision) => {
    switch (decision) {
      case 'VALID':
      case 'ANALYTICAL':
      case 'EMPIRICAL':
        return <span className="text-emerald-400 font-semibold">VALID</span>;
      case 'CONDITIONAL':
        return <span className="text-amber-400 font-semibold">CONDITIONAL</span>;
      case 'INSUFFICIENT_EVIDENCE':
        return <span className="text-amber-300 font-semibold">INSUFFICIENT</span>;
      case 'CONTRADICTED':
      case 'INVALID':
        return <span className="text-rose-400 font-semibold">INVALID</span>;
      case 'METAPHYSICAL':
        return <span className="text-purple-400 font-semibold">METAPHYSICAL</span>;
      default:
        return <span className="text-zinc-400 font-semibold">{decision}</span>;
    }
  };

  const handleApplyRevision = () => {
    if (revisionText.trim() && revisionText !== claim.text) {
      onRevise(claim.id, revisionText.trim());
      setIsRevising(false);
    }
  };

  return (
    <div className="bg-[#11131a] border border-[#252936] rounded-lg shadow-xl overflow-hidden font-mono">
      {/* Proposition Header Banner */}
      <div className="p-4 bg-[#151822] border-b border-[#252936]">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="flex items-center space-x-2 text-xs text-[#8a93a6]">
            <span className="text-[#64748b]">PROPOSITION ID:</span>
            <span className="text-[#f1f5f9] font-bold">{claim.id}</span>
            <span className="text-[#32384a]">/</span>
            <span className="text-[#64748b]">BLOCK:</span>
            <span className="text-cyan-400">#{claim.blockId}</span>
            <span className="text-[#32384a]">/</span>
            <span className="text-[#64748b]">VERSION:</span>
            <span className="text-amber-400">v{claim.version}</span>
          </div>

          <div className="flex items-center space-x-2">
            {getStatusBadge(claim.status)}
            <button
              onClick={() => setIsRevising(!isRevising)}
              className="px-2.5 py-1 text-xs text-[#cbd5e1] hover:text-white bg-[#1e222e] hover:bg-[#252936] border border-[#32384a] rounded flex items-center space-x-1 cursor-pointer transition-colors"
              title="Revise proposition without erasing historical ledger lineage"
            >
              <Edit3 className="w-3 h-3 text-amber-400" />
              <span>Revise</span>
            </button>
          </div>
        </div>

        {/* Claim Text or Revision Form */}
        {isRevising ? (
          <div className="mt-2 p-3 bg-[#0c0d12] border border-amber-500/30 rounded">
            <div className="text-xs text-amber-300 font-semibold mb-1 flex items-center space-x-1">
              <Info className="w-3.5 h-3.5 text-amber-400" />
              <span>HISTORICAL REVISION PROTOCOL (OLD CLAIM → REVISION → NEW CLAIM)</span>
            </div>
            <textarea
              value={revisionText}
              onChange={e => setRevisionText(e.target.value)}
              className="w-full h-20 bg-[#161922] border border-[#32384a] text-[#f1f5f9] text-sm p-2 rounded focus:outline-none focus:border-amber-400"
            />
            <div className="flex justify-end space-x-2 mt-2">
              <button
                onClick={() => setIsRevising(false)}
                className="px-3 py-1 text-xs text-[#8a93a6] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyRevision}
                className="px-3 py-1 text-xs bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded cursor-pointer transition-colors"
              >
                Submit Lineage Revision
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-1">
            <blockquote className="text-base md:text-lg font-medium text-[#f8fafc] leading-relaxed border-l-2 border-amber-500 pl-3">
              "{claim.text}"
            </blockquote>
          </div>
        )}

        {/* Essential Kantian Tags */}
        <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-[#1e222e] text-[11px]">
          <div className="px-2 py-0.5 bg-[#1a1e2a] border border-[#2b3142] rounded text-[#94a3b8]">
            JUDGEMENT: <span className="text-[#f1f5f9] font-semibold">{claim.judgementClass}</span>
          </div>
          <div className="px-2 py-0.5 bg-[#1a1e2a] border border-[#2b3142] rounded text-[#94a3b8]">
            ORIGIN: <span className="text-[#f1f5f9] font-semibold">{claim.origin}</span>
          </div>
          <div className="px-2 py-0.5 bg-[#1a1e2a] border border-[#2b3142] rounded text-[#94a3b8]">
            BOUNDARY: <span className="text-cyan-300 font-semibold">{claim.boundaryDomain}</span>
          </div>
          <div className="px-2 py-0.5 bg-[#1a1e2a] border border-[#2b3142] rounded text-[#94a3b8]">
            CERTAINTY: <span className="text-amber-300 font-semibold">{claim.certainty}</span>
          </div>
          <div className="px-2 py-0.5 bg-[#1a1e2a] border border-[#2b3142] rounded text-[#94a3b8] ml-auto">
            STATE HASH: <span className="text-zinc-400">{formatHash(claim.hash)}</span>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex border-b border-[#252936] bg-[#0c0e14] px-4 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('pipeline')}
          className={`py-2 px-3 text-xs font-mono tracking-wider border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
            activeSubTab === 'pipeline'
              ? 'border-amber-400 text-amber-300 font-bold bg-amber-400/5'
              : 'border-transparent text-[#8a93a6] hover:text-[#e1e4ea]'
          }`}
        >
          COGNITIVE PIPELINE
        </button>
        <button
          onClick={() => setActiveSubTab('validators')}
          className={`py-2 px-3 text-xs font-mono tracking-wider border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
            activeSubTab === 'validators'
              ? 'border-amber-400 text-amber-300 font-bold bg-amber-400/5'
              : 'border-transparent text-[#8a93a6] hover:text-[#e1e4ea]'
          }`}
        >
          VALIDATOR ATTESTATIONS ({claim.attestations?.length || 0})
        </button>
        <button
          onClick={() => setActiveSubTab('transcendental')}
          className={`py-2 px-3 text-xs font-mono tracking-wider border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
            activeSubTab === 'transcendental'
              ? 'border-amber-400 text-amber-300 font-bold bg-amber-400/5'
              : 'border-transparent text-[#8a93a6] hover:text-[#e1e4ea]'
          }`}
        >
          TRANSCENDENTAL DEDUCTION
        </button>
        <button
          onClick={() => setActiveSubTab('consensus')}
          className={`py-2 px-3 text-xs font-mono tracking-wider border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
            activeSubTab === 'consensus'
              ? 'border-amber-400 text-amber-300 font-bold bg-amber-400/5'
              : 'border-transparent text-[#8a93a6] hover:text-[#e1e4ea]'
          }`}
        >
          CONSENSUS REPORT & FINALITY
        </button>
        <button
          onClick={() => setActiveSubTab('evidence')}
          className={`py-2 px-3 text-xs font-mono tracking-wider border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
            activeSubTab === 'evidence'
              ? 'border-amber-400 text-amber-300 font-bold bg-amber-400/5'
              : 'border-transparent text-[#8a93a6] hover:text-[#e1e4ea]'
          }`}
        >
          EVIDENCE & SOURCES ({claim.evidence?.length || 0})
        </button>
      </div>

      {/* Tab Content Panes */}
      <div className="p-4">
        {/* PANE 1: COGNITIVE PIPELINE */}
        {activeSubTab === 'pipeline' && (
          <div className="space-y-4">
            {/* Kantian Categories of Understanding (Quantity, Quality, Relation, Modality) */}
            <div className="p-3 bg-[#161922] border border-[#252936] rounded">
              <div className="flex items-center justify-between text-xs font-semibold text-[#f1f5f9] mb-2">
                <span className="text-amber-400 flex items-center space-x-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  <span>KANTIAN CATEGORIES OF UNDERSTANDING (PURE CONCEPTS)</span>
                </span>
                <span className="text-[#64748b] text-[10px]">SECTION 13 PROTOCOL</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                  <div className="text-[#64748b] text-[10px]">1. QUANTITY</div>
                  <div className="font-bold text-cyan-300">{claim.categories.quantity}</div>
                  <div className="text-[10px] text-[#8a93a6] mt-0.5">Scope of manifold</div>
                </div>
                <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                  <div className="text-[#64748b] text-[10px]">2. QUALITY</div>
                  <div className="font-bold text-emerald-300">{claim.categories.quality}</div>
                  <div className="text-[10px] text-[#8a93a6] mt-0.5">Degree of reality</div>
                </div>
                <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                  <div className="text-[#64748b] text-[10px]">3. RELATION</div>
                  <div className="font-bold text-amber-300">{claim.categories.relation}</div>
                  <div className="text-[10px] text-[#8a93a6] mt-0.5">Causal / Substance</div>
                </div>
                <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                  <div className="text-[#64748b] text-[10px]">4. MODALITY</div>
                  <div className="font-bold text-purple-300">{claim.categories.modality}</div>
                  <div className="text-[10px] text-[#8a93a6] mt-0.5">Possibility/Necessity</div>
                </div>
              </div>
              <p className="text-xs text-[#94a3b8] mt-2 italic bg-[#0c0d12] p-2 rounded border border-[#1e222e]">
                {claim.categories.explanation}
              </p>
            </div>

            {/* Judgement Engine (Subject, Predicate, Form, Scope) */}
            <div className="p-3 bg-[#161922] border border-[#252936] rounded">
              <div className="text-xs font-semibold text-cyan-400 mb-2 flex items-center space-x-1.5">
                <Cpu className="w-3.5 h-3.5" />
                <span>JUDGEMENT ENGINE (FORMAL LOGICAL STRUCTURE)</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                  <span className="text-[#64748b] text-[10px] block">SUBJECT (Substance/Object)</span>
                  <span className="font-semibold text-[#f1f5f9]">{claim.judgement.subject}</span>
                </div>
                <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                  <span className="text-[#64748b] text-[10px] block">PREDICATE (Asserted Property)</span>
                  <span className="font-semibold text-amber-300">{claim.judgement.predicate}</span>
                </div>
                <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                  <span className="text-[#64748b] text-[10px] block">LOGICAL FORM</span>
                  <span className="font-semibold text-[#e2e8f0]">{claim.judgement.form} ({claim.judgement.modality})</span>
                </div>
              </div>
            </div>

            {/* Cognitive Decomposition: What is Given vs Constructed vs Inferred vs Assumed */}
            <div className="p-3 bg-[#161922] border border-[#252936] rounded">
              <div className="text-xs font-semibold text-[#cbd5e1] mb-2 flex items-center justify-between">
                <span>EPISTEMIC DECOMPOSITION (WHAT IS GIVEN vs CONSTRUCTED)</span>
                <span className="text-[#64748b] text-[10px]">SECTION 2 PRINCIPLE</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 bg-[#0d0f15] border border-[#252936] rounded">
                  <span className="text-emerald-400 font-bold block mb-1 text-[11px]">● WHAT IS GIVEN (RECEPTIVITY)</span>
                  <ul className="list-disc list-inside space-y-0.5 text-[#94a3b8] text-[11px]">
                    <li>Raw empirical sensory manifold / quantitative ledger data</li>
                    <li>Temporal interval markers registered at instrument interface</li>
                  </ul>
                </div>

                <div className="p-2.5 bg-[#0d0f15] border border-[#252936] rounded">
                  <span className="text-cyan-400 font-bold block mb-1 text-[11px]">● WHAT IS CONSTRUCTED (SYNTHESIS)</span>
                  <ul className="list-disc list-inside space-y-0.5 text-[#94a3b8] text-[11px]">
                    <li>Synthetic connection linking predicate to subject concept</li>
                    <li>Measurement scale schema and operational definitions</li>
                  </ul>
                </div>

                <div className="p-2.5 bg-[#0d0f15] border border-[#252936] rounded">
                  <span className="text-amber-400 font-bold block mb-1 text-[11px]">● WHAT IS INFERRED (REASON)</span>
                  <ul className="list-disc list-inside space-y-0.5 text-[#94a3b8] text-[11px]">
                    <li>Inductive generalization beyond the finite observation set</li>
                    <li>Underlying causal or relational invariance rule</li>
                  </ul>
                </div>

                <div className="p-2.5 bg-[#0d0f15] border border-[#252936] rounded">
                  <span className="text-purple-400 font-bold block mb-1 text-[11px]">● WHAT IS ASSUMED (PRESUPPOSITIONS)</span>
                  <ul className="list-disc list-inside space-y-0.5 text-[#94a3b8] text-[11px]">
                    <li>Homogeneity of physical/market laws across unobserved epochs</li>
                    <li>Absence of uncorrected systemic measurement distortion</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Knowledge Boundary Warning if Metaphysical */}
            {claim.boundaryDomain === 'METAPHYSICAL_CLAIMS' && (
              <div className="p-3 bg-purple-950/20 border border-purple-500/40 rounded flex items-start space-x-3 text-xs">
                <AlertTriangle className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-purple-300 font-bold">PHENOMENON / NOUMENON BOUNDARY ALERT (SECTION 17)</div>
                  <p className="text-purple-200/80 mt-1">
                    This claim exceeds the conditions of possible sensible experience. It attempts to make an apodictic assertion regarding the thing-in-itself (noumenon) rather than empirical appearances. The system preserves it as a regulative idea, but it cannot achieve empirical finality.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* PANE 2: VALIDATOR ATTESTATIONS */}
        {activeSubTab === 'validators' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-[#8a93a6] px-1 font-mono">
              <span>INDEPENDENT VALIDATOR SET (8 NODES)</span>
              <span>PROOF-OF-STAKE EPISTEMIC WEIGHTS</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {claim.attestations?.map((att, idx) => (
                <div 
                  key={att.id || idx} 
                  className="p-3 bg-[#161922] border border-[#252936] rounded hover:border-[#3a4155] transition-colors text-xs"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-[#f1f5f9]">{att.validatorName}</span>
                      <span className="text-[10px] px-1.5 py-0.2 bg-[#0c0d12] border border-[#252936] text-[#8a93a6] rounded">
                        wt: {att.epistemicWeight.toFixed(2)}x
                      </span>
                    </div>
                    <div>{getDecisionBadge(att.decision)}</div>
                  </div>

                  <p className="text-[#94a3b8] text-[11px] leading-relaxed mb-2">
                    {att.reasoning}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-[#1e222e] text-[10px] text-[#64748b]">
                    <div>
                      CONFIDENCE:{' '}
                      <span className="text-cyan-400 font-semibold">{(att.confidence * 100).toFixed(0)}%</span>
                    </div>
                    <div title={att.signature}>
                      SIG: <span className="text-zinc-400 font-mono">{formatHash(att.signature, 8)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* PANE 3: TRANSCENDENTAL DEDUCTION */}
        {activeSubTab === 'transcendental' && (
          <div className="space-y-4">
            <div className="p-3 bg-[#161922] border border-[#252936] rounded text-xs">
              <div className="text-amber-400 font-semibold mb-2 flex items-center space-x-1.5">
                <HelpCircle className="w-4 h-4" />
                <span>THE TRANSCENDENTAL QUESTION (KANT'S CRITICAL INQUIRY)</span>
              </div>
              <blockquote className="text-sm font-serif italic text-[#e2e8f0] bg-[#0c0d12] p-3 rounded border border-amber-500/20">
                "{claim.transcendental.transcendentalQuestion}"
              </blockquote>
            </div>

            <div className="p-3 bg-[#161922] border border-[#252936] rounded text-xs space-y-3">
              <div>
                <span className="text-[#64748b] text-[10px] block font-bold uppercase">Experience Phenomenon</span>
                <p className="text-[#f1f5f9] mt-0.5">{claim.transcendental.experiencePhenomenon}</p>
              </div>

              <div>
                <span className="text-cyan-400 text-[10px] block font-bold uppercase">Necessary A Priori Conditions for Experience</span>
                <ul className="list-disc list-inside space-y-1 text-[#94a3b8] mt-1 text-[11px]">
                  {claim.transcendental.necessaryConditions.map((cond, i) => (
                    <li key={i}>{cond}</li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-amber-400 text-[10px] block font-bold uppercase">Limits of Experience Verification</span>
                <p className="text-[#cbd5e1] mt-0.5 text-[11px] bg-[#0c0d12] p-2 rounded border border-[#1e222e]">
                  {claim.transcendental.boundsOfExperience}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* PANE 4: CONSENSUS REPORT & FINALITY */}
        {activeSubTab === 'consensus' && (
          <div className="space-y-4 text-xs">
            {claim.consensus ? (
              <>
                <div className="p-3 bg-[#161922] border border-[#252936] rounded">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-cyan-400 font-semibold text-sm">
                      CONSENSUS AUDIT REPORT
                    </span>
                    <span className="text-[#8a93a6] text-xs">
                      AGREEMENT: <strong className="text-white">{claim.consensus.validatorAgreementRatio}</strong>
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                    <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                      <div className="text-[#64748b] text-[10px]">EMPIRICAL SUPPORT</div>
                      <div className="text-base font-bold text-emerald-400">
                        {(claim.consensus.empiricalSupport * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                      <div className="text-[#64748b] text-[10px]">LOGICAL COHERENCE</div>
                      <div className="text-base font-bold text-cyan-400">
                        {(claim.consensus.logicalCoherence * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                      <div className="text-[#64748b] text-[10px]">CAUSAL MECHANISM</div>
                      <div className="text-base font-bold text-amber-400">
                        {(claim.consensus.causalSupport * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="p-2 bg-[#0d0f15] border border-[#252936] rounded">
                      <div className="text-[#64748b] text-[10px]">STATISTICAL POWER</div>
                      <div className="text-base font-bold text-purple-400">
                        {(claim.consensus.statisticalConfidence * 100).toFixed(0)}%
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 bg-[#0c0d12] border border-[#1e222e] rounded mb-3">
                    <span className="text-[#64748b] text-[10px] block font-bold">PRIMARY CONSENSUS REASON</span>
                    <p className="text-[#f1f5f9] text-xs mt-0.5">{claim.consensus.primaryReason}</p>
                  </div>

                  {/* Finality Checklist */}
                  <div className="p-2.5 bg-[#0d0f15] border border-[#252936] rounded">
                    <span className="text-amber-400 text-xs font-bold block mb-2">
                      4 CRITERIA FOR CANONICAL EPISTEMIC FINALITY:
                    </span>
                    <div className="space-y-1.5 text-[11px]">
                      <div className="flex items-center space-x-2">
                        {claim.consensus.finalityCriteria.validatorsAgreed ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                        )}
                        <span className={claim.consensus.finalityCriteria.validatorsAgreed ? 'text-[#e2e8f0]' : 'text-[#94a3b8]'}>
                          1. Supermajority of independent validators agreed (≥6 / 8 quorum)
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {claim.consensus.finalityCriteria.evidenceThresholdMet ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                        )}
                        <span className={claim.consensus.finalityCriteria.evidenceThresholdMet ? 'text-[#e2e8f0]' : 'text-[#94a3b8]'}>
                          2. Evidence quality threshold satisfied (verified provenance or analytic proof)
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {claim.consensus.finalityCriteria.noUnresolvedContradictions ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                        )}
                        <span className={claim.consensus.finalityCriteria.noUnresolvedContradictions ? 'text-[#e2e8f0]' : 'text-[#94a3b8]'}>
                          3. Zero fatal contradictions with earlier canonical states
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {claim.consensus.finalityCriteria.withinValidDomain ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                        )}
                        <span className={claim.consensus.finalityCriteria.withinValidDomain ? 'text-[#e2e8f0]' : 'text-[#94a3b8]'}>
                          4. Proposition does not exceed the bounds of possible experience (Non-metaphysical)
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <p className="text-[#8a93a6]">Consensus not yet evaluated.</p>
            )}
          </div>
        )}

        {/* PANE 5: EVIDENCE & SOURCES */}
        {activeSubTab === 'evidence' && (
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between text-[#8a93a6]">
              <span>VERIFIED EVIDENCE LINEAGE (NEVER "AI SAID SO")</span>
              <span>TOTAL SOURCES: {claim.evidence?.length || 0}</span>
            </div>

            {claim.evidence && claim.evidence.length > 0 ? (
              claim.evidence.map(ev => (
                <div key={ev.id} className="p-3 bg-[#161922] border border-[#252936] rounded">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-[#f1f5f9]">{ev.title}</span>
                    <span className="px-2 py-0.5 text-[10px] bg-[#0c0d12] border border-[#252936] text-amber-300 rounded">
                      {ev.sourceType}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#64748b] mb-2">
                    PROVENANCE: <span className="text-[#94a3b8]">{ev.sourceProvenance}</span> • AUTHOR: <span className="text-[#94a3b8]">{ev.author} ({ev.year || 'N/A'})</span>
                  </div>
                  <p className="text-[#cbd5e1] text-[11px] bg-[#0c0d12] p-2 rounded border border-[#1e222e]">
                    "{ev.content}"
                  </p>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#1e222e] text-[10px] text-[#64748b]">
                    <span>RELIABILITY SCORE: <strong className="text-emerald-400">{(ev.reliabilityScore * 100).toFixed(0)}%</strong></span>
                    <span>SOURCE HASH: {formatHash(ev.hash, 8)}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 bg-[#161922] border border-dashed border-[#252936] rounded text-center text-[#8a93a6]">
                {claim.judgementClass === 'ANALYTIC' ? (
                  <p>Analytic a priori proposition: validated through conceptual containment without empirical sensor data.</p>
                ) : (
                  <p>No external empirical dataset currently attached. Validator confidence penalized accordingly.</p>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
