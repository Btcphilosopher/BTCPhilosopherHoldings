import React, { useState } from 'react';
import { AntinomyRecord } from '../types/epistemic';
import { 
  Scale, 
  AlertTriangle, 
  HelpCircle, 
  CheckCircle2, 
  ArrowRight, 
  ArrowDown, 
  Layers,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

interface DialecticalGraphProps {
  antinomies: AntinomyRecord[];
}

export const DialecticalGraph: React.FC<DialecticalGraphProps> = ({ antinomies }) => {
  const [selectedAntinomyId, setSelectedAntinomyId] = useState<string>(antinomies[0]?.id || '');

  const antinomy = antinomies.find(a => a.id === selectedAntinomyId) || antinomies[0];

  return (
    <div className="space-y-6 font-mono">
      {/* Title Banner */}
      <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
        <div className="flex items-center space-x-2 text-sm font-bold text-[#f8fafc] uppercase tracking-wider mb-1">
          <Scale className="w-4 h-4 text-purple-400" />
          <span>ANTINOMY ENGINE & DIALECTICAL GRAPH (SECTION 20 & 21)</span>
        </div>
        <p className="text-xs text-[#8a93a6] font-sans">
          When reason operates without empirical intuition, it generates pairs of equally defensible yet contradictory conclusions. DEKANTIAN detects these antinomies and applies transcendental analysis to dissolve the illusion.
        </p>
      </div>

      {/* Antinomy Selector Tabs */}
      <div className="flex space-x-2 overflow-x-auto pb-1">
        {antinomies.map(item => {
          const isSelected = item.id === antinomy?.id;
          return (
            <button
              key={item.id}
              onClick={() => setSelectedAntinomyId(item.id)}
              className={`px-3 py-2 text-xs rounded border transition-all cursor-pointer text-left whitespace-nowrap ${
                isSelected
                  ? 'bg-[#1e172e] border-purple-400 text-purple-300 font-bold shadow-sm'
                  : 'bg-[#141722] border-[#252936] text-[#8a93a6] hover:text-[#cbd5e1]'
              }`}
            >
              <div className="font-bold">{item.title}</div>
              <div className="text-[10px] text-[#64748b] mt-0.5">{item.domain}</div>
            </button>
          );
        })}
      </div>

      {/* Dialectical Visual Flowchart */}
      {antinomy && (
        <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg space-y-6">
          <div className="text-center max-w-xl mx-auto">
            <span className="px-2.5 py-1 text-[10px] uppercase font-bold bg-purple-500/10 text-purple-300 border border-purple-500/30 rounded">
              DIALECTICAL CONFLICT DETECTED: {antinomy.reasonConflictType}
            </span>
            <h3 className="text-base font-bold text-[#f8fafc] mt-2">{antinomy.title}</h3>
          </div>

          {/* Thesis vs Antithesis Side-by-Side Flow */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative">
            {/* THESIS BOX */}
            <div className="p-4 bg-[#151926] border border-cyan-500/40 rounded-lg space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#252936]">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  THESIS (DOGMATIC ASSERTION)
                </span>
                <span className="text-[10px] text-cyan-300 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-500/20">
                  Weight: {(antinomy.thesis.supportWeight * 100).toFixed(0)}%
                </span>
              </div>

              <div>
                <span className="text-[#64748b] text-[10px] block font-bold uppercase">PROPOSITION</span>
                <blockquote className="text-xs font-serif text-[#f1f5f9] leading-relaxed mt-0.5 bg-[#0c0d12] p-2.5 rounded border border-[#1e222e]">
                  "{antinomy.thesis.statement}"
                </blockquote>
              </div>

              <div>
                <span className="text-[#64748b] text-[10px] block font-bold uppercase">PROOF RATIONALE</span>
                <p className="text-xs text-[#cbd5e1] leading-relaxed mt-0.5">
                  {antinomy.thesis.proofRationale}
                </p>
              </div>

              <div className="pt-2 border-t border-[#1e222e]">
                <span className="text-cyan-400 text-[10px] block font-bold uppercase">UNCONSCIOUS ASSUMPTION</span>
                <p className="text-xs text-[#94a3b8] italic mt-0.5">
                  {antinomy.thesis.underlyingAssumption}
                </p>
              </div>
            </div>

            {/* ANTITHESIS BOX */}
            <div className="p-4 bg-[#1d1624] border border-amber-500/40 rounded-lg space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#252936]">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  ANTITHESIS (EMPIRICIST COUNTER)
                </span>
                <span className="text-[10px] text-amber-300 bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/20">
                  Weight: {(antinomy.antithesis.supportWeight * 100).toFixed(0)}%
                </span>
              </div>

              <div>
                <span className="text-[#64748b] text-[10px] block font-bold uppercase">PROPOSITION</span>
                <blockquote className="text-xs font-serif text-[#f1f5f9] leading-relaxed mt-0.5 bg-[#0c0d12] p-2.5 rounded border border-[#1e222e]">
                  "{antinomy.antithesis.statement}"
                </blockquote>
              </div>

              <div>
                <span className="text-[#64748b] text-[10px] block font-bold uppercase">PROOF RATIONALE</span>
                <p className="text-xs text-[#cbd5e1] leading-relaxed mt-0.5">
                  {antinomy.antithesis.proofRationale}
                </p>
              </div>

              <div className="pt-2 border-t border-[#1e222e]">
                <span className="text-amber-400 text-[10px] block font-bold uppercase">UNCONSCIOUS ASSUMPTION</span>
                <p className="text-xs text-[#94a3b8] italic mt-0.5">
                  {antinomy.antithesis.underlyingAssumption}
                </p>
              </div>
            </div>
          </div>

          {/* Central Conflict Node */}
          <div className="p-3 bg-[#13151f] border border-[#252936] rounded-md text-center max-w-lg mx-auto">
            <div className="flex items-center justify-center space-x-2 text-xs font-bold text-rose-400">
              <AlertTriangle className="w-4 h-4" />
              <span>THE TRANSCENDENTAL ILLUSION</span>
            </div>
            <p className="text-xs text-[#94a3b8] mt-1">
              Both arguments appear logically sound because each exposes the impossibility of the other when assuming the world is a given unconditioned thing-in-itself.
            </p>
          </div>

          {/* Transcendental Resolution */}
          <div className="p-4 bg-[#141724] border border-purple-500/50 rounded-lg text-xs space-y-2">
            <div className="flex items-center space-x-2 text-purple-300 font-bold text-xs uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>TRANSCENDENTAL CRITICAL DIAGNOSIS (KANTIAN RESOLUTION)</span>
            </div>
            <p className="text-[#e2e8f0] leading-relaxed font-sans text-xs sm:text-sm">
              {antinomy.transcendentalDiagnosis}
            </p>
            <div className="pt-2 flex items-center justify-between text-[11px] text-[#8a93a6]">
              <span>RESOLVED VIA PHENOMENON / NOUMENON BOUNDARY: <strong className="text-emerald-400">YES</strong></span>
              <span className="text-purple-300">CRITIQUE OF PURE REASON (A426/B454)</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
