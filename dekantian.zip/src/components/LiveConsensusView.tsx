import React, { useState } from 'react';
import { PropositionClaim, Attestation, EpistemicValidator } from '../types/epistemic';
import { formatHash } from '../engine/crypto';
import { 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  HelpCircle, 
  ShieldCheck, 
  Info,
  ChevronRight,
  Filter
} from 'lucide-react';

interface LiveConsensusViewProps {
  propositions: PropositionClaim[];
  validators: EpistemicValidator[];
  onSelectClaim: (claim: PropositionClaim) => void;
}

export const LiveConsensusView: React.FC<LiveConsensusViewProps> = ({
  propositions,
  validators,
  onSelectClaim
}) => {
  const [selectedAttestation, setSelectedAttestation] = useState<Attestation | null>(null);
  const [selectedPropId, setSelectedPropId] = useState<string>(propositions[0]?.id || '');

  const activeProposition = propositions.find(p => p.id === selectedPropId) || propositions[0];

  const getAttestationColor = (decision: string) => {
    switch (decision) {
      case 'VALID':
      case 'ANALYTICAL':
      case 'EMPIRICAL':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'CONDITIONAL':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      case 'INSUFFICIENT_EVIDENCE':
        return 'bg-amber-500/10 text-amber-300 border-amber-500/20';
      case 'CONTRADICTED':
      case 'INVALID':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      case 'METAPHYSICAL':
        return 'bg-purple-500/15 text-purple-400 border-purple-500/30';
      default:
        return 'bg-zinc-800 text-zinc-400 border-zinc-700';
    }
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Overview Banner */}
      <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
        <div className="flex items-center space-x-2 text-sm font-bold text-[#f8fafc] uppercase tracking-wider mb-1">
          <Layers className="w-4 h-4 text-amber-400" />
          <span>INDEPENDENT VALIDATOR CONSENSUS MATRIX (SECTION 9 & 10)</span>
        </div>
        <p className="text-xs text-[#8a93a6] font-sans">
          8 autonomous epistemic validators independently audit propositions. Proof-of-stake weights prevent majority tyranny and ensure domain-appropriate verification.
        </p>
      </div>

      {/* Main Grid: Proposition Selector + Consensus Walkthrough */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Proposition selector (4 cols) */}
        <div className="lg:col-span-4 space-y-2">
          <div className="text-xs text-[#8a93a6] font-bold uppercase mb-2">
            ACTIVE PROPOSITIONS ({propositions.length})
          </div>

          <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
            {propositions.map(prop => {
              const isSelected = prop.id === activeProposition?.id;
              return (
                <div
                  key={prop.id}
                  onClick={() => {
                    setSelectedPropId(prop.id);
                    setSelectedAttestation(null);
                  }}
                  className={`p-3 rounded border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#1a1e2b] border-amber-400 shadow-md'
                      : 'bg-[#141722] border-[#252936] hover:border-[#384055]'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-[#8a93a6] mb-1">
                    <span className="font-bold text-[#f1f5f9]">{prop.id}</span>
                    <span className={
                      prop.status === 'FINALIZED' ? 'text-emerald-400 font-bold' :
                      prop.status === 'JUSTIFIED' ? 'text-cyan-400 font-bold' :
                      prop.status === 'CONDITIONAL' ? 'text-amber-400 font-bold' : 'text-rose-400'
                    }>
                      {prop.status}
                    </span>
                  </div>
                  <p className="text-xs text-[#e2e8f0] font-sans truncate mb-2">
                    "{prop.text}"
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-[#64748b]">
                    <span>{prop.attestations?.length || 0} ATTESTATIONS</span>
                    <span className="text-amber-300 font-semibold">{prop.judgementClass}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Consensus Breakdown & Attestation Detail (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {activeProposition && (
            <>
              {/* Selected Proposition Summary */}
              <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
                <div className="flex flex-wrap items-center justify-between text-xs text-[#8a93a6] mb-2">
                  <span>PROPOSITION EVALUATION</span>
                  <span className="text-cyan-400 font-bold">STATUS: {activeProposition.status}</span>
                </div>
                <blockquote className="text-sm md:text-base font-semibold text-[#f8fafc] border-l-2 border-amber-400 pl-3 mb-3">
                  "{activeProposition.text}"
                </blockquote>

                {/* Consensus Metrics Ribbon */}
                {activeProposition.consensus && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-3 border-t border-[#1e222e]">
                    <div className="p-2 bg-[#161922] border border-[#252936] rounded">
                      <span className="text-[#64748b] text-[10px] block">EMPIRICAL SUPPORT</span>
                      <span className="text-emerald-400 font-bold text-sm">
                        {(activeProposition.consensus.empiricalSupport * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="p-2 bg-[#161922] border border-[#252936] rounded">
                      <span className="text-[#64748b] text-[10px] block">CAUSAL INVARIANCE</span>
                      <span className="text-amber-400 font-bold text-sm">
                        {(activeProposition.consensus.causalSupport * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="p-2 bg-[#161922] border border-[#252936] rounded">
                      <span className="text-[#64748b] text-[10px] block">LOGICAL COHERENCE</span>
                      <span className="text-cyan-400 font-bold text-sm">
                        {(activeProposition.consensus.logicalCoherence * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="p-2 bg-[#161922] border border-[#252936] rounded">
                      <span className="text-[#64748b] text-[10px] block">QUORUM AGREEMENT</span>
                      <span className="text-purple-300 font-bold text-sm">
                        {activeProposition.consensus.validatorAgreementRatio}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Attestation Grid: 8 Validators */}
              <div className="p-4 bg-[#11131a] border border-[#252936] rounded-lg">
                <div className="flex items-center justify-between text-xs text-[#8a93a6] font-bold uppercase mb-3">
                  <span>ATTESTATION CARDS (CLICK TO INSPECT SIGNED AUDIT)</span>
                  <span className="text-[10px] text-[#64748b]">PROVABLY SIGNED</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {activeProposition.attestations?.map(att => {
                    const isSelected = selectedAttestation?.id === att.id;
                    return (
                      <div
                        key={att.id}
                        onClick={() => setSelectedAttestation(att)}
                        className={`p-3 rounded border text-xs transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#1c202d] border-cyan-400 shadow-md'
                            : 'bg-[#151822] border-[#252936] hover:border-[#384055]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="font-bold text-[#f1f5f9]">{att.validatorName}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getAttestationColor(att.decision)}`}>
                            {att.decision}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#94a3b8] line-clamp-2 mb-2">
                          {att.reasoning}
                        </p>
                        <div className="flex items-center justify-between text-[10px] text-[#64748b] pt-1.5 border-t border-[#1e222e]">
                          <span>CONF: <strong className="text-cyan-400">{(att.confidence * 100).toFixed(0)}%</strong></span>
                          <span>WT: <strong className="text-amber-300">{att.epistemicWeight.toFixed(2)}x</strong></span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Attestation Inspector Drawer */}
              {selectedAttestation && (
                <div className="p-4 bg-[#141722] border border-cyan-500/40 rounded-lg text-xs space-y-3 shadow-xl">
                  <div className="flex items-center justify-between pb-2 border-b border-[#252936]">
                    <div className="flex items-center space-x-2">
                      <ShieldCheck className="w-4 h-4 text-cyan-400" />
                      <span className="font-bold text-cyan-300 uppercase">
                        ATTESTATION PROOF: {selectedAttestation.validatorName}
                      </span>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getAttestationColor(selectedAttestation.decision)}`}>
                      {selectedAttestation.decision}
                    </span>
                  </div>

                  <div>
                    <span className="text-[#64748b] text-[10px] block font-bold uppercase mb-0.5">VALIDATOR REASONING TRACE</span>
                    <p className="text-[#f1f5f9] leading-relaxed bg-[#0c0d12] p-2.5 rounded border border-[#1e222e]">
                      {selectedAttestation.reasoning}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="p-2 bg-[#0c0d12] border border-[#1e222e] rounded">
                      <span className="text-[#64748b] text-[10px] block">CRYPTOGRAPHIC SIGNATURE</span>
                      <span className="text-amber-400 font-mono text-[10px] break-all">{selectedAttestation.signature}</span>
                    </div>
                    <div className="p-2 bg-[#0c0d12] border border-[#1e222e] rounded">
                      <span className="text-[#64748b] text-[10px] block">EVIDENCE MANIFOLD HASH</span>
                      <span className="text-cyan-400 font-mono text-[10px] break-all">{selectedAttestation.evidenceHash}</span>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
