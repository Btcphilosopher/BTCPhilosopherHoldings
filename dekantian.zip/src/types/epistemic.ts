export type EpistemicStatus = 
  | 'PENDING_VALIDATION'
  | 'JUSTIFIED'
  | 'FINALIZED'
  | 'CONDITIONAL'
  | 'CONTRADICTED'
  | 'REJECTED'
  | 'UNDECIDABLE'
  | 'FORKED';

export type EpistemicCertainty = 
  | 'TRUE'
  | 'LIKELY'
  | 'PLAUSIBLE'
  | 'POSSIBLE'
  | 'UNKNOWN'
  | 'FALSE'
  | 'UNTESTABLE';

export type JudgementClass = 'ANALYTIC' | 'SYNTHETIC';
export type EpistemicOrigin = 'A_PRIORI' | 'A_POSTERIORI' | 'MIXED' | 'UNDETERMINED';
export type BoundaryDomain = 'EMPIRICAL_PHENOMENA' | 'FORMAL_STRUCTURES' | 'CONCEPTUAL_OBJECTS' | 'METAPHYSICAL_CLAIMS';

export type AttestationDecision = 
  | 'VALID'
  | 'INVALID'
  | 'INSUFFICIENT_EVIDENCE'
  | 'CONDITIONAL'
  | 'CONTRADICTED'
  | 'UNDECIDABLE'
  | 'METAPHYSICAL'
  | 'EMPIRICAL'
  | 'ANALYTICAL'
  | 'SYNTHETIC';

export interface KantianCategories {
  quantity: 'UNITY' | 'PLURALITY' | 'TOTALITY';
  quality: 'REALITY' | 'NEGATION' | 'LIMITATION';
  relation: 'SUBSTANCE' | 'CAUSALITY' | 'COMMUNITY';
  modality: 'POSSIBILITY' | 'EXISTENCE' | 'NECESSITY';
  explanation: string;
}

export interface JudgementStructure {
  subject: string;
  predicate: string;
  form: 'CATEGORICAL' | 'HYPOTHETICAL' | 'DISJUNCTIVE';
  modality: 'PROBLEMATICAL' | 'ASSERTORIC' | 'APODICTIC';
  quantity: 'UNIVERSAL' | 'PARTICULAR' | 'SINGULAR';
  quality: 'AFFIRMATIVE' | 'NEGATIVE' | 'INFINITE';
  scope: string;
  timeContext: string;
}

export interface TranscendentalDeduction {
  experiencePhenomenon: string;
  necessaryConditions: string[];
  conceptualStructure: string[];
  boundsOfExperience: string;
  exceedsExperience: boolean;
  transcendentalQuestion: string;
}

export interface EpistemicConcept {
  id: string;
  name: string;
  definition: string;
  domain: string;
  category: string;
  containsPredicateOf: string[];
  legitimateDomain: string;
  riskOfCategoryError: boolean;
}

export interface EpistemicEvidence {
  id: string;
  claimId: string;
  title: string;
  sourceType: 'BOOK' | 'PAPER' | 'DATASET' | 'WEB_PAGE' | 'SENSOR' | 'USER_OBSERVATION' | 'STATISTICAL_SAMPLE';
  sourceProvenance: string;
  author: string;
  year?: string | number;
  reliabilityScore: number; // 0.0 - 1.0
  reproducible: boolean;
  hash: string;
  content: string;
}

export interface EpistemicInference {
  id: string;
  premises: string[];
  conclusion: string;
  inferenceType: 'DEDUCTIVE' | 'INDUCTIVE' | 'ABDUCTIVE' | 'TRANSCENDENTAL';
  valid: boolean;
  fallacyDetected?: string;
}

export interface EpistemicAssumption {
  id: string;
  statement: string;
  explicit: boolean;
  burdenOfProof: 'LOW' | 'MEDIUM' | 'CRITICAL';
  status: 'ACCEPTED' | 'UNVERIFIED' | 'CHALLENGED';
}

export interface Attestation {
  id: string;
  validatorId: string;
  validatorName: string;
  validatorType: ValidatorType;
  propositionId: string;
  blockId: number;
  timestamp: string;
  decision: AttestationDecision;
  confidence: number; // 0.00 - 1.00
  epistemicWeight: number; // weight applied to consensus
  reasoning: string;
  empiricalScore: number;
  logicalScore: number;
  evidenceHash: string;
  signature: string;
}

export type ValidatorType = 
  | 'EMPIRICAL_VALIDATOR'
  | 'LOGICAL_VALIDATOR'
  | 'CONCEPTUAL_VALIDATOR'
  | 'HISTORICAL_VALIDATOR'
  | 'SCIENTIFIC_VALIDATOR'
  | 'LINGUISTIC_VALIDATOR'
  | 'CAUSAL_VALIDATOR'
  | 'STATISTICAL_VALIDATOR';

export interface EpistemicValidator {
  id: string;
  name: string;
  type: ValidatorType;
  description: string;
  baseWeight: number;
  reputation: number; // 0.0 - 1.0
  attestationsCount: number;
  accuracyRate: number;
  slashedCount: number;
  active: boolean;
  iconName: string;
}

export interface ConsensusReport {
  propositionId: string;
  timestamp: string;
  finalStatus: EpistemicStatus;
  certaintyLevel: EpistemicCertainty;
  consensusScore: number; // 0.0 - 1.0
  empiricalSupport: number; // 0.0 - 1.0
  causalSupport: number;
  logicalCoherence: number;
  conceptualPrecision: number;
  historicalSupport: number;
  statisticalConfidence: number;
  validatorAgreementRatio: string; // e.g. "7 / 8"
  primaryReason: string;
  unresolvedContradictions: string[];
  isFinalized: boolean;
  finalityCriteria: {
    validatorsAgreed: boolean;
    evidenceThresholdMet: boolean;
    noUnresolvedContradictions: boolean;
    withinValidDomain: boolean;
  };
}

export interface PropositionClaim {
  id: string;
  blockId: number;
  text: string;
  version: number;
  createdAt: string;
  judgementClass: JudgementClass;
  origin: EpistemicOrigin;
  boundaryDomain: BoundaryDomain;
  status: EpistemicStatus;
  certainty: EpistemicCertainty;
  categories: KantianCategories;
  judgement: JudgementStructure;
  transcendental: TranscendentalDeduction;
  concepts: EpistemicConcept[];
  evidence: EpistemicEvidence[];
  inferences: EpistemicInference[];
  assumptions: EpistemicAssumption[];
  attestations: Attestation[];
  consensus?: ConsensusReport;
  weight: number;
  forkId?: string;
  hash: string;
}

export interface EpistemicFork {
  id: string;
  name: string;
  claimId: string;
  description: string;
  branches: {
    id: string;
    label: string;
    claimText: string;
    epistemicWeight: number;
    evidenceScore: number;
    logicalCoherence: number;
    explanatoryPower: number;
    isCanonical: boolean;
    advocateValidator: string;
    argumentSummary: string;
  }[];
  activeCanonicalBranchId: string;
  divergenceReason: string;
  createdAt: string;
}

export interface AntinomyRecord {
  id: string;
  title: string;
  domain: string;
  thesis: {
    statement: string;
    proofRationale: string;
    underlyingAssumption: string;
    supportWeight: number;
  };
  antithesis: {
    statement: string;
    proofRationale: string;
    underlyingAssumption: string;
    supportWeight: number;
  };
  transcendentalDiagnosis: string;
  reasonConflictType: 'COSMOLOGICAL' | 'CAUSAL_FREEDOM' | 'ONTOLOGICAL' | 'EPISTEMIC_LIMIT';
  resolvedByBoundary: boolean;
}

export interface PredictionRecord {
  id: string;
  claimId: string;
  hypothesis: string;
  timeHorizon: string;
  expectedObservation: string;
  actualObservation?: string;
  errorMargin?: number;
  status: 'PENDING' | 'VERIFIED' | 'FALSIFIED';
  registeredAt: string;
}

export interface EpistemicBlock {
  blockId: number;
  timestamp: string;
  previousStateHash: string;
  stateHash: string;
  propositions: PropositionClaim[];
  attestationsCount: number;
  consensusCount: number;
  validatorsParticipated: string[];
  blockSummary: string;
}

export interface EpistemicLedgerEvent {
  id: string;
  blockId: number;
  timestamp: string;
  type: 
    | 'CLAIM_CREATED'
    | 'EVIDENCE_ADDED'
    | 'CONCEPT_DEFINED'
    | 'INFERENCE_CREATED'
    | 'ASSUMPTION_ADDED'
    | 'CONTRADICTION_DETECTED'
    | 'CLAIM_REVISED'
    | 'CLAIM_REJECTED'
    | 'CLAIM_VALIDATED'
    | 'ATTESTATION_CREATED'
    | 'CONSENSUS_REACHED'
    | 'FORK_BRANCH_CREATED'
    | 'SLASHING_EXECUTED';
  description: string;
  actor: string;
  hash: string;
}

export interface KnowledgeGraphNode {
  id: string;
  label: string;
  type: 'CLAIM' | 'CONCEPT' | 'EVIDENCE' | 'ASSUMPTION' | 'SOURCE' | 'CONDITION';
  status?: EpistemicStatus;
  category?: string;
  x?: number;
  y?: number;
}

export interface KnowledgeGraphEdge {
  id: string;
  source: string;
  target: string;
  relation: 'SUPPORTS' | 'CONTRADICTS' | 'DEPENDS_ON' | 'CAUSES' | 'REQUIRES' | 'DERIVED_FROM' | 'HAS_CONCEPT';
  weight: number;
}

export interface NodeTelemetry {
  nodeName: string;
  uptimeSeconds: number;
  syncPercentage: number;
  currentBlockHeight: number;
  totalPropositions: number;
  justifiedCount: number;
  finalizedCount: number;
  unresolvedContradictionsCount: number;
  antinomiesCount: number;
  attestationsCount: number;
  activeValidatorsCount: number;
  epistemicHealth: number; // e.g. 97.4%
  stateHash: string;
}
