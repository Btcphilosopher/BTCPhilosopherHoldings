import { 
  Attestation, 
  ConsensusReport, 
  EpistemicStatus, 
  EpistemicCertainty,
  PropositionClaim 
} from '../types/epistemic';

export class ConsensusEngine {
  static evaluateConsensus(claim: PropositionClaim, attestations: Attestation[]): ConsensusReport {
    if (!attestations || attestations.length === 0) {
      return {
        propositionId: claim.id,
        timestamp: new Date().toISOString(),
        finalStatus: 'PENDING_VALIDATION',
        certaintyLevel: 'UNKNOWN',
        consensusScore: 0,
        empiricalSupport: 0,
        causalSupport: 0,
        logicalCoherence: 0,
        conceptualPrecision: 0,
        historicalSupport: 0,
        statisticalConfidence: 0,
        validatorAgreementRatio: `0 / 0`,
        primaryReason: 'Awaiting attestation quorum from independent epistemic validators.',
        unresolvedContradictions: [],
        isFinalized: false,
        finalityCriteria: {
          validatorsAgreed: false,
          evidenceThresholdMet: false,
          noUnresolvedContradictions: true,
          withinValidDomain: claim.boundaryDomain !== 'METAPHYSICAL_CLAIMS'
        }
      };
    }

    let totalWeight = 0;
    let validWeight = 0;
    let conditionalWeight = 0;
    let invalidWeight = 0;
    let contradictoryWeight = 0;
    let insufficientWeight = 0;

    let empiricalSupport = 0;
    let causalSupport = 0;
    let logicalCoherence = 0;
    let conceptualPrecision = 0;
    let historicalSupport = 0;
    let statisticalConfidence = 0;

    const contradictions: string[] = [];

    attestations.forEach(att => {
      totalWeight += att.epistemicWeight;

      if (att.decision === 'VALID' || att.decision === 'ANALYTICAL' || att.decision === 'EMPIRICAL') {
        validWeight += att.epistemicWeight;
      } else if (att.decision === 'CONDITIONAL') {
        conditionalWeight += att.epistemicWeight;
      } else if (att.decision === 'INVALID') {
        invalidWeight += att.epistemicWeight;
      } else if (att.decision === 'CONTRADICTED') {
        contradictoryWeight += att.epistemicWeight;
        contradictions.push(`Contradiction flagged by ${att.validatorName}: ${att.reasoning}`);
      } else if (att.decision === 'INSUFFICIENT_EVIDENCE') {
        insufficientWeight += att.epistemicWeight;
      }

      switch (att.validatorType) {
        case 'EMPIRICAL_VALIDATOR':
        case 'SCIENTIFIC_VALIDATOR':
          empiricalSupport = Math.max(empiricalSupport, att.confidence);
          break;
        case 'CAUSAL_VALIDATOR':
          causalSupport = att.decision === 'VALID' ? att.confidence : (att.decision === 'CONDITIONAL' ? 0.55 : 0.30);
          break;
        case 'LOGICAL_VALIDATOR':
          logicalCoherence = att.confidence;
          break;
        case 'CONCEPTUAL_VALIDATOR':
        case 'LINGUISTIC_VALIDATOR':
          conceptualPrecision = att.confidence;
          break;
        case 'HISTORICAL_VALIDATOR':
          historicalSupport = att.confidence;
          break;
        case 'STATISTICAL_VALIDATOR':
          statisticalConfidence = att.confidence;
          break;
      }
    });

    const validRatio = totalWeight > 0 ? validWeight / totalWeight : 0;
    const conditionalRatio = totalWeight > 0 ? conditionalWeight / totalWeight : 0;
    const invalidRatio = totalWeight > 0 ? (invalidWeight + contradictoryWeight) / totalWeight : 0;

    // Check specific Kantian conditions
    const isMetaphysical = claim.boundaryDomain === 'METAPHYSICAL_CLAIMS';
    const isAnalytic = claim.judgementClass === 'ANALYTIC';
    const hasEvidence = claim.evidence && claim.evidence.length > 0;

    let finalStatus: EpistemicStatus = 'PENDING_VALIDATION';
    let certaintyLevel: EpistemicCertainty = 'PLAUSIBLE';
    let primaryReason = '';

    if (contradictoryWeight > 0 || invalidRatio > 0.4) {
      finalStatus = 'CONTRADICTED';
      certaintyLevel = 'FALSE';
      primaryReason = 'Fatal formal contradiction or category failure verified across validator quorum.';
    } else if (isMetaphysical) {
      finalStatus = 'CONDITIONAL';
      certaintyLevel = 'UNTESTABLE';
      primaryReason = 'Transcends empirical intuition. Can function only as a regulative idea of reason, not as constitutive knowledge of appearances.';
    } else if (conditionalRatio > 0.25 || insufficientWeight > 0.25) {
      finalStatus = 'CONDITIONAL';
      certaintyLevel = 'PLAUSIBLE';
      primaryReason = causalSupport < 0.6 && claim.categories.relation === 'CAUSALITY'
        ? 'Evidence demonstrates empirical correlation, but causal mechanism invariance remains insufficient.'
        : 'Validator quorum identified conditional premises requiring further empirical verification.';
    } else if (validRatio >= 0.85) {
      // Check Finality criteria
      const evidenceMet = isAnalytic || hasEvidence;
      const domainMet = !isMetaphysical;
      const noContradictions = contradictions.length === 0;

      if (evidenceMet && domainMet && noContradictions && validRatio >= 0.88) {
        finalStatus = 'FINALIZED';
        certaintyLevel = isAnalytic ? 'TRUE' : 'LIKELY';
        primaryReason = 'Canonical epistemic threshold satisfied: All 4 conditions of finality fulfilled within legitimate domain.';
      } else {
        finalStatus = 'JUSTIFIED';
        certaintyLevel = 'LIKELY';
        primaryReason = 'Justified belief achieved. Well-supported by validator attestations, approaching canonical finality.';
      }
    } else {
      finalStatus = 'JUSTIFIED';
      certaintyLevel = 'PLAUSIBLE';
      primaryReason = 'Substantial support across validators; minor divergence on secondary empirical conditions.';
    }

    const agreeingValidators = attestations.filter(a => 
      a.decision === 'VALID' || a.decision === 'ANALYTICAL' || a.decision === 'EMPIRICAL'
    ).length;

    const isFinalized = finalStatus === 'FINALIZED';

    return {
      propositionId: claim.id,
      timestamp: new Date().toISOString(),
      finalStatus,
      certaintyLevel,
      consensusScore: Number(validRatio.toFixed(3)),
      empiricalSupport: Number(empiricalSupport.toFixed(2)),
      causalSupport: Number(causalSupport.toFixed(2)),
      logicalCoherence: Number(logicalCoherence.toFixed(2)),
      conceptualPrecision: Number(conceptualPrecision.toFixed(2)),
      historicalSupport: Number(historicalSupport.toFixed(2)),
      statisticalConfidence: Number(statisticalConfidence.toFixed(2)),
      validatorAgreementRatio: `${agreeingValidators} / ${attestations.length}`,
      primaryReason,
      unresolvedContradictions: contradictions,
      isFinalized,
      finalityCriteria: {
        validatorsAgreed: agreeingValidators >= 6,
        evidenceThresholdMet: isAnalytic || (claim.evidence && claim.evidence.length >= 1),
        noUnresolvedContradictions: contradictions.length === 0,
        withinValidDomain: !isMetaphysical
      }
    };
  }
}
