// Deterministic SHA-256 implementation supporting both Node.js and Browser environments

export async function computeSha256(message: string): Promise<string> {
  // In modern browser or edge environment
  if (typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.digest) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }
  
  // Fallback deterministic polynomial hash expanded to 64-character hex if subtle is unavailable
  return fallbackHash(message);
}

// Synchronous fast deterministic hash for immediate UI display
export function computeHashSync(message: string): string {
  let h1 = 0xdeadbeef ^ 0;
  let h2 = 0x41c6ce57 ^ 0;
  let h3 = 0x6a09e667 ^ 0;
  let h4 = 0xbb67ae85 ^ 0;
  
  for (let i = 0; i < message.length; i++) {
    const ch = message.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
    h3 = Math.imul(h3 ^ ch, 2246822519);
    h4 = Math.imul(h4 ^ ch, 3266489917);
  }
  
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822519) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489917);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 1597334677) ^ Math.imul(h3 ^ (h3 >>> 13), 2654435761);
  h3 = Math.imul(h3 ^ (h3 >>> 16), 2654435761) ^ Math.imul(h4 ^ (h4 >>> 13), 2246822519);
  h4 = Math.imul(h4 ^ (h4 >>> 16), 3266489917) ^ Math.imul(h1 ^ (h1 >>> 13), 1597334677);

  const p1 = (h1 >>> 0).toString(16).padStart(8, '0');
  const p2 = (h2 >>> 0).toString(16).padStart(8, '0');
  const p3 = (h3 >>> 0).toString(16).padStart(8, '0');
  const p4 = (h4 >>> 0).toString(16).padStart(8, '0');
  const p5 = (Math.imul(h1, 31) >>> 0).toString(16).padStart(8, '0');
  const p6 = (Math.imul(h2, 17) >>> 0).toString(16).padStart(8, '0');
  const p7 = (Math.imul(h3, 19) >>> 0).toString(16).padStart(8, '0');
  const p8 = (Math.imul(h4, 23) >>> 0).toString(16).padStart(8, '0');

  return (p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8).toUpperCase();
}

function fallbackHash(message: string): string {
  return computeHashSync(message);
}

export function formatHash(hash: string, length = 12): string {
  if (!hash) return '0x0000...0000';
  const clean = hash.startsWith('0x') ? hash.slice(2) : hash;
  if (clean.length <= length) return '0x' + clean;
  return `0x${clean.slice(0, 6)}...${clean.slice(-6)}`;
}
