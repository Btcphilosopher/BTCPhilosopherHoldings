import { AntinomyRecord } from '../types/epistemic';

export const INITIAL_ANTINOMIES: AntinomyRecord[] = [
  {
    id: 'ant-cosmo-01',
    title: 'First Kantian Antinomy: Spatiotemporal Limit of the Cosmos',
    domain: 'COSMOLOGY & METAPHYSICS OF TIME',
    thesis: {
      statement: 'The universe has a beginning in time, and is also limited as regards space.',
      proofRationale: 'If the world had no beginning in time, an eternity would have elapsed up to every given moment; but an infinite series can never be completed by successive synthesis.',
      underlyingAssumption: 'Presupposition that the world is a given whole-in-itself existing in absolute time.',
      supportWeight: 0.88
    },
    antithesis: {
      statement: 'The universe has no beginning and no limits in space, but is infinite as regards both time and space.',
      proofRationale: 'If the world had a beginning, it would be preceded by an empty time in which nothing exists; but in empty time no origin of anything is possible, for no moment has a distinguishing ground of existence.',
      underlyingAssumption: 'Presupposition that time exists as a container prior to the existence of appearances.',
      supportWeight: 0.89
    },
    transcendentalDiagnosis: 'DIALECTICAL ILLUSION: Both thesis and antithesis mistakenly treat the sensible world as a "thing-in-itself" (noumenon) rather than a continuous synthesis of appearances in experience. Space and time are pure forms of human intuition, not self-subsisting infinite containers. When restricted to possible experience, the synthesis of past time is indefinite, neither finite nor infinite in itself.',
    reasonConflictType: 'COSMOLOGICAL',
    resolvedByBoundary: true
  },
  {
    id: 'ant-causal-02',
    title: 'Third Kantian Antinomy: Freedom vs. Universal Natural Determinism',
    domain: 'PHILOSOPHY OF ACTION & PHYSICAL CAUSATION',
    thesis: {
      statement: 'Causality in accordance with laws of nature is not the only causality; it is necessary to assume also a causality through freedom.',
      proofRationale: 'If everything happens solely according to laws of nature, there is always only a subordinate, but never a first beginning, and thus no completeness of the series on the side of causes.',
      underlyingAssumption: 'Reason demands an unconditioned, complete explanation of empirical causal chains.',
      supportWeight: 0.84
    },
    antithesis: {
      statement: 'There is no freedom, but everything in the world takes place solely in accordance with laws of nature.',
      proofRationale: 'If there were freedom, an unconditioned state would break the temporal succession of appearances without antecedent rules, destroying the coherence of empirical experience.',
      underlyingAssumption: 'Every appearance in time must be completely governed by the Second Analogy of Experience.',
      supportWeight: 0.91
    },
    transcendentalDiagnosis: 'COMPATIBILIST CRITICAL RESOLUTION: Freedom and determinism can be reconciled by distinguishing between appearances and things-in-themselves. As an empirical phenomenon in time, every human action is completely determined by antecedent physical and psychological causes; but considered as an intelligible character (noumenal subject), the agent can be conceived as self-determining without violating natural laws governing the empirical appearance.',
    reasonConflictType: 'CAUSAL_FREEDOM',
    resolvedByBoundary: true
  },
  {
    id: 'ant-econ-03',
    title: 'Epistemic Antinomy: Market Efficiency vs. Reflexive Coordination',
    domain: 'ECONOMIC EPISTEMOLOGY',
    thesis: {
      statement: 'Asset prices reflect all available fundamental information and represent the objectively unbiased expectation of future cashflows.',
      proofRationale: 'Arbitrage capital systematically eliminates ungrounded subjective price anomalies.',
      underlyingAssumption: 'Price formation is an exogenous measurement of an independent economic reality.',
      supportWeight: 0.81
    },
    antithesis: {
      statement: 'Asset prices do not reflect fundamentals, but generate fundamentals reflexively through participant narrative coordination.',
      proofRationale: 'Liquidity availability and collateral valuation depend upon the price itself, altering real economic outcomes.',
      underlyingAssumption: 'Economic observation alters the state of the observed financial manifold.',
      supportWeight: 0.85
    },
    transcendentalDiagnosis: 'METHODOLOGICAL SYNTHESIS: The antinomy arises from treating financial prices as static natural substances (Category of Inherence) rather than interactive social coordination processes (Category of Community/Reciprocity).',
    reasonConflictType: 'EPISTEMIC_LIMIT',
    resolvedByBoundary: true
  }
];

export class AntinomyEngine {
  static detectAntinomy(claimText: string): AntinomyRecord | null {
    const lower = claimText.toLowerCase();

    if (/universe|beginning|finite time|infinite space|big bang|cosmo/i.test(lower)) {
      return INITIAL_ANTINOMIES[0];
    }
    if (/free will|determinism|choice|libertarian|cause|natural law/i.test(lower)) {
      return INITIAL_ANTINOMIES[1];
    }
    if (/market|efficient market|bitcoin|price|reflexiv|speculation/i.test(lower)) {
      return INITIAL_ANTINOMIES[2];
    }

    return null;
  }
}
