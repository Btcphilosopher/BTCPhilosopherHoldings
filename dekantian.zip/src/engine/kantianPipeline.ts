import { 
  KantianCategories, 
  JudgementStructure, 
  TranscendentalDeduction, 
  JudgementClass, 
  EpistemicOrigin, 
  BoundaryDomain, 
  EpistemicCertainty,
  EpistemicConcept,
  EpistemicAssumption,
  EpistemicInference
} from '../types/epistemic';

export interface EpistemicDecomposition {
  claimText: string;
  judgementClass: JudgementClass;
  origin: EpistemicOrigin;
  boundaryDomain: BoundaryDomain;
  certainty: EpistemicCertainty;
  categories: KantianCategories;
  judgement: JudgementStructure;
  transcendental: TranscendentalDeduction;
  concepts: EpistemicConcept[];
  assumptions: EpistemicAssumption[];
  inferences: EpistemicInference[];
  whatIsGiven: string[];
  whatIsConstructed: string[];
  whatIsInferred: string[];
  whatIsAssumed: string[];
  whatIsPossible: string[];
  whatIsNecessary: string[];
  whatIsUnknown: string[];
  boundaryDiagnosis: string;
  categoryErrorWarning?: string;
}

export class SensibilityEngine {
  static isolateSensoryManifold(text: string): { appearances: string[]; spatiotemporalForms: string[] } {
    const timeWords = ['during', 'after', 'before', 'period', 'at t0', 'at t1', 'when', 'historical', 'in 2024', 'rate', 'cycle'];
    const spaceWords = ['within', 'in', 'surface', 'system', 'market', 'region', 'network', 'node', 'universe'];
    
    const words = text.toLowerCase().split(/\s+/);
    const hasTime = words.some(w => timeWords.some(tw => w.includes(tw)));
    const hasSpace = words.some(w => spaceWords.some(sw => w.includes(sw)));
    
    const forms: string[] = [];
    if (hasTime) forms.push('Inner Sense (Temporal Succession)');
    if (hasSpace) forms.push('Outer Sense (Spatial Juxtaposition)');
    if (forms.length === 0) forms.push('Formal/Conceptual Schema (Non-sensible intuition)');

    return {
      appearances: [
        `Empirical data-points given in intuition`,
        `Sensory/observational records registered at empirical interfaces`
      ],
      spatiotemporalForms: forms
    };
  }
}

export class PerceptionEngine {
  static synthesize(text: string) {
    return {
      manifoldSynthesis: `Synthesis of apprehension in intuition applied to claim: "${text}"`,
      unityOfPerception: `Apperception: Transcendental unity uniting disparate observations into one cognitive object.`
    };
  }
}

export class RepresentationEngine {
  static decomposeCognition(text: string, subject: string, predicate: string) {
    const isEconomic = /price|bitcoin|inflation|interest|market|demand|investment/i.test(text);
    const isPhysical = /metal|heats|universe|object|moves|energy|quantum|light/i.test(text);
    const isMathOrLogic = /2\s*\+\s*2|bachelor|unmarried|triangle|sum|identity|all\s+\w+\s+are/i.test(text);
    const isMetaphysical = /soul|god|in-itself|noumen|infinite|absolute|free\s*will/i.test(text);

    return {
      whatIsGiven: isPhysical || isEconomic
        ? [`Empirical observations of ${subject || 'phenomenon'}`, 'Recorded measurements across observation intervals']
        : [`Syntactic definitions of ${subject || 'concept'}`, 'Axiomatic postulates'],
      whatIsConstructed: [
        `Conceptual schema connecting ${subject} with property ${predicate}`,
        'Temporal ordering and measurement metrics'
      ],
      whatIsInferred: [
        `Generalization that ${subject} exhibits ${predicate}`,
        'Systematic causal or correlative relationship'
      ],
      whatIsAssumed: [
        'Homogeneity of space-time and measurement invariance',
        'Persistence of substance across observation intervals',
        'Causal principle: every event has an antecedent condition'
      ],
      whatIsPossible: [
        `Counter-evidence or falsifying observations of ${subject}`,
        'Alternative causal explanations for the observed variance'
      ],
      whatIsNecessary: isMathOrLogic
        ? ['Logical consistency according to the law of non-contradiction']
        : ['Transcendental presupposition of the unity of experience'],
      whatIsUnknown: isMetaphysical
        ? ['The unconditioned ground of the appearance in itself']
        : ['Unobserved latent variables and non-stationary boundary conditions']
    };
  }
}

export class ConceptEngine {
  static analyzeCategories(text: string, subject: string, predicate: string): KantianCategories {
    const lower = text.toLowerCase();

    // 1. Quantity: Unity (individual/all one), Plurality (many/some), Totality (all/universal)
    let quantity: KantianCategories['quantity'] = 'UNITY';
    if (/\ball\b|\bevery\b|\btotality\b|\bentire\b|\buniversal\b/i.test(lower)) {
      quantity = 'TOTALITY';
    } else if (/\bsome\b|\bmany\b|\bseveral\b|\bplurality\b|\bfew\b/i.test(lower)) {
      quantity = 'PLURALITY';
    } else {
      quantity = 'UNITY';
    }

    // 2. Quality: Reality (affirmative), Negation (negative), Limitation (restrictive)
    let quality: KantianCategories['quality'] = 'REALITY';
    if (/\bnot\b|\bnever\b|\bneither\b|\bno\b|\bfails\b|\bnone\b/i.test(lower)) {
      quality = 'NEGATION';
    } else if (/\bonly\b|\blimited\b|\brestricted\b|\bpartially\b|\bconditional\b/i.test(lower)) {
      quality = 'LIMITATION';
    } else {
      quality = 'REALITY';
    }

    // 3. Relation: Substance (inherence), Causality (dependence/cause-effect), Community (reciprocity)
    let relation: KantianCategories['relation'] = 'SUBSTANCE';
    if (/\bcauses\b|\bcaused\b|\binfluence\b|\bleads to\b|\bproduces\b|\bbecause\b|\bdetermines\b/i.test(lower)) {
      relation = 'CAUSALITY';
    } else if (/\bcorrelates\b|\binteracts\b|\bmutual\b|\breciprocal\b|\bcoexists\b/i.test(lower)) {
      relation = 'COMMUNITY';
    } else {
      relation = 'SUBSTANCE';
    }

    // 4. Modality: Possibility (can/may), Existence (is/actual/did), Necessity (must/necessarily)
    let modality: KantianCategories['modality'] = 'EXISTENCE';
    if (/\bmust\b|\bnecessarily\b|\binevitable\b|\balways\b|\bapodictic\b/i.test(lower)) {
      modality = 'NECESSITY';
    } else if (/\bcan\b|\bmay\b|\bmight\b|\bpossible\b|\bplausible\b|\bcould\b/i.test(lower)) {
      modality = 'POSSIBILITY';
    } else {
      modality = 'EXISTENCE';
    }

    return {
      quantity,
      quality,
      relation,
      modality,
      explanation: `Synthesized under ${quantity} (Quantity), ${quality} (Quality), ${relation} (Relation), and ${modality} (Modality) governing subject "${subject}" and predicate "${predicate}".`
    };
  }
}

export class JudgementEngine {
  static parseJudgement(text: string): {
    judgement: JudgementStructure;
    judgementClass: JudgementClass;
    origin: EpistemicOrigin;
    certainty: EpistemicCertainty;
  } {
    const lower = text.toLowerCase().trim();

    // Analytic propositions: predicate contained in definition of subject
    const analyticPatterns = [
      /\ball\s+bachelors\s+are\s+unmarried\b/i,
      /\b2\s*\+\s*2\s*=\s*4\b/i,
      /\btriangles\s+have\s+three\s+sides\b/i,
      /\ba\s+circle\s+is\s+round\b/i,
      /\ba\s+part\s+is\s+smaller\s+than\s+the\s+whole\b/i
    ];

    const isAnalytic = analyticPatterns.some(p => p.test(lower)) || 
      (lower.includes('by definition') || lower.includes('tautologically'));

    // A priori vs A posteriori
    const aPrioriPatterns = [
      /\b2\s*\+\s*2\b/i,
      /\bmath/i,
      /\blogical\b/i,
      /\ba\s+priori\b/i,
      /\bidentity\b/i
    ];

    const isEmpirical = /bitcoin|price|interest|inflation|metal|water|heat|experiment|observed|sensor|sample|history|market|study/i.test(lower);
    
    let judgementClass: JudgementClass = isAnalytic ? 'ANALYTIC' : 'SYNTHETIC';
    let origin: EpistemicOrigin = 'A_POSTERIORI';
    
    if (isAnalytic) {
      origin = 'A_PRIORI';
    } else if (aPrioriPatterns.some(p => p.test(lower)) && !isEmpirical) {
      origin = 'A_PRIORI'; // Synthetic a priori (e.g. 7 + 5 = 12, or conservation of substance)
    } else if (isEmpirical) {
      origin = 'A_POSTERIORI';
    } else {
      origin = 'MIXED';
    }

    // Extract subject & predicate heuristics
    let subject = 'Propositional Subject';
    let predicate = 'Asserted Property';

    const copulaMatches = text.match(/^(?:the\s+)?([a-zA-Z0-9_\-\s]+?)\s+(?:is|are|was|were|functions as|causes|caused|exhibits|possesses|has|increased|decreased|influences)\s+(.+)$/i);
    if (copulaMatches && copulaMatches[1] && copulaMatches[2]) {
      subject = copulaMatches[1].trim();
      predicate = copulaMatches[2].trim().replace(/\.$/, '');
    } else {
      const words = text.split(/\s+/);
      subject = words.slice(0, Math.min(3, words.length)).join(' ');
      predicate = words.slice(Math.min(3, words.length)).join(' ') || 'affirmed state';
    }

    // Form: Categorical, Hypothetical (if...then), Disjunctive (either...or)
    let form: JudgementStructure['form'] = 'CATEGORICAL';
    if (/\bif\b.*\bthen\b/i.test(lower) || /\bwhen\b.*\bthen\b/i.test(lower)) {
      form = 'HYPOTHETICAL';
    } else if (/\beither\b.*\bor\b/i.test(lower)) {
      form = 'DISJUNCTIVE';
    }

    // Modality: Problematical (possible), Assertoric (actual), Apodictic (necessary)
    let modality: JudgementStructure['modality'] = 'ASSERTORIC';
    if (/\bpossibly\b|\bcan\b|\bmay\b|\bmight\b|\bperhaps\b/i.test(lower)) {
      modality = 'PROBLEMATICAL';
    } else if (/\bnecessarily\b|\bmust\b|\balways\b|\bapodictic\b/i.test(lower) || isAnalytic) {
      modality = 'APODICTIC';
    }

    // Epistemic certainty
    let certainty: EpistemicCertainty = 'PLAUSIBLE';
    if (isAnalytic) certainty = 'TRUE';
    else if (modality === 'APODICTIC') certainty = 'LIKELY';
    else if (modality === 'PROBLEMATICAL') certainty = 'POSSIBLE';
    else certainty = 'PLAUSIBLE';

    return {
      judgement: {
        subject,
        predicate,
        form,
        modality,
        quantity: /\ball\b|\bevery\b/i.test(lower) ? 'UNIVERSAL' : /\bsome\b|\bfew\b/i.test(lower) ? 'PARTICULAR' : 'SINGULAR',
        quality: /\bnot\b|\bnever\b/i.test(lower) ? 'NEGATIVE' : 'AFFIRMATIVE',
        scope: isAnalytic ? 'Conceptual definition realm' : isEmpirical ? 'Observation horizon within empirical boundaries' : 'General conceptual domain',
        timeContext: /\bpast\b|\bduring\b|\bhistorical\b/i.test(lower) ? 'Discrete past interval' : 'Continuous present / general time invariant'
      },
      judgementClass,
      origin,
      certainty
    };
  }
}

export class KnowledgeBoundaryEngine {
  static assessBoundary(text: string): { boundaryDomain: BoundaryDomain; diagnosis: string; categoryErrorWarning?: string } {
    const lower = text.toLowerCase();

    // Metaphysical markers: reality in itself, God, soul, unconditioned, infinite void, noumenon
    const isMetaphysical = /\bin itself\b|\bnoumen\b|\bunconditioned\b|\babsolute truth\b|\bsoul\b|\bgod\b|\btranscends experience\b/i.test(lower);
    const isFormal = /\bmath\b|\bgeometry\b|\b2\s*\+\s*2\b|\bset theory\b|\bformal proof\b|\btautology\b/i.test(lower);
    const isConceptual = /\bdefinition\b|\bmeaning\b|\bconcept of\b|\bsemantic\b|\banalytic\b/i.test(lower);

    if (isMetaphysical) {
      return {
        boundaryDomain: 'METAPHYSICAL_CLAIMS',
        diagnosis: 'TRANSCENDENT ASSERTION: Proposition attempts to determine objects beyond the bounds of all possible sensible experience. It cannot achieve empirical finality and operates as regulative idea or speculative antinomy.',
        categoryErrorWarning: 'Category Error: Pure category of understanding applied to the unconditioned (transcending the conditions of sensibility).'
      };
    }

    if (isFormal) {
      return {
        boundaryDomain: 'FORMAL_STRUCTURES',
        diagnosis: 'FORMAL A PRIORI DOMAIN: Validated purely through internal consistency, mathematical axioms, or pure intuition of space and time.'
      };
    }

    if (isConceptual) {
      return {
        boundaryDomain: 'CONCEPTUAL_OBJECTS',
        diagnosis: 'INTELLECTUAL/CONCEPTUAL DOMAIN: Pertains to linguistic definitions, taxonomy, or conceptual containment relations.'
      };
    }

    return {
      boundaryDomain: 'EMPIRICAL_PHENOMENA',
      diagnosis: 'PHENOMENAL/EMPIRICAL DOMAIN: Subject to space-time intuition, empirical verification, measurable observation, and falsification.'
    };
  }
}

export class TranscendentalEngine {
  static analyze(text: string, subject: string, predicate: string): TranscendentalDeduction {
    const lower = text.toLowerCase();
    const exceeds = /\bin itself\b|\bnoumen\b|\bunconditioned\b|\babsolute reality\b/i.test(lower);

    return {
      experiencePhenomenon: `Observation of ${subject} possessing or being related to ${predicate}`,
      necessaryConditions: [
        'Pure forms of intuition: Space (outer sense) and Time (inner sense) allowing representation of succession and spatial relationship',
        'Transcendental unity of apperception: Synthesizing disparate representations into a single unified conscious cognition',
        'Causal schematism: The schema of the category of cause is the succession of the manifold, insofar as it is subject to a rule'
      ],
      conceptualStructure: [
        `Category of Relation (Inherence/Substance or Causality)`,
        `Empirical concept of "${subject}" instantiated in experience`,
        `Synthesized attribution of predicate "${predicate}"`
      ],
      boundsOfExperience: exceeds 
        ? 'EXCEEDED: Proposition treats appearances as things-in-themselves.' 
        : 'RESPECTED: Proposition limits its validity to objects of possible experience and appearances.',
      exceedsExperience: exceeds,
      transcendentalQuestion: `What must be true of the cognitive faculties and conditions of experience for "${text}" to count as valid knowledge?`
    };
  }
}

export class ReasonEngine {
  static evaluateCoherence(text: string, assumptions: EpistemicAssumption[]): {
    fallacies: string[];
    hiddenAssumptions: string[];
    coherenceScore: number;
  } {
    const fallacies: string[] = [];
    const lower = text.toLowerCase();

    // Detect Causal confusion (Correlation asserted as definitive Causation without control)
    if (/\bproves that\b.*\bcaused\b/i.test(lower) || /\bincreased because\b/i.test(lower)) {
      fallacies.push('Causal Overassertion: Conflating temporal succession or statistical correlation with necessary causal determination.');
    }

    // Circularity
    if (/\bbecause it is\b/i.test(lower) || /\bby virtue of being\b/i.test(lower)) {
      fallacies.push('Potential Petitio Principii (Circular Reasoning): Conclusion is presupposed in the conceptual framing.');
    }

    // Overgeneralization
    if (/\balways\b|\beveryone\b|\bnever\b|\ball without exception\b/i.test(lower)) {
      fallacies.push('Empirical Overgeneralization: Universal claim derived from finite empirical induction.');
    }

    const hiddenAssumptions = [
      'Assumption that the observation instruments introduce no uncorrected systematic bias.',
      'Assumption that the temporal boundary conditions remain uniform outside observed epochs.'
    ];

    const coherenceScore = Math.max(0.2, 1.0 - fallacies.length * 0.25);

    return {
      fallacies,
      hiddenAssumptions,
      coherenceScore
    };
  }
}

// Master Kantian Epistemic Compiler
export class EpistemicCompiler {
  static compile(text: string): EpistemicDecomposition {
    const { judgement, judgementClass, origin, certainty } = JudgementEngine.parseJudgement(text);
    const categories = ConceptEngine.analyzeCategories(text, judgement.subject, judgement.predicate);
    const boundary = KnowledgeBoundaryEngine.assessBoundary(text);
    const transcendental = TranscendentalEngine.analyze(text, judgement.subject, judgement.predicate);
    const { whatIsGiven, whatIsConstructed, whatIsInferred, whatIsAssumed, whatIsPossible, whatIsNecessary, whatIsUnknown } = 
      RepresentationEngine.decomposeCognition(text, judgement.subject, judgement.predicate);

    const assumptions: EpistemicAssumption[] = [
      {
        id: `asm-${Math.random().toString(36).substring(2, 7)}`,
        statement: `The conceptual bounds of "${judgement.subject}" remain stable over the observation window.`,
        explicit: true,
        burdenOfProof: 'MEDIUM',
        status: 'ACCEPTED'
      },
      {
        id: `asm-${Math.random().toString(36).substring(2, 7)}`,
        statement: 'The principle of sufficient reason applies to the observed phenomenon.',
        explicit: false,
        burdenOfProof: 'CRITICAL',
        status: 'UNVERIFIED'
      }
    ];

    const inferences: EpistemicInference[] = [
      {
        id: `inf-${Math.random().toString(36).substring(2, 7)}`,
        premises: [
          `Empirical observation registers ${judgement.subject}`,
          `Predicate "${judgement.predicate}" is verified under specified conditions`
        ],
        conclusion: text,
        inferenceType: judgementClass === 'ANALYTIC' ? 'DEDUCTIVE' : 'INDUCTIVE',
        valid: true
      }
    ];

    const concepts: EpistemicConcept[] = [
      {
        id: `cpt-${Math.random().toString(36).substring(2, 7)}`,
        name: judgement.subject,
        definition: `The cognitive object or empirical manifold denoted by "${judgement.subject}".`,
        domain: boundary.boundaryDomain,
        category: categories.relation,
        containsPredicateOf: [judgement.predicate],
        legitimateDomain: boundary.boundaryDomain === 'METAPHYSICAL_CLAIMS' ? 'Speculative/Regulative' : 'Empirical Experience',
        riskOfCategoryError: boundary.boundaryDomain === 'METAPHYSICAL_CLAIMS'
      }
    ];

    return {
      claimText: text,
      judgementClass,
      origin,
      boundaryDomain: boundary.boundaryDomain,
      certainty,
      categories,
      judgement,
      transcendental,
      concepts,
      assumptions,
      inferences,
      whatIsGiven,
      whatIsConstructed,
      whatIsInferred,
      whatIsAssumed,
      whatIsPossible,
      whatIsNecessary,
      whatIsUnknown,
      boundaryDiagnosis: boundary.diagnosis,
      categoryErrorWarning: boundary.categoryErrorWarning
    };
  }
}
