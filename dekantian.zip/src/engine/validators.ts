import { 
  EpistemicValidator, 
  Attestation, 
  AttestationDecision, 
  PropositionClaim, 
  EpistemicEvidence 
} from '../types/epistemic';
import { computeHashSync } from './crypto';

export const INITIAL_VALIDATORS: EpistemicValidator[] = [
  {
    id: 'val-emp-01',
    name: 'EMPIRICAL_VALIDATOR',
    type: 'EMPIRICAL_VALIDATOR',
    description: 'Validates sensory manifold grounding, observational repeatability, and instrumentation integrity.',
    baseWeight: 1.25,
    reputation: 0.985,
    attestationsCount: 14208,
    accuracyRate: 0.962,
    slashedCount: 0,
    active: true,
    iconName: 'Eye'
  },
  {
    id: 'val-log-02',
    name: 'LOGICAL_VALIDATOR',
    type: 'LOGICAL_VALIDATOR',
    description: 'Enforces deductive validity, syllogistic structure, and freedom from formal contradiction.',
    baseWeight: 1.30,
    reputation: 0.998,
    attestationsCount: 18940,
    accuracyRate: 0.994,
    slashedCount: 0,
    active: true,
    iconName: 'Cpu'
  },
  {
    id: 'val-cpt-03',
    name: 'CONCEPTUAL_VALIDATOR',
    type: 'CONCEPTUAL_VALIDATOR',
    description: 'Audits Kantian categories of understanding and prevents illicit domain-category transfer.',
    baseWeight: 1.15,
    reputation: 0.978,
    attestationsCount: 12450,
    accuracyRate: 0.958,
    slashedCount: 0,
    active: true,
    iconName: 'Layers'
  },
  {
    id: 'val-his-04',
    name: 'HISTORICAL_VALIDATOR',
    type: 'HISTORICAL_VALIDATOR',
    description: 'Tracks temporal consistency across previous ledger states and source provenance lineage.',
    baseWeight: 1.10,
    reputation: 0.970,
    attestationsCount: 9812,
    accuracyRate: 0.949,
    slashedCount: 0,
    active: true,
    iconName: 'Clock'
  },
  {
    id: 'val-sci-05',
    name: 'SCIENTIFIC_VALIDATOR',
    type: 'SCIENTIFIC_VALIDATOR',
    description: 'Tests falsifiability, experimental control, and boundary conditions of empirical claims.',
    baseWeight: 1.20,
    reputation: 0.981,
    attestationsCount: 15320,
    accuracyRate: 0.966,
    slashedCount: 0,
    active: true,
    iconName: 'FlaskConical'
  },
  {
    id: 'val-lin-06',
    name: 'LINGUISTIC_VALIDATOR',
    type: 'LINGUISTIC_VALIDATOR',
    description: 'Audits semantic definition precision, detects equivocation, and isolates scope ambiguity.',
    baseWeight: 1.05,
    reputation: 0.965,
    attestationsCount: 8970,
    accuracyRate: 0.951,
    slashedCount: 0,
    active: true,
    iconName: 'BookOpen'
  },
  {
    id: 'val-cau-07',
    name: 'CAUSAL_VALIDATOR',
    type: 'CAUSAL_VALIDATOR',
    description: 'Evaluates succession in time according to a rule; prevents post-hoc correlation fallacies.',
    baseWeight: 1.25,
    reputation: 0.974,
    attestationsCount: 11600,
    accuracyRate: 0.953,
    slashedCount: 1,
    active: true,
    iconName: 'GitCommit'
  },
  {
    id: 'val-sta-08',
    name: 'STATISTICAL_VALIDATOR',
    type: 'STATISTICAL_VALIDATOR',
    description: 'Audits sample sizes, Bayesian prior-posterior updates, p-values, and effect size distributions.',
    baseWeight: 1.20,
    reputation: 0.989,
    attestationsCount: 16780,
    accuracyRate: 0.978,
    slashedCount: 0,
    active: true,
    iconName: 'BarChart3'
  }
];

export class EpistemicValidatorEngine {
  static calculateEpistemicWeight(
    validator: EpistemicValidator,
    evidenceQuality: number,
    sourceReliability: number,
    logicalCoherence: number,
    conceptualPrecision: number
  ): number {
    // Weighted deterministic score based on PoS epistemic stake principles
    const reputationFactor = validator.reputation * validator.baseWeight;
    const components = (
      evidenceQuality * 0.30 +
      sourceReliability * 0.20 +
      logicalCoherence * 0.25 +
      conceptualPrecision * 0.25
    );
    return Number((reputationFactor * components).toFixed(4));
  }

  static runValidation(
    validator: EpistemicValidator,
    claim: PropositionClaim,
    evidenceList: EpistemicEvidence[]
  ): Attestation {
    const text = claim.text.toLowerCase();
    const isMetaphysical = claim.boundaryDomain === 'METAPHYSICAL_CLAIMS';
    const isAnalytic = claim.judgementClass === 'ANALYTIC';
    const isEmpirical = claim.boundaryDomain === 'EMPIRICAL_PHENOMENA';

    let decision: AttestationDecision = 'VALID';
    let confidence = 0.85;
    let reasoning = '';
    let empiricalScore = 0.80;
    let logicalScore = 0.90;

    const evidenceCount = evidenceList.length;
    const avgEvidenceReliability = evidenceCount > 0 
      ? evidenceList.reduce((acc, e) => acc + e.reliabilityScore, 0) / evidenceCount
      : 0.40;

    switch (validator.type) {
      case 'EMPIRICAL_VALIDATOR': {
        if (isMetaphysical) {
          decision = 'METAPHYSICAL';
          confidence = 0.95;
          empiricalScore = 0.05;
          reasoning = 'Proposition concerns unconditioned objects beyond sensible manifold. Empirical observation cannot test appearance in itself.';
        } else if (isAnalytic) {
          decision = 'ANALYTICAL';
          confidence = 0.98;
          empiricalScore = 0.50;
          reasoning = 'Claim is analytic/formal; empirical observation is neither required nor capable of refuting conceptual tautologies.';
        } else if (evidenceCount === 0 || avgEvidenceReliability < 0.6) {
          decision = 'INSUFFICIENT_EVIDENCE';
          confidence = 0.72;
          empiricalScore = 0.35;
          reasoning = 'Sensory and observational backing is either absent or below required empirical verification threshold (0.60).';
        } else {
          decision = 'VALID';
          confidence = Number((0.80 + avgEvidenceReliability * 0.18).toFixed(2));
          empiricalScore = avgEvidenceReliability;
          reasoning = `Empirical manifold satisfied through ${evidenceCount} verified observation sources. Repeatability score: ${(avgEvidenceReliability * 100).toFixed(1)}%.`;
        }
        break;
      }

      case 'LOGICAL_VALIDATOR': {
        const hasContradiction = /\bboth\s+.+\s+and\s+not\s+/i.test(text);
        if (hasContradiction) {
          decision = 'CONTRADICTED';
          confidence = 0.99;
          logicalScore = 0.02;
          reasoning = 'Violation of the Law of Contradiction: asserts A and non-A simultaneously in the same relation.';
        } else if (isAnalytic) {
          decision = 'VALID';
          confidence = 0.99;
          logicalScore = 0.99;
          reasoning = 'Analytic judgement: predicate is conceptually contained in subject. Perfect logical consistency.';
        } else {
          decision = 'VALID';
          confidence = 0.94;
          logicalScore = 0.92;
          reasoning = 'Formal syllogistic structure satisfies deductive validity without non-sequitur or formal fallacy.';
        }
        break;
      }

      case 'CONCEPTUAL_VALIDATOR': {
        if (claim.categories.relation === 'CAUSALITY' && isMetaphysical) {
          decision = 'UNDECIDABLE';
          confidence = 0.88;
          reasoning = 'Category error: Category of Causality is legitimate only for appearances in time, not for things-in-themselves.';
        } else if (claim.judgement.predicate.length < 2) {
          decision = 'INVALID';
          confidence = 0.80;
          reasoning = 'Deficient conceptual determination: predicate lacks clear extension and intension.';
        } else {
          decision = 'VALID';
          confidence = 0.91;
          reasoning = `Kantian categories correctly configured (${claim.categories.quantity}, ${claim.categories.quality}, ${claim.categories.relation}, ${claim.categories.modality}).`;
        }
        break;
      }

      case 'HISTORICAL_VALIDATOR': {
        decision = 'VALID';
        confidence = 0.88;
        reasoning = 'Historical ledger shows no conflicting state revisions for this proposition lineage.';
        break;
      }

      case 'SCIENTIFIC_VALIDATOR': {
        if (isMetaphysical) {
          decision = 'CONDITIONAL';
          confidence = 0.92;
          empiricalScore = 0.1;
          reasoning = 'Falsifiability criterion failed: non-empirical assertions cannot be subjected to crucial experiments.';
        } else if (evidenceCount < 1 && isEmpirical) {
          decision = 'INSUFFICIENT_EVIDENCE';
          confidence = 0.75;
          empiricalScore = 0.3;
          reasoning = 'Lacks controlled experimental verification and replicable benchmark data.';
        } else {
          decision = 'VALID';
          confidence = 0.89;
          empiricalScore = 0.88;
          reasoning = 'Empirical falsification protocol is well-defined; boundary conditions are explicitly demarcated.';
        }
        break;
      }

      case 'LINGUISTIC_VALIDATOR': {
        const words = text.split(/\s+/).length;
        if (words < 3) {
          decision = 'INVALID';
          confidence = 0.85;
          reasoning = 'Syntactic ambiguity: proposition contains insufficient semantic structure for formal analysis.';
        } else {
          decision = 'VALID';
          confidence = 0.92;
          reasoning = 'Semantic terms exhibit high precision with unambiguous quantifier and relation definitions.';
        }
        break;
      }

      case 'CAUSAL_VALIDATOR': {
        const isCausalClaim = claim.categories.relation === 'CAUSALITY' || /cause|influence|lead to|produce|impact/i.test(text);
        if (isCausalClaim) {
          // If causal assertion with few evidence, make it CONDITIONAL as explicitly noted in prompt Section 10
          if (evidenceCount < 2 || avgEvidenceReliability < 0.85) {
            decision = 'CONDITIONAL';
            confidence = 0.74;
            logicalScore = 0.80;
            empiricalScore = 0.65;
            reasoning = 'Evidence supports strong statistical association, but identification of invariant causal mechanism remains conditional.';
          } else {
            decision = 'VALID';
            confidence = 0.86;
            reasoning = 'Temporal precedence and counterfactual dependence conditions satisfy Second Analogy of Experience.';
          }
        } else {
          decision = 'VALID';
          confidence = 0.90;
          reasoning = 'Non-causal relational assertion; no illicit post-hoc inferences detected.';
        }
        break;
      }

      case 'STATISTICAL_VALIDATOR': {
        if (isAnalytic || isMetaphysical) {
          decision = isAnalytic ? 'ANALYTICAL' : 'UNDECIDABLE';
          confidence = 0.88;
          reasoning = 'Statistical sampling not applicable to formal tautology or metaphysical unconditioned claims.';
        } else {
          decision = avgEvidenceReliability >= 0.7 ? 'VALID' : 'CONDITIONAL';
          confidence = Number((0.75 + avgEvidenceReliability * 0.20).toFixed(2));
          empiricalScore = avgEvidenceReliability;
          reasoning = `Bayesian update calculated: prior 0.50, posterior estimate ${confidence}. Evidence sample depth: ${evidenceCount} sources.`;
        }
        break;
      }
    }

    const epistemicWeight = this.calculateEpistemicWeight(
      validator,
      empiricalScore,
      avgEvidenceReliability,
      logicalScore,
      claim.categories ? 0.9 : 0.7
    );

    const attestationPayload = `${validator.id}:${claim.id}:${decision}:${confidence}:${epistemicWeight}`;
    const signature = computeHashSync(attestationPayload);
    const evidenceHash = computeHashSync(evidenceList.map(e => e.hash).join(':') || 'no_evidence');

    return {
      id: `att-${validator.id.replace('val-', '')}-${Math.random().toString(36).substring(2, 7)}`,
      validatorId: validator.id,
      validatorName: validator.name,
      validatorType: validator.type,
      propositionId: claim.id,
      blockId: claim.blockId,
      timestamp: new Date().toISOString(),
      decision,
      confidence,
      epistemicWeight,
      reasoning,
      empiricalScore,
      logicalScore,
      evidenceHash,
      signature
    };
  }
}
