import { EpistemicFork } from '../types/epistemic';

export const INITIAL_FORKS: EpistemicFork[] = [
  {
    id: 'fork-econ-01',
    name: 'Macroeconomic Investment Contraction Etiology',
    claimId: 'claim-101',
    description: 'Competing interpretations concerning the driving determinant behind the capital expenditure collapse.',
    branches: [
      {
        id: 'branch-a',
        label: 'Branch Alpha (Interest Rate Primacy)',
        claimText: 'Central bank benchmark rate increases directly depressed capital expenditure by raising the hurdle rate for corporate investment.',
        epistemicWeight: 0.812,
        evidenceScore: 0.84,
        logicalCoherence: 0.92,
        explanatoryPower: 0.78,
        isCanonical: false,
        advocateValidator: 'STATISTICAL_VALIDATOR',
        argumentSummary: 'Direct transmission mechanism through debt financing servicing costs.'
      },
      {
        id: 'branch-beta',
        label: 'Branch Beta (Demand Expectation Primacy)',
        claimText: 'Depressed forward consumer demand expectations reduced expected return on investment, regardless of marginal financing costs.',
        epistemicWeight: 0.865,
        evidenceScore: 0.89,
        logicalCoherence: 0.95,
        explanatoryPower: 0.88,
        isCanonical: true,
        advocateValidator: 'CAUSAL_VALIDATOR',
        argumentSummary: 'CFO survey indicators show demand elasticity dominates cost-of-capital elasticity during uncertainty.'
      },
      {
        id: 'branch-gamma',
        label: 'Branch Gamma (Conjunctive Multi-Factor Equilibrium)',
        claimText: 'Both interest rate hikes and downward revisions in aggregate demand acted as coupled reciprocal causes in investment retrenchment.',
        epistemicWeight: 0.790,
        evidenceScore: 0.80,
        logicalCoherence: 0.88,
        explanatoryPower: 0.82,
        isCanonical: false,
        advocateValidator: 'CONCEPTUAL_VALIDATOR',
        argumentSummary: 'Treats the relation as Kantian Community (reciprocity of action and reaction).'
      }
    ],
    activeCanonicalBranchId: 'branch-beta',
    divergenceReason: 'Divergent empirical identification strategies: time-series econometric regression vs firm-level qualitative hurdle rate audits.',
    createdAt: '2026-08-14T11:20:00Z'
  },
  {
    id: 'fork-tech-02',
    name: 'Bitcoin Monetary Function Emergence',
    claimId: 'claim-102',
    description: 'Competing classifications regarding the functional ontology of cryptographic network tokens.',
    branches: [
      {
        id: 'branch-monetary',
        label: 'Branch 1: Proto-Monetary Commodity',
        claimText: 'Bitcoin behaves as digital commodity money whose market liquidity fulfills medium-of-exchange functions in non-state trade.',
        epistemicWeight: 0.742,
        evidenceScore: 0.72,
        logicalCoherence: 0.88,
        explanatoryPower: 0.75,
        isCanonical: false,
        advocateValidator: 'HISTORICAL_VALIDATOR',
        argumentSummary: 'Historical monetary emergence parallels Mengerian saleableness.'
      },
      {
        id: 'branch-asset',
        label: 'Branch 2: High-Beta Speculative Asset',
        claimText: 'Bitcoin acts predominantly as a speculative liquidity asset with extreme volatility precluding unit-of-account function.',
        epistemicWeight: 0.891,
        evidenceScore: 0.93,
        logicalCoherence: 0.94,
        explanatoryPower: 0.91,
        isCanonical: true,
        advocateValidator: 'STATISTICAL_VALIDATOR',
        argumentSummary: 'Empirical pricing correlation with NASDAQ and real yields confirms speculative tech asset profile.'
      }
    ],
    activeCanonicalBranchId: 'branch-asset',
    divergenceReason: 'Distinction between normative design intention vs empirical transaction ledger behavior.',
    createdAt: '2026-09-01T09:45:00Z'
  }
];

export class ForkEngine {
  static createFork(
    name: string,
    claimId: string,
    description: string,
    branches: {
      label: string;
      claimText: string;
      evidenceScore: number;
      logicalCoherence: number;
      explanatoryPower: number;
      advocateValidator: string;
      argumentSummary: string;
    }[]
  ): EpistemicFork {
    const computedBranches = branches.map((b, idx) => {
      const weight = Number((b.evidenceScore * 0.4 + b.logicalCoherence * 0.3 + b.explanatoryPower * 0.3).toFixed(3));
      return {
        id: `branch-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`,
        label: b.label,
        claimText: b.claimText,
        epistemicWeight: weight,
        evidenceScore: b.evidenceScore,
        logicalCoherence: b.logicalCoherence,
        explanatoryPower: b.explanatoryPower,
        isCanonical: false,
        advocateValidator: b.advocateValidator,
        argumentSummary: b.argumentSummary
      };
    });

    // Select highest weight as canonical
    let maxWeight = -1;
    let canonicalId = computedBranches[0]?.id || '';
    computedBranches.forEach(b => {
      if (b.epistemicWeight > maxWeight) {
        maxWeight = b.epistemicWeight;
        canonicalId = b.id;
      }
    });

    computedBranches.forEach(b => {
      b.isCanonical = (b.id === canonicalId);
    });

    return {
      id: `fork-${Date.now().toString(36)}`,
      name,
      claimId,
      description,
      branches: computedBranches,
      activeCanonicalBranchId: canonicalId,
      divergenceReason: 'Empirical underdetermination: multiple hypotheses explain observed phenomena with divergent conceptual assumptions.',
      createdAt: new Date().toISOString()
    };
  }

  static selectCanonicalBranch(fork: EpistemicFork, targetBranchId: string): EpistemicFork {
    return {
      ...fork,
      activeCanonicalBranchId: targetBranchId,
      branches: fork.branches.map(b => ({
        ...b,
        isCanonical: b.id === targetBranchId
      }))
    };
  }
}
