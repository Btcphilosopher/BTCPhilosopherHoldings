import { 
  PropositionClaim, 
  EpistemicBlock, 
  EpistemicLedgerEvent, 
  EpistemicValidator, 
  ConsensusReport, 
  Attestation,
  EpistemicEvidence,
  EpistemicFork,
  AntinomyRecord,
  PredictionRecord,
  KnowledgeGraphNode,
  KnowledgeGraphEdge,
  NodeTelemetry
} from '../types/epistemic';
import { computeHashSync } from './crypto';
import { EpistemicCompiler } from './kantianPipeline';
import { INITIAL_VALIDATORS, EpistemicValidatorEngine } from './validators';
import { ConsensusEngine } from './consensus';
import { INITIAL_FORKS } from './fork';
import { INITIAL_ANTINOMIES } from './antinomy';

// Genesis State
const GENESIS_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

function createInitialPropositions(): PropositionClaim[] {
  // 1. Analytic Tautology
  const dec1 = EpistemicCompiler.compile('All bachelors are unmarried.');
  const claim1: PropositionClaim = {
    id: 'claim-001',
    blockId: 18471,
    text: 'All bachelors are unmarried.',
    version: 1,
    createdAt: '2026-09-08T14:32:00Z',
    judgementClass: 'ANALYTIC',
    origin: 'A_PRIORI',
    boundaryDomain: 'CONCEPTUAL_OBJECTS',
    status: 'FINALIZED',
    certainty: 'TRUE',
    categories: dec1.categories,
    judgement: dec1.judgement,
    transcendental: dec1.transcendental,
    concepts: dec1.concepts,
    evidence: [],
    inferences: dec1.inferences,
    assumptions: dec1.assumptions,
    attestations: [],
    weight: 0.99,
    hash: ''
  };
  claim1.hash = computeHashSync(claim1.text + claim1.createdAt);
  claim1.attestations = INITIAL_VALIDATORS.map(val => 
    EpistemicValidatorEngine.runValidation(val, claim1, [])
  );
  claim1.consensus = ConsensusEngine.evaluateConsensus(claim1, claim1.attestations);

  // 2. Empirical Scientific Claim
  const dec2 = EpistemicCompiler.compile('Copper conducts electricity under standard atmospheric pressure.');
  const ev2: EpistemicEvidence[] = [
    {
      id: 'ev-cu-01',
      claimId: 'claim-002',
      title: 'CRC Handbook of Chemistry and Physics (97th Edition)',
      sourceType: 'BOOK',
      sourceProvenance: 'CRC Press / NIST Standard Reference Database 69',
      author: 'W. M. Haynes, ed.',
      year: 2016,
      reliabilityScore: 0.98,
      reproducible: true,
      hash: computeHashSync('CRC-Cu-Electrical-Conductivity-Std-Pressure'),
      content: 'Electrical resistivity of high-purity electrolytic copper is measured at 1.68 × 10^-8 Ω·m at 20°C.'
    },
    {
      id: 'ev-cu-02',
      claimId: 'claim-002',
      title: 'Four-Point Probe Resistivity Laboratory Verification',
      sourceType: 'PAPER',
      sourceProvenance: 'Physical Review B, Vol 78, Issue 12',
      author: 'K. Tanaka et al.',
      year: 2021,
      reliabilityScore: 0.95,
      reproducible: true,
      hash: computeHashSync('PRB-Tanaka-Cu-Drude-Model'),
      content: 'Drude free-electron conductivity parameters empirically validated across temperature ranges 77K - 350K.'
    }
  ];
  const claim2: PropositionClaim = {
    id: 'claim-002',
    blockId: 18471,
    text: 'Copper conducts electricity under standard atmospheric pressure.',
    version: 1,
    createdAt: '2026-09-08T16:10:00Z',
    judgementClass: 'SYNTHETIC',
    origin: 'A_POSTERIORI',
    boundaryDomain: 'EMPIRICAL_PHENOMENA',
    status: 'FINALIZED',
    certainty: 'LIKELY',
    categories: dec2.categories,
    judgement: dec2.judgement,
    transcendental: dec2.transcendental,
    concepts: dec2.concepts,
    evidence: ev2,
    inferences: dec2.inferences,
    assumptions: dec2.assumptions,
    attestations: [],
    weight: 0.95,
    hash: ''
  };
  claim2.hash = computeHashSync(claim2.text + claim2.createdAt);
  claim2.attestations = INITIAL_VALIDATORS.map(val => 
    EpistemicValidatorEngine.runValidation(val, claim2, ev2)
  );
  claim2.consensus = ConsensusEngine.evaluateConsensus(claim2, claim2.attestations);

  // 3. Bitcoin Observation Claim (from prompt example Section 4)
  const dec3 = EpistemicCompiler.compile('The price of Bitcoin increased during the observation period.');
  const ev3: EpistemicEvidence[] = [
    {
      id: 'ev-btc-01',
      claimId: 'claim-003',
      title: 'Coinbase Pro & Binance Spot Trade Execution Ledger (Aggregated Feed)',
      sourceType: 'DATASET',
      sourceProvenance: 'Cryptographic API Orderbook Millisecond Tape',
      author: 'Consensus Market Data API',
      year: 2026,
      reliabilityScore: 0.96,
      reproducible: true,
      hash: computeHashSync('BTC-USD-Tape-2026-09-01-to-09-07'),
      content: 'BTC/USD opened at $61,240 (t0) and closed at $64,880 (t1). Mean volume delta +5.94%.'
    }
  ];
  const claim3: PropositionClaim = {
    id: 'claim-003',
    blockId: 18472,
    text: 'The price of Bitcoin increased during the observation period.',
    version: 1,
    createdAt: '2026-09-09T09:12:00Z',
    judgementClass: 'SYNTHETIC',
    origin: 'A_POSTERIORI',
    boundaryDomain: 'EMPIRICAL_PHENOMENA',
    status: 'FINALIZED',
    certainty: 'LIKELY',
    categories: dec3.categories,
    judgement: dec3.judgement,
    transcendental: dec3.transcendental,
    concepts: dec3.concepts,
    evidence: ev3,
    inferences: dec3.inferences,
    assumptions: dec3.assumptions,
    attestations: [],
    weight: 0.92,
    hash: ''
  };
  claim3.hash = computeHashSync(claim3.text + claim3.createdAt);
  claim3.attestations = INITIAL_VALIDATORS.map(val => 
    EpistemicValidatorEngine.runValidation(val, claim3, ev3)
  );
  claim3.consensus = ConsensusEngine.evaluateConsensus(claim3, claim3.attestations);

  // 4. Causal Claim (from prompt example Section 10)
  const dec4 = EpistemicCompiler.compile('Interest rates caused investment to fall.');
  const ev4: EpistemicEvidence[] = [
    {
      id: 'ev-rate-01',
      claimId: 'claim-004',
      title: 'Federal Reserve Board Macroeconomic Indicators Q2',
      sourceType: 'DATASET',
      sourceProvenance: 'FRED St. Louis Economic Data Series',
      author: 'Federal Reserve System',
      year: 2025,
      reliabilityScore: 0.92,
      reproducible: true,
      hash: computeHashSync('FED-FRED-Interest-CapEx-2025'),
      content: 'Federal Funds rate increased 525 bps; Non-residential private fixed investment decelerated by 1.8%.'
    }
  ];
  const claim4: PropositionClaim = {
    id: 'claim-004',
    blockId: 18472,
    text: 'Interest rates caused investment to fall.',
    version: 1,
    createdAt: '2026-09-09T18:40:00Z',
    judgementClass: 'SYNTHETIC',
    origin: 'A_POSTERIORI',
    boundaryDomain: 'EMPIRICAL_PHENOMENA',
    status: 'CONDITIONAL',
    certainty: 'PLAUSIBLE',
    categories: dec4.categories,
    judgement: dec4.judgement,
    transcendental: dec4.transcendental,
    concepts: dec4.concepts,
    evidence: ev4,
    inferences: dec4.inferences,
    assumptions: dec4.assumptions,
    attestations: [],
    weight: 0.73,
    hash: ''
  };
  claim4.hash = computeHashSync(claim4.text + claim4.createdAt);
  claim4.attestations = INITIAL_VALIDATORS.map(val => 
    EpistemicValidatorEngine.runValidation(val, claim4, ev4)
  );
  claim4.consensus = ConsensusEngine.evaluateConsensus(claim4, claim4.attestations);

  // 5. Metaphysical Boundary Transgression Claim (from prompt example Section 17)
  const dec5 = EpistemicCompiler.compile('Reality as it is in itself possesses mathematical symmetry independently of every possible condition of human experience.');
  const claim5: PropositionClaim = {
    id: 'claim-005',
    blockId: 18472,
    text: 'Reality as it is in itself possesses mathematical symmetry independently of every possible condition of human experience.',
    version: 1,
    createdAt: '2026-09-10T02:15:00Z',
    judgementClass: 'SYNTHETIC',
    origin: 'A_PRIORI',
    boundaryDomain: 'METAPHYSICAL_CLAIMS',
    status: 'CONDITIONAL',
    certainty: 'UNTESTABLE',
    categories: dec5.categories,
    judgement: dec5.judgement,
    transcendental: dec5.transcendental,
    concepts: dec5.concepts,
    evidence: [],
    inferences: dec5.inferences,
    assumptions: dec5.assumptions,
    attestations: [],
    weight: 0.35,
    hash: ''
  };
  claim5.hash = computeHashSync(claim5.text + claim5.createdAt);
  claim5.attestations = INITIAL_VALIDATORS.map(val => 
    EpistemicValidatorEngine.runValidation(val, claim5, [])
  );
  claim5.consensus = ConsensusEngine.evaluateConsensus(claim5, claim5.attestations);

  return [claim1, claim2, claim3, claim4, claim5];
}

function createInitialBlocks(propositions: PropositionClaim[]): EpistemicBlock[] {
  const block18471Props = propositions.filter(p => p.blockId === 18471);
  const block18472Props = propositions.filter(p => p.blockId === 18472);

  const hash18471 = computeHashSync(`BLOCK-18471:${GENESIS_HASH}:${block18471Props.map(p => p.hash).join(',')}`);
  const hash18472 = computeHashSync(`BLOCK-18472:${hash18471}:${block18472Props.map(p => p.hash).join(',')}`);

  const block18471: EpistemicBlock = {
    blockId: 18471,
    timestamp: '2026-09-08T18:00:00Z',
    previousStateHash: GENESIS_HASH,
    stateHash: hash18471,
    propositions: block18471Props,
    attestationsCount: block18471Props.length * 8,
    consensusCount: block18471Props.length,
    validatorsParticipated: INITIAL_VALIDATORS.map(v => v.name),
    blockSummary: 'Canonical integration of formal analytical identities and foundational physical conductivity parameters.'
  };

  const block18472: EpistemicBlock = {
    blockId: 18472,
    timestamp: '2026-09-10T06:00:00Z',
    previousStateHash: hash18471,
    stateHash: hash18472,
    propositions: block18472Props,
    attestationsCount: block18472Props.length * 8,
    consensusCount: block18472Props.length,
    validatorsParticipated: INITIAL_VALIDATORS.map(v => v.name),
    blockSummary: 'Consensus attestation on empirical asset observations, macroeconomic interest-rate causation, and metaphysical boundary analysis.'
  };

  return [block18471, block18472];
}

export class EpistemicLedgerStore {
  private static propositions: PropositionClaim[] = createInitialPropositions();
  private static blocks: EpistemicBlock[] = createInitialBlocks(this.propositions);
  private static validators: EpistemicValidator[] = [...INITIAL_VALIDATORS];
  private static forks: EpistemicFork[] = [...INITIAL_FORKS];
  private static antinomies: AntinomyRecord[] = [...INITIAL_ANTINOMIES];
  private static predictions: PredictionRecord[] = [
    {
      id: 'pred-01',
      claimId: 'claim-004',
      hypothesis: 'If policy rate holds above 5.0%, non-residential private investment will contract an additional 0.8% over the next two quarters.',
      timeHorizon: '2026-Q4',
      expectedObservation: 'Gross Private Domestic Investment (Chained 2017 Dollars) <= $3,850B',
      status: 'PENDING',
      registeredAt: '2026-09-05T10:00:00Z'
    },
    {
      id: 'pred-02',
      claimId: 'claim-002',
      hypothesis: 'Sample conductivity at 300K will measure within 2% margin of 5.96 × 10^7 S/m across 100 independent trials.',
      timeHorizon: 'Completed Benchmark',
      expectedObservation: 'Mean resistivity = 1.68 × 10^-8 Ω·m',
      actualObservation: 'Empirically measured at 1.678 ± 0.012 × 10^-8 Ω·m',
      errorMargin: 0.0012,
      status: 'VERIFIED',
      registeredAt: '2026-08-20T12:00:00Z'
    }
  ];

  private static ledgerEvents: EpistemicLedgerEvent[] = [
    {
      id: 'evt-001',
      blockId: 18471,
      timestamp: '2026-09-08T14:32:00Z',
      type: 'CLAIM_CREATED',
      description: 'New claim registered: "All bachelors are unmarried."',
      actor: 'LOGICAL_VALIDATOR',
      hash: computeHashSync('evt-001')
    },
    {
      id: 'evt-002',
      blockId: 18471,
      timestamp: '2026-09-08T14:35:00Z',
      type: 'CONSENSUS_REACHED',
      description: 'Consensus FINALIZED on claim-001 (Analytic tautology, 100% agreement).',
      actor: 'CONSENSUS_ENGINE',
      hash: computeHashSync('evt-002')
    },
    {
      id: 'evt-003',
      blockId: 18471,
      timestamp: '2026-09-08T16:10:00Z',
      type: 'EVIDENCE_ADDED',
      description: 'Standard reference material added to Copper conductivity claim.',
      actor: 'SCIENTIFIC_VALIDATOR',
      hash: computeHashSync('evt-003')
    },
    {
      id: 'evt-004',
      blockId: 18472,
      timestamp: '2026-09-09T18:45:00Z',
      type: 'ATTESTATION_CREATED',
      description: 'Causal validator issued CONDITIONAL attestation on interest rate assertion.',
      actor: 'CAUSAL_VALIDATOR',
      hash: computeHashSync('evt-004')
    },
    {
      id: 'evt-005',
      blockId: 18472,
      timestamp: '2026-09-10T02:20:00Z',
      type: 'CONTRADICTION_DETECTED',
      description: 'Knowledge boundary engine flagged claim-005 for exceeding conditions of possible sensible experience.',
      actor: 'CONCEPTUAL_VALIDATOR',
      hash: computeHashSync('evt-005')
    }
  ];

  // Getters
  static getPropositions(): PropositionClaim[] {
    return [...this.propositions];
  }

  static getBlocks(): EpistemicBlock[] {
    return [...this.blocks];
  }

  static getLatestBlock(): EpistemicBlock {
    return this.blocks[this.blocks.length - 1];
  }

  static getValidators(): EpistemicValidator[] {
    return [...this.validators];
  }

  static getForks(): EpistemicFork[] {
    return [...this.forks];
  }

  static getAntinomies(): AntinomyRecord[] {
    return [...this.antinomies];
  }

  static getPredictions(): PredictionRecord[] {
    return [...this.predictions];
  }

  static getLedgerEvents(): EpistemicLedgerEvent[] {
    return [...this.ledgerEvents];
  }

  static getTelemetry(): NodeTelemetry {
    const totalProps = this.propositions.length;
    const justified = this.propositions.filter(p => p.status === 'JUSTIFIED').length;
    const finalized = this.propositions.filter(p => p.status === 'FINALIZED').length;
    const unresolved = this.propositions.filter(p => p.status === 'CONDITIONAL' || p.status === 'PENDING_VALIDATION').length;
    const contradictions = this.propositions.filter(p => p.status === 'CONTRADICTED').length;
    const totalAttestations = this.propositions.reduce((acc, p) => acc + (p.attestations?.length || 0), 0);

    return {
      nodeName: 'DEKANTIAN-KÖNIGSBERG-01',
      uptimeSeconds: 35683200, // 413 days
      syncPercentage: 99.98,
      currentBlockHeight: this.getLatestBlock().blockId,
      totalPropositions: totalProps,
      justifiedCount: justified,
      finalizedCount: finalized,
      unresolvedContradictionsCount: unresolved,
      antinomiesCount: this.antinomies.length,
      attestationsCount: totalAttestations,
      activeValidatorsCount: this.validators.filter(v => v.active).length,
      epistemicHealth: 97.4,
      stateHash: this.getLatestBlock().stateHash
    };
  }

  // Mutation: Propose and Validate a New Proposition
  static proposeAndValidateClaim(
    text: string, 
    evidenceInput?: { title: string; sourceProvenance: string; author: string; content: string; reliability: number }
  ): { claim: PropositionClaim; newBlock: EpistemicBlock } {
    const currentLatest = this.getLatestBlock();
    const nextBlockId = currentLatest.blockId + 1;

    const decomposition = EpistemicCompiler.compile(text);
    const claimId = `claim-${Date.now().toString(36)}`;
    const now = new Date().toISOString();

    const evidenceList: EpistemicEvidence[] = [];
    if (evidenceInput && evidenceInput.title) {
      evidenceList.push({
        id: `ev-${Date.now().toString(36)}`,
        claimId,
        title: evidenceInput.title,
        sourceType: 'USER_OBSERVATION',
        sourceProvenance: evidenceInput.sourceProvenance || 'Direct Epistemic Node Ingestion',
        author: evidenceInput.author || 'Validator Peer',
        year: new Date().getFullYear(),
        reliabilityScore: evidenceInput.reliability || 0.85,
        reproducible: true,
        hash: computeHashSync(evidenceInput.title + evidenceInput.content),
        content: evidenceInput.content
      });
    }

    const claim: PropositionClaim = {
      id: claimId,
      blockId: nextBlockId,
      text,
      version: 1,
      createdAt: now,
      judgementClass: decomposition.judgementClass,
      origin: decomposition.origin,
      boundaryDomain: decomposition.boundaryDomain,
      status: 'PENDING_VALIDATION',
      certainty: decomposition.certainty,
      categories: decomposition.categories,
      judgement: decomposition.judgement,
      transcendental: decomposition.transcendental,
      concepts: decomposition.concepts,
      evidence: evidenceList,
      inferences: decomposition.inferences,
      assumptions: decomposition.assumptions,
      attestations: [],
      weight: 0.80,
      hash: computeHashSync(text + now)
    };

    // Run all 8 validators
    const attestations: Attestation[] = this.validators.map(val => 
      EpistemicValidatorEngine.runValidation(val, claim, evidenceList)
    );
    claim.attestations = attestations;

    // Run Consensus Engine
    const consensus = ConsensusEngine.evaluateConsensus(claim, attestations);
    claim.consensus = consensus;
    claim.status = consensus.finalStatus;
    claim.certainty = consensus.certaintyLevel;

    // Update Validator Reputation stakes slightly
    this.validators.forEach(val => {
      val.attestationsCount += 1;
    });

    this.propositions.unshift(claim);

    // Create a new Epistemic Block linking previous state hash
    const blockPayload = `BLOCK-${nextBlockId}:${currentLatest.stateHash}:${claim.hash}:${attestations.map(a => a.signature).join(':')}`;
    const newStateHash = computeHashSync(blockPayload);

    const newBlock: EpistemicBlock = {
      blockId: nextBlockId,
      timestamp: now,
      previousStateHash: currentLatest.stateHash,
      stateHash: newStateHash,
      propositions: [claim],
      attestationsCount: attestations.length,
      consensusCount: 1,
      validatorsParticipated: this.validators.map(v => v.name),
      blockSummary: `Validated proposition: "${text.slice(0, 65)}..." Status: ${claim.status}.`
    };

    this.blocks.push(newBlock);

    // Record append-only ledger events
    this.ledgerEvents.unshift({
      id: `evt-${Date.now().toString(36)}-1`,
      blockId: nextBlockId,
      timestamp: now,
      type: 'CLAIM_CREATED',
      description: `Claim submitted to validator network: "${text.slice(0, 50)}..."`,
      actor: 'EPISTEMIC_COMPILER',
      hash: computeHashSync(claimId + 'CREATED')
    });

    if (evidenceList.length > 0) {
      this.ledgerEvents.unshift({
        id: `evt-${Date.now().toString(36)}-2`,
        blockId: nextBlockId,
        timestamp: now,
        type: 'EVIDENCE_ADDED',
        description: `Attached empirical evidence: "${evidenceList[0].title}"`,
        actor: 'INGESTION_INTERFACE',
        hash: computeHashSync(evidenceList[0].id)
      });
    }

    this.ledgerEvents.unshift({
      id: `evt-${Date.now().toString(36)}-3`,
      blockId: nextBlockId,
      timestamp: now,
      type: 'CONSENSUS_REACHED',
      description: `Consensus evaluated -> ${claim.status} (${consensus.validatorAgreementRatio} validators agreed).`,
      actor: 'CONSENSUS_ENGINE',
      hash: computeHashSync(claimId + claim.status)
    });

    // Check for Antinomy detection
    const antinomy = INITIAL_ANTINOMIES.find(a => 
      text.toLowerCase().includes('universe') || 
      text.toLowerCase().includes('free will') || 
      text.toLowerCase().includes('determinism')
    );
    if (antinomy) {
      this.ledgerEvents.unshift({
        id: `evt-${Date.now().toString(36)}-4`,
        blockId: nextBlockId,
        timestamp: now,
        type: 'CONTRADICTION_DETECTED',
        description: `Dialectical Antinomy identified: ${antinomy.title}`,
        actor: 'ANTINOMY_DETECTOR',
        hash: computeHashSync(antinomy.id)
      });
    }

    return { claim, newBlock };
  }

  // Revision of a claim without rewriting history (Section 5: OLD CLAIM -> REVISION -> NEW CLAIM)
  static reviseClaim(claimId: string, revisedText: string): PropositionClaim | null {
    const existing = this.propositions.find(p => p.id === claimId);
    if (!existing) return null;

    const currentLatest = this.getLatestBlock();
    const nextBlockId = currentLatest.blockId + 1;
    const now = new Date().toISOString();

    const dec = EpistemicCompiler.compile(revisedText);
    const newVersion = existing.version + 1;

    const revisedClaim: PropositionClaim = {
      ...existing,
      id: `${existing.id}-v${newVersion}`,
      version: newVersion,
      blockId: nextBlockId,
      text: revisedText,
      createdAt: now,
      judgementClass: dec.judgementClass,
      origin: dec.origin,
      boundaryDomain: dec.boundaryDomain,
      categories: dec.categories,
      judgement: dec.judgement,
      transcendental: dec.transcendental,
      concepts: dec.concepts,
      hash: computeHashSync(revisedText + now)
    };

    const attestations = this.validators.map(val => 
      EpistemicValidatorEngine.runValidation(val, revisedClaim, existing.evidence)
    );
    revisedClaim.attestations = attestations;
    const consensus = ConsensusEngine.evaluateConsensus(revisedClaim, attestations);
    revisedClaim.consensus = consensus;
    revisedClaim.status = consensus.finalStatus;
    revisedClaim.certainty = consensus.certaintyLevel;

    this.propositions.unshift(revisedClaim);

    this.ledgerEvents.unshift({
      id: `evt-${Date.now().toString(36)}`,
      blockId: nextBlockId,
      timestamp: now,
      type: 'CLAIM_REVISED',
      description: `Proposition ${existing.id} revised to v${newVersion} without erasing historical lineage.`,
      actor: 'REASON_ENGINE',
      hash: computeHashSync(revisedClaim.id + 'REVISION')
    });

    return revisedClaim;
  }

  // Slashing violation execution (Section 31)
  static slashValidator(validatorId: string, reason: string): EpistemicValidator | null {
    const val = this.validators.find(v => v.id === validatorId);
    if (!val) return null;

    // Epistemic slashing: reduce reputation and baseWeight, permanently record violation
    val.reputation = Math.max(0.1, Number((val.reputation - 0.25).toFixed(3)));
    val.baseWeight = Math.max(0.2, Number((val.baseWeight - 0.35).toFixed(2)));
    val.slashedCount += 1;

    this.ledgerEvents.unshift({
      id: `evt-${Date.now().toString(36)}`,
      blockId: this.getLatestBlock().blockId,
      timestamp: new Date().toISOString(),
      type: 'SLASHING_EXECUTED',
      description: `EPISTEMIC SLASHING EXECUTED on ${val.name}: ${reason}. Reputation docked to ${val.reputation}.`,
      actor: 'SECURITY_VALIDATOR_DISCIPLINE',
      hash: computeHashSync(validatorId + 'SLASHED')
    });

    return val;
  }

  // Knowledge Graph Generator
  static getKnowledgeGraph(): { nodes: KnowledgeGraphNode[]; edges: KnowledgeGraphEdge[] } {
    const nodes: KnowledgeGraphNode[] = [];
    const edges: KnowledgeGraphEdge[] = [];

    this.propositions.slice(0, 10).forEach((p, pIdx) => {
      nodes.push({
        id: p.id,
        label: p.text.length > 30 ? p.text.slice(0, 28) + '...' : p.text,
        type: 'CLAIM',
        status: p.status,
        category: p.boundaryDomain
      });

      // Concepts
      p.concepts.forEach((c) => {
        const cNodeId = `node-${c.name.toLowerCase().replace(/\s+/g, '-')}`;
        if (!nodes.some(n => n.id === cNodeId)) {
          nodes.push({
            id: cNodeId,
            label: c.name,
            type: 'CONCEPT',
            category: c.category
          });
        }
        edges.push({
          id: `edge-${p.id}-${cNodeId}`,
          source: p.id,
          target: cNodeId,
          relation: 'HAS_CONCEPT',
          weight: 0.9
        });
      });

      // Evidence
      p.evidence.forEach(e => {
        nodes.push({
          id: e.id,
          label: e.title.length > 25 ? e.title.slice(0, 23) + '...' : e.title,
          type: 'EVIDENCE',
          category: e.sourceType
        });
        edges.push({
          id: `edge-${e.id}-${p.id}`,
          source: e.id,
          target: p.id,
          relation: 'SUPPORTS',
          weight: e.reliabilityScore
        });
      });

      // Assumptions
      p.assumptions.forEach(a => {
        const aNodeId = `node-${a.id}`;
        nodes.push({
          id: aNodeId,
          label: a.statement.slice(0, 24) + '...',
          type: 'ASSUMPTION',
          category: a.burdenOfProof
        });
        edges.push({
          id: `edge-${p.id}-${aNodeId}`,
          source: p.id,
          target: aNodeId,
          relation: 'DEPENDS_ON',
          weight: 0.75
        });
      });
    });

    return { nodes, edges };
  }
}
