import React, { useState, useEffect } from 'react';
import { EpistemicLedgerStore } from './engine/epistemicStore';
import { Header } from './components/Header';
import { DashboardOverview } from './components/DashboardOverview';
import { BlockExplorer } from './components/BlockExplorer';
import { LiveConsensusView } from './components/LiveConsensusView';
import { ForkManager } from './components/ForkManager';
import { DialecticalGraph } from './components/DialecticalGraph';
import { KnowledgeGraphView } from './components/KnowledgeGraphView';
import { EpistemicTerminal } from './components/EpistemicTerminal';
import { ValidatorSetView } from './components/ValidatorSetView';
import { NewClaimModal } from './components/NewClaimModal';
import { PropositionClaim, EpistemicFork } from './types/epistemic';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [telemetry, setTelemetry] = useState(EpistemicLedgerStore.getTelemetry());
  const [propositions, setPropositions] = useState<PropositionClaim[]>(EpistemicLedgerStore.getPropositions());
  const [blocks, setBlocks] = useState(EpistemicLedgerStore.getBlocks());
  const [validators, setValidators] = useState(EpistemicLedgerStore.getValidators());
  const [forks, setForks] = useState<EpistemicFork[]>(EpistemicLedgerStore.getForks());
  const [antinomies] = useState(EpistemicLedgerStore.getAntinomies());
  const [ledgerEvents, setLedgerEvents] = useState(EpistemicLedgerStore.getLedgerEvents());
  const [selectedClaim, setSelectedClaim] = useState<PropositionClaim>(propositions[0]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Sync state helper
  const refreshState = (newSelected?: PropositionClaim) => {
    const updatedProps = EpistemicLedgerStore.getPropositions();
    const updatedBlocks = EpistemicLedgerStore.getBlocks();
    const updatedTelemetry = EpistemicLedgerStore.getTelemetry();
    const updatedValidators = EpistemicLedgerStore.getValidators();
    const updatedLedger = EpistemicLedgerStore.getLedgerEvents();

    setPropositions(updatedProps);
    setBlocks(updatedBlocks);
    setTelemetry(updatedTelemetry);
    setValidators(updatedValidators);
    setLedgerEvents(updatedLedger);

    if (newSelected) {
      setSelectedClaim(newSelected);
    } else if (!selectedClaim && updatedProps.length > 0) {
      setSelectedClaim(updatedProps[0]);
    }
  };

  const handleProposeClaim = (text: string, evidence?: any) => {
    const { claim } = EpistemicLedgerStore.proposeAndValidateClaim(text, evidence);
    refreshState(claim);
  };

  const handleReviseClaim = (claimId: string, revisedText: string) => {
    const revised = EpistemicLedgerStore.reviseClaim(claimId, revisedText);
    if (revised) {
      refreshState(revised);
    }
  };

  const handleSlashValidator = (validatorId: string, reason: string) => {
    EpistemicLedgerStore.slashValidator(validatorId, reason);
    refreshState();
  };

  const handleUpdateForks = (updatedForks: EpistemicFork[]) => {
    setForks(updatedForks);
    refreshState();
  };

  return (
    <div className="min-h-screen bg-[#0a0c10] text-[#e2e8f0] font-mono selection:bg-amber-500 selection:text-black">
      {/* Top Header & Telemetry Ribbon */}
      <Header
        telemetry={telemetry}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewClaimModal={() => setIsModalOpen(true)}
      />

      {/* Main Workspace */}
      <main className="max-w-[1720px] mx-auto p-4 md:p-6">
        {activeTab === 'dashboard' && (
          <DashboardOverview
            telemetry={telemetry}
            propositions={propositions}
            ledgerEvents={ledgerEvents}
            selectedClaim={selectedClaim}
            onSelectClaim={setSelectedClaim}
            onSubmitProposition={handleProposeClaim}
            onReviseClaim={handleReviseClaim}
            onNavigateToTab={setActiveTab}
          />
        )}

        {activeTab === 'blocks' && (
          <BlockExplorer
            blocks={blocks}
            onSelectClaim={setSelectedClaim}
            onNavigateToDashboard={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'consensus' && (
          <LiveConsensusView
            propositions={propositions}
            validators={validators}
            onSelectClaim={claim => {
              setSelectedClaim(claim);
              setActiveTab('dashboard');
            }}
          />
        )}

        {activeTab === 'forks' && (
          <ForkManager
            forks={forks}
            onUpdateForks={handleUpdateForks}
          />
        )}

        {activeTab === 'antinomies' && (
          <DialecticalGraph
            antinomies={antinomies}
          />
        )}

        {activeTab === 'graph' && (
          <KnowledgeGraphView
            onSelectClaim={claim => {
              setSelectedClaim(claim);
              setActiveTab('dashboard');
            }}
          />
        )}

        {activeTab === 'terminal' && (
          <EpistemicTerminal
            propositions={propositions}
            blocks={blocks}
            validators={validators}
            antinomies={antinomies}
            onSubmitProposition={handleProposeClaim}
          />
        )}

        {activeTab === 'validators' && (
          <ValidatorSetView
            validators={validators}
            onSlashValidator={handleSlashValidator}
          />
        )}
      </main>

      {/* Proposition Ingestion Modal */}
      <NewClaimModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleProposeClaim}
      />
    </div>
  );
}

export default App;
