package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.data.repository.CountyCricketRepository
import com.example.ui.archive.ArchiveScreen
import com.example.ui.components.CricketTopAppBar
import com.example.ui.counties.CountiesScreen
import com.example.ui.home.HomeScreen
import com.example.ui.matchcentre.MatchCentreScreen
import com.example.ui.matches.MatchesScreen
import com.example.ui.membership.MembershipDialog
import com.example.ui.portal.ClubPortalScreen
import com.example.ui.search.SearchDialog
import com.example.ui.settings.SettingsDialog
import com.example.ui.theme.*

enum class AppDestination(val label: String, val iconFilled: androidx.compose.ui.graphics.vector.ImageVector, val iconOutlined: androidx.compose.ui.graphics.vector.ImageVector) {
  PAVILION("Pavilion", Icons.Filled.SportsCricket, Icons.Outlined.SportsCricket),
  MATCHES("Matches", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth),
  COUNTIES("Counties", Icons.Filled.Shield, Icons.Outlined.Shield),
  ARCHIVE("Archive", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
  CLUB_PORTAL("Club Portal", Icons.Filled.Podcasts, Icons.Outlined.Podcasts),
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val repository = CountyCricketRepository.getInstance()

    setContent {
      CountyCricketTheme {
        CountyCricketApp(repository = repository)
      }
    }
  }
}

@Composable
fun CountyCricketApp(repository: CountyCricketRepository) {
  val matches by repository.matches.collectAsStateWithLifecycle()
  val selectedMatch by repository.selectedMatch.collectAsStateWithLifecycle()
  val ballEventsMap by repository.ballEvents.collectAsStateWithLifecycle()
  val userProfile by repository.userProfile.collectAsStateWithLifecycle()
  val publishedBroadcasts by repository.publishedBroadcasts.collectAsStateWithLifecycle()
  val highlights by repository.highlights.collectAsStateWithLifecycle()
  val articles by repository.articles.collectAsStateWithLifecycle()
  val currentStream by repository.currentStream.collectAsStateWithLifecycle()
  val currentStreamState by repository.currentStreamState.collectAsStateWithLifecycle()
  val secondaryStream by repository.secondaryStream.collectAsStateWithLifecycle()
  val isMultiviewActive by repository.isMultiviewActive.collectAsStateWithLifecycle()

  var currentDestination by remember { mutableStateOf(AppDestination.PAVILION) }
  var isMatchCentreOpen by remember { mutableStateOf(false) }
  var selectedCountyId by remember { mutableStateOf<String?>("yorkshire") }
  var portalActiveCountyId by remember { mutableStateOf("yorkshire") }

  // Dialog states
  var isSearchOpen by remember { mutableStateOf(false) }
  var isMembershipOpen by remember { mutableStateOf(false) }
  var isSettingsOpen by remember { mutableStateOf(false) }

  val liveMatchesCount = remember(matches) { matches.count { it.status.isLive } }

  // System back button handling
  BackHandler(enabled = isMatchCentreOpen || isSearchOpen || isMembershipOpen || isSettingsOpen) {
    when {
      isSearchOpen -> isSearchOpen = false
      isMembershipOpen -> isMembershipOpen = false
      isSettingsOpen -> isSettingsOpen = false
      isMatchCentreOpen -> isMatchCentreOpen = false
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = CricketCreamBackground,
    topBar = {
      if (!isMatchCentreOpen) {
        CricketTopAppBar(
          liveCount = liveMatchesCount,
          onOpenSearch = { isSearchOpen = true },
          onOpenMembership = { isMembershipOpen = true },
          onOpenSettings = { isSettingsOpen = true }
        )
      }
    },
    bottomBar = {
      if (!isMatchCentreOpen) {
        NavigationBar(
          modifier = Modifier.border(0.5.dp, CricketBorder),
          containerColor = CricketCreamBackground,
          tonalElevation = 2.dp
        ) {
          AppDestination.entries.forEach { destination ->
            val isSelected = currentDestination == destination
            NavigationBarItem(
              icon = {
                Icon(
                  if (isSelected) destination.iconFilled else destination.iconOutlined,
                  contentDescription = destination.label
                )
              },
              label = {
                Text(
                  text = destination.label,
                  fontFamily = FontFamily.Serif,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  fontSize = 11.sp
                )
              },
              selected = isSelected,
              onClick = {
                currentDestination = destination
                if (destination == AppDestination.COUNTIES) {
                  selectedCountyId = null
                }
              },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CricketGreenDark,
                selectedTextColor = CricketGreenDark,
                indicatorColor = CricketBrassGoldContainer,
                unselectedIconColor = CricketInkMuted,
                unselectedTextColor = CricketInkSecondary
              ),
              modifier = Modifier.testTag("nav_item_${destination.name.lowercase()}")
            )
          }
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      if (isMatchCentreOpen && selectedMatch != null) {
        val activeMatch = selectedMatch!!
        val activeBallEvents = ballEventsMap[activeMatch.id] ?: emptyList()
        val secondaryMatch = matches.firstOrNull { it.id != activeMatch.id && it.status.isLive }

        MatchCentreScreen(
          match = activeMatch,
          stream = currentStream,
          secondaryStream = secondaryStream,
          secondaryMatch = secondaryMatch,
          streamState = currentStreamState,
          ballEvents = activeBallEvents,
          highlights = highlights,
          isMultiviewActive = isMultiviewActive,
          onBack = { isMatchCentreOpen = false },
          onQualityChange = { repository.setQuality(it) },
          onToggleLowBandwidth = { repository.toggleLowBandwidthMode(it) },
          onAdjustAudioSync = { repository.adjustAudioSync(it) },
          onSimulateDrop = { repository.simulateNetworkInterruption() },
          onToggleMultiview = { repository.toggleMultiview() },
          onSwapMultiview = {
            if (secondaryMatch != null) {
              repository.selectMatch(secondaryMatch.id)
            }
          },
          onStepBall = { repository.stepSingleBall() }
        )
      } else {
        when (currentDestination) {
          AppDestination.PAVILION -> {
            HomeScreen(
              matches = matches,
              articles = articles,
              highlights = highlights,
              userProfile = userProfile,
              onSelectMatch = { matchId ->
                repository.selectMatch(matchId)
                isMatchCentreOpen = true
              },
              onNavigateToMatches = { currentDestination = AppDestination.MATCHES },
              onNavigateToCounties = {
                selectedCountyId = null
                currentDestination = AppDestination.COUNTIES
              },
              onNavigateToArchive = { currentDestination = AppDestination.ARCHIVE },
              onSelectCounty = { countyId ->
                selectedCountyId = countyId
                currentDestination = AppDestination.COUNTIES
              }
            )
          }

          AppDestination.MATCHES -> {
            MatchesScreen(
              matches = matches,
              onSelectMatch = { matchId ->
                repository.selectMatch(matchId)
                isMatchCentreOpen = true
              }
            )
          }

          AppDestination.COUNTIES -> {
            CountiesScreen(
              selectedCountyId = selectedCountyId,
              onSelectCounty = { selectedCountyId = it },
              onClearCountySelection = { selectedCountyId = null },
              onNavigateToPortal = { countyId ->
                portalActiveCountyId = countyId
                currentDestination = AppDestination.CLUB_PORTAL
              }
            )
          }

          AppDestination.ARCHIVE -> {
            ArchiveScreen(
              highlights = highlights,
              articles = articles,
              onPlayHighlight = { hl ->
                val associatedMatch = matches.firstOrNull { it.homeCountyId == hl.countyId || it.awayCountyId == hl.countyId }
                if (associatedMatch != null) {
                  repository.selectMatch(associatedMatch.id)
                  isMatchCentreOpen = true
                }
              }
            )
          }

          AppDestination.CLUB_PORTAL -> {
            ClubPortalScreen(
              activeCountyId = portalActiveCountyId,
              publishedBroadcasts = publishedBroadcasts,
              matches = matches,
              onPublishBroadcast = { config ->
                repository.publishClubBroadcast(config)
              },
              onSelectCounty = { portalActiveCountyId = it }
            )
          }
        }
      }
    }
  }

  // Global Dialogs
  if (isSearchOpen) {
    SearchDialog(
      matches = matches,
      onSelectMatch = { matchId ->
        repository.selectMatch(matchId)
        isMatchCentreOpen = true
      },
      onSelectCounty = { countyId ->
        selectedCountyId = countyId
        currentDestination = AppDestination.COUNTIES
      },
      onDismiss = { isSearchOpen = false }
    )
  }

  if (isMembershipOpen) {
    MembershipDialog(
      userProfile = userProfile,
      onSelectPlan = { plan ->
        repository.updatePlan(plan)
      },
      onDismiss = { isMembershipOpen = false }
    )
  }

  if (isSettingsOpen) {
    SettingsDialog(
      userProfile = userProfile,
      isSimulationActive = repository.isLiveSimulationActive,
      onToggleSimulation = { repository.toggleSimulation(it) },
      onUpdateTerritory = { repository.updateTerritory(it) },
      onToggleLowBandwidth = { repository.toggleLowBandwidthMode(it) },
      onDismiss = { isSettingsOpen = false }
    )
  }
}
