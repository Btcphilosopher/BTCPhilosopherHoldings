package com.example.ui.archive

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EditorialArticle
import com.example.data.model.HighlightItem
import com.example.data.model.HighlightType
import com.example.ui.home.EditorialCard
import com.example.ui.theme.*

@Composable
fun ArchiveScreen(
  highlights: List<HighlightItem>,
  articles: List<EditorialArticle>,
  onPlayHighlight: (HighlightItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Video Highlights, 1: Wisden Essays
  var selectedTypeFilter by remember { mutableStateOf<HighlightType?>(null) }

  val filteredHighlights = remember(highlights, selectedTypeFilter) {
    if (selectedTypeFilter == null) highlights else highlights.filter { it.type == selectedTypeFilter }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(CricketCreamBackground)
      .padding(horizontal = 14.dp)
  ) {
    Spacer(modifier = Modifier.height(12.dp))

    // Header
    Text(
      text = "THE COUNTY ARCHIVE",
      style = MaterialTheme.typography.labelSmall,
      color = CricketBrassGold,
      letterSpacing = 1.2.sp
    )
    Text(
      text = "Highlights, Replays & Wisden Columns",
      style = MaterialTheme.typography.titleLarge,
      fontFamily = FontFamily.Serif,
      fontWeight = FontWeight.Bold,
      color = CricketInk
    )

    Spacer(modifier = Modifier.height(10.dp))

    // Tab switcher: Highlights vs Essays
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("Video Highlights & Replays", "Wisden Essays & Reports").forEachIndexed { index, title ->
        val isSelected = selectedTab == index
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CricketGreenPrimary else CricketCreamSurface)
            .border(1.dp, if (isSelected) CricketGreenPrimary else CricketBorder, RoundedCornerShape(8.dp))
            .clickable { selectedTab = index }
            .padding(vertical = 8.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) Color.White else CricketInkSecondary,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    if (selectedTab == 0) {
      // Highlights & Replays
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(filteredHighlights) { hl ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, CricketBorder, RoundedCornerShape(10.dp))
              .clickable { onPlayHighlight(hl) }
              .testTag("highlight_item_${hl.id}"),
            colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(68.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(CricketGreenDark),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(36.dp))
              }

              Spacer(modifier = Modifier.width(12.dp))

              Column(modifier = Modifier.weight(1f)) {
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(CricketScorecardHeader)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = hl.type.label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = CricketInkSecondary,
                    fontSize = 9.sp
                  )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                  text = hl.title,
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.Bold,
                  color = CricketInk,
                  fontFamily = FontFamily.Serif
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                  text = "${hl.durationText} • ${hl.viewsCount} views • ${hl.publishedDateText}",
                  style = MaterialTheme.typography.labelSmall,
                  color = CricketInkMuted
                )
              }
            }
          }
        }
      }
    } else {
      // Wisden Columns & Essays
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(articles) { article ->
          EditorialCard(article = article, onClick = {})
        }
      }
    }
  }
}
