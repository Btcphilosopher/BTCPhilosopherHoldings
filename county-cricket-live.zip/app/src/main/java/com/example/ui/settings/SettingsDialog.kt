package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Territory
import com.example.data.model.UserProfile
import com.example.ui.theme.*

@Composable
fun SettingsDialog(
  userProfile: UserProfile,
  isSimulationActive: Boolean,
  onToggleSimulation: (Boolean) -> Unit,
  onUpdateTerritory: (Territory) -> Unit,
  onToggleLowBandwidth: (Boolean) -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "PLATFORM PREFERENCES",
            style = MaterialTheme.typography.labelSmall,
            color = CricketBrassGold,
            letterSpacing = 1.sp
          )
          Text(
            text = "Territory & Playback Settings",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = CricketInk
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }
    },
    text = {
      LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Territory & Regional Rights Simulator
        item {
          Text(
            text = "Broadcast Territory Rights Simulator",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
          Text(
            text = "Simulate accessing the platform from different territories to observe rights clearances and geo-availability rules.",
            style = MaterialTheme.typography.bodySmall,
            color = CricketInkSecondary
          )

          Spacer(modifier = Modifier.height(6.dp))

          Territory.entries.forEach { terr ->
            val isSelected = userProfile.selectedTerritory == terr
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(if (isSelected) CricketGreenContainer else CricketCreamSurface)
                .clickable { onUpdateTerritory(terr) }
                .padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              RadioButton(
                selected = isSelected,
                onClick = { onUpdateTerritory(terr) }
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${terr.label} (${terr.code})",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = CricketInk
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
          }
        }

        // Live Simulation Ticker Switch
        item {
          HorizontalDivider(color = CricketBorder)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Live Match Ticker Simulator",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = CricketInk
              )
              Text(
                text = "Deterministically bowls a ball every 4 seconds in the flagship Roses match.",
                style = MaterialTheme.typography.bodySmall,
                color = CricketInkMuted
              )
            }
            Switch(
              checked = isSimulationActive,
              onCheckedChange = onToggleSimulation,
              modifier = Modifier.testTag("simulation_ticker_switch")
            )
          }
        }

        // Low-Bandwidth Mode
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Low-Bandwidth Mode (Audio Only)",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = CricketInk
              )
              Text(
                text = "Reduces data usage by streaming only the radio commentary audio.",
                style = MaterialTheme.typography.bodySmall,
                color = CricketInkMuted
              )
            }
            Switch(
              checked = userProfile.lowBandwidthAudioOnly,
              onCheckedChange = onToggleLowBandwidth
            )
          }
        }

        // About & Wisden Heritage
        item {
          HorizontalDivider(color = CricketBorder)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "COUNTY CRICKET LIVE v1.0",
            style = MaterialTheme.typography.labelSmall,
            color = CricketBrassGold,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "The Home of County Cricket. Dedicated to the 18 first-class counties across England and Wales. Where commercial streaming credentials are unavailable, clearly labelled demonstration feeds and deterministic synthetic match engines are provided.",
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Serif,
            color = CricketInkSecondary,
            fontSize = 11.sp,
            lineHeight = 16.sp
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary)
      ) {
        Text("Done", color = androidx.compose.ui.graphics.Color.White)
      }
    }
  )
}
