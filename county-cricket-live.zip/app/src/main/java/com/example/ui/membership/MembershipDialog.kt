package com.example.ui.membership

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EntitlementPlan
import com.example.data.model.UserProfile
import com.example.ui.theme.*

@Composable
fun MembershipDialog(
  userProfile: UserProfile,
  onSelectPlan: (EntitlementPlan) -> Unit,
  onDismiss: () -> Unit,
) {
  var selectedPlan by remember { mutableStateOf(userProfile.currentPlan) }
  var isCheckoutSimulated by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "COUNTY PASSES & MEMBERSHIPS",
            style = MaterialTheme.typography.labelSmall,
            color = CricketBrassGold,
            letterSpacing = 1.sp
          )
          Text(
            text = "Supporter Access Plans",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = CricketInk
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }
    },
    text = {
      if (isCheckoutSimulated) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(RoundedCornerShape(27.dp))
              .background(CricketGreenContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = CricketGreenDark, modifier = Modifier.size(32.dp))
          }
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Entitlement Activated!",
            style = MaterialTheme.typography.titleMedium,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Your ${selectedPlan.title} is now active. All authorised club feeds in your territory are unlocked.",
            style = MaterialTheme.typography.bodySmall,
            color = CricketInkSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
          )
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            Text(
              text = "Choose a pass to support your county. 70% of proceeds go directly to participating county clubs.",
              style = MaterialTheme.typography.bodySmall,
              color = CricketInkSecondary,
              fontFamily = FontFamily.Serif
            )
          }

          item {
            PlanCard(
              title = "Free Registered Supporter",
              price = "£0.00 / season",
              features = listOf(
                "Access to all Free-to-Air county club streams",
                "Official Wisden-grade scorecards and ball-by-ball",
                "Full match highlights and interview archive",
                "Standard 1080p video player"
              ),
              isSelected = selectedPlan == EntitlementPlan.FREE_SUPPORTER,
              onClick = { selectedPlan = EntitlementPlan.FREE_SUPPORTER }
            )
          }

          item {
            PlanCard(
              title = "Official County Club Pass",
              price = "£14.99 / season",
              features = listOf(
                "Every home and away stream for your chosen county",
                "Synchronised radio commentary and TMS audio",
                "Direct revenue contribution to your club's cricket academy",
                "Multi-match viewing mode with split screen"
              ),
              isSelected = selectedPlan == EntitlementPlan.COUNTY_CLUB_PASS,
              onClick = { selectedPlan = EntitlementPlan.COUNTY_CLUB_PASS }
            )
          }

          item {
            PlanCard(
              title = "All-18 Counties National Pass",
              price = "£44.99 / season",
              features = listOf(
                "Every professional county match across all 18 clubs",
                "All County Championship, Blast & One-Day Cup feeds",
                "Priority full-match replays & condensed sessions",
                "Ultra-low latency CDN feeds & low-bandwidth audio mode"
              ),
              isSelected = selectedPlan == EntitlementPlan.ALL_COUNTY_PASS,
              onClick = { selectedPlan = EntitlementPlan.ALL_COUNTY_PASS }
            )
          }
        }
      }
    },
    confirmButton = {
      if (isCheckoutSimulated) {
        Button(
          onClick = {
            onSelectPlan(selectedPlan)
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary)
        ) {
          Text("Continue Watching", color = Color.White)
        }
      } else {
        Button(
          onClick = {
            isCheckoutSimulated = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary),
          modifier = Modifier.testTag("confirm_membership_plan_button")
        ) {
          Text("Activate (${selectedPlan.priceText})", color = Color.White)
        }
      }
    },
    dismissButton = {
      if (!isCheckoutSimulated) {
        TextButton(onClick = onDismiss) { Text("Cancel") }
      }
    }
  )
}

@Composable
private fun PlanCard(
  title: String,
  price: String,
  features: List<String>,
  isSelected: Boolean,
  onClick: () -> Unit,
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .border(
        width = if (isSelected) 2.dp else 1.dp,
        color = if (isSelected) CricketBrassGold else CricketBorder,
        shape = RoundedCornerShape(10.dp)
      )
      .clickable(onClick = onClick),
    colors = CardDefaults.cardColors(
      containerColor = if (isSelected) CricketBrassGoldContainer.copy(alpha = 0.3f) else CricketCreamSurface
    )
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = title,
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.titleSmall,
          fontFamily = FontFamily.Serif,
          color = CricketInk
        )
        Text(
          text = price,
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.labelMedium,
          color = CricketGreenDark
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      features.forEach { feat ->
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(vertical = 1.dp)
        ) {
          Icon(Icons.Default.Check, contentDescription = null, tint = CricketGreenPrimary, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = feat, style = MaterialTheme.typography.bodySmall, color = CricketInkSecondary, fontSize = 11.sp)
        }
      }
    }
  }
}
