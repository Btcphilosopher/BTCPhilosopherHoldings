package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Match
import com.example.data.model.VideoStream
import com.example.data.repository.CountyDatasets
import com.example.ui.theme.*

@Composable
fun MultiviewCompanionPane(
  secondaryMatch: Match?,
  secondaryStream: VideoStream?,
  onSwapStreams: () -> Unit,
  onCloseMultiview: () -> Unit,
  modifier: Modifier = Modifier,
) {
  if (secondaryMatch == null) return

  val home = CountyDatasets.getCounty(secondaryMatch.homeCountyId)
  val away = CountyDatasets.getCounty(secondaryMatch.awayCountyId)
  val innings = secondaryMatch.inningsList.getOrNull(secondaryMatch.currentInningsIndex)
  val score = if (innings != null) "${innings.totalRuns}/${innings.wickets} (${innings.oversCompleted} ov)" else "Starting soon"

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(10.dp))
      .border(1.dp, CricketBrassGold, RoundedCornerShape(10.dp)),
    colors = CardDefaults.cardColors(containerColor = CricketGreenDark)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(CricketBrassGold)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "SECONDARY STREAM",
              color = CricketGreenDark,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              fontSize = 9.sp
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = secondaryMatch.competition.shortTitle,
            color = CricketBorder,
            style = MaterialTheme.typography.labelSmall
          )
        }

        Row {
          IconButton(onClick = onSwapStreams, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.SwapHoriz, contentDescription = "Swap Feeds", tint = Color.White, modifier = Modifier.size(18.dp))
          }
          IconButton(onClick = onCloseMultiview, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close Multiview", tint = Color.White, modifier = Modifier.size(18.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "${home.name} vs ${away.name}",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = secondaryMatch.statusDetail,
            color = CricketBrassGold,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CricketGreenPrimary)
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = score,
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Secondary Live Feed mini status bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0x33000000), RoundedCornerShape(4.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Stream: ${secondaryStream?.providerType?.label?.take(20) ?: "Kia Oval TV"}",
          color = CricketBorder,
          style = MaterialTheme.typography.labelSmall,
          fontSize = 10.sp
        )
        Text(
          text = "${secondaryStream?.bitrateKbps ?: 3200} kbps • 720p",
          color = CricketBrassGold,
          style = MaterialTheme.typography.labelSmall,
          fontSize = 10.sp
        )
      }
    }
  }
}
