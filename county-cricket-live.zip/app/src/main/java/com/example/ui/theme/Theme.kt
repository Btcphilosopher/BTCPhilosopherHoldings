package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
  primary = CricketGreenPrimary,
  onPrimary = Color.White,
  primaryContainer = CricketGreenContainer,
  onPrimaryContainer = CricketOnGreenContainer,
  secondary = CricketBrassGold,
  onSecondary = CricketOnBrassGold,
  secondaryContainer = CricketBrassGoldContainer,
  onSecondaryContainer = CricketOnBrassGold,
  tertiary = CricketGreenMedium,
  onTertiary = Color.White,
  background = CricketCreamBackground,
  onBackground = CricketInk,
  surface = CricketCreamSurface,
  onSurface = CricketInk,
  surfaceVariant = CricketScorecardCream,
  onSurfaceVariant = CricketInkSecondary,
  outline = CricketBorder,
  outlineVariant = CricketBorderSubtle,
  error = CricketLiveRed,
  onError = CricketOnLiveRed,
  errorContainer = CricketLiveRedContainer,
  onErrorContainer = CricketLiveRed,
)

private val DarkColorScheme = darkColorScheme(
  primary = CricketBrassGold,
  onPrimary = CricketGreenDark,
  primaryContainer = CricketGreenMedium,
  onPrimaryContainer = Color.White,
  secondary = CricketBrassGoldBright,
  onSecondary = CricketGreenDark,
  secondaryContainer = CricketGreenDark,
  onSecondaryContainer = CricketBrassGold,
  tertiary = CricketGreenLight,
  onTertiary = Color.White,
  background = Color(0xFF0F1512),
  onBackground = Color(0xFFE8EDE9),
  surface = Color(0xFF161E1A),
  onSurface = Color(0xFFE8EDE9),
  surfaceVariant = Color(0xFF1E2722),
  onSurfaceVariant = Color(0xFFBAC5BE),
  outline = Color(0xFF38453D),
  outlineVariant = Color(0xFF28332C),
  error = Color(0xFFFFB4AB),
  onError = Color(0xFF690005),
  errorContainer = Color(0xFF93000A),
  onErrorContainer = Color(0xFFFFDAD6),
)

@Composable
fun CountyCricketTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content,
  )
}
