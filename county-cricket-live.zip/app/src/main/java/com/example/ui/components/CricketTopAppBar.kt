package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CricketTopAppBar(
  liveCount: Int,
  onOpenSearch: () -> Unit,
  onOpenMembership: () -> Unit,
  onOpenSettings: () -> Unit,
  modifier: Modifier = Modifier,
) {
  TopAppBar(
    modifier = modifier.border(0.5.dp, CricketBorder),
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = CricketCreamBackground,
      titleContentColor = CricketInk,
    ),
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Crest / Cricket Ball Logo
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CricketGreenPrimary),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "🏏",
            fontSize = 18.sp
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "COUNTY CRICKET",
              style = MaterialTheme.typography.titleMedium,
              fontFamily = FontFamily.Serif,
              fontWeight = FontWeight.Bold,
              color = CricketGreenDark,
              letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "LIVE",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.ExtraBold,
              color = CricketBrassGold,
              letterSpacing = 1.sp
            )
          }
          Text(
            text = "The Home of County Cricket",
            style = MaterialTheme.typography.labelSmall,
            color = CricketInkMuted,
            fontSize = 10.sp
          )
        }
      }
    },
    actions = {
      // Live Count Pill
      if (liveCount > 0) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CricketLiveRedContainer)
            .border(1.dp, CricketLiveRed.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("live_matches_badge")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(CricketLiveRed)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "$liveCount LIVE",
              style = MaterialTheme.typography.labelSmall,
              color = CricketLiveRed,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp
            )
          }
        }
        Spacer(modifier = Modifier.width(6.dp))
      }

      // Search Action
      IconButton(
        onClick = onOpenSearch,
        modifier = Modifier.testTag("top_search_button")
      ) {
        Icon(Icons.Default.Search, contentDescription = "Search", tint = CricketInk)
      }

      // Passes / Membership Action
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(CricketBrassGoldContainer)
          .border(1.dp, CricketBrassGold.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
          .clickable(onClick = onOpenMembership)
          .padding(horizontal = 8.dp, vertical = 6.dp)
          .testTag("top_passes_button")
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.CardMembership, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "PASSES",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = CricketOnBrassGold,
            fontSize = 10.sp
          )
        }
      }

      Spacer(modifier = Modifier.width(4.dp))

      // Settings Action
      IconButton(
        onClick = onOpenSettings,
        modifier = Modifier.testTag("top_settings_button")
      ) {
        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = CricketInkSecondary)
      }
    }
  )
}
