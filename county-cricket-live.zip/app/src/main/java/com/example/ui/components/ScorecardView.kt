package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BattingEntry
import com.example.data.model.BowlingEntry
import com.example.data.model.Innings
import com.example.data.model.Match
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ScorecardView(
  match: Match,
  modifier: Modifier = Modifier,
) {
  if (match.inningsList.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "Scorecard will appear once the match commences.",
        style = MaterialTheme.typography.bodyMedium,
        color = CricketInkMuted,
        fontFamily = FontFamily.Serif
      )
    }
    return
  }

  var selectedInningsIndex by remember(match.id) {
    mutableIntStateOf(match.currentInningsIndex.coerceIn(0, match.inningsList.lastIndex))
  }

  // Ensure index is within bounds if innings count changes
  val activeIndex = selectedInningsIndex.coerceIn(0, match.inningsList.lastIndex)
  val innings = match.inningsList[activeIndex]

  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(CricketScorecardCream)
      .border(1.dp, CricketBorder, RoundedCornerShape(12.dp))
      .padding(16.dp)
  ) {
    // Scorecard Header & Innings Selector
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "OFFICIAL SCORECARD",
          style = MaterialTheme.typography.labelSmall,
          color = CricketBrassGold,
          letterSpacing = 1.2.sp
        )
        Text(
          text = innings.teamName,
          style = MaterialTheme.typography.titleLarge,
          color = CricketInk,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold
        )
      }

      // Total Score Pill
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(CricketGreenDark)
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        Text(
          text = "${innings.totalRuns}/${innings.wickets} (${innings.oversCompleted} ov)",
          color = Color.White,
          style = MaterialTheme.typography.titleSmall,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Innings Tabs
    if (match.inningsList.size > 1) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 14.dp)
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        match.inningsList.forEachIndexed { index, inn ->
          val isSelected = index == activeIndex
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (isSelected) CricketGreenPrimary else CricketCreamSurface)
              .border(
                1.dp,
                if (isSelected) CricketGreenPrimary else CricketBorder,
                RoundedCornerShape(6.dp)
              )
              .clickable { selectedInningsIndex = index }
              .padding(horizontal = 12.dp, vertical = 6.dp)
              .testTag("innings_tab_$index")
          ) {
            Text(
              text = inn.teamName,
              style = MaterialTheme.typography.labelMedium,
              color = if (isSelected) Color.White else CricketInkSecondary,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
          }
        }
      }
    }

    // Batting Section
    Text(
      text = "BATTING",
      style = MaterialTheme.typography.labelMedium,
      color = CricketInkSecondary,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(bottom = 6.dp)
    )

    // Batting Table Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(CricketScorecardHeader)
        .padding(horizontal = 8.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Batter",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        modifier = Modifier.weight(2.5f)
      )
      Text(
        text = "R",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.7f)
      )
      Text(
        text = "B",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.7f)
      )
      Text(
        text = "4s",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.6f)
      )
      Text(
        text = "6s",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.6f)
      )
      Text(
        text = "SR",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(1.0f)
      )
    }

    // Batting Entries
    innings.battingScorecard.forEachIndexed { i, batter ->
      BattingRow(batter = batter, isEven = i % 2 == 0)
    }

    // Extras & Total Rows
    HorizontalDivider(color = CricketBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = "Extras (b ${innings.extras.byes}, lb ${innings.extras.legByes}, w ${innings.extras.wides}, nb ${innings.extras.noBalls})",
        style = MaterialTheme.typography.bodySmall,
        color = CricketInkSecondary,
        fontFamily = FontFamily.Serif
      )
      Text(
        text = "${innings.extras.total}",
        style = MaterialTheme.typography.labelMedium,
        color = CricketInk,
        fontWeight = FontWeight.Bold
      )
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(CricketScorecardHeader)
        .padding(horizontal = 8.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "TOTAL (${innings.wickets} wkts, ${innings.oversCompleted} ov)",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = CricketInk
      )
      Text(
        text = "${innings.totalRuns}",
        style = MaterialTheme.typography.titleMedium,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        color = CricketGreenDark
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Bowling Section
    Text(
      text = "BOWLING",
      style = MaterialTheme.typography.labelMedium,
      color = CricketInkSecondary,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(bottom = 6.dp)
    )

    // Bowling Table Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(CricketScorecardHeader)
        .padding(horizontal = 8.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Bowler",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        modifier = Modifier.weight(2.5f)
      )
      Text(
        text = "O",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.7f)
      )
      Text(
        text = "M",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.7f)
      )
      Text(
        text = "R",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.8f)
      )
      Text(
        text = "W",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(0.7f)
      )
      Text(
        text = "Econ",
        style = MaterialTheme.typography.labelSmall,
        color = CricketInk,
        textAlign = TextAlign.End,
        modifier = Modifier.weight(1.0f)
      )
    }

    // Bowling Entries
    innings.bowlingFigures.forEachIndexed { i, bowler ->
      BowlingRow(bowler = bowler, isEven = i % 2 == 0)
    }

    // Fall of Wickets (if any)
    if (innings.fallOfWickets.isNotEmpty()) {
      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = "FALL OF WICKETS",
        style = MaterialTheme.typography.labelSmall,
        color = CricketBrassGold,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 4.dp)
      )
      val fowText = innings.fallOfWickets.joinToString(separator = ", ") { fow ->
        "${fow.score}-${fow.wicketNumber} (${fow.batterName}, ${fow.over} ov)"
      }
      Text(
        text = fowText,
        style = MaterialTheme.typography.bodySmall,
        color = CricketInkSecondary,
        fontFamily = FontFamily.Serif
      )
    }

    // Bonus Points & Match Info
    Spacer(modifier = Modifier.height(14.dp))
    HorizontalDivider(color = CricketBorder, thickness = 1.dp)
    Spacer(modifier = Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Bonus Points: Batting (${match.bonusPointsHome.batting}) • Bowling (${match.bonusPointsHome.bowling})",
        style = MaterialTheme.typography.bodySmall,
        color = CricketInkMuted,
        fontFamily = FontFamily.Serif
      )
      Text(
        text = "Wisden Verified",
        style = MaterialTheme.typography.labelSmall,
        color = CricketBrassGold,
        fontWeight = FontWeight.Bold
      )
    }
  }
}

@Composable
private fun BattingRow(batter: BattingEntry, isEven: Boolean) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(if (batter.isCurrentBatter) CricketBrassGoldContainer.copy(alpha = 0.5f) else if (isEven) Color.Transparent else CricketCreamSurface.copy(alpha = 0.4f))
      .padding(horizontal = 8.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(2.5f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = batter.batterName,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = if (batter.isNotOut) FontWeight.Bold else FontWeight.Medium,
          color = CricketInk,
          fontFamily = FontFamily.Serif
        )
        if (batter.isCurrentBatter) {
          Text(
            text = if (batter.isStriker) " *" else " ^",
            color = CricketBrassGold,
            fontWeight = FontWeight.Bold
          )
        }
      }
      Text(
        text = batter.dismissal,
        style = MaterialTheme.typography.labelSmall,
        color = CricketInkMuted,
        fontSize = 10.sp,
        maxLines = 1
      )
    }
    Text(
      text = "${batter.runs}",
      style = MaterialTheme.typography.bodyMedium,
      fontWeight = FontWeight.Bold,
      color = if (batter.runs >= 50) CricketGreenDark else CricketInk,
      textAlign = TextAlign.End,
      fontFamily = FontFamily.Serif,
      modifier = Modifier.weight(0.7f)
    )
    Text(
      text = "${batter.balls}",
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.7f)
    )
    Text(
      text = "${batter.fours}",
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.6f)
    )
    Text(
      text = "${batter.sixes}",
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.6f)
    )
    Text(
      text = String.format(Locale.UK, "%.1f", batter.strikeRate),
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(1.0f)
    )
  }
}

@Composable
private fun BowlingRow(bowler: BowlingEntry, isEven: Boolean) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(if (bowler.isCurrentBowler) CricketBrassGoldContainer.copy(alpha = 0.5f) else if (isEven) Color.Transparent else CricketCreamSurface.copy(alpha = 0.4f))
      .padding(horizontal = 8.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(
      modifier = Modifier.weight(2.5f),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = bowler.bowlerName,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = if (bowler.isCurrentBowler) FontWeight.Bold else FontWeight.Medium,
        color = CricketInk,
        fontFamily = FontFamily.Serif
      )
      if (bowler.isCurrentBowler) {
        Text(
          text = " *",
          color = CricketBrassGold,
          fontWeight = FontWeight.Bold
        )
      }
    }
    Text(
      text = String.format(Locale.UK, "%.1f", bowler.overs),
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.7f)
    )
    Text(
      text = "${bowler.maidens}",
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.7f)
    )
    Text(
      text = "${bowler.runs}",
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.8f)
    )
    Text(
      text = "${bowler.wickets}",
      style = MaterialTheme.typography.bodyMedium,
      fontWeight = FontWeight.Bold,
      color = if (bowler.wickets >= 3) CricketGreenDark else CricketInk,
      textAlign = TextAlign.End,
      fontFamily = FontFamily.Serif,
      modifier = Modifier.weight(0.7f)
    )
    Text(
      text = String.format(Locale.UK, "%.2f", bowler.economy),
      style = MaterialTheme.typography.bodySmall,
      color = CricketInkSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(1.0f)
    )
  }
}
