package com.example.ui.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.data.repository.CountyDatasets
import com.example.ui.theme.*

@Composable
fun HomeScreen(
  matches: List<Match>,
  articles: List<EditorialArticle>,
  highlights: List<HighlightItem>,
  userProfile: UserProfile,
  onSelectMatch: (String) -> Unit,
  onNavigateToMatches: () -> Unit,
  onNavigateToCounties: () -> Unit,
  onNavigateToArchive: () -> Unit,
  onSelectCounty: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val liveMatches = remember(matches) { matches.filter { it.status.isLive } }
  val spotlightCounty = remember { CountyDatasets.getCounty("yorkshire") }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(CricketCreamBackground),
    contentPadding = PaddingValues(bottom = 24.dp)
  ) {
    // 1. HERO SECTION (Wisden Tradition × English Summer Grounds)
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(300.dp)
          .testTag("home_hero_section")
      ) {
        // High resolution editorial ground image
        Image(
          painter = painterResource(id = R.drawable.county_ground_summer_1792073772750),
          contentDescription = "Historic English County Cricket Ground in Summer",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Subtle gradient overlay for editorial readability
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color(0x33000000),
                  Color(0x880A1A12),
                  Color(0xEE081610)
                )
              )
            )
        )

        // Hero Typography & CTAs
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
          verticalArrangement = Arrangement.Bottom
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 6.dp)
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(CricketBrassGold)
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                text = "COUNTY SEASON 2026",
                style = MaterialTheme.typography.labelSmall,
                color = CricketGreenDark,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Thursday, 15 October • Round 8",
              color = CricketBorder,
              style = MaterialTheme.typography.labelSmall
            )
          }

          Text(
            text = "THE COUNTY GAME. LIVE.",
            style = MaterialTheme.typography.displayMedium,
            color = Color.White,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "Follow the season across England and Wales. Watch live matches, explore the scorecards and follow your county wherever you are.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.9f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val primaryLive = liveMatches.firstOrNull()
            Button(
              onClick = {
                if (primaryLive != null) onSelectMatch(primaryLive.id)
                else onNavigateToMatches()
              },
              colors = ButtonDefaults.buttonColors(containerColor = CricketBrassGold),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("hero_watch_live_button")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CricketGreenDark, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "WATCH LIVE (${liveMatches.size})",
                color = CricketGreenDark,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelLarge
              )
            }

            OutlinedButton(
              onClick = onNavigateToMatches,
              border = BorderStroke(1.dp, Color.White),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("hero_explore_fixtures_button")
            ) {
              Text(
                text = "EXPLORE FIXTURES",
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.labelLarge
              )
            }
          }
        }
      }
    }

    // 2. LIVE NOW RAIL
    item {
      Column(modifier = Modifier.padding(top = 18.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(CricketLiveRed)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "LIVE NOW",
              style = MaterialTheme.typography.titleMedium,
              fontFamily = FontFamily.Serif,
              fontWeight = FontWeight.Bold,
              color = CricketInk
            )
          }

          Text(
            text = "View All (${liveMatches.size})",
            style = MaterialTheme.typography.labelMedium,
            color = CricketGreenPrimary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable(onClick = onNavigateToMatches)
          )
        }

        if (liveMatches.isEmpty()) {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = CricketCreamSurface)
          ) {
            Text(
              text = "No live fixtures currently in play. Next matches begin at 11:00 BST.",
              modifier = Modifier.padding(16.dp),
              color = CricketInkMuted
            )
          }
        } else {
          LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            items(liveMatches) { match ->
              LiveMatchCard(match = match, onWatchClick = { onSelectMatch(match.id) })
            }
          }
        }
      }
    }

    // 3. TODAY'S CRICKET SCHEDULE
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 18.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "TODAY'S CRICKET",
              style = MaterialTheme.typography.titleMedium,
              fontFamily = FontFamily.Serif,
              fontWeight = FontWeight.Bold,
              color = CricketInk
            )
            Text(
              text = "Complete day's play across divisions",
              style = MaterialTheme.typography.bodySmall,
              color = CricketInkMuted
            )
          }

          TextButton(onClick = onNavigateToMatches) {
            Text("Full Calendar", color = CricketGreenPrimary, fontWeight = FontWeight.Bold)
          }
        }

        matches.take(4).forEach { match ->
          FixtureRow(match = match, onClick = { onSelectMatch(match.id) })
          Spacer(modifier = Modifier.height(8.dp))
        }
      }
    }

    // 4. COUNTY SPOTLIGHT
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(
          text = "COUNTY SPOTLIGHT",
          style = MaterialTheme.typography.labelSmall,
          color = CricketBrassGold,
          letterSpacing = 1.2.sp
        )
        Text(
          text = "${spotlightCounty.name} County Cricket Club",
          style = MaterialTheme.typography.titleLarge,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold,
          color = CricketInk
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CricketBorder, RoundedCornerShape(12.dp)),
          colors = CardDefaults.cardColors(containerColor = CricketScorecardCream)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = spotlightCounty.crestSymbol, fontSize = 28.sp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = spotlightCounty.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = CricketInk
                  )
                  Text(
                    text = "${spotlightCounty.homeGround} • Est. ${spotlightCounty.establishedYear}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CricketInkSecondary
                  )
                }
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(CricketGreenDark)
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "${spotlightCounty.championshipTitles} Titles",
                  color = CricketBrassGold,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = spotlightCounty.description,
              style = MaterialTheme.typography.bodyMedium,
              color = CricketInkSecondary,
              fontFamily = FontFamily.Serif
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Button(
                onClick = { onSelectCounty(spotlightCounty.id) },
                colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text("Explore Club Page", color = Color.White)
              }
              OutlinedButton(
                onClick = onNavigateToCounties,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, CricketGreenPrimary)
              ) {
                Text("All 18 Counties", color = CricketGreenPrimary)
              }
            }
          }
        }
      }
    }

    // 5. LATEST EDITORIAL & WISDEN COLUMNS
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "LATEST CRICKET & ESSAYS",
              style = MaterialTheme.typography.titleMedium,
              fontFamily = FontFamily.Serif,
              fontWeight = FontWeight.Bold,
              color = CricketInk
            )
            Text(
              text = "Wisden analysis, match reports & ground guides",
              style = MaterialTheme.typography.bodySmall,
              color = CricketInkMuted
            )
          }

          TextButton(onClick = onNavigateToArchive) {
            Text("Archive", color = CricketGreenPrimary, fontWeight = FontWeight.Bold)
          }
        }

        articles.take(2).forEach { article ->
          EditorialCard(article = article, onClick = onNavigateToArchive)
          Spacer(modifier = Modifier.height(10.dp))
        }
      }
    }
  }
}

@Composable
fun LiveMatchCard(
  match: Match,
  onWatchClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val home = CountyDatasets.getCounty(match.homeCountyId)
  val away = CountyDatasets.getCounty(match.awayCountyId)
  val activeInnings = match.inningsList.getOrNull(match.currentInningsIndex)

  Card(
    modifier = modifier
      .width(290.dp)
      .border(1.dp, CricketBorder, RoundedCornerShape(12.dp))
      .clickable(onClick = onWatchClick)
      .testTag("live_match_card_${match.id}"),
    colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Header: Competition & Live Tag
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = match.competition.shortTitle,
          style = MaterialTheme.typography.labelSmall,
          color = CricketInkSecondary,
          fontWeight = FontWeight.SemiBold
        )

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(CricketLiveRed)
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "LIVE STREAM",
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Teams and Scores
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(text = home.crestSymbol, fontSize = 20.sp)
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = home.name,
          style = MaterialTheme.typography.titleMedium,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold,
          color = CricketInk
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(text = away.crestSymbol, fontSize = 20.sp)
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = away.name,
          style = MaterialTheme.typography.titleMedium,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold,
          color = CricketInk
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Current Score & Overs
      if (activeInnings != null) {
        Text(
          text = "${activeInnings.teamName.take(12)}: ${activeInnings.totalRuns}/${activeInnings.wickets} (${activeInnings.oversCompleted} ov)",
          style = MaterialTheme.typography.bodyMedium,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold,
          color = CricketGreenDark
        )
      }

      Text(
        text = match.statusDetail,
        style = MaterialTheme.typography.bodySmall,
        color = CricketInkMuted,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider(color = CricketBorderSubtle)
      Spacer(modifier = Modifier.height(10.dp))

      // Bottom Action: Watch Button & Commentary badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Headphones, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = "Radio Live", style = MaterialTheme.typography.labelSmall, color = CricketInkSecondary)
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CricketGreenPrimary)
            .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Watch Live", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun FixtureRow(
  match: Match,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val home = CountyDatasets.getCounty(match.homeCountyId)
  val away = CountyDatasets.getCounty(match.awayCountyId)
  val isLive = match.status.isLive

  Card(
    modifier = modifier
      .fillMaxWidth()
      .border(1.dp, CricketBorder, RoundedCornerShape(10.dp))
      .clickable(onClick = onClick)
      .testTag("fixture_row_${match.id}"),
    colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = match.competition.shortTitle,
            style = MaterialTheme.typography.labelSmall,
            color = CricketInkMuted,
            fontSize = 10.sp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "• ${match.venue}",
            style = MaterialTheme.typography.labelSmall,
            color = CricketInkMuted,
            fontSize = 10.sp,
            maxLines = 1
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "${home.name} vs ${away.name}",
          style = MaterialTheme.typography.bodyLarge,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold,
          color = CricketInk
        )

        Text(
          text = match.statusDetail,
          style = MaterialTheme.typography.bodySmall,
          color = if (isLive) CricketGreenDark else CricketInkSecondary,
          fontFamily = FontFamily.Serif,
          fontWeight = if (isLive) FontWeight.Bold else FontWeight.Normal
        )
      }

      Column(horizontalAlignment = Alignment.End) {
        if (isLive) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(CricketLiveRed)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(text = "LIVE", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
          }
        } else {
          Text(
            text = match.scheduledTimeText,
            style = MaterialTheme.typography.labelSmall,
            color = CricketInkSecondary,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (match.hasVideo) {
            Icon(Icons.Default.Videocam, contentDescription = "Video Feed", tint = CricketGreenPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
          }
          if (match.hasAudio) {
            Icon(Icons.Default.VolumeUp, contentDescription = "Radio Audio", tint = CricketBrassGold, modifier = Modifier.size(16.dp))
          }
        }
      }
    }
  }
}

@Composable
fun EditorialCard(
  article: EditorialArticle,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .border(1.dp, CricketBorder, RoundedCornerShape(10.dp))
      .clickable(onClick = onClick),
    colors = CardDefaults.cardColors(containerColor = CricketScorecardCream)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = article.category.uppercase(),
          style = MaterialTheme.typography.labelSmall,
          color = CricketBrassGold,
          letterSpacing = 1.sp
        )
        Text(
          text = "${article.readTimeMinutes} min read",
          style = MaterialTheme.typography.labelSmall,
          color = CricketInkMuted
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = article.title,
        style = MaterialTheme.typography.titleMedium,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        color = CricketInk
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = article.subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = CricketInkSecondary,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "By ${article.author}",
          style = MaterialTheme.typography.labelSmall,
          color = CricketInk,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = " • ${article.authorRole}",
          style = MaterialTheme.typography.labelSmall,
          color = CricketInkMuted
        )
      }
    }
  }
}
