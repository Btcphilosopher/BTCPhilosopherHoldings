package com.example.ui.matches

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Competition
import com.example.data.model.Match
import com.example.ui.home.FixtureRow
import com.example.ui.theme.*

@Composable
fun MatchesScreen(
  matches: List<Match>,
  onSelectMatch: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedCompetition by remember { mutableStateOf<Competition?>(null) }
  var selectedStatusFilter by remember { mutableStateOf("ALL") } // "ALL", "LIVE", "UPCOMING", "RESULTS"

  val filteredMatches = remember(matches, selectedCompetition, selectedStatusFilter) {
    matches.filter { match ->
      val compMatch = selectedCompetition == null || match.competition == selectedCompetition
      val statusMatch = when (selectedStatusFilter) {
        "LIVE" -> match.status.isLive
        "UPCOMING" -> !match.status.isLive && match.status.name == "UPCOMING"
        "RESULTS" -> match.status.name == "COMPLETED"
        else -> true
      }
      compMatch && statusMatch
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(CricketCreamBackground)
      .padding(horizontal = 14.dp)
  ) {
    Spacer(modifier = Modifier.height(12.dp))

    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "FIXTURES & CALENDAR",
          style = MaterialTheme.typography.labelSmall,
          color = CricketBrassGold,
          letterSpacing = 1.2.sp
        )
        Text(
          text = "Season Schedule 2026",
          style = MaterialTheme.typography.titleLarge,
          fontFamily = FontFamily.Serif,
          fontWeight = FontWeight.Bold,
          color = CricketInk
        )
      }

      Icon(Icons.Default.FilterList, contentDescription = "Filter", tint = CricketGreenPrimary)
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Status Filter Pills (ALL, LIVE, UPCOMING, RESULTS)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("ALL" to "All Play", "LIVE" to "Live Now", "UPCOMING" to "Upcoming", "RESULTS" to "Results").forEach { (key, label) ->
        val isSelected = selectedStatusFilter == key
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) CricketGreenPrimary else CricketCreamSurface)
            .border(1.dp, if (isSelected) CricketGreenPrimary else CricketBorder, RoundedCornerShape(6.dp))
            .clickable { selectedStatusFilter = key }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("filter_status_$key")
        ) {
          Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) Color.White else CricketInkSecondary,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Competition horizontal scroll filter
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      // "All Competitions" Chip
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(16.dp))
          .background(if (selectedCompetition == null) CricketBrassGold else CricketCreamSurface)
          .border(0.5.dp, CricketBorder, RoundedCornerShape(16.dp))
          .clickable { selectedCompetition = null }
          .padding(horizontal = 10.dp, vertical = 5.dp)
      ) {
        Text(
          text = "All Competitions",
          style = MaterialTheme.typography.labelSmall,
          color = if (selectedCompetition == null) CricketGreenDark else CricketInk,
          fontWeight = FontWeight.Bold
        )
      }

      Competition.entries.forEach { comp ->
        val isSelected = selectedCompetition == comp
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) CricketBrassGold else CricketCreamSurface)
            .border(0.5.dp, CricketBorder, RoundedCornerShape(16.dp))
            .clickable { selectedCompetition = comp }
            .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
          Text(
            text = comp.shortTitle,
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) CricketGreenDark else CricketInkSecondary,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Matches List
    if (filteredMatches.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(40.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No fixtures found for selected filter.",
          color = CricketInkMuted,
          fontFamily = FontFamily.Serif
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(filteredMatches) { match ->
          FixtureRow(match = match, onClick = { onSelectMatch(match.id) })
        }
      }
    }
  }
}
