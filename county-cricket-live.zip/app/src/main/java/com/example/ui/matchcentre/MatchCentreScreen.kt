package com.example.ui.matchcentre

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.CountyDatasets
import com.example.ui.components.MultiviewCompanionPane
import com.example.ui.components.ScorecardView
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.*

enum class MatchCentreTab(val label: String) {
  WATCH("Watch"),
  SCORECARD("Scorecard"),
  BALL_BY_BALL("Ball by Ball"),
  COMMENTARY("Commentary"),
  STATISTICS("Statistics"),
  TEAMS("Teams & Ground"),
  HIGHLIGHTS("Highlights"),
}

@Composable
fun MatchCentreScreen(
  match: Match,
  stream: VideoStream?,
  secondaryStream: VideoStream?,
  secondaryMatch: Match?,
  streamState: StreamState,
  ballEvents: List<BallEvent>,
  highlights: List<HighlightItem>,
  isMultiviewActive: Boolean,
  onBack: () -> Unit,
  onQualityChange: (PlaybackQuality) -> Unit,
  onToggleLowBandwidth: (Boolean) -> Unit,
  onAdjustAudioSync: (Long) -> Unit,
  onSimulateDrop: () -> Unit,
  onToggleMultiview: () -> Unit,
  onSwapMultiview: () -> Unit,
  onStepBall: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedTab by remember { mutableStateOf(MatchCentreTab.WATCH) }

  val home = CountyDatasets.getCounty(match.homeCountyId)
  val away = CountyDatasets.getCounty(match.awayCountyId)

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(CricketCreamBackground)
  ) {
    // Top Bar with Back Button, Title & Simulated Ticker Stepper
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(CricketCreamSurface)
        .border(0.5.dp, CricketBorder)
        .padding(horizontal = 8.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.testTag("match_centre_back_button")
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = CricketInk)
        }
        Column {
          Text(
            text = "${home.shortName} vs ${away.shortName}",
            style = MaterialTheme.typography.titleMedium,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = CricketInk
          )
          Text(
            text = "${match.competition.shortTitle} • ${match.venue}",
            style = MaterialTheme.typography.labelSmall,
            color = CricketInkMuted
          )
        }
      }

      // Live Step Demo Button (allows user to bowl a ball on demand!)
      if (match.status.isLive) {
        Button(
          onClick = onStepBall,
          colors = ButtonDefaults.buttonColors(containerColor = CricketBrassGold),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.testTag("bowl_next_ball_button")
        ) {
          Icon(Icons.Default.SportsCricket, contentDescription = null, tint = CricketGreenDark, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Bowl Ball",
            color = CricketGreenDark,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
          )
        }
      }
    }

    // Format-Adaptive Match Header Card
    FormatHeaderCard(match = match, home = home, away = away)

    // Navigation Tabs (Watch, Scorecard, Ball by Ball, Commentary, Statistics, Teams, Highlights)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(CricketCreamBackground)
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      MatchCentreTab.entries.forEach { tab ->
        val isSelected = tab == selectedTab
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CricketGreenPrimary else CricketCreamSurface)
            .border(1.dp, if (isSelected) CricketGreenPrimary else CricketBorder, RoundedCornerShape(8.dp))
            .clickable { selectedTab = tab }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("tab_${tab.name.lowercase()}")
        ) {
          Text(
            text = tab.label,
            style = MaterialTheme.typography.labelMedium,
            color = if (isSelected) Color.White else CricketInkSecondary,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }

    // Tab Content Area
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 12.dp)
    ) {
      when (selectedTab) {
        MatchCentreTab.WATCH -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            // Live Video Player
            item {
              VideoPlayerView(
                match = match,
                stream = stream,
                streamState = streamState,
                onQualityChange = onQualityChange,
                onToggleLowBandwidth = onToggleLowBandwidth,
                onAdjustAudioSync = onAdjustAudioSync,
                onSimulateDrop = onSimulateDrop,
                onToggleMultiview = onToggleMultiview,
                isMultiviewActive = isMultiviewActive
              )
            }

            // Multiview Secondary Stream if activated
            if (isMultiviewActive && secondaryMatch != null) {
              item {
                MultiviewCompanionPane(
                  secondaryMatch = secondaryMatch,
                  secondaryStream = secondaryStream,
                  onSwapStreams = onSwapMultiview,
                  onCloseMultiview = onToggleMultiview
                )
              }
            }

            // Quick In-Play Scorecard Preview underneath video
            item {
              ScorecardView(match = match)
            }
          }
        }

        MatchCentreTab.SCORECARD -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
          ) {
            item {
              ScorecardView(match = match)
            }
          }
        }

        MatchCentreTab.BALL_BY_BALL -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            item {
              Text(
                text = "LIVE BALL-BY-BALL COMMENTARY",
                style = MaterialTheme.typography.labelSmall,
                color = CricketBrassGold,
                letterSpacing = 1.2.sp,
                modifier = Modifier.padding(vertical = 4.dp)
              )
            }

            items(ballEvents) { event ->
              BallEventCard(event = event)
            }
          }
        }

        MatchCentreTab.COMMENTARY -> {
          CommentaryView(match = match, stream = stream, onAdjustAudioSync = onAdjustAudioSync)
        }

        MatchCentreTab.STATISTICS -> {
          MatchStatisticsView(match = match)
        }

        MatchCentreTab.TEAMS -> {
          TeamsAndGroundView(match = match, home = home, away = away)
        }

        MatchCentreTab.HIGHLIGHTS -> {
          MatchHighlightsView(match = match, highlights = highlights)
        }
      }
    }
  }
}

@Composable
private fun FormatHeaderCard(
  match: Match,
  home: County,
  away: County,
) {
  val isFirstClass = match.competition.format == MatchFormat.FIRST_CLASS
  val isT20 = match.competition.format == MatchFormat.T20

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 12.dp, vertical = 6.dp)
      .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
    colors = CardDefaults.cardColors(containerColor = CricketScorecardCream)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Status detail badge
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (match.status.isLive) {
            Box(
              modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(CricketLiveRed)
            )
            Spacer(modifier = Modifier.width(6.dp))
          }
          Text(
            text = match.statusDetail,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
        }

        // Format pill
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(CricketGreenContainer)
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = if (isFirstClass) "Day ${match.dayNumber} • 4-Day" else if (isT20) "T20 Blast" else "50 Overs",
            style = MaterialTheme.typography.labelSmall,
            color = CricketOnGreenContainer,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Toss details
      if (match.tossText.isNotEmpty()) {
        Text(
          text = "Toss: ${match.tossText}",
          style = MaterialTheme.typography.bodySmall,
          color = CricketInkMuted,
          fontFamily = FontFamily.Serif
        )
      }

      // T20 Blast Target & Chase Progress
      if (isT20 && match.targetRuns != null) {
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(CricketGreenDark, RoundedCornerShape(6.dp))
            .padding(8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Target: ${match.targetRuns} runs",
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Req RR: ${match.requiredRunRate ?: 9.5}",
            color = CricketBrassGold,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}

@Composable
private fun BallEventCard(event: BallEvent) {
  val badgeBg = when {
    event.isWicket -> CricketLiveRed
    event.isBoundarySix -> CricketBrassGold
    event.isBoundaryFour -> CricketGreenPrimary
    else -> CricketScorecardHeader
  }

  val badgeTextColor = when {
    event.isWicket -> Color.White
    event.isBoundarySix -> CricketGreenDark
    event.isBoundaryFour -> Color.White
    else -> CricketInk
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .border(0.5.dp, CricketBorder, RoundedCornerShape(8.dp)),
    colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(10.dp),
      verticalAlignment = Alignment.Top
    ) {
      // Over and outcome badge
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(46.dp)
      ) {
        Text(
          text = event.ballNumber,
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = CricketInkSecondary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
          modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(badgeBg),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = if (event.isWicket) "W" else if (event.runsScored == 0) "•" else "${event.runsScored}",
            color = badgeTextColor,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelMedium
          )
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "${event.bowlerName} to ${event.batterName}",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketInk
          )
          Text(
            text = event.timestampText,
            style = MaterialTheme.typography.labelSmall,
            color = CricketInkMuted,
            fontSize = 10.sp
          )
        }

        Spacer(modifier = Modifier.height(3.dp))

        Text(
          text = event.commentary,
          style = MaterialTheme.typography.bodySmall,
          color = CricketInkSecondary,
          fontFamily = FontFamily.Serif
        )
      }
    }
  }
}

@Composable
private fun CommentaryView(
  match: Match,
  stream: VideoStream?,
  onAdjustAudioSync: (Long) -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, CricketBrassGold, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = CricketGreenDark)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Radio, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = stream?.radioStationName ?: "BBC Radio Leeds & TMS Live",
                color = Color.White,
                style = MaterialTheme.typography.titleSmall,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
              )
            }
            Text(text = "LIVE AUDIO", color = CricketBrassGold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Commentators: Jonathan Agnew, Michael Vaughan and Kevin Howells bringing you comprehensive radio coverage from the Headingley media box.",
            color = CricketBorder,
            style = MaterialTheme.typography.bodySmall
          )
        }
      }
    }

    item {
      Text(
        text = "Wisden Live Commentary Transcript",
        style = MaterialTheme.typography.titleMedium,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        color = CricketInk
      )
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(0.5.dp, CricketBorder, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = CricketScorecardCream)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "\"The light is holding up splendidly here in Leeds. Joe Root looks in serene touch, playing within himself and punching the ball off the back foot with that accustomed Yorkshire assurance. Anderson has changed his field to a 7-2 legside ring to stifle the boundary flow.\"",
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Serif,
            color = CricketInk
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = "— Jonathan Agnew, BBC TMS", style = MaterialTheme.typography.labelSmall, color = CricketBrassGold, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun MatchStatisticsView(match: Match) {
  val home = CountyDatasets.getCounty(match.homeCountyId)
  val away = CountyDatasets.getCounty(match.awayCountyId)

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Text(
        text = "MATCH METRICS & PARTNERSHIPS",
        style = MaterialTheme.typography.labelSmall,
        color = CricketBrassGold,
        letterSpacing = 1.2.sp
      )
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "Boundary Summary", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = CricketInk)
          Spacer(modifier = Modifier.height(10.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${home.name} Fours / Sixes", style = MaterialTheme.typography.bodyMedium, color = CricketInkSecondary)
            Text("38 Fours • 4 Sixes", fontWeight = FontWeight.Bold, color = CricketGreenDark)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${away.name} Fours / Sixes", style = MaterialTheme.typography.bodyMedium, color = CricketInkSecondary)
            Text("26 Fours • 2 Sixes", fontWeight = FontWeight.Bold, color = CricketInk)
          }
        }
      }
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "Run Rate Progression", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = CricketInk)
          Spacer(modifier = Modifier.height(8.dp))
          Text("Innings 1 (Yorkshire): 3.39 RPO", style = MaterialTheme.typography.bodySmall, color = CricketInkSecondary)
          Text("Innings 2 (Lancashire): 3.23 RPO", style = MaterialTheme.typography.bodySmall, color = CricketInkSecondary)
          Text("Innings 3 (Yorkshire): 3.28 RPO", style = MaterialTheme.typography.bodySmall, color = CricketGreenDark, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun TeamsAndGroundView(
  match: Match,
  home: County,
  away: County,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = CricketScorecardCream)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "VENUE & CONDITIONS", style = MaterialTheme.typography.labelSmall, color = CricketBrassGold, letterSpacing = 1.sp)
          Text(text = match.venue, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = CricketInk)
          Spacer(modifier = Modifier.height(6.dp))
          Text(text = "Capacity: 18,350 • Kirkstall Lane End & Football Stand End", style = MaterialTheme.typography.bodySmall, color = CricketInkSecondary)
          Text(text = "Pitch: Green tinge on Day 1, flattening out nicely with true bounce on Days 2 and 3.", style = MaterialTheme.typography.bodySmall, color = CricketInkSecondary)
          Text(text = "Umpires: Michael Gough & Ian Gould", style = MaterialTheme.typography.bodySmall, color = CricketInkMuted)
        }
      }
    }

    item {
      Text(text = "${home.name} XI", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = CricketInk)
    }

    items(home.squad) { player ->
      PlayerRowCard(player = player)
    }

    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(text = "${away.name} XI", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = CricketInk)
    }

    items(away.squad) { player ->
      PlayerRowCard(player = player)
    }
  }
}

@Composable
private fun PlayerRowCard(player: Player) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .border(0.5.dp, CricketBorder, RoundedCornerShape(6.dp)),
    colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text = "#${player.squadNumber}", style = MaterialTheme.typography.labelSmall, color = CricketBrassGold, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
        Column {
          Text(text = player.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CricketInk, fontFamily = FontFamily.Serif)
          Text(text = player.role.name.replace("_", " "), style = MaterialTheme.typography.labelSmall, color = CricketInkMuted, fontSize = 10.sp)
        }
      }
      Text(text = player.battingStyle, style = MaterialTheme.typography.bodySmall, color = CricketInkSecondary)
    }
  }
}

@Composable
private fun MatchHighlightsView(
  match: Match,
  highlights: List<HighlightItem>,
) {
  val matchHighlights = remember(highlights) { highlights.filter { it.countyId == match.homeCountyId || it.countyId == match.awayCountyId } }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Text(
        text = "MATCH RECAPS & REELS",
        style = MaterialTheme.typography.labelSmall,
        color = CricketBrassGold,
        letterSpacing = 1.2.sp
      )
    }

    if (matchHighlights.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = CricketCreamSurface)
        ) {
          Text(
            text = "Highlights will be published at the close of play.",
            modifier = Modifier.padding(16.dp),
            color = CricketInkMuted
          )
        }
      }
    } else {
      items(matchHighlights) { hl ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CricketBorder, RoundedCornerShape(8.dp)),
          colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(CricketGreenDark),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(28.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = hl.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CricketInk, fontFamily = FontFamily.Serif)
              Text(text = "${hl.durationText} • ${hl.viewsCount} views", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted)
            }
          }
        }
      }
    }
  }
}
