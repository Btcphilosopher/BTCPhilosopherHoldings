package com.example.ui.counties

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.County
import com.example.data.repository.CountyDatasets
import com.example.ui.theme.*

@Composable
fun CountiesScreen(
  selectedCountyId: String?,
  onSelectCounty: (String) -> Unit,
  onClearCountySelection: () -> Unit,
  onNavigateToPortal: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val counties = remember { CountyDatasets.allCounties }
  val activeCounty = remember(selectedCountyId) { counties.firstOrNull { it.id == selectedCountyId } }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(CricketCreamBackground)
      .padding(horizontal = 14.dp)
  ) {
    if (activeCounty != null) {
      // County Detail View
      CountyDetailView(
        county = activeCounty,
        onBack = onClearCountySelection,
        onOpenPortal = { onNavigateToPortal(activeCounty.id) }
      )
    } else {
      // County Directory Grid/List
      Spacer(modifier = Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "THE 18 PROFESSIONAL COUNTIES",
            style = MaterialTheme.typography.labelSmall,
            color = CricketBrassGold,
            letterSpacing = 1.2.sp
          )
          Text(
            text = "First-Class County Clubs",
            style = MaterialTheme.typography.titleLarge,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = CricketInk
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CricketGreenContainer)
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "18 Clubs",
            color = CricketGreenDark,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(counties) { county ->
          CountyRowCard(
            county = county,
            onClick = { onSelectCounty(county.id) }
          )
        }
      }
    }
  }
}

@Composable
fun CountyRowCard(
  county: County,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .border(1.dp, CricketBorder, RoundedCornerShape(10.dp))
      .clickable(onClick = onClick)
      .testTag("county_card_${county.id}"),
    colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        // Crest / Symbol in authentic primary colour badge
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(county.primaryColor),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = county.crestSymbol,
            fontSize = 22.sp
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = county.name,
              style = MaterialTheme.typography.titleMedium,
              fontFamily = FontFamily.Serif,
              fontWeight = FontWeight.Bold,
              color = CricketInk
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "(${county.shortName})",
              style = MaterialTheme.typography.labelSmall,
              color = CricketInkMuted
            )
          }

          Text(
            text = "${county.homeGround} • ${county.city}",
            style = MaterialTheme.typography.bodySmall,
            color = CricketInkSecondary,
            maxLines = 1
          )

          Text(
            text = "${county.championshipTitles} Championship Titles • ${county.blastTitles} Blast",
            style = MaterialTheme.typography.labelSmall,
            color = CricketBrassGold,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp
          )
        }
      }

      Icon(Icons.Default.ChevronRight, contentDescription = "View Club", tint = CricketInkMuted)
    }
  }
}

@Composable
fun CountyDetailView(
  county: County,
  onBack: () -> Unit,
  onOpenPortal: () -> Unit,
  modifier: Modifier = Modifier,
) {
  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Back navigation header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = CricketInk)
          }
          Text(
            text = "Back to Counties",
            style = MaterialTheme.typography.labelMedium,
            color = CricketInkSecondary
          )
        }

        // Broadcaster Portal Shortcut for this club
        Button(
          onClick = onOpenPortal,
          colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier.testTag("manage_in_club_portal_button")
        ) {
          Icon(Icons.Default.Podcasts, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = "Club Portal", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
      }
    }

    // Hero County Banner
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, CricketBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = county.primaryColor)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "ESTABLISHED ${county.establishedYear}",
                style = MaterialTheme.typography.labelSmall,
                color = CricketBrassGold,
                letterSpacing = 1.2.sp
              )
              Text(
                text = "${county.name} CCC",
                style = MaterialTheme.typography.displayMedium,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "\"${county.nickname}\"",
                style = MaterialTheme.typography.titleSmall,
                color = Color.White.copy(alpha = 0.85f),
                fontFamily = FontFamily.Serif
              )
            }

            Text(text = county.crestSymbol, fontSize = 48.sp)
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0x33FFFFFF))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "${county.championshipTitles} County Titles",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
              )
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0x33FFFFFF))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "${county.blastTitles} T20 Blast Titles",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // Club Description & Ground
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = CricketScorecardCream)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "HERITAGE & HOME GROUND",
            style = MaterialTheme.typography.labelSmall,
            color = CricketBrassGold,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = county.description,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Serif,
            color = CricketInk
          )
          Spacer(modifier = Modifier.height(10.dp))
          HorizontalDivider(color = CricketBorder)
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = "Home Ground", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted)
              Text(text = county.homeGround, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CricketInk)
            }
            Column {
              Text(text = "Captain", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted)
              Text(text = county.captain, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CricketInk)
            }
            Column {
              Text(text = "Head Coach", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted)
              Text(text = county.headCoach, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CricketInk)
            }
          }
        }
      }
    }

    // Squad Roster
    item {
      Text(
        text = "FIRST-TEAM SQUAD",
        style = MaterialTheme.typography.titleMedium,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        color = CricketInk
      )
    }

    items(county.squad) { player ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(0.5.dp, CricketBorder, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(CricketGreenContainer),
              contentAlignment = Alignment.Center
            ) {
              Text(text = "${player.squadNumber}", color = CricketGreenDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = player.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CricketInk, fontFamily = FontFamily.Serif)
                if (player.isCaptain) {
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(text = "(c)", color = CricketBrassGold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
              }
              Text(text = "${player.role.name.replace("_", " ")} • ${player.battingStyle}", style = MaterialTheme.typography.bodySmall, color = CricketInkMuted)
            }
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(text = "${player.totalRuns} runs", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CricketInk)
            if (player.wickets > 0) {
              Text(text = "${player.wickets} wkts", style = MaterialTheme.typography.labelSmall, color = CricketGreenDark)
            }
          }
        }
      }
    }
  }
}
