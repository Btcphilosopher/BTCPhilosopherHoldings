package com.example.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.County
import com.example.data.model.Match
import com.example.data.repository.CountyDatasets
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchDialog(
  matches: List<Match>,
  onSelectMatch: (String) -> Unit,
  onSelectCounty: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  var searchQuery by remember { mutableStateOf("") }
  val allCounties = remember { CountyDatasets.allCounties }

  val matchingCounties = remember(searchQuery) {
    if (searchQuery.isBlank()) emptyList()
    else allCounties.filter {
      it.name.contains(searchQuery, ignoreCase = true) ||
          it.homeGround.contains(searchQuery, ignoreCase = true) ||
          it.city.contains(searchQuery, ignoreCase = true)
    }
  }

  val matchingPlayers = remember(searchQuery) {
    if (searchQuery.isBlank()) emptyList()
    else allCounties.flatMap { c -> c.squad.map { p -> p to c } }.filter { (p, _) ->
      p.name.contains(searchQuery, ignoreCase = true)
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Global Cricket Search", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 450.dp)
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search county, player, ground...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CricketGreenPrimary) },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_input_field")
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (searchQuery.isBlank()) {
          Text(
            text = "Popular searches: Root, Headingley, Surrey, The Oval, Anderson, T20 Blast",
            style = MaterialTheme.typography.bodySmall,
            color = CricketInkMuted,
            fontFamily = FontFamily.Serif
          )
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            if (matchingCounties.isNotEmpty()) {
              item {
                Text(
                  text = "COUNTIES (${matchingCounties.size})",
                  style = MaterialTheme.typography.labelSmall,
                  color = CricketBrassGold,
                  fontWeight = FontWeight.Bold
                )
              }
              items(matchingCounties) { county ->
                Card(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onSelectCounty(county.id)
                      onDismiss()
                    },
                  colors = CardDefaults.cardColors(containerColor = CricketCreamSurface)
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(text = county.crestSymbol, fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                      Text(text = county.name, fontWeight = FontWeight.Bold, color = CricketInk)
                      Text(text = county.homeGround, style = MaterialTheme.typography.bodySmall, color = CricketInkMuted)
                    }
                  }
                }
              }
            }

            if (matchingPlayers.isNotEmpty()) {
              item {
                Text(
                  text = "PLAYERS (${matchingPlayers.size})",
                  style = MaterialTheme.typography.labelSmall,
                  color = CricketBrassGold,
                  fontWeight = FontWeight.Bold
                )
              }
              items(matchingPlayers.take(6)) { (player, county) ->
                Card(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      onSelectCounty(county.id)
                      onDismiss()
                    },
                  colors = CardDefaults.cardColors(containerColor = CricketCreamSurface)
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text(text = player.name, fontWeight = FontWeight.Bold, color = CricketInk)
                      Text(text = "${county.name} • ${player.role.name.replace("_", " ")}", style = MaterialTheme.typography.bodySmall, color = CricketInkMuted)
                    }
                    Text(text = "#${player.squadNumber}", style = MaterialTheme.typography.labelSmall, color = CricketBrassGold)
                  }
                }
              }
            }

            if (matchingCounties.isEmpty() && matchingPlayers.isEmpty()) {
              item {
                Text("No results for \"$searchQuery\"", color = CricketInkMuted, modifier = Modifier.padding(16.dp))
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Done", color = CricketGreenPrimary) }
    }
  )
}
