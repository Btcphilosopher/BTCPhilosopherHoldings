package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// British County Cricket Live Palette
// Deep Cricket Green, Ivory, Scorecard Cream, Brass Gold & Dark Ink

val CricketGreenDark = Color(0xFF0F261D)
val CricketGreenPrimary = Color(0xFF1B3D2F)
val CricketGreenMedium = Color(0xFF265240)
val CricketGreenLight = Color(0xFF3B6B55)
val CricketGreenContainer = Color(0xFFE4EDE7)
val CricketOnGreenContainer = Color(0xFF0C241B)

val CricketCreamBackground = Color(0xFFF9F7F2)
val CricketCreamSurface = Color(0xFFF3EFE7)
val CricketCreamCard = Color(0xFFFFFFFF)
val CricketScorecardCream = Color(0xFFFAF6EB)
val CricketScorecardHeader = Color(0xFFEFE7D5)

val CricketBrassGold = Color(0xFFC5A059)
val CricketBrassGoldBright = Color(0xFFD4AF37)
val CricketBrassGoldContainer = Color(0xFFF7F1DF)
val CricketOnBrassGold = Color(0xFF332504)

val CricketInk = Color(0xFF141A17)
val CricketInkSecondary = Color(0xFF4A554E)
val CricketInkMuted = Color(0xFF75827A)

val CricketBorder = Color(0xFFDDD7C8)
val CricketBorderSubtle = Color(0xFFEAE5D9)

val CricketLiveRed = Color(0xFFBA1A1A)
val CricketLiveRedContainer = Color(0xFFFFDAD6)
val CricketOnLiveRed = Color(0xFFFFFFFF)

// Authenticated County Colors
val DerbyshireBrown = Color(0xFF4A2511)
val DerbyshireAmber = Color(0xFFE59328)

val DurhamNavy = Color(0xFF0D2543)
val DurhamGold = Color(0xFFDBA425)

val EssexCrimson = Color(0xFF861B28)
val EssexNavy = Color(0xFF132746)

val GlamorganNavy = Color(0xFF0E223D)
val GlamorganDaffodil = Color(0xFFEFA91F)

val GlosBlue = Color(0xFF0B1F44)
val GlosYellow = Color(0xFFE6B800)

val HampshireMidnight = Color(0xFF0B1C33)
val HampshireGold = Color(0xFFC79F3E)

val KentCherry = Color(0xFF891624)
val KentNavy = Color(0xFF0E203B)

val LancashireRedRose = Color(0xFF9E1B32)
val LancashireWhite = Color(0xFFFFFFFF)

val LeicestershireGreen = Color(0xFF0B4329)
val LeicestershireRed = Color(0xFFBE2525)

val MiddlesexPink = Color(0xFFD84A78)
val MiddlesexNavy = Color(0xFF0D1B36)

val NorthantsClaret = Color(0xFF6B1B29)
val NorthantsGold = Color(0xFFD19A3B)

val NottsGreen = Color(0xFF16472D)
val NottsGold = Color(0xFFD3A834)

val SomersetMaroon = Color(0xFF5B1626)
val SomersetBlack = Color(0xFF1C1A1B)

val SurreyChocolate = Color(0xFF472818)
val SurreyDuckEgg = Color(0xFF7EAEC7)

val SussexBlue = Color(0xFF1A4380)
val SussexGold = Color(0xFFDFAB26)

val WarksNavy = Color(0xFF0D1D3A)
val WarksYellow = Color(0xFFD49E25)

val WorcsGreen = Color(0xFF1A4F2F)
val WorcsGold = Color(0xFFD5AF37)

val YorksNavy = Color(0xFF122B4D)
val YorksLightBlue = Color(0xFF75A1CC)
