package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.CountyDatasets
import com.example.ui.theme.*

@Composable
fun VideoPlayerView(
  match: Match,
  stream: VideoStream?,
  streamState: StreamState,
  onQualityChange: (PlaybackQuality) -> Unit,
  onToggleLowBandwidth: (Boolean) -> Unit,
  onAdjustAudioSync: (Long) -> Unit,
  onSimulateDrop: () -> Unit,
  onToggleMultiview: () -> Unit,
  isMultiviewActive: Boolean,
  modifier: Modifier = Modifier,
) {
  var isControlsVisible by remember { mutableStateOf(true) }
  var isPlaying by remember { mutableStateOf(true) }
  var selectedCamera by remember { mutableStateOf("Pavilion Cam 1") }
  var showQualityDialog by remember { mutableStateOf(false) }
  var showSyncDialog by remember { mutableStateOf(false) }

  val homeCounty = CountyDatasets.getCounty(match.homeCountyId)
  val awayCounty = CountyDatasets.getCounty(match.awayCountyId)

  // Animation values for simulated live cricket broadcast
  val infiniteTransition = rememberInfiniteTransition(label = "cricketAction")
  val ballProgress by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 3200, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "ballFly"
  )

  val pulseLiveAlpha by infiniteTransition.animateFloat(
    initialValue = 0.3f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseLive"
  )

  Box(
    modifier = modifier
      .fillMaxWidth()
      .aspectRatio(16f / 9f)
      .clip(RoundedCornerShape(12.dp))
      .background(Color.Black)
      .border(1.dp, CricketBorder, RoundedCornerShape(12.dp))
      .clickable { isControlsVisible = !isControlsVisible }
      .testTag("video_player_container")
  ) {

    // Main Live Broadcast Canvas
    when (streamState) {
      StreamState.CONNECTING -> {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = CricketBrassGold, strokeWidth = 3.dp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "Connecting to ${homeCounty.name} Ground Feed...",
              color = Color.White,
              style = MaterialTheme.typography.bodyMedium,
              fontFamily = FontFamily.Serif
            )
            Text(
              text = "Verifying regional rights & CDN playback token",
              color = CricketBrassGold,
              style = MaterialTheme.typography.labelSmall
            )
          }
        }
      }

      StreamState.RECONNECTING -> {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = CricketLiveRed, strokeWidth = 3.dp)
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "Signal Jitter — Reconnecting to Ingest...",
              color = Color.White,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Switching to backup stream (Headingley Cam 2)",
              color = CricketBorder,
              style = MaterialTheme.typography.bodySmall
            )
          }
        }
      }

      StreamState.ERROR, StreamState.UNAVAILABLE -> {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = CricketLiveRed, modifier = Modifier.size(42.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Stream Unavailable in Selected Territory",
              color = Color.White,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Authorised match pass or domestic license required",
              color = CricketBorder,
              style = MaterialTheme.typography.bodySmall
            )
          }
        }
      }

      StreamState.PLAYING, StreamState.AVAILABLE, StreamState.ENDED -> {
        if (stream?.quality == PlaybackQuality.LOW_BANDWIDTH) {
          // Low-Bandwidth Audio Mode Visualizer
          AudioModeVisualizer(match = match, stream = stream)
        } else {
          // Full Realistic Cricket Canvas Broadcast
          Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Outfield Emerald Grass with Mowing Strip Pattern
            val stripeCount = 14
            val stripeWidth = width / stripeCount
            for (i in 0 until stripeCount) {
              val stripeColor = if (i % 2 == 0) Color(0xFF1B4D2E) else Color(0xFF225E39)
              drawRect(
                color = stripeColor,
                topLeft = Offset(i * stripeWidth, 0f),
                size = Size(stripeWidth, height)
              )
            }

            // Oval Boundary Chalk Line
            drawOval(
              color = Color(0x66FFFFFF),
              topLeft = Offset(width * 0.04f, height * 0.05f),
              size = Size(width * 0.92f, height * 0.90f),
              style = Stroke(width = 2.5f)
            )

            // Centre Pitch Strip (Warm Clay / Straw Yellow)
            val pitchLeft = width * 0.38f
            val pitchWidth = width * 0.24f
            val pitchTop = height * 0.18f
            val pitchHeight = height * 0.64f

            drawRect(
              color = Color(0xFFC7B382),
              topLeft = Offset(pitchLeft, pitchTop),
              size = Size(pitchWidth, pitchHeight)
            )

            // Crease lines (Popping crease & bowling crease)
            // Batting Crease (Bottom)
            drawLine(
              color = Color.White,
              start = Offset(pitchLeft - 10f, pitchTop + pitchHeight * 0.85f),
              end = Offset(pitchLeft + pitchWidth + 10f, pitchTop + pitchHeight * 0.85f),
              strokeWidth = 3f
            )
            // Bowling Crease (Top)
            drawLine(
              color = Color.White,
              start = Offset(pitchLeft - 10f, pitchTop + pitchHeight * 0.15f),
              end = Offset(pitchLeft + pitchWidth + 10f, pitchTop + pitchHeight * 0.15f),
              strokeWidth = 3f
            )

            // Stumps at both ends (Wooden Stumps + Bails)
            val stumpWidth = 12f
            // Top stumps
            drawRect(
              color = Color(0xFF533118),
              topLeft = Offset(pitchLeft + (pitchWidth - stumpWidth) / 2, pitchTop + pitchHeight * 0.12f),
              size = Size(stumpWidth, 8f)
            )
            // Bottom stumps
            drawRect(
              color = Color(0xFF533118),
              topLeft = Offset(pitchLeft + (pitchWidth - stumpWidth) / 2, pitchTop + pitchHeight * 0.86f),
              size = Size(stumpWidth, 8f)
            )

            // Animated Cricket Action: Bowler releasing & Ball trajectory
            val ballStartY = pitchTop + pitchHeight * 0.18f
            val ballEndY = pitchTop + pitchHeight * 0.82f
            val ballBounceY = pitchTop + pitchHeight * 0.64f

            val currentBallY: Float
            val currentBallX: Float
            if (ballProgress < 0.65f) {
              // Ball trajectory towards batsman
              val t = ballProgress / 0.65f
              currentBallY = ballStartY + (ballEndY - ballStartY) * t
              currentBallX = pitchLeft + pitchWidth * (0.48f + 0.08f * t)
            } else {
              // Off the bat: cover drive towards boundary!
              val t = (ballProgress - 0.65f) / 0.35f
              currentBallX = (pitchLeft + pitchWidth * 0.56f) + (width * 0.38f) * t
              currentBallY = ballEndY - (height * 0.45f) * t
            }

            // Draw Red Leather Cricket Ball
            drawCircle(
              color = Color(0xFFB71C1C),
              radius = 5.5f,
              center = Offset(currentBallX, currentBallY)
            )
            // Ball white seam
            drawCircle(
              color = Color.White,
              radius = 1.5f,
              center = Offset(currentBallX, currentBallY)
            )

            // Batsman and Bowler silhouettes
            // Bowler follow-through (Top)
            drawCircle(
              color = Color(0xFFECEFF1),
              radius = 9f,
              center = Offset(pitchLeft + pitchWidth * 0.45f, pitchTop + pitchHeight * 0.10f)
            )
            // Batsman stance (Bottom)
            drawCircle(
              color = Color(0xFFFFFFFF),
              radius = 11f,
              center = Offset(pitchLeft + pitchWidth * 0.54f, pitchTop + pitchHeight * 0.88f)
            )
            // Bat blade
            drawLine(
              color = Color(0xFFD4AF37),
              start = Offset(pitchLeft + pitchWidth * 0.54f, pitchTop + pitchHeight * 0.88f),
              end = Offset(pitchLeft + pitchWidth * 0.66f, pitchTop + pitchHeight * 0.84f),
              strokeWidth = 4f
            )

            // Wicketkeeper & Slip Cordon Silhouettes
            drawCircle(color = Color(0xEEFFFFFF), radius = 8f, center = Offset(pitchLeft + pitchWidth * 0.52f, pitchTop + pitchHeight * 0.96f))
            drawCircle(color = Color(0xEEFFFFFF), radius = 8f, center = Offset(pitchLeft + pitchWidth * 0.68f, pitchTop + pitchHeight * 0.98f))
            drawCircle(color = Color(0xEEFFFFFF), radius = 8f, center = Offset(pitchLeft + pitchWidth * 0.82f, pitchTop + pitchHeight * 0.99f))
          }
        }
      }
    }

    // Top Broadcast Header Overlay
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // LIVE PULSE BADGE & Feed Source
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(CricketLiveRed.copy(alpha = pulseLiveAlpha))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(Color.White)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = "LIVE",
              color = Color.White,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0x99000000))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = stream?.providerType?.label?.take(22) ?: "Club Stream",
            color = Color.White,
            style = MaterialTheme.typography.labelSmall
          )
        }
      }

      // Camera Switcher & Multiview Button
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Multi-view Toggle
        IconButton(
          onClick = onToggleMultiview,
          modifier = Modifier
            .size(34.dp)
            .background(if (isMultiviewActive) CricketBrassGold else Color(0x99000000), RoundedCornerShape(6.dp))
            .testTag("multiview_button")
        ) {
          Icon(
            Icons.Default.Dashboard,
            contentDescription = "Multi-match Viewing",
            tint = if (isMultiviewActive) CricketGreenDark else Color.White,
            modifier = Modifier.size(18.dp)
          )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Camera Angle Selector Pill
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0x99000000))
            .clickable {
              selectedCamera = when (selectedCamera) {
                "Pavilion Cam 1" -> "Bowler Arm Cam"
                "Bowler Arm Cam" -> "Stump Cam"
                else -> "Pavilion Cam 1"
              }
            }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("camera_angle_switch")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Videocam, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = selectedCamera, color = Color.White, style = MaterialTheme.typography.labelSmall)
          }
        }
      }
    }

    // Lower-Third Television Match Score Bug (Wisden-Grade Presentation)
    val activeInnings = match.inningsList.getOrNull(match.currentInningsIndex)
    val currentScore = if (activeInnings != null) "${activeInnings.totalRuns}/${activeInnings.wickets}" else "0/0"
    val overs = activeInnings?.oversCompleted ?: 0.0

    Box(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .padding(start = 12.dp, bottom = 44.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(Color(0xDD0F261D))
        .border(1.dp, CricketBrassGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        // County Badge
        Text(
          text = homeCounty.crestSymbol,
          fontSize = 18.sp,
          modifier = Modifier.padding(end = 6.dp)
        )
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "${homeCounty.shortName} vs ${awayCounty.shortName}",
              color = CricketBrassGold,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = currentScore,
              color = Color.White,
              style = MaterialTheme.typography.titleMedium,
              fontFamily = FontFamily.Serif,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "($overs ov)",
              color = CricketBorder,
              style = MaterialTheme.typography.labelSmall
            )
          }
          Text(
            text = match.statusDetail,
            color = Color.White.copy(alpha = 0.9f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1
          )
        }
      }
    }

    // Interactive Controls Bar at Bottom
    AnimatedVisibility(
      visible = isControlsVisible,
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xCC08140F))
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        // DVR Scrubber Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = { isPlaying = !isPlaying },
              modifier = Modifier.size(30.dp)
            ) {
              Icon(
                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = "Play/Pause",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
              )
            }

            Text(
              text = if (stream?.isAtLiveEdge == true) "LIVE EDGE" else "-02:40",
              color = if (stream?.isAtLiveEdge == true) CricketLiveRed else Color.White,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
          }

          // Telemetry and Controls
          Row(verticalAlignment = Alignment.CenterVertically) {
            // Bitrate badge
            Text(
              text = "${stream?.bitrateKbps ?: 5400} kbps • ${stream?.fps ?: 50}fps",
              color = CricketBorder,
              style = MaterialTheme.typography.labelSmall,
              fontSize = 10.sp
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Audio Sync Dialog button
            IconButton(
              onClick = { showSyncDialog = true },
              modifier = Modifier.size(30.dp)
            ) {
              Icon(Icons.Default.VolumeUp, contentDescription = "Audio Commentary Sync", tint = Color.White, modifier = Modifier.size(18.dp))
            }

            // Quality switcher button
            IconButton(
              onClick = { showQualityDialog = true },
              modifier = Modifier.size(30.dp)
            ) {
              Icon(Icons.Default.Settings, contentDescription = "Quality", tint = Color.White, modifier = Modifier.size(18.dp))
            }

            // Signal drop simulator button
            IconButton(
              onClick = onSimulateDrop,
              modifier = Modifier.size(30.dp)
            ) {
              Icon(Icons.Default.Refresh, contentDescription = "Test Reconnection", tint = CricketBrassGold, modifier = Modifier.size(18.dp))
            }
          }
        }
      }
    }
  }

  // Quality Dialog
  if (showQualityDialog) {
    AlertDialog(
      onDismissRequest = { showQualityDialog = false },
      title = {
        Text("Playback Quality & Bandwidth", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          PlaybackQuality.entries.forEach { q ->
            val isCurrent = stream?.quality == q
            Card(
              colors = CardDefaults.cardColors(
                containerColor = if (isCurrent) CricketGreenContainer else CricketCreamSurface
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onQualityChange(q)
                  showQualityDialog = false
                }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = q.label, fontWeight = FontWeight.Bold, color = CricketInk)
                  Text(text = "${q.resolution} • ${q.bitrate}", style = MaterialTheme.typography.bodySmall, color = CricketInkSecondary)
                }
                if (isCurrent) {
                  Icon(Icons.Default.Check, contentDescription = null, tint = CricketGreenPrimary)
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showQualityDialog = false }) { Text("Close", color = CricketGreenPrimary) }
      }
    )
  }

  // Audio Commentary Synchronisation Dialog
  if (showSyncDialog) {
    var offsetValue by remember { mutableFloatStateOf((stream?.audioSyncOffsetMs ?: 0L) / 1000f) }
    AlertDialog(
      onDismissRequest = { showSyncDialog = false },
      title = {
        Text("Audio Commentary Sync", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "Synchronise BBC Test Match Special / County Club radio with the live video feed. Adjust delay to eliminate commentary spoilers.",
            style = MaterialTheme.typography.bodySmall,
            color = CricketInkSecondary
          )
          Text(
            text = "Current Station: ${stream?.radioStationName ?: "BBC Radio"}",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketInk
          )
          Slider(
            value = offsetValue,
            onValueChange = { offsetValue = it },
            valueRange = -5f..5f,
            steps = 19,
            colors = SliderDefaults.colors(
              thumbColor = CricketBrassGold,
              activeTrackColor = CricketGreenPrimary
            )
          )
          Text(
            text = "Audio Offset: ${String.format(java.util.Locale.UK, "%+.1f", offsetValue)} seconds",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onAdjustAudioSync((offsetValue * 1000).toLong())
            showSyncDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary)
        ) {
          Text("Apply Sync", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showSyncDialog = false }) { Text("Cancel") }
      }
    )
  }
}

@Composable
private fun AudioModeVisualizer(match: Match, stream: VideoStream?) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(CricketGreenDark),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
      Icon(Icons.Default.Radio, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(48.dp))
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "LOW-BANDWIDTH AUDIO BROADCAST",
        color = CricketBrassGold,
        style = MaterialTheme.typography.labelSmall,
        letterSpacing = 1.2.sp
      )
      Text(
        text = stream?.radioStationName ?: "BBC County Live Commentary",
        color = Color.White,
        style = MaterialTheme.typography.titleMedium,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Ball-by-ball description synchronised • 128 kbps AAC stereo",
        color = CricketBorder,
        style = MaterialTheme.typography.bodySmall
      )
    }
  }
}
