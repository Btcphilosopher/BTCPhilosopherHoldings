package com.example.ui.portal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.CountyDatasets
import com.example.ui.theme.*

enum class ClubRole(val label: String) {
  OWNER("Club Owner"),
  BROADCAST_PRODUCER("Broadcast Producer"),
  ADMINISTRATOR("Club Administrator"),
  EDITOR("Video Editor"),
  ANALYST("Performance Analyst"),
}

@Composable
fun ClubPortalScreen(
  activeCountyId: String,
  publishedBroadcasts: List<BroadcastConfig>,
  matches: List<Match>,
  onPublishBroadcast: (BroadcastConfig) -> Unit,
  onSelectCounty: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedCountyId by remember { mutableStateOf(activeCountyId) }
  var currentRole by remember { mutableStateOf(ClubRole.BROADCAST_PRODUCER) }
  var isPublishStudioOpen by remember { mutableStateOf(false) }

  val counties = remember { CountyDatasets.allCounties }
  val currentCounty = remember(selectedCountyId) { CountyDatasets.getCounty(selectedCountyId) }
  val countyBroadcasts = remember(publishedBroadcasts, selectedCountyId) {
    publishedBroadcasts.filter { it.countyId == selectedCountyId }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(CricketCreamBackground)
      .padding(horizontal = 14.dp)
  ) {
    Spacer(modifier = Modifier.height(10.dp))

    // Club Selector & Role Header
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
      colors = CardDefaults.cardColors(containerColor = CricketGreenDark)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = currentCounty.crestSymbol, fontSize = 28.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "${currentCounty.name} CCC",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Official Broadcaster Publishing Portal",
                color = CricketBrassGold,
                style = MaterialTheme.typography.labelSmall
              )
            }
          }

          // Role Switcher Pill
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(Color(0x33FFFFFF))
              .clickable {
                currentRole = when (currentRole) {
                  ClubRole.BROADCAST_PRODUCER -> ClubRole.ADMINISTRATOR
                  ClubRole.ADMINISTRATOR -> ClubRole.OWNER
                  else -> ClubRole.BROADCAST_PRODUCER
                }
              }
              .padding(horizontal = 8.dp, vertical = 4.dp)
              .testTag("portal_role_switch")
          ) {
            Text(
              text = currentRole.label,
              color = Color.White,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = Color(0x33FFFFFF))
        Spacer(modifier = Modifier.height(10.dp))

        // Quick County Switcher Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Switch Club Tenant:",
            color = CricketBorder,
            style = MaterialTheme.typography.labelSmall
          )

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("yorkshire", "surrey", "somerset", "essex").forEach { cId ->
              val c = CountyDatasets.getCounty(cId)
              val isSelected = cId == selectedCountyId
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (isSelected) CricketBrassGold else Color(0x22FFFFFF))
                  .clickable {
                    selectedCountyId = cId
                    onSelectCounty(cId)
                  }
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = c.shortName,
                  color = if (isSelected) CricketGreenDark else Color.White,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Studio Action Bar: "CREATE NEW BROADCAST" button
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "ACTIVE INGEST & BROADCASTS",
        style = MaterialTheme.typography.labelSmall,
        color = CricketBrassGold,
        letterSpacing = 1.2.sp
      )

      Button(
        onClick = { isPublishStudioOpen = true },
        colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier.testTag("create_broadcast_button")
      ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Publish Broadcast", color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Broadcasts & Live Health Telemetry List
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      if (countyBroadcasts.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CricketCreamSurface)
          ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(Icons.Default.Podcasts, contentDescription = null, tint = CricketBrassGold, modifier = Modifier.size(36.dp))
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "No scheduled streams for ${currentCounty.name} CCC.",
                style = MaterialTheme.typography.bodyMedium,
                color = CricketInkSecondary,
                fontFamily = FontFamily.Serif
              )
              Spacer(modifier = Modifier.height(8.dp))
              Button(
                onClick = { isPublishStudioOpen = true },
                colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary)
              ) {
                Text("Schedule Feed Now", color = Color.White)
              }
            }
          }
        }
      } else {
        items(countyBroadcasts) { broadcast ->
          BroadcastHealthCard(broadcast = broadcast)
        }
      }

      // Pre-Broadcast Checklist & Rights Compliance Panel
      item {
        PreBroadcastGuidelinesCard()
      }
    }
  }

  // 10-Step Broadcast Creation Studio Dialog
  if (isPublishStudioOpen) {
    BroadcastStudioWizardDialog(
      county = currentCounty,
      matches = matches.filter { it.homeCountyId == currentCounty.id },
      onDismiss = { isPublishStudioOpen = false },
      onPublish = { newConfig ->
        onPublishBroadcast(newConfig)
        isPublishStudioOpen = false
      }
    )
  }
}

@Composable
fun BroadcastHealthCard(broadcast: BroadcastConfig) {
  val h = broadcast.health

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
    colors = CardDefaults.cardColors(containerColor = CricketScorecardCream)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(if (h.isLive) CricketGreenPrimary else CricketInkMuted)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (h.isLive) "LIVE INGEST HEALTHY" else "OFFLINE",
              style = MaterialTheme.typography.labelSmall,
              color = if (h.isLive) CricketGreenDark else CricketInkMuted,
              fontWeight = FontWeight.Bold
            )
          }
          Text(
            text = broadcast.matchTitle,
            style = MaterialTheme.typography.titleSmall,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = CricketInk
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(CricketBrassGoldContainer)
            .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
          Text(
            text = "${h.activeViewers} Viewers",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = CricketOnBrassGold
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Real-time Telemetry Grid (Bitrate, FPS, Dropped Frames, Audio)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(CricketCreamSurface, RoundedCornerShape(6.dp))
          .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "Bitrate", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted, fontSize = 9.sp)
          Text(text = "${h.inputBitrateKbps} kbps", fontWeight = FontWeight.Bold, color = CricketInk, style = MaterialTheme.typography.bodySmall)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "Framerate", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted, fontSize = 9.sp)
          Text(text = "${h.currentFps} fps", fontWeight = FontWeight.Bold, color = CricketInk, style = MaterialTheme.typography.bodySmall)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "Audio Level", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted, fontSize = 9.sp)
          Text(text = "${h.audioLevelDb} dB", fontWeight = FontWeight.Bold, color = CricketInk, style = MaterialTheme.typography.bodySmall)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "Rebuffering", style = MaterialTheme.typography.labelSmall, color = CricketInkMuted, fontSize = 9.sp)
          Text(text = "${h.rebufferingRatePercent}%", fontWeight = FontWeight.Bold, color = CricketGreenDark, style = MaterialTheme.typography.bodySmall)
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Endpoint details
      Text(
        text = "Primary RTMP: ${broadcast.primaryIngestUrl}",
        style = MaterialTheme.typography.bodySmall,
        color = CricketInkMuted,
        fontSize = 10.sp,
        maxLines = 1
      )
      Text(
        text = "Fallback RTMP: ${broadcast.backupIngestUrl}",
        style = MaterialTheme.typography.bodySmall,
        color = CricketInkMuted,
        fontSize = 10.sp,
        maxLines = 1
      )
    }
  }
}

@Composable
fun PreBroadcastGuidelinesCard() {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .border(1.dp, CricketBorder, RoundedCornerShape(10.dp)),
    colors = CardDefaults.cardColors(containerColor = CricketCreamCard)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = "ECB & COUNTY BROADCAST CODE",
        style = MaterialTheme.typography.labelSmall,
        color = CricketBrassGold,
        letterSpacing = 1.sp
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "• Every feed must carry verified local territory metadata (UK & Ireland vs Overseas rights).\n• Clubs retain 100% intellectual property of native commentary and video feeds.\n• Redundant backup stream ingest is recommended for major championship rounds.\n• Synthetic test feeds are strictly marked with non-production badges.",
        style = MaterialTheme.typography.bodySmall,
        fontFamily = FontFamily.Serif,
        color = CricketInkSecondary,
        lineHeight = 18.sp
      )
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BroadcastStudioWizardDialog(
  county: County,
  matches: List<Match>,
  onDismiss: () -> Unit,
  onPublish: (BroadcastConfig) -> Unit,
) {
  var streamTitle by remember { mutableStateOf("${county.name} vs Lancashire — Day 3") }
  var ingestUrl by remember { mutableStateOf("rtmp://ingest.${county.id}ccc.com/live/main") }
  var backupUrl by remember { mutableStateOf("rtmp://backup.${county.id}ccc.com/live/cam02") }
  var providerType by remember { mutableStateOf(VideoProviderType.CLUB_HOSTED) }
  var selectedTerritory by remember { mutableStateOf(Territory.UK_IRELAND) }
  var requiredPlan by remember { mutableStateOf(EntitlementPlan.FREE_SUPPORTER) }

  // 3-point Pre-broadcast checklist
  var checkFeedValid by remember { mutableStateOf(true) }
  var checkAudioSynced by remember { mutableStateOf(true) }
  var checkRightsConfirmed by remember { mutableStateOf(true) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Broadcast Creation Studio",
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        color = CricketInk
      )
    },
    text = {
      LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        item {
          Text(
            text = "Step 1: Match Title & Fixture",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
          OutlinedTextField(
            value = streamTitle,
            onValueChange = { streamTitle = it },
            label = { Text("Broadcast Title") },
            modifier = Modifier.fillMaxWidth()
          )
        }

        item {
          Text(
            text = "Step 2: Video Provider Model",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (providerType == VideoProviderType.CLUB_HOSTED) CricketGreenPrimary else CricketCreamSurface)
                .clickable { providerType = VideoProviderType.CLUB_HOSTED }
                .padding(8.dp)
            ) {
              Text("Club-Hosted", color = if (providerType == VideoProviderType.CLUB_HOSTED) Color.White else CricketInk, style = MaterialTheme.typography.labelSmall)
            }
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (providerType == VideoProviderType.PLATFORM_INTEGRATED) CricketGreenPrimary else CricketCreamSurface)
                .clickable { providerType = VideoProviderType.PLATFORM_INTEGRATED }
                .padding(8.dp)
            ) {
              Text("Platform Ingest", color = if (providerType == VideoProviderType.PLATFORM_INTEGRATED) Color.White else CricketInk, style = MaterialTheme.typography.labelSmall)
            }
          }
        }

        item {
          Text(
            text = "Step 3: Primary RTMP Ingest URL",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
          OutlinedTextField(
            value = ingestUrl,
            onValueChange = { ingestUrl = it },
            label = { Text("Primary Stream URL") },
            modifier = Modifier.fillMaxWidth()
          )
        }

        item {
          Text(
            text = "Step 4: Backup Fallback URL",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
          OutlinedTextField(
            value = backupUrl,
            onValueChange = { backupUrl = it },
            label = { Text("Redundant Backup Stream") },
            modifier = Modifier.fillMaxWidth()
          )
        }

        item {
          Text(
            text = "Step 5: Pre-Broadcast Checklist",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CricketGreenDark
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checkFeedValid, onCheckedChange = { checkFeedValid = it })
            Text("Feed playback validated on test receiver", style = MaterialTheme.typography.bodySmall)
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checkAudioSynced, onCheckedChange = { checkAudioSynced = it })
            Text("Radio commentary audio levels tested (-14 dB)", style = MaterialTheme.typography.bodySmall)
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checkRightsConfirmed, onCheckedChange = { checkRightsConfirmed = it })
            Text("Broadcast rights & territory clearance confirmed", style = MaterialTheme.typography.bodySmall)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val newConfig = BroadcastConfig(
            broadcastId = "bc-${county.id}-${System.currentTimeMillis() % 10000}",
            countyId = county.id,
            matchId = "match-01",
            matchTitle = streamTitle,
            providerType = providerType,
            primaryIngestUrl = ingestUrl,
            backupIngestUrl = backupUrl,
            streamKeyOrEmbed = "live_key_${county.shortName.lowercase()}",
            scheduledStartTime = "11:00 BST",
            allowedTerritories = listOf(selectedTerritory),
            requiredPlan = requiredPlan,
            isAudioChecked = checkAudioSynced,
            isVideoChecked = checkFeedValid,
            isRightsConfirmed = checkRightsConfirmed,
            isPublished = true,
            health = StreamHealth(
              isLive = true,
              inputBitrateKbps = 5850,
              currentFps = 50,
              droppedFramesPercent = 0.01,
              audioLevelDb = -13.8,
              activeViewers = 6420,
            )
          )
          onPublish(newConfig)
        },
        enabled = checkFeedValid && checkAudioSynced && checkRightsConfirmed,
        colors = ButtonDefaults.buttonColors(containerColor = CricketGreenPrimary),
        modifier = Modifier.testTag("publish_stream_confirm_button")
      ) {
        Text("Publish Stream", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}
