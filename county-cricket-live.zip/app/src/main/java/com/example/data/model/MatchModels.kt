package com.example.data.model

enum class Competition(val title: String, val shortTitle: String, val format: MatchFormat) {
  COUNTY_CHAMPIONSHIP_DIV1("County Championship Division One", "County Champ D1", MatchFormat.FIRST_CLASS),
  COUNTY_CHAMPIONSHIP_DIV2("County Championship Division Two", "County Champ D2", MatchFormat.FIRST_CLASS),
  T20_BLAST("Vitality T20 Blast", "T20 Blast", MatchFormat.T20),
  ONE_DAY_CUP("Metro Bank One-Day Cup", "One-Day Cup", MatchFormat.LIST_A),
  WOMENS_COUNTY("Women's County Championship", "Women's Champ", MatchFormat.T20),
  SECOND_XI("Second XI Championship", "Second XI", MatchFormat.FIRST_CLASS),
}

enum class MatchFormat(val label: String, val days: Int, val oversPerInnings: Int?) {
  FIRST_CLASS("First-Class (4-Day)", 4, null),
  T20("Twenty20", 1, 20),
  LIST_A("List A (50 Overs)", 1, 50),
}

enum class MatchStatus(val label: String, val isLive: Boolean) {
  UPCOMING("Scheduled", false),
  LIVE("LIVE", true),
  TEA_INTERVAL("Tea Interval", true),
  LUNCH_INTERVAL("Lunch Interval", true),
  RAIN_DELAY("Rain Delay", true),
  BAD_LIGHT("Bad Light", true),
  INNINGS_BREAK("Innings Break", true),
  STUMPS("Stumps", false),
  COMPLETED("Result", false),
  ABANDONED("Match Abandoned", false),
}

data class Match(
  val id: String,
  val competition: Competition,
  val season: String = "2026",
  val roundNumber: Int,
  val homeCountyId: String,
  val awayCountyId: String,
  val venue: String,
  val scheduledDateText: String,
  val scheduledTimeText: String,
  val status: MatchStatus,
  val statusDetail: String, // e.g. "Day 3, Session 2 - Yorkshire lead by 142 runs" or "Surrey need 34 runs in 18 balls"
  val tossText: String = "",
  val dayNumber: Int = 1,
  val sessionNumber: Int = 1,
  val currentInningsIndex: Int = 0,
  val inningsList: List<Innings> = emptyList(),
  val targetRuns: Int? = null,
  val requiredRunRate: Double? = null,
  val hasVideo: Boolean = true,
  val hasAudio: Boolean = true,
  val streamId: String? = null,
  val rightsTerritory: String = "UK & Worldwide",
  val isDemonstration: Boolean = true,
  val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
  val bonusPointsHome: BonusPoints = BonusPoints(3, 2),
  val bonusPointsAway: BonusPoints = BonusPoints(2, 3),
)

data class BonusPoints(
  val batting: Int,
  val bowling: Int,
) {
  val total: Int get() = batting + bowling
}

data class Innings(
  val inningsNumber: Int, // 1 to 4 for FC, 1 to 2 for Limited Overs
  val teamId: String,
  val teamName: String,
  val totalRuns: Int,
  val wickets: Int,
  val oversCompleted: Double, // e.g. 84.3
  val isDeclared: Boolean = false,
  val isFollowOn: Boolean = false,
  val isAllOut: Boolean = false,
  val extras: Extras = Extras(),
  val battingScorecard: List<BattingEntry> = emptyList(),
  val bowlingFigures: List<BowlingEntry> = emptyList(),
  val fallOfWickets: List<FallOfWicket> = emptyList(),
  val partnerships: List<Partnership> = emptyList(),
)

data class Extras(
  val byes: Int = 4,
  val legByes: Int = 3,
  val wides: Int = 2,
  val noBalls: Int = 1,
) {
  val total: Int get() = byes + legByes + wides + noBalls
}

data class BattingEntry(
  val batterName: String,
  val dismissal: String, // e.g. "c Bairstow b Coad" or "not out"
  val runs: Int,
  val balls: Int,
  val fours: Int,
  val sixes: Int,
  val isNotOut: Boolean = false,
  val isCurrentBatter: Boolean = false,
  val isStriker: Boolean = false,
) {
  val strikeRate: Double
    get() = if (balls > 0) (runs.toDouble() / balls * 100.0) else 0.0
}

data class BowlingEntry(
  val bowlerName: String,
  val overs: Double, // e.g. 18.4
  val maidens: Int,
  val runs: Int,
  val wickets: Int,
  val isCurrentBowler: Boolean = false,
) {
  val economy: Double
    get() = if (overs > 0) (runs / overs) else 0.0
}

data class FallOfWicket(
  val wicketNumber: Int,
  val score: Int,
  val batterName: String,
  val over: Double,
)

data class Partnership(
  val batter1: String,
  val batter2: String,
  val runs: Int,
  val balls: Int,
  val isUnbroken: Boolean = false,
)

data class BallEvent(
  val ballNumber: String, // e.g. "45.3"
  val bowlerName: String,
  val batterName: String,
  val runsScored: Int,
  val isBoundaryFour: Boolean = false,
  val isBoundarySix: Boolean = false,
  val isWicket: Boolean = false,
  val wicketDetail: String? = null,
  val commentary: String,
  val timestampText: String,
  val isMaidenOverEnd: Boolean = false,
)

data class DivisionStanding(
  val position: Int,
  val countyId: String,
  val countyName: String,
  val played: Int,
  val won: Int,
  val drawn: Int,
  val lost: Int,
  val battingBonus: Int,
  val bowlingBonus: Int,
  val points: Int,
  val netRunRate: Double? = null,
)
