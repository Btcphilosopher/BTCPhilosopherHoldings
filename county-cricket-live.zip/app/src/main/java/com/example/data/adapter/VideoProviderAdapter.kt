package com.example.data.adapter

import com.example.data.model.*
import kotlinx.coroutines.flow.StateFlow

interface VideoProviderAdapter {
  val providerType: VideoProviderType
  val currentStreamState: StateFlow<StreamState>
  val currentStream: StateFlow<VideoStream?>

  fun initializeStream(matchId: String, streamUrl: String)
  fun connect()
  fun disconnect()
  fun setQuality(quality: PlaybackQuality)
  fun toggleLowBandwidthMode(enabled: Boolean)
  fun adjustAudioSync(offsetMs: Long)
  fun seekDvr(positionSec: Long)
  fun returnToLiveEdge()
  fun simulateNetworkInterruption()
  fun recoverConnection()
}
