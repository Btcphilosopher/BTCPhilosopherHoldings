package com.example.data.model

enum class VideoProviderType(val label: String) {
  CLUB_HOSTED("Club-Hosted Stream (Official Club Player)"),
  PLATFORM_INTEGRATED("County Live CDN (Integrated Infrastructure)"),
  DEMONSTRATION("Demonstration Feed (Simulated Environment)"),
}

enum class StreamState(val label: String) {
  AVAILABLE("Available"),
  CONNECTING("Connecting to Stream..."),
  PLAYING("LIVE Playback"),
  RECONNECTING("Reconnecting..."),
  ENDED("Broadcast Concluded"),
  ERROR("Playback Error / Provider Unreachable"),
  UNAVAILABLE("Feed Unavailable"),
}

enum class PlaybackQuality(val label: String, val resolution: String, val bitrate: String) {
  AUTO_1080P("1080p (Auto)", "1920x1080", "5.8 Mbps"),
  HD_720P("720p HD", "1280x720", "3.2 Mbps"),
  SD_540P("540p", "960x540", "1.5 Mbps"),
  LOW_BANDWIDTH("Audio Only (Low Bandwidth)", "Sound Only", "128 kbps"),
}

enum class Territory(val code: String, val label: String) {
  UK_IRELAND("GB", "United Kingdom & Ireland"),
  REST_OF_WORLD("ROW", "Rest of the World (International)"),
  EUROPE("EU", "Continental Europe"),
  NORTH_AMERICA("NA", "North America (USA & Canada)"),
  AUSTRALIA_NZ("ANZ", "Australia & New Zealand"),
}

enum class EntitlementPlan(val id: String, val title: String, val priceText: String) {
  FREE_SUPPORTER("free", "Free Registered Supporter", "£0.00 / season"),
  COUNTY_CLUB_PASS("club_pass", "Official County Club Pass", "£14.99 / season"),
  ALL_COUNTY_PASS("all_county", "All-18 Counties National Pass", "£44.99 / season"),
}

data class VideoStream(
  val id: String,
  val matchId: String,
  val title: String,
  val providerType: VideoProviderType,
  val state: StreamState = StreamState.PLAYING,
  val streamUrl: String,
  val backupStreamUrl: String? = null,
  val quality: PlaybackQuality = PlaybackQuality.AUTO_1080P,
  val bitrateKbps: Int = 5400,
  val fps: Int = 50,
  val latencySeconds: Double = 3.2,
  val liveViewers: Int = 14820,
  val audioSyncOffsetMs: Long = 0L, // +/- audio commentary offset
  val isAudioCommentaryLinked: Boolean = true,
  val radioStationName: String = "BBC Radio / County Broadcast",
  val dvrLivePositionSec: Long = 14200L,
  val currentDvrPositionSec: Long = 14200L,
  val isAtLiveEdge: Boolean = true,
  val errorMessage: String? = null,
)

data class BroadcastConfig(
  val broadcastId: String,
  val countyId: String,
  val matchId: String,
  val matchTitle: String,
  val providerType: VideoProviderType,
  val primaryIngestUrl: String,
  val backupIngestUrl: String,
  val streamKeyOrEmbed: String,
  val scheduledStartTime: String,
  val allowedTerritories: List<Territory>,
  val requiredPlan: EntitlementPlan,
  val isAudioChecked: Boolean,
  val isVideoChecked: Boolean,
  val isRightsConfirmed: Boolean,
  val isPublished: Boolean,
  val health: StreamHealth,
)

data class StreamHealth(
  val isLive: Boolean,
  val inputBitrateKbps: Int,
  val targetBitrateKbps: Int = 6000,
  val currentFps: Int,
  val targetFps: Int = 50,
  val droppedFramesPercent: Double = 0.1,
  val audioLevelDb: Double = -14.2,
  val rebufferingRatePercent: Double = 0.05,
  val activeViewers: Int = 8900,
  val incidentCount: Int = 0,
)
