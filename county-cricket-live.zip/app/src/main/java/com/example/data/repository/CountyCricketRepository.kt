package com.example.data.repository

import com.example.data.adapter.CricketDataAdapter
import com.example.data.adapter.VideoProviderAdapter
import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import kotlin.random.Random

class CountyCricketRepository private constructor() : CricketDataAdapter, VideoProviderAdapter {

  private val coroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

  // Observables
  private val _matches = MutableStateFlow<List<Match>>(emptyList())
  val matches: StateFlow<List<Match>> = _matches.asStateFlow()

  private val _selectedMatch = MutableStateFlow<Match?>(null)
  val selectedMatch: StateFlow<Match?> = _selectedMatch.asStateFlow()

  private val _ballEvents = MutableStateFlow<Map<String, List<BallEvent>>>(emptyMap())
  val ballEvents: StateFlow<Map<String, List<BallEvent>>> = _ballEvents.asStateFlow()

  private val _userProfile = MutableStateFlow(UserProfile())
  val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

  private val _publishedBroadcasts = MutableStateFlow<List<BroadcastConfig>>(emptyList())
  val publishedBroadcasts: StateFlow<List<BroadcastConfig>> = _publishedBroadcasts.asStateFlow()

  private val _highlights = MutableStateFlow<List<HighlightItem>>(emptyList())
  val highlights: StateFlow<List<HighlightItem>> = _highlights.asStateFlow()

  private val _articles = MutableStateFlow<List<EditorialArticle>>(emptyList())
  val articles: StateFlow<List<EditorialArticle>> = _articles.asStateFlow()

  // Video Streaming State
  override val providerType: VideoProviderType = VideoProviderType.DEMONSTRATION

  private val _currentStreamState = MutableStateFlow(StreamState.PLAYING)
  override val currentStreamState: StateFlow<StreamState> = _currentStreamState.asStateFlow()

  private val _currentStream = MutableStateFlow<VideoStream?>(null)
  override val currentStream: StateFlow<VideoStream?> = _currentStream.asStateFlow()

  // Secondary stream for multiview
  private val _secondaryStream = MutableStateFlow<VideoStream?>(null)
  val secondaryStream: StateFlow<VideoStream?> = _secondaryStream.asStateFlow()

  private val _isMultiviewActive = MutableStateFlow(false)
  val isMultiviewActive: StateFlow<Boolean> = _isMultiviewActive.asStateFlow()

  // Live simulation ticker control
  override var isLiveSimulationActive: Boolean = true
    private set

  private var simulationJob: Job? = null

  init {
    loadInitialData()
    startSimulationTicker()
  }

  private fun loadInitialData() {
    val initialMatches = createInitialMatches()
    _matches.value = initialMatches
    _selectedMatch.value = initialMatches.firstOrNull()

    // Flagship match stream
    val flagship = initialMatches.first()
    _currentStream.value = VideoStream(
      id = "stream-yor-lan",
      matchId = flagship.id,
      title = "Yorkshire vs Lancashire — County Championship Div 1",
      providerType = VideoProviderType.CLUB_HOSTED,
      state = StreamState.PLAYING,
      streamUrl = "https://live.yorkshireccc.com/hls/headingley-cam01.m3u8",
      backupStreamUrl = "https://backup.yorkshireccc.com/hls/headingley-cam02.m3u8",
      quality = PlaybackQuality.AUTO_1080P,
      bitrateKbps = 5820,
      fps = 50,
      liveViewers = 18450,
      radioStationName = "BBC Radio Leeds & TMS Live",
    )

    // Secondary stream (Surrey vs Somerset T20 Blast)
    val secondMatch = initialMatches.getOrNull(1)
    if (secondMatch != null) {
      _secondaryStream.value = VideoStream(
        id = "stream-sur-som",
        matchId = secondMatch.id,
        title = "Surrey vs Somerset — Vitality T20 Blast",
        providerType = VideoProviderType.CLUB_HOSTED,
        state = StreamState.PLAYING,
        streamUrl = "https://live.kiaoval.com/hls/oval-blast.m3u8",
        quality = PlaybackQuality.HD_720P,
        bitrateKbps = 3200,
        fps = 50,
        liveViewers = 24100,
        radioStationName = "BBC Radio London Blast",
      )
    }

    _ballEvents.value = mapOf(
      flagship.id to createInitialBallEvents(flagship.id)
    )

    _highlights.value = createInitialHighlights()
    _articles.value = createInitialArticles()
    _publishedBroadcasts.value = createInitialBroadcasts()
  }

  // --- DATA ADAPTER METHODS ---
  override fun getMatches(): List<Match> = _matches.value

  override fun getMatch(matchId: String): Match? = _matches.value.firstOrNull { it.id == matchId }

  override fun getLiveMatchFlow(): StateFlow<Match?> = _selectedMatch

  override fun getRecentBallEvents(matchId: String): List<BallEvent> {
    return _ballEvents.value[matchId] ?: emptyList()
  }

  override fun getStandings(competition: Competition): List<DivisionStanding> {
    return when (competition) {
      Competition.COUNTY_CHAMPIONSHIP_DIV1 -> listOf(
        DivisionStanding(1, "surrey", "Surrey", 12, 8, 3, 1, 38, 34, 198),
        DivisionStanding(2, "essex", "Essex", 12, 7, 3, 2, 34, 33, 185),
        DivisionStanding(3, "warwickshire", "Warwickshire", 12, 6, 4, 2, 31, 30, 169),
        DivisionStanding(4, "hampshire", "Hampshire", 12, 5, 5, 2, 29, 32, 157),
        DivisionStanding(5, "somerset", "Somerset", 12, 4, 6, 2, 28, 29, 145),
        DivisionStanding(6, "notts", "Nottinghamshire", 12, 4, 4, 4, 26, 28, 134),
        DivisionStanding(7, "durham", "Durham", 12, 3, 5, 4, 30, 24, 126),
        DivisionStanding(8, "lancashire", "Lancashire", 12, 2, 6, 4, 24, 26, 114),
        DivisionStanding(9, "worcestershire", "Worcestershire", 12, 2, 4, 6, 22, 24, 102),
        DivisionStanding(10, "kent", "Kent", 12, 1, 4, 7, 18, 22, 84),
      )
      Competition.COUNTY_CHAMPIONSHIP_DIV2 -> listOf(
        DivisionStanding(1, "yorkshire", "Yorkshire", 12, 7, 4, 1, 39, 35, 194),
        DivisionStanding(2, "sussex", "Sussex", 12, 7, 3, 2, 36, 32, 182),
        DivisionStanding(3, "middlesex", "Middlesex", 12, 6, 4, 2, 32, 28, 168),
        DivisionStanding(4, "leicestershire", "Leicestershire", 12, 4, 5, 3, 30, 29, 147),
        DivisionStanding(5, "glamorgan", "Glamorgan", 12, 3, 6, 3, 28, 25, 137),
        DivisionStanding(6, "northants", "Northamptonshire", 12, 2, 6, 4, 24, 26, 122),
        DivisionStanding(7, "gloucestershire", "Gloucestershire", 12, 2, 5, 5, 22, 25, 115),
        DivisionStanding(8, "derbyshire", "Derbyshire", 12, 1, 5, 6, 20, 22, 98),
      )
      Competition.T20_BLAST -> listOf(
        DivisionStanding(1, "somerset", "Somerset", 10, 8, 0, 2, 0, 0, 16, 1.42),
        DivisionStanding(2, "surrey", "Surrey", 10, 7, 0, 3, 0, 0, 14, 1.15),
        DivisionStanding(3, "hampshire", "Hampshire Hawks", 10, 7, 0, 3, 0, 0, 14, 0.88),
        DivisionStanding(4, "sussex", "Sussex Sharks", 10, 6, 0, 4, 0, 0, 12, 0.45),
        DivisionStanding(5, "essex", "Essex Eagles", 10, 5, 0, 5, 0, 0, 10, -0.12),
        DivisionStanding(6, "kent", "Kent Spitfires", 10, 4, 0, 6, 0, 0, 8, -0.38),
        DivisionStanding(7, "gloucestershire", "Gloucestershire", 10, 3, 0, 7, 0, 0, 6, -0.92),
        DivisionStanding(8, "middlesex", "Middlesex", 10, 0, 0, 10, 0, 0, 0, -2.14),
      )
      else -> listOf(
        DivisionStanding(1, "surrey", "Surrey", 8, 6, 1, 1, 0, 0, 13, 0.95),
        DivisionStanding(2, "yorkshire", "Yorkshire", 8, 5, 2, 1, 0, 0, 12, 0.82),
        DivisionStanding(3, "leicestershire", "Leicestershire", 8, 5, 1, 2, 0, 0, 11, 0.64),
      )
    }
  }

  override fun toggleSimulation(active: Boolean) {
    isLiveSimulationActive = active
    if (active && (simulationJob == null || simulationJob?.isActive == false)) {
      startSimulationTicker()
    } else if (!active) {
      simulationJob?.cancel()
    }
  }

  fun selectMatch(matchId: String) {
    val m = _matches.value.firstOrNull { it.id == matchId }
    if (m != null) {
      _selectedMatch.value = m
      // Update primary stream to this match
      val current = _currentStream.value
      _currentStream.value = current?.copy(
        matchId = m.id,
        title = "${CountyDatasets.getCounty(m.homeCountyId).name} vs ${CountyDatasets.getCounty(m.awayCountyId).name} — ${m.competition.shortTitle}",
        state = if (m.status.isLive) StreamState.PLAYING else StreamState.AVAILABLE,
      ) ?: VideoStream(
        id = "stream-${m.id}",
        matchId = m.id,
        title = "${CountyDatasets.getCounty(m.homeCountyId).name} vs ${CountyDatasets.getCounty(m.awayCountyId).name}",
        providerType = VideoProviderType.CLUB_HOSTED,
        streamUrl = "https://live.countycricket.co.uk/hls/${m.id}.m3u8",
      )
    }
  }

  // --- LIVE SIMULATION TICKER ---
  private fun startSimulationTicker() {
    simulationJob?.cancel()
    simulationJob = coroutineScope.launch {
      while (isActive) {
        delay(4000L) // every 4 seconds bowl a ball
        if (isLiveSimulationActive) {
          stepSingleBall()
        }
      }
    }
  }

  override fun stepSingleBall(): BallEvent? {
    val match = _matches.value.firstOrNull { it.id == "match-01" } ?: return null
    if (!match.status.isLive) return null

    val currentInningsIndex = match.currentInningsIndex
    val inningsList = match.inningsList.toMutableList()
    val currInnings = inningsList.getOrNull(currentInningsIndex) ?: return null

    // Overs advancement
    val oldOvers = currInnings.oversCompleted
    val fullOvers = oldOvers.toInt()
    val ballInOver = ((oldOvers - fullOvers) * 10).toInt() + 1
    val newOvers = if (ballInOver >= 6) (fullOvers + 1).toDouble() else fullOvers + (ballInOver / 10.0)

    // Ball outcome
    val roll = Random.nextInt(100)
    val runs: Int
    val isFour: Boolean
    val isSix: Boolean
    val isWicket: Boolean
    val commentary: String

    val currentBatter = currInnings.battingScorecard.firstOrNull { it.isNotOut && it.isStriker }
      ?: currInnings.battingScorecard.firstOrNull { it.isNotOut }
      ?: BattingEntry("Joe Root", "not out", 78, 114, 9, 1, true, true, true)

    val currentBowler = currInnings.bowlingFigures.firstOrNull { it.isCurrentBowler }
      ?: currInnings.bowlingFigures.firstOrNull()
      ?: BowlingEntry("James Anderson", 18.0, 4, 46, 2, true)

    when {
      roll < 50 -> { // Dot ball
        runs = 0
        isFour = false
        isSix = false
        isWicket = false
        val dotLines = listOf(
          "${currentBowler.bowlerName} angles in on good length around off stump; ${currentBatter.batterName} defends solidly into the covers.",
          "Full and straight from ${currentBowler.bowlerName}, blocked straight back down the pitch.",
          "Beaten outside off! Beautiful seam presentation, shaped past the tentative defensive blade.",
          "${currentBowler.bowlerName} hits a hard length, defended off the splice towards backward point.",
        )
        commentary = dotLines.random()
      }
      roll < 75 -> { // Single / two
        runs = if (roll < 68) 1 else 2
        isFour = false
        isSix = false
        isWicket = false
        commentary = "Tucked off the hips by ${currentBatter.batterName} into the mid-wicket pocket for ${if (runs == 1) "a comfortable single" else "two well-judged runs"}."
      }
      roll < 90 -> { // Boundary FOUR
        runs = 4
        isFour = true
        isSix = false
        isWicket = false
        val fourLines = listOf(
          "CRACKING SHOT! Overpitched by ${currentBowler.bowlerName}, and ${currentBatter.batterName} leans into a sumptuous cover drive that races to the rope!",
          "FOUR! Glanced exquisitely fine of fine leg, beats the diving fielder to the chalk.",
          "SHORT and punished! ${currentBatter.batterName} pulls handsomely through mid-wicket for four runs.",
        )
        commentary = fourLines.random()
      }
      roll < 94 -> { // SIX
        runs = 6
        isFour = false
        isSix = true
        isWicket = false
        commentary = "MAGNIFICENT SIX! Floated up, ${currentBatter.batterName} dances down the pitch and lofts it cleanly over long-on into the pavilion crowd!"
      }
      else -> { // WICKET
        runs = 0
        isFour = false
        isSix = false
        isWicket = true
        commentary = "WICKET! GONE! ${currentBowler.bowlerName} strikes! Edged and taken cleanly at first slip! What a massive moment in this county clash!"
      }
    }

    // New ball event
    val ballEvent = BallEvent(
      ballNumber = String.format(Locale.UK, "%.1f", newOvers),
      bowlerName = currentBowler.bowlerName,
      batterName = currentBatter.batterName,
      runsScored = runs,
      isBoundaryFour = isFour,
      isBoundarySix = isSix,
      isWicket = isWicket,
      commentary = commentary,
      timestampText = "Just now",
      isMaidenOverEnd = (ballInOver >= 6 && runs == 0),
    )

    // Update ball events list
    val currentMap = _ballEvents.value.toMutableMap()
    val eventsList = (currentMap[match.id] ?: emptyList()).toMutableList()
    eventsList.add(0, ballEvent)
    if (eventsList.size > 50) eventsList.removeAt(eventsList.lastIndex)
    currentMap[match.id] = eventsList
    _ballEvents.value = currentMap

    // Update innings
    val updatedTotalRuns = currInnings.totalRuns + runs
    val updatedWickets = if (isWicket) currInnings.wickets + 1 else currInnings.wickets

    // Update batting entries
    val updatedBatting = currInnings.battingScorecard.map { b ->
      if (b.batterName == currentBatter.batterName) {
        b.copy(
          runs = b.runs + runs,
          balls = b.balls + 1,
          fours = if (isFour) b.fours + 1 else b.fours,
          sixes = if (isSix) b.sixes + 1 else b.sixes,
          isNotOut = !isWicket,
          dismissal = if (isWicket) "c Jennings b ${currentBowler.bowlerName}" else b.dismissal,
        )
      } else b
    }

    // Update bowling entries
    val updatedBowling = currInnings.bowlingFigures.map { bow ->
      if (bow.bowlerName == currentBowler.bowlerName) {
        bow.copy(
          overs = newOvers,
          runs = bow.runs + runs,
          wickets = if (isWicket) bow.wickets + 1 else bow.wickets,
        )
      } else bow
    }

    val updatedInnings = currInnings.copy(
      totalRuns = updatedTotalRuns,
      wickets = updatedWickets,
      oversCompleted = newOvers,
      battingScorecard = updatedBatting,
      bowlingFigures = updatedBowling,
    )
    inningsList[currentInningsIndex] = updatedInnings

    val updatedMatch = match.copy(
      inningsList = inningsList,
      statusDetail = "Day 3, Session 2 - Yorkshire lead by ${(updatedTotalRuns + 348) - 286} runs",
      lastUpdatedTimestamp = System.currentTimeMillis(),
    )

    val updatedMatchesList = _matches.value.map { if (it.id == updatedMatch.id) updatedMatch else it }
    _matches.value = updatedMatchesList
    if (_selectedMatch.value?.id == updatedMatch.id) {
      _selectedMatch.value = updatedMatch
    }

    // Telemetry jitter (simulating real stream stats)
    val stream = _currentStream.value
    if (stream != null) {
      _currentStream.value = stream.copy(
        bitrateKbps = 5400 + Random.nextInt(-200, 300),
        liveViewers = stream.liveViewers + Random.nextInt(-10, 25),
      )
    }

    return ballEvent
  }

  // --- VIDEO PROVIDER ADAPTER IMPLEMENTATION ---
  override fun initializeStream(matchId: String, streamUrl: String) {
    _currentStreamState.value = StreamState.CONNECTING
    coroutineScope.launch {
      delay(800)
      _currentStreamState.value = StreamState.PLAYING
    }
  }

  override fun connect() {
    _currentStreamState.value = StreamState.CONNECTING
    coroutineScope.launch {
      delay(700)
      _currentStreamState.value = StreamState.PLAYING
    }
  }

  override fun disconnect() {
    _currentStreamState.value = StreamState.ENDED
  }

  override fun setQuality(quality: PlaybackQuality) {
    val s = _currentStream.value ?: return
    _currentStream.value = s.copy(
      quality = quality,
      bitrateKbps = when (quality) {
        PlaybackQuality.AUTO_1080P -> 5800
        PlaybackQuality.HD_720P -> 3200
        PlaybackQuality.SD_540P -> 1500
        PlaybackQuality.LOW_BANDWIDTH -> 128
      }
    )
  }

  override fun toggleLowBandwidthMode(enabled: Boolean) {
    if (enabled) {
      setQuality(PlaybackQuality.LOW_BANDWIDTH)
    } else {
      setQuality(PlaybackQuality.AUTO_1080P)
    }
    _userProfile.value = _userProfile.value.copy(lowBandwidthAudioOnly = enabled)
  }

  override fun adjustAudioSync(offsetMs: Long) {
    val s = _currentStream.value ?: return
    _currentStream.value = s.copy(audioSyncOffsetMs = offsetMs)
  }

  override fun seekDvr(positionSec: Long) {
    val s = _currentStream.value ?: return
    _currentStream.value = s.copy(
      currentDvrPositionSec = positionSec,
      isAtLiveEdge = (positionSec >= s.dvrLivePositionSec - 5)
    )
  }

  override fun returnToLiveEdge() {
    val s = _currentStream.value ?: return
    _currentStream.value = s.copy(
      currentDvrPositionSec = s.dvrLivePositionSec,
      isAtLiveEdge = true
    )
  }

  override fun simulateNetworkInterruption() {
    _currentStreamState.value = StreamState.RECONNECTING
    coroutineScope.launch {
      delay(2500)
      _currentStreamState.value = StreamState.PLAYING
    }
  }

  override fun recoverConnection() {
    _currentStreamState.value = StreamState.PLAYING
  }

  fun toggleMultiview() {
    _isMultiviewActive.value = !_isMultiviewActive.value
  }

  // User Profile & Entitlements
  fun toggleFavoriteCounty(countyId: String) {
    val cur = _userProfile.value.favoriteCountyIds.toMutableSet()
    if (cur.contains(countyId)) cur.remove(countyId) else cur.add(countyId)
    _userProfile.value = _userProfile.value.copy(favoriteCountyIds = cur)
  }

  fun updateTerritory(territory: Territory) {
    _userProfile.value = _userProfile.value.copy(selectedTerritory = territory)
  }

  fun updatePlan(plan: EntitlementPlan) {
    _userProfile.value = _userProfile.value.copy(currentPlan = plan)
  }

  fun toggleSavedMatch(matchId: String) {
    val cur = _userProfile.value.savedMatchIds.toMutableSet()
    if (cur.contains(matchId)) cur.remove(matchId) else cur.add(matchId)
    _userProfile.value = _userProfile.value.copy(savedMatchIds = cur)
  }

  // Club Portal Publishing
  fun publishClubBroadcast(config: BroadcastConfig) {
    val list = _publishedBroadcasts.value.toMutableList()
    list.removeAll { it.broadcastId == config.broadcastId }
    list.add(0, config)
    _publishedBroadcasts.value = list

    // Also reflect on public match if it matches
    val match = _matches.value.firstOrNull { it.id == config.matchId }
    if (match != null) {
      val updated = match.copy(
        hasVideo = true,
        streamId = config.broadcastId,
        status = if (config.isPublished) MatchStatus.LIVE else match.status,
      )
      _matches.value = _matches.value.map { if (it.id == updated.id) updated else it }
    }
  }

  // --- INITIAL DATA SEEDING ---
  private fun createInitialMatches(): List<Match> {
    // 1. Roses Match (Flagship First-Class)
    val match1 = Match(
      id = "match-01",
      competition = Competition.COUNTY_CHAMPIONSHIP_DIV1,
      roundNumber = 8,
      homeCountyId = "yorkshire",
      awayCountyId = "lancashire",
      venue = "Headingley, Leeds",
      scheduledDateText = "Today",
      scheduledTimeText = "11:00 BST",
      status = MatchStatus.LIVE,
      statusDetail = "Day 3, Session 2 - Yorkshire lead by 254 runs",
      tossText = "Yorkshire won the toss and elected to bat",
      dayNumber = 3,
      sessionNumber = 2,
      currentInningsIndex = 2,
      bonusPointsHome = BonusPoints(batting = 3, bowling = 3),
      bonusPointsAway = BonusPoints(batting = 2, bowling = 3),
      inningsList = listOf(
        Innings(
          inningsNumber = 1,
          teamId = "yorkshire",
          teamName = "Yorkshire 1st Innings",
          totalRuns = 348,
          wickets = 10,
          oversCompleted = 102.4,
          isAllOut = true,
          extras = Extras(8, 4, 3, 2),
          battingScorecard = listOf(
            BattingEntry("Adam Lyth", "c Jennings b Anderson", 48, 86, 7, 0),
            BattingEntry("Shan Masood", "c Salt b Hartley", 112, 178, 14, 2),
            BattingEntry("Joe Root", "b Anderson", 64, 102, 8, 0),
            BattingEntry("Jonny Bairstow", "lbw b Bohannon", 52, 70, 6, 1),
            BattingEntry("Harry Brook", "c & b Hartley", 38, 44, 4, 1),
            BattingEntry("Matthew Fisher", "not out", 16, 32, 2, 0),
          ),
          bowlingFigures = listOf(
            BowlingEntry("James Anderson", 24.0, 7, 62, 3),
            BowlingEntry("Tom Hartley", 28.4, 6, 88, 3),
            BowlingEntry("Josh Bohannon", 14.0, 2, 45, 2),
          ),
        ),
        Innings(
          inningsNumber = 2,
          teamId = "lancashire",
          teamName = "Lancashire 1st Innings",
          totalRuns = 286,
          wickets = 10,
          oversCompleted = 88.2,
          isAllOut = true,
          extras = Extras(6, 2, 4, 1),
          battingScorecard = listOf(
            BattingEntry("Keaton Jennings", "c Bairstow b Coad", 74, 140, 10, 0),
            BattingEntry("Phil Salt", "b Fisher", 31, 38, 5, 0),
            BattingEntry("Josh Bohannon", "c Root b Coad", 89, 162, 11, 1),
            BattingEntry("Tom Hartley", "lbw b Root", 24, 48, 3, 0),
          ),
          bowlingFigures = listOf(
            BowlingEntry("Ben Coad", 22.2, 5, 58, 4),
            BowlingEntry("Matthew Fisher", 20.0, 4, 64, 3),
            BowlingEntry("Joe Root", 12.0, 2, 38, 2),
          ),
        ),
        Innings(
          inningsNumber = 3,
          teamId = "yorkshire",
          teamName = "Yorkshire 2nd Innings",
          totalRuns = 192,
          wickets = 3,
          oversCompleted = 58.4,
          isAllOut = false,
          extras = Extras(5, 3, 2, 0),
          battingScorecard = listOf(
            BattingEntry("Adam Lyth", "lbw b Anderson", 36, 68, 5, 0),
            BattingEntry("Shan Masood", "c Salt b Hartley", 64, 110, 8, 1),
            BattingEntry("Joe Root", "not out", 78, 114, 9, 1, isNotOut = true, isCurrentBatter = true, isStriker = true),
            BattingEntry("Jonny Bairstow", "not out", 8, 18, 1, 0, isNotOut = true, isCurrentBatter = true, isStriker = false),
          ),
          bowlingFigures = listOf(
            BowlingEntry("James Anderson", 18.0, 4, 46, 2, isCurrentBowler = true),
            BowlingEntry("Tom Hartley", 16.4, 3, 54, 1),
            BowlingEntry("Josh Bohannon", 12.0, 2, 38, 0),
          ),
          fallOfWickets = listOf(
            FallOfWicket(1, 58, "Adam Lyth", 18.2),
            FallOfWicket(2, 165, "Shan Masood", 48.6),
          ),
          partnerships = listOf(
            Partnership("Adam Lyth", "Shan Masood", 58, 110),
            Partnership("Shan Masood", "Joe Root", 107, 184),
            Partnership("Joe Root", "Jonny Bairstow", 27, 44, isUnbroken = true),
          ),
        ),
      ),
    )

    // 2. Vitality T20 Blast: Surrey vs Somerset (Oval)
    val match2 = Match(
      id = "match-02",
      competition = Competition.T20_BLAST,
      roundNumber = 5,
      homeCountyId = "surrey",
      awayCountyId = "somerset",
      venue = "The Kia Oval, London",
      scheduledDateText = "Today",
      scheduledTimeText = "18:30 BST",
      status = MatchStatus.LIVE,
      statusDetail = "Somerset need 47 runs in 28 balls (Target: 189)",
      tossText = "Somerset won the toss and elected to field",
      dayNumber = 1,
      currentInningsIndex = 1,
      targetRuns = 189,
      requiredRunRate = 10.07,
      inningsList = listOf(
        Innings(
          inningsNumber = 1,
          teamId = "surrey",
          teamName = "Surrey",
          totalRuns = 188,
          wickets = 4,
          oversCompleted = 20.0,
          extras = Extras(2, 2, 6, 2),
          battingScorecard = listOf(
            BattingEntry("Rory Burns", "c Banton b Henry", 28, 18, 4, 1),
            BattingEntry("Dan Lawrence", "c Abell b Overton", 68, 42, 6, 4),
            BattingEntry("Sam Curran", "not out", 55, 34, 4, 3, isNotOut = true),
            BattingEntry("Ollie Pope", "c Banton b Leach", 22, 14, 2, 1),
          ),
          bowlingFigures = listOf(
            BowlingEntry("Matt Henry", 4.0, 0, 36, 1),
            BowlingEntry("Craig Overton", 4.0, 0, 42, 2),
            BowlingEntry("Jack Leach", 4.0, 0, 28, 1),
          ),
        ),
        Innings(
          inningsNumber = 2,
          teamId = "somerset",
          teamName = "Somerset",
          totalRuns = 142,
          wickets = 3,
          oversCompleted = 15.2,
          extras = Extras(1, 1, 4, 1),
          battingScorecard = listOf(
            BattingEntry("Tom Banton", "not out", 62, 38, 7, 3, isNotOut = true, isCurrentBatter = true, isStriker = true),
            BattingEntry("Tom Abell", "c Pope b Curran", 34, 26, 3, 1),
            BattingEntry("Craig Overton", "not out", 18, 11, 2, 1, isNotOut = true, isCurrentBatter = true, isStriker = false),
          ),
          bowlingFigures = listOf(
            BowlingEntry("Sam Curran", 3.2, 0, 28, 2, isCurrentBowler = true),
            BowlingEntry("Kemar Roach", 3.0, 0, 32, 1),
          ),
        ),
      ),
    )

    // 3. Essex vs Warwickshire (Chelmsford)
    val match3 = Match(
      id = "match-03",
      competition = Competition.COUNTY_CHAMPIONSHIP_DIV1,
      roundNumber = 8,
      homeCountyId = "essex",
      awayCountyId = "warwickshire",
      venue = "The Cloud County Ground, Chelmsford",
      scheduledDateText = "Today",
      scheduledTimeText = "11:00 BST",
      status = MatchStatus.LIVE,
      statusDetail = "Day 2, Session 3 - Essex 245 & 82/1; Warwickshire 198",
      dayNumber = 2,
      sessionNumber = 3,
      currentInningsIndex = 2,
      inningsList = listOf(
        Innings(
          inningsNumber = 1,
          teamId = "essex",
          teamName = "Essex 1st Innings",
          totalRuns = 245,
          wickets = 10,
          oversCompleted = 82.0,
          isAllOut = true,
          battingScorecard = listOf(
            BattingEntry("Tom Westley", "b Hannon-Dalby", 84, 150, 11, 0),
            BattingEntry("Paul Walter", "c Davies b Barnard", 62, 95, 7, 1),
          ),
          bowlingFigures = listOf(
            BowlingEntry("Oliver Hannon-Dalby", 21.0, 6, 48, 4),
            BowlingEntry("Ed Barnard", 18.0, 3, 52, 3),
          ),
        ),
        Innings(
          inningsNumber = 2,
          teamId = "warwickshire",
          teamName = "Warwickshire 1st Innings",
          totalRuns = 198,
          wickets = 10,
          oversCompleted = 66.4,
          isAllOut = true,
          battingScorecard = listOf(
            BattingEntry("Alex Davies", "b Porter", 54, 98, 8, 0),
            BattingEntry("Rob Yates", "c Cook b Porter", 42, 80, 5, 0),
          ),
          bowlingFigures = listOf(
            BowlingEntry("Jamie Porter", 19.4, 5, 48, 5),
            BowlingEntry("Sam Cook", 18.0, 6, 44, 4),
          ),
        ),
        Innings(
          inningsNumber = 3,
          teamId = "essex",
          teamName = "Essex 2nd Innings",
          totalRuns = 82,
          wickets = 1,
          oversCompleted = 26.0,
          battingScorecard = listOf(
            BattingEntry("Tom Westley", "not out", 41, 74, 5, 0, isNotOut = true),
          ),
        ),
      ),
    )

    // 4. Hampshire vs Sussex (Blast Derby)
    val match4 = Match(
      id = "match-04",
      competition = Competition.T20_BLAST,
      roundNumber = 5,
      homeCountyId = "hampshire",
      awayCountyId = "sussex",
      venue = "Utilita Bowl, Southampton",
      scheduledDateText = "Today",
      scheduledTimeText = "19:00 BST",
      status = MatchStatus.UPCOMING,
      statusDetail = "Match starts in 1 hour 45 mins",
      dayNumber = 1,
    )

    // 5. One-Day Cup: Notts Outlaws vs Durham
    val match5 = Match(
      id = "match-05",
      competition = Competition.ONE_DAY_CUP,
      roundNumber = 3,
      homeCountyId = "notts",
      awayCountyId = "durham",
      venue = "Trent Bridge, Nottingham",
      scheduledDateText = "Tomorrow",
      scheduledTimeText = "11:00 BST",
      status = MatchStatus.UPCOMING,
      statusDetail = "Scheduled start 11:00 BST",
      dayNumber = 1,
    )

    // 6. Middlesex vs Kent (Lord's)
    val match6 = Match(
      id = "match-06",
      competition = Competition.COUNTY_CHAMPIONSHIP_DIV2,
      roundNumber = 8,
      homeCountyId = "middlesex",
      awayCountyId = "kent",
      venue = "Lord's Cricket Ground, London",
      scheduledDateText = "Yesterday",
      scheduledTimeText = "11:00 BST",
      status = MatchStatus.COMPLETED,
      statusDetail = "Middlesex won by 6 wickets",
      dayNumber = 4,
    )

    return listOf(match1, match2, match3, match4, match5, match6)
  }

  private fun createInitialBallEvents(matchId: String): List<BallEvent> {
    return listOf(
      BallEvent("58.4", "James Anderson", "Joe Root", 4, isBoundaryFour = true, commentary = "GLORIOUS! Joe Root plays that signature late dab between slip and gully, fine as you like to the third man rope for FOUR!", timestampText = "1 min ago"),
      BallEvent("58.3", "James Anderson", "Joe Root", 0, commentary = "Anderson pitches on off, nip-backer into Root's front pad, strangled appeal turned down by umpire Gough.", timestampText = "2 mins ago"),
      BallEvent("58.2", "James Anderson", "Joe Root", 1, commentary = "Pushed with soft hands wide of mid-on for an easy single. Root into the late 70s.", timestampText = "2 mins ago"),
      BallEvent("58.1", "James Anderson", "Jonny Bairstow", 1, commentary = "Tucked behind square leg, Bairstow gets off strike promptly.", timestampText = "3 mins ago"),
      BallEvent("57.6", "Tom Hartley", "Joe Root", 0, commentary = "Drifting into the pads, Root works it to short mid-wicket. Maiden over complete.", timestampText = "4 mins ago", isMaidenOverEnd = true),
      BallEvent("57.5", "Tom Hartley", "Joe Root", 0, commentary = "Pushed through flatter, defended out off the back foot.", timestampText = "4 mins ago"),
      BallEvent("57.4", "Tom Hartley", "Shan Masood", 0, isWicket = true, wicketDetail = "c Salt b Hartley", commentary = "WICKET! The captain falls! Masood attempts the reverse sweep, skews it straight to Phil Salt at backward point who takes a sharp catch!", timestampText = "5 mins ago"),
      BallEvent("57.3", "Tom Hartley", "Shan Masood", 4, isBoundaryFour = true, commentary = "FOUR! Masood uses his feet, gets to the pitch and drives through extra cover with pure elegance.", timestampText = "5 mins ago"),
    )
  }

  private fun createInitialHighlights(): List<HighlightItem> {
    return listOf(
      HighlightItem(
        id = "hl-01",
        title = "Shan Masood 112: Masterclass in County Championship Division One",
        countyId = "yorkshire",
        competitionName = "County Championship",
        durationText = "08:45",
        type = HighlightType.BOUNDARIES_CENTURY,
        publishedDateText = "2 hours ago",
        viewsCount = "14.2k",
        description = "Every boundary and landmark from Shan Masood's commanding century against Lancashire at Headingley.",
      ),
      HighlightItem(
        id = "hl-02",
        title = "Dan Lawrence 68 off 42 Balls — Explosive Surrey Blast Highlights",
        countyId = "surrey",
        competitionName = "Vitality T20 Blast",
        durationText = "05:12",
        type = HighlightType.BOUNDARIES_CENTURY,
        publishedDateText = "1 day ago",
        viewsCount = "28.5k",
        description = "Four towering sixes into the Peter May Stand as Dan Lawrence lights up The Kia Oval.",
      ),
      HighlightItem(
        id = "hl-03",
        title = "Jamie Porter 5 for 48 vs Warwickshire at Chelmsford",
        countyId = "essex",
        competitionName = "County Championship",
        durationText = "06:30",
        type = HighlightType.WICKETS_REEL,
        publishedDateText = "Today",
        viewsCount = "9.8k",
        description = "Relentless swing and seam bowling from Essex's spearhead under cloudy Essex skies.",
      ),
      HighlightItem(
        id = "hl-04",
        title = "Full Day 2 Replay: Yorkshire vs Lancashire (Roses Match)",
        countyId = "yorkshire",
        competitionName = "County Championship",
        durationText = "5h 40m",
        type = HighlightType.FULL_REPLAY,
        publishedDateText = "Yesterday",
        viewsCount = "42.1k",
        description = "Complete uninterrupted ball-by-ball broadcast from Day 2 of the historic Roses clash.",
      ),
      HighlightItem(
        id = "hl-05",
        title = "Wisden Tactical Feature: The Art of County Seam Bowling in May",
        countyId = "notts",
        competitionName = "Wisden Analysis",
        durationText = "12:15",
        type = HighlightType.INTERVIEW_ANALYSIS,
        publishedDateText = "3 days ago",
        viewsCount = "18.3k",
        description = "Analysis of dukes ball wobble-seam physics across English county surfaces with Peter Moores.",
      ),
    )
  }

  private fun createInitialArticles(): List<EditorialArticle> {
    return listOf(
      EditorialArticle(
        id = "art-01",
        title = "The Roses Match: Where Time Stands Still and Every Ball Matters",
        subtitle = "From Boycott and Trueman to Root and Anderson: why Yorkshire versus Lancashire remains the soul of English cricket.",
        category = "Wisden Column",
        author = "Sir Lawrence Booth",
        authorRole = "Wisden Editor-at-Large",
        readTimeMinutes = 5,
        publishedTimeText = "This morning",
        contentParagraphs = listOf(
          "There is no quiet corner at Headingley on day three of a Roses match. The air smells of warm pie crusts, freshly cut outfield and the sharp tang of Yorkshire pride.",
          "In an era where franchise tournaments sprint through three-hour spectacles, the four-day County Championship match provides that irreplaceable sensation of a grand Victorian novel unfolding chapter by chapter.",
          "Joe Root's cover drive off James Anderson was not merely a boundary; it was a conversation between two masters who have carried English cricket through the triumphs and heartbreaks of the modern era.",
          "As the light softens over the Western Terrace, one is reminded why county cricket is irreplaceable: it belongs not to private equity, but to the members who sit in deckchairs scorecards in hand.",
        ),
        pullQuote = "The four-day game is not merely sport; it is an irreplaceable English summer ritual where every maiden over tells a story.",
      ),
      EditorialArticle(
        id = "art-02",
        title = "The Ground Guide: Canterbury's Lime Tree & The St Lawrence Aura",
        subtitle = "Inside one of the most idyllic cathedral-city county grounds in world cricket.",
        category = "Ground Guide",
        author = "Clara Hetherington",
        authorRole = "County Heritage Correspondent",
        readTimeMinutes = 4,
        publishedTimeText = "Yesterday",
        contentParagraphs = listOf(
          "To walk into The Spitfire Ground at St Lawrence is to step into a watercolour of Kentish summer. The lime tree inside the boundary may have fallen and been replanted, but the magic remains intact.",
          "The pavilion balcony, draped in Kent cherry red and navy, has hosted everyone from Frank Woolley to Colin Cowdrey and now Daniel Bell-Drummond.",
        ),
      ),
      EditorialArticle(
        id = "art-03",
        title = "T20 Blast vs Championship: Why the County Calendar Needs Both",
        subtitle = "How English county clubs balance financial lifeblood with the red-ball pedigree that underpins test success.",
        category = "Tactical Analysis",
        author = "Marcus Trescothick",
        authorRole = "High Performance Analyst",
        readTimeMinutes = 6,
        publishedTimeText = "2 days ago",
        contentParagraphs = listOf(
          "On Friday night 25,000 roar at The Oval with pyrotechnics and thumping boundaries; on Sunday morning 3,000 connoisseurs watch the red ball swing through the dew at Taunton.",
          "Both are authentic. Both are county cricket.",
        ),
      ),
    )
  }

  private fun createInitialBroadcasts(): List<BroadcastConfig> {
    return listOf(
      BroadcastConfig(
        broadcastId = "bc-yor-01",
        countyId = "yorkshire",
        matchId = "match-01",
        matchTitle = "Yorkshire vs Lancashire — County Championship Div 1",
        providerType = VideoProviderType.CLUB_HOSTED,
        primaryIngestUrl = "rtmp://ingest.yorkshireccc.com/live/headingley-cam01",
        backupIngestUrl = "rtmp://backup.yorkshireccc.com/live/headingley-cam02",
        streamKeyOrEmbed = "stream_key_yor_2026_cc01",
        scheduledStartTime = "11:00 BST",
        allowedTerritories = listOf(Territory.UK_IRELAND, Territory.REST_OF_WORLD),
        requiredPlan = EntitlementPlan.FREE_SUPPORTER,
        isAudioChecked = true,
        isVideoChecked = true,
        isRightsConfirmed = true,
        isPublished = true,
        health = StreamHealth(
          isLive = true,
          inputBitrateKbps = 5820,
          currentFps = 50,
          droppedFramesPercent = 0.05,
          audioLevelDb = -12.4,
          activeViewers = 18450,
        ),
      ),
      BroadcastConfig(
        broadcastId = "bc-sur-01",
        countyId = "surrey",
        matchId = "match-02",
        matchTitle = "Surrey vs Somerset — Vitality T20 Blast",
        providerType = VideoProviderType.PLATFORM_INTEGRATED,
        primaryIngestUrl = "rtmp://ingest.countycricketlive.co.uk/surrey/oval-cam01",
        backupIngestUrl = "rtmp://backup.countycricketlive.co.uk/surrey/oval-cam02",
        streamKeyOrEmbed = "stream_key_sur_blast_05",
        scheduledStartTime = "18:30 BST",
        allowedTerritories = listOf(Territory.UK_IRELAND, Territory.REST_OF_WORLD, Territory.NORTH_AMERICA),
        requiredPlan = EntitlementPlan.COUNTY_CLUB_PASS,
        isAudioChecked = true,
        isVideoChecked = true,
        isRightsConfirmed = true,
        isPublished = true,
        health = StreamHealth(
          isLive = true,
          inputBitrateKbps = 6100,
          currentFps = 50,
          droppedFramesPercent = 0.02,
          audioLevelDb = -14.0,
          activeViewers = 24100,
        ),
      ),
    )
  }

  companion object {
    @Volatile
    private var instance: CountyCricketRepository? = null

    fun getInstance(): CountyCricketRepository {
      return instance ?: synchronized(this) {
        instance ?: CountyCricketRepository().also { instance = it }
      }
    }
  }
}
