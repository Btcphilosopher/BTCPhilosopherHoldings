package com.example.data.adapter

import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface CricketDataAdapter {
  val isLiveSimulationActive: Boolean
  fun getMatches(): List<Match>
  fun getMatch(matchId: String): Match?
  fun getLiveMatchFlow(): StateFlow<Match?>
  fun getRecentBallEvents(matchId: String): List<BallEvent>
  fun getStandings(competition: Competition): List<DivisionStanding>
  fun toggleSimulation(active: Boolean)
  fun stepSingleBall(): BallEvent?
}
