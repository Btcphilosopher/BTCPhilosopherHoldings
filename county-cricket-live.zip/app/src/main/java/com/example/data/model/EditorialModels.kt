package com.example.data.model

enum class HighlightType(val label: String) {
  FULL_REPLAY("Full Match Replay"),
  DAY_HIGHLIGHTS("Day Recap & Best Moments"),
  WICKETS_REEL("Every Wicket Reel"),
  BOUNDARIES_CENTURY("Centuries & Boundaries"),
  INTERVIEW_ANALYSIS("Captain & Coach Interview"),
  HISTORIC_CLASSIC("Wisden Historic Archive"),
}

data class HighlightItem(
  val id: String,
  val title: String,
  val countyId: String,
  val competitionName: String,
  val durationText: String,
  val type: HighlightType,
  val publishedDateText: String,
  val viewsCount: String,
  val description: String,
  val videoUrl: String = "",
)

data class EditorialArticle(
  val id: String,
  val title: String,
  val subtitle: String,
  val category: String, // "Wisden Column", "Match Report", "County Feature", "Ground Guide"
  val author: String,
  val authorRole: String,
  val readTimeMinutes: Int,
  val publishedTimeText: String,
  val contentParagraphs: List<String>,
  val pullQuote: String? = null,
)

data class UserProfile(
  val id: String = "supporter-001",
  val name: String = "Cricket Supporter",
  val email: String = "supporter@countycricketlive.co.uk",
  val favoriteCountyIds: Set<String> = setOf("yorkshire", "surrey"),
  val currentPlan: EntitlementPlan = EntitlementPlan.ALL_COUNTY_PASS,
  val selectedTerritory: Territory = Territory.UK_IRELAND,
  val lowBandwidthAudioOnly: Boolean = false,
  val audioCommentarySyncDelaySec: Int = 0,
  val savedMatchIds: Set<String> = setOf("match-01", "match-02"),
  val pushMatchStartAlerts: Boolean = true,
  val pushWicketsAlerts: Boolean = true,
)
