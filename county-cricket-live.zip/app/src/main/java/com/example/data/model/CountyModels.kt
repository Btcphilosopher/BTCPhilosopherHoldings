package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class County(
  val id: String,
  val name: String,
  val shortName: String,
  val nickname: String,
  val primaryColor: Color,
  val secondaryColor: Color,
  val crestSymbol: String, // Emoji or heraldic symbol representation
  val homeGround: String,
  val city: String,
  val establishedYear: Int,
  val championshipTitles: Int,
  val blastTitles: Int,
  val oneDayTitles: Int,
  val description: String,
  val captain: String,
  val headCoach: String,
  val officialTicketUrl: String,
  val socialHandle: String,
  val squad: List<Player>,
)

data class Player(
  val id: String,
  val name: String,
  val role: PlayerRole,
  val battingStyle: String,
  val bowlingStyle: String,
  val squadNumber: Int,
  val isCaptain: Boolean = false,
  val matchesPlayed: Int = 0,
  val totalRuns: Int = 0,
  val highscore: String = "",
  val wickets: Int = 0,
  val bestBowling: String = "",
)

enum class PlayerRole {
  TOP_ORDER_BATTER,
  MIDDLE_ORDER_BATTER,
  WICKET_KEEPER_BATTER,
  ALL_ROUNDER,
  FAST_BOWLER,
  SPIN_BOWLER,
}

data class Venue(
  val id: String,
  val name: String,
  val countyName: String,
  val capacity: String,
  val endNames: Pair<String, String>,
  val established: Int,
  val pitchCharacteristics: String,
)
