package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Competition
import com.example.data.repository.CountyCricketRepository
import com.example.data.repository.CountyDatasets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("County Cricket Live", appName)
  }

  @Test
  fun `verify all 18 counties loaded`() {
    val counties = CountyDatasets.allCounties
    assertEquals(18, counties.size)
    assertNotNull(counties.firstOrNull { it.id == "yorkshire" })
    assertNotNull(counties.firstOrNull { it.id == "surrey" })
    assertNotNull(counties.firstOrNull { it.id == "lancashire" })
  }

  @Test
  fun `verify repository initial matches and standings`() {
    val repository = CountyCricketRepository.getInstance()
    val matches = repository.getMatches()
    assertTrue(matches.isNotEmpty())

    val flagship = repository.getMatch("match-01")
    assertNotNull(flagship)
    assertEquals("yorkshire", flagship?.homeCountyId)

    val standings = repository.getStandings(Competition.COUNTY_CHAMPIONSHIP_DIV1)
    assertTrue(standings.isNotEmpty())
  }
}
