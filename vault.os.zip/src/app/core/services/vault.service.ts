import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import {
  VaultObject,
  Collection,
  TimescapeEvent,
  TimeCapsule,
  VaultPost,
  TokenState,
  TokenTransaction,
  AuditEvent,
  SystemTwinVitals,
  AIPermission,
  IntegrityAuditRecord,
} from '../models/vault.model';

export interface TransferResponse {
  success: boolean;
  transaction: TokenTransaction;
  tokenState: TokenState;
}

export interface ArchiveAuditResponse {
  success: boolean;
  record: IntegrityAuditRecord;
}

export interface CorruptionRecoveryResponse {
  success: boolean;
  message: string;
  affectedObjectId: string;
  repairedFrom: string;
  verifiedSha256: string;
}

export interface AIPolicyResponse {
  policy: {
    permission: AIPermission;
    loggingRequired: boolean;
    lastUpdated: string;
  };
}

export interface AISearchResponse {
  query: string;
  structuredFilter: {
    type?: string;
    year?: number;
    keywords?: string[];
    explanation?: string;
  };
  results: VaultObject[];
  provenance: string;
  source: string;
}

@Injectable({
  providedIn: 'root',
})
export class VaultService {
  private http = inject(HttpClient);

  // Reactive State Signals
  vitals = signal<SystemTwinVitals | null>(null);
  objects = signal<VaultObject[]>([]);
  selectedObject = signal<VaultObject | null>(null);
  collections = signal<Collection[]>([]);
  timescapeEvents = signal<TimescapeEvent[]>([]);
  timeCapsules = signal<TimeCapsule[]>([]);
  posts = signal<VaultPost[]>([]);
  tokenState = signal<TokenState | null>(null);
  tokenLedger = signal<TokenTransaction[]>([]);
  auditEvents = signal<AuditEvent[]>([]);
  aiPolicy = signal<{ permission: AIPermission; loggingRequired: boolean } | null>(null);
  isLoading = signal<boolean>(false);
  activeTab = signal<string>('dashboard');

  // Load all initial state
  loadAll(): void {
    this.fetchVitals().subscribe();
    this.fetchObjects().subscribe();
    this.fetchCollections().subscribe();
    this.fetchTimescape().subscribe();
    this.fetchTimeCapsules().subscribe();
    this.fetchPosts().subscribe();
    this.fetchTokens().subscribe();
    this.fetchAuditEvents().subscribe();
    this.fetchAIPolicy().subscribe();
  }

  fetchVitals(): Observable<SystemTwinVitals> {
    return this.http.get<SystemTwinVitals>('/api/v1/vitals').pipe(
      tap((data) => this.vitals.set(data))
    );
  }

  fetchObjects(params?: { type?: string; collectionId?: string; search?: string; year?: number }): Observable<{ objects: VaultObject[]; total: number }> {
    this.isLoading.set(true);
    const httpParams: Record<string, string> = {};
    if (params?.type) httpParams['type'] = params.type;
    if (params?.collectionId) httpParams['collectionId'] = params.collectionId;
    if (params?.search) httpParams['search'] = params.search;
    if (params?.year) httpParams['year'] = String(params.year);

    return this.http.get<{ objects: VaultObject[]; total: number }>('/api/v1/objects', { params: httpParams }).pipe(
      tap((res) => {
        this.objects.set(res.objects);
        this.isLoading.set(false);
      })
    );
  }

  fetchObject(id: string): Observable<VaultObject> {
    return this.http.get<VaultObject>(`/api/v1/objects/${id}`).pipe(
      tap((obj) => this.selectedObject.set(obj))
    );
  }

  ingestObject(payload: Partial<VaultObject> & { captureDate?: string }): Observable<{ success: boolean; object: VaultObject }> {
    return this.uploadObject({
      filename: payload.filename || 'Master_Asset.bin',
      mimeType: payload.mimeType,
      type: payload.type,
      humanDescription: payload.humanDescription,
      tags: payload.tags,
      collectionIds: payload.collectionIds,
      timescapeYear: payload.captureDate ? new Date(payload.captureDate).getFullYear() : 2026,
    });
  }

  uploadObject(payload: {
    filename: string;
    mimeType?: string;
    type?: string;
    rawData?: string;
    humanDescription?: string;
    tags?: string[];
    collectionIds?: string[];
    timescapeYear?: number;
    timescapeMonth?: string;
  }): Observable<{ success: boolean; object: VaultObject }> {
    return this.http.post<{ success: boolean; object: VaultObject }>('/api/v1/objects/upload', payload).pipe(
      tap((res) => {
        if (res.success && res.object) {
          this.objects.update((list) => [res.object, ...list]);
          this.fetchVitals().subscribe();
          this.fetchAuditEvents().subscribe();
          this.fetchTimescape().subscribe();
        }
      })
    );
  }

  fetchCollections(): Observable<{ collections: Collection[] }> {
    return this.http.get<{ collections: Collection[] }>('/api/v1/collections').pipe(
      tap((res) => this.collections.set(res.collections))
    );
  }

  createCollection(payload: Partial<Collection>): Observable<Collection> {
    return this.http.post<Collection>('/api/v1/collections', payload).pipe(
      tap((newCol) => this.collections.update((cols) => [newCol, ...cols]))
    );
  }

  fetchTimescape(): Observable<{ events: TimescapeEvent[]; availableYears: number[] }> {
    return this.http.get<{ events: TimescapeEvent[]; availableYears: number[] }>('/api/v1/timescape').pipe(
      tap((res) => this.timescapeEvents.set(res.events))
    );
  }

  createTimescapeEvent(payload: Partial<TimescapeEvent>): Observable<TimescapeEvent> {
    return this.http.post<TimescapeEvent>('/api/v1/timescape/event', payload).pipe(
      tap((evt) => this.timescapeEvents.update((evts) => [evt, ...evts]))
    );
  }

  fetchTimeCapsules(): Observable<{ capsules: TimeCapsule[] }> {
    return this.http.get<{ capsules: TimeCapsule[] }>('/api/v1/time-capsules').pipe(
      tap((res) => this.timeCapsules.set(res.capsules))
    );
  }

  sealTimeCapsule(payload: {
    title: string;
    description: string;
    openDate: string;
    enforcementType: string;
    recipientEmails: string[];
    selectedObjectIds: string[];
  }): Observable<TimeCapsule> {
    return this.http.post<TimeCapsule>('/api/v1/time-capsules', payload).pipe(
      tap((capsule) => {
        this.timeCapsules.update((list) => [capsule, ...list]);
        this.fetchVitals().subscribe();
        this.fetchAuditEvents().subscribe();
        this.fetchTimescape().subscribe();
      })
    );
  }

  fetchPosts(): Observable<{ posts: VaultPost[] }> {
    return this.http.get<{ posts: VaultPost[] }>('/api/v1/posts').pipe(
      tap((res) => this.posts.set(res.posts))
    );
  }

  createPost(payload: {
    text: string;
    visibility: string;
    tags?: string[];
    attachedObjectIds?: string[];
    tokenGatedRequiredVlt?: number;
  }): Observable<VaultPost> {
    return this.http.post<VaultPost>('/api/v1/posts', payload).pipe(
      tap((post) => {
        this.posts.update((list) => [post, ...list]);
        this.fetchAuditEvents().subscribe();
      })
    );
  }

  fetchTokens(): Observable<{ token: TokenState; ledger: TokenTransaction[] }> {
    return this.http.get<{ token: TokenState; ledger: TokenTransaction[] }>('/api/v1/tokens').pipe(
      tap((res) => {
        this.tokenState.set(res.token);
        this.tokenLedger.set(res.ledger);
      })
    );
  }

  transferTokens(to: string, amount: number, reason: string): Observable<TransferResponse> {
    return this.http.post<TransferResponse>('/api/v1/tokens/transfer', { to, amount, reason }).pipe(
      tap((res) => {
        if (res.success) {
          this.fetchTokens().subscribe();
          this.fetchVitals().subscribe();
          this.fetchAuditEvents().subscribe();
        }
      })
    );
  }

  runArchiveAudit(auditType: 'SAMPLE' | 'DEEP' | 'FULL_ARCHIVE'): Observable<ArchiveAuditResponse> {
    return this.http.post<ArchiveAuditResponse>('/api/v1/archive/audit', { auditType }).pipe(
      tap(() => {
        this.fetchVitals().subscribe();
        this.fetchAuditEvents().subscribe();
      })
    );
  }

  simulateCorruptionRecovery(): Observable<CorruptionRecoveryResponse> {
    return this.http.post<CorruptionRecoveryResponse>('/api/v1/archive/simulate-corruption-recovery', {}).pipe(
      tap(() => {
        this.fetchObjects().subscribe();
        this.fetchVitals().subscribe();
        this.fetchAuditEvents().subscribe();
      })
    );
  }

  fetchAuditEvents(): Observable<{ events: AuditEvent[] }> {
    return this.http.get<{ events: AuditEvent[] }>('/api/v1/audit/events').pipe(
      tap((res) => this.auditEvents.set(res.events))
    );
  }

  fetchAIPolicy(): Observable<AIPolicyResponse> {
    return this.http.get<AIPolicyResponse>('/api/v1/ai/policy').pipe(
      tap((res) => this.aiPolicy.set(res.policy))
    );
  }

  updateAIPolicy(permission: AIPermission): Observable<{ success: boolean; permission: AIPermission }> {
    return this.http.post<{ success: boolean; permission: AIPermission }>('/api/v1/ai/policy', { permission }).pipe(
      tap(() => {
        this.fetchAIPolicy().subscribe();
        this.fetchVitals().subscribe();
        this.fetchAuditEvents().subscribe();
      })
    );
  }

  naturalSearchAI(query: string): Observable<AISearchResponse> {
    return this.http.post<AISearchResponse>('/api/v1/ai/natural-search', { query });
  }

  analyzeObjectAI(objectId: string, analysisType: string): Observable<{
    success: boolean;
    analysis: string;
    durabilityScore: number;
    recommendations: string[];
  }> {
    return this.http.post<{
      success: boolean;
      analysis: string;
      durabilityScore: number;
      recommendations: string[];
    }>('/api/v1/ai/analyze-object', { objectId, analysisType }).pipe(
      tap(() => this.fetchAuditEvents().subscribe())
    );
  }

  downloadExportVault(): void {
    window.location.href = '/api/v1/export/vault';
  }
}
