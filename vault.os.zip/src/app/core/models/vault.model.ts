export type MediaType = 'video' | 'audio' | 'image' | 'document' | 'archive' | 'data';
export type StorageClass = 'archive' | 'hot' | 'cold' | 'offline';
export type ArchiveStatus = 'verified' | 'unverified' | 'corrupted' | 'restoring' | 'migrated';
export type EncryptionType = 'server_side' | 'client_side' | 'none';
export type PostVisibility = 'PRIVATE' | 'FOLLOWERS' | 'SELECTED_USERS' | 'TOKEN_GATED' | 'UNLISTED' | 'PUBLIC';
export type CapsuleEnforcement = 'SOFTWARE_ENFORCED' | 'CRYPTOGRAPHICALLY_ENFORCED' | 'USER_ENFORCED';
export type ProvenanceType = 'MEASURED' | 'DERIVED' | 'ESTIMATED' | 'MODELLED' | 'USER_PROVIDED' | 'AI_GENERATED';
export type AIPermission = 'ALLOW_AI_ANALYSIS' | 'DENY_AI_ANALYSIS' | 'ALLOW_METADATA_ONLY' | 'ALLOW_SELECTED_COLLECTIONS';

export interface StorageLocation {
  id: string;
  name: string; // 'Primary NVMe', 'Replica A (Zurich)', 'Replica B (Reykjavik)', 'Cold Archive LTO-9 Tape'
  type: 'LocalFilesystem' | 'S3' | 'S3-compatible' | 'Google Cloud Storage' | 'Cold Archive';
  isHealthy: boolean;
  lastChecked: string;
  bytesStored: number;
}

export interface ObjectVersion {
  version: number;
  sha256: string;
  sizeBytes: number;
  createdAt: string;
  modifiedBy: string;
  changeSummary: string;
}

export interface VideoMetadata {
  codec: string;
  resolution: string; // e.g., '3840x2160 (4K)'
  frameRate: number; // e.g. 60
  durationSeconds: number;
  audioCodec?: string;
  bitrateKbps?: number;
  resolutionsAvailable?: ('360p' | '480p' | '720p' | '1080p' | '1440p' | '2160p')[];
  subtitles?: { language: string; label: string; src: string }[];
  chapters?: { time: number; title: string }[];
  thumbnailUrl: string;
}

export interface AudioMetadata {
  codec: string; // e.g. 'FLAC (24-bit/96kHz)', 'Opus 256kbps'
  durationSeconds: number;
  bitrateKbps: number;
  sampleRateHz: number;
  channels?: number;
  artist?: string;
  album?: string;
  trackTitle?: string;
  genre?: string;
  year?: number;
  waveform?: number[]; // 0..100 amplitude values for waveform canvas
  transcript?: string;
  coverArtUrl?: string;
}

export interface DocumentMetadata {
  pageCount: number;
  formatVersion: string;
  extractedTextSnippet?: string;
  hasOCR: boolean;
}

export interface VaultObject {
  id: string;
  ownerId: string;
  ownerName: string;
  type: MediaType;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  sha256: string;
  createdAt: string;
  ingestedAt: string;
  modifiedAt: string;
  captureDate?: string;
  archiveStatus: ArchiveStatus;
  storageClass: StorageClass;
  encryption: EncryptionType;
  humanDescription: string;
  tags: string[];
  provenance: {
    type: ProvenanceType;
    source: string;
    timestamp: string;
    confidence?: number;
  };
  storageLocations: {
    locationId: string;
    locationName: string;
    status: 'synced' | 'degraded' | 'corrupted';
    verifiedAt: string;
  }[];
  replicasCount: number;
  versions: ObjectVersion[];
  videoInfo?: VideoMetadata;
  audioInfo?: AudioMetadata;
  documentInfo?: DocumentMetadata;
  collectionIds: string[];
  timescapeYear: number;
  timescapeMonth: string;
  timescapeDate: string;
  isTokenGated?: boolean;
  minTokenRequired?: number;
  downloadUrl?: string;
  streamingUrl?: string;
}

export interface AISearchResult {
  query: string;
  structuredFilter: {
    type?: string | null;
    year?: number | null;
    keywords?: string[];
    tokenGatedOnly?: boolean;
    explanation?: string;
  };
  results: VaultObject[];
  provenance: string;
  source: string;
}

export type AuditRecord = IntegrityAuditRecord;

export interface Collection {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  itemCount: number;
  totalSizeBytes: number;
  coverImageUrl?: string;
  isPublished: boolean;
  publishType: 'PRIVATE_LINK' | 'TOKEN_GATED' | 'PUBLIC';
  tokenGateRequirement?: number; // e.g. 100 VLT
  tags: string[];
  itemIds: string[];
}

export interface TimescapeEvent {
  id: string;
  year: number;
  month: string;
  date: string;
  title: string;
  summary: string;
  category: 'media' | 'document' | 'post' | 'project' | 'capsule' | 'token' | 'memory';
  location?: string;
  people?: string[];
  objectId?: string;
  objectType?: MediaType;
  thumbnailUrl?: string;
  importance: 'high' | 'medium' | 'normal';
}

export interface TimeCapsule {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  openDate: string;
  isSealed: boolean;
  enforcementType: CapsuleEnforcement;
  itemCount: number;
  totalSizeBytes: number;
  manifestSha256: string;
  replicas: number;
  archiveStatus: 'PERMANENT' | 'VERIFIED' | 'STAGED';
  categoriesCount: {
    photos: number;
    videos: number;
    audio: number;
    documents: number;
    posts: number;
  };
  recipientEmails: string[];
  manifestItems: {
    filename: string;
    type: MediaType;
    sha256: string;
    sizeBytes: number;
  }[];
}

export interface VaultPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  timestamp: string;
  text: string;
  visibility: PostVisibility;
  collectionId?: string;
  tags: string[];
  replyToId?: string;
  version: number;
  editHistory: { timestamp: string; text: string }[];
  attachedObjects: VaultObject[];
  reactions: Record<string, number>;
  repliesCount: number;
  tokenGatedRequiredVlt?: number;
}

export interface TokenState {
  name: string;
  symbol: string;
  decimals: number;
  issuer: string;
  totalSupply: number;
  circulating: number;
  locked: number;
  treasury: number;
  userBalance: number;
  stateRootHash: string;
}

export interface TokenTransaction {
  id: string;
  timestamp: string;
  type: 'ISSUE' | 'TRANSFER' | 'LOCK' | 'UNLOCK' | 'BURN' | 'GRANT' | 'REVOKE';
  from: string;
  to: string;
  amount: number;
  reason: string;
  previousStateHash: string;
  newStateHash: string;
  signature: string;
}

export interface ArchiveManifest {
  manifestId: string;
  generatedAt: string;
  vaultName: string;
  vaultId: string;
  totalObjects: number;
  totalSizeBytes: number;
  overallHealth: 'HEALTHY' | 'WARNING' | 'DEGRADED' | 'CRITICAL';
  sha256RootTree: string;
  lastDeepVerification: string;
  activeReplicationFactor: number;
}

export interface IntegrityAuditRecord {
  id: string;
  timestamp: string;
  auditType: 'SAMPLE' | 'DEEP' | 'FULL_ARCHIVE' | 'MANUAL';
  objectsScanned: number;
  objectsVerified: number;
  mismatchesDetected: number;
  autoRepairedFromReplica: number;
  status: 'PASSED' | 'REPAIRED' | 'FAILED';
  durationMs: number;
  details: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  action: string;
  category: 'SECURITY' | 'STORAGE' | 'STREAMING' | 'INTEGRITY' | 'TOKEN' | 'AI' | 'ARCHIVE';
  actor: string;
  targetId?: string;
  status: 'SUCCESS' | 'WARNING' | 'ALERT';
  sha256Hash: string;
  details: string;
}

export interface SystemTwinVitals {
  totalStorageBytes: number;
  usedStorageBytes: number;
  storageUsagePercent: number;
  totalObjects: number;
  archivedObjects: number;
  verifiedObjects: number;
  corruptedObjects: number;
  activeReplicasCount: number;
  lastFullAudit: string;
  systemHealth: 'HEALTHY' | 'WARNING' | 'DEGRADED';
  backupStatus: 'VERIFIED' | 'RUNNING' | 'PENDING';
  vaultStatus: 'OPERATIONAL' | 'LOCKDOWN';
  activeStreamsCount: number;
  tokenSupply: number;
  userVltBalance: number;
  totalPostsCount: number;
  timescapeYearsSpan: string;
  aiPermission: AIPermission;
}
