import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VitalsBar } from './components/vitals-bar/vitals-bar';
import { SidebarNav } from './components/sidebar-nav/sidebar-nav';
import { Dashboard } from './components/dashboard/dashboard';
import { VaultExplorer } from './components/vault-explorer/vault-explorer';
import { MediaStudio } from './components/media-studio/media-studio';
import { CollectionsView } from './components/collections-view/collections-view';
import { Timescape } from './components/timescape/timescape';
import { TimeCapsules } from './components/time-capsules/time-capsules';
import { Microblog } from './components/microblog/microblog';
import { TokenEngine } from './components/token-engine/token-engine';
import { ArchiveIntegrity } from './components/archive-integrity/archive-integrity';
import { AiStudio } from './components/ai-studio/ai-studio';
import { ExportSovereignty } from './components/export-sovereignty/export-sovereignty';
import { IngestModal } from './components/ingest-modal/ingest-modal';
import { ObjectInspector } from './components/object-inspector/object-inspector';
import { VaultService } from './core/services/vault.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    VitalsBar,
    SidebarNav,
    Dashboard,
    VaultExplorer,
    MediaStudio,
    CollectionsView,
    Timescape,
    TimeCapsules,
    Microblog,
    TokenEngine,
    ArchiveIntegrity,
    AiStudio,
    ExportSovereignty,
    IngestModal,
    ObjectInspector,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  vaultService = inject(VaultService);

  activeNav = signal<string>('dashboard');
  showIngestModal = signal<boolean>(false);
  inspectedObjectId = signal<string | null>(null);

  onNavigate(view: string): void {
    this.activeNav.set(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  inspectObject(id: string): void {
    this.inspectedObjectId.set(id);
  }

  closeInspector(): void {
    this.inspectedObjectId.set(null);
  }
}

