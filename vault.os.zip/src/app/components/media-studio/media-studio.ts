import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { VaultObject } from '../../core/models/vault.model';

@Component({
  selector: 'app-media-studio',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="media-studio-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-rose-400">play_circle</span>
            <span class="text-xs font-semibold text-rose-400 uppercase tracking-wider">MEDIA ENGINE & STREAMING STUDIO</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            4K CINEMA & HI-RES AUDIO STUDIO
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Direct streaming from private NVMe master archives with HTTP Range requests, multi-resolution laddering, and uncompressed 24-bit 96kHz acoustic waveform visualization.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <!-- Switcher -->
          <div class="flex items-center bg-[#12161f] rounded-lg border border-[#232a38] p-0.5 text-xs">
            <button
              id="btn-switch-video"
              type="button"
              (click)="activeMediaType.set('video')"
              [class.bg-rose-500]="activeMediaType() === 'video'"
              [class.text-black]="activeMediaType() === 'video'"
              [class.text-slate-400]="activeMediaType() !== 'video'"
              class="px-3 py-1.5 rounded-md font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <span class="material-icons text-sm">movie</span>
              <span>Cinema (4K)</span>
            </button>
            <button
              id="btn-switch-audio"
              type="button"
              (click)="activeMediaType.set('audio')"
              [class.bg-rose-500]="activeMediaType() === 'audio'"
              [class.text-black]="activeMediaType() === 'audio'"
              [class.text-slate-400]="activeMediaType() !== 'audio'"
              class="px-3 py-1.5 rounded-md font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <span class="material-icons text-sm">graphic_eq</span>
              <span>Audio (FLAC)</span>
            </button>
          </div>
        </div>
      </div>

      <!-- VIDEO STUDIO -->
      @if (activeMediaType() === 'video') {
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Main 4K Player Stage -->
          <div class="lg:col-span-2 space-y-4">
            <div class="relative rounded-xl overflow-hidden bg-black border border-[#222e40] aspect-video flex items-center justify-center group shadow-2xl">
              <img
                [src]="currentVideo()?.videoInfo?.thumbnailUrl || 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80'"
                alt="Video Poster"
                class="w-full h-full object-cover opacity-80"
                referrerpolicy="no-referrer"
              />

              <!-- Overlay Play Button -->
              <button
                id="btn-video-play-overlay"
                type="button"
                aria-label="Play or pause video"
                (click)="togglePlayVideo()"
                class="absolute inset-0 m-auto w-16 h-16 rounded-full bg-rose-500/90 hover:bg-rose-500 text-black flex items-center justify-center transition-all shadow-xl hover:scale-110 active:scale-95 cursor-pointer z-10"
              >
                <span class="material-icons text-3xl">{{ isPlaying() ? 'pause' : 'play_arrow' }}</span>
              </button>

              <!-- Top Stream Badges -->
              <div class="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 rounded bg-black/80 text-emerald-400 font-mono text-[10px] border border-emerald-500/40">
                    HTTP 206 RANGE STREAM
                  </span>
                  <span class="px-2 py-0.5 rounded bg-black/80 text-cyan-400 font-mono text-[10px] border border-cyan-500/40">
                    {{ selectedResolution() }}
                  </span>
                </div>
                <span class="px-2 py-0.5 rounded bg-black/80 text-slate-300 font-mono text-[10px]">
                  FPS: {{ currentVideo()?.videoInfo?.frameRate || 60 }}
                </span>
              </div>

              <!-- Bottom Player Controls Bar -->
              <div class="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black via-black/90 to-transparent p-4 space-y-2 z-10">
                <!-- Timeline Progress Bar with chapter ticks -->
                <div class="relative w-full h-2 bg-white/20 rounded-full cursor-pointer group/bar">
                  <div class="h-full bg-rose-500 rounded-full" [style.width.%]="videoProgress()"></div>
                  <!-- Chapter dots -->
                  <div class="absolute top-0 left-[25%] w-1.5 h-full bg-white/60"></div>
                  <div class="absolute top-0 left-[55%] w-1.5 h-full bg-white/60"></div>
                  <div class="absolute top-0 left-[80%] w-1.5 h-full bg-white/60"></div>
                </div>

                <div class="flex items-center justify-between text-xs text-slate-200">
                  <div class="flex items-center gap-3">
                    <button id="btn-video-play-bottom" type="button" aria-label="Toggle playback" (click)="togglePlayVideo()" class="hover:text-rose-400 cursor-pointer">
                      <span class="material-icons text-base">{{ isPlaying() ? 'pause' : 'play_arrow' }}</span>
                    </button>
                    <span class="text-[11px] font-mono">02:14 / 06:24</span>
                    <div class="flex items-center gap-1 text-slate-400 text-[10px]">
                      <span class="material-icons text-xs">volume_up</span>
                      <span>100%</span>
                    </div>
                  </div>

                  <div class="flex items-center gap-3">
                    <!-- Resolution Selector -->
                    <select
                      id="video-res-select"
                      aria-label="Video resolution"
                      (change)="onResolutionChange($event)"
                      class="bg-black/60 text-slate-200 px-2 py-0.5 rounded border border-white/20 text-[10px] focus:outline-none"
                    >
                      <option value="2160p (4K)">2160p (4K UHD)</option>
                      <option value="1080p">1080p FHD</option>
                      <option value="720p">720p HD</option>
                      <option value="480p">480p SD</option>
                    </select>

                    <button type="button" class="hover:text-rose-400 cursor-pointer" title="Subtitles" aria-label="Subtitles">
                      <span class="material-icons text-sm">subtitles</span>
                    </button>
                    <button type="button" class="hover:text-rose-400 cursor-pointer" title="Fullscreen" aria-label="Fullscreen">
                      <span class="material-icons text-sm">fullscreen</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Video Metadata & Chapter Navigation -->
            <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4">
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#1c2432] pb-3">
                <div>
                  <h2 class="text-base font-bold text-white">{{ currentVideo()?.filename }}</h2>
                  <div class="text-xs text-slate-400 font-sans mt-0.5">{{ currentVideo()?.humanDescription }}</div>
                </div>
                <button
                  id="btn-inspect-current-video"
                  type="button"
                  (click)="inspectObject.emit(currentVideo()?.id || '')"
                  class="px-3 py-1.5 rounded-lg bg-[#1a2332] hover:bg-[#253246] text-rose-300 text-xs font-semibold cursor-pointer shrink-0"
                >
                  Deep Inspection
                </button>
              </div>

              <!-- Chapters Matrix -->
              <div>
                <div class="text-[11px] text-slate-400 font-semibold uppercase tracking-wider mb-2">CHAPTER MARKERS</div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  @for (chap of currentVideo()?.videoInfo?.chapters || []; track chap.time) {
                    <div
                      tabindex="0"
                      role="button"
                      (click)="seekChapter(chap.time)"
                      (keydown.enter)="seekChapter(chap.time)"
                      class="p-2.5 rounded-lg bg-[#121822] border border-[#1e293b] hover:border-rose-500/40 transition-colors flex items-center justify-between cursor-pointer"
                    >
                      <span class="text-xs text-slate-200">{{ chap.title }}</span>
                      <span class="text-[10px] text-rose-400 font-mono font-semibold">{{ formatTime(chap.time) }}</span>
                    </div>
                  }
                </div>
              </div>
            </div>
          </div>

          <!-- Video Archive Library Sidebar -->
          <div class="space-y-4">
            <div class="p-4 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-200">MASTER VIDEO REPOSITORY</span>
                <span class="text-[10px] text-slate-400">{{ videoList().length }} Masters</span>
              </div>

              <div class="space-y-2">
                @for (vid of videoList(); track vid.id) {
                  <div
                    tabindex="0"
                    role="button"
                    (click)="selectVideo(vid)"
                    (keydown.enter)="selectVideo(vid)"
                    [class.border-rose-500]="currentVideo()?.id === vid.id"
                    [class.bg-[#161f2e]]="currentVideo()?.id === vid.id"
                    [class.bg-[#111722]]="currentVideo()?.id !== vid.id"
                    class="p-3 rounded-lg border border-[#1e2838] hover:border-rose-500/50 transition-all cursor-pointer space-y-2"
                  >
                    <div class="flex items-center gap-2.5">
                      <div class="w-12 h-9 rounded bg-black/60 overflow-hidden shrink-0">
                        <img [src]="vid.videoInfo?.thumbnailUrl" alt="Thumbnail" class="w-full h-full object-cover" referrerpolicy="no-referrer" />
                      </div>
                      <div class="overflow-hidden">
                        <div class="text-xs font-bold text-slate-100 truncate">{{ vid.filename }}</div>
                        <div class="text-[10px] text-slate-400">{{ vid.videoInfo?.resolution }} • {{ (vid.sizeBytes / 1024 / 1024).toFixed(0) }} MB</div>
                      </div>
                    </div>
                    <div class="flex items-center justify-between text-[9px] text-slate-400 border-t border-[#1d2737] pt-1">
                      <span class="text-emerald-400">SHA256 VERIFIED</span>
                      <span>{{ vid.storageClass.toUpperCase() }}</span>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      }

      <!-- AUDIO STUDIO (FLAC / 24-bit 96kHz Lossless) -->
      @if (activeMediaType() === 'audio') {
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Main Hi-Res Player Stage -->
          <div class="lg:col-span-2 space-y-4">
            <div class="p-6 rounded-xl bg-gradient-to-br from-[#12161f] via-[#0e1219] to-[#0a0d12] border border-[#232f42] space-y-6 shadow-2xl">
              <!-- Track Title & Cover Art -->
              <div class="flex flex-col sm:flex-row items-center gap-5">
                <div class="w-28 h-28 rounded-xl bg-purple-950 border border-purple-800/40 overflow-hidden shrink-0 shadow-lg">
                  <img
                    [src]="currentAudio()?.audioInfo?.coverArtUrl || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80'"
                    alt="Cover Art"
                    class="w-full h-full object-cover"
                    referrerpolicy="no-referrer"
                  />
                </div>
                <div class="space-y-1.5 text-center sm:text-left">
                  <div class="flex items-center justify-center sm:justify-start gap-2">
                    <span class="px-2 py-0.5 rounded bg-purple-950 text-purple-400 text-[10px] font-bold border border-purple-800/40">
                      {{ currentAudio()?.audioInfo?.codec }}
                    </span>
                    <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-800/40">
                      BIT-PERFECT MASTER
                    </span>
                  </div>
                  <h2 class="text-xl font-bold text-white tracking-tight">{{ currentAudio()?.audioInfo?.trackTitle || currentAudio()?.filename }}</h2>
                  <div class="text-xs text-slate-400">{{ currentAudio()?.audioInfo?.artist }} — {{ currentAudio()?.audioInfo?.album }} ({{ currentAudio()?.audioInfo?.year }})</div>
                </div>
              </div>

              <!-- Interactive Dynamic Waveform Canvas -->
              <div class="space-y-2">
                <div class="flex items-center justify-between text-[11px] text-slate-400">
                  <span>ACOUSTIC WAVEFORM (96kHz UNCOMPRESSED)</span>
                  <span class="text-purple-400 font-semibold">{{ currentAudio()?.audioInfo?.bitrateKbps }} kbps</span>
                </div>

                <!-- Waveform Bars -->
                <div class="h-20 bg-[#070a0e] rounded-xl p-3 border border-[#1a2332] flex items-end justify-between gap-0.5 overflow-hidden">
                  @for (bar of currentAudio()?.audioInfo?.waveform || defaultWaveform; track $index) {
                    <div
                      class="flex-1 rounded-full transition-all cursor-pointer"
                      [style.height.%]="bar"
                      [class.bg-purple-500]="$index <= audioCurrentStep()"
                      [class.bg-slate-700]="$index > audioCurrentStep()"
                    ></div>
                  }
                </div>

                <div class="flex items-center justify-between text-[11px] text-slate-400">
                  <span>03:42</span>
                  <span>{{ formatDuration(currentAudio()?.audioInfo?.durationSeconds || 582) }}</span>
                </div>
              </div>

              <!-- Audio Controls -->
              <div class="flex items-center justify-between border-t border-[#1e293b] pt-4">
                <div class="flex items-center gap-4">
                  <button
                    id="btn-audio-play-toggle"
                    type="button"
                    aria-label="Toggle audio playback"
                    (click)="togglePlayAudio()"
                    class="w-12 h-12 rounded-full bg-purple-500 hover:bg-purple-400 text-black flex items-center justify-center transition-transform hover:scale-105 active:scale-95 cursor-pointer shadow-lg"
                  >
                    <span class="material-icons text-2xl">{{ isPlaying() ? 'pause' : 'play_arrow' }}</span>
                  </button>
                  <div class="space-y-0.5">
                    <div class="text-xs text-slate-200 font-semibold">Master Audio Ingestion</div>
                    <div class="text-[10px] text-slate-400">Linear PCM Stereo (Bit-perfect playback)</div>
                  </div>
                </div>

                <div class="flex items-center gap-2">
                  <button
                    id="btn-audio-proof"
                    type="button"
                    (click)="inspectObject.emit(currentAudio()?.id || '')"
                    class="px-3 py-1.5 rounded-lg bg-[#182230] hover:bg-[#233146] text-purple-300 text-xs font-semibold cursor-pointer"
                  >
                    Audio Proof
                  </button>
                </div>
              </div>
            </div>

            <!-- Audio Description & Transcript -->
            <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
              <div class="text-xs font-bold text-slate-200">RECORDING TRANSCRIPT & NOTES</div>
              <p class="text-xs text-slate-400 font-sans leading-relaxed">
                {{ currentAudio()?.humanDescription }}
              </p>
              @if (currentAudio()?.audioInfo?.transcript) {
                <div class="p-3 rounded-lg bg-[#111722] border border-[#1d2737] text-xs text-slate-300 font-mono">
                  {{ currentAudio()?.audioInfo?.transcript }}
                </div>
              }
            </div>
          </div>

          <!-- Audio Playlist Sidebar -->
          <div class="space-y-4">
            <div class="p-4 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-200">AUDIO MASTERS</span>
                <span class="text-[10px] text-slate-400">{{ audioList().length }} Tracks</span>
              </div>

              <div class="space-y-2">
                @for (aud of audioList(); track aud.id) {
                  <div
                    tabindex="0"
                    role="button"
                    (click)="selectAudio(aud)"
                    (keydown.enter)="selectAudio(aud)"
                    [class.border-purple-500]="currentAudio()?.id === aud.id"
                    [class.bg-[#1c182b]]="currentAudio()?.id === aud.id"
                    [class.bg-[#111722]]="currentAudio()?.id !== aud.id"
                    class="p-3 rounded-lg border border-[#1e2838] hover:border-purple-500/50 transition-all cursor-pointer space-y-1.5"
                  >
                    <div class="flex items-center justify-between">
                      <div class="text-xs font-bold text-slate-100 truncate max-w-[160px]">{{ aud.audioInfo?.trackTitle || aud.filename }}</div>
                      <span class="text-[10px] text-purple-400 font-semibold">{{ aud.audioInfo?.sampleRateHz ? (aud.audioInfo!.sampleRateHz / 1000) + 'kHz' : 'FLAC' }}</span>
                    </div>
                    <div class="text-[11px] text-slate-400 truncate">{{ aud.audioInfo?.artist }}</div>
                    <div class="flex items-center justify-between text-[9px] text-slate-400 pt-1 border-t border-[#1d2737]">
                      <span class="text-emerald-400">24-BIT MASTER</span>
                      <span>{{ (aud.sizeBytes / 1024 / 1024).toFixed(0) }} MB</span>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class MediaStudio {
  vaultService = inject(VaultService);
  inspectObject = output<string>();

  activeMediaType = signal<'video' | 'audio'>('video');
  selectedResolution = signal<string>('2160p (4K)');
  isPlaying = signal<boolean>(false);
  videoProgress = signal<number>(35);
  audioCurrentStep = signal<number>(28);

  currentVideo = signal<VaultObject | null>(null);
  currentAudio = signal<VaultObject | null>(null);

  defaultWaveform = [
    12, 18, 24, 38, 45, 52, 68, 74, 82, 90, 85, 78, 62, 48, 55, 67, 80, 88, 92, 75,
    60, 42, 35, 28, 40, 58, 70, 84, 95, 88, 76, 64, 52, 40, 32, 22, 18, 25, 38, 50,
    65, 78, 86, 91, 84, 70, 58, 44, 36, 48, 62, 75, 85, 93, 89, 74, 61, 50, 38, 28,
  ];

  constructor() {
    const vids = this.vaultService.objects().filter(o => o.type === 'video');
    if (vids.length > 0) this.currentVideo.set(vids[0]);

    const auds = this.vaultService.objects().filter(o => o.type === 'audio');
    if (auds.length > 0) this.currentAudio.set(auds[0]);
  }

  videoList(): VaultObject[] {
    return this.vaultService.objects().filter(o => o.type === 'video');
  }

  audioList(): VaultObject[] {
    return this.vaultService.objects().filter(o => o.type === 'audio');
  }

  selectVideo(v: VaultObject): void {
    this.currentVideo.set(v);
    this.isPlaying.set(false);
  }

  selectAudio(a: VaultObject): void {
    this.currentAudio.set(a);
    this.isPlaying.set(false);
  }

  togglePlayVideo(): void {
    this.isPlaying.update(v => !v);
  }

  togglePlayAudio(): void {
    this.isPlaying.update(v => !v);
  }

  onResolutionChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.selectedResolution.set(target.value);
  }

  seekChapter(seconds: number): void {
    const dur = this.currentVideo()?.videoInfo?.durationSeconds || 384;
    this.videoProgress.set((seconds / dur) * 100);
  }

  formatTime(secs: number): string {
    const mins = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  }

  formatDuration(secs: number): string {
    const mins = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  }
}
