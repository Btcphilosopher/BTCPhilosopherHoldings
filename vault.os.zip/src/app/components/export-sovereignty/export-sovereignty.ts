import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-export-sovereignty',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="export-sovereignty-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-cyan-400">inventory_2</span>
            <span class="text-xs font-semibold text-cyan-400 uppercase tracking-wider">COMPLETE DATA PORTABILITY & PRESERVATION PACKAGE</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            SOVEREIGN EXPORT ENGINE
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Package your entire digital life into an open, self-contained, cryptographically verifiable archival bundle. Zero vendor lock-in.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="vaultService.downloadExportVault()"
            class="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-lg active:scale-95"
          >
            <span class="material-icons text-sm">download</span>
            <span>Download Master Vault Bundle</span>
          </button>
        </div>
      </div>

      <!-- EXPORT PACKAGE SPECIFICATION -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Package Contents -->
        <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4">
          <div class="flex items-center gap-2 text-xs font-bold text-slate-200">
            <span class="material-icons text-sm text-cyan-400">folder</span>
            <span>ARCHIVE BUNDLE STRUCTURE</span>
          </div>

          <div class="space-y-2 text-xs text-slate-300 font-mono">
            <div class="p-2.5 rounded bg-[#121822] border border-[#1e293b]">
              <div class="text-cyan-400 font-bold">📁 /manifest/</div>
              <div class="text-[10px] text-slate-400">MANIFEST.json & CHECKSUMS.sha256</div>
            </div>
            <div class="p-2.5 rounded bg-[#121822] border border-[#1e293b]">
              <div class="text-purple-400 font-bold">📁 /objects/</div>
              <div class="text-[10px] text-slate-400">4,829 Bit-perfect master raw assets</div>
            </div>
            <div class="p-2.5 rounded bg-[#121822] border border-[#1e2838]">
              <div class="text-amber-400 font-bold">📁 /ledger/</div>
              <div class="text-[10px] text-slate-400">VLT token ledger & state root proof</div>
            </div>
            <div class="p-2.5 rounded bg-[#121822] border border-[#1e2838]">
              <div class="text-emerald-400 font-bold">📁 /timescape/</div>
              <div class="text-[10px] text-slate-400">Temporal matrix & sealed time capsules</div>
            </div>
          </div>
        </div>

        <!-- Cryptographic Guarantees -->
        <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4">
          <div class="flex items-center gap-2 text-xs font-bold text-slate-200">
            <span class="material-icons text-sm text-emerald-400">verified</span>
            <span>SOVEREIGN GUARANTEES</span>
          </div>

          <div class="space-y-3 text-xs text-slate-300 font-sans">
            <div class="flex items-start gap-2">
              <span class="material-icons text-xs text-emerald-400 mt-0.5">check_circle</span>
              <div>
                <strong class="text-white font-mono">Offline-First</strong>: Can be mounted and indexed locally on any POSIX system without network access.
              </div>
            </div>
            <div class="flex items-start gap-2">
              <span class="material-icons text-xs text-emerald-400 mt-0.5">check_circle</span>
              <div>
                <strong class="text-white font-mono">Bit-for-Bit Verifiable</strong>: Every object hash validates against the embedded Merkle tree.
              </div>
            </div>
            <div class="flex items-start gap-2">
              <span class="material-icons text-xs text-emerald-400 mt-0.5">check_circle</span>
              <div>
                <strong class="text-white font-mono">Open Standards</strong>: ISO-standard container formats (PDF/A, FLAC, ProRes, DNG, JSON).
              </div>
            </div>
          </div>
        </div>

        <!-- Identity & Authority -->
        <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4">
          <div class="flex items-center gap-2 text-xs font-bold text-slate-200">
            <span class="material-icons text-sm text-amber-400">fingerprint</span>
            <span>VAULT SIGNATURE</span>
          </div>

          <div class="space-y-2 text-xs font-mono">
            <div class="text-[11px] text-slate-400">OWNER PUBLIC KEY:</div>
            <div class="p-2.5 rounded bg-[#0a0d12] border border-[#1c2738] text-[10px] text-slate-300 truncate select-all">
              ed25519:7f8a9b2c3d4e5f60112233445566778899aabbccddeeff00
            </div>
            <div class="text-[11px] text-slate-400 pt-1">ACTIVE STATE ROOT:</div>
            <div class="p-2.5 rounded bg-[#0a0d12] border border-[#1c2738] text-[10px] text-amber-300 truncate select-all">
              {{ vaultService.tokenState()?.stateRootHash }}
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ExportSovereignty {
  vaultService = inject(VaultService);
}
