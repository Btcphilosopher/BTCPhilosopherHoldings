import { ChangeDetectionStrategy, Component, inject, input, output } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';

export interface NavItem {
  id: string;
  label: string;
  icon: string;
  badge?: string | number;
  badgeColor?: string;
  group?: string;
}

@Component({
  selector: 'app-sidebar-nav',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside id="vault-sidebar" class="w-full md:w-64 bg-[#090b0e] border-r border-[#1c222e] flex flex-col justify-between shrink-0 select-none">
      <!-- Top Section: Core Domains -->
      <div class="p-3 space-y-6 overflow-y-auto max-h-[calc(100vh-140px)]">
        <!-- SYSTEM DOMAIN -->
        <div>
          <div class="px-2.5 mb-2 text-[10px] font-mono tracking-wider text-slate-400 font-semibold uppercase">
            Sovereign Command
          </div>
          <nav class="space-y-0.5 font-mono text-xs">
            @for (item of commandNav; track item.id) {
              <button
                [id]="'nav-' + item.id"
                (click)="tabSelected.emit(item.id)"
                [class.bg-[#161c26]]="activeTab() === item.id"
                [class.text-white]="activeTab() === item.id"
                [class.border-[#2a3649]]="activeTab() === item.id"
                [class.text-slate-400]="activeTab() !== item.id"
                class="w-full flex items-center justify-between px-3 py-2 rounded-md transition-all hover:bg-[#12161f] hover:text-slate-200 border border-transparent text-left cursor-pointer group"
              >
                <div class="flex items-center gap-2.5">
                  <span class="material-icons text-base group-hover:text-emerald-400 transition-colors" [class.text-emerald-400]="activeTab() === item.id">
                    {{ item.icon }}
                  </span>
                  <span class="font-medium tracking-tight">{{ item.label }}</span>
                </div>
                @if (item.badge) {
                  <span
                    class="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold"
                    [class.bg-[#10b981]/20]="item.badgeColor === 'emerald'"
                    [class.text-[#10b981]]="item.badgeColor === 'emerald'"
                    [class.bg-cyan-950]="item.badgeColor === 'cyan'"
                    [class.text-cyan-400]="item.badgeColor === 'cyan'"
                    [class.bg-amber-950]="item.badgeColor === 'amber'"
                    [class.text-amber-400]="item.badgeColor === 'amber'"
                    [class.bg-[#1e2633]]="!item.badgeColor"
                    [class.text-slate-400]="!item.badgeColor"
                  >
                    {{ item.badge }}
                  </span>
                }
              </button>
            }
          </nav>
        </div>

        <!-- MEDIA & SOCIAL LAYER -->
        <div>
          <div class="px-2.5 mb-2 text-[10px] font-mono tracking-wider text-slate-400 font-semibold uppercase">
            Media & Network
          </div>
          <nav class="space-y-0.5 font-mono text-xs">
            @for (item of mediaNav; track item.id) {
              <button
                [id]="'nav-' + item.id"
                (click)="tabSelected.emit(item.id)"
                [class.bg-[#161c26]]="activeTab() === item.id"
                [class.text-white]="activeTab() === item.id"
                [class.border-[#2a3649]]="activeTab() === item.id"
                [class.text-slate-400]="activeTab() !== item.id"
                class="w-full flex items-center justify-between px-3 py-2 rounded-md transition-all hover:bg-[#12161f] hover:text-slate-200 border border-transparent text-left cursor-pointer group"
              >
                <div class="flex items-center gap-2.5">
                  <span class="material-icons text-base group-hover:text-cyan-400 transition-colors" [class.text-cyan-400]="activeTab() === item.id">
                    {{ item.icon }}
                  </span>
                  <span class="font-medium tracking-tight">{{ item.label }}</span>
                </div>
                @if (item.badge) {
                  <span class="px-1.5 py-0.2 rounded text-[10px] font-mono bg-[#1e2633] text-slate-400">
                    {{ item.badge }}
                  </span>
                }
              </button>
            }
          </nav>
        </div>

        <!-- CRYPTOGRAPHY & ARCHIVE -->
        <div>
          <div class="px-2.5 mb-2 text-[10px] font-mono tracking-wider text-slate-400 font-semibold uppercase">
            Integrity & Sovereign Layer
          </div>
          <nav class="space-y-0.5 font-mono text-xs">
            @for (item of securityNav; track item.id) {
              <button
                [id]="'nav-' + item.id"
                (click)="tabSelected.emit(item.id)"
                [class.bg-[#161c26]]="activeTab() === item.id"
                [class.text-white]="activeTab() === item.id"
                [class.border-[#2a3649]]="activeTab() === item.id"
                [class.text-slate-400]="activeTab() !== item.id"
                class="w-full flex items-center justify-between px-3 py-2 rounded-md transition-all hover:bg-[#12161f] hover:text-slate-200 border border-transparent text-left cursor-pointer group"
              >
                <div class="flex items-center gap-2.5">
                  <span class="material-icons text-base group-hover:text-amber-400 transition-colors" [class.text-amber-400]="activeTab() === item.id">
                    {{ item.icon }}
                  </span>
                  <span class="font-medium tracking-tight">{{ item.label }}</span>
                </div>
                @if (item.badge) {
                  <span
                    class="px-1.5 py-0.2 rounded text-[10px] font-mono"
                    [class.bg-emerald-950]="item.badgeColor === 'emerald'"
                    [class.text-emerald-400]="item.badgeColor === 'emerald'"
                    [class.bg-amber-950]="item.badgeColor === 'amber'"
                    [class.text-amber-400]="item.badgeColor === 'amber'"
                    [class.bg-[#1e2633]]="!item.badgeColor"
                    [class.text-slate-400]="!item.badgeColor"
                  >
                    {{ item.badge }}
                  </span>
                }
              </button>
            }
          </nav>
        </div>
      </div>

      <!-- Bottom User / Node Key Status -->
      <div class="p-3 border-t border-[#1c222e] bg-[#07090c]">
        <div class="flex items-center justify-between text-[11px] font-mono">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold text-[10px]">
              TH
            </div>
            <div class="leading-tight">
              <div class="text-slate-200 font-semibold truncate max-w-[110px]">Tom Harrison</div>
              <div class="text-slate-400 text-[10px]">ed25519:7f8a9b</div>
            </div>
          </div>
          <button
            (click)="tabSelected.emit('audit-logs')"
            title="View Real-Time Audit Log"
            class="p-1.5 rounded hover:bg-[#161c26] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <span class="material-icons text-base">receipt_long</span>
          </button>
        </div>
      </div>
    </aside>
  `,
})
export class SidebarNav {
  vaultService = inject(VaultService);
  activeTab = input.required<string>();
  tabSelected = output<string>();
  triggerIngest = output<void>();

  commandNav: NavItem[] = [
    { id: 'dashboard', label: 'Command Centre', icon: 'dashboard', badge: 'LIVE', badgeColor: 'emerald' },
    { id: 'timescape', label: 'Timescape Matrix', icon: 'timeline', badge: '2021-2026', badgeColor: 'cyan' },
    { id: 'vault-explorer', label: 'Object Storage', icon: 'folder_zip', badge: '4,829' },
  ];

  mediaNav: NavItem[] = [
    { id: 'media-studio', label: 'Media Studio (4K/FLAC)', icon: 'movie', badge: 'PRO' },
    { id: 'collections', label: 'Collections', icon: 'collections_bookmark', badge: '5' },
    { id: 'time-capsules', label: 'Time Capsules', icon: 'lock_clock', badge: '2 SEALED', badgeColor: 'amber' },
    { id: 'microblog', label: 'VAULT.POST', icon: 'dynamic_feed', badge: '3' },
  ];

  securityNav: NavItem[] = [
    { id: 'token-engine', label: 'VAULT.TOKEN (VLT)', icon: 'toll', badge: '250 VLT', badgeColor: 'amber' },
    { id: 'archive-integrity', label: 'Archive & Integrity', icon: 'verified_user', badge: '100% OK', badgeColor: 'emerald' },
    { id: 'ai-studio', label: 'AI Intelligence', icon: 'psychology', badge: 'GEMINI' },
    { id: 'export-sovereignty', label: 'Sovereign Export', icon: 'inventory_2' },
    { id: 'audit-logs', label: 'Cryptographic Audit', icon: 'history' },
  ];
}
