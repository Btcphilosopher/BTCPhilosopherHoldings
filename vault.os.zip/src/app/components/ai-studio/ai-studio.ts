import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { AIPermission, AISearchResult } from '../../core/models/vault.model';

@Component({
  selector: 'app-ai-studio',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="ai-studio-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-cyan-400">psychology</span>
            <span class="text-xs font-semibold text-cyan-400 uppercase tracking-wider">GEMINI INTELLIGENCE & NATURAL RETRIEVAL</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            AI PRESERVATION & QUERY ENGINE
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Strictly bounded intelligence layer. Gemini translates natural language into structured deterministic vault queries and analyzes 50-year open standard format durability.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-2.5 py-1 rounded bg-[#16202d] text-cyan-400 border border-cyan-800/40 text-xs">
            Model: Gemini 3.8 Flash
          </span>
        </div>
      </div>

      <!-- PRIVACY & BOUNDARY POLICY SETTINGS -->
      <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="material-icons text-sm text-emerald-400">security</span>
            <h2 class="text-xs font-bold text-slate-200">AI SOVEREIGNTY & PRIVACY ENFORCEMENT</h2>
          </div>
          <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/30">ZERO TRAINING LOGGING</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs pt-1">
          <button
            id="btn-ai-allow-all"
            type="button"
            (click)="setAIPermission('ALLOW_AI_ANALYSIS')"
            [class.bg-cyan-950]="currentPermission() === 'ALLOW_AI_ANALYSIS'"
            [class.border-cyan-500]="currentPermission() === 'ALLOW_AI_ANALYSIS'"
            [class.text-cyan-300]="currentPermission() === 'ALLOW_AI_ANALYSIS'"
            [class.bg-[#121822]]="currentPermission() !== 'ALLOW_AI_ANALYSIS'"
            [class.text-slate-400]="currentPermission() !== 'ALLOW_AI_ANALYSIS'"
            class="p-3 rounded-lg border border-[#222d3d] text-left transition-all cursor-pointer space-y-1"
          >
            <div class="font-bold flex items-center justify-between">
              <span>ALLOW ALL</span>
              @if (currentPermission() === 'ALLOW_AI_ANALYSIS') {
                <span class="material-icons text-xs text-cyan-400">check</span>
              }
            </div>
            <div class="text-[10px] text-slate-400">Full multimodal querying and transcription</div>
          </button>

          <button
            id="btn-ai-metadata-only"
            type="button"
            (click)="setAIPermission('ALLOW_METADATA_ONLY')"
            [class.bg-cyan-950]="currentPermission() === 'ALLOW_METADATA_ONLY'"
            [class.border-cyan-500]="currentPermission() === 'ALLOW_METADATA_ONLY'"
            [class.text-cyan-300]="currentPermission() === 'ALLOW_METADATA_ONLY'"
            [class.bg-[#121822]]="currentPermission() !== 'ALLOW_METADATA_ONLY'"
            [class.text-slate-400]="currentPermission() !== 'ALLOW_METADATA_ONLY'"
            class="p-3 rounded-lg border border-[#222d3d] text-left transition-all cursor-pointer space-y-1"
          >
            <div class="font-bold flex items-center justify-between">
              <span>METADATA ONLY</span>
              @if (currentPermission() === 'ALLOW_METADATA_ONLY') {
                <span class="material-icons text-xs text-cyan-400">check</span>
              }
            </div>
            <div class="text-[10px] text-slate-400">Restricts AI to inspect filenames and tags only</div>
          </button>

          <button
            id="btn-ai-selected-collections"
            type="button"
            (click)="setAIPermission('ALLOW_SELECTED_COLLECTIONS')"
            [class.bg-cyan-950]="currentPermission() === 'ALLOW_SELECTED_COLLECTIONS'"
            [class.border-cyan-500]="currentPermission() === 'ALLOW_SELECTED_COLLECTIONS'"
            [class.text-cyan-300]="currentPermission() === 'ALLOW_SELECTED_COLLECTIONS'"
            [class.bg-[#121822]]="currentPermission() !== 'ALLOW_SELECTED_COLLECTIONS'"
            [class.text-slate-400]="currentPermission() !== 'ALLOW_SELECTED_COLLECTIONS'"
            class="p-3 rounded-lg border border-[#222d3d] text-left transition-all cursor-pointer space-y-1"
          >
            <div class="font-bold flex items-center justify-between">
              <span>SELECTED ARCHIVES</span>
              @if (currentPermission() === 'ALLOW_SELECTED_COLLECTIONS') {
                <span class="material-icons text-xs text-cyan-400">check</span>
              }
            </div>
            <div class="text-[10px] text-slate-400">Only designated public collections analyzed</div>
          </button>

          <button
            id="btn-ai-deny"
            type="button"
            (click)="setAIPermission('DENY_AI_ANALYSIS')"
            [class.bg-rose-950]="currentPermission() === 'DENY_AI_ANALYSIS'"
            [class.border-rose-500]="currentPermission() === 'DENY_AI_ANALYSIS'"
            [class.text-rose-300]="currentPermission() === 'DENY_AI_ANALYSIS'"
            [class.bg-[#121822]]="currentPermission() !== 'DENY_AI_ANALYSIS'"
            [class.text-slate-400]="currentPermission() !== 'DENY_AI_ANALYSIS'"
            class="p-3 rounded-lg border border-[#222d3d] text-left transition-all cursor-pointer space-y-1"
          >
            <div class="font-bold flex items-center justify-between">
              <span>STRICT LOCKDOWN</span>
              @if (currentPermission() === 'DENY_AI_ANALYSIS') {
                <span class="material-icons text-xs text-rose-400">check</span>
              }
            </div>
            <div class="text-[10px] text-slate-400">Completely block all Gemini API interactions</div>
          </button>
        </div>
      </div>

      <!-- NATURAL LANGUAGE ARCHIVE SEARCH TOOL -->
      <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4 shadow-sm">
        <div class="flex items-center gap-2">
          <span class="material-icons text-base text-cyan-400">manage_search</span>
          <h2 class="font-bold text-sm text-slate-200">NATURAL LANGUAGE ARCHIVAL SEARCH</h2>
        </div>

        <div class="flex flex-col sm:flex-row items-center gap-2">
          <div class="relative flex-1 w-full">
            <input
              id="ai-query-input"
              [formControl]="queryInput"
              (keydown.enter)="executeSearch()"
              type="text"
              placeholder="e.g. Show me 4K cinematic videos recorded in Peak District or high-res audio tracks from 2026..."
              aria-label="Natural language search query"
              class="w-full bg-[#121722] text-slate-100 px-4 py-2.5 rounded-lg border border-[#253246] text-xs font-mono focus:outline-none focus:border-cyan-400"
            />
          </div>
          <button
            id="btn-execute-ai-search"
            type="button"
            (click)="executeSearch()"
            [disabled]="isSearching() || !queryInput.value"
            class="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <span class="material-icons text-sm">{{ isSearching() ? 'sync' : 'auto_awesome' }}</span>
            <span>{{ isSearching() ? 'Decomposing Query...' : 'Execute AI Search' }}</span>
          </button>
        </div>

        <!-- SEARCH RESULTS & STRUCTURED PARSING PROOF -->
        @if (searchOutput(); as out) {
          <div class="space-y-3 pt-2">
            <!-- Structured Filter Explanation -->
            <div class="p-3.5 rounded-lg bg-[#0e1622] border border-cyan-800/40 text-xs space-y-1.5">
              <div class="flex items-center justify-between">
                <span class="font-bold text-cyan-300">GEMINI 3.8 FLASH STRUCTURED DECOMPOSITION</span>
                <span class="px-2 py-0.2 rounded text-[10px] bg-cyan-950 text-cyan-400 border border-cyan-700/40">
                  {{ out.provenance }}
                </span>
              </div>
              <div class="text-[11px] text-slate-300 font-sans">
                {{ out.structuredFilter.explanation || 'Query parsed and executed against authoritative Merkle vault index.' }}
              </div>
              <div class="flex flex-wrap gap-2 text-[10px] text-slate-400 font-mono pt-1">
                @if (out.structuredFilter.type) {
                  <span class="px-2 py-0.5 rounded bg-[#172230] text-cyan-300">Type: {{ out.structuredFilter.type }}</span>
                }
                @if (out.structuredFilter.year) {
                  <span class="px-2 py-0.5 rounded bg-[#172230] text-cyan-300">Year: {{ out.structuredFilter.year }}</span>
                }
                @if (out.structuredFilter.keywords && out.structuredFilter.keywords.length) {
                  <span class="px-2 py-0.5 rounded bg-[#172230] text-cyan-300">Keywords: {{ out.structuredFilter.keywords.join(', ') }}</span>
                }
              </div>
            </div>

            <!-- Matching Objects Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              @for (obj of out.results; track obj.id) {
                <div
                  tabindex="0"
                  role="button"
                  (click)="inspectObject.emit(obj.id)"
                  (keydown.enter)="inspectObject.emit(obj.id)"
                  class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] hover:border-cyan-500/40 transition-colors cursor-pointer space-y-1.5"
                >
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-xs text-slate-100 truncate max-w-[180px]">{{ obj.filename }}</span>
                    <span class="text-[10px] text-cyan-400 uppercase">{{ obj.type }}</span>
                  </div>
                  <div class="text-[11px] text-slate-400 font-sans line-clamp-1">{{ obj.humanDescription }}</div>
                  <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-[#1d2737]">
                    <span>{{ (obj.sizeBytes / 1024 / 1024).toFixed(1) }} MB</span>
                    <span class="text-emerald-400">SHA-256 Verified</span>
                  </div>
                </div>
              }
            </div>
          </div>
        }
      </div>

      <!-- FORMAT DURABILITY & PRESERVATION ANALYZER -->
      <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4 shadow-sm">
        <div class="flex items-center justify-between border-b border-[#1c2636] pb-3">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-purple-400">history_edu</span>
            <h2 class="font-bold text-sm text-slate-200">50-YEAR DIGITAL PRESERVATION AUDIT</h2>
          </div>
          <span class="text-xs text-slate-400">Open ISO Standards Assessment</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (obj of vaultService.objects().slice(0, 3); track obj.id) {
            <div class="p-4 rounded-xl bg-[#111722] border border-[#1e2838] space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-slate-100 truncate max-w-[180px]">{{ obj.filename }}</span>
                <span class="px-1.5 py-0.5 rounded text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800/40">DURABILITY: 98/100</span>
              </div>
              <div class="text-[11px] text-slate-400 font-sans">
                Container: {{ obj.mimeType }} • Codec: {{ obj.videoInfo?.codec || obj.audioInfo?.codec || 'Standard Archival' }}
              </div>
              <div class="p-2.5 rounded bg-[#090d14] border border-[#161f2b] text-[10px] text-slate-300 font-sans">
                💡 Preservation mandate: Verified lossless format. Immune to vendor lock-in.
              </div>
              <button
                type="button"
                (click)="inspectObject.emit(obj.id)"
                class="w-full py-1.5 rounded bg-[#18212e] hover:bg-[#222e40] text-purple-300 text-xs font-semibold cursor-pointer"
              >
                Inspect Archival Profile
              </button>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class AiStudio {
  vaultService = inject(VaultService);
  inspectObject = output<string>();

  queryInput = new FormControl('Peak District 4K master videos and lossless audio');
  isSearching = signal<boolean>(false);
  searchOutput = signal<AISearchResult | null>(null);

  currentPermission() {
    return this.vaultService.aiPolicy()?.permission || 'ALLOW_AI_ANALYSIS';
  }

  setAIPermission(perm: AIPermission): void {
    this.vaultService.updateAIPolicy(perm).subscribe();
  }

  executeSearch(): void {
    const q = this.queryInput.value?.trim();
    if (!q) return;

    this.isSearching.set(true);
    this.vaultService.naturalSearchAI(q).subscribe({
      next: (res) => {
        this.isSearching.set(false);
        this.searchOutput.set(res);
      },
      error: () => this.isSearching.set(false),
    });
  }
}
