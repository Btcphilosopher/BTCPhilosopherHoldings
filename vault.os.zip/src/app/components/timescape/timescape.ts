import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-timescape',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="timescape-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER & CONTROLS -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-cyan-400">timeline</span>
            <span class="text-xs font-semibold text-cyan-400 uppercase tracking-wider">TEMPORAL MEMORY HORIZON</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            TIMESCAPE MATRIX (2021 — 2026+)
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Hierarchical temporal coordinate system mapping life events, creative epochs, master media capture dates, and sealed time capsules.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            id="btn-register-memory"
            type="button"
            (click)="showAddModal.set(true)"
            class="px-3.5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
          >
            <span class="material-icons text-sm">add_circle</span>
            <span>Register Memory Event</span>
          </button>
        </div>
      </div>

      <!-- TIMELINE FILTER & ZOOM BAR -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg bg-[#0a0d12] border border-[#1a222e] text-xs">
        <!-- Year Selector Pills -->
        <div class="flex items-center gap-1.5 overflow-x-auto py-1">
          <span class="text-slate-400 text-[11px] mr-1">EPOCH:</span>
          <button
            type="button"
            (click)="selectedYear.set(null)"
            [class.bg-cyan-500]="selectedYear() === null"
            [class.text-black]="selectedYear() === null"
            [class.bg-[#161d28]]="selectedYear() !== null"
            [class.text-slate-300]="selectedYear() !== null"
            class="px-2.5 py-1 rounded text-xs font-semibold transition-all cursor-pointer"
          >
            ALL (2021-2026)
          </button>
          @for (year of [2026, 2025, 2024, 2023, 2022, 2021]; track year) {
            <button
              type="button"
              (click)="selectedYear.set(year)"
              [class.bg-cyan-500]="selectedYear() === year"
              [class.text-black]="selectedYear() === year"
              [class.bg-[#161d28]]="selectedYear() !== year"
              [class.text-slate-300]="selectedYear() !== year"
              class="px-2.5 py-1 rounded text-xs transition-all cursor-pointer hover:bg-[#202a3a]"
            >
              {{ year }}
            </button>
          }
        </div>

        <!-- Category Filter -->
        <div class="flex items-center gap-1.5 overflow-x-auto py-1">
          <span class="text-slate-400 text-[11px] mr-1">CATEGORY:</span>
          @for (cat of ['all', 'media', 'project', 'capsule', 'memory']; track cat) {
            <button
              type="button"
              (click)="selectedCategory.set(cat)"
              [class.bg-[#233144]]="selectedCategory() === cat"
              [class.text-cyan-300]="selectedCategory() === cat"
              [class.border-cyan-500/40]="selectedCategory() === cat"
              [class.bg-[#12161f]]="selectedCategory() !== cat"
              [class.text-slate-400]="selectedCategory() !== cat"
              class="px-2 py-1 rounded border border-transparent text-[11px] uppercase transition-all cursor-pointer hover:text-slate-200"
            >
              {{ cat }}
            </button>
          }
        </div>
      </div>

      <!-- TIMELINE CHRONOLOGICAL STREAM -->
      <div class="relative border-l-2 border-[#1c2738] ml-4 md:ml-8 pl-6 md:pl-8 space-y-8 py-4">
        @for (event of filteredEvents(); track event.id) {
          <div class="relative group">
            <!-- Timeline Node Marker -->
            <div
              class="absolute -left-[31px] md:-left-[39px] top-3 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all bg-[#090c10]"
              [class.border-cyan-400]="event.category === 'media'"
              [class.border-amber-400]="event.category === 'capsule'"
              [class.border-emerald-400]="event.category === 'project'"
              [class.border-purple-400]="event.category === 'memory'"
            >
              <div
                class="w-2 h-2 rounded-full"
                [class.bg-cyan-400]="event.category === 'media'"
                [class.bg-amber-400]="event.category === 'capsule'"
                [class.bg-emerald-400]="event.category === 'project'"
                [class.bg-purple-400]="event.category === 'memory'"
              ></div>
            </div>

            <!-- Event Card -->
            <div class="p-4 rounded-xl bg-[#0d1219] border border-[#1d2737] hover:border-cyan-500/50 transition-all shadow-sm space-y-3">
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider"
                    [class.bg-cyan-950]="event.category === 'media'"
                    [class.text-cyan-400]="event.category === 'media'"
                    [class.bg-amber-950]="event.category === 'capsule'"
                    [class.text-amber-400]="event.category === 'capsule'"
                    [class.bg-emerald-950]="event.category === 'project'"
                    [class.text-emerald-400]="event.category === 'project'"
                    [class.bg-purple-950]="event.category === 'memory'"
                    [class.text-purple-400]="event.category === 'memory'"
                  >
                    {{ event.category }}
                  </span>
                  <span class="text-slate-400 font-semibold">{{ event.date }}</span>
                  <span class="text-slate-400">({{ event.month }} {{ event.year }})</span>
                </div>
                @if (event.location) {
                  <div class="text-[11px] text-slate-400 flex items-center gap-1">
                    <span class="material-icons text-xs text-slate-400">place</span>
                    <span>{{ event.location }}</span>
                  </div>
                }
              </div>

              <!-- Title & Summary -->
              <div>
                <h3 class="text-base font-bold text-white tracking-tight">{{ event.title }}</h3>
                <p class="text-xs text-slate-400 font-sans mt-1 leading-relaxed">{{ event.summary }}</p>
              </div>

              <!-- Attached Thumbnail / Object Preview if available -->
              @if (event.thumbnailUrl) {
                <div class="flex items-center gap-3 p-2 rounded-lg bg-[#131923] border border-[#202b3c] max-w-md">
                  <img [src]="event.thumbnailUrl" alt="Thumbnail" class="w-16 h-12 object-cover rounded" referrerpolicy="no-referrer" />
                  <div class="text-xs space-y-0.5">
                    <div class="font-semibold text-slate-200">Associated Vault Master Media</div>
                    <div class="text-[10px] text-cyan-400">4K Master Stream Ready • SHA-256 Verified</div>
                  </div>
                </div>
              }

              <!-- Footer with people / object action -->
              <div class="flex items-center justify-between pt-2 border-t border-[#18212e] text-[11px] text-slate-400">
                <div class="flex items-center gap-2">
                  @if (event.people && event.people.length) {
                    <span>People: {{ event.people.join(', ') }}</span>
                  }
                </div>
                @if (event.objectId) {
                  <button
                    type="button"
                    (click)="inspectObject.emit(event.objectId)"
                    class="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold cursor-pointer"
                  >
                    <span>Inspect Master Asset</span>
                    <span class="material-icons text-xs">open_in_new</span>
                  </button>
                }
              </div>
            </div>
          </div>
        }
      </div>

      <!-- MODAL: REGISTER MEMORY EVENT -->
      @if (showAddModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="w-full max-w-lg bg-[#0d1219] border border-[#26354a] rounded-xl p-6 space-y-4 shadow-2xl">
            <div class="flex items-center justify-between border-b border-[#1c2738] pb-3">
              <div class="flex items-center gap-2">
                <span class="material-icons text-cyan-400 text-base">event_note</span>
                <h2 class="font-bold text-base text-white">Register Timescape Event</h2>
              </div>
              <button type="button" (click)="showAddModal.set(false)" class="text-slate-400 hover:text-white text-base cursor-pointer">✕</button>
            </div>

            <form [formGroup]="eventForm" (ngSubmit)="submitEvent()" class="space-y-3 text-xs">
              <div>
                <label for="event-title" class="block text-slate-400 mb-1">Event Title *</label>
                <input
                  id="event-title"
                  formControlName="title"
                  type="text"
                  placeholder="e.g. Completed High Peak Master Film Edition"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-cyan-400 font-sans"
                />
              </div>

              <div class="grid grid-cols-3 gap-3">
                <div>
                  <label for="event-date" class="block text-slate-400 mb-1">Date *</label>
                  <input
                    id="event-date"
                    formControlName="date"
                    type="date"
                    class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-cyan-400 font-mono"
                  />
                </div>
                <div>
                  <label for="event-category" class="block text-slate-400 mb-1">Category</label>
                  <select
                    id="event-category"
                    formControlName="category"
                    class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-cyan-400 font-mono"
                  >
                    <option value="media">Media</option>
                    <option value="project">Project</option>
                    <option value="capsule">Capsule</option>
                    <option value="memory">Memory</option>
                  </select>
                </div>
                <div>
                  <label for="event-location" class="block text-slate-400 mb-1">Location</label>
                  <input
                    id="event-location"
                    formControlName="location"
                    type="text"
                    placeholder="e.g. Sheffield, UK"
                    class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-cyan-400 font-sans"
                  />
                </div>
              </div>

              <div>
                <label for="event-summary" class="block text-slate-400 mb-1">Detailed Summary</label>
                <textarea
                  id="event-summary"
                  formControlName="summary"
                  rows="3"
                  placeholder="Describe the significance and context of this temporal milestone..."
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-cyan-400 font-sans"
                ></textarea>
              </div>

              <div class="flex items-center justify-end gap-2 pt-3 border-t border-[#1c2738]">
                <button
                  type="button"
                  (click)="showAddModal.set(false)"
                  class="px-3.5 py-2 rounded-lg bg-[#18212e] text-slate-300 hover:bg-[#202b3c] font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  [disabled]="eventForm.invalid"
                  class="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold disabled:opacity-50 cursor-pointer"
                >
                  Register in Timescape
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class Timescape {
  vaultService = inject(VaultService);
  inspectObject = output<string>();

  selectedYear = signal<number | null>(null);
  selectedCategory = signal<string>('all');
  showAddModal = signal<boolean>(false);

  eventForm = new FormGroup({
    title: new FormControl('', [Validators.required]),
    date: new FormControl(new Date().toISOString().split('T')[0], [Validators.required]),
    category: new FormControl<'media' | 'document' | 'post' | 'project' | 'capsule' | 'token' | 'memory'>('memory', [Validators.required]),
    location: new FormControl(''),
    summary: new FormControl(''),
  });

  filteredEvents() {
    let list = this.vaultService.timescapeEvents();
    if (this.selectedYear()) {
      list = list.filter(e => e.year === this.selectedYear());
    }
    if (this.selectedCategory() !== 'all') {
      list = list.filter(e => e.category === this.selectedCategory());
    }
    return list;
  }

  submitEvent(): void {
    if (this.eventForm.invalid) return;
    const val = this.eventForm.value;
    const dateObj = new Date(val.date!);
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    this.vaultService.createTimescapeEvent({
      title: val.title!,
      date: val.date!,
      year: dateObj.getFullYear(),
      month: monthNames[dateObj.getMonth()],
      category: val.category || 'memory',
      location: val.location || undefined,
      summary: val.summary || '',
      people: ['Tom Harrison'],
      importance: 'high',
    }).subscribe(() => {
      this.showAddModal.set(false);
      this.eventForm.reset({
        date: new Date().toISOString().split('T')[0],
        category: 'memory',
      });
    });
  }
}
