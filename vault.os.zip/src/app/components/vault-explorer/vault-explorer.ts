import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { VaultObject } from '../../core/models/vault.model';

@Component({
  selector: 'app-vault-explorer',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="vault-explorer-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-purple-400">folder_zip</span>
            <span class="text-xs font-semibold text-purple-400 uppercase tracking-wider">OBJECT STORE & MERKLE MANIFESTS</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            IMMUTABLE VAULT OBJECTS
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Cryptographically sealed master digital assets stored across 4 geo-replicated clusters. Verified with SHA-256 block trees.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            id="btn-ingest-master"
            type="button"
            (click)="triggerIngest.emit()"
            class="px-3.5 py-2 rounded-lg bg-[#10b981] hover:bg-[#059669] text-black font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
          >
            <span class="material-icons text-sm">cloud_upload</span>
            <span>Ingest Master File</span>
          </button>
        </div>
      </div>

      <!-- FILTER & CONTROLS TOOLBAR -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg bg-[#0a0d12] border border-[#1a222e] text-xs">
        <!-- Type Filter Pills -->
        <div class="flex items-center gap-1.5 overflow-x-auto py-1">
          <span class="text-slate-400 text-[11px] mr-1">TYPE:</span>
          @for (type of ['all', 'video', 'audio', 'image', 'document']; track type) {
            <button
              type="button"
              (click)="selectedType.set(type)"
              [class.bg-purple-600]="selectedType() === type"
              [class.text-white]="selectedType() === type"
              [class.bg-[#161d28]]="selectedType() !== type"
              [class.text-slate-300]="selectedType() !== type"
              class="px-2.5 py-1 rounded text-xs uppercase font-semibold transition-all cursor-pointer hover:bg-[#202a3a]"
            >
              {{ type }}
            </button>
          }
        </div>

        <!-- Token Gated Toggle & Search -->
        <div class="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            type="button"
            (click)="toggleTokenGatedOnly()"
            [class.bg-amber-950]="tokenGatedOnly()"
            [class.text-amber-400]="tokenGatedOnly()"
            [class.border-amber-700/50]="tokenGatedOnly()"
            [class.bg-[#12161f]]="!tokenGatedOnly()"
            [class.text-slate-400]="!tokenGatedOnly()"
            class="px-2.5 py-1.5 rounded border border-[#232a38] text-[11px] flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <span class="material-icons text-xs">toll</span>
            <span>Token-Gated Only</span>
          </button>

          <!-- Search filter -->
          <div class="relative flex-1 sm:w-48">
            <input
              id="vault-filter-input"
              [formControl]="filterInput"
              type="text"
              placeholder="Filter filename/tag..."
              aria-label="Filter filename or tag"
              class="w-full bg-[#12161f] text-slate-200 px-3 py-1.5 rounded border border-[#232a38] text-xs font-mono focus:outline-none focus:border-purple-400"
            />
          </div>

          <!-- View Mode -->
          <div class="flex items-center bg-[#12161f] rounded border border-[#232a38] p-0.5">
            <button
              type="button"
              (click)="viewMode.set('grid')"
              aria-label="Grid View"
              [class.bg-[#232d3f]]="viewMode() === 'grid'"
              [class.text-white]="viewMode() === 'grid'"
              [class.text-slate-400]="viewMode() !== 'grid'"
              class="p-1 rounded cursor-pointer"
            >
              <span class="material-icons text-sm">grid_view</span>
            </button>
            <button
              type="button"
              (click)="viewMode.set('list')"
              aria-label="List View"
              [class.bg-[#232d3f]]="viewMode() === 'list'"
              [class.text-white]="viewMode() === 'list'"
              [class.text-slate-400]="viewMode() !== 'list'"
              class="p-1 rounded cursor-pointer"
            >
              <span class="material-icons text-sm">view_list</span>
            </button>
          </div>
        </div>
      </div>

      <!-- OBJECTS GRID VIEW -->
      @if (viewMode() === 'grid') {
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (obj of filteredObjects(); track obj.id) {
            <div
              tabindex="0"
              role="button"
              (click)="inspectObject.emit(obj.id)"
              (keydown.enter)="inspectObject.emit(obj.id)"
              class="p-4 rounded-xl bg-[#0d1219] border border-[#1e2838] hover:border-purple-500/50 transition-all cursor-pointer group space-y-3 shadow-sm flex flex-col justify-between"
            >
              <!-- Card Top -->
              <div class="space-y-2">
                <!-- Media Thumbnail / Icon Placeholder -->
                <div class="relative w-full h-36 rounded-lg bg-[#141b26] border border-[#222e40] overflow-hidden flex items-center justify-center">
                  @if (obj.videoInfo?.thumbnailUrl) {
                    <img [src]="obj.videoInfo?.thumbnailUrl" [alt]="obj.filename" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerpolicy="no-referrer" />
                    <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                    <span class="absolute bottom-2 left-2 px-1.5 py-0.5 rounded bg-black/70 text-cyan-400 font-mono text-[10px]">
                      {{ obj.videoInfo?.resolution }} • {{ obj.videoInfo?.frameRate }}fps
                    </span>
                  } @else if (obj.audioInfo?.coverArtUrl) {
                    <img [src]="obj.audioInfo?.coverArtUrl" [alt]="obj.filename" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerpolicy="no-referrer" />
                    <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                    <span class="absolute bottom-2 left-2 px-1.5 py-0.5 rounded bg-black/70 text-purple-400 font-mono text-[10px]">
                      {{ obj.audioInfo?.codec }}
                    </span>
                  } @else {
                    <div class="flex flex-col items-center gap-1 text-slate-500">
                      <span class="material-icons text-3xl">
                        {{ obj.type === 'video' ? 'movie' : obj.type === 'audio' ? 'audiotrack' : obj.type === 'image' ? 'image' : 'description' }}
                      </span>
                      <span class="text-[10px] uppercase font-mono">{{ obj.type }}</span>
                    </div>
                  }

                  <!-- Token Gate Badge -->
                  @if (obj.isTokenGated) {
                    <span class="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-amber-950/90 text-amber-400 border border-amber-600/40 text-[10px] font-mono font-bold flex items-center gap-1 shadow">
                      <span class="material-icons text-[10px]">lock</span>
                      <span>{{ obj.minTokenRequired }} VLT</span>
                    </span>
                  }

                  <!-- Archive Status -->
                  <span class="absolute top-2 left-2 px-2 py-0.5 rounded bg-emerald-950/90 text-emerald-400 border border-emerald-600/40 text-[10px] font-mono">
                    {{ obj.archiveStatus.toUpperCase() }}
                  </span>
                </div>

                <!-- Title & Meta -->
                <div>
                  <h3 class="font-bold text-sm text-slate-100 truncate group-hover:text-purple-400 transition-colors">{{ obj.filename }}</h3>
                  <p class="text-[11px] text-slate-400 font-sans line-clamp-2 mt-1 leading-snug">{{ obj.humanDescription }}</p>
                </div>

                <!-- Tags -->
                <div class="flex flex-wrap gap-1 pt-1">
                  @for (tag of obj.tags.slice(0, 3); track tag) {
                    <span class="px-1.5 py-0.2 rounded bg-[#17212e] text-slate-400 text-[10px] border border-[#233144]">
                      #{{ tag }}
                    </span>
                  }
                </div>
              </div>

              <!-- Card Bottom Cryptographic Footer -->
              <div class="pt-2 border-t border-[#1a2434] space-y-1.5 text-[10px] text-slate-400">
                <div class="flex items-center justify-between">
                  <span>SIZE: {{ (obj.sizeBytes / 1024 / 1024).toFixed(1) }} MB</span>
                  <span class="text-emerald-400">{{ obj.replicasCount }} Replicas</span>
                </div>
                <div class="flex items-center gap-1 font-mono text-[9px] text-slate-400 truncate">
                  <span class="text-purple-400">SHA256:</span>
                  <span>{{ obj.sha256.substring(0, 18) }}...</span>
                </div>
              </div>
            </div>
          }
        </div>
      }

      <!-- OBJECTS LIST VIEW -->
      @if (viewMode() === 'list') {
        <div class="overflow-x-auto rounded-xl border border-[#1e2838] bg-[#0d1219]">
          <table class="w-full text-left text-xs">
            <thead class="bg-[#121822] text-slate-400 border-b border-[#1e2838] text-[11px]">
              <tr>
                <th class="p-3">FILENAME</th>
                <th class="p-3">TYPE</th>
                <th class="p-3">SIZE</th>
                <th class="p-3">STORAGE CLASS</th>
                <th class="p-3">SHA-256 MERKLE HASH</th>
                <th class="p-3">REPLICAS</th>
                <th class="p-3">PROVENANCE</th>
                <th class="p-3 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#182230]">
              @for (obj of filteredObjects(); track obj.id) {
                <tr
                  tabindex="0"
                  role="button"
                  (click)="inspectObject.emit(obj.id)"
                  (keydown.enter)="inspectObject.emit(obj.id)"
                  class="hover:bg-[#141d2a] transition-colors cursor-pointer"
                >
                  <td class="p-3 font-semibold text-slate-100 flex items-center gap-2">
                    <span class="material-icons text-sm text-purple-400">
                      {{ obj.type === 'video' ? 'movie' : obj.type === 'audio' ? 'audiotrack' : obj.type === 'image' ? 'image' : 'description' }}
                    </span>
                    <span class="truncate max-w-xs">{{ obj.filename }}</span>
                    @if (obj.isTokenGated) {
                      <span class="px-1.5 py-0.2 rounded bg-amber-950 text-amber-400 text-[9px] border border-amber-800/40 font-mono">
                        {{ obj.minTokenRequired }} VLT
                      </span>
                    }
                  </td>
                  <td class="p-3 text-slate-400 uppercase font-mono text-[10px]">{{ obj.type }}</td>
                  <td class="p-3 text-slate-300 font-mono">{{ (obj.sizeBytes / 1024 / 1024).toFixed(1) }} MB</td>
                  <td class="p-3">
                    <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/30 text-[10px] uppercase font-mono">
                      {{ obj.storageClass }}
                    </span>
                  </td>
                  <td class="p-3 font-mono text-[10px] text-slate-400">
                    {{ obj.sha256.substring(0, 16) }}...
                  </td>
                  <td class="p-3 text-emerald-400 font-mono text-[11px]">
                    {{ obj.replicasCount }} Nodes Sync
                  </td>
                  <td class="p-3 text-slate-400 font-mono text-[10px]">
                    {{ obj.provenance.type || 'MEASURED' }}
                  </td>
                  <td class="p-3 text-right">
                    <button
                      type="button"
                      (click)="inspectObject.emit(obj.id); $event.stopPropagation()"
                      class="px-2 py-1 rounded bg-[#1f2a3c] hover:bg-[#2c3b54] text-slate-200 text-[10px] font-semibold cursor-pointer"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    </div>
  `,
})
export class VaultExplorer {
  vaultService = inject(VaultService);
  inspectObject = output<string>();
  triggerIngest = output<void>();

  selectedType = signal<string>('all');
  tokenGatedOnly = signal<boolean>(false);
  viewMode = signal<'grid' | 'list'>('grid');
  filterInput = new FormControl('');

  toggleTokenGatedOnly(): void {
    this.tokenGatedOnly.update(v => !v);
  }

  filteredObjects(): VaultObject[] {
    let list = this.vaultService.objects();
    if (this.selectedType() !== 'all') {
      list = list.filter(o => o.type === this.selectedType());
    }
    if (this.tokenGatedOnly()) {
      list = list.filter(o => o.isTokenGated);
    }
    const q = this.filterInput.value?.toLowerCase()?.trim();
    if (q) {
      list = list.filter(o =>
        o.filename.toLowerCase().includes(q) ||
        o.humanDescription.toLowerCase().includes(q) ||
        o.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return list;
  }
}
