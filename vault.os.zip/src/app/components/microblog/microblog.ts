import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-microblog',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="microblog-view" class="p-4 md:p-6 space-y-6 max-w-4xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-cyan-400">dynamic_feed</span>
            <span class="text-xs font-semibold text-cyan-400 uppercase tracking-wider">SOVEREIGN PUBLISHING LAYER</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            VAULT.POST MICROBLOG
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Personal microblogging engine anchored to your private computer. Publish privately, to trusted peers, or behind token-gated VLT access gates.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="px-2.5 py-1 rounded bg-[#16202d] text-cyan-300 border border-[#24354a]">
            {{ vaultService.posts().length }} Posts Published
          </span>
        </div>
      </div>

      <!-- NEW POST COMPOSER -->
      <div class="p-5 rounded-xl bg-[#0d1219] border border-[#202c3e] space-y-4 shadow-md">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold text-xs">
            TH
          </div>
          <div class="leading-tight">
            <div class="text-xs font-bold text-slate-200">Tom Harrison</div>
            <div class="text-[10px] text-slate-400">Archivist & Vault Owner</div>
          </div>
        </div>

        <form [formGroup]="postForm" (ngSubmit)="submitPost()" class="space-y-3">
          <textarea
            formControlName="text"
            rows="3"
            placeholder="Record an archival dispatch, creative reflection, or research note..."
            class="w-full bg-[#121824] text-slate-200 p-3 rounded-lg border border-[#243144] focus:outline-none focus:border-cyan-400 font-sans text-xs resize-none"
          ></textarea>

          <div class="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
            <div class="flex flex-wrap items-center gap-2">
              <!-- Visibility Selector -->
              <div class="flex items-center gap-1 bg-[#121824] rounded-lg border border-[#243144] px-2 py-1">
                <span class="material-icons text-slate-400 text-xs">visibility</span>
                <select
                  formControlName="visibility"
                  class="bg-transparent text-slate-200 text-[11px] focus:outline-none font-mono"
                >
                  <option value="PRIVATE">Private (Vault Only)</option>
                  <option value="FOLLOWERS">Trusted Followers</option>
                  <option value="TOKEN_GATED">Token-GATED (VLT)</option>
                  <option value="PUBLIC">Public Sovereign</option>
                </select>
              </div>

              <!-- Token Requirement if Token-gated -->
              @if (postForm.get('visibility')?.value === 'TOKEN_GATED') {
                <div class="flex items-center gap-1 bg-amber-950/60 rounded-lg border border-amber-800/40 px-2 py-1">
                  <span class="text-[10px] text-amber-400">STAKE:</span>
                  <input
                    formControlName="tokenGatedRequiredVlt"
                    type="number"
                    class="w-14 bg-transparent text-amber-300 text-[11px] font-mono focus:outline-none"
                  />
                  <span class="text-[10px] text-amber-400">VLT</span>
                </div>
              }
            </div>

            <button
              type="submit"
              [disabled]="postForm.invalid"
              class="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-all disabled:opacity-50 flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <span class="material-icons text-sm">send</span>
              <span>Publish Dispatch</span>
            </button>
          </div>
        </form>
      </div>

      <!-- POSTS FEED -->
      <div class="space-y-4">
        @for (post of vaultService.posts(); track post.id) {
          <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] hover:border-cyan-500/40 transition-all space-y-3.5 shadow-sm">
            <!-- Post Header -->
            <div class="flex items-start justify-between gap-3">
              <div class="flex items-center gap-3">
                <img [src]="post.authorAvatar" [alt]="post.authorName" class="w-9 h-9 rounded-full object-cover border border-[#29364a]" referrerpolicy="no-referrer" />
                <div>
                  <div class="flex items-center gap-2">
                    <span class="font-bold text-xs text-white">{{ post.authorName }}</span>
                    <span class="text-[10px] text-slate-400 font-mono">&#64;tom</span>
                  </div>
                  <div class="text-[10px] text-slate-400 font-mono">{{ post.timestamp }}</div>
                </div>
              </div>

              <!-- Visibility Badge -->
              <span
                class="px-2 py-0.5 rounded text-[10px] font-bold font-mono tracking-wider border shadow"
                [class.bg-emerald-950]="post.visibility === 'PUBLIC'"
                [class.text-emerald-400]="post.visibility === 'PUBLIC'"
                [class.border-emerald-700/50]="post.visibility === 'PUBLIC'"
                [class.bg-amber-950]="post.visibility === 'TOKEN_GATED'"
                [class.text-amber-400]="post.visibility === 'TOKEN_GATED'"
                [class.border-amber-700/50]="post.visibility === 'TOKEN_GATED'"
                [class.bg-[#17212e]]="post.visibility === 'PRIVATE' || post.visibility === 'FOLLOWERS'"
                [class.text-cyan-400]="post.visibility === 'PRIVATE' || post.visibility === 'FOLLOWERS'"
                [class.border-cyan-800/40]="post.visibility === 'PRIVATE' || post.visibility === 'FOLLOWERS'"
              >
                {{ post.visibility }}
                @if (post.visibility === 'TOKEN_GATED') {
                  <span>({{ post.tokenGatedRequiredVlt || 100 }} VLT)</span>
                }
              </span>
            </div>

            <!-- Post Text Content -->
            <p class="text-xs text-slate-200 font-sans leading-relaxed">
              {{ post.text }}
            </p>

            <!-- Attached Vault Objects Preview -->
            @if (post.attachedObjects && post.attachedObjects.length > 0) {
              <div class="space-y-2 pt-1">
                @for (att of post.attachedObjects; track att.id) {
                  <button
                    type="button"
                    (click)="inspectObject.emit(att.id)"
                    class="w-full text-left p-3 rounded-lg bg-[#121822] border border-[#1e293b] hover:border-cyan-500/40 transition-colors flex items-center justify-between cursor-pointer"
                  >
                    <div class="flex items-center gap-2.5">
                      <div class="w-7 h-7 rounded bg-cyan-950 border border-cyan-800/40 flex items-center justify-center text-cyan-400 shrink-0">
                        <span class="material-icons text-sm">
                          {{ att.type === 'video' ? 'videocam' : att.type === 'audio' ? 'audiotrack' : att.type === 'image' ? 'photo' : 'description' }}
                        </span>
                      </div>
                      <div class="overflow-hidden">
                        <div class="text-xs font-semibold text-slate-200 truncate max-w-sm">{{ att.filename }}</div>
                        <div class="text-[10px] text-slate-400">{{ (att.sizeBytes / 1024 / 1024).toFixed(1) }} MB • SHA-256 Verified</div>
                      </div>
                    </div>
                    <span class="text-cyan-400 text-xs font-semibold">Inspect</span>
                  </button>
                }
              </div>
            }

            <!-- Tags -->
            @if (post.tags && post.tags.length > 0) {
              <div class="flex flex-wrap gap-1.5 pt-1">
                @for (tag of post.tags; track tag) {
                  <span class="px-1.5 py-0.2 rounded bg-[#16202d] text-slate-400 text-[10px] border border-[#243346]">
                    #{{ tag }}
                  </span>
                }
              </div>
            }

            <!-- Reactions & Cryptographic Signatures Footer -->
            <div class="pt-2 border-t border-[#1a2434] flex items-center justify-between text-xs text-slate-400">
              <div class="flex items-center gap-3">
                @for (reaction of getReactionEntries(post.reactions); track reaction[0]) {
                  <button type="button" class="px-2 py-0.5 rounded-full bg-[#16202d] hover:bg-[#202d3f] text-[11px] text-slate-300 flex items-center gap-1 border border-[#243346] cursor-pointer">
                    <span>{{ reaction[0] }}</span>
                    <span class="font-bold font-mono">{{ reaction[1] }}</span>
                  </button>
                }
              </div>
              <div class="text-[10px] font-mono text-slate-400">
                <span>Ed25519 Signed</span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class Microblog {
  vaultService = inject(VaultService);
  inspectObject = output<string>();

  postForm = new FormGroup({
    text: new FormControl('', [Validators.required]),
    visibility: new FormControl('PRIVATE'),
    tokenGatedRequiredVlt: new FormControl(100),
  });

  getReactionEntries(reactions: Record<string, number> | undefined) {
    if (!reactions) return [];
    return Object.entries(reactions);
  }

  submitPost(): void {
    if (this.postForm.invalid) return;
    const val = this.postForm.value;

    this.vaultService.createPost({
      text: val.text!,
      visibility: val.visibility || 'PRIVATE',
      tokenGatedRequiredVlt: val.visibility === 'TOKEN_GATED' ? Number(val.tokenGatedRequiredVlt) : 0,
      tags: ['Sovereignty', 'ArchivalDispatch'],
      attachedObjectIds: ['obj_vid_01'],
    }).subscribe(() => {
      this.postForm.reset({
        visibility: 'PRIVATE',
        tokenGatedRequiredVlt: 100,
      });
    });
  }
}
