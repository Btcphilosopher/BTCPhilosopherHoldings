import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { AuditRecord } from '../../core/models/vault.model';

@Component({
  selector: 'app-archive-integrity',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="archive-integrity-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-emerald-400">verified_user</span>
            <span class="text-xs font-semibold text-emerald-400 uppercase tracking-wider">CRYPTOGRAPHIC ARCHIVE & BITROT SELF-HEALING</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            ARCHIVE.OS INTEGRITY DAEMON
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Continuous background audit verifying SHA-256 Merkle block trees against all stored objects. Autonomous self-healing repairs bitrot from redundant geo-replicas.
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <button
            id="btn-run-deep-audit"
            type="button"
            (click)="runAudit('DEEP')"
            [disabled]="isAuditing()"
            class="px-3.5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 disabled:opacity-50"
          >
            <span class="material-icons text-sm">{{ isAuditing() ? 'sync' : 'search' }}</span>
            <span>{{ isAuditing() ? 'Verifying Tree...' : 'Run Deep Audit' }}</span>
          </button>

          <button
            id="btn-simulate-bitrot"
            type="button"
            (click)="simulateSelfHealing()"
            [disabled]="isHealing()"
            class="px-3 py-2 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-700/50 text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <span class="material-icons text-sm">{{ isHealing() ? 'build' : 'healing' }}</span>
            <span>{{ isHealing() ? 'Healing Corrupt Sector...' : 'Simulate Sector Bitrot & Heal' }}</span>
          </button>
        </div>
      </div>

      <!-- AUDIT STATUS SUMMARY BANNER -->
      @if (lastAuditResult(); as audit) {
        <div class="p-4 rounded-xl bg-[#0e171e] border border-emerald-500/40 flex items-center justify-between gap-3 text-xs">
          <div class="flex items-center gap-2.5">
            <span class="material-icons text-emerald-400 text-lg">check_circle</span>
            <div>
              <div class="font-bold text-slate-100">AUDIT COMPLETED: 100% BIT-PARITY VERIFIED</div>
              <div class="text-[11px] text-slate-400 font-sans">{{ audit.details }}</div>
            </div>
          </div>
          <div class="text-right text-[11px] text-emerald-400 font-mono">
            <div>{{ audit.durationMs }}ms execution</div>
            <div class="text-[10px] text-slate-400">{{ audit.timestamp }}</div>
          </div>
        </div>
      }

      @if (healingMessage()) {
        <div class="p-4 rounded-xl bg-rose-950/40 border border-rose-500/50 flex items-center justify-between gap-3 text-xs animate-pulse">
          <div class="flex items-center gap-2.5">
            <span class="material-icons text-rose-400 text-lg">healing</span>
            <div>
              <div class="font-bold text-rose-300">BITROT DETECTED & AUTONOMOUSLY RESTORED</div>
              <div class="text-[11px] text-slate-300 font-sans">{{ healingMessage() }}</div>
            </div>
          </div>
          <span class="px-2 py-0.5 rounded bg-rose-900 text-rose-200 text-[10px] font-bold">REPAIRED</span>
        </div>
      }

      <!-- 4-WAY GEO-REPLICATION ARCHIVE MATRIX -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- 1. Primary NVMe -->
        <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-200">CLUSTER A (LOCAL)</span>
            <span class="px-1.5 py-0.2 rounded text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800/40">AUTHORITATIVE</span>
          </div>
          <div class="text-sm font-bold text-white">Primary NVMe Array</div>
          <div class="space-y-1 text-[11px] text-slate-400">
            <div class="flex justify-between">
              <span>Location:</span>
              <span class="text-slate-200 font-semibold">Local High Peak Node</span>
            </div>
            <div class="flex justify-between">
              <span>Latency:</span>
              <span class="text-emerald-400 font-semibold">0.2 ms</span>
            </div>
            <div class="flex justify-between">
              <span>Checksum:</span>
              <span class="text-emerald-400 font-semibold">100% Verified</span>
            </div>
            <div class="flex justify-between">
              <span>Encryption:</span>
              <span class="text-slate-200">AES-256-GCM</span>
            </div>
          </div>
        </div>

        <!-- 2. Zurich Bunker -->
        <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-200">REPLICA 1 (ALPINE)</span>
            <span class="px-1.5 py-0.2 rounded text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800/40">ONLINE</span>
          </div>
          <div class="text-sm font-bold text-white">Zurich Bunker Storage</div>
          <div class="space-y-1 text-[11px] text-slate-400">
            <div class="flex justify-between">
              <span>Location:</span>
              <span class="text-slate-200 font-semibold">Zurich, Switzerland</span>
            </div>
            <div class="flex justify-between">
              <span>Latency:</span>
              <span class="text-emerald-400 font-semibold">14.8 ms</span>
            </div>
            <div class="flex justify-between">
              <span>Checksum:</span>
              <span class="text-emerald-400 font-semibold">100% Parity</span>
            </div>
            <div class="flex justify-between">
              <span>Jurisdiction:</span>
              <span class="text-slate-200">Swiss Federal Privacy</span>
            </div>
          </div>
        </div>

        <!-- 3. Reykjavik -->
        <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-200">REPLICA 2 (NORDIC)</span>
            <span class="px-1.5 py-0.2 rounded text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800/40">ONLINE</span>
          </div>
          <div class="text-sm font-bold text-white">Reykjavik Geothermal</div>
          <div class="space-y-1 text-[11px] text-slate-400">
            <div class="flex justify-between">
              <span>Location:</span>
              <span class="text-slate-200 font-semibold">Reykjavik, Iceland</span>
            </div>
            <div class="flex justify-between">
              <span>Latency:</span>
              <span class="text-emerald-400 font-semibold">28.1 ms</span>
            </div>
            <div class="flex justify-between">
              <span>Checksum:</span>
              <span class="text-emerald-400 font-semibold">100% Parity</span>
            </div>
            <div class="flex justify-between">
              <span>Power:</span>
              <span class="text-emerald-400">100% Geothermal</span>
            </div>
          </div>
        </div>

        <!-- 4. Cold Magnetic Tape -->
        <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-200">COLD TIER (OFFLINE)</span>
            <span class="px-1.5 py-0.2 rounded text-[9px] bg-cyan-950 text-cyan-400 border border-cyan-800/40">AIR-GAPPED</span>
          </div>
          <div class="text-sm font-bold text-white">LTO-9 Magnetic Tape</div>
          <div class="space-y-1 text-[11px] text-slate-400">
            <div class="flex justify-between">
              <span>Media:</span>
              <span class="text-slate-200 font-semibold">Linear Tape Open 9</span>
            </div>
            <div class="flex justify-between">
              <span>Durability:</span>
              <span class="text-cyan-400 font-semibold">50+ Years Shelf</span>
            </div>
            <div class="flex justify-between">
              <span>Status:</span>
              <span class="text-cyan-400 font-semibold">Offline Verified</span>
            </div>
            <div class="flex justify-between">
              <span>Air-Gap:</span>
              <span class="text-slate-200">Enforced</span>
            </div>
          </div>
        </div>
      </div>

      <!-- OBJECT PROVENANCE & ARCHIVE MANIFEST TABLE -->
      <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4 shadow-sm">
        <div class="flex items-center justify-between border-b border-[#1c2636] pb-3">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-emerald-400">fingerprint</span>
            <h2 class="font-bold text-sm text-slate-200">AUTHORITATIVE MASTER CHECKSUM MANIFEST</h2>
          </div>
          <span class="text-xs text-slate-400">{{ vaultService.objects().length }} Verified Blocks</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-[#121822] text-slate-400 border-b border-[#1e2838] text-[11px]">
              <tr>
                <th class="p-3">MASTER ASSET</th>
                <th class="p-3">STORAGE TIER</th>
                <th class="p-3">ORIGINAL SHA-256 HASH</th>
                <th class="p-3">REPLICA HEALTH</th>
                <th class="p-3">PROVENANCE</th>
                <th class="p-3">LAST AUDIT</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#182230]">
              @for (obj of vaultService.objects(); track obj.id) {
                <tr class="hover:bg-[#141d2a] transition-colors">
                  <td class="p-3 font-semibold text-slate-100 flex items-center gap-2">
                    <span class="material-icons text-sm text-emerald-400">check_circle</span>
                    <span class="truncate max-w-xs">{{ obj.filename }}</span>
                  </td>
                  <td class="p-3 uppercase text-[10px] text-slate-300 font-mono">{{ obj.storageClass }}</td>
                  <td class="p-3 font-mono text-[10px] text-slate-300 truncate max-w-[200px]">
                    {{ obj.sha256 }}
                  </td>
                  <td class="p-3 font-mono text-[11px]">
                    <span class="text-emerald-400 font-semibold">{{ obj.replicasCount }}/4 Sync</span>
                  </td>
                  <td class="p-3 text-[10px] text-slate-400 font-mono">
                    {{ obj.provenance.type || 'MEASURED' }}
                  </td>
                  <td class="p-3 text-[10px] text-slate-400 font-mono">
                    2026-09-10 02:00 UTC
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class ArchiveIntegrity {
  vaultService = inject(VaultService);

  isAuditing = signal<boolean>(false);
  isHealing = signal<boolean>(false);
  lastAuditResult = signal<AuditRecord | null>(null);
  healingMessage = signal<string | null>(null);

  runAudit(type: 'SAMPLE' | 'DEEP' | 'FULL_ARCHIVE'): void {
    this.isAuditing.set(true);
    this.healingMessage.set(null);

    this.vaultService.runArchiveAudit(type).subscribe({
      next: (res) => {
        this.isAuditing.set(false);
        this.lastAuditResult.set(res.record);
      },
      error: () => this.isAuditing.set(false),
    });
  }

  simulateSelfHealing(): void {
    this.isHealing.set(true);
    this.vaultService.simulateCorruptionRecovery().subscribe({
      next: (res) => {
        this.isHealing.set(false);
        this.healingMessage.set(res.message);
      },
      error: () => this.isHealing.set(false),
    });
  }
}
