import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-time-capsules',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="time-capsules-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-amber-400">lock_clock</span>
            <span class="text-xs font-semibold text-amber-400 uppercase tracking-wider">IMMUTABLE DIGITAL PRESERVATION</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            DIGITAL TIME CAPSULES
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Cryptographically sealed preservation containers scheduled for automated unlocking in future epochs. Stored across 4-way geo-replicated bunkers.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            id="btn-seal-capsule"
            type="button"
            (click)="showSealModal.set(true)"
            class="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
          >
            <span class="material-icons text-sm">lock</span>
            <span>Seal New Capsule</span>
          </button>
        </div>
      </div>

      <!-- TIME CAPSULES GRID -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        @for (capsule of vaultService.timeCapsules(); track capsule.id) {
          <div class="p-6 rounded-xl bg-[#0d1219] border border-[#1e2838] hover:border-amber-500/50 transition-all space-y-4 shadow-sm">
            <!-- Top Header -->
            <div class="flex items-start justify-between gap-3 border-b border-[#1c2636] pb-3">
              <div class="space-y-1">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 rounded text-[10px] bg-amber-950 text-amber-400 font-bold border border-amber-800/40">
                    {{ capsule.archiveStatus }}
                  </span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-purple-950 text-purple-400 border border-purple-800/40">
                    {{ capsule.enforcementType.replace('_', ' ') }}
                  </span>
                </div>
                <h2 class="text-lg font-bold text-white">{{ capsule.title }}</h2>
              </div>
              <div class="w-10 h-10 rounded-xl bg-amber-950/60 border border-amber-700/50 flex items-center justify-center text-amber-400 shrink-0">
                <span class="material-icons text-xl">lock</span>
              </div>
            </div>

            <!-- Description -->
            <p class="text-xs text-slate-300 font-sans leading-relaxed">
              {{ capsule.description }}
            </p>

            <!-- Preservation Stats Matrix -->
            <div class="grid grid-cols-3 gap-3 p-3 rounded-lg bg-[#111722] border border-[#1d2737] text-xs">
              <div>
                <div class="text-[10px] text-slate-400">SEALED ON</div>
                <div class="font-bold text-slate-200">{{ capsule.createdAt.split('T')[0] }}</div>
              </div>
              <div>
                <div class="text-[10px] text-slate-400">UNLOCK HORIZON</div>
                <div class="font-bold text-amber-400">{{ capsule.openDate.split('T')[0] }}</div>
              </div>
              <div>
                <div class="text-[10px] text-slate-400">ITEMS / SIZE</div>
                <div class="font-bold text-slate-200">{{ capsule.itemCount }} / {{ (capsule.totalSizeBytes / 1024 / 1024 / 1024).toFixed(1) }} GB</div>
              </div>
            </div>

            <!-- Item Categories Breakdown -->
            <div class="space-y-1.5">
              <div class="text-[10px] text-slate-400 uppercase font-semibold">PRESERVED ARTIFACTS</div>
              <div class="flex flex-wrap gap-2 text-xs">
                <span class="px-2 py-1 rounded bg-[#16202d] text-cyan-400 text-[11px] border border-[#233144]">
                  📸 {{ capsule.categoriesCount.photos }} Photos
                </span>
                <span class="px-2 py-1 rounded bg-[#16202d] text-rose-400 text-[11px] border border-[#233144]">
                  🎥 {{ capsule.categoriesCount.videos }} 4K Masters
                </span>
                <span class="px-2 py-1 rounded bg-[#16202d] text-purple-400 text-[11px] border border-[#233144]">
                  🎧 {{ capsule.categoriesCount.audio }} FLAC Audio
                </span>
                <span class="px-2 py-1 rounded bg-[#16202d] text-emerald-400 text-[11px] border border-[#233144]">
                  📄 {{ capsule.categoriesCount.documents }} PDF/A Docs
                </span>
              </div>
            </div>

            <!-- Merkle Proof & Replicas -->
            <div class="pt-3 border-t border-[#1a2434] space-y-1 text-[10px] text-slate-400">
              <div class="flex items-center justify-between">
                <span class="text-slate-400">MANIFEST SHA-256 ROOT:</span>
                <span class="text-emerald-400 font-semibold">{{ capsule.replicas }} Geographically Replicated</span>
              </div>
              <div class="p-2 rounded bg-[#090c10] border border-[#161f2b] text-[10px] text-slate-300 truncate select-all">
                {{ capsule.manifestSha256 }}
              </div>
            </div>
          </div>
        }
      </div>

      <!-- SEAL TIME CAPSULE MODAL -->
      @if (showSealModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="w-full max-w-lg bg-[#0d1219] border border-[#26354a] rounded-xl p-6 space-y-4 shadow-2xl">
            <div class="flex items-center justify-between border-b border-[#1c2738] pb-3">
              <div class="flex items-center gap-2">
                <span class="material-icons text-amber-400 text-base">lock_clock</span>
                <h2 class="font-bold text-base text-white">Seal Digital Time Capsule</h2>
              </div>
              <button type="button" (click)="showSealModal.set(false)" class="text-slate-400 hover:text-white text-base cursor-pointer">✕</button>
            </div>

            <form [formGroup]="capsuleForm" (ngSubmit)="submitCapsule()" class="space-y-3 text-xs">
              <div>
                <label for="capsule-title" class="block text-slate-400 mb-1">Capsule Title *</label>
                <input
                  id="capsule-title"
                  formControlName="title"
                  type="text"
                  placeholder="e.g. The 2036 Personal Epoch"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-sans"
                />
              </div>

              <div>
                <label for="capsule-desc" class="block text-slate-400 mb-1">Preservation Context</label>
                <textarea
                  id="capsule-desc"
                  formControlName="description"
                  rows="2"
                  placeholder="Explain the intent and historical context of this sealed preservation archive..."
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-sans"
                ></textarea>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="capsule-date" class="block text-slate-400 mb-1">Unlock Horizon Date *</label>
                  <input
                    id="capsule-date"
                    formControlName="openDate"
                    type="date"
                    class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label for="capsule-enforce" class="block text-slate-400 mb-1">Lock Enforcement</label>
                  <select
                    id="capsule-enforce"
                    formControlName="enforcementType"
                    class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                  >
                    <option value="CRYPTOGRAPHICALLY_ENFORCED">Cryptographically Enforced</option>
                    <option value="SOFTWARE_ENFORCED">Software Daemon Enforced</option>
                    <option value="USER_ENFORCED">User Staked Escrow</option>
                  </select>
                </div>
              </div>

              <div>
                <label for="capsule-emails" class="block text-slate-400 mb-1">Recipient / Trustee Emails (Comma-separated)</label>
                <input
                  id="capsule-emails"
                  formControlName="recipientEmails"
                  type="text"
                  placeholder="tom@ahyx.org, trustee@vaultos.archive"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div class="flex items-center justify-end gap-2 pt-3 border-t border-[#1c2738]">
                <button
                  type="button"
                  (click)="showSealModal.set(false)"
                  class="px-3.5 py-2 rounded-lg bg-[#18212e] text-slate-300 hover:bg-[#202b3c] font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  [disabled]="capsuleForm.invalid"
                  class="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold disabled:opacity-50 cursor-pointer"
                >
                  Commit & Seal
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class TimeCapsules {
  vaultService = inject(VaultService);

  showSealModal = signal<boolean>(false);

  capsuleForm = new FormGroup({
    title: new FormControl('', [Validators.required]),
    description: new FormControl(''),
    openDate: new FormControl('2036-09-10', [Validators.required]),
    enforcementType: new FormControl('CRYPTOGRAPHICALLY_ENFORCED'),
    recipientEmails: new FormControl('tom@ahyx.org'),
  });

  submitCapsule(): void {
    if (this.capsuleForm.invalid) return;
    const val = this.capsuleForm.value;
    const emails = val.recipientEmails ? val.recipientEmails.split(',').map(e => e.trim()).filter(Boolean) : ['tom@ahyx.org'];

    this.vaultService.sealTimeCapsule({
      title: val.title!,
      description: val.description || '',
      openDate: val.openDate + 'T00:00:00Z',
      enforcementType: val.enforcementType || 'CRYPTOGRAPHICALLY_ENFORCED',
      recipientEmails: emails,
      selectedObjectIds: ['obj_vid_01', 'obj_aud_02', 'obj_doc_03'],
    }).subscribe(() => {
      this.showSealModal.set(false);
      this.capsuleForm.reset({
        openDate: '2036-09-10',
        enforcementType: 'CRYPTOGRAPHICALLY_ENFORCED',
        recipientEmails: 'tom@ahyx.org',
      });
    });
  }
}
