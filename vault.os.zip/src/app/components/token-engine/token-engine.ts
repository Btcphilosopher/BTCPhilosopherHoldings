import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-token-engine',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="token-engine-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-amber-400">toll</span>
            <span class="text-xs font-semibold text-amber-400 uppercase tracking-wider">PRIVATE TOKEN NETWORK & APPEND-ONLY LEDGER</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            VAULT.TOKEN (VLT) PROTOCOL
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Cryptographic token network enabling sovereign token-gated content access, time-capsule escrow stakes, and verifiable peer exchange.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            id="btn-open-transfer"
            type="button"
            (click)="showTransferModal.set(true)"
            class="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
          >
            <span class="material-icons text-sm">swap_horiz</span>
            <span>Transfer / Grant VLT</span>
          </button>
        </div>
      </div>

      <!-- TOKEN TREASURY METRICS -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- User Balance -->
        <div class="p-4 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-2">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>MY SOVEREIGN BALANCE</span>
            <span class="material-icons text-base text-amber-400">account_balance_wallet</span>
          </div>
          <div class="text-2xl font-bold text-amber-400 tracking-tight">
            {{ vaultService.tokenState()?.userBalance || 250 }} VLT
          </div>
          <div class="text-[10px] text-emerald-400 flex items-center gap-1">
            <span class="material-icons text-xs">check_circle</span>
            <span>Streaming Tier Authorized</span>
          </div>
        </div>

        <!-- Total Supply -->
        <div class="p-4 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-2">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>TOTAL ISSUANCE</span>
            <span class="material-icons text-base text-slate-400">layers</span>
          </div>
          <div class="text-2xl font-bold text-white tracking-tight">
            1,000,000 VLT
          </div>
          <div class="text-[10px] text-slate-400">Fixed Supply (Decimals: 6)</div>
        </div>

        <!-- Circulating Supply -->
        <div class="p-4 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-2">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>CIRCULATING</span>
            <span class="material-icons text-base text-cyan-400">public</span>
          </div>
          <div class="text-2xl font-bold text-cyan-400 tracking-tight">
            {{ vaultService.tokenState()?.circulating || 742000 }} VLT
          </div>
          <div class="text-[10px] text-slate-400">Distributed to Trustees & Peers</div>
        </div>

        <!-- Locked in Escrow -->
        <div class="p-4 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-2">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>ESCROW STAKED</span>
            <span class="material-icons text-base text-purple-400">lock</span>
          </div>
          <div class="text-2xl font-bold text-purple-400 tracking-tight">
            {{ vaultService.tokenState()?.locked || 100000 }} VLT
          </div>
          <div class="text-[10px] text-slate-400">Locked in 2036 Time Capsule</div>
        </div>
      </div>

      <!-- STATE ROOT HASH BAR -->
      <div class="p-3.5 rounded-xl bg-[#0a0d12] border border-[#1c2738] flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div class="flex items-center gap-2">
          <span class="material-icons text-sm text-amber-400">fingerprint</span>
          <span class="text-slate-400 font-semibold">LEDGER STATE ROOT HASH:</span>
          <span class="text-amber-300 font-mono text-[11px] truncate max-w-sm md:max-w-md">
            {{ vaultService.tokenState()?.stateRootHash }}
          </span>
        </div>
        <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] border border-emerald-800/40 shrink-0">
          APPEND-ONLY CRYPTOGRAPHIC INTEGRITY OK
        </span>
      </div>

      <!-- APPEND-ONLY TRANSACTION LEDGER TABLE -->
      <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] space-y-4 shadow-sm">
        <div class="flex items-center justify-between border-b border-[#1c2636] pb-3">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-amber-400">receipt</span>
            <h2 class="font-bold text-sm text-slate-200">IMMUTABLE TRANSACTION LEDGER</h2>
          </div>
          <span class="text-xs text-slate-400">{{ vaultService.tokenLedger().length }} Committed Blocks</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-[#121822] text-slate-400 border-b border-[#1e2838] text-[11px]">
              <tr>
                <th class="p-3">TRANSACTION ID</th>
                <th class="p-3">TYPE</th>
                <th class="p-3">FROM</th>
                <th class="p-3">TO</th>
                <th class="p-3">AMOUNT</th>
                <th class="p-3">REASON</th>
                <th class="p-3">STATE ROOT (NEW)</th>
                <th class="p-3">PROOF SIGNATURE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#182230]">
              @for (tx of vaultService.tokenLedger(); track tx.id) {
                <tr class="hover:bg-[#141d2a] transition-colors">
                  <td class="p-3 font-mono font-semibold text-slate-200">{{ tx.id }}</td>
                  <td class="p-3">
                    <span
                      class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-950]="tx.type === 'ISSUE' || tx.type === 'GRANT'"
                      [class.text-emerald-400]="tx.type === 'ISSUE' || tx.type === 'GRANT'"
                      [class.bg-amber-950]="tx.type === 'TRANSFER'"
                      [class.text-amber-400]="tx.type === 'TRANSFER'"
                      [class.bg-purple-950]="tx.type === 'LOCK'"
                      [class.text-purple-400]="tx.type === 'LOCK'"
                    >
                      {{ tx.type }}
                    </span>
                  </td>
                  <td class="p-3 text-slate-400 font-mono text-[11px]">{{ tx.from }}</td>
                  <td class="p-3 text-slate-200 font-mono text-[11px] font-semibold">{{ tx.to }}</td>
                  <td class="p-3 text-amber-400 font-bold font-mono">{{ tx.amount }} VLT</td>
                  <td class="p-3 text-slate-300 font-sans text-[11px]">{{ tx.reason }}</td>
                  <td class="p-3 font-mono text-[10px] text-slate-400 truncate max-w-[120px]">
                    {{ tx.newStateHash.substring(0, 14) }}...
                  </td>
                  <td class="p-3 font-mono text-[10px] text-emerald-400">
                    Ed25519 Verified
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- TRANSFER / GRANT MODAL -->
      @if (showTransferModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="w-full max-w-lg bg-[#0d1219] border border-[#26354a] rounded-xl p-6 space-y-4 shadow-2xl">
            <div class="flex items-center justify-between border-b border-[#1c2738] pb-3">
              <div class="flex items-center gap-2">
                <span class="material-icons text-amber-400 text-base">swap_horiz</span>
                <h2 class="font-bold text-base text-white">Execute Token Ledger Transfer</h2>
              </div>
              <button type="button" (click)="showTransferModal.set(false)" class="text-slate-400 hover:text-white text-base cursor-pointer">✕</button>
            </div>

            <form [formGroup]="transferForm" (ngSubmit)="submitTransfer()" class="space-y-3 text-xs">
              <div>
                <label for="tx-recipient" class="block text-slate-400 mb-1">Recipient Handle or Public Key *</label>
                <input
                  id="tx-recipient"
                  formControlName="to"
                  type="text"
                  placeholder="e.g. collaborator_zurich or @alice"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div>
                <label for="tx-amount" class="block text-slate-400 mb-1">Amount (VLT) * (Max: {{ vaultService.tokenState()?.userBalance }} VLT)</label>
                <input
                  id="tx-amount"
                  formControlName="amount"
                  type="number"
                  placeholder="50"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div>
                <label for="tx-reason" class="block text-slate-400 mb-1">Transaction Reason / Governance Memo *</label>
                <input
                  id="tx-reason"
                  formControlName="reason"
                  type="text"
                  placeholder="e.g. Granted token-gated tier access to High Peak 4K masters"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-sans"
                />
              </div>

              <div class="p-3 rounded-lg bg-[#0a0d12] border border-[#1b2536] text-[10px] text-slate-400 space-y-1">
                <div>⚡ This transaction creates an immutable cryptographic block.</div>
                <div>⚡ The previous state hash will be linked to the new root state.</div>
              </div>

              <div class="flex items-center justify-end gap-2 pt-3 border-t border-[#1c2738]">
                <button
                  type="button"
                  (click)="showTransferModal.set(false)"
                  class="px-3.5 py-2 rounded-lg bg-[#18212e] text-slate-300 hover:bg-[#202b3c] font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  [disabled]="transferForm.invalid"
                  class="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold disabled:opacity-50 cursor-pointer"
                >
                  Sign & Commit Block
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class TokenEngine {
  vaultService = inject(VaultService);

  showTransferModal = signal<boolean>(false);

  transferForm = new FormGroup({
    to: new FormControl('', [Validators.required]),
    amount: new FormControl(50, [Validators.required, Validators.min(1)]),
    reason: new FormControl('Sovereign peer grant', [Validators.required]),
  });

  submitTransfer(): void {
    if (this.transferForm.invalid) return;
    const val = this.transferForm.value;

    this.vaultService.transferTokens(val.to!, Number(val.amount!), val.reason!).subscribe(() => {
      this.showTransferModal.set(false);
      this.transferForm.reset({
        amount: 50,
        reason: 'Sovereign peer grant',
      });
    });
  }
}
