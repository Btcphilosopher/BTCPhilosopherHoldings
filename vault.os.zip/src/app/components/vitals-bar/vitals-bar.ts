import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';

@Component({
  selector: 'app-vitals-bar',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header id="vault-header" class="border-b border-[#1c222e] bg-[#0c0f14]/90 backdrop-blur-md sticky top-0 z-40 px-4 py-2.5 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
      <!-- Left: Logo & System Identity -->
      <div class="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
        <div class="flex items-center gap-2.5">
          <div class="w-7 h-7 rounded bg-[#10b981]/15 border border-[#10b981]/40 flex items-center justify-center text-[#10b981] font-mono font-bold tracking-tighter shadow-sm">
            V•
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="font-mono font-bold text-sm tracking-wider text-slate-100">VAULT.OS</span>
              <span class="px-1.5 py-0.5 rounded bg-[#10b981]/10 text-[#10b981] font-mono text-[10px] border border-[#10b981]/30">v3.7 SOVEREIGN</span>
            </div>
            <div class="text-[10px] text-slate-400 font-mono flex items-center gap-1.5">
              <span>TOM'S ARCHIVE</span>
              <span>•</span>
              <span class="text-emerald-400 flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                SYSTEM HEALTHY
              </span>
            </div>
          </div>
        </div>

        <!-- Mobile quick stats toggle -->
        <div class="md:hidden flex items-center gap-2 font-mono text-[11px] text-slate-300">
          <span class="text-[#06b6d4]">8.4 TB</span>
          <span>•</span>
          <span class="text-emerald-400">{{ vaultService.vitals()?.userVltBalance || 250 }} VLT</span>
        </div>
      </div>

      <!-- Center: Vitals & Cryptographic Telemetry -->
      <div class="hidden lg:flex items-center gap-6 font-mono text-[11px] bg-[#07090c] px-4 py-1.5 rounded-lg border border-[#1c222e]">
        <div class="flex items-center gap-2">
          <span class="text-slate-400">STORAGE:</span>
          <span class="text-slate-100 font-semibold">8.43 TB</span>
          <span class="text-slate-400">/ 10.0 TB (76.7%)</span>
        </div>
        <div class="h-3 w-px bg-[#1c222e]"></div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400">REPLICAS:</span>
          <span class="text-[#10b981] font-semibold">4/4 SYNCED</span>
          <span class="text-slate-400">(0.2ms)</span>
        </div>
        <div class="h-3 w-px bg-[#1c222e]"></div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400">ARCHIVE:</span>
          <span class="text-emerald-400 font-semibold">4,829 OBJECTS</span>
          <span class="text-slate-400">[VERIFIED]</span>
        </div>
        <div class="h-3 w-px bg-[#1c222e]"></div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400">TOKEN:</span>
          <span class="text-amber-400 font-semibold">{{ vaultService.vitals()?.userVltBalance || 250 }} VLT</span>
        </div>
      </div>

      <!-- Right: Search & Quick Actions -->
      <div class="flex items-center gap-2.5 w-full md:w-auto justify-end">
        <!-- Natural Search input -->
        <div class="relative flex-1 md:w-64">
          <span class="material-icons-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm pointer-events-none">search</span>
          <input
            [formControl]="searchControl"
            (keydown.enter)="onSearchSubmit()"
            type="text"
            placeholder="Natural Search (AI or Tag)..."
            class="w-full bg-[#12161f] text-slate-200 pl-8 pr-8 py-1.5 rounded-md border border-[#232a38] text-xs font-mono focus:outline-none focus:border-[#10b981] focus:ring-1 focus:ring-[#10b981]/40 placeholder:text-slate-500 transition-all"
          />
          @if (searchControl.value) {
            <button
              (click)="clearSearch()"
              type="button"
              class="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 text-xs font-mono"
            >✕</button>
          }
        </div>

        <button
          id="btn-quick-ingest"
          type="button"
          (click)="triggerIngest.emit()"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#10b981] hover:bg-[#059669] text-black font-semibold text-xs transition-all shadow-sm active:scale-95 cursor-pointer whitespace-nowrap"
        >
          <span class="material-icons text-sm">add_circle</span>
          <span>Ingest Master</span>
        </button>

        <button
          id="btn-quick-export"
          type="button"
          (click)="vaultService.downloadExportVault()"
          title="Download Complete Portable Vault Export Package"
          class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-[#181d26] hover:bg-[#202734] text-slate-200 border border-[#263040] text-xs font-mono transition-all cursor-pointer whitespace-nowrap"
        >
          <span class="material-icons text-sm text-cyan-400">download</span>
          <span class="hidden sm:inline">Export</span>
        </button>
      </div>
    </header>
  `,
})
export class VitalsBar {
  vaultService = inject(VaultService);
  triggerIngest = output<void>();
  triggerSearch = output<string>();

  searchControl = new FormControl('');

  onSearchSubmit(): void {
    const val = this.searchControl.value?.trim();
    if (val) {
      this.triggerSearch.emit(val);
    }
  }

  clearSearch(): void {
    this.searchControl.setValue('');
    this.triggerSearch.emit('');
  }
}
