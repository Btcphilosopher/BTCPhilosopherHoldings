import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Collection } from '../../core/models/vault.model';

@Component({
  selector: 'app-collections-view',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="collections-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-mono">
      <!-- HEADER -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432]">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="material-icons text-base text-amber-400">collections_bookmark</span>
            <span class="text-xs font-semibold text-amber-400 uppercase tracking-wider">CURATED ARCHIVES & PUBLISHING</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold text-white tracking-tight">
            SOVEREIGN COLLECTIONS
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl font-sans">
            Grouped preservation containers with customizable access policies: Private, Token-Gated (VLT stake), or Cryptographic Private Links.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            id="btn-new-collection"
            type="button"
            (click)="showCreateModal.set(true)"
            class="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
          >
            <span class="material-icons text-sm">create_new_folder</span>
            <span>New Collection</span>
          </button>
        </div>
      </div>

      <!-- COLLECTIONS GRID -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @for (col of vaultService.collections(); track col.id) {
          <div class="p-5 rounded-xl bg-[#0d1219] border border-[#1e2838] hover:border-amber-500/50 transition-all shadow-sm flex flex-col justify-between space-y-4 group">
            <div class="space-y-3">
              <!-- Cover Image & Badges -->
              <div class="relative w-full h-40 rounded-lg bg-[#141a24] overflow-hidden border border-[#222e40]">
                @if (col.coverImageUrl) {
                  <img [src]="col.coverImageUrl" [alt]="col.name" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerpolicy="no-referrer" />
                  <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                }
                <!-- Publish Type Badge -->
                <div class="absolute top-2.5 left-2.5">
                  <span
                    class="px-2 py-0.5 rounded text-[10px] font-bold font-mono tracking-wider border shadow"
                    [class.bg-emerald-950]="col.publishType === 'PUBLIC'"
                    [class.text-emerald-400]="col.publishType === 'PUBLIC'"
                    [class.border-emerald-700/50]="col.publishType === 'PUBLIC'"
                    [class.bg-amber-950]="col.publishType === 'TOKEN_GATED'"
                    [class.text-amber-400]="col.publishType === 'TOKEN_GATED'"
                    [class.border-amber-700/50]="col.publishType === 'TOKEN_GATED'"
                    [class.bg-blue-950]="col.publishType === 'PRIVATE_LINK'"
                    [class.text-blue-400]="col.publishType === 'PRIVATE_LINK'"
                    [class.border-blue-700/50]="col.publishType === 'PRIVATE_LINK'"
                  >
                    {{ col.publishType }}
                  </span>
                </div>

                @if (col.publishType === 'TOKEN_GATED') {
                  <div class="absolute top-2.5 right-2.5 px-2 py-0.5 rounded bg-black/80 border border-amber-500/50 text-amber-400 text-[10px] font-bold font-mono flex items-center gap-1 shadow">
                    <span class="material-icons text-[10px]">lock</span>
                    <span>{{ col.tokenGateRequirement || 100 }} VLT</span>
                  </div>
                }

                <div class="absolute bottom-2.5 left-2.5 text-[11px] text-slate-300 font-mono">
                  <span>{{ col.itemCount }} Items</span>
                  <span>•</span>
                  <span>{{ (col.totalSizeBytes / 1024 / 1024 / 1024).toFixed(1) }} GB Master</span>
                </div>
              </div>

              <!-- Title & Description -->
              <div>
                <h3 class="text-base font-bold text-white group-hover:text-amber-400 transition-colors">{{ col.name }}</h3>
                <p class="text-xs text-slate-400 font-sans mt-1 leading-relaxed line-clamp-2">{{ col.description }}</p>
              </div>

              <!-- Tags -->
              <div class="flex flex-wrap gap-1">
                @for (tag of col.tags; track tag) {
                  <span class="px-1.5 py-0.2 rounded bg-[#17212e] text-slate-400 text-[10px] border border-[#233144]">
                    #{{ tag }}
                  </span>
                }
              </div>
            </div>

            <!-- Bottom Actions -->
            <div class="pt-3 border-t border-[#1a2434] flex items-center justify-between text-xs">
              <span class="text-[10px] text-slate-400">Created: {{ col.createdAt.split('T')[0] }}</span>
              <button
                type="button"
                (click)="openCollection(col)"
                class="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <span>Browse Archive</span>
                <span class="material-icons text-xs">arrow_forward</span>
              </button>
            </div>
          </div>
        }
      </div>

      <!-- CREATE COLLECTION MODAL -->
      @if (showCreateModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="w-full max-w-lg bg-[#0d1219] border border-[#26354a] rounded-xl p-6 space-y-4 shadow-2xl">
            <div class="flex items-center justify-between border-b border-[#1c2738] pb-3">
              <div class="flex items-center gap-2">
                <span class="material-icons text-amber-400 text-base">create_new_folder</span>
                <h2 class="font-bold text-base text-white">Create Sovereign Collection</h2>
              </div>
              <button type="button" (click)="showCreateModal.set(false)" class="text-slate-400 hover:text-white text-base cursor-pointer">✕</button>
            </div>

            <form [formGroup]="collectionForm" (ngSubmit)="submitCollection()" class="space-y-3 text-xs">
              <div>
                <label for="col-name" class="block text-slate-400 mb-1">Collection Name *</label>
                <input
                  id="col-name"
                  formControlName="name"
                  type="text"
                  placeholder="e.g. Master Audio Field Recordings"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-sans"
                />
              </div>

              <div>
                <label for="col-description" class="block text-slate-400 mb-1">Description</label>
                <textarea
                  id="col-description"
                  formControlName="description"
                  rows="2"
                  placeholder="Archival context and preservation mandate..."
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-sans"
                ></textarea>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="col-publish-type" class="block text-slate-400 mb-1">Publish Policy</label>
                  <select
                    id="col-publish-type"
                    formControlName="publishType"
                    class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                  >
                    <option value="PRIVATE_LINK">Private Link Only</option>
                    <option value="TOKEN_GATED">Token-Gated (VLT)</option>
                    <option value="PUBLIC">Public Sovereign Feed</option>
                  </select>
                </div>

                <div>
                  <label for="col-token-requirement" class="block text-slate-400 mb-1">Token Gate (VLT)</label>
                  <input
                    id="col-token-requirement"
                    formControlName="tokenGateRequirement"
                    type="number"
                    placeholder="100"
                    class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div>
                <label for="col-tags" class="block text-slate-400 mb-1">Tags (Comma-separated)</label>
                <input
                  id="col-tags"
                  formControlName="tags"
                  type="text"
                  placeholder="High Peak, FLAC, Master"
                  class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div class="flex items-center justify-end gap-2 pt-3 border-t border-[#1c2738]">
                <button
                  type="button"
                  (click)="showCreateModal.set(false)"
                  class="px-3.5 py-2 rounded-lg bg-[#18212e] text-slate-300 hover:bg-[#202b3c] font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  [disabled]="collectionForm.invalid"
                  class="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold disabled:opacity-50 cursor-pointer"
                >
                  Create Collection
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
})
export class CollectionsView {
  vaultService = inject(VaultService);
  inspectObject = output<string>();

  showCreateModal = signal<boolean>(false);

  collectionForm = new FormGroup({
    name: new FormControl('', [Validators.required]),
    description: new FormControl(''),
    publishType: new FormControl<'PRIVATE_LINK' | 'TOKEN_GATED' | 'PUBLIC'>('PRIVATE_LINK'),
    tokenGateRequirement: new FormControl(0),
    tags: new FormControl('Preservation, Master'),
  });

  openCollection(col: Collection): void {
    if (col.itemIds && col.itemIds.length > 0) {
      this.inspectObject.emit(col.itemIds[0]);
    }
  }

  submitCollection(): void {
    if (this.collectionForm.invalid) return;
    const val = this.collectionForm.value;
    const tagsArr = val.tags ? val.tags.split(',').map(t => t.trim()).filter(Boolean) : ['Archive'];

    this.vaultService.createCollection({
      name: val.name!,
      description: val.description || '',
      publishType: val.publishType || 'PRIVATE_LINK',
      tokenGateRequirement: Number(val.tokenGateRequirement) || 0,
      tags: tagsArr,
      coverImageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80',
    }).subscribe(() => {
      this.showCreateModal.set(false);
      this.collectionForm.reset({
        publishType: 'PRIVATE_LINK',
        tokenGateRequirement: 0,
      });
    });
  }
}
