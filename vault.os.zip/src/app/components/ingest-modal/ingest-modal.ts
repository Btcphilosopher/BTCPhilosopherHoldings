import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { VaultObject } from '../../core/models/vault.model';

@Component({
  selector: 'app-ingest-modal',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 font-mono">
      <div class="w-full max-w-2xl bg-[#0d1219] border border-[#26354a] rounded-xl p-6 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]">
        <!-- Top Bar -->
        <div class="flex items-center justify-between border-b border-[#1c2738] pb-3">
          <div class="flex items-center gap-2">
            <span class="material-icons text-emerald-400 text-base">cloud_upload</span>
            <h2 class="font-bold text-base text-white">Cryptographic Ingestion Pipeline</h2>
          </div>
          <button type="button" (click)="closeModal.emit()" class="text-slate-400 hover:text-white text-base cursor-pointer">✕</button>
        </div>

        <form [formGroup]="ingestForm" (ngSubmit)="startIngest()" class="space-y-4 text-xs">
          <!-- File Drop Zone Area -->
          <div
            tabindex="0"
            role="button"
            (click)="fileInput.click()"
            (keydown.enter)="fileInput.click()"
            class="p-6 rounded-xl border-2 border-dashed border-[#26354a] hover:border-emerald-400/60 bg-[#111620] text-center space-y-2 cursor-pointer transition-colors"
          >
            <input #fileInput type="file" (change)="onFileSelected($event)" class="hidden" />
            <span class="material-icons text-3xl text-emerald-400">upload_file</span>
            <div class="text-xs font-bold text-slate-200">
              {{ selectedFileName() ? selectedFileName() : 'Click or drag master raw files to ingest' }}
            </div>
            <p class="text-[11px] text-slate-400 font-sans max-w-md mx-auto">
              Accepts uncompressed 4K ProRes/H.265 video, 24-bit FLAC audio, RAW photography, and PDF/A archives.
            </p>
          </div>

          <!-- Filename & Description -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label for="ingest-filename" class="block text-slate-400 mb-1">Asset Filename *</label>
              <input
                id="ingest-filename"
                formControlName="filename"
                type="text"
                placeholder="e.g. Master_Field_Archive_2026.mov"
                class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-emerald-400 font-mono"
              />
            </div>

            <div>
              <label for="ingest-type" class="block text-slate-400 mb-1">Asset Type *</label>
              <select
                id="ingest-type"
                formControlName="type"
                class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-emerald-400 font-mono"
              >
                <option value="video">Video (4K Cinema Master)</option>
                <option value="audio">Audio (Hi-Res Lossless FLAC)</option>
                <option value="image">Image (High-Res Master)</option>
                <option value="document">Document (Preservation PDF/A)</option>
              </select>
            </div>
          </div>

          <div>
            <label for="ingest-desc" class="block text-slate-400 mb-1">Preservation Context & Description</label>
            <textarea
              id="ingest-desc"
              formControlName="humanDescription"
              rows="2"
              placeholder="Provide archival notes, recording location, context, or significance..."
              class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-emerald-400 font-sans"
            ></textarea>
          </div>

          <!-- Storage Class & Timescape Date -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label for="ingest-storage-class" class="block text-slate-400 mb-1">Storage Class</label>
              <select
                id="ingest-storage-class"
                formControlName="storageClass"
                class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-emerald-400 font-mono"
              >
                <option value="ARCHIVE">ARCHIVE (4-way Geo-Replicated)</option>
                <option value="HOT">HOT (NVMe High-Speed Streaming)</option>
                <option value="COLD">COLD (Air-Gapped LTO-9 Tape)</option>
              </select>
            </div>

            <div>
              <label for="ingest-capture-date" class="block text-slate-400 mb-1">Timescape Capture Date</label>
              <input
                id="ingest-capture-date"
                formControlName="captureDate"
                type="date"
                class="w-full bg-[#131923] text-slate-200 px-2.5 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-emerald-400 font-mono"
              />
            </div>
          </div>

          <!-- Token-Gating Option -->
          <div class="p-3.5 rounded-lg bg-[#111722] border border-[#1d2737] space-y-2">
            <label class="flex items-center gap-2 cursor-pointer">
              <input
                id="ingest-token-gate-chk"
                formControlName="isTokenGated"
                type="checkbox"
                class="rounded bg-[#1a2332] border-[#2c3b52] text-amber-500 focus:ring-0"
              />
              <span class="text-slate-200 font-bold">Require VAULT.TOKEN (VLT) Stake to Stream</span>
            </label>

            @if (ingestForm.get('isTokenGated')?.value) {
              <div class="flex items-center gap-2 pt-1">
                <label for="ingest-min-token" class="text-slate-400">Minimum VLT Required:</label>
                <input
                  id="ingest-min-token"
                  formControlName="minTokenRequired"
                  type="number"
                  class="w-20 bg-[#161f2c] text-amber-400 px-2 py-1 rounded border border-amber-500/40 text-xs font-mono focus:outline-none"
                />
              </div>
            }
          </div>

          <!-- Tags -->
          <div>
            <label for="ingest-tags" class="block text-slate-400 mb-1">Archival Tags (Comma-separated)</label>
            <input
              id="ingest-tags"
              formControlName="tags"
              type="text"
              placeholder="High Peak, 4K Master, ProRes, 2026"
              class="w-full bg-[#131923] text-slate-200 px-3 py-2 rounded-lg border border-[#222e40] focus:outline-none focus:border-emerald-400 font-mono"
            />
          </div>

          <!-- Ingestion Progress / Verification Phase -->
          @if (isProcessing()) {
            <div class="p-3 rounded-lg bg-[#0a0e14] border border-emerald-500/40 space-y-2 animate-pulse">
              <div class="flex items-center justify-between text-emerald-400">
                <span>Computing SHA-256 Merkle Block Tree...</span>
                <span>{{ progressPercent() }}%</span>
              </div>
              <div class="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                <div class="h-full bg-emerald-400 rounded-full" [style.width.%]="progressPercent()"></div>
              </div>
            </div>
          }

          <!-- Modal Action Buttons -->
          <div class="flex items-center justify-end gap-2 pt-3 border-t border-[#1c2738]">
            <button
              type="button"
              (click)="closeModal.emit()"
              class="px-3.5 py-2 rounded-lg bg-[#18212e] text-slate-300 hover:bg-[#202b3c] font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              [disabled]="ingestForm.invalid || isProcessing()"
              class="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-semibold disabled:opacity-50 flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <span class="material-icons text-sm">lock</span>
              <span>Seal & Ingest Asset</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
})
export class IngestModal {
  vaultService = inject(VaultService);
  closeModal = output<void>();

  selectedFileName = signal<string>('');
  isProcessing = signal<boolean>(false);
  progressPercent = signal<number>(0);

  ingestForm = new FormGroup({
    filename: new FormControl('Peak_District_Summit_4K_ProRes.mov', [Validators.required]),
    type: new FormControl<'video' | 'audio' | 'image' | 'document'>('video', [Validators.required]),
    humanDescription: new FormControl('Uncompressed 4K master ProRes recording of the autumn sunrise along the ridge.'),
    storageClass: new FormControl<'HOT' | 'WARM' | 'COLD' | 'ARCHIVE'>('ARCHIVE'),
    captureDate: new FormControl('2026-09-08'),
    isTokenGated: new FormControl(false),
    minTokenRequired: new FormControl(50),
    tags: new FormControl('High Peak, 4K Master, Autumn'),
  });

  onFileSelected(event: Event): void {
    const target = event.target as HTMLInputElement;
    const file = target.files?.[0];
    if (file) {
      this.selectedFileName.set(file.name);
      this.ingestForm.patchValue({
        filename: file.name,
        type: file.type.startsWith('video') ? 'video' : file.type.startsWith('audio') ? 'audio' : file.type.startsWith('image') ? 'image' : 'document',
      });
    }
  }

  startIngest(): void {
    if (this.ingestForm.invalid) return;
    this.isProcessing.set(true);
    this.progressPercent.set(20);

    const val = this.ingestForm.value;
    const tagsArr = val.tags ? val.tags.split(',').map(t => t.trim()).filter(Boolean) : ['Master'];

    setTimeout(() => {
      this.progressPercent.set(65);
      setTimeout(() => {
        this.progressPercent.set(100);

        this.vaultService.ingestObject({
          filename: val.filename!,
          type: (val.type || 'video') as VaultObject['type'],
          mimeType: val.type === 'video' ? 'video/quicktime' : val.type === 'audio' ? 'audio/flac' : 'application/octet-stream',
          sizeBytes: 1420580920,
          humanDescription: val.humanDescription || '',
          storageClass: (val.storageClass || 'ARCHIVE') as VaultObject['storageClass'],
          tags: tagsArr,
          isTokenGated: !!val.isTokenGated,
          minTokenRequired: val.isTokenGated ? Number(val.minTokenRequired) : 0,
          captureDate: val.captureDate || '2026-09-08',
          videoInfo: val.type === 'video' ? {
            durationSeconds: 420,
            resolution: '3840x2160 (4K)',
            codec: 'Apple ProRes 422 HQ',
            frameRate: 60,
            thumbnailUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
          } : undefined,
          audioInfo: val.type === 'audio' ? {
            durationSeconds: 340,
            bitrateKbps: 4608,
            sampleRateHz: 96000,
            codec: 'FLAC (24-bit Lossless)',
            artist: 'Tom Harrison',
            album: 'Peak District Recordings',
          } : undefined,
        }).subscribe(() => {
          this.isProcessing.set(false);
          this.closeModal.emit();
        });
      }, 500);
    }, 400);
  }
}
