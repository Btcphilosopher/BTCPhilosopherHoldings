import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="dashboard-view" class="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      <!-- SYSTEM HEADER BANNER -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-xl bg-gradient-to-r from-[#0d1219] via-[#101722] to-[#0c1017] border border-[#222e40] shadow-md">
        <div class="space-y-1">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span class="font-mono text-xs font-semibold uppercase tracking-wider text-emerald-400">ARCHIVAL DAEMON ACTIVE</span>
            <span class="text-slate-600 font-mono">•</span>
            <span class="font-mono text-xs text-slate-400">NODE ID: ZURICH-ALPHA-01</span>
          </div>
          <h1 class="text-xl md:text-2xl font-bold tracking-tight text-white font-mono">
            VAULT.OS DIGITAL TWIN & COMMAND CENTRE
          </h1>
          <p class="text-xs text-slate-400 max-w-2xl">
            Autonomous multi-replica digital sovereignty platform. Zero external dependencies. Continuous cryptographic hash verification across local NVMe and cold remote bunkers.
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2 font-mono text-xs">
          <button
            (click)="triggerIngest.emit()"
            class="px-3.5 py-2 rounded-lg bg-[#10b981] hover:bg-[#059669] text-black font-semibold transition-all shadow-sm active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            <span class="material-icons text-sm">cloud_upload</span>
            <span>Ingest Master</span>
          </button>
          <button
            (click)="navTab.emit('archive-integrity')"
            class="px-3 py-2 rounded-lg bg-[#192231] hover:bg-[#222e42] text-slate-200 border border-[#2c3d59] transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span class="material-icons text-sm text-emerald-400">verified</span>
            <span>Run Audit</span>
          </button>
          <button
            (click)="navTab.emit('export-sovereignty')"
            class="px-3 py-2 rounded-lg bg-[#192231] hover:bg-[#222e42] text-slate-200 border border-[#2c3d59] transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span class="material-icons text-sm text-cyan-400">inventory_2</span>
            <span>Export Archive</span>
          </button>
        </div>
      </div>

      <!-- KEY METRICS GRID -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <!-- 1. STORAGE -->
        <div class="p-4 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-3">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>STORAGE CAPACITY</span>
            <span class="material-icons text-base text-cyan-400">pie_chart</span>
          </div>
          <div>
            <div class="text-2xl font-bold text-white tracking-tight">8.43 TB</div>
            <div class="text-[11px] text-slate-400 flex items-center justify-between mt-1">
              <span>Allocated: 10.00 TB</span>
              <span class="text-cyan-400 font-semibold">76.7% used</span>
            </div>
          </div>
          <!-- Progress bar -->
          <div class="w-full h-1.5 bg-[#17202d] rounded-full overflow-hidden">
            <div class="h-full bg-cyan-400 rounded-full" style="width: 76.7%"></div>
          </div>
        </div>

        <!-- 2. REPLICAS & GEO-PERSISTENCE -->
        <div class="p-4 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-3">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>GEO REPLICAS</span>
            <span class="material-icons text-base text-emerald-400">public</span>
          </div>
          <div>
            <div class="text-2xl font-bold text-emerald-400 tracking-tight">4 / 4 ONLINE</div>
            <div class="text-[11px] text-slate-400 mt-1">
              Local NVMe + Zurich + Reykjavik + LTO Tape
            </div>
          </div>
          <div class="flex items-center gap-1.5 text-[10px] text-emerald-400">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>100% Bit-for-bit Parity</span>
          </div>
        </div>

        <!-- 3. VERIFIED OBJECTS -->
        <div class="p-4 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-3">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>VERIFIED OBJECTS</span>
            <span class="material-icons text-base text-purple-400">fingerprint</span>
          </div>
          <div>
            <div class="text-2xl font-bold text-white tracking-tight">4,829</div>
            <div class="text-[11px] text-slate-400 mt-1">
              0 Corrupted Blocks Detected
            </div>
          </div>
          <div class="flex items-center gap-1.5 text-[10px] text-slate-400">
            <span class="material-icons text-xs text-purple-400">lock</span>
            <span>SHA-256 Merkle Provenance</span>
          </div>
        </div>

        <!-- 4. TOKEN TREASURY -->
        <div class="p-4 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-3">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>VAULT TOKEN (VLT)</span>
            <span class="material-icons text-base text-amber-400">toll</span>
          </div>
          <div>
            <div class="text-2xl font-bold text-amber-400 tracking-tight">250 VLT</div>
            <div class="text-[11px] text-slate-400 mt-1">
              Treasury: 158,000 / 1,000,000 VLT
            </div>
          </div>
          <div class="flex items-center gap-1.5 text-[10px] text-amber-400/80">
            <span>Append-Only Ledger Active</span>
          </div>
        </div>
      </div>

      <!-- MIDDLE: GEO REPLICATION MATRIX & TIMESCAPE HORIZON -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- GEO REPLICATION MATRIX -->
        <div class="lg:col-span-1 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="material-icons text-base text-emerald-400">dns</span>
              <h2 class="font-mono font-bold text-sm text-slate-200">STORAGE CLUSTERS</h2>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800/40">SYNCHRONIZED</span>
          </div>

          <div class="space-y-2.5 font-mono text-xs">
            <!-- 1. Primary -->
            <div class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] flex items-center justify-between">
              <div class="space-y-0.5">
                <div class="font-semibold text-slate-100 flex items-center gap-1.5">
                  <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  Primary NVMe Array
                </div>
                <div class="text-[11px] text-slate-400">Local High-IOPS Cluster • 0.2ms</div>
              </div>
              <div class="text-right">
                <div class="text-emerald-400 font-semibold">8.43 TB</div>
                <div class="text-[10px] text-slate-500">HOT TIER</div>
              </div>
            </div>

            <!-- 2. Zurich -->
            <div class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] flex items-center justify-between">
              <div class="space-y-0.5">
                <div class="font-semibold text-slate-100 flex items-center gap-1.5">
                  <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  Replica A (Zurich Bunker)
                </div>
                <div class="text-[11px] text-slate-400">Alpine Data Shelter • 14.8ms</div>
              </div>
              <div class="text-right">
                <div class="text-emerald-400 font-semibold">8.43 TB</div>
                <div class="text-[10px] text-slate-500">ENCRYPTED</div>
              </div>
            </div>

            <!-- 3. Reykjavik -->
            <div class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] flex items-center justify-between">
              <div class="space-y-0.5">
                <div class="font-semibold text-slate-100 flex items-center gap-1.5">
                  <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  Replica B (Reykjavik)
                </div>
                <div class="text-[11px] text-slate-400">Geothermal Cold Vault • 28.1ms</div>
              </div>
              <div class="text-right">
                <div class="text-emerald-400 font-semibold">8.43 TB</div>
                <div class="text-[10px] text-slate-500">ENCRYPTED</div>
              </div>
            </div>

            <!-- 4. LTO Tape -->
            <div class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] flex items-center justify-between">
              <div class="space-y-0.5">
                <div class="font-semibold text-slate-100 flex items-center gap-1.5">
                  <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
                  Cold Archive (LTO-9 Tape)
                </div>
                <div class="text-[11px] text-slate-400">Air-Gapped Magnetic • Offline</div>
              </div>
              <div class="text-right">
                <div class="text-cyan-400 font-semibold">8.43 TB</div>
                <div class="text-[10px] text-slate-500">PERMANENT</div>
              </div>
            </div>
          </div>
        </div>

        <!-- TIMESCAPE HORIZON & MEMORY MATRIX (2 cols) -->
        <div class="lg:col-span-2 p-5 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="material-icons text-base text-cyan-400">timeline</span>
              <h2 class="font-mono font-bold text-sm text-slate-200">TIMESCAPE HORIZON (2021 — 2026)</h2>
            </div>
            <button
              (click)="navTab.emit('timescape')"
              class="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
            >
              <span>Explore Full Timescape</span>
              <span class="material-icons text-xs">arrow_forward</span>
            </button>
          </div>

          <!-- Timescape timeline nodes -->
          <div class="space-y-3 font-mono text-xs">
            @for (event of vaultService.timescapeEvents().slice(0, 4); track event.id) {
              <div class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-cyan-500/40 transition-colors">
                <div class="flex items-start gap-3">
                  <div class="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800/40 flex items-center justify-center text-cyan-400 shrink-0">
                    <span class="material-icons text-sm">
                      {{ event.category === 'media' ? 'play_circle' : event.category === 'capsule' ? 'lock_clock' : 'feed' }}
                    </span>
                  </div>
                  <div>
                    <div class="font-semibold text-slate-100">{{ event.title }}</div>
                    <div class="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{{ event.summary }}</div>
                  </div>
                </div>
                <div class="flex items-center gap-2 shrink-0 sm:text-right">
                  <span class="px-2 py-0.5 rounded bg-[#1c2534] text-slate-300 text-[10px]">{{ event.date }}</span>
                  @if (event.location) {
                    <span class="text-[10px] text-slate-400 hidden md:inline">📍 {{ event.location }}</span>
                  }
                </div>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- BOTTOM: RECENT MASTER OBJECTS & IMMUTABLE AUDIT STREAM -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- RECENT MASTER OBJECTS -->
        <div class="p-5 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="material-icons text-base text-purple-400">folder_special</span>
              <h2 class="font-mono font-bold text-sm text-slate-200">RECENT MASTER INGESTIONS</h2>
            </div>
            <button
              type="button"
              (click)="navTab.emit('vault-explorer')"
              class="text-xs font-mono text-purple-400 hover:text-purple-300 flex items-center gap-1 cursor-pointer"
            >
              <span>View All {{ vaultService.objects().length }}</span>
              <span class="material-icons text-xs">arrow_forward</span>
            </button>
          </div>

          <div class="space-y-2.5 font-mono text-xs">
            @for (obj of vaultService.objects().slice(0, 4); track obj.id) {
              <div
                tabindex="0"
                role="button"
                (click)="inspectObject.emit(obj.id)"
                (keydown.enter)="inspectObject.emit(obj.id)"
                class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] flex items-center justify-between hover:border-purple-500/40 transition-colors cursor-pointer"
              >
                <div class="flex items-center gap-3">
                  <div class="w-8 h-8 rounded-lg bg-purple-950 border border-purple-800/40 flex items-center justify-center text-purple-400 shrink-0">
                    <span class="material-icons text-sm">
                      {{ obj.type === 'video' ? 'videocam' : obj.type === 'audio' ? 'audiotrack' : obj.type === 'image' ? 'photo' : 'description' }}
                    </span>
                  </div>
                  <div>
                    <div class="font-semibold text-slate-100 truncate max-w-[200px] sm:max-w-xs">{{ obj.filename }}</div>
                    <div class="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>{{ (obj.sizeBytes / 1024 / 1024).toFixed(1) }} MB</span>
                      <span>•</span>
                      <span class="text-emerald-400">SHA-256: {{ obj.sha256.substring(0, 10) }}...</span>
                    </div>
                  </div>
                </div>
                <div class="flex items-center gap-2">
                  <span class="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/30">VERIFIED</span>
                  <span class="material-icons text-slate-500 text-sm">chevron_right</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- IMMUTABLE AUDIT STREAM -->
        <div class="p-5 rounded-xl bg-[#0d1117] border border-[#1c2432] space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="material-icons text-base text-emerald-400">receipt_long</span>
              <h2 class="font-mono font-bold text-sm text-slate-200">IMMUTABLE CRYPTOGRAPHIC AUDIT</h2>
            </div>
            <button
              (click)="navTab.emit('audit-logs')"
              class="text-xs font-mono text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
            >
              <span>Audit Ledger</span>
              <span class="material-icons text-xs">arrow_forward</span>
            </button>
          </div>

          <div class="space-y-2.5 font-mono text-xs">
            @for (audit of vaultService.auditEvents().slice(0, 4); track audit.id) {
              <div class="p-3 rounded-lg bg-[#121822] border border-[#1e293b] space-y-1">
                <div class="flex items-center justify-between text-[11px]">
                  <span class="font-semibold text-slate-200">{{ audit.action }}</span>
                  <span class="text-slate-400 text-[10px]">{{ audit.timestamp.split('T')[1].substring(0, 8) }} UTC</span>
                </div>
                <div class="text-[11px] text-slate-400 line-clamp-1">{{ audit.details }}</div>
                <div class="text-[10px] text-slate-400 flex items-center gap-1.5">
                  <span class="material-icons text-[10px] text-slate-400">lock</span>
                  <span class="font-mono truncate">Proof: {{ audit.sha256Hash.substring(0, 24) }}...</span>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class Dashboard {
  vaultService = inject(VaultService);
  navTab = output<string>();
  triggerIngest = output<void>();
  inspectObject = output<string>();
}
