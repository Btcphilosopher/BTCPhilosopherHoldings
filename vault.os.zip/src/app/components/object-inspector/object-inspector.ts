import { ChangeDetectionStrategy, Component, computed, inject, input, output } from '@angular/core';
import { VaultService } from '../../core/services/vault.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-object-inspector',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-end font-mono">
      <!-- SIDEBAR DRAWER -->
      <div class="w-full max-w-xl h-full bg-[#0b0f15] border-l border-[#222e40] p-6 space-y-6 overflow-y-auto shadow-2xl flex flex-col justify-between">
        <div class="space-y-6">
          <!-- Drawer Top Header -->
          <div class="flex items-center justify-between border-b border-[#1c2738] pb-4">
            <div class="flex items-center gap-2">
              <span class="material-icons text-purple-400 text-base">verified</span>
              <span class="text-xs font-bold text-slate-200">CRYPTOGRAPHIC PROVENANCE INSPECTOR</span>
            </div>
            <button (click)="closeInspector.emit()" class="text-slate-400 hover:text-white text-base cursor-pointer">✕</button>
          </div>

          @if (object()) {
            <!-- Asset Title & Overview -->
            <div class="space-y-3">
              <div class="flex items-center gap-2">
                <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-700/40">
                  {{ object()!.archiveStatus }}
                </span>
                <span class="px-2 py-0.5 rounded text-[10px] bg-purple-950 text-purple-400 border border-purple-700/40 uppercase">
                  {{ object()!.type }}
                </span>
                @if (object()!.isTokenGated) {
                  <span class="px-2 py-0.5 rounded text-[10px] bg-amber-950 text-amber-400 border border-amber-700/40 flex items-center gap-1 font-bold">
                    <span class="material-icons text-[10px]">lock</span>
                    <span>{{ object()!.minTokenRequired }} VLT Required</span>
                  </span>
                }
              </div>

              <h2 class="text-lg font-bold text-white tracking-tight break-all">{{ object()!.filename }}</h2>
              <p class="text-xs text-slate-300 font-sans leading-relaxed">{{ object()!.humanDescription }}</p>
            </div>

            <!-- SHA-256 ROOT & MERKLE CHUNK TREE -->
            <div class="p-4 rounded-xl bg-[#0e141e] border border-[#1e293b] space-y-3">
              <div class="flex items-center justify-between">
                <div class="text-xs font-bold text-slate-200">AUTHORITATIVE SHA-256 HASH</div>
                <span class="text-[10px] text-emerald-400">100% BIT-PARITY</span>
              </div>
              <div class="p-2.5 rounded bg-[#070a0e] border border-[#16202c] text-[10px] text-purple-300 break-all select-all font-mono">
                {{ object()!.sha256 }}
              </div>

              <!-- Merkle Tree Visualizer -->
              <div class="space-y-1.5 pt-2 border-t border-[#182332]">
                <div class="text-[10px] text-slate-400 uppercase font-semibold">MERKLE CHUNK LEAF HASHES (4MB CHUNKS)</div>
                <div class="space-y-1 text-[9px] text-slate-400 font-mono">
                  <div class="p-1.5 rounded bg-[#0a0e14] border border-[#161f2b] flex justify-between">
                    <span>Chunk 00 [0-4MB]:</span>
                    <span class="text-slate-300">d4e5f601...42a1</span>
                  </div>
                  <div class="p-1.5 rounded bg-[#0a0e14] border border-[#161f2b] flex justify-between">
                    <span>Chunk 01 [4-8MB]:</span>
                    <span class="text-slate-300">89aabbcc...9923</span>
                  </div>
                  <div class="p-1.5 rounded bg-[#0a0e14] border border-[#161f2b] flex justify-between">
                    <span>Chunk 02 [8-12MB]:</span>
                    <span class="text-slate-300">3f2e1d0c...7710</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- REPLICA SYNC HEALTH MATRIX -->
            <div class="p-4 rounded-xl bg-[#0e141e] border border-[#1e293b] space-y-3">
              <div class="flex items-center justify-between">
                <div class="text-xs font-bold text-slate-200">4-WAY REPLICA STATUS</div>
                <span class="text-[10px] text-emerald-400 font-semibold">{{ object()!.replicasCount }} Clusters Synchronized</span>
              </div>

              <div class="grid grid-cols-2 gap-2 text-[10px]">
                <div class="p-2 rounded bg-[#070a0e] border border-[#16202c] flex items-center justify-between">
                  <span>Local NVMe (Primary):</span>
                  <span class="text-emerald-400 font-bold">ONLINE</span>
                </div>
                <div class="p-2 rounded bg-[#070a0e] border border-[#16202c] flex items-center justify-between">
                  <span>Zurich Bunker:</span>
                  <span class="text-emerald-400 font-bold">ONLINE</span>
                </div>
                <div class="p-2 rounded bg-[#070a0e] border border-[#16202c] flex items-center justify-between">
                  <span>Reykjavik Geothermal:</span>
                  <span class="text-emerald-400 font-bold">ONLINE</span>
                </div>
                <div class="p-2 rounded bg-[#070a0e] border border-[#16202c] flex items-center justify-between">
                  <span>LTO-9 Tape Tier:</span>
                  <span class="text-cyan-400 font-bold">COMMITTED</span>
                </div>
              </div>
            </div>

            <!-- ASSET TECHNICAL SPECIFICATION -->
            <div class="p-4 rounded-xl bg-[#0e141e] border border-[#1e293b] space-y-2 text-xs">
              <div class="text-xs font-bold text-slate-200 mb-2">ARCHIVAL PROFILE & METADATA</div>
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>Byte Size:</span>
                <span class="text-slate-200 font-mono">{{ (object()!.sizeBytes / 1024 / 1024).toFixed(2) }} MB ({{ object()!.sizeBytes }} bytes)</span>
              </div>
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>Container MIME:</span>
                <span class="text-slate-200 font-mono">{{ object()!.mimeType }}</span>
              </div>
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>Storage Class:</span>
                <span class="text-emerald-400 font-mono uppercase">{{ object()!.storageClass }}</span>
              </div>
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>Capture Timestamp:</span>
                <span class="text-slate-200 font-mono">{{ object()!.captureDate || '2026-09-08' }}</span>
              </div>
              <div class="flex justify-between text-slate-400 text-[11px]">
                <span>Format Durability Score:</span>
                <span class="text-emerald-400 font-mono font-bold">98 / 100 (Lossless Open Standard)</span>
              </div>
            </div>
          }
        </div>

        <!-- BOTTOM ACTIONS -->
        <div class="pt-4 border-t border-[#1c2738] space-y-2">
          <button
            (click)="downloadMasterBytes()"
            class="w-full py-2.5 rounded-lg bg-purple-500 hover:bg-purple-400 text-black font-semibold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg active:scale-95"
          >
            <span class="material-icons text-sm">download</span>
            <span>Download Verified Master Stream</span>
          </button>
        </div>
      </div>
    </div>
  `,
})
export class ObjectInspector {
  vaultService = inject(VaultService);
  objectId = input.required<string>();
  closeInspector = output<void>();

  object = computed(() => {
    return this.vaultService.objects().find(o => o.id === this.objectId()) || null;
  });

  downloadMasterBytes(): void {
    if (!this.object()) return;
    const url = `/api/media/stream/${this.object()!.id}`;
    window.location.href = url;
  }
}
