import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '20mb' }));

const angularApp = new AngularNodeAppEngine();

// Shared Gemini AI instance (Server-side only)
const getGenAI = () => {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// ==========================================
// IN-MEMORY STATION DATABASE & STATE STORE
// ==========================================

let broadcastState = {
  status: 'ON_AIR' as 'ON_AIR' | 'OFF_AIR' | 'STANDBY' | 'FALLBACK' | 'MAINTENANCE',
  mode: 'HYBRID' as const,
  currentProgrammeTitle: 'The Architecture of Being',
  currentEpisodeTitle: 'Episode 04 — Time as the Missing Dimension',
  currentSceneId: 'scene-talking-head',
  previewSceneId: 'scene-screencast',
  durationSeconds: 5077, // 01:24:37
  uptimeSeconds: 16279, // 04:31:19
  viewerCount: 1284,
  peakViewers: 2150,
  bitrateMbps: 7.8,
  fps: 59.94,
  audioLevelLufs: -14.2,
  audioPeakDb: -1.5,
  health: 'HEALTHY' as const,
  encoderLoadPercent: 24,
  cpuLoadPercent: 18,
  gpuLoadPercent: 31,
  droppedFrames: 0,
  networkLatencyMs: 18,
  destinations: [
    {
      id: 'dest-1',
      name: 'Primary Origin Relay',
      protocol: 'HLS' as const,
      url: 'https://stream.btc.broadcast/live/master.m3u8',
      status: 'CONNECTED' as const,
      bitrateMbps: 7.8,
      resolution: '1920x1080',
      latencyMs: 12,
      packetLossPercent: 0.01,
      enabled: true,
    },
    {
      id: 'dest-2',
      name: 'Secondary Distributed Edge',
      protocol: 'RTMP' as const,
      url: 'rtmp://edge.btc.broadcast/live/station_master',
      status: 'CONNECTED' as const,
      bitrateMbps: 7.8,
      resolution: '1920x1080',
      latencyMs: 22,
      packetLossPercent: 0.0,
      enabled: true,
    },
    {
      id: 'dest-3',
      name: 'Radio Stream (320kbps Opus)',
      protocol: 'HLS' as const,
      url: 'https://radio.btc.broadcast/live/audio.m3u8',
      status: 'CONNECTED' as const,
      bitrateMbps: 0.32,
      resolution: 'Audio-Only',
      latencyMs: 8,
      packetLossPercent: 0.0,
      enabled: true,
    },
  ],
  recording: true,
  recordingDurationSeconds: 5077,
  archiveId: 'arch-2026-09-10-01',
  distributionMode: 'DISTRIBUTED' as const,
  autopilotActive: true,
  activeLowerThird: {
    id: 'lt-1',
    title: 'BTCPhilosopher',
    subtitle: 'Station Director & Architect',
    style: 'STANDARD_DARK' as const,
    isVisible: true,
  },
  activeTickerText: '● ON AIR: The Architecture of Being | Next: Philology Revolution @ 10:00 UTC | Network Health: 100% Deterministic',
};

const mediaLibrary = [
  {
    id: 'med-101',
    filename: 'architecture_of_being_ep4_master.mp4',
    title: 'The Architecture of Being — Ep 04',
    description: 'Deep dive into time-domain software design and personal channel sovereignty.',
    type: 'VIDEO',
    durationSeconds: 3600,
    codec: 'H.264',
    resolution: '1080p60',
    fps: 59.94,
    audioFormat: 'AAC 48kHz Stereo',
    bitrateMbps: 8.5,
    fileSizeBytes: 3825000000,
    createdAt: '2026-09-08T14:00:00Z',
    tags: ['Architecture', 'Philosophy', 'Bitcoin'],
    programmeName: 'The Architecture of Being',
    archiveStatus: 'EDITABLE_MASTER' as const,
    checksum: 'sha256-a1b2c3d4e5f67890123456789abcdef0',
    url: 'https://picsum.photos/seed/btc_arch/1280/720',
    thumbnailUrl: 'https://picsum.photos/seed/btc_arch/400/225',
  },
  {
    id: 'med-102',
    filename: 'philology_revolution_radio_02.flac',
    title: 'Philology Revolution Radio — Session 02',
    description: 'High fidelity audio transmission discussing language, code, and digital value.',
    type: 'AUDIO',
    durationSeconds: 5400,
    codec: 'FLAC',
    resolution: 'Audio 24-bit',
    fps: 0,
    audioFormat: 'FLAC 96kHz Stereo',
    bitrateMbps: 1.2,
    fileSizeBytes: 810000000,
    createdAt: '2026-09-09T08:30:00Z',
    tags: ['Radio', 'Philology', 'Soundtrack'],
    programmeName: 'Philology Revolution Radio',
    archiveStatus: 'ORIGINAL' as const,
    checksum: 'sha256-9876543210fedcba9876543210abcdef',
    url: 'https://picsum.photos/seed/btc_radio/1280/720',
    thumbnailUrl: 'https://picsum.photos/seed/btc_radio/400/225',
  },
  {
    id: 'med-103',
    filename: 'station_ident_2026_4k.mp4',
    title: 'BTC.BROADCAST Station Ident & Bumper',
    description: 'Default station ID fallback video loop.',
    type: 'VIDEO',
    durationSeconds: 30,
    codec: 'HEVC',
    resolution: '2160p60',
    fps: 60,
    audioFormat: 'Uncompressed WAV 48kHz',
    bitrateMbps: 25.0,
    fileSizeBytes: 93750000,
    createdAt: '2026-09-01T00:00:00Z',
    tags: ['Station', 'Ident', 'Loop', 'Fallback'],
    programmeName: 'Station Assets',
    archiveStatus: 'STREAM_VERSION' as const,
    checksum: 'sha256-11223344556677889900aabbccddeeff',
    url: 'https://picsum.photos/seed/btc_ident/1280/720',
    thumbnailUrl: 'https://picsum.photos/seed/btc_ident/400/225',
  },
];

const programmesList = [
  {
    id: 'prog-1',
    title: 'The Architecture of Being',
    description: 'Explorations in software engineering, sovereign computation, and digital aesthetics.',
    host: 'BTCPhilosopher',
    category: 'Technology & Philosophy',
    coverImage: 'https://picsum.photos/seed/prog1/600/400',
    tags: ['Bitcoin', 'Architecture', 'Sovereignty'],
    episodes: [
      {
        id: 'ep-1',
        programmeId: 'prog-1',
        episodeNumber: 1,
        title: 'Episode 01 — The Sovereign Computer',
        description: 'Why personal broadcasting is the foundation of personal sovereignty.',
        durationSeconds: 3600,
        airDate: '2026-09-01',
      },
      {
        id: 'ep-4',
        programmeId: 'prog-1',
        episodeNumber: 4,
        title: 'Episode 04 — Time as the Missing Dimension',
        description: 'How broadcasting structures time through continuous media streams.',
        durationSeconds: 5400,
        airDate: '2026-09-10',
      },
    ],
  },
  {
    id: 'prog-2',
    title: 'Philology Revolution Radio',
    description: 'Audio-first broadcasts on linguistics, cryptography, and timeless records.',
    host: 'BTCPhilosopher',
    category: 'Audio / Radio',
    coverImage: 'https://picsum.photos/seed/prog2/600/400',
    tags: ['Radio', 'Philology', 'Crypto'],
    episodes: [
      {
        id: 'ep-201',
        programmeId: 'prog-2',
        episodeNumber: 1,
        title: 'Session 01 — Etymology of Code',
        description: 'Examining human and machine languages in deep focus.',
        durationSeconds: 4800,
        airDate: '2026-09-05',
      },
    ],
  },
];

const scheduleList = [
  {
    id: 'sch-1',
    programmeId: 'prog-1',
    episodeTitle: 'Morning Transmission & News Synthesis',
    startTime: '06:00',
    endTime: '08:00',
    durationMinutes: 120,
    status: 'COMPLETED' as const,
    type: 'AUTOMATED' as const,
  },
  {
    id: 'sch-2',
    programmeId: 'prog-2',
    episodeTitle: 'Philology Revolution Radio — Session 02',
    startTime: '08:00',
    endTime: '10:00',
    durationMinutes: 120,
    status: 'LIVE' as const,
    type: 'RADIO' as const,
  },
  {
    id: 'sch-3',
    programmeId: 'prog-1',
    episodeTitle: 'The Architecture of Being — Ep 04',
    startTime: '10:00',
    endTime: '12:00',
    durationMinutes: 120,
    status: 'NEXT' as const,
    type: 'LIVE' as const,
  },
  {
    id: 'sch-4',
    programmeId: 'prog-1',
    episodeTitle: 'Sovereign Nodes & Mesh Broadcasting',
    startTime: '14:00',
    endTime: '16:00',
    durationMinutes: 120,
    status: 'SCHEDULED' as const,
    type: 'PREMIERE' as const,
  },
  {
    id: 'sch-5',
    programmeId: 'prog-2',
    episodeTitle: 'Night Ambient Transmission & Soundscape',
    startTime: '22:00',
    endTime: '00:00',
    durationMinutes: 120,
    status: 'SCHEDULED' as const,
    type: 'AUTOMATED' as const,
  },
];

const archiveList = [
  {
    id: 'arch-2026-09-10-01',
    broadcastTitle: 'The Architecture of Being — Episode 04',
    clipTitle: 'Why Time Is the Missing Dimension of Software',
    description: 'Key segment discussing deterministic playout and continuous state.',
    startTimeFormatted: '02:14',
    endTimeFormatted: '07:51',
    durationSeconds: 337,
    createdAt: '2026-09-10T04:00:00Z',
    url: 'https://picsum.photos/seed/clip1/1280/720',
    thumbnailUrl: 'https://picsum.photos/seed/clip1/400/225',
    tags: ['Architecture', 'Highlight'],
  },
  {
    id: 'arch-2026-09-08-02',
    broadcastTitle: 'Philology Revolution Radio',
    clipTitle: 'The Etymology of Protocol Specification',
    description: 'Discussion on linguistic clarity in network protocol engineering.',
    startTimeFormatted: '14:20',
    endTimeFormatted: '19:45',
    durationSeconds: 325,
    createdAt: '2026-09-08T18:30:00Z',
    url: 'https://picsum.photos/seed/clip2/1280/720',
    thumbnailUrl: 'https://picsum.photos/seed/clip2/400/225',
    tags: ['Radio', 'Philology'],
  },
];

const chatMessages: {
  id: string;
  username: string;
  text: string;
  timestamp: string;
  role: 'VIEWER' | 'BROADCASTER';
  satsTipped?: number;
  isPinned?: boolean;
}[] = [
  {
    id: 'msg-1',
    username: 'aureom_node',
    text: 'Crisp 60fps feed today! Signal quality is phenomenal.',
    timestamp: '04:45:12',
    role: 'VIEWER' as const,
    satsTipped: 500,
  },
  {
    id: 'msg-2',
    username: 'BTCPhilosopher',
    text: 'Welcome to the broadcast. Today we examine software time architecture.',
    timestamp: '04:46:00',
    role: 'BROADCASTER' as const,
    isPinned: true,
  },
  {
    id: 'msg-3',
    username: 'cypherpunk_99',
    text: 'Does the autopilot fallback automatically engage if the primary stream degrades?',
    timestamp: '04:48:30',
    role: 'VIEWER' as const,
  },
];

const bitcoinTips = [
  {
    id: 'tip-101',
    sender: 'aureom_node',
    satsAmount: 21000,
    fiatValueUsd: 13.65,
    message: 'For sovereign television production.',
    paymentHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    timestamp: '2026-09-10T04:42:00Z',
    status: 'CONFIRMED' as const,
  },
  {
    id: 'tip-102',
    sender: 'satoshi_listener',
    satsAmount: 50000,
    fiatValueUsd: 32.50,
    message: 'Supporting independent broadcast engineering!',
    paymentHash: '8f4e2b1a9c3d7e5f0a8b6c4d2e1f3a5b7c9d0e2f4a6b8c0d2e4f6a8b0c2d4e6f',
    timestamp: '2026-09-09T22:15:00Z',
    status: 'CONFIRMED' as const,
  },
];

// Timer loop to update station uptime and minor fluctuations in bitrate/viewers
setInterval(() => {
  broadcastState.uptimeSeconds += 1;
  if (broadcastState.status === 'ON_AIR') {
    broadcastState.durationSeconds += 1;
    if (broadcastState.recording) {
      broadcastState.recordingDurationSeconds += 1;
    }
    broadcastState.bitrateMbps = parseFloat((7.6 + Math.random() * 0.4).toFixed(2));
    broadcastState.fps = parseFloat((59.85 + Math.random() * 0.15).toFixed(2));
    broadcastState.audioLevelLufs = parseFloat((-14.5 + Math.random() * 0.6).toFixed(1));
    broadcastState.audioPeakDb = parseFloat((-2.0 + Math.random() * 0.8).toFixed(1));
    broadcastState.cpuLoadPercent = Math.min(95, Math.max(10, Math.floor(18 + Math.random() * 6)));
  }
}, 1000);

// ==========================================
// API ENDPOINTS
// ==========================================

app.get('/api/state', (_req, res) => {
  res.json({ success: true, state: broadcastState });
});

app.post('/api/state/update', (req, res) => {
  const updates = req.body;
  broadcastState = { ...broadcastState, ...updates };
  res.json({ success: true, state: broadcastState });
});

app.get('/api/media', (_req, res) => {
  res.json({ success: true, media: mediaLibrary });
});

app.post('/api/media', (req, res) => {
  const newItem = {
    id: `med-${Date.now()}`,
    filename: req.body.filename || 'uploaded_media.mp4',
    title: req.body.title || 'New Media Asset',
    description: req.body.description || '',
    type: req.body.type || 'VIDEO',
    durationSeconds: req.body.durationSeconds || 180,
    codec: req.body.codec || 'H.264',
    resolution: req.body.resolution || '1080p60',
    fps: req.body.fps || 60,
    audioFormat: req.body.audioFormat || 'AAC 48kHz',
    bitrateMbps: req.body.bitrateMbps || 8.0,
    fileSizeBytes: req.body.fileSizeBytes || 250000000,
    createdAt: new Date().toISOString(),
    tags: req.body.tags || ['Station'],
    programmeName: req.body.programmeName || 'General',
    archiveStatus: 'ORIGINAL' as const,
    checksum: `sha256-${Math.random().toString(36).substring(2)}`,
    url: req.body.url || 'https://picsum.photos/seed/newmed/1280/720',
    thumbnailUrl: req.body.thumbnailUrl || 'https://picsum.photos/seed/newmed/400/225',
  };
  mediaLibrary.unshift(newItem);
  res.json({ success: true, item: newItem });
});

app.get('/api/programmes', (_req, res) => {
  res.json({ success: true, programmes: programmesList });
});

app.get('/api/schedule', (_req, res) => {
  res.json({ success: true, schedule: scheduleList });
});

app.post('/api/schedule', (req, res) => {
  const newSch = {
    id: `sch-${Date.now()}`,
    programmeId: req.body.programmeId || 'prog-1',
    episodeTitle: req.body.episodeTitle || 'Scheduled Broadcast',
    startTime: req.body.startTime || '20:00',
    endTime: req.body.endTime || '22:00',
    durationMinutes: req.body.durationMinutes || 120,
    status: 'SCHEDULED' as const,
    type: req.body.type || 'LIVE',
  };
  scheduleList.push(newSch);
  res.json({ success: true, scheduleItem: newSch });
});

app.get('/api/archive', (_req, res) => {
  res.json({ success: true, archive: archiveList });
});

app.post('/api/archive/clip', (req, res) => {
  const newClip = {
    id: `clip-${Date.now()}`,
    broadcastTitle: broadcastState.currentProgrammeTitle,
    clipTitle: req.body.clipTitle || 'New Broadcast Clip',
    description: req.body.description || 'Created via clipping engine.',
    startTimeFormatted: req.body.startTimeFormatted || '00:00',
    endTimeFormatted: req.body.endTimeFormatted || '01:00',
    durationSeconds: req.body.durationSeconds || 60,
    createdAt: new Date().toISOString(),
    url: 'https://picsum.photos/seed/newclip/1280/720',
    thumbnailUrl: 'https://picsum.photos/seed/newclip/400/225',
    tags: req.body.tags || ['Clip'],
  };
  archiveList.unshift(newClip);
  res.json({ success: true, clip: newClip });
});

app.get('/api/chat', (_req, res) => {
  res.json({ success: true, messages: chatMessages });
});

app.post('/api/chat', (req, res) => {
  const msg = {
    id: `msg-${Date.now()}`,
    username: req.body.username || 'Anonymous Viewer',
    text: req.body.text || '',
    timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
    role: (req.body.role || 'VIEWER') as 'VIEWER' | 'BROADCASTER',
    satsTipped: req.body.satsTipped,
  };
  chatMessages.push(msg);
  res.json({ success: true, message: msg });
});

app.get('/api/payments/tips', (_req, res) => {
  res.json({ success: true, tips: bitcoinTips });
});

app.post('/api/payments/tip', (req, res) => {
  const sats = req.body.sats || 10000;
  const tip = {
    id: `tip-${Date.now()}`,
    sender: req.body.sender || 'Anonymous Cypherpunk',
    satsAmount: sats,
    fiatValueUsd: parseFloat(((sats / 100000000) * 65000).toFixed(2)),
    message: req.body.message || 'Supporting sovereign broadcasting!',
    paymentHash: `hash-${Math.random().toString(36).substring(2)}${Math.random().toString(36).substring(2)}`,
    timestamp: new Date().toISOString(),
    status: 'CONFIRMED' as const,
  };
  bitcoinTips.unshift(tip);
  res.json({ success: true, tip });
});

app.get('/api/analytics', (_req, res) => {
  res.json({
    success: true,
    metrics: {
      viewerCount: broadcastState.viewerCount,
      peakViewers: broadcastState.peakViewers,
      bitrateMbps: broadcastState.bitrateMbps,
      fps: broadcastState.fps,
      droppedFrames: broadcastState.droppedFrames,
      audioLevelLufs: broadcastState.audioLevelLufs,
      cpuLoadPercent: broadcastState.cpuLoadPercent,
      gpuLoadPercent: broadcastState.gpuLoadPercent,
      networkLatencyMs: broadcastState.networkLatencyMs,
      totalBytesTransmittedGb: parseFloat(((broadcastState.uptimeSeconds * 0.95) / 100).toFixed(2)),
      healthyStreams: broadcastState.destinations.filter(d => d.status === 'CONNECTED').length,
    },
  });
});

// ==========================================
// GEMINI 3.7 AI PRODUCTION DIRECTOR & ARCHIVIST
// ==========================================

app.post('/api/ai/director', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) {
    res.status(400).json({ success: false, error: 'Prompt is required' });
    return;
  }

  const ai = getGenAI();
  if (!ai) {
    res.json({
      success: true,
      result: {
        intent: 'NATURAL_LANGUAGE_CONTROL',
        reply: `AI Director parsed prompt: "${prompt}". (Note: GEMINI_API_KEY environment variable is not set. Deterministic station commands execute directly via control room controls).`,
        executedAction: null,
      },
    });
    return;
  }

  try {
    const systemPrompt = `You are the AI Production Director for BTC.BROADCAST — a sovereign personal broadcasting and internet television station designed in the spirit of BTCPhilosopher.
Your job is to parse natural language instructions from the station operator and return structured JSON actions to control the broadcast engine deterministically.

Available deterministic actions:
1. SWITCH_SCENE: switch to scene (e.g., 'scene-talking-head', 'scene-screencast', 'scene-fullscreen', 'scene-hybrid')
2. PUT_ON_AIR: start broadcast or toggle live camera
3. SCHEDULE_PROGRAMME: add an item to the electronic programme guide
4. CREATE_CLIP: create a clip candidate from recent broadcast timeframes
5. SEARCH_ARCHIVE: query the broadcast archive
6. GENERATE_SHOW_NOTES: summarize current programme notes
7. TRIGGER_FALLBACK: switch station to fallback/house channel loop

Respond in strictly valid JSON format with keys:
{
  "intent": "INTENT_NAME",
  "reply": "Clear engineering explanation of what was analyzed and executed.",
  "executedAction": {
    "type": "ACTION_TYPE",
    "params": {}
  },
  "requiresConfirmation": false
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    let jsonRes: {
      intent?: string;
      reply?: string;
      executedAction?: { type: string; params?: Record<string, string> };
    } = {};

    try {
      jsonRes = JSON.parse(response.text || '{}');
    } catch {
      jsonRes = {
        intent: 'GENERAL_ASSIST',
        reply: response.text || 'Command processed.',
        executedAction: undefined,
      };
    }

    if (jsonRes.executedAction) {
      const type = jsonRes.executedAction.type;
      if (type === 'SWITCH_SCENE' && jsonRes.executedAction.params?.['sceneId']) {
        broadcastState.currentSceneId = jsonRes.executedAction.params['sceneId'];
      } else if (type === 'PUT_ON_AIR') {
        broadcastState.status = 'ON_AIR';
      } else if (type === 'TRIGGER_FALLBACK') {
        broadcastState.status = 'FALLBACK';
      }
    }

    res.json({ success: true, result: jsonRes });
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : 'Gemini Director processing error';
    res.status(500).json({
      success: false,
      error: errMessage,
    });
  }
});

app.post('/api/ai/archivist', async (req, res) => {
  const { query } = req.body;
  const ai = getGenAI();

  if (!ai) {
    const matches = archiveList.filter(a =>
      a.clipTitle.toLowerCase().includes((query || '').toLowerCase()) ||
      a.description.toLowerCase().includes((query || '').toLowerCase())
    );
    res.json({
      success: true,
      answer: `Archive search for "${query}": Found ${matches.length} matching recordings. (Set GEMINI_API_KEY for rich semantic transcript reasoning).`,
      results: matches,
    });
    return;
  }

  try {
    const archiveContext = JSON.stringify({ archiveList, programmesList });
    const prompt = `Station Archive Context: ${archiveContext}\n\nUser Question: "${query}"\nProvide a precise, authoritative answer referencing specific broadcast dates, programmes, clips, and timestamps.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are the AI Archivist for BTC.BROADCAST. You have full access to the indexed broadcast archive database. Answer user questions deterministically based on station history.',
      },
    });

    res.json({
      success: true,
      answer: response.text,
      results: archiveList,
    });
  } catch (err: unknown) {
    const errMessage = err instanceof Error ? err.message : 'Archivist query error';
    res.status(500).json({ success: false, error: errMessage });
  }
});

app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, () => {
    console.log(`BTC.BROADCAST Master Control Server listening on http://0.0.0.0:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
