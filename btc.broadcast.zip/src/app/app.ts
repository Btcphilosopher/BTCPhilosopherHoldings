import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from './services/broadcast';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  bs = inject(BroadcastService);

  navItems = [
    { path: '/control-room', label: 'CONTROL ROOM', icon: 'tv' },
    { path: '/studio', label: 'STUDIO MIXER', icon: 'tune' },
    { path: '/media-library', label: 'MEDIA ARCHIVE', icon: 'perm_media' },
    { path: '/programme-guide', label: 'EPG SCHEDULER', icon: 'event_note' },
    { path: '/channel-page', label: 'PUBLIC CHANNEL', icon: 'live_tv' },
    { path: '/radio-studio', label: 'RADIO STATION', icon: 'radio' },
    { path: '/archive-view', label: 'TIMESCALE', icon: 'history' },
    { path: '/digital-twin', label: 'DIGITAL TWIN', icon: 'account_tree' },
    { path: '/ai-director-panel', label: 'AI DIRECTOR', icon: 'auto_awesome' },
    { path: '/analytics-panel', label: 'OBSERVABILITY', icon: 'bar_chart' },
    { path: '/bitcoin-accounting', label: 'BTC LEDGER', icon: 'currency_bitcoin' },
    { path: '/settings', label: 'SETTINGS', icon: 'settings' },
  ];
}
