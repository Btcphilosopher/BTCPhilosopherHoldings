import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';
import { LowerThirdGraphic, MediaSource } from '../../models/broadcast.models';

@Component({
  selector: 'app-studio',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-blue-400">tune</mat-icon>
            STUDIO MIXER & MEDIA COMPOSITOR
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Multi-input audio mixing console, real-time WebRTC inputs, lower third graphics overlays, and ticker generator.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="toggleLowerThird()"
            [class]="'px-3.5 py-2 rounded-lg font-bold uppercase flex items-center gap-1.5 border transition ' + (bs.activeLowerThird()?.isVisible ? 'bg-blue-950 text-blue-400 border-blue-600' : 'bg-slate-800 text-slate-300 border-slate-700')">
            <mat-icon class="text-sm">subtitles</mat-icon>
            {{ bs.activeLowerThird()?.isVisible ? 'LOWER THIRD ON' : 'ENABLE LOWER THIRD' }}
          </button>
        </div>
      </div>

      <!-- MAIN STUDIO GRID (SOURCES & LOWER THIRDS) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono text-xs">
        
        <!-- AUDIO & VIDEO INPUT CHANNELS (Col 8) -->
        <div class="lg:col-span-8 flex flex-col gap-3">
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-sm">
            <div class="text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="flex items-center gap-1 text-slate-200">
                <mat-icon class="text-sm text-emerald-400">graphic_eq</mat-icon>
                HARDWARE INPUT CHANNELS & FADERS
              </span>
              <span class="text-slate-500 text-[10px]">{{ bs.liveSources().length }} SOURCES CONNECTED</span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
              @for (src of bs.liveSources(); track src.id) {
                <div class="bg-[#090b0e] border border-slate-800 p-3 rounded-lg flex flex-col gap-2">
                  <div class="flex items-center justify-between font-bold text-white text-xs">
                    <span class="truncate">{{ src.name }}</span>
                    <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  </div>

                  <div class="text-[10px] text-slate-500">
                    {{ src.type }} | {{ src.codec }}
                  </div>

                  <!-- Volume Slider -->
                  <div class="flex items-center gap-2 pt-2">
                    <button (click)="toggleMute(src)" [class]="'p-1 rounded text-[10px] font-bold ' + (src.isMuted ? 'bg-red-950 text-red-400' : 'bg-slate-800 text-slate-300')">
                      {{ src.isMuted ? 'MUTED' : 'MUTE' }}
                    </button>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      [ngModel]="src.volume"
                      (ngModelChange)="onVolumeChange(src, $event)"
                      class="flex-1 h-1.5 bg-slate-800 rounded appearance-none accent-blue-500" />
                    <span class="text-[10px] text-slate-400 w-8 text-right">{{ Math.round(src.volume * 100) }}%</span>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- LOWER THIRDS & TICKER GRAPHICS EDITING (Col 4) -->
        <div class="lg:col-span-4 bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-sm">
          <div class="text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            LOWER THIRD & TICKER EDITOR
          </div>

          <div class="flex flex-col gap-2">
            <span class="text-slate-400">PRIMARY TITLE</span>
            <input type="text" [(ngModel)]="ltTitle" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
          </div>

          <div class="flex flex-col gap-2">
            <span class="text-slate-400">SUBTITLE / ROLE</span>
            <input type="text" [(ngModel)]="ltSubtitle" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
          </div>

          <button (click)="applyLowerThird()" class="py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase">
            UPDATE OVERLAY GRAPHIC
          </button>
        </div>

      </div>

    </div>
  `,
})
export class StudioComponent {
  bs = inject(BroadcastService);
  Math = Math;

  ltTitle = 'BTCPhilosopher';
  ltSubtitle = 'Station Director & Architect';

  toggleMute(src: MediaSource) {
    src.isMuted = !src.isMuted;
  }

  onVolumeChange(src: MediaSource, val: number) {
    src.volume = val;
  }

  toggleLowerThird() {
    const current = this.bs.activeLowerThird();
    if (current) {
      this.bs.updateLowerThird({ ...current, isVisible: !current.isVisible });
    }
  }

  applyLowerThird() {
    const lt: LowerThirdGraphic = {
      id: `lt-${Date.now()}`,
      title: this.ltTitle,
      subtitle: this.ltSubtitle,
      style: 'STANDARD_DARK',
      isVisible: true,
    };
    this.bs.updateLowerThird(lt);
  }
}
