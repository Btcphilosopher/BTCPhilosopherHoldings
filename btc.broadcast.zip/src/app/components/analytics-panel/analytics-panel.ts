import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-analytics-panel',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-blue-400">bar_chart</mat-icon>
            ENGINEERING OBSERVABILITY & AUDIENCE SIMULATOR
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Full-stack telemetry, hardware encoder load, network latency, and synthetic load testing.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-3 py-1 rounded bg-blue-950 text-blue-400 border border-blue-800 font-bold">
            HEALTH: 100% DETERMINISTIC
          </span>
        </div>
      </div>

      <!-- SYNTHETIC VIEWER LOAD SIMULATOR -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 font-mono text-xs shadow-md">
        <div class="text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="flex items-center gap-1 text-slate-200">
            <mat-icon class="text-sm text-blue-400">speed</mat-icon>
            SYNTHETIC VIEWER TRAFFIC SIMULATOR
          </span>
          <span class="text-blue-400 font-bold text-sm">{{ simulatedViewers.toLocaleString() }} SIMULATED VIEWERS</span>
        </div>

        <div class="flex items-center gap-4 py-2">
          <span class="text-slate-500">100</span>
          <input
            type="range"
            min="100"
            max="100000"
            step="500"
            [ngModel]="simulatedViewers"
            (ngModelChange)="onViewerSliderChange($event)"
            class="flex-1 h-2 bg-slate-800 rounded appearance-none cursor-pointer accent-blue-500" />
          <span class="text-slate-500">100,000</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-4 gap-2 text-[11px] bg-[#090b0e] p-3 rounded-lg border border-slate-800">
          <div>Edge Load: <span class="text-emerald-400 font-bold">{{ (simulatedViewers / 1000).toFixed(1) }} Gbps</span></div>
          <div>Packet Drop: <span class="text-slate-300 font-bold">0.00%</span></div>
          <div>Edge Relays: <span class="text-blue-400 font-bold">{{ Math.ceil(simulatedViewers / 2500) }} Nodes</span></div>
          <div>CDN Cost: <span class="text-amber-400 font-bold">$0.00 (Self-Hosted Origin)</span></div>
        </div>
      </div>

      <!-- TELEMETRY METRICS CARDS -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div class="bg-[#0f1319] border border-slate-800 p-4 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px] uppercase">Encoder Bitrate</span>
          <span class="text-xl font-bold text-emerald-400">{{ bs.state().bitrateMbps }} Mbps</span>
          <span class="text-[10px] text-slate-500">CBR H.264 / AAC</span>
        </div>
        <div class="bg-[#0f1319] border border-slate-800 p-4 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px] uppercase">Frame Rate Stability</span>
          <span class="text-xl font-bold text-blue-400">{{ bs.state().fps }} FPS</span>
          <span class="text-[10px] text-slate-500">0 Dropped Frames</span>
        </div>
        <div class="bg-[#0f1319] border border-slate-800 p-4 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px] uppercase">Audio Loudness</span>
          <span class="text-xl font-bold text-amber-400">{{ bs.state().audioLevelLufs }} LUFS</span>
          <span class="text-[10px] text-slate-500">Target: -14.0 LUFS</span>
        </div>
        <div class="bg-[#0f1319] border border-slate-800 p-4 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px] uppercase">Server CPU Load</span>
          <span class="text-xl font-bold text-purple-400">{{ bs.state().cpuLoadPercent }}%</span>
          <span class="text-[10px] text-slate-500">Tokio Async Runtime</span>
        </div>
      </div>

    </div>
  `,
})
export class AnalyticsPanelComponent {
  bs = inject(BroadcastService);
  Math = Math;

  simulatedViewers = 1284;

  onViewerSliderChange(val: number) {
    this.simulatedViewers = val;
    this.bs.state.update(s => ({ ...s, viewerCount: val }));
  }
}
