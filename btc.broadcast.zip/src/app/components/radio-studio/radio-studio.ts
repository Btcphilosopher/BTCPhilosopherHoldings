import {
  Component,
  ChangeDetectionStrategy,
  inject,
  signal,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-radio-studio',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-amber-400">radio</mat-icon>
            SOVEREIGN AUDIO RADIO STATION (320kbps OPUS)
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Low-latency audio transmission desk with microphone ducking and spectrum visualization.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="toggleDjMic()"
            [class]="'px-4 py-2 rounded-lg font-bold uppercase flex items-center gap-2 transition shadow ' + (isDjMicOn() ? 'bg-red-600 text-white shadow-red-900/50 animate-pulse' : 'bg-slate-800 text-slate-300 hover:bg-slate-700')">
            <mat-icon class="text-sm">mic</mat-icon>
            {{ isDjMicOn() ? 'DJ MIC LIVE (DUCKING ON)' : 'TOGGLE DJ MIC' }}
          </button>
        </div>
      </div>

      <!-- SPECTRUM VISUALIZER & TRACK PLAYER GRID -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        <!-- SPECTRUM CANVAS (Col 8) -->
        <div class="lg:col-span-8 flex flex-col gap-3">
          <div class="relative bg-black rounded-xl border border-slate-800 aspect-video flex flex-col overflow-hidden shadow-2xl p-4 justify-between">
            
            <div class="flex items-center justify-between font-mono text-xs text-slate-400 z-10">
              <span class="flex items-center gap-2 text-amber-400 font-bold">
                <span class="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping"></span>
                PHILOLOGY REVOLUTION RADIO — LIVE
              </span>
              <span class="text-slate-500">320 kbps Opus / 48kHz Stereo</span>
            </div>

            <!-- Canvas Spectrum -->
            <canvas #spectrumCanvas class="w-full h-full block absolute inset-0 pointer-events-none"></canvas>

            <!-- Center Track Info Overlay -->
            <div class="z-10 text-center font-mono py-8 my-auto">
              <div class="text-xs text-amber-400 font-bold uppercase tracking-widest mb-1">NOW PLAYING</div>
              <div class="text-xl font-bold text-white tracking-wide">Philology Revolution Radio — Session 02</div>
              <div class="text-xs text-slate-400 mt-1">BTCPhilosopher | Monologue & Ambient Code Soundscape</div>
            </div>

            <!-- Bottom Audio Stats -->
            <div class="z-10 flex items-center justify-between font-mono text-xs text-slate-400 bg-black/60 backdrop-blur p-2 rounded border border-white/10">
              <span>Peak: -1.5 dB</span>
              <span>Loudness: -14.2 LUFS</span>
              <span class="text-emerald-400">0.32 Mbps Stream</span>
            </div>
          </div>
        </div>

        <!-- TRACK PLAYLIST & QUEUE (Col 4) -->
        <div class="lg:col-span-4 bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 font-mono text-xs">
          <div class="text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="flex items-center gap-1 text-slate-200">
              <mat-icon class="text-sm text-amber-400">queue_music</mat-icon>
              RADIO AUTOMATION QUEUE
            </span>
          </div>

          <div class="flex flex-col gap-2">
            @for (track of radioPlaylist(); track track.id) {
              <div [class]="'p-3 rounded-lg border flex flex-col gap-1 ' + (track.isPlaying ? 'bg-amber-950/40 border-amber-800/80' : 'bg-[#090b0e] border-slate-800')">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white truncate max-w-[180px]">{{ track.title }}</span>
                  @if (track.isPlaying) {
                    <span class="text-[10px] px-2 py-0.5 bg-amber-500 text-slate-950 font-bold rounded">AIR</span>
                  }
                </div>
                <div class="text-[10px] text-slate-400 justify-between flex">
                  <span>{{ track.artist }}</span>
                  <span>{{ track.duration }}</span>
                </div>
              </div>
            }
          </div>
        </div>

      </div>

    </div>
  `,
})
export class RadioStudioComponent implements AfterViewInit, OnDestroy {
  bs = inject(BroadcastService);

  @ViewChild('spectrumCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  private animationFrameId?: number;
  isDjMicOn = signal(false);

  radioPlaylist = signal([
    { id: '1', title: 'Session 02 — Cryptography & Value', artist: 'BTCPhilosopher', duration: '54:00', isPlaying: true },
    { id: '2', title: 'Night Ambient Transmission 08', artist: 'BTC Soundscapes', duration: '45:12', isPlaying: false },
    { id: '3', title: 'The Etymology of Protocol Specification', artist: 'Philology Radio', duration: '32:00', isPlaying: false },
  ]);

  ngAfterViewInit() {
    this.renderSpectrum();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  toggleDjMic() {
    this.isDjMicOn.set(!this.isDjMicOn());
  }

  private renderSpectrum() {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 1280;
    canvas.height = 720;

    let step = 0;

    const draw = () => {
      step += 0.05;
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      const numBars = 64;
      const barWidth = width / numBars;

      for (let i = 0; i < numBars; i++) {
        const barHeight = (Math.sin(step + i * 0.2) * 0.4 + 0.5) * (height * 0.6);
        const x = i * barWidth;
        const y = height - barHeight;

        const gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, '#f59e0b');
        gradient.addColorStop(0.7, '#d97706');
        gradient.addColorStop(1, '#ef4444');

        ctx.fillStyle = gradient;
        ctx.fillRect(x, y, barWidth - 4, barHeight);
      }

      this.animationFrameId = requestAnimationFrame(draw);
    };

    draw();
  }
}
