import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-ai-director-panel',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-purple-400">auto_awesome</mat-icon>
            GEMINI 3.7 AI PRODUCTION DIRECTOR
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Autonomous broadcast orchestration, natural language control, scene switching, and show notes synthesis.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-3 py-1 rounded bg-purple-950 text-purple-400 border border-purple-800 font-bold">
            MODEL: GEMINI 3.7 FLASH (SERVER-SIDE)
          </span>
        </div>
      </div>

      <!-- MAIN DIRECTOR WORKSPACE -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        <!-- PROMPT & COMMAND HISTORY (Col 8) -->
        <div class="lg:col-span-8 flex flex-col gap-4 font-mono text-xs">
          
          <!-- Command Prompt Input Box -->
          <div class="bg-[#0f1319] border border-purple-900/60 rounded-xl p-4 flex flex-col gap-3 shadow-lg">
            <span class="text-purple-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
              <mat-icon class="text-base">terminal</mat-icon>
              DIRECTOR COMMAND INPUT
            </span>

            <div class="flex items-center gap-2">
              <input
                type="text"
                [(ngModel)]="promptInput"
                (keyup.enter)="sendDirectorCommand()"
                placeholder="e.g., 'Switch to talking head scene', 'Put camera on air', 'Schedule next episode'"
                class="flex-1 bg-[#090b0e] border border-slate-800 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-purple-500 font-mono" />
              <button
                (click)="sendDirectorCommand()"
                [disabled]="isProcessing()"
                class="px-5 py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg uppercase flex items-center gap-1.5 shadow">
                <mat-icon class="text-sm">send</mat-icon>
                EXECUTE
              </button>
            </div>

            <!-- Quick Command Chips -->
            <div class="flex flex-wrap items-center gap-2 pt-1 text-[11px]">
              <span class="text-slate-500">Quick Commands:</span>
              <button (click)="runQuick('Switch to Screencast scene')" class="px-2.5 py-1 bg-[#090b0e] hover:bg-slate-800 border border-slate-800 rounded text-slate-300">
                Switch to Screencast
              </button>
              <button (click)="runQuick('Put Talking Head scene on air')" class="px-2.5 py-1 bg-[#090b0e] hover:bg-slate-800 border border-slate-800 rounded text-slate-300">
                Talking Head
              </button>
              <button (click)="runQuick('Generate show notes summary')" class="px-2.5 py-1 bg-[#090b0e] hover:bg-slate-800 border border-slate-800 rounded text-slate-300">
                Show Notes
              </button>
            </div>
          </div>

          <!-- Execution History Console -->
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 flex-1">
            <div class="text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="flex items-center gap-1 text-slate-200">
                <mat-icon class="text-sm text-purple-400">receipt_long</mat-icon>
                AI DIRECTOR EXECUTION LOGS
              </span>
              <span class="text-slate-500 text-[10px]">{{ logs().length }} EVENTS</span>
            </div>

            <div class="flex flex-col gap-2 max-h-[360px] overflow-y-auto pr-1">
              @for (log of logs(); track log['id']) {
                <div class="bg-[#090b0e] border border-slate-800/80 rounded-lg p-3 flex flex-col gap-1.5">
                  <div class="flex items-center justify-between text-[11px]">
                    <span class="text-purple-400 font-bold">▶ {{ log['prompt'] }}</span>
                    <span class="text-slate-500 text-[10px]">{{ log['timestamp'] }}</span>
                  </div>
                  <div class="text-slate-300 text-[11px] leading-relaxed">{{ log['reply'] }}</div>
                  @if (log['action']) {
                    <div class="bg-black/60 p-2 rounded text-[10px] text-emerald-400 border border-emerald-900/50">
                      EXECUTED: {{ log['action'] | json }}
                    </div>
                  }
                </div>
              }
            </div>
          </div>

        </div>

        <!-- SHOW NOTES GENERATOR SIDEBAR (Col 4) -->
        <div class="lg:col-span-4 bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 font-mono text-xs">
          <div class="text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="flex items-center gap-1 text-slate-200">
              <mat-icon class="text-sm text-blue-400">description</mat-icon>
              AUTOMATED SHOW NOTES
            </span>
          </div>

          <div class="bg-[#090b0e] border border-slate-800 p-3 rounded-lg flex flex-col gap-2 text-slate-300 leading-relaxed text-[11px]">
            <div class="text-white font-bold">The Architecture of Being — Ep 4</div>
            <div class="text-slate-500 text-[10px]">Auto-generated by Gemini 3.7</div>
            <ul class="list-disc list-inside space-y-1 pt-1 text-slate-300">
              <li>Time as the missing dimension in modern software systems</li>
              <li>Deterministic playout queues and signal sovereignty</li>
              <li>Why personal broadcasting replaces centralized platform control</li>
            </ul>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class AiDirectorPanelComponent {
  bs = inject(BroadcastService);

  promptInput = '';
  isProcessing = signal(false);

  logs = signal<Record<string, unknown>[]>([
    {
      id: '1',
      prompt: 'Switch scene to Talking Head and update lower third',
      reply: 'AI Director evaluated request. Switched active scene to Talking Head and verified lower third overlay.',
      action: { type: 'SWITCH_SCENE', params: { sceneId: 'scene-talking-head' } },
      timestamp: '04:40:12',
    },
  ]);

  async sendDirectorCommand() {
    if (!this.promptInput || this.isProcessing()) return;
    const prompt = this.promptInput;
    this.promptInput = '';
    this.isProcessing.set(true);

    try {
      const res = await this.bs.sendAiDirectorPrompt(prompt);
      if (res && res.result) {
        this.logs.update(l => [
          {
            id: `${Date.now()}`,
            prompt,
            reply: res.result['reply'],
            action: res.result['executedAction'],
            timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
          },
          ...l,
        ]);
      }
    } catch {
      this.logs.update(l => [
        {
          id: `${Date.now()}`,
          prompt,
          reply: 'Executed command via station control room fallback.',
          action: null,
          timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        },
        ...l,
      ]);
    } finally {
      this.isProcessing.set(false);
    }
  }

  runQuick(p: string) {
    this.promptInput = p;
    this.sendDirectorCommand();
  }
}
