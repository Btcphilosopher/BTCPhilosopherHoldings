import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-bitcoin-accounting',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-amber-400">currency_bitcoin</mat-icon>
            SOVEREIGN BITCOIN & LIGHTNING LEDGER
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Direct station monetization without intermediary fee cuts, subscription lock-in, or payment processor censorship.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-3 py-1 rounded bg-amber-950 text-amber-400 border border-amber-800 font-bold">
            TOTAL TIPPED: {{ totalSats().toLocaleString() }} SATS
          </span>
        </div>
      </div>

      <!-- REVENUE CARDS -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
        <div class="bg-[#0f1319] border border-slate-800 p-4 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px] uppercase">Lightning Tips Received</span>
          <span class="text-xl font-bold text-amber-400">{{ totalSats().toLocaleString() }} SATS</span>
          <span class="text-[10px] text-slate-500">~$ {{ ((totalSats() / 100000000) * 65000).toFixed(2) }} USD</span>
        </div>
        <div class="bg-[#0f1319] border border-slate-800 p-4 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px] uppercase">Station Node Status</span>
          <span class="text-xl font-bold text-emerald-400">LND ONLINE</span>
          <span class="text-[10px] text-slate-500">0% Platform Cut</span>
        </div>
        <div class="bg-[#0f1319] border border-slate-800 p-4 rounded-xl flex flex-col gap-1">
          <span class="text-slate-500 text-[10px] uppercase">Lightning Address</span>
          <span class="text-xs font-bold text-blue-400 truncate">btcphilosopher@btc.broadcast</span>
          <span class="text-[10px] text-slate-500">LNURL-PAY Protocol</span>
        </div>
      </div>

      <!-- TIPS TRANSACTION TABLE -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl overflow-hidden font-mono text-xs flex flex-col shadow-md">
        <div class="bg-[#090b0e] p-3 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider grid grid-cols-12 gap-2">
          <div class="col-span-3">SENDER</div>
          <div class="col-span-2">AMOUNT</div>
          <div class="col-span-5">MESSAGE</div>
          <div class="col-span-2 text-right">TIMESTAMP</div>
        </div>

        <div class="divide-y divide-slate-800/60">
          @for (tip of bs.bitcoinTips(); track tip.id) {
            <div class="p-3 grid grid-cols-12 gap-2 items-center hover:bg-slate-900/40 transition">
              <div class="col-span-3 font-bold text-white flex items-center gap-1">
                <mat-icon class="text-sm text-amber-400">bolt</mat-icon>
                {{ tip.sender }}
              </div>
              <div class="col-span-2 text-amber-400 font-bold">
                {{ tip.satsAmount.toLocaleString() }} Sats
              </div>
              <div class="col-span-5 text-slate-300 line-clamp-1">
                {{ tip.message }}
              </div>
              <div class="col-span-2 text-right text-slate-500 text-[10px]">
                {{ tip.timestamp | date:'short' }}
              </div>
            </div>
          }
        </div>
      </div>

    </div>
  `,
})
export class BitcoinAccountingComponent {
  bs = inject(BroadcastService);

  totalSats() {
    return this.bs.bitcoinTips().reduce((acc, t) => acc + t.satsAmount, 0);
  }
}
