import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-slate-400">settings</mat-icon>
            STATION CONFIGURATION & SECURITY
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Origin URLs, RTMP ingest keys, CDN edge relays, and deterministic safety rules.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="saveSettings()"
            class="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold uppercase flex items-center gap-1.5 shadow">
            <mat-icon class="text-sm">save</mat-icon>
            SAVE CONFIGURATION
          </button>
        </div>
      </div>

      <!-- SETTINGS SECTIONS -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono text-xs">
        
        <!-- STATION IDENTITY (Col 6) -->
        <div class="lg:col-span-6 bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            STATION IDENTITY & CALL SIGN
          </div>

          <div class="flex flex-col gap-1.5">
            <span class="text-slate-400">STATION NAME</span>
            <input type="text" [(ngModel)]="channelName" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
          </div>

          <div class="flex flex-col gap-1.5">
            <span class="text-slate-400">CALL SIGN / ID</span>
            <input type="text" [(ngModel)]="callSign" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
          </div>

          <div class="flex flex-col gap-1.5">
            <span class="text-slate-400">STATION DESCRIPTION</span>
            <textarea rows="3" [(ngModel)]="description" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white resize-none"></textarea>
          </div>
        </div>

        <!-- NETWORK & RTMP INGEST (Col 6) -->
        <div class="lg:col-span-6 bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            ORIGIN TRANSMISSION & RTMP KEYS
          </div>

          <div class="flex flex-col gap-1.5">
            <span class="text-slate-400">PRIMARY RTMP ORIGIN INGEST URL</span>
            <input type="text" value="rtmp://origin.btc.broadcast/live" readonly class="bg-[#090b0e] border border-slate-800 rounded p-2 text-slate-400" />
          </div>

          <div class="flex flex-col gap-1.5">
            <span class="text-slate-400">STREAM KEY</span>
            <div class="flex items-center gap-2">
              <input type="password" value="live_btc_98237492837498273948" readonly class="bg-[#090b0e] border border-slate-800 rounded p-2 text-slate-400 flex-1" />
              <button class="px-3 py-2 bg-slate-800 text-slate-300 rounded font-bold uppercase">REVEAL</button>
            </div>
          </div>

          <div class="flex flex-col gap-1.5">
            <span class="text-slate-400">HLS MASTER PLAYLIST URL</span>
            <input type="text" value="https://stream.btc.broadcast/live/master.m3u8" readonly class="bg-[#090b0e] border border-slate-800 rounded p-2 text-blue-400" />
          </div>
        </div>

      </div>

    </div>
  `,
})
export class SettingsComponent {
  bs = inject(BroadcastService);

  channelName = 'BTC.BROADCAST';
  callSign = 'BTC-PHILOSOPHER-TV';
  description = 'Personal Internet Broadcasting & Streaming Computer';

  saveSettings() {
    alert('Station settings committed.');
  }
}
