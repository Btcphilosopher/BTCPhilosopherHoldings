import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';
import { MediaItem } from '../../models/broadcast.models';

@Component({
  selector: 'app-media-library',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-blue-400">perm_media</mat-icon>
            STATION MEDIA ARCHIVE & INGEST SERVER
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Local video files, audio stems, station idents, bumper loops, and master archives with SHA256 checksum integrity.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="showIngestModal.set(true)"
            class="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold uppercase flex items-center gap-1.5 shadow">
            <mat-icon class="text-sm">file_upload</mat-icon>
            INGEST NEW MEDIA
          </button>
        </div>
      </div>

      <!-- MEDIA SEARCH & FILTER BAR -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0f1319] border border-slate-800 p-3 rounded-xl font-mono text-xs shadow-sm">
        <div class="flex items-center gap-2 flex-1 max-w-md">
          <mat-icon class="text-slate-500 text-base">search</mat-icon>
          <input
            type="text"
            [(ngModel)]="searchQuery"
            placeholder="Search media by title, tag, or codec..."
            class="w-full bg-[#090b0e] border border-slate-800 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500" />
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="selectedType.set('ALL')"
            [class]="'px-3 py-1.5 rounded font-bold uppercase ' + (selectedType() === 'ALL' ? 'bg-blue-900 text-blue-200 border border-blue-600' : 'bg-[#090b0e] text-slate-400 border border-slate-800')">
            ALL
          </button>
          <button
            (click)="selectedType.set('VIDEO')"
            [class]="'px-3 py-1.5 rounded font-bold uppercase ' + (selectedType() === 'VIDEO' ? 'bg-blue-900 text-blue-200 border border-blue-600' : 'bg-[#090b0e] text-slate-400 border border-slate-800')">
            VIDEOS
          </button>
          <button
            (click)="selectedType.set('AUDIO')"
            [class]="'px-3 py-1.5 rounded font-bold uppercase ' + (selectedType() === 'AUDIO' ? 'bg-blue-900 text-blue-200 border border-blue-600' : 'bg-[#090b0e] text-slate-400 border border-slate-800')">
            AUDIO
          </button>
        </div>
      </div>

      <!-- MEDIA GRID -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (item of filteredMedia(); track item.id) {
          <button
            type="button"
            (click)="selectMedia(item)"
            class="bg-[#0f1319] border border-slate-800 hover:border-slate-700 rounded-xl overflow-hidden p-3.5 flex flex-col gap-2.5 font-mono text-xs transition text-left cursor-pointer">
            <div class="relative aspect-video bg-black rounded-lg overflow-hidden border border-slate-800 group">
              <img [src]="item.thumbnailUrl" [alt]="item.title" class="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition" />
              <div class="absolute top-2 left-2 px-2 py-0.5 bg-black/80 rounded text-[10px] text-blue-400 font-bold uppercase border border-white/10">
                {{ item.type }} | {{ item.resolution }}
              </div>
              <div class="absolute bottom-2 right-2 px-2 py-0.5 bg-black/90 rounded text-[10px] text-amber-400 font-bold border border-white/10">
                {{ bs.formatTime(item.durationSeconds) }}
              </div>
            </div>

            <div class="font-bold text-white text-xs truncate">{{ item.title }}</div>
            <div class="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">{{ item.description }}</div>

            <div class="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800/80 mt-auto">
              <span>{{ item.codec }}</span>
              <span class="text-slate-400 font-bold">{{ (item.fileSizeBytes / 1000000).toFixed(0) }} MB</span>
            </div>
          </button>
        }
      </div>

      <!-- INGEST MEDIA MODAL -->
      @if (showIngestModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono text-xs">
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-5 max-w-md w-full flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <span class="font-bold text-white text-sm">INGEST MEDIA ASSET</span>
              <button (click)="showIngestModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">MEDIA TITLE</span>
              <input type="text" [(ngModel)]="newTitle" placeholder="The Architecture of Being - Ep 05" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">FILENAME</span>
              <input type="text" [(ngModel)]="newFilename" placeholder="architecture_ep5_master.mp4" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">PROGRAMME</span>
              <input type="text" [(ngModel)]="newProg" placeholder="The Architecture of Being" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
            </div>

            <button (click)="submitIngest()" class="py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase">
              REGISTER IN STATION ARCHIVE
            </button>
          </div>
        </div>
      }

    </div>
  `,
})
export class MediaLibraryComponent {
  bs = inject(BroadcastService);

  searchQuery = '';
  selectedType = signal<'ALL' | 'VIDEO' | 'AUDIO'>('ALL');
  showIngestModal = signal(false);

  newTitle = '';
  newFilename = '';
  newProg = '';

  filteredMedia() {
    return this.bs.mediaList().filter(m => {
      const matchesSearch =
        m.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        m.tags.some(t => t.toLowerCase().includes(this.searchQuery.toLowerCase()));
      const matchesType = this.selectedType() === 'ALL' || m.type === this.selectedType();
      return matchesSearch && matchesType;
    });
  }

  selectMedia(item: MediaItem) {
    alert(`Selected media asset: ${item.title} (${item.filename})`);
  }

  submitIngest() {
    if (this.newTitle) {
      this.bs.mediaList.update(list => [
        {
          id: `med-${Date.now()}`,
          filename: this.newFilename || 'uploaded.mp4',
          title: this.newTitle,
          description: 'User ingested media file.',
          type: 'VIDEO',
          durationSeconds: 1800,
          codec: 'H.264',
          resolution: '1080p60',
          fps: 60,
          audioFormat: 'AAC 48kHz',
          bitrateMbps: 8.0,
          fileSizeBytes: 1200000000,
          createdAt: new Date().toISOString(),
          tags: ['Station'],
          programmeName: this.newProg || 'General',
          archiveStatus: 'ORIGINAL',
          checksum: 'sha256-user-uploaded',
          url: 'https://picsum.photos/seed/usering/1280/720',
          thumbnailUrl: 'https://picsum.photos/seed/usering/400/225',
        },
        ...list,
      ]);
      this.showIngestModal.set(false);
      this.newTitle = '';
    }
  }
}
