import {
  Component,
  ChangeDetectionStrategy,
  inject,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-control-room',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#090b0e] text-slate-200 p-4 gap-4 overflow-y-auto">
      
      <!-- TOP CONTROL ROOM HEADER & PROGRAM METERING -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div class="flex items-center gap-3">
          <div [class]="'flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-bold tracking-wider uppercase border ' + (bs.state().status === 'ON_AIR' ? 'bg-red-950/80 text-red-400 border-red-800/80 animate-pulse' : 'bg-slate-800 text-slate-400 border-slate-700')">
            <span [class]="'w-2 h-2 rounded-full ' + (bs.state().status === 'ON_AIR' ? 'bg-red-500 shadow-[0_0_8px_#ef4444]' : 'bg-slate-500')"></span>
            {{ bs.state().status.replace('_', ' ') }}
          </div>
          <div class="flex items-center gap-2 text-xs font-mono text-slate-400 bg-[#090b0e] px-2.5 py-1 rounded border border-slate-800">
            <span class="text-slate-500">MODE:</span>
            <span class="text-blue-400 font-semibold">{{ bs.state().mode }}</span>
          </div>
          <div class="flex items-center gap-2 text-xs font-mono text-slate-400 bg-[#090b0e] px-2.5 py-1 rounded border border-slate-800">
            <span class="text-slate-500">AUTOPILOT:</span>
            <span [class]="bs.state().autopilotActive ? 'text-emerald-400 font-semibold' : 'text-slate-500'">{{ bs.state().autopilotActive ? 'ENABLED' : 'MANUAL' }}</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="bs.toggleOnAir()"
            [class]="'px-4 py-1.5 rounded-lg text-xs font-mono font-bold tracking-wider uppercase flex items-center gap-2 transition-all shadow-sm ' + (bs.state().status === 'ON_AIR' ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-900/40' : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/40')">
            <mat-icon class="text-sm">sensors</mat-icon>
            {{ bs.state().status === 'ON_AIR' ? 'CUT SIGNAL (OFF AIR)' : 'TRANSMIT (ON AIR)' }}
          </button>
          <button
            (click)="bs.toggleRecording()"
            [class]="'px-3 py-1.5 rounded-lg text-xs font-mono font-semibold uppercase flex items-center gap-1.5 border transition-all ' + (bs.state().recording ? 'bg-amber-950/40 text-amber-400 border-amber-800/80' : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700')">
            <mat-icon class="text-sm">{{ bs.state().recording ? 'fiber_manual_record' : 'radio_button_checked' }}</mat-icon>
            {{ bs.state().recording ? 'REC ON' : 'START REC' }}
          </button>
          <button
            (click)="bs.toggleAutopilot()"
            class="px-3 py-1.5 rounded-lg text-xs font-mono font-semibold uppercase bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-300 flex items-center gap-1.5">
            <mat-icon class="text-sm">autorenew</mat-icon>
            AUTOPILOT
          </button>
        </div>
      </div>

      <!-- MAIN CONTROL ROOM GRID Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        <!-- LEFT / MAIN: PROGRAM MONITOR & METRICS (Col 8) -->
        <div class="lg:col-span-8 flex flex-col gap-3">
          
          <!-- CENTRAL PROGRAM OUTPUT PREVIEW CANVAS -->
          <div class="relative bg-black rounded-xl overflow-hidden broadcast-monitor border border-slate-800 group aspect-video flex items-center justify-center">
            
            <!-- Simulated Program Video / Canvas -->
            <canvas #canvasEl class="w-full h-full object-cover block"></canvas>

            <!-- On-Screen Display Overlays -->
            <div class="absolute top-3 left-3 flex items-center gap-2 bg-black/70 backdrop-blur px-2.5 py-1 rounded border border-white/10 text-[11px] font-mono text-white">
              <span class="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              <span>PROGRAM OUTPUT</span>
              <span class="text-slate-400">|</span>
              <span class="text-emerald-400">{{ bs.state().fps }} FPS</span>
            </div>

            <!-- Lower Third Graphic Overlay Preview -->
            @if (bs.activeLowerThird(); as lt) {
              @if (lt.isVisible) {
                <div class="absolute bottom-6 left-6 max-w-md bg-slate-900/90 backdrop-blur border-l-4 border-blue-500 p-3 rounded-r-lg shadow-xl animate-fade-in">
                  <div class="text-xs font-mono text-blue-400 uppercase tracking-widest">{{ lt.subtitle }}</div>
                  <div class="text-lg font-bold text-white tracking-wide font-mono">{{ lt.title }}</div>
                </div>
              }
            }

            <!-- Station Logo Bug -->
            <div class="absolute top-3 right-3 bg-slate-950/80 border border-white/10 px-2 py-0.5 rounded text-[10px] font-mono font-bold tracking-widest text-slate-300 uppercase">
              BTC.BROADCAST
            </div>

            <!-- Timecode Overlay -->
            <div class="absolute bottom-3 right-3 bg-black/80 px-2 py-1 rounded border border-white/10 font-mono text-xs text-amber-400 font-semibold tracking-wider">
              {{ bs.formatTime(bs.state().durationSeconds) }}
            </div>
          </div>

          <!-- PROGRAMME STATS TELEMETRY BAR -->
          <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 bg-[#0f1319] border border-slate-800 p-2.5 rounded-xl font-mono text-xs">
            <div class="bg-[#090b0e] p-2 rounded border border-slate-800/80">
              <div class="text-[10px] text-slate-500 uppercase tracking-wider">Programme</div>
              <div class="text-slate-200 font-semibold truncate">{{ bs.state().currentProgrammeTitle }}</div>
            </div>
            <div class="bg-[#090b0e] p-2 rounded border border-slate-800/80">
              <div class="text-[10px] text-slate-500 uppercase tracking-wider">Duration</div>
              <div class="text-amber-400 font-semibold">{{ bs.formatTime(bs.state().durationSeconds) }}</div>
            </div>
            <div class="bg-[#090b0e] p-2 rounded border border-slate-800/80">
              <div class="text-[10px] text-slate-500 uppercase tracking-wider">Viewers</div>
              <div class="text-blue-400 font-semibold">{{ bs.state().viewerCount.toLocaleString() }}</div>
            </div>
            <div class="bg-[#090b0e] p-2 rounded border border-slate-800/80">
              <div class="text-[10px] text-slate-500 uppercase tracking-wider">Bitrate</div>
              <div class="text-emerald-400 font-semibold">{{ bs.state().bitrateMbps }} Mbps</div>
            </div>
            <div class="bg-[#090b0e] p-2 rounded border border-slate-800/80">
              <div class="text-[10px] text-slate-500 uppercase tracking-wider">FPS</div>
              <div class="text-slate-200 font-semibold">{{ bs.state().fps }}</div>
            </div>
            <div class="bg-[#090b0e] p-2 rounded border border-slate-800/80">
              <div class="text-[10px] text-slate-500 uppercase tracking-wider">Audio LUFS</div>
              <div class="text-amber-300 font-semibold">{{ bs.state().audioLevelLufs }} LUFS</div>
            </div>
            <div class="bg-[#090b0e] p-2 rounded border border-slate-800/80">
              <div class="text-[10px] text-slate-500 uppercase tracking-wider">Uptime</div>
              <div class="text-slate-400 font-semibold">{{ bs.formatTime(bs.state().uptimeSeconds) }}</div>
            </div>
          </div>

          <!-- BOTTOM MEDIA TIMELINE -->
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-3 flex flex-col gap-2">
            <div class="flex items-center justify-between font-mono text-xs text-slate-400">
              <span class="flex items-center gap-1.5 font-bold text-slate-200">
                <mat-icon class="text-sm text-blue-400">timeline</mat-icon>
                BROADCAST TIMELINE & SEGMENTS
              </span>
              <span class="text-slate-500">00:00 ── 15:00 ── 30:00 ── 45:00 ── 60:00</span>
            </div>
            <!-- Timeline Track -->
            <div class="relative h-10 bg-[#090b0e] rounded border border-slate-800 flex items-center overflow-hidden p-1 gap-1">
              <div class="h-full bg-blue-900/60 border border-blue-600/60 rounded px-2 text-[10px] font-mono flex items-center text-blue-200 w-[20%] truncate">
                00:00 Station Intro
              </div>
              <div class="h-full bg-emerald-900/60 border border-emerald-600/60 rounded px-2 text-[10px] font-mono flex items-center text-emerald-200 w-[45%] truncate font-bold">
                08:20 Main Discussion (LIVE)
              </div>
              <div class="h-full bg-amber-900/40 border border-amber-700/50 rounded px-2 text-[10px] font-mono flex items-center text-amber-200 w-[20%] truncate">
                41:10 Music Break
              </div>
              <div class="h-full bg-slate-800 border border-slate-700 rounded px-2 text-[10px] font-mono flex items-center text-slate-400 w-[15%] truncate">
                55:20 Closing
              </div>
              <!-- Playhead line -->
              <div class="absolute top-0 bottom-0 w-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] left-[38%] pointer-events-none"></div>
            </div>
          </div>
        </div>

        <!-- RIGHT SIDE PANELS: PREVIEW, SCENES, AUDIO, CHAT (Col 4) -->
        <div class="lg:col-span-4 flex flex-col gap-3">
          
          <!-- PREVIEW MONITOR & TRANSITION TRIGGER -->
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-3 flex flex-col gap-2">
            <div class="flex items-center justify-between font-mono text-xs">
              <span class="text-slate-400 flex items-center gap-1 font-semibold">
                <mat-icon class="text-sm text-amber-400">preview</mat-icon>
                PREVIEW BUS
              </span>
              <span class="text-amber-400 font-mono text-[11px] uppercase">READY FOR CUT</span>
            </div>

            <!-- Preview Box -->
            <div class="relative bg-black rounded-lg aspect-video border border-amber-900/40 overflow-hidden flex items-center justify-center group">
              <div class="absolute inset-0 bg-gradient-to-tr from-amber-950/20 to-transparent"></div>
              <div class="text-center font-mono p-2">
                <div class="text-xs text-amber-400 font-bold uppercase tracking-wider">
                  {{ getSceneName(bs.state().previewSceneId) }}
                </div>
                <div class="text-[10px] text-slate-500">STAGED PREVIEW SCENE</div>
              </div>
            </div>

            <!-- Transition Actions -->
            <div class="grid grid-cols-4 gap-1.5 font-mono text-xs pt-1">
              <button
                (click)="bs.performTransition('CUT')"
                class="bg-red-700 hover:bg-red-600 text-white font-bold py-1.5 rounded transition text-[11px] uppercase shadow-sm">
                CUT
              </button>
              <button
                (click)="bs.performTransition('FADE')"
                class="bg-blue-800 hover:bg-blue-700 text-blue-100 font-semibold py-1.5 rounded transition text-[11px] uppercase">
                FADE
              </button>
              <button
                (click)="bs.performTransition('DISSOLVE')"
                class="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-1.5 rounded transition text-[11px] uppercase">
                DISSOLVE
              </button>
              <button
                (click)="bs.performTransition('WIPE')"
                class="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-1.5 rounded transition text-[11px] uppercase">
                WIPE
              </button>
            </div>
          </div>

          <!-- SCENE SELECTOR GRID -->
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-3 flex flex-col gap-2">
            <div class="font-mono text-xs text-slate-400 font-semibold flex items-center justify-between">
              <span class="flex items-center gap-1">
                <mat-icon class="text-sm text-blue-400">dashboard</mat-icon>
                PRODUCTION SCENES
              </span>
              <span class="text-[10px] text-slate-500">{{ bs.scenes().length }} SCENES</span>
            </div>

            <div class="grid grid-cols-2 gap-2">
              @for (sc of bs.scenes(); track sc.id) {
                <button
                  (click)="bs.switchScene(sc.id)"
                  [class]="'p-2 rounded-lg border text-left font-mono transition-all flex flex-col gap-1 ' + (bs.state().currentSceneId === sc.id ? 'bg-blue-950/80 border-blue-500 text-white shadow-md' : 'bg-[#090b0e] border-slate-800 hover:border-slate-700 text-slate-300')">
                  <div class="flex items-center justify-between text-xs font-bold">
                    <span>{{ sc.name }}</span>
                    @if (bs.state().currentSceneId === sc.id) {
                      <span class="w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
                    }
                  </div>
                  <div class="text-[10px] text-slate-500 truncate">{{ sc.description }}</div>
                </button>
              }
            </div>
          </div>

          <!-- MASTER AUDIO LEVEL METER -->
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-3 flex flex-col gap-2">
            <div class="font-mono text-xs text-slate-400 font-semibold flex items-center justify-between">
              <span class="flex items-center gap-1">
                <mat-icon class="text-sm text-emerald-400">equalizer</mat-icon>
                MASTER AUDIO METERS (LUFS / PEAK)
              </span>
              <span class="text-emerald-400 text-[11px] font-mono">-14.2 LUFS</span>
            </div>

            <!-- Stereo VU Bars -->
            <div class="flex flex-col gap-1.5 font-mono text-[10px]">
              <div class="flex items-center gap-2">
                <span class="w-3 text-slate-500">L</span>
                <div class="flex-1 h-3 bg-[#090b0e] rounded overflow-hidden border border-slate-800 p-0.5">
                  <div class="h-full vu-level-bar rounded-sm" style="width: 78%"></div>
                </div>
                <span class="w-8 text-right text-slate-400">-1.5dB</span>
              </div>
              <div class="flex items-center gap-2">
                <span class="w-3 text-slate-500">R</span>
                <div class="flex-1 h-3 bg-[#090b0e] rounded overflow-hidden border border-slate-800 p-0.5">
                  <div class="h-full vu-level-bar rounded-sm" style="width: 76%"></div>
                </div>
                <span class="w-8 text-right text-slate-400">-1.8dB</span>
              </div>
            </div>
          </div>

          <!-- STREAM DESTINATIONS & HEALTH -->
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-3 flex flex-col gap-2 font-mono text-xs">
            <div class="text-slate-400 font-semibold flex items-center justify-between">
              <span class="flex items-center gap-1">
                <mat-icon class="text-sm text-purple-400">router</mat-icon>
                TRANSMISSION ENDPOINTS
              </span>
              <span class="text-emerald-400 text-[10px]">● 3 ONLINE</span>
            </div>

            <div class="flex flex-col gap-1.5">
              @for (dest of bs.state().destinations; track dest.id) {
                <div class="bg-[#090b0e] p-2 rounded border border-slate-800 flex items-center justify-between">
                  <div class="flex flex-col">
                    <span class="text-slate-200 font-semibold text-[11px]">{{ dest.name }}</span>
                    <span class="text-[10px] text-slate-500">{{ dest.protocol }} | {{ dest.resolution }} | {{ dest.bitrateMbps }} Mbps</span>
                  </div>
                  <span class="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                    {{ dest.status }}
                  </span>
                </div>
              }
            </div>
          </div>

        </div>

      </div>

    </div>
  `,
})
export class ControlRoomComponent implements AfterViewInit, OnDestroy {
  bs = inject(BroadcastService);

  @ViewChild('canvasEl') canvasRef!: ElementRef<HTMLCanvasElement>;
  private animationFrameId?: number;

  ngAfterViewInit() {
    this.startCanvasRendering();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  getSceneName(sceneId: string): string {
    const sc = this.bs.scenes().find(s => s.id === sceneId);
    return sc ? sc.name : sceneId;
  }

  private startCanvasRendering() {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 1280;
    canvas.height = 720;

    let frameCount = 0;

    const render = () => {
      frameCount++;
      const width = canvas.width;
      const height = canvas.height;

      ctx.fillStyle = '#0a0d12';
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      const currentSceneId = this.bs.state().currentSceneId;

      if (currentSceneId === 'scene-talking-head') {
        ctx.save();
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(width * 0.25, height * 0.15, width * 0.5, height * 0.7);

        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < width * 0.5; i += 8) {
          const yVal = height * 0.5 + Math.sin((frameCount + i) * 0.05) * 20;
          if (i === 0) ctx.moveTo(width * 0.25 + i, yVal);
          else ctx.lineTo(width * 0.25 + i, yVal);
        }
        ctx.stroke();

        ctx.fillStyle = '#f8fafc';
        ctx.font = 'bold 24px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText('STUDIO CAMERA 1 (LIVE)', width * 0.5, height * 0.45);
        ctx.font = '16px "Plus Jakarta Sans", sans-serif';
        ctx.fillStyle = '#94a3b8';
        ctx.fillText('BTCPhilosopher Broadcast Stream', width * 0.5, height * 0.52);
        ctx.restore();
      } else if (currentSceneId === 'scene-screencast') {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(40, 40, width - 80, height - 80);
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 20px "JetBrains Mono", monospace';
        ctx.fillText('> BTC.BROADCAST DECENTRALIZED TRANSMITTER ENGINE', 80, 100);

        ctx.fillStyle = '#1e293b';
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 3;
        ctx.fillRect(width * 0.68, height * 0.6, width * 0.28, height * 0.32);
        ctx.strokeRect(width * 0.68, height * 0.6, width * 0.28, height * 0.32);
        ctx.fillStyle = '#ffffff';
        ctx.font = '14px font-mono';
        ctx.fillText('CAMERA PiP', width * 0.72, height * 0.75);
      } else {
        ctx.fillStyle = '#334155';
        ctx.font = 'bold 28px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`SCENE: ${currentSceneId.toUpperCase()}`, width * 0.5, height * 0.5);
      }

      const lt = this.bs.activeLowerThird();
      if (lt && lt.isVisible) {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
        ctx.fillRect(60, height - 120, 420, 80);
        ctx.fillStyle = '#3b82f6';
        ctx.fillRect(60, height - 120, 6, 80);

        ctx.fillStyle = '#60a5fa';
        ctx.font = 'bold 12px "JetBrains Mono", monospace';
        ctx.textAlign = 'left';
        ctx.fillText(lt.subtitle.toUpperCase(), 80, height - 92);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 20px "JetBrains Mono", monospace';
        ctx.fillText(lt.title, 80, height - 64);
      }

      this.animationFrameId = requestAnimationFrame(render);
    };

    render();
  }
}
