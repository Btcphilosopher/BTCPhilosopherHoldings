import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-archive-view',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#090b0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-blue-400">history</mat-icon>
            BROADCAST ARCHIVE & TIMESCALE REPLAY
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Immutable station broadcast history timescale, clipping engine, and Gemini AI Archivist.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="showClipModal.set(true)"
            class="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold uppercase flex items-center gap-1.5 shadow">
            <mat-icon class="text-sm">content_cut</mat-icon>
            CREATE BROADCAST CLIP
          </button>
        </div>
      </div>

      <!-- AI ARCHIVIST SEARCH BOX -->
      <div class="bg-[#0f1319] border border-purple-900/60 rounded-xl p-4 flex flex-col gap-3 font-mono text-xs shadow-md">
        <div class="flex items-center gap-2 text-purple-400 font-bold uppercase tracking-wider">
          <mat-icon class="text-base">auto_awesome</mat-icon>
          GEMINI 3.7 AI ARCHIVIST & SEMANTIC SEARCH
        </div>

        <div class="flex items-center gap-2">
          <input
            type="text"
            [(ngModel)]="aiSearchQuery"
            (keyup.enter)="searchArchiveWithAi()"
            placeholder="Ask AI Archivist e.g., 'When did we talk about time-domain software architecture in Ep 4?'"
            class="flex-1 bg-[#090b0e] border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-purple-500 font-mono" />
          <button
            (click)="searchArchiveWithAi()"
            class="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg uppercase flex items-center gap-1">
            <mat-icon class="text-sm">search</mat-icon>
            QUERY ARCHIVE
          </button>
        </div>

        @if (aiAnswer()) {
          <div class="bg-[#090b0e] border border-purple-800/80 p-3 rounded-lg text-slate-200 text-xs leading-relaxed animate-fade-in font-mono">
            <div class="text-[10px] text-purple-400 font-bold uppercase mb-1">AI ARCHIVIST RESPONSE</div>
            {{ aiAnswer() }}
          </div>
        }
      </div>

      <!-- ARCHIVE LIST & TIMELINE -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        <!-- CLIPS LIST (Col 8) -->
        <div class="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-3">
          @for (clip of bs.archiveList(); track clip.id) {
            <div class="bg-[#0f1319] border border-slate-800 hover:border-slate-700 rounded-xl overflow-hidden p-3 flex flex-col gap-2 font-mono text-xs">
              <div class="relative aspect-video bg-black rounded-lg overflow-hidden border border-slate-800 group">
                <img [src]="clip.thumbnailUrl" [alt]="clip.clipTitle" class="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition" />
                <div class="absolute bottom-2 right-2 px-2 py-0.5 bg-black/90 rounded text-[10px] text-amber-400 font-semibold border border-white/10">
                  {{ clip.startTimeFormatted }} - {{ clip.endTimeFormatted }}
                </div>
              </div>

              <div class="font-bold text-white text-xs truncate">{{ clip.clipTitle }}</div>
              <div class="text-[11px] text-slate-400 line-clamp-2">{{ clip.description }}</div>

              <div class="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800/80 mt-auto">
                <span>{{ clip.broadcastTitle }}</span>
                <span class="text-blue-400 font-semibold">{{ clip.durationSeconds }}s</span>
              </div>
            </div>
          }
        </div>

        <!-- TIMELINE SELECTOR (Col 4) -->
        <div class="lg:col-span-4 bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-col gap-3 font-mono text-xs">
          <div class="text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="flex items-center gap-1 text-slate-200">
              <mat-icon class="text-sm text-blue-400">calendar_today</mat-icon>
              BROADCAST TIMELINE NAVIGATOR
            </span>
          </div>

          <div class="flex flex-col gap-2">
            <div class="p-2.5 bg-[#090b0e] border border-blue-900/60 rounded-lg flex items-center justify-between font-bold text-white">
              <span>SEPTEMBER 2026</span>
              <span class="text-blue-400 text-[10px]">14 RECORDINGS</span>
            </div>
            <div class="p-2 bg-[#090b0e] border border-slate-800 rounded flex items-center justify-between text-slate-400">
              <span>2026-09-10 (TODAY)</span>
              <span class="text-emerald-400 font-bold">RECORDING ON AIR</span>
            </div>
            <div class="p-2 bg-[#090b0e] border border-slate-800 rounded flex items-center justify-between text-slate-400">
              <span>2026-09-08</span>
              <span>2 SHOWS</span>
            </div>
            <div class="p-2 bg-[#090b0e] border border-slate-800 rounded flex items-center justify-between text-slate-400">
              <span>2026-09-05</span>
              <span>1 SHOW</span>
            </div>
          </div>
        </div>

      </div>

      <!-- CREATE CLIP MODAL -->
      @if (showClipModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono text-xs">
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-5 max-w-md w-full flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <span class="font-bold text-white text-sm">CREATE HIGHLIGHT CLIP</span>
              <button (click)="showClipModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">CLIP TITLE</span>
              <input
                type="text"
                [(ngModel)]="clipTitle"
                placeholder="Key insight on time-domain architecture"
                class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
            </div>

            <div class="grid grid-cols-2 gap-2">
              <div class="flex flex-col gap-2">
                <span class="text-slate-400">START TIME</span>
                <input type="text" [(ngModel)]="clipStart" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
              </div>
              <div class="flex flex-col gap-2">
                <span class="text-slate-400">END TIME</span>
                <input type="text" [(ngModel)]="clipEnd" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
              </div>
            </div>

            <button
              (click)="saveClip()"
              class="py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase">
              GENERATE ARCHIVE CLIP
            </button>
          </div>
        </div>
      }

    </div>
  `,
})
export class ArchiveViewComponent {
  bs = inject(BroadcastService);

  showClipModal = signal(false);
  aiSearchQuery = '';
  aiAnswer = signal('');

  clipTitle = 'Key Highlight Segment';
  clipStart = '02:14';
  clipEnd = '07:51';

  async searchArchiveWithAi() {
    if (this.aiSearchQuery) {
      const res = await this.bs.queryAiArchivist(this.aiSearchQuery);
      if (res && res.answer) {
        this.aiAnswer.set(res.answer);
      }
    }
  }

  saveClip() {
    this.bs.createClip(this.clipTitle, 'Clip generated from station broadcast timescale.', this.clipStart, this.clipEnd);
    this.showClipModal.set(false);
  }
}
