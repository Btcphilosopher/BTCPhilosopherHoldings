import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-digital-twin',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-blue-400">account_tree</mat-icon>
            DIGITAL TWIN & BROADCAST TOPOLOGY VISUALIZER
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Interactive system architecture map displaying inputs, routing matrix, hardware encoding, and CDN distribution nodes.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-3 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
            TOPOLOGY STATUS: SYNCHRONIZED
          </span>
        </div>
      </div>

      <!-- TOPOLOGY DIAGRAM CANVAS CONTAINER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-6 flex flex-col gap-6 font-mono text-xs shadow-md">
        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
          
          <!-- NODE 1: INPUT SOURCES -->
          <button
            type="button"
            (click)="selectedNode.set('INPUTS')"
            [class]="'p-4 rounded-xl border text-left flex flex-col gap-2 transition-all cursor-pointer ' + (selectedNode() === 'INPUTS' ? 'bg-blue-950/80 border-blue-500 text-white shadow-lg shadow-blue-950/50' : 'bg-[#090b0e] border-slate-800 text-slate-300')">
            <div class="flex items-center justify-between text-xs font-bold text-blue-400 border-b border-slate-800 pb-2">
              <span class="flex items-center gap-1"><mat-icon class="text-sm">videocam</mat-icon> MEDIA INPUTS</span>
              <span class="w-2 h-2 rounded-full bg-blue-400"></span>
            </div>
            <div class="text-[11px] font-bold text-white">Studio Cam 1 (1080p60)</div>
            <div class="text-[11px] text-slate-400">Master Mic (Opus 320k)</div>
            <div class="text-[11px] text-slate-400">Screen Capture (VP9)</div>
            <div class="mt-2 text-[10px] text-blue-400 font-semibold">● 3 ACTIVE SOURCES</div>
          </button>

          <!-- NODE 2: STUDIO MATRIX SWITCHER -->
          <button
            type="button"
            (click)="selectedNode.set('MATRIX')"
            [class]="'p-4 rounded-xl border text-left flex flex-col gap-2 transition-all cursor-pointer ' + (selectedNode() === 'MATRIX' ? 'bg-purple-950/80 border-purple-500 text-white shadow-lg shadow-purple-950/50' : 'bg-[#090b0e] border-slate-800 text-slate-300')">
            <div class="flex items-center justify-between text-xs font-bold text-purple-400 border-b border-slate-800 pb-2">
              <span class="flex items-center gap-1"><mat-icon class="text-sm">tune</mat-icon> MIXER MATRIX</span>
              <span class="w-2 h-2 rounded-full bg-purple-400"></span>
            </div>
            <div class="text-[11px] font-bold text-white">Scene: {{ bs.currentScene().name }}</div>
            <div class="text-[11px] text-slate-400">Lower Third: Active</div>
            <div class="text-[11px] text-slate-400">Audio LUFS: -14.2 Target</div>
            <div class="mt-2 text-[10px] text-purple-400 font-semibold">● ZERO-LATENCY ROUTE</div>
          </button>

          <!-- NODE 3: FFMPEG DETERMINISTIC ENCODER -->
          <button
            type="button"
            (click)="selectedNode.set('ENCODER')"
            [class]="'p-4 rounded-xl border text-left flex flex-col gap-2 transition-all cursor-pointer ' + (selectedNode() === 'ENCODER' ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-lg shadow-emerald-950/50' : 'bg-[#090b0e] border-slate-800 text-slate-300')">
            <div class="flex items-center justify-between text-xs font-bold text-emerald-400 border-b border-slate-800 pb-2">
              <span class="flex items-center gap-1"><mat-icon class="text-sm">memory</mat-icon> FFMPEG PIPELINE</span>
              <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            </div>
            <div class="text-[11px] font-bold text-white">H.264 / AAC Encoding</div>
            <div class="text-[11px] text-slate-400">Bitrate: {{ bs.state().bitrateMbps }} Mbps</div>
            <div class="text-[11px] text-slate-400">CPU Load: {{ bs.state().cpuLoadPercent }}%</div>
            <div class="mt-2 text-[10px] text-emerald-400 font-semibold">● 59.94 FPS DETERMINISTIC</div>
          </button>

          <!-- NODE 4: EDGE DISTRIBUTION RELAYS -->
          <button
            type="button"
            (click)="selectedNode.set('EDGE')"
            [class]="'p-4 rounded-xl border text-left flex flex-col gap-2 transition-all cursor-pointer ' + (selectedNode() === 'EDGE' ? 'bg-amber-950/80 border-amber-500 text-white shadow-lg shadow-amber-950/50' : 'bg-[#090b0e] border-slate-800 text-slate-300')">
            <div class="flex items-center justify-between text-xs font-bold text-amber-400 border-b border-slate-800 pb-2">
              <span class="flex items-center gap-1"><mat-icon class="text-sm">cell_tower</mat-icon> EDGE RELAYS</span>
              <span class="w-2 h-2 rounded-full bg-amber-400"></span>
            </div>
            <div class="text-[11px] font-bold text-white">3 Active Endpoints</div>
            <div class="text-[11px] text-slate-400">HLS + RTMP Transmit</div>
            <div class="text-[11px] text-slate-400">Viewers: {{ bs.state().viewerCount.toLocaleString() }}</div>
            <div class="mt-2 text-[10px] text-amber-400 font-semibold">● 100% REACH</div>
          </button>

        </div>

        <!-- SELECTED NODE INSPECTOR PANEL -->
        <div class="bg-[#090b0e] border border-slate-800 p-4 rounded-xl flex flex-col gap-2">
          <div class="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
            <mat-icon class="text-sm text-blue-400">find_in_page</mat-icon>
            NODE ARCHITECTURE INSPECTOR: {{ selectedNode() }}
          </div>

          @if (selectedNode() === 'INPUTS') {
            <p class="text-slate-300 text-xs leading-relaxed">
              Input captures process high frame rate uncompressed or WebRTC video/audio buffers directly from hardware cameras, microphones, and screen framebuffers.
            </p>
          } @else if (selectedNode() === 'MATRIX') {
            <p class="text-slate-300 text-xs leading-relaxed">
              The studio matrix routes video layers, composites lower third graphics, applies audio compression, and outputs a clean master Program feed.
            </p>
          } @else if (selectedNode() === 'ENCODER') {
            <p class="text-slate-300 text-xs leading-relaxed">
              FFmpeg software/hardware encoder compresses the 1080p60 YUV420p video master stream into H.264/AAC TS segments with zero frame drops.
            </p>
          } @else {
            <p class="text-slate-300 text-xs leading-relaxed">
              Distributed edge relays push sovereign HLS master playlists and RTMP feeds to internet peers and public viewers worldwide.
            </p>
          }
        </div>

      </div>

    </div>
  `,
})
export class DigitalTwinComponent {
  bs = inject(BroadcastService);

  selectedNode = signal<'INPUTS' | 'MATRIX' | 'ENCODER' | 'EDGE'>('ENCODER');
}
