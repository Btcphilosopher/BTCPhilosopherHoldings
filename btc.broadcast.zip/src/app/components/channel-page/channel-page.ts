import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-channel-page',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#07090c] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- CHANNEL BANNER / HEADER -->
      <div class="bg-[#0f1319] border border-slate-800/80 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center font-mono font-bold text-white text-lg shadow-md shadow-blue-900/50">
            BTC
          </div>
          <div class="flex flex-col">
            <h1 class="text-base font-mono font-bold text-white flex items-center gap-2">
              BTC.BROADCAST
              <span class="text-xs px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-normal">SOVEREIGN CHANNEL</span>
            </h1>
            <p class="text-xs text-slate-400 font-mono">
              Broadcaster: BTCPhilosopher | Continuous Independent Television Station
            </p>
          </div>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="showEmbedCode.set(!showEmbedCode())"
            class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-semibold flex items-center gap-1.5 border border-slate-700">
            <mat-icon class="text-sm">code</mat-icon>
            EMBED PLAYER
          </button>
          <button
            (click)="showTipDrawer.set(true)"
            class="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-lg flex items-center gap-1.5 shadow shadow-amber-900/40">
            <mat-icon class="text-sm">bolt</mat-icon>
            LIGHTNING TIP
          </button>
        </div>
      </div>

      <!-- EMBED CODE CODEBOX -->
      @if (showEmbedCode()) {
        <div class="bg-[#0f1319] border border-blue-900/60 rounded-xl p-3 font-mono text-xs flex flex-col gap-2">
          <div class="text-blue-400 font-bold flex items-center justify-between">
            <span>EMBEDDABLE CHANNEL PLAYER CODE</span>
            <button (click)="copyEmbedCode()" class="text-slate-400 hover:text-white text-[11px] uppercase">COPY CODE</button>
          </div>
          <pre class="bg-[#07090c] p-2.5 rounded border border-slate-800 text-slate-300 overflow-x-auto text-[11px]">&lt;btc-player channel="btcphilosopher" autoplay="false" controls="true" theme="dark"&gt;&lt;/btc-player&gt;</pre>
        </div>
      }

      <!-- CHANNEL MAIN SECTION (PLAYER & CHAT SIDEBAR) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        <!-- PLAYER & PROGRAMME DETAILS (Col 8) -->
        <div class="lg:col-span-8 flex flex-col gap-3">
          
          <!-- BTC.BROADCAST EMBEDDABLE PLAYER -->
          <div class="relative bg-black rounded-xl overflow-hidden border border-slate-800 aspect-video group shadow-2xl flex items-center justify-center">
            
            <!-- Video Canvas Stream -->
            <div class="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-black flex items-center justify-center">
              <div class="text-center font-mono flex flex-col items-center gap-3">
                <div class="w-16 h-16 rounded-full bg-blue-600/20 border border-blue-500 flex items-center justify-center text-blue-400 animate-pulse">
                  <mat-icon class="text-3xl">play_arrow</mat-icon>
                </div>
                <div class="text-sm font-bold text-white tracking-wide">
                  {{ bs.state().currentProgrammeTitle }}
                </div>
                <div class="text-xs text-slate-400">
                  {{ bs.state().currentEpisodeTitle }}
                </div>
              </div>
            </div>

            <!-- On-Air Badge -->
            <div class="absolute top-3 left-3 flex items-center gap-2 bg-red-950/90 border border-red-800 px-2.5 py-1 rounded text-[10px] font-mono font-bold text-red-400 uppercase">
              <span class="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
              ON AIR
            </div>

            <!-- Lower Third Overlay -->
            @if (bs.activeLowerThird(); as lt) {
              @if (lt.isVisible) {
                <div class="absolute bottom-16 left-6 max-w-md bg-slate-950/90 border-l-4 border-blue-500 p-3 rounded-r-lg shadow-2xl">
                  <div class="text-xs font-mono text-blue-400 uppercase tracking-widest">{{ lt.subtitle }}</div>
                  <div class="text-base font-bold text-white font-mono">{{ lt.title }}</div>
                </div>
              }
            }

            <!-- Custom Player Controls Bar -->
            <div class="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black via-black/80 to-transparent p-3 flex items-center justify-between text-white font-mono text-xs opacity-90 group-hover:opacity-100 transition">
              <div class="flex items-center gap-3">
                <button (click)="isPlaying.set(!isPlaying())" class="hover:text-blue-400 transition">
                  <mat-icon class="text-base">{{ isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
                </button>
                <div class="flex items-center gap-1.5 text-xs text-red-400 font-bold uppercase">
                  <span class="w-2 h-2 rounded-full bg-red-500"></span>
                  LIVE
                </div>
                <span class="text-slate-400 text-[11px]">{{ bs.formatTime(bs.state().durationSeconds) }}</span>
              </div>

              <div class="flex items-center gap-3 text-slate-300">
                <span class="text-[10px] px-2 py-0.5 bg-slate-800 border border-slate-700 rounded text-blue-400 font-bold">1080p60</span>
                <button class="hover:text-white"><mat-icon class="text-base">volume_up</mat-icon></button>
                <button class="hover:text-white"><mat-icon class="text-base">subtitles</mat-icon></button>
                <button class="hover:text-white"><mat-icon class="text-base">fullscreen</mat-icon></button>
              </div>
            </div>
          </div>

          <!-- ON AIR DETAILS & NEXT UP CARD -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <div class="bg-[#0f1319] border border-slate-800 p-3.5 rounded-xl flex flex-col gap-1.5">
              <span class="text-[10px] text-blue-400 font-bold uppercase tracking-wider">CURRENT PROGRAMME</span>
              <span class="text-sm font-bold text-white">{{ bs.state().currentProgrammeTitle }}</span>
              <span class="text-slate-400 text-[11px]">{{ bs.state().currentEpisodeTitle }}</span>
            </div>

            <div class="bg-[#0f1319] border border-slate-800 p-3.5 rounded-xl flex flex-col gap-1.5">
              <span class="text-[10px] text-amber-400 font-bold uppercase tracking-wider">UP NEXT ON CHANNEL</span>
              <span class="text-sm font-bold text-white">Philology Revolution Radio</span>
              <span class="text-slate-400 text-[11px]">Session 02 — Cryptography & Value @ 10:00 UTC</span>
            </div>
          </div>
        </div>

        <!-- LIVE CHAT SIDEBAR (Col 4) -->
        <div class="lg:col-span-4 bg-[#0f1319] border border-slate-800 rounded-xl p-3 flex flex-col gap-2 h-[480px] font-mono text-xs">
          <div class="text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="flex items-center gap-1 text-slate-200">
              <mat-icon class="text-sm text-blue-400">chat</mat-icon>
              STATION LIVE CHAT
            </span>
            <span class="text-slate-500 text-[10px]">{{ bs.chatMessages().length }} MESSAGES</span>
          </div>

          <!-- Chat Scroll Feed -->
          <div class="flex-1 overflow-y-auto flex flex-col gap-2 pr-1">
            @for (msg of bs.chatMessages(); track msg.id) {
              <div [class]="'p-2 rounded border flex flex-col gap-1 ' + (msg.role === 'BROADCASTER' ? 'bg-blue-950/40 border-blue-800/80' : 'bg-[#07090c] border-slate-800')">
                <div class="flex items-center justify-between text-[11px]">
                  <span [class]="'font-bold ' + (msg.role === 'BROADCASTER' ? 'text-blue-400' : 'text-slate-300')">
                    {{ msg.username }}
                  </span>
                  <span class="text-slate-500 text-[9px]">{{ msg.timestamp }}</span>
                </div>
                <div class="text-slate-200 text-[11px] leading-relaxed">{{ msg.text }}</div>
                @if (msg.satsTipped) {
                  <div class="text-[10px] font-bold text-amber-400 flex items-center gap-1 pt-0.5">
                    <mat-icon class="text-xs">bolt</mat-icon> Tipped {{ msg.satsTipped }} Sats
                  </div>
                }
              </div>
            }
          </div>

          <!-- Send Input Bar -->
          <div class="flex items-center gap-1.5 pt-2 border-t border-slate-800">
            <input
              type="text"
              [(ngModel)]="chatInput"
              (keyup.enter)="sendChat()"
              placeholder="Send message to station chat..."
              class="flex-1 bg-[#07090c] border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500" />
            <button
              (click)="sendChat()"
              class="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase">
              SEND
            </button>
          </div>
        </div>

      </div>

      <!-- LIGHTNING TIP DRAWER MODAL -->
      @if (showTipDrawer()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono">
          <div class="bg-[#0f1319] border border-amber-800/80 rounded-xl p-5 max-w-md w-full flex flex-col gap-4 text-xs">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <span class="font-bold text-amber-400 text-sm flex items-center gap-1">
                <mat-icon>bolt</mat-icon>
                LIGHTNING TIP TO BROADCASTER
              </span>
              <button (click)="showTipDrawer.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">YOUR SENDER HANDLE</span>
              <input
                type="text"
                [(ngModel)]="tipSender"
                placeholder="cypherpunk_listener"
                class="bg-[#07090c] border border-slate-800 rounded p-2 text-white" />
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">TIP AMOUNT (SATS)</span>
              <div class="grid grid-cols-3 gap-2">
                <button (click)="tipSats = 1000" [class]="'p-2 rounded border font-bold ' + (tipSats === 1000 ? 'bg-amber-950 text-amber-400 border-amber-600' : 'bg-[#07090c] border-slate-800')">1,000 SATS</button>
                <button (click)="tipSats = 10000" [class]="'p-2 rounded border font-bold ' + (tipSats === 10000 ? 'bg-amber-950 text-amber-400 border-amber-600' : 'bg-[#07090c] border-slate-800')">10,000 SATS</button>
                <button (click)="tipSats = 50000" [class]="'p-2 rounded border font-bold ' + (tipSats === 50000 ? 'bg-amber-950 text-amber-400 border-amber-600' : 'bg-[#07090c] border-slate-800')">50,000 SATS</button>
              </div>
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">MESSAGE TO BROADCASTER</span>
              <input
                type="text"
                [(ngModel)]="tipMessage"
                placeholder="Great episode on software time!"
                class="bg-[#07090c] border border-slate-800 rounded p-2 text-white" />
            </div>

            <button
              (click)="submitTip()"
              class="py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded uppercase text-sm shadow">
              PAY INVOICE VIA LIGHTNING
            </button>
          </div>
        </div>
      }

    </div>
  `,
})
export class ChannelPageComponent {
  bs = inject(BroadcastService);

  isPlaying = signal(true);
  showEmbedCode = signal(false);
  showTipDrawer = signal(false);

  chatInput = '';
  tipSender = 'satoshi_viewer';
  tipSats = 10000;
  tipMessage = 'Supporting independent broadcast engineering!';

  sendChat() {
    if (this.chatInput) {
      this.bs.sendChatMessage('Viewer_99', this.chatInput);
      this.chatInput = '';
    }
  }

  copyEmbedCode() {
    navigator.clipboard.writeText('<btc-player channel="btcphilosopher" autoplay="false" controls="true"></btc-player>');
    alert('Embed code copied to clipboard!');
  }

  submitTip() {
    this.bs.sendTip(this.tipSender, this.tipSats, this.tipMessage);
    this.showTipDrawer.set(false);
    alert(`Lightning tip of ${this.tipSats} Sats confirmed for BTC.BROADCAST.`);
  }
}
