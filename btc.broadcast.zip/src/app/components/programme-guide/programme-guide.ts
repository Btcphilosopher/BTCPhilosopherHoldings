import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BroadcastService } from '../../services/broadcast';

@Component({
  selector: 'app-programme-guide',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#080a0e] text-slate-200 p-4 gap-4 overflow-y-auto font-sans">
      
      <!-- HEADER -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 class="text-base font-mono font-bold text-white flex items-center gap-2">
            <mat-icon class="text-blue-400">event_note</mat-icon>
            ELECTRONIC PROGRAMME GUIDE (EPG) & SCHEDULER
          </h2>
          <p class="text-xs text-slate-400 font-mono">
            Automated grid scheduling, programme series management, and continuous playout rules.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="showAddModal.set(true)"
            class="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold uppercase flex items-center gap-1.5 shadow">
            <mat-icon class="text-sm">add</mat-icon>
            SCHEDULE BROADCAST
          </button>
        </div>
      </div>

      <!-- EPG SCHEDULE GRID -->
      <div class="bg-[#0f1319] border border-slate-800 rounded-xl overflow-hidden font-mono text-xs flex flex-col shadow-md">
        <div class="bg-[#090b0e] p-3 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider grid grid-cols-12 gap-2">
          <div class="col-span-2">TIME SLOT</div>
          <div class="col-span-6">PROGRAMME / EPISODE TITLE</div>
          <div class="col-span-2">TYPE</div>
          <div class="col-span-2 text-right">STATUS</div>
        </div>

        <div class="divide-y divide-slate-800/60">
          @for (item of bs.scheduleList(); track item.id) {
            <div [class]="'p-3 grid grid-cols-12 gap-2 items-center transition ' + (item.status === 'LIVE' ? 'bg-red-950/30 border-l-4 border-red-500 font-bold' : 'hover:bg-slate-900/40')">
              <div class="col-span-2 text-amber-400 font-bold flex items-center gap-1">
                <mat-icon class="text-sm text-slate-500">schedule</mat-icon>
                {{ item.startTime }} - {{ item.endTime }}
              </div>
              <div class="col-span-6 text-white text-xs">
                {{ item.episodeTitle }}
              </div>
              <div class="col-span-2">
                <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 text-[10px]">
                  {{ item.type }}
                </span>
              </div>
              <div class="col-span-2 text-right">
                <span [class]="'px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ' + (item.status === 'LIVE' ? 'bg-red-950 text-red-400 border border-red-800 animate-pulse' : 'bg-slate-800 text-slate-400')">
                  {{ item.status }}
                </span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- ADD SCHEDULE ITEM MODAL -->
      @if (showAddModal()) {
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono text-xs">
          <div class="bg-[#0f1319] border border-slate-800 rounded-xl p-5 max-w-md w-full flex flex-col gap-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <span class="font-bold text-white text-sm">SCHEDULE PROGRAMME SLOT</span>
              <button (click)="showAddModal.set(false)" class="text-slate-400 hover:text-white">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">EPISODE / SHOW TITLE</span>
              <input type="text" [(ngModel)]="newTitle" placeholder="The Architecture of Being - Ep 05" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
            </div>

            <div class="flex flex-col gap-2">
              <span class="text-slate-400">START TIME (UTC)</span>
              <input type="text" [(ngModel)]="newStart" placeholder="18:00" class="bg-[#090b0e] border border-slate-800 rounded p-2 text-white" />
            </div>

            <button (click)="submitAdd()" class="py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase">
              ADD TO EPG SCHEDULE
            </button>
          </div>
        </div>
      }

    </div>
  `,
})
export class ProgrammeGuideComponent {
  bs = inject(BroadcastService);

  showAddModal = signal(false);
  newTitle = '';
  newStart = '18:00';

  submitAdd() {
    if (this.newTitle) {
      this.bs.addScheduleItem('prog-1', this.newTitle, this.newStart);
      this.showAddModal.set(false);
      this.newTitle = '';
    }
  }
}
