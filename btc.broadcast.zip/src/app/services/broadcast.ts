import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  BroadcastState,
  MediaItem,
  Programme,
  ScheduleItem,
  ClipItem,
  ChatMessage,
  BitcoinTip,
  MediaSource,
  Scene,
  LowerThirdGraphic,
} from '../models/broadcast.models';

@Injectable({
  providedIn: 'root',
})
export class BroadcastService {
  private http = inject(HttpClient);

  // Central Station Signals
  readonly state = signal<BroadcastState>({
    status: 'ON_AIR',
    mode: 'HYBRID',
    currentProgrammeTitle: 'The Architecture of Being',
    currentEpisodeTitle: 'Episode 04 — Time as the Missing Dimension',
    currentSceneId: 'scene-talking-head',
    previewSceneId: 'scene-screencast',
    durationSeconds: 5077,
    uptimeSeconds: 16279,
    viewerCount: 1284,
    peakViewers: 2150,
    bitrateMbps: 7.8,
    fps: 59.94,
    audioLevelLufs: -14.2,
    audioPeakDb: -1.5,
    health: 'HEALTHY',
    encoderLoadPercent: 24,
    cpuLoadPercent: 18,
    gpuLoadPercent: 31,
    droppedFrames: 0,
    networkLatencyMs: 18,
    destinations: [],
    recording: true,
    recordingDurationSeconds: 5077,
    archiveId: 'arch-2026-09-10-01',
    distributionMode: 'DISTRIBUTED',
    autopilotActive: true,
    activeLowerThird: {
      id: 'lt-1',
      title: 'BTCPhilosopher',
      subtitle: 'Station Director & Architect',
      style: 'STANDARD_DARK',
      isVisible: true,
    },
    activeTickerText: '● ON AIR: The Architecture of Being | Next: Philology Revolution @ 10:00 UTC',
  });

  readonly mediaList = signal<MediaItem[]>([]);
  readonly programmesList = signal<Programme[]>([]);
  readonly scheduleList = signal<ScheduleItem[]>([]);
  readonly archiveList = signal<ClipItem[]>([]);
  readonly chatMessages = signal<ChatMessage[]>([]);
  readonly bitcoinTips = signal<BitcoinTip[]>([]);

  // WebRTC / Live Media Sources
  readonly liveSources = signal<MediaSource[]>([
    {
      id: 'cam-1',
      type: 'WEBCAM',
      name: 'Studio Camera 1 (Webcam)',
      format: 'YUV420p',
      resolution: '1920x1080',
      fps: 60,
      sampleRate: 48000,
      channels: 2,
      codec: 'H.264 / WebRTC',
      latencyMs: 12,
      status: 'ACTIVE',
      health: 'HEALTHY',
      volume: 1.0,
      isMuted: false,
      isSolo: false,
    },
    {
      id: 'mic-1',
      type: 'MICROPHONE',
      name: 'Broadcaster Master Mic',
      format: 'PCM 24-bit',
      resolution: 'Audio Only',
      fps: 0,
      sampleRate: 48000,
      channels: 1,
      codec: 'Opus 320kbps',
      latencyMs: 8,
      status: 'ACTIVE',
      health: 'HEALTHY',
      volume: 0.9,
      isMuted: false,
      isSolo: false,
    },
    {
      id: 'scr-1',
      type: 'SCREEN',
      name: 'Desktop Capture',
      format: 'RGB24',
      resolution: '2560x1440',
      fps: 60,
      sampleRate: 48000,
      channels: 2,
      codec: 'VP9',
      latencyMs: 15,
      status: 'STANDBY',
      health: 'HEALTHY',
      volume: 0.5,
      isMuted: false,
      isSolo: false,
    },
  ]);

  readonly scenes = signal<Scene[]>([
    {
      id: 'scene-talking-head',
      name: 'Talking Head',
      description: 'Camera 1 + Lower Third + Logo Overlay',
      isCutReady: true,
      activeLowerThirdId: 'lt-1',
      sources: [
        { sourceId: 'cam-1', layer: 1, x: 0, y: 0, width: 100, height: 100, opacity: 1 },
      ],
    },
    {
      id: 'scene-screencast',
      name: 'Screencast + PiP',
      description: 'Desktop Screen + Camera PiP in corner',
      isCutReady: true,
      sources: [
        { sourceId: 'scr-1', layer: 1, x: 0, y: 0, width: 100, height: 100, opacity: 1 },
        { sourceId: 'cam-1', layer: 2, x: 70, y: 65, width: 28, height: 32, opacity: 1, pip: true },
      ],
    },
    {
      id: 'scene-fullscreen-video',
      name: 'Fullscreen Video',
      description: 'Media Library Video playback with bug overlay',
      isCutReady: true,
      sources: [
        { sourceId: 'med-101', layer: 1, x: 0, y: 0, width: 100, height: 100, opacity: 1 },
      ],
    },
    {
      id: 'scene-radio-mode',
      name: 'Radio Broadcast',
      description: 'Audio spectrum visualizer & studio mic',
      isCutReady: true,
      sources: [
        { sourceId: 'mic-1', layer: 1, x: 0, y: 0, width: 100, height: 100, opacity: 1 },
      ],
    },
  ]);

  // Active scene helper
  readonly currentScene = computed(() => {
    const activeId = this.state().currentSceneId;
    return this.scenes().find(s => s.id === activeId) || this.scenes()[0];
  });

  // Active lower third helper
  readonly activeLowerThird = computed(() => {
    return this.state().activeLowerThird;
  });

  constructor() {
    this.refreshAll();
    setInterval(() => this.pollState(), 2500);
  }

  async pollState() {
    try {
      const res = await firstValueFrom(this.http.get<{ success: boolean; state: BroadcastState }>('/api/state'));
      if (res.success && res.state) {
        this.state.set(res.state);
      }
    } catch {
      // Station operates in offline mode when server unavailable
    }
  }

  async refreshAll() {
    try {
      const [st, med, prog, sch, arch, msg, tip] = await Promise.all([
        firstValueFrom(this.http.get<{ success: boolean; state: BroadcastState }>('/api/state')),
        firstValueFrom(this.http.get<{ success: boolean; media: MediaItem[] }>('/api/media')),
        firstValueFrom(this.http.get<{ success: boolean; programmes: Programme[] }>('/api/programmes')),
        firstValueFrom(this.http.get<{ success: boolean; schedule: ScheduleItem[] }>('/api/schedule')),
        firstValueFrom(this.http.get<{ success: boolean; archive: ClipItem[] }>('/api/archive')),
        firstValueFrom(this.http.get<{ success: boolean; messages: ChatMessage[] }>('/api/chat')),
        firstValueFrom(this.http.get<{ success: boolean; tips: BitcoinTip[] }>('/api/payments/tips')),
      ]);

      if (st.success) this.state.set(st.state);
      if (med.success) this.mediaList.set(med.media);
      if (prog.success) this.programmesList.set(prog.programmes);
      if (sch.success) this.scheduleList.set(sch.schedule);
      if (arch.success) this.archiveList.set(arch.archive);
      if (msg.success) this.chatMessages.set(msg.messages);
      if (tip.success) this.bitcoinTips.set(tip.tips);
    } catch {
      console.warn('Operating in studio fallback mode.');
    }
  }

  async toggleOnAir() {
    const nextStatus = this.state().status === 'ON_AIR' ? 'OFF_AIR' : 'ON_AIR';
    this.state.update(s => ({ ...s, status: nextStatus }));
    await firstValueFrom(this.http.post('/api/state/update', { status: nextStatus }));
  }

  async switchScene(sceneId: string) {
    this.state.update(s => ({ ...s, currentSceneId: sceneId }));
    await firstValueFrom(this.http.post('/api/state/update', { currentSceneId: sceneId }));
  }

  async setPreviewScene(sceneId: string) {
    this.state.update(s => ({ ...s, previewSceneId: sceneId }));
    await firstValueFrom(this.http.post('/api/state/update', { previewSceneId: sceneId }));
  }

  async performTransition(transitionType: 'CUT' | 'FADE' | 'DISSOLVE' | 'WIPE' | 'SLIDE') {
    const preview = this.state().previewSceneId;
    const current = this.state().currentSceneId;
    this.state.update(s => ({
      ...s,
      currentSceneId: preview,
      previewSceneId: current,
    }));
    await firstValueFrom(
      this.http.post('/api/state/update', {
        currentSceneId: preview,
        previewSceneId: current,
        transitionType,
      })
    );
  }

  async toggleRecording() {
    const rec = !this.state().recording;
    this.state.update(s => ({ ...s, recording: rec }));
    await firstValueFrom(this.http.post('/api/state/update', { recording: rec }));
  }

  async toggleAutopilot() {
    const auto = !this.state().autopilotActive;
    this.state.update(s => ({ ...s, autopilotActive: auto }));
    await firstValueFrom(this.http.post('/api/state/update', { autopilotActive: auto }));
  }

  async updateLowerThird(lt: LowerThirdGraphic | null) {
    this.state.update(s => ({ ...s, activeLowerThird: lt }));
    await firstValueFrom(this.http.post('/api/state/update', { activeLowerThird: lt }));
  }

  async sendChatMessage(username: string, text: string) {
    const res = await firstValueFrom(
      this.http.post<{ success: boolean; message: ChatMessage }>('/api/chat', {
        username,
        text,
      })
    );
    if (res.success) {
      this.chatMessages.update(msgs => [...msgs, res.message]);
    }
  }

  async sendTip(sender: string, sats: number, message: string) {
    const res = await firstValueFrom(
      this.http.post<{ success: boolean; tip: BitcoinTip }>('/api/payments/tip', {
        sender,
        sats,
        message,
      })
    );
    if (res.success) {
      this.bitcoinTips.update(tips => [res.tip, ...tips]);
    }
  }

  async createClip(title: string, description: string, startTime: string, endTime: string) {
    const res = await firstValueFrom(
      this.http.post<{ success: boolean; clip: ClipItem }>('/api/archive/clip', {
        clipTitle: title,
        description,
        startTimeFormatted: startTime,
        endTimeFormatted: endTime,
        durationSeconds: 120,
      })
    );
    if (res.success) {
      this.archiveList.update(list => [res.clip, ...list]);
    }
  }

  async addScheduleItem(programmeId: string, episodeTitle: string, startTime: string) {
    const res = await firstValueFrom(
      this.http.post<{ success: boolean; scheduleItem: ScheduleItem }>('/api/schedule', {
        programmeId,
        episodeTitle,
        startTime,
        durationMinutes: 120,
        type: 'LIVE',
      })
    );
    if (res.success) {
      this.scheduleList.update(list => [...list, res.scheduleItem]);
    }
  }

  async sendAiDirectorPrompt(prompt: string) {
    return await firstValueFrom(
      this.http.post<{ success: boolean; result: Record<string, unknown> }>('/api/ai/director', { prompt })
    );
  }

  async queryAiArchivist(query: string) {
    return await firstValueFrom(
      this.http.post<{ success: boolean; answer: string; results: ClipItem[] }>('/api/ai/archivist', { query })
    );
  }

  formatTime(seconds: number): string {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
}
