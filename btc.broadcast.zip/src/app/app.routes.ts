import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'control-room', pathMatch: 'full' },
  {
    path: 'control-room',
    loadComponent: () =>
      import('./components/control-room/control-room').then(
        (m) => m.ControlRoomComponent
      ),
  },
  {
    path: 'studio',
    loadComponent: () =>
      import('./components/studio/studio').then((m) => m.StudioComponent),
  },
  {
    path: 'media-library',
    loadComponent: () =>
      import('./components/media-library/media-library').then(
        (m) => m.MediaLibraryComponent
      ),
  },
  {
    path: 'programme-guide',
    loadComponent: () =>
      import('./components/programme-guide/programme-guide').then(
        (m) => m.ProgrammeGuideComponent
      ),
  },
  {
    path: 'channel-page',
    loadComponent: () =>
      import('./components/channel-page/channel-page').then(
        (m) => m.ChannelPageComponent
      ),
  },
  {
    path: 'radio-studio',
    loadComponent: () =>
      import('./components/radio-studio/radio-studio').then(
        (m) => m.RadioStudioComponent
      ),
  },
  {
    path: 'archive-view',
    loadComponent: () =>
      import('./components/archive-view/archive-view').then(
        (m) => m.ArchiveViewComponent
      ),
  },
  {
    path: 'digital-twin',
    loadComponent: () =>
      import('./components/digital-twin/digital-twin').then(
        (m) => m.DigitalTwinComponent
      ),
  },
  {
    path: 'ai-director-panel',
    loadComponent: () =>
      import('./components/ai-director-panel/ai-director-panel').then(
        (m) => m.AiDirectorPanelComponent
      ),
  },
  {
    path: 'analytics-panel',
    loadComponent: () =>
      import('./components/analytics-panel/analytics-panel').then(
        (m) => m.AnalyticsPanelComponent
      ),
  },
  {
    path: 'bitcoin-accounting',
    loadComponent: () =>
      import('./components/bitcoin-accounting/bitcoin-accounting').then(
        (m) => m.BitcoinAccountingComponent
      ),
  },
  {
    path: 'settings',
    loadComponent: () =>
      import('./components/settings/settings').then(
        (m) => m.SettingsComponent
      ),
  },
  { path: '**', redirectTo: 'control-room' },
];
