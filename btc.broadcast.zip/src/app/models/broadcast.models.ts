export type BroadcastStatus = 'OFF_AIR' | 'PREVIEW' | 'ON_AIR' | 'AUTOPILOT' | 'FALLBACK' | 'RADIO';

export type BroadcastMode = 'LIVE' | 'SCHEDULED' | 'AUTOMATED' | 'PREMIERE' | 'SIMULCAST' | 'RADIO' | 'TV' | 'SCREENCAST' | 'CAMERA' | 'HYBRID';

export type SignalHealth = 'HEALTHY' | 'DEGRADED' | 'WARNING' | 'FAILED';

export type DistributionMode = 'DIRECT' | 'RELAY' | 'DISTRIBUTED';

export type SourceType = 'WEBCAM' | 'MICROPHONE' | 'SCREEN' | 'VIDEO_FILE' | 'AUDIO_FILE' | 'IMAGE' | 'REMOTE_STREAM' | 'BROWSER';

export interface MediaSource {
  id: string;
  type: SourceType;
  name: string;
  format: string;
  resolution: string;
  fps: number;
  sampleRate: number;
  channels: number;
  codec: string;
  latencyMs: number;
  status: 'ACTIVE' | 'STANDBY' | 'ERROR' | 'OFFLINE';
  health: SignalHealth;
  volume: number; // 0 to 1
  isMuted: boolean;
  isSolo: boolean;
  previewUrl?: string;
  streamTrack?: MediaStreamTrack;
}

export interface SceneSourceLayer {
  sourceId: string;
  layer: number; // Z-index
  x: number; // Percent 0-100
  y: number; // Percent 0-100
  width: number; // Percent 0-100
  height: number; // Percent 0-100
  opacity: number; // 0-1
  pip?: boolean;
}

export interface Scene {
  id: string;
  name: string;
  description: string;
  sources: SceneSourceLayer[];
  isCutReady: boolean;
  activeLowerThirdId?: string;
}

export interface LowerThirdGraphic {
  id: string;
  title: string;
  subtitle: string;
  logoUrl?: string;
  style: 'STANDARD_DARK' | 'BRUSHED_METAL' | 'AMBER_ALERT' | 'MINIMAL_WHITE';
  isVisible: boolean;
}

export interface ProgrammeEpisode {
  id: string;
  programmeId: string;
  episodeNumber: number;
  title: string;
  description: string;
  durationSeconds: number;
  mediaId?: string;
  airDate: string;
}

export interface Programme {
  id: string;
  title: string;
  description: string;
  host: string;
  category: string;
  coverImage: string;
  episodes: ProgrammeEpisode[];
  tags: string[];
}

export interface ScheduleItem {
  id: string;
  programmeId: string;
  episodeTitle: string;
  startTime: string; // ISO string or HH:MM
  endTime: string;
  durationMinutes: number;
  status: 'COMPLETED' | 'LIVE' | 'NEXT' | 'SCHEDULED';
  type: BroadcastMode;
  mediaUrl?: string;
}

export interface MediaItem {
  id: string;
  filename: string;
  title: string;
  description: string;
  type: 'VIDEO' | 'AUDIO' | 'IMAGE' | 'GRAPHIC' | 'BROADCAST' | 'CLIP';
  durationSeconds: number;
  codec: string;
  resolution: string;
  fps: number;
  audioFormat: string;
  bitrateMbps: number;
  fileSizeBytes: number;
  createdAt: string;
  tags: string[];
  programmeName?: string;
  archiveStatus: 'ORIGINAL' | 'PROXY' | 'EDITABLE_MASTER' | 'STREAM_VERSION' | 'ARCHIVE_VERSION';
  checksum: string;
  url: string;
  thumbnailUrl: string;
}

export interface StreamDestination {
  id: string;
  name: string;
  protocol: 'RTMP' | 'RTMPS' | 'SRT' | 'HLS' | 'WebRTC';
  url: string;
  status: 'CONNECTED' | 'DISCONNECTED' | 'RECONNECTING' | 'ERROR';
  bitrateMbps: number;
  resolution: string;
  latencyMs: number;
  packetLossPercent: number;
  enabled: boolean;
}

export interface BroadcastState {
  status: BroadcastStatus;
  mode: BroadcastMode;
  currentProgrammeTitle: string;
  currentEpisodeTitle: string;
  currentSceneId: string;
  previewSceneId: string;
  durationSeconds: number;
  uptimeSeconds: number;
  viewerCount: number;
  peakViewers: number;
  bitrateMbps: number;
  fps: number;
  audioLevelLufs: number;
  audioPeakDb: number;
  health: SignalHealth;
  encoderLoadPercent: number;
  cpuLoadPercent: number;
  gpuLoadPercent: number;
  droppedFrames: number;
  networkLatencyMs: number;
  destinations: StreamDestination[];
  recording: boolean;
  recordingDurationSeconds: number;
  archiveId: string | null;
  distributionMode: DistributionMode;
  autopilotActive: boolean;
  activeLowerThird: LowerThirdGraphic | null;
  activeTickerText: string;
}

export interface ClipItem {
  id: string;
  broadcastTitle: string;
  clipTitle: string;
  description: string;
  startTimeFormatted: string; // e.g. "02:14"
  endTimeFormatted: string; // e.g. "07:51"
  durationSeconds: number;
  createdAt: string;
  url: string;
  thumbnailUrl: string;
  tags: string[];
}

export interface ChatMessage {
  id: string;
  username: string;
  text: string;
  timestamp: string;
  role: 'BROADCASTER' | 'MODERATOR' | 'VIEWER';
  isPinned?: boolean;
  badge?: string;
  satsTipped?: number;
}

export interface BitcoinTip {
  id: string;
  sender: string;
  satsAmount: number;
  fiatValueUsd: number;
  message: string;
  paymentHash: string;
  timestamp: string;
  status: 'CONFIRMED' | 'PENDING';
}

export interface AiDirectorCommand {
  userPrompt: string;
  intent: string;
  action: string;
  parameters: Record<string, unknown>;
  explanation: string;
  requiresApproval: boolean;
  executedAt?: string;
}
