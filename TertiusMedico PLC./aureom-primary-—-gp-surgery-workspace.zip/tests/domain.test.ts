import test from 'node:test';
import assert from 'node:assert/strict';
import { DomainError, PracticeService } from '../server/domain.ts';
import type { AuthSession } from '../src/types/clinical.ts';

function staffSession(
  userId: string,
  role: Exclude<AuthSession['role'], 'PATIENT'>,
  name: string
): AuthSession {
  return {
    token: 'test-token',
    userId,
    actorType: 'STAFF',
    role,
    name,
    title: role,
    mfaVerified: true,
    issuedAt: new Date().toISOString(),
  };
}

const reception = staffSession('staff-rec-1', 'RECEPTION', 'Claire Whitaker');
const gpVance = staffSession('staff-gp-1', 'GP', 'Dr Eleanor Vance');
const nurseReid = staffSession('staff-nurse-1', 'NURSE', 'Hannah Reid');
const adminSharma = staffSession('staff-admin-1', 'ADMIN', 'Priya Sharma');

test('1. Booking conflicts: prevents double booking and honours explicit override permission', () => {
  const svc = new PracticeService();

  // apt-101 is at 2026-11-24T09:00 for 15 min with staff-gp-1 in room-1
  assert.throws(
    () =>
      svc.bookAppointment(reception, {
        patientId: 'pat-dorothy',
        clinicianId: 'staff-gp-1',
        roomId: 'room-1',
        appointmentType: 'GP Consultation (15 min)',
        mode: 'FACE_TO_FACE',
        startTime: '2026-11-24T09:05',
        durationMinutes: 15,
        reason: 'Double-booking test',
      }),
    (err: unknown) => err instanceof DomainError && err.code === 'BOOKING_CONFLICT'
  );

  // Reception cannot override even if overrideConflict=true
  assert.throws(
    () =>
      svc.bookAppointment(reception, {
        patientId: 'pat-dorothy',
        clinicianId: 'staff-gp-1',
        roomId: 'room-1',
        appointmentType: 'GP Consultation (15 min)',
        mode: 'FACE_TO_FACE',
        startTime: '2026-11-24T09:05',
        durationMinutes: 15,
        reason: 'Reception override attempt',
        overrideConflict: true,
        overrideReason: 'Caller insisted',
      }),
    (err: unknown) => err instanceof DomainError && err.code === 'BOOKING_CONFLICT'
  );

  // GP can override with documented reason
  const overridden = svc.bookAppointment(gpVance, {
    patientId: 'pat-dorothy',
    clinicianId: 'staff-gp-1',
    roomId: 'room-1',
    appointmentType: 'Duty Urgent Slot',
    mode: 'TELEPHONE',
    startTime: '2026-11-24T09:05',
    durationMinutes: 10,
    reason: 'Post-discharge urgent check',
    overrideConflict: true,
    overrideReason: 'Duty GP clinical priority double-slot',
  });
  assert.equal(overridden.history[0].action, 'BOOKED_WITH_OVERRIDE');
});

test('2. Patient isolation: scopes reception view, restricts sensitive records, and blocks cross-patient draft leaks', () => {
  const svc = new PracticeService();

  // Reception receives zero clinical notes and redacted clinical fields
  const recView = svc.getScopedWorkspace(reception);
  assert.equal(recView.consultations.length, 0);
  assert.equal(recView.results.length, 0);
  assert.equal(recView.patients[0].clinicalRedacted, true);
  assert.equal(recView.patients[0].activeProblems, undefined);

  // Nurse Reid is not usualGpId for restricted patient pat-amir
  const nurseViewBefore = svc.getScopedWorkspace(nurseReid);
  const amirBefore = nurseViewBefore.patients.find((p) => p.id === 'pat-amir');
  assert.equal(amirBefore?.clinicalRedacted, true);
  assert.equal(amirBefore?.requiresEmergencyAccess, true);

  // Break-glass requires >= 10 char clinical reason
  assert.throws(
    () => svc.grantEmergencyAccess(nurseReid, 'pat-amir', 'short'),
    (err: unknown) => err instanceof DomainError && err.code === 'REASON_REQUIRED'
  );

  svc.grantEmergencyAccess(nurseReid, 'pat-amir', 'Acute asthma exacerbation triage review');
  const nurseViewAfter = svc.getScopedWorkspace(nurseReid);
  const amirAfter = nurseViewAfter.patients.find((p) => p.id === 'pat-amir');
  assert.equal(amirAfter?.clinicalRedacted, false);

  // Cross-patient consultation draft save must fail
  assert.throws(
    () =>
      svc.saveConsultationDraft(gpVance, {
        id: 'con-301', // belongs to pat-margaret
        patientId: 'pat-dorothy',
        templateName: 'GP Note',
        presentingConcern: 'Wrong patient',
        historyText: '',
        examinationText: '',
        assessmentText: '',
        planText: '',
      }),
    (err: unknown) => err instanceof DomainError && err.code === 'PATIENT_CONTEXT_MISMATCH'
  );
});

test('3. Proxy permissions: rejects access based only on shared address/emergency contact and enforces scope/revocation', () => {
  const svc = new PracticeService();
  const state = svc.getRawState();

  // Emergency contact with shared address & demographic knowledge has NO record access
  const sanaProxy = state.proxyRelationships.find((p) => p.id === 'proxy-2')!;
  const sanaEval = svc.evaluateProxyAccess(sanaProxy, 'APPOINTMENTS');
  assert.equal(sanaEval.allowed, false);

  // Attempting to create a proxy with record access while unverified is rejected
  assert.throws(
    () =>
      svc.createProxyRelationship(reception, {
        patientId: 'pat-amir',
        relatedPersonName: 'Unverified Household Member',
        relationshipType: 'HOUSEHOLD_MEMBER',
        sharedAddress: true,
        isEmergencyContact: true,
        knowsDemographics: true,
        hasRecordAccess: true,
        accessScope: ['SUMMARY'],
        effectiveFrom: '2026-11-24',
        verificationStatus: 'UNVERIFIED',
      }),
    (err: unknown) => err instanceof DomainError && err.code === 'PROXY_POLICY_VIOLATION'
  );

  // Verified parental proxy for Oliver works within scope, fails outside scope, and fails once revoked
  const oliverProxy = state.proxyRelationships.find((p) => p.id === 'proxy-1')!;
  assert.equal(svc.evaluateProxyAccess(oliverProxy, 'APPOINTMENTS').allowed, true);
  assert.equal(svc.evaluateProxyAccess(oliverProxy, 'SUMMARY').allowed, false);

  svc.revokeProxyRelationship(gpVance, 'proxy-1', 'Parental access temporarily suspended pending review');
  assert.equal(svc.evaluateProxyAccess(oliverProxy, 'APPOINTMENTS').allowed, false);
});

test('4. Immutable signed notes & optimistic concurrency: blocks direct edit, allows linked amendment and entered-in-error', () => {
  const svc = new PracticeService();

  // con-300 is already SIGNED
  assert.throws(
    () =>
      svc.saveConsultationDraft(gpVance, {
        id: 'con-300',
        patientId: 'pat-margaret',
        templateName: 'GP Note',
        presentingConcern: 'Attempted silent overwrite',
        historyText: '',
        examinationText: '',
        assessmentText: '',
        planText: '',
      }),
    (err: unknown) => err instanceof DomainError && err.code === 'IMMUTABLE_SIGNED_NOTE'
  );

  // Linked amendment succeeds without erasing original note
  const amended = svc.addConsultationAmendment(
    gpVance,
    'con-300',
    'Clarifying home BP cuff calibration',
    'Patient confirmed validated upper-arm Omron monitor used.'
  );
  assert.equal(amended.status, 'AMENDED');
  assert.equal(amended.amendments.length, 1);

  // Entered-in-error retains original content and marks status
  const eie = svc.markNoteEnteredInError(gpVance, 'con-300', 'Duplicate annual review entry');
  assert.equal(eie.status, 'ENTERED_IN_ERROR');
  assert.ok(eie.presentingConcern.includes('Annual hypertension'));
});

test('5. Corrected results: viewing does not action, corrected report links to prior version and routes to cover', () => {
  const svc = new PracticeService();

  const viewed = svc.viewLabResult(gpVance, 'res-502');
  assert.ok(viewed.viewedAt);
  assert.equal(viewed.actioned, false);

  // Ingest corrected result for res-503 (assigned to staff-gp-2 who is covered by staff-gp-1)
  const corrected = svc.ingestCorrectedResult(
    adminSharma,
    'res-503',
    'K+ 5.7 / CrCl 52',
    'Haemolysed specimen corrected on repeat assay'
  );
  assert.equal(corrected.previousVersionId, 'res-503');
  assert.equal(corrected.status, 'CORRECTED');
  assert.equal(corrected.assignedReviewerId, 'staff-gp-1');
  assert.equal(corrected.actioned, false);
});

test('6. Task reassignment & cover staff routing', () => {
  const svc = new PracticeService();

  // Creating a task for Dr Mahmood (who has coverStaffId = staff-gp-1) routes to Dr Vance
  const task = svc.createOrUpdateTask(reception, {
    title: 'Call patient regarding discharge summary',
    patientId: 'pat-dorothy',
    ownerId: 'staff-gp-2',
    priority: 'HIGH',
  });
  assert.equal(task.ownerId, 'staff-gp-1');
  assert.equal(task.originalOwnerId, 'staff-gp-2');
  assert.equal(task.coveredById, 'staff-gp-1');

  // Reassigning explicitly to Nurse Reid
  const reassigned = svc.createOrUpdateTask(gpVance, {
    taskId: task.id,
    ownerId: 'staff-nurse-1',
  });
  assert.equal(reassigned.ownerId, 'staff-nurse-1');
});

test('7. Offline / concurrent note edit conflict detection', () => {
  const svc = new PracticeService();

  // con-301 starts at version 2; clinician A saves v3
  const savedA = svc.saveConsultationDraft(gpVance, {
    id: 'con-301',
    patientId: 'pat-margaret',
    expectedVersion: 2,
    templateName: 'GP Chronic Disease & Acute Review',
    presentingConcern: 'Updated concern by clinician A',
    historyText: 'Updated',
    examinationText: 'BP 136/80',
    assessmentText: 'T2DM',
    planText: 'Repeat U&Es',
  });
  assert.equal(savedA.version, 3);

  // Offline/concurrent client B tries to save with stale expectedVersion 2
  assert.throws(
    () =>
      svc.saveConsultationDraft(nurseReid, {
        id: 'con-301',
        patientId: 'pat-margaret',
        expectedVersion: 2,
        templateName: 'GP Chronic Disease & Acute Review',
        presentingConcern: 'Offline edit from tablet',
        historyText: 'Offline',
        examinationText: 'BP 136/80',
        assessmentText: 'T2DM',
        planText: 'Check feet',
      }),
    (err: unknown) => err instanceof DomainError && err.code === 'VERSION_CONFLICT'
  );
});

test('8. Duplicate integration callbacks & EPS idempotency deduplication', () => {
  const svc = new PracticeService();

  // Approve rx-401 then transmit twice with same idempotency key
  svc.reviewPrescription(gpVance, 'rx-401', 'APPROVED', 'Approved 28-day supply');
  const first = svc.submitPrescriptionToEps(gpVance, 'rx-401', 'idem-rx-401-try1', false);
  const second = svc.submitPrescriptionToEps(gpVance, 'rx-401', 'idem-rx-401-try1', false);
  assert.equal(first.status, 'CONFIRMED');
  assert.equal(second.epsMessageId, first.epsMessageId);

  // Integration callback deduplication
  const cb1 = svc.handleIntegrationCallback(
    'cb-key-99',
    'EPS_SIM',
    'rx-401',
    'CONFIRMED',
    'Dispensed by Calder Valley Pharmacy'
  );
  const cb2 = svc.handleIntegrationCallback(
    'cb-key-99',
    'EPS_SIM',
    'rx-401',
    'FAILED',
    'Duplicate stale callback'
  );
  assert.equal(cb1.deduplicated, false);
  assert.equal(cb2.deduplicated, true);
  assert.equal(cb2.status, 'CONFIRMED');
});
