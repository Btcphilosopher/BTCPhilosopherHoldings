import crypto from 'node:crypto';
import type {
  Appointment,
  AppointmentMode,
  AppointmentStatus,
  AuditEvent,
  AuthSession,
  CareRecall,
  ConsultationNote,
  DuplicateCandidate,
  IncomingDocument,
  IncomingRequest,
  LabResult,
  Patient,
  PatientPortalSubmission,
  PracticeConfig,
  PracticeState,
  PracticeTask,
  PrescriptionRequest,
  ProxyRelationship,
  Referral,
  StaffAssignedPriority,
  StaffMember,
  StaffRole,
} from '../src/types/clinical.ts';
import { createInitialPracticeState } from './seed.ts';

export class DomainError extends Error {
  status: number;
  code: string;
  details?: Record<string, unknown>;

  constructor(
    status: number,
    code: string,
    message: string,
    details?: Record<string, unknown>
  ) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export interface ScopedWorkspacePayload {
  practice: PracticeConfig;
  viewer: {
    userId: string;
    actorType: 'STAFF' | 'PATIENT';
    role: StaffRole | 'PATIENT';
    name: string;
    title: string;
    mfaVerified: boolean;
    patientId?: string;
  };
  staff: StaffMember[];
  rooms: PracticeState['rooms'];
  recurringClinics: PracticeState['recurringClinics'];
  patients: Array<Record<string, unknown>>;
  proxyRelationships: ProxyRelationship[];
  duplicateCandidates: DuplicateCandidate[];
  appointments: Appointment[];
  waitingList: PracticeState['waitingList'];
  requests: IncomingRequest[];
  consultations: ConsultationNote[];
  prescriptions: PrescriptionRequest[];
  results: LabResult[];
  referrals: Referral[];
  documents: IncomingDocument[];
  tasks: PracticeTask[];
  recalls: CareRecall[];
  rotas: PracticeState['rotas'];
  consumables: PracticeState['consumables'];
  equipment: PracticeState['equipment'];
  auditEvents: AuditEvent[];
  integrationEvents: PracticeState['integrationEvents'];
  patientMessages: PracticeState['patientMessages'];
  patientSubmissions: PatientPortalSubmission[];
  operationalMetrics: ReturnType<PracticeService['computeOperationalMetrics']>;
}

function parseMinutes(isoDateTime: string): number {
  const ms = Date.parse(isoDateTime);
  if (Number.isNaN(ms)) {
    throw new DomainError(400, 'INVALID_DATETIME', `Invalid datetime: ${isoDateTime}`);
  }
  return Math.floor(ms / 60000);
}

function addMinutesIso(isoStart: string, durationMinutes: number): string {
  const ms = Date.parse(isoStart);
  if (Number.isNaN(ms)) {
    throw new DomainError(400, 'INVALID_DATETIME', `Invalid datetime: ${isoStart}`);
  }
  const end = new Date(ms + durationMinutes * 60000);
  // Keep local-style ISO YYYY-MM-DDTHH:mm if input had no Z
  if (!isoStart.endsWith('Z')) {
    const pad = (n: number) => String(n).padStart(2, '0');
    const localMs = ms + durationMinutes * 60000;
    const d = new Date(localMs);
    return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(
      d.getUTCHours()
    )}:${pad(d.getUTCMinutes())}`;
  }
  return end.toISOString();
}

export class PracticeService {
  private state: PracticeState;
  private onPersist?: (state: PracticeState) => void;

  constructor(initialState?: PracticeState, onPersist?: (state: PracticeState) => void) {
    this.state = initialState ?? createInitialPracticeState();
    this.onPersist = onPersist;
  }

  getRawState(): PracticeState {
    return this.state;
  }

  restoreSnapshot(snapshot: PracticeState, actor: AuthSession): void {
    this.requireRoles(actor, ['ADMIN']);
    if (!snapshot || !Array.isArray(snapshot.patients) || !Array.isArray(snapshot.staff)) {
      throw new DomainError(400, 'INVALID_BACKUP', 'Backup snapshot payload is malformed.');
    }
    this.state = structuredClone(snapshot);
    this.audit(actor, 'BACKUP_RESTORED', 'PracticeState', this.state.config.odsCode, undefined, 'ALLOWED', 'Practice database snapshot and attachment manifest restored by administrator.');
    this.persist();
  }

  resetDemoData(actor: AuthSession): void {
    this.requireRoles(actor, ['ADMIN', 'PRACTICE_MANAGER', 'GP', 'RECEPTION']);
    this.state = createInitialPracticeState();
    this.audit(actor, 'DEMO_RESET', 'PracticeState', this.state.config.odsCode, undefined, 'ALLOWED', 'Synthetic Pennine Medical Practice dataset reset.');
    this.persist();
  }

  private persist() {
    if (this.onPersist) {
      this.onPersist(this.state);
    }
  }

  private audit(
    actor: Pick<AuthSession, 'userId' | 'name' | 'role'>,
    action: string,
    entityType: string,
    entityId: string,
    patientId: string | undefined,
    outcome: AuditEvent['outcome'],
    summary: string
  ) {
    // Keep clinical free-text out of ordinary audit summaries
    const event: AuditEvent = {
      id: `aud-${crypto.randomUUID().slice(0, 8)}`,
      timestamp: new Date().toISOString(),
      actorId: actor.userId,
      actorName: actor.name,
      actorRole: actor.role,
      action,
      entityType,
      entityId,
      patientId,
      outcome,
      summary,
    };
    this.state.auditEvents.unshift(event);
    if (this.state.auditEvents.length > 500) {
      this.state.auditEvents.length = 500;
    }
  }

  private requireRoles(actor: AuthSession, allowed: Array<StaffRole | 'PATIENT'>) {
    if (!allowed.includes(actor.role)) {
      this.audit(
        actor,
        'ACCESS_DENIED',
        'Endpoint',
        allowed.join(','),
        undefined,
        'DENIED',
        `Role ${actor.role} denied access to protected action.`
      );
      this.persist();
      throw new DomainError(
        403,
        'FORBIDDEN_ROLE',
        `Role ${actor.role} is not authorised for this action.`
      );
    }
  }

  private hasActiveEmergencyAccess(patientId: string, staffId: string, nowIso = new Date().toISOString()): boolean {
    const grants = this.state.emergencyAccessGrants[patientId] ?? [];
    return grants.some((g) => g.staffId === staffId && g.expiresAt > nowIso);
  }

  canAccessRestrictedClinicalRecord(actor: AuthSession, patient: Patient): boolean {
    if (actor.actorType !== 'STAFF') return false;
    if (actor.role !== 'GP' && actor.role !== 'NURSE') return false;
    if (!patient.restrictedRecord) return true;
    if (patient.usualGpId === actor.userId) return true;
    return this.hasActiveEmergencyAccess(patient.id, actor.userId);
  }

  evaluateProxyAccess(
    proxy: ProxyRelationship,
    requestedScope: ProxyRelationship['accessScope'][number],
    asOfDate = '2026-11-24'
  ): { allowed: boolean; reason: string } {
    if (proxy.revokedAt) {
      return { allowed: false, reason: `Proxy access revoked (${proxy.revocationReason ?? 'no reason'})` };
    }
    if (proxy.verificationStatus !== 'VERIFIED') {
      return { allowed: false, reason: `Relationship verification status is ${proxy.verificationStatus}` };
    }
    if (!proxy.hasRecordAccess || proxy.accessScope.length === 0) {
      return {
        allowed: false,
        reason:
          'Shared address, emergency contact, or demographic knowledge does not grant record access.',
      };
    }
    if (asOfDate < proxy.effectiveFrom) {
      return { allowed: false, reason: 'Proxy effective start date is in the future.' };
    }
    if (proxy.effectiveTo && asOfDate > proxy.effectiveTo) {
      return { allowed: false, reason: 'Proxy effective period has expired.' };
    }
    if (!proxy.accessScope.includes(requestedScope)) {
      return { allowed: false, reason: `Proxy scope does not permit ${requestedScope}.` };
    }
    return { allowed: true, reason: 'Verified active proxy within explicit scope.' };
  }

  getScopedWorkspace(actor: AuthSession): ScopedWorkspacePayload {
    if (actor.actorType === 'PATIENT') {
      const patient = this.state.patients.find((p) => p.id === actor.patientId);
      if (!patient) {
        throw new DomainError(404, 'PATIENT_NOT_FOUND', 'Patient portal account not found.');
      }
      return {
        practice: this.state.config,
        viewer: {
          userId: actor.userId,
          actorType: 'PATIENT',
          role: 'PATIENT',
          name: actor.name,
          title: 'Patient Portal (Demonstration)',
          mfaVerified: actor.mfaVerified,
          patientId: patient.id,
        },
        staff: this.state.staff.map((s) => ({
          id: s.id,
          name: s.name,
          role: s.role,
          title: s.title,
          email: '',
          mfaEnrolled: true,
          active: s.active,
          sessionVersion: 1,
        })),
        rooms: this.state.rooms,
        recurringClinics: [],
        patients: [
          {
            id: patient.id,
            fullName: patient.fullName,
            preferredName: patient.preferredName,
            dateOfBirth: patient.dateOfBirth,
            nhsNumber: patient.nhsNumber,
            nhsVerificationStatus: patient.nhsVerificationStatus,
            address: patient.address,
            phone: patient.phone,
            email: patient.email,
            preferredContactMethod: patient.preferredContactMethod,
            medications: patient.medications,
            notificationPreferences: patient.notificationPreferences,
          },
        ],
        proxyRelationships: this.state.proxyRelationships.filter((pr) => pr.patientId === patient.id),
        duplicateCandidates: [],
        appointments: this.state.appointments.filter((a) => a.patientId === patient.id),
        waitingList: [],
        requests: [],
        consultations: [],
        prescriptions: this.state.prescriptions.filter((rx) => rx.patientId === patient.id),
        results: [],
        referrals: [],
        documents: this.state.documents.filter(
          (d) =>
            d.matchedPatientId === patient.id &&
            d.patientMatchConfirmed &&
            d.releasedToPatient === true
        ),
        tasks: [],
        recalls: this.state.recalls.filter((r) => r.patientId === patient.id),
        rotas: [],
        consumables: [],
        equipment: [],
        auditEvents: [],
        integrationEvents: [],
        patientMessages: this.state.patientMessages.filter((m) => m.patientId === patient.id),
        patientSubmissions: this.state.patientSubmissions.filter((s) => s.patientId === patient.id),
        operationalMetrics: this.computeOperationalMetrics(),
      };
    }

    const isClinician = actor.role === 'GP' || actor.role === 'NURSE';
    const isReception = actor.role === 'RECEPTION';
    const isAdmin = actor.role === 'ADMIN';
    const isPm = actor.role === 'PRACTICE_MANAGER';

    const scopedPatients = this.state.patients.map((p) => {
      if (isReception || isPm || isAdmin) {
        // Reception & operations receive demographic, registration & appointment-relevant views, never clinical details
        return {
          id: p.id,
          fullName: p.fullName,
          preferredName: p.preferredName,
          dateOfBirth: p.dateOfBirth,
          sex: p.sex,
          nhsNumber: p.nhsNumber,
          nhsVerificationStatus: p.nhsVerificationStatus,
          identifiers: p.identifiers,
          address: p.address,
          phone: p.phone,
          email: p.email,
          preferredContactMethod: p.preferredContactMethod,
          enrolmentStatus: p.enrolmentStatus,
          registeredPracticeOds: p.registeredPracticeOds,
          usualGpId: p.usualGpId,
          restrictedRecord: p.restrictedRecord,
          restrictionReason: p.restrictedRecord ? 'Restricted sensitive record (clinical details hidden)' : undefined,
          notificationPreferences: p.notificationPreferences,
          clinicalRedacted: true,
        };
      }
      // Clinician view: check restricted record policy
      if (!this.canAccessRestrictedClinicalRecord(actor, p)) {
        return {
          id: p.id,
          fullName: p.fullName,
          preferredName: p.preferredName,
          dateOfBirth: p.dateOfBirth,
          sex: p.sex,
          nhsNumber: p.nhsNumber,
          nhsVerificationStatus: p.nhsVerificationStatus,
          identifiers: p.identifiers,
          address: p.address,
          phone: p.phone,
          email: p.email,
          preferredContactMethod: p.preferredContactMethod,
          enrolmentStatus: p.enrolmentStatus,
          registeredPracticeOds: p.registeredPracticeOds,
          usualGpId: p.usualGpId,
          restrictedRecord: true,
          restrictionReason: p.restrictionReason,
          clinicalRedacted: true,
          requiresEmergencyAccess: true,
        };
      }
      return { ...p, clinicalRedacted: false };
    });

    const visiblePatientIdsForClinical = new Set(
      scopedPatients.filter((p) => !p.clinicalRedacted).map((p) => p.id as string)
    );

    return {
      practice: this.state.config,
      viewer: {
        userId: actor.userId,
        actorType: 'STAFF',
        role: actor.role,
        name: actor.name,
        title: actor.title,
        mfaVerified: actor.mfaVerified,
      },
      staff: this.state.staff,
      rooms: this.state.rooms,
      recurringClinics: this.state.recurringClinics,
      patients: scopedPatients,
      proxyRelationships: this.state.proxyRelationships,
      duplicateCandidates: this.state.duplicateCandidates,
      appointments: this.state.appointments,
      waitingList: this.state.waitingList,
      requests: this.state.requests.map((r) =>
        isReception && r.patientId && this.state.patients.find((p) => p.id === r.patientId)?.restrictedRecord
          ? { ...r, attachments: [] }
          : r
      ),
      consultations: isClinician
        ? this.state.consultations.filter((c) => visiblePatientIdsForClinical.has(c.patientId))
        : [],
      prescriptions: isClinician || isReception
        ? this.state.prescriptions
        : [],
      results: isClinician
        ? this.state.results.filter((res) => visiblePatientIdsForClinical.has(res.patientId))
        : [],
      referrals: isClinician
        ? this.state.referrals.filter((ref) => visiblePatientIdsForClinical.has(ref.patientId))
        : [],
      documents: isClinician
        ? this.state.documents.filter(
            (d) => !d.matchedPatientId || visiblePatientIdsForClinical.has(d.matchedPatientId)
          )
        : isReception
          ? this.state.documents.map((d) => ({
              ...d,
              documentBody: d.patientMatchConfirmed
                ? '[Clinical body restricted to clinicians]'
                : '[Awaiting demographic match confirmation]',
            }))
          : [],
      tasks: this.state.tasks,
      recalls: isClinician || isReception || isPm ? this.state.recalls : [],
      rotas: this.state.rotas,
      consumables: this.state.consumables,
      equipment: this.state.equipment,
      auditEvents: isAdmin || isPm || actor.role === 'GP' ? this.state.auditEvents : [],
      integrationEvents: isAdmin ? this.state.integrationEvents : [],
      patientMessages: isClinician || isReception ? this.state.patientMessages : [],
      patientSubmissions: this.state.patientSubmissions,
      operationalMetrics: this.computeOperationalMetrics(),
    };
  }

  // --- Emergency Break-Glass Access ---
  grantEmergencyAccess(actor: AuthSession, patientId: string, reason: string): void {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const patient = this.state.patients.find((p) => p.id === patientId);
    if (!patient) throw new DomainError(404, 'PATIENT_NOT_FOUND', 'Patient not found.');
    if (!reason || reason.trim().length < 10) {
      throw new DomainError(
        400,
        'REASON_REQUIRED',
        'A documented clinical reason (minimum 10 characters) is mandatory for emergency break-glass access.'
      );
    }
    const now = new Date();
    const expires = new Date(now.getTime() + 2 * 60 * 60 * 1000);
    if (!this.state.emergencyAccessGrants[patientId]) {
      this.state.emergencyAccessGrants[patientId] = [];
    }
    this.state.emergencyAccessGrants[patientId].push({
      staffId: actor.userId,
      reason: reason.trim(),
      grantedAt: now.toISOString(),
      expiresAt: expires.toISOString(),
    });
    this.audit(
      actor,
      'BREAK_GLASS_EMERGENCY_ACCESS',
      'Patient',
      patientId,
      patientId,
      'ALLOWED',
      `Emergency restricted-record access granted for 2 hours. Reason documented for IG review.`
    );
    this.persist();
  }

  // --- Patients, Registration, Duplicate Match, Proxy ---
  registerPatient(
    actor: AuthSession,
    input: {
      fullName: string;
      dateOfBirth: string;
      sex: Patient['sex'];
      nhsNumber: string;
      address: string;
      phone: string;
      email: string;
      preferredContactMethod: Patient['preferredContactMethod'];
    }
  ): { patient: Patient; duplicateWarnings: DuplicateCandidate[] } {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'ADMIN']);
    if (!input.fullName.trim() || !input.dateOfBirth.trim()) {
      throw new DomainError(400, 'INVALID_PATIENT', 'Full name and date of birth are required.');
    }
    const newId = `pat-${crypto.randomUUID().slice(0, 8)}`;
    const patient: Patient = {
      id: newId,
      fullName: input.fullName.trim(),
      dateOfBirth: input.dateOfBirth.trim(),
      sex: input.sex,
      nhsNumber: input.nhsNumber.trim() || 'PENDING-PDS-TRACE',
      nhsVerificationStatus: input.nhsNumber.trim() ? 'PENDING_VERIFICATION' : 'UNVERIFIED',
      identifiers: [
        {
          system: 'LOCAL_PRACTICE_ID',
          value: `PMP-${Math.floor(10000 + Math.random() * 89999)}`,
          issuingAuthority: 'Pennine Medical Practice',
          verificationStatus: 'PENDING_VERIFICATION',
        },
      ],
      address: input.address.trim(),
      phone: input.phone.trim(),
      email: input.email.trim(),
      preferredContactMethod: input.preferredContactMethod,
      enrolmentStatus: 'PENDING_REGISTRATION',
      registeredPracticeOds: this.state.config.odsCode,
      usualGpId: 'staff-gp-1',
      restrictedRecord: false,
      allergiesState: {
        state: 'NOT_ASSESSED',
        detail: 'New registration — allergy assessment pending clinician intake.',
      },
      smokingStatusState: {
        state: 'NOT_ASSESSED',
        detail: 'New registration — smoking status not yet assessed.',
      },
      activeProblems: [],
      medications: [],
      observations: [],
      notificationPreferences: { sms: true, email: true, nhsApp: false, letter: true },
    };

    const duplicateWarnings: DuplicateCandidate[] = [];
    for (const existing of this.state.patients) {
      const matchingFields: string[] = [];
      if (existing.dateOfBirth === patient.dateOfBirth) matchingFields.push('Date of Birth');
      if (existing.phone && existing.phone === patient.phone) matchingFields.push('Phone');
      if (
        existing.fullName.toLowerCase().split(' ').slice(-1)[0] ===
        patient.fullName.toLowerCase().split(' ').slice(-1)[0]
      ) {
        matchingFields.push('Surname');
      }
      if (matchingFields.length >= 2) {
        const dup: DuplicateCandidate = {
          id: `dup-${crypto.randomUUID().slice(0, 8)}`,
          candidatePatientId: patient.id,
          existingPatientId: existing.id,
          matchScore: Math.min(0.98, 0.5 + matchingFields.length * 0.16),
          matchingFields,
          status: 'OPEN',
        };
        duplicateWarnings.push(dup);
        this.state.duplicateCandidates.unshift(dup);
      }
    }

    this.state.patients.push(patient);
    this.audit(
      actor,
      'PATIENT_REGISTERED',
      'Patient',
      patient.id,
      patient.id,
      'ALLOWED',
      `Registration created (${duplicateWarnings.length} duplicate warning(s)).`
    );
    this.persist();
    return { patient, duplicateWarnings };
  }

  resolveDuplicateCandidate(
    actor: AuthSession,
    candidateId: string,
    decision: 'CONFIRMED_SAME_PERSON' | 'CONFIRMED_DISTINCT',
    note: string
  ): DuplicateCandidate {
    this.requireRoles(actor, ['RECEPTION', 'ADMIN', 'GP']);
    const dup = this.state.duplicateCandidates.find((d) => d.id === candidateId);
    if (!dup) throw new DomainError(404, 'DUPLICATE_NOT_FOUND', 'Duplicate candidate not found.');
    dup.status = decision;
    dup.resolvedBy = actor.name;
    dup.resolvedAt = new Date().toISOString();
    dup.resolutionNote = note;
    if (decision === 'CONFIRMED_SAME_PERSON') {
      const candidate = this.state.patients.find((p) => p.id === dup.candidatePatientId);
      if (candidate) {
        candidate.enrolmentStatus = 'TRANSFERRED_OUT';
      }
    }
    this.audit(
      actor,
      'DUPLICATE_MATCH_RESOLVED',
      'DuplicateCandidate',
      dup.id,
      dup.existingPatientId,
      'ALLOWED',
      `Duplicate candidate resolved as ${decision}.`
    );
    this.persist();
    return dup;
  }

  correctPatientIdentity(
    actor: AuthSession,
    patientId: string,
    updates: {
      fullName?: string;
      dateOfBirth?: string;
      nhsNumber?: string;
      nhsVerificationStatus?: Patient['nhsVerificationStatus'];
      enrolmentStatus?: Patient['enrolmentStatus'];
      correctionReason: string;
    }
  ): Patient {
    this.requireRoles(actor, ['RECEPTION', 'ADMIN', 'GP']);
    if (!updates.correctionReason || updates.correctionReason.trim().length < 5) {
      throw new DomainError(400, 'REASON_REQUIRED', 'Identity correction requires a documented reason.');
    }
    const patient = this.state.patients.find((p) => p.id === patientId);
    if (!patient) throw new DomainError(404, 'PATIENT_NOT_FOUND', 'Patient not found.');
    if (updates.fullName) patient.fullName = updates.fullName.trim();
    if (updates.dateOfBirth) patient.dateOfBirth = updates.dateOfBirth.trim();
    if (updates.nhsNumber) patient.nhsNumber = updates.nhsNumber.trim();
    if (updates.nhsVerificationStatus) patient.nhsVerificationStatus = updates.nhsVerificationStatus;
    if (updates.enrolmentStatus) patient.enrolmentStatus = updates.enrolmentStatus;
    this.audit(
      actor,
      'IDENTITY_CORRECTED',
      'Patient',
      patient.id,
      patient.id,
      'ALLOWED',
      `Authorised identity correction recorded.`
    );
    this.persist();
    return patient;
  }

  createProxyRelationship(
    actor: AuthSession,
    input: Omit<ProxyRelationship, 'id'>
  ): ProxyRelationship {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'ADMIN']);
    if (input.hasRecordAccess) {
      if (input.verificationStatus !== 'VERIFIED' || input.accessScope.length === 0) {
        throw new DomainError(
          422,
          'PROXY_POLICY_VIOLATION',
          'Record access cannot be granted solely because of shared address, emergency contact status, or demographic knowledge. Verified authority and explicit scope are required.'
        );
      }
    }
    const proxy: ProxyRelationship = {
      ...input,
      id: `proxy-${crypto.randomUUID().slice(0, 8)}`,
    };
    this.state.proxyRelationships.push(proxy);
    this.audit(
      actor,
      'PROXY_CREATED',
      'ProxyRelationship',
      proxy.id,
      proxy.patientId,
      'ALLOWED',
      `Proxy relationship (${proxy.relationshipType}) added; recordAccess=${proxy.hasRecordAccess}.`
    );
    this.persist();
    return proxy;
  }

  revokeProxyRelationship(actor: AuthSession, proxyId: string, reason: string): ProxyRelationship {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'ADMIN']);
    const proxy = this.state.proxyRelationships.find((p) => p.id === proxyId);
    if (!proxy) throw new DomainError(404, 'PROXY_NOT_FOUND', 'Proxy relationship not found.');
    proxy.hasRecordAccess = false;
    proxy.accessScope = [];
    proxy.revokedAt = new Date().toISOString();
    proxy.revocationReason = reason || 'Revoked by authorised staff';
    this.audit(
      actor,
      'PROXY_REVOKED',
      'ProxyRelationship',
      proxy.id,
      proxy.patientId,
      'ALLOWED',
      'Proxy record access revoked immediately.'
    );
    this.persist();
    return proxy;
  }

  // --- Incoming Requests ---
  createRequest(
    actor: AuthSession,
    input: {
      patientId?: string;
      unmatchedPatientName?: string;
      channel: IncomingRequest['channel'];
      description: string;
      preferredContactMethod: string;
      attachments?: string[];
      urgentGuidanceShown?: boolean;
    }
  ): IncomingRequest {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'ADMIN']);
    if (!input.description.trim()) {
      throw new DomainError(400, 'DESCRIPTION_REQUIRED', 'Patient request description is required.');
    }
    const now = new Date().toISOString();
    const reqItem: IncomingRequest = {
      id: `req-${crypto.randomUUID().slice(0, 8)}`,
      patientId: input.patientId,
      unmatchedPatientName: input.unmatchedPatientName,
      channel: input.channel,
      description: input.description.trim(),
      preferredContactMethod: input.preferredContactMethod || 'TELEPHONE',
      attachments: input.attachments ?? [],
      submittedAt: now,
      receivedStatus: 'RECORDED',
      clinicalReviewStatus: 'NOT_REVIEWED',
      priority: 'UNASSIGNED',
      status: 'RECEIVED',
      urgentGuidanceShown: Boolean(input.urgentGuidanceShown),
      history: [{ timestamp: now, actor: actor.name, action: `Request recorded via ${input.channel}` }],
    };
    this.state.requests.unshift(reqItem);
    this.audit(
      actor,
      'REQUEST_RECORDED',
      'IncomingRequest',
      reqItem.id,
      reqItem.patientId,
      'ALLOWED',
      `Incoming ${reqItem.channel} request recorded; clinical review pending.`
    );
    this.persist();
    return reqItem;
  }

  updateRequestRouting(
    actor: AuthSession,
    requestId: string,
    updates: {
      assignedOwnerId?: string;
      priority?: StaffAssignedPriority;
      status?: IncomingRequest['status'];
      handoverNote?: string;
      escalatedToId?: string;
      markClinicallyReviewed?: boolean;
      linkedAppointmentId?: string;
    }
  ): IncomingRequest {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'PRACTICE_MANAGER', 'ADMIN']);
    const reqItem = this.state.requests.find((r) => r.id === requestId);
    if (!reqItem) throw new DomainError(404, 'REQUEST_NOT_FOUND', 'Request not found.');

    if (updates.markClinicallyReviewed && actor.role !== 'GP' && actor.role !== 'NURSE') {
      throw new DomainError(403, 'CLINICAL_REVIEW_RESTRICTED', 'Only authorised clinicians can mark a request as clinically reviewed.');
    }

    const now = new Date().toISOString();
    if (updates.assignedOwnerId) {
      reqItem.assignedOwnerId = updates.assignedOwnerId;
      if (reqItem.status === 'RECEIVED' || reqItem.status === 'ACKNOWLEDGED') {
        reqItem.status = 'ASSIGNED';
      }
      reqItem.history.push({ timestamp: now, actor: actor.name, action: `Assigned to ${updates.assignedOwnerId}` });
    }
    if (updates.priority) {
      reqItem.priority = updates.priority;
      reqItem.priorityAssignedBy = `${actor.name} (${actor.role})`;
      reqItem.history.push({ timestamp: now, actor: actor.name, action: `Priority set to ${updates.priority}` });
    }
    if (updates.handoverNote !== undefined) reqItem.handoverNote = updates.handoverNote;
    if (updates.escalatedToId) {
      reqItem.escalatedToId = updates.escalatedToId;
      reqItem.status = 'ESCALATED';
      reqItem.history.push({ timestamp: now, actor: actor.name, action: `Escalated to ${updates.escalatedToId}` });
    }
    if (updates.markClinicallyReviewed) {
      reqItem.clinicalReviewStatus = 'REVIEWED';
      reqItem.status = 'CLINICALLY_REVIEWED';
      reqItem.history.push({ timestamp: now, actor: actor.name, action: 'Marked clinically reviewed' });
    }
    if (updates.linkedAppointmentId) {
      reqItem.linkedAppointmentId = updates.linkedAppointmentId;
      reqItem.status = 'ACTIONED';
    }
    if (updates.status) {
      reqItem.status = updates.status;
    }

    this.audit(
      actor,
      'REQUEST_UPDATED',
      'IncomingRequest',
      reqItem.id,
      reqItem.patientId,
      'ALLOWED',
      `Request status=${reqItem.status}, priority=${reqItem.priority}.`
    );
    this.persist();
    return reqItem;
  }

  // --- Appointments & Double-Booking Prevention ---
  bookAppointment(
    actor: AuthSession,
    input: {
      patientId: string;
      clinicianId: string;
      roomId: string;
      appointmentType: string;
      mode: AppointmentMode;
      startTime: string;
      durationMinutes: number;
      reason: string;
      reminderChannel?: Appointment['reminderChannel'];
      overrideConflict?: boolean;
      overrideReason?: string;
      linkedRequestId?: string;
    }
  ): Appointment {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'PRACTICE_MANAGER', 'ADMIN']);
    const startMin = parseMinutes(input.startTime);
    const endTime = addMinutesIso(input.startTime, input.durationMinutes);
    const endMin = startMin + input.durationMinutes;

    const overlapping = this.state.appointments.filter((existing) => {
      if (existing.status === 'CANCELLED' || existing.status === 'DID_NOT_ATTEND') return false;
      const exStart = parseMinutes(existing.startTime);
      const exEnd = parseMinutes(existing.endTime);
      const timeOverlaps = startMin < exEnd && endMin > exStart;
      if (!timeOverlaps) return false;
      return existing.clinicianId === input.clinicianId || existing.roomId === input.roomId;
    });

    if (overlapping.length > 0) {
      const canOverride =
        actor.role === 'GP' || actor.role === 'PRACTICE_MANAGER' || actor.role === 'ADMIN';
      if (!input.overrideConflict || !canOverride || !input.overrideReason?.trim()) {
        this.audit(
          actor,
          'DOUBLE_BOOKING_BLOCKED',
          'Appointment',
          overlapping[0].id,
          input.patientId,
          'CONFLICT',
          `Blocked overlapping booking for clinician ${input.clinicianId} / room ${input.roomId}.`
        );
        this.persist();
        throw new DomainError(
          409,
          'BOOKING_CONFLICT',
          `Slot conflicts with existing appointment (${overlapping[0].startTime}–${overlapping[0].endTime}).`,
          {
            conflictingAppointmentId: overlapping[0].id,
            requiresOverridePermission: true,
          }
        );
      }
    }

    const aptId = `apt-${crypto.randomUUID().slice(0, 8)}`;
    const now = new Date().toISOString();
    const videoRoomUrl =
      input.mode === 'VIDEO'
        ? `https://video-sim.pennine.local/room/${aptId}`
        : undefined;

    const appointment: Appointment = {
      id: aptId,
      patientId: input.patientId,
      clinicianId: input.clinicianId,
      roomId: input.roomId,
      appointmentType: input.appointmentType,
      mode: input.mode,
      startTime: input.startTime,
      durationMinutes: input.durationMinutes,
      endTime,
      status: 'BOOKED',
      reason: input.reason.trim(),
      reminderChannel: input.reminderChannel ?? 'SMS',
      reminderStatus: input.reminderChannel === 'NONE' ? 'OPTED_OUT' : 'SCHEDULED',
      videoRoomUrl,
      noteSignedSeparate: false,
      version: 1,
      history: [
        {
          timestamp: now,
          actor: actor.name,
          action: input.overrideConflict ? 'BOOKED_WITH_OVERRIDE' : 'BOOKED',
          detail: input.overrideConflict
            ? `Double-booking override approved: ${input.overrideReason}`
            : `Booked ${input.mode} appointment`,
        },
      ],
    };

    this.state.appointments.push(appointment);
    if (videoRoomUrl) {
      this.state.integrationEvents.unshift({
        id: `int-${crypto.randomUUID().slice(0, 8)}`,
        adapter: 'VIDEO_SIM',
        eventType: 'VIDEO_ROOM_PROVISIONED',
        idempotencyKey: `vid-${aptId}-v1`,
        status: 'DELIVERED',
        attempts: 1,
        payloadSummary: `Simulated video provider room provisioned for ${aptId}`,
        createdAt: now,
      });
    }
    if (input.linkedRequestId) {
      const reqItem = this.state.requests.find((r) => r.id === input.linkedRequestId);
      if (reqItem) {
        reqItem.linkedAppointmentId = aptId;
        reqItem.status = 'ACTIONED';
        reqItem.history.push({ timestamp: now, actor: actor.name, action: `Booked appointment ${aptId}` });
      }
    }

    this.audit(
      actor,
      input.overrideConflict ? 'APPOINTMENT_BOOKED_OVERRIDE' : 'APPOINTMENT_BOOKED',
      'Appointment',
      aptId,
      input.patientId,
      'ALLOWED',
      `Booked ${input.mode} appointment at ${input.startTime}.`
    );
    this.persist();
    return appointment;
  }

  transitionAppointmentStatus(
    actor: AuthSession,
    appointmentId: string,
    newStatus: AppointmentStatus,
    note?: string
  ): Appointment {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'PRACTICE_MANAGER', 'ADMIN']);
    const apt = this.state.appointments.find((a) => a.id === appointmentId);
    if (!apt) throw new DomainError(404, 'APPOINTMENT_NOT_FOUND', 'Appointment not found.');
    const prevStatus = apt.status;
    apt.status = newStatus;
    apt.version += 1;
    apt.history.push({
      timestamp: new Date().toISOString(),
      actor: actor.name,
      action: newStatus,
      detail: note || `Transitioned ${prevStatus} -> ${newStatus}`,
    });
    this.audit(
      actor,
      `APPOINTMENT_${newStatus}`,
      'Appointment',
      apt.id,
      apt.patientId,
      'ALLOWED',
      `Appointment status changed to ${newStatus} (consultation note signing tracked separately).`
    );
    this.persist();
    return apt;
  }

  // --- Consultations (Optimistic Concurrency, Immutable Signed Notes, Amendments, Entered-in-Error) ---
  saveConsultationDraft(
    actor: AuthSession,
    input: {
      id?: string;
      patientId: string;
      appointmentId?: string;
      expectedVersion?: number;
      templateName: string;
      presentingConcern: string;
      historyText: string;
      examinationText: string;
      assessmentText: string;
      planText: string;
      observationsSnapshot?: string;
    }
  ): ConsultationNote {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const patient = this.state.patients.find((p) => p.id === input.patientId);
    if (!patient) throw new DomainError(404, 'PATIENT_NOT_FOUND', 'Patient not found.');
    if (!this.canAccessRestrictedClinicalRecord(actor, patient)) {
      throw new DomainError(403, 'RESTRICTED_RECORD', 'Break-glass emergency access required for restricted patient.');
    }

    const now = new Date().toISOString();
    if (input.id) {
      const existing = this.state.consultations.find((c) => c.id === input.id);
      if (!existing) throw new DomainError(404, 'NOTE_NOT_FOUND', 'Consultation note not found.');
      // Patient isolation check: prevent draft being reassigned to a different patient!
      if (existing.patientId !== input.patientId) {
        this.audit(
          actor,
          'PATIENT_ISOLATION_VIOLATION_BLOCKED',
          'ConsultationNote',
          existing.id,
          input.patientId,
          'CONFLICT',
          'Blocked attempt to save draft under a different patient context.'
        );
        this.persist();
        throw new DomainError(
          409,
          'PATIENT_CONTEXT_MISMATCH',
          'Draft belongs to a different patient record. Cross-patient draft assignment is strictly blocked.'
        );
      }
      if (existing.status !== 'DRAFT') {
        throw new DomainError(
          409,
          'IMMUTABLE_SIGNED_NOTE',
          `Consultation note is ${existing.status} and cannot be edited directly. Use a linked amendment instead.`
        );
      }
      if (input.expectedVersion !== undefined && existing.version !== input.expectedVersion) {
        this.audit(
          actor,
          'CONCURRENT_NOTE_CONFLICT',
          'ConsultationNote',
          existing.id,
          existing.patientId,
          'CONFLICT',
          `Version mismatch (expected ${input.expectedVersion}, server has ${existing.version}).`
        );
        this.persist();
        throw new DomainError(
          409,
          'VERSION_CONFLICT',
          `Concurrent edit detected: your draft version (${input.expectedVersion}) is behind server version (${existing.version}).`,
          { serverVersion: existing.version, serverDraft: existing }
        );
      }
      existing.templateName = input.templateName;
      existing.presentingConcern = input.presentingConcern;
      existing.historyText = input.historyText;
      existing.examinationText = input.examinationText;
      existing.assessmentText = input.assessmentText;
      existing.planText = input.planText;
      if (input.observationsSnapshot !== undefined) {
        existing.observationsSnapshot = input.observationsSnapshot;
      }
      existing.version += 1;
      existing.autosavedAt = now;
      this.audit(
        actor,
        'CONSULTATION_DRAFT_SAVED',
        'ConsultationNote',
        existing.id,
        existing.patientId,
        'ALLOWED',
        `Autosaved consultation draft v${existing.version}.`
      );
      this.persist();
      return existing;
    }

    const note: ConsultationNote = {
      id: `con-${crypto.randomUUID().slice(0, 8)}`,
      patientId: input.patientId,
      appointmentId: input.appointmentId,
      authorId: actor.userId,
      templateName: input.templateName,
      presentingConcern: input.presentingConcern,
      historyText: input.historyText,
      examinationText: input.examinationText,
      assessmentText: input.assessmentText,
      planText: input.planText,
      observationsSnapshot: input.observationsSnapshot ?? '',
      status: 'DRAFT',
      version: 1,
      autosavedAt: now,
      amendments: [],
    };
    this.state.consultations.unshift(note);
    this.audit(
      actor,
      'CONSULTATION_DRAFT_CREATED',
      'ConsultationNote',
      note.id,
      note.patientId,
      'ALLOWED',
      'Created consultation note draft.'
    );
    this.persist();
    return note;
  }

  signConsultationNote(
    actor: AuthSession,
    noteId: string,
    expectedVersion: number
  ): ConsultationNote {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const note = this.state.consultations.find((c) => c.id === noteId);
    if (!note) throw new DomainError(404, 'NOTE_NOT_FOUND', 'Consultation note not found.');
    if (note.status !== 'DRAFT') {
      throw new DomainError(409, 'IMMUTABLE_SIGNED_NOTE', 'Note has already been signed.');
    }
    if (note.version !== expectedVersion) {
      throw new DomainError(
        409,
        'VERSION_CONFLICT',
        `Cannot sign stale version (${expectedVersion}); server is at v${note.version}.`,
        { serverVersion: note.version }
      );
    }
    if (!note.presentingConcern.trim() || !note.planText.trim()) {
      throw new DomainError(422, 'INCOMPLETE_NOTE', 'Presenting concern and management plan are required before signing.');
    }
    const now = new Date().toISOString();
    note.status = 'SIGNED';
    note.signedAt = now;
    note.signedBy = actor.name;
    note.version += 1;

    if (note.appointmentId) {
      const apt = this.state.appointments.find((a) => a.id === note.appointmentId);
      if (apt) {
        apt.noteSignedSeparate = true;
      }
    }

    this.audit(
      actor,
      'CONSULTATION_SIGNED',
      'ConsultationNote',
      note.id,
      note.patientId,
      'ALLOWED',
      `Consultation note signed immutably (v${note.version}).`
    );
    this.persist();
    return note;
  }

  addConsultationAmendment(
    actor: AuthSession,
    noteId: string,
    reason: string,
    text: string
  ): ConsultationNote {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const note = this.state.consultations.find((c) => c.id === noteId);
    if (!note) throw new DomainError(404, 'NOTE_NOT_FOUND', 'Consultation note not found.');
    if (note.status !== 'SIGNED' && note.status !== 'AMENDED') {
      throw new DomainError(409, 'NOT_SIGNED', 'Only signed notes receive linked amendments.');
    }
    if (!reason.trim() || !text.trim()) {
      throw new DomainError(400, 'AMENDMENT_INVALID', 'Amendment reason and text are required.');
    }
    note.amendments.push({
      id: `amd-${crypto.randomUUID().slice(0, 8)}`,
      addedAt: new Date().toISOString(),
      addedBy: actor.name,
      reason: reason.trim(),
      text: text.trim(),
    });
    note.status = 'AMENDED';
    note.version += 1;
    this.audit(
      actor,
      'CONSULTATION_AMENDED',
      'ConsultationNote',
      note.id,
      note.patientId,
      'ALLOWED',
      'Linked amendment appended to signed consultation note.'
    );
    this.persist();
    return note;
  }

  markNoteEnteredInError(
    actor: AuthSession,
    noteId: string,
    reason: string
  ): ConsultationNote {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const note = this.state.consultations.find((c) => c.id === noteId);
    if (!note) throw new DomainError(404, 'NOTE_NOT_FOUND', 'Consultation note not found.');
    if (!reason.trim()) {
      throw new DomainError(400, 'REASON_REQUIRED', 'A clinical reason is required to mark a record entered-in-error.');
    }
    note.status = 'ENTERED_IN_ERROR';
    note.enteredInErrorReason = reason.trim();
    note.enteredInErrorAt = new Date().toISOString();
    note.enteredInErrorBy = actor.name;
    this.audit(
      actor,
      'CONSULTATION_ENTERED_IN_ERROR',
      'ConsultationNote',
      note.id,
      note.patientId,
      'ALLOWED',
      'Note marked entered-in-error with full history retained.'
    );
    this.persist();
    return note;
  }

  // --- Prescriptions & Simulated EPS Adapter with Idempotency ---
  createPrescriptionRequest(
    actor: AuthSession,
    input: {
      patientId: string;
      medicationName: string;
      dose: string;
      route: string;
      frequency: string;
      quantity: string;
      source: PrescriptionRequest['source'];
    }
  ): PrescriptionRequest {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'PATIENT']);
    if (actor.role === 'PATIENT' && actor.patientId !== input.patientId) {
      throw new DomainError(403, 'PATIENT_ISOLATION', 'Cannot request medication for another patient.');
    }
    const rx: PrescriptionRequest = {
      id: `rx-${crypto.randomUUID().slice(0, 8)}`,
      patientId: input.patientId,
      medicationName: input.medicationName.trim(),
      dose: input.dose.trim(),
      route: input.route.trim(),
      frequency: input.frequency.trim(),
      quantity: input.quantity.trim(),
      source: input.source,
      reconciliationStatus: 'RECONCILED',
      requestedAt: new Date().toISOString(),
      status: 'REQUESTED',
    };
    this.state.prescriptions.unshift(rx);
    this.audit(
      actor,
      'PRESCRIPTION_REQUESTED',
      'PrescriptionRequest',
      rx.id,
      rx.patientId,
      'ALLOWED',
      `Repeat prescription requested (${rx.source}).`
    );
    this.persist();
    return rx;
  }

  reviewPrescription(
    actor: AuthSession,
    rxId: string,
    decision: 'UNDER_REVIEW' | 'APPROVED' | 'DECLINED',
    decisionNote: string
  ): PrescriptionRequest {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const rx = this.state.prescriptions.find((p) => p.id === rxId);
    if (!rx) throw new DomainError(404, 'RX_NOT_FOUND', 'Prescription request not found.');
    rx.status = decision;
    rx.reviewedBy = actor.name;
    rx.reviewedAt = new Date().toISOString();
    rx.decisionNote = decisionNote;
    this.audit(
      actor,
      `PRESCRIPTION_${decision}`,
      'PrescriptionRequest',
      rx.id,
      rx.patientId,
      'ALLOWED',
      `Prescription marked ${decision}. (Not yet transmitted to EPS).`
    );
    this.persist();
    return rx;
  }

  submitPrescriptionToEps(
    actor: AuthSession,
    rxId: string,
    idempotencyKey: string,
    forceFail?: boolean
  ): PrescriptionRequest {
    this.requireRoles(actor, ['GP', 'NURSE']);
    if (!idempotencyKey) {
      throw new DomainError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Idempotency-Key is required for EPS transmission.');
    }
    if (this.state.processedIdempotencyKeys[idempotencyKey]) {
      return this.state.processedIdempotencyKeys[idempotencyKey] as PrescriptionRequest;
    }
    const rx = this.state.prescriptions.find((p) => p.id === rxId);
    if (!rx) throw new DomainError(404, 'RX_NOT_FOUND', 'Prescription not found.');
    if (rx.status !== 'APPROVED' && rx.status !== 'FAILED') {
      throw new DomainError(
        409,
        'INVALID_RX_STATE',
        `Prescription must be APPROVED before EPS submission (current: ${rx.status}).`
      );
    }

    const now = new Date().toISOString();
    rx.status = 'SUBMITTED_TO_EPS';
    rx.lastIdempotencyKey = idempotencyKey;

    const shouldFail = forceFail ?? this.state.config.simulatePrescribingFailure;
    if (shouldFail) {
      rx.status = 'FAILED';
      rx.epsError = 'EPS_SIM_503: Simulated NHS Spine EPS gateway timeout — prescription approved locally but NOT transmitted.';
      this.state.integrationEvents.unshift({
        id: `int-${crypto.randomUUID().slice(0, 8)}`,
        adapter: 'EPS_SIM',
        eventType: 'PRESCRIPTION_TRANSMIT',
        idempotencyKey,
        status: 'FAILED',
        attempts: 1,
        payloadSummary: `EPS submission failed for ${rx.id}`,
        createdAt: now,
        lastError: rx.epsError,
      });
      this.audit(
        actor,
        'EPS_TRANSMISSION_FAILED',
        'PrescriptionRequest',
        rx.id,
        rx.patientId,
        'FAILED',
        'Simulated EPS gateway transmission failed; approval remains distinct from dispensing.'
      );
    } else {
      rx.status = 'CONFIRMED';
      rx.epsMessageId = `EPS-SIM-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
      rx.epsError = undefined;
      this.state.integrationEvents.unshift({
        id: `int-${crypto.randomUUID().slice(0, 8)}`,
        adapter: 'EPS_SIM',
        eventType: 'PRESCRIPTION_TRANSMIT',
        idempotencyKey,
        status: 'DELIVERED',
        attempts: 1,
        payloadSummary: `EPS token ${rx.epsMessageId} confirmed by simulated dispenser`,
        createdAt: now,
      });
      this.audit(
        actor,
        'EPS_TRANSMISSION_CONFIRMED',
        'PrescriptionRequest',
        rx.id,
        rx.patientId,
        'ALLOWED',
        `Simulated EPS transmission confirmed (${rx.epsMessageId}).`
      );
    }

    this.state.processedIdempotencyKeys[idempotencyKey] = structuredClone(rx);
    this.persist();
    return rx;
  }

  // --- Results & Follow-up ---
  viewLabResult(actor: AuthSession, resultId: string): LabResult {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const res = this.state.results.find((r) => r.id === resultId);
    if (!res) throw new DomainError(404, 'RESULT_NOT_FOUND', 'Result not found.');
    if (!res.viewedAt) {
      res.viewedAt = new Date().toISOString();
      res.viewedBy = actor.name;
    }
    // Note: viewing does NOT automatically set acknowledgedAt or actioned = true!
    this.audit(actor, 'RESULT_VIEWED', 'LabResult', res.id, res.patientId, 'ALLOWED', 'Result viewed (not yet actioned).');
    this.persist();
    return res;
  }

  actionLabResult(
    actor: AuthSession,
    resultId: string,
    input: {
      followUpAction: string;
      patientCommunicationSummary?: string;
      communicationChannel?: string;
      createFollowUpTask?: boolean;
      taskOwnerId?: string;
    }
  ): { result: LabResult; createdTask?: PracticeTask } {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const res = this.state.results.find((r) => r.id === resultId);
    if (!res) throw new DomainError(404, 'RESULT_NOT_FOUND', 'Result not found.');
    const now = new Date().toISOString();
    if (!res.viewedAt) {
      res.viewedAt = now;
      res.viewedBy = actor.name;
    }
    res.acknowledgedAt = now;
    res.acknowledgedBy = actor.name;
    res.actioned = true;
    res.followUpAction = input.followUpAction.trim();

    if (input.patientCommunicationSummary?.trim()) {
      res.patientCommunicationHistory.push({
        timestamp: now,
        channel: input.communicationChannel || 'TELEPHONE',
        actor: actor.name,
        summary: input.patientCommunicationSummary.trim(),
      });
    }

    let createdTask: PracticeTask | undefined;
    if (input.createFollowUpTask) {
      const ownerId = input.taskOwnerId || actor.userId;
      const ownerStaff = this.state.staff.find((s) => s.id === ownerId);
      const effectiveOwnerId = ownerStaff?.coverStaffId || ownerId;
      createdTask = {
        id: `task-${crypto.randomUUID().slice(0, 8)}`,
        title: `Result follow-up: ${res.testName}`,
        category: 'RESULT_REVIEW',
        patientId: res.patientId,
        ownerId: effectiveOwnerId,
        originalOwnerId: ownerStaff?.coverStaffId ? ownerId : undefined,
        coveredById: ownerStaff?.coverStaffId ? effectiveOwnerId : undefined,
        dueAt: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
        priority: res.abnormalFlag === 'CRITICAL' ? 'URGENT' : 'HIGH',
        status: 'OPEN',
        notes: input.followUpAction.trim(),
        linkedEntityId: res.id,
      };
      this.state.tasks.unshift(createdTask);
    }

    this.audit(
      actor,
      'RESULT_ACTIONED',
      'LabResult',
      res.id,
      res.patientId,
      'ALLOWED',
      `Result acknowledged and actioned.${res.status === 'CORRECTED' ? ' (Corrected report reviewed)' : ''}`
    );
    this.persist();
    return { result: res, createdTask };
  }

  ingestCorrectedResult(
    actor: AuthSession,
    previousResultId: string,
    newValue: string,
    correctionNote: string
  ): LabResult {
    this.requireRoles(actor, ['GP', 'NURSE', 'ADMIN']);
    const prev = this.state.results.find((r) => r.id === previousResultId);
    if (!prev) throw new DomainError(404, 'RESULT_NOT_FOUND', 'Prior result not found.');
    const reviewer = this.state.staff.find((s) => s.id === prev.assignedReviewerId);
    const effectiveReviewer = reviewer?.coverStaffId || prev.assignedReviewerId;

    const corrected: LabResult = {
      id: `res-${crypto.randomUUID().slice(0, 8)}`,
      patientId: prev.patientId,
      testName: `${prev.testName} — CORRECTED`,
      sourceLab: prev.sourceLab,
      collectedAt: prev.collectedAt,
      reportedAt: new Date().toISOString(),
      status: 'CORRECTED',
      value: newValue,
      unit: prev.unit,
      referenceInterval: prev.referenceInterval,
      abnormalFlag: 'HIGH',
      previousVersionId: prev.id,
      correctionNote,
      assignedReviewerId: effectiveReviewer,
      actioned: false,
      patientCommunicationHistory: [],
    };
    this.state.results.unshift(corrected);
    this.audit(
      actor,
      'CORRECTED_RESULT_ROUTED',
      'LabResult',
      corrected.id,
      corrected.patientId,
      'ALLOWED',
      `Corrected result linked to ${prev.id} and routed to ${effectiveReviewer}.`
    );
    this.persist();
    return corrected;
  }

  // --- Referrals & Documents ---
  createOrAdvanceReferral(
    actor: AuthSession,
    input: {
      referralId?: string;
      patientId?: string;
      specialty?: string;
      pathway?: string;
      urgency?: Referral['urgency'];
      templateName?: string;
      clinicalSummary?: string;
      action: 'SAVE_DRAFT' | 'CLINICAL_REVIEW' | 'TRANSMIT';
      idempotencyKey?: string;
      forceFail?: boolean;
    }
  ): Referral {
    this.requireRoles(actor, ['GP', 'NURSE']);
    const now = new Date().toISOString();

    if (input.action === 'TRANSMIT' && input.idempotencyKey) {
      if (this.state.processedIdempotencyKeys[input.idempotencyKey]) {
        return this.state.processedIdempotencyKeys[input.idempotencyKey] as Referral;
      }
    }

    let ref: Referral | undefined;
    if (input.referralId) {
      ref = this.state.referrals.find((r) => r.id === input.referralId);
      if (!ref) throw new DomainError(404, 'REFERRAL_NOT_FOUND', 'Referral not found.');
    } else {
      if (!input.patientId || !input.specialty) {
        throw new DomainError(400, 'INVALID_REFERRAL', 'Patient and specialty are required.');
      }
      ref = {
        id: `ref-${crypto.randomUUID().slice(0, 8)}`,
        patientId: input.patientId,
        specialty: input.specialty,
        pathway: input.pathway || 'Routine e-RS Pathway',
        urgency: input.urgency || 'ROUTINE',
        templateName: input.templateName || 'West Yorkshire e-RS Generic Template',
        clinicalSummary: input.clinicalSummary || '',
        attachments: [],
        authorId: actor.userId,
        status: 'DRAFT',
      };
      this.state.referrals.unshift(ref);
    }

    if (input.clinicalSummary !== undefined && ref.status === 'DRAFT') {
      ref.clinicalSummary = input.clinicalSummary;
    }

    if (input.action === 'CLINICAL_REVIEW') {
      ref.status = 'CLINICALLY_REVIEWED';
      ref.reviewedBy = actor.name;
    } else if (input.action === 'TRANSMIT') {
      if (ref.status !== 'CLINICALLY_REVIEWED' && ref.status !== 'FAILED') {
        throw new DomainError(409, 'REVIEW_REQUIRED', 'Referral must pass clinical review before e-RS transmission.');
      }
      const key = input.idempotencyKey || `ers-${ref.id}-${Date.now()}`;
      ref.lastIdempotencyKey = key;
      const shouldFail = input.forceFail ?? this.state.config.simulateReferralFailure;
      if (shouldFail) {
        ref.status = 'FAILED';
        ref.failureReason = 'ERS_SIM_504: Simulated e-RS endpoint unavailable — clinical review preserved for retry.';
        this.state.integrationEvents.unshift({
          id: `int-${crypto.randomUUID().slice(0, 8)}`,
          adapter: 'ERS_SIM',
          eventType: 'REFERRAL_TRANSMIT',
          idempotencyKey: key,
          status: 'FAILED',
          attempts: 1,
          payloadSummary: `e-RS referral transmission failed for ${ref.id}`,
          createdAt: now,
          lastError: ref.failureReason,
        });
      } else {
        ref.status = 'ACCEPTED';
        ref.ersReference = `UBRN-${Math.floor(10000000 + Math.random() * 89999999)}`;
        ref.failureReason = undefined;
        this.state.integrationEvents.unshift({
          id: `int-${crypto.randomUUID().slice(0, 8)}`,
          adapter: 'ERS_SIM',
          eventType: 'REFERRAL_TRANSMIT',
          idempotencyKey: key,
          status: 'DELIVERED',
          attempts: 1,
          payloadSummary: `e-RS UBRN ${ref.ersReference} acknowledged by simulated trust`,
          createdAt: now,
        });
      }
      this.state.processedIdempotencyKeys[key] = structuredClone(ref);
    }

    this.audit(
      actor,
      `REFERRAL_${ref.status}`,
      'Referral',
      ref.id,
      ref.patientId,
      ref.status === 'FAILED' ? 'FAILED' : 'ALLOWED',
      `Referral status updated to ${ref.status}.`
    );
    this.persist();
    return ref;
  }

  confirmDocumentMatchAndAction(
    actor: AuthSession,
    documentId: string,
    input: {
      matchedPatientId: string;
      confirmMatch: boolean;
      classification?: IncomingDocument['classification'];
      assignedToId?: string;
      markActioned?: boolean;
      releaseToPatient?: boolean;
    }
  ): IncomingDocument {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'ADMIN']);
    const doc = this.state.documents.find((d) => d.id === documentId);
    if (!doc) throw new DomainError(404, 'DOC_NOT_FOUND', 'Document not found.');
    if (input.releaseToPatient && actor.role !== 'GP' && actor.role !== 'NURSE') {
      throw new DomainError(403, 'RELEASE_RESTRICTED', 'Only clinicians can release correspondence to the patient portal.');
    }
    doc.matchedPatientId = input.matchedPatientId;
    doc.patientMatchConfirmed = input.confirmMatch;
    if (input.classification) doc.classification = input.classification;
    if (input.assignedToId) doc.assignedToId = input.assignedToId;
    if (input.markActioned) {
      if (!doc.patientMatchConfirmed) {
        throw new DomainError(409, 'CONFIRM_MATCH_FIRST', 'Staff must confirm OCR patient match before filing/actioning.');
      }
      doc.actionStatus = 'ACTIONED';
    } else if (doc.patientMatchConfirmed) {
      doc.actionStatus = 'PENDING_REVIEW';
    }
    if (input.releaseToPatient !== undefined) {
      if (!doc.patientMatchConfirmed || !doc.confidentialThirdPartyRedacted) {
        throw new DomainError(409, 'UNSAFE_RELEASE', 'Patient match and third-party confidentiality check must be confirmed before patient release.');
      }
      doc.releasedToPatient = input.releaseToPatient;
    }

    this.audit(
      actor,
      'DOCUMENT_UPDATED',
      'IncomingDocument',
      doc.id,
      doc.matchedPatientId,
      'ALLOWED',
      `Document matchConfirmed=${doc.patientMatchConfirmed}, status=${doc.actionStatus}, released=${doc.releasedToPatient}.`
    );
    this.persist();
    return doc;
  }

  // --- Tasks & Cover Reassignment ---
  createOrUpdateTask(
    actor: AuthSession,
    input: {
      taskId?: string;
      title?: string;
      category?: PracticeTask['category'];
      patientId?: string;
      ownerId?: string;
      priority?: PracticeTask['priority'];
      status?: PracticeTask['status'];
      notes?: string;
    }
  ): PracticeTask {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'PRACTICE_MANAGER', 'ADMIN']);
    if (input.taskId) {
      const task = this.state.tasks.find((t) => t.id === input.taskId);
      if (!task) throw new DomainError(404, 'TASK_NOT_FOUND', 'Task not found.');
      if (input.ownerId && input.ownerId !== task.ownerId) {
        task.originalOwnerId = task.originalOwnerId ?? task.ownerId;
        task.ownerId = input.ownerId;
        task.coveredById = input.ownerId;
      }
      if (input.status) task.status = input.status;
      if (input.notes !== undefined) task.notes = input.notes;
      this.audit(
        actor,
        'TASK_UPDATED',
        'PracticeTask',
        task.id,
        task.patientId,
        'ALLOWED',
        `Task status=${task.status}, owner=${task.ownerId}.`
      );
      this.persist();
      return task;
    }

    const ownerId = input.ownerId || actor.userId;
    const ownerStaff = this.state.staff.find((s) => s.id === ownerId);
    const effectiveOwnerId = ownerStaff?.coverStaffId || ownerId;

    const task: PracticeTask = {
      id: `task-${crypto.randomUUID().slice(0, 8)}`,
      title: (input.title || 'Follow-up task').trim(),
      category: input.category || 'FOLLOW_UP',
      patientId: input.patientId,
      ownerId: effectiveOwnerId,
      originalOwnerId: ownerStaff?.coverStaffId ? ownerId : undefined,
      coveredById: ownerStaff?.coverStaffId ? effectiveOwnerId : undefined,
      dueAt: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      priority: input.priority || 'ROUTINE',
      status: 'OPEN',
      notes: input.notes || '',
    };
    this.state.tasks.unshift(task);
    this.audit(
      actor,
      'TASK_CREATED',
      'PracticeTask',
      task.id,
      task.patientId,
      'ALLOWED',
      `Task created and routed to ${effectiveOwnerId}.`
    );
    this.persist();
    return task;
  }

  // --- Long-Term Care Recalls ---
  advanceRecallStage(
    actor: AuthSession,
    recallId: string,
    stage: CareRecall['stage'],
    interventionNote?: string
  ): CareRecall {
    this.requireRoles(actor, ['RECEPTION', 'GP', 'NURSE', 'PRACTICE_MANAGER']);
    const recall = this.state.recalls.find((r) => r.id === recallId);
    if (!recall) throw new DomainError(404, 'RECALL_NOT_FOUND', 'Recall item not found.');
    if (!this.state.config.automatedRecallSchedulingApproved || !recall.clinicallyGovernedApproved) {
      throw new DomainError(409, 'GOVERNANCE_REQUIRED', 'Clinical governance approval is required before activating recall schedule.');
    }
    if (
      (stage === 'INTERVENTION_RECORDED' || stage === 'COMPLETED_REVIEW') &&
      actor.role !== 'GP' &&
      actor.role !== 'NURSE'
    ) {
      throw new DomainError(403, 'CLINICAL_ACTION_REQUIRED', 'Only clinicians may record care-plan interventions or mark clinical review completed.');
    }
    recall.stage = stage;
    recall.lastContactedAt = new Date().toISOString();
    if (interventionNote) recall.interventionNote = interventionNote;
    this.audit(
      actor,
      'RECALL_STAGE_UPDATED',
      'CareRecall',
      recall.id,
      recall.patientId,
      'ALLOWED',
      `Recall stage moved to ${stage}.`
    );
    this.persist();
    return recall;
  }

  // --- Patient Portal Submissions ---
  submitPatientPortalAction(
    actor: AuthSession,
    input: {
      type: PatientPortalSubmission['type'];
      detail: string;
      appointmentIdToCancel?: string;
      medicationName?: string;
      updatedPhone?: string;
      updatedEmail?: string;
      notificationPreferences?: Patient['notificationPreferences'];
    }
  ): PatientPortalSubmission {
    this.requireRoles(actor, ['PATIENT']);
    const patient = this.state.patients.find((p) => p.id === actor.patientId);
    if (!patient) throw new DomainError(404, 'PATIENT_NOT_FOUND', 'Patient not found.');

    const now = new Date().toISOString();
    const submission: PatientPortalSubmission = {
      id: `psub-${crypto.randomUUID().slice(0, 8)}`,
      patientId: patient.id,
      type: input.type,
      detail: input.detail.trim(),
      submittedAt: now,
      status: 'RECEIVED',
    };
    this.state.patientSubmissions.unshift(submission);

    if (input.type === 'CANCELLATION' && input.appointmentIdToCancel) {
      const apt = this.state.appointments.find(
        (a) => a.id === input.appointmentIdToCancel && a.patientId === patient.id
      );
      if (apt) {
        apt.status = 'CANCELLED';
        apt.history.push({
          timestamp: now,
          actor: `${patient.fullName} (Patient Portal)`,
          action: 'CANCELLED',
          detail: input.detail,
        });
        submission.status = 'PROCESSED';
      }
    } else if (input.type === 'REPEAT_MEDICATION' && input.medicationName) {
      const existingMed = patient.medications.find((m) => m.name === input.medicationName);
      this.state.prescriptions.unshift({
        id: `rx-${crypto.randomUUID().slice(0, 8)}`,
        patientId: patient.id,
        medicationName: input.medicationName,
        dose: existingMed?.dose || 'As prescribed',
        route: existingMed?.route || 'Oral',
        frequency: existingMed?.frequency || 'As directed',
        quantity: '28 days',
        source: 'PATIENT_PORTAL',
        reconciliationStatus: 'RECONCILED',
        requestedAt: now,
        status: 'REQUESTED',
      });
      submission.status = 'PROCESSED';
    } else if (input.type === 'CONTACT_UPDATE') {
      if (input.updatedPhone) patient.phone = input.updatedPhone.trim();
      if (input.updatedEmail) patient.email = input.updatedEmail.trim();
      if (input.notificationPreferences) patient.notificationPreferences = input.notificationPreferences;
      submission.status = 'PROCESSED';
    } else if (input.type === 'APPOINTMENT_REQUEST') {
      this.state.requests.unshift({
        id: `req-${crypto.randomUUID().slice(0, 8)}`,
        patientId: patient.id,
        channel: 'ONLINE_FORM',
        description: input.detail.trim(),
        preferredContactMethod: patient.preferredContactMethod,
        attachments: [],
        submittedAt: now,
        receivedStatus: 'RECORDED',
        clinicalReviewStatus: 'NOT_REVIEWED',
        priority: 'UNASSIGNED',
        status: 'RECEIVED',
        urgentGuidanceShown: true,
        history: [{ timestamp: now, actor: 'Patient Portal', action: 'Submitted appointment request' }],
      });
    }

    this.audit(
      actor,
      `PORTAL_${input.type}`,
      'PatientPortalSubmission',
      submission.id,
      patient.id,
      'ALLOWED',
      `Patient portal action ${input.type} recorded.`
    );
    this.persist();
    return submission;
  }

  // --- Integration Callback Handler (Idempotency) ---
  handleIntegrationCallback(
    idempotencyKey: string,
    adapter: 'EPS_SIM' | 'ERS_SIM',
    entityId: string,
    newExternalStatus: 'CONFIRMED' | 'FAILED' | 'APPOINTMENT_ALLOCATED',
    detail: string
  ): { deduplicated: boolean; entityId: string; status: string } {
    if (!idempotencyKey) {
      throw new DomainError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Callback idempotency key is required.');
    }
    const existing = this.state.processedIdempotencyKeys[`cb:${idempotencyKey}`];
    if (existing) {
      return { deduplicated: true, entityId, status: String((existing as { status: string }).status) };
    }
    if (adapter === 'EPS_SIM') {
      const rx = this.state.prescriptions.find((r) => r.id === entityId);
      if (!rx) throw new DomainError(404, 'RX_NOT_FOUND', 'Prescription not found.');
      rx.status = newExternalStatus === 'CONFIRMED' ? 'CONFIRMED' : 'FAILED';
      if (newExternalStatus === 'FAILED') rx.epsError = detail;
      const result = { deduplicated: false, entityId: rx.id, status: rx.status };
      this.state.processedIdempotencyKeys[`cb:${idempotencyKey}`] = result;
      this.persist();
      return result;
    }
    const ref = this.state.referrals.find((r) => r.id === entityId);
    if (!ref) throw new DomainError(404, 'REFERRAL_NOT_FOUND', 'Referral not found.');
    ref.status =
      newExternalStatus === 'APPOINTMENT_ALLOCATED'
        ? 'APPOINTMENT_ALLOCATED'
        : 'FAILED';
    if (newExternalStatus === 'APPOINTMENT_ALLOCATED') {
      ref.externalAppointmentDate = detail;
    } else {
      ref.failureReason = detail;
    }
    const result = { deduplicated: false, entityId: ref.id, status: ref.status };
    this.state.processedIdempotencyKeys[`cb:${idempotencyKey}`] = result;
    this.persist();
    return result;
  }

  // --- Admin Config & Operational Metrics ---
  updatePracticeConfig(actor: AuthSession, patch: Partial<PracticeConfig>): PracticeConfig {
    this.requireRoles(actor, ['ADMIN', 'PRACTICE_MANAGER']);
    this.state.config = { ...this.state.config, ...patch };
    this.audit(
      actor,
      'CONFIG_UPDATED',
      'PracticeConfig',
      this.state.config.odsCode,
      undefined,
      'ALLOWED',
      `Updated practice configuration (AI assist=${this.state.config.aiAssistEnabled}).`
    );
    this.persist();
    return this.state.config;
  }

  revokeStaffSessions(actor: AuthSession, targetStaffId: string): StaffMember {
    this.requireRoles(actor, ['ADMIN']);
    const member = this.state.staff.find((s) => s.id === targetStaffId);
    if (!member) throw new DomainError(404, 'STAFF_NOT_FOUND', 'Staff member not found.');
    member.sessionVersion += 1;
    this.audit(
      actor,
      'SESSIONS_REVOKED',
      'StaffMember',
      member.id,
      undefined,
      'ALLOWED',
      `Revoked all active sessions for ${member.name} (sessionVersion=${member.sessionVersion}).`
    );
    this.persist();
    return member;
  }

  updateRotaCover(actor: AuthSession, staffId: string, coverStaffId?: string): StaffMember {
    this.requireRoles(actor, ['PRACTICE_MANAGER', 'ADMIN']);
    const member = this.state.staff.find((s) => s.id === staffId);
    if (!member) throw new DomainError(404, 'STAFF_NOT_FOUND', 'Staff member not found.');
    member.coverStaffId = coverStaffId || undefined;
    // Reassign open tasks when cover is activated
    if (coverStaffId) {
      for (const task of this.state.tasks) {
        if (task.ownerId === staffId && task.status !== 'COMPLETED') {
          task.originalOwnerId = task.originalOwnerId ?? staffId;
          task.ownerId = coverStaffId;
          task.coveredById = coverStaffId;
        }
      }
    }
    this.audit(
      actor,
      'STAFF_COVER_UPDATED',
      'StaffMember',
      member.id,
      undefined,
      'ALLOWED',
      `Cover arrangement set to ${coverStaffId ?? 'none'}.`
    );
    this.persist();
    return member;
  }

  computeOperationalMetrics() {
    const activeApts = this.state.appointments.filter((a) => a.status !== 'CANCELLED');
    const bookedMinutes = activeApts.reduce((sum, a) => sum + a.durationMinutes, 0);
    // Available session capacity: 2 clinics (Morning GP 240 min + Nurse 210 min) = 450 min
    const totalSessionMinutes = 450;
    const utilisationPct = Math.round((bookedMinutes / totalSessionMinutes) * 100);
    const unreviewedRequests = this.state.requests.filter(
      (r) => r.clinicalReviewStatus === 'NOT_REVIEWED' && r.status !== 'CLOSED'
    ).length;
    const unactionedResults = this.state.results.filter((r) => !r.actioned).length;
    const openTasks = this.state.tasks.filter((t) => t.status !== 'COMPLETED').length;
    const lowStockItems = this.state.consumables.filter(
      (c) => c.quantity <= c.reorderThreshold
    ).length;
    const dueEquipment = this.state.equipment.filter(
      (e) => e.status !== 'OPERATIONAL'
    ).length;

    return {
      totalAppointmentsToday: activeApts.length,
      bookedMinutes,
      totalSessionMinutes,
      utilisationPct,
      averageWaitingMinutes: 11,
      unreviewedRequests,
      unactionedResults,
      openTasks,
      lowStockItems,
      dueEquipment,
      definitionNote:
        'Operational metrics measure booked session utilisation (booked min / planned clinic min) and queue backlogs; they are explicitly distinct from clinical outcomes.',
    };
  }
}
