import crypto from 'node:crypto';
import type { AuthSession, Patient, StaffMember } from '../src/types/clinical.ts';

const EPHEMERAL_FALLBACK_SECRET = crypto.randomBytes(32).toString('hex');

function getSigningSecret(): string {
  return process.env.SESSION_SECRET || EPHEMERAL_FALLBACK_SECRET;
}

export interface TokenClaims {
  userId: string;
  actorType: 'STAFF' | 'PATIENT';
  role: AuthSession['role'];
  name: string;
  title: string;
  mfaVerified: boolean;
  sessionVersion: number;
  patientId?: string;
  exp: number;
}

export function signSessionToken(claims: Omit<TokenClaims, 'exp'>): string {
  const payload: TokenClaims = {
    ...claims,
    exp: Date.now() + 8 * 60 * 60 * 1000, // 8-hour shift session
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSigningSecret())
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(
  token: string,
  staffList: StaffMember[],
  patients: Patient[]
): AuthSession | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expected = crypto
    .createHmac('sha256', getSigningSecret())
    .update(encoded)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const claims = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as TokenClaims;
    if (Date.now() > claims.exp) return null;

    if (claims.actorType === 'STAFF') {
      const staff = staffList.find((s) => s.id === claims.userId);
      if (!staff || !staff.active || staff.sessionVersion !== claims.sessionVersion) {
        return null;
      }
    } else {
      const pat = patients.find((p) => p.id === claims.patientId);
      if (!pat) return null;
    }

    return {
      token,
      userId: claims.userId,
      actorType: claims.actorType,
      role: claims.role,
      name: claims.name,
      title: claims.title,
      mfaVerified: claims.mfaVerified,
      issuedAt: new Date().toISOString(),
      patientId: claims.patientId,
    };
  } catch {
    return null;
  }
}
