export type StaffRole =
  | 'RECEPTION'
  | 'GP'
  | 'NURSE'
  | 'PRACTICE_MANAGER'
  | 'ADMIN';

export type ActorType = 'STAFF' | 'PATIENT';

export interface StaffMember {
  id: string;
  name: string;
  role: StaffRole;
  title: string;
  professionalReg?: string;
  email: string;
  mfaEnrolled: boolean;
  active: boolean;
  coverStaffId?: string;
  sessionVersion: number;
}

export interface AuthSession {
  token: string;
  userId: string;
  actorType: ActorType;
  role: StaffRole | 'PATIENT';
  name: string;
  title: string;
  mfaVerified: boolean;
  issuedAt: string;
  patientId?: string;
}

export type VerificationStatus =
  | 'VERIFIED'
  | 'PENDING_VERIFICATION'
  | 'UNVERIFIED'
  | 'DISPUTED';

export interface PatientIdentifier {
  system: 'NHS_NUMBER' | 'LOCAL_PRACTICE_ID' | 'IDENTITY_DOCUMENT';
  value: string;
  issuingAuthority: string;
  verificationStatus: VerificationStatus;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface AllergyRecord {
  id: string;
  substance: string;
  reaction: string;
  severity: 'MILD' | 'MODERATE' | 'SEVERE';
  recordedAt: string;
}

export type ClinicalDataState<T> =
  | { state: 'RECORDED'; value: T; recordedAt: string }
  | { state: 'EXPLICITLY_ABSENT'; detail: string; recordedAt: string }
  | { state: 'UNKNOWN'; detail: string; recordedAt: string }
  | { state: 'NOT_ASSESSED'; detail: string };

export interface ProxyRelationship {
  id: string;
  patientId: string;
  relatedPersonName: string;
  relationshipType:
    | 'PARENT'
    | 'CARER'
    | 'LPA_HEALTH'
    | 'EMERGENCY_CONTACT'
    | 'HOUSEHOLD_MEMBER';
  sharedAddress: boolean;
  isEmergencyContact: boolean;
  knowsDemographics: boolean;
  hasRecordAccess: boolean;
  accessScope: Array<'APPOINTMENTS' | 'PRESCRIPTIONS' | 'SUMMARY' | 'MESSAGES'>;
  effectiveFrom: string;
  effectiveTo?: string;
  verificationStatus: VerificationStatus;
  restrictions?: string;
  revokedAt?: string;
  revocationReason?: string;
}

export interface DuplicateCandidate {
  id: string;
  candidatePatientId: string;
  existingPatientId: string;
  matchScore: number;
  matchingFields: string[];
  status: 'OPEN' | 'CONFIRMED_SAME_PERSON' | 'CONFIRMED_DISTINCT';
  resolvedBy?: string;
  resolvedAt?: string;
  resolutionNote?: string;
}

export interface MedicationItem {
  id: string;
  name: string;
  dose: string;
  route: string;
  frequency: string;
  type: 'REPEAT' | 'ACUTE';
  lastIssuedAt: string;
  source: string;
}

export interface ObservationItem {
  id: string;
  type: string;
  value: string;
  unit: string;
  recordedAt: string;
  recordedBy: string;
}

export interface NotificationPreferences {
  sms: boolean;
  email: boolean;
  nhsApp: boolean;
  letter: boolean;
}

export interface Patient {
  id: string;
  fullName: string;
  preferredName?: string;
  dateOfBirth: string;
  sex: 'Female' | 'Male' | 'Unspecified';
  nhsNumber: string;
  nhsVerificationStatus: VerificationStatus;
  identifiers: PatientIdentifier[];
  address: string;
  phone: string;
  email: string;
  preferredContactMethod: 'TELEPHONE' | 'SMS' | 'EMAIL' | 'NHS_APP' | 'LETTER';
  enrolmentStatus:
    | 'REGISTERED'
    | 'PENDING_REGISTRATION'
    | 'TRANSFER_IN'
    | 'TRANSFERRED_OUT';
  registeredPracticeOds: string;
  usualGpId: string;
  restrictedRecord: boolean;
  restrictionReason?: string;
  allergiesState: ClinicalDataState<AllergyRecord[]>;
  smokingStatusState: ClinicalDataState<string>;
  activeProblems: string[];
  medications: MedicationItem[];
  observations: ObservationItem[];
  notificationPreferences: NotificationPreferences;
}

export type AppointmentMode = 'FACE_TO_FACE' | 'TELEPHONE' | 'VIDEO';

export type AppointmentStatus =
  | 'BOOKED'
  | 'ARRIVED'
  | 'WAITING'
  | 'IN_CONSULTATION'
  | 'COMPLETED'
  | 'DID_NOT_ATTEND'
  | 'CANCELLED';

export interface AppointmentHistoryEntry {
  timestamp: string;
  actor: string;
  action: string;
  detail: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  clinicianId: string;
  roomId: string;
  appointmentType: string;
  mode: AppointmentMode;
  startTime: string;
  durationMinutes: number;
  endTime: string;
  status: AppointmentStatus;
  reason: string;
  reminderChannel: 'SMS' | 'EMAIL' | 'NHS_APP' | 'NONE';
  reminderStatus: 'SCHEDULED' | 'SENT' | 'OPTED_OUT';
  videoRoomUrl?: string;
  noteSignedSeparate: boolean;
  history: AppointmentHistoryEntry[];
  version: number;
}

export interface Room {
  id: string;
  name: string;
  floor: string;
  equipment: string[];
  status: 'AVAILABLE' | 'MAINTENANCE';
}

export interface WaitingListEntry {
  id: string;
  patientId: string;
  requestedType: string;
  preferredClinicianId?: string;
  urgencyNote: string;
  addedAt: string;
  status: 'WAITING' | 'BOOKED' | 'REMOVED';
}

export interface RecurringClinic {
  id: string;
  name: string;
  clinicianId: string;
  roomId: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  slotMinutes: number;
  appointmentType: string;
}

export type RequestChannel = 'TELEPHONE' | 'RECEPTION_DESK' | 'ONLINE_FORM';

export type RequestStatus =
  | 'RECEIVED'
  | 'ACKNOWLEDGED'
  | 'ASSIGNED'
  | 'CLINICALLY_REVIEWED'
  | 'ACTIONED'
  | 'ESCALATED'
  | 'CLOSED';

export type StaffAssignedPriority =
  | 'UNASSIGNED'
  | 'ROUTINE'
  | 'SOON'
  | 'SAME_DAY_DUTY'
  | 'URGENT_SIGNPOSTED';

export interface IncomingRequest {
  id: string;
  patientId?: string;
  unmatchedPatientName?: string;
  channel: RequestChannel;
  description: string;
  preferredContactMethod: string;
  attachments: string[];
  submittedAt: string;
  receivedStatus: 'RECORDED';
  clinicalReviewStatus: 'NOT_REVIEWED' | 'REVIEWED';
  assignedOwnerId?: string;
  priority: StaffAssignedPriority;
  priorityAssignedBy?: string;
  status: RequestStatus;
  handoverNote?: string;
  escalatedToId?: string;
  linkedAppointmentId?: string;
  urgentGuidanceShown: boolean;
  history: { timestamp: string; actor: string; action: string }[];
}

export type ConsultationStatus =
  | 'DRAFT'
  | 'SIGNED'
  | 'AMENDED'
  | 'ENTERED_IN_ERROR';

export interface ConsultationAmendment {
  id: string;
  addedAt: string;
  addedBy: string;
  reason: string;
  text: string;
}

export interface ConsultationNote {
  id: string;
  patientId: string;
  appointmentId?: string;
  authorId: string;
  templateName: string;
  presentingConcern: string;
  historyText: string;
  examinationText: string;
  assessmentText: string;
  planText: string;
  observationsSnapshot: string;
  status: ConsultationStatus;
  version: number;
  autosavedAt: string;
  signedAt?: string;
  signedBy?: string;
  amendments: ConsultationAmendment[];
  enteredInErrorReason?: string;
  enteredInErrorAt?: string;
  enteredInErrorBy?: string;
}

export type PrescriptionStatus =
  | 'REQUESTED'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'DECLINED'
  | 'SUBMITTED_TO_EPS'
  | 'CONFIRMED'
  | 'FAILED';

export interface PrescriptionRequest {
  id: string;
  patientId: string;
  medicationName: string;
  dose: string;
  route: string;
  frequency: string;
  quantity: string;
  source: 'PATIENT_PORTAL' | 'PHARMACY_POD' | 'CLINICIAN_INITIATED';
  reconciliationStatus:
    | 'RECONCILED'
    | 'HOSPITAL_DISCHARGE_PENDING'
    | 'UNVERIFIED';
  requestedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  decisionNote?: string;
  status: PrescriptionStatus;
  epsMessageId?: string;
  epsError?: string;
  lastIdempotencyKey?: string;
}

export type ResultStatus = 'PRELIMINARY' | 'FINAL' | 'CORRECTED' | 'CANCELLED';

export interface LabResult {
  id: string;
  patientId: string;
  testName: string;
  sourceLab: string;
  collectedAt: string;
  reportedAt: string;
  status: ResultStatus;
  value: string;
  unit: string;
  referenceInterval: string;
  abnormalFlag: 'NORMAL' | 'HIGH' | 'LOW' | 'CRITICAL';
  previousVersionId?: string;
  correctionNote?: string;
  assignedReviewerId: string;
  viewedAt?: string;
  viewedBy?: string;
  acknowledgedAt?: string;
  acknowledgedBy?: string;
  actioned: boolean;
  followUpAction?: string;
  patientCommunicationHistory: {
    timestamp: string;
    channel: string;
    actor: string;
    summary: string;
  }[];
}

export type ReferralStatus =
  | 'DRAFT'
  | 'CLINICALLY_REVIEWED'
  | 'TRANSMITTED'
  | 'ACCEPTED'
  | 'APPOINTMENT_ALLOCATED'
  | 'FAILED'
  | 'REJECTED';

export interface Referral {
  id: string;
  patientId: string;
  specialty: string;
  pathway: string;
  urgency: 'ROUTINE' | 'URGENT' | 'TWO_WEEK_WAIT';
  templateName: string;
  clinicalSummary: string;
  attachments: string[];
  authorId: string;
  reviewedBy?: string;
  status: ReferralStatus;
  ersReference?: string;
  externalAppointmentDate?: string;
  failureReason?: string;
  lastIdempotencyKey?: string;
}

export interface IncomingDocument {
  id: string;
  title: string;
  sourceOrganisation: string;
  receivedAt: string;
  ocrSuggestedPatientName: string;
  ocrSuggestedNhsNumber: string;
  ocrSuggestedSummary: string;
  matchedPatientId?: string;
  patientMatchConfirmed: boolean;
  classification:
    | 'DISCHARGE_SUMMARY'
    | 'OUTPATIENT_LETTER'
    | 'SCREENING_REPORT'
    | 'SAFEGUARDING'
    | 'OTHER';
  assignedToId?: string;
  actionStatus: 'UNMATCHED' | 'PENDING_REVIEW' | 'ACTIONED';
  releasedToPatient: boolean;
  confidentialThirdPartyRedacted: boolean;
  documentBody: string;
}

export type TaskStatus = 'OPEN' | 'IN_PROGRESS' | 'COMPLETED' | 'ESCALATED';

export interface PracticeTask {
  id: string;
  title: string;
  category:
    | 'FOLLOW_UP'
    | 'MEDICATION'
    | 'RESULT_REVIEW'
    | 'RECONCILIATION'
    | 'RECALL'
    | 'ADMIN';
  patientId?: string;
  ownerId: string;
  originalOwnerId?: string;
  coveredById?: string;
  dueAt: string;
  priority: 'ROUTINE' | 'HIGH' | 'URGENT';
  status: TaskStatus;
  notes: string;
  linkedEntityId?: string;
}

export interface CareRecall {
  id: string;
  patientId: string;
  programmeName: string;
  eligibilityRuleSource: string;
  eligibilityRuleVersion: string;
  clinicallyGovernedApproved: boolean;
  approvedBy?: string;
  stage:
    | 'ELIGIBLE'
    | 'INVITED'
    | 'BOOKED'
    | 'ATTENDED'
    | 'INTERVENTION_RECORDED'
    | 'COMPLETED_REVIEW';
  dueDate: string;
  lastContactedAt?: string;
  interventionNote?: string;
}

export interface StaffRota {
  id: string;
  staffId: string;
  date: string;
  shift: string;
  roomId?: string;
  status: 'ON_DUTY' | 'ON_LEAVE' | 'SICK_COVER';
  coverStaffId?: string;
}

export interface ConsumableStock {
  id: string;
  itemName: string;
  category: string;
  location: string;
  quantity: number;
  unit: string;
  reorderThreshold: number;
  expiryDate: string;
}

export interface EquipmentAsset {
  id: string;
  name: string;
  roomId: string;
  serialNumber: string;
  lastCalibrated: string;
  nextMaintenanceDue: string;
  status: 'OPERATIONAL' | 'DUE_SERVICE' | 'OUT_OF_SERVICE';
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  entityType: string;
  entityId: string;
  patientId?: string;
  outcome: 'ALLOWED' | 'DENIED' | 'CONFLICT' | 'FAILED';
  summary: string;
}

export interface IntegrationEvent {
  id: string;
  adapter:
    | 'EPS_SIM'
    | 'ERS_SIM'
    | 'VIDEO_SIM'
    | 'PDS_SIM'
    | 'NHS_PATIENT_APP_SIM';
  eventType: string;
  idempotencyKey: string;
  status: 'PENDING' | 'DELIVERED' | 'FAILED';
  attempts: number;
  payloadSummary: string;
  createdAt: string;
  lastError?: string;
}

export interface PatientPortalMessage {
  id: string;
  patientId: string;
  fromStaffName: string;
  sentAt: string;
  subject: string;
  body: string;
  releasedByStaffId: string;
}

export interface PatientPortalSubmission {
  id: string;
  patientId: string;
  type:
    | 'APPOINTMENT_REQUEST'
    | 'CANCELLATION'
    | 'REPEAT_MEDICATION'
    | 'CONTACT_UPDATE';
  detail: string;
  submittedAt: string;
  status: 'RECEIVED' | 'PROCESSED';
}

export interface PracticeConfig {
  practiceName: string;
  odsCode: string;
  postcode: string;
  aiAssistEnabled: boolean;
  simulatePrescribingFailure: boolean;
  simulateReferralFailure: boolean;
  automatedRecallSchedulingApproved: boolean;
  recallGovernanceSignOffBy: string;
  urgentSignpostingBanner: string;
  reminderLeadHours: number;
}

export interface PracticeState {
  config: PracticeConfig;
  staff: StaffMember[];
  rooms: Room[];
  recurringClinics: RecurringClinic[];
  patients: Patient[];
  proxyRelationships: ProxyRelationship[];
  duplicateCandidates: DuplicateCandidate[];
  appointments: Appointment[];
  waitingList: WaitingListEntry[];
  requests: IncomingRequest[];
  consultations: ConsultationNote[];
  prescriptions: PrescriptionRequest[];
  results: LabResult[];
  referrals: Referral[];
  documents: IncomingDocument[];
  tasks: PracticeTask[];
  recalls: CareRecall[];
  rotas: StaffRota[];
  consumables: ConsumableStock[];
  equipment: EquipmentAsset[];
  auditEvents: AuditEvent[];
  integrationEvents: IntegrationEvent[];
  patientMessages: PatientPortalMessage[];
  patientSubmissions: PatientPortalSubmission[];
  processedIdempotencyKeys: Record<string, unknown>;
  emergencyAccessGrants: Record<
    string,
    { staffId: string; reason: string; grantedAt: string; expiresAt: string }[]
  >;
}
