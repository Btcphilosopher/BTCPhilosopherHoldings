import React from 'react';
import { ShieldAlert, User, X } from 'lucide-react';
import type { ClinicalDataState, AllergyRecord } from '../types/clinical';

interface PatientContextBarProps {
  patient: Record<string, unknown> | null;
  activeAppointmentId?: string | null;
  onClearPatient: () => void;
  onRequestBreakGlass?: (patientId: string) => void;
}

function renderAllergySummary(allergiesState: unknown): {
  label: string;
  tone: 'warning' | 'ok' | 'muted';
} {
  if (!allergiesState || typeof allergiesState !== 'object') {
    return { label: 'Allergies: Restricted / Reception Scope', tone: 'muted' };
  }
  const st = allergiesState as ClinicalDataState<AllergyRecord[]>;
  switch (st.state) {
    case 'RECORDED':
      return {
        label: `Allergies (${st.value.length}): ${st.value.map((a) => `${a.substance} (${a.severity})`).join(', ')}`,
        tone: 'warning',
      };
    case 'EXPLICITLY_ABSENT':
      return {
        label: 'Allergies: Explicitly Absent (NKDA confirmed)',
        tone: 'ok',
      };
    case 'UNKNOWN':
      return {
        label: 'Allergies: Unknown (patient uncertain — verify)',
        tone: 'warning',
      };
    case 'NOT_ASSESSED':
      return {
        label: 'Allergies: Not Yet Assessed',
        tone: 'warning',
      };
  }
}

export const PatientContextBar: React.FC<PatientContextBarProps> = ({
  patient,
  activeAppointmentId,
  onClearPatient,
  onRequestBreakGlass,
}) => {
  if (!patient) return null;

  const isRedacted = Boolean(patient.clinicalRedacted);
  const requiresEmergency = Boolean(patient.requiresEmergencyAccess);
  const allergy = renderAllergySummary(patient.allergiesState);

  return (
    <section
      aria-label="Active Patient Context"
      className="bg-white border-b border-[#D8DDE0] px-6 py-3 flex flex-wrap items-center justify-between gap-4"
    >
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
        <div className="flex items-center gap-2 font-bold text-[#003087]">
          <User className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{String(patient.fullName)}</span>
        </div>
        <span className="text-[#4C6272] tabular-nums">
          DOB: <strong className="font-semibold text-[#212B32]">{String(patient.dateOfBirth)}</strong>
        </span>
        <span className="text-[#4C6272]" aria-hidden="true">·</span>
        <span className="text-[#4C6272] font-mono text-xs tabular-nums">
          NHS {String(patient.nhsNumber)} ({String(patient.nhsVerificationStatus)})
        </span>
        <span className="text-[#4C6272]" aria-hidden="true">·</span>
        <span className="text-xs text-[#4C6272]">Sex: {String(patient.sex)}</span>
        <span className="text-[#4C6272]" aria-hidden="true">·</span>
        <span
          className={`text-xs font-semibold ${
            allergy.tone === 'warning'
              ? 'text-[#B45309]'
              : allergy.tone === 'ok'
                ? 'text-[#00703C]'
                : 'text-[#4C6272]'
          }`}
        >
          {allergy.label}
        </span>
        {activeAppointmentId && (
          <>
            <span className="text-[#4C6272]" aria-hidden="true">·</span>
            <span className="text-xs font-semibold text-[#005EB8]">
              Encounter: {activeAppointmentId}
            </span>
          </>
        )}
      </div>

      <div className="flex items-center gap-3 shrink-0">
        {isRedacted && requiresEmergency && onRequestBreakGlass && (
          <button
            type="button"
            onClick={() => onRequestBreakGlass(String(patient.id))}
            className="px-3 py-1.5 text-xs font-semibold bg-[#D5281B] text-white hover:bg-[#B01F14] flex items-center gap-1.5 whitespace-nowrap"
          >
            <ShieldAlert className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Break-Glass Access</span>
          </button>
        )}
        <button
          type="button"
          onClick={onClearPatient}
          className="px-2.5 py-1.5 text-xs font-medium border border-[#D8DDE0] bg-[#F0F4F5] text-[#212B32] hover:bg-[#E5EAEC] flex items-center gap-1 whitespace-nowrap"
        >
          <X className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Clear Context</span>
        </button>
      </div>
    </section>
  );
};
