import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ClipboardList,
  Lock,
  Sparkles,
  WifiOff,
  FileWarning,
} from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import type { ConsultationNote } from '../../types/clinical';
import { api } from '../../api/client';

export interface OfflineQueuedDraft {
  queueId: string;
  patientId: string;
  noteId?: string;
  expectedVersion?: number;
  templateName: string;
  presentingConcern: string;
  historyText: string;
  examinationText: string;
  assessmentText: string;
  planText: string;
  observationsSnapshot: string;
  queuedAt: string;
}

interface ConsultationsViewProps {
  workspace: ScopedWorkspacePayload;
  selectedPatientId: string | null;
  activeAppointmentId: string | null;
  offlineMode: boolean;
  offlineQueue: OfflineQueuedDraft[];
  onQueueOfflineDraft: (draft: OfflineQueuedDraft) => void;
  onSyncOfflineQueue: () => Promise<void>;
  onRefresh: () => Promise<void>;
  onSelectPatient: (id: string) => void;
}

const TEMPLATES: Record<
  string,
  { concern: string; history: string; exam: string; assessment: string; plan: string }
> = {
  'GP Chronic Disease & Acute Review': {
    concern: '',
    history: 'Medication adherence checked. Red flags screened.',
    exam: 'Observations reviewed. Targeted physical exam:',
    assessment: '',
    plan: 'Safety-netting provided. Follow-up arranged.',
  },
  'Acute Same-Day Consultation': {
    concern: '',
    history: 'Onset, duration, severity, and systemic symptoms:',
    exam: 'Vital signs and system examination:',
    assessment: 'Working clinical impression:',
    plan: 'Management, prescriptions, and clear worsening advice:',
  },
  'Nurse Long-Term Condition Review': {
    concern: 'Annual long-term condition review',
    history: 'Symptoms, inhaler/medication technique, lifestyle:',
    exam: 'BP, weight, foot/respiratory check:',
    assessment: 'Care plan goals reviewed:',
    plan: 'Next recall interval confirmed.',
  },
};

export const ConsultationsView: React.FC<ConsultationsViewProps> = ({
  workspace,
  selectedPatientId,
  activeAppointmentId,
  offlineMode,
  offlineQueue,
  onQueueOfflineDraft,
  onSyncOfflineQueue,
  onRefresh,
  onSelectPatient,
}) => {
  const isClinician =
    workspace.viewer.role === 'GP' || workspace.viewer.role === 'NURSE';

  const patient =
    workspace.patients.find((p) => p.id === selectedPatientId) ??
    workspace.patients[0];
  const patId = patient ? String(patient.id) : '';

  const patientNotes = workspace.consultations.filter((c) => c.patientId === patId);
  const existingDraft = patientNotes.find((c) => c.status === 'DRAFT');

  const [draftId, setDraftId] = useState<string | undefined>(existingDraft?.id);
  const [draftVersion, setDraftVersion] = useState<number | undefined>(
    existingDraft?.version
  );
  const [templateName, setTemplateName] = useState<string>(
    existingDraft?.templateName || 'GP Chronic Disease & Acute Review'
  );
  const [presentingConcern, setPresentingConcern] = useState(
    existingDraft?.presentingConcern || ''
  );
  const [historyText, setHistoryText] = useState(existingDraft?.historyText || '');
  const [examinationText, setExaminationText] = useState(
    existingDraft?.examinationText || ''
  );
  const [assessmentText, setAssessmentText] = useState(
    existingDraft?.assessmentText || ''
  );
  const [planText, setPlanText] = useState(existingDraft?.planText || '');
  const [observationsSnapshot, setObservationsSnapshot] = useState(
    existingDraft?.observationsSnapshot || ''
  );
  const [attachmentLabel, setAttachmentLabel] = useState('');
  const [reviewOpen, setReviewOpen] = useState(false);
  const [amendReason, setAmendReason] = useState('');
  const [amendText, setAmendText] = useState('');
  const [eieReason, setEieReason] = useState('');
  const [conflictState, setConflictState] = useState<{
    message: string;
    serverDraft?: ConsultationNote;
  } | null>(null);
  const [aiDraft, setAiDraft] = useState<{
    draftText: string;
    sourceCitations: string[];
    humanReviewWarning: string;
  } | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'error'; text: string } | null>(
    null
  );
  const [busy, setBusy] = useState(false);

  // CRITICAL PATIENT ISOLATION: Reset all draft fields & attachments immediately when switching patients!
  useEffect(() => {
    const nextDraft = workspace.consultations.find(
      (c) => c.patientId === patId && c.status === 'DRAFT'
    );
    setDraftId(nextDraft?.id);
    setDraftVersion(nextDraft?.version);
    setTemplateName(nextDraft?.templateName || 'GP Chronic Disease & Acute Review');
    setPresentingConcern(nextDraft?.presentingConcern || '');
    setHistoryText(nextDraft?.historyText || '');
    setExaminationText(nextDraft?.examinationText || '');
    setAssessmentText(nextDraft?.assessmentText || '');
    setPlanText(nextDraft?.planText || '');
    setObservationsSnapshot(nextDraft?.observationsSnapshot || '');
    setAttachmentLabel('');
    setConflictState(null);
    setAiDraft(null);
    setReviewOpen(false);
  }, [patId, workspace.consultations.length]);

  if (!isClinician) {
    return (
      <div className="bg-white border border-[#D8DDE0] p-8 text-sm text-[#4C6272]">
        <h2 className="text-lg font-bold text-[#212B32]">Consultation Workspace Restricted</h2>
        <p className="mt-2">
          Server policy restricts clinical consultation authoring and full clinical summaries to
          authorised clinicians (GPs and Practice Nurses). Reception and administrative staff access
          demographics, appointments, and incoming requests through scoped views.
        </p>
      </div>
    );
  }

  if (!patient) return null;

  if (patient.clinicalRedacted) {
    return (
      <div className="bg-white border border-[#D5281B] p-6 space-y-3 text-sm">
        <div className="font-bold text-[#991B1B] flex items-center gap-2">
          <Lock className="w-4 h-4" aria-hidden="true" />
          <span>Restricted Record — Clinical Consultation Locked</span>
        </div>
        <p className="text-[#4C6272]">
          {String(patient.restrictionReason || 'Sensitive record restricted.')} Use the Break-Glass
          Access button in the top patient bar or Patients tab with a documented clinical reason.
        </p>
      </div>
    );
  }

  const handleApplyTemplate = (name: string) => {
    setTemplateName(name);
    const tpl = TEMPLATES[name];
    if (tpl) {
      if (!presentingConcern) setPresentingConcern(tpl.concern);
      if (!historyText) setHistoryText(tpl.history);
      if (!examinationText) setExaminationText(tpl.exam);
      if (!assessmentText) setAssessmentText(tpl.assessment);
      if (!planText) setPlanText(tpl.plan);
    }
  };

  const handleSaveDraft = async (overrideExpectedVersion?: number) => {
    setFeedback(null);
    setConflictState(null);

    if (offlineMode) {
      onQueueOfflineDraft({
        queueId: `q-${Date.now()}`,
        patientId: patId,
        noteId: draftId,
        expectedVersion: overrideExpectedVersion ?? draftVersion,
        templateName,
        presentingConcern,
        historyText,
        examinationText,
        assessmentText,
        planText,
        observationsSnapshot,
        queuedAt: new Date().toISOString(),
      });
      setFeedback({
        type: 'ok',
        text: 'Offline mode active: draft saved locally in permitted Room-style offline queue pending sync.',
      });
      return;
    }

    setBusy(true);
    try {
      const saved = (await api.saveConsultationDraft({
        id: draftId,
        patientId: patId,
        appointmentId: activeAppointmentId || undefined,
        expectedVersion: overrideExpectedVersion ?? draftVersion,
        templateName,
        presentingConcern,
        historyText,
        examinationText,
        assessmentText,
        planText,
        observationsSnapshot,
      })) as ConsultationNote;
      setDraftId(saved.id);
      setDraftVersion(saved.version);
      await onRefresh();
      setFeedback({
        type: 'ok',
        text: `Consultation draft autosaved (v${saved.version}) for ${String(patient.fullName)}.`,
      });
    } catch (err: any) {
      if (err.code === 'VERSION_CONFLICT') {
        setConflictState({
          message: err.message,
          serverDraft: err.details?.serverDraft as ConsultationNote | undefined,
        });
      } else {
        setFeedback({ type: 'error', text: err.message });
      }
    } finally {
      setBusy(false);
    }
  };

  const handleSignNote = async () => {
    if (!draftId || draftVersion === undefined) {
      setFeedback({
        type: 'error',
        text: 'Save draft to the server before signing.',
      });
      return;
    }
    if (offlineMode) {
      setFeedback({
        type: 'error',
        text: 'Server validation is mandatory before final signing. Reconnect to sign.',
      });
      return;
    }
    setBusy(true);
    setFeedback(null);
    try {
      await api.signConsultationNote(draftId, draftVersion);
      await onRefresh();
      setReviewOpen(false);
      setDraftId(undefined);
      setDraftVersion(undefined);
      setFeedback({
        type: 'ok',
        text: 'Consultation note signed immutably. Future changes require a linked amendment.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  const handleSimulateConcurrentConflict = async () => {
    if (!draftId) {
      setFeedback({ type: 'error', text: 'Select Margaret Thornton (with draft con-301) or save a draft first.' });
      return;
    }
    // Simulate a stale local version (-1) to demonstrate server optimistic concurrency check
    await handleSaveDraft(Math.max(1, (draftVersion || 2) - 1));
  };

  const handleAmend = async (noteId: string) => {
    try {
      await api.amendConsultationNote(noteId, amendReason, amendText);
      await onRefresh();
      setAmendReason('');
      setAmendText('');
      setFeedback({ type: 'ok', text: 'Linked amendment appended to immutable signed note.' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleEie = async (noteId: string) => {
    try {
      await api.markEnteredInError(noteId, eieReason);
      await onRefresh();
      setEieReason('');
      setFeedback({ type: 'ok', text: 'Note marked Entered-in-Error with full history retained.' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleAiAssist = async () => {
    setBusy(true);
    setFeedback(null);
    try {
      const res = await api.requestAiAssist({
        mode: 'CONSULTATION_DRAFT',
        patientId: patId,
        contextNote: `Presenting: ${presentingConcern}\nHistory: ${historyText}\nPlan: ${planText}`,
      });
      setAiDraft(res);
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  const patResults = workspace.results.filter((r) => r.patientId === patId);
  const patRecalls = workspace.recalls.filter((r) => r.patientId === patId);
  const patTasks = workspace.tasks.filter((t) => t.patientId === patId && t.status !== 'COMPLETED');

  return (
    <div className="space-y-6">
      {/* Patient Selector & Offline Status */}
      <div className="bg-white border border-[#D8DDE0] p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <label htmlFor="consult-patient" className="text-xs font-bold text-[#4C6272]">
            Active Patient Record:
          </label>
          <select
            id="consult-patient"
            value={patId}
            onChange={(e) => onSelectPatient(e.target.value)}
            className="border border-[#768692] bg-white px-3 py-1.5 text-sm font-semibold"
          >
            {workspace.patients.map((p) => (
              <option key={String(p.id)} value={String(p.id)}>
                {String(p.fullName)} (DOB {String(p.dateOfBirth)})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-3 text-xs">
          {offlineMode && (
            <span className="font-semibold text-[#D5281B] flex items-center gap-1">
              <WifiOff className="w-3.5 h-3.5" aria-hidden="true" />
              Offline Mode Active
            </span>
          )}
          {offlineQueue.length > 0 && (
            <button
              type="button"
              onClick={() => void onSyncOfflineQueue()}
              disabled={offlineMode}
              className="px-3 py-1.5 bg-[#B45309] text-white font-semibold disabled:opacity-50"
            >
              Sync {offlineQueue.length} Queued Draft(s)
            </button>
          )}
        </div>
      </div>

      {feedback && (
        <div
          role="alert"
          className={`p-3.5 border text-sm flex items-start gap-2 ${
            feedback.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          {feedback.type === 'error' ? (
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {conflictState && (
        <div className="bg-[#FDF2F2] border border-[#D5281B] p-4 space-y-2 text-xs">
          <div className="font-bold text-[#991B1B] flex items-center gap-2">
            <FileWarning className="w-4 h-4" aria-hidden="true" />
            <span>Concurrent Edit Conflict Detected</span>
          </div>
          <p className="text-[#7F1D1D]">{conflictState.message}</p>
          {conflictState.serverDraft && (
            <div className="p-2.5 bg-white border border-[#D8DDE0] text-[#212B32]">
              <strong>Server v{conflictState.serverDraft.version} Plan:</strong>{' '}
              {conflictState.serverDraft.planText}
            </div>
          )}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => {
                if (conflictState.serverDraft) {
                  setDraftVersion(conflictState.serverDraft.version);
                  setConflictState(null);
                  setFeedback({
                    type: 'ok',
                    text: `Rebased local draft onto server v${conflictState.serverDraft.version}. Review and save again.`,
                  });
                }
              }}
              className="px-3 py-1.5 bg-[#005EB8] text-white font-semibold"
            >
              Rebase onto Server Version & Keep My Edits
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Clinical Summary Rail */}
        <aside className="lg:col-span-4 bg-white border border-[#D8DDE0] p-5 space-y-5 text-xs">
          <div>
            <h3 className="text-sm font-bold text-[#212B32]">Active Problems</h3>
            <ul className="mt-1.5 space-y-1 text-[#212B32] list-disc pl-4">
              {((patient.activeProblems as string[]) || []).length === 0 ? (
                <li className="text-[#4C6272]">None recorded</li>
              ) : (
                (patient.activeProblems as string[]).map((prob, i) => <li key={i}>{prob}</li>)
              )}
            </ul>
          </div>

          <div className="border-t border-[#D8DDE0] pt-4">
            <h3 className="text-sm font-bold text-[#212B32]">Data Completeness States</h3>
            <div className="mt-1.5 space-y-1 text-[#4C6272]">
              <div>
                <strong className="text-[#212B32]">Allergies:</strong>{' '}
                {(patient.allergiesState as any)?.state} —{' '}
                {(patient.allergiesState as any)?.detail ||
                  (patient.allergiesState as any)?.value?.map((a: any) => a.substance).join(', ')}
              </div>
              <div>
                <strong className="text-[#212B32]">Smoking:</strong>{' '}
                {(patient.smokingStatusState as any)?.state} —{' '}
                {(patient.smokingStatusState as any)?.detail ||
                  (patient.smokingStatusState as any)?.value}
              </div>
            </div>
          </div>

          <div className="border-t border-[#D8DDE0] pt-4">
            <h3 className="text-sm font-bold text-[#212B32]">Current Medications</h3>
            <div className="mt-1.5 space-y-1.5">
              {((patient.medications as any[]) || []).map((m) => (
                <div key={m.id} className="text-[#212B32]">
                  <span className="font-semibold">{m.name}</span> · {m.frequency} ({m.source})
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-[#D8DDE0] pt-4">
            <h3 className="text-sm font-bold text-[#212B32]">Observations & Recent Results</h3>
            <div className="mt-1.5 space-y-1">
              {((patient.observations as any[]) || []).map((o) => (
                <div key={o.id} className="font-mono tabular-nums text-[#212B32]">
                  {o.type}: {o.value} {o.unit} ({o.recordedAt.slice(0, 10)})
                </div>
              ))}
              {patResults.map((r) => (
                <div key={r.id} className="text-[#003087] font-mono">
                  [{r.status}] {r.testName}: {r.value} {r.unit}
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-[#D8DDE0] pt-4">
            <h3 className="text-sm font-bold text-[#212B32]">Care Plans & Outstanding Actions</h3>
            {patRecalls.map((rec) => (
              <div key={rec.id} className="mt-1 text-[#007F7F]">
                Recall: {rec.programmeName} ({rec.stage})
              </div>
            ))}
            {patTasks.map((t) => (
              <div key={t.id} className="mt-1 text-[#B45309]">
                Task: {t.title} ({t.status})
              </div>
            ))}
          </div>
        </aside>

        {/* Right Consultation Note Authoring + Immutable Signed Notes */}
        <div className="lg:col-span-8 space-y-6">
          <section className="bg-white border border-[#D8DDE0] p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#D8DDE0] pb-3">
              <div>
                <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2">
                  <ClipboardList className="w-5 h-5 text-[#005EB8]" aria-hidden="true" />
                  <span>Consultation Note Workspace</span>
                </h2>
                <div className="text-xs text-[#4C6272] mt-0.5 font-mono tabular-nums">
                  {draftId ? `Draft ${draftId} · Server v${draftVersion}` : 'New Unsaved Draft'} ·
                  Patient Lock: {patId}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  aria-label="Consultation Template"
                  value={templateName}
                  onChange={(e) => handleApplyTemplate(e.target.value)}
                  className="border border-[#768692] bg-white px-2.5 py-1.5 text-xs"
                >
                  {Object.keys(TEMPLATES).map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={handleSimulateConcurrentConflict}
                  className="px-2.5 py-1.5 text-xs border border-[#B45309] text-[#B45309] bg-[#FFFBEB]"
                >
                  Simulate Concurrent Edit
                </button>
              </div>
            </div>

            <div className="space-y-3 text-sm">
              <div>
                <label className="block text-xs font-semibold text-[#4C6272]">
                  Presenting Concern
                </label>
                <input
                  type="text"
                  value={presentingConcern}
                  onChange={(e) => setPresentingConcern(e.target.value)}
                  className="mt-1 w-full border border-[#768692] px-3 py-2 text-sm"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#4C6272]">
                    Relevant History
                  </label>
                  <textarea
                    rows={3}
                    value={historyText}
                    onChange={(e) => setHistoryText(e.target.value)}
                    className="mt-1 w-full border border-[#768692] p-2.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4C6272]">
                    Examination & Observations
                  </label>
                  <textarea
                    rows={3}
                    value={examinationText}
                    onChange={(e) => setExaminationText(e.target.value)}
                    className="mt-1 w-full border border-[#768692] p-2.5 text-sm"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#4C6272]">
                    Clinical Assessment
                  </label>
                  <textarea
                    rows={3}
                    value={assessmentText}
                    onChange={(e) => setAssessmentText(e.target.value)}
                    className="mt-1 w-full border border-[#768692] p-2.5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4C6272]">
                    Management Plan & Safety-Netting
                  </label>
                  <textarea
                    rows={3}
                    value={planText}
                    onChange={(e) => setPlanText(e.target.value)}
                    className="mt-1 w-full border border-[#768692] p-2.5 text-sm"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#4C6272]">
                    Observations Snapshot
                  </label>
                  <input
                    type="text"
                    value={observationsSnapshot}
                    onChange={(e) => setObservationsSnapshot(e.target.value)}
                    placeholder="e.g., BP 136/80 mmHg · HR 74 bpm"
                    className="mt-1 w-full border border-[#768692] px-2.5 py-1.5 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4C6272]">
                    Draft Attachment (Isolated to Patient {patId})
                  </label>
                  <input
                    type="text"
                    value={attachmentLabel}
                    onChange={(e) => setAttachmentLabel(e.target.value)}
                    placeholder="Clears automatically if patient switches"
                    className="mt-1 w-full border border-[#768692] px-2.5 py-1.5 text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Optional AI Assistance (Disabled by Default) */}
            <div className="p-3 bg-[#F8FAFB] border border-[#D8DDE0] text-xs space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 font-semibold text-[#212B32]">
                  <Sparkles className="w-3.5 h-3.5 text-[#005EB8]" aria-hidden="true" />
                  <span>
                    Optional AI Drafting Support:{' '}
                    {workspace.practice.aiAssistEnabled
                      ? 'Enabled (Human Review Mandatory)'
                      : 'Disabled by Default (Enable in Practice > Admin)'}
                  </span>
                </div>
                <button
                  type="button"
                  disabled={!workspace.practice.aiAssistEnabled || busy}
                  onClick={handleAiAssist}
                  className="px-3 py-1 bg-[#005EB8] text-white font-semibold disabled:opacity-40"
                >
                  Draft Source-Linked Summary
                </button>
              </div>
              {aiDraft && (
                <div className="p-3 bg-white border border-[#005EB8] space-y-1.5">
                  <div className="font-bold text-[#B45309]">{aiDraft.humanReviewWarning}</div>
                  <p className="text-[#212B32]">{aiDraft.draftText}</p>
                  <div className="font-mono text-[#4C6272]">
                    Sources: {aiDraft.sourceCitations?.join(', ')}
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#D8DDE0]">
              <button
                type="button"
                disabled={busy}
                onClick={() => void handleSaveDraft()}
                className="px-4 py-2 bg-[#F0F4F5] border border-[#768692] text-[#212B32] font-semibold text-sm hover:bg-[#E2E8EA]"
              >
                {offlineMode ? 'Queue Draft Offline' : 'Autosave Draft'}
              </button>
              <button
                type="button"
                disabled={busy || !draftId}
                onClick={() => setReviewOpen(true)}
                className="px-4 py-2 bg-[#005EB8] text-white font-semibold text-sm hover:bg-[#004B93] disabled:opacity-50"
              >
                Review & Sign Note Immutably
              </button>
            </div>

            {reviewOpen && (
              <div className="p-4 bg-[#EFF6FF] border border-[#005EB8] space-y-3 text-xs">
                <div className="font-bold text-[#003087]">
                  Pre-Signing Verification for {String(patient.fullName)} (v{draftVersion})
                </div>
                <p className="text-[#212B32]">
                  Once signed, this consultation record becomes immutable. Any later corrections must
                  be recorded as a linked amendment or marked entered-in-error with retained history.
                </p>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleSignNote}
                    className="px-3 py-1.5 bg-[#00703C] text-white font-semibold"
                  >
                    Confirm & Sign Immutably
                  </button>
                  <button
                    type="button"
                    onClick={() => setReviewOpen(false)}
                    className="px-3 py-1.5 border border-[#768692] bg-white"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </section>

          {/* Previous Notes, Immutable Signed Notes, Amendments, Entered-in-Error */}
          <section className="bg-white border border-[#D8DDE0] p-6 space-y-4">
            <h3 className="text-base font-bold text-[#212B32]">
              Previous Notes & Amendments ({patientNotes.length})
            </h3>
            <div className="divide-y divide-[#D8DDE0] text-xs">
              {patientNotes.map((n) => (
                <div key={n.id} className="py-4 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-bold text-sm text-[#212B32]">
                      {n.presentingConcern || n.templateName}
                    </span>
                    <span
                      className={`font-mono font-bold ${
                        n.status === 'ENTERED_IN_ERROR'
                          ? 'text-[#D5281B]'
                          : n.status === 'SIGNED' || n.status === 'AMENDED'
                            ? 'text-[#00703C]'
                            : 'text-[#B45309]'
                      }`}
                    >
                      {n.status} · v{n.version}
                    </span>
                  </div>
                  <div className="text-[#4C6272]">
                    {n.signedAt ? `Signed by ${n.signedBy} at ${n.signedAt}` : `Autosaved ${n.autosavedAt}`}
                  </div>
                  <p className="text-[#212B32]">
                    <strong>Assessment:</strong> {n.assessmentText} · <strong>Plan:</strong> {n.planText}
                  </p>
                  {n.enteredInErrorReason && (
                    <div className="p-2 bg-[#FDF2F2] border border-[#D5281B] text-[#991B1B]">
                      Entered in Error by {n.enteredInErrorBy}: {n.enteredInErrorReason} (Original text retained)
                    </div>
                  )}
                  {n.amendments.map((amd) => (
                    <div key={amd.id} className="p-2 bg-[#F8FAFB] border border-[#D8DDE0]">
                      <strong>Amendment ({amd.addedBy}):</strong> {amd.text} — <em>Reason: {amd.reason}</em>
                    </div>
                  ))}
                  {(n.status === 'SIGNED' || n.status === 'AMENDED') && (
                    <div className="pt-2 flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        value={amendReason}
                        onChange={(e) => setAmendReason(e.target.value)}
                        placeholder="Amendment reason"
                        className="border border-[#768692] px-2 py-1"
                      />
                      <input
                        type="text"
                        value={amendText}
                        onChange={(e) => setAmendText(e.target.value)}
                        placeholder="Linked addendum text"
                        className="flex-1 min-w-[180px] border border-[#768692] px-2 py-1"
                      />
                      <button
                        type="button"
                        onClick={() => handleAmend(n.id)}
                        className="px-2.5 py-1 bg-[#005EB8] text-white font-semibold"
                      >
                        Append Amendment
                      </button>
                      <input
                        type="text"
                        value={eieReason}
                        onChange={(e) => setEieReason(e.target.value)}
                        placeholder="Entered-in-error reason"
                        className="border border-[#D5281B] px-2 py-1"
                      />
                      <button
                        type="button"
                        onClick={() => handleEie(n.id)}
                        className="px-2.5 py-1 border border-[#D5281B] text-[#D5281B] font-semibold"
                      >
                        Mark Entered-in-Error
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
