import React, { useState } from 'react';
import { Pill, AlertCircle, CheckCircle2, Send } from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import { api } from '../../api/client';

interface PrescriptionsViewProps {
  workspace: ScopedWorkspacePayload;
  onRefresh: () => Promise<void>;
}

export const PrescriptionsView: React.FC<PrescriptionsViewProps> = ({
  workspace,
  onRefresh,
}) => {
  const [patientId, setPatientId] = useState(
    String(workspace.patients[0]?.id ?? 'pat-margaret')
  );
  const [medName, setMedName] = useState('Atorvastatin 20mg tablets');
  const [dose, setDose] = useState('20mg');
  const [route, setRoute] = useState('Oral');
  const [frequency, setFrequency] = useState('Once nightly');
  const [quantity, setQuantity] = useState('28 tablets');
  const [forceEpsFail, setForceEpsFail] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'error'; text: string } | null>(
    null
  );

  const isClinician =
    workspace.viewer.role === 'GP' || workspace.viewer.role === 'NURSE';

  const getPatientName = (id: string) =>
    String(workspace.patients.find((p) => p.id === id)?.fullName ?? id);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await api.createPrescription({
        patientId,
        medicationName: medName,
        dose,
        route,
        frequency,
        quantity,
        source: isClinician ? 'CLINICIAN_INITIATED' : 'PHARMACY_POD',
      });
      await onRefresh();
      setFeedback({ type: 'ok', text: 'Prescription request added in REQUESTED state.' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleReview = async (
    id: string,
    decision: 'UNDER_REVIEW' | 'APPROVED' | 'DECLINED'
  ) => {
    setFeedback(null);
    try {
      await api.reviewPrescription(
        id,
        decision,
        `Clinician decision (${decision}) by ${workspace.viewer.name}`
      );
      await onRefresh();
      setFeedback({
        type: 'ok',
        text: `Prescription ${id} marked ${decision}. Approval does NOT transmit or dispense automatically.`,
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleTransmitEps = async (id: string) => {
    setFeedback(null);
    try {
      const rx = (await api.submitPrescriptionEps(
        id,
        `eps-${id}-${Date.now()}`,
        forceEpsFail
      )) as any;
      await onRefresh();
      if (rx.status === 'FAILED') {
        setFeedback({
          type: 'error',
          text: rx.epsError || 'EPS transmission failed.',
        });
      } else {
        setFeedback({
          type: 'ok',
          text: `Simulated EPS transmission confirmed (${rx.epsMessageId}).`,
        });
      }
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  return (
    <div className="space-y-6">
      {feedback && (
        <div
          role="alert"
          className={`p-3.5 border text-sm flex items-start gap-2 ${
            feedback.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          {feedback.type === 'error' ? (
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-white border border-[#D8DDE0] p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D8DDE0] pb-4">
            <div>
              <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2">
                <Pill className="w-5 h-5 text-[#007F7F]" aria-hidden="true" />
                <span>Prescriptions & Simulated EPS Transmission</span>
              </h2>
              <p className="text-xs text-[#4C6272] mt-0.5">
                States kept strictly separate: Requested → Under review → Approved/Declined → Submitted to EPS → Confirmed/Failed.
              </p>
            </div>
            <label className="flex items-center gap-2 text-xs font-semibold text-[#D5281B]">
              <input
                type="checkbox"
                checked={forceEpsFail}
                onChange={(e) => setForceEpsFail(e.target.checked)}
              />
              <span>Simulate EPS Gateway Failure</span>
            </label>
          </div>

          <div className="mt-4 divide-y divide-[#D8DDE0]">
            {workspace.prescriptions.map((rx) => (
              <div key={rx.id} className="py-4 space-y-2.5 text-sm">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="font-bold text-[#212B32]">
                      {getPatientName(rx.patientId)} — {rx.medicationName}
                    </div>
                    <div className="text-xs text-[#4C6272] mt-0.5">
                      {rx.dose} · {rx.route} · {rx.frequency} · Qty: {rx.quantity} · Source:{' '}
                      {rx.source}
                    </div>
                    <div className="text-xs text-[#4C6272] mt-0.5">
                      Reconciliation:{' '}
                      <strong
                        className={
                          rx.reconciliationStatus === 'HOSPITAL_DISCHARGE_PENDING'
                            ? 'text-[#B45309]'
                            : 'text-[#00703C]'
                        }
                      >
                        {rx.reconciliationStatus}
                      </strong>
                      {rx.reviewedBy ? ` · Reviewed by ${rx.reviewedBy}` : ''}
                    </div>
                    {rx.epsMessageId && (
                      <div className="text-xs font-mono text-[#00703C] mt-1">
                        EPS Token: {rx.epsMessageId}
                      </div>
                    )}
                    {rx.epsError && (
                      <div className="text-xs text-[#D5281B] mt-1">{rx.epsError}</div>
                    )}
                  </div>

                  <span
                    className={`font-mono text-xs font-bold ${
                      rx.status === 'CONFIRMED'
                        ? 'text-[#00703C]'
                        : rx.status === 'FAILED' || rx.status === 'DECLINED'
                          ? 'text-[#D5281B]'
                          : 'text-[#005EB8]'
                    }`}
                  >
                    {rx.status}
                  </span>
                </div>

                {isClinician && (
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    {rx.status === 'REQUESTED' && (
                      <button
                        type="button"
                        onClick={() => handleReview(rx.id, 'UNDER_REVIEW')}
                        className="px-2.5 py-1 border border-[#768692] bg-[#F8FAFB]"
                      >
                        Start Review
                      </button>
                    )}
                    {(rx.status === 'REQUESTED' || rx.status === 'UNDER_REVIEW') && (
                      <>
                        <button
                          type="button"
                          onClick={() => handleReview(rx.id, 'APPROVED')}
                          className="px-3 py-1 bg-[#00703C] text-white font-semibold"
                        >
                          Approve Locally
                        </button>
                        <button
                          type="button"
                          onClick={() => handleReview(rx.id, 'DECLINED')}
                          className="px-2.5 py-1 border border-[#D5281B] text-[#D5281B] font-semibold"
                        >
                          Decline
                        </button>
                      </>
                    )}
                    {(rx.status === 'APPROVED' || rx.status === 'FAILED') && (
                      <button
                        type="button"
                        onClick={() => handleTransmitEps(rx.id)}
                        className="px-3 py-1 bg-[#005EB8] text-white font-semibold flex items-center gap-1"
                      >
                        <Send className="w-3 h-3" aria-hidden="true" />
                        <span>
                          {rx.status === 'FAILED'
                            ? 'Retry Simulated EPS Transmission'
                            : 'Submit to Simulated EPS'}
                        </span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Request Repeat Medication */}
        <div className="lg:col-span-4 bg-white border border-[#D8DDE0] p-6">
          <h3 className="text-base font-bold text-[#212B32]">Log Repeat Medication Request</h3>
          <p className="text-xs text-[#4C6272] mt-1">
            No automated dosing recommendations or unverified interaction assurances are generated.
          </p>
          <form onSubmit={handleCreate} className="mt-4 space-y-3 text-sm">
            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">Patient</label>
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="mt-1 w-full border border-[#768692] bg-white px-2.5 py-2 text-sm"
              >
                {workspace.patients.map((p) => (
                  <option key={String(p.id)} value={String(p.id)}>
                    {String(p.fullName)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">Medication</label>
              <input
                type="text"
                required
                value={medName}
                onChange={(e) => setMedName(e.target.value)}
                className="mt-1 w-full border border-[#768692] px-2.5 py-2 text-sm"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={dose}
                onChange={(e) => setDose(e.target.value)}
                placeholder="Dose"
                className="border border-[#768692] px-2.5 py-1.5 text-xs"
              />
              <input
                type="text"
                value={route}
                onChange={(e) => setRoute(e.target.value)}
                placeholder="Route"
                className="border border-[#768692] px-2.5 py-1.5 text-xs"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={frequency}
                onChange={(e) => setFrequency(e.target.value)}
                placeholder="Frequency"
                className="border border-[#768692] px-2.5 py-1.5 text-xs"
              />
              <input
                type="text"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="Quantity"
                className="border border-[#768692] px-2.5 py-1.5 text-xs"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 bg-[#007F7F] hover:bg-[#006464] text-white font-semibold text-sm"
            >
              Create Prescription Request
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
