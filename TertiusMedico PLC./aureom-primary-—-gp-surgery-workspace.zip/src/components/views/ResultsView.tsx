import React, { useState } from 'react';
import { FlaskConical, CheckCircle2, AlertCircle, Eye } from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import { api } from '../../api/client';

interface ResultsViewProps {
  workspace: ScopedWorkspacePayload;
  onRefresh: () => Promise<void>;
}

export const ResultsView: React.FC<ResultsViewProps> = ({ workspace, onRefresh }) => {
  const isClinician =
    workspace.viewer.role === 'GP' || workspace.viewer.role === 'NURSE';
  const [followUpText, setFollowUpText] = useState(
    'Reviewed corrected HbA1c; patient contacted to adjust diabetes review plan.'
  );
  const [commSummary, setCommSummary] = useState(
    'Telephoned patient and explained updated HbA1c result and follow-up blood test.'
  );
  const [createTask, setCreateTask] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'error'; text: string } | null>(
    null
  );

  if (!isClinician) {
    return (
      <div className="bg-white border border-[#D8DDE0] p-8 text-sm text-[#4C6272]">
        <h2 className="text-lg font-bold text-[#212B32]">Pathology Results Inbox Restricted</h2>
        <p className="mt-2">
          Clinical pathology results are restricted to GPs and authorised clinical staff.
        </p>
      </div>
    );
  }

  const getPatientName = (id: string) =>
    String(workspace.patients.find((p) => p.id === id)?.fullName ?? id);
  const getStaffName = (id: string) =>
    workspace.staff.find((s) => s.id === id)?.name ?? id;

  const handleView = async (id: string) => {
    setFeedback(null);
    try {
      await api.viewResult(id);
      await onRefresh();
      setFeedback({
        type: 'ok',
        text: 'Result marked Viewed. Viewing does NOT automatically acknowledge or action the result.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleAction = async (id: string) => {
    setFeedback(null);
    try {
      await api.actionResult(id, {
        followUpAction: followUpText,
        patientCommunicationSummary: commSummary,
        communicationChannel: 'TELEPHONE',
        createFollowUpTask: createTask,
      });
      await onRefresh();
      setFeedback({
        type: 'ok',
        text: 'Result acknowledged, actioned, and patient communication recorded.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleSimulateCorrected = async (id: string) => {
    setFeedback(null);
    try {
      await api.ingestCorrectedResult(
        id,
        'K+ 5.7 / CrCl 51',
        'Pathology lab issued corrected assay (links to prior version and routes to cover GP if reviewer absent).'
      );
      await onRefresh();
      setFeedback({
        type: 'ok',
        text: 'Corrected pathology report ingested, linked to prior report, and routed for review.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  return (
    <div className="space-y-6">
      {feedback && (
        <div
          role="alert"
          className={`p-3.5 border text-sm flex items-start gap-2 ${
            feedback.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          {feedback.type === 'error' ? (
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      <div className="bg-white border border-[#D8DDE0] p-6 space-y-4">
        <div className="border-b border-[#D8DDE0] pb-4">
          <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-[#005EB8]" aria-hidden="true" />
            <span>Pathology Results & Follow-Up Inbox</span>
          </h2>
          <p className="text-xs text-[#4C6272] mt-0.5">
            Corrected reports link to prior versions and re-route for review. A viewed result is never auto-actioned.
          </p>
        </div>

        {/* Action Template Inputs */}
        <div className="p-4 bg-[#F8FAFB] border border-[#D8DDE0] grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-[#4C6272]">Follow-Up Action Note</label>
            <input
              type="text"
              value={followUpText}
              onChange={(e) => setFollowUpText(e.target.value)}
              className="mt-1 w-full border border-[#768692] bg-white px-2.5 py-1.5"
            />
          </div>
          <div>
            <label className="block font-semibold text-[#4C6272]">
              Patient Communication Summary (Optional)
            </label>
            <input
              type="text"
              value={commSummary}
              onChange={(e) => setCommSummary(e.target.value)}
              className="mt-1 w-full border border-[#768692] bg-white px-2.5 py-1.5"
            />
          </div>
          <label className="flex items-center gap-2 col-span-full">
            <input
              type="checkbox"
              checked={createTask}
              onChange={(e) => setCreateTask(e.target.checked)}
            />
            <span>Create linked follow-up task (auto-routes to cover clinician if owner on leave)</span>
          </label>
        </div>

        <div className="divide-y divide-[#D8DDE0]">
          {workspace.results.map((res) => (
            <div key={res.id} className="py-4 space-y-2.5 text-sm">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#4C6272]">
                    <span className="font-mono font-bold text-[#212B32]">{res.id}</span>
                    <span>· {res.sourceLab}</span>
                    <span>· Collected {res.collectedAt.slice(0, 16).replace('T', ' ')}</span>
                    {res.previousVersionId && (
                      <span className="font-semibold text-[#B45309]">
                        · Supersedes {res.previousVersionId}
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-bold text-[#212B32] mt-1">
                    {getPatientName(res.patientId)} — {res.testName}
                  </h3>
                  <div className="mt-1 font-mono tabular-nums text-sm">
                    <strong>
                      {res.value} {res.unit}
                    </strong>{' '}
                    <span className="text-xs text-[#4C6272]">
                      (Ref: {res.referenceInterval} · Flag: {res.abnormalFlag})
                    </span>
                  </div>
                  {res.correctionNote && (
                    <div className="mt-1 text-xs text-[#B45309]">
                      Correction Note: {res.correctionNote}
                    </div>
                  )}
                  <div className="mt-1 text-xs text-[#4C6272]">
                    Reviewer: {getStaffName(res.assignedReviewerId)} · Viewed:{' '}
                    {res.viewedAt ? `${res.viewedBy} (${res.viewedAt.slice(0, 16)})` : 'Not viewed'} ·
                    Acknowledged: {res.acknowledgedAt ? res.acknowledgedBy : 'Pending'}
                  </div>
                  {res.patientCommunicationHistory.length > 0 && (
                    <div className="mt-1 text-xs text-[#00703C]">
                      Patient Comms: {res.patientCommunicationHistory.map((c) => c.summary).join(' | ')}
                    </div>
                  )}
                </div>

                <div className="text-right text-xs font-mono font-bold shrink-0">
                  <div
                    className={
                      res.status === 'CORRECTED' ? 'text-[#B45309]' : 'text-[#005EB8]'
                    }
                  >
                    {res.status}
                  </div>
                  <div className={res.actioned ? 'text-[#00703C]' : 'text-[#D5281B]'}>
                    {res.actioned ? 'ACTIONED' : 'UNACTIONED'}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs">
                {!res.viewedAt && (
                  <button
                    type="button"
                    onClick={() => handleView(res.id)}
                    className="px-2.5 py-1.5 border border-[#768692] bg-[#F8FAFB] flex items-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Mark Viewed (Does Not Action)</span>
                  </button>
                )}
                {!res.actioned && (
                  <button
                    type="button"
                    onClick={() => handleAction(res.id)}
                    className="px-3 py-1.5 bg-[#005EB8] text-white font-semibold hover:bg-[#004B93]"
                  >
                    Acknowledge & Action Result
                  </button>
                )}
                {res.status === 'FINAL' && (
                  <button
                    type="button"
                    onClick={() => handleSimulateCorrected(res.id)}
                    className="px-2.5 py-1.5 border border-[#B45309] text-[#B45309] bg-[#FFFBEB]"
                  >
                    Simulate Lab Corrected Report
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
