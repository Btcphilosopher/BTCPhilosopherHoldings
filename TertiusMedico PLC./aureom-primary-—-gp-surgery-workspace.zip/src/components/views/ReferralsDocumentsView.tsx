import React, { useState } from 'react';
import { FileText, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import { api } from '../../api/client';

interface ReferralsDocumentsViewProps {
  mode: 'Referrals' | 'Documents';
  workspace: ScopedWorkspacePayload;
  onRefresh: () => Promise<void>;
}

export const ReferralsDocumentsView: React.FC<ReferralsDocumentsViewProps> = ({
  mode,
  workspace,
  onRefresh,
}) => {
  const isClinician =
    workspace.viewer.role === 'GP' || workspace.viewer.role === 'NURSE';
  const [patientId, setPatientId] = useState(
    String(workspace.patients[0]?.id ?? 'pat-dorothy')
  );
  const [specialty, setSpecialty] = useState('Cardiology (Rapid Access Chest Pain / AF)');
  const [urgency, setUrgency] = useState<'ROUTINE' | 'URGENT' | 'TWO_WEEK_WAIT'>('URGENT');
  const [clinicalSummary, setClinicalSummary] = useState('');
  const [forceErsFail, setForceErsFail] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'error'; text: string } | null>(
    null
  );

  const getPatientName = (id?: string) =>
    id
      ? String(workspace.patients.find((p) => p.id === id)?.fullName ?? id)
      : 'Unmatched';

  const handleCreateReferral = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await api.advanceReferral({
        patientId,
        specialty,
        urgency,
        clinicalSummary,
        action: 'SAVE_DRAFT',
      });
      await onRefresh();
      setClinicalSummary('');
      setFeedback({ type: 'ok', text: 'Referral draft created (separate from transmission).' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleReferralAction = async (
    referralId: string,
    action: 'CLINICAL_REVIEW' | 'TRANSMIT'
  ) => {
    setFeedback(null);
    try {
      const ref = (await api.advanceReferral({
        referralId,
        action,
        idempotencyKey: `ers-${referralId}-${Date.now()}`,
        forceFail: forceErsFail,
      })) as any;
      await onRefresh();
      if (ref.status === 'FAILED') {
        setFeedback({ type: 'error', text: ref.failureReason });
      } else {
        setFeedback({
          type: 'ok',
          text: `Referral ${ref.id} updated to ${ref.status}${ref.ersReference ? ` (${ref.ersReference})` : ''}.`,
        });
      }
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleDocumentAction = async (
    docId: string,
    matchedPatientId: string,
    payload: Record<string, unknown>,
    msg: string
  ) => {
    setFeedback(null);
    try {
      await api.processDocument(docId, { matchedPatientId, ...payload });
      await onRefresh();
      setFeedback({ type: 'ok', text: msg });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  if (mode === 'Referrals') {
    if (!isClinician) {
      return (
        <div className="bg-white border border-[#D8DDE0] p-8 text-sm text-[#4C6272]">
          <h2 className="text-lg font-bold text-[#212B32]">Referrals Workspace Restricted</h2>
          <p className="mt-2">
            Clinical referral authoring and e-RS submission require GP or Nurse authorisation.
          </p>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {feedback && (
          <div
            role="alert"
            className={`p-3.5 border text-sm flex items-start gap-2 ${
              feedback.type === 'error'
                ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
                : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
            }`}
          >
            {feedback.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
            )}
            <span>{feedback.text}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-white border border-[#D8DDE0] p-6">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D8DDE0] pb-4">
              <div>
                <h2 className="text-lg font-bold text-[#212B32]">
                  Referrals & Simulated e-RS Tracking
                </h2>
                <p className="text-xs text-[#4C6272] mt-0.5">
                  Drafting, clinical review, transmission, acceptance, and external appointment allocation remain distinct stages.
                </p>
              </div>
              <label className="flex items-center gap-2 text-xs font-semibold text-[#D5281B]">
                <input
                  type="checkbox"
                  checked={forceErsFail}
                  onChange={(e) => setForceErsFail(e.target.checked)}
                />
                <span>Simulate e-RS Failure</span>
              </label>
            </div>

            <div className="mt-4 divide-y divide-[#D8DDE0]">
              {workspace.referrals.map((ref) => (
                <div key={ref.id} className="py-4 space-y-2 text-sm">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <div className="font-bold text-[#212B32]">
                        {getPatientName(ref.patientId)} — {ref.specialty}
                      </div>
                      <div className="text-xs text-[#4C6272] mt-0.5">
                        {ref.pathway} · Urgency: {ref.urgency} · Template: {ref.templateName}
                      </div>
                      <p className="text-xs text-[#212B32] mt-1">{ref.clinicalSummary}</p>
                      {ref.ersReference && (
                        <div className="text-xs font-mono text-[#00703C] mt-1">
                          Simulated e-RS UBRN: {ref.ersReference}
                        </div>
                      )}
                      {ref.failureReason && (
                        <div className="text-xs text-[#D5281B] mt-1">{ref.failureReason}</div>
                      )}
                    </div>
                    <span className="font-mono text-xs font-bold text-[#005EB8]">{ref.status}</span>
                  </div>

                  <div className="flex flex-wrap gap-2 text-xs">
                    {ref.status === 'DRAFT' && (
                      <button
                        type="button"
                        onClick={() => handleReferralAction(ref.id, 'CLINICAL_REVIEW')}
                        className="px-3 py-1.5 bg-[#007F7F] text-white font-semibold"
                      >
                        Approve Clinical Review
                      </button>
                    )}
                    {(ref.status === 'CLINICALLY_REVIEWED' || ref.status === 'FAILED') && (
                      <button
                        type="button"
                        onClick={() => handleReferralAction(ref.id, 'TRANSMIT')}
                        className="px-3 py-1.5 bg-[#005EB8] text-white font-semibold flex items-center gap-1"
                      >
                        <Send className="w-3 h-3" aria-hidden="true" />
                        <span>Transmit to Simulated e-RS</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4 bg-white border border-[#D8DDE0] p-6">
            <h3 className="text-base font-bold text-[#212B32]">Prepare New Referral</h3>
            <form onSubmit={handleCreateReferral} className="mt-4 space-y-3 text-sm">
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="w-full border border-[#768692] bg-white px-2.5 py-2 text-sm"
              >
                {workspace.patients.map((p) => (
                  <option key={String(p.id)} value={String(p.id)}>
                    {String(p.fullName)}
                  </option>
                ))}
              </select>
              <input
                type="text"
                required
                value={specialty}
                onChange={(e) => setSpecialty(e.target.value)}
                className="w-full border border-[#768692] px-2.5 py-2 text-sm"
              />
              <select
                value={urgency}
                onChange={(e) => setUrgency(e.target.value as any)}
                className="w-full border border-[#768692] bg-white px-2.5 py-2 text-xs"
              >
                <option value="ROUTINE">Routine</option>
                <option value="URGENT">Urgent</option>
                <option value="TWO_WEEK_WAIT">2-Week Wait (Suspected Cancer)</option>
              </select>
              <textarea
                rows={4}
                required
                value={clinicalSummary}
                onChange={(e) => setClinicalSummary(e.target.value)}
                placeholder="Clinical referral summary..."
                className="w-full border border-[#768692] p-2.5 text-sm"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-[#005EB8] text-white font-semibold text-sm"
              >
                Save Referral Draft
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // Documents Inbox Mode
  return (
    <div className="space-y-6">
      {feedback && (
        <div
          role="alert"
          className={`p-3.5 border text-sm flex items-start gap-2 ${
            feedback.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          <span>{feedback.text}</span>
        </div>
      )}

      <div className="bg-white border border-[#D8DDE0] p-6 space-y-4">
        <div className="border-b border-[#D8DDE0] pb-4">
          <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#005EB8]" aria-hidden="true" />
            <span>Incoming Correspondence & OCR Verification Inbox</span>
          </h2>
          <p className="text-xs text-[#4C6272] mt-0.5">
            OCR extraction suggests patient identity and summary, but staff must confirm patient matching and clinical entries before filing or patient release.
          </p>
        </div>

        <div className="divide-y divide-[#D8DDE0]">
          {workspace.documents.map((doc) => (
            <div key={doc.id} className="py-4 space-y-2.5 text-sm">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="font-bold text-[#212B32]">{doc.title}</div>
                  <div className="text-xs text-[#4C6272] mt-0.5">
                    From {doc.sourceOrganisation} · Received {doc.receivedAt.slice(0, 10)} ·{' '}
                    Classification: {doc.classification}
                  </div>
                  <div className="mt-2 p-3 bg-[#F8FAFB] border border-[#D8DDE0] text-xs space-y-1">
                    <div>
                      <strong>OCR Suggested Match:</strong> {doc.ocrSuggestedPatientName} (NHS{' '}
                      {doc.ocrSuggestedNhsNumber})
                    </div>
                    <div>
                      <strong>OCR Suggested Summary:</strong> {doc.ocrSuggestedSummary}
                    </div>
                    <div className="text-[#4C6272]">{doc.documentBody}</div>
                  </div>
                </div>

                <div className="text-right text-xs font-mono shrink-0 space-y-1">
                  <div
                    className={
                      doc.patientMatchConfirmed ? 'text-[#00703C] font-bold' : 'text-[#B45309] font-bold'
                    }
                  >
                    {doc.patientMatchConfirmed ? 'MATCH CONFIRMED' : 'AWAITING STAFF MATCH'}
                  </div>
                  <div>Status: {doc.actionStatus}</div>
                  <div>Patient Released: {doc.releasedToPatient ? 'YES' : 'NO (Internal Only)'}</div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs">
                {!doc.patientMatchConfirmed && doc.matchedPatientId && (
                  <button
                    type="button"
                    onClick={() =>
                      handleDocumentAction(
                        doc.id,
                        doc.matchedPatientId!,
                        { confirmMatch: true },
                        `Confirmed OCR match to ${getPatientName(doc.matchedPatientId)}.`
                      )
                    }
                    className="px-3 py-1.5 bg-[#005EB8] text-white font-semibold"
                  >
                    Confirm OCR Patient Match ({getPatientName(doc.matchedPatientId)})
                  </button>
                )}
                {doc.patientMatchConfirmed && doc.actionStatus !== 'ACTIONED' && (
                  <button
                    type="button"
                    onClick={() =>
                      handleDocumentAction(
                        doc.id,
                        doc.matchedPatientId!,
                        { confirmMatch: true, markActioned: true },
                        'Document filed and marked actioned.'
                      )
                    }
                    className="px-3 py-1.5 bg-[#00703C] text-white font-semibold"
                  >
                    Confirm Clinical Entry & Mark Actioned
                  </button>
                )}
                {isClinician && doc.patientMatchConfirmed && !doc.releasedToPatient && (
                  <button
                    type="button"
                    onClick={() =>
                      handleDocumentAction(
                        doc.id,
                        doc.matchedPatientId!,
                        { confirmMatch: true, releaseToPatient: true },
                        'Document deliberately released to Patient Portal.'
                      )
                    }
                    className="px-3 py-1.5 border border-[#007F7F] text-[#007F7F] font-semibold"
                  >
                    Release to Patient Portal
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
