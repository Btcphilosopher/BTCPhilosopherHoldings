import React, { useState } from 'react';
import {
  CheckSquare,
  Building2,
  ShieldCheck,
  Download,
  Upload,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import { api } from '../../api/client';

interface TasksPracticeViewProps {
  mode: 'Tasks' | 'Practice';
  workspace: ScopedWorkspacePayload;
  onRefresh: () => Promise<void>;
  onResetDemo: () => Promise<void>;
}

export const TasksPracticeView: React.FC<TasksPracticeViewProps> = ({
  mode,
  workspace,
  onRefresh,
  onResetDemo,
}) => {
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskOwner, setNewTaskOwner] = useState('staff-gp-2');
  const [coverStaffId, setCoverStaffId] = useState('staff-gp-1');
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'error'; text: string } | null>(
    null
  );

  const isAdmin = workspace.viewer.role === 'ADMIN';
  const isPmOrAdmin =
    workspace.viewer.role === 'PRACTICE_MANAGER' || isAdmin;
  const isClinician =
    workspace.viewer.role === 'GP' || workspace.viewer.role === 'NURSE';

  const getStaffName = (id?: string) =>
    workspace.staff.find((s) => s.id === id)?.name ?? id ?? 'Unassigned';
  const getPatientName = (id?: string) =>
    id ? String(workspace.patients.find((p) => p.id === id)?.fullName ?? id) : 'Practice-wide';

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      const task = (await api.saveTask({
        title: newTaskTitle,
        category: 'FOLLOW_UP',
        patientId: 'pat-margaret',
        ownerId: newTaskOwner,
        priority: 'HIGH',
      })) as any;
      await onRefresh();
      setNewTaskTitle('');
      setFeedback({
        type: 'ok',
        text: `Task created and assigned to ${getStaffName(task.ownerId)}${task.coveredById ? ' (via active leave cover routing)' : ''}.`,
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleUpdateTask = async (
    taskId: string,
    payload: Record<string, unknown>,
    msg: string
  ) => {
    try {
      await api.saveTask({ taskId, ...payload });
      await onRefresh();
      setFeedback({ type: 'ok', text: msg });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleToggleAi = async () => {
    try {
      await api.updateConfig({
        aiAssistEnabled: !workspace.practice.aiAssistEnabled,
      });
      await onRefresh();
      setFeedback({
        type: 'ok',
        text: `Optional AI drafting updated (enabled=${!workspace.practice.aiAssistEnabled}).`,
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleRevokeSessions = async (staffId: string) => {
    try {
      await api.revokeStaffSessions(staffId);
      await onRefresh();
      setFeedback({
        type: 'ok',
        text: `Active sessions revoked for ${getStaffName(staffId)}.`,
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleDownloadBackup = async () => {
    try {
      const backup = await api.downloadBackup();
      const blob = new Blob([JSON.stringify(backup.snapshot, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `pennine-backup-${backup.exportedAt.slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setFeedback({
        type: 'ok',
        text: 'Database and attachment manifest backup exported.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      await api.restoreBackup(parsed);
      await onRefresh();
      setFeedback({ type: 'ok', text: 'Practice database restored from backup snapshot.' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message || 'Invalid backup file.' });
    }
  };

  const handleAdvanceRecall = async (id: string, stage: string) => {
    try {
      await api.advanceRecall(id, stage, `Updated by ${workspace.viewer.name}`);
      await onRefresh();
      setFeedback({ type: 'ok', text: `Recall stage moved to ${stage}.` });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  if (mode === 'Tasks') {
    return (
      <div className="space-y-6">
        {feedback && (
          <div
            role="alert"
            className={`p-3.5 border text-sm flex items-center gap-2 ${
              feedback.type === 'error'
                ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
                : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
            }`}
          >
            <span>{feedback.text}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-white border border-[#D8DDE0] p-6">
            <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2 border-b border-[#D8DDE0] pb-3">
              <CheckSquare className="w-5 h-5 text-[#005EB8]" aria-hidden="true" />
              <span>Practice Tasks & Cover Reassignment ({workspace.tasks.length})</span>
            </h2>

            <div className="mt-4 divide-y divide-[#D8DDE0]">
              {workspace.tasks.map((t) => (
                <div key={t.id} className="py-4 space-y-2 text-sm">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <div className="font-bold text-[#212B32]">{t.title}</div>
                      <div className="text-xs text-[#4C6272] mt-0.5">
                        Patient: {getPatientName(t.patientId)} · Owner: {getStaffName(t.ownerId)}
                        {t.originalOwnerId
                          ? ` (Cover for ${getStaffName(t.originalOwnerId)})`
                          : ''}{' '}
                        · Priority: {t.priority}
                      </div>
                      {t.notes && <div className="text-xs text-[#4C6272] mt-1">{t.notes}</div>}
                    </div>
                    <span className="font-mono text-xs font-bold text-[#005EB8]">{t.status}</span>
                  </div>

                  <div className="flex flex-wrap gap-2 text-xs">
                    {t.status !== 'COMPLETED' && (
                      <>
                        <button
                          type="button"
                          onClick={() =>
                            handleUpdateTask(t.id, { status: 'COMPLETED' }, 'Task marked completed.')
                          }
                          className="px-3 py-1 bg-[#00703C] text-white font-semibold"
                        >
                          Complete Task
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            handleUpdateTask(
                              t.id,
                              { ownerId: 'staff-nurse-1' },
                              'Task reassigned to Nurse Hannah Reid.'
                            )
                          }
                          className="px-2.5 py-1 border border-[#768692] bg-[#F8FAFB]"
                        >
                          Reassign to Nurse Reid
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4 bg-white border border-[#D8DDE0] p-6">
            <h3 className="text-base font-bold text-[#212B32]">Create Follow-Up Task</h3>
            <p className="text-xs text-[#4C6272] mt-1">
              Assigning to Dr Tariq Mahmood (on leave) automatically routes to cover GP Dr Eleanor Vance.
            </p>
            <form onSubmit={handleCreateTask} className="mt-4 space-y-3 text-sm">
              <input
                type="text"
                required
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                placeholder="Task title (e.g., Check repeat U&Es in 14 days)"
                className="w-full border border-[#768692] px-2.5 py-2 text-sm"
              />
              <select
                value={newTaskOwner}
                onChange={(e) => setNewTaskOwner(e.target.value)}
                className="w-full border border-[#768692] bg-white px-2.5 py-2 text-xs"
              >
                {workspace.staff.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.role}) {s.coverStaffId ? '— Covered' : ''}
                  </option>
                ))}
              </select>
              <button
                type="submit"
                className="w-full py-2.5 bg-[#005EB8] text-white font-semibold text-sm"
              >
                Assign Task
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // Practice Operations, Long-Term Recalls, Admin, Audit, Backup & NHS Regulatory Summary
  return (
    <div className="space-y-6">
      {feedback && (
        <div
          role="alert"
          className={`p-3.5 border text-sm flex items-start gap-2 ${
            feedback.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          {feedback.type === 'error' ? (
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Operational Capacity & Metric Definitions */}
      <section className="bg-white border border-[#D8DDE0] p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D8DDE0] pb-4">
          <div>
            <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2">
              <Building2 className="w-5 h-5 text-[#005EB8]" aria-hidden="true" />
              <span>Practice Operations, Capacity & Long-Term Care Governance</span>
            </h2>
            <p className="text-xs text-[#4C6272] mt-0.5">
              {workspace.operationalMetrics.definitionNote}
            </p>
          </div>
          <button
            type="button"
            onClick={() => void onResetDemo()}
            className="px-3 py-1.5 text-xs font-semibold border border-[#768692] bg-[#F0F4F5] hover:bg-[#E2E8EA]"
          >
            Reset Pennine Synthetic Demo Data
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 lg:grid-cols-5 gap-4 text-sm">
          <div>
            <div className="text-xs text-[#4C6272]">Session Utilisation</div>
            <div className="text-xl font-bold font-mono tabular-nums">
              {workspace.operationalMetrics.utilisationPct}%
            </div>
            <div className="text-xs text-[#4C6272]">
              {workspace.operationalMetrics.bookedMinutes}/{workspace.operationalMetrics.totalSessionMinutes}m
            </div>
          </div>
          <div>
            <div className="text-xs text-[#4C6272]">Avg Wait Time</div>
            <div className="text-xl font-bold font-mono tabular-nums">
              {workspace.operationalMetrics.averageWaitingMinutes} min
            </div>
          </div>
          <div>
            <div className="text-xs text-[#4C6272]">Unreviewed Requests</div>
            <div className="text-xl font-bold font-mono tabular-nums">
              {workspace.operationalMetrics.unreviewedRequests}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#4C6272]">Low Stock Items</div>
            <div className="text-xl font-bold font-mono tabular-nums text-[#B45309]">
              {workspace.operationalMetrics.lowStockItems}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#4C6272]">Equipment Due Service</div>
            <div className="text-xl font-bold font-mono tabular-nums text-[#B45309]">
              {workspace.operationalMetrics.dueEquipment}
            </div>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Rotas, Cover, Consumables & Equipment */}
        <section className="bg-white border border-[#D8DDE0] p-6 space-y-5 text-xs">
          <h3 className="text-base font-bold text-[#212B32]">
            Rotas, Leave Cover, Stock & Equipment
          </h3>
          <div className="divide-y divide-[#D8DDE0]">
            {workspace.rotas.map((r) => (
              <div key={r.id} className="py-2 flex items-center justify-between gap-2">
                <div>
                  <div className="font-semibold text-[#212B32]">{getStaffName(r.staffId)}</div>
                  <div className="text-[#4C6272]">{r.shift}</div>
                </div>
                <div className="text-right font-mono">
                  <div className={r.status === 'ON_LEAVE' ? 'text-[#B45309] font-bold' : 'text-[#00703C]'}>
                    {r.status}
                  </div>
                  {r.coverStaffId && <div className="text-[#4C6272]">Cover: {getStaffName(r.coverStaffId)}</div>}
                </div>
              </div>
            ))}
          </div>

          {isPmOrAdmin && (
            <div className="p-3 bg-[#F8FAFB] border border-[#D8DDE0] flex flex-wrap items-center gap-2">
              <span className="font-semibold">Set Cover for Dr Mahmood:</span>
              <select
                value={coverStaffId}
                onChange={(e) => setCoverStaffId(e.target.value)}
                className="border border-[#768692] bg-white px-2 py-1"
              >
                <option value="staff-gp-1">Dr Eleanor Vance</option>
                <option value="staff-nurse-1">Nurse Hannah Reid</option>
              </select>
              <button
                type="button"
                onClick={async () => {
                  await api.updateCover('staff-gp-2', coverStaffId);
                  await onRefresh();
                  setFeedback({ type: 'ok', text: 'Leave cover updated and open tasks routed.' });
                }}
                className="px-2.5 py-1 bg-[#005EB8] text-white font-semibold"
              >
                Apply Cover
              </button>
            </div>
          )}

          <div className="border-t border-[#D8DDE0] pt-4">
            <h4 className="font-bold text-sm text-[#212B32]">Consumables Stock</h4>
            <div className="mt-2 space-y-1.5">
              {workspace.consumables.map((c) => (
                <div key={c.id} className="flex items-center justify-between">
                  <span>
                    {c.itemName} ({c.location})
                  </span>
                  <span
                    className={`font-mono font-bold tabular-nums ${
                      c.quantity <= c.reorderThreshold ? 'text-[#B45309]' : 'text-[#212B32]'
                    }`}
                  >
                    {c.quantity} {c.unit} (Reorder ≤ {c.reorderThreshold})
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-[#D8DDE0] pt-4">
            <h4 className="font-bold text-sm text-[#212B32]">Clinical Equipment Maintenance</h4>
            <div className="mt-2 space-y-1.5">
              {workspace.equipment.map((eq) => (
                <div key={eq.id} className="flex items-center justify-between">
                  <span>
                    {eq.name} (S/N {eq.serialNumber})
                  </span>
                  <span
                    className={`font-mono font-bold ${
                      eq.status !== 'OPERATIONAL' ? 'text-[#B45309]' : 'text-[#00703C]'
                    }`}
                  >
                    {eq.status} · Due {eq.nextMaintenanceDue}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Long-Term Care Recalls & Clinical Governance */}
        <section className="bg-white border border-[#D8DDE0] p-6 space-y-4 text-xs">
          <div>
            <h3 className="text-base font-bold text-[#212B32]">
              Long-Term Care Plans & Governed Recalls
            </h3>
            <p className="text-[#4C6272] mt-0.5">
              Governance sign-off: {workspace.practice.recallGovernanceSignOffBy}. Invitation, booking,
              attendance, intervention, and completed review are tracked separately.
            </p>
          </div>

          <div className="divide-y divide-[#D8DDE0]">
            {workspace.recalls.map((rec) => (
              <div key={rec.id} className="py-3 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-[#212B32]">
                    {getPatientName(rec.patientId)} — {rec.programmeName}
                  </span>
                  <span className="font-mono font-bold text-[#007F7F]">{rec.stage}</span>
                </div>
                <div className="text-[#4C6272]">
                  Rule: {rec.eligibilityRuleSource} ({rec.eligibilityRuleVersion}) · Due: {rec.dueDate}
                </div>
                <div className="flex flex-wrap gap-2 pt-1">
                  {rec.stage === 'INVITED' && (
                    <button
                      type="button"
                      onClick={() => handleAdvanceRecall(rec.id, 'BOOKED')}
                      className="px-2.5 py-1 border border-[#005EB8] text-[#005EB8] font-semibold"
                    >
                      Mark Booked
                    </button>
                  )}
                  {rec.stage === 'BOOKED' && (
                    <button
                      type="button"
                      onClick={() => handleAdvanceRecall(rec.id, 'ATTENDED')}
                      className="px-2.5 py-1 border border-[#005EB8] text-[#005EB8] font-semibold"
                    >
                      Mark Attended
                    </button>
                  )}
                  {isClinician && rec.stage === 'ATTENDED' && (
                    <button
                      type="button"
                      onClick={() => handleAdvanceRecall(rec.id, 'COMPLETED_REVIEW')}
                      className="px-2.5 py-1 bg-[#00703C] text-white font-semibold"
                    >
                      Record Intervention & Complete Review
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Admin Controls: AI Flag, Session Revocation, Backup & Restore */}
          {isAdmin && (
            <div className="border-t border-[#D8DDE0] pt-4 space-y-3">
              <h4 className="font-bold text-sm text-[#212B32] flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
                <span>Administrator Security, AI Policy & Backup Controls</span>
              </h4>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleToggleAi}
                  className="px-3 py-1.5 border border-[#005EB8] text-[#005EB8] font-semibold"
                >
                  {workspace.practice.aiAssistEnabled
                    ? 'Disable Optional AI Support'
                    : 'Enable Optional AI Support (Human Review Only)'}
                </button>
                <button
                  type="button"
                  onClick={handleDownloadBackup}
                  className="px-3 py-1.5 bg-[#212B32] text-white font-semibold flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Export Database Backup</span>
                </button>
                <label className="px-3 py-1.5 border border-[#768692] bg-[#F8FAFB] cursor-pointer flex items-center gap-1 font-semibold">
                  <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Restore Snapshot</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleRestoreFile}
                    className="sr-only"
                  />
                </label>
              </div>
              <div className="space-y-1">
                <div className="font-semibold text-[#4C6272]">Active Staff Session Controls:</div>
                <div className="flex flex-wrap gap-2">
                  {workspace.staff
                    .filter((s) => s.id !== workspace.viewer.userId)
                    .map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => handleRevokeSessions(s.id)}
                        className="px-2 py-1 border border-[#D5281B] text-[#D5281B]"
                      >
                        Revoke {s.name}
                      </button>
                    ))}
                </div>
              </div>
            </div>
          )}
        </section>
      </div>

      {/* Audit Log & Integration Outbox */}
      {(isAdmin || workspace.viewer.role === 'PRACTICE_MANAGER' || workspace.viewer.role === 'GP') && (
        <section className="bg-white border border-[#D8DDE0] p-6 space-y-4">
          <h3 className="text-base font-bold text-[#212B32]">
            Immutable Audit History ({workspace.auditEvents.length} events)
          </h3>
          <p className="text-xs text-[#4C6272]">
            Clinical note free-text is excluded from ordinary audit summaries and logs.
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#D8DDE0] text-[#4C6272]">
                  <th className="py-2 pr-3">Timestamp</th>
                  <th className="py-2 pr-3">Actor</th>
                  <th className="py-2 pr-3">Action</th>
                  <th className="py-2 pr-3">Outcome</th>
                  <th className="py-2">Summary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D8DDE0]">
                {workspace.auditEvents.slice(0, 20).map((ev) => (
                  <tr key={ev.id}>
                    <td className="py-2 pr-3 font-mono tabular-nums whitespace-nowrap text-[#4C6272]">
                      {ev.timestamp.slice(0, 19).replace('T', ' ')}
                    </td>
                    <td className="py-2 pr-3 whitespace-nowrap">
                      {ev.actorName} ({ev.actorRole})
                    </td>
                    <td className="py-2 pr-3 font-mono font-semibold text-[#212B32]">
                      {ev.action}
                    </td>
                    <td
                      className={`py-2 pr-3 font-mono font-bold ${
                        ev.outcome === 'ALLOWED'
                          ? 'text-[#00703C]'
                          : ev.outcome === 'CONFLICT'
                            ? 'text-[#B45309]'
                            : 'text-[#D5281B]'
                      }`}
                    >
                      {ev.outcome}
                    </td>
                    <td className="py-2 text-[#212B32]">{ev.summary}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
};
