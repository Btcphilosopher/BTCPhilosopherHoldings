import React, { useState } from 'react';
import { UserPlus, ShieldAlert, AlertTriangle, CheckCircle2, Users } from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import { api } from '../../api/client';

interface PatientsViewProps {
  workspace: ScopedWorkspacePayload;
  selectedPatientId: string | null;
  onSelectPatient: (id: string) => void;
  onRefresh: () => Promise<void>;
}

export const PatientsView: React.FC<PatientsViewProps> = ({
  workspace,
  selectedPatientId,
  onSelectPatient,
  onRefresh,
}) => {
  const [fullName, setFullName] = useState('');
  const [dob, setDob] = useState('1941-02-18');
  const [nhsNumber, setNhsNumber] = useState('');
  const [phone, setPhone] = useState('01422 555 0177');
  const [address, setAddress] = useState('3 Shibden Fold, Halifax, HX3 9XA');
  const [breakGlassReason, setBreakGlassReason] = useState('');
  const [identityReason, setIdentityReason] = useState('');
  const [correctedName, setCorrectedName] = useState('');
  const [proxyName, setProxyName] = useState('');
  const [proxyVerified, setProxyVerified] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'error'; text: string } | null>(
    null
  );

  const activePatient =
    workspace.patients.find((p) => p.id === selectedPatientId) ??
    workspace.patients[0];

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      const res = (await api.registerPatient({
        fullName,
        dateOfBirth: dob,
        sex: 'Female',
        nhsNumber,
        address,
        phone,
        email: '',
        preferredContactMethod: 'TELEPHONE',
      })) as any;
      await onRefresh();
      setFullName('');
      setFeedback({
        type: 'ok',
        text: `Patient registered (${res.duplicateWarnings?.length || 0} duplicate warning(s) flagged).`,
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleResolveDuplicate = async (
    id: string,
    decision: 'CONFIRMED_SAME_PERSON' | 'CONFIRMED_DISTINCT'
  ) => {
    try {
      await api.resolveDuplicate(id, decision, `Reviewed by ${workspace.viewer.name}`);
      await onRefresh();
      setFeedback({ type: 'ok', text: `Duplicate candidate resolved as ${decision}.` });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleBreakGlass = async (patId: string) => {
    try {
      await api.grantEmergencyAccess(patId, breakGlassReason);
      await onRefresh();
      setBreakGlassReason('');
      setFeedback({
        type: 'ok',
        text: 'Emergency break-glass access granted for 2 hours and logged in audit history.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleProxyCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;
    try {
      await api.createProxy({
        patientId: activePatient.id,
        relatedPersonName: proxyName,
        relationshipType: 'HOUSEHOLD_MEMBER',
        sharedAddress: true,
        isEmergencyContact: true,
        knowsDemographics: true,
        hasRecordAccess: true,
        accessScope: ['SUMMARY'],
        effectiveFrom: '2026-11-24',
        verificationStatus: proxyVerified ? 'VERIFIED' : 'UNVERIFIED',
      });
      await onRefresh();
      setProxyName('');
      setFeedback({ type: 'ok', text: 'Verified proxy relationship created.' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleRevokeProxy = async (proxyId: string) => {
    try {
      await api.revokeProxy(proxyId, 'Revoked in patient record administration');
      await onRefresh();
      setFeedback({ type: 'ok', text: 'Proxy access revoked immediately.' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleIdentityCorrection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;
    try {
      await api.correctIdentity(String(activePatient.id), {
        fullName: correctedName || undefined,
        nhsVerificationStatus: 'VERIFIED',
        enrolmentStatus: 'REGISTERED',
        correctionReason: identityReason,
      });
      await onRefresh();
      setCorrectedName('');
      setIdentityReason('');
      setFeedback({ type: 'ok', text: 'Authorised identity correction saved and audited.' });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const openDuplicates = workspace.duplicateCandidates.filter((d) => d.status === 'OPEN');

  return (
    <div className="space-y-6">
      {feedback && (
        <div
          role="alert"
          className={`p-3.5 border text-sm flex items-start gap-2 ${
            feedback.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Duplicate Warnings Banner */}
      {openDuplicates.length > 0 && (
        <section className="bg-[#FFFBEB] border border-[#B45309] p-5">
          <h2 className="text-sm font-bold text-[#92400E] flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" aria-hidden="true" />
            <span>Uncertain Patient Match / Duplicate Warnings ({openDuplicates.length})</span>
          </h2>
          <div className="mt-3 space-y-3">
            {openDuplicates.map((dup) => {
              const cand = workspace.patients.find((p) => p.id === dup.candidatePatientId);
              const exist = workspace.patients.find((p) => p.id === dup.existingPatientId);
              return (
                <div
                  key={dup.id}
                  className="bg-white border border-[#D8DDE0] p-3 flex flex-wrap items-center justify-between gap-4 text-xs"
                >
                  <div>
                    <div className="font-semibold text-[#212B32]">
                      Candidate: {String(cand?.fullName)} ({String(cand?.nhsNumber)}) ↔ Existing:{' '}
                      {String(exist?.fullName)} ({String(exist?.nhsNumber)})
                    </div>
                    <div className="text-[#4C6272] mt-0.5">
                      Match Score: {Math.round(dup.matchScore * 100)}% · Fields:{' '}
                      {dup.matchingFields.join(', ')}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleResolveDuplicate(dup.id, 'CONFIRMED_SAME_PERSON')}
                      className="px-3 py-1.5 bg-[#005EB8] text-white font-semibold hover:bg-[#004B93]"
                    >
                      Merge / Confirm Same Person
                    </button>
                    <button
                      type="button"
                      onClick={() => handleResolveDuplicate(dup.id, 'CONFIRMED_DISTINCT')}
                      className="px-3 py-1.5 border border-[#768692] bg-white hover:bg-[#F0F4F5]"
                    >
                      Confirm Distinct Individuals
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Patient Directory List */}
        <div className="lg:col-span-5 bg-white border border-[#D8DDE0] p-5">
          <h2 className="text-base font-bold text-[#212B32] flex items-center gap-2">
            <Users className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
            <span>Practice Patient Register ({workspace.patients.length})</span>
          </h2>
          <p className="text-xs text-[#4C6272] mt-1">
            {workspace.viewer.role === 'RECEPTION'
              ? 'Reception view: demographic, identifier verification, and proxy fields only.'
              : 'Clinician view: restricted records require usual GP or documented emergency break-glass.'}
          </p>

          <div className="mt-4 divide-y divide-[#D8DDE0]">
            {workspace.patients.map((p) => {
              const id = String(p.id);
              const isSelected = activePatient?.id === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onSelectPatient(id)}
                  className={`w-full text-left py-3 px-3 transition-colors ${
                    isSelected ? 'bg-[#E8F1FA]' : 'hover:bg-[#F8FAFB]'
                  }`}
                >
                  <div className="flex items-center justify-between text-sm font-semibold text-[#212B32]">
                    <span>{String(p.fullName)}</span>
                    <span className="text-xs font-mono text-[#4C6272]">
                      {String(p.enrolmentStatus)}
                    </span>
                  </div>
                  <div className="text-xs text-[#4C6272] font-mono tabular-nums mt-0.5">
                    DOB {String(p.dateOfBirth)} · NHS {String(p.nhsNumber)} ({String(p.nhsVerificationStatus)})
                  </div>
                  {Boolean(p.restrictedRecord) && (
                    <div className="text-xs font-semibold text-[#D5281B] mt-0.5">
                      Restricted Sensitive Record
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Registration Form */}
          <form onSubmit={handleRegister} className="mt-6 pt-5 border-t border-[#D8DDE0] space-y-3">
            <h3 className="text-sm font-bold text-[#212B32] flex items-center gap-1.5">
              <UserPlus className="w-4 h-4 text-[#007F7F]" aria-hidden="true" />
              <span>Register New Patient (Duplicate Check Enabled)</span>
            </h3>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Full name (e.g., Dorothy Wilkinson)"
              className="w-full border border-[#768692] px-2.5 py-2 text-xs"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                placeholder="DOB YYYY-MM-DD"
                className="border border-[#768692] px-2.5 py-2 text-xs font-mono"
              />
              <input
                type="text"
                value={nhsNumber}
                onChange={(e) => setNhsNumber(e.target.value)}
                placeholder="NHS Number (optional)"
                className="border border-[#768692] px-2.5 py-2 text-xs font-mono"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-[#007F7F] hover:bg-[#006464] text-white text-xs font-semibold"
            >
              Submit Registration Request
            </button>
          </form>
        </div>

        {/* Selected Patient Details: Identifiers, Proxy Relationships, Identity Correction */}
        <div className="lg:col-span-7 bg-white border border-[#D8DDE0] p-6 space-y-6">
          {activePatient && (
            <>
              <div className="border-b border-[#D8DDE0] pb-4 flex flex-wrap items-start justify-between gap-4">
                <div>
                  <h3 className="text-lg font-bold text-[#212B32]">
                    {String(activePatient.fullName)}
                  </h3>
                  <div className="text-xs text-[#4C6272] mt-1">
                    {String(activePatient.address)} · {String(activePatient.phone)} · Preferred:{' '}
                    {String(activePatient.preferredContactMethod)}
                  </div>
                </div>
                <span className="text-xs font-mono text-[#005EB8] font-semibold">
                  Practice ODS {String(activePatient.registeredPracticeOds)}
                </span>
              </div>

              {/* Restricted Record Break-Glass */}
              {Boolean(activePatient.requiresEmergencyAccess) && (
                <div className="p-4 bg-[#FDF2F2] border border-[#D5281B] space-y-2 text-xs">
                  <div className="font-bold text-[#991B1B] flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4" aria-hidden="true" />
                    <span>Restricted Record — Clinical Details Redacted</span>
                  </div>
                  <p className="text-[#7F1D1D]">{String(activePatient.restrictionReason)}</p>
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <input
                      type="text"
                      value={breakGlassReason}
                      onChange={(e) => setBreakGlassReason(e.target.value)}
                      placeholder="Enter mandatory clinical reason (min 10 chars)..."
                      className="flex-1 min-w-[220px] border border-[#D5281B] bg-white px-2.5 py-1.5 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => handleBreakGlass(String(activePatient.id))}
                      className="px-3 py-1.5 bg-[#D5281B] text-white font-semibold hover:bg-[#B01F14]"
                    >
                      Confirm Break-Glass Access
                    </button>
                  </div>
                </div>
              )}

              {/* Identifiers */}
              <div>
                <h4 className="text-sm font-bold text-[#212B32]">
                  Stored Identifiers & Verification Authority
                </h4>
                <div className="mt-2 divide-y divide-[#D8DDE0] border border-[#D8DDE0] text-xs">
                  {((activePatient.identifiers as any[]) || []).map((ident, idx) => (
                    <div key={idx} className="p-2.5 flex items-center justify-between gap-2">
                      <div>
                        <span className="font-mono font-semibold text-[#212B32]">
                          {ident.system}: {ident.value}
                        </span>
                        <div className="text-[#4C6272]">Authority: {ident.issuingAuthority}</div>
                      </div>
                      <span
                        className={`font-mono font-semibold ${
                          ident.verificationStatus === 'VERIFIED'
                            ? 'text-[#00703C]'
                            : 'text-[#B45309]'
                        }`}
                      >
                        {ident.verificationStatus}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Proxy & Contact Relationships */}
              <div>
                <h4 className="text-sm font-bold text-[#212B32]">
                  Contacts & Proxy Relationships (Explicit Scope Required)
                </h4>
                <p className="text-xs text-[#4C6272] mt-0.5">
                  Shared address, emergency contact status, or knowing demographic details never grants record access.
                </p>
                <div className="mt-2 space-y-2 text-xs">
                  {workspace.proxyRelationships
                    .filter((pr) => pr.patientId === activePatient.id)
                    .map((pr) => (
                      <div key={pr.id} className="p-3 border border-[#D8DDE0] bg-[#F8FAFB]">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-[#212B32]">
                            {pr.relatedPersonName} · {pr.relationshipType}
                          </span>
                          <span
                            className={`font-mono font-semibold ${
                              pr.hasRecordAccess && !pr.revokedAt
                                ? 'text-[#00703C]'
                                : 'text-[#D5281B]'
                            }`}
                          >
                            {pr.revokedAt
                              ? 'REVOKED'
                              : pr.hasRecordAccess
                                ? `ACCESS: ${pr.accessScope.join(', ')}`
                                : 'NO RECORD ACCESS'}
                          </span>
                        </div>
                        <div className="text-[#4C6272] mt-1">
                          Verification: {pr.verificationStatus} · Effective: {pr.effectiveFrom}
                          {pr.effectiveTo ? ` to ${pr.effectiveTo}` : ''} · Shared address:{' '}
                          {pr.sharedAddress ? 'Yes' : 'No'} · Emergency contact:{' '}
                          {pr.isEmergencyContact ? 'Yes' : 'No'}
                        </div>
                        {pr.restrictions && (
                          <div className="text-[#4C6272] mt-0.5">{pr.restrictions}</div>
                        )}
                        {pr.hasRecordAccess && !pr.revokedAt && (
                          <button
                            type="button"
                            onClick={() => handleRevokeProxy(pr.id)}
                            className="mt-2 px-2.5 py-1 border border-[#D5281B] text-[#D5281B] font-semibold hover:bg-[#FDF2F2]"
                          >
                            Revoke Proxy Access
                          </button>
                        )}
                      </div>
                    ))}
                </div>

                {/* Test proxy policy enforcement */}
                <form
                  onSubmit={handleProxyCreate}
                  className="mt-3 p-3 border border-[#D8DDE0] bg-white text-xs space-y-2"
                >
                  <div className="font-semibold text-[#212B32]">
                    Add Proxy Relationship (Test Policy Enforcement)
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      required
                      value={proxyName}
                      onChange={(e) => setProxyName(e.target.value)}
                      placeholder="Related person name (e.g., Household Contact)"
                      className="flex-1 min-w-[180px] border border-[#768692] px-2 py-1.5"
                    />
                    <label className="flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={proxyVerified}
                        onChange={(e) => setProxyVerified(e.target.checked)}
                      />
                      <span>Authority Verified</span>
                    </label>
                    <button
                      type="submit"
                      className="px-3 py-1.5 bg-[#005EB8] text-white font-semibold"
                    >
                      Grant Summary Access
                    </button>
                  </div>
                </form>
              </div>

              {/* Authorised Identity Correction */}
              <form
                onSubmit={handleIdentityCorrection}
                className="pt-4 border-t border-[#D8DDE0] space-y-2 text-xs"
              >
                <h4 className="text-sm font-bold text-[#212B32] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
                  <span>Authorised Identity Correction & PDS Verification</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={correctedName}
                    onChange={(e) => setCorrectedName(e.target.value)}
                    placeholder="Corrected legal name (leave blank to keep)"
                    className="border border-[#768692] px-2.5 py-1.5"
                  />
                  <input
                    type="text"
                    required
                    value={identityReason}
                    onChange={(e) => setIdentityReason(e.target.value)}
                    placeholder="Audit reason (e.g., Passport & PDS trace verified)"
                    className="border border-[#768692] px-2.5 py-1.5"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-[#212B32] text-white font-semibold hover:bg-black"
                >
                  Apply Verified Identity Update
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
