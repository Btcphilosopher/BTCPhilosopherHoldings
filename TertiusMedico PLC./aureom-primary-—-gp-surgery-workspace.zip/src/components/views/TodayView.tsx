import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Calendar,
  ClipboardCheck,
  FileWarning,
  ShieldCheck,
  Users,
} from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';

export type NavTab =
  | 'Today'
  | 'Appointments'
  | 'Patients'
  | 'Requests'
  | 'Consultations'
  | 'Prescriptions'
  | 'Results'
  | 'Referrals'
  | 'Documents'
  | 'Tasks'
  | 'Practice';

interface TodayViewProps {
  workspace: ScopedWorkspacePayload;
  onNavigate: (tab: NavTab) => void;
  onSelectPatient: (patientId: string, appointmentId?: string) => void;
  onTriggerScenario: (
    scenario:
      | 'DOUBLE_BOOK'
      | 'UNCERTAIN_MATCH'
      | 'OFFLINE_TOGGLE'
      | 'CONCURRENT_NOTE'
      | 'FAILED_EPS'
  ) => void;
  offlineMode: boolean;
}

export const TodayView: React.FC<TodayViewProps> = ({
  workspace,
  onNavigate,
  onSelectPatient,
  onTriggerScenario,
  offlineMode,
}) => {
  const { viewer, operationalMetrics } = workspace;
  const role = viewer.role;

  const getPatientName = (id?: string) =>
    String(workspace.patients.find((p) => p.id === id)?.fullName ?? id ?? 'Unmatched');

  const getStaffName = (id?: string) =>
    workspace.staff.find((s) => s.id === id)?.name ?? id ?? 'Unassigned';

  const demoSteps: Array<{ step: string; label: string; tab: NavTab }> = [
    { step: '01', label: 'Reception records a patient request', tab: 'Requests' },
    { step: '02', label: 'Authorised staff assign & route request', tab: 'Requests' },
    { step: '03', label: 'Reception books an available appointment', tab: 'Appointments' },
    { step: '04', label: 'Patient arrives & moves to waiting queue', tab: 'Appointments' },
    { step: '05', label: 'GP reviews record & documents consultation', tab: 'Consultations' },
    { step: '06', label: 'GP signs note & creates follow-up tasks', tab: 'Consultations' },
    { step: '07', label: 'Repeat medication reviewed & sent to EPS', tab: 'Prescriptions' },
    { step: '08', label: 'Corrected result reviewed & actioned', tab: 'Results' },
    { step: '09', label: 'Referral prepared & tracked via e-RS', tab: 'Referrals' },
    { step: '10', label: 'Cover staff receive outstanding task', tab: 'Tasks' },
    { step: '11', label: 'Administrator inspects audit history', tab: 'Practice' },
  ];

  return (
    <div className="space-y-6">
      {/* Role Header & Key Operational Strip */}
      <div className="bg-white border border-[#D8DDE0] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-xs font-semibold text-[#005EB8]">
              {workspace.practice.practiceName} · Role Home ({role})
            </div>
            <h2 className="mt-1 text-2xl font-bold text-[#212B32]">
              {role === 'RECEPTION' && 'Reception Front Desk & Care Navigation'}
              {role === 'GP' && 'GP Clinical Day List & Follow-Up'}
              {role === 'NURSE' && 'Practice Nurse Clinics & Long-Term Care'}
              {role === 'PRACTICE_MANAGER' && 'Practice Operations, Rotas & Capacity'}
              {role === 'ADMIN' && 'System Administration, Governance & Audit'}
            </h2>
            <p className="mt-1 text-sm text-[#4C6272]">
              Signed in as {viewer.name} ({viewer.title}). Server-side policy enforces role-scoped visibility.
            </p>
          </div>
          <div className="text-right text-xs text-[#4C6272] font-mono tabular-nums">
            <div>ODS {workspace.practice.odsCode}</div>
            <div>2026-11-24 · Tuesday Session</div>
          </div>
        </div>

        {/* 4-column metric strip */}
        <div className="mt-6 grid grid-cols-2 lg:grid-cols-4 border-t border-[#D8DDE0] pt-5 gap-6">
          <div>
            <div className="text-xs text-[#4C6272]">Today’s Appointments</div>
            <div className="mt-1 text-2xl font-bold tabular-nums text-[#212B32]">
              {operationalMetrics.totalAppointmentsToday}
            </div>
            <div className="text-xs text-[#4C6272] tabular-nums">
              {operationalMetrics.utilisationPct}% session utilisation
            </div>
          </div>
          <div>
            <div className="text-xs text-[#4C6272]">Unreviewed Requests</div>
            <div className="mt-1 text-2xl font-bold tabular-nums text-[#212B32]">
              {operationalMetrics.unreviewedRequests}
            </div>
            <div className="text-xs text-[#4C6272]">Receipt distinct from clinical review</div>
          </div>
          <div>
            <div className="text-xs text-[#4C6272]">
              {role === 'RECEPTION' ? 'Duplicate Warnings' : 'Unactioned Results'}
            </div>
            <div className="mt-1 text-2xl font-bold tabular-nums text-[#B45309]">
              {role === 'RECEPTION'
                ? workspace.duplicateCandidates.filter((d) => d.status === 'OPEN').length
                : operationalMetrics.unactionedResults}
            </div>
            <div className="text-xs text-[#4C6272]">
              {role === 'RECEPTION' ? 'Identity matches needing check' : 'Viewed does not auto-action'}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#4C6272]">Open Practice Tasks</div>
            <div className="mt-1 text-2xl font-bold tabular-nums text-[#212B32]">
              {operationalMetrics.openTasks}
            </div>
            <div className="text-xs text-[#4C6272]">Including cover assignments</div>
          </div>
        </div>
      </div>

      {/* Role-Specific Primary Queues */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-[#D8DDE0] p-6">
          <div className="flex items-center justify-between border-b border-[#D8DDE0] pb-3">
            <h3 className="text-base font-bold text-[#212B32] flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
              <span>
                {role === 'PRACTICE_MANAGER'
                  ? 'Today’s Clinic Rotas & Cover'
                  : role === 'ADMIN'
                    ? 'Recent Security & Clinical Audit Events'
                    : 'Today’s Appointment & Arrival Queue'}
              </span>
            </h3>
            <button
              type="button"
              onClick={() =>
                onNavigate(
                  role === 'PRACTICE_MANAGER' || role === 'ADMIN' ? 'Practice' : 'Appointments'
                )
              }
              className="text-xs font-semibold text-[#005EB8] hover:underline flex items-center gap-1"
            >
              <span>Open full view</span>
              <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </div>

          {role === 'ADMIN' ? (
            <div className="mt-3 divide-y divide-[#D8DDE0] text-xs">
              {workspace.auditEvents.slice(0, 6).map((ev) => (
                <div key={ev.id} className="py-2.5 flex items-start justify-between gap-4">
                  <div>
                    <div className="font-semibold text-[#212B32]">
                      {ev.action} · {ev.outcome}
                    </div>
                    <div className="text-[#4C6272] mt-0.5">{ev.summary}</div>
                  </div>
                  <div className="text-right font-mono tabular-nums text-[#4C6272] shrink-0">
                    <div>{ev.actorName}</div>
                    <div>{ev.timestamp.slice(11, 19)}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : role === 'PRACTICE_MANAGER' ? (
            <div className="mt-3 divide-y divide-[#D8DDE0] text-sm">
              {workspace.rotas.map((r) => (
                <div key={r.id} className="py-2.5 flex items-center justify-between gap-4">
                  <div>
                    <div className="font-semibold text-[#212B32]">{getStaffName(r.staffId)}</div>
                    <div className="text-xs text-[#4C6272]">{r.shift}</div>
                  </div>
                  <div className="text-right text-xs">
                    <span
                      className={`font-semibold ${
                        r.status === 'ON_LEAVE' ? 'text-[#B45309]' : 'text-[#00703C]'
                      }`}
                    >
                      {r.status}
                    </span>
                    {r.coverStaffId && (
                      <div className="text-[#4C6272]">Cover: {getStaffName(r.coverStaffId)}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-3 divide-y divide-[#D8DDE0] text-sm">
              {workspace.appointments.map((apt) => (
                <div key={apt.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-[#212B32]">
                      <span className="font-mono tabular-nums text-[#005EB8] mr-2">
                        {apt.startTime.slice(11, 16)}
                      </span>
                      {getPatientName(apt.patientId)}
                    </div>
                    <div className="text-xs text-[#4C6272] mt-0.5">
                      {apt.appointmentType} · {apt.mode} · {getStaffName(apt.clinicianId)}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-semibold text-[#212B32]">
                      {apt.status}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectPatient(apt.patientId, apt.id);
                        onNavigate(role === 'RECEPTION' ? 'Appointments' : 'Consultations');
                      }}
                      className="px-2.5 py-1 text-xs font-semibold bg-[#F0F4F5] hover:bg-[#E2E8EA] border border-[#D8DDE0] text-[#003087]"
                    >
                      {role === 'RECEPTION' ? 'Manage' : 'Open Consultation'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right column: Incoming Requests / Role Actions */}
        <div className="lg:col-span-5 bg-white border border-[#D8DDE0] p-6">
          <div className="flex items-center justify-between border-b border-[#D8DDE0] pb-3">
            <h3 className="text-base font-bold text-[#212B32] flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4 text-[#007F7F]" aria-hidden="true" />
              <span>
                {role === 'RECEPTION'
                  ? 'Incoming Requests & Triage Inbox'
                  : role === 'GP' || role === 'NURSE'
                    ? 'Clinical Review & Follow-Up Queue'
                    : 'Integration Outbox & Governance'}
              </span>
            </h3>
            <button
              type="button"
              onClick={() =>
                onNavigate(
                  role === 'GP' || role === 'NURSE'
                    ? 'Results'
                    : role === 'RECEPTION'
                      ? 'Requests'
                      : 'Practice'
                )
              }
              className="text-xs font-semibold text-[#005EB8] hover:underline"
            >
              View all
            </button>
          </div>

          <div className="mt-3 divide-y divide-[#D8DDE0] text-sm">
            {workspace.requests.slice(0, 3).map((req) => (
              <div key={req.id} className="py-3">
                <div className="flex items-center justify-between text-xs text-[#4C6272]">
                  <span>
                    {req.channel} · {req.priority}
                  </span>
                  <span className="font-mono">{req.clinicalReviewStatus}</span>
                </div>
                <div className="font-semibold text-[#212B32] mt-1">
                  {getPatientName(req.patientId)}
                </div>
                <p className="text-xs text-[#4C6272] mt-0.5 line-clamp-2">{req.description}</p>
              </div>
            ))}

            {(role === 'GP' || role === 'NURSE') &&
              workspace.results
                .filter((r) => !r.actioned)
                .map((res) => (
                  <div key={res.id} className="py-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-[#B45309]">
                        {res.status} RESULT · {res.abnormalFlag}
                      </span>
                      <span className="font-mono text-[#4C6272]">Action required</span>
                    </div>
                    <div className="font-semibold text-[#212B32] mt-0.5">
                      {getPatientName(res.patientId)} — {res.testName}
                    </div>
                    <div className="text-xs font-mono text-[#4C6272] mt-0.5">
                      {res.value} {res.unit}
                    </div>
                  </div>
                ))}
          </div>
        </div>
      </div>

      {/* 11-Step End-to-End Walkthrough & Edge-Case Simulator */}
      <section className="bg-white border border-[#D8DDE0] p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D8DDE0] pb-4">
          <div>
            <h3 className="text-base font-bold text-[#212B32] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
              <span>Pennine Medical Practice — Workflow Walkthrough & Failure Scenarios</span>
            </h3>
            <p className="mt-1 text-xs text-[#4C6272]">
              Use these shortcuts to step through the 11 clinical/reception stages or trigger the 5 required edge-case demonstrations.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => onTriggerScenario('DOUBLE_BOOK')}
              className="px-3 py-1.5 text-xs font-semibold border border-[#B45309] text-[#B45309] bg-[#FFFBEB] hover:bg-[#FEF3C7]"
            >
              Test Double-Booking Block
            </button>
            <button
              type="button"
              onClick={() => onTriggerScenario('UNCERTAIN_MATCH')}
              className="px-3 py-1.5 text-xs font-semibold border border-[#005EB8] text-[#005EB8] bg-[#EFF6FF] hover:bg-[#DBEAFE]"
            >
              Inspect Uncertain Patient Match
            </button>
            <button
              type="button"
              onClick={() => onTriggerScenario('OFFLINE_TOGGLE')}
              className={`px-3 py-1.5 text-xs font-semibold border ${
                offlineMode
                  ? 'border-[#D5281B] bg-[#D5281B] text-white'
                  : 'border-[#768692] bg-[#F0F4F5] text-[#212B32]'
              }`}
            >
              {offlineMode ? 'Connection Lost (Reconnect & Sync)' : 'Simulate Connection Loss'}
            </button>
            <button
              type="button"
              onClick={() => onTriggerScenario('CONCURRENT_NOTE')}
              className="px-3 py-1.5 text-xs font-semibold border border-[#007F7F] text-[#007F7F] bg-[#F0FDFA] hover:bg-[#CCFBF1]"
            >
              Test Concurrent Note Conflict
            </button>
            <button
              type="button"
              onClick={() => onTriggerScenario('FAILED_EPS')}
              className="px-3 py-1.5 text-xs font-semibold border border-[#D5281B] text-[#D5281B] bg-[#FDF2F2] hover:bg-[#FEE2E2]"
            >
              Test Failed External EPS Submission
            </button>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          {demoSteps.map((s) => (
            <button
              key={s.step}
              type="button"
              onClick={() => onNavigate(s.tab)}
              className="text-left p-3 border border-[#D8DDE0] bg-[#F8FAFB] hover:bg-[#E8F1FA] hover:border-[#005EB8] transition-colors flex items-center justify-between gap-2"
            >
              <span>
                <span className="font-mono font-bold text-[#005EB8] mr-2">{s.step}.</span>
                <span className="font-medium text-[#212B32]">{s.label}</span>
              </span>
              <span className="text-[#4C6272] shrink-0">{s.tab}</span>
            </button>
          ))}
        </div>

        <div className="mt-4 pt-3 border-t border-[#D8DDE0] flex items-center gap-2 text-xs text-[#4C6272]">
          <FileWarning className="w-4 h-4 text-[#B45309] shrink-0" aria-hidden="true" />
          <span>
            {workspace.practice.urgentSignpostingBanner}
          </span>
        </div>
      </section>
    </div>
  );
};
