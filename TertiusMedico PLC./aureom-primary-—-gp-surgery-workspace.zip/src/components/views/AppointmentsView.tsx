import React, { useState } from 'react';
import { Calendar, Clock, Video, Phone, Users, AlertCircle, CheckCircle2 } from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import type { AppointmentMode, AppointmentStatus } from '../../types/clinical';
import { api } from '../../api/client';

interface AppointmentsViewProps {
  workspace: ScopedWorkspacePayload;
  onRefresh: () => Promise<void>;
  onOpenConsultation: (patientId: string, appointmentId: string) => void;
}

export const AppointmentsView: React.FC<AppointmentsViewProps> = ({
  workspace,
  onRefresh,
  onOpenConsultation,
}) => {
  const [patientId, setPatientId] = useState(
    String(workspace.patients[0]?.id ?? 'pat-margaret')
  );
  const [clinicianId, setClinicianId] = useState('staff-gp-1');
  const [roomId, setRoomId] = useState('room-1');
  const [mode, setMode] = useState<AppointmentMode>('FACE_TO_FACE');
  const [appointmentType, setAppointmentType] = useState('GP Consultation (15 min)');
  const [startTime, setStartTime] = useState('2026-11-24T11:00');
  const [durationMinutes, setDurationMinutes] = useState(15);
  const [reason, setReason] = useState('');
  const [overrideConflict, setOverrideConflict] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');
  const [filterClinician, setFilterClinician] = useState<string>('ALL');
  const [statusMessage, setStatusMessage] = useState<{
    type: 'ok' | 'error';
    text: string;
  } | null>(null);
  const [busy, setBusy] = useState(false);

  const clinicians = workspace.staff.filter(
    (s) => s.role === 'GP' || s.role === 'NURSE'
  );

  const getPatientName = (id: string) =>
    String(workspace.patients.find((p) => p.id === id)?.fullName ?? id);
  const getStaffName = (id: string) =>
    workspace.staff.find((s) => s.id === id)?.name ?? id;
  const getRoomName = (id: string) =>
    workspace.rooms.find((r) => r.id === id)?.name ?? id;

  const handleBook = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setStatusMessage(null);
    try {
      await api.bookAppointment({
        patientId,
        clinicianId,
        roomId,
        appointmentType,
        mode,
        startTime,
        durationMinutes,
        reason: reason || 'Clinical review',
        reminderChannel: 'SMS',
        overrideConflict,
        overrideReason,
      });
      await onRefresh();
      setReason('');
      setOverrideConflict(false);
      setOverrideReason('');
      setStatusMessage({
        type: 'ok',
        text: 'Appointment booked and recorded in clinic ledger.',
      });
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Booking failed.',
      });
    } finally {
      setBusy(false);
    }
  };

  const handleTransition = async (id: string, status: AppointmentStatus) => {
    setBusy(true);
    setStatusMessage(null);
    try {
      await api.transitionAppointment(id, status);
      await onRefresh();
      setStatusMessage({
        type: 'ok',
        text: `Appointment ${id} updated to ${status}. (Note signing remains separate.)`,
      });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  const visibleAppointments = workspace.appointments.filter(
    (a) => filterClinician === 'ALL' || a.clinicianId === filterClinician
  );

  return (
    <div className="space-y-6">
      {statusMessage && (
        <div
          role="alert"
          className={`p-3.5 border text-sm flex items-start gap-2 ${
            statusMessage.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          {statusMessage.type === 'error' ? (
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          ) : (
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Clinician Calendar & Arrival Queue */}
        <div className="lg:col-span-8 bg-white border border-[#D8DDE0] p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D8DDE0] pb-4">
            <div>
              <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#005EB8]" aria-hidden="true" />
                <span>Clinician Diaries & Arrival Flow</span>
              </h2>
              <p className="text-xs text-[#4C6272] mt-0.5">
                Appointment completion is tracked separately from consultation-note signing.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <label htmlFor="filter-clinician" className="text-xs font-semibold text-[#4C6272]">
                Clinician:
              </label>
              <select
                id="filter-clinician"
                value={filterClinician}
                onChange={(e) => setFilterClinician(e.target.value)}
                className="border border-[#768692] bg-white px-2.5 py-1.5 text-xs"
              >
                <option value="ALL">All Clinicians</option>
                {clinicians.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-4 divide-y divide-[#D8DDE0]">
            {visibleAppointments.map((apt) => (
              <div key={apt.id} className="py-4 flex flex-col gap-3">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-sm font-bold text-[#212B32]">
                      <span className="font-mono tabular-nums text-[#005EB8]">
                        {apt.startTime.slice(11, 16)}–{apt.endTime.slice(11, 16)}
                      </span>
                      <span>{getPatientName(apt.patientId)}</span>
                      <span className="text-xs font-normal text-[#4C6272]">
                        · {apt.mode === 'VIDEO' && 'Video Room'}
                        {apt.mode === 'TELEPHONE' && 'Telephone'}
                        {apt.mode === 'FACE_TO_FACE' && 'Face-to-Face'}
                      </span>
                    </div>
                    <div className="text-xs text-[#4C6272] mt-1">
                      {apt.appointmentType} · {getStaffName(apt.clinicianId)} ·{' '}
                      {getRoomName(apt.roomId)} · Reminder: {apt.reminderChannel} ({apt.reminderStatus})
                    </div>
                    <div className="text-xs text-[#212B32] mt-1">Reason: {apt.reason}</div>
                    {apt.videoRoomUrl && (
                      <div className="mt-1 text-xs font-mono text-[#007F7F] flex items-center gap-1.5">
                        <Video className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Simulated Video Provider Room: {apt.videoRoomUrl}</span>
                      </div>
                    )}
                  </div>

                  <div className="text-right text-xs">
                    <div className="font-mono font-bold text-[#003087]">{apt.status}</div>
                    <div className="text-[#4C6272] mt-0.5">
                      Note signed: {apt.noteSignedSeparate ? 'Yes' : 'Separate / Pending'}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {apt.status === 'BOOKED' && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleTransition(apt.id, 'ARRIVED')}
                      className="px-3 py-1.5 text-xs font-semibold bg-[#005EB8] text-white hover:bg-[#004B93]"
                    >
                      Mark Arrived
                    </button>
                  )}
                  {(apt.status === 'ARRIVED' || apt.status === 'BOOKED') && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleTransition(apt.id, 'WAITING')}
                      className="px-3 py-1.5 text-xs font-semibold border border-[#005EB8] text-[#005EB8] hover:bg-[#EFF6FF]"
                    >
                      Move to Waiting
                    </button>
                  )}
                  {(apt.status === 'WAITING' || apt.status === 'ARRIVED') && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleTransition(apt.id, 'IN_CONSULTATION')}
                      className="px-3 py-1.5 text-xs font-semibold bg-[#007F7F] text-white hover:bg-[#006464]"
                    >
                      Start Consultation
                    </button>
                  )}
                  {apt.status === 'IN_CONSULTATION' && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleTransition(apt.id, 'COMPLETED')}
                      className="px-3 py-1.5 text-xs font-semibold bg-[#00703C] text-white hover:bg-[#005A30]"
                    >
                      Mark Appointment Completed
                    </button>
                  )}
                  {apt.status !== 'CANCELLED' && apt.status !== 'COMPLETED' && (
                    <>
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => handleTransition(apt.id, 'DID_NOT_ATTEND')}
                        className="px-2.5 py-1.5 text-xs border border-[#D8DDE0] bg-[#F0F4F5] hover:bg-[#E2E8EA]"
                      >
                        Record DNA
                      </button>
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => handleTransition(apt.id, 'CANCELLED')}
                        className="px-2.5 py-1.5 text-xs border border-[#D5281B] text-[#D5281B] hover:bg-[#FDF2F2]"
                      >
                        Cancel
                      </button>
                    </>
                  )}
                  {(workspace.viewer.role === 'GP' || workspace.viewer.role === 'NURSE') && (
                    <button
                      type="button"
                      onClick={() => onOpenConsultation(apt.patientId, apt.id)}
                      className="ml-auto px-3 py-1.5 text-xs font-semibold border border-[#212B32] text-[#212B32] hover:bg-[#F0F4F5]"
                    >
                      Open Consultation Note
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Recurring Clinics & Waiting List */}
          <div className="mt-6 pt-5 border-t border-[#D8DDE0] grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-bold text-[#212B32] flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
                <span>Recurring Clinics</span>
              </h3>
              <div className="mt-2 space-y-2 text-xs">
                {workspace.recurringClinics.map((c) => (
                  <div key={c.id} className="p-2.5 bg-[#F8FAFB] border border-[#D8DDE0]">
                    <div className="font-semibold">{c.name}</div>
                    <div className="text-[#4C6272]">
                      {c.dayOfWeek} {c.startTime}–{c.endTime} ({c.slotMinutes}m) · {getStaffName(c.clinicianId)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#212B32] flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#007F7F]" aria-hidden="true" />
                <span>Waiting List</span>
              </h3>
              <div className="mt-2 space-y-2 text-xs">
                {workspace.waitingList.map((w) => (
                  <div key={w.id} className="p-2.5 bg-[#F8FAFB] border border-[#D8DDE0]">
                    <div className="font-semibold">{getPatientName(w.patientId)}</div>
                    <div className="text-[#4C6272]">{w.requestedType}</div>
                    <div className="text-[#B45309] mt-0.5">{w.urgencyNote}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Book Appointment + Double-Booking Guard */}
        <div className="lg:col-span-4 bg-white border border-[#D8DDE0] p-6">
          <h3 className="text-base font-bold text-[#212B32]">Book New Appointment</h3>
          <p className="mt-1 text-xs text-[#4C6272]">
            Transactional conflict check blocks clinician or room overlaps unless authorised override is provided.
          </p>

          <form onSubmit={handleBook} className="mt-4 space-y-3.5 text-sm">
            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">Patient</label>
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="mt-1 w-full border border-[#768692] bg-white px-2.5 py-2 text-sm"
              >
                {workspace.patients.map((p) => (
                  <option key={String(p.id)} value={String(p.id)}>
                    {String(p.fullName)} (DOB {String(p.dateOfBirth)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">Clinician</label>
              <select
                value={clinicianId}
                onChange={(e) => setClinicianId(e.target.value)}
                className="mt-1 w-full border border-[#768692] bg-white px-2.5 py-2 text-sm"
              >
                {clinicians.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.role})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">Room & Equipment</label>
              <select
                value={roomId}
                onChange={(e) => setRoomId(e.target.value)}
                className="mt-1 w-full border border-[#768692] bg-white px-2.5 py-2 text-sm"
              >
                {workspace.rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({r.equipment.slice(0, 2).join(', ')})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#4C6272]">Mode</label>
                <select
                  value={mode}
                  onChange={(e) => setMode(e.target.value as AppointmentMode)}
                  className="mt-1 w-full border border-[#768692] bg-white px-2 py-2 text-xs"
                >
                  <option value="FACE_TO_FACE">Face-to-Face</option>
                  <option value="TELEPHONE">Telephone</option>
                  <option value="VIDEO">Video (Sim)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#4C6272]">Duration</label>
                <select
                  value={durationMinutes}
                  onChange={(e) => setDurationMinutes(Number(e.target.value))}
                  className="mt-1 w-full border border-[#768692] bg-white px-2 py-2 text-xs"
                >
                  <option value={10}>10 mins</option>
                  <option value={15}>15 mins</option>
                  <option value={20}>20 mins</option>
                  <option value={30}>30 mins</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">
                Start Date & Time (ISO)
              </label>
              <input
                type="text"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="mt-1 w-full border border-[#768692] px-2.5 py-2 text-sm font-mono tabular-nums"
              />
              <button
                type="button"
                onClick={() => {
                  setClinicianId('staff-gp-1');
                  setRoomId('room-1');
                  setStartTime('2026-11-24T09:05');
                  setReason('Intentional double-booking overlap test');
                }}
                className="mt-1 text-xs text-[#B45309] underline"
              >
                Pre-fill conflicting 09:05 slot to test double-booking guard
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">Type & Reason</label>
              <input
                type="text"
                value={appointmentType}
                onChange={(e) => setAppointmentType(e.target.value)}
                className="mt-1 w-full border border-[#768692] px-2.5 py-1.5 text-xs"
              />
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Clinical / admin booking reason..."
                className="mt-2 w-full border border-[#768692] px-2.5 py-2 text-sm"
              />
            </div>

            {(workspace.viewer.role === 'GP' ||
              workspace.viewer.role === 'PRACTICE_MANAGER' ||
              workspace.viewer.role === 'ADMIN') && (
              <div className="p-2.5 bg-[#F8FAFB] border border-[#D8DDE0] text-xs space-y-2">
                <label className="flex items-center gap-2 font-semibold">
                  <input
                    type="checkbox"
                    checked={overrideConflict}
                    onChange={(e) => setOverrideConflict(e.target.checked)}
                  />
                  <span>Authorised Double-Booking Override</span>
                </label>
                {overrideConflict && (
                  <input
                    type="text"
                    value={overrideReason}
                    onChange={(e) => setOverrideReason(e.target.value)}
                    placeholder="Mandatory override clinical justification..."
                    className="w-full border border-[#768692] px-2 py-1.5 text-xs bg-white"
                  />
                )}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 px-4 bg-[#005EB8] hover:bg-[#004B93] text-white font-semibold text-sm"
            >
              Book Appointment
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
