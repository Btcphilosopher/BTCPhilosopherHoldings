import React, { useState } from 'react';
import { Inbox, AlertTriangle, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../../server/domain';
import type { RequestChannel, StaffAssignedPriority } from '../../types/clinical';
import { api } from '../../api/client';

interface RequestsViewProps {
  workspace: ScopedWorkspacePayload;
  onRefresh: () => Promise<void>;
  onBookedFromRequest: () => void;
}

export const RequestsView: React.FC<RequestsViewProps> = ({
  workspace,
  onRefresh,
  onBookedFromRequest,
}) => {
  const [patientId, setPatientId] = useState(
    String(workspace.patients[0]?.id ?? 'pat-margaret')
  );
  const [channel, setChannel] = useState<RequestChannel>('TELEPHONE');
  const [description, setDescription] = useState('');
  const [preferredContactMethod, setPreferredContactMethod] = useState('TELEPHONE');
  const [attachmentName, setAttachmentName] = useState('');
  const [urgentGuidanceShown, setUrgentGuidanceShown] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'error'; text: string } | null>(
    null
  );

  const isClinician =
    workspace.viewer.role === 'GP' || workspace.viewer.role === 'NURSE';

  const getPatientName = (id?: string, fallback?: string) =>
    id
      ? String(workspace.patients.find((p) => p.id === id)?.fullName ?? id)
      : fallback || 'Unmatched Caller';

  const getStaffName = (id?: string) =>
    workspace.staff.find((s) => s.id === id)?.name ?? 'Unassigned';

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await api.createRequest({
        patientId: patientId || undefined,
        channel,
        description,
        preferredContactMethod,
        attachments: attachmentName ? [attachmentName] : [],
        urgentGuidanceShown,
      });
      await onRefresh();
      setDescription('');
      setAttachmentName('');
      setFeedback({
        type: 'ok',
        text: 'Request recorded in shared inbox. Receipt is distinct from clinical review.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleAssignAndPrioritise = async (
    reqId: string,
    ownerId: string,
    priority: StaffAssignedPriority
  ) => {
    setFeedback(null);
    try {
      await api.updateRequest(reqId, {
        assignedOwnerId: ownerId,
        priority,
      });
      await onRefresh();
      setFeedback({ type: 'ok', text: `Request ${reqId} routed and prioritised.` });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleMarkClinicallyReviewed = async (reqId: string) => {
    try {
      await api.updateRequest(reqId, { markClinicallyReviewed: true });
      await onRefresh();
      setFeedback({ type: 'ok', text: `Request ${reqId} marked clinically reviewed.` });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  const handleBookFromRequest = async (reqId: string, patId?: string) => {
    if (!patId) {
      setFeedback({
        type: 'error',
        text: 'Patient identity must be matched before booking an appointment.',
      });
      return;
    }
    try {
      await api.bookAppointment({
        patientId: patId,
        clinicianId: 'staff-gp-1',
        roomId: 'room-1',
        appointmentType: 'GP Consultation (15 min)',
        mode: 'FACE_TO_FACE',
        startTime: '2026-11-24T11:30',
        durationMinutes: 15,
        reason: `Booked from incoming request ${reqId}`,
        linkedRequestId: reqId,
      });
      await onRefresh();
      onBookedFromRequest();
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#FFFBEB] border border-[#B45309] p-4 flex items-start gap-3 text-xs text-[#78350F]">
        <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-[#B45309]" aria-hidden="true" />
        <div>
          <strong className="font-bold">Practice-Approved Urgency Protocol:</strong>{' '}
          {workspace.practice.urgentSignpostingBanner} No automated algorithm determines urgency or guarantees a response window.
        </div>
      </div>

      {feedback && (
        <div
          role="status"
          className={`p-3 border text-sm flex items-center gap-2 ${
            feedback.type === 'error'
              ? 'border-[#D5281B] bg-[#FDF2F2] text-[#991B1B]'
              : 'border-[#00703C] bg-[#EBF7F1] text-[#005A30]'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{feedback.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Shared Inbox */}
        <div className="lg:col-span-8 bg-white border border-[#D8DDE0] p-6">
          <h2 className="text-lg font-bold text-[#212B32] flex items-center gap-2 border-b border-[#D8DDE0] pb-3">
            <Inbox className="w-5 h-5 text-[#005EB8]" aria-hidden="true" />
            <span>Shared Incoming Requests Inbox ({workspace.requests.length})</span>
          </h2>

          <div className="mt-4 divide-y divide-[#D8DDE0]">
            {workspace.requests.map((req) => (
              <div key={req.id} className="py-4 space-y-3">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#4C6272]">
                      <span className="font-mono font-bold text-[#005EB8]">{req.id}</span>
                      <span>· {req.channel}</span>
                      <span>· Submitted {req.submittedAt.slice(0, 16).replace('T', ' ')}</span>
                      <span>· Preferred: {req.preferredContactMethod}</span>
                    </div>
                    <h3 className="text-base font-bold text-[#212B32] mt-1">
                      {getPatientName(req.patientId, req.unmatchedPatientName)}
                    </h3>
                    <p className="text-sm text-[#212B32] mt-1">{req.description}</p>
                    {req.attachments.length > 0 && (
                      <div className="text-xs text-[#4C6272] mt-1">
                        Attachments: {req.attachments.join(', ')}
                      </div>
                    )}
                    {req.handoverNote && (
                      <div className="text-xs text-[#007F7F] mt-1">
                        Handover: {req.handoverNote}
                      </div>
                    )}
                  </div>

                  <div className="text-right text-xs space-y-1 shrink-0">
                    <div className="font-mono font-bold text-[#212B32]">
                      Status: {req.status}
                    </div>
                    <div className="text-[#4C6272]">
                      Clinical review:{' '}
                      <strong
                        className={
                          req.clinicalReviewStatus === 'REVIEWED'
                            ? 'text-[#00703C]'
                            : 'text-[#B45309]'
                        }
                      >
                        {req.clinicalReviewStatus}
                      </strong>
                    </div>
                    <div className="text-[#4C6272]">
                      Priority: <strong className="text-[#212B32]">{req.priority}</strong>
                    </div>
                    <div className="text-[#4C6272]">
                      Owner: {getStaffName(req.assignedOwnerId)}
                    </div>
                  </div>
                </div>

                {/* Routing & Action Controls */}
                <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                  <button
                    type="button"
                    onClick={() =>
                      handleAssignAndPrioritise(req.id, 'staff-gp-1', 'SAME_DAY_DUTY')
                    }
                    className="px-2.5 py-1.5 border border-[#005EB8] text-[#005EB8] font-semibold hover:bg-[#EFF6FF]"
                  >
                    Assign to Dr Vance (Same-Day Duty)
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleAssignAndPrioritise(req.id, 'staff-nurse-1', 'ROUTINE')
                    }
                    className="px-2.5 py-1.5 border border-[#768692] bg-[#F8FAFB] hover:bg-[#E5EAEC]"
                  >
                    Route to Nurse Reid (Routine)
                  </button>
                  {isClinician && req.clinicalReviewStatus !== 'REVIEWED' && (
                    <button
                      type="button"
                      onClick={() => handleMarkClinicallyReviewed(req.id)}
                      className="px-2.5 py-1.5 bg-[#007F7F] text-white font-semibold hover:bg-[#006464]"
                    >
                      Mark Clinically Reviewed
                    </button>
                  )}
                  {!req.linkedAppointmentId && (
                    <button
                      type="button"
                      onClick={() => handleBookFromRequest(req.id, req.patientId)}
                      className="ml-auto px-3 py-1.5 bg-[#005EB8] text-white font-semibold hover:bg-[#004B93] flex items-center gap-1"
                    >
                      <span>Book 11:30 Appointment</span>
                      <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Capture New Request */}
        <div className="lg:col-span-4 bg-white border border-[#D8DDE0] p-6">
          <h3 className="text-base font-bold text-[#212B32]">Record New Patient Request</h3>
          <p className="text-xs text-[#4C6272] mt-1">
            Captures patient’s description and preferred contact without assigning clinical urgency automatically.
          </p>

          <form onSubmit={handleCreate} className="mt-4 space-y-3.5 text-sm">
            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">Patient</label>
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="mt-1 w-full border border-[#768692] bg-white px-2.5 py-2 text-sm"
              >
                {workspace.patients.map((p) => (
                  <option key={String(p.id)} value={String(p.id)}>
                    {String(p.fullName)} (DOB {String(p.dateOfBirth)})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-[#4C6272]">Channel</label>
                <select
                  value={channel}
                  onChange={(e) => setChannel(e.target.value as RequestChannel)}
                  className="mt-1 w-full border border-[#768692] bg-white px-2 py-2 text-xs"
                >
                  <option value="TELEPHONE">Telephone</option>
                  <option value="RECEPTION_DESK">Reception Desk</option>
                  <option value="ONLINE_FORM">Online Form</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#4C6272]">Preferred Contact</label>
                <input
                  type="text"
                  value={preferredContactMethod}
                  onChange={(e) => setPreferredContactMethod(e.target.value)}
                  className="mt-1 w-full border border-[#768692] px-2 py-2 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">
                Patient’s Description
              </label>
              <textarea
                rows={4}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Record caller's own words and symptoms..."
                className="mt-1 w-full border border-[#768692] p-2.5 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4C6272]">
                Attachment Reference (Optional)
              </label>
              <input
                type="text"
                value={attachmentName}
                onChange={(e) => setAttachmentName(e.target.value)}
                placeholder="e.g., rash-photo-object-store.jpg"
                className="mt-1 w-full border border-[#768692] px-2.5 py-1.5 text-xs"
              />
            </div>

            <label className="flex items-start gap-2 text-xs text-[#212B32]">
              <input
                type="checkbox"
                checked={urgentGuidanceShown}
                onChange={(e) => setUrgentGuidanceShown(e.target.checked)}
                className="mt-0.5"
              />
              <span>
                Confirmed practice red-flag signposting guidance was checked with caller.
              </span>
            </label>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#005EB8] hover:bg-[#004B93] text-white font-semibold text-sm"
            >
              Record Request in Inbox
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
