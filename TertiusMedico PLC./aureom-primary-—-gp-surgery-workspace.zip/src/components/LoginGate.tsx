import React, { useState } from 'react';
import { ShieldCheck, Lock, UserCheck, Building2, AlertCircle } from 'lucide-react';
import type { DirectoryResponse } from '../api/client';

interface LoginGateProps {
  directory: DirectoryResponse;
  onLoginStaff: (staffId: string, mfaCode: string) => Promise<void>;
  onLoginPatient: (patientId: string) => Promise<void>;
  error: string | null;
  loading: boolean;
}

export const LoginGate: React.FC<LoginGateProps> = ({
  directory,
  onLoginStaff,
  onLoginPatient,
  error,
  loading,
}) => {
  const [selectedStaffId, setSelectedStaffId] = useState(
    directory.staff[0]?.id ?? 'staff-rec-1'
  );
  const [mfaCode, setMfaCode] = useState('482910');
  const [portalMode, setPortalMode] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState(
    directory.portalPatients[0]?.id ?? 'pat-margaret'
  );

  const selectedStaff = directory.staff.find((s) => s.id === selectedStaffId);

  const handleStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void onLoginStaff(selectedStaffId, mfaCode);
  };

  const handlePatientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void onLoginPatient(selectedPatientId);
  };

  return (
    <div className="min-h-screen bg-[#F0F4F5] flex flex-col justify-between">
      <div className="bg-[#003087] text-white px-6 py-2.5 text-xs flex flex-wrap items-center justify-between gap-2">
        <span className="font-medium">
          Independent Prototype Demonstration · Fictional {directory.practiceName} (ODS {directory.odsCode})
        </span>
        <span className="text-[#D4E3F5]">
          Synthetic records only · No live NHS Spine / EPS / e-RS connectivity
        </span>
      </div>

      <main className="flex-1 flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 bg-white border border-[#D8DDE0] shadow-sm">
          {/* Left column: NHS-inspired organisational identity & safety summary */}
          <div className="lg:col-span-5 bg-[#005EB8] text-white p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2.5 text-sm font-semibold tracking-tight text-[#D4E3F5]">
                <Building2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>AUREOM PRIMARY</span>
              </div>
              <h1 className="mt-4 text-2xl font-bold leading-tight text-white">
                GP Surgery Workspace
              </h1>
              <p className="mt-3 text-sm leading-relaxed text-[#E8F1FA]">
                Role-scoped reception, consultation, prescribing, results, referral,
                and practice operations console for {directory.practiceName}.
              </p>

              <div className="mt-8 space-y-4 border-t border-white/20 pt-6 text-xs text-[#E8F1FA]">
                <div className="flex items-start gap-2.5">
                  <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-white" aria-hidden="true" />
                  <div>
                    <p className="font-semibold text-white">Server-enforced access policies</p>
                    <p className="mt-0.5 text-[#D4E3F5]">
                      Reception views exclude clinical free-text; restricted records require reasoned break-glass access.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <Lock className="w-4 h-4 shrink-0 mt-0.5 text-white" aria-hidden="true" />
                  <div>
                    <p className="font-semibold text-white">Session & MFA protection</p>
                    <p className="mt-0.5 text-[#D4E3F5]">
                      Organisational Bearer tokens held in memory with administrator session revocation.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <p className="mt-8 text-xs text-[#D4E3F5]">
              Accessible design · Keyboard navigable · WCAG AA contrast
            </p>
          </div>

          {/* Right column: Sign-in form */}
          <div className="lg:col-span-7 p-8">
            <div className="flex items-center gap-2 border-b border-[#D8DDE0] pb-4">
              <button
                type="button"
                onClick={() => setPortalMode(false)}
                className={`px-4 py-2 text-sm font-semibold whitespace-nowrap transition-colors ${
                  !portalMode
                    ? 'bg-[#005EB8] text-white'
                    : 'bg-[#F0F4F5] text-[#4C6272] hover:text-[#212B32]'
                }`}
              >
                Practice Staff Sign-In
              </button>
              <button
                type="button"
                onClick={() => setPortalMode(true)}
                className={`px-4 py-2 text-sm font-semibold whitespace-nowrap transition-colors ${
                  portalMode
                    ? 'bg-[#007F7F] text-white'
                    : 'bg-[#F0F4F5] text-[#4C6272] hover:text-[#212B32]'
                }`}
              >
                Patient Portal Demo
              </button>
            </div>

            {error && (
              <div
                role="alert"
                className="mt-4 p-3 border border-[#D5281B] bg-[#FDF2F2] text-[#991B1B] text-sm flex items-start gap-2"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{error}</span>
              </div>
            )}

            {!portalMode ? (
              <form onSubmit={handleStaffSubmit} className="mt-6 space-y-5">
                <div>
                  <label
                    htmlFor="staff-select"
                    className="block text-sm font-semibold text-[#212B32]"
                  >
                    Select Practice Role & Staff Account
                  </label>
                  <select
                    id="staff-select"
                    value={selectedStaffId}
                    onChange={(e) => setSelectedStaffId(e.target.value)}
                    className="mt-1.5 w-full border border-[#768692] bg-white px-3 py-2.5 text-sm text-[#212B32]"
                  >
                    {directory.staff.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} — {s.role} ({s.title})
                      </option>
                    ))}
                  </select>
                </div>

                {selectedStaff && (
                  <div className="p-3 bg-[#F0F4F5] border border-[#D8DDE0] text-xs text-[#4C6272] space-y-1">
                    <div className="font-semibold text-[#212B32]">
                      {selectedStaff.name} · {selectedStaff.role}
                    </div>
                    <div>{selectedStaff.title}</div>
                    <div>
                      MFA Enrolled: {selectedStaff.mfaEnrolled ? 'Yes (Authenticator TOTP)' : 'No'}
                    </div>
                  </div>
                )}

                <div>
                  <label
                    htmlFor="mfa-code"
                    className="block text-sm font-semibold text-[#212B32]"
                  >
                    Organisational MFA Verification Code (6 digits)
                  </label>
                  <input
                    id="mfa-code"
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    value={mfaCode}
                    onChange={(e) => setMfaCode(e.target.value)}
                    className="mt-1.5 w-full border border-[#768692] bg-white px-3 py-2.5 text-sm font-mono tabular-nums text-[#212B32]"
                    placeholder="6-digit authenticator code"
                  />
                  <p className="mt-1 text-xs text-[#4C6272]">
                    Demo MFA code pre-filled (`482910`). Clear or enter invalid digits to verify server rejection.
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 px-4 bg-[#005EB8] hover:bg-[#004B93] disabled:opacity-60 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
                >
                  <UserCheck className="w-4 h-4" aria-hidden="true" />
                  <span>{loading ? 'Verifying session...' : 'Sign in to Surgery Workspace'}</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handlePatientSubmit} className="mt-6 space-y-5">
                <p className="text-sm text-[#4C6272]">
                  Enter the patient-facing portal demonstration. Only deliberately released
                  documents, approved messages, and the patient’s own appointments or repeat requests are visible.
                </p>
                <div>
                  <label
                    htmlFor="portal-patient-select"
                    className="block text-sm font-semibold text-[#212B32]"
                  >
                    Select Synthetic Patient Account
                  </label>
                  <select
                    id="portal-patient-select"
                    value={selectedPatientId}
                    onChange={(e) => setSelectedPatientId(e.target.value)}
                    className="mt-1.5 w-full border border-[#768692] bg-white px-3 py-2.5 text-sm text-[#212B32]"
                  >
                    {directory.portalPatients.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.fullName} (NHS {p.nhsNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 px-4 bg-[#007F7F] hover:bg-[#006464] disabled:opacity-60 text-white font-semibold text-sm transition-colors"
                >
                  {loading ? 'Opening Patient Portal...' : 'Open Patient Portal Demonstration'}
                </button>
              </form>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};
