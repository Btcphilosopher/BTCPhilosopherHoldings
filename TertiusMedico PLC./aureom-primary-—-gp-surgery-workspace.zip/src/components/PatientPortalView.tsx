import React, { useState } from 'react';
import { Calendar, FileText, Mail, Pill, PhoneCall, CheckCircle2, AlertTriangle } from 'lucide-react';
import type { ScopedWorkspacePayload } from '../../server/domain';
import { api } from '../api/client';

interface PatientPortalViewProps {
  workspace: ScopedWorkspacePayload;
  onRefresh: () => Promise<void>;
  onSignOut: () => void;
}

export const PatientPortalView: React.FC<PatientPortalViewProps> = ({
  workspace,
  onRefresh,
  onSignOut,
}) => {
  const patient = workspace.patients[0] as Record<string, any>;
  const [reqDetail, setReqDetail] = useState('');
  const [selectedMed, setSelectedMed] = useState<string>(
    patient?.medications?.[0]?.name || ''
  );
  const [phone, setPhone] = useState<string>(patient?.phone || '');
  const [email, setEmail] = useState<string>(patient?.email || '');
  const [prefs, setPrefs] = useState(
    patient?.notificationPreferences || {
      sms: true,
      email: true,
      nhsApp: true,
      letter: false,
    }
  );
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submitAction = async (payload: Record<string, unknown>, successMsg: string) => {
    setBusy(true);
    setFeedback(null);
    try {
      await api.submitPortalAction(payload);
      await onRefresh();
      setFeedback(successMsg);
      setReqDetail('');
    } catch (err: any) {
      setFeedback(err.message || 'Could not submit request.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F0F4F5] text-[#212B32]">
      <header className="bg-[#005EB8] text-white px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-xs text-[#D4E3F5] font-medium">
            {workspace.practice.practiceName} · Patient Portal Demonstration (Independent Prototype)
          </div>
          <h1 className="text-xl font-bold mt-0.5">Welcome, {patient.fullName}</h1>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <span className="font-mono tabular-nums text-[#E8F1FA]">
            NHS {patient.nhsNumber}
          </span>
          <button
            type="button"
            onClick={onSignOut}
            className="px-3 py-1.5 bg-white text-[#003087] font-semibold hover:bg-[#E8F1FA]"
          >
            Sign Out
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 space-y-6">
        <div className="bg-white border border-[#D8DDE0] p-4 flex items-start gap-3 text-sm">
          <AlertTriangle className="w-5 h-5 text-[#B45309] shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="font-semibold text-[#212B32]">
              Urgent Medical Guidance & Prototype Adapter Notice
            </p>
            <p className="mt-1 text-[#4C6272]">
              {workspace.practice.urgentSignpostingBanner} · NHS Patient Services / NHS App adapter is
              currently in <strong>simulated prototype mode</strong> (not connected to live NHS Login).
              Internal staff notes and confidential third-party records never appear here automatically.
            </p>
          </div>
        </div>

        {feedback && (
          <div
            role="status"
            className="bg-[#EBF7F1] border border-[#00703C] p-3 text-sm text-[#005A30] flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{feedback}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Appointments & Cancellations */}
          <section className="bg-white border border-[#D8DDE0] p-5">
            <h2 className="text-base font-bold flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
              <span>Your Appointments</span>
            </h2>
            <div className="mt-4 divide-y divide-[#D8DDE0]">
              {workspace.appointments.length === 0 ? (
                <p className="text-sm text-[#4C6272]">No upcoming appointments.</p>
              ) : (
                workspace.appointments.map((apt) => (
                  <div key={apt.id} className="py-3 flex items-center justify-between gap-4 text-sm">
                    <div>
                      <div className="font-semibold text-[#212B32]">
                        {apt.appointmentType} · {apt.mode}
                      </div>
                      <div className="text-xs text-[#4C6272] font-mono tabular-nums mt-0.5">
                        {apt.startTime} · Status: {apt.status}
                      </div>
                    </div>
                    {apt.status === 'BOOKED' && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() =>
                          submitAction(
                            {
                              type: 'CANCELLATION',
                              appointmentIdToCancel: apt.id,
                              detail: 'Cancelled by patient via portal',
                            },
                            `Appointment ${apt.id} cancelled and practice notified.`
                          )
                        }
                        className="px-3 py-1.5 text-xs font-semibold border border-[#D5281B] text-[#D5281B] hover:bg-[#FDF2F2]"
                      >
                        Cancel Appointment
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>

            <div className="mt-5 pt-4 border-t border-[#D8DDE0]">
              <h3 className="text-sm font-semibold">Request an Appointment or Callback</h3>
              <textarea
                rows={3}
                value={reqDetail}
                onChange={(e) => setReqDetail(e.target.value)}
                placeholder="Describe what you need help with and preferred contact time..."
                className="mt-2 w-full border border-[#768692] p-2.5 text-sm"
              />
              <button
                type="button"
                disabled={busy || !reqDetail.trim()}
                onClick={() =>
                  submitAction(
                    { type: 'APPOINTMENT_REQUEST', detail: reqDetail },
                    'Your request has been received by Pennine Medical Practice reception.'
                  )
                }
                className="mt-2 px-4 py-2 bg-[#005EB8] text-white text-sm font-semibold hover:bg-[#004B93] disabled:opacity-50"
              >
                Submit Appointment Request
              </button>
            </div>
          </section>

          {/* Repeat Medication Requests */}
          <section className="bg-white border border-[#D8DDE0] p-5">
            <h2 className="text-base font-bold flex items-center gap-2">
              <Pill className="w-4 h-4 text-[#007F7F]" aria-hidden="true" />
              <span>Repeat Medication Requests</span>
            </h2>
            <p className="mt-1 text-xs text-[#4C6272]">
              Requests are reviewed by a practice clinician before transmission to your nominated pharmacy.
            </p>
            <div className="mt-4 space-y-3">
              <label htmlFor="portal-med-select" className="block text-sm font-semibold">
                Select Authorised Repeat Medication
              </label>
              <select
                id="portal-med-select"
                value={selectedMed}
                onChange={(e) => setSelectedMed(e.target.value)}
                className="w-full border border-[#768692] bg-white px-3 py-2 text-sm"
              >
                {(patient.medications || []).map((m: any) => (
                  <option key={m.id} value={m.name}>
                    {m.name} ({m.dose} · {m.frequency})
                  </option>
                ))}
              </select>
              <button
                type="button"
                disabled={busy || !selectedMed}
                onClick={() =>
                  submitAction(
                    {
                      type: 'REPEAT_MEDICATION',
                      medicationName: selectedMed,
                      detail: `Patient portal repeat request for ${selectedMed}`,
                    },
                    `Repeat request for ${selectedMed} submitted for clinician review.`
                  )
                }
                className="px-4 py-2 bg-[#007F7F] text-white text-sm font-semibold hover:bg-[#006464] disabled:opacity-50"
              >
                Request Repeat Prescription
              </button>
            </div>

            <div className="mt-5 pt-4 border-t border-[#D8DDE0]">
              <h3 className="text-sm font-semibold">Your Recent Medication Requests</h3>
              <div className="mt-2 divide-y divide-[#D8DDE0] text-xs">
                {workspace.prescriptions.map((rx) => (
                  <div key={rx.id} className="py-2 flex items-center justify-between gap-2">
                    <span className="font-medium">{rx.medicationName}</span>
                    <span className="font-mono text-[#4C6272]">{rx.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Approved Messages & Released Documents */}
          <section className="bg-white border border-[#D8DDE0] p-5">
            <h2 className="text-base font-bold flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
              <span>Approved Messages & Released Documents</span>
            </h2>
            <p className="mt-1 text-xs text-[#4C6272]">
              Only items explicitly released by a clinician appear here.
            </p>
            <div className="mt-4 space-y-4">
              {workspace.patientMessages.map((msg) => (
                <div key={msg.id} className="p-3 bg-[#F0F4F5] border border-[#D8DDE0] text-sm">
                  <div className="font-semibold text-[#003087]">{msg.subject}</div>
                  <div className="text-xs text-[#4C6272] mt-0.5">
                    From {msg.fromStaffName} · {msg.sentAt.slice(0, 10)}
                  </div>
                  <p className="mt-2 text-sm text-[#212B32]">{msg.body}</p>
                </div>
              ))}
              {workspace.documents.map((doc) => (
                <div key={doc.id} className="p-3 bg-white border border-[#D8DDE0] text-sm">
                  <div className="flex items-center gap-2 font-semibold">
                    <FileText className="w-4 h-4 text-[#007F7F]" aria-hidden="true" />
                    <span>{doc.title}</span>
                  </div>
                  <div className="text-xs text-[#4C6272] mt-0.5">
                    {doc.sourceOrganisation} · Released document
                  </div>
                  <p className="mt-2 text-xs text-[#212B32]">{doc.documentBody}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Contact & Notification Preferences */}
          <section className="bg-white border border-[#D8DDE0] p-5">
            <h2 className="text-base font-bold flex items-center gap-2">
              <PhoneCall className="w-4 h-4 text-[#005EB8]" aria-hidden="true" />
              <span>Contact Details & Notification Preferences</span>
            </h2>
            <div className="mt-4 space-y-3 text-sm">
              <div>
                <label className="block font-semibold text-xs text-[#4C6272]">Telephone</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="mt-1 w-full border border-[#768692] px-3 py-2 text-sm font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold text-xs text-[#4C6272]">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="mt-1 w-full border border-[#768692] px-3 py-2 text-sm"
                />
              </div>
              <div className="pt-2 space-y-2">
                <span className="block font-semibold text-xs text-[#4C6272]">
                  Notification Channels
                </span>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={prefs.sms}
                    onChange={(e) => setPrefs({ ...prefs, sms: e.target.checked })}
                  />
                  <span>SMS appointment reminders</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={prefs.nhsApp}
                    onChange={(e) => setPrefs({ ...prefs, nhsApp: e.target.checked })}
                  />
                  <span>NHS App messaging (simulated adapter)</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={prefs.email}
                    onChange={(e) => setPrefs({ ...prefs, email: e.target.checked })}
                  />
                  <span>Email updates</span>
                </label>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  submitAction(
                    {
                      type: 'CONTACT_UPDATE',
                      updatedPhone: phone,
                      updatedEmail: email,
                      notificationPreferences: prefs,
                      detail: 'Patient updated contact details & notification preferences',
                    },
                    'Contact details and notification preferences updated.'
                  )
                }
                className="mt-2 px-4 py-2 bg-[#005EB8] text-white text-sm font-semibold hover:bg-[#004B93]"
              >
                Save Contact & Preferences
              </button>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};
