import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  LogOut,
  Wifi,
  WifiOff,
  Type as TypeIcon,
  Eye,
} from 'lucide-react';
import { api, setAuthToken, type DirectoryResponse } from './api/client';
import type { ScopedWorkspacePayload } from '../server/domain';
import { LoginGate } from './components/LoginGate';
import { PatientContextBar } from './components/PatientContextBar';
import { PatientPortalView } from './components/PatientPortalView';
import { TodayView, type NavTab } from './components/views/TodayView';
import { AppointmentsView } from './components/views/AppointmentsView';
import { PatientsView } from './components/views/PatientsView';
import { RequestsView } from './components/views/RequestsView';
import {
  ConsultationsView,
  type OfflineQueuedDraft,
} from './components/views/ConsultationsView';
import { PrescriptionsView } from './components/views/PrescriptionsView';
import { ResultsView } from './components/views/ResultsView';
import { ReferralsDocumentsView } from './components/views/ReferralsDocumentsView';
import { TasksPracticeView } from './components/views/TasksPracticeView';

const NAV_TABS: NavTab[] = [
  'Today',
  'Appointments',
  'Patients',
  'Requests',
  'Consultations',
  'Prescriptions',
  'Results',
  'Referrals',
  'Documents',
  'Tasks',
  'Practice',
];

export default function App() {
  const [directory, setDirectory] = useState<DirectoryResponse | null>(null);
  const [workspace, setWorkspace] = useState<ScopedWorkspacePayload | null>(null);
  const [activeTab, setActiveTab] = useState<NavTab>('Today');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [activeAppointmentId, setActiveAppointmentId] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Accessibility & Offline Simulation Controls
  const [largeText, setLargeText] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [offlineMode, setOfflineMode] = useState(false);
  const [offlineQueue, setOfflineQueue] = useState<OfflineQueuedDraft[]>([]);
  const [bannerAlert, setBannerAlert] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle('a11y-large-text', largeText);
  }, [largeText]);

  useEffect(() => {
    document.documentElement.classList.toggle('a11y-reduced-motion', reducedMotion);
  }, [reducedMotion]);

  useEffect(() => {
    api
      .getDirectory()
      .then(setDirectory)
      .catch((err) => setAuthError(err.message));
  }, []);

  const refreshWorkspace = useCallback(async () => {
    const data = await api.getWorkspace();
    setWorkspace(data);
  }, []);

  const handleLoginStaff = async (staffId: string, mfaCode: string) => {
    setLoading(true);
    setAuthError(null);
    try {
      const res = await api.loginStaff(staffId, mfaCode);
      setAuthToken(res.token);
      await refreshWorkspace();
      setActiveTab('Today');
      setSelectedPatientId(null);
      setActiveAppointmentId(null);
    } catch (err: any) {
      setAuthError(err.message || 'Sign-in failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleLoginPatient = async (patientId: string) => {
    setLoading(true);
    setAuthError(null);
    try {
      const res = await api.loginPatient(patientId);
      setAuthToken(res.token);
      await refreshWorkspace();
    } catch (err: any) {
      setAuthError(err.message || 'Patient portal sign-in failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = () => {
    setAuthToken(null);
    setWorkspace(null);
    setSelectedPatientId(null);
    setActiveAppointmentId(null);
    setOfflineQueue([]);
    setOfflineMode(false);
  };

  const handleSelectPatient = (patId: string, aptId?: string) => {
    setSelectedPatientId(patId);
    setActiveAppointmentId(aptId ?? null);
  };

  const handleSyncOfflineQueue = async () => {
    if (offlineMode || offlineQueue.length === 0) return;
    setBannerAlert(null);
    const remaining: OfflineQueuedDraft[] = [];
    for (const item of offlineQueue) {
      try {
        await api.saveConsultationDraft({
          id: item.noteId,
          patientId: item.patientId,
          expectedVersion: item.expectedVersion,
          templateName: item.templateName,
          presentingConcern: item.presentingConcern,
          historyText: item.historyText,
          examinationText: item.examinationText,
          assessmentText: item.assessmentText,
          planText: item.planText,
          observationsSnapshot: item.observationsSnapshot,
        });
      } catch (err: any) {
        remaining.push(item);
        setBannerAlert(
          `Offline sync conflict for patient ${item.patientId}: ${err.message}`
        );
      }
    }
    setOfflineQueue(remaining);
    await refreshWorkspace();
    if (remaining.length === 0) {
      setBannerAlert('All offline consultation drafts synchronised cleanly.');
    }
  };

  const handleTriggerScenario = (
    scenario:
      | 'DOUBLE_BOOK'
      | 'UNCERTAIN_MATCH'
      | 'OFFLINE_TOGGLE'
      | 'CONCURRENT_NOTE'
      | 'FAILED_EPS'
  ) => {
    setBannerAlert(null);
    if (scenario === 'DOUBLE_BOOK') {
      setActiveTab('Appointments');
      setBannerAlert(
        'Double-Booking Test: Click "Pre-fill conflicting 09:05 slot" on the right booking form and submit.'
      );
    } else if (scenario === 'UNCERTAIN_MATCH') {
      setActiveTab('Patients');
      setBannerAlert(
        'Uncertain Patient Match: Inspect the open duplicate candidate warning for D. Wilkinson / Dorothy Wilkinson.'
      );
    } else if (scenario === 'OFFLINE_TOGGLE') {
      const next = !offlineMode;
      setOfflineMode(next);
      if (!next && offlineQueue.length > 0) {
        void handleSyncOfflineQueue();
      } else {
        setBannerAlert(
          next
            ? 'Connection loss simulated. Consultation drafts will queue locally until reconnected.'
            : 'Connection restored.'
        );
      }
    } else if (scenario === 'CONCURRENT_NOTE') {
      setSelectedPatientId('pat-margaret');
      setActiveTab('Consultations');
      setBannerAlert(
        'Concurrent Note Test: Click "Simulate Concurrent Edit" in the Consultation Workspace.'
      );
    } else if (scenario === 'FAILED_EPS') {
      setActiveTab('Prescriptions');
      setBannerAlert(
        'Failed External Submission: Enable "Simulate EPS Gateway Failure", approve a repeat request, then submit to simulated EPS.'
      );
    }
  };

  if (!directory) {
    return (
      <div className="min-h-screen bg-[#F0F4F5] flex items-center justify-center p-6 text-sm text-[#4C6272]">
        Initialising AUREOM PRIMARY workspace...
      </div>
    );
  }

  if (!workspace) {
    return (
      <LoginGate
        directory={directory}
        onLoginStaff={handleLoginStaff}
        onLoginPatient={handleLoginPatient}
        error={authError}
        loading={loading}
      />
    );
  }

  if (workspace.viewer.actorType === 'PATIENT') {
    return (
      <PatientPortalView
        workspace={workspace}
        onRefresh={refreshWorkspace}
        onSignOut={handleSignOut}
      />
    );
  }

  const activePatient = selectedPatientId
    ? (workspace.patients.find((p) => p.id === selectedPatientId) ?? null)
    : null;

  return (
    <div className="min-h-screen bg-[#F0F4F5] text-[#212B32] flex flex-col">
      {/* Prototype & Accessibility Utility Strip */}
      <div className="bg-[#003087] text-white px-6 py-1.5 text-xs flex flex-wrap items-center justify-between gap-3">
        <span>
          Independent Prototype · {workspace.practice.practiceName} (ODS {workspace.practice.odsCode}) ·
          Synthetic Data Only
        </span>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => setLargeText((v) => !v)}
            className="underline hover:text-[#D4E3F5] flex items-center gap-1 whitespace-nowrap"
          >
            <TypeIcon className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{largeText ? 'Standard Text' : 'Larger Text'}</span>
          </button>
          <button
            type="button"
            onClick={() => setReducedMotion((v) => !v)}
            className="underline hover:text-[#D4E3F5] flex items-center gap-1 whitespace-nowrap"
          >
            <Eye className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{reducedMotion ? 'Standard Motion' : 'Reduced Motion'}</span>
          </button>
          <button
            type="button"
            onClick={() => handleTriggerScenario('OFFLINE_TOGGLE')}
            className="underline hover:text-[#D4E3F5] flex items-center gap-1 whitespace-nowrap"
          >
            {offlineMode ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-[#FCD34D]" aria-hidden="true" />
                <span>Offline ({offlineQueue.length} queued) — Reconnect</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Online</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Top Bar (3-zone contract) */}
      <header className="bg-white border-b border-[#D8DDE0] px-6 py-3 flex items-center justify-between gap-8">
        <div className="flex items-center gap-2 font-display font-bold text-lg text-[#005EB8] whitespace-nowrap shrink-0">
          <Activity className="w-5 h-5 shrink-0" aria-hidden="true" />
          <span>AUREOM PRIMARY</span>
        </div>

        <div className="hidden md:flex items-center gap-3 text-xs text-[#4C6272] truncate">
          <span className="font-semibold text-[#212B32]">{workspace.viewer.name}</span>
          <span aria-hidden="true">·</span>
          <span>{workspace.viewer.role}</span>
          <span aria-hidden="true">·</span>
          <span>MFA Verified</span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleSignOut}
            className="px-3 py-1.5 text-xs font-semibold border border-[#768692] bg-[#F0F4F5] hover:bg-[#E2E8EA] text-[#212B32] flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Switch Role / Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main 11-Tab Navigation */}
      <nav
        aria-label="Primary Surgery Navigation"
        className="bg-white border-b border-[#D8DDE0] px-6 overflow-x-auto"
      >
        <div className="flex items-center gap-1">
          {NAV_TABS.map((tab) => {
            const active = activeTab === tab;
            return (
              <button
                key={tab}
                type="button"
                aria-current={active ? 'page' : undefined}
                onClick={() => setActiveTab(tab)}
                className={`px-3.5 py-2.5 text-sm font-medium whitespace-nowrap shrink-0 border-b-2 transition-colors ${
                  active
                    ? 'border-[#005EB8] text-[#005EB8] font-semibold'
                    : 'border-transparent text-[#4C6272] hover:text-[#212B32] hover:border-[#D8DDE0]'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Persistent Patient & Encounter Context Bar */}
      <PatientContextBar
        patient={activePatient}
        activeAppointmentId={activeAppointmentId}
        onClearPatient={() => {
          setSelectedPatientId(null);
          setActiveAppointmentId(null);
        }}
        onRequestBreakGlass={() => setActiveTab('Patients')}
      />

      {/* Main Content */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto p-6 space-y-4">
        {bannerAlert && (
          <div
            role="status"
            className="bg-[#EFF6FF] border border-[#005EB8] px-4 py-2.5 text-xs text-[#003087] flex items-center justify-between gap-4"
          >
            <span>{bannerAlert}</span>
            <button
              type="button"
              onClick={() => setBannerAlert(null)}
              className="font-semibold underline shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {activeTab === 'Today' && (
          <TodayView
            workspace={workspace}
            onNavigate={setActiveTab}
            onSelectPatient={handleSelectPatient}
            onTriggerScenario={handleTriggerScenario}
            offlineMode={offlineMode}
          />
        )}

        {activeTab === 'Appointments' && (
          <AppointmentsView
            workspace={workspace}
            onRefresh={refreshWorkspace}
            onOpenConsultation={(patId, aptId) => {
              handleSelectPatient(patId, aptId);
              setActiveTab('Consultations');
            }}
          />
        )}

        {activeTab === 'Patients' && (
          <PatientsView
            workspace={workspace}
            selectedPatientId={selectedPatientId}
            onSelectPatient={(id) => handleSelectPatient(id)}
            onRefresh={refreshWorkspace}
          />
        )}

        {activeTab === 'Requests' && (
          <RequestsView
            workspace={workspace}
            onRefresh={refreshWorkspace}
            onBookedFromRequest={() => setActiveTab('Appointments')}
          />
        )}

        {activeTab === 'Consultations' && (
          <ConsultationsView
            workspace={workspace}
            selectedPatientId={selectedPatientId}
            activeAppointmentId={activeAppointmentId}
            offlineMode={offlineMode}
            offlineQueue={offlineQueue}
            onQueueOfflineDraft={(draft) =>
              setOfflineQueue((prev) => [...prev, draft])
            }
            onSyncOfflineQueue={handleSyncOfflineQueue}
            onRefresh={refreshWorkspace}
            onSelectPatient={(id) => handleSelectPatient(id)}
          />
        )}

        {activeTab === 'Prescriptions' && (
          <PrescriptionsView workspace={workspace} onRefresh={refreshWorkspace} />
        )}

        {activeTab === 'Results' && (
          <ResultsView workspace={workspace} onRefresh={refreshWorkspace} />
        )}

        {(activeTab === 'Referrals' || activeTab === 'Documents') && (
          <ReferralsDocumentsView
            mode={activeTab}
            workspace={workspace}
            onRefresh={refreshWorkspace}
          />
        )}

        {(activeTab === 'Tasks' || activeTab === 'Practice') && (
          <TasksPracticeView
            mode={activeTab}
            workspace={workspace}
            onRefresh={refreshWorkspace}
            onResetDemo={async () => {
              const fresh = await api.resetDemo();
              setWorkspace(fresh);
              setBannerAlert('Synthetic Pennine Medical Practice dataset restored to initial state.');
            }}
          />
        )}
      </main>
    </div>
  );
}
