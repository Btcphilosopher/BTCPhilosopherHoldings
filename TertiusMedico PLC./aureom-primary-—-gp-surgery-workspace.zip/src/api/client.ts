import type {
  AuthSession,
  PracticeConfig,
  PracticeState,
} from '../types/clinical';
import type { ScopedWorkspacePayload } from '../../server/domain';

export interface DirectoryResponse {
  prototypeNotice: string;
  practiceName: string;
  odsCode: string;
  staff: Array<{
    id: string;
    name: string;
    role: string;
    title: string;
    mfaEnrolled: boolean;
  }>;
  portalPatients: Array<{
    id: string;
    fullName: string;
    nhsNumber: string;
  }>;
}

export class ApiError extends Error {
  status: number;
  code: string;
  details?: Record<string, unknown>;

  constructor(
    status: number,
    code: string,
    message: string,
    details?: Record<string, unknown>
  ) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

let inMemoryToken: string | null = null;

export function setAuthToken(token: string | null) {
  inMemoryToken = token;
}

export function getAuthToken(): string | null {
  return inMemoryToken;
}

async function requestJson<T>(
  url: string,
  options: RequestInit = {}
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (inMemoryToken) {
    headers.Authorization = `Bearer ${inMemoryToken}`;
  }

  const res = await fetch(url, { ...options, headers });
  const text = await res.text();
  const data = text ? JSON.parse(text) : {};

  if (!res.ok) {
    throw new ApiError(
      res.status,
      data.error || 'REQUEST_FAILED',
      data.message || `Request failed (${res.status})`,
      data.details
    );
  }
  return data as T;
}

export const api = {
  getDirectory: () => requestJson<DirectoryResponse>('/api/directory'),
  loginStaff: (staffId: string, mfaCode: string) =>
    requestJson<{ token: string; session: AuthSession }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ staffId, mfaCode }),
    }),
  loginPatient: (patientId: string) =>
    requestJson<{ token: string; session: AuthSession }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ patientId }),
    }),
  getWorkspace: () => requestJson<ScopedWorkspacePayload>('/api/workspace'),
  grantEmergencyAccess: (patientId: string, reason: string) =>
    requestJson<ScopedWorkspacePayload>(
      `/api/patients/${encodeURIComponent(patientId)}/emergency-access`,
      {
        method: 'POST',
        body: JSON.stringify({ reason }),
      }
    ),
  registerPatient: (payload: Record<string, unknown>) =>
    requestJson('/api/patients', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  resolveDuplicate: (
    id: string,
    decision: 'CONFIRMED_SAME_PERSON' | 'CONFIRMED_DISTINCT',
    note: string
  ) =>
    requestJson(`/api/duplicates/${encodeURIComponent(id)}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ decision, note }),
    }),
  correctIdentity: (patientId: string, payload: Record<string, unknown>) =>
    requestJson(`/api/patients/${encodeURIComponent(patientId)}/identity`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
  createProxy: (payload: Record<string, unknown>) =>
    requestJson('/api/proxies', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  revokeProxy: (id: string, reason: string) =>
    requestJson(`/api/proxies/${encodeURIComponent(id)}/revoke`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }),
  createRequest: (payload: Record<string, unknown>) =>
    requestJson('/api/requests', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateRequest: (id: string, payload: Record<string, unknown>) =>
    requestJson(`/api/requests/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),
  bookAppointment: (payload: Record<string, unknown>) =>
    requestJson('/api/appointments', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  transitionAppointment: (id: string, status: string, note?: string) =>
    requestJson(`/api/appointments/${encodeURIComponent(id)}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, note }),
    }),
  saveConsultationDraft: (payload: Record<string, unknown>) =>
    requestJson('/api/consultations/draft', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  signConsultationNote: (id: string, expectedVersion: number) =>
    requestJson(`/api/consultations/${encodeURIComponent(id)}/sign`, {
      method: 'POST',
      body: JSON.stringify({ expectedVersion }),
    }),
  amendConsultationNote: (id: string, reason: string, text: string) =>
    requestJson(`/api/consultations/${encodeURIComponent(id)}/amend`, {
      method: 'POST',
      body: JSON.stringify({ reason, text }),
    }),
  markEnteredInError: (id: string, reason: string) =>
    requestJson(
      `/api/consultations/${encodeURIComponent(id)}/entered-in-error`,
      {
        method: 'POST',
        body: JSON.stringify({ reason }),
      }
    ),
  createPrescription: (payload: Record<string, unknown>) =>
    requestJson('/api/prescriptions', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  reviewPrescription: (
    id: string,
    decision: 'UNDER_REVIEW' | 'APPROVED' | 'DECLINED',
    decisionNote: string
  ) =>
    requestJson(`/api/prescriptions/${encodeURIComponent(id)}/review`, {
      method: 'POST',
      body: JSON.stringify({ decision, decisionNote }),
    }),
  submitPrescriptionEps: (
    id: string,
    idempotencyKey: string,
    forceFail?: boolean
  ) =>
    requestJson(`/api/prescriptions/${encodeURIComponent(id)}/submit-eps`, {
      method: 'POST',
      headers: { 'Idempotency-Key': idempotencyKey },
      body: JSON.stringify({ idempotencyKey, forceFail }),
    }),
  viewResult: (id: string) =>
    requestJson(`/api/results/${encodeURIComponent(id)}/view`, {
      method: 'POST',
    }),
  actionResult: (id: string, payload: Record<string, unknown>) =>
    requestJson(`/api/results/${encodeURIComponent(id)}/action`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  ingestCorrectedResult: (
    previousId: string,
    newValue: string,
    correctionNote: string
  ) =>
    requestJson(`/api/results/${encodeURIComponent(previousId)}/correct`, {
      method: 'POST',
      body: JSON.stringify({ newValue, correctionNote }),
    }),
  advanceReferral: (payload: Record<string, unknown>) =>
    requestJson('/api/referrals', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  processDocument: (id: string, payload: Record<string, unknown>) =>
    requestJson(`/api/documents/${encodeURIComponent(id)}/process`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  saveTask: (payload: Record<string, unknown>) =>
    requestJson('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  advanceRecall: (id: string, stage: string, interventionNote?: string) =>
    requestJson(`/api/recalls/${encodeURIComponent(id)}/stage`, {
      method: 'POST',
      body: JSON.stringify({ stage, interventionNote }),
    }),
  submitPortalAction: (payload: Record<string, unknown>) =>
    requestJson('/api/portal/submissions', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateConfig: (patch: Partial<PracticeConfig>) =>
    requestJson<PracticeConfig>('/api/admin/config', {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),
  revokeStaffSessions: (staffId: string) =>
    requestJson(`/api/admin/staff/${encodeURIComponent(staffId)}/revoke-sessions`, {
      method: 'POST',
    }),
  updateCover: (staffId: string, coverStaffId?: string) =>
    requestJson('/api/operations/cover', {
      method: 'POST',
      body: JSON.stringify({ staffId, coverStaffId }),
    }),
  downloadBackup: () =>
    requestJson<{ exportedAt: string; schemaVersion: string; snapshot: PracticeState }>(
      '/api/admin/backup'
    ),
  restoreBackup: (snapshot: PracticeState) =>
    requestJson<{ restored: boolean }>('/api/admin/restore', {
      method: 'POST',
      body: JSON.stringify({ snapshot }),
    }),
  resetDemo: () =>
    requestJson<ScopedWorkspacePayload>('/api/demo/reset', {
      method: 'POST',
    }),
  requestAiAssist: (payload: {
    mode: 'RECORD_SUMMARY' | 'CONSULTATION_DRAFT' | 'ADMIN_WORDING';
    patientId?: string;
    contextNote?: string;
  }) =>
    requestJson<{
      mode: string;
      requiresHumanReview: boolean;
      draftText: string;
      sourceCitations: string[];
      humanReviewWarning: string;
    }>('/api/ai/assist', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};
