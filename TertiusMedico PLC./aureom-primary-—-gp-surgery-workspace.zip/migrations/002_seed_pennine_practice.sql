-- Migration 002: Synthetic Pennine Medical Practice Seed Data (Independent Prototype)

INSERT INTO practice_config (
    ods_code, practice_name, postcode, ai_assist_enabled, automated_recall_approved,
    recall_governance_signoff_by, urgent_signposting_banner
) VALUES (
    'Y89012',
    'Pennine Medical Practice',
    'HX1 4NP',
    FALSE,
    TRUE,
    'Dr Eleanor Vance (Clinical Safety Lead)',
    'Practice Guidance: Do not use automated urgency scores. For chest pain, acute breathlessness, stroke signs, or severe bleeding, dial 999 or transfer immediately to Duty GP.'
) ON CONFLICT (ods_code) DO NOTHING;

INSERT INTO staff_members (id, full_name, role, title, professional_reg, email, mfa_enrolled, active, cover_staff_id)
VALUES
    ('staff-rec-1', 'Claire Whitaker', 'RECEPTION', 'Senior Care Navigator & Receptionist', NULL, 'c.whitaker@pennine-practice.nhs.uk.example', TRUE, TRUE, NULL),
    ('staff-gp-1', 'Dr Eleanor Vance', 'GP', 'GP Partner & Clinical Safety Lead', 'GMC 7041928', 'e.vance@pennine-practice.nhs.uk.example', TRUE, TRUE, NULL),
    ('staff-gp-2', 'Dr Tariq Mahmood', 'GP', 'Salaried GP (Annual Leave — Covered)', 'GMC 7128403', 't.mahmood@pennine-practice.nhs.uk.example', TRUE, TRUE, 'staff-gp-1'),
    ('staff-nurse-1', 'Hannah Reid', 'NURSE', 'Practice Nurse (Long-Term Conditions)', 'NMC 14H0921E', 'h.reid@pennine-practice.nhs.uk.example', TRUE, TRUE, NULL),
    ('staff-pm-1', 'David Okafor', 'PRACTICE_MANAGER', 'Practice Operations Manager', NULL, 'd.okafor@pennine-practice.nhs.uk.example', TRUE, TRUE, NULL),
    ('staff-admin-1', 'Priya Sharma', 'ADMIN', 'System & Information Governance Admin', NULL, 'p.sharma@pennine-practice.nhs.uk.example', TRUE, TRUE, NULL)
ON CONFLICT (id) DO NOTHING;

INSERT INTO rooms (id, name, floor, equipment, status)
VALUES
    ('room-1', 'Consulting Room 1', 'Ground Floor', '["Examination couch", "Automatic BP monitor", "Otoscope"]'::jsonb, 'AVAILABLE'),
    ('room-2', 'Consulting Room 2', 'Ground Floor', '["Examination couch", "ECG cart", "Pulse oximeter"]'::jsonb, 'AVAILABLE'),
    ('room-3', 'Treatment Room A', 'First Floor', '["Spirometer", "Vaccine fridge", "Phlebotomy chair"]'::jsonb, 'AVAILABLE'),
    ('room-4', 'Remote & Video Hub B', 'First Floor', '["Dual-screen clinical workstation", "Headset"]'::jsonb, 'AVAILABLE')
ON CONFLICT (id) DO NOTHING;

INSERT INTO patients (
    id, full_name, preferred_name, date_of_birth, sex, nhs_number, nhs_verification_status,
    address, phone, email, preferred_contact_method, enrolment_status, registered_practice_ods,
    usual_gp_id, restricted_record, restriction_reason, allergies_state, smoking_state, smoking_detail
) VALUES
    ('pat-margaret', 'Margaret Thornton', 'Maggie', '1954-04-12', 'Female', '943 476 5919', 'VERIFIED',
     '14 Calder Valley Terrace, Halifax, HX1 4NP', '01422 555 0148', 'm.thornton@example.uk', 'TELEPHONE',
     'REGISTERED', 'Y89012', 'staff-gp-1', FALSE, NULL, 'RECORDED', 'EXPLICITLY_ABSENT', 'Never smoked tobacco'),
    ('pat-amir', 'Amir Patel', NULL, '1988-09-23', 'Male', '943 582 1044', 'VERIFIED',
     '8 Savile Park Crescent, Halifax, HX1 3EB', '01422 555 0199', 'a.patel@example.uk', 'SMS',
     'REGISTERED', 'Y89012', 'staff-gp-1', TRUE, 'Confidential occupational & safeguarding sensitivity flag',
     'EXPLICITLY_ABSENT', 'RECORDED', 'Ex-smoker (ceased 2022)'),
    ('pat-oliver', 'Oliver Green', NULL, '2019-11-05', 'Male', '943 619 3320', 'PENDING_VERIFICATION',
     '27 Beacon Hill Road, Halifax, HX3 6AB', '01422 555 0123', 'd.green.family@example.uk', 'SMS',
     'REGISTERED', 'Y89012', 'staff-gp-2', FALSE, NULL, 'NOT_ASSESSED', 'NOT_ASSESSED', 'Paediatric record'),
    ('pat-dorothy', 'Dorothy Wilkinson', NULL, '1941-02-18', 'Female', '943 702 8811', 'VERIFIED',
     '3 Shibden Fold Cottages, Halifax, HX3 9XA', '01422 555 0177', 'dorothy.w@example.uk', 'LETTER',
     'REGISTERED', 'Y89012', 'staff-gp-1', FALSE, NULL, 'UNKNOWN', 'RECORDED', 'Ex-smoker (15 pack-years)')
ON CONFLICT (id) DO NOTHING;

INSERT INTO proxy_relationships (
    id, patient_id, related_person_name, relationship_type, shared_address, is_emergency_contact,
    knows_demographics, has_record_access, access_scope, effective_from, effective_to, verification_status, restrictions
) VALUES
    ('proxy-1', 'pat-oliver', 'David Green (Father)', 'PARENT', TRUE, TRUE, TRUE, TRUE, ARRAY['APPOINTMENTS','PRESCRIPTIONS','MESSAGES'], '2019-11-05', '2035-11-05', 'VERIFIED', 'Subject to Gillick competence review at age 13'),
    ('proxy-2', 'pat-amir', 'Sana Patel (Sister)', 'EMERGENCY_CONTACT', TRUE, TRUE, TRUE, FALSE, ARRAY[]::TEXT[], '2026-01-10', NULL, 'VERIFIED', 'Emergency contact only; record access prohibited'),
    ('proxy-3', 'pat-dorothy', 'Peter Wilkinson (Son)', 'LPA_HEALTH', FALSE, TRUE, TRUE, TRUE, ARRAY['APPOINTMENTS','SUMMARY','PRESCRIPTIONS'], '2025-05-01', NULL, 'VERIFIED', 'OPG LPA verified')
ON CONFLICT (id) DO NOTHING;
