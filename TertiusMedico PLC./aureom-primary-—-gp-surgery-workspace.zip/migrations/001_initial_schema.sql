-- AUREOM PRIMARY — GP Surgery Workspace
-- PostgreSQL 16 Authoritative Clinical & Operational Schema
-- Migration 001: Initial Schema with Transactional Safety Constraints

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

CREATE TYPE staff_role AS ENUM ('RECEPTION', 'GP', 'NURSE', 'PRACTICE_MANAGER', 'ADMIN');
CREATE TYPE verification_status AS ENUM ('VERIFIED', 'PENDING_VERIFICATION', 'UNVERIFIED', 'DISPUTED');
CREATE TYPE data_completeness_state AS ENUM ('RECORDED', 'EXPLICITLY_ABSENT', 'UNKNOWN', 'NOT_ASSESSED');
CREATE TYPE appointment_mode AS ENUM ('FACE_TO_FACE', 'TELEPHONE', 'VIDEO');
CREATE TYPE appointment_status AS ENUM ('BOOKED', 'ARRIVED', 'WAITING', 'IN_CONSULTATION', 'COMPLETED', 'DID_NOT_ATTEND', 'CANCELLED');
CREATE TYPE consultation_status AS ENUM ('DRAFT', 'SIGNED', 'AMENDED', 'ENTERED_IN_ERROR');
CREATE TYPE prescription_status AS ENUM ('REQUESTED', 'UNDER_REVIEW', 'APPROVED', 'DECLINED', 'SUBMITTED_TO_EPS', 'CONFIRMED', 'FAILED');
CREATE TYPE result_status AS ENUM ('PRELIMINARY', 'FINAL', 'CORRECTED', 'CANCELLED');
CREATE TYPE referral_status AS ENUM ('DRAFT', 'CLINICALLY_REVIEWED', 'TRANSMITTED', 'ACCEPTED', 'APPOINTMENT_ALLOCATED', 'FAILED', 'REJECTED');

CREATE TABLE practice_config (
    ods_code TEXT PRIMARY KEY,
    practice_name TEXT NOT NULL,
    postcode TEXT NOT NULL,
    ai_assist_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    automated_recall_approved BOOLEAN NOT NULL DEFAULT FALSE,
    recall_governance_signoff_by TEXT,
    urgent_signposting_banner TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE staff_members (
    id TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    role staff_role NOT NULL,
    title TEXT NOT NULL,
    professional_reg TEXT,
    email TEXT UNIQUE NOT NULL,
    mfa_enrolled BOOLEAN NOT NULL DEFAULT TRUE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    cover_staff_id TEXT REFERENCES staff_members(id),
    session_version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE rooms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    floor TEXT NOT NULL,
    equipment JSONB NOT NULL DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'AVAILABLE'
);

CREATE TABLE patients (
    id TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    preferred_name TEXT,
    date_of_birth DATE NOT NULL,
    sex TEXT NOT NULL,
    nhs_number TEXT NOT NULL,
    nhs_verification_status verification_status NOT NULL,
    address TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    preferred_contact_method TEXT NOT NULL,
    enrolment_status TEXT NOT NULL,
    registered_practice_ods TEXT NOT NULL REFERENCES practice_config(ods_code),
    usual_gp_id TEXT REFERENCES staff_members(id),
    restricted_record BOOLEAN NOT NULL DEFAULT FALSE,
    restriction_reason TEXT,
    allergies_state data_completeness_state NOT NULL DEFAULT 'NOT_ASSESSED',
    allergies_payload JSONB,
    smoking_state data_completeness_state NOT NULL DEFAULT 'NOT_ASSESSED',
    smoking_detail TEXT,
    notification_preferences JSONB NOT NULL DEFAULT '{"sms":true,"email":false,"nhsApp":true,"letter":false}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE patient_identifiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    system_name TEXT NOT NULL,
    identifier_value TEXT NOT NULL,
    issuing_authority TEXT NOT NULL,
    verification_status verification_status NOT NULL,
    verified_at TIMESTAMPTZ,
    verified_by TEXT REFERENCES staff_members(id)
);

-- Explicit Proxy Policy Enforcement:
-- Never allow record access unless verification_status = 'VERIFIED' and explicit access_scope is populated.
CREATE TABLE proxy_relationships (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    related_person_name TEXT NOT NULL,
    relationship_type TEXT NOT NULL,
    shared_address BOOLEAN NOT NULL DEFAULT FALSE,
    is_emergency_contact BOOLEAN NOT NULL DEFAULT FALSE,
    knows_demographics BOOLEAN NOT NULL DEFAULT FALSE,
    has_record_access BOOLEAN NOT NULL DEFAULT FALSE,
    access_scope TEXT[] NOT NULL DEFAULT '{}',
    effective_from DATE NOT NULL,
    effective_to DATE,
    verification_status verification_status NOT NULL,
    restrictions TEXT,
    revoked_at TIMESTAMPTZ,
    revocation_reason TEXT,
    CONSTRAINT chk_proxy_verified_scope CHECK (
        NOT has_record_access
        OR (verification_status = 'VERIFIED' AND array_length(access_scope, 1) > 0 AND revoked_at IS NULL)
    )
);

CREATE TABLE duplicate_candidates (
    id TEXT PRIMARY KEY,
    candidate_patient_id TEXT NOT NULL REFERENCES patients(id),
    existing_patient_id TEXT NOT NULL REFERENCES patients(id),
    match_score NUMERIC(4,2) NOT NULL,
    matching_fields TEXT[] NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN',
    resolved_by TEXT,
    resolved_at TIMESTAMPTZ,
    resolution_note TEXT
);

CREATE TABLE appointments (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL REFERENCES patients(id),
    clinician_id TEXT NOT NULL REFERENCES staff_members(id),
    room_id TEXT NOT NULL REFERENCES rooms(id),
    appointment_type TEXT NOT NULL,
    mode appointment_mode NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
    status appointment_status NOT NULL DEFAULT 'BOOKED',
    reason TEXT NOT NULL,
    override_approved BOOLEAN NOT NULL DEFAULT FALSE,
    override_reason TEXT,
    video_room_url TEXT,
    note_signed_separate BOOLEAN NOT NULL DEFAULT FALSE,
    version INTEGER NOT NULL DEFAULT 1,
    history JSONB NOT NULL DEFAULT '[]'::jsonb,
    -- Exclusion constraint preventing accidental clinician double-booking unless explicit override approved
    EXCLUDE USING gist (
        clinician_id WITH =,
        tstzrange(start_time, end_time, '[)') WITH &&
    ) WHERE (status NOT IN ('CANCELLED', 'DID_NOT_ATTEND') AND NOT override_approved),
    -- Exclusion constraint preventing room double-booking unless explicit override approved
    EXCLUDE USING gist (
        room_id WITH =,
        tstzrange(start_time, end_time, '[)') WITH &&
    ) WHERE (status NOT IN ('CANCELLED', 'DID_NOT_ATTEND') AND NOT override_approved)
);

CREATE TABLE incoming_requests (
    id TEXT PRIMARY KEY,
    patient_id TEXT REFERENCES patients(id),
    unmatched_patient_name TEXT,
    channel TEXT NOT NULL,
    description TEXT NOT NULL,
    preferred_contact_method TEXT NOT NULL,
    attachment_keys TEXT[] NOT NULL DEFAULT '{}',
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    clinical_review_status TEXT NOT NULL DEFAULT 'NOT_REVIEWED',
    assigned_owner_id TEXT REFERENCES staff_members(id),
    priority TEXT NOT NULL DEFAULT 'UNASSIGNED',
    priority_assigned_by TEXT,
    status TEXT NOT NULL DEFAULT 'RECEIVED',
    handover_note TEXT,
    linked_appointment_id TEXT REFERENCES appointments(id)
);

CREATE TABLE consultation_notes (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL REFERENCES patients(id),
    appointment_id TEXT REFERENCES appointments(id),
    author_id TEXT NOT NULL REFERENCES staff_members(id),
    template_name TEXT NOT NULL,
    presenting_concern TEXT NOT NULL,
    history_text TEXT NOT NULL,
    examination_text TEXT NOT NULL,
    assessment_text TEXT NOT NULL,
    plan_text TEXT NOT NULL,
    observations_snapshot TEXT NOT NULL DEFAULT '',
    status consultation_status NOT NULL DEFAULT 'DRAFT',
    version INTEGER NOT NULL DEFAULT 1,
    autosaved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signed_at TIMESTAMPTZ,
    signed_by TEXT REFERENCES staff_members(id),
    entered_in_error_reason TEXT,
    entered_in_error_at TIMESTAMPTZ,
    entered_in_error_by TEXT REFERENCES staff_members(id)
);

CREATE TABLE consultation_amendments (
    id TEXT PRIMARY KEY,
    consultation_id TEXT NOT NULL REFERENCES consultation_notes(id),
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    added_by TEXT NOT NULL REFERENCES staff_members(id),
    reason TEXT NOT NULL,
    amendment_text TEXT NOT NULL
);

-- Immutability Trigger: Signed clinical body columns cannot be altered after signing
CREATE OR REPLACE FUNCTION enforce_signed_note_immutability()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.status IN ('SIGNED', 'AMENDED', 'ENTERED_IN_ERROR') THEN
        IF NEW.presenting_concern <> OLD.presenting_concern
           OR NEW.history_text <> OLD.history_text
           OR NEW.examination_text <> OLD.examination_text
           OR NEW.assessment_text <> OLD.assessment_text
           OR NEW.plan_text <> OLD.plan_text
           OR NEW.patient_id <> OLD.patient_id THEN
            RAISE EXCEPTION 'Signed consultation note % is immutable; append a linked amendment or mark entered-in-error.', OLD.id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_consultation_immutability
    BEFORE UPDATE ON consultation_notes
    FOR EACH ROW EXECUTE FUNCTION enforce_signed_note_immutability();

CREATE TABLE prescription_requests (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL REFERENCES patients(id),
    medication_name TEXT NOT NULL,
    dose TEXT NOT NULL,
    route TEXT NOT NULL,
    frequency TEXT NOT NULL,
    quantity TEXT NOT NULL,
    source TEXT NOT NULL,
    reconciliation_status TEXT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reviewed_by TEXT REFERENCES staff_members(id),
    reviewed_at TIMESTAMPTZ,
    decision_note TEXT,
    status prescription_status NOT NULL DEFAULT 'REQUESTED',
    eps_message_id TEXT,
    eps_error TEXT,
    last_idempotency_key TEXT
);

CREATE TABLE lab_results (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL REFERENCES patients(id),
    test_name TEXT NOT NULL,
    source_lab TEXT NOT NULL,
    collected_at TIMESTAMPTZ NOT NULL,
    reported_at TIMESTAMPTZ NOT NULL,
    status result_status NOT NULL,
    result_value TEXT NOT NULL,
    unit TEXT NOT NULL,
    reference_interval TEXT NOT NULL,
    abnormal_flag TEXT NOT NULL,
    previous_version_id TEXT REFERENCES lab_results(id),
    correction_note TEXT,
    assigned_reviewer_id TEXT NOT NULL REFERENCES staff_members(id),
    viewed_at TIMESTAMPTZ,
    viewed_by TEXT REFERENCES staff_members(id),
    acknowledged_at TIMESTAMPTZ,
    acknowledged_by TEXT REFERENCES staff_members(id),
    actioned BOOLEAN NOT NULL DEFAULT FALSE,
    follow_up_action TEXT
);

CREATE TABLE referrals (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL REFERENCES patients(id),
    specialty TEXT NOT NULL,
    pathway TEXT NOT NULL,
    urgency TEXT NOT NULL,
    template_name TEXT NOT NULL,
    clinical_summary TEXT NOT NULL,
    author_id TEXT NOT NULL REFERENCES staff_members(id),
    reviewed_by TEXT REFERENCES staff_members(id),
    status referral_status NOT NULL DEFAULT 'DRAFT',
    ers_reference TEXT,
    external_appointment_date TIMESTAMPTZ,
    failure_reason TEXT
);

CREATE TABLE incoming_documents (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    source_organisation TEXT NOT NULL,
    received_at TIMESTAMPTZ NOT NULL,
    ocr_suggested_patient_name TEXT,
    ocr_suggested_nhs_number TEXT,
    ocr_suggested_summary TEXT,
    matched_patient_id TEXT REFERENCES patients(id),
    patient_match_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
    classification TEXT NOT NULL,
    assigned_to_id TEXT REFERENCES staff_members(id),
    action_status TEXT NOT NULL DEFAULT 'PENDING_REVIEW',
    released_to_patient BOOLEAN NOT NULL DEFAULT FALSE,
    confidential_third_party_redacted BOOLEAN NOT NULL DEFAULT FALSE,
    object_storage_key TEXT NOT NULL
);

CREATE TABLE practice_tasks (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    patient_id TEXT REFERENCES patients(id),
    owner_id TEXT NOT NULL REFERENCES staff_members(id),
    original_owner_id TEXT REFERENCES staff_members(id),
    covered_by_id TEXT REFERENCES staff_members(id),
    due_at TIMESTAMPTZ NOT NULL,
    priority TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN',
    notes TEXT,
    linked_entity_id TEXT
);

CREATE TABLE idempotency_keys (
    key TEXT PRIMARY KEY,
    response_payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE integration_outbox (
    id TEXT PRIMARY KEY,
    adapter TEXT NOT NULL,
    event_type TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'PENDING',
    attempts INTEGER NOT NULL DEFAULT 0,
    payload JSONB NOT NULL,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_events (
    id TEXT PRIMARY KEY,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    actor_id TEXT NOT NULL,
    actor_name TEXT NOT NULL,
    actor_role TEXT NOT NULL,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    patient_id TEXT,
    outcome TEXT NOT NULL,
    summary TEXT NOT NULL
);

CREATE TABLE emergency_access_grants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id TEXT NOT NULL REFERENCES patients(id),
    staff_id TEXT NOT NULL REFERENCES staff_members(id),
    clinical_reason TEXT NOT NULL CHECK (char_length(clinical_reason) >= 10),
    granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);
