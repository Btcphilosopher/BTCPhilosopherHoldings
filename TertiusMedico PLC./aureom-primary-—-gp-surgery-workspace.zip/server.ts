import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { signSessionToken, verifySessionToken } from './server/auth.ts';
import { DomainError, PracticeService } from './server/domain.ts';
import { createInitialPracticeState } from './server/seed.ts';
import type { AuthSession, PracticeState } from './src/types/clinical.ts';

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'pennine-practice.json');

function loadPersistedState(): PracticeState {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      return JSON.parse(raw) as PracticeState;
    }
  } catch (err) {
    console.warn('Could not read persisted state, falling back to synthetic seed:', err);
  }
  return createInitialPracticeState();
}

function savePersistedState(state: PracticeState): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmpFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(state, null, 2), 'utf8');
  fs.renameSync(tmpFile, DB_FILE);
}

const service = new PracticeService(loadPersistedState(), savePersistedState);

interface AuthenticatedRequest extends Request {
  session?: AuthSession;
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      error: 'UNAUTHENTICATED',
      message: 'Valid organisational Bearer session token is required.',
    });
    return;
  }
  const token = authHeader.slice('Bearer '.length).trim();
  const raw = service.getRawState();
  const session = verifySessionToken(token, raw.staff, raw.patients);
  if (!session) {
    res.status(401).json({
      error: 'SESSION_EXPIRED_OR_REVOKED',
      message: 'Session has expired or was revoked by an administrator.',
    });
    return;
  }
  req.session = session;
  next();
}

function wrapHandler(fn: (req: AuthenticatedRequest, res: Response) => Promise<void> | void) {
  return async (req: AuthenticatedRequest, res: Response) => {
    try {
      await fn(req, res);
    } catch (err) {
      if (err instanceof DomainError) {
        res.status(err.status).json({
          error: err.code,
          message: err.message,
          details: err.details,
        });
        return;
      }
      console.error('Unhandled server error:', err);
      res.status(500).json({
        error: 'INTERNAL_ERROR',
        message: 'An unexpected server error occurred.',
      });
    }
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  // Public prototype directory for login selector (staff display names/roles only; zero patient data)
  app.get('/api/directory', (_req, res) => {
    const raw = service.getRawState();
    res.json({
      prototypeNotice:
        'INDEPENDENT PROTOTYPE DEMONSTRATION — Fictional Pennine Medical Practice (synthetic data only). Not connected to live NHS Spine services.',
      practiceName: raw.config.practiceName,
      odsCode: raw.config.odsCode,
      staff: raw.staff.map((s) => ({
        id: s.id,
        name: s.name,
        role: s.role,
        title: s.title,
        mfaEnrolled: s.mfaEnrolled,
      })),
      portalPatients: raw.patients
        .filter((p) => p.enrolmentStatus === 'REGISTERED')
        .map((p) => ({
          id: p.id,
          fullName: p.fullName,
          nhsNumber: p.nhsNumber,
        })),
    });
  });

  // Organisational staff sign-in + MFA step-up verification
  app.post(
    '/api/auth/login',
    wrapHandler((req, res) => {
      const { staffId, patientId, mfaCode } = req.body as {
        staffId?: string;
        patientId?: string;
        mfaCode?: string;
      };
      const raw = service.getRawState();

      if (patientId) {
        const patient = raw.patients.find((p) => p.id === patientId);
        if (!patient) {
          throw new DomainError(404, 'PATIENT_NOT_FOUND', 'Synthetic patient not found.');
        }
        const token = signSessionToken({
          userId: `portal-${patient.id}`,
          actorType: 'PATIENT',
          role: 'PATIENT',
          name: patient.fullName,
          title: 'NHS Patient Portal (Prototype)',
          mfaVerified: true,
          sessionVersion: 1,
          patientId: patient.id,
        });
        res.json({
          token,
          session: {
            userId: `portal-${patient.id}`,
            actorType: 'PATIENT',
            role: 'PATIENT',
            name: patient.fullName,
            title: 'NHS Patient Portal (Prototype)',
            mfaVerified: true,
            patientId: patient.id,
          },
        });
        return;
      }

      const staff = raw.staff.find((s) => s.id === staffId);
      if (!staff || !staff.active) {
        throw new DomainError(401, 'INVALID_CREDENTIALS', 'Unknown or inactive staff member.');
      }
      if (!mfaCode || !/^\d{6}$/.test(mfaCode.trim())) {
        throw new DomainError(
          401,
          'MFA_REQUIRED',
          'A 6-digit MFA authenticator code is required for organisational sign-in.'
        );
      }

      const token = signSessionToken({
        userId: staff.id,
        actorType: 'STAFF',
        role: staff.role,
        name: staff.name,
        title: staff.title,
        mfaVerified: true,
        sessionVersion: staff.sessionVersion,
      });

      res.json({
        token,
        session: {
          userId: staff.id,
          actorType: 'STAFF',
          role: staff.role,
          name: staff.name,
          title: staff.title,
          mfaVerified: true,
        },
      });
    })
  );

  // Scoped workspace bootstrap
  app.get(
    '/api/workspace',
    requireAuth,
    wrapHandler((req, res) => {
      res.json(service.getScopedWorkspace(req.session!));
    })
  );

  // Emergency break-glass access
  app.post(
    '/api/patients/:id/emergency-access',
    requireAuth,
    wrapHandler((req, res) => {
      const { reason } = req.body as { reason: string };
      service.grantEmergencyAccess(req.session!, req.params.id, reason);
      res.json(service.getScopedWorkspace(req.session!));
    })
  );

  // Registration & identity
  app.post(
    '/api/patients',
    requireAuth,
    wrapHandler((req, res) => {
      const result = service.registerPatient(req.session!, req.body);
      res.status(201).json(result);
    })
  );

  app.post(
    '/api/duplicates/:id/resolve',
    requireAuth,
    wrapHandler((req, res) => {
      const { decision, note } = req.body as {
        decision: 'CONFIRMED_SAME_PERSON' | 'CONFIRMED_DISTINCT';
        note: string;
      };
      const dup = service.resolveDuplicateCandidate(req.session!, req.params.id, decision, note);
      res.json(dup);
    })
  );

  app.patch(
    '/api/patients/:id/identity',
    requireAuth,
    wrapHandler((req, res) => {
      const pat = service.correctPatientIdentity(req.session!, req.params.id, req.body);
      res.json(pat);
    })
  );

  app.post(
    '/api/proxies',
    requireAuth,
    wrapHandler((req, res) => {
      const proxy = service.createProxyRelationship(req.session!, req.body);
      res.status(201).json(proxy);
    })
  );

  app.post(
    '/api/proxies/:id/revoke',
    requireAuth,
    wrapHandler((req, res) => {
      const { reason } = req.body as { reason: string };
      const proxy = service.revokeProxyRelationship(req.session!, req.params.id, reason);
      res.json(proxy);
    })
  );

  // Incoming requests
  app.post(
    '/api/requests',
    requireAuth,
    wrapHandler((req, res) => {
      const created = service.createRequest(req.session!, req.body);
      res.status(201).json(created);
    })
  );

  app.patch(
    '/api/requests/:id',
    requireAuth,
    wrapHandler((req, res) => {
      const updated = service.updateRequestRouting(req.session!, req.params.id, req.body);
      res.json(updated);
    })
  );

  // Appointments
  app.post(
    '/api/appointments',
    requireAuth,
    wrapHandler((req, res) => {
      const apt = service.bookAppointment(req.session!, req.body);
      res.status(201).json(apt);
    })
  );

  app.post(
    '/api/appointments/:id/status',
    requireAuth,
    wrapHandler((req, res) => {
      const { status, note } = req.body as { status: any; note?: string };
      const apt = service.transitionAppointmentStatus(req.session!, req.params.id, status, note);
      res.json(apt);
    })
  );

  // Consultations
  app.post(
    '/api/consultations/draft',
    requireAuth,
    wrapHandler((req, res) => {
      const note = service.saveConsultationDraft(req.session!, req.body);
      res.json(note);
    })
  );

  app.post(
    '/api/consultations/:id/sign',
    requireAuth,
    wrapHandler((req, res) => {
      const { expectedVersion } = req.body as { expectedVersion: number };
      const note = service.signConsultationNote(req.session!, req.params.id, expectedVersion);
      res.json(note);
    })
  );

  app.post(
    '/api/consultations/:id/amend',
    requireAuth,
    wrapHandler((req, res) => {
      const { reason, text } = req.body as { reason: string; text: string };
      const note = service.addConsultationAmendment(req.session!, req.params.id, reason, text);
      res.json(note);
    })
  );

  app.post(
    '/api/consultations/:id/entered-in-error',
    requireAuth,
    wrapHandler((req, res) => {
      const { reason } = req.body as { reason: string };
      const note = service.markNoteEnteredInError(req.session!, req.params.id, reason);
      res.json(note);
    })
  );

  // Prescriptions
  app.post(
    '/api/prescriptions',
    requireAuth,
    wrapHandler((req, res) => {
      const rx = service.createPrescriptionRequest(req.session!, req.body);
      res.status(201).json(rx);
    })
  );

  app.post(
    '/api/prescriptions/:id/review',
    requireAuth,
    wrapHandler((req, res) => {
      const { decision, decisionNote } = req.body as {
        decision: 'UNDER_REVIEW' | 'APPROVED' | 'DECLINED';
        decisionNote: string;
      };
      const rx = service.reviewPrescription(req.session!, req.params.id, decision, decisionNote);
      res.json(rx);
    })
  );

  app.post(
    '/api/prescriptions/:id/submit-eps',
    requireAuth,
    wrapHandler((req, res) => {
      const key =
        (req.headers['idempotency-key'] as string) ||
        (req.body?.idempotencyKey as string) ||
        `eps-${req.params.id}-${Date.now()}`;
      const forceFail = req.body?.forceFail as boolean | undefined;
      const rx = service.submitPrescriptionToEps(req.session!, req.params.id, key, forceFail);
      res.json(rx);
    })
  );

  // Results
  app.post(
    '/api/results/:id/view',
    requireAuth,
    wrapHandler((req, res) => {
      const result = service.viewLabResult(req.session!, req.params.id);
      res.json(result);
    })
  );

  app.post(
    '/api/results/:id/action',
    requireAuth,
    wrapHandler((req, res) => {
      const out = service.actionLabResult(req.session!, req.params.id, req.body);
      res.json(out);
    })
  );

  app.post(
    '/api/results/:id/correct',
    requireAuth,
    wrapHandler((req, res) => {
      const { newValue, correctionNote } = req.body as {
        newValue: string;
        correctionNote: string;
      };
      const out = service.ingestCorrectedResult(
        req.session!,
        req.params.id,
        newValue,
        correctionNote
      );
      res.status(201).json(out);
    })
  );

  // Referrals & Documents
  app.post(
    '/api/referrals',
    requireAuth,
    wrapHandler((req, res) => {
      const ref = service.createOrAdvanceReferral(req.session!, req.body);
      res.json(ref);
    })
  );

  app.post(
    '/api/documents/:id/process',
    requireAuth,
    wrapHandler((req, res) => {
      const doc = service.confirmDocumentMatchAndAction(req.session!, req.params.id, req.body);
      res.json(doc);
    })
  );

  // Tasks & Recalls
  app.post(
    '/api/tasks',
    requireAuth,
    wrapHandler((req, res) => {
      const task = service.createOrUpdateTask(req.session!, req.body);
      res.json(task);
    })
  );

  app.post(
    '/api/recalls/:id/stage',
    requireAuth,
    wrapHandler((req, res) => {
      const { stage, interventionNote } = req.body as { stage: any; interventionNote?: string };
      const recall = service.advanceRecallStage(req.session!, req.params.id, stage, interventionNote);
      res.json(recall);
    })
  );

  // Patient portal submissions
  app.post(
    '/api/portal/submissions',
    requireAuth,
    wrapHandler((req, res) => {
      const sub = service.submitPatientPortalAction(req.session!, req.body);
      res.status(201).json(sub);
    })
  );

  // Practice operations & admin
  app.patch(
    '/api/admin/config',
    requireAuth,
    wrapHandler((req, res) => {
      const cfg = service.updatePracticeConfig(req.session!, req.body);
      res.json(cfg);
    })
  );

  app.post(
    '/api/admin/staff/:id/revoke-sessions',
    requireAuth,
    wrapHandler((req, res) => {
      const staff = service.revokeStaffSessions(req.session!, req.params.id);
      res.json(staff);
    })
  );

  app.post(
    '/api/operations/cover',
    requireAuth,
    wrapHandler((req, res) => {
      const { staffId, coverStaffId } = req.body as { staffId: string; coverStaffId?: string };
      const updated = service.updateRotaCover(req.session!, staffId, coverStaffId);
      res.json(updated);
    })
  );

  app.get(
    '/api/admin/backup',
    requireAuth,
    wrapHandler((req, res) => {
      if (req.session!.role !== 'ADMIN') {
        throw new DomainError(403, 'FORBIDDEN', 'Only Administrators can export database backups.');
      }
      res.json({
        exportedAt: new Date().toISOString(),
        schemaVersion: '001_initial_schema',
        snapshot: service.getRawState(),
      });
    })
  );

  app.post(
    '/api/admin/restore',
    requireAuth,
    wrapHandler((req, res) => {
      const { snapshot } = req.body as { snapshot: PracticeState };
      service.restoreSnapshot(snapshot, req.session!);
      res.json({ restored: true });
    })
  );

  app.post(
    '/api/demo/reset',
    requireAuth,
    wrapHandler((req, res) => {
      service.resetDemoData(req.session!);
      res.json(service.getScopedWorkspace(req.session!));
    })
  );

  // Optional AI Support (Disabled by default, human review mandatory, scoped to requesting clinician)
  app.post(
    '/api/ai/assist',
    requireAuth,
    wrapHandler(async (req, res) => {
      const actor = req.session!;
      if (actor.role !== 'GP' && actor.role !== 'NURSE' && actor.role !== 'RECEPTION') {
        throw new DomainError(403, 'FORBIDDEN', 'AI drafting assistance is restricted to authorised practice staff.');
      }
      const raw = service.getRawState();
      if (!raw.config.aiAssistEnabled) {
        throw new DomainError(
          403,
          'AI_DISABLED_BY_DEFAULT',
          'Optional AI drafting support is disabled by default in Practice Configuration. An Administrator must enable it first.'
        );
      }

      const { mode, patientId, contextNote } = req.body as {
        mode: 'RECORD_SUMMARY' | 'CONSULTATION_DRAFT' | 'ADMIN_WORDING';
        patientId?: string;
        contextNote?: string;
      };

      if (mode !== 'ADMIN_WORDING' && actor.role === 'RECEPTION') {
        throw new DomainError(403, 'ROLE_SCOPED_DENIAL', 'Reception staff can only request administrative wording assistance.');
      }

      let scopedContext = '';
      if (patientId) {
        const patient = raw.patients.find((p) => p.id === patientId);
        if (!patient) throw new DomainError(404, 'PATIENT_NOT_FOUND', 'Patient not found.');
        if (actor.role === 'GP' || actor.role === 'NURSE') {
          if (!service.canAccessRestrictedClinicalRecord(actor, patient)) {
            throw new DomainError(403, 'RESTRICTED_RECORD', 'Cannot invoke AI on restricted record without break-glass access.');
          }
          const notes = raw.consultations
            .filter((c) => c.patientId === patient.id && c.status !== 'ENTERED_IN_ERROR')
            .slice(0, 3)
            .map((c) => `[Note ${c.id} ${c.status}] ${c.presentingConcern} | Plan: ${c.planText}`)
            .join('\n');
          const results = raw.results
            .filter((r) => r.patientId === patient.id)
            .slice(0, 4)
            .map((r) => `[Result ${r.id} ${r.status}] ${r.testName}: ${r.value} ${r.unit}`)
            .join('\n');
          scopedContext = `Patient: ${patient.fullName} (DOB ${patient.dateOfBirth})\nProblems: ${patient.activeProblems.join('; ')}\nMeds: ${patient.medications.map((m) => m.name).join('; ')}\n${notes}\n${results}`;
        } else {
          scopedContext = `Patient name: ${patient.fullName}, Preferred contact: ${patient.preferredContactMethod}`;
        }
      }

      if (!process.env.GEMINI_API_KEY) {
        throw new DomainError(
          503,
          'GEMINI_KEY_MISSING',
          'GEMINI_API_KEY is not configured in environment secrets.'
        );
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const systemInstruction =
        'You are an optional drafting assistant in an NHS primary-care prototype. ' +
        'NEVER diagnose, NEVER recommend medication doses, NEVER assign clinical urgency, NEVER sign notes or close tasks. ' +
        'Every summary must cite source IDs from the provided scoped context (e.g., [Note con-300], [Result res-502]). ' +
        'Return structured JSON with draftText, sourceCitations, and humanReviewWarning.';

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Mode: ${mode}\nStaff Role: ${actor.role}\nScoped Context:\n${scopedContext}\nAdditional Input:\n${contextNote || ''}`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              draftText: { type: Type.STRING },
              sourceCitations: { type: Type.ARRAY, items: { type: Type.STRING } },
              humanReviewWarning: { type: Type.STRING },
            },
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      res.json({
        mode,
        requiresHumanReview: true,
        ...parsed,
      });
    })
  );

  // Vite dev middleware vs static production dist
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AUREOM PRIMARY server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
