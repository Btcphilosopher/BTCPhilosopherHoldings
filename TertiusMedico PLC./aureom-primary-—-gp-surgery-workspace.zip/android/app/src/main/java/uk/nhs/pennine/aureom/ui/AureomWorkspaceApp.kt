package uk.nhs.pennine.aureom.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uk.nhs.pennine.aureom.data.DraftSyncStatus

enum class AndroidNavDestination(val label: String) {
    TODAY("Today"),
    APPOINTMENTS("Appointments"),
    PATIENTS("Patients"),
    REQUESTS("Requests"),
    CONSULTATIONS("Consultations"),
    PRESCRIPTIONS("Prescriptions"),
    RESULTS("Results"),
    REFERRALS("Referrals"),
    DOCUMENTS("Documents"),
    TASKS("Tasks"),
    PRACTICE("Practice")
}

@Composable
fun AureomWorkspaceApp(
    widthSizeClass: WindowWidthSizeClass,
    clinicianName: String,
    clinicianRole: String,
    activePatientName: String?,
    activePatientNhs: String?,
    allergyBanner: String?,
    syncStatus: DraftSyncStatus
) {
    val isTablet = widthSizeClass != WindowWidthSizeClass.Compact
    var selectedDest by remember { mutableStateOf(AndroidNavDestination.TODAY) }
    var presentingConcern by remember(activePatientName) { mutableStateOf("") }
    var planText by remember(activePatientName) { mutableStateOf("") }

    AureomTheme {
        Scaffold(
            topBar = {
                Column(modifier = Modifier.fillMaxWidth().background(Color.White)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NhsDarkBlue)
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Independent Prototype · Pennine Medical Practice (ODS Y89012)",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Text(
                            text = "Sync: ${syncStatus.name}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    if (activePatientName != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White)
                                .border(1.dp, Color(0xFFD8DDE0))
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .semantics(mergeDescendants = true) { heading() }
                        ) {
                            Text(
                                text = "$activePatientName · NHS $activePatientNhs",
                                fontWeight = FontWeight.Bold,
                                color = NhsDarkBlue,
                                style = MaterialTheme.typography.titleSmall
                            )
                            if (allergyBanner != null) {
                                Text(
                                    text = allergyBanner,
                                    color = NhsInk,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            },
            bottomBar = {
                if (!isTablet) {
                    NavigationBar(containerColor = Color.White) {
                        listOf(
                            AndroidNavDestination.TODAY,
                            AndroidNavDestination.APPOINTMENTS,
                            AndroidNavDestination.CONSULTATIONS,
                            AndroidNavDestination.RESULTS,
                            AndroidNavDestination.TASKS
                        ).forEach { dest ->
                            NavigationBarItem(
                                selected = selectedDest == dest,
                                onClick = { selectedDest = dest },
                                icon = { Icon(Icons.Default.MedicalServices, contentDescription = dest.label) },
                                label = { Text(dest.label, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                if (isTablet) {
                    NavigationRail(containerColor = Color.White) {
                        AndroidNavDestination.entries.take(7).forEach { dest ->
                            NavigationRailItem(
                                selected = selectedDest == dest,
                                onClick = { selectedDest = dest },
                                icon = { Icon(Icons.Default.MedicalServices, contentDescription = dest.label) },
                                label = { Text(dest.label, maxLines = 1) }
                            )
                        }
                    }
                }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NhsPaleGrey)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "${selectedDest.label} · $clinicianName ($clinicianRole)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.semantics { heading() }
                    )
                    if (selectedDest == AndroidNavDestination.CONSULTATIONS) {
                        OutlinedTextField(
                            value = presentingConcern,
                            onValueChange = { presentingConcern = it },
                            label = { Text("Presenting Concern (Patient-Locked Draft)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = planText,
                            onValueChange = { planText = it },
                            label = { Text("Management Plan & Safety-Netting") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Note signing requires server validation; offline drafts queue via WorkManager.",
                            style = MaterialTheme.typography.bodySmall,
                            color = NhsMuted
                        )
                    } else {
                        Text(
                            text = "Adaptive tablet/phone view connected to Ktor API with TalkBack headings, >=48dp touch targets, and scalable text.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
