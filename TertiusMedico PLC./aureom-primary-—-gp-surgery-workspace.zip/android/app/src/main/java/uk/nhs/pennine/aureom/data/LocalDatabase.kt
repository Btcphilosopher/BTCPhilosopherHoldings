package uk.nhs.pennine.aureom.data

import androidx.room.*

enum class DraftSyncStatus { SYNCED, QUEUED_OFFLINE, CONFLICT }

@Entity(tableName = "local_consultation_drafts")
data class LocalConsultationDraftEntity(
    @PrimaryKey val draftId: String,
    val patientId: String,
    val appointmentId: String?,
    val serverNoteId: String?,
    val expectedVersion: Int,
    val templateName: String,
    val presentingConcern: String,
    val historyText: String,
    val examinationText: String,
    val assessmentText: String,
    val planText: String,
    val syncStatus: DraftSyncStatus,
    val updatedAtIso: String,
    val conflictMessage: String? = null
)

@Entity(tableName = "cache_metadata")
data class CacheMetadataEntity(
    @PrimaryKey val cacheKey: String,
    val fetchedAtIso: String,
    val scopedRole: String
)

@Dao
interface ConsultationDraftDao {
    @Query("SELECT * FROM local_consultation_drafts WHERE patientId = :patientId ORDER BY updatedAtIso DESC LIMIT 1")
    suspend fun getDraftForPatient(patientId: String): LocalConsultationDraftEntity?

    @Query("SELECT * FROM local_consultation_drafts WHERE syncStatus = 'QUEUED_OFFLINE'")
    suspend fun getPendingSyncDrafts(): List<LocalConsultationDraftEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDraft(draft: LocalConsultationDraftEntity)

    @Query("DELETE FROM local_consultation_drafts")
    suspend fun clearAllOnSignOut()
}

@Database(
    entities = [LocalConsultationDraftEntity::class, CacheMetadataEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AureomLocalDatabase : RoomDatabase() {
    abstract fun consultationDraftDao(): ConsultationDraftDao
}
