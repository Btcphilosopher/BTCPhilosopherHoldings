package uk.nhs.pennine.aureom.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NhsBlue = Color(0xFF005EB8)
val NhsDarkBlue = Color(0xFF003087)
val NhsPaleGrey = Color(0xFFF0F4F5)
val NhsTeal = Color(0xFF007F7F)
val NhsInk = Color(0xFF212B32)
val NhsMuted = Color(0xFF4C6272)
val NhsAlertRed = Color(0xFFD5281B)

private val AureomLightColors = lightColorScheme(
    primary = NhsBlue,
    onPrimary = Color.White,
    secondary = NhsTeal,
    onSecondary = Color.White,
    background = NhsPaleGrey,
    onBackground = NhsInk,
    surface = Color.White,
    onSurface = NhsInk,
    surfaceVariant = NhsPaleGrey,
    onSurfaceVariant = NhsMuted,
    error = NhsAlertRed,
    onError = Color.White
)

@Composable
fun AureomTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AureomLightColors,
        content = content
    )
}
