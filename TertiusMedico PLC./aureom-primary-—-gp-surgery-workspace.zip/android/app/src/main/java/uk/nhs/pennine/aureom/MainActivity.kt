package uk.nhs.pennine.aureom

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import uk.nhs.pennine.aureom.data.DraftSyncStatus
import uk.nhs.pennine.aureom.ui.AureomWorkspaceApp

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val windowSizeClass = calculateWindowSizeClass(this)
            AureomWorkspaceApp(
                widthSizeClass = windowSizeClass.widthSizeClass,
                clinicianName = "Dr Eleanor Vance",
                clinicianRole = "GP",
                activePatientName = "Margaret Thornton",
                activePatientNhs = "943 476 5919 (VERIFIED)",
                allergyBanner = "Allergies: Penicillin V (MODERATE)",
                syncStatus = DraftSyncStatus.SYNCED
            )
        }
    }
}
