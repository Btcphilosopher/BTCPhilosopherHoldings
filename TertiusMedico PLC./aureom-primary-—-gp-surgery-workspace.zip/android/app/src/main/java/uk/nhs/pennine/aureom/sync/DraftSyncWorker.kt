package uk.nhs.pennine.aureom.sync

import android.content.Context
import androidx.work.*
import uk.nhs.pennine.aureom.data.AureomLocalDatabase
import uk.nhs.pennine.aureom.data.DraftSyncStatus
import java.util.concurrent.TimeUnit

class DraftSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters,
    private val db: AureomLocalDatabase,
    private val remoteSyncFn: suspend (uk.nhs.pennine.aureom.data.LocalConsultationDraftEntity) -> SyncAttemptResult
) : CoroutineWorker(appContext, workerParams) {

    sealed class SyncAttemptResult {
        data class Success(val newVersion: Int, val serverNoteId: String) : SyncAttemptResult()
        data class Conflict(val serverMessage: String) : SyncAttemptResult()
        data object TransientError : SyncAttemptResult()
    }

    override suspend fun doWork(): Result {
        val dao = db.consultationDraftDao()
        val pending = dao.getPendingSyncDrafts()
        if (pending.isEmpty()) return Result.success()

        var retryNeeded = false
        for (draft in pending) {
            when (val res = remoteSyncFn(draft)) {
                is SyncAttemptResult.Success -> {
                    dao.upsertDraft(
                        draft.copy(
                            serverNoteId = res.serverNoteId,
                            expectedVersion = res.newVersion,
                            syncStatus = DraftSyncStatus.SYNCED,
                            conflictMessage = null
                        )
                    )
                }
                is SyncAttemptResult.Conflict -> {
                    // Explicit conflict state surfaced to clinician UI — never silently overwrites
                    dao.upsertDraft(
                        draft.copy(
                            syncStatus = DraftSyncStatus.CONFLICT,
                            conflictMessage = res.serverMessage
                        )
                    )
                }
                SyncAttemptResult.TransientError -> retryNeeded = true
            }
        }
        return if (retryNeeded) Result.retry() else Result.success()
    }

    companion object {
        fun enqueue(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val req = OneTimeWorkRequestBuilder<DraftSyncWorker>()
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "aureom_draft_sync",
                ExistingWorkPolicy.KEEP,
                req
            )
        }
    }
}
