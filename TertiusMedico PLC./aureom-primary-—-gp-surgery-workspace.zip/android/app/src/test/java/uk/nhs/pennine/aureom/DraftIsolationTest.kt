package uk.nhs.pennine.aureom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import uk.nhs.pennine.aureom.data.DraftSyncStatus
import uk.nhs.pennine.aureom.data.LocalConsultationDraftEntity

class DraftIsolationTest {
    @Test
    fun draft_is_bound_to_single_patient_and_surfaces_conflict() {
        val margaretDraft = LocalConsultationDraftEntity(
            draftId = "local-1",
            patientId = "pat-margaret",
            appointmentId = "apt-101",
            serverNoteId = "con-301",
            expectedVersion = 2,
            templateName = "GP Chronic Disease & Acute Review",
            presentingConcern = "HbA1c review",
            historyText = "",
            examinationText = "",
            assessmentText = "",
            planText = "Repeat U&Es",
            syncStatus = DraftSyncStatus.QUEUED_OFFLINE,
            updatedAtIso = "2026-11-24T09:05:00Z"
        )
        assertNotEquals("pat-dorothy", margaretDraft.patientId)

        val conflicted = margaretDraft.copy(
            syncStatus = DraftSyncStatus.CONFLICT,
            conflictMessage = "Server is at v3"
        )
        assertEquals(DraftSyncStatus.CONFLICT, conflicted.syncStatus)
    }
}
