package uk.nhs.pennine.aureom

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.transactions.transaction
import java.sql.SQLException
import java.time.Instant
import java.util.UUID

class ClinicalDomainException(
    val statusCode: HttpStatusCode,
    val errorCode: String,
    override val message: String
) : RuntimeException(message)

fun main() {
    embeddedServer(Netty, port = 8080, host = "0.0.0.0", module = Application::aureomModule).start(wait = true)
}

fun Application.aureomModule() {
    val dbUrl = System.getenv("DATABASE_URL") ?: "jdbc:postgresql://localhost:5432/aureom_primary"
    val dbUser = System.getenv("DB_USER") ?: "aureom"
    val dbPassword = System.getenv("DB_PASSWORD") ?: "aureom_local_dev_only"
    val jwtSecret = System.getenv("SESSION_SECRET") ?: UUID.randomUUID().toString()

    val hikari = HikariConfig().apply {
        jdbcUrl = dbUrl
        username = dbUser
        password = dbPassword
        maximumPoolSize = 10
        isAutoCommit = false
        transactionIsolation = "TRANSACTION_SERIALIZABLE"
    }
    Database.connect(HikariDataSource(hikari))

    install(ContentNegotiation) {
        json()
    }

    install(StatusPages) {
        exception<ClinicalDomainException> { call, cause ->
            call.respond(
                cause.statusCode,
                ApiErrorResponse(error = cause.errorCode, message = cause.message)
            )
        }
        exception<SQLException> { call, cause ->
            // PostgreSQL 23P01 = exclusion_violation (double-booking prevented at DB transaction level)
            if (cause.sqlState == "23P01") {
                call.respond(
                    HttpStatusCode.Conflict,
                    ApiErrorResponse(
                        error = "BOOKING_CONFLICT",
                        message = "Slot conflicts with an existing clinician or room booking."
                    )
                )
            } else {
                call.respond(
                    HttpStatusCode.InternalServerError,
                    ApiErrorResponse(error = "DATABASE_ERROR", message = "Database transaction failed.")
                )
            }
        }
    }

    install(Authentication) {
        jwt("staff-jwt") {
            verifier(JWT.require(Algorithm.HMAC256(jwtSecret)).withIssuer("aureom-primary").build())
            validate { credential ->
                val staffId = credential.payload.getClaim("staffId").asString()
                val role = credential.payload.getClaim("role").asString()
                val mfa = credential.payload.getClaim("mfaVerified").asBoolean() ?: false
                if (!staffId.isNullOrBlank() && !role.isNullOrBlank() && mfa) {
                    JWTPrincipal(credential.payload)
                } else null
            }
        }
    }

    routing {
        get("/health") {
            call.respond(mapOf("status" to "ok", "prototype" to "Pennine Medical Practice"))
        }

        authenticate("staff-jwt") {
            post("/api/appointments") {
                val principal = call.principal<JWTPrincipal>()!!
                val role = StaffRole.valueOf(principal.payload.getClaim("role").asString())
                val staffId = principal.payload.getClaim("staffId").asString()
                val req = call.receive<BookAppointmentRequest>()

                if (req.overrideConflict && role !in setOf(StaffRole.GP, StaffRole.PRACTICE_MANAGER, StaffRole.ADMIN)) {
                    throw ClinicalDomainException(
                        HttpStatusCode.Forbidden,
                        "OVERRIDE_FORBIDDEN",
                        "Staff role $role cannot override double-booking constraints."
                    )
                }

                val aptId = "apt-${UUID.randomUUID().toString().take(8)}"
                transaction {
                    val conn = org.jetbrains.exposed.sql.transactions.TransactionManager.current().connection
                    val insertApt = conn.prepareStatement(
                        """
                        INSERT INTO appointments (
                            id, patient_id, clinician_id, room_id, appointment_type, mode,
                            start_time, end_time, duration_minutes, status, reason,
                            override_approved, override_reason
                        ) VALUES (
                            ?, ?, ?, ?, ?, ?::appointment_mode,
                            ?::timestamptz,
                            (?::timestamptz + (? * interval '1 minute')),
                            ?, 'BOOKED', ?, ?, ?
                        )
                        """.trimIndent(),
                        false
                    )
                    insertApt.fillParameters(
                        listOf(
                            org.jetbrains.exposed.sql.VarCharColumnType() to aptId,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.patientId,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.clinicianId,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.roomId,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.appointmentType,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.mode,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.startTimeIso,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.startTimeIso,
                            org.jetbrains.exposed.sql.IntegerColumnType() to req.durationMinutes,
                            org.jetbrains.exposed.sql.IntegerColumnType() to req.durationMinutes,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.reason,
                            org.jetbrains.exposed.sql.BooleanColumnType() to req.overrideConflict,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.overrideReason
                        )
                    )
                    insertApt.executeUpdate()

                    val insertAudit = conn.prepareStatement(
                        """
                        INSERT INTO audit_events (id, actor_id, actor_name, actor_role, action, entity_type, entity_id, patient_id, outcome, summary)
                        VALUES (?, ?, ?, ?, 'APPOINTMENT_BOOKED', 'Appointment', ?, ?, 'ALLOWED', 'Appointment booked via Ktor transactional endpoint.')
                        """.trimIndent(),
                        false
                    )
                    insertAudit.fillParameters(
                        listOf(
                            org.jetbrains.exposed.sql.VarCharColumnType() to "aud-${UUID.randomUUID().toString().take(8)}",
                            org.jetbrains.exposed.sql.VarCharColumnType() to staffId,
                            org.jetbrains.exposed.sql.VarCharColumnType() to staffId,
                            org.jetbrains.exposed.sql.VarCharColumnType() to role.name,
                            org.jetbrains.exposed.sql.VarCharColumnType() to aptId,
                            org.jetbrains.exposed.sql.VarCharColumnType() to req.patientId
                        )
                    )
                    insertAudit.executeUpdate()
                }
                call.respond(HttpStatusCode.Created, mapOf("appointmentId" to aptId, "status" to "BOOKED"))
            }

            post("/api/prescriptions/{id}/submit-eps") {
                val rxId = call.parameters["id"] ?: throw ClinicalDomainException(HttpStatusCode.BadRequest, "MISSING_ID", "Missing prescription ID")
                val idempotencyKey = call.request.headers["Idempotency-Key"]
                    ?: throw ClinicalDomainException(HttpStatusCode.BadRequest, "IDEMPOTENCY_KEY_REQUIRED", "Idempotency-Key header required.")

                // Simulated EPS Adapter keeping local approval separate from external transmission
                val epsToken = "EPS-SIM-${UUID.randomUUID().toString().take(8).uppercase()}"
                val result = EpsTransmissionResult(
                    prescriptionId = rxId,
                    status = PrescriptionStatus.CONFIRMED,
                    epsMessageId = epsToken,
                    idempotencyKey = idempotencyKey
                )
                call.respond(HttpStatusCode.OK, result)
            }
        }
    }
}
