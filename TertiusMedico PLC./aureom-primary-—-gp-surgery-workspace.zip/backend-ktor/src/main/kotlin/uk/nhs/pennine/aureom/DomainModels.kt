package uk.nhs.pennine.aureom

import kotlinx.serialization.Serializable

@Serializable
enum class StaffRole { RECEPTION, GP, NURSE, PRACTICE_MANAGER, ADMIN }

@Serializable
enum class ClinicalDataState { RECORDED, EXPLICITLY_ABSENT, UNKNOWN, NOT_ASSESSED }

@Serializable
enum class AppointmentStatus { BOOKED, ARRIVED, WAITING, IN_CONSULTATION, COMPLETED, DID_NOT_ATTEND, CANCELLED }

@Serializable
enum class ConsultationStatus { DRAFT, SIGNED, AMENDED, ENTERED_IN_ERROR }

@Serializable
enum class PrescriptionStatus { REQUESTED, UNDER_REVIEW, APPROVED, DECLINED, SUBMITTED_TO_EPS, CONFIRMED, FAILED }

@Serializable
data class ApiErrorResponse(
    val error: String,
    val message: String,
    val conflictId: String? = null
)

@Serializable
data class BookAppointmentRequest(
    val patientId: String,
    val clinicianId: String,
    val roomId: String,
    val appointmentType: String,
    val mode: String,
    val startTimeIso: String,
    val durationMinutes: Int,
    val reason: String,
    val overrideConflict: Boolean = false,
    val overrideReason: String? = null
)

@Serializable
data class ConsultationDraftRequest(
    val id: String? = null,
    val patientId: String,
    val appointmentId: String? = null,
    val expectedVersion: Int? = null,
    val templateName: String,
    val presentingConcern: String,
    val historyText: String,
    val examinationText: String,
    val assessmentText: String,
    val planText: String
)

@Serializable
data class EpsTransmissionResult(
    val prescriptionId: String,
    val status: PrescriptionStatus,
    val epsMessageId: String? = null,
    val errorDetail: String? = null,
    val idempotencyKey: String
)

@Serializable
data class ProxyPolicyCheck(
    val proxyId: String,
    val verificationStatus: String,
    val hasRecordAccess: Boolean,
    val accessScope: List<String>,
    val effectiveFrom: String,
    val effectiveTo: String? = null,
    val revokedAt: String? = null
) {
    fun permits(scope: String, asOfDate: String): Boolean {
        if (revokedAt != null) return false
        if (verificationStatus != "VERIFIED") return false
        if (!hasRecordAccess || accessScope.isEmpty()) return false
        if (asOfDate < effectiveFrom) return false
        if (effectiveTo != null && asOfDate > effectiveTo) return false
        return scope in accessScope
    }
}
