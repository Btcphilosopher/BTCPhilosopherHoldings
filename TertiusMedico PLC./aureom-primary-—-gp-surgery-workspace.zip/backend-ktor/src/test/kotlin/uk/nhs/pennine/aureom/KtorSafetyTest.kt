package uk.nhs.pennine.aureom

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class KtorSafetyTest {
    @Test
    fun `proxy access denies shared address or emergency contact without verified scope`() {
        val emergencyContactOnly = ProxyPolicyCheck(
            proxyId = "proxy-2",
            verificationStatus = "VERIFIED",
            hasRecordAccess = false,
            accessScope = emptyList(),
            effectiveFrom = "2026-01-10"
        )
        assertFalse(emergencyContactOnly.permits("SUMMARY", "2026-11-24"))

        val unverified = ProxyPolicyCheck(
            proxyId = "proxy-unverified",
            verificationStatus = "UNVERIFIED",
            hasRecordAccess = true,
            accessScope = listOf("SUMMARY"),
            effectiveFrom = "2026-01-10"
        )
        assertFalse(unverified.permits("SUMMARY", "2026-11-24"))

        val verifiedParent = ProxyPolicyCheck(
            proxyId = "proxy-1",
            verificationStatus = "VERIFIED",
            hasRecordAccess = true,
            accessScope = listOf("APPOINTMENTS", "PRESCRIPTIONS"),
            effectiveFrom = "2019-11-05",
            effectiveTo = "2035-11-05"
        )
        assertTrue(verifiedParent.permits("APPOINTMENTS", "2026-11-24"))
        assertFalse(verifiedParent.permits("SUMMARY", "2026-11-24"))
    }
}
