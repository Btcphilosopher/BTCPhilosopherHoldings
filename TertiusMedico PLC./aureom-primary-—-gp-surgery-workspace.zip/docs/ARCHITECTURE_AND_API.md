# AUREOM PRIMARY — GP Surgery Workspace
**Independent Prototype Demonstration · Fictional Pennine Medical Practice (ODS Y89012)**

## 1. Architecture & Implementation Sequence
1. **Core Domain & RBAC Security (`server/domain.ts`, `server/auth.ts`, `migrations/001_initial_schema.sql`)**:
   - Server-enforced role scoping (`RECEPTION`, `GP`, `NURSE`, `PRACTICE_MANAGER`, `ADMIN`, `PATIENT`).
   - Organisational MFA sign-in, in-memory Bearer tokens, session-version revocation, and reasoned 2-hour break-glass emergency access.
2. **Core Clinical Workflow First**:
   - `Request -> Appointment -> Arrival -> Consultation -> Signed Note -> Follow-Up -> Audit`
3. **Clinical Safety & Interoperability Adapters**:
   - Separate Prescribing (`REQUESTED -> UNDER_REVIEW -> APPROVED/DECLINED -> SUBMITTED_TO_EPS -> CONFIRMED/FAILED`), Results (`viewedAt` != `actioned`, corrected report linkage), Referrals (`DRAFT -> CLINICALLY_REVIEWED -> TRANSMITTED -> ACCEPTED`), OCR Document confirmation, Governed Recalls, and Patient Portal release isolation.
4. **Clients**:
   - Browser Reception & Clinical Console (React + TypeScript + Tailwind CSS on Port 3000).
   - Kotlin + Jetpack Compose Android App (`/android`) with Material 3 adaptive `NavigationRail` (tablets) / `NavigationBar` (phones), Room offline drafts, and WorkManager sync.

## 2. Screen Map
- **Auth Gate**: Staff Role + MFA Verification / Patient Portal Demo Sign-In.
- **Main 11-Tab Navigation**: `Today · Appointments · Patients · Requests · Consultations · Prescriptions · Results · Referrals · Documents · Tasks · Practice`.
- **Persistent Clinical Context Header**: Active patient full name, DOB, NHS Number verification status, sex, explicit allergy state (`RECORDED` / `EXPLICITLY_ABSENT` / `UNKNOWN` / `NOT_ASSESSED`), and encounter ID.
- **Patient Portal**: Released messages, released documents, appointments/cancellations, repeat medication requests, contact/notification preferences.

## 3. Repository Structure
- `server.ts`, `server/domain.ts`, `server/auth.ts`, `server/seed.ts` — Running Node/Express API + Vite middleware + durable state engine.
- `src/` — React + TypeScript Reception, Clinical & Patient Portal UI.
- `tests/domain.test.ts` — Executed automated tests for all 8 clinical safety/concurrency scenarios.
- `migrations/` — PostgreSQL 16 DDL (`001_initial_schema.sql`) and seed (`002_seed_pennine_practice.sql`).
- `backend-ktor/` — Kotlin + Ktor 3.0.1 + Exposed + PostgreSQL server source.
- `android/` — Kotlin + Jetpack Compose + Room + WorkManager Android app source.
- `docker-compose.yml` — PostgreSQL 16 + MinIO object storage + Ktor + Web Console.

## 4. API Documentation Summary
- `GET /api/directory` — Public prototype staff/patient selector (no clinical data).
- `POST /api/auth/login` — Staff MFA / Patient Portal authentication returning HMAC Bearer token.
- `GET /api/workspace` — Server-scoped workspace payload tailored to caller role & break-glass grants.
- `POST /api/patients/:id/emergency-access` — Reasoned 2-hour break-glass access for restricted records.
- `POST /api/patients`, `PATCH /api/patients/:id/identity`, `POST /api/duplicates/:id/resolve`, `POST /api/proxies`, `POST /api/proxies/:id/revoke` — Patient registration, duplicate matching, identity correction, and scoped proxy control.
- `POST /api/requests`, `PATCH /api/requests/:id` — Shared inbox intake & manual staff prioritisation/routing.
- `POST /api/appointments`, `POST /api/appointments/:id/status` — Transactional booking with conflict detection (`409 BOOKING_CONFLICT`) & arrival states.
- `POST /api/consultations/draft`, `POST /api/consultations/:id/sign`, `POST /api/consultations/:id/amend`, `POST /api/consultations/:id/entered-in-error` — Versioned drafts (`409 VERSION_CONFLICT`), patient-lock (`409 PATIENT_CONTEXT_MISMATCH`), immutable notes.
- `POST /api/prescriptions`, `POST /api/prescriptions/:id/review`, `POST /api/prescriptions/:id/submit-eps` — Separate approval vs idempotent EPS transmission.
- `POST /api/results/:id/view`, `POST /api/results/:id/action`, `POST /api/results/:id/correct` — Results workflow & corrected report chaining.
- `POST /api/referrals`, `POST /api/documents/:id/process`, `POST /api/tasks`, `POST /api/recalls/:id/stage`, `POST /api/portal/submissions`, `POST /api/ai/assist`, `GET /api/admin/backup`, `POST /api/admin/restore`.

## 5. Deployment & Android Build Commands
- **Local Web + API Runtime**: `npm install && npm run dev` (Port 3000) · Tests: `npm test`.
- **Docker Compose (PostgreSQL + MinIO + Ktor + Web)**: `docker compose up --build -d`.
- **PostgreSQL Backup / Restore**: `pg_dump -U aureom aureom_primary > backup.sql` / `psql -U aureom aureom_primary < backup.sql`.
- **Android Debug / Release APK**:
  ```bash
  cd android
  ./gradlew assembleDebug          # Output: app/build/outputs/apk/debug/app-debug.apk
  ./gradlew testDebugUnitTest      # Runs DraftIsolationTest
  ```

## 6. Verified NHS Regulatory, Clinical Safety, Privacy & Accessibility Requirements
Verified against official NHS England (`digital.nhs.uk`) and UK Government (`gov.uk`) guidance for an English NHS GP practice deployment:
- **Clinical Safety (Health and Social Care Act 2012)**: Mandatory **DCB0129** (manufacturer clinical risk management, Clinical Safety Officer, Hazard Log, Safety Case Report) and **DCB0160** (deploying practice local clinical risk assessment).
- **National Integrations**: **PDS FHIR API** (demographic trace), **GP Connect** (Access Record HTML/Structured, HSCN connectivity), **EPS** (Electronic Prescription Service conformance), **e-RS** (electronic Referral Service), and **NHS App / NHS Login** — all require ODS code, NHS Digital Onboarding Service (DOS) approval, and Connection Agreements.
- **Information Governance & Privacy**: **UK GDPR & Data Protection Act 2018** (Special Category health data, mandatory DPIA, encryption at rest/in transit, data minimisation) and annual **Data Security and Protection Toolkit (DSPT)** publication.
- **Medical Device Regulation**: **MHRA** Software / AI as a Medical Device (SaMD / AIaMD) rules under UK Medical Devices Regulations 2002; optional AI here is strictly constrained to non-diagnostic administrative/drafting assistance requiring human review.
- **Accessibility**: **Public Sector Bodies Accessibility Regulations** & NHS **DTAC** targeting **WCAG 2.2 AA** (keyboard navigation, visible focus, scalable text, reduced motion, TalkBack semantics, no hue-only signalling).

## 7. Capability Matrix (Implemented / Simulated / Integrated / Tested)
| Capability | Status | Notes |
| --- | --- | --- |
| Reception & Clinical Web Console (11 modules + Patient Portal) | **Implemented** | Live React + TypeScript + Express runtime on port 3000 |
| Server-side RBAC, MFA check, session revocation, break-glass, audit log | **Implemented & Tested** | Enforced on Express API & verified in `tests/domain.test.ts` |
| Transactional Double-Booking Prevention & Override | **Implemented & Tested** | Enforced in Node domain + PostgreSQL `btree_gist` migration |
| Immutable Signed Notes, Optimistic Concurrency, Patient Isolation | **Implemented & Tested** | Enforced in Node domain + PostgreSQL trigger + Room entity |
| Proxy Policy (No auto-access via address/emergency contact) | **Implemented & Tested** | Enforced in Node domain, PostgreSQL `CHECK`, and Ktor unit test |
| Optional AI Drafting Support (`@google/genai` `gemini-4-hydrogen`) | **Integrated (Disabled by Default)** | Server-side `/api/ai/assist` when `GEMINI_API_KEY` configured & Admin enables flag |
| EPS, e-RS, Video Provider, PDS Trace, NHS App Portal Adapter | **Simulated** | Explicit simulated adapters with idempotency keys and failure toggles |
| PostgreSQL Migrations, Ktor Server, Jetpack Compose Android App | **Source Delivered** | Ready for Docker Compose / Gradle build (JVM/Android SDK not present in Node preview container) |
