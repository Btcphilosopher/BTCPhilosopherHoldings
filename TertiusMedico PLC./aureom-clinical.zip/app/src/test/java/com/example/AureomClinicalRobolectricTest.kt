package com.example

import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.database.AureomDatabase
import com.example.core.model.*
import com.example.core.network.ClinicalApiClient
import com.example.core.network.ClinicalApiException
import com.example.core.repository.ClinicalRepository
import com.example.core.repository.UiResource
import com.example.core.security.CredentialVault
import com.example.core.sync.ClinicalSyncExecutor
import com.example.core.sync.SyncScheduler
import com.example.ui.navigation.AureomAppRoot
import com.example.ui.viewmodel.AureomViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.Instant

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AureomClinicalRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  private lateinit var context: Context
  private lateinit var db: AureomDatabase
  private lateinit var repo: ClinicalRepository
  private lateinit var viewModel: AureomViewModel

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    db = Room.inMemoryDatabaseBuilder(context, AureomDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    val vault = CredentialVault(context)
    val api = ClinicalApiClient()
    val syncExec = ClinicalSyncExecutor(db, api, vault)
    val syncScheduler = SyncScheduler(context)
    repo = ClinicalRepository(context, db, vault, api, syncExec, syncScheduler)
    viewModel = AureomViewModel(repo)
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `patient isolation blocks out-of-context patient until break-glass emergency access`() = runBlocking {
    val auth = repo.signInWithOidc("dr.jenkins", "CTX-AMU-A").getOrThrow()
    assertEquals("DOCTOR", auth.clinician.role)

    // PAT-9001 is in CTX-RENAL-WARD -> denied
    repo.openPatientOverview("PAT-9001")
    val deniedState = repo.patientOverviewState.value
    assertTrue(deniedState is UiResource.Error && deniedState.isPermissionDenied)

    // Emergency break-glass with reason grants audited access
    val grant = repo.requestEmergencyAccess("PAT-9001", "Urgent cross-cover renal potassium review").getOrThrow()
    assertEquals("PENDING_CALDICOTT_REVIEW", grant.reviewStatus)

    val allowedState = repo.patientOverviewState.value
    assertTrue(allowedState is UiResource.Success)
    assertTrue((allowedState as UiResource.Success).data.patient.emergencyAccessActive)
  }

  @Test
  fun `role permissions prevent nurse from signing and auditor from saving drafts`() = runBlocking {
    val nurse = repo.signInWithOidc("nurse.patel", "CTX-AMU-A").getOrThrow()
    assertEquals("NURSE", nurse.clinician.role)
    repo.openPatientOverview("PAT-1001")
    val draft = db.clinicalCacheDao().getDraftById("NOTE-302")!!
    val nurseSign = repo.signNote(draft, "PAT-1001")
    assertTrue(nurseSign.isFailure)
    assertTrue(nurseSign.exceptionOrNull() is ClinicalApiException.Forbidden)

    val auditor = repo.signInWithOidc("auditor.cole", "CTX-AMU-A").getOrThrow()
    assertEquals("AUDITOR", auditor.clinician.role)
    val auditDraft = draft.copy(freeText = "Attempt by auditor", dirty = true)
    val auditorSave = repo.submitOrQueueNoteDraft(auditDraft)
    assertTrue(auditorSave.isFailure)
    assertTrue(auditorSave.exceptionOrNull() is ClinicalApiException.Forbidden)
  }

  @Test
  fun `offline draft, reconnect conflict detection, signing immutability, retries, and amendment`() = runBlocking {
    repo.signInWithOidc("dr.jenkins", "CTX-AMU-A").getOrThrow()
    repo.openPatientOverview("PAT-1001")

    // Go offline and autosave draft locally
    repo.setOfflineSimulated(true)
    val offlineDraft = repo.autosaveNoteDraft(
      noteId = "NOTE-302",
      expectedPatientId = "PAT-1001",
      patientName = "Arthur Pendelton",
      encounterId = "ENC-2001",
      templateType = NoteTemplateType.WARD_ROUND,
      title = "Morning Consultant Ward Round",
      sections = listOf(NoteSectionDto("plan", "Management Plan", "Offline plan for K+ 5.8")),
      freeText = "Offline edit by Dr Jenkins",
      copiedAttributions = emptyList(),
      baseVersion = 1L,
    )
    val queueRes = repo.submitOrQueueNoteDraft(offlineDraft)
    assertTrue(queueRes.isSuccess)
    assertEquals(1, db.clinicalCacheDao().getSyncableOps().size)

    // Another clinician updates NOTE-302 on server while offline
    assertTrue(repo.simulateServerConcurrentEdit("NOTE-302"))

    // Reconnect and sync -> conflict detected, NOT silently overwritten
    repo.setOfflineSimulated(false)
    val syncOutcome = repo.triggerManualSync()
    assertTrue(syncOutcome is ClinicalSyncExecutor.SyncOutcome.ConflictDetected)
    val conflicted = db.clinicalCacheDao().getDraftById("NOTE-302")!!
    assertEquals("CONFLICT", conflicted.status)
    assertEquals("Offline edit by Dr Jenkins", conflicted.freeText)

    // Rebase local changes onto server v2 -> succeeds
    val ov = (repo.patientOverviewState.value as UiResource.Success).data
    val serverNote = ov.previousNotes.first { it.noteId == "NOTE-302" }
    val resolved = repo.resolveDraftConflict(conflicted, keepLocalChanges = true, serverNote = serverNote)
    assertTrue(resolved.isSuccess)
    assertTrue(db.clinicalCacheDao().observePendingOps().first().isEmpty())

    // Sign note and verify immutability + amendment
    val latestDraft = db.clinicalCacheDao().getDraftById("NOTE-302")!!
    val signed = repo.signNote(latestDraft, "PAT-1001").getOrThrow()
    assertEquals("SIGNED", signed.status)
    assertNotNull(signed.contentHash)

    // Idempotent retry on same signature key does not fail or duplicate
    val token = repo.session.value!!.accessToken
    val retrySign = repo.api.signNote(
      token,
      "NOTE-302",
      SignNoteRequest("PAT-1001", latestDraft.baseVersion, "sign-NOTE-302-v${latestDraft.baseVersion}"),
    )
    assertEquals(signed.signedAt, retrySign.signedAt)

    // Attempting to edit signed note returns Conflict (immutable)
    val tamperResult = runCatching {
      repo.api.saveNoteDraft(
        token,
        SaveNoteDraftRequest(
          noteId = "NOTE-302",
          patientId = "PAT-1001",
          encounterId = "ENC-2001",
          templateType = "WARD_ROUND",
          title = "Tamper",
          sections = emptyList(),
          freeText = "Tamper",
          expectedVersion = signed.version,
        ),
      )
    }
    assertTrue(tamperResult.exceptionOrNull() is ClinicalApiException.Conflict)

    // Linked amendment succeeds
    val amended = repo.addAmendment("NOTE-302", "PAT-1001", "AMENDMENT", "ECG normal, repeat K+ ordered.", "ECG verification").getOrThrow()
    assertEquals(1, amended.amendments.size)
  }

  @Test
  fun `corrected result workflow and missing observation preservation`() = runBlocking {
    repo.signInWithOidc("dr.jenkins", "CTX-AMU-A").getOrThrow()
    repo.openPatientOverview("PAT-1001")
    val ov = (repo.patientOverviewState.value as UiResource.Success).data

    // Missing Capillary Blood Glucose must remain null rather than 0.0
    val glucose = ov.recentObservations.first { it.observationId == "OBS-104" }
    assertNull(glucose.valueNumeric)
    assertEquals("MISSING", glucose.abnormalFlag)

    // Corrected result RES-201 supersedes RES-200 and starts in AVAILABLE
    val corrected = ov.diagnosticResults.first { it.resultId == "RES-201" }
    assertEquals("CORRECTED", corrected.resultStatus)
    assertEquals("RES-200", corrected.supersedesResultId)
    assertEquals("AVAILABLE", corrected.workflowState)

    val viewed = repo.updateResultWorkflow("RES-201", "PAT-1001", "VIEWED").getOrThrow()
    assertEquals("VIEWED", viewed.workflowState)

    val acked = repo.updateResultWorkflow("RES-201", "PAT-1001", "ACKNOWLEDGED").getOrThrow()
    assertEquals("ACKNOWLEDGED", acked.workflowState)

    // Creating task linked to RES-201 advances result to FOLLOW_UP_ASSIGNED; completing advances to ACTION_COMPLETED
    val task = repo.createFollowUpTask(
      CreateTaskRequest(
        patientId = "PAT-1001",
        encounterId = "ENC-2001",
        linkedResultId = "RES-201",
        title = "Repeat serum K+",
        description = "Check non-haemolysed venous K+ at 10:00",
        ownerName = "Dr Sarah Jenkins",
        priority = "URGENT",
        dueAt = Instant.now().plusSeconds(3600).toString(),
      )
    ).getOrThrow()
    val ovAfterTask = (repo.patientOverviewState.value as UiResource.Success).data
    assertEquals("FOLLOW_UP_ASSIGNED", ovAfterTask.diagnosticResults.first { it.resultId == "RES-201" }.workflowState)

    repo.completeFollowUpTask(task.taskId, "PAT-1001", "Repeat venous K+ 4.6 mmol/L", task.version).getOrThrow()
    val ovAfterComplete = (repo.patientOverviewState.value as UiResource.Success).data
    assertEquals("ACTION_COMPLETED", ovAfterComplete.diagnosticResults.first { it.resultId == "RES-201" }.workflowState)
  }

  @Test
  fun `cache purge on sign out and session expiry enforcement`() = runBlocking {
    repo.signInWithOidc("dr.jenkins", "CTX-AMU-A").getOrThrow()
    repo.openPatientOverview("PAT-1001")
    assertNotNull(db.clinicalCacheDao().getPatientCache("PAT-1001"))

    // Simulate session expiry -> clears active session cleanly
    repo.simulateSessionExpiry()
    assertNull(repo.session.value)

    // Sign back in, cache record, then sign out -> cache purged
    repo.signInWithOidc("dr.jenkins", "CTX-AMU-A").getOrThrow()
    repo.openPatientOverview("PAT-1001")
    assertNotNull(db.clinicalCacheDao().getPatientCache("PAT-1001"))

    repo.signOut(purgeLocalCache = true)
    assertNull(db.clinicalCacheDao().getPatientCache("PAT-1001"))
    assertEquals(0, db.clinicalCacheDao().observeAllDrafts().first().size)
  }

  @Test
  fun `compose UI journey signs in, loads worklist, and opens patient banner`() {
    composeTestRule.setContent {
      AureomAppRoot(viewModel = viewModel)
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("sign_in_button").performScrollTo().performClick()
    composeTestRule.waitUntil(5000) {
      composeTestRule.onAllNodesWithTag("today_worklist_list").fetchSemanticsNodes().isNotEmpty()
    }
    composeTestRule.onNodeWithTag("today_worklist_list").performScrollToNode(hasTestTag("appointment_card_PAT-1001"))
    composeTestRule.onNodeWithTag("appointment_card_PAT-1001").performClick()
    composeTestRule.waitUntil(5000) {
      composeTestRule.onAllNodesWithTag("persistent_patient_banner").fetchSemanticsNodes().isNotEmpty()
    }
    composeTestRule.onNodeWithTag("persistent_patient_banner").assertIsDisplayed()
  }
}
