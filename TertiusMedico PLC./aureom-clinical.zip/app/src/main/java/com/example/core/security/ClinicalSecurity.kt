package com.example.core.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.fragment.app.FragmentActivity
import com.example.core.model.AuthSessionResponse
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.securityDataStore: DataStore<Preferences> by preferencesDataStore(name = "aureom_secure_prefs")

/**
 * Redacted operational logger: never logs patient identifiers, clinical notes, or session tokens.
 */
object ClinicalLogger {
  private const val TAG = "AureomClinical"

  fun info(component: String, message: String) {
    Log.i(TAG, "[$component] $message")
  }

  fun warn(component: String, message: String) {
    Log.w(TAG, "[$component] $message")
  }

  fun error(component: String, message: String) {
    Log.e(TAG, "[$component] $message")
  }
}

class CredentialVault(private val context: Context) {
  private val json = Json { ignoreUnknownKeys = true }
  private val sessionBlobKey = stringPreferencesKey("encrypted_session_blob")
  private val biometricEnabledKey = booleanPreferencesKey("biometric_unlock_enabled")
  private val aiEnabledKey = booleanPreferencesKey("ai_drafting_enabled")
  private val reducedMotionKey = booleanPreferencesKey("reduced_motion_enabled")
  private val serverUrlKey = stringPreferencesKey("live_server_url")
  private val connectionModeKey = stringPreferencesKey("connection_mode")

  private val keystoreAlias = "aureom_session_aes_key_v1"

  val biometricUnlockEnabled: Flow<Boolean> = context.securityDataStore.data.map { it[biometricEnabledKey] ?: false }
  val aiDraftingEnabled: Flow<Boolean> = context.securityDataStore.data.map { it[aiEnabledKey] ?: false } // Disabled by default
  val reducedMotionEnabled: Flow<Boolean> = context.securityDataStore.data.map { it[reducedMotionKey] ?: false }
  val liveServerUrl: Flow<String> = context.securityDataStore.data.map { it[serverUrlKey] ?: "http://10.0.2.2:8080" }
  val connectionModeName: Flow<String> = context.securityDataStore.data.map { it[connectionModeKey] ?: "EMBEDDED_DEMO_SERVER" }

  suspend fun saveSession(session: AuthSessionResponse) {
    val serialized = json.encodeToString(session)
    val encrypted = encryptWithKeystore(serialized)
    context.securityDataStore.edit { prefs ->
      prefs[sessionBlobKey] = encrypted
    }
    ClinicalLogger.info("CredentialVault", "Encrypted session stored in Android Keystore-backed vault")
  }

  suspend fun loadSession(): AuthSessionResponse? {
    val prefs = context.securityDataStore.data.first()
    val blob = prefs[sessionBlobKey] ?: return null
    return runCatching {
      val decrypted = decryptWithKeystore(blob)
      json.decodeFromString<AuthSessionResponse>(decrypted)
    }.onFailure {
      ClinicalLogger.warn("CredentialVault", "Failed to decrypt local session blob; clearing vault")
      clearSession()
    }.getOrNull()
  }

  suspend fun hasStoredSession(): Boolean {
    val prefs = context.securityDataStore.data.first()
    return !prefs[sessionBlobKey].isNullOrBlank()
  }

  suspend fun clearSession() {
    context.securityDataStore.edit { prefs ->
      prefs.remove(sessionBlobKey)
    }
    ClinicalLogger.info("CredentialVault", "Cleared encrypted session from vault")
  }

  suspend fun setBiometricUnlockEnabled(enabled: Boolean) {
    context.securityDataStore.edit { it[biometricEnabledKey] = enabled }
  }

  suspend fun setAiDraftingEnabled(enabled: Boolean) {
    context.securityDataStore.edit { it[aiEnabledKey] = enabled }
  }

  suspend fun setReducedMotionEnabled(enabled: Boolean) {
    context.securityDataStore.edit { it[reducedMotionKey] = enabled }
  }

  suspend fun setServerConfig(mode: String, url: String) {
    context.securityDataStore.edit {
      it[connectionModeKey] = mode
      it[serverUrlKey] = url.trim().trimEnd('/')
    }
  }

  private fun encryptWithKeystore(plaintext: String): String {
    val key = getOrCreateSecretKey() ?: return "PLAIN_TEST_FALLBACK:${Base64.encodeToString(plaintext.toByteArray(), Base64.NO_WRAP)}"
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key)
    val iv = cipher.iv
    val cipherBytes = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
    val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
    val bodyB64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP)
    return "GCM_V1:$ivB64:$bodyB64"
  }

  private fun decryptWithKeystore(blob: String): String {
    if (blob.startsWith("PLAIN_TEST_FALLBACK:")) {
      return String(Base64.decode(blob.removePrefix("PLAIN_TEST_FALLBACK:"), Base64.NO_WRAP), Charsets.UTF_8)
    }
    require(blob.startsWith("GCM_V1:")) { "Unsupported vault payload format" }
    val parts = blob.split(":")
    val iv = Base64.decode(parts[1], Base64.NO_WRAP)
    val cipherBytes = Base64.decode(parts[2], Base64.NO_WRAP)
    val key = getOrCreateSecretKey() ?: error("AndroidKeyStore unavailable for decryption")
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
    return String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
  }

  private fun getOrCreateSecretKey(): SecretKey? {
    return runCatching {
      val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
      (keyStore.getKey(keystoreAlias, null) as? SecretKey)?.let { return it }
      val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
      val spec = KeyGenParameterSpec.Builder(
        keystoreAlias,
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
      )
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .build()
      generator.init(spec)
      generator.generateKey()
    }.getOrNull()
  }
}

object BiometricUnlockHelper {
  fun canAuthenticate(context: Context): Boolean {
    val manager = BiometricManager.from(context)
    val res = manager.canAuthenticate(
      BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    )
    return res == BiometricManager.BIOMETRIC_SUCCESS
  }

  fun promptLocalSessionUnlock(
    activity: FragmentActivity,
    onSuccess: () -> Unit,
    onError: (String) -> Unit,
  ) {
    val executor = ContextCompat.getMainExecutor(activity)
    val prompt = BiometricPrompt(
      activity,
      executor,
      object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
          onSuccess()
        }

        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
          onError(errString.toString())
        }
      },
    )
    val info = BiometricPrompt.PromptInfo.Builder()
      .setTitle("Unlock Aureom Clinical Session")
      .setSubtitle("Restores protected local session (server token validity is still enforced)")
      .setAllowedAuthenticators(
        BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
      )
      .build()
    prompt.authenticate(info)
  }
}
