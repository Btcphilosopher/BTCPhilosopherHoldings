package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.*
import com.example.core.repository.UiResource
import com.example.ui.components.PersistentPatientBanner
import com.example.ui.components.PrototypeNoticeStrip
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AureomViewModel

enum class AureomDestination(
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
) {
  TODAY("Today", Icons.Filled.Today, Icons.Outlined.Today),
  PATIENTS("Patients", Icons.Filled.People, Icons.Outlined.People),
  NOTES("Notes", Icons.Filled.EditNote, Icons.Outlined.EditNote),
  RESULTS("Results", Icons.Filled.Biotech, Icons.Outlined.Biotech),
  TASKS("Tasks", Icons.Filled.TaskAlt, Icons.Outlined.TaskAlt),
  SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings),
}

@Composable
fun AureomAppRoot(viewModel: AureomViewModel) {
  val session by viewModel.session.collectAsStateWithLifecycle()
  val hasStoredSession by viewModel.hasEncryptedStoredSession.collectAsStateWithLifecycle()
  val isSigningIn by viewModel.isSigningIn.collectAsStateWithLifecycle()
  val authError by viewModel.authError.collectAsStateWithLifecycle()
  val biometricEnabled by viewModel.biometricUnlockEnabled.collectAsStateWithLifecycle()
  val aiEnabled by viewModel.aiDraftingEnabled.collectAsStateWithLifecycle()
  val reducedMotion by viewModel.reducedMotionEnabled.collectAsStateWithLifecycle()
  val liveServerUrl by viewModel.liveServerUrl.collectAsStateWithLifecycle()
  val connectionModeName by viewModel.connectionModeName.collectAsStateWithLifecycle()

  val worklistState by viewModel.worklistState.collectAsStateWithLifecycle()
  val patientOverviewState by viewModel.patientOverviewState.collectAsStateWithLifecycle()
  val patientSearchResults by viewModel.patientSearchResults.collectAsStateWithLifecycle()
  val syncStatus by viewModel.syncSummary.collectAsStateWithLifecycle()
  val auditLogsState by viewModel.auditLogsState.collectAsStateWithLifecycle()
  val fhirBundleState by viewModel.fhirBundleState.collectAsStateWithLifecycle()
  val allDrafts by viewModel.allDrafts.collectAsStateWithLifecycle()
  val noteEditor by viewModel.noteEditor.collectAsStateWithLifecycle()
  val feedback by viewModel.feedbackMessage.collectAsStateWithLifecycle()
  val bannerMsg by viewModel.bannerMessage.collectAsStateWithLifecycle()

  AureomClinicalTheme(reducedMotion = reducedMotion) {
    val activeSession = session
    if (activeSession == null) {
      SignInScreen(
        hasStoredSession = hasStoredSession,
        biometricEnabled = biometricEnabled,
        isSigningIn = isSigningIn,
        authError = authError,
        connectionModeName = connectionModeName,
        liveServerUrl = liveServerUrl,
        onSignIn = { u, c -> viewModel.signIn(u, c) },
        onBiometricUnlockSuccess = { viewModel.unlockWithBiometricSuccess() },
        onUpdateServerConfig = { mode, url -> viewModel.updateServerConfig(mode, url) },
      )
      return@AureomClinicalTheme
    }

    var currentTab by remember { mutableStateOf(AureomDestination.TODAY) }
    var showingPatientOverviewOnPhone by remember { mutableStateOf(false) }

    val activePatient: PatientSummaryDto? = (patientOverviewState as? UiResource.Success)?.data?.patient
    val canWrite = activeSession.clinician.role in setOf("DOCTOR", "NURSE")
    val canSign = activeSession.clinician.role == "DOCTOR"

    val snackbarHostState = remember { SnackbarHostState() }
    val activeToast = feedback ?: bannerMsg
    LaunchedEffect(activeToast) {
      if (activeToast != null) {
        snackbarHostState.showSnackbar(activeToast)
        viewModel.clearFeedback()
      }
    }

    if (showingPatientOverviewOnPhone && currentTab == AureomDestination.PATIENTS) {
      BackHandler { showingPatientOverviewOnPhone = false }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val isTablet = maxWidth >= 840.dp

      Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
          Column {
            PrototypeNoticeStrip()
            if (activePatient != null && (currentTab != AureomDestination.TODAY || isTablet)) {
              PersistentPatientBanner(
                patient = activePatient,
                onSwitchPatient = {
                  showingPatientOverviewOnPhone = false
                  currentTab = AureomDestination.PATIENTS
                },
              )
            }
          }
        },
        bottomBar = {
          if (!isTablet) {
            NavigationBar(
              containerColor = ClinicalBlueDark,
              contentColor = androidx.compose.ui.graphics.Color.White,
            ) {
              AureomDestination.entries.forEach { dest ->
                val selected = currentTab == dest
                NavigationBarItem(
                  selected = selected,
                  onClick = {
                    if (dest == AureomDestination.PATIENTS && currentTab == AureomDestination.PATIENTS) {
                      showingPatientOverviewOnPhone = false
                    }
                    currentTab = dest
                  },
                  icon = {
                    Icon(
                      imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                      contentDescription = dest.label,
                    )
                  },
                  label = { Text(dest.label, maxLines = 1) },
                  colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ClinicalBlueDark,
                    selectedTextColor = androidx.compose.ui.graphics.Color.White,
                    indicatorColor = androidx.compose.ui.graphics.Color.White,
                    unselectedIconColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.78f),
                    unselectedTextColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.78f),
                  ),
                  modifier = Modifier.testTag("nav_${dest.name.lowercase()}"),
                )
              }
            }
          }
        },
      ) { innerPadding ->
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        ) {
          if (isTablet) {
            // NHS-blue NavigationRail for tablet ergonomics
            NavigationRail(
              containerColor = ClinicalBlueDark,
              contentColor = androidx.compose.ui.graphics.Color.White,
            ) {
              Spacer(modifier = Modifier.height(8.dp))
              AureomDestination.entries.forEach { dest ->
                val selected = currentTab == dest
                NavigationRailItem(
                  selected = selected,
                  onClick = { currentTab = dest },
                  icon = {
                    Icon(
                      imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                      contentDescription = dest.label,
                    )
                  },
                  label = { Text(dest.label) },
                  colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = ClinicalBlueDark,
                    selectedTextColor = androidx.compose.ui.graphics.Color.White,
                    indicatorColor = androidx.compose.ui.graphics.Color.White,
                    unselectedIconColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.78f),
                    unselectedTextColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.78f),
                  ),
                  modifier = Modifier.testTag("rail_${dest.name.lowercase()}"),
                )
              }
            }

            // Tablet Worklist Sidebar
            val assignedPatients = (worklistState as? UiResource.Success)?.data?.assignedPatients.orEmpty()
            Surface(
              modifier = Modifier.width(260.dp).fillMaxHeight(),
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
              LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                item {
                  Text("Ward / Clinic List", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                }
                items(assignedPatients, key = { it.patientId }) { p ->
                  val isActive = activePatient?.patientId == p.patientId
                  Surface(
                    onClick = {
                      viewModel.openPatient(p.patientId)
                      currentTab = AureomDestination.PATIENTS
                    },
                    color = if (isActive) ClinicalBlueContainer else MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                      Text(p.fullName, style = MaterialTheme.typography.titleSmall)
                      Text("NHS ${p.nhsNumber}", style = MaterialTheme.typography.labelSmall)
                      Text(p.allergyBadgeSummary, style = MaterialTheme.typography.labelSmall, color = ClinicalTeal)
                    }
                  }
                }
              }
            }
          }

          // Primary Workspace Pane
          Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            val openPatientAction: (String) -> Unit = { pid ->
              viewModel.openPatient(pid)
              showingPatientOverviewOnPhone = true
              currentTab = AureomDestination.PATIENTS
            }

            when (currentTab) {
              AureomDestination.TODAY -> TodayWorklistScreen(
                clinician = activeSession.clinician,
                worklistState = worklistState,
                syncStatus = syncStatus,
                onSyncNow = { viewModel.triggerManualSync() },
                onToggleOffline = { viewModel.setOfflineSimulated(it) },
                onRefresh = { viewModel.refreshWorklist() },
                onOpenPatient = openPatientAction,
                onOpenNote = { note ->
                  viewModel.openPatient(note.patientId)
                  viewModel.openExistingNote(note, allDrafts.firstOrNull { it.noteId == note.noteId })
                  currentTab = AureomDestination.NOTES
                },
                onOpenResultsTab = { currentTab = AureomDestination.RESULTS },
                onOpenTasksTab = { currentTab = AureomDestination.TASKS },
              )

              AureomDestination.PATIENTS -> {
                if (isTablet) {
                  Row(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(0.42f).fillMaxHeight()) {
                      PatientsScreen(
                        searchResults = patientSearchResults,
                        onSearch = { q, inc -> viewModel.searchPatients(q, inc) },
                        onSelectPatient = { pid -> viewModel.openPatient(pid) },
                        onRequestEmergencyAccess = { pid, reason -> viewModel.requestEmergencyAccess(pid, reason) },
                      )
                    }
                    VerticalDivider(color = MaterialTheme.colorScheme.outline)
                    Box(modifier = Modifier.weight(0.58f).fillMaxHeight()) {
                      if (activePatient != null || patientOverviewState !is UiResource.Loading) {
                        PatientOverviewContent(
                          viewModel = viewModel,
                          patientOverviewState = patientOverviewState,
                          fhirBundleState = fhirBundleState,
                          canWrite = canWrite,
                          onOpenNoteTab = { currentTab = AureomDestination.NOTES },
                        )
                      }
                    }
                  }
                } else {
                  if (showingPatientOverviewOnPhone && (activePatient != null || patientOverviewState is UiResource.Error || patientOverviewState is UiResource.Loading)) {
                    Column(modifier = Modifier.fillMaxSize()) {
                      TextButton(
                        onClick = { showingPatientOverviewOnPhone = false },
                        modifier = Modifier.padding(horizontal = 8.dp).minimumInteractiveComponentSize(),
                      ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Back to Patient Search")
                      }
                      PatientOverviewContent(
                        viewModel = viewModel,
                        patientOverviewState = patientOverviewState,
                        fhirBundleState = fhirBundleState,
                        canWrite = canWrite,
                        onOpenNoteTab = { currentTab = AureomDestination.NOTES },
                      )
                    }
                  } else {
                    PatientsScreen(
                      searchResults = patientSearchResults,
                      onSearch = { q, inc -> viewModel.searchPatients(q, inc) },
                      onSelectPatient = openPatientAction,
                      onRequestEmergencyAccess = { pid, reason ->
                        viewModel.requestEmergencyAccess(pid, reason)
                        showingPatientOverviewOnPhone = true
                      },
                    )
                  }
                }
              }

              AureomDestination.NOTES -> NotesWorkspaceScreen(
                activePatient = activePatient,
                overviewState = patientOverviewState,
                allDrafts = allDrafts,
                editorState = noteEditor,
                aiDraftingEnabled = aiEnabled,
                canWrite = canWrite,
                canSign = canSign,
                isOffline = syncStatus.isOfflineSimulated,
                onNewNote = { p -> viewModel.openNewNoteForPatient(p) },
                onOpenNote = { note, local -> viewModel.openExistingNote(note, local) },
                onOpenDraftOnly = { draft ->
                  viewModel.openExistingNote(
                    ClinicalNoteDto(
                      noteId = draft.noteId,
                      patientId = draft.patientId,
                      patientName = draft.patientName,
                      encounterId = draft.encounterId,
                      templateType = draft.templateType,
                      title = draft.title,
                      sections = emptyList(),
                      freeText = draft.freeText,
                      status = draft.status,
                      version = draft.baseVersion,
                      authorId = activeSession.clinician.clinicianId,
                      authorName = activeSession.clinician.displayName,
                      createdAt = "",
                      updatedAt = "",
                    ),
                    draft,
                  )
                },
                onChangeTemplate = { viewModel.changeTemplate(it) },
                onUpdateTitle = { viewModel.updateTitle(it) },
                onUpdateSection = { k, v -> viewModel.updateSection(k, v) },
                onUpdateFreeText = { viewModel.updateFreeText(it) },
                onSyncDraft = { viewModel.syncDraftToServer() },
                onResolveConflict = { keepLocal -> viewModel.resolveConflict(keepLocal) },
                onRequestAiSuggestion = { ov -> viewModel.requestAiAssistiveDraft(ov) },
                onApplyAiSuggestion = { viewModel.applyAiSuggestionToDraft() },
                onDismissAiSuggestion = { viewModel.dismissAiSuggestion() },
                onSignNote = { pid -> viewModel.signCurrentNote(pid) },
                onAddAmendment = { nid, pid, type, body, reason -> viewModel.addAmendment(nid, pid, type, body, reason) },
                onMarkEnteredInError = { nid, pid, reason -> viewModel.markEnteredInError(nid, pid, reason) },
                onSimulateConcurrentEdit = { nid -> viewModel.simulateConcurrentEdit(nid) },
              )

              AureomDestination.RESULTS -> ResultsScreen(
                worklistState = worklistState,
                activeOverviewState = patientOverviewState,
                canWrite = canWrite,
                onOpenPatient = openPatientAction,
                onUpdateResultWorkflow = { rid, pid, state -> viewModel.updateResultWorkflow(rid, pid, state) },
                onCreateFollowUpForResult = { req -> viewModel.createTask(req) },
              )

              AureomDestination.TASKS -> TasksScreen(
                worklistState = worklistState,
                activeOverviewState = patientOverviewState,
                canWrite = canWrite,
                onOpenPatient = openPatientAction,
                onCreateTask = { req -> viewModel.createTask(req) },
                onCompleteTask = { tid, pid, ev, ver -> viewModel.completeTask(tid, pid, ev, ver) },
              )

              AureomDestination.SETTINGS -> SettingsAndAuditScreen(
                session = activeSession,
                syncStatus = syncStatus,
                biometricEnabled = biometricEnabled,
                aiDraftingEnabled = aiEnabled,
                reducedMotion = reducedMotion,
                auditLogsState = auditLogsState,
                onToggleBiometric = { viewModel.setBiometricEnabled(it) },
                onToggleAiDrafting = { viewModel.setAiDraftingEnabled(it) },
                onToggleReducedMotion = { viewModel.setReducedMotion(it) },
                onToggleOffline = { viewModel.setOfflineSimulated(it) },
                onSyncNow = { viewModel.triggerManualSync() },
                onSimulateConflict = { viewModel.simulateConcurrentEdit("NOTE-302") },
                onSimulateSessionExpiry = { viewModel.simulateSessionExpiry() },
                onPurgeCache = { viewModel.purgeLocalCache() },
                onRefreshAudit = { viewModel.loadAuditLogs() },
                onSignOut = { viewModel.signOut(true) },
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PatientOverviewContent(
  viewModel: AureomViewModel,
  patientOverviewState: UiResource<PatientOverviewDto>,
  fhirBundleState: UiResource<FhirPatientEverythingBundle>?,
  canWrite: Boolean,
  onOpenNoteTab: () -> Unit,
) {
  val activeId = (patientOverviewState as? UiResource.Success)?.data?.patient?.patientId
  PatientOverviewScreen(
    overviewState = patientOverviewState,
    fhirBundleState = fhirBundleState,
    canWrite = canWrite,
    onRetry = { activeId?.let { viewModel.openPatient(it) } },
    onNewNote = { p ->
      viewModel.openNewNoteForPatient(p, NoteTemplateType.CONSULTATION)
      onOpenNoteTab()
    },
    onOpenNote = { note ->
      viewModel.openExistingNote(note, null)
      onOpenNoteTab()
    },
    onCopyExcerptToNote = { p, srcLabel, srcAuthor, srcTs, excerpt ->
      viewModel.openNewNoteForPatient(p, NoteTemplateType.CONSULTATION)
      viewModel.addCopiedAttribution(srcLabel, srcAuthor, srcTs, excerpt)
      onOpenNoteTab()
    },
    onUpdateResultWorkflow = { rid, pid, state -> viewModel.updateResultWorkflow(rid, pid, state) },
    onReconcileMedication = { mid, pid, action, note -> viewModel.reconcileMedication(mid, pid, action, note) },
    onCreateTaskForPatient = { req -> viewModel.createTask(req) },
    onCompleteTask = { tid, pid, ev, ver -> viewModel.completeTask(tid, pid, ev, ver) },
    onSaveClinicalPhoto = { pid, encId, title, uri, consent, note -> viewModel.saveClinicalPhoto(pid, encId, title, uri, consent, note) },
    onLoadFhirBundle = { pid -> viewModel.loadFhirBundle(pid) },
  )
}
