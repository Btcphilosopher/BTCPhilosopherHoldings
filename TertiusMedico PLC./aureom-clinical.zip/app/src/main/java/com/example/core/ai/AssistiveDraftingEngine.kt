package com.example.core.ai

import com.example.core.model.AiDraftSuggestion
import com.example.core.model.NoteSectionDto
import com.example.core.model.NoteTemplateType
import com.example.core.model.PatientOverviewDto

/**
 * Disabled-by-default assistive drafting engine.
 * Synthesises structured, source-cited draft sections strictly from authorised patient records,
 * explicitly preserves uncertainty and contradictions, and requires clinician review before saving.
 * Never diagnoses, prescribes, signs notes, acknowledges results, or completes tasks.
 */
object AssistiveDraftingEngine {

  fun generateSourceLinkedSuggestion(
    overview: PatientOverviewDto,
    templateType: NoteTemplateType,
  ): AiDraftSuggestion {
    val citations = mutableListOf<String>()
    val uncertainties = mutableListOf<String>()
    val bullets = mutableListOf<String>()

    val patient = overview.patient
    if (patient.matchConfidence == "POSSIBLE_DEMOGRAPHIC_MATCH") {
      uncertainties += "Identity status is PROVISIONAL (${patient.matchConfidence}); confirm demographics before documenting."
    }

    when (patient.allergyStatusState) {
      "NOT_ASSESSED" -> uncertainties += "Allergy status is NOT ASSESSED — verify allergies before medication decisions."
      "UNKNOWN" -> uncertainties += "Allergy status is recorded as UNKNOWN."
      "UNAVAILABLE" -> uncertainties += "Allergy source record is currently UNAVAILABLE."
      "EXPLICIT_NO_KNOWN_ALLERGIES" -> bullets += "Allergies: Explicitly documented No Known Allergies."
      else -> {
        val list = overview.allergies.joinToString("; ") { "${it.substance} (${it.severity}, ${it.verificationStatus}) [${it.allergyId}]" }
        overview.allergies.forEach { citations += it.allergyId }
        bullets += "Allergies: $list"
      }
    }

    val activeProbs = overview.activeProblems.take(3)
    if (activeProbs.isNotEmpty()) {
      activeProbs.forEach { citations += it.problemId }
      bullets += "Active problems: ${activeProbs.joinToString("; ") { "${it.title} [${it.problemId}]" }}"
    }

    val discrepancies = overview.medications.filter { it.discrepancyFlag }
    if (discrepancies.isNotEmpty()) {
      discrepancies.forEach { citations += it.medicationId }
      uncertainties += "Medication discrepancy flagged: ${discrepancies.joinToString("; ") { "${it.name} ${it.dose} (${it.recordCategory}) — ${it.discrepancyNote ?: "Check reconciliation"} [${it.medicationId}]" }}"
    }

    val abnormalResults = overview.diagnosticResults.filter { it.abnormalFlag in setOf("HIGH", "LOW", "CRITICAL") || it.resultStatus == "CORRECTED" }
    if (abnormalResults.isNotEmpty()) {
      abnormalResults.forEach { citations += it.resultId }
      bullets += "Key results: ${abnormalResults.joinToString("; ") { "${it.testName} ${it.valueText ?: "N/A"} ${it.unit} (${it.resultStatus}, ${it.workflowState}) [${it.resultId}]" }}"
    }

    val missingObs = overview.recentObservations.filter { it.valueNumeric == null }
    if (missingObs.isNotEmpty()) {
      missingObs.forEach { citations += it.observationId }
      uncertainties += "Missing observation(s): ${missingObs.joinToString { "${it.name} (${it.missingReason ?: "Not measured"}) [${it.observationId}]" }}"
    }

    val obsText = overview.recentObservations.joinToString(", ") { obs ->
      citations += obs.observationId
      val v = obs.valueNumeric?.let { "$it ${obs.unit}" } ?: "MISSING"
      "${obs.name}: $v [${obs.observationId}]"
    }.ifBlank { "No recent observations recorded." }

    val resText = overview.diagnosticResults.take(4).joinToString("\n") { r ->
      citations += r.resultId
      "- ${r.testName}: ${r.valueText ?: "N/A"} ${r.unit} (${r.resultStatus}, ${r.workflowState}) [${r.resultId}]"
    }.ifBlank { "No diagnostic results available." }

    val sections = templateType.defaultSections.mapIndexed { index, (key, label) ->
      val body = when (index) {
        0 -> "Authorised summary for ${patient.fullName} (${patient.patientId}). " +
          if (activeProbs.isNotEmpty()) "Active focus: ${activeProbs.joinToString(", ") { "${it.title} [${it.problemId}]" }}." else "Reviewing current encounter ${patient.currentEncounterLabel ?: ""}."
        1 -> "Observations: $obsText\nResults:\n$resText"
        else -> {
          val openTasks = overview.outstandingTasks.filter { it.status != "COMPLETED" }
          if (openTasks.isNotEmpty()) {
            openTasks.forEach { citations += it.taskId }
            "Pending follow-up tasks:\n" + openTasks.joinToString("\n") { "- ${it.title} (Due ${it.dueAt.take(10)}) [${it.taskId}]" }
          } else {
            "Clinician to complete management plan after reviewing uncertainties."
          }
        }
      }
      NoteSectionDto(key = key, label = label, content = body)
    }

    return AiDraftSuggestion(
      summaryBullets = bullets,
      suggestedSections = sections,
      uncertaintiesAndContradictions = uncertainties,
      citedRecordIds = citations.distinct(),
    )
  }
}
