package com.example.core.network

import com.example.core.model.*
import com.example.core.security.ClinicalLogger
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
import java.io.IOException

sealed class ClinicalApiException(message: String, val code: String) : Exception(message) {
  class Unauthorized(message: String, code: String = "UNAUTHORIZED") : ClinicalApiException(message, code)
  class Forbidden(message: String, code: String = "FORBIDDEN") : ClinicalApiException(message, code)
  class Conflict(message: String, code: String = "CONFLICT") : ClinicalApiException(message, code)
  class BadRequest(message: String, code: String = "BAD_REQUEST") : ClinicalApiException(message, code)
  class Offline(message: String = "Network unavailable — offline mode active") : ClinicalApiException(message, "OFFLINE")
  class Server(message: String, code: String = "SERVER_ERROR") : ClinicalApiException(message, code)
}

class ClinicalApiClient(
  val demoServerEngine: InProcessClinicalServerEngine = InProcessClinicalServerEngine(),
) {
  private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

  @Volatile var connectionMode: ConnectionMode = ConnectionMode.EMBEDDED_DEMO_SERVER
  @Volatile var baseUrl: String = "http://10.0.2.2:8080"
  @Volatile var isOfflineSimulated: Boolean = false

  private val embeddedClient: HttpClient by lazy {
    HttpClient(demoServerEngine.engine) {
      install(ContentNegotiation) { json(json) }
    }
  }

  private val liveClient: HttpClient by lazy {
    HttpClient(OkHttp) {
      install(ContentNegotiation) { json(json) }
    }
  }

  private fun activeClient(): HttpClient =
    if (connectionMode == ConnectionMode.EMBEDDED_DEMO_SERVER) embeddedClient else liveClient

  private fun url(path: String): String =
    if (connectionMode == ConnectionMode.EMBEDDED_DEMO_SERVER) "http://localhost$path" else "$baseUrl$path"

  suspend fun signInOidc(req: OidcTokenRequest): AuthSessionResponse {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/auth/oidc/token")) {
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun logout(token: String) {
    if (isOfflineSimulated) return
    runCatching {
      activeClient().post(url("/auth/logout")) { bearerAuth(token) }
    }
  }

  suspend fun getWorklist(token: String): WorklistResponseDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().get(url("/api/v1/worklist")) { bearerAuth(token) }
    }
  }

  suspend fun searchPatients(token: String, query: String, includeOtherContexts: Boolean): PaginatedResponse<PatientSummaryDto> {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().get(url("/api/v1/patients")) {
        bearerAuth(token)
        parameter("q", query)
        parameter("includeOtherContexts", includeOtherContexts)
      }
    }
  }

  suspend fun getPatientOverview(token: String, patientId: String): PatientOverviewDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().get(url("/api/v1/patients/$patientId/overview")) { bearerAuth(token) }
    }
  }

  suspend fun requestEmergencyAccess(token: String, patientId: String, reason: String): EmergencyAccessGrantDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/patients/$patientId/emergency-access")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(EmergencyAccessRequest(reason))
      }
    }
  }

  suspend fun saveNoteDraft(token: String, req: SaveNoteDraftRequest): ClinicalNoteDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/notes")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun signNote(token: String, noteId: String, req: SignNoteRequest): ClinicalNoteDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/notes/$noteId/sign")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun addAmendment(token: String, noteId: String, req: CreateAmendmentRequest): ClinicalNoteDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/notes/$noteId/amendments")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun markEnteredInError(token: String, noteId: String, req: EnteredInErrorRequest): ClinicalNoteDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/notes/$noteId/entered-in-error")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun updateResultWorkflow(token: String, resultId: String, req: UpdateResultWorkflowRequest): DiagnosticResultDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/results/$resultId/workflow")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun reconcileMedication(token: String, medicationId: String, req: ReconcileMedicationRequest): MedicationDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/medications/$medicationId/reconcile")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun createTask(token: String, req: CreateTaskRequest): FollowUpTaskDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/tasks")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun completeTask(token: String, taskId: String, req: CompleteTaskRequest): FollowUpTaskDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/tasks/$taskId/complete")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun uploadDocument(token: String, req: UploadDocumentRequest): ClinicalDocumentDto {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().post(url("/api/v1/documents")) {
        bearerAuth(token)
        contentType(ContentType.Application.Json)
        setBody(req)
      }
    }
  }

  suspend fun getFhirBundle(token: String, patientId: String): FhirPatientEverythingBundle {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().get(url("/api/v1/fhir/Patient/$patientId/\$everything")) { bearerAuth(token) }
    }
  }

  suspend fun getAuditLogs(token: String, patientId: String? = null): PaginatedResponse<AuditLogDto> {
    if (isOfflineSimulated) throw ClinicalApiException.Offline()
    return execute {
      activeClient().get(url("/api/v1/audit")) {
        bearerAuth(token)
        if (patientId != null) parameter("patientId", patientId)
      }
    }
  }

  private suspend inline fun <reified T> execute(crossinline block: suspend () -> HttpResponse): T {
    val response = try {
      block()
    } catch (io: IOException) {
      ClinicalLogger.warn("ClinicalApiClient", "Network I/O failure")
      throw ClinicalApiException.Offline(io.message ?: "Unable to reach clinical server")
    }
    if (response.status.isSuccess()) {
      return response.body()
    }
    val err = runCatching { response.body<ApiError>() }.getOrNull()
    val msg = err?.message ?: "HTTP ${response.status.value}"
    val code = err?.code ?: "HTTP_${response.status.value}"
    throw when (response.status) {
      HttpStatusCode.Unauthorized -> ClinicalApiException.Unauthorized(msg, code)
      HttpStatusCode.Forbidden -> ClinicalApiException.Forbidden(msg, code)
      HttpStatusCode.Conflict -> ClinicalApiException.Conflict(msg, code)
      HttpStatusCode.BadRequest -> ClinicalApiException.BadRequest(msg, code)
      else -> ClinicalApiException.Server(msg, code)
    }
  }
}
