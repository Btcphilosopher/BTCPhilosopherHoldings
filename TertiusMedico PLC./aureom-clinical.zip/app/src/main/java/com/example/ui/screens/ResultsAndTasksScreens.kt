package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.core.repository.UiResource
import com.example.ui.components.ClinicalStateCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import java.time.Instant

@Composable
fun ResultsScreen(
  worklistState: UiResource<WorklistResponseDto>,
  activeOverviewState: UiResource<PatientOverviewDto>,
  canWrite: Boolean,
  onOpenPatient: (String) -> Unit,
  onUpdateResultWorkflow: (resultId: String, patientId: String, targetState: String) -> Unit,
  onCreateFollowUpForResult: (CreateTaskRequest) -> Unit,
) {
  var statusFilter by remember { mutableStateOf("ALL") }
  var taskTargetResult by remember { mutableStateOf<DiagnosticResultDto?>(null) }

  val resultsList = remember(worklistState, activeOverviewState, statusFilter) {
    val combined = buildList {
      if (activeOverviewState is UiResource.Success) addAll(activeOverviewState.data.diagnosticResults)
      if (worklistState is UiResource.Success) addAll(worklistState.data.resultsRequiringReview)
    }.distinctBy { it.resultId }
    when (statusFilter) {
      "CORRECTED" -> combined.filter { it.resultStatus == "CORRECTED" }
      "NEEDS_REVIEW" -> combined.filter { it.workflowState in setOf("AVAILABLE", "VIEWED") }
      else -> combined
    }
  }

  Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Observations & Diagnostic Results", style = MaterialTheme.typography.headlineSmall)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      FilterChip(selected = statusFilter == "ALL", onClick = { statusFilter = "ALL" }, label = { Text("All (${resultsList.size})") })
      FilterChip(selected = statusFilter == "NEEDS_REVIEW", onClick = { statusFilter = "NEEDS_REVIEW" }, label = { Text("Needs Review") })
      FilterChip(selected = statusFilter == "CORRECTED", onClick = { statusFilter = "CORRECTED" }, label = { Text("Corrected") })
    }

    if (resultsList.isEmpty()) {
      ClinicalStateCard(
        icon = Icons.Outlined.Biotech,
        title = "No Results in This Filter",
        message = "Switch filters or open a patient chart to review historical laboratory and radiology reports.",
      )
    } else {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
        items(resultsList, key = { it.resultId }) { r ->
          val isCorrected = r.resultStatus == "CORRECTED"
          Card(
            colors = CardDefaults.cardColors(containerColor = if (isCorrected) ClinicalWarningContainer else MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, if (isCorrected) ClinicalWarning else MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("results_tab_card_${r.resultId}"),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                  Text("${r.testName}: ${r.valueText ?: "N/A"} ${r.unit}", style = MaterialTheme.typography.titleMedium)
                  Text("${r.patientName} (${r.patientId}) • ${r.category}", style = MaterialTheme.typography.bodySmall)
                }
                StatusPill(r.resultStatus, if (isCorrected) ClinicalDangerContainer else ClinicalBlueContainer, if (isCorrected) ClinicalDanger else OnClinicalBlueContainer)
              }
              Text("Workflow: ${r.workflowState} • Ref: ${r.referenceInterval} (${r.abnormalFlag})", style = MaterialTheme.typography.labelMedium)
              Text("Source: ${r.sourceSystem} • Verification: ${r.verificationStatus} • Reported ${r.reportedAt.take(16)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              r.supersedesResultId?.let { prev ->
                Text("Linked Superseding Correction (replaces $prev): ${r.correctionReason ?: ""}", style = MaterialTheme.typography.bodySmall, color = ClinicalWarning)
              }
              r.reviewedBy?.let {
                Text("Acknowledged by $it at ${r.reviewedAt?.take(16) ?: ""}", style = MaterialTheme.typography.labelSmall, color = ClinicalSuccess)
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { onOpenPatient(r.patientId) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                  Text("Open Patient")
                }
                if (canWrite && r.workflowState == "AVAILABLE") {
                  OutlinedButton(
                    onClick = { onUpdateResultWorkflow(r.resultId, r.patientId, "VIEWED") },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                  ) { Text("Mark Viewed") }
                }
                if (canWrite && r.workflowState in setOf("AVAILABLE", "VIEWED")) {
                  Button(
                    onClick = { onUpdateResultWorkflow(r.resultId, r.patientId, "ACKNOWLEDGED") },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("results_ack_${r.resultId}"),
                  ) { Text("Acknowledge") }
                }
                if (canWrite && r.workflowState != "ACTION_COMPLETED") {
                  OutlinedButton(
                    onClick = { taskTargetResult = r },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                  ) { Text("Assign Follow-up") }
                }
              }
            }
          }
        }
      }
    }
  }

  taskTargetResult?.let { res ->
    var title by remember { mutableStateOf("Follow up ${res.resultStatus} ${res.testName} (${res.valueText ?: ""} ${res.unit})") }
    var desc by remember { mutableStateOf(res.correctionReason ?: "Review abnormal result and repeat as indicated.") }
    AlertDialog(
      onDismissRequest = { taskTargetResult = null },
      title = { Text("Assign Result Follow-up — ${res.patientName}") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task title") }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Instructions") }, modifier = Modifier.fillMaxWidth())
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onCreateFollowUpForResult(
              CreateTaskRequest(
                patientId = res.patientId,
                encounterId = res.encounterId,
                linkedResultId = res.resultId,
                title = title,
                description = desc,
                ownerName = "Dr Sarah Jenkins",
                priority = if (res.resultStatus == "CORRECTED" || res.abnormalFlag == "CRITICAL") "URGENT" else "ROUTINE",
                dueAt = Instant.now().plusSeconds(7200).toString(),
              )
            )
            taskTargetResult = null
          },
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) { Text("Assign Task") }
      },
      dismissButton = { TextButton(onClick = { taskTargetResult = null }) { Text("Cancel") } },
    )
  }
}

@Composable
fun TasksScreen(
  worklistState: UiResource<WorklistResponseDto>,
  activeOverviewState: UiResource<PatientOverviewDto>,
  canWrite: Boolean,
  onOpenPatient: (String) -> Unit,
  onCreateTask: (CreateTaskRequest) -> Unit,
  onCompleteTask: (taskId: String, patientId: String, evidence: String, version: Long) -> Unit,
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var completeTarget by remember { mutableStateOf<FollowUpTaskDto?>(null) }
  var evidence by remember { mutableStateOf("") }

  val tasksList = remember(worklistState, activeOverviewState) {
    buildList {
      if (activeOverviewState is UiResource.Success) addAll(activeOverviewState.data.outstandingTasks)
      if (worklistState is UiResource.Success) addAll(worklistState.data.outstandingTasks)
    }.distinctBy { it.taskId }
  }

  val activePatient = (activeOverviewState as? UiResource.Success)?.data?.patient

  Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
      Text("Clinical Follow-up Tasks", style = MaterialTheme.typography.headlineSmall)
      if (canWrite && activePatient != null) {
        Button(
          onClick = { showCreateDialog = true },
          modifier = Modifier.minimumInteractiveComponentSize().testTag("tasks_tab_new_button"),
        ) {
          Icon(Icons.Filled.AddTask, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Assign")
        }
      }
    }

    if (tasksList.isEmpty()) {
      ClinicalStateCard(
        icon = Icons.Outlined.TaskAlt,
        title = "No Outstanding Follow-up Tasks",
        message = "Select a patient or diagnostic result to create a tracked clinical follow-up task.",
      )
    } else {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
        items(tasksList, key = { it.taskId }) { task ->
          Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("task_card_${task.taskId}"),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(task.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                StatusPill(
                  text = "${task.priority} • ${task.status}",
                  containerColor = if (task.status == "COMPLETED") ClinicalSuccessContainer else if (task.priority == "URGENT") ClinicalDangerContainer else ClinicalBlueContainer,
                  contentColor = if (task.status == "COMPLETED") ClinicalSuccess else if (task.priority == "URGENT") ClinicalDanger else OnClinicalBlueContainer,
                )
              }
              Text("${task.patientName} (${task.patientId}) • Owner: ${task.ownerName}", style = MaterialTheme.typography.bodySmall)
              Text(task.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text("Due: ${task.dueAt.take(16)} • Created by ${task.createdBy}", style = MaterialTheme.typography.labelSmall)
              task.completionEvidence?.let {
                Text("Completion evidence: $it (${task.completedBy ?: ""})", style = MaterialTheme.typography.bodySmall, color = ClinicalSuccess)
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { onOpenPatient(task.patientId) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                  Text("Open Patient")
                }
                if (canWrite && task.status != "COMPLETED") {
                  Button(
                    onClick = {
                      completeTarget = task
                      evidence = ""
                    },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("complete_task_${task.taskId}"),
                  ) { Text("Complete with Evidence") }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showCreateDialog && activePatient != null) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("URGENT") }
    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      title = { Text("New Task — ${activePatient.fullName}") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task title") }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Clinical instructions") }, modifier = Modifier.fillMaxWidth())
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ROUTINE", "URGENT", "STAT").forEach { p ->
              FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p) })
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onCreateTask(
              CreateTaskRequest(
                patientId = activePatient.patientId,
                encounterId = activePatient.currentEncounterId,
                title = title,
                description = desc.ifBlank { title },
                ownerName = "Dr Sarah Jenkins",
                priority = priority,
                dueAt = Instant.now().plusSeconds(7200).toString(),
              )
            )
            showCreateDialog = false
          },
          enabled = title.isNotBlank(),
        ) { Text("Create") }
      },
      dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") } },
    )
  }

  completeTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { completeTarget = null },
      title = { Text("Record Completion Evidence") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(target.title, style = MaterialTheme.typography.bodySmall)
          OutlinedTextField(
            value = evidence,
            onValueChange = { evidence = it },
            label = { Text("Completion evidence (e.g. ECG normal, repeat K+ 4.7)") },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onCompleteTask(target.taskId, target.patientId, evidence, target.version)
            completeTarget = null
          },
          enabled = evidence.trim().length >= 4,
        ) { Text("Mark Completed") }
      },
      dismissButton = { TextButton(onClick = { completeTarget = null }) { Text("Cancel") } },
    )
  }
}
