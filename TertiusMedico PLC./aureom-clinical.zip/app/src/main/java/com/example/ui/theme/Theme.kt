package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val LocalReducedMotion = compositionLocalOf { false }

private val ClinicalLightColorScheme = lightColorScheme(
  primary = ClinicalBlue,
  onPrimary = Color.White,
  primaryContainer = ClinicalBlueContainer,
  onPrimaryContainer = OnClinicalBlueContainer,
  secondary = ClinicalTeal,
  onSecondary = Color.White,
  secondaryContainer = ClinicalTealContainer,
  onSecondaryContainer = OnClinicalTealContainer,
  tertiary = ClinicalBlueDark,
  onTertiary = Color.White,
  background = ClinicalCanvas,
  onBackground = ClinicalInk,
  surface = ClinicalSurface,
  onSurface = ClinicalInk,
  surfaceVariant = ClinicalSurfaceVariant,
  onSurfaceVariant = ClinicalInkSecondary,
  outline = ClinicalOutline,
  error = ClinicalDanger,
  onError = Color.White,
  errorContainer = ClinicalDangerContainer,
  onErrorContainer = ClinicalDanger,
)

private val ClinicalDarkColorScheme = darkColorScheme(
  primary = ClinicalDarkBlue,
  onPrimary = Color(0xFF001C38),
  primaryContainer = Color(0xFF003B75),
  onPrimaryContainer = Color(0xFFD6E6FF),
  secondary = ClinicalDarkTeal,
  onSecondary = Color(0xFF002825),
  secondaryContainer = Color(0xFF004F4A),
  onSecondaryContainer = Color(0xFFC4F5F0),
  background = ClinicalDarkCanvas,
  onBackground = Color(0xFFF0F4F8),
  surface = ClinicalDarkSurface,
  onSurface = Color(0xFFF0F4F8),
  surfaceVariant = ClinicalDarkSurfaceVariant,
  onSurfaceVariant = Color(0xFFB0C4D8),
  outline = Color(0xFF334E68),
  error = Color(0xFFFF8A80),
  onError = Color(0xFF4A0000),
  errorContainer = Color(0xFF690005),
  onErrorContainer = Color(0xFFFFDAD6),
)

private val ClinicalShapes = Shapes(
  small = RoundedCornerShape(8.dp),
  medium = RoundedCornerShape(12.dp),
  large = RoundedCornerShape(16.dp),
)

@Composable
fun AureomClinicalTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  reducedMotion: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) ClinicalDarkColorScheme else ClinicalLightColorScheme
  CompositionLocalProvider(LocalReducedMotion provides reducedMotion) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = ClinicalTypography,
      shapes = ClinicalShapes,
      content = content,
    )
  }
}
