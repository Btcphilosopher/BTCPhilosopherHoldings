package com.example

import android.app.Application
import android.content.Context
import com.example.core.database.AureomDatabase
import com.example.core.network.ClinicalApiClient
import com.example.core.repository.ClinicalRepository
import com.example.core.security.CredentialVault
import com.example.core.sync.ClinicalSyncExecutor
import com.example.core.sync.SyncScheduler

class AppContainer(context: Context) {
  val database: AureomDatabase = AureomDatabase.build(context)
  val vault: CredentialVault = CredentialVault(context)
  val apiClient: ClinicalApiClient = ClinicalApiClient()
  val syncExecutor: ClinicalSyncExecutor = ClinicalSyncExecutor(database, apiClient, vault)
  val syncScheduler: SyncScheduler = SyncScheduler(context)
  val repository: ClinicalRepository = ClinicalRepository(
    context = context.applicationContext,
    db = database,
    vault = vault,
    api = apiClient,
    syncExecutor = syncExecutor,
    syncScheduler = syncScheduler,
  )
}

class AureomApplication : Application() {
  lateinit var container: AppContainer
    private set

  override fun onCreate() {
    super.onCreate()
    container = AppContainer(this)
  }

  companion object {
    fun containerOrNull(context: Context): AppContainer? =
      (context.applicationContext as? AureomApplication)?.container
  }
}
