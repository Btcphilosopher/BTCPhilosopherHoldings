package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.PatientSummaryDto
import com.example.core.model.SyncStatusSummary
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PrototypeNoticeStrip(modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = ClinicalBlueDark,
    contentColor = Color.White,
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = Icons.Outlined.Science,
        contentDescription = null,
        modifier = Modifier.size(16.dp),
      )
      Text(
        text = "INDEPENDENT PROTOTYPE • SYNTHETIC DEMO CLINIC • NOT AN NHS INTEGRATION",
        style = MaterialTheme.typography.labelSmall,
        color = Color.White,
      )
    }
  }
}

@Composable
fun StatusPill(
  text: String,
  containerColor: Color,
  contentColor: Color,
  icon: ImageVector? = null,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    color = containerColor,
    contentColor = contentColor,
    shape = MaterialTheme.shapes.small,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      if (icon != null) {
        Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(14.dp))
      }
      Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.SemiBold,
      )
    }
  }
}

@Composable
fun PersistentPatientBanner(
  patient: PatientSummaryDto,
  modifier: Modifier = Modifier,
  onSwitchPatient: (() -> Unit)? = null,
) {
  val isPossibleMatch = patient.matchConfidence == "POSSIBLE_DEMOGRAPHIC_MATCH"
  val (allergyBg, allergyFg, allergyIcon) = when (patient.allergyStatusState) {
    "RECORDED" -> Triple(ClinicalDangerContainer, ClinicalDanger, Icons.Filled.Warning)
    "EXPLICIT_NO_KNOWN_ALLERGIES" -> Triple(ClinicalSuccessContainer, ClinicalSuccess, Icons.Filled.CheckCircle)
    "NOT_ASSESSED", "UNKNOWN", "UNAVAILABLE" -> Triple(ClinicalWarningContainer, ClinicalWarning, Icons.Outlined.HelpOutline)
    else -> Triple(ClinicalNeutralContainer, ClinicalNeutralBadge, Icons.Outlined.Info)
  }

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("persistent_patient_banner"),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 2.dp,
    border = BorderStroke(1.dp, if (isPossibleMatch) ClinicalWarning else MaterialTheme.colorScheme.outline),
  ) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(
              text = patient.fullName,
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.semantics { heading() },
            )
            if (isPossibleMatch) {
              StatusPill(
                text = "POSSIBLE MATCH • UNVERIFIED ID",
                containerColor = ClinicalWarningContainer,
                contentColor = ClinicalWarning,
                icon = Icons.Filled.ReportProblem,
              )
            } else {
              StatusPill(
                text = "VERIFIED ID",
                containerColor = ClinicalTealContainer,
                contentColor = OnClinicalTealContainer,
                icon = Icons.Filled.VerifiedUser,
              )
            }
            if (patient.emergencyAccessActive) {
              StatusPill(
                text = "BREAK-GLASS",
                containerColor = ClinicalDangerContainer,
                contentColor = ClinicalDanger,
                icon = Icons.Filled.Security,
              )
            }
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "DOB ${patient.dateOfBirth} • ${patient.sexAtBirth} • NHS ${patient.nhsNumber} • ID ${patient.patientId}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        if (onSwitchPatient != null) {
          TextButton(
            onClick = onSwitchPatient,
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("switch_patient_button"),
          ) {
            Text("Switch")
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        StatusPill(
          text = patient.allergyBadgeSummary,
          containerColor = allergyBg,
          contentColor = allergyFg,
          icon = allergyIcon,
        )
        patient.currentEncounterLabel?.let { enc ->
          Text(
            text = enc,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
          )
        }
      }
    }
  }
}

@Composable
fun SyncStatusStrip(
  syncStatus: SyncStatusSummary,
  onSyncNow: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val bg = when {
    syncStatus.conflictCount > 0 || syncStatus.failedOperationCount > 0 -> ClinicalWarningContainer
    syncStatus.isOfflineSimulated -> ClinicalNeutralContainer
    else -> MaterialTheme.colorScheme.primaryContainer
  }
  val fg = when {
    syncStatus.conflictCount > 0 || syncStatus.failedOperationCount > 0 -> ClinicalWarning
    syncStatus.isOfflineSimulated -> ClinicalNeutralBadge
    else -> MaterialTheme.colorScheme.onPrimaryContainer
  }
  val lastSyncText = syncStatus.lastSuccessfulSyncEpochMs?.let {
    SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(it))
  } ?: "Never"

  val cacheAgeText = syncStatus.oldestCachedRecordEpochMs?.let { oldest ->
    val mins = ((System.currentTimeMillis() - oldest) / 60_000L).coerceAtLeast(0)
    "${mins}m old"
  } ?: "No local cache"

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("sync_status_card"),
    color = bg,
    contentColor = fg,
    shape = MaterialTheme.shapes.medium,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = syncStatus.workManagerStateLabel,
          style = MaterialTheme.typography.labelLarge,
          color = fg,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Last sync: $lastSyncText • Cache: $cacheAgeText • Pending: ${syncStatus.pendingUploadCount} • Conflicts: ${syncStatus.conflictCount} • Failed: ${syncStatus.failedOperationCount}",
          style = MaterialTheme.typography.bodySmall,
          color = fg,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      FilledTonalButton(
        onClick = onSyncNow,
        enabled = !syncStatus.isSyncing,
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("sync_now_button"),
      ) {
        Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(if (syncStatus.isSyncing) "Syncing" else "Sync")
      }
    }
  }
}

@Composable
fun ClinicalStateCard(
  icon: ImageVector,
  title: String,
  message: String,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
  isDanger: Boolean = false,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(
      containerColor = if (isDanger) ClinicalDangerContainer else MaterialTheme.colorScheme.surface,
    ),
    border = BorderStroke(1.dp, if (isDanger) ClinicalDanger else MaterialTheme.colorScheme.outline),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (isDanger) ClinicalDanger else MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(36.dp),
      )
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = if (isDanger) ClinicalDanger else MaterialTheme.colorScheme.onSurface,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      if (actionLabel != null && onAction != null) {
        Spacer(modifier = Modifier.height(14.dp))
        Button(
          onClick = onAction,
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Text(actionLabel)
        }
      }
    }
  }
}

@Composable
fun ConfirmPatientActionDialog(
  title: String,
  actionDescription: String,
  patient: PatientSummaryDto,
  confirmLabel: String,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = { Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
    title = { Text(title, style = MaterialTheme.typography.titleLarge) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(actionDescription, style = MaterialTheme.typography.bodyMedium)
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = MaterialTheme.shapes.small,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("Confirm Patient Identity", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text("${patient.fullName} (DOB ${patient.dateOfBirth})", style = MaterialTheme.typography.titleSmall)
            Text("NHS: ${patient.nhsNumber} • Internal ID: ${patient.patientId}", style = MaterialTheme.typography.labelMedium)
            if (patient.matchConfidence == "POSSIBLE_DEMOGRAPHIC_MATCH") {
              Text(
                "Warning: Identity is currently PROVISIONAL (possible demographic match). Double-check wristband/ID before proceeding.",
                style = MaterialTheme.typography.bodySmall,
                color = ClinicalWarning,
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("confirm_patient_action_button"),
      ) {
        Text(confirmLabel)
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text("Cancel")
      }
    },
  )
}
