package com.example.core.database

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cached_patients")
data class CachedPatientEntity(
  @PrimaryKey val patientId: String,
  val careContextId: String,
  val overviewJson: String,
  val cachedAtEpochMs: Long,
  val expiresAtEpochMs: Long,
)

@Entity(tableName = "local_note_drafts")
data class LocalNoteDraftEntity(
  @PrimaryKey val noteId: String,
  val patientId: String,
  val patientName: String,
  val encounterId: String,
  val templateType: String,
  val title: String,
  val sectionsJson: String,
  val freeText: String,
  val copiedAttributionsJson: String,
  val baseVersion: Long,
  val status: String, // DRAFT, CONFLICT, SIGNED, ENTERED_IN_ERROR
  val dirty: Boolean,
  val pendingSync: Boolean,
  val conflictMessage: String?,
  val serverSnapshotJson: String?,
  val idempotencyKey: String,
  val updatedAtEpochMs: Long,
)

@Entity(tableName = "pending_sync_ops")
data class PendingSyncOpEntity(
  @PrimaryKey val opId: String,
  val opType: String, // SAVE_DRAFT, SIGN_NOTE, ADD_AMENDMENT, CREATE_TASK, COMPLETE_TASK, RESULT_WORKFLOW
  val targetId: String,
  val patientId: String,
  val payloadJson: String,
  val idempotencyKey: String,
  val retryCount: Int,
  val state: String, // PENDING, IN_FLIGHT, CONFLICT, FAILED
  val lastError: String?,
  val createdAtEpochMs: Long,
  val updatedAtEpochMs: Long,
)

@Entity(tableName = "sync_metadata")
data class SyncMetadataEntity(
  @PrimaryKey val id: String = "singleton",
  val lastSuccessfulSyncEpochMs: Long?,
  val lastError: String?,
)

@Entity(tableName = "protected_attachments")
data class ProtectedAttachmentEntity(
  @PrimaryKey val localId: String,
  val patientId: String,
  val encounterId: String?,
  val title: String,
  val localFilePath: String,
  val mimeType: String,
  val isClinicalPhoto: Boolean,
  val consentRecorded: Boolean,
  val consentNote: String?,
  val authorName: String,
  val originalPreserved: Boolean,
  val derivedLabel: String?,
  val createdAtEpochMs: Long,
  val uploadedDocumentId: String?,
)

@Dao
interface ClinicalCacheDao {
  @Query("SELECT * FROM cached_patients WHERE patientId = :patientId")
  suspend fun getPatientCache(patientId: String): CachedPatientEntity?

  @Query("SELECT * FROM cached_patients WHERE careContextId = :contextId ORDER BY cachedAtEpochMs DESC")
  fun observePatientsForContext(contextId: String): Flow<List<CachedPatientEntity>>

  @Query("SELECT MIN(cachedAtEpochMs) FROM cached_patients")
  fun observeOldestCacheTimestamp(): Flow<Long?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertPatientCache(entity: CachedPatientEntity)

  @Query("DELETE FROM cached_patients WHERE expiresAtEpochMs < :nowMs")
  suspend fun purgeExpiredCache(nowMs: Long)

  @Query("DELETE FROM cached_patients")
  suspend fun purgeAllPatients()

  // Note Drafts
  @Query("SELECT * FROM local_note_drafts WHERE patientId = :patientId ORDER BY updatedAtEpochMs DESC")
  fun observeDraftsForPatient(patientId: String): Flow<List<LocalNoteDraftEntity>>

  @Query("SELECT * FROM local_note_drafts ORDER BY updatedAtEpochMs DESC")
  fun observeAllDrafts(): Flow<List<LocalNoteDraftEntity>>

  @Query("SELECT * FROM local_note_drafts WHERE noteId = :noteId")
  suspend fun getDraftById(noteId: String): LocalNoteDraftEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertDraft(draft: LocalNoteDraftEntity)

  @Query("DELETE FROM local_note_drafts")
  suspend fun purgeAllDrafts()

  // Pending Sync Queue
  @Query("SELECT * FROM pending_sync_ops ORDER BY createdAtEpochMs ASC")
  fun observePendingOps(): Flow<List<PendingSyncOpEntity>>

  @Query("SELECT * FROM pending_sync_ops WHERE state IN ('PENDING', 'FAILED') AND retryCount < 3 ORDER BY createdAtEpochMs ASC")
  suspend fun getSyncableOps(): List<PendingSyncOpEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertPendingOp(op: PendingSyncOpEntity)

  @Query("DELETE FROM pending_sync_ops WHERE opId = :opId")
  suspend fun deletePendingOp(opId: String)

  @Query("DELETE FROM pending_sync_ops")
  suspend fun purgeAllPendingOps()

  // Sync Metadata
  @Query("SELECT * FROM sync_metadata WHERE id = 'singleton'")
  fun observeSyncMetadata(): Flow<SyncMetadataEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertSyncMetadata(meta: SyncMetadataEntity)

  // Protected Attachments
  @Query("SELECT * FROM protected_attachments WHERE patientId = :patientId ORDER BY createdAtEpochMs DESC")
  fun observeAttachmentsForPatient(patientId: String): Flow<List<ProtectedAttachmentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAttachment(attachment: ProtectedAttachmentEntity)

  @Query("DELETE FROM protected_attachments")
  suspend fun purgeAllAttachments()
}

@Database(
  entities = [
    CachedPatientEntity::class,
    LocalNoteDraftEntity::class,
    PendingSyncOpEntity::class,
    SyncMetadataEntity::class,
    ProtectedAttachmentEntity::class,
  ],
  version = 1,
  exportSchema = false,
)
abstract class AureomDatabase : RoomDatabase() {
  abstract fun clinicalCacheDao(): ClinicalCacheDao

  companion object {
    fun build(context: Context): AureomDatabase {
      return Room.databaseBuilder(
        context.applicationContext,
        AureomDatabase::class.java,
        "aureom_clinical_cache.db",
      ).fallbackToDestructiveMigration(true).build()
    }
  }
}
