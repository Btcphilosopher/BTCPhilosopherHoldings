package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.database.LocalNoteDraftEntity
import com.example.core.model.*
import com.example.core.repository.UiResource
import com.example.ui.components.ClinicalStateCard
import com.example.ui.components.ConfirmPatientActionDialog
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.NoteEditorUiState

@Composable
fun NotesWorkspaceScreen(
  activePatient: PatientSummaryDto?,
  overviewState: UiResource<PatientOverviewDto>,
  allDrafts: List<LocalNoteDraftEntity>,
  editorState: NoteEditorUiState?,
  aiDraftingEnabled: Boolean,
  canWrite: Boolean,
  canSign: Boolean,
  isOffline: Boolean,
  onNewNote: (PatientSummaryDto) -> Unit,
  onOpenNote: (ClinicalNoteDto, LocalNoteDraftEntity?) -> Unit,
  onOpenDraftOnly: (LocalNoteDraftEntity) -> Unit,
  onChangeTemplate: (NoteTemplateType) -> Unit,
  onUpdateTitle: (String) -> Unit,
  onUpdateSection: (String, String) -> Unit,
  onUpdateFreeText: (String) -> Unit,
  onSyncDraft: () -> Unit,
  onResolveConflict: (keepLocal: Boolean) -> Unit,
  onRequestAiSuggestion: (PatientOverviewDto) -> Unit,
  onApplyAiSuggestion: () -> Unit,
  onDismissAiSuggestion: () -> Unit,
  onSignNote: (String) -> Unit,
  onAddAmendment: (noteId: String, patientId: String, type: String, body: String, reason: String) -> Unit,
  onMarkEnteredInError: (noteId: String, patientId: String, reason: String) -> Unit,
  onSimulateConcurrentEdit: (String) -> Unit,
) {
  var showSignPreviewDialog by remember { mutableStateOf(false) }
  var showAmendmentDialog by remember { mutableStateOf(false) }
  var showErrorDialog by remember { mutableStateOf(false) }
  var amendmentType by remember { mutableStateOf("AMENDMENT") }
  var amendmentBody by remember { mutableStateOf("") }
  var amendmentReason by remember { mutableStateOf("") }
  var errorReason by remember { mutableStateOf("") }

  val overview = (overviewState as? UiResource.Success)?.data
  val serverNotes = overview?.previousNotes.orEmpty()

  if (editorState == null) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().testTag("notes_list_view"),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text("Consultation & Ward Notes", style = MaterialTheme.typography.headlineSmall)
          if (activePatient != null && canWrite) {
            Button(
              onClick = { onNewNote(activePatient) },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("create_note_from_tab"),
            ) {
              Icon(Icons.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("New Note")
            }
          }
        }
      }

      if (allDrafts.isNotEmpty()) {
        item { SectionHeader("Local Autosaved Drafts (${allDrafts.size})", Icons.Outlined.EditNote) }
        items(allDrafts, key = { it.noteId }) { draft ->
          val matchingServer = serverNotes.firstOrNull { it.noteId == draft.noteId }
          Card(
            onClick = {
              if (matchingServer != null) onOpenNote(matchingServer, draft)
              else onOpenDraftOnly(draft)
            },
            colors = CardDefaults.cardColors(containerColor = if (draft.status == "CONFLICT") ClinicalWarningContainer else MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, if (draft.status == "CONFLICT") ClinicalWarning else MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("local_draft_${draft.noteId}"),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(draft.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                StatusPill(
                  text = if (draft.status == "CONFLICT") "CONFLICT" else if (draft.dirty) "DIRTY • v${draft.baseVersion}" else "DRAFT v${draft.baseVersion}",
                  containerColor = if (draft.status == "CONFLICT") ClinicalDangerContainer else ClinicalWarningContainer,
                  contentColor = if (draft.status == "CONFLICT") ClinicalDanger else ClinicalWarning,
                )
              }
              Text("Bound Patient: ${draft.patientName} (${draft.patientId}) • ${draft.templateType}", style = MaterialTheme.typography.bodySmall)
              draft.conflictMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = ClinicalDanger) }
            }
          }
        }
      }

      if (activePatient == null) {
        item {
          ClinicalStateCard(
            icon = Icons.Outlined.PersonOutline,
            title = "Select a Patient to View Signed Notes",
            message = "Open a patient from Today or Patients to review historical notes or start a new consultation record.",
          )
        }
      } else {
        item { SectionHeader("Notes for ${activePatient.fullName}", Icons.Outlined.Description) }
        items(serverNotes, key = { it.noteId }) { note ->
          val local = allDrafts.firstOrNull { it.noteId == note.noteId }
          Card(
            onClick = { onOpenNote(note, local) },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("server_note_${note.noteId}"),
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(note.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                StatusPill(note.status, if (note.status == "SIGNED") ClinicalTealContainer else ClinicalWarningContainer, if (note.status == "SIGNED") OnClinicalTealContainer else ClinicalWarning)
              }
              Text("${note.templateType} • Author ${note.authorName} • v${note.version}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }
    return
  }

  // Active Note Editor / Viewer
  val isEditable = canWrite && (editorState.status == "DRAFT" || editorState.status == "CONFLICT")
  val boundPatientMatchesActive = activePatient == null || activePatient.patientId == editorState.boundPatientId

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("note_editor_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // Patient Attribution Lock Banner (Prevents wrong-patient assignment when switching records)
    item {
      Surface(
        color = if (boundPatientMatchesActive) ClinicalBlueContainer else ClinicalWarningContainer,
        shape = MaterialTheme.shapes.medium,
        border = BorderStroke(1.dp, if (boundPatientMatchesActive) ClinicalBlue else ClinicalWarning),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(
            "Bound Patient: ${editorState.boundPatientName} (${editorState.boundPatientId}) • Encounter ${editorState.boundEncounterId}",
            style = MaterialTheme.typography.titleSmall,
          )
          Text(
            "${editorState.autosaveLabel} • Base v${editorState.baseVersion} • Status ${editorState.status}",
            style = MaterialTheme.typography.labelSmall,
          )
          if (!boundPatientMatchesActive) {
            Text(
              "Patient isolation guard: You switched active patient to ${activePatient?.fullName}, but this draft remains safely locked to ${editorState.boundPatientName}.",
              style = MaterialTheme.typography.bodySmall,
              color = ClinicalWarning,
            )
          }
        }
      }
    }

    // Conflict Resolution Card (Never silently overwrite)
    if (editorState.status == "CONFLICT" && editorState.serverConflictNote != null) {
      val server = editorState.serverConflictNote
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = ClinicalWarningContainer),
          border = BorderStroke(1.5.dp, ClinicalDanger),
          modifier = Modifier.fillMaxWidth().testTag("conflict_resolution_card"),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Optimistic Concurrency Conflict Detected", style = MaterialTheme.typography.titleMedium, color = ClinicalDanger)
            Text(editorState.conflictMessage ?: "Another clinician updated this draft on the server.", style = MaterialTheme.typography.bodySmall)
            Surface(color = MaterialTheme.colorScheme.surface, shape = MaterialTheme.shapes.small) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text("Server Version (v${server.version} by ${server.authorName}):", style = MaterialTheme.typography.labelLarge)
                Text(server.freeText, style = MaterialTheme.typography.bodySmall)
              }
            }
            Surface(color = MaterialTheme.colorScheme.surface, shape = MaterialTheme.shapes.small) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text("Your Local Draft (based on v${editorState.baseVersion}):", style = MaterialTheme.typography.labelLarge)
                Text(editorState.freeText, style = MaterialTheme.typography.bodySmall)
              }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { onResolveConflict(true) },
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("conflict_keep_local_button"),
              ) { Text("Rebase & Save Local") }
              OutlinedButton(
                onClick = { onResolveConflict(false) },
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("conflict_accept_server_button"),
              ) { Text("Accept Server v${server.version}") }
            }
          }
        }
      }
    }

    // Template Selector
    if (isEditable) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("Template", style = MaterialTheme.typography.labelLarge)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            NoteTemplateType.entries.take(3).forEach { tpl ->
              FilterChip(
                selected = editorState.templateType == tpl,
                onClick = { onChangeTemplate(tpl) },
                label = { Text(tpl.displayLabel) },
              )
            }
          }
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            NoteTemplateType.entries.drop(3).forEach { tpl ->
              FilterChip(
                selected = editorState.templateType == tpl,
                onClick = { onChangeTemplate(tpl) },
                label = { Text(tpl.displayLabel) },
              )
            }
          }
        }
      }
    }

    // Optional Assistive AI Panel (Disabled by default)
    if (isEditable && aiDraftingEnabled && overview != null && overview.patient.patientId == editorState.boundPatientId) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = ClinicalTealContainer),
          border = BorderStroke(1.dp, ClinicalTeal),
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Text("Optional Source-Linked Draft Structuring", style = MaterialTheme.typography.titleSmall, color = OnClinicalTealContainer)
              OutlinedButton(onClick = { onRequestAiSuggestion(overview) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                Text("Generate Draft")
              }
            }
            editorState.aiSuggestion?.let { sug ->
              Text(sug.disclaimer, style = MaterialTheme.typography.labelSmall)
              sug.uncertaintiesAndContradictions.forEach { u ->
                Text("Uncertainty: $u", style = MaterialTheme.typography.bodySmall, color = ClinicalWarning)
              }
              sug.summaryBullets.forEach { b -> Text("• $b", style = MaterialTheme.typography.bodySmall) }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onApplyAiSuggestion, modifier = Modifier.minimumInteractiveComponentSize()) { Text("Insert After Review") }
                TextButton(onClick = onDismissAiSuggestion, modifier = Modifier.minimumInteractiveComponentSize()) { Text("Dismiss") }
              }
            }
          }
        }
      }
    }

    // Note Title & Structured Sections
    item {
      OutlinedTextField(
        value = editorState.title,
        onValueChange = onUpdateTitle,
        enabled = isEditable,
        label = { Text("Note Title") },
        modifier = Modifier.fillMaxWidth().testTag("note_title_input"),
      )
    }

    items(editorState.sections, key = { it.key }) { sec ->
      OutlinedTextField(
        value = sec.content,
        onValueChange = { onUpdateSection(sec.key, it) },
        enabled = isEditable,
        label = { Text(sec.label) },
        minLines = 3,
        modifier = Modifier.fillMaxWidth().testTag("note_section_${sec.key}"),
      )
    }

    item {
      OutlinedTextField(
        value = editorState.freeText,
        onValueChange = onUpdateFreeText,
        enabled = isEditable,
        label = { Text("Additional Free Text / Clinical Reasoning") },
        minLines = 3,
        modifier = Modifier.fillMaxWidth().testTag("note_freetext_input"),
      )
    }

    // Copied Text Attribution
    if (editorState.copiedAttributions.isNotEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Copied Text Attribution (${editorState.copiedAttributions.size})", style = MaterialTheme.typography.titleSmall)
            editorState.copiedAttributions.forEach { att ->
              Text("• ${att.sourceLabel} by ${att.sourceAuthor} (${att.sourceTimestamp.take(16)}): \"${att.excerpt}\"", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    // Editor Actions
    if (isEditable) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
              onClick = onSyncDraft,
              modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("sync_draft_button"),
            ) {
              Icon(Icons.Filled.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isOffline) "Queue Draft" else "Save to Server")
            }
            if (canSign) {
              Button(
                onClick = { showSignPreviewDialog = true },
                enabled = !isOffline && editorState.status == "DRAFT",
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("preview_sign_button"),
              ) {
                Icon(Icons.Filled.Draw, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Preview & Sign")
              }
            }
          }
          editorState.noteId?.let { id ->
            TextButton(
              onClick = { onSimulateConcurrentEdit(id) },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("simulate_conflict_button"),
            ) {
              Text("Demo Helper: Simulate Registrar Server Edit on $id")
            }
          }
        }
      }
    }

    // Signed Metadata + Amendments + Entered-in-Error
    editorState.signedMetadata?.let { signed ->
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = if (signed.status == "ENTERED_IN_ERROR") ClinicalDangerContainer else ClinicalTealContainer),
          border = BorderStroke(1.dp, if (signed.status == "ENTERED_IN_ERROR") ClinicalDanger else ClinicalTeal),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              if (signed.status == "ENTERED_IN_ERROR") "ENTERED IN ERROR — HISTORY RETAINED" else "IMMUTABLE SIGNED RECORD",
              style = MaterialTheme.typography.titleSmall,
            )
            signed.signedByName?.let {
              Text("Signed by $it at ${signed.signedAt ?: ""} • Hash ${signed.contentHash ?: ""}", style = MaterialTheme.typography.labelSmall)
            }
            signed.enteredInErrorReason?.let {
              Text("Entered in error by ${signed.enteredInErrorBy}: $it", style = MaterialTheme.typography.bodySmall, color = ClinicalDanger)
            }
            if (signed.amendments.isNotEmpty()) {
              HorizontalDivider()
              Text("Linked Amendments & Addenda (${signed.amendments.size})", style = MaterialTheme.typography.titleSmall)
              signed.amendments.forEach { amd ->
                Text("[${amd.amendmentType}] ${amd.bodyText} — Reason: ${amd.reason} (${amd.authorName}, ${amd.createdAt.take(16)})", style = MaterialTheme.typography.bodySmall)
              }
            }
            if (signed.status == "SIGNED" && canWrite) {
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                  onClick = {
                    amendmentBody = ""
                    amendmentReason = ""
                    showAmendmentDialog = true
                  },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("add_amendment_button"),
                ) { Text("Add Amendment / Addendum") }
                if (canSign) {
                  OutlinedButton(
                    onClick = {
                      errorReason = ""
                      showErrorDialog = true
                    },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("entered_in_error_button"),
                  ) { Text("Entered in Error") }
                }
              }
            }
          }
        }
      }
    }
  }

  // Preview Before Signing Dialog with Explicit Patient Confirmation
  if (showSignPreviewDialog) {
    val previewSummary = buildString {
      appendLine("Title: ${editorState.title} (${editorState.templateType.displayLabel})")
      editorState.sections.forEach { appendLine("${it.label}: ${it.content}") }
      if (editorState.freeText.isNotBlank()) appendLine("Notes: ${editorState.freeText}")
    }
    val patientForConfirm = activePatient?.takeIf { it.patientId == editorState.boundPatientId } ?: PatientSummaryDto(
      patientId = editorState.boundPatientId,
      nhsNumber = "Verify in banner",
      externalMrn = "",
      identityVerificationStatus = "VERIFIED",
      matchConfidence = "VERIFIED_IDENTITY",
      fullName = editorState.boundPatientName,
      dateOfBirth = "",
      sexAtBirth = "",
      careContextId = "",
      careTeamSummary = "",
      allergyStatusState = "RECORDED",
      allergyBadgeSummary = "",
      updatedAt = "",
    )
    ConfirmPatientActionDialog(
      title = "Preview & Sign Clinical Note",
      actionDescription = "Once signed, this note becomes immutable and commits atomically with an audit record.\n\n$previewSummary",
      patient = patientForConfirm,
      confirmLabel = "Sign & Lock Note",
      onConfirm = {
        onSignNote(editorState.boundPatientId)
        showSignPreviewDialog = false
      },
      onDismiss = { showSignPreviewDialog = false },
    )
  }

  // Amendment / Addendum Dialog
  if (showAmendmentDialog) {
    AlertDialog(
      onDismissRequest = { showAmendmentDialog = false },
      title = { Text("Add Attributed Amendment / Addendum") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = amendmentType == "AMENDMENT", onClick = { amendmentType = "AMENDMENT" }, label = { Text("Amendment") })
            FilterChip(selected = amendmentType == "ADDENDUM", onClick = { amendmentType = "ADDENDUM" }, label = { Text("Addendum") })
          }
          OutlinedTextField(value = amendmentReason, onValueChange = { amendmentReason = it }, label = { Text("Reason for amendment") }, modifier = Modifier.fillMaxWidth().testTag("amendment_reason_input"))
          OutlinedTextField(value = amendmentBody, onValueChange = { amendmentBody = it }, label = { Text("Amendment text") }, minLines = 3, modifier = Modifier.fillMaxWidth().testTag("amendment_body_input"))
        }
      },
      confirmButton = {
        Button(
          onClick = {
            editorState.noteId?.let { id ->
              onAddAmendment(id, editorState.boundPatientId, amendmentType, amendmentBody, amendmentReason)
            }
            showAmendmentDialog = false
          },
          enabled = amendmentBody.isNotBlank() && amendmentReason.isNotBlank(),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("confirm_amendment_button"),
        ) { Text("Commit Amendment") }
      },
      dismissButton = { TextButton(onClick = { showAmendmentDialog = false }) { Text("Cancel") } },
    )
  }

  // Entered-in-Error Dialog
  if (showErrorDialog) {
    AlertDialog(
      onDismissRequest = { showErrorDialog = false },
      title = { Text("Mark Note Entered-in-Error") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("The original note content and audit trail will be retained for governance.", style = MaterialTheme.typography.bodySmall)
          OutlinedTextField(value = errorReason, onValueChange = { errorReason = it }, label = { Text("Reason (min 6 characters)") }, modifier = Modifier.fillMaxWidth())
        }
      },
      confirmButton = {
        Button(
          onClick = {
            editorState.noteId?.let { id -> onMarkEnteredInError(id, editorState.boundPatientId, errorReason) }
            showErrorDialog = false
          },
          enabled = errorReason.trim().length >= 6,
          colors = ButtonDefaults.buttonColors(containerColor = ClinicalDanger),
        ) { Text("Mark Entered in Error") }
      },
      dismissButton = { TextButton(onClick = { showErrorDialog = false }) { Text("Cancel") } },
    )
  }
}
