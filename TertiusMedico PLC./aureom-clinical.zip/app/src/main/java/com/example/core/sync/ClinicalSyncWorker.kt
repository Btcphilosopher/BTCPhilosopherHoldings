package com.example.core.sync

import android.content.Context
import androidx.work.*
import com.example.core.database.AureomDatabase
import com.example.core.database.SyncMetadataEntity
import com.example.core.model.*
import com.example.core.network.ClinicalApiClient
import com.example.core.network.ClinicalApiException
import com.example.core.security.ClinicalLogger
import com.example.core.security.CredentialVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant
import java.util.concurrent.TimeUnit

class ClinicalSyncExecutor(
  private val db: AureomDatabase,
  private val api: ClinicalApiClient,
  private val vault: CredentialVault,
) {
  private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
  private val dao = db.clinicalCacheDao()

  sealed interface SyncOutcome {
    data class Success(val syncedCount: Int) : SyncOutcome
    data class ConflictDetected(val message: String) : SyncOutcome
    data class AuthExpired(val message: String) : SyncOutcome
    data class DeferredOffline(val message: String) : SyncOutcome
  }

  suspend fun flushPendingOperations(): SyncOutcome = withContext(Dispatchers.IO) {
    val session = vault.loadSession() ?: return@withContext SyncOutcome.AuthExpired("No active session")
    if (Instant.now().isAfter(Instant.parse(session.expiresAt))) {
      return@withContext SyncOutcome.AuthExpired("Session expired before sync")
    }
    if (api.isOfflineSimulated) {
      return@withContext SyncOutcome.DeferredOffline("Offline mode active — drafts safely held in Room queue")
    }

    val ops = dao.getSyncableOps()
    var syncedCount = 0
    var conflictMessage: String? = null

    for (op in ops) {
      try {
        when (op.opType) {
          "SAVE_DRAFT" -> {
            val req = json.decodeFromString<SaveNoteDraftRequest>(op.payloadJson)
            val saved = api.saveNoteDraft(session.accessToken, req)
            val existingDraft = dao.getDraftById(saved.noteId)
            if (existingDraft != null) {
              dao.upsertDraft(
                existingDraft.copy(
                  baseVersion = saved.version,
                  status = saved.status,
                  dirty = false,
                  pendingSync = false,
                  conflictMessage = null,
                  serverSnapshotJson = null,
                  updatedAtEpochMs = System.currentTimeMillis(),
                )
              )
            }
          }
          "CREATE_TASK" -> {
            val req = json.decodeFromString<CreateTaskRequest>(op.payloadJson)
            api.createTask(session.accessToken, req)
          }
          "COMPLETE_TASK" -> {
            val req = json.decodeFromString<CompleteTaskRequest>(op.payloadJson)
            api.completeTask(session.accessToken, op.targetId, req)
          }
          "RESULT_WORKFLOW" -> {
            val req = json.decodeFromString<UpdateResultWorkflowRequest>(op.payloadJson)
            api.updateResultWorkflow(session.accessToken, op.targetId, req)
          }
        }
        dao.deletePendingOp(op.opId)
        syncedCount++
      } catch (e: ClinicalApiException.Conflict) {
        ClinicalLogger.warn("ClinicalSyncExecutor", "Version conflict during sync for ${op.opType}")
        conflictMessage = e.message ?: "Version conflict detected"
        dao.upsertPendingOp(op.copy(state = "CONFLICT", lastError = conflictMessage, updatedAtEpochMs = System.currentTimeMillis()))
        if (op.opType == "SAVE_DRAFT") {
          val draft = dao.getDraftById(op.targetId)
          val serverOverview = runCatching { api.getPatientOverview(session.accessToken, op.patientId) }.getOrNull()
          val serverNote = serverOverview?.previousNotes?.firstOrNull { it.noteId == op.targetId }
          if (draft != null) {
            dao.upsertDraft(
              draft.copy(
                status = "CONFLICT",
                pendingSync = false,
                conflictMessage = conflictMessage,
                serverSnapshotJson = serverNote?.let { json.encodeToString(it) },
              )
            )
          }
        }
      } catch (e: ClinicalApiException.Unauthorized) {
        return@withContext SyncOutcome.AuthExpired(e.message ?: "Session expired or revoked")
      } catch (e: ClinicalApiException.Offline) {
        return@withContext SyncOutcome.DeferredOffline(e.message ?: "Network unreachable")
      } catch (e: Exception) {
        val nextRetry = op.retryCount + 1
        val nextState = if (nextRetry >= 3) "FAILED" else "PENDING"
        dao.upsertPendingOp(
          op.copy(
            retryCount = nextRetry,
            state = nextState,
            lastError = e.message ?: "Sync error",
            updatedAtEpochMs = System.currentTimeMillis(),
          )
        )
      }
    }

    // Purge expired patient cache per policy
    dao.purgeExpiredCache(System.currentTimeMillis())

    if (conflictMessage != null) {
      dao.upsertSyncMetadata(SyncMetadataEntity(lastSuccessfulSyncEpochMs = System.currentTimeMillis(), lastError = conflictMessage))
      return@withContext SyncOutcome.ConflictDetected(conflictMessage)
    }

    dao.upsertSyncMetadata(SyncMetadataEntity(lastSuccessfulSyncEpochMs = System.currentTimeMillis(), lastError = null))
    SyncOutcome.Success(syncedCount)
  }
}

class ClinicalSyncWorker(
  appContext: Context,
  params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val container = com.example.AureomApplication.containerOrNull(applicationContext)
      ?: return Result.failure()
    return when (container.syncExecutor.flushPendingOperations()) {
      is ClinicalSyncExecutor.SyncOutcome.Success -> Result.success()
      is ClinicalSyncExecutor.SyncOutcome.ConflictDetected -> Result.success() // Conflict surfaced in UI; stop retrying blindly
      is ClinicalSyncExecutor.SyncOutcome.AuthExpired -> Result.failure()
      is ClinicalSyncExecutor.SyncOutcome.DeferredOffline -> {
        if (runAttemptCount >= 3) Result.failure() else Result.retry()
      }
    }
  }
}

class SyncScheduler(private val context: Context) {
  fun enqueueDeferredSync() {
    val constraints = Constraints.Builder()
      .setRequiredNetworkType(NetworkType.CONNECTED)
      .build()
    val request = OneTimeWorkRequestBuilder<ClinicalSyncWorker>()
      .setConstraints(constraints)
      .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
      .build()
    runCatching {
      WorkManager.getInstance(context).enqueueUniqueWork(
        UNIQUE_SYNC_WORK,
        ExistingWorkPolicy.KEEP,
        request,
      )
    }
  }

  fun cancelPendingWork() {
    runCatching {
      WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_SYNC_WORK)
    }
  }

  companion object {
    const val UNIQUE_SYNC_WORK = "aureom_deferred_clinical_sync"
  }
}
