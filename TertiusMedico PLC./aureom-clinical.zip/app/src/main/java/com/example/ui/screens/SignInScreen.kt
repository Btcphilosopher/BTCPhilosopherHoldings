package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.core.model.ConnectionMode
import com.example.core.security.BiometricUnlockHelper
import com.example.ui.components.PrototypeNoticeStrip
import com.example.ui.components.StatusPill
import com.example.ui.theme.*

@Composable
fun SignInScreen(
  hasStoredSession: Boolean,
  biometricEnabled: Boolean,
  isSigningIn: Boolean,
  authError: String?,
  connectionModeName: String,
  liveServerUrl: String,
  onSignIn: (username: String, careContextId: String) -> Unit,
  onBiometricUnlockSuccess: () -> Unit,
  onUpdateServerConfig: (ConnectionMode, String) -> Unit,
) {
  val context = LocalContext.current
  val activity = context as? FragmentActivity

  var selectedUser by remember { mutableStateOf("dr.jenkins") }
  var selectedContext by remember { mutableStateOf("CTX-AMU-A") }
  var selectedMode by remember(connectionModeName) {
    mutableStateOf(runCatching { ConnectionMode.valueOf(connectionModeName) }.getOrDefault(ConnectionMode.EMBEDDED_DEMO_SERVER))
  }
  var serverUrlText by remember(liveServerUrl) { mutableStateOf(liveServerUrl) }
  var biometricError by remember { mutableStateOf<String?>(null) }

  val roles = listOf(
    Triple("dr.jenkins", "Dr Sarah Jenkins", "DOCTOR • Acute & General Medicine"),
    Triple("nurse.patel", "Sister Maya Patel", "NURSE • Ward 4B (Cannot sign notes)"),
    Triple("auditor.cole", "Owen Cole", "AUDITOR • Clinical Governance (Read-only)"),
  )

  val contexts = listOf(
    "CTX-AMU-A" to "Acute Medical Unit — Ward 4B & SDEC",
    "CTX-CARD-OPD" to "Cardiology Outpatient Clinic",
  )

  Scaffold(
    topBar = { PrototypeNoticeStrip() },
    containerColor = MaterialTheme.colorScheme.background,
  ) { padding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        // Branded Clinical Header
        Surface(
          color = ClinicalBlue,
          contentColor = androidx.compose.ui.graphics.Color.White,
          shape = MaterialTheme.shapes.large,
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.LocalHospital,
                contentDescription = "Aureom Clinical emblem",
                modifier = Modifier.size(34.dp),
              )
              Column {
                Text("AUREOM CLINICAL", style = MaterialTheme.typography.headlineSmall)
                Text("Patient Records & Consultation Workspace", style = MaterialTheme.typography.bodyMedium)
              }
            }
            Spacer(modifier = Modifier.height(10.dp))
            StatusPill(
              text = "Local OpenID Connect Identity Provider (Demo)",
              containerColor = ClinicalBlueDark,
              contentColor = androidx.compose.ui.graphics.Color.White,
              icon = Icons.Filled.VerifiedUser,
            )
          }
        }

        if (hasStoredSession && biometricEnabled && activity != null && BiometricUnlockHelper.canAuthenticate(context)) {
          Card(
            colors = CardDefaults.cardColors(containerColor = ClinicalTealContainer),
            border = BorderStroke(1.dp, ClinicalTeal),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("Encrypted Session Available", style = MaterialTheme.typography.titleSmall, color = OnClinicalTealContainer)
                Text(
                  "Biometric unlock restores local Keystore access; server token expiry remains enforced.",
                  style = MaterialTheme.typography.bodySmall,
                  color = OnClinicalTealContainer,
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Button(
                onClick = {
                  BiometricUnlockHelper.promptLocalSessionUnlock(
                    activity = activity,
                    onSuccess = onBiometricUnlockSuccess,
                    onError = { biometricError = it },
                  )
                },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("biometric_unlock_button"),
              ) {
                Icon(Icons.Filled.Fingerprint, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Unlock")
              }
            }
          }
        }

        // Role / Identity Card
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Organisational Sign-In", style = MaterialTheme.typography.titleLarge)
            Text(
              "Select a synthetic clinician profile to authenticate via the local OIDC adapter.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            roles.forEach { (username, name, desc) ->
              val selected = selectedUser == username
              Surface(
                onClick = {
                  selectedUser = username
                  if (username != "dr.jenkins") selectedContext = "CTX-AMU-A"
                },
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth().testTag("role_option_$username"),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  RadioButton(selected = selected, onClick = null)
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(name, style = MaterialTheme.typography.titleSmall)
                    Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text("Authorised Care Context", style = MaterialTheme.typography.titleSmall)
            contexts.forEach { (ctxId, ctxName) ->
              val enabled = selectedUser == "dr.jenkins" || ctxId == "CTX-AMU-A"
              val selected = selectedContext == ctxId
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                RadioButton(
                  selected = selected,
                  onClick = { if (enabled) selectedContext = ctxId },
                  enabled = enabled,
                )
                Column {
                  Text(ctxName, style = MaterialTheme.typography.bodyMedium, color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(ctxId, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }

            if (authError != null || biometricError != null) {
              Surface(
                color = ClinicalDangerContainer,
                shape = MaterialTheme.shapes.small,
              ) {
                Text(
                  text = authError ?: biometricError ?: "",
                  style = MaterialTheme.typography.bodySmall,
                  color = ClinicalDanger,
                  modifier = Modifier.padding(10.dp),
                )
              }
            }

            Button(
              onClick = {
                onUpdateServerConfig(selectedMode, serverUrlText)
                onSignIn(selectedUser, selectedContext)
              },
              enabled = !isSigningIn,
              modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .testTag("sign_in_button"),
            ) {
              if (isSigningIn) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(modifier = Modifier.width(8.dp))
              } else {
                Icon(Icons.Filled.Login, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
              }
              Text("Sign In via OIDC Prototype")
            }
          }
        }

        // Backend Connection Target Card
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Server Connection Adapter", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              FilterChip(
                selected = selectedMode == ConnectionMode.EMBEDDED_DEMO_SERVER,
                onClick = {
                  selectedMode = ConnectionMode.EMBEDDED_DEMO_SERVER
                  onUpdateServerConfig(selectedMode, serverUrlText)
                },
                label = { Text("Embedded Demo Server") },
              )
              FilterChip(
                selected = selectedMode == ConnectionMode.LIVE_HTTP_SERVER,
                onClick = {
                  selectedMode = ConnectionMode.LIVE_HTTP_SERVER
                  onUpdateServerConfig(selectedMode, serverUrlText)
                },
                label = { Text("Docker Ktor Server") },
              )
            }
            if (selectedMode == ConnectionMode.LIVE_HTTP_SERVER) {
              OutlinedTextField(
                value = serverUrlText,
                onValueChange = { serverUrlText = it },
                label = { Text("Ktor Server URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
              )
            } else {
              Text(
                "Uses Ktor MockEngine in-process HTTP adapter enforcing identical OIDC, role, version conflict, and audit rules.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }
    }
  }
}
