package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.navigation.AureomAppRoot
import com.example.ui.viewmodel.AureomViewModel

class MainActivity : FragmentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val app = application as AureomApplication
    setContent {
      val vm: AureomViewModel = viewModel(
        factory = AureomViewModel.Factory(app.container.repository)
      )
      AureomAppRoot(viewModel = vm)
    }
  }
}
