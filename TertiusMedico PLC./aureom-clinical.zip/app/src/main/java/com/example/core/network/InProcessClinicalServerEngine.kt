package com.example.core.network

import com.example.core.model.*
import io.ktor.client.engine.mock.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.utils.io.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.MessageDigest
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Stateful in-process HTTP server engine backed by Ktor MockEngine.
 * Mirrors the exact Ktor + PostgreSQL backend contracts, optimistic concurrency checks,
 * idempotency keys, role/care-context isolation, emergency break-glass, and audit trails
 * so the Android demonstration APK works immediately even without Docker Compose running.
 */
class InProcessClinicalServerEngine {
  private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

  private val contexts = mapOf(
    "CTX-AMU-A" to CareContextDto("CTX-AMU-A", "Acute Medical Unit — Ward 4B", "Ward 4B & SDEC", "St Jude Synthetic Teaching Hospital", "FULL"),
    "CTX-CARD-OPD" to CareContextDto("CTX-CARD-OPD", "Cardiology Outpatient Clinic", "Clinic Suite 2", "St Jude Synthetic Teaching Hospital", "FULL"),
    "CTX-RENAL-WARD" to CareContextDto("CTX-RENAL-WARD", "Renal Inpatient Unit", "Ward 9C", "St Jude Synthetic Teaching Hospital", "RESTRICTED"),
  )

  private data class UserSeed(
    val clinicianId: String,
    val username: String,
    val displayName: String,
    val role: String,
    val specialty: String,
    val contextIds: List<String>,
  )

  private val users = mapOf(
    "dr.jenkins" to UserSeed("USR-DOC-1", "dr.jenkins", "Dr Sarah Jenkins", "DOCTOR", "Acute & General Medicine", listOf("CTX-AMU-A", "CTX-CARD-OPD")),
    "nurse.patel" to UserSeed("USR-NUR-1", "nurse.patel", "Sister Maya Patel", "NURSE", "Acute Medical Unit", listOf("CTX-AMU-A")),
    "auditor.cole" to UserSeed("USR-AUD-1", "auditor.cole", "Owen Cole", "AUDITOR", "Clinical Governance", listOf("CTX-AMU-A")),
  )

  private data class SessionRecord(
    val sessionId: String,
    val token: String,
    val user: UserSeed,
    val careContextId: String,
    var expiresAt: Instant,
    var revoked: Boolean = false,
  )

  private val sessions = ConcurrentHashMap<String, SessionRecord>()
  private val emergencyGrants = ConcurrentHashMap<String, EmergencyAccessGrantDto>()
  private val idempotencyStore = ConcurrentHashMap<String, String>()
  private val auditLogs = mutableListOf<AuditLogDto>()
  private val patients = LinkedHashMap<String, PatientSummaryDto>()
  private val appointments = mutableListOf<AppointmentDto>()
  private val encounters = mutableListOf<EncounterDto>()
  private val problems = mutableListOf<ProblemDto>()
  private val history = mutableListOf<ClinicalHistoryDto>()
  private val medications = mutableListOf<MedicationDto>()
  private val allergies = mutableListOf<AllergyDto>()
  private val observations = mutableListOf<ObservationDto>()
  private val results = mutableListOf<DiagnosticResultDto>()
  private val notes = LinkedHashMap<String, ClinicalNoteDto>()
  private val carePlans = mutableListOf<CarePlanDto>()
  private val documents = mutableListOf<ClinicalDocumentDto>()
  private val documentBytes = ConcurrentHashMap<String, ByteArray>()
  private val tasks = LinkedHashMap<String, FollowUpTaskDto>()

  init {
    seedSyntheticClinic()
  }

  fun simulateConcurrentEditOnServer(noteId: String): Boolean {
    synchronized(this) {
      val current = notes[noteId] ?: return false
      if (current.status != "DRAFT") return false
      val bumped = current.copy(
        version = current.version + 1L,
        freeText = "${current.freeText}\n[Registrar update at ${Instant.now()}]: Patient reviewed on ward; fluids charted.",
        updatedAt = Instant.now().toString(),
      )
      notes[noteId] = bumped
      appendAudit(
        actorId = "USR-REG-2",
        actorName = "Dr Liam Shaw (Registrar)",
        actorRole = "DOCTOR",
        action = "EDIT_NOTE_DRAFT",
        resourceType = "CLINICAL_NOTE",
        resourceId = noteId,
        patientId = current.patientId,
        careContextId = patients[current.patientId]?.careContextId,
        outcome = "ALLOWED",
        reason = "Concurrent server edit for conflict demonstration",
        emergencyAccess = false,
      )
      return true
    }
  }

  fun expireTokenForDemo(token: String) {
    sessions[token]?.let { it.expiresAt = Instant.now().minusSeconds(60) }
  }

  val engine: MockEngine = MockEngine { request ->
    val path = request.url.encodedPath
    val method = request.method
    val bodyText = when (val b = request.body) {
      is io.ktor.http.content.TextContent -> b.text
      else -> ""
    }

    try {
      when {
        method == HttpMethod.Post && path == "/auth/oidc/token" -> {
          val req = json.decodeFromString<OidcTokenRequest>(bodyText)
          val user = users[req.username.trim()]
            ?: return@MockEngine jsonError(HttpStatusCode.Unauthorized, "INVALID_CREDENTIALS", "Unknown clinician username")
          if (req.careContextId !in user.contextIds) {
            return@MockEngine jsonError(HttpStatusCode.Forbidden, "CONTEXT_NOT_PERMITTED", "Clinician is not authorised for care context ${req.careContextId}")
          }
          val token = "tok_${UUID.randomUUID()}"
          val sessionId = "SES-${UUID.randomUUID().toString().take(8)}"
          val expires = Instant.now().plus(8, ChronoUnit.HOURS)
          sessions[token] = SessionRecord(sessionId, token, user, req.careContextId, expires)
          appendAudit(user.clinicianId, user.displayName, user.role, "OIDC_LOGIN", "SESSION", sessionId, null, req.careContextId, "ALLOWED", "Local OIDC prototype sign-in", false)
          val resp = AuthSessionResponse(
            sessionId = sessionId,
            accessToken = token,
            refreshToken = "ref_${UUID.randomUUID()}",
            expiresAt = expires.toString(),
            clinician = ClinicianProfile(
              clinicianId = user.clinicianId,
              username = user.username,
              displayName = user.displayName,
              role = user.role,
              specialty = user.specialty,
              activeCareContextId = req.careContextId,
              activeCareContextName = contexts.getValue(req.careContextId).name,
              permittedCareContexts = user.contextIds.map { contexts.getValue(it) },
            ),
            prototypeBanner = "INDEPENDENT PROTOTYPE • SYNTHETIC DEMONSTRATION CLINIC • NOT AN NHS INTEGRATION",
          )
          respondJson(HttpStatusCode.OK, json.encodeToString(resp))
        }

        method == HttpMethod.Post && path == "/auth/logout" -> {
          val session = authenticate(request)
          session.revoked = true
          appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "SESSION_REVOKED", "SESSION", session.sessionId, null, session.careContextId, "ALLOWED", "User sign-out", false)
          respondJson(HttpStatusCode.OK, """{"revoked":"true"}""")
        }

        method == HttpMethod.Get && path == "/api/v1/worklist" -> {
          val session = authenticate(request)
          val ctx = contexts.getValue(session.careContextId)
          val ctxPatients = patients.values.filter { it.careContextId == session.careContextId }.map { enrichPatient(it, session) }
          val ctxPatientIds = ctxPatients.map { it.patientId }.toSet()
          val worklist = WorklistResponseDto(
            careContext = ctx,
            todaysAppointments = appointments.filter { it.careContextId == session.careContextId },
            assignedPatients = ctxPatients,
            recentEncounters = encounters.filter { it.careContextId == session.careContextId },
            unsignedNotes = notes.values.filter { it.patientId in ctxPatientIds && it.status == "DRAFT" },
            resultsRequiringReview = results.filter { it.patientId in ctxPatientIds && it.workflowState in setOf("AVAILABLE", "VIEWED", "FOLLOW_UP_ASSIGNED") },
            outstandingTasks = tasks.values.filter { it.patientId in ctxPatientIds && it.status != "COMPLETED" },
            serverTimestamp = Instant.now().toString(),
          )
          appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "VIEW_WORKLIST", "CARE_CONTEXT", session.careContextId, null, session.careContextId, "ALLOWED", null, false)
          respondJson(HttpStatusCode.OK, json.encodeToString(worklist))
        }

        method == HttpMethod.Get && path == "/api/v1/patients" -> {
          val session = authenticate(request)
          val q = (request.url.parameters["q"] ?: "").trim().lowercase()
          val includeOther = request.url.parameters["includeOtherContexts"]?.toBoolean() ?: false
          val list = patients.values
            .filter { includeOther || it.careContextId == session.careContextId }
            .map { enrichPatient(it, session) }
            .filter {
              q.isEmpty() ||
                it.fullName.lowercase().contains(q) ||
                it.nhsNumber.replace(" ", "").lowercase().contains(q.replace(" ", "")) ||
                it.externalMrn.lowercase().contains(q) ||
                it.patientId.lowercase().contains(q) ||
                it.dateOfBirth.contains(q)
            }
          respondJson(HttpStatusCode.OK, json.encodeToString(PaginatedResponse(list, 1, 50, list.size, false)))
        }

        method == HttpMethod.Get && path.matches(Regex("/api/v1/patients/[^/]+/overview")) -> {
          val session = authenticate(request)
          val patientId = path.split("/")[4]
          val emergency = verifyPatientAccess(session, patientId, "VIEW_PATIENT_OVERVIEW")
          val p = enrichPatient(patients.getValue(patientId), session)
          val overview = PatientOverviewDto(
            patient = p,
            activeProblems = problems.filter { it.patientId == patientId },
            relevantHistory = history.filter { it.patientId == patientId },
            medications = medications.filter { it.patientId == patientId },
            allergies = allergies.filter { it.patientId == patientId },
            recentObservations = observations.filter { it.patientId == patientId },
            diagnosticResults = results.filter { it.patientId == patientId }.sortedByDescending { it.reportedAt },
            previousNotes = notes.values.filter { it.patientId == patientId }.sortedByDescending { it.updatedAt },
            carePlans = carePlans.filter { it.patientId == patientId },
            documents = documents.filter { it.patientId == patientId },
            outstandingTasks = tasks.values.filter { it.patientId == patientId },
            serverTimestamp = Instant.now().toString(),
          )
          appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "VIEW_PATIENT_OVERVIEW", "PATIENT", patientId, patientId, session.careContextId, "ALLOWED", if (emergency) "Emergency break-glass active" else null, emergency)
          respondJson(HttpStatusCode.OK, json.encodeToString(overview))
        }

        method == HttpMethod.Post && path.matches(Regex("/api/v1/patients/[^/]+/emergency-access")) -> {
          val session = authenticate(request)
          if (session.user.role == "AUDITOR") {
            return@MockEngine jsonError(HttpStatusCode.Forbidden, "ROLE_FORBIDDEN", "Auditor role cannot invoke clinical emergency access")
          }
          val patientId = path.split("/")[4]
          patients[patientId] ?: return@MockEngine jsonError(HttpStatusCode.NotFound, "PATIENT_NOT_FOUND", "Patient not found")
          val req = json.decodeFromString<EmergencyAccessRequest>(bodyText)
          if (req.reason.trim().length < 8) {
            return@MockEngine jsonError(HttpStatusCode.BadRequest, "REASON_REQUIRED", "Emergency access reason must be at least 8 characters")
          }
          val now = Instant.now()
          val grant = EmergencyAccessGrantDto(
            grantId = "EMG-${UUID.randomUUID().toString().take(8)}",
            patientId = patientId,
            clinicianId = session.user.clinicianId,
            reason = req.reason.trim(),
            grantedAt = now.toString(),
            expiresAt = now.plus(2, ChronoUnit.HOURS).toString(),
            reviewStatus = "PENDING_CALDICOTT_REVIEW",
          )
          emergencyGrants["${session.user.clinicianId}:$patientId"] = grant
          appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "EMERGENCY_BREAK_GLASS_GRANTED", "PATIENT", patientId, patientId, session.careContextId, "ALLOWED", req.reason.trim(), true)
          respondJson(HttpStatusCode.Created, json.encodeToString(grant))
        }

        method == HttpMethod.Post && path == "/api/v1/notes" -> {
          val session = authenticate(request)
          requireWrite(session, "SAVE_NOTE_DRAFT")
          val req = json.decodeFromString<SaveNoteDraftRequest>(bodyText)
          val emergency = verifyPatientAccess(session, req.patientId, "SAVE_NOTE_DRAFT")
          req.idempotencyKey?.let { key ->
            idempotencyStore["${session.user.clinicianId}:SAVE:$key"]?.let { cached ->
              return@MockEngine respondJson(HttpStatusCode.OK, cached)
            }
          }
          val noteId = req.noteId ?: "NOTE-${UUID.randomUUID().toString().take(6)}"
          val saved = synchronized(this) {
            val existing = notes[noteId]
            if (existing != null) {
              if (existing.patientId != req.patientId) {
                throw EngineException(HttpStatusCode.BadRequest, "PATIENT_MISMATCH", "Note belongs to another patient")
              }
              if (existing.status != "DRAFT") {
                throw EngineException(HttpStatusCode.Conflict, "NOTE_IMMUTABLE", "Signed or entered-in-error notes are immutable")
              }
              if (existing.version != req.expectedVersion) {
                throw EngineException(
                  HttpStatusCode.Conflict,
                  "VERSION_CONFLICT",
                  "Optimistic concurrency conflict: server version is ${existing.version}, client sent ${req.expectedVersion}.",
                )
              }
              existing.copy(
                templateType = req.templateType,
                title = req.title,
                sections = req.sections,
                freeText = req.freeText,
                copiedAttributions = req.copiedAttributions,
                version = existing.version + 1L,
                updatedAt = Instant.now().toString(),
              )
            } else {
              val pName = patients.getValue(req.patientId).fullName
              val nowStr = Instant.now().toString()
              ClinicalNoteDto(
                noteId = noteId,
                patientId = req.patientId,
                patientName = pName,
                encounterId = req.encounterId,
                templateType = req.templateType,
                title = req.title,
                sections = req.sections,
                freeText = req.freeText,
                copiedAttributions = req.copiedAttributions,
                status = "DRAFT",
                version = 1L,
                authorId = session.user.clinicianId,
                authorName = session.user.displayName,
                createdAt = nowStr,
                updatedAt = nowStr,
              )
            }.also { notes[noteId] = it }
          }
          appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "EDIT_NOTE_DRAFT", "CLINICAL_NOTE", noteId, req.patientId, session.careContextId, "ALLOWED", null, emergency)
          val out = json.encodeToString(saved)
          req.idempotencyKey?.let { idempotencyStore["${session.user.clinicianId}:SAVE:$it"] = out }
          respondJson(HttpStatusCode.OK, out)
        }

        method == HttpMethod.Post && path.matches(Regex("/api/v1/notes/[^/]+/sign")) -> {
          val session = authenticate(request)
          if (session.user.role != "DOCTOR") {
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "SIGN_NOTE", "CLINICAL_NOTE", "policy-check", null, session.careContextId, "DENIED", "Only DOCTOR role may sign notes", false)
            return@MockEngine jsonError(HttpStatusCode.Forbidden, "SIGN_ROLE_FORBIDDEN", "Only DOCTOR role may sign clinical notes")
          }
          val noteId = path.split("/")[4]
          val req = json.decodeFromString<SignNoteRequest>(bodyText)
          idempotencyStore["${session.user.clinicianId}:SIGN:$noteId:${req.idempotencyKey}"]?.let { cached ->
            return@MockEngine respondJson(HttpStatusCode.OK, cached)
          }
          val signed = synchronized(this) {
            val current = notes[noteId] ?: throw EngineException(HttpStatusCode.NotFound, "NOTE_NOT_FOUND", "Note not found")
            val emergency = verifyPatientAccess(session, current.patientId, "SIGN_NOTE")
            if (req.confirmedPatientId != current.patientId) {
              throw EngineException(HttpStatusCode.BadRequest, "PATIENT_CONFIRMATION_MISMATCH", "Patient confirmation mismatch")
            }
            if (current.status != "DRAFT") {
              throw EngineException(HttpStatusCode.Conflict, "NOTE_NOT_DRAFT", "Note is already ${current.status}")
            }
            if (current.version != req.expectedVersion) {
              throw EngineException(HttpStatusCode.Conflict, "VERSION_CONFLICT", "Cannot sign stale version: server=${current.version}, expected=${req.expectedVersion}")
            }
            val nowStr = Instant.now().toString()
            val hash = "sha256:${sha256("${current.noteId}|${current.patientId}|${current.title}|${current.freeText}")}"
            val updated = current.copy(
              status = "SIGNED",
              version = current.version + 1L,
              updatedAt = nowStr,
              signedAt = nowStr,
              signedById = session.user.clinicianId,
              signedByName = session.user.displayName,
              contentHash = hash,
            )
            notes[noteId] = updated
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "SIGN_NOTE", "CLINICAL_NOTE", noteId, current.patientId, session.careContextId, "ALLOWED", "Signed after preview & patient confirmation", emergency)
            updated
          }
          val out = json.encodeToString(signed)
          idempotencyStore["${session.user.clinicianId}:SIGN:$noteId:${req.idempotencyKey}"] = out
          respondJson(HttpStatusCode.OK, out)
        }

        method == HttpMethod.Post && path.matches(Regex("/api/v1/notes/[^/]+/amendments")) -> {
          val session = authenticate(request)
          requireWrite(session, "ADD_AMENDMENT")
          val noteId = path.split("/")[4]
          val req = json.decodeFromString<CreateAmendmentRequest>(bodyText)
          idempotencyStore["${session.user.clinicianId}:AMD:$noteId:${req.idempotencyKey}"]?.let { cached ->
            return@MockEngine respondJson(HttpStatusCode.OK, cached)
          }
          val updated = synchronized(this) {
            val current = notes[noteId] ?: throw EngineException(HttpStatusCode.NotFound, "NOTE_NOT_FOUND", "Note not found")
            val emergency = verifyPatientAccess(session, current.patientId, "ADD_AMENDMENT")
            if (req.confirmedPatientId != current.patientId) {
              throw EngineException(HttpStatusCode.BadRequest, "PATIENT_CONFIRMATION_MISMATCH", "Patient confirmation mismatch")
            }
            if (current.status != "SIGNED") {
              throw EngineException(HttpStatusCode.Conflict, "NOTE_NOT_SIGNED", "Amendments only allowed on signed notes")
            }
            val amd = NoteAmendmentDto(
              amendmentId = "AMD-${UUID.randomUUID().toString().take(6)}",
              noteId = noteId,
              patientId = current.patientId,
              amendmentType = req.amendmentType,
              bodyText = req.bodyText.trim(),
              reason = req.reason.trim(),
              authorId = session.user.clinicianId,
              authorName = session.user.displayName,
              createdAt = Instant.now().toString(),
              contentHash = "sha256:${sha256(req.bodyText)}",
            )
            val next = current.copy(amendments = current.amendments + amd)
            notes[noteId] = next
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "ADD_NOTE_AMENDMENT", "NOTE_AMENDMENT", amd.amendmentId, current.patientId, session.careContextId, "ALLOWED", req.reason.trim(), emergency)
            next
          }
          val out = json.encodeToString(updated)
          idempotencyStore["${session.user.clinicianId}:AMD:$noteId:${req.idempotencyKey}"] = out
          respondJson(HttpStatusCode.OK, out)
        }

        method == HttpMethod.Post && path.matches(Regex("/api/v1/notes/[^/]+/entered-in-error")) -> {
          val session = authenticate(request)
          if (session.user.role != "DOCTOR") {
            return@MockEngine jsonError(HttpStatusCode.Forbidden, "SIGN_ROLE_FORBIDDEN", "Only DOCTOR role may mark a note entered in error")
          }
          val noteId = path.split("/")[4]
          val req = json.decodeFromString<EnteredInErrorRequest>(bodyText)
          val updated = synchronized(this) {
            val current = notes[noteId] ?: throw EngineException(HttpStatusCode.NotFound, "NOTE_NOT_FOUND", "Note not found")
            val emergency = verifyPatientAccess(session, current.patientId, "ENTERED_IN_ERROR")
            if (req.confirmedPatientId != current.patientId) {
              throw EngineException(HttpStatusCode.BadRequest, "PATIENT_CONFIRMATION_MISMATCH", "Patient confirmation mismatch")
            }
            val nowStr = Instant.now().toString()
            val next = current.copy(
              status = "ENTERED_IN_ERROR",
              version = current.version + 1L,
              updatedAt = nowStr,
              enteredInErrorReason = req.reason.trim(),
              enteredInErrorBy = session.user.displayName,
              enteredInErrorAt = nowStr,
            )
            notes[noteId] = next
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "MARK_NOTE_ENTERED_IN_ERROR", "CLINICAL_NOTE", noteId, current.patientId, session.careContextId, "ALLOWED", req.reason.trim(), emergency)
            next
          }
          respondJson(HttpStatusCode.OK, json.encodeToString(updated))
        }

        method == HttpMethod.Post && path.matches(Regex("/api/v1/results/[^/]+/workflow")) -> {
          val session = authenticate(request)
          val resultId = path.split("/")[4]
          val req = json.decodeFromString<UpdateResultWorkflowRequest>(bodyText)
          if (req.targetState != "VIEWED") requireWrite(session, "UPDATE_RESULT_WORKFLOW")
          val updated = synchronized(this) {
            val idx = results.indexOfFirst { it.resultId == resultId }
            if (idx < 0) throw EngineException(HttpStatusCode.NotFound, "RESULT_NOT_FOUND", "Result not found")
            val current = results[idx]
            val emergency = verifyPatientAccess(session, current.patientId, "RESULT_${req.targetState}")
            if (req.confirmedPatientId != current.patientId) {
              throw EngineException(HttpStatusCode.BadRequest, "PATIENT_CONFIRMATION_MISMATCH", "Patient confirmation mismatch")
            }
            val ack = req.targetState in setOf("ACKNOWLEDGED", "FOLLOW_UP_ASSIGNED", "ACTION_COMPLETED")
            val next = current.copy(
              workflowState = req.targetState,
              reviewedBy = if (ack) session.user.displayName else current.reviewedBy,
              reviewedAt = if (ack) Instant.now().toString() else current.reviewedAt,
              followUpTaskId = req.followUpTaskId ?: current.followUpTaskId,
            )
            results[idx] = next
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "RESULT_${req.targetState}", "DIAGNOSTIC_RESULT", resultId, current.patientId, session.careContextId, "ALLOWED", null, emergency)
            next
          }
          respondJson(HttpStatusCode.OK, json.encodeToString(updated))
        }

        method == HttpMethod.Post && path.matches(Regex("/api/v1/medications/[^/]+/reconcile")) -> {
          val session = authenticate(request)
          requireWrite(session, "RECONCILE_MEDICATION")
          val medId = path.split("/")[4]
          val req = json.decodeFromString<ReconcileMedicationRequest>(bodyText)
          val updated = synchronized(this) {
            val idx = medications.indexOfFirst { it.medicationId == medId }
            if (idx < 0) throw EngineException(HttpStatusCode.NotFound, "MEDICATION_NOT_FOUND", "Medication not found")
            val current = medications[idx]
            val emergency = verifyPatientAccess(session, current.patientId, "RECONCILE_MEDICATION")
            val flag = req.action == "FLAG_DISCREPANCY"
            val next = current.copy(
              discrepancyFlag = flag,
              discrepancyNote = req.discrepancyNote ?: if (!flag) "Reconciled with patient & GP summary" else "Discrepancy flagged",
              reconciledBy = session.user.displayName,
              reconciledAt = Instant.now().toString(),
            )
            medications[idx] = next
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "RECONCILE_MEDICATION", "MEDICATION", medId, current.patientId, session.careContextId, "ALLOWED", req.action, emergency)
            next
          }
          respondJson(HttpStatusCode.OK, json.encodeToString(updated))
        }

        method == HttpMethod.Post && path == "/api/v1/tasks" -> {
          val session = authenticate(request)
          requireWrite(session, "CREATE_TASK")
          val req = json.decodeFromString<CreateTaskRequest>(bodyText)
          val emergency = verifyPatientAccess(session, req.patientId, "CREATE_TASK")
          req.idempotencyKey?.let { key ->
            idempotencyStore["${session.user.clinicianId}:TASK:$key"]?.let { cached ->
              return@MockEngine respondJson(HttpStatusCode.Created, cached)
            }
          }
          val created = synchronized(this) {
            val taskId = "TSK-${UUID.randomUUID().toString().take(6)}"
            val pName = patients.getValue(req.patientId).fullName
            val task = FollowUpTaskDto(
              taskId = taskId,
              patientId = req.patientId,
              patientName = pName,
              encounterId = req.encounterId,
              linkedResultId = req.linkedResultId,
              title = req.title.trim(),
              description = req.description.trim(),
              ownerId = session.user.clinicianId,
              ownerName = req.ownerName.trim(),
              priority = req.priority,
              dueAt = req.dueAt,
              status = "OPEN",
              createdBy = session.user.displayName,
              createdAt = Instant.now().toString(),
              version = 1L,
            )
            tasks[taskId] = task
            if (!req.linkedResultId.isNullOrBlank()) {
              val rIdx = results.indexOfFirst { it.resultId == req.linkedResultId && it.patientId == req.patientId }
              if (rIdx >= 0) {
                results[rIdx] = results[rIdx].copy(workflowState = "FOLLOW_UP_ASSIGNED", followUpTaskId = taskId)
              }
            }
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "CREATE_FOLLOW_UP_TASK", "FOLLOW_UP_TASK", taskId, req.patientId, session.careContextId, "ALLOWED", null, emergency)
            task
          }
          val out = json.encodeToString(created)
          req.idempotencyKey?.let { idempotencyStore["${session.user.clinicianId}:TASK:$it"] = out }
          respondJson(HttpStatusCode.Created, out)
        }

        method == HttpMethod.Post && path.matches(Regex("/api/v1/tasks/[^/]+/complete")) -> {
          val session = authenticate(request)
          requireWrite(session, "COMPLETE_TASK")
          val taskId = path.split("/")[4]
          val req = json.decodeFromString<CompleteTaskRequest>(bodyText)
          if (req.completionEvidence.trim().length < 4) {
            return@MockEngine jsonError(HttpStatusCode.BadRequest, "EVIDENCE_REQUIRED", "Completion evidence is required")
          }
          val updated = synchronized(this) {
            val current = tasks[taskId] ?: throw EngineException(HttpStatusCode.NotFound, "TASK_NOT_FOUND", "Task not found")
            val emergency = verifyPatientAccess(session, current.patientId, "COMPLETE_TASK")
            if (req.confirmedPatientId != current.patientId) {
              throw EngineException(HttpStatusCode.BadRequest, "PATIENT_CONFIRMATION_MISMATCH", "Patient confirmation mismatch")
            }
            val next = current.copy(
              status = "COMPLETED",
              completionEvidence = req.completionEvidence.trim(),
              completedAt = Instant.now().toString(),
              completedBy = session.user.displayName,
              version = current.version + 1L,
            )
            tasks[taskId] = next
            if (!current.linkedResultId.isNullOrBlank()) {
              val rIdx = results.indexOfFirst { it.resultId == current.linkedResultId && it.patientId == current.patientId }
              if (rIdx >= 0) {
                results[rIdx] = results[rIdx].copy(workflowState = "ACTION_COMPLETED")
              }
            }
            appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "COMPLETE_FOLLOW_UP_TASK", "FOLLOW_UP_TASK", taskId, current.patientId, session.careContextId, "ALLOWED", req.completionEvidence.trim(), emergency)
            next
          }
          respondJson(HttpStatusCode.OK, json.encodeToString(updated))
        }

        method == HttpMethod.Post && path == "/api/v1/documents" -> {
          val session = authenticate(request)
          requireWrite(session, "UPLOAD_DOCUMENT")
          val req = json.decodeFromString<UploadDocumentRequest>(bodyText)
          if (req.isClinicalPhoto && !req.consentRecorded) {
            return@MockEngine jsonError(HttpStatusCode.BadRequest, "CONSENT_REQUIRED", "Clinical photos require recorded consent")
          }
          val emergency = verifyPatientAccess(session, req.confirmedPatientId, "UPLOAD_DOCUMENT")
          val docId = "DOC-${UUID.randomUUID().toString().take(6)}"
          val doc = ClinicalDocumentDto(
            documentId = docId,
            patientId = req.confirmedPatientId,
            encounterId = req.encounterId,
            title = req.title.trim(),
            docType = req.docType,
            mimeType = req.mimeType,
            objectKey = "protected/${req.confirmedPatientId}/$docId",
            isClinicalPhoto = req.isClinicalPhoto,
            consentRecorded = req.consentRecorded,
            consentNote = req.consentNote,
            authorName = session.user.displayName,
            originalPreserved = true,
            derivedLabel = req.derivedLabel,
            createdAt = Instant.now().toString(),
            sourceSystem = "Aureom Protected Mobile Capture",
          )
          documents.add(0, doc)
          documentBytes[docId] = req.contentBase64.toByteArray()
          appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "UPLOAD_DOCUMENT", "DOCUMENT", docId, req.confirmedPatientId, session.careContextId, "ALLOWED", req.consentNote, emergency)
          respondJson(HttpStatusCode.Created, json.encodeToString(doc))
        }

        method == HttpMethod.Get && path.matches(Regex("/api/v1/fhir/Patient/[^/]+/\\\$everything")) -> {
          val session = authenticate(request)
          val patientId = path.split("/")[5]
          val emergency = verifyPatientAccess(session, patientId, "VIEW_FHIR_BUNDLE")
          val p = patients.getValue(patientId)
          val entries = mutableListOf<FhirBundleEntry>()
          entries += FhirBundleEntry("urn:aureom:Patient/$patientId", "Patient", patientId, p.identityVerificationStatus, "${p.fullName} (DOB ${p.dateOfBirth})", "Aureom Synthetic EPR", p.updatedAt)
          allergies.filter { it.patientId == patientId }.forEach { a ->
            entries += FhirBundleEntry("urn:aureom:AllergyIntolerance/${a.allergyId}", "AllergyIntolerance", a.allergyId, "${a.verificationStatus}/${a.severity}", "${a.substance}: ${a.reaction}", a.provenance, a.recordedAt)
          }
          medications.filter { it.patientId == patientId }.forEach { m ->
            entries += FhirBundleEntry("urn:aureom:MedicationStatement/${m.medicationId}", "MedicationStatement", m.medicationId, "${m.recordCategory}/${m.status}", "${m.name} ${m.strength} ${m.dose}", m.sourceSystem, m.startDate)
          }
          results.filter { it.patientId == patientId }.forEach { r ->
            entries += FhirBundleEntry("urn:aureom:DiagnosticReport/${r.resultId}", "DiagnosticReport", r.resultId, "${r.resultStatus}/${r.workflowState}", "${r.testName}: ${r.valueText ?: "N/A"} ${r.unit}", r.sourceSystem, r.reportedAt)
          }
          appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, "EXPORT_FHIR_BUNDLE", "FHIR_BUNDLE", patientId, patientId, session.careContextId, "ALLOWED", null, emergency)
          val bundle = FhirPatientEverythingBundle(
            disclaimer = "MOCK FHIR R4 ADAPTER FOR DEMONSTRATION ONLY. NOT A VERIFIED NHS SPINE OR UK CORE LIVE ENDPOINT.",
            total = entries.size,
            entries = entries,
          )
          respondJson(HttpStatusCode.OK, json.encodeToString(bundle))
        }

        method == HttpMethod.Get && path == "/api/v1/audit" -> {
          val session = authenticate(request)
          val patientId = request.url.parameters["patientId"]
          if (patientId != null) verifyPatientAccess(session, patientId, "VIEW_AUDIT_LOG")
          val items = auditLogs.filter { patientId == null || it.patientId == patientId }
          respondJson(HttpStatusCode.OK, json.encodeToString(PaginatedResponse(items, 1, 100, items.size, false)))
        }

        else -> jsonError(HttpStatusCode.NotFound, "ENDPOINT_NOT_FOUND", "Unknown endpoint $path")
      }
    } catch (e: EngineException) {
      jsonError(e.status, e.code, e.message ?: "Request failed")
    }
  }

  private class EngineException(val status: HttpStatusCode, val code: String, message: String) : RuntimeException(message)

  private fun authenticate(request: HttpRequestData): SessionRecord {
    val token = request.headers[HttpHeaders.Authorization]?.removePrefix("Bearer ")?.trim()
      ?: throw EngineException(HttpStatusCode.Unauthorized, "MISSING_TOKEN", "Missing bearer session token")
    val session = sessions[token]
      ?: throw EngineException(HttpStatusCode.Unauthorized, "INVALID_TOKEN", "Invalid session token")
    if (session.revoked) {
      throw EngineException(HttpStatusCode.Unauthorized, "SESSION_REVOKED", "Session has been revoked")
    }
    if (Instant.now().isAfter(session.expiresAt)) {
      throw EngineException(HttpStatusCode.Unauthorized, "SESSION_EXPIRED", "Session expired — please sign in again")
    }
    return session
  }

  private fun requireWrite(session: SessionRecord, action: String) {
    if (session.user.role !in setOf("DOCTOR", "NURSE")) {
      appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, action, "AUTHORISATION", session.sessionId, null, session.careContextId, "DENIED", "Read-only role", false)
      throw EngineException(HttpStatusCode.Forbidden, "ROLE_FORBIDDEN", "Role ${session.user.role} is read-only")
    }
  }

  private fun verifyPatientAccess(session: SessionRecord, patientId: String, action: String): Boolean {
    val p = patients[patientId] ?: throw EngineException(HttpStatusCode.NotFound, "PATIENT_NOT_FOUND", "Patient $patientId not found")
    if (p.careContextId == session.careContextId) return false
    val grant = emergencyGrants["${session.user.clinicianId}:$patientId"]
    if (grant != null && Instant.now().isBefore(Instant.parse(grant.expiresAt))) {
      return true
    }
    appendAudit(session.user.clinicianId, session.user.displayName, session.user.role, action, "PATIENT", patientId, patientId, session.careContextId, "DENIED", "Outside active care context ${session.careContextId}", false)
    throw EngineException(HttpStatusCode.Forbidden, "CARE_CONTEXT_ISOLATION", "Patient $patientId is in ${p.careContextId}, outside active context ${session.careContextId}")
  }

  private fun enrichPatient(p: PatientSummaryDto, session: SessionRecord): PatientSummaryDto {
    val inContext = p.careContextId == session.careContextId
    val grant = emergencyGrants["${session.user.clinicianId}:${p.patientId}"]
    val emergency = !inContext && grant != null && Instant.now().isBefore(Instant.parse(grant.expiresAt))
    return p.copy(hasAccessInCurrentContext = inContext || emergency, emergencyAccessActive = emergency)
  }

  private fun appendAudit(
    actorId: String,
    actorName: String,
    actorRole: String,
    action: String,
    resourceType: String,
    resourceId: String,
    patientId: String?,
    careContextId: String?,
    outcome: String,
    reason: String?,
    emergencyAccess: Boolean,
  ) {
    synchronized(auditLogs) {
      auditLogs.add(
        0,
        AuditLogDto(
          auditId = "AUD-${UUID.randomUUID().toString().take(8)}",
          timestamp = Instant.now().toString(),
          actorId = actorId,
          actorName = actorName,
          actorRole = actorRole,
          action = action,
          resourceType = resourceType,
          resourceId = resourceId,
          patientId = patientId,
          careContextId = careContextId,
          outcome = outcome,
          reason = reason,
          emergencyAccess = emergencyAccess,
          metadataJson = "{}",
        ),
      )
    }
  }

  private fun MockRequestHandleScope.respondJson(status: HttpStatusCode, body: String): HttpResponseData {
    return respond(
      content = ByteReadChannel(body),
      status = status,
      headers = headersOf(HttpHeaders.ContentType, ContentType.Application.Json.toString()),
    )
  }

  private fun MockRequestHandleScope.jsonError(status: HttpStatusCode, code: String, message: String): HttpResponseData {
    val err = ApiError(code = code, message = message, timestamp = Instant.now().toString())
    return respondJson(status, json.encodeToString(err))
  }

  private fun sha256(value: String): String {
    return MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
  }

  private fun seedSyntheticClinic() {
    val now = Instant.now()
    patients["PAT-1001"] = PatientSummaryDto(
      patientId = "PAT-1001",
      nhsNumber = "943 476 5919",
      externalMrn = "MRN-SJ-88412",
      identityVerificationStatus = "VERIFIED",
      matchConfidence = "VERIFIED_IDENTITY",
      fullName = "Arthur Pendelton",
      preferredName = "Artie",
      dateOfBirth = "1948-06-14",
      sexAtBirth = "Male",
      careContextId = "CTX-AMU-A",
      assignedClinicianId = "USR-DOC-1",
      currentEncounterId = "ENC-2001",
      currentEncounterLabel = "AMU Ward 4B • Bed 06 • Acute Care",
      careTeamSummary = "Dr Sarah Jenkins (Consultant), Sister Maya Patel (Named Nurse)",
      allergyStatusState = "RECORDED",
      allergyBadgeSummary = "2 allergy record(s) — Penicillin (Severe)",
      updatedAt = now.minus(1, ChronoUnit.HOURS).toString(),
    )
    patients["PAT-1002"] = PatientSummaryDto(
      patientId = "PAT-1002",
      nhsNumber = "943 512 0084",
      externalMrn = "MRN-SJ-77109",
      identityVerificationStatus = "VERIFIED",
      matchConfidence = "VERIFIED_IDENTITY",
      fullName = "Miriam Okafor",
      dateOfBirth = "1976-11-03",
      sexAtBirth = "Female",
      careContextId = "CTX-AMU-A",
      assignedClinicianId = "USR-DOC-1",
      currentEncounterId = "ENC-2002",
      currentEncounterLabel = "SDEC Bay 2 • Same Day Emergency Care",
      careTeamSummary = "Dr Sarah Jenkins (Consultant), Dr Liam Shaw (Registrar)",
      allergyStatusState = "EXPLICIT_NO_KNOWN_ALLERGIES",
      allergyBadgeSummary = "No known allergies (explicitly documented)",
      updatedAt = now.minus(2, ChronoUnit.HOURS).toString(),
    )
    patients["PAT-1003"] = PatientSummaryDto(
      patientId = "PAT-1003",
      nhsNumber = "Unverified-Demo-03",
      externalMrn = "MRN-SJ-91044",
      identityVerificationStatus = "PROVISIONAL",
      matchConfidence = "POSSIBLE_DEMOGRAPHIC_MATCH",
      fullName = "Evelyn Gallagher",
      dateOfBirth = "1959-02-21",
      sexAtBirth = "Female",
      careContextId = "CTX-AMU-A",
      assignedClinicianId = "USR-DOC-1",
      currentEncounterId = "ENC-2003",
      currentEncounterLabel = "AMU Assessment Bay 1 • Identity Pending",
      careTeamSummary = "Dr Sarah Jenkins (Consultant)",
      allergyStatusState = "NOT_ASSESSED",
      allergyBadgeSummary = "Allergies not assessed",
      updatedAt = now.minus(30, ChronoUnit.MINUTES).toString(),
    )
    patients["PAT-1004"] = PatientSummaryDto(
      patientId = "PAT-1004",
      nhsNumber = "943 880 3312",
      externalMrn = "MRN-SJ-65201",
      identityVerificationStatus = "VERIFIED",
      matchConfidence = "VERIFIED_IDENTITY",
      fullName = "Tariq Al-Mansoor",
      dateOfBirth = "1964-09-18",
      sexAtBirth = "Male",
      careContextId = "CTX-CARD-OPD",
      assignedClinicianId = "USR-DOC-1",
      currentEncounterId = "ENC-2004",
      currentEncounterLabel = "Cardiology Clinic Rm 4 • Follow-up",
      careTeamSummary = "Dr Sarah Jenkins (General Medicine), Dr Priya Nair (Cardiology)",
      allergyStatusState = "UNKNOWN",
      allergyBadgeSummary = "Allergy status unknown",
      updatedAt = now.minus(3, ChronoUnit.HOURS).toString(),
    )
    patients["PAT-9001"] = PatientSummaryDto(
      patientId = "PAT-9001",
      nhsNumber = "943 991 4401",
      externalMrn = "MRN-SJ-30991",
      identityVerificationStatus = "VERIFIED",
      matchConfidence = "VERIFIED_IDENTITY",
      fullName = "Helena Vance",
      dateOfBirth = "1982-04-09",
      sexAtBirth = "Female",
      careContextId = "CTX-RENAL-WARD",
      assignedClinicianId = null,
      currentEncounterId = "ENC-9001",
      currentEncounterLabel = "Renal Unit Ward 9C • Bed 11",
      careTeamSummary = "Dr Marcus Thorne (Nephrology)",
      allergyStatusState = "UNAVAILABLE",
      allergyBadgeSummary = "Allergy information unavailable",
      updatedAt = now.minus(4, ChronoUnit.HOURS).toString(),
    )

    encounters += listOf(
      EncounterDto("ENC-2001", "PAT-1001", "CTX-AMU-A", "USR-DOC-1", "INPATIENT_WARD", "ACTIVE", "AMU Ward 4B • Bed 06", "Acute kidney injury & community-acquired pneumonia review", now.minus(18, ChronoUnit.HOURS).toString()),
      EncounterDto("ENC-2002", "PAT-1002", "CTX-AMU-A", "USR-DOC-1", "SDEC_CONSULT", "ACTIVE", "SDEC Bay 2", "Pleuritic chest pain & D-dimer review", now.minus(3, ChronoUnit.HOURS).toString()),
      EncounterDto("ENC-2003", "PAT-1003", "CTX-AMU-A", "USR-DOC-1", "ACUTE_ASSESSMENT", "ACTIVE", "AMU Bay 1", "Syncope episode — provisional identity check", now.minus(45, ChronoUnit.MINUTES).toString()),
      EncounterDto("ENC-2004", "PAT-1004", "CTX-CARD-OPD", "USR-DOC-1", "OUTPATIENT", "SCHEDULED", "Clinic Suite 2 • Rm 4", "Heart failure titration review", now.plus(2, ChronoUnit.HOURS).toString()),
    )

    appointments += listOf(
      AppointmentDto("APT-3001", "PAT-1001", "Arthur Pendelton", "1948-06-14", "943 476 5919", "ENC-2001", "USR-DOC-1", "CTX-AMU-A", now.plus(25, ChronoUnit.MINUTES).toString(), 20, "Ward 4B Bed 06", "CHECKED_IN", "Morning ward round & corrected K+ review"),
      AppointmentDto("APT-3002", "PAT-1002", "Miriam Okafor", "1976-11-03", "943 512 0084", "ENC-2002", "USR-DOC-1", "CTX-AMU-A", now.plus(55, ChronoUnit.MINUTES).toString(), 20, "SDEC Bay 2", "IN_CLINIC", "Pleuritic chest pain & D-dimer assessment"),
      AppointmentDto("APT-3003", "PAT-1003", "Evelyn Gallagher", "1959-02-21", "Unverified-Demo-03", "ENC-2003", "USR-DOC-1", "CTX-AMU-A", now.plus(90, ChronoUnit.MINUTES).toString(), 30, "AMU Bay 1", "AWAITING_ID_CHECK", "Syncope assessment (confirm demographic match first)"),
    )

    problems += listOf(
      ProblemDto("PRB-1", "PAT-1001", "Stage 1 Acute Kidney Injury (resolving)", "SNOMED:14669001", "ACTIVE", "2026-11-21", "Dr Sarah Jenkins", now.minus(36, ChronoUnit.HOURS).toString(), "Aureom Ward EPR (Synthetic)"),
      ProblemDto("PRB-2", "PAT-1001", "Community-Acquired Pneumonia (right lower lobe)", "SNOMED:385093006", "ACTIVE", "2026-11-20", "Dr Liam Shaw", now.minus(40, ChronoUnit.HOURS).toString(), "Aureom Ward EPR (Synthetic)"),
      ProblemDto("PRB-3", "PAT-1001", "Type 2 Diabetes Mellitus", "SNOMED:44054006", "CHRONIC", "2014-05-10", "GP Summary Feed", now.minus(120, ChronoUnit.DAYS).toString(), "GP Connect Mock Adapter"),
      ProblemDto("PRB-4", "PAT-1002", "Suspected Pulmonary Embolism — rule-out pathway", "SNOMED:59282003", "PROVISIONAL", "2026-11-23", "Dr Sarah Jenkins", now.minus(2, ChronoUnit.HOURS).toString(), "SDEC Assessment"),
    )

    history += listOf(
      ClinicalHistoryDto("HIS-1", "PAT-1001", "PAST_MEDICAL", "Hypertension (2011), Benign prostatic hyperplasia (2019), Non-smoker.", "GP Summary Feed", now.minus(90, ChronoUnit.DAYS).toString(), "GP Connect Mock Adapter"),
      ClinicalHistoryDto("HIS-2", "PAT-1001", "SOCIAL", "Lives with spouse in bungalow; independent with ADLs prior to admission.", "Sister Maya Patel", now.minus(16, ChronoUnit.HOURS).toString(), "Nursing Admission Assessment"),
      ClinicalHistoryDto("HIS-3", "PAT-1002", "PAST_MEDICAL", "Oral contraceptive stopped 6 weeks ago; recent 9-hour flight.", "Dr Sarah Jenkins", now.minus(3, ChronoUnit.HOURS).toString(), "SDEC Intake"),
    )

    medications += listOf(
      MedicationDto("MED-101", "PAT-1001", "Doxycycline", "100 mg", "100 mg", "Oral", "Once daily (Day 3/5)", "PRESCRIBING", "ACTIVE", "2026-11-21", "2026-11-25", "ePMA Inpatient Chart (Simulated)", "Dr Sarah Jenkins"),
      MedicationDto("MED-102", "PAT-1001", "Doxycycline", "100 mg", "100 mg", "Oral", "08:00 dose given", "ADMINISTRATION", "COMPLETED_DOSE", "2026-11-23", null, "BCMA Ward Administration", "Sister Maya Patel"),
      MedicationDto("MED-103", "PAT-1001", "Metformin", "500 mg", "1000 mg", "Oral", "Twice daily (GP record)", "DISPENSING", "HELD_INPATIENT", "2024-01-12", null, "Community Pharmacy Dispensing Feed (Synthetic)", "GP/Pharmacy Feed", true, "GP/Dispensing shows 1000 mg BD; patient reports 500 mg OD due to GI upset. Held during AKI."),
      MedicationDto("MED-104", "PAT-1001", "Metformin", "500 mg", "500 mg", "Oral", "Once daily (Patient reported)", "PATIENT_REPORTED", "REPORTED_ACTIVE", "2026-10-01", null, "Admission Medicines Reconciliation", "Sister Maya Patel", true, "Discrepancy vs GP dispensing feed (1000 mg BD)."),
      MedicationDto("MED-105", "PAT-1002", "Apixaban", "5 mg", "5 mg", "Oral", "Twice daily (provisional hold)", "PRESCRIBING", "PENDING_REVIEW", "2026-11-23", null, "SDEC Prescribing Adapter (Simulated)", "Dr Sarah Jenkins"),
    )

    allergies += listOf(
      AllergyDto("ALG-101", "PAT-1001", "Penicillin (Amoxicillin)", "Generalised urticaria & facial angioedema", "CONFIRMED", "HIGH_SEVERE", "GP Summary & Patient Confirmation", "Dr Sarah Jenkins", now.minus(18, ChronoUnit.HOURS).toString()),
      AllergyDto("ALG-102", "PAT-1001", "Latex", "Contact dermatitis", "UNCONFIRMED", "LOW_MILD", "Patient-reported (2018)", "Sister Maya Patel", now.minus(16, ChronoUnit.HOURS).toString()),
    )

    observations += listOf(
      ObservationDto("OBS-101", "PAT-1001", "ENC-2001", "Systolic Blood Pressure", 128.0, "mmHg", "100–140 mmHg", "NORMAL", null, now.minus(55, ChronoUnit.MINUTES).toString(), "Ward 4B Welch Allyn Monitor", "VERIFIED"),
      ObservationDto("OBS-102", "PAT-1001", "ENC-2001", "Heart Rate", 94.0, "bpm", "60–90 bpm", "HIGH", null, now.minus(55, ChronoUnit.MINUTES).toString(), "Ward 4B Welch Allyn Monitor", "VERIFIED"),
      ObservationDto("OBS-103", "PAT-1001", "ENC-2001", "Oxygen Saturation (SpO2)", 95.0, "%", "94–98% (room air)", "NORMAL", null, now.minus(55, ChronoUnit.MINUTES).toString(), "Ward 4B Welch Allyn Monitor", "VERIFIED"),
      ObservationDto("OBS-104", "PAT-1001", "ENC-2001", "Capillary Blood Glucose", null, "mmol/L", "4.0–7.8 mmol/L", "MISSING", "Not recorded during 05:00 obs round (patient asleep)", now.minus(55, ChronoUnit.MINUTES).toString(), "Ward 4B Nursing Chart", "UNVERIFIED"),
    )

    results += listOf(
      DiagnosticResultDto("RES-200", "PAT-1001", "Arthur Pendelton", "ENC-2001", "Serum Potassium (K+)", "Biochemistry", "4.8", "mmol/L", "3.5–5.3 mmol/L", "NORMAL", "FINAL", "ACKNOWLEDGED", null, null, now.minus(6, ChronoUnit.HOURS).toString(), "St Jude LIMS (Synthetic)", "VERIFIED", "Dr Sarah Jenkins", now.minus(5, ChronoUnit.HOURS).toString()),
      DiagnosticResultDto("RES-201", "PAT-1001", "Arthur Pendelton", "ENC-2001", "Serum Potassium (K+)", "Biochemistry", "5.8", "mmol/L", "3.5–5.3 mmol/L", "HIGH", "CORRECTED", "AVAILABLE", "RES-200", "Initial sample diluted by IV line draw; repeat non-haemolysed venous sample confirms hyperkalaemia.", now.minus(25, ChronoUnit.MINUTES).toString(), "St Jude LIMS (Synthetic)", "VERIFIED"),
      DiagnosticResultDto("RES-202", "PAT-1001", "Arthur Pendelton", "ENC-2001", "Serum Creatinine", "Biochemistry", "146", "umol/L", "60–110 umol/L", "HIGH", "FINAL", "VIEWED", null, null, now.minus(40, ChronoUnit.MINUTES).toString(), "St Jude LIMS (Synthetic)", "VERIFIED"),
      DiagnosticResultDto("RES-203", "PAT-1002", "Miriam Okafor", "ENC-2002", "Quantitative D-dimer", "Haematology", "640", "ng/mL FEU", "< 500 ng/mL", "HIGH", "PRELIMINARY", "AVAILABLE", null, null, now.minus(20, ChronoUnit.MINUTES).toString(), "St Jude LIMS (Synthetic)", "PROVISIONAL"),
      DiagnosticResultDto("RES-204", "PAT-1001", "Arthur Pendelton", "ENC-2001", "Blood Culture — 48h Interim", "Microbiology", null, "", "No growth expected", "MISSING", "CANCELLED", "ACKNOWLEDGED", null, "Specimen rejected in lab: unlabelled bottle", now.minus(8, ChronoUnit.HOURS).toString(), "Microbiology LIMS (Synthetic)", "VERIFIED", "Dr Sarah Jenkins", now.minus(7, ChronoUnit.HOURS).toString()),
    )

    notes["NOTE-301"] = ClinicalNoteDto(
      noteId = "NOTE-301",
      patientId = "PAT-1001",
      patientName = "Arthur Pendelton",
      encounterId = "ENC-2001",
      templateType = "ADMISSION",
      title = "Acute Medical Admission Clerking",
      sections = listOf(
        NoteSectionDto("history", "Presenting Complaint & History", "78M admitted with 3 days productive cough, fever, and mild dehydration. Right basal crepitations."),
        NoteSectionDto("examination", "Examination", "Alert, HR 96, BP 124/76, SpO2 94% on room air, temp 38.1 C."),
        NoteSectionDto("impression", "Impression & Plan", "1. Right lower lobe CAP (CURB-65 2). 2. Mild pre-renal AKI. Start IV fluids and oral doxycycline (penicillin allergic)."),
      ),
      freeText = "Penicillin allergy verified with patient and GP summary prior to prescribing doxycycline.",
      status = "SIGNED",
      version = 1L,
      authorId = "USR-DOC-1",
      authorName = "Dr Sarah Jenkins",
      createdAt = now.minus(17, ChronoUnit.HOURS).toString(),
      updatedAt = now.minus(16, ChronoUnit.HOURS).toString(),
      signedAt = now.minus(16, ChronoUnit.HOURS).toString(),
      signedById = "USR-DOC-1",
      signedByName = "Dr Sarah Jenkins",
      contentHash = "sha256:9f82b1c4a8d0e331",
    )

    notes["NOTE-302"] = ClinicalNoteDto(
      noteId = "NOTE-302",
      patientId = "PAT-1001",
      patientName = "Arthur Pendelton",
      encounterId = "ENC-2001",
      templateType = "WARD_ROUND",
      title = "Morning Consultant Ward Round",
      sections = listOf(
        NoteSectionDto("progress", "Interval Progress", "Overnight fever settled. Drinking oral fluids well."),
        NoteSectionDto("obs_results", "Observations & Results Review", "Awaiting morning biochemistry check."),
        NoteSectionDto("plan", "Management Plan", "Continue doxycycline Day 3/5; review repeat U&Es."),
      ),
      freeText = "Draft started prior to morning round.",
      copiedAttributions = listOf(
        CopiedAttributionDto(
          attributionId = "ATT-1",
          sourceLabel = "Admission Clerking (NOTE-301)",
          sourceAuthor = "Dr Sarah Jenkins",
          sourceTimestamp = now.minus(16, ChronoUnit.HOURS).toString(),
          excerpt = "Right lower lobe CAP (CURB-65 2); penicillin allergic — doxycycline prescribed.",
        )
      ),
      status = "DRAFT",
      version = 1L,
      authorId = "USR-DOC-1",
      authorName = "Dr Sarah Jenkins",
      createdAt = now.minus(45, ChronoUnit.MINUTES).toString(),
      updatedAt = now.minus(35, ChronoUnit.MINUTES).toString(),
    )

    carePlans += CarePlanDto("PLAN-1", "PAT-1001", "Acute Kidney Injury & Sepsis Recovery Bundle", "Strict fluid balance charting, hold metformin until eGFR > 45 and repeat K+ < 5.2, repeat U&Es in 6 hours.", "ACTIVE", "Dr Sarah Jenkins", now.minus(10, ChronoUnit.HOURS).toString(), "Ward 4B Multidisciplinary Plan")

    tasks["TSK-401"] = FollowUpTaskDto("TSK-401", "PAT-1001", "Arthur Pendelton", "ENC-2001", "RES-201", "Repeat ECG & Potassium check after corrected K+ 5.8 mmol/L", "Assess ECG for peaked T-waves, stop any K+-sparing agents, repeat venous K+ in 4 hours.", "USR-DOC-1", "Dr Sarah Jenkins", "URGENT", now.plus(2, ChronoUnit.HOURS).toString(), "OPEN", null, null, null, "Dr Sarah Jenkins", now.minus(20, ChronoUnit.MINUTES).toString(), 1L)
    tasks["TSK-402"] = FollowUpTaskDto("TSK-402", "PAT-1002", "Miriam Okafor", "ENC-2002", "RES-203", "Arrange CTPA if clinical probability remains high", "Review Wells score alongside final D-dimer.", "USR-DOC-1", "Dr Sarah Jenkins", "URGENT", now.plus(3, ChronoUnit.HOURS).toString(), "IN_PROGRESS", null, null, null, "Dr Sarah Jenkins", now.minus(15, ChronoUnit.MINUTES).toString(), 1L)

    documents += ClinicalDocumentDto("DOC-501", "PAT-1001", "ENC-2001", "Previous Cardiology Clinic Letter (Synthetic)", "CLINIC_LETTER", "text/plain", "protected/PAT-1001/DOC-501", false, false, null, "Dr Priya Nair", true, null, now.minus(30, ChronoUnit.DAYS).toString(), "Outpatient Correspondence Archive")

    auditLogs += AuditLogDto("AUD-SEED-001", now.minus(16, ChronoUnit.HOURS).toString(), "USR-DOC-1", "Dr Sarah Jenkins", "DOCTOR", "SIGN_NOTE", "CLINICAL_NOTE", "NOTE-301", "PAT-1001", "CTX-AMU-A", "ALLOWED", "Admission note signed with atomic audit commit", false, """{"version":1}""")
  }
}
