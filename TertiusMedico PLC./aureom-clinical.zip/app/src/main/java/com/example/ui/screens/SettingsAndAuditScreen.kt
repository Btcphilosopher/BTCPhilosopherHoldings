package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.core.repository.UiResource
import com.example.ui.components.StatusPill
import com.example.ui.components.SyncStatusStrip
import com.example.ui.theme.*

@Composable
fun SettingsAndAuditScreen(
  session: AuthSessionResponse,
  syncStatus: SyncStatusSummary,
  biometricEnabled: Boolean,
  aiDraftingEnabled: Boolean,
  reducedMotion: Boolean,
  auditLogsState: UiResource<List<AuditLogDto>>,
  onToggleBiometric: (Boolean) -> Unit,
  onToggleAiDrafting: (Boolean) -> Unit,
  onToggleReducedMotion: (Boolean) -> Unit,
  onToggleOffline: (Boolean) -> Unit,
  onSyncNow: () -> Unit,
  onSimulateConflict: () -> Unit,
  onSimulateSessionExpiry: () -> Unit,
  onPurgeCache: () -> Unit,
  onRefreshAudit: () -> Unit,
  onSignOut: () -> Unit,
) {
  LaunchedEffect(Unit) {
    onRefreshAudit()
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("settings_audit_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item { Text("Settings, Privacy & Audit Trail", style = MaterialTheme.typography.headlineSmall) }

    item {
      SyncStatusStrip(syncStatus = syncStatus, onSyncNow = onSyncNow)
    }

    // Active Session Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("Active Organisational Session", style = MaterialTheme.typography.titleMedium)
          Text("${session.clinician.displayName} (${session.clinician.role}) • ${session.clinician.specialty}", style = MaterialTheme.typography.bodyMedium)
          Text("Context: ${session.clinician.activeCareContextName} (${session.clinician.activeCareContextId})", style = MaterialTheme.typography.bodySmall)
          Text("Session ID: ${session.sessionId} • Expires: ${session.expiresAt.take(19)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = onSignOut,
              colors = ButtonDefaults.buttonColors(containerColor = ClinicalDanger),
              modifier = Modifier.minimumInteractiveComponentSize().testTag("sign_out_button"),
            ) {
              Icon(Icons.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Sign Out & Purge Cache")
            }
            OutlinedButton(
              onClick = onSimulateSessionExpiry,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("simulate_expiry_button"),
            ) {
              Text("Test Session Expiry")
            }
          }
        }
      }
    }

    // Security, Privacy & Accessibility Preferences
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Security, AI & Accessibility Controls", style = MaterialTheme.typography.titleMedium)
          PreferenceSwitchRow(
            title = "Biometric local session unlock",
            subtitle = "Restores Android Keystore session access only; never replaces server auth or expiry checks.",
            checked = biometricEnabled,
            onCheckedChange = onToggleBiometric,
            tag = "biometric_toggle",
          )
          PreferenceSwitchRow(
            title = "Optional assistive AI drafting (Default: OFF)",
            subtitle = "Generates source-cited note structure strictly from authorised records. Clinician review required.",
            checked = aiDraftingEnabled,
            onCheckedChange = onToggleAiDrafting,
            tag = "ai_drafting_toggle",
          )
          PreferenceSwitchRow(
            title = "Reduced motion",
            subtitle = "Minimises UI transitions for clinical accessibility.",
            checked = reducedMotion,
            onCheckedChange = onToggleReducedMotion,
            tag = "reduced_motion_toggle",
          )
          PreferenceSwitchRow(
            title = "Simulate offline network state",
            subtitle = "Holds local drafts in Room and queues WorkManager deferred sync.",
            checked = syncStatus.isOfflineSimulated,
            onCheckedChange = onToggleOffline,
            tag = "settings_offline_toggle",
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onSimulateConflict, modifier = Modifier.minimumInteractiveComponentSize().testTag("settings_simulate_conflict")) {
              Text("Simulate Server Conflict (NOTE-302)")
            }
            OutlinedButton(onClick = onPurgeCache, modifier = Modifier.minimumInteractiveComponentSize().testTag("purge_cache_button")) {
              Text("Purge Local Cache")
            }
          }
        }
      }
    }

    // Governance & Pre-Deployment Verification Notice
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = ClinicalBlueContainer),
        border = BorderStroke(1.dp, ClinicalBlue),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text("Prototype & Pre-Deployment Regulatory Boundary", style = MaterialTheme.typography.titleSmall, color = OnClinicalBlueContainer)
          Text(
            "Aureom Clinical is an independent prototype using synthetic demonstration data. Before clinical deployment, identify the intended healthcare organisation and jurisdiction and verify official safety, privacy, and interoperability requirements (e.g., NHS DCB0129/DCB0160, UK GDPR, DTAC, NHS CIS2 OIDC, FHIR UK Core R4).",
            style = MaterialTheme.typography.bodySmall,
            color = OnClinicalBlueContainer,
          )
        }
      }
    }

    // Audit Log Inspector
    item {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        SectionHeader("Audit Trail (View, Edit, Sign, Export)", Icons.Outlined.Policy)
        TextButton(onClick = onRefreshAudit, modifier = Modifier.minimumInteractiveComponentSize().testTag("refresh_audit_button")) {
          Text("Refresh")
        }
      }
    }

    when (auditLogsState) {
      is UiResource.Loading -> item { CircularProgressIndicator() }
      is UiResource.Error -> item { Text(auditLogsState.message, color = ClinicalDanger) }
      is UiResource.Success -> {
        items(auditLogsState.data.take(30), key = { it.auditId }) { log ->
          Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, if (log.emergencyAccess) ClinicalDanger else MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("audit_row_${log.auditId}"),
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${log.action} • ${log.resourceType} (${log.resourceId})", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                StatusPill(
                  text = if (log.emergencyAccess) "BREAK-GLASS ${log.outcome}" else log.outcome,
                  containerColor = if (log.outcome == "DENIED" || log.emergencyAccess) ClinicalDangerContainer else ClinicalTealContainer,
                  contentColor = if (log.outcome == "DENIED" || log.emergencyAccess) ClinicalDanger else OnClinicalTealContainer,
                )
              }
              Text("${log.actorName} (${log.actorRole}) • Patient: ${log.patientId ?: "N/A"} • ${log.timestamp.take(19)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              log.reason?.let { Text("Reason: $it", style = MaterialTheme.typography.bodySmall) }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PreferenceSwitchRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  tag: String,
) {
  Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
    Column(modifier = Modifier.weight(1f)) {
      Text(title, style = MaterialTheme.typography.titleSmall)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Switch(checked = checked, onCheckedChange = onCheckedChange, modifier = Modifier.testTag(tag))
  }
}
