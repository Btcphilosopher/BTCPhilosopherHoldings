package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.database.LocalNoteDraftEntity
import com.example.core.database.PendingSyncOpEntity
import com.example.core.model.*
import com.example.core.repository.ClinicalRepository
import com.example.core.repository.UiResource
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

data class NoteEditorUiState(
  val noteId: String? = null,
  val boundPatientId: String = "",
  val boundPatientName: String = "",
  val boundEncounterId: String = "",
  val templateType: NoteTemplateType = NoteTemplateType.WARD_ROUND,
  val title: String = "",
  val sections: List<NoteSectionDto> = NoteTemplateType.WARD_ROUND.defaultSections.map { NoteSectionDto(it.first, it.second, "") },
  val freeText: String = "",
  val copiedAttributions: List<CopiedAttributionDto> = emptyList(),
  val baseVersion: Long = 1L,
  val status: String = "DRAFT",
  val dirty: Boolean = false,
  val autosaveLabel: String = "Autosave ready",
  val conflictMessage: String? = null,
  val serverConflictNote: ClinicalNoteDto? = null,
  val aiSuggestion: AiDraftSuggestion? = null,
  val signedMetadata: ClinicalNoteDto? = null,
)

class AureomViewModel(private val repo: ClinicalRepository) : ViewModel() {
  private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

  val session: StateFlow<AuthSessionResponse?> = repo.session
  val hasEncryptedStoredSession: StateFlow<Boolean> = repo.hasEncryptedStoredSession
  val worklistState: StateFlow<UiResource<WorklistResponseDto>> = repo.worklistState
  val patientOverviewState: StateFlow<UiResource<PatientOverviewDto>> = repo.patientOverviewState
  val patientSearchResults: StateFlow<UiResource<List<PatientSummaryDto>>> = repo.patientSearchResults
  val syncSummary: StateFlow<SyncStatusSummary> = repo.syncSummary
  val auditLogsState: StateFlow<UiResource<List<AuditLogDto>>> = repo.auditLogsState
  val fhirBundleState: StateFlow<UiResource<FhirPatientEverythingBundle>?> = repo.fhirBundleState
  val bannerMessage: StateFlow<String?> = repo.bannerMessage

  val allDrafts: StateFlow<List<LocalNoteDraftEntity>> = repo.allDrafts
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
  val pendingOps: StateFlow<List<PendingSyncOpEntity>> = repo.pendingOps
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val biometricUnlockEnabled: StateFlow<Boolean> = repo.vault.biometricUnlockEnabled
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
  val aiDraftingEnabled: StateFlow<Boolean> = repo.vault.aiDraftingEnabled
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
  val reducedMotionEnabled: StateFlow<Boolean> = repo.vault.reducedMotionEnabled
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
  val liveServerUrl: StateFlow<String> = repo.vault.liveServerUrl
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "http://10.0.2.2:8080")
  val connectionModeName: StateFlow<String> = repo.vault.connectionModeName
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ConnectionMode.EMBEDDED_DEMO_SERVER.name)

  private val _authError = MutableStateFlow<String?>(null)
  val authError: StateFlow<String?> = _authError.asStateFlow()

  private val _isSigningIn = MutableStateFlow(false)
  val isSigningIn: StateFlow<Boolean> = _isSigningIn.asStateFlow()

  private val _feedbackMessage = MutableStateFlow<String?>(null)
  val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

  private val _noteEditor = MutableStateFlow<NoteEditorUiState?>(null)
  val noteEditor: StateFlow<NoteEditorUiState?> = _noteEditor.asStateFlow()

  private var autosaveJob: Job? = null

  init {
    viewModelScope.launch {
      repo.initializeVaultState()
    }
  }

  fun signIn(username: String, careContextId: String) {
    viewModelScope.launch {
      _isSigningIn.value = true
      _authError.value = null
      repo.signInWithOidc(username, careContextId)
        .onFailure { _authError.value = it.message ?: "Sign-in failed" }
      _isSigningIn.value = false
    }
  }

  fun unlockWithBiometricSuccess() {
    viewModelScope.launch {
      _authError.value = null
      repo.restoreLocalSessionAfterBiometric()
        .onFailure { _authError.value = it.message ?: "Local session invalid or expired" }
    }
  }

  fun signOut(purgeLocalCache: Boolean = true) {
    viewModelScope.launch {
      _noteEditor.value = null
      repo.signOut(purgeLocalCache)
    }
  }

  fun refreshWorklist() {
    viewModelScope.launch { repo.loadWorklist() }
  }

  fun searchPatients(query: String, includeOtherContexts: Boolean) {
    viewModelScope.launch { repo.searchPatients(query, includeOtherContexts) }
  }

  fun openPatient(patientId: String) {
    viewModelScope.launch {
      repo.openPatientOverview(patientId)
    }
  }

  fun requestEmergencyAccess(patientId: String, reason: String) {
    viewModelScope.launch {
      repo.requestEmergencyAccess(patientId, reason)
        .onSuccess { _feedbackMessage.value = "Emergency access granted (${it.grantId})" }
        .onFailure { _feedbackMessage.value = it.message ?: "Emergency access denied" }
    }
  }

  fun openNewNoteForPatient(patient: PatientSummaryDto, templateType: NoteTemplateType = NoteTemplateType.CONSULTATION) {
    val encounterId = patient.currentEncounterId ?: "ENC-NEW"
    _noteEditor.value = NoteEditorUiState(
      noteId = "NOTE-${UUID.randomUUID().toString().take(6)}",
      boundPatientId = patient.patientId,
      boundPatientName = patient.fullName,
      boundEncounterId = encounterId,
      templateType = templateType,
      title = "${templateType.displayLabel} Note",
      sections = templateType.defaultSections.map { NoteSectionDto(it.first, it.second, "") },
      freeText = "",
      baseVersion = 1L,
      status = "DRAFT",
      autosaveLabel = "New draft bound to ${patient.fullName} (${patient.patientId})",
    )
  }

  fun openExistingNote(note: ClinicalNoteDto, localOverride: LocalNoteDraftEntity? = null) {
    val template = NoteTemplateType.entries.firstOrNull { it.apiKey == (localOverride?.templateType ?: note.templateType) }
      ?: NoteTemplateType.WARD_ROUND
    val conflictServer = localOverride?.serverSnapshotJson?.let {
      runCatching { json.decodeFromString<ClinicalNoteDto>(it) }.getOrNull()
    }
    val sections: List<NoteSectionDto> = localOverride?.let {
      runCatching { json.decodeFromString<List<NoteSectionDto>>(it.sectionsJson) }.getOrNull()
    } ?: note.sections
    val attributions: List<CopiedAttributionDto> = localOverride?.let {
      runCatching { json.decodeFromString<List<CopiedAttributionDto>>(it.copiedAttributionsJson) }.getOrNull()
    } ?: note.copiedAttributions

    _noteEditor.value = NoteEditorUiState(
      noteId = note.noteId,
      boundPatientId = note.patientId,
      boundPatientName = note.patientName.ifBlank { localOverride?.patientName ?: note.patientId },
      boundEncounterId = note.encounterId,
      templateType = template,
      title = localOverride?.title ?: note.title,
      sections = sections,
      freeText = localOverride?.freeText ?: note.freeText,
      copiedAttributions = attributions,
      baseVersion = localOverride?.baseVersion ?: note.version,
      status = localOverride?.status ?: note.status,
      dirty = localOverride?.dirty ?: false,
      autosaveLabel = when {
        localOverride?.status == "CONFLICT" -> "Conflict detected — review server vs local changes"
        localOverride?.dirty == true -> "Local autosave pending sync"
        note.status == "SIGNED" -> "Signed & immutable"
        note.status == "ENTERED_IN_ERROR" -> "Entered in error (history retained)"
        else -> "Loaded v${note.version}"
      },
      conflictMessage = localOverride?.conflictMessage,
      serverConflictNote = conflictServer,
      signedMetadata = if (note.status != "DRAFT") note else null,
    )
  }

  fun changeTemplate(templateType: NoteTemplateType) {
    val cur = _noteEditor.value ?: return
    if (cur.status != "DRAFT") return
    val existingMap = cur.sections.associateBy { it.key }
    val merged = templateType.defaultSections.map { (k, label) ->
      NoteSectionDto(k, label, existingMap[k]?.content ?: "")
    }
    updateDraftContent(cur.copy(templateType = templateType, sections = merged))
  }

  fun updateTitle(title: String) {
    val cur = _noteEditor.value ?: return
    if (cur.status != "DRAFT" && cur.status != "CONFLICT") return
    updateDraftContent(cur.copy(title = title))
  }

  fun updateSection(key: String, content: String) {
    val cur = _noteEditor.value ?: return
    if (cur.status != "DRAFT" && cur.status != "CONFLICT") return
    val updated = cur.sections.map { if (it.key == key) it.copy(content = content) else it }
    updateDraftContent(cur.copy(sections = updated))
  }

  fun updateFreeText(freeText: String) {
    val cur = _noteEditor.value ?: return
    if (cur.status != "DRAFT" && cur.status != "CONFLICT") return
    updateDraftContent(cur.copy(freeText = freeText))
  }

  fun addCopiedAttribution(sourceLabel: String, sourceAuthor: String, sourceTimestamp: String, excerpt: String) {
    val cur = _noteEditor.value ?: return
    if (cur.status != "DRAFT") return
    val attr = CopiedAttributionDto(
      attributionId = "ATT-${UUID.randomUUID().toString().take(6)}",
      sourceLabel = sourceLabel,
      sourceAuthor = sourceAuthor,
      sourceTimestamp = sourceTimestamp,
      excerpt = excerpt,
    )
    val appended = if (cur.freeText.isBlank()) "[Copied from $sourceLabel — $sourceAuthor]: $excerpt"
    else "${cur.freeText}\n\n[Copied from $sourceLabel — $sourceAuthor]: $excerpt"
    updateDraftContent(cur.copy(freeText = appended, copiedAttributions = cur.copiedAttributions + attr))
  }

  private fun updateDraftContent(updated: NoteEditorUiState) {
    _noteEditor.value = updated.copy(dirty = true, autosaveLabel = "Saving local draft...")
    autosaveJob?.cancel()
    autosaveJob = viewModelScope.launch {
      delay(350)
      val savedEntity = repo.autosaveNoteDraft(
        noteId = updated.noteId,
        expectedPatientId = updated.boundPatientId,
        patientName = updated.boundPatientName,
        encounterId = updated.boundEncounterId,
        templateType = updated.templateType,
        title = updated.title,
        sections = updated.sections,
        freeText = updated.freeText,
        copiedAttributions = updated.copiedAttributions,
        baseVersion = updated.baseVersion,
      )
      _noteEditor.value = _noteEditor.value?.copy(
        noteId = savedEntity.noteId,
        autosaveLabel = "Autosaved locally to encrypted Room store",
      )
    }
  }

  fun syncDraftToServer() {
    val cur = _noteEditor.value ?: return
    viewModelScope.launch {
      val entity = repo.autosaveNoteDraft(
        noteId = cur.noteId,
        expectedPatientId = cur.boundPatientId,
        patientName = cur.boundPatientName,
        encounterId = cur.boundEncounterId,
        templateType = cur.templateType,
        title = cur.title,
        sections = cur.sections,
        freeText = cur.freeText,
        copiedAttributions = cur.copiedAttributions,
        baseVersion = cur.baseVersion,
      )
      repo.submitOrQueueNoteDraft(entity)
        .onSuccess { msg ->
          _feedbackMessage.value = msg
          val refreshed = repo.db.clinicalCacheDao().getDraftById(entity.noteId)
          if (refreshed != null) {
            _noteEditor.value = _noteEditor.value?.copy(
              baseVersion = refreshed.baseVersion,
              dirty = refreshed.dirty,
              status = refreshed.status,
              autosaveLabel = msg,
            )
          }
        }
        .onFailure { err ->
          val refreshed = repo.db.clinicalCacheDao().getDraftById(entity.noteId)
          val serverNote = refreshed?.serverSnapshotJson?.let { runCatching { json.decodeFromString<ClinicalNoteDto>(it) }.getOrNull() }
          _noteEditor.value = _noteEditor.value?.copy(
            status = refreshed?.status ?: cur.status,
            conflictMessage = err.message,
            serverConflictNote = serverNote,
            autosaveLabel = "Conflict detected — action required",
          )
          _feedbackMessage.value = err.message
        }
    }
  }

  fun resolveConflict(keepLocal: Boolean) {
    val cur = _noteEditor.value ?: return
    val serverNote = cur.serverConflictNote ?: return
    viewModelScope.launch {
      val entity = repo.db.clinicalCacheDao().getDraftById(cur.noteId ?: return@launch) ?: return@launch
      repo.resolveDraftConflict(entity, keepLocal, serverNote)
        .onSuccess { msg ->
          _feedbackMessage.value = msg
          val refreshed = repo.db.clinicalCacheDao().getDraftById(entity.noteId)
          if (refreshed != null) {
            openExistingNote(serverNote, refreshed)
          }
        }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun signCurrentNote(confirmedPatientId: String) {
    val cur = _noteEditor.value ?: return
    viewModelScope.launch {
      val entity = repo.autosaveNoteDraft(
        noteId = cur.noteId,
        expectedPatientId = cur.boundPatientId,
        patientName = cur.boundPatientName,
        encounterId = cur.boundEncounterId,
        templateType = cur.templateType,
        title = cur.title,
        sections = cur.sections,
        freeText = cur.freeText,
        copiedAttributions = cur.copiedAttributions,
        baseVersion = cur.baseVersion,
      )
      repo.signNote(entity, confirmedPatientId)
        .onSuccess { signed ->
          _feedbackMessage.value = "Note signed & locked (v${signed.version})"
          openExistingNote(signed)
        }
        .onFailure { _feedbackMessage.value = it.message ?: "Signing failed" }
    }
  }

  fun addAmendment(noteId: String, confirmedPatientId: String, type: String, bodyText: String, reason: String) {
    viewModelScope.launch {
      repo.addAmendment(noteId, confirmedPatientId, type, bodyText, reason)
        .onSuccess { updated ->
          _feedbackMessage.value = "$type recorded and linked to $noteId"
          if (_noteEditor.value?.noteId == noteId) openExistingNote(updated)
        }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun markEnteredInError(noteId: String, confirmedPatientId: String, reason: String) {
    viewModelScope.launch {
      repo.markEnteredInError(noteId, confirmedPatientId, reason)
        .onSuccess { updated ->
          _feedbackMessage.value = "Note marked Entered-in-Error (history retained)"
          if (_noteEditor.value?.noteId == noteId) openExistingNote(updated)
        }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun requestAiAssistiveDraft(overview: PatientOverviewDto) {
    val cur = _noteEditor.value ?: return
    if (!aiDraftingEnabled.value) return
    val suggestion = repo.generateAssistiveDraft(overview, cur.templateType)
    _noteEditor.value = cur.copy(aiSuggestion = suggestion)
  }

  fun applyAiSuggestionToDraft() {
    val cur = _noteEditor.value ?: return
    val sug = cur.aiSuggestion ?: return
    if (cur.status != "DRAFT") return
    updateDraftContent(
      cur.copy(
        sections = sug.suggestedSections,
        copiedAttributions = cur.copiedAttributions + CopiedAttributionDto(
          attributionId = "AI-${UUID.randomUUID().toString().take(5)}",
          sourceLabel = "Assistive Summary (${sug.citedRecordIds.joinToString(", ")})",
          sourceAuthor = "Clinician-reviewed assistive draft",
          sourceTimestamp = java.time.Instant.now().toString(),
          excerpt = sug.summaryBullets.joinToString(" | "),
        ),
        aiSuggestion = null,
      )
    )
  }

  fun dismissAiSuggestion() {
    _noteEditor.value = _noteEditor.value?.copy(aiSuggestion = null)
  }

  fun updateResultWorkflow(resultId: String, confirmedPatientId: String, targetState: String, followUpTaskId: String? = null) {
    viewModelScope.launch {
      repo.updateResultWorkflow(resultId, confirmedPatientId, targetState, followUpTaskId)
        .onSuccess { _feedbackMessage.value = "Result $resultId updated to $targetState" }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun reconcileMedication(medicationId: String, patientId: String, action: String, note: String?) {
    viewModelScope.launch {
      repo.reconcileMedication(medicationId, patientId, action, note)
        .onSuccess { _feedbackMessage.value = "Medication reconciliation updated" }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun createTask(req: CreateTaskRequest) {
    viewModelScope.launch {
      repo.createFollowUpTask(req)
        .onSuccess { _feedbackMessage.value = "Follow-up task created (${it.taskId})" }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun completeTask(taskId: String, confirmedPatientId: String, evidence: String, version: Long) {
    viewModelScope.launch {
      repo.completeFollowUpTask(taskId, confirmedPatientId, evidence, version)
        .onSuccess { _feedbackMessage.value = "Task completed with evidence" }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun saveClinicalPhoto(
    confirmedPatientId: String,
    encounterId: String?,
    title: String,
    uri: Uri,
    consentRecorded: Boolean,
    consentNote: String,
  ) {
    viewModelScope.launch {
      repo.saveProtectedClinicalPhoto(confirmedPatientId, encounterId, title, uri, consentRecorded, consentNote, null)
        .onSuccess { _feedbackMessage.value = "Protected clinical photograph saved (${it.documentId})" }
        .onFailure { _feedbackMessage.value = it.message }
    }
  }

  fun loadFhirBundle(patientId: String) {
    viewModelScope.launch { repo.loadFhirBundle(patientId) }
  }

  fun loadAuditLogs(patientId: String? = null) {
    viewModelScope.launch { repo.loadAuditLogs(patientId) }
  }

  fun setOfflineSimulated(offline: Boolean) {
    repo.setOfflineSimulated(offline)
  }

  fun triggerManualSync() {
    viewModelScope.launch { repo.triggerManualSync() }
  }

  fun simulateConcurrentEdit(noteId: String = "NOTE-302") {
    val ok = repo.simulateServerConcurrentEdit(noteId)
    _feedbackMessage.value = if (ok) {
      "Simulated registrar update on server for $noteId (version bumped)"
    } else {
      "Could not simulate edit — $noteId is not currently a server draft"
    }
  }

  fun simulateSessionExpiry() {
    viewModelScope.launch { repo.simulateSessionExpiry() }
  }

  fun purgeLocalCache() {
    viewModelScope.launch { repo.purgeAllCachedPhi() }
  }

  fun setBiometricEnabled(enabled: Boolean) {
    viewModelScope.launch { repo.vault.setBiometricUnlockEnabled(enabled) }
  }

  fun setAiDraftingEnabled(enabled: Boolean) {
    viewModelScope.launch { repo.vault.setAiDraftingEnabled(enabled) }
  }

  fun setReducedMotion(enabled: Boolean) {
    viewModelScope.launch { repo.vault.setReducedMotionEnabled(enabled) }
  }

  fun updateServerConfig(mode: ConnectionMode, url: String) {
    repo.api.connectionMode = mode
    repo.api.baseUrl = url.trim().trimEnd('/')
    viewModelScope.launch {
      repo.setServerConfiguration(mode, url)
      _feedbackMessage.value = "Connection target updated: ${mode.name}"
    }
  }

  fun clearFeedback() {
    _feedbackMessage.value = null
    repo.clearBanner()
  }

  class Factory(private val repo: ClinicalRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AureomViewModel(repo) as T
  }
}
