package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.PatientSummaryDto
import com.example.core.repository.UiResource
import com.example.ui.components.ClinicalStateCard
import com.example.ui.components.StatusPill
import com.example.ui.theme.*

@Composable
fun PatientsScreen(
  searchResults: UiResource<List<PatientSummaryDto>>,
  onSearch: (query: String, includeOtherContexts: Boolean) -> Unit,
  onSelectPatient: (String) -> Unit,
  onRequestEmergencyAccess: (patientId: String, reason: String) -> Unit,
) {
  var query by remember { mutableStateOf("") }
  var includeOtherContexts by remember { mutableStateOf(false) }
  var breakGlassTarget by remember { mutableStateOf<PatientSummaryDto?>(null) }
  var breakGlassReason by remember { mutableStateOf("") }

  LaunchedEffect(query, includeOtherContexts) {
    onSearch(query, includeOtherContexts)
  }

  Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Patient Search & Identification", style = MaterialTheme.typography.headlineSmall)

    OutlinedTextField(
      value = query,
      onValueChange = { query = it },
      label = { Text("Search name, NHS number, MRN, or DOB (YYYY-MM-DD)") },
      leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("patient_search_input"),
    )

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
      Text("Include outside-context patients (requires break-glass)", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
      Switch(
        checked = includeOtherContexts,
        onCheckedChange = { includeOtherContexts = it },
        modifier = Modifier.testTag("include_other_contexts_switch"),
      )
    }

    when (searchResults) {
      is UiResource.Loading -> {
        Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
          CircularProgressIndicator()
        }
      }
      is UiResource.Error -> {
        ClinicalStateCard(
          icon = Icons.Outlined.ErrorOutline,
          title = "Search Unavailable",
          message = searchResults.message,
          actionLabel = "Retry",
          onAction = { onSearch(query, includeOtherContexts) },
        )
      }
      is UiResource.Success -> {
        if (searchResults.data.isEmpty()) {
          ClinicalStateCard(
            icon = Icons.Outlined.PersonSearch,
            title = "No Matching Patients",
            message = "Check spelling, NHS number, or enable outside-context search if cross-covering.",
          )
        } else {
          LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
            items(searchResults.data, key = { it.patientId }) { patient ->
              val isPossible = patient.matchConfidence == "POSSIBLE_DEMOGRAPHIC_MATCH"
              Card(
                onClick = {
                  if (patient.hasAccessInCurrentContext) {
                    onSelectPatient(patient.patientId)
                  } else {
                    breakGlassTarget = patient
                    breakGlassReason = ""
                  }
                },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, if (isPossible) ClinicalWarning else MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth().testTag("patient_row_${patient.patientId}"),
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(patient.fullName, style = MaterialTheme.typography.titleMedium)
                    if (isPossible) {
                      StatusPill("POSSIBLE DEMOGRAPHIC MATCH", ClinicalWarningContainer, ClinicalWarning, Icons.Filled.ReportProblem)
                    } else {
                      StatusPill("VERIFIED IDENTITY", ClinicalTealContainer, OnClinicalTealContainer, Icons.Filled.VerifiedUser)
                    }
                  }
                  Text(
                    "DOB ${patient.dateOfBirth} • ${patient.sexAtBirth} • NHS ${patient.nhsNumber} (${patient.identityVerificationStatus}) • MRN ${patient.externalMrn}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  Text("Encounter: ${patient.currentEncounterLabel ?: "None"}", style = MaterialTheme.typography.bodySmall)
                  Text("Care team: ${patient.careTeamSummary}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusPill(
                      text = patient.allergyBadgeSummary,
                      containerColor = if (patient.allergyStatusState == "RECORDED") ClinicalDangerContainer else ClinicalNeutralContainer,
                      contentColor = if (patient.allergyStatusState == "RECORDED") ClinicalDanger else ClinicalNeutralBadge,
                    )
                    if (!patient.hasAccessInCurrentContext) {
                      StatusPill("OUTSIDE CONTEXT (${patient.careContextId})", ClinicalDangerContainer, ClinicalDanger, Icons.Filled.Lock)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  breakGlassTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { breakGlassTarget = null },
      icon = { Icon(Icons.Filled.Security, contentDescription = null, tint = ClinicalDanger) },
      title = { Text("Restricted Emergency Access") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "${target.fullName} (${target.patientId}) is assigned to ${target.careContextId}, outside your active care context. Emergency break-glass access is time-limited and audited for Caldicott review.",
            style = MaterialTheme.typography.bodySmall,
          )
          OutlinedTextField(
            value = breakGlassReason,
            onValueChange = { breakGlassReason = it },
            label = { Text("Clinical justification (min 8 characters)") },
            modifier = Modifier.fillMaxWidth().testTag("break_glass_reason_input"),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onRequestEmergencyAccess(target.patientId, breakGlassReason)
            breakGlassTarget = null
          },
          enabled = breakGlassReason.trim().length >= 8,
          colors = ButtonDefaults.buttonColors(containerColor = ClinicalDanger),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("break_glass_confirm_button"),
        ) {
          Text("Grant Emergency Access")
        }
      },
      dismissButton = {
        TextButton(onClick = { breakGlassTarget = null }, modifier = Modifier.minimumInteractiveComponentSize()) {
          Text("Cancel")
        }
      },
    )
  }
}
