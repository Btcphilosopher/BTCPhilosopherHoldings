package com.example.core.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.example.core.ai.AssistiveDraftingEngine
import com.example.core.database.*
import com.example.core.model.*
import com.example.core.network.ClinicalApiClient
import com.example.core.network.ClinicalApiException
import com.example.core.security.ClinicalLogger
import com.example.core.security.CredentialVault
import com.example.core.sync.ClinicalSyncExecutor
import com.example.core.sync.SyncScheduler
import kotlinx.coroutines.flow.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.time.Instant
import java.util.UUID

sealed interface UiResource<out T> {
  data object Loading : UiResource<Nothing>
  data class Success<T>(val data: T, val fromCache: Boolean = false, val cacheTimestampMs: Long? = null) : UiResource<T>
  data class Error(val message: String, val code: String = "ERROR", val isPermissionDenied: Boolean = false) : UiResource<Nothing>
}

class ClinicalRepository(
  private val context: Context,
  val db: AureomDatabase,
  val vault: CredentialVault,
  val api: ClinicalApiClient,
  val syncExecutor: ClinicalSyncExecutor,
  val syncScheduler: SyncScheduler,
) {
  private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
  private val dao = db.clinicalCacheDao()

  private val _session = MutableStateFlow<AuthSessionResponse?>(null)
  val session: StateFlow<AuthSessionResponse?> = _session.asStateFlow()

  private val _hasEncryptedStoredSession = MutableStateFlow(false)
  val hasEncryptedStoredSession: StateFlow<Boolean> = _hasEncryptedStoredSession.asStateFlow()

  private val _worklistState = MutableStateFlow<UiResource<WorklistResponseDto>>(UiResource.Loading)
  val worklistState: StateFlow<UiResource<WorklistResponseDto>> = _worklistState.asStateFlow()

  private val _activePatientId = MutableStateFlow<String?>(null)
  val activePatientId: StateFlow<String?> = _activePatientId.asStateFlow()

  private val _patientOverviewState = MutableStateFlow<UiResource<PatientOverviewDto>>(UiResource.Loading)
  val patientOverviewState: StateFlow<UiResource<PatientOverviewDto>> = _patientOverviewState.asStateFlow()

  private val _patientSearchResults = MutableStateFlow<UiResource<List<PatientSummaryDto>>>(UiResource.Success(emptyList()))
  val patientSearchResults: StateFlow<UiResource<List<PatientSummaryDto>>> = _patientSearchResults.asStateFlow()

  private val _auditLogsState = MutableStateFlow<UiResource<List<AuditLogDto>>>(UiResource.Success(emptyList()))
  val auditLogsState: StateFlow<UiResource<List<AuditLogDto>>> = _auditLogsState.asStateFlow()

  private val _fhirBundleState = MutableStateFlow<UiResource<FhirPatientEverythingBundle>?>(null)
  val fhirBundleState: StateFlow<UiResource<FhirPatientEverythingBundle>?> = _fhirBundleState.asStateFlow()

  private val _isOfflineSimulated = MutableStateFlow(false)
  private val _isSyncing = MutableStateFlow(false)
  private val _bannerMessage = MutableStateFlow<String?>(null)
  val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

  val allDrafts: Flow<List<LocalNoteDraftEntity>> = dao.observeAllDrafts()
  val pendingOps: Flow<List<PendingSyncOpEntity>> = dao.observePendingOps()

  val syncSummary: StateFlow<SyncStatusSummary> = combine(
    _isOfflineSimulated,
    _isSyncing,
    dao.observeSyncMetadata(),
    dao.observeOldestCacheTimestamp(),
    dao.observePendingOps(),
    dao.observeAllDrafts(),
  ) { arr ->
    val offline = arr[0] as Boolean
    val syncing = arr[1] as Boolean
    val meta = arr[2] as SyncMetadataEntity?
    val oldest = arr[3] as Long?
    @Suppress("UNCHECKED_CAST")
    val ops = arr[4] as List<PendingSyncOpEntity>
    @Suppress("UNCHECKED_CAST")
    val drafts = arr[5] as List<LocalNoteDraftEntity>

    val conflicts = drafts.count { it.status == "CONFLICT" } + ops.count { it.state == "CONFLICT" }
    val failed = ops.count { it.state == "FAILED" }
    SyncStatusSummary(
      isOfflineSimulated = offline,
      isSyncing = syncing,
      lastSuccessfulSyncEpochMs = meta?.lastSuccessfulSyncEpochMs,
      oldestCachedRecordEpochMs = oldest,
      pendingUploadCount = ops.count { it.state in setOf("PENDING", "IN_FLIGHT") },
      conflictCount = conflicts,
      failedOperationCount = failed,
      lastErrorMessage = meta?.lastError,
      workManagerStateLabel = when {
        offline -> "Offline — local drafts queued for WorkManager deferred sync"
        syncing -> "Synchronising with clinical server..."
        conflicts > 0 -> "Action required: $conflicts edit conflict(s) awaiting clinician review"
        ops.isNotEmpty() -> "WorkManager scheduled (${ops.size} pending item(s))"
        else -> "Up to date (WorkManager connected-network constraint)"
      },
    )
  }.stateIn(
    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO),
    SharingStarted.Eagerly,
    SyncStatusSummary(),
  )

  suspend fun initializeVaultState() {
    val modeName = vault.connectionModeName.first()
    val url = vault.liveServerUrl.first()
    api.connectionMode = runCatching { ConnectionMode.valueOf(modeName) }.getOrDefault(ConnectionMode.EMBEDDED_DEMO_SERVER)
    api.baseUrl = url
    _hasEncryptedStoredSession.value = vault.hasStoredSession()
  }

  suspend fun signInWithOidc(username: String, careContextId: String): Result<AuthSessionResponse> {
    return try {
      val resp = api.signInOidc(OidcTokenRequest(username = username, careContextId = careContextId))
      vault.saveSession(resp)
      _session.value = resp
      _hasEncryptedStoredSession.value = true
      loadWorklist()
      Result.success(resp)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun restoreLocalSessionAfterBiometric(): Result<AuthSessionResponse> {
    val stored = vault.loadSession()
      ?: return Result.failure(IllegalStateException("No protected local session available"))
    if (Instant.now().isAfter(Instant.parse(stored.expiresAt))) {
      handleSessionInvalidated("Stored session expired — organisational sign-in required")
      return Result.failure(ClinicalApiException.Unauthorized("Session expired"))
    }
    _session.value = stored
    loadWorklist()
    return Result.success(stored)
  }

  suspend fun signOut(purgeLocalCache: Boolean = true) {
    val token = _session.value?.accessToken
    if (token != null) {
      api.logout(token)
    }
    syncScheduler.cancelPendingWork()
    vault.clearSession()
    _session.value = null
    _hasEncryptedStoredSession.value = false
    _activePatientId.value = null
    _worklistState.value = UiResource.Loading
    _patientOverviewState.value = UiResource.Loading
    if (purgeLocalCache) {
      purgeAllCachedPhi()
    }
  }

  suspend fun purgeAllCachedPhi() {
    dao.purgeAllPatients()
    dao.purgeAllDrafts()
    dao.purgeAllPendingOps()
    dao.purgeAllAttachments()
    File(context.filesDir, "clinical_attachments").deleteRecursively()
    _bannerMessage.value = "Local cached records and drafts purged per session policy."
  }

  fun setOfflineSimulated(offline: Boolean) {
    _isOfflineSimulated.value = offline
    api.isOfflineSimulated = offline
    if (!offline) {
      syncScheduler.enqueueDeferredSync()
    }
  }

  suspend fun setServerConfiguration(mode: ConnectionMode, url: String) {
    api.connectionMode = mode
    api.baseUrl = url.trim().trimEnd('/')
    vault.setServerConfig(mode.name, url)
  }

  fun clearBanner() {
    _bannerMessage.value = null
  }

  suspend fun loadWorklist() {
    val current = _session.value ?: return
    _worklistState.value = UiResource.Loading
    try {
      val data = api.getWorklist(current.accessToken)
      dao.upsertSyncMetadata(SyncMetadataEntity(lastSuccessfulSyncEpochMs = System.currentTimeMillis(), lastError = null))
      _worklistState.value = UiResource.Success(data)
    } catch (e: ClinicalApiException.Unauthorized) {
      handleSessionInvalidated(e.message ?: "Session expired")
    } catch (e: ClinicalApiException.Offline) {
      _worklistState.value = UiResource.Error("Offline — showing cached patient access only", "OFFLINE")
    } catch (e: Exception) {
      _worklistState.value = UiResource.Error(e.message ?: "Failed to load worklist")
    }
  }

  suspend fun searchPatients(query: String, includeOtherContexts: Boolean) {
    val current = _session.value ?: return
    _patientSearchResults.value = UiResource.Loading
    try {
      val page = api.searchPatients(current.accessToken, query, includeOtherContexts)
      _patientSearchResults.value = UiResource.Success(page.items)
    } catch (e: ClinicalApiException.Unauthorized) {
      handleSessionInvalidated(e.message ?: "Session expired")
    } catch (e: ClinicalApiException.Offline) {
      // Fallback to permitted cached patients in Room
      val cached = dao.observePatientsForContext(current.clinician.activeCareContextId).first()
        .map { json.decodeFromString<PatientOverviewDto>(it.overviewJson).patient }
        .filter {
          query.isBlank() ||
            it.fullName.contains(query, ignoreCase = true) ||
            it.nhsNumber.contains(query, ignoreCase = true) ||
            it.dateOfBirth.contains(query)
        }
      _patientSearchResults.value = UiResource.Success(cached, fromCache = true)
    } catch (e: Exception) {
      _patientSearchResults.value = UiResource.Error(e.message ?: "Search failed")
    }
  }

  suspend fun openPatientOverview(patientId: String) {
    val current = _session.value ?: return
    _activePatientId.value = patientId
    _fhirBundleState.value = null
    _patientOverviewState.value = UiResource.Loading
    try {
      val overview = api.getPatientOverview(current.accessToken, patientId)
      val nowMs = System.currentTimeMillis()
      dao.upsertPatientCache(
        CachedPatientEntity(
          patientId = patientId,
          careContextId = overview.patient.careContextId,
          overviewJson = json.encodeToString(overview),
          cachedAtEpochMs = nowMs,
          expiresAtEpochMs = nowMs + 4 * 60 * 60 * 1000L, // 4-hour local cache TTL
        )
      )
      // Sync server drafts into Room unless local draft has dirty/conflict state
      overview.previousNotes.filter { it.status == "DRAFT" }.forEach { serverNote ->
        val local = dao.getDraftById(serverNote.noteId)
        if (local == null || (!local.dirty && local.status != "CONFLICT")) {
          dao.upsertDraft(
            LocalNoteDraftEntity(
              noteId = serverNote.noteId,
              patientId = serverNote.patientId,
              patientName = overview.patient.fullName,
              encounterId = serverNote.encounterId,
              templateType = serverNote.templateType,
              title = serverNote.title,
              sectionsJson = json.encodeToString(serverNote.sections),
              freeText = serverNote.freeText,
              copiedAttributionsJson = json.encodeToString(serverNote.copiedAttributions),
              baseVersion = serverNote.version,
              status = serverNote.status,
              dirty = false,
              pendingSync = false,
              conflictMessage = null,
              serverSnapshotJson = null,
              idempotencyKey = UUID.randomUUID().toString(),
              updatedAtEpochMs = nowMs,
            )
          )
        }
      }
      _patientOverviewState.value = UiResource.Success(overview, fromCache = false, cacheTimestampMs = nowMs)
    } catch (e: ClinicalApiException.Unauthorized) {
      handleSessionInvalidated(e.message ?: "Session expired")
    } catch (e: ClinicalApiException.Forbidden) {
      _patientOverviewState.value = UiResource.Error(
        message = e.message ?: "Access denied for this patient's care context",
        code = e.code,
        isPermissionDenied = true,
      )
    } catch (e: ClinicalApiException.Offline) {
      val cached = dao.getPatientCache(patientId)
      if (cached != null && cached.expiresAtEpochMs > System.currentTimeMillis()) {
        val overview = json.decodeFromString<PatientOverviewDto>(cached.overviewJson)
        _patientOverviewState.value = UiResource.Success(overview, fromCache = true, cacheTimestampMs = cached.cachedAtEpochMs)
      } else {
        _patientOverviewState.value = UiResource.Error("Offline and no valid cached record for this patient", "OFFLINE")
      }
    } catch (e: Exception) {
      _patientOverviewState.value = UiResource.Error(e.message ?: "Failed to load patient overview")
    }
  }

  suspend fun requestEmergencyAccess(patientId: String, reason: String): Result<EmergencyAccessGrantDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    return try {
      val grant = api.requestEmergencyAccess(current.accessToken, patientId, reason)
      _bannerMessage.value = "Emergency access granted for $patientId (logged for Caldicott review)."
      openPatientOverview(patientId)
      Result.success(grant)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun autosaveNoteDraft(
    noteId: String?,
    expectedPatientId: String,
    patientName: String,
    encounterId: String,
    templateType: NoteTemplateType,
    title: String,
    sections: List<NoteSectionDto>,
    freeText: String,
    copiedAttributions: List<CopiedAttributionDto>,
    baseVersion: Long,
  ): LocalNoteDraftEntity {
    val resolvedId = noteId ?: "NOTE-${UUID.randomUUID().toString().take(6)}"
    val existing = dao.getDraftById(resolvedId)
    require(existing == null || existing.patientId == expectedPatientId) {
      "Patient safety guard: Draft $resolvedId belongs to ${existing?.patientId}, refusing assignment to $expectedPatientId"
    }
    val entity = LocalNoteDraftEntity(
      noteId = resolvedId,
      patientId = expectedPatientId,
      patientName = patientName,
      encounterId = encounterId,
      templateType = templateType.apiKey,
      title = title,
      sectionsJson = json.encodeToString(sections),
      freeText = freeText,
      copiedAttributionsJson = json.encodeToString(copiedAttributions),
      baseVersion = existing?.baseVersion ?: baseVersion,
      status = if (existing?.status == "CONFLICT") "CONFLICT" else "DRAFT",
      dirty = true,
      pendingSync = true,
      conflictMessage = existing?.conflictMessage,
      serverSnapshotJson = existing?.serverSnapshotJson,
      idempotencyKey = existing?.idempotencyKey ?: UUID.randomUUID().toString(),
      updatedAtEpochMs = System.currentTimeMillis(),
    )
    dao.upsertDraft(entity)
    return entity
  }

  suspend fun submitOrQueueNoteDraft(draft: LocalNoteDraftEntity): Result<String> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    val req = SaveNoteDraftRequest(
      noteId = draft.noteId,
      patientId = draft.patientId,
      encounterId = draft.encounterId,
      templateType = draft.templateType,
      title = draft.title,
      sections = json.decodeFromString(draft.sectionsJson),
      freeText = draft.freeText,
      copiedAttributions = json.decodeFromString(draft.copiedAttributionsJson),
      expectedVersion = draft.baseVersion,
      idempotencyKey = draft.idempotencyKey,
    )
    return try {
      val saved = api.saveNoteDraft(current.accessToken, req)
      dao.upsertDraft(
        draft.copy(
          baseVersion = saved.version,
          status = saved.status,
          dirty = false,
          pendingSync = false,
          conflictMessage = null,
          serverSnapshotJson = null,
          idempotencyKey = UUID.randomUUID().toString(),
          updatedAtEpochMs = System.currentTimeMillis(),
        )
      )
      dao.deletePendingOp("OP-${draft.noteId}")
      dao.upsertSyncMetadata(SyncMetadataEntity(lastSuccessfulSyncEpochMs = System.currentTimeMillis(), lastError = null))
      openPatientOverview(draft.patientId)
      loadWorklist()
      Result.success("Draft saved to server (v${saved.version})")
    } catch (e: ClinicalApiException.Conflict) {
      val serverOverview = runCatching { api.getPatientOverview(current.accessToken, draft.patientId) }.getOrNull()
      val serverNote = serverOverview?.previousNotes?.firstOrNull { it.noteId == draft.noteId }
      dao.upsertDraft(
        draft.copy(
          status = "CONFLICT",
          pendingSync = false,
          conflictMessage = e.message,
          serverSnapshotJson = serverNote?.let { json.encodeToString(it) },
        )
      )
      Result.failure(e)
    } catch (e: ClinicalApiException.Offline) {
      dao.upsertPendingOp(
        PendingSyncOpEntity(
          opId = "OP-${draft.noteId}",
          opType = "SAVE_DRAFT",
          targetId = draft.noteId,
          patientId = draft.patientId,
          payloadJson = json.encodeToString(req),
          idempotencyKey = draft.idempotencyKey,
          retryCount = 0,
          state = "PENDING",
          lastError = "Offline — queued for deferred WorkManager sync",
          createdAtEpochMs = System.currentTimeMillis(),
          updatedAtEpochMs = System.currentTimeMillis(),
        )
      )
      syncScheduler.enqueueDeferredSync()
      Result.success("Offline: draft autosaved locally & queued for synchronisation")
    } catch (e: ClinicalApiException.Unauthorized) {
      handleSessionInvalidated(e.message ?: "Session expired")
      Result.failure(e)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun resolveDraftConflict(
    draft: LocalNoteDraftEntity,
    keepLocalChanges: Boolean,
    serverNote: ClinicalNoteDto,
  ): Result<String> {
    return if (keepLocalChanges) {
      val rebased = draft.copy(
        baseVersion = serverNote.version,
        status = "DRAFT",
        conflictMessage = null,
        serverSnapshotJson = null,
        idempotencyKey = UUID.randomUUID().toString(),
      )
      dao.upsertDraft(rebased)
      submitOrQueueNoteDraft(rebased)
    } else {
      val accepted = draft.copy(
        title = serverNote.title,
        sectionsJson = json.encodeToString(serverNote.sections),
        freeText = serverNote.freeText,
        copiedAttributionsJson = json.encodeToString(serverNote.copiedAttributions),
        baseVersion = serverNote.version,
        status = serverNote.status,
        dirty = false,
        pendingSync = false,
        conflictMessage = null,
        serverSnapshotJson = null,
      )
      dao.upsertDraft(accepted)
      dao.deletePendingOp("OP-${draft.noteId}")
      openPatientOverview(draft.patientId)
      Result.success("Accepted server version v${serverNote.version}")
    }
  }

  suspend fun signNote(
    draft: LocalNoteDraftEntity,
    confirmedPatientId: String,
  ): Result<ClinicalNoteDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    if (confirmedPatientId != draft.patientId) {
      return Result.failure(IllegalArgumentException("Patient safety guard: patient confirmation mismatch"))
    }
    if (api.isOfflineSimulated) {
      return Result.failure(ClinicalApiException.Offline("Server validation is required before final signing"))
    }
    return try {
      // Ensure latest local draft edits are persisted cleanly before signing if dirty
      var versionToSign = draft.baseVersion
      if (draft.dirty) {
        val saved = api.saveNoteDraft(
          current.accessToken,
          SaveNoteDraftRequest(
            noteId = draft.noteId,
            patientId = draft.patientId,
            encounterId = draft.encounterId,
            templateType = draft.templateType,
            title = draft.title,
            sections = json.decodeFromString(draft.sectionsJson),
            freeText = draft.freeText,
            copiedAttributions = json.decodeFromString(draft.copiedAttributionsJson),
            expectedVersion = draft.baseVersion,
            idempotencyKey = draft.idempotencyKey,
          ),
        )
        versionToSign = saved.version
      }
      val signed = api.signNote(
        current.accessToken,
        draft.noteId,
        SignNoteRequest(
          confirmedPatientId = confirmedPatientId,
          expectedVersion = versionToSign,
          idempotencyKey = "sign-${draft.noteId}-v$versionToSign",
        ),
      )
      dao.upsertDraft(
        draft.copy(
          baseVersion = signed.version,
          status = "SIGNED",
          dirty = false,
          pendingSync = false,
          conflictMessage = null,
        )
      )
      openPatientOverview(draft.patientId)
      loadWorklist()
      Result.success(signed)
    } catch (e: ClinicalApiException.Unauthorized) {
      handleSessionInvalidated(e.message ?: "Session expired")
      Result.failure(e)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun addAmendment(
    noteId: String,
    confirmedPatientId: String,
    type: String,
    bodyText: String,
    reason: String,
  ): Result<ClinicalNoteDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    return try {
      val updated = api.addAmendment(
        current.accessToken,
        noteId,
        CreateAmendmentRequest(
          confirmedPatientId = confirmedPatientId,
          amendmentType = type,
          bodyText = bodyText,
          reason = reason,
          idempotencyKey = UUID.randomUUID().toString(),
        ),
      )
      openPatientOverview(confirmedPatientId)
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun markEnteredInError(
    noteId: String,
    confirmedPatientId: String,
    reason: String,
  ): Result<ClinicalNoteDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    return try {
      val updated = api.markEnteredInError(
        current.accessToken,
        noteId,
        EnteredInErrorRequest(confirmedPatientId, reason, UUID.randomUUID().toString()),
      )
      openPatientOverview(confirmedPatientId)
      loadWorklist()
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateResultWorkflow(
    resultId: String,
    confirmedPatientId: String,
    targetState: String,
    followUpTaskId: String? = null,
  ): Result<DiagnosticResultDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    return try {
      val updated = api.updateResultWorkflow(
        current.accessToken,
        resultId,
        UpdateResultWorkflowRequest(targetState, confirmedPatientId, followUpTaskId),
      )
      openPatientOverview(confirmedPatientId)
      loadWorklist()
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun reconcileMedication(
    medicationId: String,
    patientId: String,
    action: String,
    note: String?,
  ): Result<MedicationDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    return try {
      val updated = api.reconcileMedication(
        current.accessToken,
        medicationId,
        ReconcileMedicationRequest(action, note),
      )
      openPatientOverview(patientId)
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun createFollowUpTask(req: CreateTaskRequest): Result<FollowUpTaskDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    return try {
      val created = api.createTask(current.accessToken, req.copy(idempotencyKey = UUID.randomUUID().toString()))
      openPatientOverview(req.patientId)
      loadWorklist()
      Result.success(created)
    } catch (e: ClinicalApiException.Offline) {
      val idem = UUID.randomUUID().toString()
      dao.upsertPendingOp(
        PendingSyncOpEntity(
          opId = "OP-TASK-$idem",
          opType = "CREATE_TASK",
          targetId = req.patientId,
          patientId = req.patientId,
          payloadJson = json.encodeToString(req.copy(idempotencyKey = idem)),
          idempotencyKey = idem,
          retryCount = 0,
          state = "PENDING",
          lastError = "Offline — queued for deferred sync",
          createdAtEpochMs = System.currentTimeMillis(),
          updatedAtEpochMs = System.currentTimeMillis(),
        )
      )
      syncScheduler.enqueueDeferredSync()
      Result.failure(e)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun completeFollowUpTask(
    taskId: String,
    confirmedPatientId: String,
    evidence: String,
    expectedVersion: Long,
  ): Result<FollowUpTaskDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    return try {
      val updated = api.completeTask(
        current.accessToken,
        taskId,
        CompleteTaskRequest(confirmedPatientId, evidence, expectedVersion, UUID.randomUUID().toString()),
      )
      openPatientOverview(confirmedPatientId)
      loadWorklist()
      Result.success(updated)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun saveProtectedClinicalPhoto(
    confirmedPatientId: String,
    encounterId: String?,
    title: String,
    sourceUri: Uri,
    consentRecorded: Boolean,
    consentNote: String,
    derivedLabel: String?,
  ): Result<ClinicalDocumentDto> {
    val current = _session.value ?: return Result.failure(IllegalStateException("Not signed in"))
    if (!consentRecorded) {
      return Result.failure(IllegalArgumentException("Patient consent must be recorded before saving a clinical photograph"))
    }
    return try {
      val bytes = context.contentResolver.openInputStream(sourceUri)?.use { it.readBytes() }
        ?: return Result.failure(IllegalStateException("Unable to read selected image"))

      // Save strictly inside app-private protected directory (never public gallery / MediaStore)
      val dir = File(context.filesDir, "clinical_attachments/$confirmedPatientId").apply { mkdirs() }
      val localFile = File(dir, "photo_${System.currentTimeMillis()}_orig.jpg")
      localFile.writeBytes(bytes)

      val doc = api.uploadDocument(
        current.accessToken,
        UploadDocumentRequest(
          confirmedPatientId = confirmedPatientId,
          encounterId = encounterId,
          title = title,
          docType = "CLINICAL_PHOTOGRAPH",
          mimeType = "image/jpeg",
          isClinicalPhoto = true,
          consentRecorded = true,
          consentNote = consentNote,
          derivedLabel = derivedLabel,
          contentBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP),
        ),
      )
      dao.upsertAttachment(
        ProtectedAttachmentEntity(
          localId = doc.documentId,
          patientId = confirmedPatientId,
          encounterId = encounterId,
          title = title,
          localFilePath = localFile.absolutePath,
          mimeType = "image/jpeg",
          isClinicalPhoto = true,
          consentRecorded = true,
          consentNote = consentNote,
          authorName = current.clinician.displayName,
          originalPreserved = true,
          derivedLabel = derivedLabel,
          createdAtEpochMs = System.currentTimeMillis(),
          uploadedDocumentId = doc.documentId,
        )
      )
      openPatientOverview(confirmedPatientId)
      Result.success(doc)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun triggerManualSync(): ClinicalSyncExecutor.SyncOutcome {
    _isSyncing.value = true
    return try {
      val outcome = syncExecutor.flushPendingOperations()
      when (outcome) {
        is ClinicalSyncExecutor.SyncOutcome.AuthExpired -> handleSessionInvalidated(outcome.message)
        is ClinicalSyncExecutor.SyncOutcome.ConflictDetected -> {
          _bannerMessage.value = outcome.message
          _activePatientId.value?.let { openPatientOverview(it) }
        }
        is ClinicalSyncExecutor.SyncOutcome.Success -> {
          if (outcome.syncedCount > 0) {
            _bannerMessage.value = "Synchronised ${outcome.syncedCount} pending clinical item(s)."
          }
          loadWorklist()
          _activePatientId.value?.let { openPatientOverview(it) }
        }
        is ClinicalSyncExecutor.SyncOutcome.DeferredOffline -> _bannerMessage.value = outcome.message
      }
      outcome
    } finally {
      _isSyncing.value = false
    }
  }

  fun simulateServerConcurrentEdit(noteId: String): Boolean {
    return api.demoServerEngine.simulateConcurrentEditOnServer(noteId)
  }

  suspend fun simulateSessionExpiry() {
    val token = _session.value?.accessToken ?: return
    api.demoServerEngine.expireTokenForDemo(token)
    loadWorklist() // Triggers 401 -> clean re-auth state
  }

  suspend fun loadFhirBundle(patientId: String) {
    val current = _session.value ?: return
    _fhirBundleState.value = UiResource.Loading
    try {
      val bundle = api.getFhirBundle(current.accessToken, patientId)
      _fhirBundleState.value = UiResource.Success(bundle)
    } catch (e: Exception) {
      _fhirBundleState.value = UiResource.Error(e.message ?: "Unable to fetch FHIR R4 bundle")
    }
  }

  suspend fun loadAuditLogs(patientId: String? = null) {
    val current = _session.value ?: return
    _auditLogsState.value = UiResource.Loading
    try {
      val resp = api.getAuditLogs(current.accessToken, patientId)
      _auditLogsState.value = UiResource.Success(resp.items)
    } catch (e: ClinicalApiException.Unauthorized) {
      handleSessionInvalidated(e.message ?: "Session expired")
    } catch (e: Exception) {
      _auditLogsState.value = UiResource.Error(e.message ?: "Failed to load audit trail")
    }
  }

  fun generateAssistiveDraft(overview: PatientOverviewDto, templateType: NoteTemplateType): AiDraftSuggestion {
    return AssistiveDraftingEngine.generateSourceLinkedSuggestion(overview, templateType)
  }

  private suspend fun handleSessionInvalidated(message: String) {
    ClinicalLogger.warn("ClinicalRepository", "Session invalidated: $message")
    vault.clearSession()
    _session.value = null
    _hasEncryptedStoredSession.value = false
    _bannerMessage.value = message
  }
}
