package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.core.repository.UiResource
import com.example.ui.components.ClinicalStateCard
import com.example.ui.components.ConfirmPatientActionDialog
import com.example.ui.components.StatusPill
import com.example.ui.theme.*

@Composable
fun PatientOverviewScreen(
  overviewState: UiResource<PatientOverviewDto>,
  fhirBundleState: UiResource<FhirPatientEverythingBundle>?,
  canWrite: Boolean,
  onRetry: () -> Unit,
  onNewNote: (PatientSummaryDto) -> Unit,
  onOpenNote: (ClinicalNoteDto) -> Unit,
  onCopyExcerptToNote: (PatientSummaryDto, String, String, String, String) -> Unit,
  onUpdateResultWorkflow: (resultId: String, patientId: String, targetState: String) -> Unit,
  onReconcileMedication: (medId: String, patientId: String, action: String, note: String?) -> Unit,
  onCreateTaskForPatient: (CreateTaskRequest) -> Unit,
  onCompleteTask: (taskId: String, patientId: String, evidence: String, version: Long) -> Unit,
  onSaveClinicalPhoto: (patientId: String, encounterId: String?, title: String, uri: Uri, consent: Boolean, note: String) -> Unit,
  onLoadFhirBundle: (String) -> Unit,
) {
  var showFhirDialog by remember { mutableStateOf(false) }
  var showNewTaskDialog by remember { mutableStateOf(false) }
  var taskPrefillResultId by remember { mutableStateOf<String?>(null) }
  var pendingPhotoUri by remember { mutableStateOf<Uri?>(null) }
  var photoTitle by remember { mutableStateOf("Clinical Wound / Lesion Photo") }
  var photoConsent by remember { mutableStateOf(false) }
  var photoConsentNote by remember { mutableStateOf("Verbal & written clinical photography consent obtained") }
  var confirmResultAction by remember { mutableStateOf<Pair<DiagnosticResultDto, String>?>(null) }
  var completeTaskTarget by remember { mutableStateOf<FollowUpTaskDto?>(null) }
  var completionEvidence by remember { mutableStateOf("") }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = { uri -> if (uri != null) pendingPhotoUri = uri },
  )

  when (overviewState) {
    is UiResource.Loading -> {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    }
    is UiResource.Error -> {
      Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
        ClinicalStateCard(
          icon = if (overviewState.isPermissionDenied) Icons.Outlined.Lock else Icons.Outlined.ErrorOutline,
          title = if (overviewState.isPermissionDenied) "Permission Denied" else "Unable to Load Patient Record",
          message = overviewState.message,
          actionLabel = if (overviewState.isPermissionDenied) null else "Retry",
          onAction = if (overviewState.isPermissionDenied) null else onRetry,
          isDanger = overviewState.isPermissionDenied,
        )
      }
    }
    is UiResource.Success -> {
      val data = overviewState.data
      val patient = data.patient

      LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("patient_overview_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        if (overviewState.fromCache) {
          item {
            StatusPill(
              text = "OFFLINE CACHE • Read-only cached snapshot until reconnected",
              containerColor = ClinicalWarningContainer,
              contentColor = ClinicalWarning,
              icon = Icons.Outlined.CloudOff,
            )
          }
        }

        // Action Bar
        item {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            if (canWrite) {
              Button(
                onClick = { onNewNote(patient) },
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("new_note_button"),
              ) {
                Icon(Icons.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Note")
              }
              OutlinedButton(
                onClick = {
                  taskPrefillResultId = null
                  showNewTaskDialog = true
                },
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("new_task_button"),
              ) {
                Icon(Icons.Filled.AddTask, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Task")
              }
            }
            OutlinedButton(
              onClick = {
                onLoadFhirBundle(patient.patientId)
                showFhirDialog = true
              },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("view_fhir_button"),
            ) {
              Text("FHIR R4")
            }
          }
        }

        // 1. Allergies & Adverse Reactions (CRITICAL SAFETY RULE: empty list never displays "no known allergies")
        item {
          OverviewSectionCard("1. Allergies & Adverse Reactions", Icons.Outlined.WarningAmber) {
            when (patient.allergyStatusState) {
              "EXPLICIT_NO_KNOWN_ALLERGIES" -> {
                StatusPill("EXPLICITLY DOCUMENTED: No known allergies", ClinicalSuccessContainer, ClinicalSuccess, Icons.Filled.CheckCircle)
              }
              "NOT_ASSESSED" -> {
                StatusPill("NOT ASSESSED — Allergy history has not been recorded", ClinicalWarningContainer, ClinicalWarning, Icons.Outlined.HelpOutline)
              }
              "UNKNOWN" -> {
                StatusPill("UNKNOWN — Patient unable to confirm allergies", ClinicalWarningContainer, ClinicalWarning, Icons.Outlined.HelpOutline)
              }
              "UNAVAILABLE" -> {
                StatusPill("UNAVAILABLE — External allergy source unavailable", ClinicalDangerContainer, ClinicalDanger, Icons.Outlined.CloudOff)
              }
              else -> {
                if (data.allergies.isEmpty()) {
                  StatusPill("UNVERIFIED / NO ITEMS LOADED — Confirm before prescribing", ClinicalWarningContainer, ClinicalWarning)
                } else {
                  data.allergies.forEach { a ->
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(a.substance, style = MaterialTheme.typography.titleSmall)
                        StatusPill("${a.severity} • ${a.verificationStatus}", ClinicalDangerContainer, ClinicalDanger)
                      }
                      Text("Reaction: ${a.reaction}", style = MaterialTheme.typography.bodySmall)
                      Text("Provenance: ${a.provenance} • Recorded by ${a.recordedBy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline)
                  }
                }
              }
            }
          }
        }

        // 2. Active Problems
        item {
          OverviewSectionCard("2. Active Problems (${data.activeProblems.size})", Icons.Outlined.MedicalInformation) {
            if (data.activeProblems.isEmpty()) {
              Text("No active problems recorded.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
              data.activeProblems.forEach { p ->
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    StatusPill(p.clinicalStatus, ClinicalBlueContainer, OnClinicalBlueContainer)
                  }
                  Text("${p.coding} • Onset ${p.onsetDate} • ${p.authorName} (${p.sourceSystem})", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }

        // 3. Relevant History
        item {
          OverviewSectionCard("3. Relevant History (${data.relevantHistory.size})", Icons.Outlined.History) {
            if (data.relevantHistory.isEmpty()) {
              Text("No relevant history recorded.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
              data.relevantHistory.forEach { h ->
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                  Text("${h.category}: ${h.summary}", style = MaterialTheme.typography.bodyMedium)
                  Text("${h.authorName} • ${h.sourceSystem}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }

        // 4. Medications & Reconciliation
        item {
          OverviewSectionCard("4. Medications & Reconciliation (${data.medications.size})", Icons.Outlined.Medication) {
            Text(
              "Simulated prescribing adapter — no automated dosing or interaction advice generated.",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(6.dp))
            if (data.medications.isEmpty()) {
              Text("No medication records in this context.", style = MaterialTheme.typography.bodySmall)
            } else {
              data.medications.forEach { m ->
                Surface(
                  color = if (m.discrepancyFlag) ClinicalWarningContainer else MaterialTheme.colorScheme.surfaceVariant,
                  shape = MaterialTheme.shapes.small,
                  modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                  Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text("${m.name} ${m.strength}", style = MaterialTheme.typography.titleSmall)
                      StatusPill("${m.recordCategory} • ${m.status}", ClinicalBlueContainer, OnClinicalBlueContainer)
                    }
                    Text("${m.dose} • ${m.route} • ${m.frequency} (Start ${m.startDate})", style = MaterialTheme.typography.bodySmall)
                    Text("Source: ${m.sourceSystem} • Author: ${m.authorName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (m.discrepancyFlag && !m.discrepancyNote.isNullOrBlank()) {
                      Text("Discrepancy: ${m.discrepancyNote}", style = MaterialTheme.typography.bodySmall, color = ClinicalWarning)
                    }
                    m.reconciledBy?.let {
                      Text("Reconciled by $it", style = MaterialTheme.typography.labelSmall, color = ClinicalSuccess)
                    }
                    if (canWrite && m.discrepancyFlag) {
                      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                          onClick = { onReconcileMedication(m.medicationId, patient.patientId, "RECONCILE_MATCH", "Reconciled with patient & GP chart") },
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) { Text("Mark Reconciled") }
                      }
                    }
                  }
                }
              }
            }
          }
        }

        // 5. Recent Observations (Missing measurements remain missing, never zero)
        item {
          OverviewSectionCard("5. Recent Observations (${data.recentObservations.size})", Icons.Outlined.MonitorHeart) {
            if (data.recentObservations.isEmpty()) {
              Text("No observations recorded.", style = MaterialTheme.typography.bodySmall)
            } else {
              data.recentObservations.forEach { o ->
                Row(
                  modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(o.name, style = MaterialTheme.typography.titleSmall)
                    Text(
                      "${o.sourceSystem} • ${o.verificationStatus} • Ref ${o.referenceInterval}",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    o.missingReason?.let {
                      Text("Missing: $it", style = MaterialTheme.typography.bodySmall, color = ClinicalWarning)
                    }
                  }
                  if (o.valueNumeric != null) {
                    StatusPill(
                      text = "${o.valueNumeric} ${o.unit} (${o.abnormalFlag})",
                      containerColor = if (o.abnormalFlag == "NORMAL") ClinicalSuccessContainer else ClinicalDangerContainer,
                      contentColor = if (o.abnormalFlag == "NORMAL") ClinicalSuccess else ClinicalDanger,
                    )
                  } else {
                    StatusPill("MISSING", ClinicalNeutralContainer, ClinicalNeutralBadge)
                  }
                }
              }
            }
          }
        }

        // 6. Diagnostic Results
        item {
          OverviewSectionCard("6. Diagnostic Results (${data.diagnosticResults.size})", Icons.Outlined.Biotech) {
            data.diagnosticResults.forEach { r ->
              val isCorrected = r.resultStatus == "CORRECTED"
              Surface(
                color = if (isCorrected) ClinicalWarningContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("overview_result_${r.resultId}"),
              ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${r.testName}: ${r.valueText ?: "N/A"} ${r.unit}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    StatusPill("${r.resultStatus} • ${r.workflowState}", ClinicalBlueContainer, OnClinicalBlueContainer)
                  }
                  Text("Ref ${r.referenceInterval} • Flag ${r.abnormalFlag} • ${r.sourceSystem}", style = MaterialTheme.typography.labelSmall)
                  r.supersedesResultId?.let { prev ->
                    Text("Supersedes earlier result $prev: ${r.correctionReason ?: ""}", style = MaterialTheme.typography.bodySmall, color = ClinicalWarning)
                  }
                  r.reviewedBy?.let {
                    Text("Reviewed by $it", style = MaterialTheme.typography.labelSmall, color = ClinicalSuccess)
                  }
                  if (canWrite && r.workflowState != "ACTION_COMPLETED") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      if (r.workflowState == "AVAILABLE") {
                        TextButton(
                          onClick = { onUpdateResultWorkflow(r.resultId, patient.patientId, "VIEWED") },
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) { Text("Mark Viewed") }
                      }
                      if (r.workflowState in setOf("AVAILABLE", "VIEWED")) {
                        Button(
                          onClick = { confirmResultAction = r to "ACKNOWLEDGED" },
                          modifier = Modifier.minimumInteractiveComponentSize().testTag("ack_result_${r.resultId}"),
                        ) { Text("Acknowledge") }
                      }
                      OutlinedButton(
                        onClick = {
                          taskPrefillResultId = r.resultId
                          showNewTaskDialog = true
                        },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) { Text("Assign Follow-up") }
                    }
                  }
                }
              }
            }
          }
        }

        // 7. Previous Notes
        item {
          OverviewSectionCard("7. Previous & Draft Notes (${data.previousNotes.size})", Icons.Outlined.Description) {
            data.previousNotes.forEach { note ->
              Surface(
                onClick = { onOpenNote(note) },
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("overview_note_${note.noteId}"),
              ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(note.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    StatusPill(
                      text = "${note.status} v${note.version}",
                      containerColor = when (note.status) {
                        "SIGNED" -> ClinicalTealContainer
                        "ENTERED_IN_ERROR" -> ClinicalDangerContainer
                        else -> ClinicalWarningContainer
                      },
                      contentColor = when (note.status) {
                        "SIGNED" -> OnClinicalTealContainer
                        "ENTERED_IN_ERROR" -> ClinicalDanger
                        else -> ClinicalWarning
                      },
                    )
                  }
                  Text("${note.templateType} • ${note.authorName} • ${note.amendments.size} amendment(s)", style = MaterialTheme.typography.labelSmall)
                  if (canWrite && note.status == "SIGNED") {
                    TextButton(
                      onClick = {
                        val excerpt = note.sections.firstOrNull()?.content ?: note.freeText
                        onCopyExcerptToNote(patient, note.title, note.authorName, note.signedAt ?: note.updatedAt, excerpt)
                      },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Text("Copy excerpt with attribution to new note")
                    }
                  }
                }
              }
            }
          }
        }

        // 8. Care Plans
        item {
          OverviewSectionCard("8. Care Plans (${data.carePlans.size})", Icons.Outlined.FactCheck) {
            if (data.carePlans.isEmpty()) {
              Text("No active care plans.", style = MaterialTheme.typography.bodySmall)
            } else {
              data.carePlans.forEach { cp ->
                Text("${cp.title} (${cp.status})", style = MaterialTheme.typography.titleSmall)
                Text(cp.goalsSummary, style = MaterialTheme.typography.bodySmall)
                Text("Owner: ${cp.ownerName} • ${cp.sourceSystem}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }

        // 9. Documents & Protected Clinical Photographs
        item {
          OverviewSectionCard("9. Documents & Clinical Photos (${data.documents.size})", Icons.Outlined.FolderShared) {
            if (canWrite) {
              OutlinedButton(
                onClick = {
                  photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("attach_clinical_photo_button"),
              ) {
                Icon(Icons.Outlined.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Attach Clinical Photo (Protected App Storage)")
              }
              Spacer(modifier = Modifier.height(6.dp))
            }
            data.documents.forEach { d ->
              Column(modifier = Modifier.padding(vertical = 4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                  Text(d.title, style = MaterialTheme.typography.titleSmall)
                  if (d.isClinicalPhoto) {
                    StatusPill(
                      text = if (d.consentRecorded) "CONSENT RECORDED" else "NO CONSENT",
                      containerColor = if (d.consentRecorded) ClinicalSuccessContainer else ClinicalDangerContainer,
                      contentColor = if (d.consentRecorded) ClinicalSuccess else ClinicalDanger,
                    )
                  }
                }
                Text(
                  "${d.docType} • Author: ${d.authorName} • Original preserved: ${d.originalPreserved}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }

        // 10. Outstanding Tasks
        item {
          OverviewSectionCard("10. Follow-up Tasks (${data.outstandingTasks.size})", Icons.Outlined.TaskAlt) {
            if (data.outstandingTasks.isEmpty()) {
              Text("No follow-up tasks for this patient.", style = MaterialTheme.typography.bodySmall)
            } else {
              data.outstandingTasks.forEach { t ->
                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  shape = MaterialTheme.shapes.small,
                  modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                  Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                      Text(t.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                      StatusPill(t.status, if (t.status == "COMPLETED") ClinicalSuccessContainer else ClinicalWarningContainer, if (t.status == "COMPLETED") ClinicalSuccess else ClinicalWarning)
                    }
                    Text("${t.priority} • Owner: ${t.ownerName} • Due: ${t.dueAt.take(16)}", style = MaterialTheme.typography.labelSmall)
                    t.completionEvidence?.let {
                      Text("Completion evidence: $it", style = MaterialTheme.typography.bodySmall, color = ClinicalSuccess)
                    }
                    if (canWrite && t.status != "COMPLETED") {
                      TextButton(
                        onClick = {
                          completeTaskTarget = t
                          completionEvidence = ""
                        },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) { Text("Complete with Evidence") }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Confirmation Dialog for Result Acknowledgment
      confirmResultAction?.let { (res, targetState) ->
        ConfirmPatientActionDialog(
          title = "Confirm Result Acknowledgment",
          actionDescription = "Acknowledge ${res.testName} (${res.valueText ?: "N/A"} ${res.unit}, status ${res.resultStatus}) for this patient?",
          patient = patient,
          confirmLabel = "Confirm & Acknowledge",
          onConfirm = {
            onUpdateResultWorkflow(res.resultId, patient.patientId, targetState)
            confirmResultAction = null
          },
          onDismiss = { confirmResultAction = null },
        )
      }

      // Photo Consent & Protected Storage Dialog
      pendingPhotoUri?.let { uri ->
        AlertDialog(
          onDismissRequest = { pendingPhotoUri = null },
          title = { Text("Clinical Photograph Consent & Storage") },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                "Confirm patient identity (${patient.fullName}, ${patient.patientId}). Photograph will be saved in app-private protected storage only (never personal gallery) with original preserved.",
                style = MaterialTheme.typography.bodySmall,
              )
              OutlinedTextField(value = photoTitle, onValueChange = { photoTitle = it }, label = { Text("Image title") }, modifier = Modifier.fillMaxWidth())
              Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = photoConsent, onCheckedChange = { photoConsent = it })
                Text("Explicit patient consent obtained", style = MaterialTheme.typography.bodySmall)
              }
              OutlinedTextField(value = photoConsentNote, onValueChange = { photoConsentNote = it }, label = { Text("Consent note") }, modifier = Modifier.fillMaxWidth())
            }
          },
          confirmButton = {
            Button(
              onClick = {
                onSaveClinicalPhoto(patient.patientId, patient.currentEncounterId, photoTitle, uri, photoConsent, photoConsentNote)
                pendingPhotoUri = null
              },
              enabled = photoConsent && photoTitle.isNotBlank(),
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) { Text("Save Protected Photo") }
          },
          dismissButton = {
            TextButton(onClick = { pendingPhotoUri = null }) { Text("Cancel") }
          },
        )
      }

      // Create Follow-up Task Dialog
      if (showNewTaskDialog) {
        var taskTitle by remember { mutableStateOf(if (taskPrefillResultId != null) "Review & act on result $taskPrefillResultId" else "") }
        var taskDesc by remember { mutableStateOf("") }
        var taskOwner by remember { mutableStateOf("Dr Sarah Jenkins") }
        var taskPriority by remember { mutableStateOf("URGENT") }

        AlertDialog(
          onDismissRequest = { showNewTaskDialog = false },
          title = { Text("Assign Follow-up Task — ${patient.fullName}") },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(value = taskTitle, onValueChange = { taskTitle = it }, label = { Text("Task title") }, modifier = Modifier.fillMaxWidth().testTag("task_title_input"))
              OutlinedTextField(value = taskDesc, onValueChange = { taskDesc = it }, label = { Text("Clinical instructions") }, modifier = Modifier.fillMaxWidth())
              OutlinedTextField(value = taskOwner, onValueChange = { taskOwner = it }, label = { Text("Owner") }, modifier = Modifier.fillMaxWidth())
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ROUTINE", "URGENT", "STAT").forEach { p ->
                  FilterChip(selected = taskPriority == p, onClick = { taskPriority = p }, label = { Text(p) })
                }
              }
            }
          },
          confirmButton = {
            Button(
              onClick = {
                onCreateTaskForPatient(
                  CreateTaskRequest(
                    patientId = patient.patientId,
                    encounterId = patient.currentEncounterId,
                    linkedResultId = taskPrefillResultId,
                    title = taskTitle,
                    description = taskDesc.ifBlank { taskTitle },
                    ownerName = taskOwner,
                    priority = taskPriority,
                    dueAt = java.time.Instant.now().plusSeconds(7200).toString(),
                  )
                )
                showNewTaskDialog = false
              },
              enabled = taskTitle.isNotBlank(),
              modifier = Modifier.minimumInteractiveComponentSize().testTag("confirm_create_task_button"),
            ) { Text("Create Task") }
          },
          dismissButton = {
            TextButton(onClick = { showNewTaskDialog = false }) { Text("Cancel") }
          },
        )
      }

      // Complete Task with Evidence Dialog
      completeTaskTarget?.let { target ->
        AlertDialog(
          onDismissRequest = { completeTaskTarget = null },
          title = { Text("Complete Follow-up Task") },
          text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("${target.title} (${patient.fullName})", style = MaterialTheme.typography.bodySmall)
              OutlinedTextField(
                value = completionEvidence,
                onValueChange = { completionEvidence = it },
                label = { Text("Completion evidence (min 4 chars)") },
                modifier = Modifier.fillMaxWidth(),
              )
            }
          },
          confirmButton = {
            Button(
              onClick = {
                onCompleteTask(target.taskId, patient.patientId, completionEvidence, target.version)
                completeTaskTarget = null
              },
              enabled = completionEvidence.trim().length >= 4,
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) { Text("Complete Task") }
          },
          dismissButton = {
            TextButton(onClick = { completeTaskTarget = null }) { Text("Cancel") }
          },
        )
      }

      // FHIR R4 Adapter Bundle Dialog
      if (showFhirDialog) {
        AlertDialog(
          onDismissRequest = { showFhirDialog = false },
          title = { Text("Mock FHIR R4 \$everything Bundle") },
          text = {
            when (fhirBundleState) {
              is UiResource.Success -> {
                val b = fhirBundleState.data
                Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.heightIn(max = 360.dp)) {
                  Text(b.disclaimer, style = MaterialTheme.typography.labelSmall, color = ClinicalWarning)
                  Text("Total resources: ${b.total} • Version: ${b.fhirVersion}", style = MaterialTheme.typography.labelMedium)
                  b.entries.take(8).forEach { e ->
                    Text("• [${e.resourceType}/${e.id}] ${e.summary} (${e.sourceSystem})", style = MaterialTheme.typography.bodySmall)
                  }
                }
              }
              is UiResource.Error -> Text(fhirBundleState.message, color = ClinicalDanger)
              else -> CircularProgressIndicator()
            }
          },
          confirmButton = {
            TextButton(onClick = { showFhirDialog = false }) { Text("Close") }
          },
        )
      }
    }
  }
}

@Composable
private fun OverviewSectionCard(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  content: @Composable ColumnScope.() -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      SectionHeader(title, icon)
      content()
    }
  }
}
