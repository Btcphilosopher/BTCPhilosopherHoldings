package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.*
import com.example.core.repository.UiResource
import com.example.ui.components.ClinicalStateCard
import com.example.ui.components.StatusPill
import com.example.ui.components.SyncStatusStrip
import com.example.ui.theme.*

@Composable
fun TodayWorklistScreen(
  clinician: ClinicianProfile,
  worklistState: UiResource<WorklistResponseDto>,
  syncStatus: SyncStatusSummary,
  onSyncNow: () -> Unit,
  onToggleOffline: (Boolean) -> Unit,
  onRefresh: () -> Unit,
  onOpenPatient: (String) -> Unit,
  onOpenNote: (ClinicalNoteDto) -> Unit,
  onOpenResultsTab: () -> Unit,
  onOpenTasksTab: () -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("today_worklist_list"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("Today's Clinical Worklist", style = MaterialTheme.typography.headlineSmall)
          Text(
            "${clinician.displayName} (${clinician.role}) • ${clinician.activeCareContextName}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text("Offline", style = MaterialTheme.typography.labelMedium)
          Spacer(modifier = Modifier.width(4.dp))
          Switch(
            checked = syncStatus.isOfflineSimulated,
            onCheckedChange = onToggleOffline,
            modifier = Modifier.testTag("offline_mode_switch"),
          )
        }
      }
    }

    item {
      SyncStatusStrip(syncStatus = syncStatus, onSyncNow = onSyncNow)
    }

    when (worklistState) {
      is UiResource.Loading -> {
        item {
          Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
          }
        }
      }
      is UiResource.Error -> {
        item {
          ClinicalStateCard(
            icon = if (worklistState.code == "OFFLINE") Icons.Outlined.CloudOff else Icons.Outlined.ErrorOutline,
            title = if (worklistState.code == "OFFLINE") "Working Offline" else "Unable to Load Worklist",
            message = worklistState.message,
            actionLabel = "Retry",
            onAction = onRefresh,
          )
        }
      }
      is UiResource.Success -> {
        val data = worklistState.data

        // Summary KPI Row
        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WorklistCountBadge("Appointments", data.todaysAppointments.size, ClinicalBlue, Modifier.weight(1f))
            WorklistCountBadge("Unsigned", data.unsignedNotes.size, ClinicalWarning, Modifier.weight(1f))
            WorklistCountBadge("Results", data.resultsRequiringReview.size, ClinicalDanger, Modifier.weight(1f))
            WorklistCountBadge("Tasks", data.outstandingTasks.size, ClinicalTeal, Modifier.weight(1f))
          }
        }

        // Today's Appointments
        item { SectionHeader("Today's Appointments", Icons.Outlined.CalendarToday) }
        if (data.todaysAppointments.isEmpty()) {
          item { EmptySectionNote("No scheduled clinic or ward appointments in this care context.") }
        } else {
          items(data.todaysAppointments, key = { it.appointmentId }) { appt ->
            Card(
              onClick = { onOpenPatient(appt.patientId) },
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
              modifier = Modifier.fillMaxWidth().testTag("appointment_card_${appt.patientId}"),
            ) {
              Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(appt.patientName, style = MaterialTheme.typography.titleMedium)
                    StatusPill(appt.status.replace("_", " "), ClinicalBlueContainer, OnClinicalBlueContainer)
                  }
                  Text("DOB ${appt.patientDob} • NHS ${appt.nhsNumber} • ${appt.clinicRoom}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(appt.reason, style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Filled.ChevronRight, contentDescription = "Open patient record")
              }
            }
          }
        }

        // Results Requiring Review
        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SectionHeader("Results Requiring Review", Icons.Outlined.Science)
            TextButton(onClick = onOpenResultsTab, modifier = Modifier.minimumInteractiveComponentSize()) { Text("View all") }
          }
        }
        items(data.resultsRequiringReview, key = { it.resultId }) { res ->
          val isCorrected = res.resultStatus == "CORRECTED"
          Card(
            onClick = { onOpenPatient(res.patientId) },
            colors = CardDefaults.cardColors(containerColor = if (isCorrected) ClinicalWarningContainer else MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, if (isCorrected) ClinicalWarning else MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("worklist_result_${res.resultId}"),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${res.testName}: ${res.valueText ?: "N/A"} ${res.unit}", style = MaterialTheme.typography.titleSmall)
                StatusPill(
                  text = "${res.resultStatus} • ${res.workflowState}",
                  containerColor = if (isCorrected) ClinicalDangerContainer else ClinicalBlueContainer,
                  contentColor = if (isCorrected) ClinicalDanger else OnClinicalBlueContainer,
                )
              }
              Text("${res.patientName} • Ref ${res.referenceInterval} (${res.abnormalFlag})", style = MaterialTheme.typography.bodySmall)
              res.correctionReason?.let {
                Text("Correction: $it", style = MaterialTheme.typography.bodySmall, color = ClinicalWarning)
              }
            }
          }
        }

        // Unsigned Notes
        item { SectionHeader("Unsigned Notes", Icons.Outlined.EditNote) }
        if (data.unsignedNotes.isEmpty()) {
          item { EmptySectionNote("All clinical notes in this context are signed.") }
        } else {
          items(data.unsignedNotes, key = { it.noteId }) { note ->
            Card(
              onClick = { onOpenNote(note) },
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
              modifier = Modifier.fillMaxWidth().testTag("unsigned_note_${note.noteId}"),
            ) {
              Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(note.title, style = MaterialTheme.typography.titleSmall)
                  Text("${note.patientName} • ${note.templateType} • v${note.version} • ${note.authorName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatusPill("DRAFT", ClinicalWarningContainer, ClinicalWarning)
              }
            }
          }
        }

        // Outstanding Follow-up
        item {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SectionHeader("Outstanding Follow-up", Icons.Outlined.TaskAlt)
            TextButton(onClick = onOpenTasksTab, modifier = Modifier.minimumInteractiveComponentSize()) { Text("Manage tasks") }
          }
        }
        items(data.outstandingTasks, key = { it.taskId }) { t ->
          Card(
            onClick = { onOpenPatient(t.patientId) },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(t.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                StatusPill(t.priority, if (t.priority == "URGENT") ClinicalDangerContainer else ClinicalNeutralContainer, if (t.priority == "URGENT") ClinicalDanger else ClinicalNeutralBadge)
              }
              Text("${t.patientName} • Owner: ${t.ownerName} • Status: ${t.status}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }

        // Assigned Patients & Recent Encounters
        item { SectionHeader("Assigned Patients (${data.assignedPatients.size})", Icons.Outlined.People) }
        items(data.assignedPatients, key = { it.patientId }) { p ->
          Card(
            onClick = { onOpenPatient(p.patientId) },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth().testTag("assigned_patient_${p.patientId}"),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(p.fullName, style = MaterialTheme.typography.titleSmall)
                Text("NHS ${p.nhsNumber}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Text(p.currentEncounterLabel ?: "No active encounter", style = MaterialTheme.typography.bodySmall)
              Text(p.allergyBadgeSummary, style = MaterialTheme.typography.labelSmall, color = ClinicalTeal)
            }
          }
        }

        item { SectionHeader("Recent Encounters", Icons.Outlined.History) }
        items(data.recentEncounters, key = { it.encounterId }) { enc ->
          Card(
            onClick = { onOpenPatient(enc.patientId) },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text("${enc.encounterType} • ${enc.location} (${enc.status})", style = MaterialTheme.typography.titleSmall)
              Text("${enc.patientId} • ${enc.reasonForVisit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun WorklistCountBadge(label: String, count: Int, accent: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier,
    color = MaterialTheme.colorScheme.surface,
    shape = MaterialTheme.shapes.medium,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Text(count.toString(), style = MaterialTheme.typography.titleLarge, color = accent)
      Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
  }
}

@Composable
private fun EmptySectionNote(text: String) {
  Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp))
}
