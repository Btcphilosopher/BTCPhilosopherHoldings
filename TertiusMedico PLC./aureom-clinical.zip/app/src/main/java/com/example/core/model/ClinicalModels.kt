package com.example.core.model

import kotlinx.serialization.Serializable

@Serializable
data class ApiError(
  val code: String,
  val message: String,
  val details: Map<String, String> = emptyMap(),
  val timestamp: String,
)

@Serializable
data class PaginatedResponse<T>(
  val items: List<T>,
  val page: Int,
  val pageSize: Int,
  val totalCount: Int,
  val hasMore: Boolean,
)

@Serializable
data class OidcTokenRequest(
  val grantType: String = "authorization_code",
  val username: String,
  val password: String = "demo-clinician-pass",
  val careContextId: String,
  val codeVerifier: String = "pkce-demo-verifier",
)

@Serializable
data class CareContextDto(
  val contextId: String,
  val name: String,
  val wardOrClinic: String,
  val facilityName: String,
  val accessLevel: String,
)

@Serializable
data class ClinicianProfile(
  val clinicianId: String,
  val username: String,
  val displayName: String,
  val role: String,
  val specialty: String,
  val activeCareContextId: String,
  val activeCareContextName: String,
  val permittedCareContexts: List<CareContextDto>,
)

@Serializable
data class AuthSessionResponse(
  val sessionId: String,
  val accessToken: String,
  val refreshToken: String,
  val expiresAt: String,
  val clinician: ClinicianProfile,
  val prototypeBanner: String,
)

@Serializable
data class EmergencyAccessRequest(
  val reason: String,
)

@Serializable
data class EmergencyAccessGrantDto(
  val grantId: String,
  val patientId: String,
  val clinicianId: String,
  val reason: String,
  val grantedAt: String,
  val expiresAt: String,
  val reviewStatus: String,
)

@Serializable
data class PatientSummaryDto(
  val patientId: String,
  val nhsNumber: String,
  val externalMrn: String,
  val identityVerificationStatus: String,
  val matchConfidence: String,
  val fullName: String,
  val preferredName: String? = null,
  val dateOfBirth: String,
  val sexAtBirth: String,
  val careContextId: String,
  val assignedClinicianId: String? = null,
  val currentEncounterId: String? = null,
  val currentEncounterLabel: String? = null,
  val careTeamSummary: String,
  val allergyStatusState: String,
  val allergyBadgeSummary: String,
  val hasAccessInCurrentContext: Boolean = true,
  val emergencyAccessActive: Boolean = false,
  val updatedAt: String,
)

@Serializable
data class EncounterDto(
  val encounterId: String,
  val patientId: String,
  val careContextId: String,
  val clinicianId: String,
  val encounterType: String,
  val status: String,
  val location: String,
  val reasonForVisit: String,
  val startedAt: String,
)

@Serializable
data class AppointmentDto(
  val appointmentId: String,
  val patientId: String,
  val patientName: String,
  val patientDob: String,
  val nhsNumber: String,
  val encounterId: String,
  val clinicianId: String,
  val careContextId: String,
  val scheduledAt: String,
  val durationMinutes: Int,
  val clinicRoom: String,
  val status: String,
  val reason: String,
)

@Serializable
data class ProblemDto(
  val problemId: String,
  val patientId: String,
  val title: String,
  val coding: String,
  val clinicalStatus: String,
  val onsetDate: String,
  val authorName: String,
  val recordedAt: String,
  val sourceSystem: String,
)

@Serializable
data class ClinicalHistoryDto(
  val historyId: String,
  val patientId: String,
  val category: String,
  val summary: String,
  val authorName: String,
  val recordedAt: String,
  val sourceSystem: String,
)

@Serializable
data class MedicationDto(
  val medicationId: String,
  val patientId: String,
  val name: String,
  val strength: String,
  val dose: String,
  val route: String,
  val frequency: String,
  val recordCategory: String,
  val status: String,
  val startDate: String,
  val endDate: String? = null,
  val sourceSystem: String,
  val authorName: String,
  val discrepancyFlag: Boolean = false,
  val discrepancyNote: String? = null,
  val reconciledBy: String? = null,
  val reconciledAt: String? = null,
)

@Serializable
data class ReconcileMedicationRequest(
  val action: String,
  val discrepancyNote: String? = null,
)

@Serializable
data class AllergyDto(
  val allergyId: String,
  val patientId: String,
  val substance: String,
  val reaction: String,
  val verificationStatus: String,
  val severity: String,
  val provenance: String,
  val recordedBy: String,
  val recordedAt: String,
)

@Serializable
data class ObservationDto(
  val observationId: String,
  val patientId: String,
  val encounterId: String,
  val name: String,
  val valueNumeric: Double? = null,
  val unit: String,
  val referenceInterval: String,
  val abnormalFlag: String,
  val missingReason: String? = null,
  val observedAt: String,
  val sourceSystem: String,
  val verificationStatus: String,
)

@Serializable
data class DiagnosticResultDto(
  val resultId: String,
  val patientId: String,
  val patientName: String = "",
  val encounterId: String,
  val testName: String,
  val category: String,
  val valueText: String? = null,
  val unit: String,
  val referenceInterval: String,
  val abnormalFlag: String,
  val resultStatus: String,
  val workflowState: String,
  val supersedesResultId: String? = null,
  val correctionReason: String? = null,
  val reportedAt: String,
  val sourceSystem: String,
  val verificationStatus: String,
  val reviewedBy: String? = null,
  val reviewedAt: String? = null,
  val followUpTaskId: String? = null,
)

@Serializable
data class UpdateResultWorkflowRequest(
  val targetState: String,
  val confirmedPatientId: String,
  val followUpTaskId: String? = null,
)

@Serializable
data class NoteSectionDto(
  val key: String,
  val label: String,
  val content: String,
)

@Serializable
data class CopiedAttributionDto(
  val attributionId: String,
  val sourceLabel: String,
  val sourceAuthor: String,
  val sourceTimestamp: String,
  val excerpt: String,
)

@Serializable
data class NoteAmendmentDto(
  val amendmentId: String,
  val noteId: String,
  val patientId: String,
  val amendmentType: String,
  val bodyText: String,
  val reason: String,
  val authorId: String,
  val authorName: String,
  val createdAt: String,
  val contentHash: String,
)

@Serializable
data class ClinicalNoteDto(
  val noteId: String,
  val patientId: String,
  val patientName: String = "",
  val encounterId: String,
  val templateType: String,
  val title: String,
  val sections: List<NoteSectionDto>,
  val freeText: String,
  val copiedAttributions: List<CopiedAttributionDto> = emptyList(),
  val status: String,
  val version: Long,
  val authorId: String,
  val authorName: String,
  val createdAt: String,
  val updatedAt: String,
  val signedAt: String? = null,
  val signedById: String? = null,
  val signedByName: String? = null,
  val contentHash: String? = null,
  val enteredInErrorReason: String? = null,
  val enteredInErrorBy: String? = null,
  val enteredInErrorAt: String? = null,
  val amendments: List<NoteAmendmentDto> = emptyList(),
)

@Serializable
data class SaveNoteDraftRequest(
  val noteId: String? = null,
  val patientId: String,
  val encounterId: String,
  val templateType: String,
  val title: String,
  val sections: List<NoteSectionDto>,
  val freeText: String,
  val copiedAttributions: List<CopiedAttributionDto> = emptyList(),
  val expectedVersion: Long,
  val idempotencyKey: String? = null,
)

@Serializable
data class SignNoteRequest(
  val confirmedPatientId: String,
  val expectedVersion: Long,
  val idempotencyKey: String,
)

@Serializable
data class CreateAmendmentRequest(
  val confirmedPatientId: String,
  val amendmentType: String,
  val bodyText: String,
  val reason: String,
  val idempotencyKey: String,
)

@Serializable
data class EnteredInErrorRequest(
  val confirmedPatientId: String,
  val reason: String,
  val idempotencyKey: String,
)

@Serializable
data class CarePlanDto(
  val planId: String,
  val patientId: String,
  val title: String,
  val goalsSummary: String,
  val status: String,
  val ownerName: String,
  val updatedAt: String,
  val sourceSystem: String,
)

@Serializable
data class FollowUpTaskDto(
  val taskId: String,
  val patientId: String,
  val patientName: String = "",
  val encounterId: String? = null,
  val linkedResultId: String? = null,
  val title: String,
  val description: String,
  val ownerId: String,
  val ownerName: String,
  val priority: String,
  val dueAt: String,
  val status: String,
  val completionEvidence: String? = null,
  val completedAt: String? = null,
  val completedBy: String? = null,
  val createdBy: String,
  val createdAt: String,
  val version: Long,
)

@Serializable
data class CreateTaskRequest(
  val patientId: String,
  val encounterId: String? = null,
  val linkedResultId: String? = null,
  val title: String,
  val description: String,
  val ownerName: String,
  val priority: String,
  val dueAt: String,
  val idempotencyKey: String? = null,
)

@Serializable
data class CompleteTaskRequest(
  val confirmedPatientId: String,
  val completionEvidence: String,
  val expectedVersion: Long,
  val idempotencyKey: String,
)

@Serializable
data class ClinicalDocumentDto(
  val documentId: String,
  val patientId: String,
  val encounterId: String? = null,
  val title: String,
  val docType: String,
  val mimeType: String,
  val objectKey: String,
  val isClinicalPhoto: Boolean,
  val consentRecorded: Boolean,
  val consentNote: String? = null,
  val authorName: String,
  val originalPreserved: Boolean,
  val derivedLabel: String? = null,
  val createdAt: String,
  val sourceSystem: String,
)

@Serializable
data class UploadDocumentRequest(
  val confirmedPatientId: String,
  val encounterId: String? = null,
  val title: String,
  val docType: String,
  val mimeType: String,
  val isClinicalPhoto: Boolean,
  val consentRecorded: Boolean,
  val consentNote: String? = null,
  val derivedLabel: String? = null,
  val contentBase64: String,
)

@Serializable
data class PatientOverviewDto(
  val patient: PatientSummaryDto,
  val activeProblems: List<ProblemDto>,
  val relevantHistory: List<ClinicalHistoryDto>,
  val medications: List<MedicationDto>,
  val allergies: List<AllergyDto>,
  val recentObservations: List<ObservationDto>,
  val diagnosticResults: List<DiagnosticResultDto>,
  val previousNotes: List<ClinicalNoteDto>,
  val carePlans: List<CarePlanDto>,
  val documents: List<ClinicalDocumentDto>,
  val outstandingTasks: List<FollowUpTaskDto>,
  val serverTimestamp: String,
)

@Serializable
data class WorklistResponseDto(
  val careContext: CareContextDto,
  val todaysAppointments: List<AppointmentDto>,
  val assignedPatients: List<PatientSummaryDto>,
  val recentEncounters: List<EncounterDto>,
  val unsignedNotes: List<ClinicalNoteDto>,
  val resultsRequiringReview: List<DiagnosticResultDto>,
  val outstandingTasks: List<FollowUpTaskDto>,
  val serverTimestamp: String,
)

@Serializable
data class AuditLogDto(
  val auditId: String,
  val timestamp: String,
  val actorId: String,
  val actorName: String,
  val actorRole: String,
  val action: String,
  val resourceType: String,
  val resourceId: String,
  val patientId: String? = null,
  val careContextId: String? = null,
  val outcome: String,
  val reason: String? = null,
  val emergencyAccess: Boolean,
  val metadataJson: String,
)

@Serializable
data class FhirBundleEntry(
  val fullUrl: String,
  val resourceType: String,
  val id: String,
  val status: String,
  val summary: String,
  val sourceSystem: String,
  val recordedAt: String? = null,
)

@Serializable
data class FhirPatientEverythingBundle(
  val resourceType: String = "Bundle",
  val type: String = "collection",
  val fhirVersion: String = "4.0.1-synthetic-adapter",
  val disclaimer: String,
  val total: Int,
  val entries: List<FhirBundleEntry>,
)

data class NoteConflictState(
  val noteId: String,
  val patientId: String,
  val localTitle: String,
  val localSections: List<NoteSectionDto>,
  val localFreeText: String,
  val localExpectedVersion: Long,
  val serverNote: ClinicalNoteDto,
  val message: String,
)

data class SyncStatusSummary(
  val isOfflineSimulated: Boolean = false,
  val isSyncing: Boolean = false,
  val lastSuccessfulSyncEpochMs: Long? = null,
  val oldestCachedRecordEpochMs: Long? = null,
  val pendingUploadCount: Int = 0,
  val conflictCount: Int = 0,
  val failedOperationCount: Int = 0,
  val lastErrorMessage: String? = null,
  val workManagerStateLabel: String = "Idle (constrained on unmetered/connected network)",
)

data class AiDraftSuggestion(
  val summaryBullets: List<String>,
  val suggestedSections: List<NoteSectionDto>,
  val uncertaintiesAndContradictions: List<String>,
  val citedRecordIds: List<String>,
  val disclaimer: String = "Assistive draft generated solely from authorised patient records. Requires clinician verification before saving.",
)

enum class NoteTemplateType(val apiKey: String, val displayLabel: String, val defaultSections: List<Pair<String, String>>) {
  CONSULTATION("CONSULTATION", "Consultation", listOf("presenting" to "Presenting Complaint", "assessment" to "Clinical Assessment", "plan" to "Shared Management Plan")),
  WARD_ROUND("WARD_ROUND", "Ward Round", listOf("progress" to "Interval Progress", "obs_results" to "Observations & Results Review", "plan" to "Management Plan")),
  ADMISSION("ADMISSION", "Admission", listOf("history" to "Presenting Complaint & History", "examination" to "Examination", "impression" to "Impression & Plan")),
  PROGRESS("PROGRESS", "Progress", listOf("update" to "Clinical Update", "plan" to "Ongoing Plan")),
  DISCHARGE("DISCHARGE", "Discharge", listOf("summary" to "Inpatient Summary", "meds_changes" to "Medication Changes", "gp_actions" to "GP & Outpatient Follow-up")),
  HANDOVER("HANDOVER", "Handover", listOf("situation" to "Situation & Background", "actions" to "Outstanding Actions & Escalation")),
}

enum class ConnectionMode {
  EMBEDDED_DEMO_SERVER,
  LIVE_HTTP_SERVER,
}
