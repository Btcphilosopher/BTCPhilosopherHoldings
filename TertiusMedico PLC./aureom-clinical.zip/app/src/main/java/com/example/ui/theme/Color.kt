package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NHS-Inspired Clinical Palette — Blue navigation, White workspaces, Restrained Teal accents
val ClinicalBlue = Color(0xFF005EB8)
val ClinicalBlueDark = Color(0xFF003087)
val ClinicalBlueContainer = Color(0xFFE6F0FA)
val OnClinicalBlueContainer = Color(0xFF002652)

val ClinicalTeal = Color(0xFF007A73)
val ClinicalTealAccent = Color(0xFF00A499)
val ClinicalTealContainer = Color(0xFFE0F4F2)
val OnClinicalTealContainer = Color(0xFF003835)

val ClinicalCanvas = Color(0xFFF4F7FA)
val ClinicalSurface = Color(0xFFFFFFFF)
val ClinicalSurfaceVariant = Color(0xFFEBF0F5)
val ClinicalOutline = Color(0xFFD0DCE8)
val ClinicalInk = Color(0xFF102A43)
val ClinicalInkSecondary = Color(0xFF486581)

// Semantic clinical status tokens (WCAG AA+ contrast)
val ClinicalDanger = Color(0xFFB31B1B)
val ClinicalDangerContainer = Color(0xFFFDECEC)
val ClinicalWarning = Color(0xFF8A4B00)
val ClinicalWarningContainer = Color(0xFFFFF4E0)
val ClinicalSuccess = Color(0xFF006B3C)
val ClinicalSuccessContainer = Color(0xFFE6F4ED)
val ClinicalNeutralBadge = Color(0xFF334E68)
val ClinicalNeutralContainer = Color(0xFFE8EEF5)

// Dark high-contrast support
val ClinicalDarkCanvas = Color(0xFF0B1622)
val ClinicalDarkSurface = Color(0xFF132232)
val ClinicalDarkSurfaceVariant = Color(0xFF1D3247)
val ClinicalDarkBlue = Color(0xFF66B2FF)
val ClinicalDarkTeal = Color(0xFF4FD1C5)
