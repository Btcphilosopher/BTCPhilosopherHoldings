# AUREOM CLINICAL — Typed REST & Interoperability API Contracts

Base URL (Docker Compose): `http://10.0.2.2:8080` (Emulator) / `http://localhost:8080` (Host).
All endpoints except `/health`, `/.well-known/openid-configuration`, and `/auth/oidc/token` require `Authorization: Bearer <accessToken>`.

## Error Contract (`ApiError`)
```json
{
  "code": "VERSION_CONFLICT",
  "message": "Optimistic concurrency conflict: server version is 2, client sent 1.",
  "details": {},
  "timestamp": "2026-11-23T14:00:00Z"
}
```

## Endpoints

| Method | Path | Purpose | Key Guarantees |
|---|---|---|---|
| `GET` | `/.well-known/openid-configuration` | Local OIDC discovery document | Prototype disclosure |
| `POST` | `/auth/oidc/token` | OIDC token exchange | Validates clinician + permitted care context |
| `POST` | `/auth/logout` | Revoke active session | Immediate `401` on subsequent calls + audit |
| `GET` | `/auth/session` | Inspect session validity & expiry | Enforces server expiry |
| `GET` | `/api/v1/worklist` | Appointments, assigned patients, encounters, unsigned notes, results, tasks | Filtered by active care context |
| `GET` | `/api/v1/patients?q=&includeOtherContexts=&page=&pageSize=` | Paginated patient search | Distinguishes `VERIFIED_IDENTITY` vs `POSSIBLE_DEMOGRAPHIC_MATCH` |
| `GET` | `/api/v1/patients/{patientId}/overview` | Full 10-section patient summary | Enforces care-context isolation (`403`) + audit |
| `POST` | `/api/v1/patients/{patientId}/emergency-access` | Grant 2-hour break-glass access | Requires >= 8 char reason + Caldicott audit flag |
| `POST` | `/api/v1/notes` | Create/update consultation draft | `expectedVersion` optimistic lock (`409` on mismatch), blocks `AUDITOR` and signed notes |
| `POST` | `/api/v1/notes/{noteId}/sign` | Atomically sign note + commit audit | `DOCTOR` only, `confirmedPatientId`, `idempotencyKey`, SHA-256 content hash |
| `POST` | `/api/v1/notes/{noteId}/amendments` | Add attributed amendment/addendum | Signed notes only, `idempotencyKey` |
| `POST` | `/api/v1/notes/{noteId}/entered-in-error` | Mark note entered-in-error | Retains original content & history |
| `POST` | `/api/v1/results/{resultId}/workflow` | Advance result state (`VIEWED`, `ACKNOWLEDGED`, `FOLLOW_UP_ASSIGNED`, `ACTION_COMPLETED`) | Requires `confirmedPatientId`, separate from lab status (`PRELIMINARY/FINAL/CORRECTED/CANCELLED`) |
| `POST` | `/api/v1/medications/{medicationId}/reconcile` | Reconcile or flag medication discrepancy | Distinguishes prescribing/dispensing/administration/patient-reported |
| `POST` | `/api/v1/tasks` | Create patient-linked follow-up task | Links optional `linkedResultId`, `idempotencyKey` |
| `POST` | `/api/v1/tasks/{taskId}/complete` | Complete task with evidence | Advances linked result to `ACTION_COMPLETED` |
| `POST` | `/api/v1/documents` | Upload protected document / clinical photo | Requires `consentRecorded=true` for photos |
| `GET` | `/api/v1/documents/{documentId}/content` | Download protected attachment bytes | Enforces patient access + path confinement + audit |
| `GET` | `/api/v1/fhir/Patient/{patientId}/$everything` | Mock FHIR R4 Bundle adapter | Explicit synthetic disclaimer, preserves source provenance |
| `GET` | `/api/v1/audit?patientId=&page=&pageSize=` | Paginated audit trail | View/edit/sign/export/denied/break-glass events |
