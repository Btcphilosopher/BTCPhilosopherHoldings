# AUREOM CLINICAL — Architecture, Screen Map, Schema & Repository Structure

> **Independent Prototype Notice:** Aureom Clinical is an independent prototype using synthetic demonstration records. It is not an official NHS product or live clinical system.

## 1. Layered Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│ UI Layer (Jetpack Compose + Material 3 + Adaptive Phone/Tablet Shell)   │
│  SignInScreen · TodayWorklistScreen · PatientsScreen ·                  │
│  PatientOverviewScreen · NotesWorkspaceScreen · ResultsScreen ·         │
│  TasksScreen · SettingsAndAuditScreen · PersistentPatientBanner         │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │ StateFlow / Intents
┌───────────────────────────────▼─────────────────────────────────────────┐
│ Presentation Layer (AureomViewModel)                                    │
│  Session state · Patient safety binding guard · Autosave debounce ·     │
│  Explicit confirmation dialogs · Conflict resolution state              │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │ Repository Boundary
┌───────────────────────────────▼─────────────────────────────────────────┐
│ Domain & Repository Layer (ClinicalRepository, AssistiveDraftingEngine) │
│  Room Cache/Drafts/Sync Queue · WorkManager CoroutineWorker ·           │
│  Android Keystore CredentialVault + BiometricPrompt unlock ·            │
│  Ktor Client (Live OkHttp HTTP or Embedded Ktor MockEngine Demo)        │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │ HTTPS / Authenticated REST JSON + FHIR
┌───────────────────────────────▼─────────────────────────────────────────┐
│ Backend Layer (Kotlin + Ktor Server + PostgreSQL + Flyway + Storage)    │
│  Local OIDC IdP Adapter · Care-Context & Role Policy Enforcement ·      │
│  Optimistic Concurrency · Atomic Note Signing + Audit Commit ·          │
│  Idempotency Keys · Protected Object Storage · Mock FHIR R4 Adapter     │
└─────────────────────────────────────────────────────────────────────────┘
```

## 2. Screen Map & Adaptive Navigation

- **Authentication Gate**: `SignInScreen` (Organisational OIDC profile & care-context selector, Keystore + Biometric local unlock when valid session exists, server mode switch).
- **Phone (`< 840dp`)**: Bottom `NavigationBar` (`Today · Patients · Notes · Results · Tasks · Settings`) + `PersistentPatientBanner` whenever a patient record is open.
- **Tablet (`>= 840dp`)**: NHS-blue `NavigationRail` + persistent Ward/Clinic Worklist Sidebar + Patient Workspace (split Search/Overview on `Patients` tab).

## 3. Database Schema

### PostgreSQL (`backend/src/main/resources/db/migration/V1__initial_clinical_schema.sql`)
- `care_contexts`, `users`, `user_care_contexts`, `sessions`
- `patients` (with `identity_verification_status`, `match_confidence`, `allergy_status_state`)
- `encounters`, `appointments`, `problems`, `clinical_history`, `medications`, `allergies`, `observations`
- `diagnostic_results` (`result_status`, `workflow_state`, `supersedes_result_id`, `correction_reason`)
- `clinical_notes` (`status`, `version`, `content_hash`, `entered_in_error_*`), `note_amendments`
- `care_plans`, `follow_up_tasks`, `documents_attachments`
- `emergency_access_grants`, `audit_logs`, `idempotency_keys`

### Room Local Cache (`app/src/main/java/com/example/core/database/AureomDatabase.kt`)
- `cached_patients`: TTL-bounded authorised patient overview snapshots
- `local_note_drafts`: Autosaved drafts, `baseVersion`, `dirty`, `CONFLICT` state, server snapshot diff
- `pending_sync_ops`: Bounded-retry (`max 3`) idempotent offline queue processed by `ClinicalSyncWorker`
- `sync_metadata`: Last successful sync timestamp and error state
- `protected_attachments`: App-private file references (`filesDir/clinical_attachments/`) with consent metadata

## 4. Repository Structure

- `app/` — Native Android Kotlin/Compose application
- `backend/` — Standalone Kotlin/Ktor Server with Flyway migrations & H2/PostgreSQL support
- `docker-compose.yml` — PostgreSQL 16 + MinIO object storage + Ktor backend
- `docs/` — Architecture, API Contracts, and Pre-deployment Verification checklist

## 5. Exact Build & Verification Commands

```bash
# 1. Backend tests (Ktor + Flyway + H2 PostgreSQL compatibility mode)
gradle -p backend test --no-daemon

# 2. Android Robolectric & Compose UI tests
gradle :app:testDebugUnitTest --no-daemon

# 3. Debug APK build (uses debug.keystore)
gradle :app:assembleDebug --no-daemon

# 4. Release APK build (provide keystore & passwords via env vars outside source control)
KEYSTORE_PATH=/path/to/upload.jks STORE_PASSWORD=*** KEY_PASSWORD=*** gradle :app:assembleRelease --no-daemon

# 5. Local backend + PostgreSQL + MinIO deployment
docker compose up --build
```

## 6. Pre-Deployment Verification Checklist

Before proposing any clinical deployment:
1. Identify the **target healthcare organisation and jurisdiction**.
2. Verify current official clinical safety standards (e.g., **NHS England DCB0129 / DCB0160** clinical risk management, Clinical Safety Officer sign-off).
3. Verify privacy & data protection compliance (**UK GDPR / Data Protection Act 2018**, Caldicott Principles, NHS DSPT / DTAC).
4. Verify official authentication & interoperability profiles (**NHS CIS2 / OIDC**, **FHIR UK Core R4**, SNOMED CT / dm+d terminology, and LIMS/ePMA interface specifications).
