plugins {
  kotlin("jvm") version "2.1.20"
  kotlin("plugin.serialization") version "2.1.20"
  application
}

group = "com.aureom.backend"
version = "1.0.0"

application {
  mainClass.set("com.aureom.backend.MainKt")
}

kotlin {
  jvmToolchain(21)
}

val ktorVersion = "3.1.2"
val flywayVersion = "11.3.4"
val postgresVersion = "42.7.5"
val hikariVersion = "6.2.1"
val h2Version = "2.3.232"
val logbackVersion = "1.5.16"
val jbcryptVersion = "0.4"

dependencies {
  implementation("io.ktor:ktor-server-core:$ktorVersion")
  implementation("io.ktor:ktor-server-netty:$ktorVersion")
  implementation("io.ktor:ktor-server-content-negotiation:$ktorVersion")
  implementation("io.ktor:ktor-serialization-kotlinx-json:$ktorVersion")
  implementation("io.ktor:ktor-server-auth:$ktorVersion")
  implementation("io.ktor:ktor-server-auth-jwt:$ktorVersion")
  implementation("io.ktor:ktor-server-status-pages:$ktorVersion")
  implementation("io.ktor:ktor-server-call-logging:$ktorVersion")
  implementation("io.ktor:ktor-server-cors:$ktorVersion")

  implementation("org.postgresql:postgresql:$postgresVersion")
  implementation("com.zaxxer:HikariCP:$hikariVersion")
  implementation("org.flywaydb:flyway-core:$flywayVersion")
  implementation("org.flywaydb:flyway-database-postgresql:$flywayVersion")
  implementation("org.mindrot:jbcrypt:$jbcryptVersion")
  implementation("ch.qos.logback:logback-classic:$logbackVersion")

  testImplementation("io.ktor:ktor-server-test-host:$ktorVersion")
  testImplementation("io.ktor:ktor-client-content-negotiation:$ktorVersion")
  testImplementation("com.h2database:h2:$h2Version")
  testImplementation(kotlin("test"))
}

tasks.test {
  useJUnitPlatform()
}
