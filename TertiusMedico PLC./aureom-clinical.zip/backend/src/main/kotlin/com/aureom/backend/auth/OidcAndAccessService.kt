package com.aureom.backend.auth

import com.aureom.backend.db.DatabaseFactory
import com.aureom.backend.model.*
import org.mindrot.jbcrypt.BCrypt
import java.security.MessageDigest
import java.security.SecureRandom
import java.sql.Connection
import java.sql.Timestamp
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.Base64
import java.util.UUID

data class AuthenticatedPrincipal(
  val sessionId: String,
  val clinicianId: String,
  val username: String,
  val displayName: String,
  val role: String,
  val specialty: String,
  val careContextId: String,
  val expiresAt: Instant,
)

class ClinicalForbiddenException(message: String, val code: String = "FORBIDDEN") : RuntimeException(message)
class ClinicalUnauthorizedException(message: String, val code: String = "UNAUTHORIZED") : RuntimeException(message)
class ClinicalNotFoundException(message: String, val code: String = "NOT_FOUND") : RuntimeException(message)
class ClinicalConflictException(message: String, val code: String = "CONFLICT") : RuntimeException(message)
class ClinicalBadRequestException(message: String, val code: String = "BAD_REQUEST") : RuntimeException(message)

class OidcAndAccessService(
  private val db: DatabaseFactory,
  val issuer: String = System.getenv("OIDC_ISSUER") ?: "https://idp.aureom-demo.local",
) {
  private val random = SecureRandom()

  fun discoveryDocument(): OidcDiscoveryDocument = OidcDiscoveryDocument(
    issuer = issuer,
    authorizationEndpoint = "$issuer/auth/oidc/authorize",
    tokenEndpoint = "$issuer/auth/oidc/token",
    revocationEndpoint = "$issuer/auth/logout",
    scopesSupported = listOf("openid", "profile", "clinical.read", "clinical.write", "clinical.sign"),
    prototypeNotice = "Independent prototype local OpenID Connect identity provider for synthetic demonstration only. Not connected to NHS CIS2.",
  )

  fun exchangeOidcToken(request: OidcTokenRequest, ttlMinutes: Long = 480): AuthSessionResponse {
    return db.inTransaction { conn ->
      val userStmt = conn.prepareStatement(
        "SELECT clinician_id, username, display_name, role, specialty, password_hash, active FROM users WHERE username = ?"
      )
      userStmt.setString(1, request.username.trim())
      val rs = userStmt.executeQuery()
      if (!rs.next() || !rs.getBoolean("active")) {
        recordAudit(
          conn = conn,
          actorId = "anonymous",
          actorName = request.username,
          actorRole = "UNAUTHENTICATED",
          action = "OIDC_LOGIN",
          resourceType = "SESSION",
          resourceId = "unknown",
          patientId = null,
          careContextId = request.careContextId,
          outcome = "DENIED",
          reason = "Invalid credentials or inactive clinician account",
          emergencyAccess = false,
        )
        throw ClinicalUnauthorizedException("Invalid organisational credentials", "INVALID_CREDENTIALS")
      }
      val clinicianId = rs.getString("clinician_id")
      val displayName = rs.getString("display_name")
      val role = rs.getString("role")
      val specialty = rs.getString("specialty")
      val passwordHash = rs.getString("password_hash")
      if (!BCrypt.checkpw(request.password, passwordHash)) {
        recordAudit(
          conn = conn,
          actorId = clinicianId,
          actorName = displayName,
          actorRole = role,
          action = "OIDC_LOGIN",
          resourceType = "SESSION",
          resourceId = "unknown",
          patientId = null,
          careContextId = request.careContextId,
          outcome = "DENIED",
          reason = "Password verification failed",
          emergencyAccess = false,
        )
        throw ClinicalUnauthorizedException("Invalid organisational credentials", "INVALID_CREDENTIALS")
      }

      val contexts = loadPermittedContexts(conn, clinicianId)
      val activeContext = contexts.firstOrNull { it.contextId == request.careContextId }
        ?: throw ClinicalForbiddenException("Clinician is not authorised for care context ${request.careContextId}", "CONTEXT_NOT_PERMITTED")

      val sessionId = "SES-${UUID.randomUUID()}"
      val accessToken = generateOpaqueToken()
      val refreshToken = generateOpaqueToken()
      val now = Instant.now()
      val expiresAt = now.plus(ttlMinutes, ChronoUnit.MINUTES)

      val insertSession = conn.prepareStatement(
        """
        INSERT INTO sessions (session_id, clinician_id, care_context_id, access_token_hash, refresh_token_hash, issued_at, expires_at, revoked_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NULL)
        """.trimIndent()
      )
      insertSession.setString(1, sessionId)
      insertSession.setString(2, clinicianId)
      insertSession.setString(3, activeContext.contextId)
      insertSession.setString(4, sha256(accessToken))
      insertSession.setString(5, sha256(refreshToken))
      insertSession.setTimestamp(6, Timestamp.from(now))
      insertSession.setTimestamp(7, Timestamp.from(expiresAt))
      insertSession.executeUpdate()

      recordAudit(
        conn = conn,
        actorId = clinicianId,
        actorName = displayName,
        actorRole = role,
        action = "OIDC_LOGIN",
        resourceType = "SESSION",
        resourceId = sessionId,
        patientId = null,
        careContextId = activeContext.contextId,
        outcome = "ALLOWED",
        reason = "Local OIDC prototype sign-in",
        emergencyAccess = false,
      )

      AuthSessionResponse(
        sessionId = sessionId,
        accessToken = accessToken,
        refreshToken = refreshToken,
        expiresAt = expiresAt.toString(),
        clinician = ClinicianProfile(
          clinicianId = clinicianId,
          username = request.username.trim(),
          displayName = displayName,
          role = role,
          specialty = specialty,
          activeCareContextId = activeContext.contextId,
          activeCareContextName = activeContext.name,
          permittedCareContexts = contexts,
        ),
        prototypeBanner = "INDEPENDENT PROTOTYPE • SYNTHETIC DEMONSTRATION CLINIC • NOT AN NHS INTEGRATION",
      )
    }
  }

  fun authenticateBearer(bearerToken: String?): AuthenticatedPrincipal {
    if (bearerToken.isNullOrBlank()) {
      throw ClinicalUnauthorizedException("Missing bearer session token", "MISSING_TOKEN")
    }
    val hash = sha256(bearerToken.trim())
    return db.inTransaction { conn ->
      val stmt = conn.prepareStatement(
        """
        SELECT s.session_id, s.clinician_id, s.care_context_id, s.expires_at, s.revoked_at,
               u.username, u.display_name, u.role, u.specialty, u.active
        FROM sessions s
        JOIN users u ON u.clinician_id = s.clinician_id
        WHERE s.access_token_hash = ?
        """.trimIndent()
      )
      stmt.setString(1, hash)
      val rs = stmt.executeQuery()
      if (!rs.next()) {
        throw ClinicalUnauthorizedException("Invalid session token", "INVALID_TOKEN")
      }
      if (!rs.getBoolean("active")) {
        throw ClinicalUnauthorizedException("Clinician account disabled", "ACCOUNT_DISABLED")
      }
      val revokedAt = rs.getTimestamp("revoked_at")
      if (revokedAt != null) {
        throw ClinicalUnauthorizedException("Session has been revoked", "SESSION_REVOKED")
      }
      val expiresAt = rs.getTimestamp("expires_at").toInstant()
      if (Instant.now().isAfter(expiresAt)) {
        throw ClinicalUnauthorizedException("Session expired — please re-authenticate", "SESSION_EXPIRED")
      }
      AuthenticatedPrincipal(
        sessionId = rs.getString("session_id"),
        clinicianId = rs.getString("clinician_id"),
        username = rs.getString("username"),
        displayName = rs.getString("display_name"),
        role = rs.getString("role"),
        specialty = rs.getString("specialty"),
        careContextId = rs.getString("care_context_id"),
        expiresAt = expiresAt,
      )
    }
  }

  fun revokeSession(principal: AuthenticatedPrincipal) {
    db.inTransaction { conn ->
      val stmt = conn.prepareStatement("UPDATE sessions SET revoked_at = ? WHERE session_id = ?")
      stmt.setTimestamp(1, Timestamp.from(Instant.now()))
      stmt.setString(2, principal.sessionId)
      stmt.executeUpdate()
      recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "SESSION_REVOKED",
        resourceType = "SESSION",
        resourceId = principal.sessionId,
        patientId = null,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = "User sign-out or session revocation",
        emergencyAccess = false,
      )
    }
  }

  fun expireSessionForTesting(sessionId: String) {
    db.inTransaction { conn ->
      val stmt = conn.prepareStatement("UPDATE sessions SET expires_at = ? WHERE session_id = ?")
      stmt.setTimestamp(1, Timestamp.from(Instant.now().minusSeconds(60)))
      stmt.setString(2, sessionId)
      stmt.executeUpdate()
    }
  }

  fun requireWriteRole(principal: AuthenticatedPrincipal, action: String) {
    if (principal.role !in setOf("DOCTOR", "NURSE")) {
      db.inTransaction { conn ->
        recordAudit(
          conn = conn,
          actorId = principal.clinicianId,
          actorName = principal.displayName,
          actorRole = principal.role,
          action = action,
          resourceType = "AUTHORISATION",
          resourceId = principal.sessionId,
          patientId = null,
          careContextId = principal.careContextId,
          outcome = "DENIED",
          reason = "Role ${principal.role} is read-only",
          emergencyAccess = false,
        )
      }
      throw ClinicalForbiddenException("Role ${principal.role} is not permitted to perform $action", "ROLE_FORBIDDEN")
    }
  }

  fun requireSigningRole(principal: AuthenticatedPrincipal) {
    if (principal.role != "DOCTOR") {
      db.inTransaction { conn ->
        recordAudit(
          conn = conn,
          actorId = principal.clinicianId,
          actorName = principal.displayName,
          actorRole = principal.role,
          action = "SIGN_NOTE",
          resourceType = "CLINICAL_NOTE",
          resourceId = "policy-check",
          patientId = null,
          careContextId = principal.careContextId,
          outcome = "DENIED",
          reason = "Only DOCTOR role may sign consultation notes",
          emergencyAccess = false,
        )
      }
      throw ClinicalForbiddenException("Only authorised medical practitioners (DOCTOR) may sign notes", "SIGN_ROLE_FORBIDDEN")
    }
  }

  fun verifyPatientAccess(
    conn: Connection,
    principal: AuthenticatedPrincipal,
    patientId: String,
    action: String,
  ): Boolean {
    val pStmt = conn.prepareStatement("SELECT care_context_id FROM patients WHERE patient_id = ?")
    pStmt.setString(1, patientId)
    val pRs = pStmt.executeQuery()
    if (!pRs.next()) {
      throw ClinicalNotFoundException("Patient $patientId not found", "PATIENT_NOT_FOUND")
    }
    val patientContext = pRs.getString("care_context_id")
    if (patientContext == principal.careContextId) {
      return false
    }

    // Check active emergency break-glass grant
    val gStmt = conn.prepareStatement(
      """
      SELECT grant_id, expires_at FROM emergency_access_grants
      WHERE clinician_id = ? AND patient_id = ? AND expires_at > ?
      ORDER BY granted_at DESC LIMIT 1
      """.trimIndent()
    )
    gStmt.setString(1, principal.clinicianId)
    gStmt.setString(2, patientId)
    gStmt.setTimestamp(3, Timestamp.from(Instant.now()))
    val gRs = gStmt.executeQuery()
    if (gRs.next()) {
      return true
    }

    recordAudit(
      conn = conn,
      actorId = principal.clinicianId,
      actorName = principal.displayName,
      actorRole = principal.role,
      action = action,
      resourceType = "PATIENT",
      resourceId = patientId,
      patientId = patientId,
      careContextId = principal.careContextId,
      outcome = "DENIED",
      reason = "Patient belongs to care context $patientContext; active context is ${principal.careContextId}",
      emergencyAccess = false,
    )
    throw ClinicalForbiddenException(
      "Access denied: patient $patientId is outside active care context (${principal.careContextId}). Use restricted emergency access if clinically justified.",
      "CARE_CONTEXT_ISOLATION",
    )
  }

  fun grantEmergencyAccess(
    principal: AuthenticatedPrincipal,
    patientId: String,
    reason: String,
  ): EmergencyAccessGrantDto {
    if (reason.trim().length < 8) {
      throw ClinicalBadRequestException("Emergency break-glass access requires a clinical reason (min 8 characters)", "REASON_REQUIRED")
    }
    if (principal.role == "AUDITOR") {
      throw ClinicalForbiddenException("Auditor role cannot invoke emergency clinical break-glass access", "ROLE_FORBIDDEN")
    }
    return db.inTransaction { conn ->
      val pStmt = conn.prepareStatement("SELECT patient_id FROM patients WHERE patient_id = ?")
      pStmt.setString(1, patientId)
      if (!pStmt.executeQuery().next()) {
        throw ClinicalNotFoundException("Patient $patientId not found", "PATIENT_NOT_FOUND")
      }
      val now = Instant.now()
      val expires = now.plus(2, ChronoUnit.HOURS)
      val grantId = "EMG-${UUID.randomUUID()}"
      val stmt = conn.prepareStatement(
        """
        INSERT INTO emergency_access_grants (grant_id, clinician_id, patient_id, reason, granted_at, expires_at, review_status)
        VALUES (?, ?, ?, ?, ?, ?, 'PENDING_CALDICOTT_REVIEW')
        """.trimIndent()
      )
      stmt.setString(1, grantId)
      stmt.setString(2, principal.clinicianId)
      stmt.setString(3, patientId)
      stmt.setString(4, reason.trim())
      stmt.setTimestamp(5, Timestamp.from(now))
      stmt.setTimestamp(6, Timestamp.from(expires))
      stmt.executeUpdate()

      recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "EMERGENCY_BREAK_GLASS_GRANTED",
        resourceType = "PATIENT",
        resourceId = patientId,
        patientId = patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = reason.trim(),
        emergencyAccess = true,
        metadataJson = """{"grantId":"$grantId","expiresAt":"$expires"}""",
      )

      EmergencyAccessGrantDto(
        grantId = grantId,
        patientId = patientId,
        clinicianId = principal.clinicianId,
        reason = reason.trim(),
        grantedAt = now.toString(),
        expiresAt = expires.toString(),
        reviewStatus = "PENDING_CALDICOTT_REVIEW",
      )
    }
  }

  private fun loadPermittedContexts(conn: Connection, clinicianId: String): List<CareContextDto> {
    val stmt = conn.prepareStatement(
      """
      SELECT c.context_id, c.name, c.ward_or_clinic, c.facility_name, ucc.access_level
      FROM user_care_contexts ucc
      JOIN care_contexts c ON c.context_id = ucc.context_id
      WHERE ucc.clinician_id = ?
      ORDER BY c.context_id
      """.trimIndent()
    )
    stmt.setString(1, clinicianId)
    val rs = stmt.executeQuery()
    val list = mutableListOf<CareContextDto>()
    while (rs.next()) {
      list += CareContextDto(
        contextId = rs.getString("context_id"),
        name = rs.getString("name"),
        wardOrClinic = rs.getString("ward_or_clinic"),
        facilityName = rs.getString("facility_name"),
        accessLevel = rs.getString("access_level"),
      )
    }
    return list
  }

  fun recordAudit(
    conn: Connection,
    actorId: String,
    actorName: String,
    actorRole: String,
    action: String,
    resourceType: String,
    resourceId: String,
    patientId: String?,
    careContextId: String?,
    outcome: String,
    reason: String?,
    emergencyAccess: Boolean,
    metadataJson: String = "{}",
  ) {
    val stmt = conn.prepareStatement(
      """
      INSERT INTO audit_logs (
        audit_id, timestamp, actor_id, actor_name, actor_role, action,
        resource_type, resource_id, patient_id, care_context_id, outcome,
        reason, emergency_access, metadata_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      """.trimIndent()
    )
    stmt.setString(1, "AUD-${UUID.randomUUID()}")
    stmt.setTimestamp(2, Timestamp.from(Instant.now()))
    stmt.setString(3, actorId)
    stmt.setString(4, actorName)
    stmt.setString(5, actorRole)
    stmt.setString(6, action)
    stmt.setString(7, resourceType)
    stmt.setString(8, resourceId)
    stmt.setString(9, patientId)
    stmt.setString(10, careContextId)
    stmt.setString(11, outcome)
    stmt.setString(12, reason)
    stmt.setBoolean(13, emergencyAccess)
    stmt.setString(14, metadataJson)
    stmt.executeUpdate()
  }

  private fun generateOpaqueToken(): String {
    val bytes = ByteArray(32)
    random.nextBytes(bytes)
    return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
  }

  fun sha256(value: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
  }
}
