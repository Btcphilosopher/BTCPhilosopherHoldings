package com.aureom.backend.fhir

import com.aureom.backend.model.*
import kotlinx.serialization.Serializable

@Serializable
data class FhirCoding(
  val system: String,
  val code: String,
  val display: String,
)

@Serializable
data class FhirMeta(
  val profile: List<String>,
  val tag: List<FhirCoding>,
)

@Serializable
data class FhirIdentifier(
  val system: String,
  val value: String,
  val verificationStatus: String,
)

@Serializable
data class FhirBundleEntry(
  val fullUrl: String,
  val resourceType: String,
  val id: String,
  val status: String,
  val summary: String,
  val sourceSystem: String,
  val recordedAt: String? = null,
)

@Serializable
data class FhirPatientEverythingBundle(
  val resourceType: String = "Bundle",
  val type: String = "collection",
  val fhirVersion: String = "4.0.1-synthetic-adapter",
  val disclaimer: String = "MOCK FHIR R4 ADAPTER FOR DEMONSTRATION ONLY. NOT A VERIFIED NHS SPINE OR UK CORE LIVE ENDPOINT.",
  val meta: FhirMeta,
  val patientIdentifiers: List<FhirIdentifier>,
  val total: Int,
  val entries: List<FhirBundleEntry>,
)

object FhirR4Adapter {
  fun toPatientEverythingBundle(overview: PatientOverviewDto): FhirPatientEverythingBundle {
    val entries = mutableListOf<FhirBundleEntry>()

    entries += FhirBundleEntry(
      fullUrl = "urn:aureom:Patient/${overview.patient.patientId}",
      resourceType = "Patient",
      id = overview.patient.patientId,
      status = overview.patient.identityVerificationStatus,
      summary = "${overview.patient.fullName} (DOB ${overview.patient.dateOfBirth}) — ${overview.patient.matchConfidence}",
      sourceSystem = "Aureom Synthetic EPR",
      recordedAt = overview.patient.updatedAt,
    )

    overview.allergies.forEach { a ->
      entries += FhirBundleEntry(
        fullUrl = "urn:aureom:AllergyIntolerance/${a.allergyId}",
        resourceType = "AllergyIntolerance",
        id = a.allergyId,
        status = "${a.verificationStatus} (${a.severity})",
        summary = "${a.substance} -> ${a.reaction}",
        sourceSystem = a.provenance,
        recordedAt = a.recordedAt,
      )
    }

    overview.medications.forEach { m ->
      entries += FhirBundleEntry(
        fullUrl = "urn:aureom:MedicationStatement/${m.medicationId}",
        resourceType = "MedicationStatement",
        id = m.medicationId,
        status = "${m.recordCategory}/${m.status}",
        summary = "${m.name} ${m.strength} (${m.dose} ${m.route} ${m.frequency})",
        sourceSystem = m.sourceSystem,
        recordedAt = m.startDate,
      )
    }

    overview.recentObservations.forEach { o ->
      val valueDisplay = o.valueNumeric?.let { "$it ${o.unit}" } ?: "MISSING (${o.missingReason ?: "Not measured"})"
      entries += FhirBundleEntry(
        fullUrl = "urn:aureom:Observation/${o.observationId}",
        resourceType = "Observation",
        id = o.observationId,
        status = "${o.verificationStatus}/${o.abnormalFlag}",
        summary = "${o.name}: $valueDisplay [ref ${o.referenceInterval}]",
        sourceSystem = o.sourceSystem,
        recordedAt = o.observedAt,
      )
    }

    overview.diagnosticResults.forEach { r ->
      entries += FhirBundleEntry(
        fullUrl = "urn:aureom:DiagnosticReport/${r.resultId}",
        resourceType = "DiagnosticReport",
        id = r.resultId,
        status = "${r.resultStatus}/${r.workflowState}",
        summary = "${r.testName}: ${r.valueText ?: "N/A"} ${r.unit} (${r.abnormalFlag})",
        sourceSystem = r.sourceSystem,
        recordedAt = r.reportedAt,
      )
    }

    overview.documents.forEach { d ->
      entries += FhirBundleEntry(
        fullUrl = "urn:aureom:DocumentReference/${d.documentId}",
        resourceType = "DocumentReference",
        id = d.documentId,
        status = if (d.originalPreserved) "current" else "derived",
        summary = "${d.title} (${d.mimeType})",
        sourceSystem = d.sourceSystem,
        recordedAt = d.createdAt,
      )
    }

    return FhirPatientEverythingBundle(
      meta = FhirMeta(
        profile = listOf("https://aureom-demo.local/fhir/StructureDefinition/SyntheticPatientBundle"),
        tag = listOf(
          FhirCoding(
            system = "https://aureom-demo.local/fhir/CodeSystem/environment",
            code = "SYNTHETIC_DEMO_ADAPTER",
            display = "Independent Prototype Mock FHIR R4 Service",
          )
        ),
      ),
      patientIdentifiers = listOf(
        FhirIdentifier(
          system = "https://aureom-demo.local/ids/internal-patient",
          value = overview.patient.patientId,
          verificationStatus = "INTERNAL",
        ),
        FhirIdentifier(
          system = "https://aureom-demo.local/ids/synthetic-nhs-number",
          value = overview.patient.nhsNumber,
          verificationStatus = overview.patient.identityVerificationStatus,
        ),
        FhirIdentifier(
          system = "https://aureom-demo.local/ids/external-mrn",
          value = overview.patient.externalMrn,
          verificationStatus = overview.patient.identityVerificationStatus,
        ),
      ),
      total = entries.size,
      entries = entries,
    )
  }
}
