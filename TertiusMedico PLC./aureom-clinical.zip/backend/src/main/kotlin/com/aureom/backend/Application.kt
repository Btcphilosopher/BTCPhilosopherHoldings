package com.aureom.backend

import com.aureom.backend.auth.*
import com.aureom.backend.db.DatabaseFactory
import com.aureom.backend.fhir.FhirR4Adapter
import com.aureom.backend.model.*
import com.aureom.backend.seed.SyntheticClinicSeeder
import com.aureom.backend.service.ClinicalRecordService
import com.aureom.backend.storage.ProtectedObjectStorage
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.plugins.calllogging.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.json.Json
import org.slf4j.event.Level
import java.time.Instant

data class BackendContext(
  val db: DatabaseFactory,
  val auth: OidcAndAccessService,
  val storage: ProtectedObjectStorage,
  val records: ClinicalRecordService,
)

fun Application.configureAureomBackend(customDb: DatabaseFactory? = null): BackendContext {
  val db = customDb ?: DatabaseFactory()
  val storage = ProtectedObjectStorage()
  val auth = OidcAndAccessService(db)
  val records = ClinicalRecordService(db, auth, storage)

  if ((System.getenv("SEED_SYNTHETIC_CLINIC") ?: "true").equals("true", ignoreCase = true)) {
    SyntheticClinicSeeder.seedIfEmpty(db, storage)
  }

  install(ContentNegotiation) {
    json(Json {
      prettyPrint = false
      ignoreUnknownKeys = true
      encodeDefaults = true
    })
  }

  // Keep clinical content and bearer tokens out of server logs
  install(CallLogging) {
    level = Level.INFO
    format { call ->
      val status = call.response.status()
      val method = call.request.httpMethod.value
      val path = call.request.path()
      "http $method $path -> ${status?.value ?: 0}"
    }
  }

  install(StatusPages) {
    exception<ClinicalUnauthorizedException> { call, cause ->
      call.respond(
        HttpStatusCode.Unauthorized,
        ApiError(code = cause.code, message = cause.message ?: "Unauthorized", timestamp = Instant.now().toString()),
      )
    }
    exception<ClinicalForbiddenException> { call, cause ->
      call.respond(
        HttpStatusCode.Forbidden,
        ApiError(code = cause.code, message = cause.message ?: "Forbidden", timestamp = Instant.now().toString()),
      )
    }
    exception<ClinicalNotFoundException> { call, cause ->
      call.respond(
        HttpStatusCode.NotFound,
        ApiError(code = cause.code, message = cause.message ?: "Not found", timestamp = Instant.now().toString()),
      )
    }
    exception<ClinicalConflictException> { call, cause ->
      call.respond(
        HttpStatusCode.Conflict,
        ApiError(code = cause.code, message = cause.message ?: "Conflict", timestamp = Instant.now().toString()),
      )
    }
    exception<ClinicalBadRequestException> { call, cause ->
      call.respond(
        HttpStatusCode.BadRequest,
        ApiError(code = cause.code, message = cause.message ?: "Bad request", timestamp = Instant.now().toString()),
      )
    }
  }

  fun ApplicationCall.requirePrincipal(): AuthenticatedPrincipal {
    val header = request.headers[HttpHeaders.Authorization]
    val token = header?.removePrefix("Bearer ")?.trim()
    return auth.authenticateBearer(token)
  }

  routing {
    get("/health") {
      call.respond(mapOf("status" to "ok", "service" to "aureom-clinical-prototype", "timestamp" to Instant.now().toString()))
    }

    get("/.well-known/openid-configuration") {
      call.respond(auth.discoveryDocument())
    }

    post("/auth/oidc/token") {
      val req = call.receive<OidcTokenRequest>()
      call.respond(HttpStatusCode.OK, auth.exchangeOidcToken(req))
    }

    post("/auth/logout") {
      val principal = call.requirePrincipal()
      auth.revokeSession(principal)
      call.respond(HttpStatusCode.OK, mapOf("revoked" to "true"))
    }

    get("/auth/session") {
      val principal = call.requirePrincipal()
      call.respond(
        mapOf(
          "sessionId" to principal.sessionId,
          "clinicianId" to principal.clinicianId,
          "role" to principal.role,
          "careContextId" to principal.careContextId,
          "expiresAt" to principal.expiresAt.toString(),
        )
      )
    }

    get("/api/v1/worklist") {
      val principal = call.requirePrincipal()
      call.respond(records.getWorklist(principal))
    }

    get("/api/v1/patients") {
      val principal = call.requirePrincipal()
      val q = call.request.queryParameters["q"] ?: ""
      val includeOther = call.request.queryParameters["includeOtherContexts"]?.toBoolean() ?: false
      val page = call.request.queryParameters["page"]?.toIntOrNull() ?: 1
      val pageSize = call.request.queryParameters["pageSize"]?.toIntOrNull() ?: 25
      call.respond(records.searchPatients(principal, q, includeOther, page, pageSize))
    }

    get("/api/v1/patients/{patientId}/overview") {
      val principal = call.requirePrincipal()
      val patientId = call.parameters["patientId"] ?: throw ClinicalBadRequestException("Missing patientId")
      call.respond(records.getPatientOverview(principal, patientId))
    }

    post("/api/v1/patients/{patientId}/emergency-access") {
      val principal = call.requirePrincipal()
      val patientId = call.parameters["patientId"] ?: throw ClinicalBadRequestException("Missing patientId")
      val req = call.receive<EmergencyAccessRequest>()
      call.respond(HttpStatusCode.Created, auth.grantEmergencyAccess(principal, patientId, req.reason))
    }

    post("/api/v1/notes") {
      val principal = call.requirePrincipal()
      val req = call.receive<SaveNoteDraftRequest>()
      call.respond(records.saveNoteDraft(principal, req))
    }

    post("/api/v1/notes/{noteId}/sign") {
      val principal = call.requirePrincipal()
      val noteId = call.parameters["noteId"] ?: throw ClinicalBadRequestException("Missing noteId")
      val req = call.receive<SignNoteRequest>()
      call.respond(records.signNote(principal, noteId, req))
    }

    post("/api/v1/notes/{noteId}/amendments") {
      val principal = call.requirePrincipal()
      val noteId = call.parameters["noteId"] ?: throw ClinicalBadRequestException("Missing noteId")
      val req = call.receive<CreateAmendmentRequest>()
      call.respond(records.addAmendment(principal, noteId, req))
    }

    post("/api/v1/notes/{noteId}/entered-in-error") {
      val principal = call.requirePrincipal()
      val noteId = call.parameters["noteId"] ?: throw ClinicalBadRequestException("Missing noteId")
      val req = call.receive<EnteredInErrorRequest>()
      call.respond(records.markEnteredInError(principal, noteId, req))
    }

    post("/api/v1/results/{resultId}/workflow") {
      val principal = call.requirePrincipal()
      val resultId = call.parameters["resultId"] ?: throw ClinicalBadRequestException("Missing resultId")
      val req = call.receive<UpdateResultWorkflowRequest>()
      call.respond(records.updateResultWorkflow(principal, resultId, req))
    }

    post("/api/v1/medications/{medicationId}/reconcile") {
      val principal = call.requirePrincipal()
      val medicationId = call.parameters["medicationId"] ?: throw ClinicalBadRequestException("Missing medicationId")
      val req = call.receive<ReconcileMedicationRequest>()
      call.respond(records.reconcileMedication(principal, medicationId, req))
    }

    post("/api/v1/tasks") {
      val principal = call.requirePrincipal()
      val req = call.receive<CreateTaskRequest>()
      call.respond(HttpStatusCode.Created, records.createTask(principal, req))
    }

    post("/api/v1/tasks/{taskId}/complete") {
      val principal = call.requirePrincipal()
      val taskId = call.parameters["taskId"] ?: throw ClinicalBadRequestException("Missing taskId")
      val req = call.receive<CompleteTaskRequest>()
      call.respond(records.completeTask(principal, taskId, req))
    }

    post("/api/v1/documents") {
      val principal = call.requirePrincipal()
      val req = call.receive<UploadDocumentRequest>()
      call.respond(HttpStatusCode.Created, records.uploadDocument(principal, req))
    }

    get("/api/v1/documents/{documentId}/content") {
      val principal = call.requirePrincipal()
      val docId = call.parameters["documentId"] ?: throw ClinicalBadRequestException("Missing documentId")
      val (doc, bytes) = records.downloadDocument(principal, docId)
      call.respondBytes(bytes, ContentType.parse(doc.mimeType))
    }

    get("/api/v1/fhir/Patient/{patientId}/\$everything") {
      val principal = call.requirePrincipal()
      val patientId = call.parameters["patientId"] ?: throw ClinicalBadRequestException("Missing patientId")
      val overview = records.getPatientOverview(principal, patientId)
      call.respond(FhirR4Adapter.toPatientEverythingBundle(overview))
    }

    get("/api/v1/audit") {
      val principal = call.requirePrincipal()
      val patientId = call.request.queryParameters["patientId"]
      val page = call.request.queryParameters["page"]?.toIntOrNull() ?: 1
      val pageSize = call.request.queryParameters["pageSize"]?.toIntOrNull() ?: 50
      call.respond(records.getAuditLogs(principal, patientId, page, pageSize))
    }
  }

  return BackendContext(db, auth, storage, records)
}
