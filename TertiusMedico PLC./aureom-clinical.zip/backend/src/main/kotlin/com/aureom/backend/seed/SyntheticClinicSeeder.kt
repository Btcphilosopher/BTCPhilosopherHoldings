package com.aureom.backend.seed

import com.aureom.backend.db.DatabaseFactory
import com.aureom.backend.model.CopiedAttributionDto
import com.aureom.backend.model.NoteSectionDto
import com.aureom.backend.storage.ProtectedObjectStorage
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.mindrot.jbcrypt.BCrypt
import java.sql.Timestamp
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.Base64

object SyntheticClinicSeeder {
  private val json = Json { prettyPrint = false }

  fun seedIfEmpty(db: DatabaseFactory, storage: ProtectedObjectStorage) {
    db.inTransaction { conn ->
      val check = conn.prepareStatement("SELECT COUNT(*) FROM users").executeQuery()
      check.next()
      if (check.getInt(1) > 0) return@inTransaction

      val now = Instant.now()
      val hash = BCrypt.hashpw("demo-clinician-pass", BCrypt.gensalt(10))

      fun exec(sql: String, vararg params: Any?) {
        val stmt = conn.prepareStatement(sql)
        params.forEachIndexed { idx, v ->
          when (v) {
            null -> stmt.setObject(idx + 1, null)
            is Instant -> stmt.setTimestamp(idx + 1, Timestamp.from(v))
            is Boolean -> stmt.setBoolean(idx + 1, v)
            is Int -> stmt.setInt(idx + 1, v)
            is Long -> stmt.setLong(idx + 1, v)
            is Double -> stmt.setDouble(idx + 1, v)
            else -> stmt.setString(idx + 1, v.toString())
          }
        }
        stmt.executeUpdate()
      }

      // Care Contexts
      exec("INSERT INTO care_contexts VALUES (?, ?, ?, ?)", "CTX-AMU-A", "Acute Medical Unit — Ward 4B", "Ward 4B & SDEC", "St Jude Synthetic Teaching Hospital")
      exec("INSERT INTO care_contexts VALUES (?, ?, ?, ?)", "CTX-CARD-OPD", "Cardiology Outpatient Clinic", "Clinic Suite 2", "St Jude Synthetic Teaching Hospital")
      exec("INSERT INTO care_contexts VALUES (?, ?, ?, ?)", "CTX-RENAL-WARD", "Renal Inpatient Unit", "Ward 9C", "St Jude Synthetic Teaching Hospital")

      // Users
      exec("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?, ?)", "USR-DOC-1", "dr.jenkins", "Dr Sarah Jenkins", "DOCTOR", "Acute & General Medicine", hash, "oidc-sub-dr-jenkins", true)
      exec("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?, ?)", "USR-NUR-1", "nurse.patel", "Sister Maya Patel", "NURSE", "Acute Medical Unit", hash, "oidc-sub-nurse-patel", true)
      exec("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?, ?)", "USR-AUD-1", "auditor.cole", "Owen Cole", "AUDITOR", "Clinical Governance", hash, "oidc-sub-auditor-cole", true)

      // Permitted Care Contexts (Note: Renal Ward CTX-RENAL-WARD is deliberately NOT assigned to dr.jenkins to test isolation & break-glass)
      exec("INSERT INTO user_care_contexts VALUES (?, ?, ?)", "USR-DOC-1", "CTX-AMU-A", "FULL")
      exec("INSERT INTO user_care_contexts VALUES (?, ?, ?)", "USR-DOC-1", "CTX-CARD-OPD", "FULL")
      exec("INSERT INTO user_care_contexts VALUES (?, ?, ?)", "USR-NUR-1", "CTX-AMU-A", "CLINICAL_SUPPORT")
      exec("INSERT INTO user_care_contexts VALUES (?, ?, ?)", "USR-AUD-1", "CTX-AMU-A", "READ_ONLY_AUDIT")

      // Patients (Synthetic demonstration cohort)
      exec(
        "INSERT INTO patients VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "PAT-1001", "943 476 5919", "MRN-SJ-88412", "VERIFIED", "VERIFIED_IDENTITY",
        "Arthur Pendelton", "Artie", "1948-06-14", "Male",
        "CTX-AMU-A", "USR-DOC-1", "ENC-2001", "AMU Ward 4B • Bed 06 • Acute Care",
        "Dr Sarah Jenkins (Consultant), Sister Maya Patel (Named Nurse)",
        "RECORDED", now.minus(1, ChronoUnit.HOURS)
      )
      exec(
        "INSERT INTO patients VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "PAT-1002", "943 512 0084", "MRN-SJ-77109", "VERIFIED", "VERIFIED_IDENTITY",
        "Miriam Okafor", null, "1976-11-03", "Female",
        "CTX-AMU-A", "USR-DOC-1", "ENC-2002", "SDEC Bay 2 • Same Day Emergency Care",
        "Dr Sarah Jenkins (Consultant), Dr Liam Shaw (Registrar)",
        "EXPLICIT_NO_KNOWN_ALLERGIES", now.minus(2, ChronoUnit.HOURS)
      )
      exec(
        "INSERT INTO patients VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "PAT-1003", "Unverified-Demo-03", "MRN-SJ-91044", "PROVISIONAL", "POSSIBLE_DEMOGRAPHIC_MATCH",
        "Evelyn Gallagher", null, "1959-02-21", "Female",
        "CTX-AMU-A", "USR-DOC-1", "ENC-2003", "AMU Assessment Bay 1 • Identity Pending",
        "Dr Sarah Jenkins (Consultant)",
        "NOT_ASSESSED", now.minus(30, ChronoUnit.MINUTES)
      )
      exec(
        "INSERT INTO patients VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "PAT-1004", "943 880 3312", "MRN-SJ-65201", "VERIFIED", "VERIFIED_IDENTITY",
        "Tariq Al-Mansoor", null, "1964-09-18", "Male",
        "CTX-CARD-OPD", "USR-DOC-1", "ENC-2004", "Cardiology Clinic Rm 4 • Follow-up",
        "Dr Sarah Jenkins (General Medicine), Dr Priya Nair (Cardiology)",
        "UNKNOWN", now.minus(3, ChronoUnit.HOURS)
      )
      // Isolated patient in CTX-RENAL-WARD (not in dr.jenkins default context)
      exec(
        "INSERT INTO patients VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "PAT-9001", "943 991 4401", "MRN-SJ-30991", "VERIFIED", "VERIFIED_IDENTITY",
        "Helena Vance", null, "1982-04-09", "Female",
        "CTX-RENAL-WARD", null, "ENC-9001", "Renal Unit Ward 9C • Bed 11",
        "Dr Marcus Thorne (Nephrology)",
        "UNAVAILABLE", now.minus(4, ChronoUnit.HOURS)
      )

      // Encounters
      exec("INSERT INTO encounters VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "ENC-2001", "PAT-1001", "CTX-AMU-A", "USR-DOC-1", "INPATIENT_WARD", "ACTIVE", "AMU Ward 4B • Bed 06", "Acute kidney injury & community-acquired pneumonia review", now.minus(18, ChronoUnit.HOURS))
      exec("INSERT INTO encounters VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "ENC-2002", "PAT-1002", "CTX-AMU-A", "USR-DOC-1", "SDEC_CONSULT", "ACTIVE", "SDEC Bay 2", "Pleuritic chest pain & D-dimer review", now.minus(3, ChronoUnit.HOURS))
      exec("INSERT INTO encounters VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "ENC-2003", "PAT-1003", "CTX-AMU-A", "USR-DOC-1", "ACUTE_ASSESSMENT", "ACTIVE", "AMU Bay 1", "Syncope episode — provisional identity check", now.minus(45, ChronoUnit.MINUTES))
      exec("INSERT INTO encounters VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "ENC-2004", "PAT-1004", "CTX-CARD-OPD", "USR-DOC-1", "OUTPATIENT", "SCHEDULED", "Clinic Suite 2 • Rm 4", "Heart failure titration review", now.plus(2, ChronoUnit.HOURS))
      exec("INSERT INTO encounters VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "ENC-9001", "PAT-9001", "CTX-RENAL-WARD", "USR-DOC-1", "INPATIENT_WARD", "ACTIVE", "Ward 9C • Bed 11", "Renal transplant follow-up", now.minus(24, ChronoUnit.HOURS))

      // Today's Appointments
      exec("INSERT INTO appointments VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", "APT-3001", "PAT-1001", "ENC-2001", "USR-DOC-1", "CTX-AMU-A", now.plus(25, ChronoUnit.MINUTES), 20, "Ward 4B Bed 06", "CHECKED_IN", "Morning consultant ward round & corrected K+ review")
      exec("INSERT INTO appointments VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", "APT-3002", "PAT-1002", "ENC-2002", "USR-DOC-1", "CTX-AMU-A", now.plus(55, ChronoUnit.MINUTES), 20, "SDEC Bay 2", "IN_CLINIC", "Same-day diagnostic & anticoagulation assessment")
      exec("INSERT INTO appointments VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", "APT-3003", "PAT-1003", "ENC-2003", "USR-DOC-1", "CTX-AMU-A", now.plus(90, ChronoUnit.MINUTES), 30, "AMU Bay 1", "AWAITING_ID_CHECK", "Syncope assessment (confirm demographic match first)")

      // Problems
      exec("INSERT INTO problems VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "PRB-1", "PAT-1001", "Stage 1 Acute Kidney Injury (resolving)", "SNOMED:14669001", "ACTIVE", "2026-11-21", "Dr Sarah Jenkins", now.minus(36, ChronoUnit.HOURS), "Aureom Ward EPR (Synthetic)")
      exec("INSERT INTO problems VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "PRB-2", "PAT-1001", "Community-Acquired Pneumonia (right lower lobe)", "SNOMED:385093006", "ACTIVE", "2026-11-20", "Dr Liam Shaw", now.minus(40, ChronoUnit.HOURS), "Aureom Ward EPR (Synthetic)")
      exec("INSERT INTO problems VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "PRB-3", "PAT-1001", "Type 2 Diabetes Mellitus", "SNOMED:44054006", "CHRONIC", "2014-05-10", "GP Summary Feed (Synthetic)", now.minus(120, ChronoUnit.DAYS), "GP Connect Mock Adapter")
      exec("INSERT INTO problems VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "PRB-4", "PAT-1002", "Suspected Pulmonary Embolism — rule-out pathway", "SNOMED:59282003", "PROVISIONAL", "2026-11-23", "Dr Sarah Jenkins", now.minus(2, ChronoUnit.HOURS), "SDEC Assessment")

      // Relevant History
      exec("INSERT INTO clinical_history VALUES (?, ?, ?, ?, ?, ?, ?)", "HIS-1", "PAT-1001", "PAST_MEDICAL", "Hypertension (2011), Benign prostatic hyperplasia (2019), Non-smoker.", "GP Summary Feed (Synthetic)", now.minus(90, ChronoUnit.DAYS), "GP Connect Mock Adapter")
      exec("INSERT INTO clinical_history VALUES (?, ?, ?, ?, ?, ?, ?)", "HIS-2", "PAT-1001", "SOCIAL", "Lives with spouse in bungalow; independent with ADLs prior to admission.", "Sister Maya Patel", now.minus(16, ChronoUnit.HOURS), "Nursing Admission Assessment")
      exec("INSERT INTO clinical_history VALUES (?, ?, ?, ?, ?, ?, ?)", "HIS-3", "PAT-1002", "PAST_MEDICAL", "Oral contraceptive stopped 6 weeks ago; recent 9-hour flight.", "Dr Sarah Jenkins", now.minus(3, ChronoUnit.HOURS), "SDEC Intake")

      // Medications (Distinguish PRESCRIBING, DISPENSING, ADMINISTRATION, PATIENT_REPORTED + Discrepancy)
      exec("INSERT INTO medications VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "MED-101", "PAT-1001", "Doxycycline", "100 mg", "100 mg", "Oral", "Once daily (Day 3/5)",
        "PRESCRIBING", "ACTIVE", "2026-11-21", "2026-11-25", "ePMA Inpatient Chart (Synthetic)", "Dr Sarah Jenkins",
        false, null, null, null
      )
      exec("INSERT INTO medications VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "MED-102", "PAT-1001", "Doxycycline", "100 mg", "100 mg", "Oral", "08:00 dose given",
        "ADMINISTRATION", "COMPLETED_DOSE", "2026-11-23", null, "BCMA Ward Administration", "Sister Maya Patel",
        false, null, null, null
      )
      exec("INSERT INTO medications VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "MED-103", "PAT-1001", "Metformin", "500 mg", "1000 mg", "Oral", "Twice daily (GP record)",
        "DISPENSING", "HELD_INPATIENT", "2024-01-12", null, "Community Pharmacy Dispensing Feed (Synthetic)", "GP/Pharmacy Feed",
        true, "GP/Dispensing record shows 1000 mg BD; patient reports taking 500 mg OD due to GI upset. Temporarily held during AKI.", null, null
      )
      exec("INSERT INTO medications VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "MED-104", "PAT-1001", "Metformin", "500 mg", "500 mg", "Oral", "Once daily (Patient reported)",
        "PATIENT_REPORTED", "REPORTED_ACTIVE", "2026-10-01", null, "Admission Medicines Reconciliation", "Sister Maya Patel",
        true, "Differs from GP prescribing/dispensing dose (1000 mg BD). Requires clinician reconciliation.", null, null
      )
      exec("INSERT INTO medications VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "MED-105", "PAT-1002", "Apixaban", "5 mg", "5 mg", "Oral", "Twice daily (provisional SDEC hold pending D-dimer)",
        "PRESCRIBING", "PENDING_REVIEW", "2026-11-23", null, "SDEC Prescribing Adapter (Simulated)", "Dr Sarah Jenkins",
        false, null, null, null
      )

      // Allergies
      exec("INSERT INTO allergies VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "ALG-101", "PAT-1001", "Penicillin (Amoxicillin)", "Generalised urticaria & facial angioedema",
        "CONFIRMED", "HIGH_SEVERE", "GP Summary & Patient Confirmation", "Dr Sarah Jenkins", now.minus(18, ChronoUnit.HOURS)
      )
      exec("INSERT INTO allergies VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "ALG-102", "PAT-1001", "Latex", "Contact dermatitis",
        "UNCONFIRMED", "LOW_MILD", "Patient-reported (2018)", "Sister Maya Patel", now.minus(16, ChronoUnit.HOURS)
      )
      // Note: PAT-1002 has EXPLICIT_NO_KNOWN_ALLERGIES, PAT-1003 has NOT_ASSESSED, PAT-1004 has UNKNOWN, PAT-9001 has UNAVAILABLE.

      // Observations (including a missing measurement left null rather than zero)
      exec("INSERT INTO observations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "OBS-101", "PAT-1001", "ENC-2001", "Systolic Blood Pressure", 128.0, "mmHg", "100–140 mmHg", "NORMAL", null, now.minus(55, ChronoUnit.MINUTES), "Ward 4B Welch Allyn Monitor", "VERIFIED"
      )
      exec("INSERT INTO observations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "OBS-102", "PAT-1001", "ENC-2001", "Heart Rate", 94.0, "bpm", "60–90 bpm", "HIGH", null, now.minus(55, ChronoUnit.MINUTES), "Ward 4B Welch Allyn Monitor", "VERIFIED"
      )
      exec("INSERT INTO observations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "OBS-103", "PAT-1001", "ENC-2001", "Oxygen Saturation (SpO2)", 95.0, "%", "94–98% (air)", "NORMAL", null, now.minus(55, ChronoUnit.MINUTES), "Ward 4B Welch Allyn Monitor", "VERIFIED"
      )
      exec("INSERT INTO observations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "OBS-104", "PAT-1001", "ENC-2001", "Capillary Blood Glucose", null, "mmol/L", "4.0–7.8 mmol/L", "MISSING", "Not recorded during 05:00 obs round (patient asleep)", now.minus(55, ChronoUnit.MINUTES), "Ward 4B Nursing Chart", "UNVERIFIED"
      )

      // Diagnostic Results (including a CORRECTED result linked to its superseded FINAL version)
      exec("INSERT INTO diagnostic_results VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "RES-200", "PAT-1001", "ENC-2001", "Serum Potassium (K+)", "Biochemistry", "4.8", "mmol/L", "3.5–5.3 mmol/L", "NORMAL",
        "FINAL", "ACKNOWLEDGED", null, null, now.minus(6, ChronoUnit.HOURS), "St Jude LIMS (Synthetic)", "VERIFIED", "Dr Sarah Jenkins", now.minus(5, ChronoUnit.HOURS), null
      )
      exec("INSERT INTO diagnostic_results VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "RES-201", "PAT-1001", "ENC-2001", "Serum Potassium (K+)", "Biochemistry", "5.8", "mmol/L", "3.5–5.3 mmol/L", "HIGH",
        "CORRECTED", "AVAILABLE", "RES-200", "Initial sample diluted by IV line draw; repeat non-haemolysed venous sample confirms hyperkalaemia.",
        now.minus(25, ChronoUnit.MINUTES), "St Jude LIMS (Synthetic)", "VERIFIED", null, null, null
      )
      exec("INSERT INTO diagnostic_results VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "RES-202", "PAT-1001", "ENC-2001", "Serum Creatinine", "Biochemistry", "146", "umol/L", "60–110 umol/L", "HIGH",
        "FINAL", "VIEWED", null, null, now.minus(40, ChronoUnit.MINUTES), "St Jude LIMS (Synthetic)", "VERIFIED", null, null, null
      )
      exec("INSERT INTO diagnostic_results VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "RES-203", "PAT-1002", "ENC-2002", "Quantitative D-dimer", "Haematology", "640", "ng/mL FEU", "< 500 ng/mL", "HIGH",
        "PRELIMINARY", "AVAILABLE", null, null, now.minus(20, ChronoUnit.MINUTES), "St Jude LIMS (Synthetic)", "PROVISIONAL", null, null, null
      )
      exec("INSERT INTO diagnostic_results VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "RES-204", "PAT-1001", "ENC-2001", "Blood Culture — 48h Interim", "Microbiology", null, "", "No growth expected", "MISSING",
        "CANCELLED", "ACKNOWLEDGED", null, "Specimen rejected in lab: unlabelled bottle", now.minus(8, ChronoUnit.HOURS), "Microbiology LIMS (Synthetic)", "VERIFIED", "Dr Sarah Jenkins", now.minus(7, ChronoUnit.HOURS), null
      )

      // Notes (1 SIGNED immutable admission note + 1 DRAFT ward round note ready for conflict/signing demo)
      val signedSections = json.encodeToString(
        listOf(
          NoteSectionDto("history", "Presenting Complaint & History", "78M admitted with 3 days productive cough, fever, and mild dehydration. Right basal crepitations."),
          NoteSectionDto("examination", "Examination", "Alert, HR 96, BP 124/76, SpO2 94% on room air, temp 38.1 C."),
          NoteSectionDto("impression", "Impression & Plan", "1. Right lower lobe CAP (CURB-65 2). 2. Mild pre-renal AKI. Start IV fluids and oral doxycycline (penicillin allergic)."),
        )
      )
      exec("INSERT INTO clinical_notes VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "NOTE-301", "PAT-1001", "ENC-2001", "ADMISSION", "Acute Medical Admission Clerking",
        signedSections, "Penicillin allergy verified with patient and GP summary prior to prescribing doxycycline.",
        "[]", "SIGNED", 1L, "USR-DOC-1", "Dr Sarah Jenkins",
        now.minus(17, ChronoUnit.HOURS), now.minus(16, ChronoUnit.HOURS),
        now.minus(16, ChronoUnit.HOURS), "USR-DOC-1", "Dr Sarah Jenkins",
        "sha256:9f82b1c4a8d0e331", null, null, null
      )

      val draftSections = json.encodeToString(
        listOf(
          NoteSectionDto("progress", "Interval Progress", "Overnight fever settled. Drinking oral fluids well."),
          NoteSectionDto("obs_results", "Observations & Results Review", "Awaiting morning biochemistry check."),
          NoteSectionDto("plan", "Management Plan", "Continue doxycycline Day 3/5; review repeat U&Es."),
        )
      )
      val sampleAttribution = json.encodeToString(
        listOf(
          CopiedAttributionDto(
            attributionId = "ATT-1",
            sourceLabel = "Admission Clerking (NOTE-301)",
            sourceAuthor = "Dr Sarah Jenkins",
            sourceTimestamp = now.minus(16, ChronoUnit.HOURS).toString(),
            excerpt = "Right lower lobe CAP (CURB-65 2); penicillin allergic — doxycycline prescribed.",
          )
        )
      )
      exec("INSERT INTO clinical_notes VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "NOTE-302", "PAT-1001", "ENC-2001", "WARD_ROUND", "Morning Consultant Ward Round",
        draftSections, "Draft started prior to morning round.",
        sampleAttribution, "DRAFT", 1L, "USR-DOC-1", "Dr Sarah Jenkins",
        now.minus(45, ChronoUnit.MINUTES), now.minus(35, ChronoUnit.MINUTES),
        null, null, null, null, null, null, null
      )

      // Care Plans
      exec("INSERT INTO care_plans VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        "PLAN-1", "PAT-1001", "Acute Kidney Injury & Sepsis Recovery Bundle",
        "Strict fluid balance charting, hold metformin until eGFR > 45 and repeat K+ < 5.2, repeat U&Es in 6 hours.",
        "ACTIVE", "Dr Sarah Jenkins", now.minus(10, ChronoUnit.HOURS), "Ward 4B Multidisciplinary Plan"
      )

      // Follow-up Tasks
      exec("INSERT INTO follow_up_tasks VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "TSK-401", "PAT-1001", "ENC-2001", "RES-201",
        "Repeat ECG & Potassium check after corrected K+ 5.8 mmol/L",
        "Assess ECG for peaked T-waves, stop any K+-sparing agents, repeat venous K+ in 4 hours.",
        "USR-DOC-1", "Dr Sarah Jenkins", "URGENT", now.plus(2, ChronoUnit.HOURS),
        "OPEN", null, null, null, "Dr Sarah Jenkins", now.minus(20, ChronoUnit.MINUTES), 1L
      )
      exec("INSERT INTO follow_up_tasks VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "TSK-402", "PAT-1002", "ENC-2002", "RES-203",
        "Arrange CTPA if clinical probability remains high",
        "Review Wells score alongside final D-dimer.",
        "USR-DOC-1", "Dr Sarah Jenkins", "URGENT", now.plus(3, ChronoUnit.HOURS),
        "IN_PROGRESS", null, null, null, "Dr Sarah Jenkins", now.minus(15, ChronoUnit.MINUTES), 1L
      )

      // Documents & Protected Clinical Attachment
      val sampleSummaryDoc = "AUREOM CLINICAL SYNTHETIC DISCHARGE SUMMARY\nPatient: Arthur Pendelton (PAT-1001)\nSummary: Synthetic demo document stored in protected object storage."
      val storedDoc = storage.storeProtectedBytes(
        patientId = "PAT-1001",
        documentId = "DOC-501",
        extension = "txt",
        base64Payload = Base64.getEncoder().encodeToString(sampleSummaryDoc.toByteArray()),
      )
      exec("INSERT INTO documents_attachments VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "DOC-501", "PAT-1001", "ENC-2001", "Previous Cardiology Clinic Letter (Synthetic)",
        "CLINIC_LETTER", "text/plain", storedDoc.objectKey, false, false, null,
        "Dr Priya Nair", true, null, now.minus(30, ChronoUnit.DAYS), "Outpatient Correspondence Archive"
      )

      // Initial Audit Log
      exec("INSERT INTO audit_logs VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        "AUD-SEED-001", now.minus(16, ChronoUnit.HOURS), "USR-DOC-1", "Dr Sarah Jenkins", "DOCTOR",
        "SIGN_NOTE", "CLINICAL_NOTE", "NOTE-301", "PAT-1001", "CTX-AMU-A",
        "ALLOWED", "Admission note signed with atomic audit commit", false, """{"version":1}"""
      )
    }
  }
}
