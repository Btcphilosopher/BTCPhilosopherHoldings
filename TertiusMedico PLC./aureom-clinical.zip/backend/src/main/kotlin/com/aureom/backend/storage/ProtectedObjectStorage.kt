package com.aureom.backend.storage

import java.io.File
import java.security.MessageDigest
import java.util.Base64
import java.util.UUID

class ProtectedObjectStorage(
  baseDirectory: String = System.getenv("STORAGE_DIR") ?: "./build/protected-attachments",
) {
  private val rootDir: File = File(baseDirectory).canonicalFile.apply { mkdirs() }

  data class StoredAttachment(
    val objectKey: String,
    val sha256: String,
    val sizeBytes: Long,
  )

  fun storeProtectedBytes(
    patientId: String,
    documentId: String,
    extension: String,
    base64Payload: String,
  ): StoredAttachment {
    val safePatient = patientId.replace(Regex("[^A-Za-z0-9_-]"), "_")
    val safeExt = extension.replace(Regex("[^A-Za-z0-9]"), "").ifEmpty { "bin" }
    val objectKey = "$safePatient/${documentId}_${UUID.randomUUID()}.$safeExt"
    val target = resolveConfined(objectKey)
    target.parentFile?.mkdirs()

    val bytes = Base64.getDecoder().decode(base64Payload)
    target.writeBytes(bytes)
    val sha256 = MessageDigest.getInstance("SHA-256")
      .digest(bytes)
      .joinToString("") { "%02x".format(it) }
    return StoredAttachment(objectKey = objectKey, sha256 = sha256, sizeBytes = bytes.size.toLong())
  }

  fun readProtectedBytes(objectKey: String): ByteArray? {
    val target = resolveConfined(objectKey)
    if (!target.exists() || !target.isFile) return null
    return target.readBytes()
  }

  private fun resolveConfined(objectKey: String): File {
    val candidate = File(rootDir, objectKey).canonicalFile
    val rootPath = rootDir.path
    require(candidate.path.startsWith(rootPath + File.separator)) {
      "Refusing path outside protected attachment storage boundary"
    }
    return candidate
  }
}
