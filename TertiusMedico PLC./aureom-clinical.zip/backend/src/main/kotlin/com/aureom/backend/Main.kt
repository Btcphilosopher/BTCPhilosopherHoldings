package com.aureom.backend

import io.ktor.server.engine.*
import io.ktor.server.netty.*

fun main() {
  val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
  embeddedServer(Netty, port = port, host = "0.0.0.0") {
    configureAureomBackend()
  }.start(wait = true)
}
