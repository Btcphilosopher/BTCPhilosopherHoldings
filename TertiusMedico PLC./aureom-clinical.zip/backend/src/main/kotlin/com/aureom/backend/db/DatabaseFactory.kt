package com.aureom.backend.db

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.flywaydb.core.Flyway
import java.sql.Connection
import javax.sql.DataSource

class DatabaseFactory(
  jdbcUrl: String = System.getenv("DB_URL") ?: "jdbc:h2:mem:aureom_dev;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH;DB_CLOSE_DELAY=-1",
  username: String = System.getenv("DB_USER") ?: "sa",
  password: String = System.getenv("DB_PASSWORD") ?: "",
) {
  val dataSource: DataSource

  init {
    val config = HikariConfig().apply {
      this.jdbcUrl = jdbcUrl
      this.username = username
      this.password = password
      maximumPoolSize = 10
      isAutoCommit = false
      transactionIsolation = "TRANSACTION_REPEATABLE_READ"
    }
    dataSource = HikariDataSource(config)
    Flyway.configure()
      .dataSource(dataSource)
      .locations("classpath:db/migration")
      .load()
      .migrate()
  }

  fun <T> inTransaction(block: (Connection) -> T): T {
    dataSource.connection.use { conn ->
      conn.autoCommit = false
      try {
        val result = block(conn)
        conn.commit()
        return result
      } catch (t: Throwable) {
        runCatching { conn.rollback() }
        throw t
      }
    }
  }
}
