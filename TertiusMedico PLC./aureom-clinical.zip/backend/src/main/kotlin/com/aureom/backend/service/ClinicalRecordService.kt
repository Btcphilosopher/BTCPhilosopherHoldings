package com.aureom.backend.service

import com.aureom.backend.auth.*
import com.aureom.backend.db.DatabaseFactory
import com.aureom.backend.model.*
import com.aureom.backend.storage.ProtectedObjectStorage
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.sql.Connection
import java.sql.ResultSet
import java.sql.Timestamp
import java.time.Instant
import java.util.UUID

class ClinicalRecordService(
  private val db: DatabaseFactory,
  private val auth: OidcAndAccessService,
  private val storage: ProtectedObjectStorage,
) {
  private val json = Json { ignoreUnknownKeys = true }

  fun getWorklist(principal: AuthenticatedPrincipal): WorklistResponseDto {
    return db.inTransaction { conn ->
      val ctxStmt = conn.prepareStatement(
        """
        SELECT c.context_id, c.name, c.ward_or_clinic, c.facility_name, ucc.access_level
        FROM care_contexts c
        JOIN user_care_contexts ucc ON ucc.context_id = c.context_id
        WHERE c.context_id = ? AND ucc.clinician_id = ?
        """.trimIndent()
      )
      ctxStmt.setString(1, principal.careContextId)
      ctxStmt.setString(2, principal.clinicianId)
      val ctxRs = ctxStmt.executeQuery()
      if (!ctxRs.next()) {
        throw ClinicalForbiddenException("No access to care context ${principal.careContextId}", "CONTEXT_FORBIDDEN")
      }
      val careContext = CareContextDto(
        contextId = ctxRs.getString("context_id"),
        name = ctxRs.getString("name"),
        wardOrClinic = ctxRs.getString("ward_or_clinic"),
        facilityName = ctxRs.getString("facility_name"),
        accessLevel = ctxRs.getString("access_level"),
      )

      val appts = mutableListOf<AppointmentDto>()
      val aStmt = conn.prepareStatement(
        """
        SELECT a.*, p.full_name, p.date_of_birth, p.nhs_number
        FROM appointments a
        JOIN patients p ON p.patient_id = a.patient_id
        WHERE a.care_context_id = ?
        ORDER BY a.scheduled_at ASC
        """.trimIndent()
      )
      aStmt.setString(1, principal.careContextId)
      val aRs = aStmt.executeQuery()
      while (aRs.next()) {
        appts += AppointmentDto(
          appointmentId = aRs.getString("appointment_id"),
          patientId = aRs.getString("patient_id"),
          patientName = aRs.getString("full_name"),
          patientDob = aRs.getString("date_of_birth"),
          nhsNumber = aRs.getString("nhs_number"),
          encounterId = aRs.getString("encounter_id"),
          clinicianId = aRs.getString("clinician_id"),
          careContextId = aRs.getString("care_context_id"),
          scheduledAt = aRs.getTimestamp("scheduled_at").toInstant().toString(),
          durationMinutes = aRs.getInt("duration_minutes"),
          clinicRoom = aRs.getString("clinic_room"),
          status = aRs.getString("status"),
          reason = aRs.getString("reason"),
        )
      }

      val patients = queryPatientsForContext(conn, principal.careContextId)

      val encounters = mutableListOf<EncounterDto>()
      val eStmt = conn.prepareStatement(
        "SELECT * FROM encounters WHERE care_context_id = ? ORDER BY started_at DESC"
      )
      eStmt.setString(1, principal.careContextId)
      val eRs = eStmt.executeQuery()
      while (eRs.next()) {
        encounters += EncounterDto(
          encounterId = eRs.getString("encounter_id"),
          patientId = eRs.getString("patient_id"),
          careContextId = eRs.getString("care_context_id"),
          clinicianId = eRs.getString("clinician_id"),
          encounterType = eRs.getString("encounter_type"),
          status = eRs.getString("status"),
          location = eRs.getString("location"),
          reasonForVisit = eRs.getString("reason_for_visit"),
          startedAt = eRs.getTimestamp("started_at").toInstant().toString(),
        )
      }

      val unsignedNotes = mutableListOf<ClinicalNoteDto>()
      val nStmt = conn.prepareStatement(
        """
        SELECT n.*, p.full_name AS patient_name
        FROM clinical_notes n
        JOIN patients p ON p.patient_id = n.patient_id
        WHERE p.care_context_id = ? AND n.status = 'DRAFT'
        ORDER BY n.updated_at DESC
        """.trimIndent()
      )
      nStmt.setString(1, principal.careContextId)
      val nRs = nStmt.executeQuery()
      while (nRs.next()) {
        unsignedNotes += mapNote(conn, nRs)
      }

      val results = mutableListOf<DiagnosticResultDto>()
      val rStmt = conn.prepareStatement(
        """
        SELECT r.*, p.full_name AS patient_name
        FROM diagnostic_results r
        JOIN patients p ON p.patient_id = r.patient_id
        WHERE p.care_context_id = ? AND r.workflow_state IN ('AVAILABLE', 'VIEWED', 'FOLLOW_UP_ASSIGNED')
        ORDER BY r.reported_at DESC
        """.trimIndent()
      )
      rStmt.setString(1, principal.careContextId)
      val rRs = rStmt.executeQuery()
      while (rRs.next()) {
        results += mapResult(rRs)
      }

      val tasks = mutableListOf<FollowUpTaskDto>()
      val tStmt = conn.prepareStatement(
        """
        SELECT t.*, p.full_name AS patient_name
        FROM follow_up_tasks t
        JOIN patients p ON p.patient_id = t.patient_id
        WHERE p.care_context_id = ? AND t.status != 'COMPLETED'
        ORDER BY t.due_at ASC
        """.trimIndent()
      )
      tStmt.setString(1, principal.careContextId)
      val tRs = tStmt.executeQuery()
      while (tRs.next()) {
        tasks += mapTask(tRs)
      }

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "VIEW_WORKLIST",
        resourceType = "CARE_CONTEXT",
        resourceId = principal.careContextId,
        patientId = null,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = null,
        emergencyAccess = false,
      )

      WorklistResponseDto(
        careContext = careContext,
        todaysAppointments = appts,
        assignedPatients = patients,
        recentEncounters = encounters,
        unsignedNotes = unsignedNotes,
        resultsRequiringReview = results,
        outstandingTasks = tasks,
        serverTimestamp = Instant.now().toString(),
      )
    }
  }

  fun searchPatients(
    principal: AuthenticatedPrincipal,
    query: String,
    includeOtherContexts: Boolean,
    page: Int,
    pageSize: Int,
  ): PaginatedResponse<PatientSummaryDto> {
    return db.inTransaction { conn ->
      val sql = if (includeOtherContexts) {
        "SELECT * FROM patients ORDER BY full_name ASC"
      } else {
        "SELECT * FROM patients WHERE care_context_id = ? ORDER BY full_name ASC"
      }
      val stmt = conn.prepareStatement(sql)
      if (!includeOtherContexts) {
        stmt.setString(1, principal.careContextId)
      }
      val rs = stmt.executeQuery()
      val q = query.trim().lowercase()
      val all = mutableListOf<PatientSummaryDto>()
      while (rs.next()) {
        val dto = mapPatientSummary(conn, rs, principal)
        if (q.isEmpty() ||
          dto.fullName.lowercase().contains(q) ||
          dto.nhsNumber.replace(" ", "").lowercase().contains(q.replace(" ", "")) ||
          dto.externalMrn.lowercase().contains(q) ||
          dto.patientId.lowercase().contains(q) ||
          dto.dateOfBirth.contains(q)
        ) {
          all += dto
        }
      }
      val safePage = page.coerceAtLeast(1)
      val safeSize = pageSize.coerceIn(1, 50)
      val from = ((safePage - 1) * safeSize).coerceAtMost(all.size)
      val to = (from + safeSize).coerceAtMost(all.size)
      PaginatedResponse(
        items = all.subList(from, to),
        page = safePage,
        pageSize = safeSize,
        totalCount = all.size,
        hasMore = to < all.size,
      )
    }
  }

  fun getPatientOverview(principal: AuthenticatedPrincipal, patientId: String): PatientOverviewDto {
    return db.inTransaction { conn ->
      val emergency = auth.verifyPatientAccess(conn, principal, patientId, "VIEW_PATIENT_OVERVIEW")
      val pStmt = conn.prepareStatement("SELECT * FROM patients WHERE patient_id = ?")
      pStmt.setString(1, patientId)
      val pRs = pStmt.executeQuery()
      pRs.next()
      val patient = mapPatientSummary(conn, pRs, principal)

      val problems = queryList(conn, "SELECT * FROM problems WHERE patient_id = ? ORDER BY recorded_at DESC", patientId) { rs ->
        ProblemDto(
          problemId = rs.getString("problem_id"),
          patientId = rs.getString("patient_id"),
          title = rs.getString("title"),
          coding = rs.getString("coding"),
          clinicalStatus = rs.getString("clinical_status"),
          onsetDate = rs.getString("onset_date"),
          authorName = rs.getString("author_name"),
          recordedAt = rs.getTimestamp("recorded_at").toInstant().toString(),
          sourceSystem = rs.getString("source_system"),
        )
      }

      val history = queryList(conn, "SELECT * FROM clinical_history WHERE patient_id = ? ORDER BY recorded_at DESC", patientId) { rs ->
        ClinicalHistoryDto(
          historyId = rs.getString("history_id"),
          patientId = rs.getString("patient_id"),
          category = rs.getString("category"),
          summary = rs.getString("summary"),
          authorName = rs.getString("author_name"),
          recordedAt = rs.getTimestamp("recorded_at").toInstant().toString(),
          sourceSystem = rs.getString("source_system"),
        )
      }

      val medications = queryList(conn, "SELECT * FROM medications WHERE patient_id = ? ORDER BY discrepancy_flag DESC, name ASC", patientId) { rs ->
        MedicationDto(
          medicationId = rs.getString("medication_id"),
          patientId = rs.getString("patient_id"),
          name = rs.getString("name"),
          strength = rs.getString("strength"),
          dose = rs.getString("dose"),
          route = rs.getString("route"),
          frequency = rs.getString("frequency"),
          recordCategory = rs.getString("record_category"),
          status = rs.getString("status"),
          startDate = rs.getString("start_date"),
          endDate = rs.getString("end_date"),
          sourceSystem = rs.getString("source_system"),
          authorName = rs.getString("author_name"),
          discrepancyFlag = rs.getBoolean("discrepancy_flag"),
          discrepancyNote = rs.getString("discrepancy_note"),
          reconciledBy = rs.getString("reconciled_by"),
          reconciledAt = rs.getTimestamp("reconciled_at")?.toInstant()?.toString(),
        )
      }

      val allergies = queryList(conn, "SELECT * FROM allergies WHERE patient_id = ? ORDER BY recorded_at DESC", patientId) { rs ->
        AllergyDto(
          allergyId = rs.getString("allergy_id"),
          patientId = rs.getString("patient_id"),
          substance = rs.getString("substance"),
          reaction = rs.getString("reaction"),
          verificationStatus = rs.getString("verification_status"),
          severity = rs.getString("severity"),
          provenance = rs.getString("provenance"),
          recordedBy = rs.getString("recorded_by"),
          recordedAt = rs.getTimestamp("recorded_at").toInstant().toString(),
        )
      }

      val observations = queryList(conn, "SELECT * FROM observations WHERE patient_id = ? ORDER BY observed_at DESC", patientId) { rs ->
        val rawVal = rs.getObject("value_numeric")
        ObservationDto(
          observationId = rs.getString("observation_id"),
          patientId = rs.getString("patient_id"),
          encounterId = rs.getString("encounter_id"),
          name = rs.getString("name"),
          valueNumeric = (rawVal as? Number)?.toDouble(),
          unit = rs.getString("unit"),
          referenceInterval = rs.getString("reference_interval"),
          abnormalFlag = rs.getString("abnormal_flag"),
          missingReason = rs.getString("missing_reason"),
          observedAt = rs.getTimestamp("observed_at").toInstant().toString(),
          sourceSystem = rs.getString("source_system"),
          verificationStatus = rs.getString("verification_status"),
        )
      }

      val results = queryList(
        conn,
        """
        SELECT r.*, p.full_name AS patient_name
        FROM diagnostic_results r
        JOIN patients p ON p.patient_id = r.patient_id
        WHERE r.patient_id = ?
        ORDER BY r.reported_at DESC
        """.trimIndent(),
        patientId,
      ) { rs -> mapResult(rs) }

      val notes = queryList(
        conn,
        """
        SELECT n.*, p.full_name AS patient_name
        FROM clinical_notes n
        JOIN patients p ON p.patient_id = n.patient_id
        WHERE n.patient_id = ?
        ORDER BY n.updated_at DESC
        """.trimIndent(),
        patientId,
      ) { rs -> mapNote(conn, rs) }

      val plans = queryList(conn, "SELECT * FROM care_plans WHERE patient_id = ? ORDER BY updated_at DESC", patientId) { rs ->
        CarePlanDto(
          planId = rs.getString("plan_id"),
          patientId = rs.getString("patient_id"),
          title = rs.getString("title"),
          goalsSummary = rs.getString("goals_summary"),
          status = rs.getString("status"),
          ownerName = rs.getString("owner_name"),
          updatedAt = rs.getTimestamp("updated_at").toInstant().toString(),
          sourceSystem = rs.getString("source_system"),
        )
      }

      val docs = queryList(conn, "SELECT * FROM documents_attachments WHERE patient_id = ? ORDER BY created_at DESC", patientId) { rs ->
        mapDocument(rs)
      }

      val tasks = queryList(
        conn,
        """
        SELECT t.*, p.full_name AS patient_name
        FROM follow_up_tasks t
        JOIN patients p ON p.patient_id = t.patient_id
        WHERE t.patient_id = ?
        ORDER BY t.due_at ASC
        """.trimIndent(),
        patientId,
      ) { rs -> mapTask(rs) }

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "VIEW_PATIENT_OVERVIEW",
        resourceType = "PATIENT",
        resourceId = patientId,
        patientId = patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = if (emergency) "Emergency break-glass access active" else null,
        emergencyAccess = emergency,
      )

      PatientOverviewDto(
        patient = patient,
        activeProblems = problems,
        relevantHistory = history,
        medications = medications,
        allergies = allergies,
        recentObservations = observations,
        diagnosticResults = results,
        previousNotes = notes,
        carePlans = plans,
        documents = docs,
        outstandingTasks = tasks,
        serverTimestamp = Instant.now().toString(),
      )
    }
  }

  fun saveNoteDraft(principal: AuthenticatedPrincipal, req: SaveNoteDraftRequest): ClinicalNoteDto {
    auth.requireWriteRole(principal, "SAVE_NOTE_DRAFT")
    return db.inTransaction { conn ->
      val emergency = auth.verifyPatientAccess(conn, principal, req.patientId, "SAVE_NOTE_DRAFT")
      req.idempotencyKey?.let { key ->
        findIdempotentBody(conn, key, principal.clinicianId, "SAVE_NOTE_DRAFT")?.let { cached ->
          return@inTransaction json.decodeFromString<ClinicalNoteDto>(cached)
        }
      }

      val now = Instant.now()
      val noteId = req.noteId ?: "NOTE-${UUID.randomUUID().toString().take(8)}"
      val existingStmt = conn.prepareStatement("SELECT status, version, patient_id FROM clinical_notes WHERE note_id = ?")
      existingStmt.setString(1, noteId)
      val existingRs = existingStmt.executeQuery()

      val newVersion: Long
      if (existingRs.next()) {
        val currentStatus = existingRs.getString("status")
        val currentVersion = existingRs.getLong("version")
        val currentPatient = existingRs.getString("patient_id")
        if (currentPatient != req.patientId) {
          throw ClinicalBadRequestException("Note $noteId belongs to patient $currentPatient, refusing cross-patient write", "PATIENT_MISMATCH")
        }
        if (currentStatus != "DRAFT") {
          throw ClinicalConflictException("Signed or entered-in-error notes are immutable. Use amendment or addendum.", "NOTE_IMMUTABLE")
        }
        if (currentVersion != req.expectedVersion) {
          throw ClinicalConflictException(
            "Optimistic concurrency conflict: server version is $currentVersion, client sent ${req.expectedVersion}. Review changes before saving.",
            "VERSION_CONFLICT",
          )
        }
        newVersion = currentVersion + 1L
        val upd = conn.prepareStatement(
          """
          UPDATE clinical_notes
          SET template_type = ?, title = ?, sections_json = ?, free_text = ?, copied_attributions_json = ?,
              version = ?, updated_at = ?
          WHERE note_id = ? AND version = ?
          """.trimIndent()
        )
        upd.setString(1, req.templateType)
        upd.setString(2, req.title)
        upd.setString(3, json.encodeToString(req.sections))
        upd.setString(4, req.freeText)
        upd.setString(5, json.encodeToString(req.copiedAttributions))
        upd.setLong(6, newVersion)
        upd.setTimestamp(7, Timestamp.from(now))
        upd.setString(8, noteId)
        upd.setLong(9, req.expectedVersion)
        if (upd.executeUpdate() == 0) {
          throw ClinicalConflictException("Concurrent modification detected while saving draft", "VERSION_CONFLICT")
        }
      } else {
        newVersion = 1L
        val ins = conn.prepareStatement(
          """
          INSERT INTO clinical_notes (
            note_id, patient_id, encounter_id, template_type, title, sections_json, free_text,
            copied_attributions_json, status, version, author_id, author_name, created_at, updated_at,
            signed_at, signed_by_id, signed_by_name, content_hash, entered_in_error_reason,
            entered_in_error_by, entered_in_error_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
          """.trimIndent()
        )
        ins.setString(1, noteId)
        ins.setString(2, req.patientId)
        ins.setString(3, req.encounterId)
        ins.setString(4, req.templateType)
        ins.setString(5, req.title)
        ins.setString(6, json.encodeToString(req.sections))
        ins.setString(7, req.freeText)
        ins.setString(8, json.encodeToString(req.copiedAttributions))
        ins.setLong(9, newVersion)
        ins.setString(10, principal.clinicianId)
        ins.setString(11, principal.displayName)
        ins.setTimestamp(12, Timestamp.from(now))
        ins.setTimestamp(13, Timestamp.from(now))
        ins.executeUpdate()
      }

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "EDIT_NOTE_DRAFT",
        resourceType = "CLINICAL_NOTE",
        resourceId = noteId,
        patientId = req.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = null,
        emergencyAccess = emergency,
        metadataJson = """{"version":$newVersion}""",
      )

      val saved = loadNoteById(conn, noteId)
      req.idempotencyKey?.let { key ->
        saveIdempotentBody(conn, key, principal.clinicianId, "SAVE_NOTE_DRAFT", 200, json.encodeToString(saved))
      }
      saved
    }
  }

  fun signNote(principal: AuthenticatedPrincipal, noteId: String, req: SignNoteRequest): ClinicalNoteDto {
    auth.requireSigningRole(principal)
    if (req.idempotencyKey.isBlank()) {
      throw ClinicalBadRequestException("idempotencyKey is required when signing a clinical note", "IDEMPOTENCY_REQUIRED")
    }
    return db.inTransaction { conn ->
      findIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "SIGN_NOTE:$noteId")?.let { cached ->
        return@inTransaction json.decodeFromString<ClinicalNoteDto>(cached)
      }

      val note = loadNoteById(conn, noteId)
      val emergency = auth.verifyPatientAccess(conn, principal, note.patientId, "SIGN_NOTE")
      if (req.confirmedPatientId != note.patientId) {
        throw ClinicalBadRequestException("Explicit patient confirmation mismatch for signing", "PATIENT_CONFIRMATION_MISMATCH")
      }
      if (note.status != "DRAFT") {
        throw ClinicalConflictException("Note $noteId is already ${note.status} and cannot be re-signed", "NOTE_NOT_DRAFT")
      }
      if (note.version != req.expectedVersion) {
        throw ClinicalConflictException(
          "Cannot sign stale note version: server=${note.version}, expected=${req.expectedVersion}",
          "VERSION_CONFLICT",
        )
      }

      val now = Instant.now()
      val canonicalBody = "${note.noteId}|${note.patientId}|${note.title}|${json.encodeToString(note.sections)}|${note.freeText}"
      val contentHash = "sha256:${auth.sha256(canonicalBody)}"
      val newVersion = note.version + 1L

      val upd = conn.prepareStatement(
        """
        UPDATE clinical_notes
        SET status = 'SIGNED', version = ?, updated_at = ?, signed_at = ?, signed_by_id = ?, signed_by_name = ?, content_hash = ?
        WHERE note_id = ? AND version = ? AND status = 'DRAFT'
        """.trimIndent()
      )
      upd.setLong(1, newVersion)
      upd.setTimestamp(2, Timestamp.from(now))
      upd.setTimestamp(3, Timestamp.from(now))
      upd.setString(4, principal.clinicianId)
      upd.setString(5, principal.displayName)
      upd.setString(6, contentHash)
      upd.setString(7, noteId)
      upd.setLong(8, req.expectedVersion)
      if (upd.executeUpdate() == 0) {
        throw ClinicalConflictException("Concurrent update prevented atomic signature", "VERSION_CONFLICT")
      }

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "SIGN_NOTE",
        resourceType = "CLINICAL_NOTE",
        resourceId = noteId,
        patientId = note.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = "Signed after preview & patient confirmation",
        emergencyAccess = emergency,
        metadataJson = """{"version":$newVersion,"contentHash":"$contentHash"}""",
      )

      val signed = loadNoteById(conn, noteId)
      saveIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "SIGN_NOTE:$noteId", 200, json.encodeToString(signed))
      signed
    }
  }

  fun addAmendment(principal: AuthenticatedPrincipal, noteId: String, req: CreateAmendmentRequest): ClinicalNoteDto {
    auth.requireWriteRole(principal, "ADD_AMENDMENT")
    if (req.bodyText.isBlank() || req.reason.isBlank()) {
      throw ClinicalBadRequestException("Amendment text and clinical reason are required", "INVALID_AMENDMENT")
    }
    return db.inTransaction { conn ->
      findIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "ADD_AMENDMENT:$noteId")?.let { cached ->
        return@inTransaction json.decodeFromString<ClinicalNoteDto>(cached)
      }
      val note = loadNoteById(conn, noteId)
      val emergency = auth.verifyPatientAccess(conn, principal, note.patientId, "ADD_AMENDMENT")
      if (req.confirmedPatientId != note.patientId) {
        throw ClinicalBadRequestException("Patient confirmation mismatch", "PATIENT_CONFIRMATION_MISMATCH")
      }
      if (note.status != "SIGNED") {
        throw ClinicalConflictException("Amendments/addenda may only be linked to SIGNED notes", "NOTE_NOT_SIGNED")
      }
      val now = Instant.now()
      val amendmentId = "AMD-${UUID.randomUUID().toString().take(8)}"
      val hash = "sha256:${auth.sha256("$noteId|${req.amendmentType}|${req.bodyText}|${req.reason}")}"
      val ins = conn.prepareStatement(
        """
        INSERT INTO note_amendments (amendment_id, note_id, patient_id, amendment_type, body_text, reason, author_id, author_name, created_at, content_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimIndent()
      )
      ins.setString(1, amendmentId)
      ins.setString(2, noteId)
      ins.setString(3, note.patientId)
      ins.setString(4, req.amendmentType)
      ins.setString(5, req.bodyText.trim())
      ins.setString(6, req.reason.trim())
      ins.setString(7, principal.clinicianId)
      ins.setString(8, principal.displayName)
      ins.setTimestamp(9, Timestamp.from(now))
      ins.setString(10, hash)
      ins.executeUpdate()

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "ADD_NOTE_AMENDMENT",
        resourceType = "NOTE_AMENDMENT",
        resourceId = amendmentId,
        patientId = note.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = req.reason.trim(),
        emergencyAccess = emergency,
        metadataJson = """{"noteId":"$noteId","type":"${req.amendmentType}"}""",
      )

      val updated = loadNoteById(conn, noteId)
      saveIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "ADD_AMENDMENT:$noteId", 200, json.encodeToString(updated))
      updated
    }
  }

  fun markEnteredInError(principal: AuthenticatedPrincipal, noteId: String, req: EnteredInErrorRequest): ClinicalNoteDto {
    auth.requireSigningRole(principal)
    if (req.reason.trim().length < 6) {
      throw ClinicalBadRequestException("Entered-in-error requires an explicit reason", "REASON_REQUIRED")
    }
    return db.inTransaction { conn ->
      findIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "ENTERED_IN_ERROR:$noteId")?.let { cached ->
        return@inTransaction json.decodeFromString<ClinicalNoteDto>(cached)
      }
      val note = loadNoteById(conn, noteId)
      val emergency = auth.verifyPatientAccess(conn, principal, note.patientId, "ENTERED_IN_ERROR")
      if (req.confirmedPatientId != note.patientId) {
        throw ClinicalBadRequestException("Patient confirmation mismatch", "PATIENT_CONFIRMATION_MISMATCH")
      }
      if (note.status == "ENTERED_IN_ERROR") {
        return@inTransaction note
      }
      val now = Instant.now()
      val newVersion = note.version + 1L
      val upd = conn.prepareStatement(
        """
        UPDATE clinical_notes
        SET status = 'ENTERED_IN_ERROR', version = ?, updated_at = ?, entered_in_error_reason = ?, entered_in_error_by = ?, entered_in_error_at = ?
        WHERE note_id = ?
        """.trimIndent()
      )
      upd.setLong(1, newVersion)
      upd.setTimestamp(2, Timestamp.from(now))
      upd.setString(3, req.reason.trim())
      upd.setString(4, principal.displayName)
      upd.setTimestamp(5, Timestamp.from(now))
      upd.setString(6, noteId)
      upd.executeUpdate()

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "MARK_NOTE_ENTERED_IN_ERROR",
        resourceType = "CLINICAL_NOTE",
        resourceId = noteId,
        patientId = note.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = req.reason.trim(),
        emergencyAccess = emergency,
        metadataJson = """{"retainedHistory":true,"version":$newVersion}""",
      )

      val updated = loadNoteById(conn, noteId)
      saveIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "ENTERED_IN_ERROR:$noteId", 200, json.encodeToString(updated))
      updated
    }
  }

  fun updateResultWorkflow(
    principal: AuthenticatedPrincipal,
    resultId: String,
    req: UpdateResultWorkflowRequest,
  ): DiagnosticResultDto {
    if (req.targetState != "VIEWED") {
      auth.requireWriteRole(principal, "UPDATE_RESULT_WORKFLOW")
    }
    val validStates = listOf("AVAILABLE", "VIEWED", "ACKNOWLEDGED", "FOLLOW_UP_ASSIGNED", "ACTION_COMPLETED")
    if (req.targetState !in validStates) {
      throw ClinicalBadRequestException("Invalid result workflow state ${req.targetState}", "INVALID_WORKFLOW_STATE")
    }
    return db.inTransaction { conn ->
      val stmt = conn.prepareStatement(
        "SELECT r.*, p.full_name AS patient_name FROM diagnostic_results r JOIN patients p ON p.patient_id = r.patient_id WHERE r.result_id = ?"
      )
      stmt.setString(1, resultId)
      val rs = stmt.executeQuery()
      if (!rs.next()) {
        throw ClinicalNotFoundException("Result $resultId not found", "RESULT_NOT_FOUND")
      }
      val current = mapResult(rs)
      val emergency = auth.verifyPatientAccess(conn, principal, current.patientId, "RESULT_WORKFLOW_${req.targetState}")
      if (req.confirmedPatientId != current.patientId) {
        throw ClinicalBadRequestException("Patient confirmation mismatch for result action", "PATIENT_CONFIRMATION_MISMATCH")
      }
      val now = Instant.now()
      val upd = conn.prepareStatement(
        """
        UPDATE diagnostic_results
        SET workflow_state = ?, reviewed_by = COALESCE(?, reviewed_by), reviewed_at = COALESCE(?, reviewed_at),
            follow_up_task_id = COALESCE(?, follow_up_task_id)
        WHERE result_id = ?
        """.trimIndent()
      )
      upd.setString(1, req.targetState)
      val ackActor = if (req.targetState in listOf("ACKNOWLEDGED", "FOLLOW_UP_ASSIGNED", "ACTION_COMPLETED")) principal.displayName else null
      val ackTime = if (ackActor != null) Timestamp.from(now) else null
      upd.setString(2, ackActor)
      upd.setTimestamp(3, ackTime)
      upd.setString(4, req.followUpTaskId)
      upd.setString(5, resultId)
      upd.executeUpdate()

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "RESULT_${req.targetState}",
        resourceType = "DIAGNOSTIC_RESULT",
        resourceId = resultId,
        patientId = current.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = if (current.resultStatus == "CORRECTED") "Corrected result explicit review step" else null,
        emergencyAccess = emergency,
        metadataJson = """{"previousState":"${current.workflowState}","newState":"${req.targetState}"}""",
      )

      val refreshed = conn.prepareStatement(
        "SELECT r.*, p.full_name AS patient_name FROM diagnostic_results r JOIN patients p ON p.patient_id = r.patient_id WHERE r.result_id = ?"
      )
      refreshed.setString(1, resultId)
      val r2 = refreshed.executeQuery()
      r2.next()
      mapResult(r2)
    }
  }

  fun reconcileMedication(
    principal: AuthenticatedPrincipal,
    medicationId: String,
    req: ReconcileMedicationRequest,
  ): MedicationDto {
    auth.requireWriteRole(principal, "RECONCILE_MEDICATION")
    return db.inTransaction { conn ->
      val stmt = conn.prepareStatement("SELECT * FROM medications WHERE medication_id = ?")
      stmt.setString(1, medicationId)
      val rs = stmt.executeQuery()
      if (!rs.next()) {
        throw ClinicalNotFoundException("Medication $medicationId not found", "MEDICATION_NOT_FOUND")
      }
      val patientId = rs.getString("patient_id")
      val emergency = auth.verifyPatientAccess(conn, principal, patientId, "RECONCILE_MEDICATION")
      val now = Instant.now()
      val isDiscrepancy = req.action == "FLAG_DISCREPANCY"
      val upd = conn.prepareStatement(
        """
        UPDATE medications
        SET discrepancy_flag = ?, discrepancy_note = ?, reconciled_by = ?, reconciled_at = ?
        WHERE medication_id = ?
        """.trimIndent()
      )
      upd.setBoolean(1, isDiscrepancy)
      upd.setString(2, req.discrepancyNote ?: if (!isDiscrepancy) "Reconciled against inpatient chart & patient interview" else "Discrepancy flagged")
      upd.setString(3, principal.displayName)
      upd.setTimestamp(4, Timestamp.from(now))
      upd.setString(5, medicationId)
      upd.executeUpdate()

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "RECONCILE_MEDICATION",
        resourceType = "MEDICATION",
        resourceId = medicationId,
        patientId = patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = req.action,
        emergencyAccess = emergency,
      )

      val refreshed = conn.prepareStatement("SELECT * FROM medications WHERE medication_id = ?")
      refreshed.setString(1, medicationId)
      val r2 = refreshed.executeQuery()
      r2.next()
      MedicationDto(
        medicationId = r2.getString("medication_id"),
        patientId = r2.getString("patient_id"),
        name = r2.getString("name"),
        strength = r2.getString("strength"),
        dose = r2.getString("dose"),
        route = r2.getString("route"),
        frequency = r2.getString("frequency"),
        recordCategory = r2.getString("record_category"),
        status = r2.getString("status"),
        startDate = r2.getString("start_date"),
        endDate = r2.getString("end_date"),
        sourceSystem = r2.getString("source_system"),
        authorName = r2.getString("author_name"),
        discrepancyFlag = r2.getBoolean("discrepancy_flag"),
        discrepancyNote = r2.getString("discrepancy_note"),
        reconciledBy = r2.getString("reconciled_by"),
        reconciledAt = r2.getTimestamp("reconciled_at")?.toInstant()?.toString(),
      )
    }
  }

  fun createTask(principal: AuthenticatedPrincipal, req: CreateTaskRequest): FollowUpTaskDto {
    auth.requireWriteRole(principal, "CREATE_TASK")
    return db.inTransaction { conn ->
      req.idempotencyKey?.let { key ->
        findIdempotentBody(conn, key, principal.clinicianId, "CREATE_TASK")?.let { cached ->
          return@inTransaction json.decodeFromString<FollowUpTaskDto>(cached)
        }
      }
      val emergency = auth.verifyPatientAccess(conn, principal, req.patientId, "CREATE_TASK")
      val taskId = "TSK-${UUID.randomUUID().toString().take(8)}"
      val now = Instant.now()
      val ins = conn.prepareStatement(
        """
        INSERT INTO follow_up_tasks (
          task_id, patient_id, encounter_id, linked_result_id, title, description,
          owner_id, owner_name, priority, due_at, status, completion_evidence,
          completed_at, completed_by, created_by, created_at, version
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', NULL, NULL, NULL, ?, ?, 1)
        """.trimIndent()
      )
      ins.setString(1, taskId)
      ins.setString(2, req.patientId)
      ins.setString(3, req.encounterId)
      ins.setString(4, req.linkedResultId)
      ins.setString(5, req.title.trim())
      ins.setString(6, req.description.trim())
      ins.setString(7, principal.clinicianId)
      ins.setString(8, req.ownerName.trim())
      ins.setString(9, req.priority)
      ins.setTimestamp(10, Timestamp.from(Instant.parse(req.dueAt)))
      ins.setString(11, principal.displayName)
      ins.setTimestamp(12, Timestamp.from(now))
      ins.executeUpdate()

      if (!req.linkedResultId.isNullOrBlank()) {
        val rUpd = conn.prepareStatement(
          "UPDATE diagnostic_results SET workflow_state = 'FOLLOW_UP_ASSIGNED', follow_up_task_id = ? WHERE result_id = ? AND patient_id = ?"
        )
        rUpd.setString(1, taskId)
        rUpd.setString(2, req.linkedResultId)
        rUpd.setString(3, req.patientId)
        rUpd.executeUpdate()
      }

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "CREATE_FOLLOW_UP_TASK",
        resourceType = "FOLLOW_UP_TASK",
        resourceId = taskId,
        patientId = req.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = null,
        emergencyAccess = emergency,
      )

      val created = loadTaskById(conn, taskId)
      req.idempotencyKey?.let { key ->
        saveIdempotentBody(conn, key, principal.clinicianId, "CREATE_TASK", 200, json.encodeToString(created))
      }
      created
    }
  }

  fun completeTask(principal: AuthenticatedPrincipal, taskId: String, req: CompleteTaskRequest): FollowUpTaskDto {
    auth.requireWriteRole(principal, "COMPLETE_TASK")
    if (req.completionEvidence.trim().length < 4) {
      throw ClinicalBadRequestException("Completion evidence is required to close a clinical task", "EVIDENCE_REQUIRED")
    }
    return db.inTransaction { conn ->
      findIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "COMPLETE_TASK:$taskId")?.let { cached ->
        return@inTransaction json.decodeFromString<FollowUpTaskDto>(cached)
      }
      val current = loadTaskById(conn, taskId)
      val emergency = auth.verifyPatientAccess(conn, principal, current.patientId, "COMPLETE_TASK")
      if (req.confirmedPatientId != current.patientId) {
        throw ClinicalBadRequestException("Patient confirmation mismatch", "PATIENT_CONFIRMATION_MISMATCH")
      }
      if (current.version != req.expectedVersion) {
        throw ClinicalConflictException("Task version conflict", "VERSION_CONFLICT")
      }
      val now = Instant.now()
      val newVersion = current.version + 1L
      val upd = conn.prepareStatement(
        """
        UPDATE follow_up_tasks
        SET status = 'COMPLETED', completion_evidence = ?, completed_at = ?, completed_by = ?, version = ?
        WHERE task_id = ? AND version = ?
        """.trimIndent()
      )
      upd.setString(1, req.completionEvidence.trim())
      upd.setTimestamp(2, Timestamp.from(now))
      upd.setString(3, principal.displayName)
      upd.setLong(4, newVersion)
      upd.setString(5, taskId)
      upd.setLong(6, req.expectedVersion)
      if (upd.executeUpdate() == 0) {
        throw ClinicalConflictException("Task updated concurrently", "VERSION_CONFLICT")
      }

      if (!current.linkedResultId.isNullOrBlank()) {
        val rUpd = conn.prepareStatement(
          "UPDATE diagnostic_results SET workflow_state = 'ACTION_COMPLETED' WHERE result_id = ? AND patient_id = ?"
        )
        rUpd.setString(1, current.linkedResultId)
        rUpd.setString(2, current.patientId)
        rUpd.executeUpdate()
      }

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "COMPLETE_FOLLOW_UP_TASK",
        resourceType = "FOLLOW_UP_TASK",
        resourceId = taskId,
        patientId = current.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = req.completionEvidence.trim(),
        emergencyAccess = emergency,
      )

      val completed = loadTaskById(conn, taskId)
      saveIdempotentBody(conn, req.idempotencyKey, principal.clinicianId, "COMPLETE_TASK:$taskId", 200, json.encodeToString(completed))
      completed
    }
  }

  fun uploadDocument(principal: AuthenticatedPrincipal, req: UploadDocumentRequest): ClinicalDocumentDto {
    auth.requireWriteRole(principal, "UPLOAD_DOCUMENT")
    if (req.isClinicalPhoto && !req.consentRecorded) {
      throw ClinicalBadRequestException("Clinical photographs require recorded patient consent", "CONSENT_REQUIRED")
    }
    return db.inTransaction { conn ->
      val emergency = auth.verifyPatientAccess(conn, principal, req.confirmedPatientId, "UPLOAD_DOCUMENT")
      val docId = "DOC-${UUID.randomUUID().toString().take(8)}"
      val ext = when {
        req.mimeType.contains("png") -> "png"
        req.mimeType.contains("jpeg") || req.mimeType.contains("jpg") -> "jpg"
        else -> "txt"
      }
      val stored = storage.storeProtectedBytes(req.confirmedPatientId, docId, ext, req.contentBase64)
      val now = Instant.now()
      val ins = conn.prepareStatement(
        """
        INSERT INTO documents_attachments (
          document_id, patient_id, encounter_id, title, doc_type, mime_type, object_key,
          is_clinical_photo, consent_recorded, consent_note, author_name, original_preserved,
          derived_label, created_at, source_system
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE, ?, ?, ?)
        """.trimIndent()
      )
      ins.setString(1, docId)
      ins.setString(2, req.confirmedPatientId)
      ins.setString(3, req.encounterId)
      ins.setString(4, req.title.trim())
      ins.setString(5, req.docType)
      ins.setString(6, req.mimeType)
      ins.setString(7, stored.objectKey)
      ins.setBoolean(8, req.isClinicalPhoto)
      ins.setBoolean(9, req.consentRecorded)
      ins.setString(10, req.consentNote)
      ins.setString(11, principal.displayName)
      ins.setString(12, req.derivedLabel)
      ins.setTimestamp(13, Timestamp.from(now))
      ins.setString(14, "Aureom Protected Mobile Capture")
      ins.executeUpdate()

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "UPLOAD_DOCUMENT",
        resourceType = "DOCUMENT",
        resourceId = docId,
        patientId = req.confirmedPatientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = if (req.isClinicalPhoto) "Clinical photo with recorded consent" else null,
        emergencyAccess = emergency,
        metadataJson = """{"sha256":"${stored.sha256}","originalPreserved":true}""",
      )

      val stmt = conn.prepareStatement("SELECT * FROM documents_attachments WHERE document_id = ?")
      stmt.setString(1, docId)
      val rs = stmt.executeQuery()
      rs.next()
      mapDocument(rs)
    }
  }

  fun downloadDocument(principal: AuthenticatedPrincipal, documentId: String): Pair<ClinicalDocumentDto, ByteArray> {
    return db.inTransaction { conn ->
      val stmt = conn.prepareStatement("SELECT * FROM documents_attachments WHERE document_id = ?")
      stmt.setString(1, documentId)
      val rs = stmt.executeQuery()
      if (!rs.next()) {
        throw ClinicalNotFoundException("Document $documentId not found", "DOCUMENT_NOT_FOUND")
      }
      val doc = mapDocument(rs)
      val emergency = auth.verifyPatientAccess(conn, principal, doc.patientId, "DOWNLOAD_DOCUMENT")
      val bytes = storage.readProtectedBytes(doc.objectKey)
        ?: throw ClinicalNotFoundException("Attachment payload missing from protected storage", "OBJECT_MISSING")

      auth.recordAudit(
        conn = conn,
        actorId = principal.clinicianId,
        actorName = principal.displayName,
        actorRole = principal.role,
        action = "VIEW_DOWNLOAD_DOCUMENT",
        resourceType = "DOCUMENT",
        resourceId = documentId,
        patientId = doc.patientId,
        careContextId = principal.careContextId,
        outcome = "ALLOWED",
        reason = null,
        emergencyAccess = emergency,
      )
      doc to bytes
    }
  }

  fun getAuditLogs(
    principal: AuthenticatedPrincipal,
    patientId: String?,
    page: Int,
    pageSize: Int,
  ): PaginatedResponse<AuditLogDto> {
    return db.inTransaction { conn ->
      if (patientId != null) {
        auth.verifyPatientAccess(conn, principal, patientId, "VIEW_AUDIT_LOG")
      }
      val sql = if (patientId != null) {
        "SELECT * FROM audit_logs WHERE patient_id = ? ORDER BY timestamp DESC"
      } else {
        "SELECT * FROM audit_logs ORDER BY timestamp DESC"
      }
      val stmt = conn.prepareStatement(sql)
      if (patientId != null) stmt.setString(1, patientId)
      val rs = stmt.executeQuery()
      val all = mutableListOf<AuditLogDto>()
      while (rs.next()) {
        all += AuditLogDto(
          auditId = rs.getString("audit_id"),
          timestamp = rs.getTimestamp("timestamp").toInstant().toString(),
          actorId = rs.getString("actor_id"),
          actorName = rs.getString("actor_name"),
          actorRole = rs.getString("actor_role"),
          action = rs.getString("action"),
          resourceType = rs.getString("resource_type"),
          resourceId = rs.getString("resource_id"),
          patientId = rs.getString("patient_id"),
          careContextId = rs.getString("care_context_id"),
          outcome = rs.getString("outcome"),
          reason = rs.getString("reason"),
          emergencyAccess = rs.getBoolean("emergency_access"),
          metadataJson = rs.getString("metadata_json"),
        )
      }
      val safePage = page.coerceAtLeast(1)
      val safeSize = pageSize.coerceIn(1, 100)
      val from = ((safePage - 1) * safeSize).coerceAtMost(all.size)
      val to = (from + safeSize).coerceAtMost(all.size)
      PaginatedResponse(
        items = all.subList(from, to),
        page = safePage,
        pageSize = safeSize,
        totalCount = all.size,
        hasMore = to < all.size,
      )
    }
  }

  private fun queryPatientsForContext(conn: Connection, contextId: String): List<PatientSummaryDto> {
    val stmt = conn.prepareStatement("SELECT * FROM patients WHERE care_context_id = ? ORDER BY full_name ASC")
    stmt.setString(1, contextId)
    val rs = stmt.executeQuery()
    val list = mutableListOf<PatientSummaryDto>()
    while (rs.next()) {
      list += mapPatientSummary(conn, rs, null)
    }
    return list
  }

  private fun mapPatientSummary(conn: Connection, rs: ResultSet, principal: AuthenticatedPrincipal?): PatientSummaryDto {
    val patientId = rs.getString("patient_id")
    val allergyState = rs.getString("allergy_status_state")
    val allergyBadge = when (allergyState) {
      "RECORDED" -> {
        val cStmt = conn.prepareStatement("SELECT COUNT(*) FROM allergies WHERE patient_id = ?")
        cStmt.setString(1, patientId)
        val cRs = cStmt.executeQuery()
        cRs.next()
        "${cRs.getInt(1)} allergy record(s)"
      }
      "EXPLICIT_NO_KNOWN_ALLERGIES" -> "No known allergies (explicitly documented)"
      "NOT_ASSESSED" -> "Allergies not assessed"
      "UNKNOWN" -> "Allergy status unknown"
      "UNAVAILABLE" -> "Allergy information unavailable"
      else -> "Allergies not assessed"
    }
    val ctx = rs.getString("care_context_id")
    val inContext = principal == null || ctx == principal.careContextId
    var emergencyActive = false
    if (!inContext && principal != null) {
      val gStmt = conn.prepareStatement(
        "SELECT 1 FROM emergency_access_grants WHERE clinician_id = ? AND patient_id = ? AND expires_at > ?"
      )
      gStmt.setString(1, principal.clinicianId)
      gStmt.setString(2, patientId)
      gStmt.setTimestamp(3, Timestamp.from(Instant.now()))
      emergencyActive = gStmt.executeQuery().next()
    }
    return PatientSummaryDto(
      patientId = patientId,
      nhsNumber = rs.getString("nhs_number"),
      externalMrn = rs.getString("external_mrn"),
      identityVerificationStatus = rs.getString("identity_verification_status"),
      matchConfidence = rs.getString("match_confidence"),
      fullName = rs.getString("full_name"),
      preferredName = rs.getString("preferred_name"),
      dateOfBirth = rs.getString("date_of_birth"),
      sexAtBirth = rs.getString("sex_at_birth"),
      careContextId = ctx,
      assignedClinicianId = rs.getString("assigned_clinician_id"),
      currentEncounterId = rs.getString("current_encounter_id"),
      currentEncounterLabel = rs.getString("current_encounter_label"),
      careTeamSummary = rs.getString("care_team_summary"),
      allergyStatusState = allergyState,
      allergyBadgeSummary = allergyBadge,
      hasAccessInCurrentContext = inContext || emergencyActive,
      emergencyAccessActive = emergencyActive,
      updatedAt = rs.getTimestamp("updated_at").toInstant().toString(),
    )
  }

  private fun loadNoteById(conn: Connection, noteId: String): ClinicalNoteDto {
    val stmt = conn.prepareStatement(
      "SELECT n.*, p.full_name AS patient_name FROM clinical_notes n JOIN patients p ON p.patient_id = n.patient_id WHERE n.note_id = ?"
    )
    stmt.setString(1, noteId)
    val rs = stmt.executeQuery()
    if (!rs.next()) throw ClinicalNotFoundException("Note $noteId not found", "NOTE_NOT_FOUND")
    return mapNote(conn, rs)
  }

  private fun mapNote(conn: Connection, rs: ResultSet): ClinicalNoteDto {
    val noteId = rs.getString("note_id")
    val sections: List<NoteSectionDto> = json.decodeFromString(rs.getString("sections_json"))
    val attributions: List<CopiedAttributionDto> = json.decodeFromString(rs.getString("copied_attributions_json"))
    val amendments = queryList(conn, "SELECT * FROM note_amendments WHERE note_id = ? ORDER BY created_at ASC", noteId) { aRs ->
      NoteAmendmentDto(
        amendmentId = aRs.getString("amendment_id"),
        noteId = aRs.getString("note_id"),
        patientId = aRs.getString("patient_id"),
        amendmentType = aRs.getString("amendment_type"),
        bodyText = aRs.getString("body_text"),
        reason = aRs.getString("reason"),
        authorId = aRs.getString("author_id"),
        authorName = aRs.getString("author_name"),
        createdAt = aRs.getTimestamp("created_at").toInstant().toString(),
        contentHash = aRs.getString("content_hash"),
      )
    }
    return ClinicalNoteDto(
      noteId = noteId,
      patientId = rs.getString("patient_id"),
      patientName = rs.getString("patient_name"),
      encounterId = rs.getString("encounter_id"),
      templateType = rs.getString("template_type"),
      title = rs.getString("title"),
      sections = sections,
      freeText = rs.getString("free_text"),
      copiedAttributions = attributions,
      status = rs.getString("status"),
      version = rs.getLong("version"),
      authorId = rs.getString("author_id"),
      authorName = rs.getString("author_name"),
      createdAt = rs.getTimestamp("created_at").toInstant().toString(),
      updatedAt = rs.getTimestamp("updated_at").toInstant().toString(),
      signedAt = rs.getTimestamp("signed_at")?.toInstant()?.toString(),
      signedById = rs.getString("signed_by_id"),
      signedByName = rs.getString("signed_by_name"),
      contentHash = rs.getString("content_hash"),
      enteredInErrorReason = rs.getString("entered_in_error_reason"),
      enteredInErrorBy = rs.getString("entered_in_error_by"),
      enteredInErrorAt = rs.getTimestamp("entered_in_error_at")?.toInstant()?.toString(),
      amendments = amendments,
    )
  }

  private fun mapResult(rs: ResultSet): DiagnosticResultDto = DiagnosticResultDto(
    resultId = rs.getString("result_id"),
    patientId = rs.getString("patient_id"),
    patientName = rs.getString("patient_name"),
    encounterId = rs.getString("encounter_id"),
    testName = rs.getString("test_name"),
    category = rs.getString("category"),
    valueText = rs.getString("value_text"),
    unit = rs.getString("unit"),
    referenceInterval = rs.getString("reference_interval"),
    abnormalFlag = rs.getString("abnormal_flag"),
    resultStatus = rs.getString("result_status"),
    workflowState = rs.getString("workflow_state"),
    supersedesResultId = rs.getString("supersedes_result_id"),
    correctionReason = rs.getString("correction_reason"),
    reportedAt = rs.getTimestamp("reported_at").toInstant().toString(),
    sourceSystem = rs.getString("source_system"),
    verificationStatus = rs.getString("verification_status"),
    reviewedBy = rs.getString("reviewed_by"),
    reviewedAt = rs.getTimestamp("reviewed_at")?.toInstant()?.toString(),
    followUpTaskId = rs.getString("follow_up_task_id"),
  )

  private fun loadTaskById(conn: Connection, taskId: String): FollowUpTaskDto {
    val stmt = conn.prepareStatement(
      "SELECT t.*, p.full_name AS patient_name FROM follow_up_tasks t JOIN patients p ON p.patient_id = t.patient_id WHERE t.task_id = ?"
    )
    stmt.setString(1, taskId)
    val rs = stmt.executeQuery()
    if (!rs.next()) throw ClinicalNotFoundException("Task $taskId not found", "TASK_NOT_FOUND")
    return mapTask(rs)
  }

  private fun mapTask(rs: ResultSet): FollowUpTaskDto = FollowUpTaskDto(
    taskId = rs.getString("task_id"),
    patientId = rs.getString("patient_id"),
    patientName = rs.getString("patient_name"),
    encounterId = rs.getString("encounter_id"),
    linkedResultId = rs.getString("linked_result_id"),
    title = rs.getString("title"),
    description = rs.getString("description"),
    ownerId = rs.getString("owner_id"),
    ownerName = rs.getString("owner_name"),
    priority = rs.getString("priority"),
    dueAt = rs.getTimestamp("due_at").toInstant().toString(),
    status = rs.getString("status"),
    completionEvidence = rs.getString("completion_evidence"),
    completedAt = rs.getTimestamp("completed_at")?.toInstant()?.toString(),
    completedBy = rs.getString("completed_by"),
    createdBy = rs.getString("created_by"),
    createdAt = rs.getTimestamp("created_at").toInstant().toString(),
    version = rs.getLong("version"),
  )

  private fun mapDocument(rs: ResultSet): ClinicalDocumentDto = ClinicalDocumentDto(
    documentId = rs.getString("document_id"),
    patientId = rs.getString("patient_id"),
    encounterId = rs.getString("encounter_id"),
    title = rs.getString("title"),
    docType = rs.getString("doc_type"),
    mimeType = rs.getString("mime_type"),
    objectKey = rs.getString("object_key"),
    isClinicalPhoto = rs.getBoolean("is_clinical_photo"),
    consentRecorded = rs.getBoolean("consent_recorded"),
    consentNote = rs.getString("consent_note"),
    authorName = rs.getString("author_name"),
    originalPreserved = rs.getBoolean("original_preserved"),
    derivedLabel = rs.getString("derived_label"),
    createdAt = rs.getTimestamp("created_at").toInstant().toString(),
    sourceSystem = rs.getString("source_system"),
  )

  private fun <T> queryList(conn: Connection, sql: String, param: String, mapper: (ResultSet) -> T): List<T> {
    val stmt = conn.prepareStatement(sql)
    stmt.setString(1, param)
    val rs = stmt.executeQuery()
    val list = mutableListOf<T>()
    while (rs.next()) list += mapper(rs)
    return list
  }

  private fun findIdempotentBody(conn: Connection, key: String, actorId: String, endpoint: String): String? {
    val stmt = conn.prepareStatement(
      "SELECT response_body FROM idempotency_keys WHERE idempotency_key = ? AND actor_id = ? AND endpoint = ?"
    )
    stmt.setString(1, key)
    stmt.setString(2, actorId)
    stmt.setString(3, endpoint)
    val rs = stmt.executeQuery()
    return if (rs.next()) rs.getString("response_body") else null
  }

  private fun saveIdempotentBody(
    conn: Connection,
    key: String,
    actorId: String,
    endpoint: String,
    status: Int,
    body: String,
  ) {
    val stmt = conn.prepareStatement(
      "INSERT INTO idempotency_keys (idempotency_key, actor_id, endpoint, response_status, response_body, created_at) VALUES (?, ?, ?, ?, ?, ?)"
    )
    stmt.setString(1, key)
    stmt.setString(2, actorId)
    stmt.setString(3, endpoint)
    stmt.setInt(4, status)
    stmt.setString(5, body)
    stmt.setTimestamp(6, Timestamp.from(Instant.now()))
    stmt.executeUpdate()
  }
}
