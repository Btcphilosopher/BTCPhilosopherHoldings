-- Aureom Clinical PostgreSQL Initial Schema (V1)
-- Independent prototype schema for synthetic clinical demonstration records.

CREATE TABLE IF NOT EXISTS care_contexts (
    context_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    ward_or_clinic VARCHAR(160) NOT NULL,
    facility_name VARCHAR(160) NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    clinician_id VARCHAR(64) PRIMARY KEY,
    username VARCHAR(120) UNIQUE NOT NULL,
    display_name VARCHAR(160) NOT NULL,
    role VARCHAR(64) NOT NULL,
    specialty VARCHAR(120) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    oidc_subject VARCHAR(160) UNIQUE NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS user_care_contexts (
    clinician_id VARCHAR(64) NOT NULL REFERENCES users(clinician_id),
    context_id VARCHAR(64) NOT NULL REFERENCES care_contexts(context_id),
    access_level VARCHAR(32) NOT NULL,
    PRIMARY KEY (clinician_id, context_id)
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id VARCHAR(64) PRIMARY KEY,
    clinician_id VARCHAR(64) NOT NULL REFERENCES users(clinician_id),
    care_context_id VARCHAR(64) NOT NULL REFERENCES care_contexts(context_id),
    access_token_hash VARCHAR(128) NOT NULL,
    refresh_token_hash VARCHAR(128) NOT NULL,
    issued_at TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    revoked_at TIMESTAMP WITH TIME ZONE NULL
);

CREATE TABLE IF NOT EXISTS patients (
    patient_id VARCHAR(64) PRIMARY KEY,
    nhs_number VARCHAR(32) NOT NULL,
    external_mrn VARCHAR(64) NOT NULL,
    identity_verification_status VARCHAR(48) NOT NULL,
    match_confidence VARCHAR(48) NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    preferred_name VARCHAR(120) NULL,
    date_of_birth VARCHAR(32) NOT NULL,
    sex_at_birth VARCHAR(32) NOT NULL,
    care_context_id VARCHAR(64) NOT NULL REFERENCES care_contexts(context_id),
    assigned_clinician_id VARCHAR(64) NULL REFERENCES users(clinician_id),
    current_encounter_id VARCHAR(64) NULL,
    current_encounter_label VARCHAR(200) NULL,
    care_team_summary TEXT NOT NULL,
    allergy_status_state VARCHAR(48) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS encounters (
    encounter_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    care_context_id VARCHAR(64) NOT NULL REFERENCES care_contexts(context_id),
    clinician_id VARCHAR(64) NOT NULL REFERENCES users(clinician_id),
    encounter_type VARCHAR(64) NOT NULL,
    status VARCHAR(48) NOT NULL,
    location VARCHAR(160) NOT NULL,
    reason_for_visit VARCHAR(255) NOT NULL,
    started_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS appointments (
    appointment_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    encounter_id VARCHAR(64) NOT NULL REFERENCES encounters(encounter_id),
    clinician_id VARCHAR(64) NOT NULL REFERENCES users(clinician_id),
    care_context_id VARCHAR(64) NOT NULL REFERENCES care_contexts(context_id),
    scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
    duration_minutes INT NOT NULL,
    clinic_room VARCHAR(80) NOT NULL,
    status VARCHAR(48) NOT NULL,
    reason VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS problems (
    problem_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    title VARCHAR(255) NOT NULL,
    coding VARCHAR(64) NOT NULL,
    clinical_status VARCHAR(48) NOT NULL,
    onset_date VARCHAR(32) NOT NULL,
    author_name VARCHAR(160) NOT NULL,
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL,
    source_system VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS clinical_history (
    history_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    category VARCHAR(64) NOT NULL,
    summary TEXT NOT NULL,
    author_name VARCHAR(160) NOT NULL,
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL,
    source_system VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS medications (
    medication_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    name VARCHAR(160) NOT NULL,
    strength VARCHAR(64) NOT NULL,
    dose VARCHAR(64) NOT NULL,
    route VARCHAR(64) NOT NULL,
    frequency VARCHAR(120) NOT NULL,
    record_category VARCHAR(48) NOT NULL,
    status VARCHAR(48) NOT NULL,
    start_date VARCHAR(32) NOT NULL,
    end_date VARCHAR(32) NULL,
    source_system VARCHAR(120) NOT NULL,
    author_name VARCHAR(160) NOT NULL,
    discrepancy_flag BOOLEAN NOT NULL DEFAULT FALSE,
    discrepancy_note TEXT NULL,
    reconciled_by VARCHAR(160) NULL,
    reconciled_at TIMESTAMP WITH TIME ZONE NULL
);

CREATE TABLE IF NOT EXISTS allergies (
    allergy_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    substance VARCHAR(160) NOT NULL,
    reaction VARCHAR(255) NOT NULL,
    verification_status VARCHAR(48) NOT NULL,
    severity VARCHAR(48) NOT NULL,
    provenance VARCHAR(160) NOT NULL,
    recorded_by VARCHAR(160) NOT NULL,
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS observations (
    observation_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    encounter_id VARCHAR(64) NOT NULL REFERENCES encounters(encounter_id),
    name VARCHAR(120) NOT NULL,
    value_numeric DOUBLE PRECISION NULL,
    unit VARCHAR(48) NOT NULL,
    reference_interval VARCHAR(80) NOT NULL,
    abnormal_flag VARCHAR(32) NOT NULL,
    missing_reason VARCHAR(120) NULL,
    observed_at TIMESTAMP WITH TIME ZONE NOT NULL,
    source_system VARCHAR(120) NOT NULL,
    verification_status VARCHAR(48) NOT NULL
);

CREATE TABLE IF NOT EXISTS diagnostic_results (
    result_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    encounter_id VARCHAR(64) NOT NULL REFERENCES encounters(encounter_id),
    test_name VARCHAR(160) NOT NULL,
    category VARCHAR(64) NOT NULL,
    value_text VARCHAR(160) NULL,
    unit VARCHAR(48) NOT NULL,
    reference_interval VARCHAR(80) NOT NULL,
    abnormal_flag VARCHAR(32) NOT NULL,
    result_status VARCHAR(32) NOT NULL,
    workflow_state VARCHAR(48) NOT NULL,
    supersedes_result_id VARCHAR(64) NULL,
    correction_reason TEXT NULL,
    reported_at TIMESTAMP WITH TIME ZONE NOT NULL,
    source_system VARCHAR(120) NOT NULL,
    verification_status VARCHAR(48) NOT NULL,
    reviewed_by VARCHAR(160) NULL,
    reviewed_at TIMESTAMP WITH TIME ZONE NULL,
    follow_up_task_id VARCHAR(64) NULL
);

CREATE TABLE IF NOT EXISTS clinical_notes (
    note_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    encounter_id VARCHAR(64) NOT NULL REFERENCES encounters(encounter_id),
    template_type VARCHAR(48) NOT NULL,
    title VARCHAR(200) NOT NULL,
    sections_json TEXT NOT NULL,
    free_text TEXT NOT NULL,
    copied_attributions_json TEXT NOT NULL,
    status VARCHAR(32) NOT NULL,
    version BIGINT NOT NULL,
    author_id VARCHAR(64) NOT NULL REFERENCES users(clinician_id),
    author_name VARCHAR(160) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    signed_at TIMESTAMP WITH TIME ZONE NULL,
    signed_by_id VARCHAR(64) NULL,
    signed_by_name VARCHAR(160) NULL,
    content_hash VARCHAR(128) NULL,
    entered_in_error_reason TEXT NULL,
    entered_in_error_by VARCHAR(160) NULL,
    entered_in_error_at TIMESTAMP WITH TIME ZONE NULL
);

CREATE TABLE IF NOT EXISTS note_amendments (
    amendment_id VARCHAR(64) PRIMARY KEY,
    note_id VARCHAR(64) NOT NULL REFERENCES clinical_notes(note_id),
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    amendment_type VARCHAR(32) NOT NULL,
    body_text TEXT NOT NULL,
    reason VARCHAR(255) NOT NULL,
    author_id VARCHAR(64) NOT NULL REFERENCES users(clinician_id),
    author_name VARCHAR(160) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    content_hash VARCHAR(128) NOT NULL
);

CREATE TABLE IF NOT EXISTS care_plans (
    plan_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    title VARCHAR(200) NOT NULL,
    goals_summary TEXT NOT NULL,
    status VARCHAR(48) NOT NULL,
    owner_name VARCHAR(160) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    source_system VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS follow_up_tasks (
    task_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    encounter_id VARCHAR(64) NULL,
    linked_result_id VARCHAR(64) NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    owner_id VARCHAR(64) NOT NULL,
    owner_name VARCHAR(160) NOT NULL,
    priority VARCHAR(32) NOT NULL,
    due_at TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(32) NOT NULL,
    completion_evidence TEXT NULL,
    completed_at TIMESTAMP WITH TIME ZONE NULL,
    completed_by VARCHAR(160) NULL,
    created_by VARCHAR(160) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    version BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents_attachments (
    document_id VARCHAR(64) PRIMARY KEY,
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    encounter_id VARCHAR(64) NULL,
    title VARCHAR(200) NOT NULL,
    doc_type VARCHAR(64) NOT NULL,
    mime_type VARCHAR(120) NOT NULL,
    object_key VARCHAR(255) NOT NULL,
    is_clinical_photo BOOLEAN NOT NULL DEFAULT FALSE,
    consent_recorded BOOLEAN NOT NULL DEFAULT FALSE,
    consent_note TEXT NULL,
    author_name VARCHAR(160) NOT NULL,
    original_preserved BOOLEAN NOT NULL DEFAULT TRUE,
    derived_label VARCHAR(160) NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    source_system VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS emergency_access_grants (
    grant_id VARCHAR(64) PRIMARY KEY,
    clinician_id VARCHAR(64) NOT NULL REFERENCES users(clinician_id),
    patient_id VARCHAR(64) NOT NULL REFERENCES patients(patient_id),
    reason TEXT NOT NULL,
    granted_at TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    review_status VARCHAR(48) NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
    audit_id VARCHAR(64) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    actor_id VARCHAR(64) NOT NULL,
    actor_name VARCHAR(160) NOT NULL,
    actor_role VARCHAR(64) NOT NULL,
    action VARCHAR(64) NOT NULL,
    resource_type VARCHAR(64) NOT NULL,
    resource_id VARCHAR(64) NOT NULL,
    patient_id VARCHAR(64) NULL,
    care_context_id VARCHAR(64) NULL,
    outcome VARCHAR(32) NOT NULL,
    reason TEXT NULL,
    emergency_access BOOLEAN NOT NULL DEFAULT FALSE,
    metadata_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
    idempotency_key VARCHAR(128) NOT NULL,
    actor_id VARCHAR(64) NOT NULL,
    endpoint VARCHAR(160) NOT NULL,
    response_status INT NOT NULL,
    response_body TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    PRIMARY KEY (idempotency_key, actor_id, endpoint)
);
