package com.aureom.backend

import com.aureom.backend.db.DatabaseFactory
import com.aureom.backend.model.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.testing.*
import kotlinx.serialization.json.Json
import kotlin.test.*

class BackendClinicalTests {

  private fun createTestDb(): DatabaseFactory {
    val uniqueName = "aureom_test_${System.nanoTime()}"
    return DatabaseFactory(
      jdbcUrl = "jdbc:h2:mem:$uniqueName;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH;DB_CLOSE_DELAY=-1",
      username = "sa",
      password = "",
    )
  }

  @Test
  fun `patient isolation blocks outside care context until break-glass emergency access is granted`() = testApplication {
    val db = createTestDb()
    application { configureAureomBackend(db) }
    val client = createClient { install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) } }

    val login = client.post("/auth/oidc/token") {
      contentType(ContentType.Application.Json)
      setBody(OidcTokenRequest(username = "dr.jenkins", careContextId = "CTX-AMU-A"))
    }.body<AuthSessionResponse>()

    // PAT-9001 belongs to CTX-RENAL-WARD; dr.jenkins in CTX-AMU-A must receive 403 Forbidden
    val denied = client.get("/api/v1/patients/PAT-9001/overview") {
      bearerAuth(login.accessToken)
    }
    assertEquals(HttpStatusCode.Forbidden, denied.status)

    // Emergency break-glass with reason grants temporary audited access
    val grant = client.post("/api/v1/patients/PAT-9001/emergency-access") {
      bearerAuth(login.accessToken)
      contentType(ContentType.Application.Json)
      setBody(EmergencyAccessRequest(reason = "Urgent cross-cover hyperkalaemia review on Ward 9C"))
    }
    assertEquals(HttpStatusCode.Created, grant.status)

    val allowed = client.get("/api/v1/patients/PAT-9001/overview") {
      bearerAuth(login.accessToken)
    }
    assertEquals(HttpStatusCode.OK, allowed.status)
    val overview = allowed.body<PatientOverviewDto>()
    assertTrue(overview.patient.emergencyAccessActive)
  }

  @Test
  fun `role policy blocks nurse from signing notes and auditor from editing drafts`() = testApplication {
    val db = createTestDb()
    application { configureAureomBackend(db) }
    val client = createClient { install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) } }

    val nurseSession = client.post("/auth/oidc/token") {
      contentType(ContentType.Application.Json)
      setBody(OidcTokenRequest(username = "nurse.patel", careContextId = "CTX-AMU-A"))
    }.body<AuthSessionResponse>()

    val signAttempt = client.post("/api/v1/notes/NOTE-302/sign") {
      bearerAuth(nurseSession.accessToken)
      contentType(ContentType.Application.Json)
      setBody(SignNoteRequest(confirmedPatientId = "PAT-1001", expectedVersion = 1L, idempotencyKey = "idem-nurse-1"))
    }
    assertEquals(HttpStatusCode.Forbidden, signAttempt.status)

    val auditorSession = client.post("/auth/oidc/token") {
      contentType(ContentType.Application.Json)
      setBody(OidcTokenRequest(username = "auditor.cole", careContextId = "CTX-AMU-A"))
    }.body<AuthSessionResponse>()

    val editAttempt = client.post("/api/v1/notes") {
      bearerAuth(auditorSession.accessToken)
      contentType(ContentType.Application.Json)
      setBody(
        SaveNoteDraftRequest(
          noteId = "NOTE-302",
          patientId = "PAT-1001",
          encounterId = "ENC-2001",
          templateType = "WARD_ROUND",
          title = "Auditor attempt",
          sections = emptyList(),
          freeText = "Should be blocked",
          expectedVersion = 1L,
        )
      )
    }
    assertEquals(HttpStatusCode.Forbidden, editAttempt.status)
  }

  @Test
  fun `optimistic concurrency conflict, idempotent note signature, immutability, and amendment workflow`() = testApplication {
    val db = createTestDb()
    application { configureAureomBackend(db) }
    val client = createClient { install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) } }

    val doc = client.post("/auth/oidc/token") {
      contentType(ContentType.Application.Json)
      setBody(OidcTokenRequest(username = "dr.jenkins", careContextId = "CTX-AMU-A"))
    }.body<AuthSessionResponse>()

    // Save draft v1 -> v2
    val v2Resp = client.post("/api/v1/notes") {
      bearerAuth(doc.accessToken)
      contentType(ContentType.Application.Json)
      setBody(
        SaveNoteDraftRequest(
          noteId = "NOTE-302",
          patientId = "PAT-1001",
          encounterId = "ENC-2001",
          templateType = "WARD_ROUND",
          title = "Morning Consultant Ward Round",
          sections = listOf(NoteSectionDto("plan", "Management Plan", "Review K+ 5.8 mmol/L and repeat ECG.")),
          freeText = "Updated plan after lab alert.",
          expectedVersion = 1L,
        )
      )
    }
    assertEquals(HttpStatusCode.OK, v2Resp.status)
    val v2Note = v2Resp.body<ClinicalNoteDto>()
    assertEquals(2L, v2Note.version)

    // Stale v1 write must return 409 Conflict
    val staleWrite = client.post("/api/v1/notes") {
      bearerAuth(doc.accessToken)
      contentType(ContentType.Application.Json)
      setBody(
        SaveNoteDraftRequest(
          noteId = "NOTE-302",
          patientId = "PAT-1001",
          encounterId = "ENC-2001",
          templateType = "WARD_ROUND",
          title = "Stale Offline Edit",
          sections = emptyList(),
          freeText = "Offline overwrite attempt",
          expectedVersion = 1L,
        )
      )
    }
    assertEquals(HttpStatusCode.Conflict, staleWrite.status)

    // Idempotent signature with same key must not duplicate signatures
    val signReq = SignNoteRequest(confirmedPatientId = "PAT-1001", expectedVersion = 2L, idempotencyKey = "sign-key-302")
    val signed1 = client.post("/api/v1/notes/NOTE-302/sign") {
      bearerAuth(doc.accessToken)
      contentType(ContentType.Application.Json)
      setBody(signReq)
    }
    assertEquals(HttpStatusCode.OK, signed1.status)
    val signedBody1 = signed1.body<ClinicalNoteDto>()
    assertEquals("SIGNED", signedBody1.status)
    assertNotNull(signedBody1.contentHash)

    val signed2 = client.post("/api/v1/notes/NOTE-302/sign") {
      bearerAuth(doc.accessToken)
      contentType(ContentType.Application.Json)
      setBody(signReq)
    }
    assertEquals(HttpStatusCode.OK, signed2.status)
    assertEquals(signedBody1.signedAt, signed2.body<ClinicalNoteDto>().signedAt)

    // Signed note is immutable
    val mutateSigned = client.post("/api/v1/notes") {
      bearerAuth(doc.accessToken)
      contentType(ContentType.Application.Json)
      setBody(
        SaveNoteDraftRequest(
          noteId = "NOTE-302",
          patientId = "PAT-1001",
          encounterId = "ENC-2001",
          templateType = "WARD_ROUND",
          title = "Tamper",
          sections = emptyList(),
          freeText = "Tamper",
          expectedVersion = signedBody1.version,
        )
      )
    }
    assertEquals(HttpStatusCode.Conflict, mutateSigned.status)

    // Attributed amendment succeeds
    val amended = client.post("/api/v1/notes/NOTE-302/amendments") {
      bearerAuth(doc.accessToken)
      contentType(ContentType.Application.Json)
      setBody(
        CreateAmendmentRequest(
          confirmedPatientId = "PAT-1001",
          amendmentType = "AMENDMENT",
          bodyText = "ECG normal sinus rhythm, no peaked T-waves.",
          reason = "Post-ward-round ECG verification",
          idempotencyKey = "amd-302-1",
        )
      )
    }
    assertEquals(HttpStatusCode.OK, amended.status)
    assertEquals(1, amended.body<ClinicalNoteDto>().amendments.size)
  }

  @Test
  fun `session expiry and revocation block subsequent clinical requests`() = testApplication {
    val db = createTestDb()
    lateinit var ctx: BackendContext
    application { ctx = configureAureomBackend(db) }
    val client = createClient { install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) } }

    val session = client.post("/auth/oidc/token") {
      contentType(ContentType.Application.Json)
      setBody(OidcTokenRequest(username = "dr.jenkins", careContextId = "CTX-AMU-A"))
    }.body<AuthSessionResponse>()

    ctx.auth.expireSessionForTesting(session.sessionId)
    val expiredResp = client.get("/api/v1/worklist") { bearerAuth(session.accessToken) }
    assertEquals(HttpStatusCode.Unauthorized, expiredResp.status)

    val fresh = client.post("/auth/oidc/token") {
      contentType(ContentType.Application.Json)
      setBody(OidcTokenRequest(username = "dr.jenkins", careContextId = "CTX-AMU-A"))
    }.body<AuthSessionResponse>()
    client.post("/auth/logout") { bearerAuth(fresh.accessToken) }
    val revokedResp = client.get("/api/v1/worklist") { bearerAuth(fresh.accessToken) }
    assertEquals(HttpStatusCode.Unauthorized, revokedResp.status)
  }
}
