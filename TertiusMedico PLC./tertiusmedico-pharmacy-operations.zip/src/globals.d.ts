declare module 'node:sqlite' {
  export interface StatementSync {
    run(...params: unknown[]): {changes: number; lastInsertRowid: number | bigint};
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
  }

  export class DatabaseSync {
    constructor(location: string);
    exec(sql: string): void;
    prepare(sql: string): StatementSync;
    close(): void;
  }
}
