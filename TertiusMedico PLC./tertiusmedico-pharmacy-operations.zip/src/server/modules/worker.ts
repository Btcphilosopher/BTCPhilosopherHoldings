import type {DatabaseSync} from 'node:sqlite';
import {appendAudit} from './pharmacy-engine';

let workerTimer: ReturnType<typeof setInterval> | null = null;

export interface WorkerCycleSummary {
  ranAt: string;
  notificationsProcessed: number;
  expiredBatchesFlagged: number;
}

export function runWorkerCycle(db: DatabaseSync): WorkerCycleSummary {
  const now = new Date().toISOString();
  const today = now.slice(0, 10);

  // 1. Flag any available batches whose expiry date has passed
  const expiredRows = db
    .prepare(
      `SELECT id, batch_number FROM stock_batches
       WHERE state = 'available' AND expiry_date <= ?`,
    )
    .all(today) as {id: string; batch_number: string}[];

  for (const b of expiredRows) {
    db.prepare(
      `UPDATE stock_batches
       SET state = 'expired', location = 'Quarantine Cage',
           quarantine_reason = 'Automatically flagged expired by background worker'
       WHERE id = ?`,
    ).run(b.id);

    appendAudit(
      db,
      {id: 'SYS-WORKER', name: 'Background Operations Worker', role: 'system'},
      'BATCH_EXPIRED_AUTO_FLAGGED',
      'stock_batch',
      b.id,
      `Batch ${b.batch_number} automatically moved to expired state.`,
    );
  }

  // 2. Process queued notifications (preserving medicine-name privacy in public_summary)
  const queued = db
    .prepare(`SELECT id, patient_id, channel FROM notifications WHERE status = 'queued'`)
    .all() as {id: string; patient_id: string; channel: string}[];

  for (const n of queued) {
    // Simulate gateway delivery (and simulate intentional failure if patient is PAT-1003 SMS)
    if (n.patient_id === 'PAT-1003' && n.channel === 'sms') {
      db.prepare(
        `UPDATE notifications
         SET status = 'failed', attempts = attempts + 1,
             failure_reason = 'Simulated carrier bounce on SMS route — manual phone contact required'
         WHERE id = ?`,
      ).run(n.id);
    } else {
      db.prepare(
        `UPDATE notifications
         SET status = 'sent', attempts = attempts + 1, sent_at = ?, failure_reason = NULL
         WHERE id = ?`,
      ).run(now, n.id);
    }
  }

  return {
    ranAt: now,
    notificationsProcessed: queued.length,
    expiredBatchesFlagged: expiredRows.length,
  };
}

export function startBackgroundWorker(db: DatabaseSync): void {
  if (workerTimer) {
    return;
  }
  workerTimer = setInterval(() => {
    try {
      runWorkerCycle(db);
    } catch (err) {
      console.error('Background worker cycle error:', err);
    }
  }, 15000);
  // Don't prevent Node process from exiting cleanly
  if (typeof workerTimer.unref === 'function') {
    workerTimer.unref();
  }
}
