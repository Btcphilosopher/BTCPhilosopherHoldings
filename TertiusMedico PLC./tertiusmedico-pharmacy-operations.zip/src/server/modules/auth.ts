import {randomBytes, scryptSync, timingSafeEqual} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import {ROLE_PERMISSIONS, type StaffRole, type StaffUser} from '../types';

export interface SessionPrincipal {
  token: string;
  actorType: 'staff' | 'patient';
  actorId: string;
  role: StaffRole | 'patient';
  displayName: string;
  expiresAt: string;
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const derived = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) {
    return false;
  }
  const [salt, keyHex] = parts;
  if (!salt || !keyHex) {
    return false;
  }
  const derived = scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== keyBuf.length) {
    return false;
  }
  return timingSafeEqual(derived, keyBuf);
}

export function createSession(
  db: DatabaseSync,
  actorType: 'staff' | 'patient',
  actorId: string,
  role: StaffRole | 'patient',
  displayName: string,
): SessionPrincipal {
  const token = randomBytes(32).toString('hex');
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 12 * 60 * 60 * 1000).toISOString();

  db.prepare(
    `INSERT INTO sessions (token, actor_type, actor_id, role, display_name, created_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).run(token, actorType, actorId, role, displayName, now.toISOString(), expiresAt);

  return {
    token,
    actorType,
    actorId,
    role,
    displayName,
    expiresAt,
  };
}

export function authenticateBearer(
  db: DatabaseSync,
  authHeader: string | undefined,
): SessionPrincipal | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.slice(7).trim();
  if (!token) {
    return null;
  }

  const row = db
    .prepare(
      `SELECT token, actor_type, actor_id, role, display_name, expires_at
       FROM sessions WHERE token = ?`,
    )
    .get(token) as
    | {
        token: string;
        actor_type: 'staff' | 'patient';
        actor_id: string;
        role: StaffRole | 'patient';
        display_name: string;
        expires_at: string;
      }
    | undefined;

  if (!row) {
    return null;
  }

  if (new Date(row.expires_at).getTime() < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    return null;
  }

  return {
    token: row.token,
    actorType: row.actor_type,
    actorId: row.actor_id,
    role: row.role,
    displayName: row.display_name,
    expiresAt: row.expires_at,
  };
}

export function hasStaffPermission(role: StaffRole | 'patient', permission: string): boolean {
  if (role === 'patient') {
    return false;
  }
  const perms = ROLE_PERMISSIONS[role];
  return Array.isArray(perms) && perms.includes(permission);
}

export function listStaffUsers(db: DatabaseSync): StaffUser[] {
  const rows = db
    .prepare(
      `SELECT id, username, display_name, role, gphc_number, branch_id, active
       FROM staff_users ORDER BY role, display_name`,
    )
    .all() as {
    id: string;
    username: string;
    display_name: string;
    role: StaffRole;
    gphc_number: string | null;
    branch_id: string;
    active: number;
  }[];

  return rows.map((r) => ({
    id: r.id,
    username: r.username,
    displayName: r.display_name,
    role: r.role,
    gphcNumber: r.gphc_number,
    branchId: r.branch_id,
    active: r.active === 1,
  }));
}

export function redactSensitiveText(input: string): string {
  // Redact UK NHS numbers (10 digits) and email addresses in operational logs
  return input
    .replace(/\b\d{3}[\s-]?\d{3}[\s-]?\d{4}\b/g, '[NHS-REDACTED]')
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[EMAIL-REDACTED]');
}
