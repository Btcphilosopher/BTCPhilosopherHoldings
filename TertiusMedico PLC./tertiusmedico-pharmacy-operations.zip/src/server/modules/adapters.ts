import type {HazardLogEntry} from '../types';

export interface ExternalAdapterStatus {
  id: string;
  name: string;
  mode: 'SIMULATED' | 'DEFERRED';
  version: string;
  authoritativeSource: string;
  authMechanism: string;
  coverage: string;
  available: boolean;
  retryAndIdempotencyPolicy: string;
  disclaimer: string;
}

export interface ClinicalKnowledgeCheckResult {
  adapterName: string;
  adapterVersion: string;
  available: boolean;
  coverage: string;
  checkedAt: string;
  alerts: {
    severity: 'critical' | 'amber' | 'info';
    category: 'allergy' | 'interaction' | 'dose' | 'contraindication' | 'availability';
    message: string;
    sourceRef: string;
  }[];
  safetyStatement: string;
}

export function getExternalAdaptersStatus(clinicalAdapterAvailable: boolean): ExternalAdapterStatus[] {
  return [
    {
      id: 'eps_fhir',
      name: 'Electronic Prescription Service (EPS)',
      mode: 'SIMULATED',
      version: 'NHS EPS FHIR R4 UK Core v2.1 (Simulated)',
      authoritativeSource: 'NHS England Digital — EPS FHIR API Specification',
      authMechanism: 'Simulated CIS2 / mTLS OAuth2 Bearer (Deferred for production)',
      coverage: 'Synthetic GP prescriptions, amendments, and cancellations',
      available: true,
      retryAndIdempotencyPolicy: 'Idempotency enforced via (source_system, source_identifier, version)',
      disclaimer:
        'Successful synthetic transmission does not imply acceptance by live NHS Spine EPS.',
    },
    {
      id: 'pds_identity',
      name: 'Personal Demographics Service (PDS)',
      mode: 'SIMULATED',
      version: 'NHS PDS FHIR R4 (Simulated)',
      authoritativeSource: 'NHS England Digital — PDS FHIR API',
      authMechanism: 'Simulated Application-Restricted JWT',
      coverage: 'Synthetic NHS number verification and demographic tracing',
      available: true,
      retryAndIdempotencyPolicy: 'Explicit manual review required on ambiguous demographic trace; no auto-merge.',
      disclaimer: 'NHS number is an identifier only and is never used as authentication.',
    },
    {
      id: 'dmd_terminology',
      name: 'Dictionary of Medicines and Devices (dm+d)',
      mode: 'SIMULATED',
      version: 'dm+d Release 2026.11 (SNOMED CT UK Drug Extension)',
      authoritativeSource: 'NHSBSA / TRUD dm+d Weekly Release',
      authMechanism: 'TRUD API Key (Deferred; local versioned fixture)',
      coverage: 'VTM, VMP, AMP, VMPP, AMPP codes for prototype formulary',
      available: true,
      retryAndIdempotencyPolicy: 'Immutable versioned snapshots per release week.',
      disclaimer: 'Subset of synthetic UK medicines for demonstration only.',
    },
    {
      id: 'clinical_knowledge',
      name: 'Clinical Knowledge & Decision Support',
      mode: 'SIMULATED',
      version: 'UK-BNF-Demo-Adapter v2026.11',
      authoritativeSource: 'BNF / dm+d / Licensed Clinical Decision Support Vendor',
      authMechanism: 'Licensed vendor API key (Server-side only)',
      coverage: clinicalAdapterAvailable
        ? 'Synthetic allergy cross-sensitivity and major drug-interaction screening'
        : 'UNAVAILABLE — Screening offline; manual pharmacist verification mandatory',
      available: clinicalAdapterAvailable,
      retryAndIdempotencyPolicy: 'Fail-safe open warning: absence of alerts never implies clinical safety.',
      disclaimer:
        'Decision support only. Absence of an alert must never be presented as proof that dispensing is safe.',
    },
    {
      id: 'wholesaler_edi',
      name: 'Wholesaler Ordering & ASN',
      mode: 'SIMULATED',
      version: 'Pennine Wholesale EDI v1.4 (Simulated)',
      authoritativeSource: 'Fictional UK Wholesalers (Pennine Pharma Wholesale, Northern Generics)',
      authMechanism: 'Simulated AS2/HTTPS Partner Token',
      coverage: 'PO submission, acknowledgement, ASN goods receipt, price & short-supply flags',
      available: true,
      retryAndIdempotencyPolicy: 'Order number idempotency key with line-level reconciliation.',
      disclaimer: 'Uses fictional wholesalers and synthetic pricing only.',
    },
    {
      id: 'messaging_notify',
      name: 'Patient Messaging (SMS / Email / Portal)',
      mode: 'SIMULATED',
      version: 'NHS Notify Pattern v1.0 (Simulated)',
      authoritativeSource: 'NHS Notify / UK Gov Notify',
      authMechanism: 'Server-side API token',
      coverage: 'Collection readiness, partial supply updates, service reminders',
      available: true,
      retryAndIdempotencyPolicy:
        'Dead-letter retry queue; medicine names omitted from SMS/lock-screen text.',
      disclaimer: 'Simulated delivery queue including deliberate failure test case.',
    },
    {
      id: 'payments_nhsbsa',
      name: 'Payments & NHSBSA Reimbursement',
      mode: 'SIMULATED',
      version: 'NHSBSA FP34C / Card Terminal Sim v2026.11',
      authoritativeSource: 'NHSBSA Drug Tariff & NHS Prescription Charges (England)',
      authMechanism: 'Simulated Payment Intent + MYS Submission Export',
      coverage: 'Integer-pence NHS charges (£9.90/item), exemptions, FP34C export',
      available: true,
      retryAndIdempotencyPolicy: 'Ledger append-only transactions with explicit refund entries.',
      disclaimer:
        'No connection to live Stripe/Merchant terminals or NHSBSA Manage Your Service (MYS).',
    },
    {
      id: 'printer_scanner',
      name: 'Dispensing Label Printer & Barcode Scanner',
      mode: 'SIMULATED',
      version: 'ZPL-Demo / HID-EAN13 Adapter v1.0',
      authoritativeSource: 'Local Workstation Peripheral Bridge',
      authMechanism: 'Local workstation session',
      coverage: 'HTML/ZPL demonstration label preview + EAN-13 barcode verification',
      available: true,
      retryAndIdempotencyPolicy: 'All fixture labels carry DEMONSTRATION — NOT FOR DISPENSING banner.',
      disclaimer: 'Barcode verification is one check only, not proof of clinical suitability.',
    },
  ];
}

export function runSimulatedClinicalKnowledgeCheck(params: {
  adapterAvailable: boolean;
  adapterVersion: string;
  allergyStatus: 'recorded' | 'no_known_allergies' | 'unavailable';
  allergies: {substance: string; severity: string; reaction: string}[];
  prescribedName: string;
  directions: string;
  legalCategory: string;
}): ClinicalKnowledgeCheckResult {
  const checkedAt = new Date().toISOString();

  if (!params.adapterAvailable) {
    return {
      adapterName: 'Clinical Knowledge & Decision Support',
      adapterVersion: params.adapterVersion,
      available: false,
      coverage: 'UNAVAILABLE — Screening service offline',
      checkedAt,
      alerts: [
        {
          severity: 'critical',
          category: 'availability',
          message:
            'Clinical-checking adapter is currently UNAVAILABLE. Automated allergy, interaction, and dose checks were NOT executed. Manual pharmacist verification using authoritative BNF/SmPC is mandatory.',
          sourceRef: 'Safety Policy CS-05',
        },
      ],
      safetyStatement:
        'Screening incomplete: adapter unavailable. Absence of alerts does NOT indicate dispensing is safe.',
    };
  }

  const alerts: ClinicalKnowledgeCheckResult['alerts'] = [];

  if (params.allergyStatus === 'unavailable') {
    alerts.push({
      severity: 'amber',
      category: 'allergy',
      message:
        'Patient allergy status is UNAVAILABLE (distinct from No Known Allergies). Verify allergy history with patient or GP Summary Care Record before approving.',
      sourceRef: 'Patient Record Governance',
    });
  }

  const medLower = params.prescribedName.toLowerCase();
  for (const allergy of params.allergies) {
    const subLower = allergy.substance.toLowerCase();
    if (
      (subLower.includes('penicillin') &&
        (medLower.includes('amoxicillin') ||
          medLower.includes('flucloxacillin') ||
          medLower.includes('co-amoxiclav'))) ||
      medLower.includes(subLower)
    ) {
      alerts.push({
        severity: 'critical',
        category: 'allergy',
        message: `ALLERGY ALERT: Patient has recorded ${allergy.severity} allergy to ${allergy.substance} (${allergy.reaction}). Prescribed item "${params.prescribedName}" has beta-lactam/penicillin cross-sensitivity.`,
        sourceRef: 'BNF Beta-lactam Hypersensitivity (Demo Rule)',
      });
    }
  }

  if (params.legalCategory === 'CD2') {
    alerts.push({
      severity: 'amber',
      category: 'dose',
      message:
        'Schedule 2 Controlled Drug: verify total quantity in words and figures, 28-day prescription validity, and CD register balancing.',
      sourceRef: 'Misuse of Drugs Regulations 2001 (Demo Reference)',
    });
  }

  if (medLower.includes('insulin')) {
    alerts.push({
      severity: 'amber',
      category: 'contraindication',
      message:
        'High-risk medicine (Insulin): confirm exact brand/device, units abbreviation check, and 2–8°C cold-chain storage integrity.',
      sourceRef: 'NPSA Safer Insulin Prescribing',
    });
  }

  return {
    adapterName: 'Clinical Knowledge & Decision Support',
    adapterVersion: params.adapterVersion,
    available: true,
    coverage: 'Synthetic Penicillin cross-sensitivity, CD2 statutory reminder, High-risk Insulin notice',
    checkedAt,
    alerts,
    safetyStatement:
      'Decision support is advisory only. Absence of an alert is not proof that dispensing is safe. Authorised pharmacist judgment is required.',
  };
}

export const PROTOTYPE_HAZARD_LOG: HazardLogEntry[] = [
  {
    id: 'HAZ-01',
    hazardRef: 'DCB0129-H01',
    category: 'Wrong-patient selection',
    hazardTitle: 'Silent transfer of dispensing context or automatic merging of similar patient records',
    clinicalRisk: 'Medicine dispensed to wrong patient causing severe harm or missed allergy contraindication.',
    mitigationInPrototype:
      'Persistent locked patient banner in dispensing view; explicit patient-matching exception queue; automatic patient merging disabled; NHS number treated as identifier only.',
    residualStatus: 'Controlled in prototype — requires DCB0160 local SOP sign-off',
    standardRef: 'NHS DCB0129 / GPhC Principle 4',
  },
  {
    id: 'HAZ-02',
    hazardRef: 'DCB0129-H02',
    category: 'Wrong product or quantity',
    hazardTitle: 'Unit conflation (tablets vs packs vs mL vs inhalers) or silent product substitution',
    clinicalRisk: 'Overdose or underdose from dispensing wrong pack size, strength, or pharmaceutical form.',
    mitigationInPrototype:
      'dm+d VMP/AMP/VMPP/AMPP hierarchy separates prescribed vs dispensable item; explicit unit enum; integer arithmetic; barcode EAN-13 match check required prior to checking.',
    residualStatus: 'Controlled in prototype — barcode check enforced as one step only',
    standardRef: 'NHS dm+d / SNOMED CT UK Drug Extension',
  },
  {
    id: 'HAZ-03',
    hazardRef: 'DCB0129-H03',
    category: 'Missed cancellations',
    hazardTitle: 'Duplicate or out-of-order EPS cancellation message fails or leaves stock reserved / ready for handover',
    clinicalRisk: 'Cancelled medicine handed to patient after prescriber stopped therapy.',
    mitigationInPrototype:
      'Idempotent cancellation processor keyed by (message_type, source_identifier); releases unconsumed stock reservations; blocks handover on cancelled items; logs duplicate safely.',
    residualStatus: 'Controlled & covered by automated concurrency/cancellation tests',
    standardRef: 'NHS EPS R4 Cancellation Handling',
  },
  {
    id: 'HAZ-04',
    hazardRef: 'DCB0129-H04',
    category: 'Stock discrepancies',
    hazardTitle: 'Race condition allocating the same physical batch to two prescriptions, or dispensing expired/recalled stock',
    clinicalRisk: 'Supply of expired/recalled medicine or failed fulfilment due to phantom stock.',
    mitigationInPrototype:
      'SQLite BEGIN IMMEDIATE transactional allocation; physical vs reserved stock separation; FEFO excludes expired, quarantined, recalled, and disposed batches.',
    residualStatus: 'Controlled & verified by concurrency test suite',
    standardRef: 'MHRA GDP / GPhC Principle 5',
  },
  {
    id: 'HAZ-05',
    hazardRef: 'DCB0129-H05',
    category: 'Incomplete checking',
    hazardTitle: 'Bypassing clinical review or accuracy check, or false reassurance when clinical screening is offline',
    clinicalRisk: 'Unchecked prescribing error reaches patient; staff assume no alert means safe.',
    mitigationInPrototype:
      'Separate stage transitions and role permissions (Pharmacist vs ACT/Dispenser vs Counter); configurable role-separation; prominent amber/red banner when adapter unavailable.',
    residualStatus: 'Controlled in prototype — configurable in Administration Policy',
    standardRef: 'GPhC Standards / RPS Professional Guidance',
  },
  {
    id: 'HAZ-06',
    hazardRef: 'DCB0129-H06',
    category: 'Failed communications',
    hazardTitle: 'Silent SMS/notification failure or leakage of sensitive medicine names on patient lock screens',
    clinicalRisk: 'Patient misses partial supply or urgent recall follow-up; privacy breach on shared device.',
    mitigationInPrototype:
      'Background worker tracks delivery status and surfaces failed notifications in staff alert queue; SMS/lock-screen text omits medicine names; full detail behind authenticated portal.',
    residualStatus: 'Controlled in prototype — requires production NHS Notify integration',
    standardRef: 'NHS DSPT / UK GDPR Art. 9',
  },
];
