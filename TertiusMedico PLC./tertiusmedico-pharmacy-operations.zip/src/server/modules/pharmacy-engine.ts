import {randomUUID} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import {runInTransaction} from '../db/database';
import type {
  OrganisationalPolicy,
  PatientRecord,
  Prescription,
  PrescriptionItem,
  PrescriptionItemStage,
  PrescriptionStage,
  StockBatch,
} from '../types';
import {runSimulatedClinicalKnowledgeCheck, type ClinicalKnowledgeCheckResult} from './adapters';
import {hasStaffPermission, redactSensitiveText, type SessionPrincipal} from './auth';

export class DomainError extends Error {
  constructor(
    public readonly statusCode: number,
    message: string,
  ) {
    super(message);
  }
}

export function appendAudit(
  db: DatabaseSync,
  actor: {id: string; name: string; role: string},
  action: string,
  entityType: string,
  entityId: string,
  summary: string,
  beforeObj: unknown = null,
  afterObj: unknown = null,
): void {
  db.prepare(
    `INSERT INTO audit_events (
      id, actor_id, actor_name, actor_role, action, entity_type, entity_id,
      summary, before_json, after_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    `AUD-${randomUUID().slice(0, 8).toUpperCase()}`,
    actor.id,
    actor.name,
    actor.role,
    action,
    entityType,
    entityId,
    redactSensitiveText(summary),
    beforeObj ? JSON.stringify(beforeObj) : null,
    afterObj ? JSON.stringify(afterObj) : null,
    new Date().toISOString(),
  );
}

export function getOrgPolicy(db: DatabaseSync): OrganisationalPolicy {
  const row = db.prepare('SELECT * FROM org_policy LIMIT 1').get() as Record<string, unknown>;
  return {
    id: String(row['id']),
    organisationName: String(row['organisation_name']),
    branchName: String(row['branch_name']),
    odsCode: String(row['ods_code']),
    jurisdiction: String(row['jurisdiction']),
    requireSeparatePreparerAndChecker: Number(row['require_separate_preparer_and_checker']) === 1,
    requireSeparateClinicalAndAccuracyChecker:
      Number(row['require_separate_clinical_and_accuracy_checker']) === 1,
    allowEmergencySelfCheckOverride: Number(row['allow_emergency_self_check_override']) === 1,
    requirePatientIdCheckOnHandover: Number(row['require_patient_id_check_on_handover']) === 1,
    clinicalAdapterAvailable: Number(row['clinical_adapter_available']) === 1,
    clinicalAdapterVersion: String(row['clinical_adapter_version']),
    dmdCatalogVersion: String(row['dmd_catalog_version']),
    updatedAt: String(row['updated_at']),
    updatedBy: String(row['updated_by']),
  };
}

export function listPatients(db: DatabaseSync): PatientRecord[] {
  const rows = db.prepare('SELECT * FROM patients ORDER BY full_name').all() as Record<string, unknown>[];
  return rows.map(mapPatientRow);
}

export function getPatientById(db: DatabaseSync, patientId: string): PatientRecord | null {
  const row = db.prepare('SELECT * FROM patients WHERE id = ?').get(patientId) as
    | Record<string, unknown>
    | undefined;
  return row ? mapPatientRow(row) : null;
}

function mapPatientRow(row: Record<string, unknown>): PatientRecord {
  return {
    id: String(row['id']),
    internalId: String(row['internal_id']),
    nhsNumber: row['nhs_number'] ? String(row['nhs_number']) : null,
    nhsNumberVerified: Number(row['nhs_number_verified']) === 1,
    fullName: String(row['full_name']),
    dateOfBirth: String(row['date_of_birth']),
    postcode: String(row['postcode']),
    addressLine1: String(row['address_line1']),
    city: String(row['city']),
    phone: String(row['phone']),
    email: String(row['email']),
    preferredContact: String(row['preferred_contact']) as PatientRecord['preferredContact'],
    accessibilityNeeds: JSON.parse(String(row['accessibility_needs_json'])) as string[],
    allergyStatus: String(row['allergy_status']) as PatientRecord['allergyStatus'],
    allergies: JSON.parse(String(row['allergies_json'])) as PatientRecord['allergies'],
    exemptionStatus: String(row['exemption_status']) as PatientRecord['exemptionStatus'],
    exemptionReference: row['exemption_reference'] ? String(row['exemption_reference']) : null,
    authorisedRepresentatives: JSON.parse(
      String(row['authorised_representatives_json']),
    ) as PatientRecord['authorisedRepresentatives'],
    externalReferences: JSON.parse(String(row['external_references_json'])) as Record<string, string>,
    portalPinLast4: String(row['portal_pin_last4']),
  };
}

export function listPrescriptions(db: DatabaseSync): Prescription[] {
  const rxRows = db
    .prepare('SELECT * FROM prescriptions ORDER BY received_at DESC')
    .all() as Record<string, unknown>[];
  const itemRows = db.prepare('SELECT * FROM prescription_items').all() as Record<string, unknown>[];
  const patients = listPatients(db);
  const patientMap = new Map(patients.map((p) => [p.id, p]));

  const itemsByRx = new Map<string, PrescriptionItem[]>();
  for (const r of itemRows) {
    const item = mapItemRow(r);
    const arr = itemsByRx.get(item.prescriptionId) ?? [];
    arr.push(item);
    itemsByRx.set(item.prescriptionId, arr);
  }

  return rxRows.map((r) => {
    const patientId = r['patient_id'] ? String(r['patient_id']) : null;
    const pat = patientId ? patientMap.get(patientId) : undefined;
    return {
      id: String(r['id']),
      prescriptionId: String(r['prescription_id']),
      sourceIdentifier: String(r['source_identifier']),
      sourceSystem: String(r['source_system']) as Prescription['sourceSystem'],
      patientId,
      patientReference: String(r['patient_reference']),
      matchStatus: String(r['match_status']) as Prescription['matchStatus'],
      prescriberDetails: String(r['prescriber_details']),
      issueDate: String(r['issue_date']),
      receivedAt: String(r['received_at']),
      status: String(r['status']) as PrescriptionStage,
      version: Number(r['version']),
      provenance: String(r['provenance']),
      verificationRequired: Number(r['verification_required']) === 1,
      documentVerifiedBy: r['document_verified_by'] ? String(r['document_verified_by']) : null,
      documentVerifiedAt: r['document_verified_at'] ? String(r['document_verified_at']) : null,
      attachmentId: r['attachment_id'] ? String(r['attachment_id']) : null,
      deliveryRequested: Number(r['delivery_requested']) === 1,
      collectionOption: String(r['collection_option']) as Prescription['collectionOption'],
      exemptionOrChargeStatus: String(r['exemption_or_charge_status']),
      chargeTotalPence: Number(r['charge_total_pence']),
      paymentStatus: String(r['payment_status']) as Prescription['paymentStatus'],
      sourcePayloadJson: String(r['source_payload_json']),
      items: itemsByRx.get(String(r['id'])) ?? [],
      patientSummary: pat
        ? {
            id: pat.id,
            internalId: pat.internalId,
            fullName: pat.fullName,
            nhsNumber: pat.nhsNumber,
            nhsNumberVerified: pat.nhsNumberVerified,
            dateOfBirth: pat.dateOfBirth,
            allergyStatus: pat.allergyStatus,
            allergiesCount: pat.allergies.length,
          }
        : null,
    };
  });
}

function mapItemRow(r: Record<string, unknown>): PrescriptionItem {
  return {
    id: String(r['id']),
    prescriptionId: String(r['prescription_id']),
    productId: String(r['product_id']),
    prescribedMedicineText: String(r['prescribed_medicine_text']),
    selectedProductName: String(r['selected_product_name']),
    strength: String(r['strength']),
    form: String(r['form']),
    directionsAsReceived: String(r['directions_as_received']),
    directionsAmended: r['directions_amended'] ? String(r['directions_amended']) : null,
    amendmentReason: r['amendment_reason'] ? String(r['amendment_reason']) : null,
    prescribedQty: Number(r['prescribed_qty']),
    preparedQty: Number(r['prepared_qty']),
    suppliedQty: Number(r['supplied_qty']),
    outstandingQty: Number(r['outstanding_qty']),
    cancelledQty: Number(r['cancelled_qty']),
    unit: String(r['unit']) as PrescriptionItem['unit'],
    legalCategory: String(r['legal_category']) as PrescriptionItem['legalCategory'],
    status: String(r['status']) as PrescriptionItemStage,
    allocatedBatchId: r['allocated_batch_id'] ? String(r['allocated_batch_id']) : null,
    allocatedBatchNumber: r['allocated_batch_number'] ? String(r['allocated_batch_number']) : null,
    allocatedExpiryDate: r['allocated_expiry_date'] ? String(r['allocated_expiry_date']) : null,
    barcodeVerified: Number(r['barcode_verified']) === 1,
    barcodeScannedAt: r['barcode_scanned_at'] ? String(r['barcode_scanned_at']) : null,
    barcodeScannedValue: r['barcode_scanned_value'] ? String(r['barcode_scanned_value']) : null,
    clinicalDecision: String(r['clinical_decision']) as PrescriptionItem['clinicalDecision'],
    clinicalReviewedBy: r['clinical_reviewed_by'] ? String(r['clinical_reviewed_by']) : null,
    clinicalReviewedAt: r['clinical_reviewed_at'] ? String(r['clinical_reviewed_at']) : null,
    clinicalNotes: r['clinical_notes'] ? String(r['clinical_notes']) : null,
    clinicalAdapterUsed: r['clinical_adapter_used'] ? String(r['clinical_adapter_used']) : null,
    clinicalAdapterStatusAtReview: r['clinical_adapter_status_at_review']
      ? (String(r['clinical_adapter_status_at_review']) as 'available' | 'unavailable')
      : null,
    preparedBy: r['prepared_by'] ? String(r['prepared_by']) : null,
    preparedAt: r['prepared_at'] ? String(r['prepared_at']) : null,
    checkedBy: r['checked_by'] ? String(r['checked_by']) : null,
    checkedAt: r['checked_at'] ? String(r['checked_at']) : null,
    handedOverBy: r['handed_over_by'] ? String(r['handed_over_by']) : null,
    handedOverAt: r['handed_over_at'] ? String(r['handed_over_at']) : null,
    labelGeneratedAt: r['label_generated_at'] ? String(r['label_generated_at']) : null,
    substitutionRecorded: r['substitution_recorded'] ? String(r['substitution_recorded']) : null,
    partialReason: r['partial_reason'] ? String(r['partial_reason']) : null,
    owingExpiryDate: r['owing_expiry_date'] ? String(r['owing_expiry_date']) : null,
  };
}

export function listStockBatches(db: DatabaseSync): (StockBatch & {productName: string; barcodeEan13: string})[] {
  const rows = db
    .prepare(
      `SELECT sb.*, mp.dispensable_product_name as product_name, mp.barcode_ean13
       FROM stock_batches sb
       JOIN medicine_products mp ON sb.product_id = mp.id
       ORDER BY sb.expiry_date ASC`,
    )
    .all() as Record<string, unknown>[];

  return rows.map((r) => {
    const physicalQty = Number(r['physical_qty']);
    const reservedQty = Number(r['reserved_qty']);
    return {
      id: String(r['id']),
      branchId: String(r['branch_id']),
      location: String(r['location']),
      productId: String(r['product_id']),
      batchNumber: String(r['batch_number']),
      expiryDate: String(r['expiry_date']),
      physicalQty,
      reservedQty,
      availableQty: Math.max(0, physicalQty - reservedQty),
      state: String(r['state']) as StockBatch['state'],
      unit: String(r['unit']) as StockBatch['unit'],
      costPencePerPack: Number(r['cost_pence_per_pack']),
      receivedAt: String(r['received_at']),
      quarantineReason: r['quarantine_reason'] ? String(r['quarantine_reason']) : null,
      productName: String(r['product_name']),
      barcodeEan13: String(r['barcode_ean13']),
    };
  });
}

function recalculateParentPrescriptionStatus(db: DatabaseSync, prescriptionId: string): PrescriptionStage {
  const rx = db
    .prepare('SELECT status, match_status, verification_required, document_verified_at FROM prescriptions WHERE id = ?')
    .get(prescriptionId) as
    | {
        status: PrescriptionStage;
        match_status: string;
        verification_required: number;
        document_verified_at: string | null;
      }
    | undefined;
  if (!rx) {
    throw new DomainError(404, 'Prescription not found');
  }

  const items = db
    .prepare('SELECT * FROM prescription_items WHERE prescription_id = ?')
    .all(prescriptionId) as Record<string, unknown>[];

  if (items.length === 0) {
    return rx.status;
  }

  const allCancelled = items.every((i) => String(i['status']) === 'Cancelled');
  if (allCancelled) {
    db.prepare('UPDATE prescriptions SET status = ? WHERE id = ?').run('Cancelled', prescriptionId);
    return 'Cancelled';
  }

  const activeItems = items.filter((i) => String(i['status']) !== 'Cancelled');
  const allCompleted = activeItems.every(
    (i) => String(i['status']) === 'Completed' && Number(i['outstanding_qty']) === 0,
  );
  if (allCompleted) {
    db.prepare('UPDATE prescriptions SET status = ? WHERE id = ?').run('Completed', prescriptionId);
    return 'Completed';
  }

  const anySuppliedWithOutstanding = activeItems.some(
    (i) => Number(i['supplied_qty']) > 0 && Number(i['outstanding_qty']) > 0,
  );
  const someCompletedAndSomePending =
    activeItems.some((i) => String(i['status']) === 'Completed') &&
    activeItems.some((i) => String(i['status']) !== 'Completed');

  let derived: PrescriptionStage = 'Received';

  if (rx.match_status !== 'matched') {
    derived = 'Received';
  } else if (rx.verification_required === 1 && !rx.document_verified_at) {
    derived = 'Received';
  } else if (anySuppliedWithOutstanding || someCompletedAndSomePending) {
    derived = 'Partially supplied';
  } else {
    const statuses = activeItems.map((i) => String(i['status']) as PrescriptionItemStage);
    if (statuses.includes('Awaiting clarification')) {
      derived = 'Awaiting clarification';
    } else if (statuses.includes('Awaiting clinical review')) {
      derived = 'Awaiting clinical review';
    } else if (statuses.includes('Awaiting stock')) {
      derived = 'Awaiting stock';
    } else if (statuses.includes('Ready for preparation')) {
      derived = 'Ready for preparation';
    } else if (statuses.includes('Prepared')) {
      derived = 'Prepared';
    } else if (statuses.includes('Awaiting accuracy check')) {
      derived = 'Awaiting accuracy check';
    } else if (statuses.includes('Ready for handover')) {
      derived = 'Ready for handover';
    }
  }

  db.prepare('UPDATE prescriptions SET status = ? WHERE id = ?').run(derived, prescriptionId);
  return derived;
}

export function intakePrescription(
  db: DatabaseSync,
  actor: SessionPrincipal,
  input: {
    sourceIdentifier: string;
    sourceSystem: 'NHS_EPS_SIM' | 'MANUAL_DEMO' | 'UPLOADED_DOCUMENT';
    patientId: string | null;
    patientReference: string;
    prescriberDetails: string;
    productId: string;
    prescribedQty: number;
    directionsAsReceived: string;
    attachmentFilename?: string;
  },
): Prescription {
  if (!hasStaffPermission(actor.role, 'intake')) {
    throw new DomainError(403, 'Role not permitted to intake prescriptions');
  }
  if (!Number.isInteger(input.prescribedQty) || input.prescribedQty <= 0) {
    throw new DomainError(400, 'Prescribed quantity must be a positive integer');
  }

  return runInTransaction(db, () => {
    const dup = db
      .prepare('SELECT id FROM prescriptions WHERE source_system = ? AND source_identifier = ?')
      .get(input.sourceSystem, input.sourceIdentifier) as {id: string} | undefined;
    if (dup) {
      throw new DomainError(
        409,
        `Duplicate prescription detected: ${input.sourceSystem} / ${input.sourceIdentifier} already exists as ${dup.id}`,
      );
    }

    const med = db.prepare('SELECT * FROM medicine_products WHERE id = ?').get(input.productId) as
      | Record<string, unknown>
      | undefined;
    if (!med) {
      throw new DomainError(404, 'Selected medicine product not found in dm+d catalogue');
    }

    let pat: PatientRecord | null = null;
    if (input.patientId) {
      pat = getPatientById(db, input.patientId);
      if (!pat) {
        throw new DomainError(404, 'Referenced patient record not found');
      }
    }

    const now = new Date().toISOString();
    const rxCode = `RX-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const verificationRequired = input.sourceSystem === 'UPLOADED_DOCUMENT' ? 1 : 0;

    let attachmentId: string | null = null;
    if (input.sourceSystem === 'UPLOADED_DOCUMENT') {
      attachmentId = `ATT-${randomUUID().slice(0, 6).toUpperCase()}`;
      db.prepare(
        `INSERT INTO attachments (id, filename, mime_type, storage_key, uploaded_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
      ).run(
        attachmentId,
        input.attachmentFilename || 'scanned_prescription.pdf',
        'application/pdf',
        `protected-uploads/${attachmentId.toLowerCase()}.pdf`,
        actor.displayName,
        now,
      );
    }

    const initialStage: PrescriptionStage =
      pat && !verificationRequired ? 'Awaiting clinical review' : 'Received';
    const matchStatus = pat ? 'matched' : 'ambiguous_review';

    const chargeRule = db.prepare('SELECT nhs_charge_per_item_pence FROM charge_rules LIMIT 1').get() as {
      nhs_charge_per_item_pence: number;
    };
    const isChargeable = pat?.exemptionStatus === 'chargeable';
    const chargePence = isChargeable ? chargeRule.nhs_charge_per_item_pence : 0;

    const sourcePayload = {
      sourceSystem: input.sourceSystem,
      sourceIdentifier: input.sourceIdentifier,
      patientReference: input.patientReference,
      prescriberDetails: input.prescriberDetails,
      receivedAt: now,
      prescribedItems: [
        {
          vmpCode: med['vmp_code'],
          prescribedName: med['prescribed_name'],
          quantity: input.prescribedQty,
          unit: med['quantity_unit'],
          directionsAsReceived: input.directionsAsReceived,
        },
      ],
    };

    db.prepare(
      `INSERT INTO prescriptions (
        id, prescription_id, source_identifier, source_system, patient_id,
        patient_reference, match_status, prescriber_details, issue_date, received_at,
        status, version, provenance, verification_required, attachment_id,
        delivery_requested, collection_option, exemption_or_charge_status,
        charge_total_pence, payment_status, source_payload_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'in_store_counter', ?, ?, ?, ?)`,
    ).run(
      rxCode,
      rxCode,
      input.sourceIdentifier,
      input.sourceSystem,
      pat ? pat.id : null,
      input.patientReference,
      matchStatus,
      input.prescriberDetails,
      now.slice(0, 10),
      now,
      initialStage,
      1,
      `Ingested via ${input.sourceSystem} adapter`,
      verificationRequired,
      attachmentId,
      pat ? `${pat.exemptionStatus}${pat.exemptionReference ? ` (${pat.exemptionReference})` : ''}` : 'pending_match',
      chargePence,
      isChargeable ? 'unpaid' : 'not_applicable',
      JSON.stringify(sourcePayload),
    );

    const itemId = `ITEM-${randomUUID().slice(0, 6).toUpperCase()}`;
    db.prepare(
      `INSERT INTO prescription_items (
        id, prescription_id, product_id, prescribed_medicine_text, selected_product_name,
        strength, form, directions_as_received, prescribed_qty, prepared_qty,
        supplied_qty, outstanding_qty, cancelled_qty, unit, legal_category, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, 0, ?, ?, ?)`,
    ).run(
      itemId,
      rxCode,
      String(med['id']),
      String(med['prescribed_name']),
      String(med['dispensable_product_name']),
      String(med['strength']),
      String(med['pharmaceutical_form']),
      input.directionsAsReceived,
      input.prescribedQty,
      input.prescribedQty,
      String(med['quantity_unit']),
      String(med['legal_category']),
      initialStage,
    );

    db.prepare(
      `INSERT INTO processed_messages (id, message_type, idempotency_key, prescription_id, status, received_at, notes)
       VALUES (?, 'PRESCRIPTION_INTAKE', ?, ?, 'processed', ?, ?)`,
    ).run(
      `MSG-${randomUUID().slice(0, 6)}`,
      `${input.sourceSystem}:${input.sourceIdentifier}:v1`,
      rxCode,
      now,
      'Initial intake stored with immutable source payload.',
    );

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'PRESCRIPTION_RECEIVED',
      'prescription',
      rxCode,
      `Prescription ${rxCode} ingested from ${input.sourceSystem} (${med['prescribed_name']} x ${input.prescribedQty} ${med['quantity_unit']}).`,
      null,
      {rxCode, stage: initialStage, matchStatus},
    );

    const created = listPrescriptions(db).find((p) => p.id === rxCode);
    if (!created) {
      throw new DomainError(500, 'Failed to read created prescription');
    }
    return created;
  });
}

export function matchPatientToPrescription(
  db: DatabaseSync,
  actor: SessionPrincipal,
  prescriptionId: string,
  patientId: string,
  verificationNote: string,
): Prescription {
  if (!hasStaffPermission(actor.role, 'match_patient')) {
    throw new DomainError(403, 'Role not permitted to resolve patient matching');
  }
  const pat = getPatientById(db, patientId);
  if (!pat) {
    throw new DomainError(404, 'Target patient not found');
  }

  return runInTransaction(db, () => {
    const rx = db.prepare('SELECT * FROM prescriptions WHERE id = ?').get(prescriptionId) as
      | Record<string, unknown>
      | undefined;
    if (!rx) {
      throw new DomainError(404, 'Prescription not found');
    }

    const chargeRule = db.prepare('SELECT nhs_charge_per_item_pence FROM charge_rules LIMIT 1').get() as {
      nhs_charge_per_item_pence: number;
    };
    const isChargeable = pat.exemptionStatus === 'chargeable';
    const nextStatus =
      Number(rx['verification_required']) === 1 && !rx['document_verified_at']
        ? 'Received'
        : 'Awaiting clinical review';

    db.prepare(
      `UPDATE prescriptions
       SET patient_id = ?, match_status = 'matched', status = ?,
           exemption_or_charge_status = ?, charge_total_pence = ?,
           payment_status = ?
       WHERE id = ?`,
    ).run(
      pat.id,
      nextStatus,
      `${pat.exemptionStatus}${pat.exemptionReference ? ` (${pat.exemptionReference})` : ''}`,
      isChargeable ? chargeRule.nhs_charge_per_item_pence : 0,
      isChargeable ? 'unpaid' : 'not_applicable',
      prescriptionId,
    );

    db.prepare('UPDATE prescription_items SET status = ? WHERE prescription_id = ?').run(
      nextStatus,
      prescriptionId,
    );

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'PATIENT_MATCH_VERIFIED',
      'prescription',
      prescriptionId,
      `Matched prescription ${prescriptionId} to ${pat.internalId} (${pat.fullName}). Note: ${verificationNote}`,
      {previousMatchStatus: rx['match_status']},
      {patientId: pat.id, internalId: pat.internalId},
    );

    const updated = listPrescriptions(db).find((p) => p.id === prescriptionId);
    if (!updated) throw new DomainError(404, 'Prescription not found');
    return updated;
  });
}

export function verifyUploadedDocument(
  db: DatabaseSync,
  actor: SessionPrincipal,
  prescriptionId: string,
): Prescription {
  if (!hasStaffPermission(actor.role, 'clinical_review')) {
    throw new DomainError(403, 'Only an authorised pharmacist can verify uploaded prescription documents');
  }
  return runInTransaction(db, () => {
    const rx = db.prepare('SELECT * FROM prescriptions WHERE id = ?').get(prescriptionId) as
      | Record<string, unknown>
      | undefined;
    if (!rx) throw new DomainError(404, 'Prescription not found');
    const now = new Date().toISOString();

    db.prepare(
      `UPDATE prescriptions SET document_verified_by = ?, document_verified_at = ?, status = 'Awaiting clinical review'
       WHERE id = ?`,
    ).run(actor.displayName, now, prescriptionId);

    if (rx['attachment_id']) {
      db.prepare('UPDATE attachments SET verified_by = ?, verified_at = ? WHERE id = ?').run(
        actor.displayName,
        now,
        String(rx['attachment_id']),
      );
    }

    db.prepare(
      `UPDATE prescription_items SET status = 'Awaiting clinical review'
       WHERE prescription_id = ? AND status = 'Received'`,
    ).run(prescriptionId);

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'UPLOADED_DOCUMENT_VERIFIED',
      'prescription',
      prescriptionId,
      `Verified uploaded document for ${prescriptionId} prior to clinical review.`,
    );

    return listPrescriptions(db).find((p) => p.id === prescriptionId)!;
  });
}

export function previewClinicalKnowledgeForItem(
  db: DatabaseSync,
  itemId: string,
): ClinicalKnowledgeCheckResult {
  const item = db.prepare('SELECT * FROM prescription_items WHERE id = ?').get(itemId) as
    | Record<string, unknown>
    | undefined;
  if (!item) throw new DomainError(404, 'Prescription item not found');
  const rx = db.prepare('SELECT * FROM prescriptions WHERE id = ?').get(String(item['prescription_id'])) as
    | Record<string, unknown>
    | undefined;
  if (!rx || !rx['patient_id']) {
    throw new DomainError(400, 'Patient must be matched before clinical knowledge check');
  }
  const pat = getPatientById(db, String(rx['patient_id']));
  if (!pat) throw new DomainError(404, 'Patient not found');
  const policy = getOrgPolicy(db);

  return runSimulatedClinicalKnowledgeCheck({
    adapterAvailable: policy.clinicalAdapterAvailable,
    adapterVersion: policy.clinicalAdapterVersion,
    allergyStatus: pat.allergyStatus,
    allergies: pat.allergies,
    prescribedName: String(item['prescribed_medicine_text']),
    directions: String(item['directions_amended'] || item['directions_as_received']),
    legalCategory: String(item['legal_category']),
  });
}

export function performClinicalReview(
  db: DatabaseSync,
  actor: SessionPrincipal,
  itemId: string,
  decision: 'approved' | 'query' | 'rejected',
  clinicalNotes: string,
  amendedDirections?: string,
  amendmentReason?: string,
): {prescription: Prescription; knowledgeResult: ClinicalKnowledgeCheckResult} {
  if (!hasStaffPermission(actor.role, 'clinical_review')) {
    throw new DomainError(403, 'Only an authorised pharmacist may record clinical review decisions');
  }

  return runInTransaction(db, () => {
    const item = db.prepare('SELECT * FROM prescription_items WHERE id = ?').get(itemId) as
      | Record<string, unknown>
      | undefined;
    if (!item) throw new DomainError(404, 'Prescription item not found');
    const rxId = String(item['prescription_id']);
    const rx = db.prepare('SELECT * FROM prescriptions WHERE id = ?').get(rxId) as
      | Record<string, unknown>
      | undefined;
    if (!rx) throw new DomainError(404, 'Prescription not found');
    if (rx['match_status'] !== 'matched' || !rx['patient_id']) {
      throw new DomainError(409, 'Cannot perform clinical review until patient match is verified');
    }
    if (Number(rx['verification_required']) === 1 && !rx['document_verified_at']) {
      throw new DomainError(409, 'Uploaded document scan must be verified before clinical review');
    }

    const knowledgeResult = previewClinicalKnowledgeForItem(db, itemId);
    const now = new Date().toISOString();

    let nextItemStatus: PrescriptionItemStage = 'Awaiting clinical review';
    if (decision === 'approved') {
      // Check current available stock across valid non-expired, non-quarantined batches
      const today = new Date().toISOString().slice(0, 10);
      const stockRow = db
        .prepare(
          `SELECT COALESCE(SUM(physical_qty - reserved_qty), 0) as avail
           FROM stock_batches
           WHERE product_id = ? AND state = 'available' AND expiry_date > ?`,
        )
        .get(String(item['product_id']), today) as {avail: number};
      const needed = Number(item['outstanding_qty']);
      nextItemStatus = stockRow.avail >= needed ? 'Ready for preparation' : 'Awaiting stock';
    } else if (decision === 'query') {
      nextItemStatus = 'Awaiting clarification';
    } else if (decision === 'rejected') {
      nextItemStatus = 'Cancelled';
    }

    db.prepare(
      `UPDATE prescription_items
       SET clinical_decision = ?,
           clinical_reviewed_by = ?,
           clinical_reviewed_at = ?,
           clinical_notes = ?,
           clinical_adapter_used = ?,
           clinical_adapter_status_at_review = ?,
           directions_amended = COALESCE(?, directions_amended),
           amendment_reason = COALESCE(?, amendment_reason),
           status = ?,
           cancelled_qty = CASE WHEN ? = 'rejected' THEN outstanding_qty ELSE cancelled_qty END,
           outstanding_qty = CASE WHEN ? = 'rejected' THEN 0 ELSE outstanding_qty END
       WHERE id = ?`,
    ).run(
      decision,
      actor.displayName,
      now,
      clinicalNotes,
      knowledgeResult.adapterVersion,
      knowledgeResult.available ? 'available' : 'unavailable',
      amendedDirections?.trim() || null,
      amendmentReason?.trim() || null,
      nextItemStatus,
      decision,
      decision,
      itemId,
    );

    recalculateParentPrescriptionStatus(db, rxId);

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'CLINICAL_REVIEW_RECORDED',
      'prescription_item',
      itemId,
      `Pharmacist clinical review (${decision}) for ${item['prescribed_medicine_text']}. Adapter status: ${knowledgeResult.available ? 'available' : 'unavailable'}. Notes: ${clinicalNotes}`,
      {previousStatus: item['status']},
      {decision, nextItemStatus, adapterAvailable: knowledgeResult.available},
    );

    const updatedRx = listPrescriptions(db).find((p) => p.id === rxId)!;
    return {prescription: updatedRx, knowledgeResult};
  });
}

export function allocateStockAndPrepare(
  db: DatabaseSync,
  actor: SessionPrincipal,
  itemId: string,
  params: {
    qtyToPrepare?: number;
    partialReason?: string;
    barcodeScannedValue: string;
    substitutionNote?: string;
    targetBatchId?: string;
  },
): Prescription {
  if (!hasStaffPermission(actor.role, 'prepare')) {
    throw new DomainError(403, 'Role not permitted to allocate stock or prepare medicines');
  }

  return runInTransaction(db, () => {
    const item = db.prepare('SELECT * FROM prescription_items WHERE id = ?').get(itemId) as
      | Record<string, unknown>
      | undefined;
    if (!item) throw new DomainError(404, 'Prescription item not found');
    const rxId = String(item['prescription_id']);

    if (String(item['clinical_decision']) !== 'approved') {
      throw new DomainError(409, 'Clinical review approval is required before stock allocation and preparation');
    }
    if (
      !['Ready for preparation', 'Awaiting stock', 'Partially supplied'].includes(
        String(item['status']),
      )
    ) {
      throw new DomainError(409, `Item in stage "${item['status']}" cannot be prepared now`);
    }

    const med = db
      .prepare('SELECT * FROM medicine_products WHERE id = ?')
      .get(String(item['product_id'])) as Record<string, unknown>;

    if (params.barcodeScannedValue.trim() !== String(med['barcode_ean13'])) {
      throw new DomainError(
        400,
        `Barcode mismatch: scanned "${params.barcodeScannedValue}" does not match selected product EAN-13 "${med['barcode_ean13']}"`,
      );
    }

    const outstanding = Number(item['outstanding_qty']);
    if (outstanding <= 0) {
      throw new DomainError(409, 'No outstanding quantity remaining on this item');
    }

    const today = new Date().toISOString().slice(0, 10);
    // FEFO query strictly excludes expired, quarantined, recalled, disposed batches
    const candidateBatches = db
      .prepare(
        `SELECT * FROM stock_batches
         WHERE product_id = ? AND state = 'available' AND expiry_date > ? AND (physical_qty - reserved_qty) > 0
         ORDER BY expiry_date ASC`,
      )
      .all(String(item['product_id']), today) as Record<string, unknown>[];

    const selectedBatch = params.targetBatchId
      ? candidateBatches.find((b) => String(b['id']) === params.targetBatchId)
      : candidateBatches[0];

    if (!selectedBatch) {
      // Check if an explicit expired or quarantined batch was requested to provide clear error
      if (params.targetBatchId) {
        const requested = db
          .prepare('SELECT state, expiry_date, batch_number FROM stock_batches WHERE id = ?')
          .get(params.targetBatchId) as
          | {state: string; expiry_date: string; batch_number: string}
          | undefined;
        if (requested) {
          throw new DomainError(
            409,
            `Batch ${requested.batch_number} is excluded from dispensing (state: ${requested.state}, expiry: ${requested.expiry_date})`,
          );
        }
      }
      throw new DomainError(409, 'No available, unexpired, non-quarantined stock batches for this medicine');
    }

    const batchAvail = Number(selectedBatch['physical_qty']) - Number(selectedBatch['reserved_qty']);
    const requestedPrepare = params.qtyToPrepare ?? Math.min(outstanding, batchAvail);
    if (!Number.isInteger(requestedPrepare) || requestedPrepare <= 0) {
      throw new DomainError(400, 'Quantity to prepare must be a positive integer');
    }
    if (requestedPrepare > outstanding) {
      throw new DomainError(
        400,
        `Cannot prepare ${requestedPrepare} ${item['unit']} when only ${outstanding} ${item['unit']} are outstanding`,
      );
    }
    if (requestedPrepare > batchAvail) {
      throw new DomainError(
        409,
        `Insufficient available stock in batch ${selectedBatch['batch_number']} (available: ${batchAvail} ${item['unit']}, requested: ${requestedPrepare})`,
      );
    }

    const now = new Date().toISOString();
    const isPartial = requestedPrepare < outstanding;
    if (isPartial && !params.partialReason?.trim()) {
      // Provide informative default reason when partial supply occurs due to stock
      params.partialReason = `Partial supply due to stock availability (${requestedPrepare} of ${outstanding} ${item['unit']} available)`;
    }

    // Reserve stock atomically inside BEGIN IMMEDIATE transaction
    db.prepare('UPDATE stock_batches SET reserved_qty = reserved_qty + ? WHERE id = ?').run(
      requestedPrepare,
      String(selectedBatch['id']),
    );

    db.prepare(
      `INSERT INTO stock_movements (
        id, batch_id, product_id, movement_type, qty_delta, unit,
        reference_type, reference_id, actor_id, actor_name, notes, created_at
      ) VALUES (?, ?, ?, 'RESERVATION', ?, ?, 'prescription_item', ?, ?, ?, ?, ?)`,
    ).run(
      `MOV-${randomUUID().slice(0, 8)}`,
      String(selectedBatch['id']),
      String(item['product_id']),
      -requestedPrepare,
      String(item['unit']),
      itemId,
      actor.actorId,
      actor.displayName,
      `FEFO reservation from batch ${selectedBatch['batch_number']}${isPartial ? ' (partial supply)' : ''}`,
      now,
    );

    const owingExpiry = isPartial
      ? new Date(Date.now() + 28 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
      : null;

    db.prepare(
      `UPDATE prescription_items
       SET prepared_qty = ?,
           allocated_batch_id = ?,
           allocated_batch_number = ?,
           allocated_expiry_date = ?,
           barcode_verified = 1,
           barcode_scanned_at = ?,
           barcode_scanned_value = ?,
           prepared_by = ?,
           prepared_at = ?,
           label_generated_at = ?,
           substitution_recorded = COALESCE(?, substitution_recorded),
           partial_reason = COALESCE(?, partial_reason),
           owing_expiry_date = COALESCE(?, owing_expiry_date),
           status = 'Awaiting accuracy check'
       WHERE id = ?`,
    ).run(
      requestedPrepare,
      String(selectedBatch['id']),
      String(selectedBatch['batch_number']),
      String(selectedBatch['expiry_date']),
      now,
      params.barcodeScannedValue.trim(),
      actor.displayName,
      now,
      now,
      params.substitutionNote?.trim() || null,
      params.partialReason?.trim() || null,
      owingExpiry,
      itemId,
    );

    recalculateParentPrescriptionStatus(db, rxId);

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'ITEM_PREPARED_AND_STOCK_RESERVED',
      'prescription_item',
      itemId,
      `Prepared ${requestedPrepare} ${item['unit']} from batch ${selectedBatch['batch_number']} (exp ${selectedBatch['expiry_date']}). Barcode verified (${params.barcodeScannedValue}). Label generated with DEMONSTRATION watermark.`,
      {outstanding},
      {preparedQty: requestedPrepare, batchId: selectedBatch['id'], isPartial},
    );

    return listPrescriptions(db).find((p) => p.id === rxId)!;
  });
}

export function performAccuracyCheck(
  db: DatabaseSync,
  actor: SessionPrincipal,
  itemId: string,
  checkNotes: string,
  emergencyOverride = false,
): Prescription {
  if (!hasStaffPermission(actor.role, 'accuracy_check')) {
    throw new DomainError(403, 'Only an Accuracy Checking Technician (ACT) or Pharmacist can record accuracy checks');
  }

  return runInTransaction(db, () => {
    const item = db.prepare('SELECT * FROM prescription_items WHERE id = ?').get(itemId) as
      | Record<string, unknown>
      | undefined;
    if (!item) throw new DomainError(404, 'Prescription item not found');
    const rxId = String(item['prescription_id']);

    if (String(item['status']) !== 'Awaiting accuracy check') {
      throw new DomainError(409, `Item must be in "Awaiting accuracy check" stage (currently "${item['status']}")`);
    }
    if (Number(item['barcode_verified']) !== 1) {
      throw new DomainError(409, 'Barcode scan verification must be completed before accuracy checking');
    }

    const policy = getOrgPolicy(db);
    if (
      policy.requireSeparatePreparerAndChecker &&
      String(item['prepared_by']) === actor.displayName &&
      !(policy.allowEmergencySelfCheckOverride && emergencyOverride)
    ) {
      throw new DomainError(
        403,
        `Organisational policy requires separate preparer and accuracy checker ("${item['prepared_by']}" cannot self-check this item).`,
      );
    }

    if (
      policy.requireSeparateClinicalAndAccuracyChecker &&
      String(item['clinical_reviewed_by']) === actor.displayName
    ) {
      throw new DomainError(
        403,
        `Organisational policy requires separate clinical reviewer and accuracy checker ("${item['clinical_reviewed_by']}" cannot accuracy-check this item).`,
      );
    }

    const now = new Date().toISOString();
    db.prepare(
      `UPDATE prescription_items
       SET checked_by = ?, checked_at = ?, status = 'Ready for handover'
       WHERE id = ?`,
    ).run(actor.displayName, now, itemId);

    const newRxStatus = recalculateParentPrescriptionStatus(db, rxId);

    // Queue privacy-safe notification (no medicine name in public/SMS summary!)
    const rx = db.prepare('SELECT patient_id, prescription_id FROM prescriptions WHERE id = ?').get(rxId) as {
      patient_id: string;
      prescription_id: string;
    };
    const isPartial = Number(item['prepared_qty']) < Number(item['outstanding_qty']);
    const publicSummary = isPartial
      ? 'Pennine Community Pharmacy: A partial supply of your prescription is ready for collection. Check your patient portal for details.'
      : 'Pennine Community Pharmacy: Your prescription is ready for collection. Check your patient portal for details.';
    const portalDetail = isPartial
      ? `Partial supply ready on ${rx.prescription_id}: ${item['prepared_qty']} ${item['unit']} of ${item['selected_product_name']} prepared (${Number(item['outstanding_qty']) - Number(item['prepared_qty'])} ${item['unit']} will follow when stock arrives).`
      : `Your item (${item['selected_product_name']} x ${item['prepared_qty']} ${item['unit']}) on ${rx.prescription_id} has completed accuracy checking and is ready for handover.`;

    const pat = getPatientById(db, rx.patient_id);
    db.prepare(
      `INSERT INTO notifications (
        id, patient_id, prescription_id, channel, public_summary, portal_detail,
        status, attempts, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'queued', 0, ?)`,
    ).run(
      `NOTIF-${randomUUID().slice(0, 6).toUpperCase()}`,
      rx.patient_id,
      rxId,
      pat?.preferredContact || 'sms',
      publicSummary,
      portalDetail,
      now,
    );

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'ACCURACY_CHECK_COMPLETED',
      'prescription_item',
      itemId,
      `Accuracy check passed by ${actor.displayName}. Notes: ${checkNotes}. Prescription status: ${newRxStatus}.`,
    );

    return listPrescriptions(db).find((p) => p.id === rxId)!;
  });
}

export function recordHandover(
  db: DatabaseSync,
  actor: SessionPrincipal,
  itemId: string,
  params: {
    identityCheckMode: 'patient_photo_id' | 'patient_dob_address' | 'authorised_representative' | 'van_driver_dispatch';
    representativeName?: string;
    paymentCaptured?: boolean;
    paymentMethod?: 'card_sim' | 'cash_sim' | 'exempt_verified';
    notes?: string;
  },
): Prescription {
  if (!hasStaffPermission(actor.role, 'handover')) {
    throw new DomainError(403, 'Role not permitted to record handover');
  }

  return runInTransaction(db, () => {
    const item = db.prepare('SELECT * FROM prescription_items WHERE id = ?').get(itemId) as
      | Record<string, unknown>
      | undefined;
    if (!item) throw new DomainError(404, 'Prescription item not found');
    const rxId = String(item['prescription_id']);
    const rx = db.prepare('SELECT * FROM prescriptions WHERE id = ?').get(rxId) as Record<string, unknown>;

    if (String(item['status']) !== 'Ready for handover') {
      throw new DomainError(
        409,
        `Cannot hand over item in stage "${item['status']}". Clinical review and accuracy check must be completed first.`,
      );
    }

    const qtyHandedOver = Number(item['prepared_qty']);
    if (qtyHandedOver <= 0) {
      throw new DomainError(409, 'Prepared quantity is zero');
    }

    const batchId = item['allocated_batch_id'] ? String(item['allocated_batch_id']) : null;
    if (!batchId) {
      throw new DomainError(409, 'No allocated batch found on item');
    }

    const batch = db.prepare('SELECT * FROM stock_batches WHERE id = ?').get(batchId) as
      | Record<string, unknown>
      | undefined;
    if (!batch) throw new DomainError(404, 'Allocated batch not found');
    if (String(batch['state']) === 'recalled' || String(batch['state']) === 'quarantined') {
      throw new DomainError(
        409,
        `Handover blocked: allocated batch ${batch['batch_number']} is currently ${batch['state']}`,
      );
    }

    // Handle payment if chargeable
    const chargePence = Number(rx['charge_total_pence']);
    const paymentStatus = String(rx['payment_status']);
    if (chargePence > 0 && paymentStatus === 'unpaid') {
      if (!params.paymentCaptured && params.paymentMethod !== 'exempt_verified') {
        throw new DomainError(
          402,
          `Prescription has unpaid NHS charge of £${(chargePence / 100).toFixed(2)}. Record payment or verified exemption before handover.`,
        );
      }
      const nowPay = new Date().toISOString();
      db.prepare(
        `INSERT INTO financial_transactions (
          id, tx_type, prescription_id, patient_id, description, amount_pence,
          payment_method, exemption_code, status, actor_name, created_at
        ) VALUES (?, 'nhs_charge', ?, ?, ?, ?, ?, ?, 'captured_simulated', ?, ?)`,
      ).run(
        `TX-${randomUUID().slice(0, 8).toUpperCase()}`,
        rxId,
        String(rx['patient_id']),
        `NHS England Prescription Charge (${rxId})`,
        params.paymentMethod === 'exempt_verified' ? 0 : chargePence,
        params.paymentMethod || 'card_sim',
        params.paymentMethod === 'exempt_verified' ? 'EXEMPT_VERIFIED_AT_COUNTER' : null,
        actor.displayName,
        nowPay,
      );
      db.prepare('UPDATE prescriptions SET payment_status = ? WHERE id = ?').run(
        params.paymentMethod === 'exempt_verified' ? 'not_applicable' : 'paid_simulated',
        rxId,
      );
    }

    const now = new Date().toISOString();
    // Consume reserved physical stock
    db.prepare(
      `UPDATE stock_batches
       SET physical_qty = physical_qty - ?, reserved_qty = reserved_qty - ?
       WHERE id = ?`,
    ).run(qtyHandedOver, qtyHandedOver, batchId);

    db.prepare(
      `INSERT INTO stock_movements (
        id, batch_id, product_id, movement_type, qty_delta, unit,
        reference_type, reference_id, actor_id, actor_name, notes, created_at
      ) VALUES (?, ?, ?, 'DISPENSING_CONSUMPTION', ?, ?, 'prescription_item', ?, ?, ?, ?, ?)`,
    ).run(
      `MOV-${randomUUID().slice(0, 8)}`,
      batchId,
      String(item['product_id']),
      -qtyHandedOver,
      String(item['unit']),
      itemId,
      actor.actorId,
      actor.displayName,
      `Handed over (${params.identityCheckMode}${params.representativeName ? `: ${params.representativeName}` : ''})`,
      now,
    );

    // If Schedule 2 Controlled Drug, record CD register supply entry!
    if (String(item['legal_category']) === 'CD2') {
      const lastEntry = db
        .prepare('SELECT entry_number, running_balance FROM cd_register_entries WHERE product_id = ? ORDER BY entry_number DESC LIMIT 1')
        .get(String(item['product_id'])) as {entry_number: number; running_balance: number} | undefined;
      const nextNum = (lastEntry?.entry_number ?? 0) + 1;
      const newBalance = (lastEntry?.running_balance ?? 0) - qtyHandedOver;
      const pat = getPatientById(db, String(rx['patient_id']));
      db.prepare(
        `INSERT INTO cd_register_entries (
          id, entry_number, product_id, entry_type, prescription_ref, patient_or_supplier,
          qty_received, qty_supplied, running_balance, unit, batch_number,
          actor_id, actor_name, created_at
        ) VALUES (?, ?, ?, 'supply', ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        `CD-ENT-${randomUUID().slice(0, 6)}`,
        nextNum,
        String(item['product_id']),
        rxId,
        `${pat?.fullName || 'Patient'} (${pat?.addressLine1 || ''})`,
        qtyHandedOver,
        newBalance,
        String(item['unit']),
        String(batch['batch_number']),
        actor.actorId,
        actor.displayName,
        now,
      );
    }

    const newSupplied = Number(item['supplied_qty']) + qtyHandedOver;
    const newOutstanding = Number(item['prescribed_qty']) - newSupplied - Number(item['cancelled_qty']);
    const nextItemStatus: PrescriptionItemStage = newOutstanding > 0 ? 'Partially supplied' : 'Completed';

    db.prepare(
      `UPDATE prescription_items
       SET supplied_qty = ?,
           outstanding_qty = ?,
           prepared_qty = 0,
           allocated_batch_id = NULL,
           allocated_batch_number = NULL,
           allocated_expiry_date = NULL,
           barcode_verified = 0,
           handed_over_by = ?,
           handed_over_at = ?,
           status = ?
       WHERE id = ?`,
    ).run(newSupplied, newOutstanding, actor.displayName, now, nextItemStatus, itemId);

    const newRxStatus = recalculateParentPrescriptionStatus(db, rxId);

    if (params.identityCheckMode === 'van_driver_dispatch') {
      db.prepare(
        `INSERT INTO deliveries (
          id, prescription_id, patient_id, driver_name, route_zone, status,
          recipient_checked, dispatched_at, notes
        ) VALUES (?, ?, ?, 'Marcus Cole (Van 1)', 'HX7 Local Delivery', 'dispatched', ?, ?, ?)`,
      ).run(
        `DEL-${randomUUID().slice(0, 6).toUpperCase()}`,
        rxId,
        String(rx['patient_id']),
        params.representativeName || 'Patient doorstep signature pending',
        now,
        params.notes || 'Dispatched — awaiting confirmed receipt (dispatched is NOT confirmed receipt).',
      );
    }

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'HANDOVER_RECORDED',
      'prescription_item',
      itemId,
      `Handed over ${qtyHandedOver} ${item['unit']} (${params.identityCheckMode}). Supplied total: ${newSupplied}/${item['prescribed_qty']}. Outstanding: ${newOutstanding}. Rx status: ${newRxStatus}.`,
    );

    return listPrescriptions(db).find((p) => p.id === rxId)!;
  });
}

export function processCancellationMessage(
  db: DatabaseSync,
  actor: SessionPrincipal,
  params: {
    prescriptionId: string;
    idempotencyKey: string;
    reason: string;
  },
): {duplicate: boolean; prescription: Prescription; message: string} {
  return runInTransaction(db, () => {
    const existingMsg = db
      .prepare('SELECT id, received_at FROM processed_messages WHERE idempotency_key = ?')
      .get(params.idempotencyKey) as {id: string; received_at: string} | undefined;

    if (existingMsg) {
      const rx = listPrescriptions(db).find((p) => p.id === params.prescriptionId);
      if (!rx) throw new DomainError(404, 'Prescription not found');
      appendAudit(
        db,
        {id: actor.actorId, name: actor.displayName, role: actor.role},
        'DUPLICATE_CANCELLATION_IGNORED',
        'prescription',
        params.prescriptionId,
        `Duplicate cancellation message (${params.idempotencyKey}) safely ignored via idempotency log.`,
      );
      return {
        duplicate: true,
        prescription: rx,
        message: `Duplicate cancellation message (${params.idempotencyKey}) safely detected and ignored without double-processing.`,
      };
    }

    const items = db
      .prepare('SELECT * FROM prescription_items WHERE prescription_id = ?')
      .all(params.prescriptionId) as Record<string, unknown>[];
    if (items.length === 0) {
      throw new DomainError(404, 'Prescription not found');
    }

    const now = new Date().toISOString();
    for (const item of items) {
      const preparedQty = Number(item['prepared_qty']);
      const batchId = item['allocated_batch_id'] ? String(item['allocated_batch_id']) : null;
      if (preparedQty > 0 && batchId) {
        db.prepare('UPDATE stock_batches SET reserved_qty = MAX(0, reserved_qty - ?) WHERE id = ?').run(
          preparedQty,
          batchId,
        );
        db.prepare(
          `INSERT INTO stock_movements (
            id, batch_id, product_id, movement_type, qty_delta, unit,
            reference_type, reference_id, actor_id, actor_name, notes, created_at
          ) VALUES (?, ?, ?, 'RESERVATION_RELEASE', ?, ?, 'prescription', ?, ?, ?, ?, ?)`,
        ).run(
          `MOV-${randomUUID().slice(0, 8)}`,
          batchId,
          String(item['product_id']),
          preparedQty,
          String(item['unit']),
          params.prescriptionId,
          actor.actorId,
          actor.displayName,
          `Released unconsumed reservation on cancellation: ${params.reason}`,
          now,
        );
      }

      const outstanding = Number(item['outstanding_qty']);
      const supplied = Number(item['supplied_qty']);
      const itemStatus: PrescriptionItemStage = supplied > 0 ? 'Partially supplied' : 'Cancelled';

      db.prepare(
        `UPDATE prescription_items
         SET cancelled_qty = cancelled_qty + outstanding_qty,
             outstanding_qty = 0,
             prepared_qty = 0,
             allocated_batch_id = NULL,
             allocated_batch_number = NULL,
             allocated_expiry_date = NULL,
             status = ?
         WHERE id = ?`,
      ).run(itemStatus, String(item['id']));

      if (outstanding > 0 && supplied > 0) {
        // Note: partially supplied then remaining cancelled
      }
    }

    recalculateParentPrescriptionStatus(db, params.prescriptionId);

    db.prepare(
      `INSERT INTO processed_messages (id, message_type, idempotency_key, prescription_id, status, received_at, notes)
       VALUES (?, 'EPS_CANCELLATION', ?, ?, 'processed', ?, ?)`,
    ).run(
      `MSG-${randomUUID().slice(0, 6)}`,
      params.idempotencyKey,
      params.prescriptionId,
      now,
      params.reason,
    );

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'PRESCRIPTION_CANCELLED',
      'prescription',
      params.prescriptionId,
      `Processed cancellation (${params.idempotencyKey}): ${params.reason}`,
    );

    return {
      duplicate: false,
      prescription: listPrescriptions(db).find((p) => p.id === params.prescriptionId)!,
      message: `Cancellation applied cleanly to ${params.prescriptionId}; unconsumed stock reservations released.`,
    };
  });
}

export function receiveProcurementGoods(
  db: DatabaseSync,
  actor: SessionPrincipal,
  orderId: string,
  params: {
    productId: string;
    receivedGoodPacks: number;
    damagedPacks: number;
    batchNumber: string;
    expiryDate: string;
    unitCostPence?: number;
    notes?: string;
  },
): {order: Record<string, unknown>; batchesCreated: StockBatch[]} {
  if (!hasStaffPermission(actor.role, 'procurement')) {
    throw new DomainError(403, 'Role not permitted to receive goods');
  }

  return runInTransaction(db, () => {
    const order = db.prepare('SELECT * FROM procurement_orders WHERE id = ?').get(orderId) as
      | Record<string, unknown>
      | undefined;
    if (!order) throw new DomainError(404, 'Purchase order not found');

    const med = db.prepare('SELECT * FROM medicine_products WHERE id = ?').get(params.productId) as
      | Record<string, unknown>
      | undefined;
    if (!med) throw new DomainError(404, 'Product not found');

    const packSize = Number(med['pack_size']);
    const unit = String(med['quantity_unit']) as StockBatch['unit'];
    const costPence = params.unitCostPence ?? Number(med['nhs_tariff_pence']);
    const now = new Date().toISOString();
    const batchesCreated: StockBatch[] = [];

    if (params.receivedGoodPacks > 0) {
      const goodUnits = params.receivedGoodPacks * packSize;
      const batchId = `BAT-${randomUUID().slice(0, 6).toUpperCase()}`;
      const location = Number(med['cold_chain_required']) === 1 ? 'Cold Chain Fridge 1' : 'Dispensary Bay A';

      db.prepare(
        `INSERT INTO stock_batches (
          id, branch_id, location, product_id, batch_number, expiry_date,
          physical_qty, reserved_qty, state, unit, cost_pence_per_pack, received_at
        ) VALUES (?, 'BR-PENNINE-01', ?, ?, ?, ?, ?, 0, 'available', ?, ?, ?)`,
      ).run(batchId, location, params.productId, params.batchNumber, params.expiryDate, goodUnits, unit, costPence, now);

      db.prepare(
        `INSERT INTO stock_movements (
          id, batch_id, product_id, movement_type, qty_delta, unit,
          reference_type, reference_id, actor_id, actor_name, notes, created_at
        ) VALUES (?, ?, ?, 'GOODS_RECEIPT', ?, ?, 'procurement_order', ?, ?, ?, ?, ?)`,
      ).run(
        `MOV-${randomUUID().slice(0, 8)}`,
        batchId,
        params.productId,
        goodUnits,
        unit,
        orderId,
        actor.actorId,
        actor.displayName,
        `Received ${params.receivedGoodPacks} pack(s) (${goodUnits} ${unit}) on ${order['order_number']}`,
        now,
      );

      batchesCreated.push({
        id: batchId,
        branchId: 'BR-PENNINE-01',
        location,
        productId: params.productId,
        batchNumber: params.batchNumber,
        expiryDate: params.expiryDate,
        physicalQty: goodUnits,
        reservedQty: 0,
        availableQty: goodUnits,
        state: 'available',
        unit,
        costPencePerPack: costPence,
        receivedAt: now,
        quarantineReason: null,
      });

      // Automatically promote 'Awaiting stock' items for this product to 'Ready for preparation'
      const awaitingItems = db
        .prepare(
          `SELECT id, prescription_id FROM prescription_items
           WHERE product_id = ? AND status = 'Awaiting stock'`,
        )
        .all(params.productId) as {id: string; prescription_id: string}[];

      for (const ai of awaitingItems) {
        db.prepare(`UPDATE prescription_items SET status = 'Ready for preparation' WHERE id = ?`).run(
          ai.id,
        );
        recalculateParentPrescriptionStatus(db, ai.prescription_id);
      }
    }

    if (params.damagedPacks > 0) {
      const dmgUnits = params.damagedPacks * packSize;
      const qBatchId = `BAT-DMG-${randomUUID().slice(0, 5).toUpperCase()}`;
      db.prepare(
        `INSERT INTO stock_batches (
          id, branch_id, location, product_id, batch_number, expiry_date,
          physical_qty, reserved_qty, state, unit, cost_pence_per_pack, received_at, quarantine_reason
        ) VALUES (?, 'BR-PENNINE-01', 'Quarantine Cage', ?, ?, ?, ?, 0, 'quarantined', ?, ?, ?, ?)`,
      ).run(
        qBatchId,
        params.productId,
        `${params.batchNumber}-DMG`,
        params.expiryDate,
        dmgUnits,
        unit,
        costPence,
        now,
        'Damaged in transit on goods receipt — quarantined for wholesaler credit',
      );
    }

    const lines = JSON.parse(String(order['lines_json'])) as Record<string, unknown>[];
    for (const line of lines) {
      if (line['productId'] === params.productId) {
        line['receivedPacks'] = Number(line['receivedPacks'] || 0) + params.receivedGoodPacks;
        line['damagedPacks'] = Number(line['damagedPacks'] || 0) + params.damagedPacks;
        line['unitCostPence'] = costPence;
      }
    }
    const allSatisfied = lines.every(
      (l) => Number(l['receivedPacks'] || 0) >= Number(l['orderedPacks'] || 0),
    );
    const nextOrderStatus = allSatisfied ? 'Reconciled' : 'Partially received';

    db.prepare(
      `UPDATE procurement_orders SET status = ?, updated_at = ?, lines_json = ?, notes = COALESCE(?, notes)
       WHERE id = ?`,
    ).run(nextOrderStatus, now, JSON.stringify(lines), params.notes || null, orderId);

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'GOODS_RECEIVED',
      'procurement_order',
      orderId,
      `Goods receipt on ${order['order_number']}: ${params.receivedGoodPacks} good pack(s), ${params.damagedPacks} damaged pack(s) quarantined. Batch ${params.batchNumber}.`,
    );

    return {
      order: db.prepare('SELECT * FROM procurement_orders WHERE id = ?').get(orderId) as Record<string, unknown>,
      batchesCreated,
    };
  });
}

export function triggerBatchRecall(
  db: DatabaseSync,
  actor: SessionPrincipal,
  params: {
    recallRef: string;
    source: string;
    classification: string;
    productId: string;
    affectedBatchNumber: string;
    reason: string;
  },
): Record<string, unknown> {
  if (!hasStaffPermission(actor.role, 'recall_action')) {
    throw new DomainError(403, 'Role not permitted to action batch recalls');
  }

  return runInTransaction(db, () => {
    const existing = db
      .prepare('SELECT * FROM recalls WHERE recall_ref = ?')
      .get(params.recallRef) as Record<string, unknown> | undefined;
    if (existing) {
      return existing;
    }

    const now = new Date().toISOString();
    const matchingBatches = db
      .prepare('SELECT * FROM stock_batches WHERE product_id = ? AND batch_number = ?')
      .all(params.productId, params.affectedBatchNumber) as Record<string, unknown>[];

    let quarantinedQty = 0;
    for (const b of matchingBatches) {
      quarantinedQty += Number(b['physical_qty']);
      db.prepare(
        `UPDATE stock_batches
         SET state = 'recalled', location = 'Quarantine Cage',
             quarantine_reason = ?
         WHERE id = ?`,
      ).run(`RECALL ${params.recallRef}: ${params.reason}`, String(b['id']));

      db.prepare(
        `INSERT INTO stock_movements (
          id, batch_id, product_id, movement_type, qty_delta, unit,
          reference_type, reference_id, actor_id, actor_name, notes, created_at
        ) VALUES (?, ?, ?, 'RECALL_QUARANTINE', 0, ?, 'recall', ?, ?, ?, ?, ?)`,
      ).run(
        `MOV-${randomUUID().slice(0, 8)}`,
        String(b['id']),
        params.productId,
        String(b['unit']),
        params.recallRef,
        actor.actorId,
        actor.displayName,
        `Quarantined batch ${params.affectedBatchNumber} under ${params.recallRef}`,
        now,
      );
    }

    // Identify patients who previously received supplies from this batch
    const suppliedMovements = db
      .prepare(
        `SELECT DISTINCT p.id as prescription_id, pat.id as patient_id, pat.full_name, pat.internal_id, sb.batch_number
         FROM stock_movements sm
         JOIN stock_batches sb ON sm.batch_id = sb.id
         JOIN prescription_items pi ON sm.reference_id = pi.id
         JOIN prescriptions p ON pi.prescription_id = p.id
         JOIN patients pat ON p.patient_id = pat.id
         WHERE sb.product_id = ? AND sb.batch_number = ? AND sm.movement_type = 'DISPENSING_CONSUMPTION'`,
      )
      .all(params.productId, params.affectedBatchNumber) as Record<string, unknown>[];

    const affectedPatients = suppliedMovements.map((m) => ({
      patientId: String(m['patient_id']),
      internalId: String(m['internal_id']),
      fullName: String(m['full_name']),
      prescriptionId: String(m['prescription_id']),
      reviewStatus: 'Pending pharmacist review — do not auto-issue clinical advice',
    }));

    const recallId = `REC-${randomUUID().slice(0, 6).toUpperCase()}`;
    const investigationLog = [
      {
        timestamp: now,
        actor: actor.displayName,
        note: `Recall imported from ${params.source}. Quarantined ${quarantinedQty} unit(s). ${affectedPatients.length} patient supply review task(s) created. Automated patient clinical advice intentionally blocked pending pharmacist review.`,
      },
    ];

    db.prepare(
      `INSERT INTO recalls (
        id, recall_ref, source, classification, product_id, affected_batch_number,
        reason, status, created_at, quarantined_qty, affected_patients_json, investigation_log_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Quarantined — Investigation Open', ?, ?, ?, ?)`,
    ).run(
      recallId,
      params.recallRef,
      params.source,
      params.classification,
      params.productId,
      params.affectedBatchNumber,
      params.reason,
      now,
      quarantinedQty,
      JSON.stringify(affectedPatients),
      JSON.stringify(investigationLog),
    );

    appendAudit(
      db,
      {id: actor.actorId, name: actor.displayName, role: actor.role},
      'BATCH_RECALL_QUARANTINED',
      'recall',
      recallId,
      `Recall ${params.recallRef} quarantined batch ${params.affectedBatchNumber} (${quarantinedQty} units). ${affectedPatients.length} supply review task(s) created.`,
    );

    return db.prepare('SELECT * FROM recalls WHERE id = ?').get(recallId) as Record<string, unknown>;
  });
}

export function runReproducibleDemoStep(
  db: DatabaseSync,
  actor: SessionPrincipal,
  stepNumber: number,
): {step: number; title: string; detail: string; status: 'completed'} {
  const stepMap: Record<number, () => {title: string; detail: string}> = {
    1: () => {
      const existing = db
        .prepare(`SELECT id FROM prescriptions WHERE source_identifier = 'EPS-DEMO-STEP1'`)
        .get() as {id: string} | undefined;
      if (existing) {
        return {
          title: 'Step 1: Receive synthetic prescription',
          detail: `Synthetic prescription ${existing.id} (Atorvastatin 20mg tablets x 28) already received.`,
        };
      }
      const rx = intakePrescription(db, actor, {
        sourceIdentifier: 'EPS-DEMO-STEP1',
        sourceSystem: 'NHS_EPS_SIM',
        patientId: null,
        patientReference: 'Arthur Pendelton · DOB 1951-04-12 · NHS 943 476 5821',
        prescriberDetails: 'Dr. R. Ellis · Hebden Bridge Group Practice',
        productId: 'MED-ATOR-20',
        prescribedQty: 28,
        directionsAsReceived: 'Take ONE tablet each night',
      });
      return {
        title: 'Step 1: Receive synthetic prescription',
        detail: `Received ${rx.id} (Atorvastatin 20mg tablets x 28) via NHS_EPS_SIM.`,
      };
    },
    2: () => {
      const rx = db
        .prepare(`SELECT id, match_status FROM prescriptions WHERE source_identifier = 'EPS-DEMO-STEP1'`)
        .get() as {id: string; match_status: string} | undefined;
      if (!rx) throw new DomainError(409, 'Run Step 1 first to receive EPS-DEMO-STEP1');
      if (rx.match_status === 'matched') {
        return {
          title: 'Step 2: Match the patient',
          detail: `${rx.id} already matched to Arthur Pendelton (PEN-PAT-001001).`,
        };
      }
      matchPatientToPrescription(
        db,
        actor,
        rx.id,
        'PAT-1001',
        'Verified NHS 943 476 5821 & DOB 1951-04-12 — Penicillin allergy recorded, large-print label noted.',
      );
      return {
        title: 'Step 2: Match the patient',
        detail: `Matched ${rx.id} to Arthur Pendelton (PEN-PAT-001001).`,
      };
    },
    3: () => {
      const item = db
        .prepare(
          `SELECT pi.id, pi.clinical_decision FROM prescription_items pi
           JOIN prescriptions p ON pi.prescription_id = p.id
           WHERE p.source_identifier = 'EPS-DEMO-STEP1'`,
        )
        .get() as {id: string; clinical_decision: string} | undefined;
      if (!item) throw new DomainError(409, 'Run Steps 1–2 first');
      if (item.clinical_decision === 'approved') {
        return {
          title: 'Step 3: Complete authorised review',
          detail: `Item ${item.id} clinically approved by pharmacist.`,
        };
      }
      performClinicalReview(
        db,
        actor,
        item.id,
        'approved',
        'Clinically appropriate dose (20mg ON). Patient requires large-print label.',
      );
      return {
        title: 'Step 3: Complete authorised review',
        detail: `Pharmacist clinical review approved for item ${item.id}.`,
      };
    },
    4: () => {
      const item = db
        .prepare(
          `SELECT pi.id, pi.status, pi.outstanding_qty FROM prescription_items pi
           JOIN prescriptions p ON pi.prescription_id = p.id
           WHERE p.source_identifier = 'EPS-DEMO-STEP1'`,
        )
        .get() as {id: string; status: string; outstanding_qty: number} | undefined;
      if (!item) throw new DomainError(409, 'Run Steps 1–3 first');
      const avail = db
        .prepare(
          `SELECT COALESCE(SUM(physical_qty - reserved_qty), 0) as qty FROM stock_batches WHERE product_id = 'MED-ATOR-20' AND state = 'available'`,
        )
        .get() as {qty: number};
      return {
        title: 'Step 4: Detect insufficient stock',
        detail: `Item ${item.id} requires ${item.outstanding_qty} tablets; available stock is ${avail.qty} tablets (${item.status}).`,
      };
    },
    5: () => {
      const item = db
        .prepare(
          `SELECT pi.id, pi.status, pi.prepared_qty FROM prescription_items pi
           JOIN prescriptions p ON pi.prescription_id = p.id
           WHERE p.source_identifier = 'EPS-DEMO-STEP1'`,
        )
        .get() as {id: string; status: string; prepared_qty: number} | undefined;
      if (!item) throw new DomainError(409, 'Run Steps 1–4 first');
      if (item.status === 'Awaiting accuracy check' || item.status === 'Ready for handover' || item.status === 'Partially supplied' || item.status === 'Completed') {
        return {
          title: 'Step 5: Prepare a partial supply',
          detail: `Partial supply already prepared for item ${item.id}.`,
        };
      }
      allocateStockAndPrepare(db, actor, item.id, {
        qtyToPrepare: 14,
        partialReason: 'Only 14 of 28 Atorvastatin 20mg tablets available; 14 owing on PO-2026-0101',
        barcodeScannedValue: '5012345000101',
      });
      return {
        title: 'Step 5: Prepare a partial supply',
        detail: `Allocated 14 tablets from batch AT26-441, verified EAN-13 5012345000101, generated DEMONSTRATION label.`,
      };
    },
    6: () => {
      const item = db
        .prepare(
          `SELECT pi.id, pi.status FROM prescription_items pi
           JOIN prescriptions p ON pi.prescription_id = p.id
           WHERE p.source_identifier = 'EPS-DEMO-STEP1'`,
        )
        .get() as {id: string; status: string} | undefined;
      if (!item) throw new DomainError(409, 'Run Steps 1–5 first');
      if (item.status === 'Ready for handover' || item.status === 'Partially supplied' || item.status === 'Completed') {
        return {
          title: 'Step 6: Perform and record accuracy checking',
          detail: `Accuracy check already recorded for ${item.id}.`,
        };
      }
      // Use ACT Liam Patel if current actor is the preparer to honour role separation!
      const checker: SessionPrincipal = {
        token: actor.token,
        actorType: 'staff',
        actorId: 'STF-ACT-01',
        role: 'act',
        displayName: 'Liam Patel',
        expiresAt: actor.expiresAt,
      };
      performAccuracyCheck(
        db,
        checker,
        item.id,
        'Checked 14 tablets batch AT26-441, large-print demonstration label & owing slip.',
      );
      return {
        title: 'Step 6: Perform and record accuracy checking',
        detail: `Accuracy check recorded by Liam Patel (ACT) — separate from preparer.`,
      };
    },
    7: () => {
      const notif = db
        .prepare(
          `SELECT n.id, n.status, n.public_summary FROM notifications n
           JOIN prescriptions p ON n.prescription_id = p.id
           WHERE p.source_identifier = 'EPS-DEMO-STEP1'
           ORDER BY n.created_at DESC LIMIT 1`,
        )
        .get() as {id: string; status: string; public_summary: string} | undefined;
      if (!notif) throw new DomainError(409, 'Run Steps 1–6 first');
      db.prepare(`UPDATE notifications SET status = 'sent', sent_at = ?, attempts = attempts + 1 WHERE id = ?`).run(
        new Date().toISOString(),
        notif.id,
      );
      return {
        title: 'Step 7: Notify the patient',
        detail: `Notification ${notif.id} sent via SMS (medicine name redacted): "${notif.public_summary}"`,
      };
    },
    8: () => {
      const item = db
        .prepare(
          `SELECT pi.id, pi.status FROM prescription_items pi
           JOIN prescriptions p ON pi.prescription_id = p.id
           WHERE p.source_identifier = 'EPS-DEMO-STEP1'`,
        )
        .get() as {id: string; status: string} | undefined;
      if (!item) throw new DomainError(409, 'Run Steps 1–7 first');
      if (item.status === 'Partially supplied' || item.status === 'Completed') {
        return {
          title: 'Step 8: Record handover',
          detail: `Partial supply handover already recorded (14 supplied, 14 outstanding).`,
        };
      }
      recordHandover(db, actor, item.id, {
        identityCheckMode: 'authorised_representative',
        representativeName: 'Claire Pendelton (Daughter — ID verified)',
        notes: 'Partial supply handed over; owing slip issued for remaining 14 tablets.',
      });
      return {
        title: 'Step 8: Record handover',
        detail: `Handed over 14 tablets to Claire Pendelton (authorised representative). 14 tablets remain outstanding.`,
      };
    },
    9: () => {
      const order = db
        .prepare(`SELECT id, status FROM procurement_orders WHERE id = 'PO-2026-0101'`)
        .get() as {id: string; status: string};
      if (order.status === 'Reconciled') {
        return {
          title: 'Step 9: Receive replacement stock',
          detail: `PO-2026-0101 already received and reconciled (56 Atorvastatin 20mg tablets).`,
        };
      }
      receiveProcurementGoods(db, actor, 'PO-2026-0101', {
        productId: 'MED-ATOR-20',
        receivedGoodPacks: 2,
        damagedPacks: 0,
        batchNumber: 'AT26-990',
        expiryDate: '2028-04-30',
        notes: 'Replenishment delivery received in full.',
      });
      return {
        title: 'Step 9: Receive replacement stock',
        detail: `Received 2 x 28 packs (56 tablets) of Atorvastatin 20mg (Batch AT26-990, Exp 2028-04-30).`,
      };
    },
    10: () => {
      const item = db
        .prepare(
          `SELECT pi.id, pi.status, pi.outstanding_qty, pi.prescription_id FROM prescription_items pi
           JOIN prescriptions p ON pi.prescription_id = p.id
           WHERE p.source_identifier = 'EPS-DEMO-STEP1'`,
        )
        .get() as {id: string; status: string; outstanding_qty: number; prescription_id: string} | undefined;
      if (!item) throw new DomainError(409, 'Run Steps 1–9 first');
      if (item.status === 'Completed' && item.outstanding_qty === 0) {
        return {
          title: 'Step 10: Complete the outstanding supply',
          detail: `Outstanding supply on ${item.prescription_id} already completed.`,
        };
      }
      if (item.status === 'Partially supplied') {
        allocateStockAndPrepare(db, actor, item.id, {
          qtyToPrepare: item.outstanding_qty,
          barcodeScannedValue: '5012345000101',
        });
        const checker: SessionPrincipal = {
          token: actor.token,
          actorType: 'staff',
          actorId: 'STF-ACT-01',
          role: 'act',
          displayName: 'Liam Patel',
          expiresAt: actor.expiresAt,
        };
        performAccuracyCheck(db, checker, item.id, 'Checked remaining 14 tablets from batch AT26-990.');
        recordHandover(db, actor, item.id, {
          identityCheckMode: 'patient_dob_address',
          notes: 'Outstanding balance of 14 tablets handed over.',
        });
      }
      return {
        title: 'Step 10: Complete the outstanding supply',
        detail: `Prepared, accuracy-checked, and handed over remaining 14 tablets on ${item.prescription_id}. Prescription now Completed.`,
      };
    },
    11: () => {
      const rx = intakePrescription(db, actor, {
        sourceIdentifier: `EPS-CANCEL-TARGET-${Date.now().toString().slice(-4)}`,
        sourceSystem: 'NHS_EPS_SIM',
        patientId: 'PAT-1002',
        patientReference: 'NHS 943 512 0944 | Meera Sharma',
        prescriberDetails: 'Dr. S. Iqbal',
        productId: 'MED-LEVO-50',
        prescribedQty: 28,
        directionsAsReceived: 'Take ONE tablet daily',
      });
      const key = `CANCEL-${rx.id}`;
      const first = processCancellationMessage(db, actor, {
        prescriptionId: rx.id,
        idempotencyKey: key,
        reason: 'GP switched therapy before dispensing',
      });
      const second = processCancellationMessage(db, actor, {
        prescriptionId: rx.id,
        idempotencyKey: key,
        reason: 'GP switched therapy before dispensing',
      });
      return {
        title: 'Step 11: Process a duplicate cancellation message safely',
        detail: `First call: ${first.message} | Second duplicate call: ${second.message}`,
      };
    },
    12: () => {
      const recall = triggerBatchRecall(db, actor, {
        recallRef: 'MHRA-EL(26)A/14-DEMO',
        source: 'MHRA Drug Alert Prototype Feed',
        classification: 'Class 2 Medicines Recall',
        productId: 'MED-AMOX-500',
        affectedBatchNumber: 'BATCH-AMX-REC',
        reason: 'Out-of-specification dissolution profile in stability testing (Synthetic Demo)',
      });
      return {
        title: 'Step 12: Quarantine a recalled batch',
        detail: `Quarantined ${recall['quarantined_qty']} capsules of BATCH-AMX-REC and created patient review task for George Barlow (RX-2026-4005).`,
      };
    },
    13: () => {
      const existing = db
        .prepare(`SELECT id FROM service_appointments WHERE id = 'APT-DEMO-13'`)
        .get() as {id: string} | undefined;
      if (existing) {
        return {
          title: 'Step 13: Book a pharmacy-service appointment',
          detail: 'Appointment APT-DEMO-13 (NHS Pharmacy First Consultation) already booked.',
        };
      }
      db.prepare(
        `INSERT INTO service_appointments (
          id, service_id, patient_id, practitioner_id, scheduled_at, status,
          consent_recorded, attendance_status, follow_up_task, notes, created_at
        ) VALUES ('APT-DEMO-13', 'SVC-PHARM-FIRST', 'PAT-1004', 'STF-PHARM-01', ?, 'booked', 1, 'pending', 'Record clinical pathway outcome', 'Booked during reproducible demonstration', ?)`,
      ).run(new Date(Date.now() + 86400000).toISOString(), new Date().toISOString());
      appendAudit(
        db,
        {id: actor.actorId, name: actor.displayName, role: actor.role},
        'SERVICE_APPOINTMENT_BOOKED',
        'service_appointment',
        'APT-DEMO-13',
        'Booked NHS Pharmacy First Consultation for Eleanor Vance with Dr. Hannah Whitaker.',
      );
      return {
        title: 'Step 13: Book a pharmacy-service appointment',
        detail: 'Booked APT-DEMO-13 (NHS Pharmacy First Consultation) for Eleanor Vance in Consultation Room 1.',
      };
    },
    14: () => {
      const auditCount = (db.prepare('SELECT COUNT(*) as cnt FROM audit_events').get() as {cnt: number}).cnt;
      const batchCount = (db.prepare('SELECT COUNT(*) as cnt FROM stock_batches').get() as {cnt: number}).cnt;
      return {
        title: 'Step 14: Review stock and audit reports',
        detail: `Audit trail verified (${auditCount} immutable events across ${batchCount} stock batches). Reports & FP34C summary ready.`,
      };
    },
  };

  const fn = stepMap[stepNumber];
  if (!fn) {
    throw new DomainError(400, `Demo step ${stepNumber} out of range (1–14)`);
  }
  const result = fn();
  return {step: stepNumber, ...result, status: 'completed'};
}
