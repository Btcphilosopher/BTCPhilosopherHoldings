import {randomUUID} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import express, {type NextFunction, type Request, type Response} from 'express';
import {getExternalAdaptersStatus, PROTOTYPE_HAZARD_LOG} from './modules/adapters';
import {
  authenticateBearer,
  createSession,
  hasStaffPermission,
  listStaffUsers,
  verifyPassword,
  type SessionPrincipal,
} from './modules/auth';
import {
  allocateStockAndPrepare,
  appendAudit,
  DomainError,
  getOrgPolicy,
  getPatientById,
  intakePrescription,
  listPatients,
  listPrescriptions,
  listStockBatches,
  matchPatientToPrescription,
  performAccuracyCheck,
  performClinicalReview,
  previewClinicalKnowledgeForItem,
  processCancellationMessage,
  receiveProcurementGoods,
  recordHandover,
  runReproducibleDemoStep,
  triggerBatchRecall,
  verifyUploadedDocument,
} from './modules/pharmacy-engine';
import {seedDatabaseIfEmpty} from './db/seed';
import {runWorkerCycle} from './modules/worker';

interface AuthedRequest extends Request {
  principal?: SessionPrincipal;
}

export function createApiRouter(db: DatabaseSync): express.Router {
  const router = express.Router();
  router.use(express.json({limit: '2mb'}));

  const requireAuth = (req: AuthedRequest, res: Response, next: NextFunction): void => {
    const principal = authenticateBearer(db, req.headers.authorization);
    if (!principal) {
      res.status(401).json({error: 'Authentication required (missing or expired Bearer session)'});
      return;
    }
    req.principal = principal;
    next();
  };

  const requireStaff = (req: AuthedRequest, res: Response, next: NextFunction): void => {
    requireAuth(req, res, () => {
      if (req.principal?.actorType !== 'staff') {
        res.status(403).json({error: 'Staff session required'});
        return;
      }
      next();
    });
  };

  const wrap =
    (handler: (req: AuthedRequest, res: Response) => unknown) =>
    (req: AuthedRequest, res: Response): void => {
      try {
        const result = handler(req, res);
        if (!res.headersSent && result !== undefined) {
          res.json(result);
        }
      } catch (err) {
        if (err instanceof DomainError) {
          res.status(err.statusCode).json({error: err.message});
          return;
        }
        const message = err instanceof Error ? err.message : 'Unexpected server error';
        res.status(500).json({error: message});
      }
    };

  router.get('/health', (_req, res) => {
    res.json({
      status: 'ok',
      prototype: true,
      organisation: 'TERTIUSMEDICO — Pennine Community Pharmacy (Synthetic Prototype)',
      timestamp: new Date().toISOString(),
    });
  });

  // --- Authentication & Identity ---
  router.get('/auth/staff-directory', (_req, res) => {
    res.json({
      staff: listStaffUsers(db),
      prototypeHint: 'Synthetic staff accounts for prototype verification (passcode: pennine-demo)',
    });
  });

  router.get('/auth/patient-directory', (_req, res) => {
    const rows = db
      .prepare('SELECT id, internal_id, full_name, date_of_birth, postcode FROM patients ORDER BY full_name')
      .all() as Record<string, unknown>[];
    res.json({
      patients: rows.map((r) => ({
        id: String(r['id']),
        internalId: String(r['internal_id']),
        fullName: String(r['full_name']),
        dateOfBirth: String(r['date_of_birth']),
        postcode: String(r['postcode']),
      })),
    });
  });

  router.post(
    '/auth/staff-login',
    wrap((req) => {
      const {username, passcode} = req.body as {username?: string; passcode?: string};
      if (!username || !passcode) {
        throw new DomainError(400, 'Username and passcode are required');
      }
      const row = db
        .prepare('SELECT * FROM staff_users WHERE username = ? AND active = 1')
        .get(username) as Record<string, unknown> | undefined;
      if (!row || !verifyPassword(passcode, String(row['password_hash']))) {
        throw new DomainError(401, 'Invalid staff credentials');
      }
      const session = createSession(
        db,
        'staff',
        String(row['id']),
        String(row['role']) as SessionPrincipal['role'],
        String(row['display_name']),
      );
      appendAudit(
        db,
        {id: session.actorId, name: session.displayName, role: session.role},
        'STAFF_SIGN_IN',
        'session',
        session.actorId,
        `Signed in as ${session.displayName} (${session.role}).`,
      );
      return {session};
    }),
  );

  router.post(
    '/auth/patient-login',
    wrap((req) => {
      const {patientId, dateOfBirth, pinLast4} = req.body as {
        patientId?: string;
        dateOfBirth?: string;
        pinLast4?: string;
      };
      if (!patientId || !dateOfBirth || !pinLast4) {
        throw new DomainError(400, 'Patient identifier, date of birth, and 4-digit PIN are required');
      }
      const pat = getPatientById(db, patientId);
      if (!pat || pat.dateOfBirth !== dateOfBirth || pat.portalPinLast4 !== pinLast4) {
        throw new DomainError(401, 'Patient verification details did not match');
      }
      const session = createSession(db, 'patient', pat.id, 'patient', pat.fullName);
      appendAudit(
        db,
        {id: pat.id, name: pat.fullName, role: 'patient'},
        'PATIENT_PORTAL_SIGN_IN',
        'patient',
        pat.id,
        `Patient portal session started for ${pat.internalId}.`,
      );
      return {session};
    }),
  );

  router.get(
    '/auth/me',
    requireAuth,
    wrap((req) => ({principal: req.principal})),
  );

  router.post(
    '/auth/logout',
    requireAuth,
    wrap((req) => {
      if (req.principal) {
        db.prepare('DELETE FROM sessions WHERE token = ?').run(req.principal.token);
      }
      return {ok: true};
    }),
  );

  // --- Staff Overview ---
  router.get(
    '/overview',
    requireStaff,
    wrap(() => {
      const policy = getOrgPolicy(db);
      const prescriptions = listPrescriptions(db);
      const batches = listStockBatches(db);
      const notifications = db
        .prepare('SELECT * FROM notifications ORDER BY created_at DESC')
        .all() as Record<string, unknown>[];
      const recalls = db.prepare('SELECT * FROM recalls ORDER BY created_at DESC').all() as Record<
        string,
        unknown
      >[];
      const appointments = db
        .prepare('SELECT * FROM service_appointments ORDER BY scheduled_at ASC')
        .all() as Record<string, unknown>[];

      const stageCounts: Record<string, number> = {};
      for (const rx of prescriptions) {
        stageCounts[rx.status] = (stageCounts[rx.status] ?? 0) + 1;
      }

      return {
        policy,
        stageCounts,
        totalPrescriptions: prescriptions.length,
        unmatchedCount: prescriptions.filter((p) => p.matchStatus !== 'matched').length,
        unverifiedDocumentsCount: prescriptions.filter(
          (p) => p.verificationRequired && !p.documentVerifiedAt,
        ).length,
        failedNotificationsCount: notifications.filter((n) => n['status'] === 'failed').length,
        expiredBatchesCount: batches.filter((b) => b.state === 'expired').length,
        quarantinedOrRecalledCount: batches.filter(
          (b) => b.state === 'quarantined' || b.state === 'recalled',
        ).length,
        lowStockProductsCount: batches.filter(
          (b) => b.state === 'available' && b.availableQty <= 20,
        ).length,
        openRecallsCount: recalls.length,
        upcomingAppointmentsCount: appointments.filter((a) => a['status'] === 'booked').length,
        adapters: getExternalAdaptersStatus(policy.clinicalAdapterAvailable),
      };
    }),
  );

  // --- Prescriptions & Dispensing Workflow ---
  router.get(
    '/prescriptions',
    requireStaff,
    wrap(() => ({
      prescriptions: listPrescriptions(db),
      policy: getOrgPolicy(db),
    })),
  );

  router.post(
    '/prescriptions/intake',
    requireStaff,
    wrap((req) => {
      const body = req.body as {
        sourceIdentifier: string;
        sourceSystem: 'NHS_EPS_SIM' | 'MANUAL_DEMO' | 'UPLOADED_DOCUMENT';
        patientId: string | null;
        patientReference: string;
        prescriberDetails: string;
        productId: string;
        prescribedQty: number;
        directionsAsReceived: string;
        attachmentFilename?: string;
      };
      return {
        prescription: intakePrescription(db, req.principal!, {
          ...body,
          prescribedQty: Number(body.prescribedQty),
        }),
      };
    }),
  );

  router.post(
    '/prescriptions/:id/match-patient',
    requireStaff,
    wrap((req) => {
      const {patientId, verificationNote} = req.body as {
        patientId: string;
        verificationNote?: string;
      };
      return {
        prescription: matchPatientToPrescription(
          db,
          req.principal!,
          String(req.params['id']),
          patientId,
          verificationNote || 'Verified demographic & NHS details',
        ),
      };
    }),
  );

  router.post(
    '/prescriptions/:id/verify-document',
    requireStaff,
    wrap((req) => ({
      prescription: verifyUploadedDocument(db, req.principal!, String(req.params['id'])),
    })),
  );

  router.post(
    '/prescriptions/:id/cancel',
    requireStaff,
    wrap((req) => {
      const {idempotencyKey, reason} = req.body as {idempotencyKey?: string; reason?: string};
      if (!idempotencyKey) {
        throw new DomainError(400, 'idempotencyKey is required for cancellation handling');
      }
      return processCancellationMessage(db, req.principal!, {
        prescriptionId: String(req.params['id']),
        idempotencyKey,
        reason: reason || 'Prescriber cancellation notice',
      });
    }),
  );

  router.get(
    '/items/:itemId/clinical-preview',
    requireStaff,
    wrap((req) => ({
      preview: previewClinicalKnowledgeForItem(db, String(req.params['itemId'])),
    })),
  );

  router.post(
    '/items/:itemId/clinical-review',
    requireStaff,
    wrap((req) => {
      const {decision, clinicalNotes, amendedDirections, amendmentReason} = req.body as {
        decision: 'approved' | 'query' | 'rejected';
        clinicalNotes: string;
        amendedDirections?: string;
        amendmentReason?: string;
      };
      return performClinicalReview(
        db,
        req.principal!,
        String(req.params['itemId']),
        decision,
        clinicalNotes || 'Pharmacist review recorded',
        amendedDirections,
        amendmentReason,
      );
    }),
  );

  router.post(
    '/items/:itemId/prepare',
    requireStaff,
    wrap((req) => {
      const {qtyToPrepare, partialReason, barcodeScannedValue, substitutionNote, targetBatchId} =
        req.body as {
          qtyToPrepare?: number;
          partialReason?: string;
          barcodeScannedValue: string;
          substitutionNote?: string;
          targetBatchId?: string;
        };
      return {
        prescription: allocateStockAndPrepare(db, req.principal!, String(req.params['itemId']), {
          qtyToPrepare: qtyToPrepare ? Number(qtyToPrepare) : undefined,
          partialReason,
          barcodeScannedValue: barcodeScannedValue || '',
          substitutionNote,
          targetBatchId,
        }),
      };
    }),
  );

  router.post(
    '/items/:itemId/accuracy-check',
    requireStaff,
    wrap((req) => {
      const {checkNotes, emergencyOverride} = req.body as {
        checkNotes?: string;
        emergencyOverride?: boolean;
      };
      return {
        prescription: performAccuracyCheck(
          db,
          req.principal!,
          String(req.params['itemId']),
          checkNotes || 'Accuracy check passed',
          Boolean(emergencyOverride),
        ),
      };
    }),
  );

  router.post(
    '/items/:itemId/handover',
    requireStaff,
    wrap((req) => {
      const body = req.body as {
        identityCheckMode:
          | 'patient_photo_id'
          | 'patient_dob_address'
          | 'authorised_representative'
          | 'van_driver_dispatch';
        representativeName?: string;
        paymentCaptured?: boolean;
        paymentMethod?: 'card_sim' | 'cash_sim' | 'exempt_verified';
        notes?: string;
      };
      return {
        prescription: recordHandover(db, req.principal!, String(req.params['itemId']), body),
      };
    }),
  );

  // --- Patients ---
  router.get(
    '/patients',
    requireStaff,
    wrap(() => ({patients: listPatients(db)})),
  );

  router.get(
    '/patients/:id',
    requireStaff,
    wrap((req) => {
      const patient = getPatientById(db, String(req.params['id']));
      if (!patient) throw new DomainError(404, 'Patient not found');
      const prescriptions = listPrescriptions(db).filter((p) => p.patientId === patient.id);
      return {patient, prescriptions};
    }),
  );

  router.post(
    '/patients/:id/preferences',
    requireStaff,
    wrap((req) => {
      const {preferredContact} = req.body as {preferredContact: string};
      const pat = getPatientById(db, String(req.params['id']));
      if (!pat) throw new DomainError(404, 'Patient not found');
      db.prepare('UPDATE patients SET preferred_contact = ? WHERE id = ?').run(
        preferredContact,
        pat.id,
      );
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'PATIENT_CONTACT_UPDATED',
        'patient',
        pat.id,
        `Updated preferred contact channel to ${preferredContact}.`,
      );
      return {patient: getPatientById(db, pat.id)};
    }),
  );

  // --- Medicine Catalogue & Stock ---
  router.get(
    '/catalogue',
    requireStaff,
    wrap(() => ({
      products: db.prepare('SELECT * FROM medicine_products ORDER BY prescribed_name').all(),
    })),
  );

  router.get(
    '/stock',
    requireStaff,
    wrap(() => ({
      batches: listStockBatches(db),
      movements: db
        .prepare('SELECT * FROM stock_movements ORDER BY created_at DESC LIMIT 80')
        .all(),
      products: db.prepare('SELECT * FROM medicine_products ORDER BY prescribed_name').all(),
    })),
  );

  router.post(
    '/stock/quarantine',
    requireStaff,
    wrap((req) => {
      if (!hasStaffPermission(req.principal!.role, 'stock_manage')) {
        throw new DomainError(403, 'Role not permitted to quarantine stock');
      }
      const {batchId, reason} = req.body as {batchId: string; reason: string};
      db.prepare(
        `UPDATE stock_batches SET state = 'quarantined', location = 'Quarantine Cage', quarantine_reason = ? WHERE id = ?`,
      ).run(reason || 'Manual staff quarantine', batchId);
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'STOCK_BATCH_QUARANTINED',
        'stock_batch',
        batchId,
        `Quarantined batch ${batchId}: ${reason}`,
      );
      return {batches: listStockBatches(db)};
    }),
  );

  router.post(
    '/stock/adjust',
    requireStaff,
    wrap((req) => {
      if (!hasStaffPermission(req.principal!.role, 'stock_manage')) {
        throw new DomainError(403, 'Role not permitted to adjust stock');
      }
      const {batchId, qtyDelta, reason} = req.body as {
        batchId: string;
        qtyDelta: number;
        reason: string;
      };
      const delta = Number(qtyDelta);
      if (!Number.isInteger(delta) || delta === 0) {
        throw new DomainError(400, 'qtyDelta must be a non-zero integer');
      }
      const batch = db.prepare('SELECT * FROM stock_batches WHERE id = ?').get(batchId) as
        | Record<string, unknown>
        | undefined;
      if (!batch) throw new DomainError(404, 'Stock batch not found');
      const nextPhys = Number(batch['physical_qty']) + delta;
      if (nextPhys < Number(batch['reserved_qty'])) {
        throw new DomainError(409, 'Adjustment would reduce physical stock below active reservations');
      }
      db.prepare('UPDATE stock_batches SET physical_qty = ? WHERE id = ?').run(nextPhys, batchId);
      db.prepare(
        `INSERT INTO stock_movements (
          id, batch_id, product_id, movement_type, qty_delta, unit,
          reference_type, reference_id, actor_id, actor_name, notes, created_at
        ) VALUES (?, ?, ?, 'STOCK_ADJUSTMENT', ?, ?, 'manual_adjustment', ?, ?, ?, ?, ?)`,
      ).run(
        `MOV-${randomUUID().slice(0, 8)}`,
        batchId,
        String(batch['product_id']),
        delta,
        String(batch['unit']),
        batchId,
        req.principal!.actorId,
        req.principal!.displayName,
        reason || 'Cycle count adjustment',
        new Date().toISOString(),
      );
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'STOCK_ADJUSTED',
        'stock_batch',
        batchId,
        `Adjusted batch ${batch['batch_number']} by ${delta} ${batch['unit']}: ${reason}`,
      );
      return {batches: listStockBatches(db)};
    }),
  );

  // --- Procurement & Recalls ---
  router.get(
    '/orders',
    requireStaff,
    wrap(() => ({
      orders: db.prepare('SELECT * FROM procurement_orders ORDER BY created_at DESC').all(),
      recalls: db.prepare('SELECT * FROM recalls ORDER BY created_at DESC').all(),
    })),
  );

  router.post(
    '/orders',
    requireStaff,
    wrap((req) => {
      if (!hasStaffPermission(req.principal!.role, 'procurement')) {
        throw new DomainError(403, 'Role not permitted to create reorder proposals');
      }
      const {supplierName, productId, orderedPacks, notes} = req.body as {
        supplierName: string;
        productId: string;
        orderedPacks: number;
        notes?: string;
      };
      const med = db.prepare('SELECT * FROM medicine_products WHERE id = ?').get(productId) as
        | Record<string, unknown>
        | undefined;
      if (!med) throw new DomainError(404, 'Product not found');
      const packs = Number(orderedPacks);
      if (!Number.isInteger(packs) || packs <= 0) {
        throw new DomainError(400, 'orderedPacks must be a positive integer');
      }
      const now = new Date().toISOString();
      const poNumber = `PO-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const totalPence = packs * Number(med['nhs_tariff_pence']);
      const lines = [
        {
          productId,
          productName: String(med['dispensable_product_name']),
          sku: String(med['supplier_sku']),
          orderedPacks: packs,
          packSize: Number(med['pack_size']),
          unit: String(med['quantity_unit']),
          unitCostPence: Number(med['nhs_tariff_pence']),
          receivedPacks: 0,
          damagedPacks: 0,
        },
      ];
      db.prepare(
        `INSERT INTO procurement_orders (
          id, order_number, supplier_name, status, created_by, approved_by,
          created_at, updated_at, total_pence, notes, lines_json
        ) VALUES (?, ?, ?, 'Reorder proposal', ?, NULL, ?, ?, ?, ?, ?)`,
      ).run(
        poNumber,
        poNumber,
        supplierName || 'Pennine Pharma Wholesale Ltd',
        req.principal!.displayName,
        now,
        now,
        totalPence,
        notes || 'Manual reorder proposal',
        JSON.stringify(lines),
      );
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'REORDER_PROPOSAL_CREATED',
        'procurement_order',
        poNumber,
        `Created reorder proposal ${poNumber} for ${packs} pack(s) of ${med['dispensable_product_name']}.`,
      );
      return {orders: db.prepare('SELECT * FROM procurement_orders ORDER BY created_at DESC').all()};
    }),
  );

  router.post(
    '/orders/:id/approve',
    requireStaff,
    wrap((req) => {
      if (!hasStaffPermission(req.principal!.role, 'procurement')) {
        throw new DomainError(403, 'Role not permitted to approve supplier orders');
      }
      const orderId = String(req.params['id']);
      db.prepare(
        `UPDATE procurement_orders SET status = 'Acknowledged', approved_by = ?, updated_at = ? WHERE id = ?`,
      ).run(req.principal!.displayName, new Date().toISOString(), orderId);
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'PURCHASE_ORDER_APPROVED_AND_ACKNOWLEDGED',
        'procurement_order',
        orderId,
        `Approved and transmitted order ${orderId} to simulated wholesaler EDI.`,
      );
      return {orders: db.prepare('SELECT * FROM procurement_orders ORDER BY created_at DESC').all()};
    }),
  );

  router.post(
    '/orders/:id/receive',
    requireStaff,
    wrap((req) => {
      const body = req.body as {
        productId: string;
        receivedGoodPacks: number;
        damagedPacks: number;
        batchNumber: string;
        expiryDate: string;
        unitCostPence?: number;
        notes?: string;
      };
      return receiveProcurementGoods(db, req.principal!, String(req.params['id']), {
        ...body,
        receivedGoodPacks: Number(body.receivedGoodPacks),
        damagedPacks: Number(body.damagedPacks || 0),
        unitCostPence: body.unitCostPence ? Number(body.unitCostPence) : undefined,
      });
    }),
  );

  router.post(
    '/recalls',
    requireStaff,
    wrap((req) => {
      const body = req.body as {
        recallRef: string;
        source: string;
        classification: string;
        productId: string;
        affectedBatchNumber: string;
        reason: string;
      };
      return {recall: triggerBatchRecall(db, req.principal!, body)};
    }),
  );

  router.post(
    '/recalls/:id/review-patient',
    requireStaff,
    wrap((req) => {
      if (!hasStaffPermission(req.principal!.role, 'clinical_review')) {
        throw new DomainError(403, 'Only a pharmacist can sign off recall patient reviews');
      }
      const recallId = String(req.params['id']);
      const {patientId, decisionNote} = req.body as {patientId: string; decisionNote: string};
      const row = db.prepare('SELECT * FROM recalls WHERE id = ?').get(recallId) as
        | Record<string, unknown>
        | undefined;
      if (!row) throw new DomainError(404, 'Recall record not found');

      const affected = JSON.parse(String(row['affected_patients_json'])) as Record<string, unknown>[];
      for (const a of affected) {
        if (a['patientId'] === patientId) {
          a['reviewStatus'] = `Reviewed by ${req.principal!.displayName}: ${decisionNote}`;
        }
      }
      const log = JSON.parse(String(row['investigation_log_json'])) as Record<string, unknown>[];
      log.push({
        timestamp: new Date().toISOString(),
        actor: req.principal!.displayName,
        note: `Patient ${patientId} supply reviewed: ${decisionNote}`,
      });
      db.prepare(
        `UPDATE recalls SET affected_patients_json = ?, investigation_log_json = ? WHERE id = ?`,
      ).run(JSON.stringify(affected), JSON.stringify(log), recallId);
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'RECALL_PATIENT_REVIEWED',
        'recall',
        recallId,
        `Pharmacist reviewed recall exposure for ${patientId}: ${decisionNote}`,
      );
      return {recalls: db.prepare('SELECT * FROM recalls ORDER BY created_at DESC').all()};
    }),
  );

  // --- Controlled Drugs & Cold Chain ---
  router.get(
    '/cd-register',
    requireStaff,
    wrap(() => ({
      entries: db
        .prepare(
          `SELECT cd.*, mp.dispensable_product_name as product_name
           FROM cd_register_entries cd
           JOIN medicine_products mp ON cd.product_id = mp.id
           ORDER BY cd.entry_number ASC`,
        )
        .all(),
      disclaimer:
        'PROTOTYPE DEMONSTRATION REGISTER ONLY — NOT A LEGALLY VALIDATED CONTROLLED DRUG REGISTER WITHOUT JURISDICTION-SPECIFIC REGULATORY APPROVAL.',
    })),
  );

  router.post(
    '/cd-register/correction',
    requireStaff,
    wrap((req) => {
      if (!hasStaffPermission(req.principal!.role, 'cd_register')) {
        throw new DomainError(403, 'Only an authorised pharmacist may record CD register corrections');
      }
      const {productId, qtyDelta, reason, correctionOfId} = req.body as {
        productId: string;
        qtyDelta: number;
        reason: string;
        correctionOfId?: string;
      };
      const delta = Number(qtyDelta);
      const last = db
        .prepare('SELECT entry_number, running_balance, unit, batch_number FROM cd_register_entries WHERE product_id = ? ORDER BY entry_number DESC LIMIT 1')
        .get(productId) as
        | {entry_number: number; running_balance: number; unit: string; batch_number: string}
        | undefined;
      const nextNum = (last?.entry_number ?? 0) + 1;
      const nextBal = (last?.running_balance ?? 0) + delta;
      db.prepare(
        `INSERT INTO cd_register_entries (
          id, entry_number, product_id, entry_type, prescription_ref, patient_or_supplier,
          qty_received, qty_supplied, running_balance, unit, batch_number,
          actor_id, actor_name, correction_of_id, correction_reason, created_at
        ) VALUES (?, ?, ?, 'reconciliation_correction', 'RECON-ADJ', 'Balance Reconciliation Entry', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        `CD-ENT-${randomUUID().slice(0, 6)}`,
        nextNum,
        productId,
        delta > 0 ? delta : 0,
        delta < 0 ? Math.abs(delta) : 0,
        nextBal,
        last?.unit || 'mL',
        last?.batch_number || 'MS26-019',
        req.principal!.actorId,
        req.principal!.displayName,
        correctionOfId || null,
        reason,
        new Date().toISOString(),
      );
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'CD_REGISTER_CORRECTION',
        'cd_register',
        productId,
        `Recorded append-only CD register correction (${delta}): ${reason}`,
      );
      return {ok: true};
    }),
  );

  router.get(
    '/cold-chain',
    requireStaff,
    wrap(() => ({
      logs: db.prepare('SELECT * FROM cold_chain_logs ORDER BY recorded_at DESC').all(),
    })),
  );

  router.post(
    '/cold-chain',
    requireStaff,
    wrap((req) => {
      const {location, temperatureC, source} = req.body as {
        location?: string;
        temperatureC: number;
        source?: string;
      };
      const temp = Number(temperatureC);
      if (Number.isNaN(temp)) throw new DomainError(400, 'Valid temperatureC is required');
      const loc = location || 'Cold Chain Fridge 1';
      const excursion = temp < 2.0 || temp > 8.0;
      const now = new Date().toISOString();
      const actionTaken = excursion
        ? `EXCURSION (${temp}°C outside 2.0–8.0°C): All stock in ${loc} automatically quarantined pending pharmacist stability assessment.`
        : 'Within 2.0°C–8.0°C approved range';

      db.prepare(
        `INSERT INTO cold_chain_logs (id, location, temperature_c, source, excursion_detected, action_taken, recorded_by, recorded_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        `TEMP-${randomUUID().slice(0, 6)}`,
        loc,
        temp,
        source || 'Manual Staff Log',
        excursion ? 1 : 0,
        actionTaken,
        req.principal!.displayName,
        now,
      );

      if (excursion) {
        db.prepare(
          `UPDATE stock_batches SET state = 'quarantined', quarantine_reason = ? WHERE location = ? AND state = 'available'`,
        ).run(`Cold-chain excursion (${temp}°C) — awaiting manufacturer/pharmacist review`, loc);
        appendAudit(
          db,
          {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
          'COLD_CHAIN_EXCURSION_QUARANTINE',
          'cold_chain',
          loc,
          actionTaken,
        );
      }
      return {
        excursion,
        logs: db.prepare('SELECT * FROM cold_chain_logs ORDER BY recorded_at DESC').all(),
      };
    }),
  );

  // --- Pharmacy Services ---
  router.get(
    '/services',
    requireStaff,
    wrap(() => ({
      services: db.prepare('SELECT * FROM pharmacy_services ORDER BY name').all(),
      appointments: db
        .prepare(
          `SELECT sa.*, ps.name as service_name, ps.room, pat.full_name as patient_name, su.display_name as practitioner_name
           FROM service_appointments sa
           JOIN pharmacy_services ps ON sa.service_id = ps.id
           JOIN patients pat ON sa.patient_id = pat.id
           LEFT JOIN staff_users su ON sa.practitioner_id = su.id
           ORDER BY sa.scheduled_at ASC`,
        )
        .all(),
    })),
  );

  router.post(
    '/services/appointments',
    requireStaff,
    wrap((req) => {
      const {serviceId, patientId, practitionerId, scheduledAt, consentRecorded, notes} = req.body as {
        serviceId: string;
        patientId: string;
        practitionerId?: string;
        scheduledAt: string;
        consentRecorded: boolean;
        notes?: string;
      };
      const aptId = `APT-${randomUUID().slice(0, 6).toUpperCase()}`;
      db.prepare(
        `INSERT INTO service_appointments (
          id, service_id, patient_id, practitioner_id, scheduled_at, status,
          consent_recorded, attendance_status, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, 'booked', ?, 'pending', ?, ?)`,
      ).run(
        aptId,
        serviceId,
        patientId,
        practitionerId || 'STF-PHARM-01',
        scheduledAt || new Date(Date.now() + 86400000).toISOString(),
        consentRecorded ? 1 : 0,
        notes || '',
        new Date().toISOString(),
      );
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'SERVICE_APPOINTMENT_BOOKED',
        'service_appointment',
        aptId,
        `Booked service ${serviceId} for patient ${patientId}.`,
      );
      return {ok: true, id: aptId};
    }),
  );

  router.post(
    '/services/appointments/:id/update',
    requireStaff,
    wrap((req) => {
      const {attendanceStatus, outcomeReference, followUpTask} = req.body as {
        attendanceStatus: string;
        outcomeReference?: string;
        followUpTask?: string;
      };
      const nextStatus = attendanceStatus === 'attended' ? 'completed' : 'booked';
      db.prepare(
        `UPDATE service_appointments
         SET attendance_status = ?, status = ?, outcome_reference = ?, follow_up_task = ?
         WHERE id = ?`,
      ).run(
        attendanceStatus,
        nextStatus,
        outcomeReference || null,
        followUpTask || null,
        String(req.params['id']),
      );
      return {ok: true};
    }),
  );

  // --- Deliveries & Notifications ---
  router.get(
    '/deliveries',
    requireStaff,
    wrap(() => ({
      deliveries: db
        .prepare(
          `SELECT d.*, pat.full_name as patient_name, pat.address_line1, pat.postcode
           FROM deliveries d
           JOIN patients pat ON d.patient_id = pat.id
           ORDER BY d.dispatched_at DESC`,
        )
        .all(),
    })),
  );

  router.post(
    '/deliveries/:id/confirm',
    requireStaff,
    wrap((req) => {
      const {recipientChecked} = req.body as {recipientChecked: string};
      const now = new Date().toISOString();
      db.prepare(
        `UPDATE deliveries SET status = 'confirmed_received', recipient_checked = ?, delivered_at = ? WHERE id = ?`,
      ).run(recipientChecked || 'Confirmed by recipient at doorstep', now, String(req.params['id']));
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'DELIVERY_CONFIRMED_RECEIVED',
        'delivery',
        String(req.params['id']),
        `Confirmed delivery receipt: ${recipientChecked || 'Recipient signed'}.`,
      );
      return {ok: true};
    }),
  );

  router.get(
    '/notifications',
    requireStaff,
    wrap(() => ({
      notifications: db
        .prepare(
          `SELECT n.*, pat.full_name as patient_name
           FROM notifications n
           JOIN patients pat ON n.patient_id = pat.id
           ORDER BY n.created_at DESC`,
        )
        .all(),
    })),
  );

  router.post(
    '/notifications/:id/retry',
    requireStaff,
    wrap((req) => {
      const id = String(req.params['id']);
      const {overrideChannel} = req.body as {overrideChannel?: string};
      if (overrideChannel) {
        db.prepare(`UPDATE notifications SET channel = ?, status = 'sent', sent_at = ?, failure_reason = NULL, attempts = attempts + 1 WHERE id = ?`).run(
          overrideChannel,
          new Date().toISOString(),
          id,
        );
      } else {
        db.prepare(`UPDATE notifications SET status = 'queued' WHERE id = ?`).run(id);
        runWorkerCycle(db);
      }
      return {ok: true};
    }),
  );

  // --- Reports, Financial Reconciliation & Audit ---
  router.get(
    '/reports',
    requireStaff,
    wrap(() => {
      const policy = getOrgPolicy(db);
      const batches = listStockBatches(db);
      const transactions = db
        .prepare('SELECT * FROM financial_transactions ORDER BY created_at DESC')
        .all() as Record<string, unknown>[];
      const auditEvents = db
        .prepare('SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 120')
        .all();
      const chargeRules = db.prepare('SELECT * FROM charge_rules').all();
      const prescriptions = listPrescriptions(db);

      const completedItems = prescriptions.flatMap((rx) =>
        rx.items.filter((i) => i.suppliedQty > 0),
      );
      const exemptItemsCount = prescriptions
        .filter((rx) => !rx.exemptionOrChargeStatus.startsWith('chargeable'))
        .reduce((acc, rx) => acc + rx.items.filter((i) => i.suppliedQty > 0).length, 0);
      const chargeableItemsCount = completedItems.length - exemptItemsCount;
      const totalCollectedPence = transactions.reduce(
        (acc, t) => acc + Number(t['amount_pence'] || 0),
        0,
      );

      return {
        policy,
        chargeRules,
        hazardLog: PROTOTYPE_HAZARD_LOG,
        adapters: getExternalAdaptersStatus(policy.clinicalAdapterAvailable),
        transactions,
        auditEvents,
        fp34cSummary: {
          period: '2026-11 (Simulated)',
          organisationOds: policy.odsCode,
          totalSuppliedItemLines: completedItems.length,
          exemptSuppliedLines: exemptItemsCount,
          chargeableSuppliedLines: chargeableItemsCount,
          collectedChargesPence: totalCollectedPence,
          submissionStatus: 'SIMULATED DRAFT — NOT TRANSMITTED TO NHSBSA MYS',
        },
        stockValuationPence: batches
          .filter((b) => b.state === 'available')
          .reduce((acc, b) => acc + b.physicalQty * Math.round(b.costPencePerPack / 28), 0),
      };
    }),
  );

  // --- Organisational Policy & Demo Controls ---
  router.get(
    '/policy',
    requireStaff,
    wrap(() => ({
      policy: getOrgPolicy(db),
      adapters: getExternalAdaptersStatus(getOrgPolicy(db).clinicalAdapterAvailable),
      staff: listStaffUsers(db),
    })),
  );

  router.post(
    '/policy',
    requireStaff,
    wrap((req) => {
      if (!hasStaffPermission(req.principal!.role, 'admin_policy')) {
        throw new DomainError(403, 'Only Admin or Pharmacist may update organisational policy');
      }
      const body = req.body as Partial<OrganisationalPolicy>;
      const current = getOrgPolicy(db);
      const nextSepPrep =
        body.requireSeparatePreparerAndChecker ?? current.requireSeparatePreparerAndChecker;
      const nextSepClin =
        body.requireSeparateClinicalAndAccuracyChecker ??
        current.requireSeparateClinicalAndAccuracyChecker;
      const nextOverride =
        body.allowEmergencySelfCheckOverride ?? current.allowEmergencySelfCheckOverride;
      const nextClinAvail = body.clinicalAdapterAvailable ?? current.clinicalAdapterAvailable;

      db.prepare(
        `UPDATE org_policy
         SET require_separate_preparer_and_checker = ?,
             require_separate_clinical_and_accuracy_checker = ?,
             allow_emergency_self_check_override = ?,
             clinical_adapter_available = ?,
             updated_at = ?,
             updated_by = ?
         WHERE id = ?`,
      ).run(
        nextSepPrep ? 1 : 0,
        nextSepClin ? 1 : 0,
        nextOverride ? 1 : 0,
        nextClinAvail ? 1 : 0,
        new Date().toISOString(),
        req.principal!.displayName,
        current.id,
      );
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'ORG_POLICY_UPDATED',
        'org_policy',
        current.id,
        `Updated policy: separatePrepCheck=${nextSepPrep}, separateClinCheck=${nextSepClin}, clinicalAdapter=${nextClinAvail}`,
      );
      return {policy: getOrgPolicy(db)};
    }),
  );

  router.post(
    '/demo/step/:step',
    requireStaff,
    wrap((req) => {
      const step = Number(req.params['step']);
      return runReproducibleDemoStep(db, req.principal!, step);
    }),
  );

  router.post(
    '/demo/reset',
    requireStaff,
    wrap(() => {
      seedDatabaseIfEmpty(db, true);
      return {ok: true, message: 'Pennine Community Pharmacy demonstration state reset cleanly.'};
    }),
  );

  router.post(
    '/worker/run',
    requireStaff,
    wrap(() => ({summary: runWorkerCycle(db)})),
  );

  // --- Patient Portal (Strictly Isolated to Authenticated Patient) ---
  router.get(
    '/portal/me',
    requireAuth,
    wrap((req) => {
      const targetPatientId =
        req.principal!.actorType === 'patient'
          ? req.principal!.actorId
          : String(req.query['patientId'] || 'PAT-1001');

      const patient = getPatientById(db, targetPatientId);
      if (!patient) throw new DomainError(404, 'Patient record not found');

      const prescriptions = listPrescriptions(db).filter((p) => p.patientId === patient.id);
      const repeatRequests = db
        .prepare(
          `SELECT rr.*, mp.prescribed_name as product_name
           FROM repeat_requests rr
           JOIN medicine_products mp ON rr.product_id = mp.id
           WHERE rr.patient_id = ?
           ORDER BY rr.created_at DESC`,
        )
        .all(patient.id);
      const messages = db
        .prepare('SELECT * FROM notifications WHERE patient_id = ? ORDER BY created_at DESC')
        .all(patient.id);
      const appointments = db
        .prepare(
          `SELECT sa.*, ps.name as service_name, ps.room
           FROM service_appointments sa
           JOIN pharmacy_services ps ON sa.service_id = ps.id
           WHERE sa.patient_id = ?
           ORDER BY sa.scheduled_at ASC`,
        )
        .all(patient.id);
      const services = db.prepare('SELECT * FROM pharmacy_services WHERE active = 1').all();
      const catalogue = db
        .prepare('SELECT id, prescribed_name, strength, quantity_unit FROM medicine_products ORDER BY prescribed_name')
        .all();

      return {
        patient,
        prescriptions,
        repeatRequests,
        messages,
        appointments,
        services,
        catalogue,
      };
    }),
  );

  router.post(
    '/portal/repeat-requests',
    requireAuth,
    wrap((req) => {
      const patientId =
        req.principal!.actorType === 'patient'
          ? req.principal!.actorId
          : String((req.body as {patientId?: string}).patientId || '');
      const {productId, requestedQty, patientNote} = req.body as {
        productId: string;
        requestedQty: number;
        patientNote?: string;
      };
      const reqId = `REQ-${randomUUID().slice(0, 6).toUpperCase()}`;
      db.prepare(
        `INSERT INTO repeat_requests (id, patient_id, product_id, requested_qty, patient_note, status, created_at)
         VALUES (?, ?, ?, ?, ?, 'Pending GP / Pharmacist Review (Not a prescription)', ?)`,
      ).run(
        reqId,
        patientId,
        productId,
        Number(requestedQty || 28),
        patientNote || '',
        new Date().toISOString(),
      );
      appendAudit(
        db,
        {id: req.principal!.actorId, name: req.principal!.displayName, role: req.principal!.role},
        'PATIENT_REPEAT_REQUEST_SUBMITTED',
        'repeat_request',
        reqId,
        `Patient repeat request submitted (${reqId}) — awaiting prescriber/pharmacist review; NOT a dispensing authorisation.`,
      );
      return {ok: true, id: reqId};
    }),
  );

  router.post(
    '/portal/collection-option',
    requireAuth,
    wrap((req) => {
      const patientId =
        req.principal!.actorType === 'patient'
          ? req.principal!.actorId
          : String((req.body as {patientId?: string}).patientId || '');
      const {prescriptionId, collectionOption} = req.body as {
        prescriptionId: string;
        collectionOption: 'in_store_counter' | 'representative_collection' | 'local_van_delivery';
      };
      const rx = db.prepare('SELECT patient_id FROM prescriptions WHERE id = ?').get(prescriptionId) as
        | {patient_id: string}
        | undefined;
      if (!rx || rx.patient_id !== patientId) {
        throw new DomainError(403, 'Access denied to this prescription');
      }
      db.prepare(
        `UPDATE prescriptions SET collection_option = ?, delivery_requested = ? WHERE id = ?`,
      ).run(collectionOption, collectionOption === 'local_van_delivery' ? 1 : 0, prescriptionId);
      return {ok: true};
    }),
  );

  router.post(
    '/portal/appointments',
    requireAuth,
    wrap((req) => {
      const patientId =
        req.principal!.actorType === 'patient'
          ? req.principal!.actorId
          : String((req.body as {patientId?: string}).patientId || '');
      const {serviceId, scheduledAt, consentRecorded, notes} = req.body as {
        serviceId: string;
        scheduledAt: string;
        consentRecorded: boolean;
        notes?: string;
      };
      const aptId = `APT-${randomUUID().slice(0, 6).toUpperCase()}`;
      db.prepare(
        `INSERT INTO service_appointments (
          id, service_id, patient_id, practitioner_id, scheduled_at, status,
          consent_recorded, attendance_status, notes, created_at
        ) VALUES (?, ?, ?, 'STF-PHARM-01', ?, 'booked', ?, 'pending', ?, ?)`,
      ).run(
        aptId,
        serviceId,
        patientId,
        scheduledAt || new Date(Date.now() + 86400000).toISOString(),
        consentRecorded ? 1 : 0,
        notes || 'Booked via Patient Portal',
        new Date().toISOString(),
      );
      return {ok: true, id: aptId};
    }),
  );

  router.post(
    '/portal/preferences',
    requireAuth,
    wrap((req) => {
      const patientId =
        req.principal!.actorType === 'patient'
          ? req.principal!.actorId
          : String((req.body as {patientId?: string}).patientId || '');
      const {preferredContact} = req.body as {preferredContact: string};
      db.prepare('UPDATE patients SET preferred_contact = ? WHERE id = ?').run(
        preferredContact,
        patientId,
      );
      return {ok: true};
    }),
  );

  return router;
}

import type {OrganisationalPolicy} from './types';
