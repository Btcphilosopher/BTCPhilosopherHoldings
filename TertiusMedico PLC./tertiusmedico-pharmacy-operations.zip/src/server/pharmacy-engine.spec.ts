import {describe, expect, it} from 'vitest';
import {getDb, resetDbConnection} from './db/database';
import {seedDatabaseIfEmpty} from './db/seed';
import {createSession, hasStaffPermission} from './modules/auth';
import {
  allocateStockAndPrepare,
  DomainError,
  intakePrescription,
  matchPatientToPrescription,
  performAccuracyCheck,
  performClinicalReview,
  processCancellationMessage,
  receiveProcurementGoods,
  recordHandover,
  runReproducibleDemoStep,
  triggerBatchRecall,
} from './modules/pharmacy-engine';

function setupMemoryDb() {
  process.env['TERMED_DB_PATH'] = ':memory:';
  resetDbConnection();
  const db = getDb(':memory:');
  seedDatabaseIfEmpty(db, true);
  const pharmacist = createSession(db, 'staff', 'STF-PHARM-01', 'pharmacist', 'Dr. Hannah Whitaker');
  const act = createSession(db, 'staff', 'STF-ACT-01', 'act', 'Liam Patel');
  const dispenser = createSession(db, 'staff', 'STF-DISP-01', 'dispenser', 'Chloe Bennett');
  const counter = createSession(db, 'staff', 'STF-CNTR-01', 'counter', 'Samira Khan');
  return {db, pharmacist, act, dispenser, counter};
}

describe('TERTIUSMEDICO Pharmacy Operations Engine', () => {
  it('enforces role restrictions across clinical review, accuracy check, and handover', () => {
    const {db, dispenser, counter} = setupMemoryDb();
    expect(hasStaffPermission(dispenser.role, 'clinical_review')).toBe(false);
    expect(hasStaffPermission(dispenser.role, 'accuracy_check')).toBe(false);
    expect(hasStaffPermission(counter.role, 'prepare')).toBe(false);

    expect(() =>
      performClinicalReview(db, dispenser, 'ITEM-4001-1', 'approved', 'Unauthorized check'),
    ).toThrow(DomainError);
  });

  it('prevents duplicate prescription intake and preserves unmatched patients without auto-merge', () => {
    const {db, pharmacist} = setupMemoryDb();
    expect(() =>
      intakePrescription(db, pharmacist, {
        sourceIdentifier: 'EPS-MSG-4001',
        sourceSystem: 'NHS_EPS_SIM',
        patientId: 'PAT-1002',
        patientReference: 'Meera Sharma',
        prescriberDetails: 'Dr. S. Iqbal',
        productId: 'MED-RAMI-5',
        prescribedQty: 28,
        directionsAsReceived: 'Take ONE daily',
      }),
    ).toThrow(/Duplicate prescription/);

    // Cannot clinically review unmatched RX-2026-4004 before explicit match
    expect(() =>
      performClinicalReview(db, pharmacist, 'ITEM-4004-1', 'approved', 'Attempt without match'),
    ).toThrow(/patient match is verified/);

    const matched = matchPatientToPrescription(db, pharmacist, 'RX-2026-4004', 'PAT-1002', 'Matched DOB');
    expect(matched.matchStatus).toBe('matched');
    expect(matched.status).toBe('Awaiting clinical review');
  });

  it('excludes expired and quarantined batches during FEFO allocation and prevents double-reservation', () => {
    const {db, pharmacist, dispenser} = setupMemoryDb();

    // Approve RX-2026-4001 (Ramipril 5mg) and attempt to allocate an expired batch directly
    performClinicalReview(db, pharmacist, 'ITEM-4001-1', 'approved', 'Approved');
    expect(() =>
      allocateStockAndPrepare(db, dispenser, 'ITEM-4001-1', {
        qtyToPrepare: 28,
        barcodeScannedValue: '5012345000200',
        targetBatchId: 'BAT-AMOX-EXP',
      }),
    ).toThrow(/excluded from dispensing/);

    // Now test concurrent / double allocation on Atorvastatin 20mg (only 14 tablets available!)
    const rxA = intakePrescription(db, pharmacist, {
      sourceIdentifier: 'EPS-CONC-A',
      sourceSystem: 'NHS_EPS_SIM',
      patientId: 'PAT-1001',
      patientReference: 'Arthur Pendelton',
      prescriberDetails: 'Dr. Ellis',
      productId: 'MED-ATOR-20',
      prescribedQty: 14,
      directionsAsReceived: 'One nightly',
    });
    const rxB = intakePrescription(db, pharmacist, {
      sourceIdentifier: 'EPS-CONC-B',
      sourceSystem: 'NHS_EPS_SIM',
      patientId: 'PAT-1002',
      patientReference: 'Meera Sharma',
      prescriberDetails: 'Dr. Ellis',
      productId: 'MED-ATOR-20',
      prescribedQty: 14,
      directionsAsReceived: 'One nightly',
    });
    performClinicalReview(db, pharmacist, rxA.items[0]!.id, 'approved', 'OK');
    performClinicalReview(db, pharmacist, rxB.items[0]!.id, 'approved', 'OK');

    // First allocation consumes all 14 available tablets
    allocateStockAndPrepare(db, dispenser, rxA.items[0]!.id, {
      qtyToPrepare: 14,
      barcodeScannedValue: '5012345000101',
    });

    // Second allocation must fail — no double-consumption of BAT-ATOR-01!
    expect(() =>
      allocateStockAndPrepare(db, dispenser, rxB.items[0]!.id, {
        qtyToPrepare: 14,
        barcodeScannedValue: '5012345000101',
      }),
    ).toThrow(/No available, unexpired, non-quarantined stock/);
  });

  it('enforces role separation on accuracy check and handles partial supply + replenishment + audit completeness', () => {
    const {db, pharmacist, act, counter} = setupMemoryDb();

    // Run Steps 1-10 using the engine functions
    for (let s = 1; s <= 10; s++) {
      runReproducibleDemoStep(db, pharmacist, s);
    }

    // Verify RX from Step 1 is now Completed with 28 supplied, 0 outstanding
    const rxRow = db
      .prepare(`SELECT status FROM prescriptions WHERE source_identifier = 'EPS-DEMO-STEP1'`)
      .get() as {status: string};
    expect(rxRow.status).toBe('Completed');

    // Also test self-check block on a fresh item
    performClinicalReview(db, pharmacist, 'ITEM-4001-1', 'approved', 'OK');
    allocateStockAndPrepare(db, act, 'ITEM-4001-1', {
      qtyToPrepare: 28,
      barcodeScannedValue: '5012345000200',
    });
    expect(() =>
      performAccuracyCheck(db, act, 'ITEM-4001-1', 'Attempt self check'),
    ).toThrow(/requires separate preparer and accuracy checker/);

    // Different checker (pharmacist) succeeds
    performAccuracyCheck(db, pharmacist, 'ITEM-4001-1', 'Verified');
    // Handover requires payment when chargeable (PAT-1002)
    expect(() =>
      recordHandover(db, counter, 'ITEM-4001-1', {
        identityCheckMode: 'patient_dob_address',
      }),
    ).toThrow(/unpaid NHS charge/);

    const completed = recordHandover(db, counter, 'ITEM-4001-1', {
      identityCheckMode: 'patient_dob_address',
      paymentCaptured: true,
      paymentMethod: 'card_sim',
    });
    expect(completed.status).toBe('Completed');
    expect(completed.paymentStatus).toBe('paid_simulated');
  });

  it('processes duplicate cancellation messages idempotently and quarantines recalled batches', () => {
    const {db, pharmacist, dispenser} = setupMemoryDb();

    // Prepare RX-2026-4001 to reserve 28 Ramipril capsules
    performClinicalReview(db, pharmacist, 'ITEM-4001-1', 'approved', 'OK');
    allocateStockAndPrepare(db, dispenser, 'ITEM-4001-1', {
      qtyToPrepare: 28,
      barcodeScannedValue: '5012345000200',
    });

    const firstCancel = processCancellationMessage(db, pharmacist, {
      prescriptionId: 'RX-2026-4001',
      idempotencyKey: 'CANCEL-4001-MSG1',
      reason: 'Prescriber stopped Ramipril',
    });
    expect(firstCancel.duplicate).toBe(false);
    expect(firstCancel.prescription.status).toBe('Cancelled');

    // Stock reservation must be released back to 0
    const batch = db.prepare(`SELECT reserved_qty FROM stock_batches WHERE id = 'BAT-RAMI-01'`).get() as {
      reserved_qty: number;
    };
    expect(batch.reserved_qty).toBe(0);

    // Duplicate cancellation message must be ignored safely
    const secondCancel = processCancellationMessage(db, pharmacist, {
      prescriptionId: 'RX-2026-4001',
      idempotencyKey: 'CANCEL-4001-MSG1',
      reason: 'Prescriber stopped Ramipril',
    });
    expect(secondCancel.duplicate).toBe(true);

    // Recall batch BATCH-AMX-REC
    const recall = triggerBatchRecall(db, pharmacist, {
      recallRef: 'MHRA-TEST-REC',
      source: 'MHRA Prototype',
      classification: 'Class 2',
      productId: 'MED-AMOX-500',
      affectedBatchNumber: 'BATCH-AMX-REC',
      reason: 'Dissolution test',
    });
    expect(recall['quarantined_qty']).toBe(42);

    // Verify audit log recorded events
    const auditCount = (db.prepare('SELECT COUNT(*) as cnt FROM audit_events').get() as {cnt: number}).cnt;
    expect(auditCount).toBeGreaterThan(5);
  });

  it('handles damaged packs on goods receipt into Quarantine Cage', () => {
    const {db, pharmacist} = setupMemoryDb();
    const res = receiveProcurementGoods(db, pharmacist, 'PO-2026-0101', {
      productId: 'MED-ATOR-20',
      receivedGoodPacks: 1,
      damagedPacks: 1,
      batchNumber: 'AT26-MIX',
      expiryDate: '2028-06-30',
    });
    expect(res.batchesCreated.length).toBe(1);
    expect(res.order['status']).toBe('Partially received');

    const dmgBatch = db
      .prepare(`SELECT state, location FROM stock_batches WHERE batch_number = 'AT26-MIX-DMG'`)
      .get() as {state: string; location: string};
    expect(dmgBatch.state).toBe('quarantined');
    expect(dmgBatch.location).toBe('Quarantine Cage');
  });
});
