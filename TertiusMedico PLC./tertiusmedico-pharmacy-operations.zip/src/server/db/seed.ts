import type {DatabaseSync} from 'node:sqlite';
import {hashPassword} from '../modules/auth';

export function seedDatabaseIfEmpty(db: DatabaseSync, forceReset = false): void {
  if (forceReset) {
    const tables = [
      'audit_events',
      'financial_transactions',
      'deliveries',
      'notifications',
      'service_appointments',
      'pharmacy_services',
      'cold_chain_logs',
      'cd_register_entries',
      'recalls',
      'procurement_orders',
      'stock_movements',
      'repeat_requests',
      'processed_messages',
      'prescription_items',
      'prescriptions',
      'attachments',
      'stock_batches',
      'medicine_products',
      'patients',
      'charge_rules',
      'org_policy',
      'sessions',
      'staff_users',
    ];
    for (const table of tables) {
      db.exec(`DELETE FROM ${table};`);
    }
  }

  const countRow = db.prepare('SELECT COUNT(*) as cnt FROM staff_users').get() as {cnt: number};
  if (countRow.cnt > 0) {
    return;
  }

  const now = new Date().toISOString();
  const demoPasscode = process.env['TERMED_DEMO_ADMIN_PASSCODE'] || 'pennine-demo';
  const defaultHash = hashPassword(demoPasscode);

  // 1. Staff Users
  const insertStaff = db.prepare(
    `INSERT INTO staff_users (id, username, display_name, role, gphc_number, branch_id, password_hash, active)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
  );
  insertStaff.run('STF-PHARM-01', 'h.whitaker', 'Dr. Hannah Whitaker', 'pharmacist', 'DEMO-2091841', 'BR-PENNINE-01', defaultHash);
  insertStaff.run('STF-ACT-01', 'l.patel', 'Liam Patel', 'act', 'DEMO-5018293', 'BR-PENNINE-01', defaultHash);
  insertStaff.run('STF-DISP-01', 'c.bennett', 'Chloe Bennett', 'dispenser', null, 'BR-PENNINE-01', defaultHash);
  insertStaff.run('STF-CNTR-01', 's.khan', 'Samira Khan', 'counter', null, 'BR-PENNINE-01', defaultHash);
  insertStaff.run('STF-ADMIN-01', 'o.grant', 'Oliver Grant', 'admin', null, 'BR-PENNINE-01', defaultHash);

  // 2. Organisational Policy
  db.prepare(
    `INSERT INTO org_policy (
      id, organisation_name, branch_name, ods_code, jurisdiction,
      require_separate_preparer_and_checker, require_separate_clinical_and_accuracy_checker,
      allow_emergency_self_check_override, require_patient_id_check_on_handover,
      clinical_adapter_available, clinical_adapter_version, dmd_catalog_version,
      updated_at, updated_by
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'POL-PENNINE-01',
    'TERTIUSMEDICO Independent Prototype',
    'Pennine Community Pharmacy (Hebden Bridge)',
    'FPROTO-PENNINE-01',
    'England (NHSBSA / GPhC)',
    1,
    0,
    0,
    1,
    1,
    'UK-BNF-Demo-Adapter v2026.11',
    'dm+d Release 2026.11',
    now,
    'Oliver Grant',
  );

  // 3. Versioned NHS England Charge Rules
  db.prepare(
    `INSERT INTO charge_rules (
      id, effective_from, jurisdiction, nhs_charge_per_item_pence,
      ppc_3_month_pence, ppc_12_month_pence, hrt_ppc_12_month_pence, source_url, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'CHG-ENG-2026',
    '2024-05-01',
    'England',
    990,
    3205,
    11450,
    1980,
    'https://www.nhsbsa.nhs.uk/help-nhs-prescription-costs',
    'England NHS prescription charge frozen at £9.90/item (990p). Note: Legacy Income Support / Income-based JSA exemptions phased out April 2026 in favour of Universal Credit thresholds.',
  );

  // 4. Synthetic Patients
  const insertPatient = db.prepare(
    `INSERT INTO patients (
      id, internal_id, nhs_number, nhs_number_verified, full_name, date_of_birth,
      postcode, address_line1, city, phone, email, preferred_contact,
      accessibility_needs_json, allergy_status, allergies_json,
      exemption_status, exemption_reference, authorised_representatives_json,
      external_references_json, portal_pin_last4
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  insertPatient.run(
    'PAT-1001',
    'PEN-PAT-001001',
    '943 476 5821',
    1,
    'Arthur Pendelton',
    '1951-04-12',
    'HX7 6AB',
    '22 Bridge Gate',
    'Hebden Bridge',
    '07700 900142',
    'arthur.pendelton@synthetic.example.uk',
    'sms',
    JSON.stringify(['Large-print dispensing labels (16pt)', 'Easy-open non-CRC bottle caps']),
    'recorded',
    JSON.stringify([
      {
        id: 'ALG-101',
        substance: 'Penicillins',
        reaction: 'Urticarial rash & facial swelling',
        severity: 'severe',
        source: 'GP Summary Care Record (Synthetic)',
        verificationStatus: 'verified',
        recordedAt: '2024-06-15T10:00:00Z',
      },
    ]),
    'exempt_age_60_plus',
    'AGE-EXEMPT-60+',
    JSON.stringify([
      {
        id: 'REP-101',
        name: 'Claire Pendelton',
        relationship: 'Daughter',
        phone: '07700 900199',
        idVerificationRequired: true,
        verifiedByStaff: true,
      },
    ]),
    JSON.stringify({gpSystemRef: 'EMIS-SYN-88412', pdsTraceId: 'PDS-SIM-1001'}),
    '5821',
  );

  insertPatient.run(
    'PAT-1002',
    'PEN-PAT-001002',
    '943 512 0944',
    1,
    'Meera Sharma',
    '1986-09-23',
    'HX7 7DL',
    '8 Valley Road',
    'Hebden Bridge',
    '07700 900255',
    'meera.sharma@synthetic.example.uk',
    'portal',
    JSON.stringify([]),
    'no_known_allergies',
    JSON.stringify([]),
    'chargeable',
    null,
    JSON.stringify([]),
    JSON.stringify({gpSystemRef: 'TPP-SYN-44109', pdsTraceId: 'PDS-SIM-1002'}),
    '0944',
  );

  insertPatient.run(
    'PAT-1003',
    'PEN-PAT-001003',
    '943 882 1107',
    0,
    "Declan O'Connor",
    '1974-11-03',
    'HX7 8AA',
    '15 Crown Street',
    'Hebden Bridge',
    '07700 900311',
    'declan.oconnor@synthetic.example.uk',
    'sms',
    JSON.stringify(['Braille / tactile label request']),
    'unavailable',
    JSON.stringify([]),
    'ppc_12_month',
    'PPC-SIM-2026-7721',
    JSON.stringify([]),
    JSON.stringify({gpSystemRef: 'PENDING-TRACE'}),
    '1107',
  );

  insertPatient.run(
    'PAT-1004',
    'PEN-PAT-001004',
    '943 604 3319',
    1,
    'Eleanor Vance',
    '1993-02-18',
    'HX7 6EF',
    '4 Albert Terrace',
    'Hebden Bridge',
    '07700 900488',
    'eleanor.vance@synthetic.example.uk',
    'email',
    JSON.stringify([]),
    'no_known_allergies',
    JSON.stringify([]),
    'exempt_matex',
    'MATEX-SIM-99201',
    JSON.stringify([]),
    JSON.stringify({gpSystemRef: 'EMIS-SYN-33018', pdsTraceId: 'PDS-SIM-1004'}),
    '3319',
  );

  insertPatient.run(
    'PAT-1005',
    'PEN-PAT-001005',
    '943 221 7740',
    1,
    'George Barlow',
    '1945-07-30',
    'HX7 9PR',
    '31 Hangingroyd Lane',
    'Hebden Bridge',
    '07700 900512',
    'george.barlow@synthetic.example.uk',
    'phone',
    JSON.stringify(['Housebound — authorised van delivery']),
    'recorded',
    JSON.stringify([
      {
        id: 'ALG-501',
        substance: 'Sulfonamides',
        reaction: 'GI intolerance & skin sensitivity',
        severity: 'moderate',
        source: 'Patient self-report (Pending GP confirmation)',
        verificationStatus: 'unverified',
        recordedAt: '2025-03-10T14:20:00Z',
      },
    ]),
    'exempt_age_60_plus',
    'AGE-EXEMPT-60+',
    JSON.stringify([]),
    JSON.stringify({gpSystemRef: 'EMIS-SYN-11294', pdsTraceId: 'PDS-SIM-1005'}),
    '7740',
  );

  // 5. Medicine Catalogue (dm+d versioned)
  const insertMed = db.prepare(
    `INSERT INTO medicine_products (
      id, vtm_name, vmp_code, amp_code, vmpp_code, ampp_code,
      prescribed_name, dispensable_product_name, strength, pharmaceutical_form,
      pack_size, quantity_unit, legal_category, cold_chain_required,
      storage_requirement, supplier_sku, barcode_ean13,
      nhs_tariff_pence, private_price_pence, dmd_version
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  insertMed.run(
    'MED-ATOR-20',
    'Atorvastatin',
    '319773006',
    '91827364501',
    '10482911000001105',
    '10482911000001999',
    'Atorvastatin 20mg tablets',
    'Atorvastatin 20mg film-coated tablets (Pennine Generics 28 pack)',
    '20mg',
    'Film-coated tablet',
    28,
    'tablet',
    'POM',
    0,
    'Ambient (<25°C)',
    'PEN-ATOR-20-28',
    '5012345000101',
    118,
    950,
    '2026.11',
  );

  insertMed.run(
    'MED-RAMI-5',
    'Ramipril',
    '318851002',
    '91827364502',
    '10482921000001106',
    '10482921000001998',
    'Ramipril 5mg capsules',
    'Ramipril 5mg hard capsules (Northern Pharma 28 pack)',
    '5mg',
    'Hard capsule',
    28,
    'capsule',
    'POM',
    0,
    'Ambient (<25°C)',
    'PEN-RAMI-05-28',
    '5012345000200',
    134,
    980,
    '2026.11',
  );

  insertMed.run(
    'MED-AMOX-500',
    'Amoxicillin',
    '323942006',
    '91827364503',
    '10482931000001107',
    '10482931000001997',
    'Amoxicillin 500mg capsules',
    'Amoxicillin 500mg hard capsules (21 pack)',
    '500mg',
    'Hard capsule',
    21,
    'capsule',
    'POM',
    0,
    'Ambient (<25°C)',
    'PEN-AMOX-500-21',
    '5012345000309',
    149,
    1120,
    '2026.11',
  );

  insertMed.run(
    'MED-SALB-100',
    'Salbutamol',
    '358427001',
    '91827364504',
    '10482941000001108',
    '10482941000001996',
    'Salbutamol 100micrograms/dose inhaler CFC free',
    'Salbutamol 100micrograms/dose Evohaler (200-dose unit)',
    '100mcg/actuation',
    'Pressurised inhalation suspension',
    1,
    'inhaler',
    'POM',
    0,
    'Ambient (<30°C)',
    'PEN-SALB-100-01',
    '5012345000408',
    150,
    1250,
    '2026.11',
  );

  insertMed.run(
    'MED-INSG-100',
    'Insulin glargine',
    '395891009',
    '91827364505',
    '10482951000001109',
    '10482951000001995',
    'Insulin glargine 100units/ml solution for injection 3ml pre-filled pens',
    'Lantus SoloStar 100units/mL 3mL pre-filled pens (5 pack)',
    '100units/mL',
    'Solution for injection in pre-filled pen',
    5,
    'pen',
    'POM',
    1,
    'Cold Chain (2°C to 8°C — Do not freeze)',
    'PEN-INSG-05',
    '5012345000507',
    3475,
    4800,
    '2026.11',
  );

  insertMed.run(
    'MED-MORP-10',
    'Morphine',
    '329894007',
    '91827364506',
    '10482961000001110',
    '10482961000001994',
    'Morphine sulfate 10mg/5ml oral solution',
    'Oramorph 10mg/5mL oral solution (100mL bottle)',
    '10mg/5mL',
    'Oral solution',
    100,
    'mL',
    'CD2',
    0,
    'CD Safe (Schedule 2 Controlled Drug)',
    'PEN-MORP-100',
    '5012345000606',
    192,
    1450,
    '2026.11',
  );

  insertMed.run(
    'MED-LEVO-50',
    'Levothyroxine sodium',
    '322591008',
    '91827364507',
    '10482971000001111',
    '10482971000001993',
    'Levothyroxine sodium 50microgram tablets',
    'Levothyroxine 50mcg tablets (28 pack)',
    '50mcg',
    'Tablet',
    28,
    'tablet',
    'POM',
    0,
    'Ambient (<25°C)',
    'PEN-LEVO-50-28',
    '5012345000705',
    122,
    890,
    '2026.11',
  );

  // 6. Stock Batches
  const insertBatch = db.prepare(
    `INSERT INTO stock_batches (
      id, branch_id, location, product_id, batch_number, expiry_date,
      physical_qty, reserved_qty, state, unit, cost_pence_per_pack, received_at, quarantine_reason
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  // Intentionally 14 tablets of Atorvastatin 20mg so 28-tablet Rx shows insufficient stock -> partial supply!
  insertBatch.run('BAT-ATOR-01', 'BR-PENNINE-01', 'Dispensary Bay A', 'MED-ATOR-20', 'AT26-441', '2027-09-30', 14, 0, 'available', 'tablet', 118, '2026-10-12T09:00:00Z', null);
  insertBatch.run('BAT-RAMI-01', 'BR-PENNINE-01', 'Dispensary Bay A', 'MED-RAMI-5', 'RM26-102', '2027-11-30', 84, 0, 'available', 'capsule', 134, '2026-10-18T11:30:00Z', null);
  // Expired Amoxicillin batch (must be excluded from FEFO!)
  insertBatch.run('BAT-AMOX-EXP', 'BR-PENNINE-01', 'Quarantine Cage', 'MED-AMOX-500', 'BATCH-AMX-EXP', '2026-09-30', 21, 0, 'expired', 'capsule', 149, '2025-11-01T10:00:00Z', 'Expired 2026-09-30 — awaiting disposal');
  // Recalled-target Amoxicillin batch (starts available until Step 12 recall or manual recall trigger)
  insertBatch.run('BAT-AMOX-REC', 'BR-PENNINE-01', 'Dispensary Bay B', 'MED-AMOX-500', 'BATCH-AMX-REC', '2027-05-31', 42, 0, 'available', 'capsule', 149, '2026-08-14T10:00:00Z', null);
  insertBatch.run('BAT-AMOX-01', 'BR-PENNINE-01', 'Dispensary Bay B', 'MED-AMOX-500', 'BATCH-AMX-2611', '2027-08-31', 63, 0, 'available', 'capsule', 149, '2026-11-02T09:15:00Z', null);
  insertBatch.run('BAT-SALB-01', 'BR-PENNINE-01', 'Dispensary Bay B', 'MED-SALB-100', 'SB26-884', '2028-01-31', 12, 2, 'available', 'inhaler', 150, '2026-10-20T14:00:00Z', null);
  insertBatch.run('BAT-INSG-01', 'BR-PENNINE-01', 'Cold Chain Fridge 1', 'MED-INSG-100', 'IG26-220', '2027-06-30', 10, 0, 'available', 'pen', 3475, '2026-11-01T08:30:00Z', null);
  insertBatch.run('BAT-MORP-01', 'BR-PENNINE-01', 'CD Cabinet', 'MED-MORP-10', 'MS26-019', '2027-10-31', 300, 0, 'available', 'mL', 192, '2026-10-28T13:10:00Z', null);
  insertBatch.run('BAT-LEVO-01', 'BR-PENNINE-01', 'Dispensary Bay A', 'MED-LEVO-50', 'LV26-512', '2027-12-31', 112, 0, 'available', 'tablet', 122, '2026-11-04T10:00:00Z', null);

  // 7. Synthetic Prescriptions
  const insertRx = db.prepare(
    `INSERT INTO prescriptions (
      id, prescription_id, source_identifier, source_system, patient_id,
      patient_reference, match_status, prescriber_details, issue_date, received_at,
      status, version, provenance, verification_required, document_verified_by,
      document_verified_at, attachment_id, delivery_requested, collection_option,
      exemption_or_charge_status, charge_total_pence, payment_status, source_payload_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  const insertItem = db.prepare(
    `INSERT INTO prescription_items (
      id, prescription_id, product_id, prescribed_medicine_text, selected_product_name,
      strength, form, directions_as_received, directions_amended, amendment_reason,
      prescribed_qty, prepared_qty, supplied_qty, outstanding_qty, cancelled_qty,
      unit, legal_category, status, allocated_batch_id, allocated_batch_number,
      allocated_expiry_date, barcode_verified, barcode_scanned_at, barcode_scanned_value,
      clinical_decision, clinical_reviewed_by, clinical_reviewed_at, clinical_notes,
      clinical_adapter_used, clinical_adapter_status_at_review,
      prepared_by, prepared_at, checked_by, checked_at, handed_over_by, handed_over_at,
      label_generated_at, substitution_recorded, partial_reason, owing_expiry_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  // RX-2026-4001: Meera Sharma - Awaiting clinical review
  insertRx.run(
    'RX-2026-4001',
    'RX-2026-4001',
    'EPS-MSG-4001',
    'NHS_EPS_SIM',
    'PAT-1002',
    'NHS 943 512 0944 | Meera Sharma',
    'matched',
    'Dr. S. Iqbal · Calder Valley Medical Centre (ODS Y09911)',
    '2026-11-26',
    '2026-11-26T08:15:00Z',
    'Awaiting clinical review',
    1,
    'Synthetic NHS EPS R4 Inbound Message',
    0,
    null,
    null,
    null,
    0,
    'in_store_counter',
    'chargeable (£9.90 per item)',
    990,
    'unpaid',
    JSON.stringify({
      messageId: 'EPS-MSG-4001',
      patientNhs: '9435120944',
      prescriber: 'Dr. S. Iqbal',
      items: [{vmp: '318851002', text: 'Ramipril 5mg capsules', qty: 28, sig: 'Take ONE capsule daily'}],
    }),
  );
  insertItem.run(
    'ITEM-4001-1',
    'RX-2026-4001',
    'MED-RAMI-5',
    'Ramipril 5mg capsules',
    'Ramipril 5mg hard capsules (Northern Pharma 28 pack)',
    '5mg',
    'Hard capsule',
    'Take ONE capsule daily',
    null,
    null,
    28,
    0,
    0,
    28,
    0,
    'capsule',
    'POM',
    'Awaiting clinical review',
    null,
    null,
    null,
    0,
    null,
    null,
    'pending',
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
  );

  // RX-2026-4002: Declan O'Connor - Awaiting clarification (Allergy status unavailable)
  insertRx.run(
    'RX-2026-4002',
    'RX-2026-4002',
    'EPS-MSG-4002',
    'NHS_EPS_SIM',
    'PAT-1003',
    "NHS 943 882 1107 | Declan O'Connor",
    'matched',
    'Dr. R. Ellis · Hebden Bridge Group Practice',
    '2026-11-25',
    '2026-11-25T16:40:00Z',
    'Awaiting clarification',
    1,
    'Synthetic NHS EPS R4 Inbound Message',
    0,
    null,
    null,
    null,
    0,
    'in_store_counter',
    'ppc_12_month (PPC-SIM-2026-7721)',
    0,
    'not_applicable',
    JSON.stringify({
      messageId: 'EPS-MSG-4002',
      patientNhs: '9438821107',
      prescriber: 'Dr. R. Ellis',
      items: [{vmp: '322591008', text: 'Levothyroxine 50mcg tablets', qty: 28, sig: 'Take ONE tablet each morning before breakfast'}],
    }),
  );
  insertItem.run(
    'ITEM-4002-1',
    'RX-2026-4002',
    'MED-LEVO-50',
    'Levothyroxine sodium 50microgram tablets',
    'Levothyroxine 50mcg tablets (28 pack)',
    '50mcg',
    'Tablet',
    'Take ONE tablet each morning before breakfast',
    null,
    null,
    28,
    0,
    0,
    28,
    0,
    'tablet',
    'POM',
    'Awaiting clarification',
    null,
    null,
    null,
    0,
    null,
    null,
    'query',
    'Dr. Hannah Whitaker',
    '2026-11-25T17:00:00Z',
    'Allergy history unavailable and NHS number unverified — confirm with patient/GP.',
    'UK-BNF-Demo-Adapter v2026.11',
    'available',
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
  );

  // RX-2026-4003: Eleanor Vance - Ready for handover (Salbutamol x 2 inhalers)
  insertRx.run(
    'RX-2026-4003',
    'RX-2026-4003',
    'EPS-MSG-4003',
    'NHS_EPS_SIM',
    'PAT-1004',
    'NHS 943 604 3319 | Eleanor Vance',
    'matched',
    'Dr. S. Iqbal · Calder Valley Medical Centre',
    '2026-11-25',
    '2026-11-25T11:20:00Z',
    'Ready for handover',
    1,
    'Synthetic NHS EPS R4 Inbound Message',
    0,
    null,
    null,
    null,
    0,
    'in_store_counter',
    'exempt_matex (MATEX-SIM-99201)',
    0,
    'not_applicable',
    JSON.stringify({
      messageId: 'EPS-MSG-4003',
      patientNhs: '9436043319',
      items: [{vmp: '358427001', text: 'Salbutamol 100mcg/dose inhaler', qty: 2, sig: 'Inhale TWO puffs when required'}],
    }),
  );
  insertItem.run(
    'ITEM-4003-1',
    'RX-2026-4003',
    'MED-SALB-100',
    'Salbutamol 100micrograms/dose inhaler CFC free',
    'Salbutamol 100micrograms/dose Evohaler (200-dose unit)',
    '100mcg/actuation',
    'Pressurised inhalation suspension',
    'Inhale TWO puffs when required for wheeze or breathlessness',
    null,
    null,
    2,
    2,
    0,
    2,
    0,
    'inhaler',
    'POM',
    'Ready for handover',
    'BAT-SALB-01',
    'SB26-884',
    '2028-01-31',
    1,
    '2026-11-25T12:15:00Z',
    '5012345000408',
    'approved',
    'Dr. Hannah Whitaker',
    '2026-11-25T11:45:00Z',
    'Clinically appropriate; spacer technique reinforced.',
    'UK-BNF-Demo-Adapter v2026.11',
    'available',
    'Chloe Bennett',
    '2026-11-25T12:15:00Z',
    'Liam Patel',
    '2026-11-25T12:40:00Z',
    null,
    null,
    '2026-11-25T12:16:00Z',
    null,
    null,
    null,
  );

  // RX-2026-4004: Unmatched Patient Exception
  insertRx.run(
    'RX-2026-4004',
    'RX-2026-4004',
    'EPS-UNMATCHED-9904',
    'NHS_EPS_SIM',
    null,
    'UNMATCHED: J. Whitaker · DOB 1962-08-14 · HX7 8PQ (No NHS number)',
    'ambiguous_review',
    'Dr. A. Shaw · Todmorden Health Centre',
    '2026-11-26',
    '2026-11-26T07:55:00Z',
    'Received',
    1,
    'Synthetic NHS EPS R4 Inbound Message — Demographic Trace Ambiguous',
    0,
    null,
    null,
    null,
    0,
    'in_store_counter',
    'pending_patient_match',
    0,
    'not_applicable',
    JSON.stringify({
      messageId: 'EPS-UNMATCHED-9904',
      patientReference: 'J. Whitaker, DOB 1962-08-14, HX7 8PQ',
      items: [{vmp: '323942006', text: 'Amoxicillin 500mg capsules', qty: 21, sig: 'Take ONE capsule THREE times daily for 7 days'}],
    }),
  );
  insertItem.run(
    'ITEM-4004-1',
    'RX-2026-4004',
    'MED-AMOX-500',
    'Amoxicillin 500mg capsules',
    'Amoxicillin 500mg hard capsules (21 pack)',
    '500mg',
    'Hard capsule',
    'Take ONE capsule THREE times daily for 7 days',
    null,
    null,
    21,
    0,
    0,
    21,
    0,
    'capsule',
    'POM',
    'Received',
    null,
    null,
    null,
    0,
    null,
    null,
    'pending',
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
  );

  // RX-2026-4005: George Barlow - Previously supplied from BATCH-AMX-REC (Recall demonstration target!)
  insertRx.run(
    'RX-2026-4005',
    'RX-2026-4005',
    'EPS-MSG-4005',
    'NHS_EPS_SIM',
    'PAT-1005',
    'NHS 943 221 7740 | George Barlow',
    'matched',
    'Dr. R. Ellis · Hebden Bridge Group Practice',
    '2026-11-20',
    '2026-11-20T09:10:00Z',
    'Completed',
    1,
    'Synthetic NHS EPS R4 Inbound Message',
    0,
    null,
    null,
    null,
    1,
    'local_van_delivery',
    'exempt_age_60_plus (AGE-EXEMPT-60+)',
    0,
    'not_applicable',
    JSON.stringify({
      messageId: 'EPS-MSG-4005',
      patientNhs: '9432217740',
      items: [{vmp: '323942006', text: 'Amoxicillin 500mg capsules', qty: 21, sig: 'Take ONE capsule THREE times daily'}],
    }),
  );
  insertItem.run(
    'ITEM-4005-1',
    'RX-2026-4005',
    'MED-AMOX-500',
    'Amoxicillin 500mg capsules',
    'Amoxicillin 500mg hard capsules (21 pack)',
    '500mg',
    'Hard capsule',
    'Take ONE capsule THREE times daily for 7 days',
    null,
    null,
    21,
    21,
    21,
    0,
    0,
    'capsule',
    'POM',
    'Completed',
    'BAT-AMOX-REC',
    'BATCH-AMX-REC',
    '2027-05-31',
    1,
    '2026-11-20T10:15:00Z',
    '5012345000309',
    'approved',
    'Dr. Hannah Whitaker',
    '2026-11-20T09:40:00Z',
    'No penicillin allergy recorded (Sulfonamides allergy only).',
    'UK-BNF-Demo-Adapter v2026.11',
    'available',
    'Chloe Bennett',
    '2026-11-20T10:15:00Z',
    'Liam Patel',
    '2026-11-20T10:35:00Z',
    'Samira Khan',
    '2026-11-20T14:10:00Z',
    '2026-11-20T10:16:00Z',
    null,
    null,
    null,
  );

  // RX-2026-4006: Uploaded document scan requiring verification
  db.prepare(
    `INSERT INTO attachments (id, filename, mime_type, storage_key, uploaded_by, verified_by, verified_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'ATT-DOC-701',
    'private_rx_scan_eleanor_vance.pdf',
    'application/pdf',
    'protected-uploads/att-doc-701.pdf',
    'Samira Khan',
    null,
    null,
    '2026-11-26T08:45:00Z',
  );
  insertRx.run(
    'RX-2026-4006',
    'RX-2026-4006',
    'UPLOAD-DOC-701',
    'UPLOADED_DOCUMENT',
    'PAT-1004',
    'NHS 943 604 3319 | Eleanor Vance',
    'matched',
    'Dr. P. Mercer · Private Clinic (Uploaded PDF — Unverified)',
    '2026-11-26',
    '2026-11-26T08:45:00Z',
    'Received',
    1,
    'Uploaded Scanned Document — Requires Pharmacist Verification before Dispensing',
    1,
    null,
    null,
    'ATT-DOC-701',
    0,
    'in_store_counter',
    'exempt_matex (MATEX-SIM-99201)',
    0,
    'not_applicable',
    JSON.stringify({
      attachmentId: 'ATT-DOC-701',
      note: 'Uploaded scan cannot become valid prescription until verified by authorised staff.',
    }),
  );
  insertItem.run(
    'ITEM-4006-1',
    'RX-2026-4006',
    'MED-INSG-100',
    'Insulin glargine 100units/ml pre-filled pens',
    'Lantus SoloStar 100units/mL 3mL pre-filled pens (5 pack)',
    '100units/mL',
    'Solution for injection in pre-filled pen',
    'Inject 14 units subcutaneously once daily at bedtime',
    null,
    null,
    5,
    0,
    0,
    5,
    0,
    'pen',
    'POM',
    'Received',
    null,
    null,
    null,
    0,
    null,
    null,
    'pending',
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
  );

  // 8. Procurement Order (ready for approval/receipt or new order)
  db.prepare(
    `INSERT INTO procurement_orders (
      id, order_number, supplier_name, status, created_by, approved_by,
      created_at, updated_at, total_pence, notes, lines_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'PO-2026-0101',
    'PO-2026-0101',
    'Pennine Pharma Wholesale Ltd',
    'Acknowledged',
    'Chloe Bennett',
    'Dr. Hannah Whitaker',
    '2026-11-25T15:00:00Z',
    '2026-11-26T08:00:00Z',
    236,
    'Scheduled morning van replenishment for Atorvastatin 20mg tablets (2 packs x 28 = 56 tablets).',
    JSON.stringify([
      {
        productId: 'MED-ATOR-20',
        productName: 'Atorvastatin 20mg film-coated tablets (Pennine Generics 28 pack)',
        sku: 'PEN-ATOR-20-28',
        orderedPacks: 2,
        packSize: 28,
        unit: 'tablet',
        unitCostPence: 118,
        receivedPacks: 0,
        damagedPacks: 0,
      },
    ]),
  );

  // 9. CD Register Entry (Demonstration Schedule 2 Register)
  db.prepare(
    `INSERT INTO cd_register_entries (
      id, entry_number, product_id, entry_type, prescription_ref, patient_or_supplier,
      qty_received, qty_supplied, running_balance, unit, batch_number,
      actor_id, actor_name, correction_of_id, correction_reason, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'CD-ENT-001',
    1,
    'MED-MORP-10',
    'receipt',
    'INV-PEN-8821',
    'Pennine Pharma Wholesale Ltd (14 Market St)',
    300,
    0,
    300,
    'mL',
    'MS26-019',
    'STF-PHARM-01',
    'Dr. Hannah Whitaker',
    null,
    null,
    '2026-10-28T13:15:00Z',
  );

  // 10. Cold Chain Observations
  const insertTemp = db.prepare(
    `INSERT INTO cold_chain_logs (id, location, temperature_c, source, excursion_detected, action_taken, recorded_by, recorded_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertTemp.run('TEMP-001', 'Cold Chain Fridge 1', 4.3, 'Automated Probe Log (Simulated)', 0, 'Within 2.0°C–8.0°C range', 'Chloe Bennett', '2026-11-26T08:00:00Z');
  insertTemp.run('TEMP-002', 'Cold Chain Fridge 1', 4.6, 'Manual Morning Min/Max Check', 0, 'Within 2.0°C–8.0°C range', 'Dr. Hannah Whitaker', '2026-11-25T08:05:00Z');

  // 11. Pharmacy Services & Appointments
  const insertSvc = db.prepare(
    `INSERT INTO pharmacy_services (
      id, name, category, duration_minutes, eligible_roles_json, room, required_equipment, active, clinical_pathway_note
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertSvc.run(
    'SVC-PHARM-FIRST',
    'NHS Pharmacy First Consultation',
    'Clinical Pathway',
    20,
    JSON.stringify(['pharmacist']),
    'Consultation Room 1',
    'Otoscope, thermometer, clinical examination light',
    1,
    'Eligibility and clinical supply decision remain strictly with authorised pharmacist under validated PGDs.',
  );
  insertSvc.run(
    'SVC-BP-CHECK',
    'NHS Hypertension Case-Finding (Blood Pressure Check)',
    'Screening',
    15,
    JSON.stringify(['pharmacist', 'act', 'dispenser']),
    'Consultation Room 1',
    'Validated upper-arm BP monitor & ABPM loan kit',
    1,
    'Escalate readings >= 140/90 mmHg for ABPM or GP referral per NICE NG136 pathway.',
  );
  insertSvc.run(
    'SVC-NMS',
    'New Medicine Service (NMS) Follow-up',
    'Medicines Support',
    15,
    JSON.stringify(['pharmacist']),
    'Consultation Room 1 / Telephone',
    'PMR record access',
    1,
    'Supports adherence 7–14 days after newly prescribed chronic condition medicines.',
  );
  insertSvc.run(
    'SVC-FLU-VAC',
    'Seasonal Influenza Vaccination',
    'Immunisation',
    15,
    JSON.stringify(['pharmacist']),
    'Consultation Room 2',
    'Vaccine fridge stock, anaphylaxis kit, sharps bin',
    1,
    'Requires signed patient consent and cold-chain batch verification.',
  );

  db.prepare(
    `INSERT INTO service_appointments (
      id, service_id, patient_id, practitioner_id, scheduled_at, status,
      consent_recorded, attendance_status, outcome_reference, follow_up_task, notes, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'APT-1001',
    'SVC-BP-CHECK',
    'PAT-1001',
    'STF-PHARM-01',
    '2026-11-27T10:30:00Z',
    'booked',
    1,
    'pending',
    null,
    'Confirm clinic reading & update summary',
    'Routine 6-monthly BP check alongside lipid medication review.',
    '2026-11-25T14:00:00Z',
  );

  // 12. Notifications (including 1 failed notification for test/demo coverage!)
  const insertNotif = db.prepare(
    `INSERT INTO notifications (
      id, patient_id, prescription_id, channel, public_summary, portal_detail,
      status, attempts, failure_reason, created_at, sent_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertNotif.run(
    'NOTIF-001',
    'PAT-1004',
    'RX-2026-4003',
    'sms',
    'Pennine Community Pharmacy: Your prescription is ready for collection. View details in the patient portal.',
    'Prescription RX-2026-4003 (Salbutamol 100mcg/dose Evohaler x 2) is ready for collection at Pennine Community Pharmacy counter.',
    'sent',
    1,
    null,
    '2026-11-25T12:42:00Z',
    '2026-11-25T12:42:05Z',
  );
  insertNotif.run(
    'NOTIF-002',
    'PAT-1003',
    'RX-2026-4002',
    'sms',
    'Pennine Community Pharmacy: Please contact the pharmacy regarding a query on your prescription.',
    'Clarification required on RX-2026-4002: please confirm your allergy history with the pharmacist.',
    'failed',
    3,
    'SMS gateway bounce: carrier unreachable (07700 900311) — manual phone call required',
    '2026-11-25T17:05:00Z',
    null,
  );

  // 13. Deliveries (dispatched != confirmed receipt)
  db.prepare(
    `INSERT INTO deliveries (
      id, prescription_id, patient_id, driver_name, route_zone, status,
      recipient_checked, dispatched_at, delivered_at, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'DEL-1001',
    'RX-2026-4005',
    'PAT-1005',
    'Marcus Cole (Van 1)',
    'HX7 Hebden Valley West',
    'confirmed_received',
    'George Barlow (Signed doorstep receipt)',
    '2026-11-20T13:45:00Z',
    '2026-11-20T14:10:00Z',
    'Delivered to housebound patient.',
  );

  // 14. Audit Trail Seed
  db.prepare(
    `INSERT INTO audit_events (
      id, actor_id, actor_name, actor_role, action, entity_type, entity_id, summary, before_json, after_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'AUD-0001',
    'STF-ADMIN-01',
    'Oliver Grant',
    'admin',
    'SYSTEM_SEED_INITIALISED',
    'system',
    'PENNINE-01',
    'Initialised Pennine Community Pharmacy synthetic demonstration database (Independent Prototype).',
    null,
    JSON.stringify({dmdVersion: '2026.11', nhsChargePerItemPence: 990}),
    now,
  );
}
