import {createRequire} from 'node:module';
import type {DatabaseSync as DatabaseSyncType} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {dirname, resolve} from 'node:path';

const require = createRequire(import.meta.url);
const {DatabaseSync} = require('node:sqlite') as typeof import('node:sqlite');
type DatabaseSync = DatabaseSyncType;

let dbInstance: DatabaseSync | null = null;
let initializedPath: string | null = null;

export function getDbPath(): string {
  const configured = process.env['TERMED_DB_PATH'];
  if (configured === ':memory:') {
    return ':memory:';
  }
  return resolve(process.cwd(), configured || './data/tertiusmedico.sqlite');
}

export function getDb(overridePath?: string): DatabaseSync {
  const targetPath = overridePath ?? getDbPath();
  if (dbInstance && initializedPath === targetPath) {
    return dbInstance;
  }

  if (targetPath !== ':memory:') {
    mkdirSync(dirname(targetPath), {recursive: true});
  }

  const db = new DatabaseSync(targetPath);
  db.exec('PRAGMA foreign_keys = ON;');
  if (targetPath !== ':memory:') {
    db.exec('PRAGMA journal_mode = WAL;');
    db.exec('PRAGMA busy_timeout = 5000;');
  }
  applyMigrations(db);
  dbInstance = db;
  initializedPath = targetPath;
  return db;
}

export function resetDbConnection(): void {
  if (dbInstance) {
    try {
      dbInstance.close();
    } catch {
      // Ignore close error during reset
    }
    dbInstance = null;
    initializedPath = null;
  }
}

export function runInTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE;');
  try {
    const result = fn();
    db.exec('COMMIT;');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // Ignore rollback error
    }
    throw err;
  }
}

function applyMigrations(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const applied = new Set<number>(
    (db.prepare('SELECT version FROM schema_migrations').all() as {version: number}[]).map(
      (r) => r.version,
    ),
  );

  if (!applied.has(1)) {
    db.exec(`
      CREATE TABLE IF NOT EXISTS staff_users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        display_name TEXT NOT NULL,
        role TEXT NOT NULL,
        gphc_number TEXT,
        branch_id TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        actor_type TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        role TEXT NOT NULL,
        display_name TEXT NOT NULL,
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS org_policy (
        id TEXT PRIMARY KEY,
        organisation_name TEXT NOT NULL,
        branch_name TEXT NOT NULL,
        ods_code TEXT NOT NULL,
        jurisdiction TEXT NOT NULL,
        require_separate_preparer_and_checker INTEGER NOT NULL,
        require_separate_clinical_and_accuracy_checker INTEGER NOT NULL,
        allow_emergency_self_check_override INTEGER NOT NULL,
        require_patient_id_check_on_handover INTEGER NOT NULL,
        clinical_adapter_available INTEGER NOT NULL,
        clinical_adapter_version TEXT NOT NULL,
        dmd_catalog_version TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        updated_by TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS charge_rules (
        id TEXT PRIMARY KEY,
        effective_from TEXT NOT NULL,
        jurisdiction TEXT NOT NULL,
        nhs_charge_per_item_pence INTEGER NOT NULL,
        ppc_3_month_pence INTEGER NOT NULL,
        ppc_12_month_pence INTEGER NOT NULL,
        hrt_ppc_12_month_pence INTEGER NOT NULL,
        source_url TEXT NOT NULL,
        notes TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS patients (
        id TEXT PRIMARY KEY,
        internal_id TEXT UNIQUE NOT NULL,
        nhs_number TEXT,
        nhs_number_verified INTEGER NOT NULL DEFAULT 0,
        full_name TEXT NOT NULL,
        date_of_birth TEXT NOT NULL,
        postcode TEXT NOT NULL,
        address_line1 TEXT NOT NULL,
        city TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT NOT NULL,
        preferred_contact TEXT NOT NULL,
        accessibility_needs_json TEXT NOT NULL,
        allergy_status TEXT NOT NULL,
        allergies_json TEXT NOT NULL,
        exemption_status TEXT NOT NULL,
        exemption_reference TEXT,
        authorised_representatives_json TEXT NOT NULL,
        external_references_json TEXT NOT NULL,
        portal_pin_last4 TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS medicine_products (
        id TEXT PRIMARY KEY,
        vtm_name TEXT NOT NULL,
        vmp_code TEXT NOT NULL,
        amp_code TEXT,
        vmpp_code TEXT NOT NULL,
        ampp_code TEXT,
        prescribed_name TEXT NOT NULL,
        dispensable_product_name TEXT NOT NULL,
        strength TEXT NOT NULL,
        pharmaceutical_form TEXT NOT NULL,
        pack_size INTEGER NOT NULL,
        quantity_unit TEXT NOT NULL,
        legal_category TEXT NOT NULL,
        cold_chain_required INTEGER NOT NULL DEFAULT 0,
        storage_requirement TEXT NOT NULL,
        supplier_sku TEXT NOT NULL,
        barcode_ean13 TEXT NOT NULL,
        nhs_tariff_pence INTEGER NOT NULL,
        private_price_pence INTEGER NOT NULL,
        dmd_version TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS stock_batches (
        id TEXT PRIMARY KEY,
        branch_id TEXT NOT NULL,
        location TEXT NOT NULL,
        product_id TEXT NOT NULL REFERENCES medicine_products(id),
        batch_number TEXT NOT NULL,
        expiry_date TEXT NOT NULL,
        physical_qty INTEGER NOT NULL,
        reserved_qty INTEGER NOT NULL DEFAULT 0,
        state TEXT NOT NULL,
        unit TEXT NOT NULL,
        cost_pence_per_pack INTEGER NOT NULL,
        received_at TEXT NOT NULL,
        quarantine_reason TEXT
      );

      CREATE TABLE IF NOT EXISTS prescriptions (
        id TEXT PRIMARY KEY,
        prescription_id TEXT UNIQUE NOT NULL,
        source_identifier TEXT NOT NULL,
        source_system TEXT NOT NULL,
        patient_id TEXT REFERENCES patients(id),
        patient_reference TEXT NOT NULL,
        match_status TEXT NOT NULL,
        prescriber_details TEXT NOT NULL,
        issue_date TEXT NOT NULL,
        received_at TEXT NOT NULL,
        status TEXT NOT NULL,
        version INTEGER NOT NULL DEFAULT 1,
        provenance TEXT NOT NULL,
        verification_required INTEGER NOT NULL DEFAULT 0,
        document_verified_by TEXT,
        document_verified_at TEXT,
        attachment_id TEXT,
        delivery_requested INTEGER NOT NULL DEFAULT 0,
        collection_option TEXT NOT NULL DEFAULT 'in_store_counter',
        exemption_or_charge_status TEXT NOT NULL,
        charge_total_pence INTEGER NOT NULL DEFAULT 0,
        payment_status TEXT NOT NULL DEFAULT 'not_applicable',
        source_payload_json TEXT NOT NULL,
        UNIQUE(source_system, source_identifier, version)
      );

      CREATE TABLE IF NOT EXISTS prescription_items (
        id TEXT PRIMARY KEY,
        prescription_id TEXT NOT NULL REFERENCES prescriptions(id) ON DELETE CASCADE,
        product_id TEXT NOT NULL REFERENCES medicine_products(id),
        prescribed_medicine_text TEXT NOT NULL,
        selected_product_name TEXT NOT NULL,
        strength TEXT NOT NULL,
        form TEXT NOT NULL,
        directions_as_received TEXT NOT NULL,
        directions_amended TEXT,
        amendment_reason TEXT,
        prescribed_qty INTEGER NOT NULL,
        prepared_qty INTEGER NOT NULL DEFAULT 0,
        supplied_qty INTEGER NOT NULL DEFAULT 0,
        outstanding_qty INTEGER NOT NULL,
        cancelled_qty INTEGER NOT NULL DEFAULT 0,
        unit TEXT NOT NULL,
        legal_category TEXT NOT NULL,
        status TEXT NOT NULL,
        allocated_batch_id TEXT REFERENCES stock_batches(id),
        allocated_batch_number TEXT,
        allocated_expiry_date TEXT,
        barcode_verified INTEGER NOT NULL DEFAULT 0,
        barcode_scanned_at TEXT,
        barcode_scanned_value TEXT,
        clinical_decision TEXT NOT NULL DEFAULT 'pending',
        clinical_reviewed_by TEXT,
        clinical_reviewed_at TEXT,
        clinical_notes TEXT,
        clinical_adapter_used TEXT,
        clinical_adapter_status_at_review TEXT,
        prepared_by TEXT,
        prepared_at TEXT,
        checked_by TEXT,
        checked_at TEXT,
        handed_over_by TEXT,
        handed_over_at TEXT,
        label_generated_at TEXT,
        substitution_recorded TEXT,
        partial_reason TEXT,
        owing_expiry_date TEXT
      );

      CREATE TABLE IF NOT EXISTS processed_messages (
        id TEXT PRIMARY KEY,
        message_type TEXT NOT NULL,
        idempotency_key TEXT UNIQUE NOT NULL,
        prescription_id TEXT,
        status TEXT NOT NULL,
        received_at TEXT NOT NULL,
        notes TEXT
      );

      CREATE TABLE IF NOT EXISTS repeat_requests (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(id),
        product_id TEXT NOT NULL REFERENCES medicine_products(id),
        requested_qty INTEGER NOT NULL,
        patient_note TEXT,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL,
        reviewed_by TEXT,
        reviewed_at TEXT
      );

      CREATE TABLE IF NOT EXISTS stock_movements (
        id TEXT PRIMARY KEY,
        batch_id TEXT NOT NULL REFERENCES stock_batches(id),
        product_id TEXT NOT NULL REFERENCES medicine_products(id),
        movement_type TEXT NOT NULL,
        qty_delta INTEGER NOT NULL,
        unit TEXT NOT NULL,
        reference_type TEXT NOT NULL,
        reference_id TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        actor_name TEXT NOT NULL,
        notes TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS procurement_orders (
        id TEXT PRIMARY KEY,
        order_number TEXT UNIQUE NOT NULL,
        supplier_name TEXT NOT NULL,
        status TEXT NOT NULL,
        created_by TEXT NOT NULL,
        approved_by TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        total_pence INTEGER NOT NULL,
        notes TEXT,
        lines_json TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS recalls (
        id TEXT PRIMARY KEY,
        recall_ref TEXT UNIQUE NOT NULL,
        source TEXT NOT NULL,
        classification TEXT NOT NULL,
        product_id TEXT NOT NULL REFERENCES medicine_products(id),
        affected_batch_number TEXT NOT NULL,
        reason TEXT NOT NULL,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL,
        quarantined_qty INTEGER NOT NULL DEFAULT 0,
        affected_patients_json TEXT NOT NULL,
        investigation_log_json TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS cd_register_entries (
        id TEXT PRIMARY KEY,
        entry_number INTEGER NOT NULL,
        product_id TEXT NOT NULL REFERENCES medicine_products(id),
        entry_type TEXT NOT NULL,
        prescription_ref TEXT,
        patient_or_supplier TEXT NOT NULL,
        qty_received INTEGER NOT NULL DEFAULT 0,
        qty_supplied INTEGER NOT NULL DEFAULT 0,
        running_balance INTEGER NOT NULL,
        unit TEXT NOT NULL,
        batch_number TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        actor_name TEXT NOT NULL,
        correction_of_id TEXT,
        correction_reason TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS cold_chain_logs (
        id TEXT PRIMARY KEY,
        location TEXT NOT NULL,
        temperature_c REAL NOT NULL,
        source TEXT NOT NULL,
        excursion_detected INTEGER NOT NULL DEFAULT 0,
        action_taken TEXT,
        recorded_by TEXT NOT NULL,
        recorded_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS pharmacy_services (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        duration_minutes INTEGER NOT NULL,
        eligible_roles_json TEXT NOT NULL,
        room TEXT NOT NULL,
        required_equipment TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        clinical_pathway_note TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS service_appointments (
        id TEXT PRIMARY KEY,
        service_id TEXT NOT NULL REFERENCES pharmacy_services(id),
        patient_id TEXT NOT NULL REFERENCES patients(id),
        practitioner_id TEXT REFERENCES staff_users(id),
        scheduled_at TEXT NOT NULL,
        status TEXT NOT NULL,
        consent_recorded INTEGER NOT NULL DEFAULT 0,
        attendance_status TEXT NOT NULL DEFAULT 'pending',
        outcome_reference TEXT,
        follow_up_task TEXT,
        notes TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS notifications (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(id),
        prescription_id TEXT,
        channel TEXT NOT NULL,
        public_summary TEXT NOT NULL,
        portal_detail TEXT NOT NULL,
        status TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0,
        failure_reason TEXT,
        created_at TEXT NOT NULL,
        sent_at TEXT
      );

      CREATE TABLE IF NOT EXISTS deliveries (
        id TEXT PRIMARY KEY,
        prescription_id TEXT NOT NULL REFERENCES prescriptions(id),
        patient_id TEXT NOT NULL REFERENCES patients(id),
        driver_name TEXT NOT NULL,
        route_zone TEXT NOT NULL,
        status TEXT NOT NULL,
        recipient_checked TEXT,
        dispatched_at TEXT,
        delivered_at TEXT,
        notes TEXT
      );

      CREATE TABLE IF NOT EXISTS financial_transactions (
        id TEXT PRIMARY KEY,
        tx_type TEXT NOT NULL,
        prescription_id TEXT,
        patient_id TEXT,
        description TEXT NOT NULL,
        amount_pence INTEGER NOT NULL,
        payment_method TEXT NOT NULL,
        exemption_code TEXT,
        status TEXT NOT NULL,
        actor_name TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS attachments (
        id TEXT PRIMARY KEY,
        filename TEXT NOT NULL,
        mime_type TEXT NOT NULL,
        storage_key TEXT NOT NULL,
        uploaded_by TEXT NOT NULL,
        verified_by TEXT,
        verified_at TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS audit_events (
        id TEXT PRIMARY KEY,
        actor_id TEXT NOT NULL,
        actor_name TEXT NOT NULL,
        actor_role TEXT NOT NULL,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        summary TEXT NOT NULL,
        before_json TEXT,
        after_json TEXT,
        created_at TEXT NOT NULL
      );
    `);

    db.prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)').run(
      1,
      'initial_pharmacy_schema',
      new Date().toISOString(),
    );
  }
}
