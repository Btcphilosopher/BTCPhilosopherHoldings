export type StaffRole = 'pharmacist' | 'act' | 'dispenser' | 'counter' | 'admin';

export type PrescriptionStage =
  | 'Received'
  | 'Awaiting clarification'
  | 'Awaiting clinical review'
  | 'Awaiting stock'
  | 'Ready for preparation'
  | 'Prepared'
  | 'Awaiting accuracy check'
  | 'Ready for handover'
  | 'Partially supplied'
  | 'Completed'
  | 'Cancelled';

export type PrescriptionItemStage =
  | 'Received'
  | 'Awaiting clarification'
  | 'Awaiting clinical review'
  | 'Awaiting stock'
  | 'Ready for preparation'
  | 'Prepared'
  | 'Awaiting accuracy check'
  | 'Ready for handover'
  | 'Partially supplied'
  | 'Completed'
  | 'Cancelled';

export type AllergyRecordStatus = 'recorded' | 'no_known_allergies' | 'unavailable';

export type BatchAvailabilityState =
  | 'available'
  | 'quarantined'
  | 'recalled'
  | 'expired'
  | 'disposed';

export type LegalCategory = 'POM' | 'P' | 'GSL' | 'CD2' | 'CD3' | 'CD4';

export type QuantityUnit = 'tablet' | 'capsule' | 'mL' | 'inhaler' | 'pen' | 'pack';

export type SourceSystem = 'NHS_EPS_SIM' | 'MANUAL_DEMO' | 'UPLOADED_DOCUMENT' | 'PATIENT_PORTAL';

export interface StaffUser {
  id: string;
  username: string;
  displayName: string;
  role: StaffRole;
  gphcNumber: string | null;
  branchId: string;
  active: boolean;
}

export interface OrganisationalPolicy {
  id: string;
  organisationName: string;
  branchName: string;
  odsCode: string;
  jurisdiction: string;
  requireSeparatePreparerAndChecker: boolean;
  requireSeparateClinicalAndAccuracyChecker: boolean;
  allowEmergencySelfCheckOverride: boolean;
  requirePatientIdCheckOnHandover: boolean;
  clinicalAdapterAvailable: boolean;
  clinicalAdapterVersion: string;
  dmdCatalogVersion: string;
  updatedAt: string;
  updatedBy: string;
}

export interface ChargeRuleSet {
  id: string;
  effectiveFrom: string;
  jurisdiction: string;
  nhsChargePerItemPence: number;
  ppc3MonthPence: number;
  ppc12MonthPence: number;
  hrtPpc12MonthPence: number;
  sourceUrl: string;
  notes: string;
}

export interface PatientAllergy {
  id: string;
  substance: string;
  reaction: string;
  severity: 'mild' | 'moderate' | 'severe';
  source: string;
  verificationStatus: 'verified' | 'unverified';
  recordedAt: string;
}

export interface AuthorisedRepresentative {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  idVerificationRequired: boolean;
  verifiedByStaff: boolean;
}

export interface PatientRecord {
  id: string;
  internalId: string;
  nhsNumber: string | null;
  nhsNumberVerified: boolean;
  fullName: string;
  dateOfBirth: string;
  postcode: string;
  addressLine1: string;
  city: string;
  phone: string;
  email: string;
  preferredContact: 'sms' | 'email' | 'phone' | 'portal';
  accessibilityNeeds: string[];
  allergyStatus: AllergyRecordStatus;
  allergies: PatientAllergy[];
  exemptionStatus: 'exempt_age_60_plus' | 'exempt_matex' | 'exempt_medex' | 'ppc_12_month' | 'chargeable';
  exemptionReference: string | null;
  authorisedRepresentatives: AuthorisedRepresentative[];
  externalReferences: Record<string, string>;
  portalPinLast4: string;
}

export interface MedicineProduct {
  id: string;
  vtmName: string;
  vmpCode: string;
  ampCode: string | null;
  vmppCode: string;
  amppCode: string | null;
  prescribedName: string;
  dispensableProductName: string;
  strength: string;
  pharmaceuticalForm: string;
  packSize: number;
  quantityUnit: QuantityUnit;
  legalCategory: LegalCategory;
  coldChainRequired: boolean;
  storageRequirement: string;
  supplierSku: string;
  barcodeEan13: string;
  nhsTariffPence: number;
  privatePricePence: number;
  dmdVersion: string;
}

export interface StockBatch {
  id: string;
  branchId: string;
  location: string;
  productId: string;
  batchNumber: string;
  expiryDate: string;
  physicalQty: number;
  reservedQty: number;
  availableQty: number;
  state: BatchAvailabilityState;
  unit: QuantityUnit;
  costPencePerPack: number;
  receivedAt: string;
  quarantineReason: string | null;
}

export interface PrescriptionItem {
  id: string;
  prescriptionId: string;
  productId: string;
  prescribedMedicineText: string;
  selectedProductName: string;
  strength: string;
  form: string;
  directionsAsReceived: string;
  directionsAmended: string | null;
  amendmentReason: string | null;
  prescribedQty: number;
  preparedQty: number;
  suppliedQty: number;
  outstandingQty: number;
  cancelledQty: number;
  unit: QuantityUnit;
  legalCategory: LegalCategory;
  status: PrescriptionItemStage;
  allocatedBatchId: string | null;
  allocatedBatchNumber: string | null;
  allocatedExpiryDate: string | null;
  barcodeVerified: boolean;
  barcodeScannedAt: string | null;
  barcodeScannedValue: string | null;
  clinicalDecision: 'pending' | 'approved' | 'query' | 'rejected';
  clinicalReviewedBy: string | null;
  clinicalReviewedAt: string | null;
  clinicalNotes: string | null;
  clinicalAdapterUsed: string | null;
  clinicalAdapterStatusAtReview: 'available' | 'unavailable' | null;
  preparedBy: string | null;
  preparedAt: string | null;
  checkedBy: string | null;
  checkedAt: string | null;
  handedOverBy: string | null;
  handedOverAt: string | null;
  labelGeneratedAt: string | null;
  substitutionRecorded: string | null;
  partialReason: string | null;
  owingExpiryDate: string | null;
}

export interface Prescription {
  id: string;
  prescriptionId: string;
  sourceIdentifier: string;
  sourceSystem: SourceSystem;
  patientId: string | null;
  patientReference: string;
  matchStatus: 'matched' | 'unmatched' | 'ambiguous_review';
  prescriberDetails: string;
  issueDate: string;
  receivedAt: string;
  status: PrescriptionStage;
  version: number;
  provenance: string;
  verificationRequired: boolean;
  documentVerifiedBy: string | null;
  documentVerifiedAt: string | null;
  attachmentId: string | null;
  deliveryRequested: boolean;
  collectionOption: 'in_store_counter' | 'representative_collection' | 'local_van_delivery';
  exemptionOrChargeStatus: string;
  chargeTotalPence: number;
  paymentStatus: 'not_applicable' | 'unpaid' | 'paid_simulated' | 'refunded';
  sourcePayloadJson: string;
  items: PrescriptionItem[];
  patientSummary?: {
    id: string;
    internalId: string;
    fullName: string;
    nhsNumber: string | null;
    nhsNumberVerified: boolean;
    dateOfBirth: string;
    allergyStatus: AllergyRecordStatus;
    allergiesCount: number;
  } | null;
}

export interface HazardLogEntry {
  id: string;
  hazardRef: string;
  category: string;
  hazardTitle: string;
  clinicalRisk: string;
  mitigationInPrototype: string;
  residualStatus: string;
  standardRef: string;
}

export const ROLE_PERMISSIONS: Record<StaffRole, string[]> = {
  pharmacist: [
    'view_all',
    'intake',
    'match_patient',
    'clinical_review',
    'allocate_stock',
    'prepare',
    'accuracy_check',
    'handover',
    'stock_manage',
    'procurement',
    'recall_action',
    'cd_register',
    'services_manage',
    'payments',
    'reports',
    'admin_policy',
  ],
  act: [
    'view_all',
    'intake',
    'match_patient',
    'allocate_stock',
    'prepare',
    'accuracy_check',
    'handover',
    'stock_manage',
    'procurement',
    'services_manage',
    'payments',
    'reports',
  ],
  dispenser: [
    'view_all',
    'intake',
    'match_patient',
    'allocate_stock',
    'prepare',
    'stock_manage',
    'procurement',
    'services_manage',
  ],
  counter: ['view_all', 'handover', 'payments', 'services_manage', 'intake'],
  admin: [
    'view_all',
    'stock_manage',
    'procurement',
    'recall_action',
    'services_manage',
    'payments',
    'reports',
    'admin_policy',
  ],
};
