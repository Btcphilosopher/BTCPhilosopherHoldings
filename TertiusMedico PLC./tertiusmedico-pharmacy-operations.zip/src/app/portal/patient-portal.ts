import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Router, RouterLink} from '@angular/router';
import {PharmacyApi} from '../core/pharmacy-api';
import type {PatientRecord, Prescription} from '../core/pharmacy.types';

type PortalTab = 'prescriptions' | 'requests' | 'appointments' | 'messages' | 'collection' | 'account';

@Component({
  selector: 'app-patient-portal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, RouterLink],
  template: `
    <div class="min-h-screen bg-[#f4f6f8] text-[#0f2440] pb-20 md:pb-8">
      <!-- Compact Sticky Top Bar (<= 56px) -->
      <header class="sticky top-0 z-30 h-14 bg-[#0b3d2e] text-white border-b border-[#06291f] px-4 sm:px-6 flex items-center justify-between gap-4">
        <div class="flex items-center gap-3 min-w-0">
          <span class="font-display font-bold text-base tracking-tight whitespace-nowrap">TERTIUSMEDICO</span>
          <span class="hidden sm:inline text-xs text-emerald-100/80 truncate">
            Pennine Community Pharmacy · Patient Portal
          </span>
        </div>

        <!-- Desktop Tab Bar -->
        <nav aria-label="Patient portal desktop navigation" class="hidden md:flex items-center gap-4 text-xs font-medium">
          @for (t of tabs; track t.id) {
            <button
              type="button"
              (click)="activeTab.set(t.id)"
              class="py-1.5 border-b-2 transition-colors whitespace-nowrap"
              [class]="activeTab() === t.id ? 'border-white text-white font-semibold' : 'border-transparent text-emerald-100/80 hover:text-white'"
            >
              {{ t.label }}
            </button>
          }
        </nav>

        <div class="flex items-center gap-3 shrink-0 text-xs">
          @if (api.isStaff()) {
            <a
              routerLink="/staff/overview"
              class="px-2.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white whitespace-nowrap"
            >
              Staff View
            </a>
          }
          <button
            type="button"
            (click)="signOut()"
            class="min-h-[40px] px-2 text-emerald-100 hover:text-white flex items-center gap-1"
          >
            <mat-icon class="!text-base !w-4 !h-4">logout</mat-icon>
            <span class="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      <main class="max-w-5xl mx-auto px-4 sm:px-6 py-5 space-y-5">
        <!-- Prototype Identification & Staff Preview Switcher -->
        <div class="bg-amber-50 border border-amber-300 rounded-xl p-3.5 text-xs text-amber-950 flex flex-wrap items-center justify-between gap-3">
          <div>
            <strong>Independent Prototype:</strong> Pennine Community Pharmacy synthetic patient portal.
          </div>
          @if (api.isStaff()) {
            <div class="flex items-center gap-2">
              <label for="preview-pat" class="font-semibold">Preview Patient:</label>
              <select
                id="preview-pat"
                [value]="previewPatientId()"
                (change)="switchPreviewPatient($any($event.target).value)"
                class="px-2.5 py-1 border border-amber-300 rounded bg-white text-[#0f2440]"
              >
                <option value="PAT-1001">Arthur Pendelton</option>
                <option value="PAT-1002">Meera Sharma</option>
                <option value="PAT-1003">Declan O'Connor</option>
                <option value="PAT-1004">Eleanor Vance</option>
                <option value="PAT-1005">George Barlow</option>
              </select>
            </div>
          }
        </div>

        @if (feedbackMsg()) {
          <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-950">
            {{ feedbackMsg() }}
          </div>
        }

        @if (patient(); as pat) {
          <!-- Prescriptions Tab -->
          @if (activeTab() === 'prescriptions') {
            <section class="space-y-4">
              <h1 class="font-display text-xl font-bold text-[#0f2440]">Your Prescriptions</h1>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                @for (rx of prescriptions(); track rx.id) {
                  <article class="bg-white border border-[#d9e2ec] rounded-2xl p-4 space-y-3">
                    <div class="flex items-center justify-between gap-2 border-b border-[#e2e8f0] pb-2.5">
                      <div>
                        <div class="font-mono text-xs font-bold text-[#0f2440]">{{ rx.prescriptionId }}</div>
                        <div class="text-xs text-[#486581]">Issued {{ rx.issueDate }}</div>
                      </div>
                      <div
                        class="text-xs font-semibold"
                        [class]="rx.status === 'Partially supplied' ? 'text-amber-800' : rx.status === 'Ready for handover' ? 'text-[#0b3d2e]' : 'text-[#243b53]'"
                      >
                        {{ rx.status }}
                      </div>
                    </div>
                    @for (item of rx.items; track item.id) {
                      <div class="text-xs space-y-1">
                        <div class="font-semibold text-[#0f2440] text-sm">{{ item.prescribedMedicineText }}</div>
                        <div class="text-[#243b53]">{{ item.directionsAmended || item.directionsAsReceived }}</div>
                        <div class="text-[#486581] tabular-nums">
                          Prescribed: {{ item.prescribedQty }} {{ item.unit }} ·
                          Supplied: {{ item.suppliedQty }} ·
                          Outstanding: {{ item.outstandingQty }}
                        </div>
                        @if (item.suppliedQty > 0 && item.outstandingQty > 0) {
                          <div class="bg-amber-50 border border-amber-300 rounded-lg p-2 text-amber-950 mt-1">
                            <strong>Warning:</strong> Partial supply only ({{ item.suppliedQty }} supplied, {{ item.outstandingQty }} {{ item.unit }} remaining to follow).
                          </div>
                        }
                      </div>
                    }
                  </article>
                } @empty {
                  <div class="bg-white border border-[#d9e2ec] rounded-2xl p-6 text-sm text-[#486581]">
                    No prescriptions found on your record.
                  </div>
                }
              </div>
            </section>
          }

          <!-- Repeat Requests Tab -->
          @if (activeTab() === 'requests') {
            <section class="space-y-4">
              <div>
                <h1 class="font-display text-xl font-bold text-[#0f2440]">Repeat Medicine Requests</h1>
                <p class="text-xs text-amber-900 bg-amber-50 border border-amber-300 rounded-xl p-3 mt-2">
                  <strong>Warning:</strong> A repeat request is a request for your GP or pharmacist to review. It is not a prescription or dispensing authorisation.
                </p>
              </div>

              <div class="bg-white border border-[#d9e2ec] rounded-2xl p-4 space-y-3">
                <h2 class="text-sm font-bold text-[#0f2440]">Request a Repeat Medicine</h2>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label for="rep-med" class="block font-semibold text-[#243b53] mb-1">Medicine</label>
                    <select
                      id="rep-med"
                      [value]="reqProductId()"
                      (change)="reqProductId.set($any($event.target).value)"
                      class="w-full px-3 py-2.5 border border-[#bcccdc] rounded-xl bg-white min-h-[44px]"
                    >
                      @for (m of catalogue(); track m['id']) {
                        <option [value]="m['id']">{{ m['prescribed_name'] }}</option>
                      }
                    </select>
                  </div>
                  <div>
                    <label for="rep-note" class="block font-semibold text-[#243b53] mb-1">Note for Pharmacy Team</label>
                    <input
                      id="rep-note"
                      type="text"
                      [value]="reqNote()"
                      (input)="reqNote.set($any($event.target).value)"
                      placeholder="e.g. Running low (5 days left)"
                      class="w-full px-3 py-2.5 border border-[#bcccdc] rounded-xl min-h-[44px]"
                    />
                  </div>
                  <div class="flex items-end">
                    <button
                      type="button"
                      (click)="submitRepeatRequest()"
                      class="w-full min-h-[44px] px-4 bg-[#0b3d2e] text-white font-semibold rounded-xl"
                    >
                      Submit Request
                    </button>
                  </div>
                </div>
              </div>

              <div class="bg-white border border-[#d9e2ec] rounded-2xl divide-y divide-[#e2e8f0] text-xs">
                @for (r of repeatRequests(); track r['id']) {
                  <div class="p-4 flex items-center justify-between gap-3">
                    <div>
                      <div class="font-semibold text-[#0f2440]">{{ r['product_name'] }} (Qty {{ r['requested_qty'] }})</div>
                      <div class="text-[#486581] mt-0.5">{{ r['status'] }}</div>
                    </div>
                    <span class="font-mono text-[#486581]">{{ r['id'] }}</span>
                  </div>
                } @empty {
                  <div class="p-4 text-[#486581]">No repeat requests submitted yet.</div>
                }
              </div>
            </section>
          }

          <!-- Appointments Tab -->
          @if (activeTab() === 'appointments') {
            <section class="space-y-4">
              <h1 class="font-display text-xl font-bold text-[#0f2440]">Pharmacy Service Appointments</h1>
              <div class="bg-white border border-[#d9e2ec] rounded-2xl p-4 space-y-3 text-xs">
                <h2 class="text-sm font-bold text-[#0f2440]">Book a Consultation or Service</h2>
                <p class="text-[#486581]">
                  Clinical eligibility is assessed by our pharmacist at your appointment.
                </p>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <select
                    [value]="aptServiceId()"
                    (change)="aptServiceId.set($any($event.target).value)"
                    aria-label="Choose pharmacy service"
                    class="px-3 py-2.5 border border-[#bcccdc] rounded-xl bg-white min-h-[44px]"
                  >
                    @for (s of services(); track s['id']) {
                      <option [value]="s['id']">{{ s['name'] }} ({{ s['duration_minutes'] }} min)</option>
                    }
                  </select>
                  <button
                    type="button"
                    (click)="bookService()"
                    class="min-h-[44px] px-4 bg-[#0b3d2e] text-white font-semibold rounded-xl"
                  >
                    Request Service Appointment
                  </button>
                </div>
              </div>

              <div class="bg-white border border-[#d9e2ec] rounded-2xl divide-y divide-[#e2e8f0] text-xs">
                @for (a of appointments(); track a['id']) {
                  <div class="p-4 flex items-center justify-between gap-3">
                    <div>
                      <div class="font-semibold text-[#0f2440]">{{ a['service_name'] }}</div>
                      <div class="text-[#486581] mt-0.5">{{ a['scheduled_at'] }} · {{ a['room'] }}</div>
                    </div>
                    <span class="font-semibold text-[#0b3d2e] capitalize">{{ a['status'] }}</span>
                  </div>
                } @empty {
                  <div class="p-4 text-[#486581]">No appointments booked.</div>
                }
              </div>
            </section>
          }

          <!-- Messages Tab -->
          @if (activeTab() === 'messages') {
            <section class="space-y-4">
              <h1 class="font-display text-xl font-bold text-[#0f2440]">Pharmacy Messages</h1>
              <p class="text-xs text-[#486581]">
                SMS/lock-screen notifications omit sensitive medicine details; full details appear only inside this authenticated portal.
              </p>
              <div class="space-y-3">
                @for (m of messages(); track m['id']) {
                  <div class="bg-white border border-[#d9e2ec] rounded-2xl p-4 text-xs space-y-1.5">
                    <div class="flex items-center justify-between text-[#486581]">
                      <span class="uppercase font-mono">{{ m['channel'] }} · {{ m['status'] }}</span>
                      <span class="font-mono">{{ m['created_at'] }}</span>
                    </div>
                    <div class="font-semibold text-[#0f2440]">{{ m['portal_detail'] }}</div>
                    <div class="text-[#486581]">Lock-screen/SMS preview sent: "{{ m['public_summary'] }}"</div>
                  </div>
                } @empty {
                  <div class="bg-white border border-[#d9e2ec] rounded-2xl p-4 text-xs text-[#486581]">
                    No messages yet.
                  </div>
                }
              </div>
            </section>
          }

          <!-- Collection & Delivery Tab -->
          @if (activeTab() === 'collection') {
            <section class="space-y-4">
              <h1 class="font-display text-xl font-bold text-[#0f2440]">Collection &amp; Delivery Options</h1>
              <div class="space-y-3">
                @for (rx of prescriptions(); track rx.id) {
                  <div class="bg-white border border-[#d9e2ec] rounded-2xl p-4 text-xs space-y-2.5">
                    <div class="font-mono font-bold text-[#0f2440]">
                      {{ rx.prescriptionId }} · {{ rx.status }}
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <button
                        type="button"
                        (click)="setCollection(rx.id, 'in_store_counter')"
                        class="min-h-[44px] px-3 rounded-xl border font-medium"
                        [class]="rx.collectionOption === 'in_store_counter' ? 'border-[#0b3d2e] bg-emerald-50 text-[#0b3d2e]' : 'border-[#d9e2ec]'"
                      >
                        In-Store Counter
                      </button>
                      <button
                        type="button"
                        (click)="setCollection(rx.id, 'representative_collection')"
                        class="min-h-[44px] px-3 rounded-xl border font-medium"
                        [class]="rx.collectionOption === 'representative_collection' ? 'border-[#0b3d2e] bg-emerald-50 text-[#0b3d2e]' : 'border-[#d9e2ec]'"
                      >
                        Authorised Representative
                      </button>
                      <button
                        type="button"
                        (click)="setCollection(rx.id, 'local_van_delivery')"
                        class="min-h-[44px] px-3 rounded-xl border font-medium"
                        [class]="rx.collectionOption === 'local_van_delivery' ? 'border-[#0b3d2e] bg-emerald-50 text-[#0b3d2e]' : 'border-[#d9e2ec]'"
                      >
                        Request Local Delivery
                      </button>
                    </div>
                  </div>
                }
              </div>
            </section>
          }

          <!-- Account Tab -->
          @if (activeTab() === 'account') {
            <section class="space-y-4">
              <h1 class="font-display text-xl font-bold text-[#0f2440]">Your Account &amp; Preferences</h1>
              <div class="bg-white border border-[#d9e2ec] rounded-2xl p-4 text-xs space-y-3">
                <div class="font-bold text-sm text-[#0f2440]">{{ pat.fullName }}</div>
                <div class="text-[#486581] font-mono">
                  DOB {{ pat.dateOfBirth }} · NHS {{ pat.nhsNumber || 'Unrecorded' }} · {{ pat.addressLine1 }}, {{ pat.postcode }}
                </div>
                <div class="text-[#243b53]">
                  Recorded Exemption: <span class="font-mono">{{ pat.exemptionStatus }}</span>
                </div>
                <div class="pt-2 border-t border-[#e2e8f0] space-y-2">
                  <label for="pref-comm" class="block font-semibold text-[#243b53]">Communication Preference</label>
                  <select
                    id="pref-comm"
                    [value]="pat.preferredContact"
                    (change)="saveContactPref($any($event.target).value)"
                    class="w-full sm:w-64 px-3 py-2.5 border border-[#bcccdc] rounded-xl bg-white min-h-[44px]"
                  >
                    <option value="sms">SMS Text (Privacy-Redacted)</option>
                    <option value="email">Email Notification</option>
                    <option value="portal">Patient Portal Only</option>
                    <option value="phone">Telephone Call</option>
                  </select>
                </div>
              </div>
            </section>
          }
        }
      </main>

      <!-- Mobile Bottom Thumb-Zone Navigation Bar (<= 64px height, within 15% sticky cap) -->
      <nav
        aria-label="Patient portal mobile navigation"
        class="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 backdrop-blur-md border-t border-[#d9e2ec] grid grid-cols-6 items-center"
      >
        @for (t of tabs; track t.id) {
          <button
            type="button"
            (click)="activeTab.set(t.id)"
            class="h-full min-h-[44px] flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium"
            [class]="activeTab() === t.id ? 'text-[#0b3d2e] font-bold' : 'text-[#486581]'"
          >
            <mat-icon class="!text-[20px] !w-5 !h-5">{{ t.icon }}</mat-icon>
            <span class="truncate max-w-[56px]">{{ t.shortLabel }}</span>
          </button>
        }
      </nav>
    </div>
  `,
})
export class PatientPortal implements OnInit {
  readonly api = inject(PharmacyApi);
  private readonly router = inject(Router);

  readonly activeTab = signal<PortalTab>('prescriptions');
  readonly previewPatientId = signal('PAT-1001');
  readonly patient = signal<PatientRecord | null>(null);
  readonly prescriptions = signal<Prescription[]>([]);
  readonly repeatRequests = signal<Record<string, unknown>[]>([]);
  readonly messages = signal<Record<string, unknown>[]>([]);
  readonly appointments = signal<Record<string, unknown>[]>([]);
  readonly services = signal<Record<string, unknown>[]>([]);
  readonly catalogue = signal<Record<string, unknown>[]>([]);
  readonly feedbackMsg = signal<string | null>(null);

  readonly reqProductId = signal('MED-ATOR-20');
  readonly reqNote = signal('');
  readonly aptServiceId = signal('SVC-BP-CHECK');

  readonly tabs: {id: PortalTab; label: string; shortLabel: string; icon: string}[] = [
    {id: 'prescriptions', label: 'Prescriptions', shortLabel: 'Rx', icon: 'medication'},
    {id: 'requests', label: 'Requests', shortLabel: 'Requests', icon: 'autorenew'},
    {id: 'appointments', label: 'Appointments', shortLabel: 'Book', icon: 'calendar_today'},
    {id: 'messages', label: 'Messages', shortLabel: 'Inbox', icon: 'chat_bubble_outline'},
    {id: 'collection', label: 'Collection', shortLabel: 'Collect', icon: 'local_shipping'},
    {id: 'account', label: 'Account', shortLabel: 'Account', icon: 'person'},
  ];

  async ngOnInit(): Promise<void> {
    await this.loadPortal();
  }

  async loadPortal(): Promise<void> {
    const data = await this.api.getPortalData(
      this.api.isStaff() ? this.previewPatientId() : undefined,
    );
    this.patient.set(data['patient'] as PatientRecord);
    this.prescriptions.set(data['prescriptions'] as Prescription[]);
    this.repeatRequests.set(data['repeatRequests'] as Record<string, unknown>[]);
    this.messages.set(data['messages'] as Record<string, unknown>[]);
    this.appointments.set(data['appointments'] as Record<string, unknown>[]);
    this.services.set(data['services'] as Record<string, unknown>[]);
    this.catalogue.set(data['catalogue'] as Record<string, unknown>[]);
  }

  async switchPreviewPatient(id: string): Promise<void> {
    this.previewPatientId.set(id);
    await this.loadPortal();
  }

  async submitRepeatRequest(): Promise<void> {
    await this.api.submitRepeatRequest({
      patientId: this.patient()?.id,
      productId: this.reqProductId(),
      requestedQty: 28,
      patientNote: this.reqNote(),
    });
    this.reqNote.set('');
    this.feedbackMsg.set('Repeat request submitted for review (not a prescription or dispensing authorisation).');
    await this.loadPortal();
  }

  async setCollection(rxId: string, option: string): Promise<void> {
    await this.api.updatePortalCollectionOption(rxId, option);
    this.feedbackMsg.set(`Updated collection preference for ${rxId}.`);
    await this.loadPortal();
  }

  async bookService(): Promise<void> {
    await this.api.bookAppointment({
      patientId: this.patient()?.id,
      serviceId: this.aptServiceId(),
      consentRecorded: true,
    });
    this.feedbackMsg.set('Service appointment booked.');
    await this.loadPortal();
  }

  async saveContactPref(pref: string): Promise<void> {
    await this.api.updatePortalPreferences(pref);
    this.feedbackMsg.set(`Updated communication preference to ${pref}.`);
    await this.loadPortal();
  }

  async signOut(): Promise<void> {
    await this.api.logout();
    await this.router.navigateByUrl('/sign-in');
  }
}
