import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import {PharmacyApi} from '../core/pharmacy-api';
import type {StaffUser} from '../core/pharmacy.types';

@Component({
  selector: 'app-sign-in',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="min-h-screen bg-[#f4f6f8] flex flex-col justify-between">
      <!-- Top deep-green British healthcare bar -->
      <header class="bg-[#0b3d2e] text-white border-b border-[#06291f]">
        <div class="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <div class="font-display font-bold text-lg tracking-tight whitespace-nowrap shrink-0">
            TERTIUSMEDICO
          </div>
          <div class="hidden sm:flex items-center gap-3 text-xs text-emerald-100/90">
            <span>Pennine Community Pharmacy (Synthetic England Prototype)</span>
            <span aria-hidden="true">·</span>
            <span class="font-mono">ODS FPROTO-PENNINE-01</span>
          </div>
          <div class="text-xs font-medium text-emerald-100 whitespace-nowrap shrink-0">
            Independent Prototype
          </div>
        </div>
      </header>

      <main class="flex-1 max-w-5xl w-full mx-auto px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <!-- Left Context Panel -->
        <section class="lg:col-span-5 space-y-6">
          <div>
            <p class="text-xs font-medium text-[#0b3d2e] tracking-wide mb-2">
              Community Pharmacy Operations &amp; Patient Portal
            </p>
            <h1 class="font-display text-3xl font-bold text-[#0f2440] tracking-tight leading-tight">
              Pennine Community Pharmacy
            </h1>
            <p class="mt-3 text-sm text-[#334e68] leading-relaxed">
              Integrated prototype for prescription intake, patient matching, clinical review,
              transactional stock allocation, accuracy checking, procurement, recalls, and audit
              governance.
            </p>
          </div>

          <div class="bg-amber-50 border border-amber-300 rounded-xl p-4 text-xs text-amber-950 space-y-1.5">
            <div class="flex items-center gap-2 font-semibold">
              <mat-icon class="!text-base !w-4 !h-4 text-amber-700">warning</mat-icon>
              <span>Warning: Independent Synthetic Prototype</span>
            </div>
            <p class="leading-relaxed">
              All patients, NHS numbers, prescriptions, wholesalers, and transactions are synthetic.
              This system is not connected to live NHS Spine EPS, PDS, dm+d TRUD, or NHSBSA
              reimbursement services.
            </p>
          </div>

          <div class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-3">
            <h2 class="text-sm font-semibold text-[#0f2440]">Verified Prototype Controls</h2>
            <ul class="text-xs text-[#334e68] space-y-2 leading-relaxed">
              <li>Separate clinical review, preparation, accuracy checking, and handover roles.</li>
              <li>Transactional stock reservations with FEFO batch &amp; expiry exclusions.</li>
              <li>Immutable source payloads kept separate from staff clinical amendments.</li>
              <li>NHS number is treated strictly as an identifier, never as authentication.</li>
            </ul>
          </div>
        </section>

        <!-- Right Sign-In Card -->
        <section class="lg:col-span-7 bg-white border border-[#d9e2ec] rounded-xl p-6 sm:p-8 shadow-sm">
          <!-- Mode Switcher -->
          <div class="flex items-center gap-1 p-1 bg-[#f4f6f8] rounded-lg mb-6">
            <button
              type="button"
              (click)="setMode('staff')"
              class="flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors whitespace-nowrap flex items-center justify-center gap-2 min-h-[40px]"
              [class]="mode() === 'staff' ? 'bg-white text-[#0f2440] shadow-sm' : 'text-[#486581] hover:text-[#0f2440]'"
            >
              <mat-icon class="!text-lg !w-5 !h-5">local_pharmacy</mat-icon>
              <span>Staff Operations</span>
            </button>
            <button
              type="button"
              (click)="setMode('patient')"
              class="flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors whitespace-nowrap flex items-center justify-center gap-2 min-h-[40px]"
              [class]="mode() === 'patient' ? 'bg-white text-[#0f2440] shadow-sm' : 'text-[#486581] hover:text-[#0f2440]'"
            >
              <mat-icon class="!text-lg !w-5 !h-5">person</mat-icon>
              <span>Patient Portal</span>
            </button>
          </div>

          @if (errorMsg()) {
            <div class="mb-5 bg-red-50 border border-red-300 rounded-lg p-3 text-xs text-red-900 flex items-start gap-2">
              <mat-icon class="!text-base !w-4 !h-4 text-red-700 shrink-0 mt-0.5">error</mat-icon>
              <span><strong>Critical:</strong> {{ errorMsg() }}</span>
            </div>
          }

          @if (mode() === 'staff') {
            <div class="space-y-5">
              <div>
                <h2 class="text-lg font-semibold text-[#0f2440]">Organisational Staff Sign-In</h2>
                <p class="text-xs text-[#486581] mt-1">
                  Select a synthetic Pennine Community Pharmacy staff member to test role-separated workflows.
                </p>
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                @for (member of staffList(); track member.id) {
                  <button
                    type="button"
                    (click)="selectedUsername.set(member.username)"
                    class="text-left p-3 rounded-lg border transition-colors"
                    [class]="selectedUsername() === member.username
                      ? 'border-[#0b3d2e] bg-emerald-50/60'
                      : 'border-[#d9e2ec] hover:bg-[#f4f6f8]'"
                  >
                    <div class="text-sm font-semibold text-[#0f2440]">{{ member.displayName }}</div>
                    <div class="text-xs text-[#486581] mt-0.5 flex items-center gap-1.5">
                      <span class="capitalize font-medium text-[#0b3d2e]">{{ member.role }}</span>
                      @if (member.gphcNumber) {
                        <span aria-hidden="true">·</span>
                        <span class="font-mono">{{ member.gphcNumber }}</span>
                      }
                    </div>
                  </button>
                }
              </div>

              <div>
                <label for="staff-passcode" class="block text-xs font-semibold text-[#243b53] mb-1.5">
                  Organisational Passcode (Synthetic Demo: <span class="font-mono">pennine-demo</span>)
                </label>
                <input
                  id="staff-passcode"
                  type="password"
                  [value]="passcode()"
                  (input)="passcode.set($any($event.target).value)"
                  class="w-full px-3.5 py-2.5 text-sm border border-[#bcccdc] rounded-lg bg-white text-[#0f2440]"
                  placeholder="Enter staff passcode"
                />
              </div>

              <button
                type="button"
                [disabled]="loading() || !selectedUsername()"
                (click)="submitStaffLogin()"
                class="w-full py-2.5 px-5 bg-[#0b3d2e] hover:bg-[#11523f] disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]"
              >
                <mat-icon class="!text-lg !w-5 !h-5">login</mat-icon>
                <span>{{ loading() ? 'Signing in...' : 'Sign In to Staff Workspace' }}</span>
              </button>
            </div>
          } @else {
            <div class="space-y-5">
              <div>
                <h2 class="text-lg font-semibold text-[#0f2440]">Patient Portal Sign-In</h2>
                <p class="text-xs text-[#486581] mt-1">
                  Verify identity using Date of Birth and Portal PIN (NHS number alone is never accepted for login).
                </p>
              </div>

              <div>
                <label for="pat-select" class="block text-xs font-semibold text-[#243b53] mb-1.5">
                  Synthetic Patient Account
                </label>
                <select
                  id="pat-select"
                  [value]="selectedPatientId()"
                  (change)="onPatientSelect($any($event.target).value)"
                  class="w-full px-3.5 py-2.5 text-sm border border-[#bcccdc] rounded-lg bg-white text-[#0f2440]"
                >
                  @for (p of patientList(); track p.id) {
                    <option [value]="p.id">{{ p.fullName }} ({{ p.internalId }} · {{ p.postcode }})</option>
                  }
                </select>
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label for="pat-dob" class="block text-xs font-semibold text-[#243b53] mb-1.5">
                    Date of Birth
                  </label>
                  <input
                    id="pat-dob"
                    type="date"
                    [value]="patientDob()"
                    (input)="patientDob.set($any($event.target).value)"
                    class="w-full px-3.5 py-2.5 text-sm border border-[#bcccdc] rounded-lg bg-white text-[#0f2440] font-mono"
                  />
                </div>
                <div>
                  <label for="pat-pin" class="block text-xs font-semibold text-[#243b53] mb-1.5">
                    4-Digit Portal PIN
                  </label>
                  <input
                    id="pat-pin"
                    type="password"
                    maxlength="4"
                    [value]="patientPin()"
                    (input)="patientPin.set($any($event.target).value)"
                    class="w-full px-3.5 py-2.5 text-sm border border-[#bcccdc] rounded-lg bg-white text-[#0f2440] font-mono"
                    placeholder="e.g. 5821"
                  />
                </div>
              </div>

              <p class="text-xs text-[#486581]">
                Prototype test pins: Arthur Pendelton (<span class="font-mono">1951-04-12 / 5821</span>),
                Meera Sharma (<span class="font-mono">1986-09-23 / 0944</span>),
                Eleanor Vance (<span class="font-mono">1993-02-18 / 3319</span>).
              </p>

              <button
                type="button"
                [disabled]="loading()"
                (click)="submitPatientLogin()"
                class="w-full py-2.5 px-5 bg-[#0b3d2e] hover:bg-[#11523f] disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 min-h-[44px]"
              >
                <mat-icon class="!text-lg !w-5 !h-5">verified_user</mat-icon>
                <span>{{ loading() ? 'Verifying...' : 'Open Patient Portal' }}</span>
              </button>
            </div>
          }
        </section>
      </main>

      <footer class="border-t border-[#d9e2ec] bg-white py-4 px-6 text-xs text-[#486581]">
        <div class="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <span>TERTIUSMEDICO — Pharmacy Operations (Independent Prototype)</span>
          <span>Synthetic UK Community Pharmacy Demonstration · No Live NHS Connectivity</span>
        </div>
      </footer>
    </div>
  `,
})
export class SignInPage implements OnInit {
  private readonly api = inject(PharmacyApi);
  private readonly router = inject(Router);

  readonly mode = signal<'staff' | 'patient'>('staff');
  readonly staffList = signal<StaffUser[]>([]);
  readonly patientList = signal<
    {id: string; internalId: string; fullName: string; dateOfBirth: string; postcode: string}[]
  >([]);

  readonly selectedUsername = signal('h.whitaker');
  readonly passcode = signal('pennine-demo');

  readonly selectedPatientId = signal('PAT-1001');
  readonly patientDob = signal('1951-04-12');
  readonly patientPin = signal('5821');

  readonly loading = signal(false);
  readonly errorMsg = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    try {
      const [s, p] = await Promise.all([
        this.api.getStaffDirectory(),
        this.api.getPatientDirectory(),
      ]);
      this.staffList.set(s.staff);
      this.patientList.set(p.patients);
    } catch {
      this.errorMsg.set('Unable to reach backend directory service.');
    }
  }

  setMode(m: 'staff' | 'patient'): void {
    this.mode.set(m);
    this.errorMsg.set(null);
  }

  onPatientSelect(id: string): void {
    this.selectedPatientId.set(id);
    const match = this.patientList().find((p) => p.id === id);
    if (match) {
      this.patientDob.set(match.dateOfBirth);
      const pinMap: Record<string, string> = {
        'PAT-1001': '5821',
        'PAT-1002': '0944',
        'PAT-1003': '1107',
        'PAT-1004': '3319',
        'PAT-1005': '7740',
      };
      this.patientPin.set(pinMap[id] ?? '');
    }
  }

  async submitStaffLogin(): Promise<void> {
    this.loading.set(true);
    this.errorMsg.set(null);
    try {
      await this.api.loginStaff(this.selectedUsername(), this.passcode());
      await this.router.navigateByUrl('/staff/overview');
    } catch (err: unknown) {
      const msg =
        (err as {error?: {error?: string}})?.error?.error || 'Sign-in failed. Check credentials.';
      this.errorMsg.set(msg);
    } finally {
      this.loading.set(false);
    }
  }

  async submitPatientLogin(): Promise<void> {
    this.loading.set(true);
    this.errorMsg.set(null);
    try {
      await this.api.loginPatient(this.selectedPatientId(), this.patientDob(), this.patientPin());
      await this.router.navigateByUrl('/portal');
    } catch (err: unknown) {
      const msg =
        (err as {error?: {error?: string}})?.error?.error ||
        'Patient verification failed. Check DOB and PIN.';
      this.errorMsg.set(msg);
    } finally {
      this.loading.set(false);
    }
  }
}
