import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PharmacyApi} from '../../core/pharmacy-api';

@Component({
  selector: 'app-deliveries-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#0f2440]">
          Deliveries &amp; Patient Notifications
        </h1>
        <p class="text-sm text-[#486581] mt-0.5">
          Dispatched deliveries are tracked separately from confirmed receipt · Sensitive medicine names omitted from SMS summaries
        </p>
      </div>

      @if (feedbackMsg()) {
        <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-950">
          {{ feedbackMsg() }}
        </div>
      }

      <!-- Deliveries Table -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
        <div class="px-5 py-3.5 border-b border-[#d9e2ec] bg-[#f4f6f8]">
          <h2 class="text-sm font-bold text-[#0f2440]">Local Van Deliveries</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-[#d9e2ec] text-[#243b53] font-semibold">
                <th class="py-3 px-4">Delivery &amp; Rx</th>
                <th class="py-3 px-4">Patient &amp; Address</th>
                <th class="py-3 px-4">Driver &amp; Zone</th>
                <th class="py-3 px-4">Status</th>
                <th class="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#e2e8f0]">
              @for (d of deliveries(); track d['id']) {
                <tr>
                  <td class="py-3 px-4 font-mono">
                    <div class="font-bold text-[#0f2440]">{{ d['id'] }}</div>
                    <div class="text-[#486581]">Rx {{ d['prescription_id'] }}</div>
                  </td>
                  <td class="py-3 px-4">
                    <div class="font-semibold">{{ d['patient_name'] }}</div>
                    <div class="text-[#486581]">{{ d['address_line1'] }}, {{ d['postcode'] }}</div>
                  </td>
                  <td class="py-3 px-4 text-[#486581]">
                    {{ d['driver_name'] }} · {{ d['route_zone'] }}
                  </td>
                  <td class="py-3 px-4">
                    @if (d['status'] === 'confirmed_received') {
                      <span class="text-[#0b3d2e] font-semibold">Confirmed Received</span>
                      <div class="text-[#486581]">{{ d['recipient_checked'] }}</div>
                    } @else {
                      <span class="text-amber-800 font-semibold">Warning: Dispatched (Receipt Pending)</span>
                    }
                  </td>
                  <td class="py-3 px-4 text-right">
                    @if (d['status'] !== 'confirmed_received') {
                      <button
                        type="button"
                        (click)="confirmDelivery(String(d['id']))"
                        class="px-3 py-1.5 bg-[#0b3d2e] text-white font-semibold rounded-lg"
                      >
                        Confirm Recipient Receipt
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Patient Notifications Queue -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
        <div class="px-5 py-3.5 border-b border-[#d9e2ec] bg-[#f4f6f8]">
          <h2 class="text-sm font-bold text-[#0f2440]">
            Patient Notification Queue (Privacy-Redacted Lock-Screen Copy)
          </h2>
        </div>
        <div class="divide-y divide-[#e2e8f0] text-xs">
          @for (n of notifications(); track n['id']) {
            <div class="p-4 flex flex-wrap items-start justify-between gap-4">
              <div class="space-y-1 max-w-2xl">
                <div class="flex items-center gap-2">
                  <span class="font-mono font-bold text-[#0f2440]">{{ n['id'] }}</span>
                  <span aria-hidden="true">·</span>
                  <span class="font-semibold">{{ n['patient_name'] }}</span>
                  <span aria-hidden="true">·</span>
                  <span class="uppercase font-mono text-[#486581]">{{ n['channel'] }}</span>
                  <span aria-hidden="true">·</span>
                  @if (n['status'] === 'failed') {
                    <span class="text-red-800 font-bold">Critical: Failed ({{ n['attempts'] }} attempts)</span>
                  } @else if (n['status'] === 'queued') {
                    <span class="text-amber-800 font-semibold">Queued</span>
                  } @else {
                    <span class="text-[#0b3d2e] font-semibold">Sent</span>
                  }
                </div>
                <div class="text-[#243b53]">
                  <strong>Public/SMS text:</strong> {{ n['public_summary'] }}
                </div>
                @if (n['failure_reason']) {
                  <div class="text-red-800 font-medium">
                    Failure reason: {{ n['failure_reason'] }}
                  </div>
                }
              </div>

              @if (n['status'] === 'failed') {
                <div class="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    (click)="retry(String(n['id']), 'phone')"
                    class="px-3 py-1.5 bg-[#0b3d2e] text-white font-semibold rounded-lg"
                  >
                    Log Manual Phone Call
                  </button>
                  <button
                    type="button"
                    (click)="retry(String(n['id']), 'portal')"
                    class="px-3 py-1.5 border border-[#d9e2ec] rounded-lg font-semibold text-[#0f2440]"
                  >
                    Fallback to Portal
                  </button>
                </div>
              }
            </div>
          }
        </div>
      </section>
    </div>
  `,
})
export class DeliveriesPage implements OnInit {
  private readonly api = inject(PharmacyApi);
  readonly String = String;

  readonly deliveries = signal<Record<string, unknown>[]>([]);
  readonly notifications = signal<Record<string, unknown>[]>([]);
  readonly feedbackMsg = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    await this.loadAll();
  }

  async loadAll(): Promise<void> {
    const [d, n] = await Promise.all([this.api.getDeliveries(), this.api.getNotifications()]);
    this.deliveries.set(d.deliveries);
    this.notifications.set(n.notifications);
  }

  async confirmDelivery(id: string): Promise<void> {
    await this.api.confirmDelivery(id, 'Signed doorstep receipt confirmed by patient');
    this.feedbackMsg.set(`Delivery ${id} marked as confirmed received.`);
    await this.loadAll();
  }

  async retry(id: string, channel: string): Promise<void> {
    await this.api.retryNotification(id, channel);
    this.feedbackMsg.set(`Notification ${id} resolved via ${channel}.`);
    await this.loadAll();
  }
}
