import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {PharmacyApi} from '../../core/pharmacy-api';
import type {ExternalAdapterStatus, OrganisationalPolicy, StaffUser} from '../../core/pharmacy.types';

@Component({
  selector: 'app-admin-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#0f2440]">
          Administration, Role Policy &amp; Adapter Governance
        </h1>
        <p class="text-sm text-[#486581] mt-0.5">
          Configure role-separation policy, simulate Clinical Knowledge Adapter outage, and inspect system capability boundaries
        </p>
      </div>

      @if (feedbackMsg()) {
        <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-950">
          {{ feedbackMsg() }}
        </div>
      }
      @if (errorMsg()) {
        <div class="bg-red-50 border border-red-300 rounded-xl p-3 text-xs text-red-950">
          <strong>Critical:</strong> {{ errorMsg() }}
        </div>
      }

      @if (policy(); as pol) {
        <!-- Organisational Governance Policy -->
        <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-4">
          <h2 class="font-display text-base font-bold text-[#0f2440]">
            Organisational Role-Separation &amp; Safety Configuration
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <label class="flex items-start gap-3 p-3 border border-[#d9e2ec] rounded-lg cursor-pointer">
              <input
                type="checkbox"
                [checked]="pol.requireSeparatePreparerAndChecker"
                (change)="togglePolicy('requireSeparatePreparerAndChecker', $any($event.target).checked)"
                class="mt-0.5"
              />
              <div>
                <div class="font-semibold text-[#0f2440]">Require Separate Preparer &amp; Accuracy Checker</div>
                <div class="text-[#486581] mt-0.5">Blocks staff from accuracy-checking items they personally prepared.</div>
              </div>
            </label>

            <label class="flex items-start gap-3 p-3 border border-[#d9e2ec] rounded-lg cursor-pointer">
              <input
                type="checkbox"
                [checked]="pol.requireSeparateClinicalAndAccuracyChecker"
                (change)="togglePolicy('requireSeparateClinicalAndAccuracyChecker', $any($event.target).checked)"
                class="mt-0.5"
              />
              <div>
                <div class="font-semibold text-[#0f2440]">Require Separate Clinical Reviewer &amp; Accuracy Checker</div>
                <div class="text-[#486581] mt-0.5">Enforces second-person accuracy check even after pharmacist clinical review.</div>
              </div>
            </label>

            <label class="flex items-start gap-3 p-3 border border-[#d9e2ec] rounded-lg cursor-pointer">
              <input
                type="checkbox"
                [checked]="pol.clinicalAdapterAvailable"
                (change)="togglePolicy('clinicalAdapterAvailable', $any($event.target).checked)"
                class="mt-0.5"
              />
              <div>
                <div class="font-semibold text-[#0f2440]">Clinical-Checking Knowledge Adapter Online</div>
                <div class="text-[#486581] mt-0.5">
                  Uncheck to test unavailable-adapter warning banner and fail-safe clinical review behaviour.
                </div>
              </div>
            </label>

            <div class="p-3 border border-[#d9e2ec] rounded-lg bg-[#f4f6f8] text-[#243b53]">
              <div class="font-semibold text-[#0f2440]">Organisation &amp; Jurisdiction</div>
              <div class="mt-0.5">{{ pol.branchName }} · ODS {{ pol.odsCode }} · {{ pol.jurisdiction }}</div>
              <div class="text-[#486581] mt-0.5">dm+d Version: {{ pol.dmdCatalogVersion }}</div>
            </div>
          </div>
        </section>
      }

      <!-- External Adapters Status -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
        <div class="px-5 py-3.5 border-b border-[#d9e2ec] bg-[#f4f6f8]">
          <h2 class="font-display text-sm font-bold text-[#0f2440]">
            Typed External Integration Adapters (Boundary Classification)
          </h2>
        </div>
        <div class="divide-y divide-[#e2e8f0] text-xs">
          @for (ad of adapters(); track ad.id) {
            <div class="p-4 flex flex-wrap items-start justify-between gap-4">
              <div class="space-y-1 max-w-2xl">
                <div class="font-semibold text-[#0f2440]">
                  {{ ad.name }} · <span class="font-mono text-[#0b3d2e]">{{ ad.mode }}</span>
                </div>
                <div class="text-[#486581]">
                  Version: {{ ad.version }} · Source: {{ ad.authoritativeSource }}
                </div>
                <div class="text-[#243b53]">{{ ad.disclaimer }}</div>
              </div>
              <div class="font-mono text-xs font-semibold" [class]="ad.available ? 'text-[#0b3d2e]' : 'text-red-800'">
                {{ ad.available ? 'AVAILABLE' : 'UNAVAILABLE' }}
              </div>
            </div>
          }
        </div>
      </section>

      <!-- Staff Role Directory -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
        <div class="px-5 py-3.5 border-b border-[#d9e2ec] bg-[#f4f6f8]">
          <h2 class="font-display text-sm font-bold text-[#0f2440]">Synthetic Staff &amp; Role Permissions</h2>
        </div>
        <div class="divide-y divide-[#e2e8f0] text-xs">
          @for (u of staff(); track u.id) {
            <div class="px-5 py-3 flex items-center justify-between">
              <div>
                <span class="font-semibold text-[#0f2440]">{{ u.displayName }}</span>
                <span class="font-mono text-[#486581] ml-2">{{ u.username }}</span>
              </div>
              <div class="capitalize font-semibold text-[#0b3d2e]">
                {{ u.role }} {{ u.gphcNumber ? '· ' + u.gphcNumber : '' }}
              </div>
            </div>
          }
        </div>
      </section>
    </div>
  `,
})
export class AdminPage implements OnInit {
  private readonly api = inject(PharmacyApi);

  readonly policy = signal<OrganisationalPolicy | null>(null);
  readonly adapters = signal<ExternalAdapterStatus[]>([]);
  readonly staff = signal<StaffUser[]>([]);
  readonly feedbackMsg = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    await this.loadAll();
  }

  async loadAll(): Promise<void> {
    const res = await this.api.getPolicy();
    this.policy.set(res.policy);
    this.adapters.set(res.adapters as ExternalAdapterStatus[]);
    this.staff.set(res.staff);
  }

  async togglePolicy(field: keyof OrganisationalPolicy, value: boolean): Promise<void> {
    this.errorMsg.set(null);
    this.feedbackMsg.set(null);
    try {
      await this.api.updatePolicy({[field]: value});
      this.feedbackMsg.set('Organisational policy updated and recorded in audit log.');
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Policy update failed');
    }
  }
}
