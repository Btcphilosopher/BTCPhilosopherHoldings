import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PharmacyApi} from '../../core/pharmacy-api';

@Component({
  selector: 'app-orders-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#0f2440]">
          Procurement, Goods Receipt &amp; Batch Recalls
        </h1>
        <p class="text-sm text-[#486581] mt-0.5">
          Fictional wholesaler ordering, partial/damaged goods receipt, MHRA-style recall quarantine, and supply review tasks
        </p>
      </div>

      @if (feedbackMsg()) {
        <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-950 flex items-center justify-between">
          <span>{{ feedbackMsg() }}</span>
          <button type="button" (click)="feedbackMsg.set(null)" class="underline font-semibold">Dismiss</button>
        </div>
      }

      @if (errorMsg()) {
        <div class="bg-red-50 border border-red-300 rounded-xl p-3 text-xs text-red-950 flex items-center justify-between">
          <span><strong>Critical:</strong> {{ errorMsg() }}</span>
          <button type="button" (click)="errorMsg.set(null)" class="underline font-semibold">Dismiss</button>
        </div>
      }

      <!-- Procurement Orders -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-4 border-b border-[#d9e2ec] pb-3">
          <h2 class="font-display text-base font-bold text-[#0f2440]">Wholesaler Purchase Orders</h2>
          <div class="flex items-center gap-2 text-xs">
            <select
              [value]="newOrderProductId()"
              (change)="newOrderProductId.set($any($event.target).value)"
              class="px-3 py-1.5 border border-[#bcccdc] rounded-lg bg-white"
            >
              @for (p of products(); track p['id']) {
                <option [value]="p['id']">{{ p['dispensable_product_name'] }}</option>
              }
            </select>
            <button
              type="button"
              (click)="createProposal()"
              class="px-3.5 py-1.5 bg-[#0b3d2e] text-white font-semibold rounded-lg whitespace-nowrap"
            >
              Create Reorder Proposal (2 Packs)
            </button>
          </div>
        </div>

        <div class="divide-y divide-[#e2e8f0] text-xs">
          @for (po of orders(); track po['id']) {
            <div class="py-4 space-y-3">
              <div class="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div class="font-mono font-bold text-[#0f2440]">
                    {{ po['order_number'] }} · {{ po['supplier_name'] }}
                  </div>
                  <div class="text-[#486581] mt-0.5">
                    Status: <strong>{{ po['status'] }}</strong> · Total: £{{ (Number(po['total_pence']) / 100).toFixed(2) }}
                    · Created by {{ po['created_by'] }}
                  </div>
                  <div class="text-[#486581] mt-0.5">{{ po['notes'] }}</div>
                </div>
                <div class="flex items-center gap-2">
                  @if (po['status'] === 'Reorder proposal') {
                    <button
                      type="button"
                      (click)="approvePo(String(po['id']))"
                      class="px-3 py-1.5 bg-[#0b3d2e] text-white font-semibold rounded-lg"
                    >
                      Approve &amp; Transmit Order
                    </button>
                  }
                  @if (po['status'] === 'Acknowledged' || po['status'] === 'Partially received') {
                    <button
                      type="button"
                      (click)="receivePo(po, 2, 0)"
                      class="px-3 py-1.5 bg-[#0b3d2e] text-white font-semibold rounded-lg"
                    >
                      Receive Good Packs (Full)
                    </button>
                    <button
                      type="button"
                      (click)="receivePo(po, 1, 1)"
                      class="px-3 py-1.5 border border-amber-300 bg-amber-50 text-amber-950 font-semibold rounded-lg"
                    >
                      Receive 1 Good + 1 Damaged (Quarantine)
                    </button>
                  }
                </div>
              </div>
            </div>
          }
        </div>
      </section>

      <!-- Batch Recalls -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-4 border-b border-[#d9e2ec] pb-3">
          <div>
            <h2 class="font-display text-base font-bold text-[#0f2440]">
              Medicines Recalls &amp; Patient Supply Reviews
            </h2>
            <p class="text-xs text-[#486581] mt-0.5">
              Unreviewed recall imports quarantine stock and create review tasks — never auto-issue clinical advice to patients.
            </p>
          </div>
          <button
            type="button"
            (click)="triggerDemoRecall()"
            class="px-3.5 py-2 bg-red-700 hover:bg-red-800 text-white text-xs font-semibold rounded-lg whitespace-nowrap"
          >
            Import MHRA Class 2 Demo Recall (BATCH-AMX-REC)
          </button>
        </div>

        @for (rec of recalls(); track rec['id']) {
          <div class="border border-red-300 bg-red-50/50 rounded-lg p-4 space-y-3 text-xs">
            <div class="flex flex-wrap items-center justify-between gap-2">
              <div class="font-bold text-red-950">
                Critical: {{ rec['recall_ref'] }} · {{ rec['classification'] }} · Batch {{ rec['affected_batch_number'] }}
              </div>
              <span class="font-mono text-red-900">Quarantined: {{ rec['quarantined_qty'] }} units</span>
            </div>
            <div class="text-[#243b53]">{{ rec['reason'] }} ({{ rec['source'] }})</div>
            <div class="space-y-2 pt-2 border-t border-red-200">
              <div class="font-semibold text-[#0f2440]">Affected Supplied Patients Requiring Pharmacist Review:</div>
              @for (pat of parseJson(rec['affected_patients_json']); track pat['patientId']) {
                <div class="flex flex-wrap items-center justify-between gap-2 bg-white border border-[#d9e2ec] rounded p-2.5">
                  <div>
                    <span class="font-semibold text-[#0f2440]">{{ pat['fullName'] }}</span>
                    <span class="font-mono text-[#486581] ml-2">Rx {{ pat['prescriptionId'] }}</span>
                    <div class="text-[#486581] mt-0.5">{{ pat['reviewStatus'] }}</div>
                  </div>
                  <button
                    type="button"
                    (click)="signOffRecallPatient(String(rec['id']), String(pat['patientId']))"
                    class="px-3 py-1 bg-[#0b3d2e] text-white font-semibold rounded"
                  >
                    Record Pharmacist Review
                  </button>
                </div>
              }
            </div>
          </div>
        } @empty {
          <div class="text-xs text-[#486581] py-4">
            No active recalls imported yet. Click "Import MHRA Class 2 Demo Recall" to test batch quarantine and patient review task creation.
          </div>
        }
      </section>
    </div>
  `,
})
export class OrdersPage implements OnInit {
  private readonly api = inject(PharmacyApi);
  readonly Number = Number;
  readonly String = String;

  readonly orders = signal<Record<string, unknown>[]>([]);
  readonly recalls = signal<Record<string, unknown>[]>([]);
  readonly products = signal<Record<string, unknown>[]>([]);
  readonly newOrderProductId = signal('MED-ATOR-20');
  readonly feedbackMsg = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    await this.loadAll();
  }

  async loadAll(): Promise<void> {
    const [ordRes, catRes] = await Promise.all([
      this.api.getOrdersAndRecalls(),
      this.api.getCatalogue(),
    ]);
    this.orders.set(ordRes.orders);
    this.recalls.set(ordRes.recalls);
    this.products.set(catRes.products);
  }

  parseJson(raw: unknown): Record<string, unknown>[] {
    try {
      return JSON.parse(String(raw)) as Record<string, unknown>[];
    } catch {
      return [];
    }
  }

  async createProposal(): Promise<void> {
    this.errorMsg.set(null);
    await this.api.createOrder({
      supplierName: 'Pennine Pharma Wholesale Ltd',
      productId: this.newOrderProductId(),
      orderedPacks: 2,
      notes: 'Replenishment reorder proposal',
    });
    this.feedbackMsg.set('Created reorder proposal pending approval.');
    await this.loadAll();
  }

  async approvePo(id: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.approveOrder(id);
      this.feedbackMsg.set(`Order ${id} approved and acknowledged by simulated wholesaler.`);
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Approve failed');
    }
  }

  async receivePo(po: Record<string, unknown>, goodPacks: number, damagedPacks: number): Promise<void> {
    this.errorMsg.set(null);
    try {
      const lines = this.parseJson(po['lines_json']);
      const firstLine = lines[0];
      if (!firstLine) return;
      await this.api.receiveOrderGoods(String(po['id']), {
        productId: String(firstLine['productId']),
        receivedGoodPacks: goodPacks,
        damagedPacks,
        batchNumber: `RCV-${Date.now().toString().slice(-4)}`,
        expiryDate: '2028-06-30',
      });
      this.feedbackMsg.set(
        `Received ${goodPacks} good pack(s) and quarantined ${damagedPacks} damaged pack(s).`,
      );
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Receipt failed');
    }
  }

  async triggerDemoRecall(): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.createRecall({
        recallRef: 'MHRA-EL(26)A/14-DEMO',
        source: 'MHRA Drug Alert Prototype Feed',
        classification: 'Class 2 Medicines Recall',
        productId: 'MED-AMOX-500',
        affectedBatchNumber: 'BATCH-AMX-REC',
        reason: 'Out-of-specification dissolution profile in stability testing (Synthetic Demo)',
      });
      this.feedbackMsg.set('Recall imported: batch BATCH-AMX-REC quarantined and patient review tasks created.');
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Recall failed');
    }
  }

  async signOffRecallPatient(recallId: string, patientId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.reviewRecallPatient(
        recallId,
        patientId,
        'Pharmacist telephoned patient to arrange replacement supply from unaffected batch.',
      );
      this.feedbackMsg.set('Pharmacist recall review recorded.');
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Review failed');
    }
  }
}
