import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PharmacyApi} from '../../core/pharmacy-api';
import type {StockBatch} from '../../core/pharmacy.types';

@Component({
  selector: 'app-stock-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#0f2440]">
          Stock, Batch Expiry, Controlled Drugs &amp; Cold Chain
        </h1>
        <p class="text-sm text-[#486581] mt-0.5">
          Physical vs reserved stock separation · Expired, quarantined, and recalled batches excluded from FEFO allocation
        </p>
      </div>

      @if (feedbackMsg()) {
        <div class="bg-amber-50 border border-amber-300 rounded-xl p-3 text-xs text-amber-950 flex items-center justify-between">
          <span>{{ feedbackMsg() }}</span>
          <button type="button" (click)="feedbackMsg.set(null)" class="underline font-semibold">Dismiss</button>
        </div>
      }

      <!-- Segmented Section Switcher -->
      <div class="inline-flex items-center gap-1 p-1 bg-white border border-[#d9e2ec] rounded-lg">
        <button
          type="button"
          (click)="activeTab.set('batches')"
          class="px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors"
          [class]="activeTab() === 'batches' ? 'bg-[#0b3d2e] text-white' : 'text-[#486581] hover:text-[#0f2440]'"
        >
          Inventory Batches
        </button>
        <button
          type="button"
          (click)="activeTab.set('cd')"
          class="px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors"
          [class]="activeTab() === 'cd' ? 'bg-[#0b3d2e] text-white' : 'text-[#486581] hover:text-[#0f2440]'"
        >
          CD2 Demonstration Register
        </button>
        <button
          type="button"
          (click)="activeTab.set('cold')"
          class="px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors"
          [class]="activeTab() === 'cold' ? 'bg-[#0b3d2e] text-white' : 'text-[#486581] hover:text-[#0f2440]'"
        >
          Cold Chain (2–8°C)
        </button>
      </div>

      @if (activeTab() === 'batches') {
        <div class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
              <thead>
                <tr class="border-b border-[#d9e2ec] bg-[#f4f6f8] font-semibold text-[#243b53]">
                  <th class="py-3 px-4">Product &amp; Location</th>
                  <th class="py-3 px-4">Batch &amp; Expiry</th>
                  <th class="py-3 px-4 text-right">Physical</th>
                  <th class="py-3 px-4 text-right">Reserved</th>
                  <th class="py-3 px-4 text-right">Available</th>
                  <th class="py-3 px-4">State</th>
                  <th class="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#e2e8f0]">
                @for (b of batches(); track b.id) {
                  <tr class="hover:bg-[#f8fafc]">
                    <td class="py-3 px-4">
                      <div class="font-semibold text-[#0f2440]">{{ b.productName }}</div>
                      <div class="text-[#486581] font-mono">
                        {{ b.location }} · EAN {{ b.barcodeEan13 }}
                      </div>
                    </td>
                    <td class="py-3 px-4 font-mono">
                      <div class="font-semibold text-[#0f2440]">{{ b.batchNumber }}</div>
                      <div class="text-[#486581]">Exp {{ b.expiryDate }}</div>
                    </td>
                    <td class="py-3 px-4 text-right font-mono tabular-nums">
                      {{ b.physicalQty }} {{ b.unit }}
                    </td>
                    <td class="py-3 px-4 text-right font-mono tabular-nums text-[#486581]">
                      {{ b.reservedQty }} {{ b.unit }}
                    </td>
                    <td class="py-3 px-4 text-right font-mono tabular-nums font-bold text-[#0f2440]">
                      {{ b.availableQty }} {{ b.unit }}
                    </td>
                    <td class="py-3 px-4">
                      @if (b.state === 'recalled' || b.state === 'expired') {
                        <span class="text-red-800 font-semibold">Critical: {{ b.state }}</span>
                      } @else if (b.state === 'quarantined') {
                        <span class="text-amber-800 font-semibold">Warning: {{ b.state }}</span>
                      } @else {
                        <span class="text-[#0b3d2e] font-semibold">{{ b.state }}</span>
                      }
                      @if (b.quarantineReason) {
                        <div class="text-[#486581] mt-0.5 max-w-[200px]">{{ b.quarantineReason }}</div>
                      }
                    </td>
                    <td class="py-3 px-4 text-right space-x-2 whitespace-nowrap">
                      @if (b.state === 'available') {
                        <button
                          type="button"
                          (click)="quarantine(b.id)"
                          class="px-2.5 py-1 border border-amber-300 bg-amber-50 text-amber-950 rounded font-medium"
                        >
                          Quarantine
                        </button>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      @if (activeTab() === 'cd') {
        <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-4">
          <div class="bg-amber-50 border border-amber-300 rounded-lg p-3 text-xs text-amber-950">
            <strong>Warning:</strong> {{ cdDisclaimer() }}
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
              <thead>
                <tr class="border-b border-[#d9e2ec] bg-[#f4f6f8] font-semibold text-[#243b53]">
                  <th class="py-2.5 px-3">#</th>
                  <th class="py-2.5 px-3">Date / Time</th>
                  <th class="py-2.5 px-3">Product &amp; Batch</th>
                  <th class="py-2.5 px-3">Patient / Supplier</th>
                  <th class="py-2.5 px-3 text-right">In</th>
                  <th class="py-2.5 px-3 text-right">Out</th>
                  <th class="py-2.5 px-3 text-right">Balance</th>
                  <th class="py-2.5 px-3">Recorded By</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#e2e8f0]">
                @for (e of cdEntries(); track e['id']) {
                  <tr>
                    <td class="py-2.5 px-3 font-mono">{{ e['entry_number'] }}</td>
                    <td class="py-2.5 px-3 font-mono text-[#486581]">{{ e['created_at'] }}</td>
                    <td class="py-2.5 px-3">
                      <div class="font-semibold text-[#0f2440]">{{ e['product_name'] }}</div>
                      <div class="font-mono text-[#486581]">Batch {{ e['batch_number'] }} · {{ e['entry_type'] }}</div>
                    </td>
                    <td class="py-2.5 px-3">
                      {{ e['patient_or_supplier'] }}
                      @if (e['correction_reason']) {
                        <div class="text-amber-800">Correction: {{ e['correction_reason'] }}</div>
                      }
                    </td>
                    <td class="py-2.5 px-3 text-right font-mono tabular-nums">{{ e['qty_received'] }}</td>
                    <td class="py-2.5 px-3 text-right font-mono tabular-nums">{{ e['qty_supplied'] }}</td>
                    <td class="py-2.5 px-3 text-right font-mono tabular-nums font-bold">
                      {{ e['running_balance'] }} {{ e['unit'] }}
                    </td>
                    <td class="py-2.5 px-3">{{ e['actor_name'] }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <div class="border-t border-[#d9e2ec] pt-4 flex flex-wrap items-end gap-3 text-xs">
            <div>
              <label for="cd-delta" class="block font-semibold text-[#243b53] mb-1">Append-only Reconciliation Delta (mL)</label>
              <input
                id="cd-delta"
                type="number"
                [value]="cdDelta()"
                (input)="cdDelta.set(+$any($event.target).value)"
                class="px-3 py-2 border border-[#bcccdc] rounded-lg font-mono w-36"
              />
            </div>
            <div class="flex-1 min-w-[200px]">
              <label for="cd-reason" class="block font-semibold text-[#243b53] mb-1">Discrepancy / Correction Reason</label>
              <input
                id="cd-reason"
                type="text"
                [value]="cdReason()"
                (input)="cdReason.set($any($event.target).value)"
                class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg"
              />
            </div>
            <button
              type="button"
              (click)="submitCdCorrection()"
              class="px-4 py-2 bg-[#0b3d2e] text-white font-semibold rounded-lg"
            >
              Record Append-Only Correction
            </button>
          </div>
        </section>
      }

      @if (activeTab() === 'cold') {
        <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-4">
          <div class="flex flex-wrap items-end gap-3 border-b border-[#d9e2ec] pb-4 text-xs">
            <div>
              <label for="fridge-temp" class="block font-semibold text-[#243b53] mb-1">
                Log Cold Chain Fridge 1 Temperature (°C · Approved 2.0–8.0°C)
              </label>
              <input
                id="fridge-temp"
                type="number"
                step="0.1"
                [value]="tempInput()"
                (input)="tempInput.set(+$any($event.target).value)"
                class="px-3 py-2 border border-[#bcccdc] rounded-lg font-mono w-44"
              />
            </div>
            <button
              type="button"
              (click)="recordTemperature()"
              class="px-4 py-2 bg-[#0b3d2e] text-white font-semibold rounded-lg"
            >
              Record Observation
            </button>
            <button
              type="button"
              (click)="tempInput.set(11.4); recordTemperature()"
              class="px-3 py-2 border border-amber-300 bg-amber-50 text-amber-950 font-semibold rounded-lg"
            >
              Simulate 11.4°C Excursion
            </button>
          </div>

          <div class="divide-y divide-[#e2e8f0] text-xs">
            @for (log of coldLogs(); track log['id']) {
              <div class="py-3 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div class="font-semibold text-[#0f2440]">
                    {{ log['location'] }} ·
                    <span class="font-mono tabular-nums">{{ log['temperature_c'] }}°C</span>
                    @if (log['excursion_detected'] === 1) {
                      <span class="text-red-800 ml-2">Critical: Excursion Detected</span>
                    }
                  </div>
                  <div class="text-[#486581] mt-0.5">{{ log['action_taken'] }}</div>
                </div>
                <div class="text-[#486581] font-mono">
                  {{ log['recorded_by'] }} · {{ log['recorded_at'] }}
                </div>
              </div>
            }
          </div>
        </section>
      }
    </div>
  `,
})
export class StockPage implements OnInit {
  private readonly api = inject(PharmacyApi);

  readonly activeTab = signal<'batches' | 'cd' | 'cold'>('batches');
  readonly batches = signal<StockBatch[]>([]);
  readonly cdEntries = signal<Record<string, unknown>[]>([]);
  readonly cdDisclaimer = signal('');
  readonly coldLogs = signal<Record<string, unknown>[]>([]);
  readonly feedbackMsg = signal<string | null>(null);

  readonly cdDelta = signal(0);
  readonly cdReason = signal('Routine weekly balance verification');
  readonly tempInput = signal(4.5);

  async ngOnInit(): Promise<void> {
    await this.loadAll();
  }

  async loadAll(): Promise<void> {
    const [stock, cd, cold] = await Promise.all([
      this.api.getStock(),
      this.api.getCdRegister(),
      this.api.getColdChain(),
    ]);
    this.batches.set(stock.batches);
    this.cdEntries.set(cd.entries);
    this.cdDisclaimer.set(cd.disclaimer);
    this.coldLogs.set(cold.logs);
  }

  async quarantine(batchId: string): Promise<void> {
    const res = await this.api.quarantineBatch(batchId, 'Quarantined via Stock Inspector');
    this.batches.set(res.batches);
    this.feedbackMsg.set('Batch quarantined and excluded from dispensing allocation.');
  }

  async submitCdCorrection(): Promise<void> {
    if (this.cdDelta() === 0) return;
    await this.api.postCdCorrection({
      productId: 'MED-MORP-10',
      qtyDelta: this.cdDelta(),
      reason: this.cdReason(),
    });
    this.feedbackMsg.set('Append-only CD register correction entry recorded.');
    await this.loadAll();
  }

  async recordTemperature(): Promise<void> {
    const res = await this.api.logTemperature({temperatureC: this.tempInput()});
    this.coldLogs.set(res.logs);
    if (res.excursion) {
      this.feedbackMsg.set(
        'Warning: Cold-chain excursion detected! Fridge 1 stock has been automatically quarantined pending stability review.',
      );
      await this.loadAll();
    } else {
      this.feedbackMsg.set(`Recorded ${this.tempInput()}°C within 2.0–8.0°C range.`);
    }
  }
}
