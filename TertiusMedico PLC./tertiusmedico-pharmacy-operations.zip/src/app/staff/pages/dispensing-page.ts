import {ChangeDetectionStrategy, Component, computed, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PharmacyApi} from '../../core/pharmacy-api';
import type {
  ClinicalKnowledgePreview,
  OrganisationalPolicy,
  PatientRecord,
  Prescription,
  PrescriptionItem,
  StockBatch,
} from '../../core/pharmacy.types';

@Component({
  selector: 'app-dispensing-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-[#0f2440]">
            Clinical Review &amp; Dispensing Workspace
          </h1>
          <p class="text-sm text-[#486581] mt-0.5">
            Locked patient context · Separate clinical check, stock allocation, preparation, checking, and handover
          </p>
        </div>

        <div class="flex items-center gap-2">
          <label for="rx-selector" class="text-xs font-semibold text-[#243b53]">Switch Locked Rx:</label>
          <select
            id="rx-selector"
            [value]="selectedRxId() || ''"
            (change)="selectPrescription($any($event.target).value)"
            class="px-3 py-2 text-xs border border-[#d9e2ec] rounded-lg bg-white font-mono"
          >
            @for (rx of prescriptions(); track rx.id) {
              <option [value]="rx.id">
                {{ rx.prescriptionId }} · {{ rx.patientSummary?.fullName || 'UNMATCHED' }} ({{ rx.status }})
              </option>
            }
          </select>
        </div>
      </div>

      @if (feedbackMsg()) {
        <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-950 flex items-center justify-between">
          <span>{{ feedbackMsg() }}</span>
          <button type="button" (click)="feedbackMsg.set(null)" class="underline font-semibold">Dismiss</button>
        </div>
      }

      @if (errorMsg()) {
        <div class="bg-red-50 border border-red-300 rounded-xl p-3 text-xs text-red-950 flex items-center justify-between">
          <span><strong>Critical:</strong> {{ errorMsg() }}</span>
          <button type="button" (click)="errorMsg.set(null)" class="underline font-semibold">Dismiss</button>
        </div>
      }

      @if (selectedRx(); as rx) {
        <!-- Persistent Locked Patient & Prescription Identification Banner -->
        <section
          aria-label="Locked patient and prescription identification"
          class="bg-[#0f2440] text-white rounded-xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4"
        >
          <div class="space-y-1">
            <div class="text-xs text-emerald-200 font-medium flex items-center gap-2">
              <mat-icon class="!text-sm !w-4 !h-4">lock</mat-icon>
              <span>Persistent Patient Context Locked · {{ rx.prescriptionId }} ({{ rx.status }})</span>
            </div>
            @if (selectedPatient(); as pat) {
              <div class="font-display text-lg font-bold">
                {{ pat.fullName }}
                <span class="font-mono text-sm font-normal text-slate-200 ml-2">
                  DOB {{ pat.dateOfBirth }} · {{ pat.internalId }} · NHS {{ pat.nhsNumber || 'None' }}
                  ({{ pat.nhsNumberVerified ? 'Verified' : 'Unverified' }})
                </span>
              </div>
              <div class="text-xs text-slate-200 flex flex-wrap items-center gap-3 pt-1">
                <span>{{ pat.addressLine1 }}, {{ pat.postcode }}</span>
                <span aria-hidden="true">·</span>
                <span>Exemption: {{ rx.exemptionOrChargeStatus }}</span>
                @if (pat.accessibilityNeeds.length > 0) {
                  <span aria-hidden="true">·</span>
                  <span class="text-amber-200 font-semibold">
                    Accessibility: {{ pat.accessibilityNeeds.join(', ') }}
                  </span>
                }
              </div>
            } @else {
              <div class="text-amber-200 font-semibold text-sm">
                Warning: Patient unmatched ({{ rx.patientReference }}). Match patient in Prescriptions Queue before clinical review.
              </div>
            }
          </div>

          @if (selectedPatient(); as pat) {
            <div class="text-xs">
              @if (pat.allergyStatus === 'recorded') {
                <div class="bg-red-900/80 border border-red-400 rounded-lg px-3 py-2 text-red-50">
                  <div class="font-bold">Critical: Recorded Allergies</div>
                  @for (alg of pat.allergies; track alg.id) {
                    <div>{{ alg.substance }} — {{ alg.reaction }} ({{ alg.severity }})</div>
                  }
                </div>
              } @else if (pat.allergyStatus === 'unavailable') {
                <div class="bg-amber-900/80 border border-amber-400 rounded-lg px-3 py-2 text-amber-50">
                  <div class="font-bold">Warning: Allergy Information Unavailable</div>
                  <div>Not confirmed as "No Known Allergies"</div>
                </div>
              } @else {
                <div class="bg-emerald-900/60 border border-emerald-400/50 rounded-lg px-3 py-2 text-emerald-50">
                  No Known Allergies (Verified)
                </div>
              }
            </div>
          }
        </section>

        <!-- Items Workflow -->
        @for (item of rx.items; track item.id) {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <!-- Left Column: Item Details, Provenance & Step Controls -->
            <div class="lg:col-span-7 bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-5">
              <div class="flex flex-wrap items-start justify-between gap-3 border-b border-[#d9e2ec] pb-4">
                <div>
                  <div class="text-xs text-[#486581]">
                    Prescribed: {{ item.prescribedMedicineText }} · {{ item.legalCategory }}
                  </div>
                  <h2 class="font-display text-lg font-bold text-[#0f2440] mt-0.5">
                    {{ item.selectedProductName }}
                  </h2>
                  <div class="text-xs text-[#243b53] mt-1">
                    <strong>Directions as received:</strong> "{{ item.directionsAsReceived }}"
                  </div>
                  @if (item.directionsAmended) {
                    <div class="text-xs text-amber-900 mt-1">
                      <strong>Amended Directions:</strong> "{{ item.directionsAmended }}" ({{ item.amendmentReason }})
                    </div>
                  }
                </div>
                <div class="text-right text-xs tabular-nums">
                  <div class="font-bold text-[#0f2440]">{{ item.status }}</div>
                  <div class="text-[#486581] mt-1">
                    Prescribed {{ item.prescribedQty }} {{ item.unit }}
                  </div>
                  <div class="text-[#486581]">
                    Supplied {{ item.suppliedQty }} · Outstanding {{ item.outstandingQty }}
                  </div>
                </div>
              </div>

              <!-- Step A: Pharmacist Clinical Review -->
              <div class="space-y-3 border-b border-[#d9e2ec] pb-5">
                <div class="flex items-center justify-between">
                  <h3 class="text-sm font-bold text-[#0f2440]">1. Pharmacist Clinical Review</h3>
                  <span class="text-xs font-mono text-[#486581]">
                    Decision: {{ item.clinicalDecision }}
                    @if (item.clinicalReviewedBy) {
                      · {{ item.clinicalReviewedBy }}
                    }
                  </span>
                </div>

                @if (clinicalPreview(); as cp) {
                  <div
                    class="rounded-lg p-3 text-xs border space-y-1.5"
                    [class]="cp.available ? 'bg-[#f4f6f8] border-[#d9e2ec] text-[#0f2440]' : 'bg-red-50 border-red-300 text-red-950'"
                  >
                    <div class="font-semibold flex items-center justify-between">
                      <span>{{ cp.adapterName }} ({{ cp.adapterVersion }})</span>
                      <span>{{ cp.available ? 'AVAILABLE' : 'UNAVAILABLE' }}</span>
                    </div>
                    <div class="text-[#486581]">Coverage: {{ cp.coverage }}</div>
                    @for (al of cp.alerts; track al.message) {
                      <div
                        class="p-2 rounded border mt-1"
                        [class]="al.severity === 'critical' ? 'bg-red-100 border-red-300 text-red-950' : 'bg-amber-50 border-amber-300 text-amber-950'"
                      >
                        <strong>{{ al.severity === 'critical' ? 'Critical:' : 'Warning:' }}</strong>
                        {{ al.message }}
                      </div>
                    }
                    <div class="italic text-[#486581]">{{ cp.safetyStatement }}</div>
                  </div>
                }

                @if (item.clinicalDecision === 'pending' || item.clinicalDecision === 'query') {
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label for="clin-notes" class="block font-semibold text-[#243b53] mb-1">Clinical Review Notes</label>
                      <input
                        id="clin-notes"
                        type="text"
                        [value]="clinicalNotes()"
                        (input)="clinicalNotes.set($any($event.target).value)"
                        class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg"
                      />
                    </div>
                    <div>
                      <label for="clin-amend" class="block font-semibold text-[#243b53] mb-1">Optional Amended Label Directions</label>
                      <input
                        id="clin-amend"
                        type="text"
                        [value]="amendedDirections()"
                        (input)="amendedDirections.set($any($event.target).value)"
                        placeholder="Leave blank to keep original"
                        class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg"
                      />
                    </div>
                  </div>
                  <div class="flex flex-wrap gap-2">
                    <button
                      type="button"
                      (click)="submitClinical(item.id, 'approved')"
                      class="px-3.5 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg"
                    >
                      Approve Clinically (Pharmacist)
                    </button>
                    <button
                      type="button"
                      (click)="submitClinical(item.id, 'query')"
                      class="px-3.5 py-2 text-xs font-semibold border border-amber-300 bg-amber-50 text-amber-950 rounded-lg"
                    >
                      Raise Clarification Query
                    </button>
                  </div>
                }
              </div>

              <!-- Step B: Stock Allocation & Preparation + Barcode Scan -->
              <div class="space-y-3 border-b border-[#d9e2ec] pb-5">
                <div class="flex items-center justify-between">
                  <h3 class="text-sm font-bold text-[#0f2440]">
                    2. Transactional Stock Allocation &amp; Preparation
                  </h3>
                  <span class="text-xs font-mono text-[#486581]">
                    Available Stock: {{ availableStockForProduct(item.productId) }} {{ item.unit }}
                  </span>
                </div>

                @if (['Ready for preparation', 'Awaiting stock', 'Partially supplied'].includes(item.status)) {
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label for="prep-qty" class="block font-semibold text-[#243b53] mb-1">
                        Quantity to Prepare (Partial Allowed)
                      </label>
                      <input
                        id="prep-qty"
                        type="number"
                        min="1"
                        [max]="item.outstandingQty"
                        [value]="qtyToPrepare()"
                        (input)="qtyToPrepare.set(+$any($event.target).value)"
                        class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg font-mono"
                      />
                    </div>
                    <div>
                      <label for="barcode-input" class="block font-semibold text-[#243b53] mb-1">
                        Barcode Scan (EAN-13)
                      </label>
                      <div class="flex gap-1.5">
                        <input
                          id="barcode-input"
                          type="text"
                          [value]="barcodeInput()"
                          (input)="barcodeInput.set($any($event.target).value)"
                          placeholder="Scan pack EAN-13..."
                          class="flex-1 px-3 py-2 border border-[#bcccdc] rounded-lg font-mono"
                        />
                        <button
                          type="button"
                          (click)="simulateScan(item.productId)"
                          class="px-2.5 py-2 border border-[#d9e2ec] bg-[#f4f6f8] hover:bg-slate-200 rounded-lg font-medium whitespace-nowrap"
                        >
                          Simulate Scan
                        </button>
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    (click)="submitPrepare(item)"
                    class="px-4 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg inline-flex items-center gap-1.5"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">qr_code_scanner</mat-icon>
                    <span>Allocate FEFO Batch, Verify Barcode &amp; Generate Label</span>
                  </button>
                } @else if (item.preparedBy) {
                  <div class="text-xs text-[#486581]">
                    Prepared by {{ item.preparedBy }} · Batch {{ item.allocatedBatchNumber || 'Handed over' }}
                    · Barcode {{ item.barcodeVerified ? 'Verified (' + item.barcodeScannedValue + ')' : 'Consumed' }}
                  </div>
                }
              </div>

              <!-- Step C: Separate-Role Accuracy Check -->
              <div class="space-y-3 border-b border-[#d9e2ec] pb-5">
                <div class="flex items-center justify-between">
                  <h3 class="text-sm font-bold text-[#0f2440]">3. Final Accuracy Check</h3>
                  @if (policy()?.requireSeparatePreparerAndChecker) {
                    <span class="text-xs text-[#486581]">Policy: Separate Preparer &amp; Checker Enforced</span>
                  }
                </div>

                @if (item.status === 'Awaiting accuracy check') {
                  <p class="text-xs text-[#486581]">
                    Prepared by <strong>{{ item.preparedBy }}</strong>. Sign in or switch role to a different
                    ACT/Pharmacist (e.g., Liam Patel) if needed to satisfy role separation.
                  </p>
                  <button
                    type="button"
                    (click)="submitAccuracyCheck(item.id)"
                    class="px-4 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg inline-flex items-center gap-1.5"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">fact_check</mat-icon>
                    <span>Record Accuracy Check Passed</span>
                  </button>
                } @else if (item.checkedBy) {
                  <div class="text-xs text-[#0b3d2e] font-medium">
                    Accuracy check passed by {{ item.checkedBy }} ({{ item.checkedAt }})
                  </div>
                }
              </div>

              <!-- Step D: Handover & Payment -->
              <div class="space-y-3">
                <h3 class="text-sm font-bold text-[#0f2440]">4. Patient / Representative Handover</h3>
                @if (item.status === 'Ready for handover') {
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label for="id-mode" class="block font-semibold text-[#243b53] mb-1">Identity / Handover Check</label>
                      <select
                        id="id-mode"
                        [value]="handoverIdMode()"
                        (change)="handoverIdMode.set($any($event.target).value)"
                        class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg bg-white"
                      >
                        <option value="patient_dob_address">Patient DOB &amp; Address Confirmed</option>
                        <option value="patient_photo_id">Patient Photo ID Checked</option>
                        <option value="authorised_representative">Authorised Representative Verified</option>
                        <option value="van_driver_dispatch">Dispatch via Local Van Delivery</option>
                      </select>
                    </div>
                    <div>
                      <label for="rep-name" class="block font-semibold text-[#243b53] mb-1">Representative / Driver Note</label>
                      <input
                        id="rep-name"
                        type="text"
                        [value]="repName()"
                        (input)="repName.set($any($event.target).value)"
                        placeholder="Optional representative name"
                        class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg"
                      />
                    </div>
                  </div>
                  @if (rx.chargeTotalPence > 0 && rx.paymentStatus === 'unpaid') {
                    <div class="bg-amber-50 border border-amber-300 rounded-lg p-3 text-xs text-amber-950 flex items-center justify-between gap-3">
                      <span>
                        <strong>Warning:</strong> NHS Charge Due: £{{ (rx.chargeTotalPence / 100).toFixed(2) }}
                      </span>
                      <label class="inline-flex items-center gap-1.5 font-semibold">
                        <input
                          type="checkbox"
                          [checked]="capturePayment()"
                          (change)="capturePayment.set($any($event.target).checked)"
                        />
                        <span>Capture Simulated Card Payment</span>
                      </label>
                    </div>
                  }
                  <button
                    type="button"
                    (click)="submitHandover(item.id)"
                    class="px-4 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg inline-flex items-center gap-1.5"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">volunteer_activism</mat-icon>
                    <span>Confirm Handover ({{ item.preparedQty }} {{ item.unit }})</span>
                  </button>
                } @else if (item.handedOverBy) {
                  <div class="text-xs text-[#486581]">
                    Last handover recorded by {{ item.handedOverBy }} ({{ item.handedOverAt }}).
                  </div>
                }
              </div>
            </div>

            <!-- Right Column: Demonstration Label & Source Record Separation -->
            <div class="lg:col-span-5 space-y-5">
              <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-3">
                <div class="flex items-center justify-between">
                  <h3 class="text-sm font-bold text-[#0f2440]">Demonstration Dispensing Label</h3>
                  <span class="text-xs font-mono text-[#486581]">ZPL/HTML Adapter</span>
                </div>

                <!-- Conspicuous Demonstration Marking -->
                <div class="border-2 border-dashed border-[#0f2440] rounded-lg p-4 bg-[#f8fafc] space-y-2">
                  <div class="bg-amber-100 border border-amber-400 text-amber-950 text-center py-1 px-2 text-xs font-bold tracking-wider">
                    DEMONSTRATION — NOT FOR DISPENSING
                  </div>
                  <div class="text-sm font-bold text-[#0f2440]">
                    {{ item.selectedProductName }}
                  </div>
                  <div class="text-xs font-mono text-[#243b53]">
                    Qty: {{ item.preparedQty || item.outstandingQty }} {{ item.unit }}
                    @if (item.allocatedBatchNumber) {
                      · Batch {{ item.allocatedBatchNumber }} · Exp {{ item.allocatedExpiryDate }}
                    }
                  </div>
                  <div
                    class="p-2.5 bg-white border border-[#d9e2ec] rounded text-[#0f2440]"
                    [class]="hasLargePrint() ? 'text-base font-semibold leading-snug' : 'text-xs leading-relaxed'"
                  >
                    {{ item.directionsAmended || item.directionsAsReceived }}
                  </div>
                  <div class="text-xs text-[#486581] flex justify-between pt-1 border-t border-[#e2e8f0]">
                    <span>{{ selectedPatient()?.fullName || 'Unmatched Patient' }}</span>
                    <span>Pennine Community Pharmacy (Prototype)</span>
                  </div>
                  <div class="text-[11px] text-[#486581]">
                    Keep out of the reach and sight of children.
                  </div>
                </div>
              </section>

              <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-2">
                <h3 class="text-sm font-bold text-[#0f2440]">Immutable Source Provenance</h3>
                <p class="text-xs text-[#486581]">
                  Original prescription payload preserved separately from staff amendments:
                </p>
                <pre class="text-[11px] font-mono bg-[#f4f6f8] border border-[#d9e2ec] rounded-lg p-3 overflow-x-auto text-[#243b53]">{{ rx.sourcePayloadJson }}</pre>
              </section>
            </div>
          </div>
        }
      }
    </div>
  `,
})
export class DispensingPage implements OnInit {
  private readonly api = inject(PharmacyApi);

  readonly prescriptions = signal<Prescription[]>([]);
  readonly patients = signal<PatientRecord[]>([]);
  readonly batches = signal<StockBatch[]>([]);
  readonly policy = signal<OrganisationalPolicy | null>(null);
  readonly clinicalPreview = signal<ClinicalKnowledgePreview | null>(null);

  readonly selectedRxId = signal<string | null>(null);
  readonly feedbackMsg = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  readonly clinicalNotes = signal('Clinically checked against patient allergies and BNF.');
  readonly amendedDirections = signal('');
  readonly qtyToPrepare = signal(14);
  readonly barcodeInput = signal('');
  readonly handoverIdMode = signal('patient_dob_address');
  readonly repName = signal('');
  readonly capturePayment = signal(true);

  readonly selectedRx = computed(() => {
    const id = this.selectedRxId();
    return this.prescriptions().find((p) => p.id === id) ?? this.prescriptions()[0] ?? null;
  });

  readonly selectedPatient = computed(() => {
    const pid = this.selectedRx()?.patientId;
    return pid ? this.patients().find((p) => p.id === pid) ?? null : null;
  });

  readonly hasLargePrint = computed(() => {
    return (
      this.selectedPatient()?.accessibilityNeeds.some((n) =>
        n.toLowerCase().includes('large-print'),
      ) ?? false
    );
  });

  async ngOnInit(): Promise<void> {
    await this.loadAll();
  }

  async loadAll(): Promise<void> {
    const [rxRes, patRes, stockRes] = await Promise.all([
      this.api.getPrescriptions(),
      this.api.getPatients(),
      this.api.getStock(),
    ]);
    this.prescriptions.set(rxRes.prescriptions);
    this.policy.set(rxRes.policy);
    this.patients.set(patRes.patients);
    this.batches.set(stockRes.batches);

    const locked = this.api.lockedRxId();
    if (locked && rxRes.prescriptions.some((p) => p.id === locked)) {
      this.selectedRxId.set(locked);
    } else if (!this.selectedRxId() && rxRes.prescriptions.length > 0) {
      this.selectedRxId.set(rxRes.prescriptions[0]!.id);
    }
    await this.refreshClinicalPreview();
  }

  async selectPrescription(rxId: string): Promise<void> {
    this.selectedRxId.set(rxId);
    this.api.setLockedRxId(rxId);
    this.errorMsg.set(null);
    this.feedbackMsg.set(null);
    await this.refreshClinicalPreview();
  }

  async refreshClinicalPreview(): Promise<void> {
    const rx = this.selectedRx();
    const firstItem = rx?.items[0];
    if (!rx || !rx.patientId || !firstItem) {
      this.clinicalPreview.set(null);
      return;
    }
    const avail = this.availableStockForProduct(firstItem.productId);
    this.qtyToPrepare.set(Math.min(firstItem.outstandingQty || 1, Math.max(1, avail)));
    try {
      const res = await this.api.getClinicalPreview(firstItem.id);
      this.clinicalPreview.set(res.preview);
    } catch {
      this.clinicalPreview.set(null);
    }
  }

  availableStockForProduct(productId: string): number {
    const today = new Date().toISOString().slice(0, 10);
    return this.batches()
      .filter((b) => b.productId === productId && b.state === 'available' && b.expiryDate > today)
      .reduce((sum, b) => sum + b.availableQty, 0);
  }

  simulateScan(productId: string): void {
    const match = this.batches().find((b) => b.productId === productId);
    if (match) {
      this.barcodeInput.set(match.barcodeEan13);
    }
  }

  async submitClinical(itemId: string, decision: 'approved' | 'query'): Promise<void> {
    this.errorMsg.set(null);
    try {
      const res = await this.api.submitClinicalReview(itemId, {
        decision,
        clinicalNotes: this.clinicalNotes(),
        amendedDirections: this.amendedDirections() || undefined,
        amendmentReason: this.amendedDirections() ? 'Pharmacist clarification' : undefined,
      });
      this.feedbackMsg.set(
        `Clinical review (${decision}) saved. Status: ${res.prescription.status}.`,
      );
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Review failed');
    }
  }

  async submitPrepare(item: PrescriptionItem): Promise<void> {
    this.errorMsg.set(null);
    try {
      const res = await this.api.prepareItem(item.id, {
        qtyToPrepare: this.qtyToPrepare(),
        barcodeScannedValue: this.barcodeInput(),
      });
      this.feedbackMsg.set(
        `Prepared ${this.qtyToPrepare()} ${item.unit} with barcode verified. Ready for accuracy check.`,
      );
      this.barcodeInput.set('');
      this.selectedRxId.set(res.prescription.id);
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Preparation failed');
    }
  }

  async submitAccuracyCheck(itemId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.accuracyCheckItem(itemId, {
        checkNotes: 'Verified product, batch, expiry, quantity, and demonstration label.',
      });
      this.feedbackMsg.set('Accuracy check recorded. Item ready for handover and patient notified.');
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Accuracy check failed');
    }
  }

  async submitHandover(itemId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.handoverItem(itemId, {
        identityCheckMode: this.handoverIdMode(),
        representativeName: this.repName() || undefined,
        paymentCaptured: this.capturePayment(),
        paymentMethod: 'card_sim',
      });
      this.feedbackMsg.set('Handover recorded and stock reservation consumed.');
      await this.loadAll();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Handover failed');
    }
  }
}
