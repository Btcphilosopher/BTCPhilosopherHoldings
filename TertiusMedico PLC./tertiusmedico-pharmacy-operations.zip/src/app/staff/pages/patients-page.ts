import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import {PharmacyApi} from '../../core/pharmacy-api';
import type {PatientRecord, Prescription} from '../../core/pharmacy.types';

@Component({
  selector: 'app-patients-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#0f2440]">Patient Records</h1>
        <p class="text-sm text-[#486581] mt-0.5">
          Synthetic patient register · Automatic patient merging disabled · NHS number is an identifier only
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <!-- Directory List -->
        <div class="lg:col-span-4 bg-white border border-[#d9e2ec] rounded-xl divide-y divide-[#e2e8f0] overflow-hidden">
          @for (p of patients(); track p.id) {
            <button
              type="button"
              (click)="selectPatient(p.id)"
              class="w-full text-left p-4 transition-colors"
              [class]="selected()?.id === p.id ? 'bg-emerald-50/70' : 'hover:bg-[#f8fafc]'"
            >
              <div class="flex items-center justify-between gap-2">
                <span class="text-sm font-semibold text-[#0f2440]">{{ p.fullName }}</span>
                <span class="text-xs font-mono text-[#486581]">{{ p.internalId }}</span>
              </div>
              <div class="text-xs text-[#486581] mt-1 font-mono">
                DOB {{ p.dateOfBirth }} · NHS {{ p.nhsNumber || 'Unrecorded' }}
                ({{ p.nhsNumberVerified ? 'Verified' : 'Unverified' }})
              </div>
              @if (p.allergyStatus === 'unavailable') {
                <div class="text-xs text-amber-800 font-medium mt-1">
                  Warning: Allergy information unavailable
                </div>
              } @else if (p.allergies.length > 0) {
                <div class="text-xs text-red-800 font-medium mt-1">
                  Critical: {{ p.allergies[0].substance }} allergy
                </div>
              } @else {
                <div class="text-xs text-[#486581] mt-1">No known allergies</div>
              }
            </button>
          }
        </div>

        <!-- Patient Detail -->
        @if (selected(); as pat) {
          <div class="lg:col-span-8 bg-white border border-[#d9e2ec] rounded-xl p-6 space-y-6">
            <div class="flex flex-wrap items-start justify-between gap-4 border-b border-[#d9e2ec] pb-4">
              <div>
                <div class="text-xs font-mono text-[#486581]">
                  Internal ID: {{ pat.internalId }} · NHS: {{ pat.nhsNumber || 'None' }}
                  ({{ pat.nhsNumberVerified ? 'PDS Verified' : 'Unverified' }})
                </div>
                <h2 class="font-display text-xl font-bold text-[#0f2440] mt-1">{{ pat.fullName }}</h2>
                <div class="text-xs text-[#486581] mt-1">
                  DOB {{ pat.dateOfBirth }} · {{ pat.addressLine1 }}, {{ pat.city }}, {{ pat.postcode }}
                </div>
              </div>
              <div class="text-xs text-right">
                <div class="font-semibold text-[#0f2440]">Exemption / Charge Status</div>
                <div class="text-[#486581] mt-0.5 font-mono">
                  {{ pat.exemptionStatus }} {{ pat.exemptionReference ? '(' + pat.exemptionReference + ')' : '' }}
                </div>
              </div>
            </div>

            <!-- Allergies & Adverse Reactions -->
            <div class="space-y-2">
              <h3 class="text-sm font-bold text-[#0f2440]">Allergies &amp; Adverse Reactions</h3>
              @if (pat.allergyStatus === 'unavailable') {
                <div class="bg-amber-50 border border-amber-300 rounded-lg p-3 text-xs text-amber-950 flex items-start gap-2">
                  <mat-icon class="!text-base !w-4 !h-4 text-amber-700 shrink-0">warning</mat-icon>
                  <span>
                    <strong>Warning: Allergy information unavailable.</strong> This is distinct from
                    "No known allergies" and must be verified with the patient or GP record prior to supply.
                  </span>
                </div>
              } @else if (pat.allergyStatus === 'no_known_allergies') {
                <div class="bg-[#f4f6f8] border border-[#d9e2ec] rounded-lg p-3 text-xs text-[#243b53]">
                  No known drug allergies recorded (verified status).
                </div>
              } @else {
                <div class="space-y-2">
                  @for (alg of pat.allergies; track alg.id) {
                    <div class="bg-red-50 border border-red-300 rounded-lg p-3 text-xs text-red-950">
                      <div class="font-bold">Critical: {{ alg.substance }} ({{ alg.severity }})</div>
                      <div class="mt-0.5">Reaction: {{ alg.reaction }}</div>
                      <div class="text-red-800 mt-0.5">
                        Source: {{ alg.source }} · Status: {{ alg.verificationStatus }}
                      </div>
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Accessibility, Contact Preferences & Representatives -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div class="space-y-2">
                <h3 class="text-sm font-bold text-[#0f2440]">Contact &amp; Accessibility Needs</h3>
                <div class="text-[#243b53]">Preferred Channel: <strong class="uppercase">{{ pat.preferredContact }}</strong></div>
                <div class="text-[#486581]">Phone: {{ pat.phone }} · Email: {{ pat.email }}</div>
                <div class="pt-1">
                  <div class="font-semibold text-[#243b53]">Accessibility Adjustments:</div>
                  @if (pat.accessibilityNeeds.length > 0) {
                    <ul class="list-disc pl-4 text-[#0f2440] mt-1 space-y-1">
                      @for (need of pat.accessibilityNeeds; track need) {
                        <li>{{ need }}</li>
                      }
                    </ul>
                  } @else {
                    <div class="text-[#486581] mt-1">None recorded.</div>
                  }
                </div>
              </div>

              <div class="space-y-2">
                <h3 class="text-sm font-bold text-[#0f2440]">Authorised Representatives &amp; External Refs</h3>
                @if (pat.authorisedRepresentatives.length > 0) {
                  @for (rep of pat.authorisedRepresentatives; track rep.id) {
                    <div class="p-2.5 border border-[#d9e2ec] rounded-lg bg-[#f8fafc]">
                      <div class="font-semibold text-[#0f2440]">{{ rep.name }} ({{ rep.relationship }})</div>
                      <div class="text-[#486581]">Phone: {{ rep.phone }} · Staff verified: {{ rep.verifiedByStaff ? 'Yes' : 'No' }}</div>
                    </div>
                  }
                } @else {
                  <div class="text-[#486581]">No authorised representatives recorded.</div>
                }
                <div class="pt-2 text-[#486581] font-mono">
                  External Refs: GP {{ pat.externalReferences['gpSystemRef'] || 'None' }} · PDS {{ pat.externalReferences['pdsTraceId'] || 'Pending' }}
                </div>
              </div>
            </div>

            <!-- Patient Prescription History -->
            <div class="space-y-2">
              <h3 class="text-sm font-bold text-[#0f2440]">Prescription History</h3>
              <div class="border border-[#d9e2ec] rounded-lg divide-y divide-[#e2e8f0]">
                @for (rx of patientPrescriptions(); track rx.id) {
                  <div class="p-3 flex items-center justify-between gap-4 text-xs">
                    <div>
                      <div class="font-mono font-semibold text-[#0f2440]">
                        {{ rx.prescriptionId }} · {{ rx.status }}
                      </div>
                      <div class="text-[#486581] mt-0.5">
                        @for (i of rx.items; track i.id) {
                          <span>{{ i.prescribedMedicineText }} ({{ i.suppliedQty }}/{{ i.prescribedQty }} {{ i.unit }})</span>
                        }
                      </div>
                    </div>
                    <button
                      type="button"
                      (click)="openRx(rx.id)"
                      class="px-3 py-1.5 border border-[#d9e2ec] rounded-lg font-semibold text-[#0b3d2e] hover:bg-[#f4f6f8]"
                    >
                      Open in Dispensing
                    </button>
                  </div>
                } @empty {
                  <div class="p-4 text-xs text-[#486581]">No prescriptions recorded for this patient.</div>
                }
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class PatientsPage implements OnInit {
  private readonly api = inject(PharmacyApi);
  private readonly router = inject(Router);

  readonly patients = signal<PatientRecord[]>([]);
  readonly selected = signal<PatientRecord | null>(null);
  readonly patientPrescriptions = signal<Prescription[]>([]);

  async ngOnInit(): Promise<void> {
    const res = await this.api.getPatients();
    this.patients.set(res.patients);
    if (res.patients.length > 0) {
      await this.selectPatient(res.patients[0]!.id);
    }
  }

  async selectPatient(id: string): Promise<void> {
    const res = await this.api.getPatientDetail(id);
    this.selected.set(res.patient);
    this.patientPrescriptions.set(res.prescriptions);
  }

  async openRx(rxId: string): Promise<void> {
    this.api.setLockedRxId(rxId);
    await this.router.navigateByUrl('/staff/dispensing');
  }
}
