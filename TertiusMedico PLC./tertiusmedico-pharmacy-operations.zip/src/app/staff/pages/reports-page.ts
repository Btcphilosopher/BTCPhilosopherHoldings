import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {PharmacyApi} from '../../core/pharmacy-api';

@Component({
  selector: 'app-reports-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#0f2440]">
          Reconciliation, Audit Trail &amp; Prototype Hazard Log
        </h1>
        <p class="text-sm text-[#486581] mt-0.5">
          Simulated NHSBSA FP34C summary, versioned England charges, immutable audit log, and DCB0129/DCB0160 hazard register
        </p>
      </div>

      @if (reports(); as rep) {
        <!-- Simulated FP34C & Stock Valuation -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">Available Stock Valuation</div>
            <div class="text-xl font-bold font-mono tabular-nums text-[#0f2440] mt-1">
              £{{ (Number(rep['stockValuationPence']) / 100).toFixed(2) }}
            </div>
            <div class="text-xs text-[#486581] mt-1">Integer-pence Drug Tariff basis</div>
          </div>
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">FP34C Supplied Item Lines</div>
            <div class="text-xl font-bold font-mono tabular-nums text-[#0f2440] mt-1">
              {{ asRecord(rep['fp34cSummary'])['totalSuppliedItemLines'] }}
            </div>
            <div class="text-xs text-[#486581] mt-1">
              Exempt: {{ asRecord(rep['fp34cSummary'])['exemptSuppliedLines'] }} ·
              Chargeable: {{ asRecord(rep['fp34cSummary'])['chargeableSuppliedLines'] }}
            </div>
          </div>
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">NHS Charges Collected (Sim)</div>
            <div class="text-xl font-bold font-mono tabular-nums text-[#0b3d2e] mt-1">
              £{{ (Number(asRecord(rep['fp34cSummary'])['collectedChargesPence']) / 100).toFixed(2) }}
            </div>
            <div class="text-xs text-[#486581] mt-1">Not connected to live payment gateway</div>
          </div>
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">Reimbursement Export</div>
            <div class="text-xs font-semibold text-amber-800 mt-1">
              {{ asRecord(rep['fp34cSummary'])['submissionStatus'] }}
            </div>
          </div>
        </div>

        <!-- Versioned Charge Rules -->
        <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-3">
          <h2 class="font-display text-base font-bold text-[#0f2440]">
            Versioned NHS England Prescription Charge Configuration
          </h2>
          @for (rule of asArray(rep['chargeRules']); track rule['id']) {
            <div class="text-xs space-y-1 text-[#243b53]">
              <div class="font-mono font-semibold text-[#0f2440]">
                Effective {{ rule['effective_from'] }} · {{ rule['jurisdiction'] }} ·
                Item Charge: £{{ (Number(rule['nhs_charge_per_item_pence']) / 100).toFixed(2) }} ·
                3m PPC: £{{ (Number(rule['ppc_3_month_pence']) / 100).toFixed(2) }} ·
                12m PPC: £{{ (Number(rule['ppc_12_month_pence']) / 100).toFixed(2) }} ·
                HRT PPC: £{{ (Number(rule['hrt_ppc_12_month_pence']) / 100).toFixed(2) }}
              </div>
              <div class="text-[#486581]">{{ rule['notes'] }}</div>
            </div>
          }
        </section>

        <!-- DCB0129 / DCB0160 Prototype Hazard Log -->
        <section class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
          <div class="px-5 py-3.5 border-b border-[#d9e2ec] bg-[#f4f6f8]">
            <h2 class="font-display text-sm font-bold text-[#0f2440]">
              Prototype Clinical Safety Hazard Log (DCB0129 / DCB0160 Reference)
            </h2>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
              <thead>
                <tr class="border-b border-[#d9e2ec] text-[#243b53] font-semibold">
                  <th class="py-2.5 px-4">Ref</th>
                  <th class="py-2.5 px-4">Category &amp; Hazard</th>
                  <th class="py-2.5 px-4">Prototype Mitigation</th>
                  <th class="py-2.5 px-4">Residual Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#e2e8f0]">
                @for (h of asArray(rep['hazardLog']); track h['id']) {
                  <tr class="align-top">
                    <td class="py-3 px-4 font-mono font-bold text-[#0f2440] whitespace-nowrap">{{ h['hazardRef'] }}</td>
                    <td class="py-3 px-4">
                      <div class="font-semibold text-[#0f2440]">{{ h['category'] }}: {{ h['hazardTitle'] }}</div>
                      <div class="text-red-800 mt-0.5">{{ h['clinicalRisk'] }}</div>
                    </td>
                    <td class="py-3 px-4 text-[#243b53]">{{ h['mitigationInPrototype'] }}</td>
                    <td class="py-3 px-4 text-[#486581]">{{ h['residualStatus'] }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>

        <!-- Immutable Audit Trail -->
        <section class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
          <div class="px-5 py-3.5 border-b border-[#d9e2ec] bg-[#f4f6f8]">
            <h2 class="font-display text-sm font-bold text-[#0f2440]">
              Immutable Operational Audit Trail (Redacted Logs)
            </h2>
          </div>
          <div class="max-h-96 overflow-y-auto divide-y divide-[#e2e8f0] text-xs">
            @for (ev of asArray(rep['auditEvents']); track ev['id']) {
              <div class="px-5 py-3 flex flex-wrap items-start justify-between gap-4">
                <div>
                  <span class="font-mono font-semibold text-[#0b3d2e]">{{ ev['action'] }}</span>
                  <span class="text-[#486581] ml-2">by {{ ev['actor_name'] }} ({{ ev['actor_role'] }})</span>
                  <div class="text-[#0f2440] mt-0.5">{{ ev['summary'] }}</div>
                </div>
                <div class="font-mono text-[#486581] whitespace-nowrap">{{ ev['created_at'] }}</div>
              </div>
            }
          </div>
        </section>
      }
    </div>
  `,
})
export class ReportsPage implements OnInit {
  private readonly api = inject(PharmacyApi);
  readonly Number = Number;

  readonly reports = signal<Record<string, unknown> | null>(null);

  async ngOnInit(): Promise<void> {
    this.reports.set(await this.api.getReports());
  }

  asRecord(v: unknown): Record<string, unknown> {
    return (v as Record<string, unknown>) || {};
  }

  asArray(v: unknown): Record<string, unknown>[] {
    return Array.isArray(v) ? (v as Record<string, unknown>[]) : [];
  }
}
