import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PharmacyApi} from '../../core/pharmacy-api';
import type {PatientRecord} from '../../core/pharmacy.types';

@Component({
  selector: 'app-services-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-[#0f2440]">Pharmacy Services &amp; Consultations</h1>
        <p class="text-sm text-[#486581] mt-0.5">
          Configurable branch service directory · Clinical eligibility and supply decisions remain with authorised practitioners
        </p>
      </div>

      @if (feedbackMsg()) {
        <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-950">
          {{ feedbackMsg() }}
        </div>
      }

      <!-- Service Catalog -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        @for (svc of services(); track svc['id']) {
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-2">
            <div class="flex items-center justify-between gap-2">
              <h2 class="font-display text-sm font-bold text-[#0f2440]">{{ svc['name'] }}</h2>
              <span class="text-xs font-mono text-[#486581]">{{ svc['duration_minutes'] }} min</span>
            </div>
            <div class="text-xs text-[#486581]">
              {{ svc['category'] }} · {{ svc['room'] }} · Equipment: {{ svc['required_equipment'] }}
            </div>
            <p class="text-xs text-[#243b53] pt-1">{{ svc['clinical_pathway_note'] }}</p>
          </div>
        }
      </div>

      <!-- Book Appointment -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-4">
        <h2 class="font-display text-base font-bold text-[#0f2440]">Book Pharmacy Service Appointment</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div>
            <label for="svc-sel" class="block font-semibold text-[#243b53] mb-1">Service</label>
            <select
              id="svc-sel"
              [value]="selectedServiceId()"
              (change)="selectedServiceId.set($any($event.target).value)"
              class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg bg-white"
            >
              @for (svc of services(); track svc['id']) {
                <option [value]="svc['id']">{{ svc['name'] }}</option>
              }
            </select>
          </div>
          <div>
            <label for="svc-pat" class="block font-semibold text-[#243b53] mb-1">Patient</label>
            <select
              id="svc-pat"
              [value]="selectedPatientId()"
              (change)="selectedPatientId.set($any($event.target).value)"
              class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg bg-white"
            >
              @for (p of patients(); track p.id) {
                <option [value]="p.id">{{ p.fullName }}</option>
              }
            </select>
          </div>
          <div>
            <label for="svc-note" class="block font-semibold text-[#243b53] mb-1">Consultation Note</label>
            <input
              id="svc-note"
              type="text"
              [value]="bookingNote()"
              (input)="bookingNote.set($any($event.target).value)"
              class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg"
            />
          </div>
          <div class="flex items-end">
            <button
              type="button"
              (click)="book()"
              class="w-full py-2 px-4 bg-[#0b3d2e] hover:bg-[#11523f] text-white font-semibold rounded-lg"
            >
              Confirm Booking (Consent Recorded)
            </button>
          </div>
        </div>
      </section>

      <!-- Appointments Table -->
      <section class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
        <table class="w-full text-left border-collapse text-xs">
          <thead>
            <tr class="border-b border-[#d9e2ec] bg-[#f4f6f8] font-semibold text-[#243b53]">
              <th class="py-3 px-4">Appointment</th>
              <th class="py-3 px-4">Patient</th>
              <th class="py-3 px-4">Practitioner &amp; Room</th>
              <th class="py-3 px-4">Consent &amp; Attendance</th>
              <th class="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-[#e2e8f0]">
            @for (apt of appointments(); track apt['id']) {
              <tr>
                <td class="py-3 px-4">
                  <div class="font-semibold text-[#0f2440]">{{ apt['service_name'] }}</div>
                  <div class="font-mono text-[#486581]">{{ apt['id'] }} · {{ apt['scheduled_at'] }}</div>
                </td>
                <td class="py-3 px-4 font-semibold">{{ apt['patient_name'] }}</td>
                <td class="py-3 px-4 text-[#486581]">
                  {{ apt['practitioner_name'] || 'Pharmacist' }} · {{ apt['room'] }}
                </td>
                <td class="py-3 px-4">
                  <div>Consent: {{ apt['consent_recorded'] === 1 ? 'Yes' : 'Pending' }} · Attendance: {{ apt['attendance_status'] }}</div>
                  @if (apt['outcome_reference']) {
                    <div class="font-mono text-[#0b3d2e]">Outcome: {{ apt['outcome_reference'] }}</div>
                  }
                </td>
                <td class="py-3 px-4 text-right">
                  @if (apt['attendance_status'] === 'pending') {
                    <button
                      type="button"
                      (click)="completeAppointment(String(apt['id']))"
                      class="px-3 py-1 bg-[#0b3d2e] text-white font-semibold rounded"
                    >
                      Mark Attended &amp; Record Outcome
                    </button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      </section>
    </div>
  `,
})
export class ServicesPage implements OnInit {
  private readonly api = inject(PharmacyApi);
  readonly String = String;

  readonly services = signal<Record<string, unknown>[]>([]);
  readonly appointments = signal<Record<string, unknown>[]>([]);
  readonly patients = signal<PatientRecord[]>([]);
  readonly selectedServiceId = signal('SVC-PHARM-FIRST');
  readonly selectedPatientId = signal('PAT-1004');
  readonly bookingNote = signal('Patient consented for clinical assessment');
  readonly feedbackMsg = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    await this.loadAll();
  }

  async loadAll(): Promise<void> {
    const [svcRes, patRes] = await Promise.all([this.api.getServices(), this.api.getPatients()]);
    this.services.set(svcRes.services);
    this.appointments.set(svcRes.appointments);
    this.patients.set(patRes.patients);
  }

  async book(): Promise<void> {
    const res = await this.api.bookAppointment({
      serviceId: this.selectedServiceId(),
      patientId: this.selectedPatientId(),
      consentRecorded: true,
      notes: this.bookingNote(),
    });
    this.feedbackMsg.set(`Booked service appointment ${res.id}.`);
    await this.loadAll();
  }

  async completeAppointment(id: string): Promise<void> {
    await this.api.updateAppointment(id, {
      attendanceStatus: 'attended',
      outcomeReference: `OUTCOME-${id}`,
      followUpTask: 'GP notification summary queued (simulated)',
    });
    this.feedbackMsg.set(`Recorded attendance and outcome for ${id}.`);
    await this.loadAll();
  }
}
