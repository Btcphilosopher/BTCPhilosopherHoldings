import {ChangeDetectionStrategy, Component, computed, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Router} from '@angular/router';
import {PharmacyApi} from '../../core/pharmacy-api';
import type {PatientRecord, Prescription} from '../../core/pharmacy.types';

@Component({
  selector: 'app-prescriptions-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-[#0f2440]">Prescriptions &amp; Intake Queue</h1>
          <p class="text-sm text-[#486581] mt-0.5">
            Electronic messages, manual demonstration entries, uploaded document verification, and patient matching
          </p>
        </div>
        <button
          type="button"
          (click)="showIntake.set(!showIntake())"
          class="px-4 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg flex items-center gap-1.5 whitespace-nowrap"
        >
          <mat-icon class="!text-base !w-4 !h-4">add_circle_outline</mat-icon>
          <span>{{ showIntake() ? 'Close Intake Form' : 'Receive New Prescription' }}</span>
        </button>
      </div>

      @if (feedbackMsg()) {
        <div class="bg-emerald-50 border border-emerald-300 rounded-xl p-3 text-xs text-emerald-950 flex items-center justify-between gap-3">
          <span>{{ feedbackMsg() }}</span>
          <button type="button" (click)="feedbackMsg.set(null)" class="underline font-semibold">Dismiss</button>
        </div>
      }

      @if (errorMsg()) {
        <div class="bg-red-50 border border-red-300 rounded-xl p-3 text-xs text-red-950 flex items-center justify-between gap-3">
          <span><strong>Critical:</strong> {{ errorMsg() }}</span>
          <button type="button" (click)="errorMsg.set(null)" class="underline font-semibold">Dismiss</button>
        </div>
      }

      <!-- Intake Form Panel -->
      @if (showIntake()) {
        <section class="bg-white border border-[#d9e2ec] rounded-xl p-5 space-y-4">
          <h2 class="text-sm font-bold text-[#0f2440]">
            Prescription Intake (Preserves Immutable Source Payload)
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label for="intake-source" class="block font-semibold text-[#243b53] mb-1">Source System</label>
              <select
                id="intake-source"
                [value]="intakeSource()"
                (change)="intakeSource.set($any($event.target).value)"
                class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg bg-white"
              >
                <option value="NHS_EPS_SIM">Synthetic EPS Message</option>
                <option value="MANUAL_DEMO">Manual Demonstration Rx</option>
                <option value="UPLOADED_DOCUMENT">Uploaded Document Scan (Requires Verification)</option>
              </select>
            </div>
            <div>
              <label for="intake-ref" class="block font-semibold text-[#243b53] mb-1">
                Source Identifier (Duplicate Checked)
              </label>
              <input
                id="intake-ref"
                type="text"
                [value]="intakeSourceId()"
                (input)="intakeSourceId.set($any($event.target).value)"
                class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg font-mono"
              />
            </div>
            <div>
              <label for="intake-patient" class="block font-semibold text-[#243b53] mb-1">
                Patient (Leave Unmatched to Test Queue)
              </label>
              <select
                id="intake-patient"
                [value]="intakePatientId()"
                (change)="intakePatientId.set($any($event.target).value)"
                class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg bg-white"
              >
                <option value="">-- Unmatched (Route to Exception Queue) --</option>
                @for (p of patients(); track p.id) {
                  <option [value]="p.id">{{ p.fullName }} ({{ p.internalId }})</option>
                }
              </select>
            </div>
            <div>
              <label for="intake-med" class="block font-semibold text-[#243b53] mb-1">Prescribed Medicine (dm+d)</label>
              <select
                id="intake-med"
                [value]="intakeProductId()"
                (change)="intakeProductId.set($any($event.target).value)"
                class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg bg-white"
              >
                @for (m of products(); track m['id']) {
                  <option [value]="m['id']">{{ m['prescribed_name'] }} ({{ m['quantity_unit'] }})</option>
                }
              </select>
            </div>
            <div>
              <label for="intake-qty" class="block font-semibold text-[#243b53] mb-1">Quantity</label>
              <input
                id="intake-qty"
                type="number"
                min="1"
                [value]="intakeQty()"
                (input)="intakeQty.set(+$any($event.target).value)"
                class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg font-mono"
              />
            </div>
            <div>
              <label for="intake-dir" class="block font-semibold text-[#243b53] mb-1">Directions as Received</label>
              <input
                id="intake-dir"
                type="text"
                [value]="intakeDirections()"
                (input)="intakeDirections.set($any($event.target).value)"
                class="w-full px-3 py-2 border border-[#bcccdc] rounded-lg"
              />
            </div>
          </div>
          <div class="flex justify-end gap-3 pt-2">
            <button
              type="button"
              (click)="submitIntake()"
              class="px-4 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg"
            >
              Submit Prescription Intake
            </button>
          </div>
        </section>
      }

      <!-- Segmented Filter Controls -->
      <div class="flex flex-wrap items-center gap-2">
        <div class="flex flex-wrap items-center gap-1 p-1 bg-white border border-[#d9e2ec] rounded-lg">
          @for (f of filterTabs; track f.id) {
            <button
              type="button"
              (click)="activeFilter.set(f.id)"
              class="px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap"
              [class]="activeFilter() === f.id ? 'bg-[#0b3d2e] text-white' : 'text-[#486581] hover:text-[#0f2440]'"
            >
              {{ f.label }}
            </button>
          }
        </div>
        <input
          type="search"
          [value]="searchQuery()"
          (input)="searchQuery.set($any($event.target).value)"
          placeholder="Search Rx ID, patient, or medicine..."
          aria-label="Search prescriptions"
          class="px-3 py-2 text-xs border border-[#d9e2ec] rounded-lg bg-white min-w-[240px]"
        />
      </div>

      <!-- Readable Work Queue Table -->
      <div class="bg-white border border-[#d9e2ec] rounded-xl overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse">
            <thead>
              <tr class="border-b border-[#d9e2ec] bg-[#f4f6f8] text-xs font-semibold text-[#243b53]">
                <th class="py-3 px-4">Prescription</th>
                <th class="py-3 px-4">Patient &amp; Safety</th>
                <th class="py-3 px-4">Items &amp; Quantities</th>
                <th class="py-3 px-4">Stage</th>
                <th class="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#e2e8f0] text-xs">
              @for (rx of filteredPrescriptions(); track rx.id) {
                <tr class="hover:bg-[#f8fafc] align-top">
                  <td class="py-3.5 px-4">
                    <div class="font-mono font-semibold text-[#0f2440]">{{ rx.prescriptionId }}</div>
                    <div class="text-[#486581] mt-0.5">
                      {{ rx.sourceSystem }} · v{{ rx.version }} · {{ rx.issueDate }}
                    </div>
                    <div class="text-[#486581] mt-0.5 truncate max-w-[220px]" [title]="rx.prescriberDetails">
                      {{ rx.prescriberDetails }}
                    </div>
                  </td>
                  <td class="py-3.5 px-4">
                    @if (rx.matchStatus !== 'matched') {
                      <div class="text-amber-900 bg-amber-50 border border-amber-300 rounded-lg p-2.5 space-y-2 max-w-xs">
                        <div class="font-semibold flex items-center gap-1">
                          <mat-icon class="!text-sm !w-4 !h-4 text-amber-700">warning</mat-icon>
                          <span>Warning: Unmatched Patient</span>
                        </div>
                        <div class="text-[#243b53]">{{ rx.patientReference }}</div>
                        <div class="flex items-center gap-1.5">
                          <select
                            #matchSelect
                            class="flex-1 px-2 py-1 border border-amber-300 rounded bg-white text-xs"
                          >
                            @for (p of patients(); track p.id) {
                              <option [value]="p.id">{{ p.fullName }} ({{ p.dateOfBirth }})</option>
                            }
                          </select>
                          <button
                            type="button"
                            (click)="resolveMatch(rx.id, matchSelect.value)"
                            class="px-2.5 py-1 bg-[#0b3d2e] text-white rounded font-semibold whitespace-nowrap"
                          >
                            Match
                          </button>
                        </div>
                      </div>
                    } @else if (rx.patientSummary) {
                      <div class="font-semibold text-[#0f2440]">{{ rx.patientSummary.fullName }}</div>
                      <div class="text-[#486581] font-mono mt-0.5">
                        {{ rx.patientSummary.internalId }} · NHS {{ rx.patientSummary.nhsNumber || 'None' }}
                        ({{ rx.patientSummary.nhsNumberVerified ? 'Verified' : 'Unverified' }})
                      </div>
                      @if (rx.patientSummary.allergyStatus === 'unavailable') {
                        <div class="text-amber-800 font-medium mt-1">
                          Warning: Allergy information unavailable
                        </div>
                      } @else if (rx.patientSummary.allergiesCount > 0) {
                        <div class="text-red-800 font-semibold mt-1">
                          Critical: {{ rx.patientSummary.allergiesCount }} Recorded Allergy
                        </div>
                      } @else {
                        <div class="text-[#486581] mt-1">No known allergies</div>
                      }
                    }
                  </td>
                  <td class="py-3.5 px-4 space-y-1.5">
                    @for (item of rx.items; track item.id) {
                      <div>
                        <div class="font-semibold text-[#0f2440]">
                          {{ item.prescribedMedicineText }}
                        </div>
                        <div class="text-[#486581] tabular-nums">
                          Prescribed: {{ item.prescribedQty }} {{ item.unit }} ·
                          Supplied: {{ item.suppliedQty }} ·
                          Outstanding: {{ item.outstandingQty }}
                          @if (item.cancelledQty > 0) {
                            · Cancelled: {{ item.cancelledQty }}
                          }
                        </div>
                      </div>
                    }
                    @if (rx.verificationRequired && !rx.documentVerifiedAt) {
                      <div class="text-amber-900 bg-amber-50 border border-amber-300 rounded px-2 py-1 inline-flex items-center gap-1.5">
                        <mat-icon class="!text-sm !w-4 !h-4 text-amber-700">description</mat-icon>
                        <span>Uploaded scan unverified</span>
                        <button
                          type="button"
                          (click)="verifyDoc(rx.id)"
                          class="underline font-semibold ml-1"
                        >
                          Verify Document
                        </button>
                      </div>
                    }
                  </td>
                  <td class="py-3.5 px-4">
                    <div
                      class="font-semibold"
                      [class]="rx.status === 'Cancelled' ? 'text-red-800' : rx.status === 'Partially supplied' ? 'text-amber-800' : 'text-[#0f2440]'"
                    >
                      {{ rx.status }}
                    </div>
                    <div class="text-[#486581] mt-0.5">{{ rx.exemptionOrChargeStatus }}</div>
                  </td>
                  <td class="py-3.5 px-4 text-right space-x-2 whitespace-nowrap">
                    <button
                      type="button"
                      (click)="openInDispensing(rx.id)"
                      class="px-3 py-1.5 bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg font-semibold inline-flex items-center gap-1"
                    >
                      <mat-icon class="!text-sm !w-4 !h-4">medication</mat-icon>
                      <span>Dispense</span>
                    </button>
                    @if (rx.status !== 'Cancelled' && rx.status !== 'Completed') {
                      <button
                        type="button"
                        (click)="cancelRx(rx.id)"
                        class="px-2.5 py-1.5 border border-[#d9e2ec] hover:bg-red-50 hover:text-red-900 rounded-lg text-[#486581]"
                      >
                        Cancel
                      </button>
                    }
                  </td>
                </tr>
              } @empty {
                <tr>
                  <td colspan="5" class="py-8 text-center text-sm text-[#486581]">
                    No prescriptions match the current filter.
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class PrescriptionsPage implements OnInit {
  private readonly api = inject(PharmacyApi);
  private readonly router = inject(Router);

  readonly prescriptions = signal<Prescription[]>([]);
  readonly patients = signal<PatientRecord[]>([]);
  readonly products = signal<Record<string, unknown>[]>([]);
  readonly activeFilter = signal<string>('all');
  readonly searchQuery = signal('');
  readonly showIntake = signal(false);
  readonly feedbackMsg = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  // Intake form state
  readonly intakeSource = signal<'NHS_EPS_SIM' | 'MANUAL_DEMO' | 'UPLOADED_DOCUMENT'>('NHS_EPS_SIM');
  readonly intakeSourceId = signal(`EPS-SYN-${Math.floor(1000 + Math.random() * 9000)}`);
  readonly intakePatientId = signal('PAT-1001');
  readonly intakeProductId = signal('MED-RAMI-5');
  readonly intakeQty = signal(28);
  readonly intakeDirections = signal('Take ONE capsule daily');

  readonly filterTabs = [
    {id: 'all', label: 'All Prescriptions'},
    {id: 'exceptions', label: 'Exceptions & Unmatched'},
    {id: 'clinical', label: 'Awaiting Clinical Review'},
    {id: 'dispense', label: 'Preparation & Checking'},
    {id: 'handover', label: 'Ready / Partial'},
    {id: 'done', label: 'Completed / Cancelled'},
  ];

  readonly filteredPrescriptions = computed(() => {
    const f = this.activeFilter();
    const q = this.searchQuery().trim().toLowerCase();
    return this.prescriptions().filter((rx) => {
      if (f === 'exceptions' && rx.matchStatus === 'matched' && !(rx.verificationRequired && !rx.documentVerifiedAt) && rx.status !== 'Awaiting clarification') {
        return false;
      }
      if (f === 'clinical' && rx.status !== 'Awaiting clinical review') return false;
      if (f === 'dispense' && !['Awaiting stock', 'Ready for preparation', 'Prepared', 'Awaiting accuracy check'].includes(rx.status)) return false;
      if (f === 'handover' && !['Ready for handover', 'Partially supplied'].includes(rx.status)) return false;
      if (f === 'done' && !['Completed', 'Cancelled'].includes(rx.status)) return false;
      if (q) {
        const hay = `${rx.prescriptionId} ${rx.patientReference} ${rx.patientSummary?.fullName || ''} ${rx.items.map((i) => i.prescribedMedicineText).join(' ')}`.toLowerCase();
        return hay.includes(q);
      }
      return true;
    });
  });

  async ngOnInit(): Promise<void> {
    await this.loadData();
  }

  async loadData(): Promise<void> {
    const [rxRes, patRes, catRes] = await Promise.all([
      this.api.getPrescriptions(),
      this.api.getPatients(),
      this.api.getCatalogue(),
    ]);
    this.prescriptions.set(rxRes.prescriptions);
    this.patients.set(patRes.patients);
    this.products.set(catRes.products);
  }

  async submitIntake(): Promise<void> {
    this.errorMsg.set(null);
    this.feedbackMsg.set(null);
    try {
      const pat = this.patients().find((p) => p.id === this.intakePatientId());
      const res = await this.api.intakePrescription({
        sourceIdentifier: this.intakeSourceId(),
        sourceSystem: this.intakeSource(),
        patientId: this.intakePatientId() || null,
        patientReference: pat ? `${pat.fullName} · NHS ${pat.nhsNumber || 'None'}` : 'UNMATCHED INTAKE TEST',
        prescriberDetails: 'Dr. R. Ellis · Hebden Bridge Group Practice',
        productId: this.intakeProductId(),
        prescribedQty: this.intakeQty(),
        directionsAsReceived: this.intakeDirections(),
      });
      this.feedbackMsg.set(`Ingested ${res.prescription.prescriptionId} (${res.prescription.status}).`);
      this.intakeSourceId.set(`EPS-SYN-${Math.floor(1000 + Math.random() * 9000)}`);
      this.showIntake.set(false);
      await this.loadData();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Intake failed');
    }
  }

  async resolveMatch(rxId: string, patientId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.matchPatient(rxId, patientId, 'Verified manually in Staff Queue');
      this.feedbackMsg.set(`Verified patient match for ${rxId}.`);
      await this.loadData();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Match failed');
    }
  }

  async verifyDoc(rxId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.verifyDocument(rxId);
      this.feedbackMsg.set(`Uploaded document scan verified for ${rxId}.`);
      await this.loadData();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Verification failed');
    }
  }

  async cancelRx(rxId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      const res = await this.api.cancelPrescription(rxId, `CANCEL-${rxId}`, 'Cancelled from Staff Queue');
      this.feedbackMsg.set(res.message);
      await this.loadData();
    } catch (err: unknown) {
      this.errorMsg.set((err as {error?: {error?: string}})?.error?.error || 'Cancellation failed');
    }
  }

  async openInDispensing(rxId: string): Promise<void> {
    this.api.setLockedRxId(rxId);
    await this.router.navigateByUrl('/staff/dispensing');
  }
}
