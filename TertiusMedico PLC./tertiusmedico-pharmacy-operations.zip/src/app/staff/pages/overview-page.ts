import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {RouterLink} from '@angular/router';
import {PharmacyApi} from '../../core/pharmacy-api';
import type {OverviewResponse} from '../../core/pharmacy.types';

interface DemoStepLog {
  step: number;
  title: string;
  detail: string;
  status: string;
}

@Component({
  selector: 'app-overview-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, RouterLink],
  template: `
    <div class="space-y-6">
      <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-[#0f2440]">
            Pharmacy Operations Overview
          </h1>
          <p class="text-sm text-[#486581] mt-0.5">
            Pennine Community Pharmacy · Independent Prototype · All queues live from SQLite
          </p>
        </div>
        <div class="flex items-center gap-3">
          <button
            type="button"
            (click)="runWorker()"
            class="px-4 py-2 text-xs font-semibold border border-[#d9e2ec] bg-white hover:bg-[#f4f6f8] text-[#0f2440] rounded-lg flex items-center gap-1.5 whitespace-nowrap"
          >
            <mat-icon class="!text-base !w-4 !h-4">sync</mat-icon>
            <span>Run Background Worker</span>
          </button>
          <a
            routerLink="/staff/prescriptions"
            class="px-4 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] text-white rounded-lg flex items-center gap-1.5 whitespace-nowrap"
          >
            <mat-icon class="!text-base !w-4 !h-4">receipt_long</mat-icon>
            <span>Open Prescription Queue</span>
          </a>
        </div>
      </div>

      @if (workerNote()) {
        <div class="bg-white border border-[#d9e2ec] rounded-xl p-3 text-xs text-[#243b53]">
          {{ workerNote() }}
        </div>
      }

      @if (overview(); as ov) {
        <!-- Critical / Amber Operational Safety Alerts -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          @if (!ov.policy.clinicalAdapterAvailable) {
            <div class="bg-red-50 border border-red-300 rounded-xl p-4 text-xs text-red-950 flex items-start gap-2.5">
              <mat-icon class="!text-lg !w-5 !h-5 text-red-700 shrink-0">error</mat-icon>
              <div>
                <div class="font-semibold">Critical: Clinical-Checking Adapter Unavailable</div>
                <p class="mt-0.5 leading-relaxed">
                  {{ ov.policy.clinicalAdapterVersion }} is offline. Absence of automated alerts does
                  not indicate dispensing is safe. Manual pharmacist checks are mandatory.
                </p>
              </div>
            </div>
          }

          @if (ov.unmatchedCount > 0 || ov.unverifiedDocumentsCount > 0) {
            <div class="bg-amber-50 border border-amber-300 rounded-xl p-4 text-xs text-amber-950 flex items-start gap-2.5">
              <mat-icon class="!text-lg !w-5 !h-5 text-amber-700 shrink-0">warning</mat-icon>
              <div>
                <div class="font-semibold">
                  Warning: {{ ov.unmatchedCount }} Unmatched Patient(s) · {{ ov.unverifiedDocumentsCount }} Unverified Scan(s)
                </div>
                <p class="mt-0.5 leading-relaxed">
                  Automatic patient merging and automatic scan approval are disabled.
                  <a routerLink="/staff/prescriptions" class="underline font-semibold ml-1">Review intake exceptions</a>
                </p>
              </div>
            </div>
          }

          @if (ov.failedNotificationsCount > 0 || ov.expiredBatchesCount > 0) {
            <div class="bg-amber-50 border border-amber-300 rounded-xl p-4 text-xs text-amber-950 flex items-start gap-2.5">
              <mat-icon class="!text-lg !w-5 !h-5 text-amber-700 shrink-0">warning</mat-icon>
              <div>
                <div class="font-semibold">
                  Warning: {{ ov.failedNotificationsCount }} Failed Notification(s) · {{ ov.expiredBatchesCount }} Expired Batch(es)
                </div>
                <p class="mt-0.5 leading-relaxed">
                  Expired batches are excluded from FEFO allocation. Failed SMS alerts require manual follow-up in Deliveries &amp; Messaging.
                </p>
              </div>
            </div>
          }
        </div>

        <!-- Key Operational Metrics Row -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">Active Prescriptions</div>
            <div class="text-2xl font-bold text-[#0f2440] tabular-nums mt-1">{{ ov.totalPrescriptions }}</div>
            <div class="text-xs text-[#486581] mt-1">
              {{ ov.stageCounts['Awaiting clinical review'] || 0 }} awaiting review
            </div>
          </div>
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">Ready for Handover</div>
            <div class="text-2xl font-bold text-[#0b3d2e] tabular-nums mt-1">
              {{ ov.stageCounts['Ready for handover'] || 0 }}
            </div>
            <div class="text-xs text-[#486581] mt-1">
              {{ ov.stageCounts['Partially supplied'] || 0 }} partially supplied
            </div>
          </div>
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">Stock Alerts</div>
            <div class="text-2xl font-bold text-[#0f2440] tabular-nums mt-1">{{ ov.lowStockProductsCount }}</div>
            <div class="text-xs text-[#486581] mt-1">
              {{ ov.quarantinedOrRecalledCount }} quarantined/recalled
            </div>
          </div>
          <div class="bg-white border border-[#d9e2ec] rounded-xl p-4">
            <div class="text-xs text-[#486581]">Service Appointments</div>
            <div class="text-2xl font-bold text-[#0f2440] tabular-nums mt-1">{{ ov.upcomingAppointmentsCount }}</div>
            <div class="text-xs text-[#486581] mt-1">
              {{ ov.openRecallsCount }} active recall log(s)
            </div>
          </div>
        </div>

        <!-- 14-Step Reproducible Demonstration Console -->
        <section class="bg-white border border-[#d9e2ec] rounded-xl p-6 space-y-5">
          <div class="flex flex-wrap items-start justify-between gap-4 border-b border-[#d9e2ec] pb-4">
            <div>
              <h2 class="font-display text-lg font-bold text-[#0f2440]">
                Reproducible 14-Step Pharmacy Demonstration
              </h2>
              <p class="text-xs text-[#486581] mt-1 max-w-2xl">
                Execute the full end-to-end Pennine Community Pharmacy scenario against the SQLite
                database — including insufficient stock, partial supply, goods receipt replenishment,
                duplicate cancellation handling, batch recall quarantine, and service booking.
              </p>
            </div>
            <div class="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                [disabled]="demoRunning()"
                (click)="runAllDemoSteps()"
                class="px-4 py-2 text-xs font-semibold bg-[#0b3d2e] hover:bg-[#11523f] disabled:opacity-50 text-white rounded-lg flex items-center gap-1.5 whitespace-nowrap"
              >
                <mat-icon class="!text-base !w-4 !h-4">play_arrow</mat-icon>
                <span>{{ demoRunning() ? 'Running...' : 'Run All 14 Steps' }}</span>
              </button>
              <button
                type="button"
                [disabled]="demoRunning()"
                (click)="resetDemo()"
                class="px-4 py-2 text-xs font-semibold border border-[#d9e2ec] bg-white hover:bg-[#f4f6f8] text-[#0f2440] rounded-lg flex items-center gap-1.5 whitespace-nowrap"
              >
                <mat-icon class="!text-base !w-4 !h-4">restart_alt</mat-icon>
                <span>Reset Synthetic Data</span>
              </button>
            </div>
          </div>

          @if (demoError()) {
            <div class="bg-red-50 border border-red-300 rounded-lg p-3 text-xs text-red-900">
              <strong>Critical:</strong> {{ demoError() }}
            </div>
          }

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            @for (step of demoCatalog; track step.num) {
              <button
                type="button"
                [disabled]="demoRunning()"
                (click)="runSingleStep(step.num)"
                class="text-left p-3 rounded-lg border transition-colors flex flex-col justify-between gap-2"
                [class]="completedSteps().has(step.num)
                  ? 'border-emerald-300 bg-emerald-50/50'
                  : 'border-[#d9e2ec] hover:bg-[#f4f6f8]'"
              >
                <div class="flex items-center justify-between gap-2">
                  <span class="text-xs font-mono font-semibold text-[#0b3d2e] tabular-nums">
                    Step {{ step.num < 10 ? '0' + step.num : step.num }}
                  </span>
                  @if (completedSteps().has(step.num)) {
                    <mat-icon class="!text-base !w-4 !h-4 text-emerald-700">check_circle</mat-icon>
                  } @else {
                    <mat-icon class="!text-base !w-4 !h-4 text-[#829ab1]">play_circle_outline</mat-icon>
                  }
                </div>
                <div class="text-xs font-semibold text-[#0f2440]">{{ step.label }}</div>
              </button>
            }
          </div>

          @if (demoLogs().length > 0) {
            <div class="border-t border-[#d9e2ec] pt-4 space-y-2">
              <div class="text-xs font-semibold text-[#243b53]">Execution Output</div>
              <div class="max-h-64 overflow-y-auto divide-y divide-[#e2e8f0] border border-[#d9e2ec] rounded-lg">
                @for (log of demoLogs(); track log.step) {
                  <div class="p-3 text-xs flex items-start gap-3 bg-white">
                    <span class="font-mono font-semibold text-[#0b3d2e] shrink-0">
                      #{{ log.step }}
                    </span>
                    <div class="min-w-0">
                      <div class="font-semibold text-[#0f2440]">{{ log.title }}</div>
                      <div class="text-[#486581] mt-0.5">{{ log.detail }}</div>
                    </div>
                  </div>
                }
              </div>
            </div>
          }
        </section>

        <!-- Workflow Stage Distribution -->
        <section class="bg-white border border-[#d9e2ec] rounded-xl p-6">
          <h2 class="font-display text-base font-bold text-[#0f2440] mb-4">
            Prescription Queue by Workflow Stage
          </h2>
          <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            @for (stage of allStages; track stage) {
              <div class="border border-[#d9e2ec] rounded-lg p-3 bg-[#f4f6f8]/60">
                <div class="text-xs text-[#486581] truncate" [title]="stage">{{ stage }}</div>
                <div class="text-xl font-bold text-[#0f2440] tabular-nums mt-1">
                  {{ ov.stageCounts[stage] || 0 }}
                </div>
              </div>
            }
          </div>
        </section>
      }
    </div>
  `,
})
export class OverviewPage implements OnInit {
  private readonly api = inject(PharmacyApi);

  readonly overview = signal<OverviewResponse | null>(null);
  readonly demoRunning = signal(false);
  readonly demoError = signal<string | null>(null);
  readonly workerNote = signal<string | null>(null);
  readonly demoLogs = signal<DemoStepLog[]>([]);
  readonly completedSteps = signal<Set<number>>(new Set());

  readonly allStages = [
    'Received',
    'Awaiting clarification',
    'Awaiting clinical review',
    'Awaiting stock',
    'Ready for preparation',
    'Prepared',
    'Awaiting accuracy check',
    'Ready for handover',
    'Partially supplied',
    'Completed',
    'Cancelled',
  ];

  readonly demoCatalog = [
    {num: 1, label: 'Receive synthetic EPS prescription (Atorvastatin 20mg x 28)'},
    {num: 2, label: 'Match prescription to Arthur Pendelton (PEN-PAT-001001)'},
    {num: 3, label: 'Complete authorised pharmacist clinical review'},
    {num: 4, label: 'Detect insufficient stock (14 of 28 tablets available)'},
    {num: 5, label: 'Prepare partial supply (14 tablets) + barcode & label'},
    {num: 6, label: 'Perform separate-role ACT accuracy check'},
    {num: 7, label: 'Notify patient via privacy-redacted SMS'},
    {num: 8, label: 'Record handover to authorised representative'},
    {num: 9, label: 'Receive replacement stock (PO-2026-0101 goods receipt)'},
    {num: 10, label: 'Complete outstanding 14-tablet supply'},
    {num: 11, label: 'Process duplicate cancellation message safely'},
    {num: 12, label: 'Quarantine recalled batch (BATCH-AMX-REC)'},
    {num: 13, label: 'Book NHS Pharmacy First service appointment'},
    {num: 14, label: 'Verify stock valuation & immutable audit reports'},
  ];

  async ngOnInit(): Promise<void> {
    await this.loadOverview();
  }

  async loadOverview(): Promise<void> {
    try {
      const ov = await this.api.getOverview();
      this.overview.set(ov);
    } catch {
      // Ignore if session expired
    }
  }

  async runWorker(): Promise<void> {
    const res = await this.api.runWorker();
    this.workerNote.set(
      `Background worker ran at ${res.summary.ranAt}: processed ${res.summary.notificationsProcessed} notification(s), flagged ${res.summary.expiredBatchesFlagged} expired batch(es).`,
    );
    await this.loadOverview();
  }

  async runSingleStep(step: number): Promise<void> {
    this.demoRunning.set(true);
    this.demoError.set(null);
    try {
      const res = await this.api.runDemoStep(step);
      this.demoLogs.update((logs) => [res, ...logs.filter((l) => l.step !== res.step)]);
      this.completedSteps.update((set) => {
        const next = new Set(set);
        next.add(step);
        return next;
      });
      await this.loadOverview();
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error || `Step ${step} failed`;
      this.demoError.set(msg);
    } finally {
      this.demoRunning.set(false);
    }
  }

  async runAllDemoSteps(): Promise<void> {
    this.demoRunning.set(true);
    this.demoError.set(null);
    try {
      for (let i = 1; i <= 14; i++) {
        const res = await this.api.runDemoStep(i);
        this.demoLogs.update((logs) => [res, ...logs.filter((l) => l.step !== res.step)]);
        this.completedSteps.update((set) => {
          const next = new Set(set);
          next.add(i);
          return next;
        });
      }
      await this.loadOverview();
    } catch (err: unknown) {
      const msg = (err as {error?: {error?: string}})?.error?.error || 'Demo sequence interrupted';
      this.demoError.set(msg);
    } finally {
      this.demoRunning.set(false);
    }
  }

  async resetDemo(): Promise<void> {
    this.demoRunning.set(true);
    this.demoError.set(null);
    try {
      await this.api.resetDemo();
      this.demoLogs.set([]);
      this.completedSteps.set(new Set());
      await this.loadOverview();
    } finally {
      this.demoRunning.set(false);
    }
  }
}
