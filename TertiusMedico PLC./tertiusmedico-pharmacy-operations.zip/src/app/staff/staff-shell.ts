import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {Router, RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {PharmacyApi} from '../core/pharmacy-api';

interface NavItem {
  label: string;
  path: string;
  icon: string;
}

@Component({
  selector: 'app-staff-shell',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  template: `
    <div class="min-h-screen flex bg-[#f4f6f8] text-[#0f2440]">
      <!-- Deep-green British healthcare navigation sidebar -->
      <aside
        class="w-60 shrink-0 bg-[#0b3d2e] text-white flex flex-col justify-between border-r border-[#06291f] hidden lg:flex"
      >
        <div>
          <div class="px-5 py-4 border-b border-white/10">
            <div class="font-display font-bold text-base tracking-tight whitespace-nowrap">
              TERTIUSMEDICO
            </div>
            <div class="text-xs text-emerald-100/80 mt-0.5 truncate">
              Pennine Community Pharmacy
            </div>
          </div>

          <nav aria-label="Staff primary navigation" class="p-3 space-y-1">
            @for (item of navItems; track item.path) {
              <a
                [routerLink]="item.path"
                routerLinkActive="bg-white/15 text-white font-semibold"
                class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-emerald-50/90 hover:bg-white/10 hover:text-white transition-colors whitespace-nowrap"
              >
                <mat-icon class="!text-lg !w-5 !h-5 opacity-90">{{ item.icon }}</mat-icon>
                <span>{{ item.label }}</span>
              </a>
            }
          </nav>
        </div>

        <div class="p-4 border-t border-white/10 space-y-3 text-xs text-emerald-100/90">
          <div>
            <div class="font-semibold text-white">{{ principal()?.displayName }}</div>
            <div class="capitalize text-emerald-200/80">{{ principal()?.role }} · Branch HX7</div>
          </div>
          <div class="flex flex-col gap-1.5">
            <a
              routerLink="/portal"
              class="inline-flex items-center gap-1.5 text-emerald-100 hover:text-white underline underline-offset-2"
            >
              <mat-icon class="!text-sm !w-4 !h-4">smartphone</mat-icon>
              <span>Preview Patient Portal</span>
            </a>
            <button
              type="button"
              (click)="signOut()"
              class="inline-flex items-center gap-1.5 text-left text-emerald-100 hover:text-white"
            >
              <mat-icon class="!text-sm !w-4 !h-4">logout</mat-icon>
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </aside>

      <!-- Mobile Drawer Backdrop -->
      @if (mobileNavOpen()) {
        <div
          class="fixed inset-0 z-40 bg-black/40 lg:hidden"
          (click)="mobileNavOpen.set(false)"
          aria-hidden="true"
        ></div>
        <aside class="fixed inset-y-0 left-0 z-50 w-64 bg-[#0b3d2e] text-white flex flex-col justify-between p-4 lg:hidden">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
              <span class="font-display font-bold text-base">TERTIUSMEDICO</span>
              <button type="button" (click)="mobileNavOpen.set(false)" aria-label="Close menu">
                <mat-icon>close</mat-icon>
              </button>
            </div>
            <nav class="space-y-1">
              @for (item of navItems; track item.path) {
                <a
                  [routerLink]="item.path"
                  (click)="mobileNavOpen.set(false)"
                  routerLinkActive="bg-white/15 text-white font-semibold"
                  class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-emerald-50 hover:bg-white/10"
                >
                  <mat-icon class="!text-lg !w-5 !h-5">{{ item.icon }}</mat-icon>
                  <span>{{ item.label }}</span>
                </a>
              }
            </nav>
          </div>
          <button
            type="button"
            (click)="signOut()"
            class="flex items-center gap-2 text-sm text-emerald-100 py-2"
          >
            <mat-icon class="!text-lg !w-5 !h-5">logout</mat-icon>
            <span>Sign Out</span>
          </button>
        </aside>
      }

      <!-- Main Workspace Column -->
      <div class="flex-1 min-w-0 flex flex-col">
        <!-- Compact Top Header -->
        <header class="bg-white border-b border-[#d9e2ec] px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div class="flex items-center gap-3 min-w-0">
            <button
              type="button"
              (click)="mobileNavOpen.set(true)"
              class="lg:hidden p-2 rounded-lg border border-[#d9e2ec] text-[#0f2440]"
              aria-label="Open navigation menu"
            >
              <mat-icon class="!text-xl !w-5 !h-5">menu</mat-icon>
            </button>
            <div class="text-xs text-[#486581] flex items-center gap-2 truncate">
              <span class="font-semibold text-[#0f2440]">Independent Prototype</span>
              <span aria-hidden="true">·</span>
              <span>Synthetic NHS England Community Pharmacy Data</span>
            </div>
          </div>

          <div class="flex items-center gap-3 shrink-0">
            <label for="quick-role" class="sr-only">Switch demo staff role</label>
            <select
              id="quick-role"
              [value]="currentUsername()"
              (change)="switchStaffRole($any($event.target).value)"
              class="text-xs border border-[#d9e2ec] rounded-lg px-2.5 py-1.5 bg-[#f4f6f8] text-[#0f2440] font-medium"
            >
              <option value="h.whitaker">Dr. Hannah Whitaker (Pharmacist)</option>
              <option value="l.patel">Liam Patel (ACT)</option>
              <option value="c.bennett">Chloe Bennett (Dispenser)</option>
              <option value="s.khan">Samira Khan (Counter)</option>
              <option value="o.grant">Oliver Grant (Admin)</option>
            </select>
          </div>
        </header>

        <main class="flex-1 p-4 sm:p-6 max-w-[1440px] w-full mx-auto">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
})
export class StaffShell {
  private readonly api = inject(PharmacyApi);
  private readonly router = inject(Router);

  readonly principal = this.api.session;
  readonly mobileNavOpen = signal(false);

  readonly currentUsername = computed(() => {
    const id = this.principal()?.actorId;
    const map: Record<string, string> = {
      'STF-PHARM-01': 'h.whitaker',
      'STF-ACT-01': 'l.patel',
      'STF-DISP-01': 'c.bennett',
      'STF-CNTR-01': 's.khan',
      'STF-ADMIN-01': 'o.grant',
    };
    return (id && map[id]) || 'h.whitaker';
  });

  readonly navItems: NavItem[] = [
    {label: 'Overview', path: '/staff/overview', icon: 'dashboard'},
    {label: 'Prescriptions', path: '/staff/prescriptions', icon: 'receipt_long'},
    {label: 'Dispensing', path: '/staff/dispensing', icon: 'medication'},
    {label: 'Patients', path: '/staff/patients', icon: 'people'},
    {label: 'Stock', path: '/staff/stock', icon: 'inventory_2'},
    {label: 'Orders', path: '/staff/orders', icon: 'local_shipping'},
    {label: 'Services', path: '/staff/services', icon: 'medical_services'},
    {label: 'Deliveries', path: '/staff/deliveries', icon: 'markunread_mailbox'},
    {label: 'Reports', path: '/staff/reports', icon: 'assessment'},
    {label: 'Administration', path: '/staff/administration', icon: 'admin_panel_settings'},
  ];

  async switchStaffRole(username: string): Promise<void> {
    try {
      await this.api.loginStaff(username, 'pennine-demo');
    } catch {
      // Ignore if role switch fails
    }
  }

  async signOut(): Promise<void> {
    await this.api.logout();
    await this.router.navigateByUrl('/sign-in');
  }
}
