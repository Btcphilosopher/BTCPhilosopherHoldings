import {inject} from '@angular/core';
import {type CanActivateFn, Router, type Routes} from '@angular/router';
import {PharmacyApi} from './core/pharmacy-api';

const requireStaffGuard: CanActivateFn = () => {
  const api = inject(PharmacyApi);
  const router = inject(Router);
  if (api.isStaff()) {
    return true;
  }
  return router.parseUrl('/sign-in');
};

const requireAuthGuard: CanActivateFn = () => {
  const api = inject(PharmacyApi);
  const router = inject(Router);
  if (api.isAuthenticated()) {
    return true;
  }
  return router.parseUrl('/sign-in');
};

export const routes: Routes = [
  {
    path: 'sign-in',
    loadComponent: () => import('./auth/sign-in').then((m) => m.SignInPage),
  },
  {
    path: 'staff',
    canActivate: [requireStaffGuard],
    loadComponent: () => import('./staff/staff-shell').then((m) => m.StaffShell),
    children: [
      {
        path: 'overview',
        loadComponent: () => import('./staff/pages/overview-page').then((m) => m.OverviewPage),
      },
      {
        path: 'prescriptions',
        loadComponent: () =>
          import('./staff/pages/prescriptions-page').then((m) => m.PrescriptionsPage),
      },
      {
        path: 'dispensing',
        loadComponent: () =>
          import('./staff/pages/dispensing-page').then((m) => m.DispensingPage),
      },
      {
        path: 'patients',
        loadComponent: () => import('./staff/pages/patients-page').then((m) => m.PatientsPage),
      },
      {
        path: 'stock',
        loadComponent: () => import('./staff/pages/stock-page').then((m) => m.StockPage),
      },
      {
        path: 'orders',
        loadComponent: () => import('./staff/pages/orders-page').then((m) => m.OrdersPage),
      },
      {
        path: 'services',
        loadComponent: () => import('./staff/pages/services-page').then((m) => m.ServicesPage),
      },
      {
        path: 'deliveries',
        loadComponent: () =>
          import('./staff/pages/deliveries-page').then((m) => m.DeliveriesPage),
      },
      {
        path: 'reports',
        loadComponent: () => import('./staff/pages/reports-page').then((m) => m.ReportsPage),
      },
      {
        path: 'administration',
        loadComponent: () => import('./staff/pages/admin-page').then((m) => m.AdminPage),
      },
      {path: '', redirectTo: 'overview', pathMatch: 'full'},
    ],
  },
  {
    path: 'portal',
    canActivate: [requireAuthGuard],
    loadComponent: () => import('./portal/patient-portal').then((m) => m.PatientPortal),
  },
  {path: '', redirectTo: 'sign-in', pathMatch: 'full'},
  {path: '**', redirectTo: 'sign-in'},
];
