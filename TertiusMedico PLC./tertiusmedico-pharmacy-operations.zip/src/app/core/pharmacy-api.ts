import {HttpClient, HttpHeaders} from '@angular/common/http';
import {computed, inject, Injectable, signal} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import type {
  ClinicalKnowledgePreview,
  OrganisationalPolicy,
  OverviewResponse,
  PatientRecord,
  Prescription,
  SessionPrincipal,
  StaffUser,
  StockBatch,
} from './pharmacy.types';

@Injectable({providedIn: 'root'})
export class PharmacyApi {
  private readonly http = inject(HttpClient);

  // Bearer session held strictly in memory (never localStorage/sessionStorage)
  private readonly sessionSignal = signal<SessionPrincipal | null>(null);
  readonly session = this.sessionSignal.asReadonly();
  readonly isAuthenticated = computed(() => this.sessionSignal() !== null);
  readonly isStaff = computed(() => this.sessionSignal()?.actorType === 'staff');
  readonly isPatient = computed(() => this.sessionSignal()?.actorType === 'patient');

  // Persistent Dispensing Context Lock (prevents silent patient switching)
  private readonly lockedRxIdSignal = signal<string | null>(null);
  readonly lockedRxId = this.lockedRxIdSignal.asReadonly();

  setLockedRxId(rxId: string | null): void {
    this.lockedRxIdSignal.set(rxId);
  }

  private authHeaders(): HttpHeaders {
    const token = this.sessionSignal()?.token;
    return token ? new HttpHeaders({Authorization: `Bearer ${token}`}) : new HttpHeaders();
  }

  async getStaffDirectory(): Promise<{staff: StaffUser[]; prototypeHint: string}> {
    return firstValueFrom(
      this.http.get<{staff: StaffUser[]; prototypeHint: string}>('/api/auth/staff-directory'),
    );
  }

  async getPatientDirectory(): Promise<{
    patients: {id: string; internalId: string; fullName: string; dateOfBirth: string; postcode: string}[];
  }> {
    return firstValueFrom(
      this.http.get<{
        patients: {id: string; internalId: string; fullName: string; dateOfBirth: string; postcode: string}[];
      }>('/api/auth/patient-directory'),
    );
  }

  async loginStaff(username: string, passcode: string): Promise<SessionPrincipal> {
    const res = await firstValueFrom(
      this.http.post<{session: SessionPrincipal}>('/api/auth/staff-login', {username, passcode}),
    );
    this.sessionSignal.set(res.session);
    return res.session;
  }

  async loginPatient(patientId: string, dateOfBirth: string, pinLast4: string): Promise<SessionPrincipal> {
    const res = await firstValueFrom(
      this.http.post<{session: SessionPrincipal}>('/api/auth/patient-login', {
        patientId,
        dateOfBirth,
        pinLast4,
      }),
    );
    this.sessionSignal.set(res.session);
    this.lockedRxIdSignal.set(null);
    return res.session;
  }

  async logout(): Promise<void> {
    if (this.sessionSignal()) {
      try {
        await firstValueFrom(this.http.post('/api/auth/logout', {}, {headers: this.authHeaders()}));
      } catch {
        // Ignore network errors on logout
      }
    }
    this.sessionSignal.set(null);
    this.lockedRxIdSignal.set(null);
  }

  getOverview(): Promise<OverviewResponse> {
    return firstValueFrom(this.http.get<OverviewResponse>('/api/overview', {headers: this.authHeaders()}));
  }

  getPrescriptions(): Promise<{prescriptions: Prescription[]; policy: OrganisationalPolicy}> {
    return firstValueFrom(
      this.http.get<{prescriptions: Prescription[]; policy: OrganisationalPolicy}>('/api/prescriptions', {
        headers: this.authHeaders(),
      }),
    );
  }

  intakePrescription(payload: Record<string, unknown>): Promise<{prescription: Prescription}> {
    return firstValueFrom(
      this.http.post<{prescription: Prescription}>('/api/prescriptions/intake', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  matchPatient(rxId: string, patientId: string, verificationNote: string): Promise<{prescription: Prescription}> {
    return firstValueFrom(
      this.http.post<{prescription: Prescription}>(
        `/api/prescriptions/${rxId}/match-patient`,
        {patientId, verificationNote},
        {headers: this.authHeaders()},
      ),
    );
  }

  verifyDocument(rxId: string): Promise<{prescription: Prescription}> {
    return firstValueFrom(
      this.http.post<{prescription: Prescription}>(
        `/api/prescriptions/${rxId}/verify-document`,
        {},
        {headers: this.authHeaders()},
      ),
    );
  }

  cancelPrescription(
    rxId: string,
    idempotencyKey: string,
    reason: string,
  ): Promise<{duplicate: boolean; prescription: Prescription; message: string}> {
    return firstValueFrom(
      this.http.post<{duplicate: boolean; prescription: Prescription; message: string}>(
        `/api/prescriptions/${rxId}/cancel`,
        {idempotencyKey, reason},
        {headers: this.authHeaders()},
      ),
    );
  }

  getClinicalPreview(itemId: string): Promise<{preview: ClinicalKnowledgePreview}> {
    return firstValueFrom(
      this.http.get<{preview: ClinicalKnowledgePreview}>(`/api/items/${itemId}/clinical-preview`, {
        headers: this.authHeaders(),
      }),
    );
  }

  submitClinicalReview(
    itemId: string,
    payload: {
      decision: 'approved' | 'query' | 'rejected';
      clinicalNotes: string;
      amendedDirections?: string;
      amendmentReason?: string;
    },
  ): Promise<{prescription: Prescription; knowledgeResult: ClinicalKnowledgePreview}> {
    return firstValueFrom(
      this.http.post<{prescription: Prescription; knowledgeResult: ClinicalKnowledgePreview}>(
        `/api/items/${itemId}/clinical-review`,
        payload,
        {headers: this.authHeaders()},
      ),
    );
  }

  prepareItem(
    itemId: string,
    payload: {
      qtyToPrepare?: number;
      partialReason?: string;
      barcodeScannedValue: string;
      substitutionNote?: string;
      targetBatchId?: string;
    },
  ): Promise<{prescription: Prescription}> {
    return firstValueFrom(
      this.http.post<{prescription: Prescription}>(`/api/items/${itemId}/prepare`, payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  accuracyCheckItem(
    itemId: string,
    payload: {checkNotes: string; emergencyOverride?: boolean},
  ): Promise<{prescription: Prescription}> {
    return firstValueFrom(
      this.http.post<{prescription: Prescription}>(`/api/items/${itemId}/accuracy-check`, payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  handoverItem(itemId: string, payload: Record<string, unknown>): Promise<{prescription: Prescription}> {
    return firstValueFrom(
      this.http.post<{prescription: Prescription}>(`/api/items/${itemId}/handover`, payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  getPatients(): Promise<{patients: PatientRecord[]}> {
    return firstValueFrom(
      this.http.get<{patients: PatientRecord[]}>('/api/patients', {headers: this.authHeaders()}),
    );
  }

  getPatientDetail(id: string): Promise<{patient: PatientRecord; prescriptions: Prescription[]}> {
    return firstValueFrom(
      this.http.get<{patient: PatientRecord; prescriptions: Prescription[]}>(`/api/patients/${id}`, {
        headers: this.authHeaders(),
      }),
    );
  }

  getCatalogue(): Promise<{products: Record<string, unknown>[]}> {
    return firstValueFrom(
      this.http.get<{products: Record<string, unknown>[]}>('/api/catalogue', {
        headers: this.authHeaders(),
      }),
    );
  }

  getStock(): Promise<{
    batches: StockBatch[];
    movements: Record<string, unknown>[];
    products: Record<string, unknown>[];
  }> {
    return firstValueFrom(
      this.http.get<{
        batches: StockBatch[];
        movements: Record<string, unknown>[];
        products: Record<string, unknown>[];
      }>('/api/stock', {headers: this.authHeaders()}),
    );
  }

  quarantineBatch(batchId: string, reason: string): Promise<{batches: StockBatch[]}> {
    return firstValueFrom(
      this.http.post<{batches: StockBatch[]}>(
        '/api/stock/quarantine',
        {batchId, reason},
        {headers: this.authHeaders()},
      ),
    );
  }

  adjustStock(batchId: string, qtyDelta: number, reason: string): Promise<{batches: StockBatch[]}> {
    return firstValueFrom(
      this.http.post<{batches: StockBatch[]}>(
        '/api/stock/adjust',
        {batchId, qtyDelta, reason},
        {headers: this.authHeaders()},
      ),
    );
  }

  getOrdersAndRecalls(): Promise<{
    orders: Record<string, unknown>[];
    recalls: Record<string, unknown>[];
  }> {
    return firstValueFrom(
      this.http.get<{orders: Record<string, unknown>[]; recalls: Record<string, unknown>[]}>(
        '/api/orders',
        {headers: this.authHeaders()},
      ),
    );
  }

  createOrder(payload: Record<string, unknown>): Promise<{orders: Record<string, unknown>[]}> {
    return firstValueFrom(
      this.http.post<{orders: Record<string, unknown>[]}>('/api/orders', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  approveOrder(id: string): Promise<{orders: Record<string, unknown>[]}> {
    return firstValueFrom(
      this.http.post<{orders: Record<string, unknown>[]}>(
        `/api/orders/${id}/approve`,
        {},
        {headers: this.authHeaders()},
      ),
    );
  }

  receiveOrderGoods(id: string, payload: Record<string, unknown>): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.post<Record<string, unknown>>(`/api/orders/${id}/receive`, payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  createRecall(payload: Record<string, unknown>): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.post<Record<string, unknown>>('/api/recalls', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  reviewRecallPatient(recallId: string, patientId: string, decisionNote: string): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.post<Record<string, unknown>>(
        `/api/recalls/${recallId}/review-patient`,
        {patientId, decisionNote},
        {headers: this.authHeaders()},
      ),
    );
  }

  getCdRegister(): Promise<{entries: Record<string, unknown>[]; disclaimer: string}> {
    return firstValueFrom(
      this.http.get<{entries: Record<string, unknown>[]; disclaimer: string}>('/api/cd-register', {
        headers: this.authHeaders(),
      }),
    );
  }

  postCdCorrection(payload: Record<string, unknown>): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>('/api/cd-register/correction', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  getColdChain(): Promise<{logs: Record<string, unknown>[]}> {
    return firstValueFrom(
      this.http.get<{logs: Record<string, unknown>[]}>('/api/cold-chain', {
        headers: this.authHeaders(),
      }),
    );
  }

  logTemperature(payload: {temperatureC: number; location?: string; source?: string}): Promise<{
    excursion: boolean;
    logs: Record<string, unknown>[];
  }> {
    return firstValueFrom(
      this.http.post<{excursion: boolean; logs: Record<string, unknown>[]}>('/api/cold-chain', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  getServices(): Promise<{
    services: Record<string, unknown>[];
    appointments: Record<string, unknown>[];
  }> {
    return firstValueFrom(
      this.http.get<{services: Record<string, unknown>[]; appointments: Record<string, unknown>[]}>(
        '/api/services',
        {headers: this.authHeaders()},
      ),
    );
  }

  bookAppointment(payload: Record<string, unknown>): Promise<{ok: boolean; id: string}> {
    return firstValueFrom(
      this.http.post<{ok: boolean; id: string}>('/api/services/appointments', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  updateAppointment(id: string, payload: Record<string, unknown>): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(`/api/services/appointments/${id}/update`, payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  getDeliveries(): Promise<{deliveries: Record<string, unknown>[]}> {
    return firstValueFrom(
      this.http.get<{deliveries: Record<string, unknown>[]}>('/api/deliveries', {
        headers: this.authHeaders(),
      }),
    );
  }

  confirmDelivery(id: string, recipientChecked: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        `/api/deliveries/${id}/confirm`,
        {recipientChecked},
        {headers: this.authHeaders()},
      ),
    );
  }

  getNotifications(): Promise<{notifications: Record<string, unknown>[]}> {
    return firstValueFrom(
      this.http.get<{notifications: Record<string, unknown>[]}>('/api/notifications', {
        headers: this.authHeaders(),
      }),
    );
  }

  retryNotification(id: string, overrideChannel?: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        `/api/notifications/${id}/retry`,
        {overrideChannel},
        {headers: this.authHeaders()},
      ),
    );
  }

  getReports(): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.get<Record<string, unknown>>('/api/reports', {headers: this.authHeaders()}),
    );
  }

  getPolicy(): Promise<{
    policy: OrganisationalPolicy;
    adapters: unknown[];
    staff: StaffUser[];
  }> {
    return firstValueFrom(
      this.http.get<{policy: OrganisationalPolicy; adapters: unknown[]; staff: StaffUser[]}>(
        '/api/policy',
        {headers: this.authHeaders()},
      ),
    );
  }

  updatePolicy(payload: Partial<OrganisationalPolicy>): Promise<{policy: OrganisationalPolicy}> {
    return firstValueFrom(
      this.http.post<{policy: OrganisationalPolicy}>('/api/policy', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  runDemoStep(step: number): Promise<{step: number; title: string; detail: string; status: string}> {
    return firstValueFrom(
      this.http.post<{step: number; title: string; detail: string; status: string}>(
        `/api/demo/step/${step}`,
        {},
        {headers: this.authHeaders()},
      ),
    );
  }

  resetDemo(): Promise<{ok: boolean; message: string}> {
    return firstValueFrom(
      this.http.post<{ok: boolean; message: string}>(
        '/api/demo/reset',
        {},
        {headers: this.authHeaders()},
      ),
    );
  }

  runWorker(): Promise<{summary: {ranAt: string; notificationsProcessed: number; expiredBatchesFlagged: number}}> {
    return firstValueFrom(
      this.http.post<{summary: {ranAt: string; notificationsProcessed: number; expiredBatchesFlagged: number}}>(
        '/api/worker/run',
        {},
        {headers: this.authHeaders()},
      ),
    );
  }

  // --- Patient Portal ---
  getPortalData(patientId?: string): Promise<Record<string, unknown>> {
    const q = patientId ? `?patientId=${encodeURIComponent(patientId)}` : '';
    return firstValueFrom(
      this.http.get<Record<string, unknown>>(`/api/portal/me${q}`, {headers: this.authHeaders()}),
    );
  }

  submitRepeatRequest(payload: Record<string, unknown>): Promise<{ok: boolean; id: string}> {
    return firstValueFrom(
      this.http.post<{ok: boolean; id: string}>('/api/portal/repeat-requests', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  updatePortalCollectionOption(prescriptionId: string, collectionOption: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        '/api/portal/collection-option',
        {prescriptionId, collectionOption},
        {headers: this.authHeaders()},
      ),
    );
  }

  bookPortalAppointment(payload: Record<string, unknown>): Promise<{ok: boolean; id: string}> {
    return firstValueFrom(
      this.http.post<{ok: boolean; id: string}>('/api/portal/appointments', payload, {
        headers: this.authHeaders(),
      }),
    );
  }

  updatePortalPreferences(preferredContact: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        '/api/portal/preferences',
        {preferredContact},
        {headers: this.authHeaders()},
      ),
    );
  }
}
