export type StaffRole = 'pharmacist' | 'act' | 'dispenser' | 'counter' | 'admin';

export interface SessionPrincipal {
  token: string;
  actorType: 'staff' | 'patient';
  actorId: string;
  role: StaffRole | 'patient';
  displayName: string;
  expiresAt: string;
}

export interface StaffUser {
  id: string;
  username: string;
  displayName: string;
  role: StaffRole;
  gphcNumber: string | null;
  branchId: string;
  active: boolean;
}

export interface OrganisationalPolicy {
  id: string;
  organisationName: string;
  branchName: string;
  odsCode: string;
  jurisdiction: string;
  requireSeparatePreparerAndChecker: boolean;
  requireSeparateClinicalAndAccuracyChecker: boolean;
  allowEmergencySelfCheckOverride: boolean;
  requirePatientIdCheckOnHandover: boolean;
  clinicalAdapterAvailable: boolean;
  clinicalAdapterVersion: string;
  dmdCatalogVersion: string;
  updatedAt: string;
  updatedBy: string;
}

export interface PatientAllergy {
  id: string;
  substance: string;
  reaction: string;
  severity: 'mild' | 'moderate' | 'severe';
  source: string;
  verificationStatus: 'verified' | 'unverified';
  recordedAt: string;
}

export interface AuthorisedRepresentative {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  idVerificationRequired: boolean;
  verifiedByStaff: boolean;
}

export interface PatientRecord {
  id: string;
  internalId: string;
  nhsNumber: string | null;
  nhsNumberVerified: boolean;
  fullName: string;
  dateOfBirth: string;
  postcode: string;
  addressLine1: string;
  city: string;
  phone: string;
  email: string;
  preferredContact: 'sms' | 'email' | 'phone' | 'portal';
  accessibilityNeeds: string[];
  allergyStatus: 'recorded' | 'no_known_allergies' | 'unavailable';
  allergies: PatientAllergy[];
  exemptionStatus: string;
  exemptionReference: string | null;
  authorisedRepresentatives: AuthorisedRepresentative[];
  externalReferences: Record<string, string>;
  portalPinLast4: string;
}

export interface PrescriptionItem {
  id: string;
  prescriptionId: string;
  productId: string;
  prescribedMedicineText: string;
  selectedProductName: string;
  strength: string;
  form: string;
  directionsAsReceived: string;
  directionsAmended: string | null;
  amendmentReason: string | null;
  prescribedQty: number;
  preparedQty: number;
  suppliedQty: number;
  outstandingQty: number;
  cancelledQty: number;
  unit: string;
  legalCategory: string;
  status: string;
  allocatedBatchId: string | null;
  allocatedBatchNumber: string | null;
  allocatedExpiryDate: string | null;
  barcodeVerified: boolean;
  barcodeScannedAt: string | null;
  barcodeScannedValue: string | null;
  clinicalDecision: 'pending' | 'approved' | 'query' | 'rejected';
  clinicalReviewedBy: string | null;
  clinicalReviewedAt: string | null;
  clinicalNotes: string | null;
  clinicalAdapterUsed: string | null;
  clinicalAdapterStatusAtReview: 'available' | 'unavailable' | null;
  preparedBy: string | null;
  preparedAt: string | null;
  checkedBy: string | null;
  checkedAt: string | null;
  handedOverBy: string | null;
  handedOverAt: string | null;
  labelGeneratedAt: string | null;
  substitutionRecorded: string | null;
  partialReason: string | null;
  owingExpiryDate: string | null;
}

export interface Prescription {
  id: string;
  prescriptionId: string;
  sourceIdentifier: string;
  sourceSystem: string;
  patientId: string | null;
  patientReference: string;
  matchStatus: 'matched' | 'unmatched' | 'ambiguous_review';
  prescriberDetails: string;
  issueDate: string;
  receivedAt: string;
  status: string;
  version: number;
  provenance: string;
  verificationRequired: boolean;
  documentVerifiedBy: string | null;
  documentVerifiedAt: string | null;
  attachmentId: string | null;
  deliveryRequested: boolean;
  collectionOption: string;
  exemptionOrChargeStatus: string;
  chargeTotalPence: number;
  paymentStatus: string;
  sourcePayloadJson: string;
  items: PrescriptionItem[];
  patientSummary?: {
    id: string;
    internalId: string;
    fullName: string;
    nhsNumber: string | null;
    nhsNumberVerified: boolean;
    dateOfBirth: string;
    allergyStatus: 'recorded' | 'no_known_allergies' | 'unavailable';
    allergiesCount: number;
  } | null;
}

export interface ClinicalKnowledgePreview {
  adapterName: string;
  adapterVersion: string;
  available: boolean;
  coverage: string;
  checkedAt: string;
  alerts: {
    severity: 'critical' | 'amber' | 'info';
    category: string;
    message: string;
    sourceRef: string;
  }[];
  safetyStatement: string;
}

export interface StockBatch {
  id: string;
  branchId: string;
  location: string;
  productId: string;
  batchNumber: string;
  expiryDate: string;
  physicalQty: number;
  reservedQty: number;
  availableQty: number;
  state: 'available' | 'quarantined' | 'recalled' | 'expired' | 'disposed';
  unit: string;
  costPencePerPack: number;
  receivedAt: string;
  quarantineReason: string | null;
  productName: string;
  barcodeEan13: string;
}

export interface ExternalAdapterStatus {
  id: string;
  name: string;
  mode: 'SIMULATED' | 'DEFERRED';
  version: string;
  authoritativeSource: string;
  authMechanism: string;
  coverage: string;
  available: boolean;
  retryAndIdempotencyPolicy: string;
  disclaimer: string;
}

export interface OverviewResponse {
  policy: OrganisationalPolicy;
  stageCounts: Record<string, number>;
  totalPrescriptions: number;
  unmatchedCount: number;
  unverifiedDocumentsCount: number;
  failedNotificationsCount: number;
  expiredBatchesCount: number;
  quarantinedOrRecalledCount: number;
  lowStockProductsCount: number;
  openRecallsCount: number;
  upcomingAppointmentsCount: number;
  adapters: ExternalAdapterStatus[];
}
