# TERTIUSMEDICO — Pharmacy Operations: Architecture & Capability Matrix

**Status**: Independent Prototype (Synthetic Data Only — Pennine Community Pharmacy, England)

## 1. Capability Classification

### Implemented & Live in Running Application (Angular 21 + Express + SQLite)
- **Staff Operations Workspace** (`Overview`, `Prescriptions`, `Dispensing`, `Patients`, `Stock`, `Orders`, `Services`, `Deliveries`, `Reports`, `Administration`)
- **Mobile-Optimised Patient Portal** (`Prescriptions`, `Requests`, `Appointments`, `Messages`, `Collection`, `Account`) with thumb-zone bottom bar and strict patient isolation
- **Organisational Auth & RBAC**: `scrypt` password hashing, in-memory `Authorization: Bearer` sessions, role-separated permissions (`pharmacist`, `act`, `dispenser`, `counter`, `admin`), configurable preparer/checker and clinical/accuracy separation
- **Relational Persistence & Concurrency**: `node:sqlite` (`DatabaseSync`) with schema migrations and `BEGIN IMMEDIATE` transactions preventing double-allocation of physical stock
- **Prescription Lifecycle**: Intake (`NHS_EPS_SIM`, `MANUAL_DEMO`, `UPLOADED_DOCUMENT` verification gate), duplicate detection, explicit patient matching (no auto-merge), immutable `source_payload_json`, 11 explicit workflow stages, partial supplies, owing balances, and idempotent cancellation handling
- **Stock, CD2 & Cold Chain**: Batch/expiry FEFO excluding `expired`, `quarantined`, `recalled`, `disposed`; goods receipt with short-delivery and damaged-stock quarantine; MHRA-style recall batch quarantine & patient review tasks; append-only CD2 demonstration register; 2–8°C fridge excursion auto-quarantine
- **Governance & Audit**: Redacted immutable `audit_events` log, DCB0129/DCB0160 Prototype Hazard Log, 14-Step Reproducible Demonstration Runner, and automated Vitest test suite

### Companion Target-Stack Deliverables (`/platform/`)
- `platform/docker-compose.yml` (PostgreSQL 16 + FastAPI API + background worker services)
- `platform/fastapi/main.py` & `platform/fastapi/migrations/001_initial_schema.sql`

### Simulated External Adapters
- **NHS EPS FHIR R4 / PDS FHIR / dm+d Release 2026.11**: Local versioned synthetic fixtures
- **Clinical Knowledge & Decision Support (`UK-BNF-Demo-Adapter v2026.11`)**: Synthetic penicillin cross-sensitivity & CD2/insulin checks with toggleable `UNAVAILABLE` mode
- **Wholesaler EDI, NHS Notify Messaging, Card Terminal, NHSBSA FP34C Export, ZPL/EAN-13 Printer/Scanner**: Local simulation with `DEMONSTRATION — NOT FOR DISPENSING` label banner

### Deferred for Regulated Production Deployment
- Live NHS HSCN / CIS2 smartcard OAuth2 authentication and mTLS Spine connectivity
- Live NHSBSA TRUD dm+d weekly sync and Manage Your Service (MYS) FP34C submission
- Licensed commercial clinical decision support engine (BNF/FDB)
- Formal GPhC premises registration & DCB0129 / DCB0160 Clinical Safety Officer sign-off
