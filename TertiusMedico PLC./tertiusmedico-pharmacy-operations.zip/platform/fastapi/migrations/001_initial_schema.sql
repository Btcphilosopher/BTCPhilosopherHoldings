-- PostgreSQL Reference Migration 001 for TERTIUSMEDICO — Pharmacy Operations
-- Mirrors the live SQLite schema used by the Angular + Express prototype.

CREATE TABLE IF NOT EXISTS org_policy (
  id TEXT PRIMARY KEY,
  organisation_name TEXT NOT NULL,
  branch_name TEXT NOT NULL,
  ods_code TEXT NOT NULL,
  jurisdiction TEXT NOT NULL,
  require_separate_preparer_and_checker BOOLEAN NOT NULL DEFAULT TRUE,
  require_separate_clinical_and_accuracy_checker BOOLEAN NOT NULL DEFAULT FALSE,
  allow_emergency_self_check_override BOOLEAN NOT NULL DEFAULT FALSE,
  clinical_adapter_available BOOLEAN NOT NULL DEFAULT TRUE,
  clinical_adapter_version TEXT NOT NULL,
  dmd_catalog_version TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS patients (
  id TEXT PRIMARY KEY,
  internal_id TEXT UNIQUE NOT NULL,
  nhs_number TEXT,
  nhs_number_verified BOOLEAN NOT NULL DEFAULT FALSE,
  full_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  postcode TEXT NOT NULL,
  allergy_status TEXT NOT NULL CHECK (allergy_status IN ('recorded', 'no_known_allergies', 'unavailable')),
  allergies_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  exemption_status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS medicine_products (
  id TEXT PRIMARY KEY,
  vtm_name TEXT NOT NULL,
  vmp_code TEXT NOT NULL,
  amp_code TEXT,
  vmpp_code TEXT NOT NULL,
  ampp_code TEXT,
  prescribed_name TEXT NOT NULL,
  dispensable_product_name TEXT NOT NULL,
  strength TEXT NOT NULL,
  pharmaceutical_form TEXT NOT NULL,
  pack_size INTEGER NOT NULL,
  quantity_unit TEXT NOT NULL,
  legal_category TEXT NOT NULL,
  barcode_ean13 TEXT NOT NULL,
  dmd_version TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stock_batches (
  id TEXT PRIMARY KEY,
  branch_id TEXT NOT NULL,
  location TEXT NOT NULL,
  product_id TEXT NOT NULL REFERENCES medicine_products(id),
  batch_number TEXT NOT NULL,
  expiry_date DATE NOT NULL,
  physical_qty INTEGER NOT NULL CHECK (physical_qty >= 0),
  reserved_qty INTEGER NOT NULL DEFAULT 0 CHECK (reserved_qty >= 0),
  state TEXT NOT NULL CHECK (state IN ('available', 'quarantined', 'recalled', 'expired', 'disposed')),
  unit TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS prescriptions (
  id TEXT PRIMARY KEY,
  prescription_id TEXT UNIQUE NOT NULL,
  source_identifier TEXT NOT NULL,
  source_system TEXT NOT NULL,
  patient_id TEXT REFERENCES patients(id),
  match_status TEXT NOT NULL,
  status TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  source_payload_json JSONB NOT NULL,
  UNIQUE (source_system, source_identifier, version)
);
