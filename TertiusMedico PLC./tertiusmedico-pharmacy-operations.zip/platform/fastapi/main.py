"""TERTIUSMEDICO — Pharmacy Operations (FastAPI Companion Service)

Provides a typed FastAPI reference surface mirroring the live Express + SQLite
modular monolith endpoints running in the AI Studio preview environment.
"""

from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(
    title="TERTIUSMEDICO — Pharmacy Operations API (Reference Companion)",
    version="0.1.0-prototype",
    description="Independent prototype for UK community pharmacy workflows (synthetic data only).",
)


class HealthStatus(BaseModel):
    status: str
    prototype: bool
    organisation: str
    timestamp: str


@app.get("/api/health", response_model=HealthStatus)
def health() -> HealthStatus:
    return HealthStatus(
        status="ok",
        prototype=True,
        organisation="TERTIUSMEDICO — Pennine Community Pharmacy (Reference FastAPI)",
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@app.get("/api/charge-rules")
def charge_rules() -> dict:
    return {
        "effective_from": "2024-05-01",
        "jurisdiction": "England",
        "nhs_charge_per_item_pence": 990,
        "ppc_3_month_pence": 3205,
        "ppc_12_month_pence": 11450,
        "hrt_ppc_12_month_pence": 1980,
    }
