-- Aureom Clinical — Synthetic Clinic Seed Data (PostgreSQL)
-- Fictional English Organisation: Thames Valley Integrated Care Clinic (ODS: Y99001 - Synthetic)
-- All NHS Numbers are synthetic test numbers with valid Modulus-11 check digits (999-xxx-xxxx reserved test range).
-- Zero real patient data.

INSERT INTO roles (code, display_name, permissions_json) VALUES
('consultant_physician', 'Consultant Physician', '["patient.read","patient.write","patient.merge","encounter.write","note.write","note.sign","note.amend","allergy.write","medication.prescribe","result.review","task.write","document.write","audit.read_own","ai.assist"]'),
('specialty_registrar', 'Specialty Registrar', '["patient.read","patient.write","encounter.write","note.write","note.sign","note.amend","allergy.write","medication.prescribe","result.review","task.write","document.write","ai.assist"]'),
('ward_nurse', 'Senior Ward Nurse', '["patient.read","encounter.read","note.write","allergy.write","medication.administer","observation.write","result.view","task.write","document.read"]'),
('clinical_admin', 'Clinical Records Administrator', '["patient.read","patient.write","patient.merge","encounter.write","document.write","task.write"]'),
('caldicott_guardian', 'Caldicott Guardian / IG Lead', '["patient.read","audit.read_all","break_glass.review","retention.manage","ai.configure","fhir.manage"]');

INSERT INTO organisations (id, ods_code, name, org_type, country, ai_assistant_enabled, config_json) VALUES
('11111111-1111-1111-1111-111111111111', 'Y99001', 'Thames Valley Integrated Care Clinic (Synthetic)', 'community_provider', 'GB-ENG', FALSE, '{"nhs_number_validation":"mod11","fhir_profile":"UKCore-R4","timezone":"Europe/London"}');

INSERT INTO locations (id, organisation_id, code, name, location_type) VALUES
('22222222-2222-2222-2222-222222222201', '11111111-1111-1111-1111-111111111111', 'TV-OPD-1', 'Reading Medical Outpatients Suite', 'outpatient_clinic'),
('22222222-2222-2222-2222-222222222202', '11111111-1111-1111-1111-111111111111', 'TV-WARD-A', 'Kennet Acute Assessment Unit', 'ward');

INSERT INTO users (id, organisation_id, username, email, full_name, professional_reg_no, role_code, mfa_enrolled) VALUES
('33333333-3333-3333-3333-333333333301', '11111111-1111-1111-1111-111111111111', 'e.whitaker', 'e.whitaker@thamesvalley.example.nhs.uk', 'Dr Eleanor Whitaker', 'GMC-6140928', 'consultant_physician', TRUE),
('33333333-3333-3333-3333-333333333302', '11111111-1111-1111-1111-111111111111', 'r.patel', 'r.patel@thamesvalley.example.nhs.uk', 'Dr Rohan Patel', 'GMC-7429104', 'specialty_registrar', TRUE),
('33333333-3333-3333-3333-333333333303', '11111111-1111-1111-1111-111111111111', 'h.okafor', 'h.okafor@thamesvalley.example.nhs.uk', 'Hannah Okafor RN', 'NMC-18B0412E', 'ward_nurse', TRUE),
('33333333-3333-3333-3333-333333333304', '11111111-1111-1111-1111-111111111111', 'm.bennett', 'm.bennett@thamesvalley.example.nhs.uk', 'Marcus Bennett', NULL, 'clinical_admin', TRUE),
('33333333-3333-3333-3333-333333333305', '11111111-1111-1111-1111-111111111111', 's.aldridge', 's.aldridge@thamesvalley.example.nhs.uk', 'Sarah Aldridge (Caldicott)', 'IG-900412', 'caldicott_guardian', TRUE);
