import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { getDb } from './server/db.ts';
import { registerRoutes } from './server/routes.ts';

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT || 3000);

  app.set('trust proxy', true);
  app.use(express.json({ limit: '2mb' }));

  const db = getDb();
  registerRoutes(app, db);

  // Background Outbox Reconciliation Worker (runs every 30s)
  const outboxTimer = setInterval(() => {
    try {
      const pending = db
        .prepare("SELECT id, attempts FROM integration_outbox_events WHERE delivery_status = 'pending' LIMIT 10")
        .all() as Array<{ id: string; attempts: number }>;
      for (const evt of pending) {
        db.prepare("UPDATE integration_outbox_events SET delivery_status = 'dispatched', attempts = ? WHERE id = ?").run(
          evt.attempts + 1,
          evt.id
        );
      }
    } catch {
      // keep worker resilient
    }
  }, 30000);
  outboxTimer.unref();

  const distDir = path.resolve(process.cwd(), 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distDir);

  if (isProd) {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Aureom Clinical server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Aureom Clinical server:', err);
  process.exit(1);
});
