#!/usr/bin/env bash
set -euo pipefail

# Aureom Clinical — PostgreSQL & Protected Attachment Backup + Isolated Restoration Drill
# Measures Recovery Time Objective (RTO) and verifies database integrity & row counts.

DB_URL="${DATABASE_URL:-postgres://aureom:change_me_local_only@localhost:5432/aureom_clinical}"
ISOLATED_DB="aureom_restore_verify_$(date +%s)"
BACKUP_DIR="./data/pg_backups/$(date +%Y%m%d_%H%M%S)"
STORAGE_SRC="${AUREOM_STORAGE_DIR:-./data/object_storage}"

mkdir -p "${BACKUP_DIR}"
START_NS=$(date +%s%N)

echo "[1/4] Taking consistent pg_dump custom-format snapshot..."
pg_dump "${DB_URL}" --format=custom --file="${BACKUP_DIR}/aureom.dump"

echo "[2/4] Archiving protected object storage with SHA-256 manifest..."
if [ -d "${STORAGE_SRC}" ]; then
  cp -a "${STORAGE_SRC}" "${BACKUP_DIR}/object_storage"
  (cd "${BACKUP_DIR}/object_storage" && find . -type f -exec sha256sum {} + > ../attachments.sha256)
fi

echo "[3/4] Restoring into isolated PostgreSQL database '${ISOLATED_DB}'..."
createdb "${ISOLATED_DB}"
pg_restore --dbname="${ISOLATED_DB}" --no-owner --exit-on-error "${BACKUP_DIR}/aureom.dump"

echo "[4/4] Verifying row counts and attachment checksums..."
psql "${ISOLATED_DB}" -c "SELECT 'patients' AS tbl, COUNT(*) FROM patients UNION ALL SELECT 'clinical_notes', COUNT(*) FROM clinical_notes UNION ALL SELECT 'audit_events', COUNT(*) FROM audit_events;"
if [ -f "${BACKUP_DIR}/attachments.sha256" ]; then
  (cd "${BACKUP_DIR}/object_storage" && sha256sum -c ../attachments.sha256)
fi

dropdb "${ISOLATED_DB}"
END_NS=$(date +%s%N)
RTO_MS=$(( (END_NS - START_NS) / 1000000 ))
echo "Isolated restoration drill PASSED. Measured RTO: ${RTO_MS} ms (Target RTO <= 900000 ms)."
