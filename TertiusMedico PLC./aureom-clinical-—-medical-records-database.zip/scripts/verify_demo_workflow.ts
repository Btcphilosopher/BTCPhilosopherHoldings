import assert from 'node:assert/strict';
import fs from 'node:fs';
import express from 'express';
import { openClinicalDatabase } from '../server/db.ts';
import { registerRoutes } from '../server/routes.ts';
import { PATIENT_IDS, seedClinicData, USER_IDS } from '../server/seedData.ts';
import { makeSyntheticNhsNumber } from '../server/nhsNumber.ts';

async function runVerification() {
  const testDbPath = './data/verify_test_run.sqlite';
  if (fs.existsSync(testDbPath)) fs.rmSync(testDbPath);
  const db = openClinicalDatabase(testDbPath);
  seedClinicData(db);

  const app = express();
  app.use(express.json());
  registerRoutes(app, db);

  const server = await new Promise<import('node:http').Server>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address() as { port: number };
  const base = `http://127.0.0.1:${addr.port}`;

  async function req(path: string, opts: RequestInit = {}, token?: string) {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${base}${path}`, { ...opts, headers });
    const body = await res.json().catch(() => ({}));
    return { status: res.status, body };
  }

  try {
    console.log('--- Running Aureom Clinical End-to-End Verification Suite ---');

    // 0. Reject unauthenticated request
    const unauth = await req('/api/patients');
    assert.equal(unauth.status, 401, 'Unauthenticated requests must return 401');
    console.log('[PASS] Unauthorised request rejected (401)');

    // Sign in as Consultant & Nurse & Caldicott Guardian
    const loginCon = await req('/api/auth/login', { method: 'POST', body: JSON.stringify({ userId: USER_IDS.consultant, otpCode: '482910' }) });
    assert.equal(loginCon.status, 200);
    const conToken = loginCon.body.token as string;

    const loginNurse = await req('/api/auth/login', { method: 'POST', body: JSON.stringify({ userId: USER_IDS.nurse, otpCode: '482910' }) });
    assert.equal(loginNurse.status, 200);
    const nurseToken = loginNurse.body.token as string;

    const loginCald = await req('/api/auth/login', { method: 'POST', body: JSON.stringify({ userId: USER_IDS.caldicott, otpCode: '482910' }) });
    assert.equal(loginCald.status, 200);
    const caldToken = loginCald.body.token as string;

    // 1. Register a patient with valid Mod-11 NHS number
    const newNhs = makeSyntheticNhsNumber('999000007');
    const reg = await req(
      '/api/patients',
      {
        method: 'POST',
        body: JSON.stringify({
          givenNames: 'Beatrice',
          familyName: 'Hawthorne',
          birthDate: '1967-07-14',
          administrativeGender: 'female',
          nhsNumber: newNhs,
          addressLine1: '19 Bath Road',
          postcode: 'RG1 6HH',
          allergyAssessmentStatus: 'not_assessed',
        }),
      },
      conToken
    );
    assert.equal(reg.status, 201);
    const newPatientId = reg.body.id as string;
    console.log('[PASS] 1. Registered synthetic patient with Mod-11 NHS check:', reg.body.internalMrn);

    // 2. Open an encounter
    const encList = await req(`/api/encounters?patientId=${newPatientId}`, {}, conToken);
    const locationId = encList.body.locations[0].id as string;
    const enc = await req(
      '/api/encounters',
      { method: 'POST', body: JSON.stringify({ patientId: newPatientId, locationId, encounterClass: 'outpatient', reasonText: 'Initial cardiology review' }) },
      conToken
    );
    assert.equal(enc.status, 201);
    const encounterId = enc.body.id as string;
    console.log('[PASS] 2. Opened encounter:', encounterId);

    // 3. Record observation and allergy
    const obs = await req(
      `/api/patients/${newPatientId}/observations`,
      { method: 'POST', body: JSON.stringify({ encounterId, displayName: 'Systolic blood pressure', valueNumeric: 138, unit: 'mmHg', refRangeLow: 90, refRangeHigh: 139 }) },
      nurseToken
    );
    assert.equal(obs.status, 201);
    const alg = await req(
      `/api/patients/${newPatientId}/allergies`,
      { method: 'POST', body: JSON.stringify({ encounterId, substanceName: 'Trimethoprim', reactionManifestation: 'Maculopapular rash', severity: 'moderate' }) },
      conToken
    );
    assert.equal(alg.status, 201);
    console.log('[PASS] 3. Recorded observation & allergy');

    // 4. Write draft note, test optimistic concurrency conflict (409), test duplicate-safe signing
    const note = await req(
      '/api/notes',
      { method: 'POST', body: JSON.stringify({ patientId: newPatientId, encounterId, noteType: 'consultation', title: 'Initial Consultation', bodyText: 'Draft v1 findings' }) },
      conToken
    );
    assert.equal(note.status, 201);
    const noteId = note.body.id as string;

    const saveOk = await req(
      `/api/notes/${noteId}/draft`,
      { method: 'PUT', body: JSON.stringify({ title: 'Initial Consultation', bodyText: 'Updated findings v2', expectedVersion: 1 }) },
      conToken
    );
    assert.equal(saveOk.status, 200);
    assert.equal(saveOk.body.currentVersion, 2);

    const saveConflict = await req(
      `/api/notes/${noteId}/draft`,
      { method: 'PUT', body: JSON.stringify({ title: 'Stale', bodyText: 'Stale overwrite', expectedVersion: 1 }) },
      conToken
    );
    assert.equal(saveConflict.status, 409, 'Stale version must trigger 409 Conflict');

    const signKey = `idem-${noteId}`;
    const sign1 = await req(
      `/api/notes/${noteId}/sign`,
      { method: 'POST', body: JSON.stringify({ expectedVersion: 2, idempotencyKey: signKey, attestationStatement: 'Clinically attested' }) },
      conToken
    );
    assert.equal(sign1.status, 200);

    const sign2 = await req(
      `/api/notes/${noteId}/sign`,
      { method: 'POST', body: JSON.stringify({ expectedVersion: 2, idempotencyKey: signKey, attestationStatement: 'Clinically attested' }) },
      conToken
    );
    assert.equal(sign2.status, 200);
    assert.equal(sign2.body.duplicateSafeReplay, true);

    const mutateSigned = await req(
      `/api/notes/${noteId}/draft`,
      { method: 'PUT', body: JSON.stringify({ title: 'Tamper', bodyText: 'Tamper', expectedVersion: 2 }) },
      conToken
    );
    assert.equal(mutateSigned.status, 409, 'Signed notes must be immutable');
    console.log('[PASS] 4. Consultation note concurrency conflict (409), duplicate-safe signing & immutability verified');

    // 5. Add attributed amendment
    const amd = await req(
      `/api/notes/${noteId}/amendments`,
      { method: 'POST', body: JSON.stringify({ amendmentType: 'addendum', reason: 'Post-clinic echo review', addendumText: 'Echocardiogram shows preserved LVEF 58%.' }) },
      conToken
    );
    assert.equal(amd.status, 201);
    console.log('[PASS] 5. Added attributed addendum amendment');

    // 6 & 7. Import diagnostic result + duplicate message + corrected version
    const fhir1 = await req(
      '/api/fhir/ingest',
      {
        method: 'POST',
        body: JSON.stringify({
          resourceType: 'Bundle',
          id: 'verify-msg-001',
          entry: [{ resource: { resourceType: 'DiagnosticReport', id: 'LIS-V1', status: 'preliminary', code: { text: 'Lipid Panel' }, subject: { reference: `Patient/${newPatientId}` }, conclusion: 'LDL 3.9 mmol/L' } }],
        }),
      },
      conToken
    );
    assert.equal(fhir1.status, 200);
    assert.equal(fhir1.body.status, 'processed');

    const fhirDup = await req(
      '/api/fhir/ingest',
      {
        method: 'POST',
        body: JSON.stringify({
          resourceType: 'Bundle',
          id: 'verify-msg-001',
          entry: [{ resource: { resourceType: 'DiagnosticReport', id: 'LIS-V1', status: 'preliminary', code: { text: 'Lipid Panel' }, subject: { reference: `Patient/${newPatientId}` }, conclusion: 'LDL 3.9 mmol/L' } }],
        }),
      },
      conToken
    );
    assert.equal(fhirDup.body.status, 'duplicate_ignored');

    const fhirCorr = await req(
      '/api/fhir/ingest',
      {
        method: 'POST',
        body: JSON.stringify({
          resourceType: 'Bundle',
          id: 'verify-msg-002',
          entry: [{ resource: { resourceType: 'DiagnosticReport', id: 'LIS-V1-C', status: 'corrected', replacesReference: 'LIS-V1', correctionReason: 'Recalculated Friedewald LDL', code: { text: 'Lipid Panel' }, subject: { reference: `Patient/${newPatientId}` }, conclusion: 'Corrected LDL 3.5 mmol/L' } }],
        }),
      },
      conToken
    );
    assert.equal(fhirCorr.status, 200);
    const correctedResultId = fhirCorr.body.createdResultIds[0] as string;
    console.log('[PASS] 6 & 7. Imported diagnostic result, suppressed duplicate bundle, and linked corrected result');

    // 8. Assign follow-up on result
    const rev = await req(
      `/api/results/${correctedResultId}/review`,
      { method: 'POST', body: JSON.stringify({ reviewState: 'assigned_for_followup', followUpTitle: 'Discuss statin therapy', followUpInstructions: 'Review corrected LDL 3.5 mmol/L' }) },
      conToken
    );
    assert.equal(rev.status, 200);
    assert.ok(rev.body.createdTaskId);
    console.log('[PASS] 8. Assigned follow-up task linked to corrected result');

    // 9. Search timeline & test zero search leakage on restricted patient Clara
    const timeline = await req(`/api/patients/${newPatientId}/timeline?categories=notes,results`, {}, conToken);
    assert.equal(timeline.status, 200);
    assert.ok(timeline.body.timeline.length >= 2);

    const nurseRestrictedView = await req(`/api/patients/${PATIENT_IDS.clara}`, {}, nurseToken);
    assert.equal(nurseRestrictedView.status, 403, 'Nurse without Break-Glass must be denied restricted safeguarding record');

    const nurseLeakSearch = await req('/api/search?q=perinatal', {}, nurseToken);
    assert.equal(nurseLeakSearch.body.totalCount, 0, 'Zero search leakage: nurse search must return 0 hits for restricted keyword');

    const conSearch = await req('/api/search?q=perinatal', {}, conToken);
    assert.ok(conSearch.body.totalCount >= 1, 'Authorised consultant sees restricted search hit');
    console.log('[PASS] 9. Timeline filtering & zero search leakage verified');

    // 10. Duplicate patient review, authorised merge, and controlled unmerge
    const merge = await req(
      '/api/patients-governance/merge',
      { method: 'POST', body: JSON.stringify({ sourcePatientId: PATIENT_IDS.oliverB, targetPatientId: PATIENT_IDS.oliverA, candidateId: 'dup-oliver-001', reason: 'Verified match' }) },
      conToken
    );
    assert.equal(merge.status, 200);
    const unmerge = await req(
      `/api/patients-governance/unmerge/${merge.body.mergeEventId}`,
      { method: 'POST', body: JSON.stringify({ reason: 'Controlled unmerge verification test' }) },
      conToken
    );
    assert.equal(unmerge.status, 200);
    console.log('[PASS] 10. Duplicate patient merge & controlled unmerge verified');

    // 11. Retry failed FHIR inbox message & inspect hash-chained audit
    const retryInbox = await req('/api/interoperability/inbox/inbox-fail-1/retry', { method: 'POST' }, caldToken);
    assert.equal(retryInbox.status, 200);
    assert.equal(retryInbox.body.status, 'processed');

    const audit = await req('/api/admin/audit', {}, caldToken);
    assert.equal(audit.status, 200);
    assert.equal(audit.body.verification.valid, true);
    console.log('[PASS] 11. Failed FHIR inbox retry & hash-chained audit verification passed:', audit.body.verification.totalEvents, 'events');

    // 12. Isolated Backup & Restore verification drill
    const drill = await req('/api/admin/backup-restore-drill', { method: 'POST' }, caldToken);
    assert.equal(drill.status, 200);
    assert.equal(drill.body.integrityCheckPassed, true);
    console.log(`[PASS] 12. Isolated backup & restore drill passed (RTO: ${drill.body.measuredRtoMs} ms, Attachments verified: ${drill.body.attachmentsVerified})`);

    console.log('ALL 12 VERIFICATION SCENARIOS + SECURITY CONTROLS PASSED!');
  } finally {
    server.close();
    db.close();
    if (fs.existsSync(testDbPath)) fs.rmSync(testDbPath);
  }
}

runVerification().catch((err) => {
  console.error('Verification failed:', err);
  process.exit(1);
});
