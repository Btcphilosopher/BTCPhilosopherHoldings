import React, { useEffect, useState } from 'react';
import { ShieldCheck, KeyRound, Lock } from 'lucide-react';
import { apiFetch, setAuthToken } from '../api.ts';
import type { ActorSession, StaffDirectoryEntry } from '../types.ts';

interface SignInViewProps {
  onSignedIn: (actor: ActorSession) => void;
}

export const SignInView: React.FC<SignInViewProps> = ({ onSignedIn }) => {
  const [directory, setDirectory] = useState<StaffDirectoryEntry[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [otpCode, setOtpCode] = useState<string>('482910');
  const [loading, setLoading] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<{ users: StaffDirectoryEntry[] }>('/api/auth/directory')
      .then((data) => {
        setDirectory(data.users);
        if (data.users.length > 0) {
          setSelectedUserId(data.users[0].id);
        }
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'Unable to load staff directory'))
      .finally(() => setLoading(false));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) return;
    setSubmitting(true);
    setError(null);
    try {
      const res = await apiFetch<{ token: string; actor: ActorSession }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ userId: selectedUserId, otpCode }),
      });
      setAuthToken(res.token);
      onSignedIn(res.actor);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center px-4 py-10">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="bg-[#0B1F3A] px-8 py-6 text-white">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-teal-400 shrink-0" />
            <h1 className="text-xl font-semibold tracking-tight">Aureom Clinical</h1>
          </div>
          <p className="mt-2 text-sm text-slate-300">
            Longitudinal Medical Records Database · Thames Valley Integrated Care Clinic (ODS: Y99001 · Synthetic)
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Organisational Sign-In & MFA Verification</h2>
            <p className="mt-1 text-sm text-slate-600">
              Select a staff identity via the replaceable CIS2 / OIDC identity adapter and confirm a 6-digit MFA token.
            </p>
          </div>

          {error && (
            <div role="alert" className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-800">
              {error}
            </div>
          )}

          {loading ? (
            <div className="space-y-3">
              <div className="h-12 bg-slate-100 rounded-lg animate-pulse" />
              <div className="h-12 bg-slate-100 rounded-lg animate-pulse" />
            </div>
          ) : (
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Staff Identity</label>
              <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg">
                {directory.map((entry) => {
                  const active = entry.id === selectedUserId;
                  return (
                    <label
                      key={entry.id}
                      className={`flex items-center justify-between gap-4 px-4 py-3 cursor-pointer transition-colors ${
                        active ? 'bg-teal-50/70' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <input
                          type="radio"
                          name="staffUser"
                          value={entry.id}
                          checked={active}
                          onChange={() => setSelectedUserId(entry.id)}
                          className="h-4 w-4 text-teal-700 focus:ring-teal-600"
                        />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-slate-900 truncate">{entry.full_name}</div>
                          <div className="text-xs text-slate-600 truncate">
                            {entry.role_display_name}
                            {entry.professional_reg_no ? ` · ${entry.professional_reg_no}` : ''} · {entry.email}
                          </div>
                        </div>
                      </div>
                      <span className="text-xs font-mono text-slate-500 whitespace-nowrap shrink-0">
                        {entry.identity_provider}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
            <div>
              <label htmlFor="mfa-otp" className="block text-sm font-medium text-slate-700">
                MFA One-Time Passcode (6 digits)
              </label>
              <div className="mt-1.5 relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  id="mfa-otp"
                  type="text"
                  inputMode="numeric"
                  pattern="\d{6}"
                  maxLength={6}
                  required
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg font-mono text-sm tabular-nums focus:outline-none focus:ring-2 focus:ring-teal-600"
                  placeholder="482910"
                />
              </div>
              <p className="mt-1 text-xs text-slate-500">Development CIS2 TOTP adapter accepts any 6-digit code.</p>
            </div>

            <button
              type="submit"
              disabled={submitting || loading || !selectedUserId}
              className="w-full sm:w-auto px-5 py-2.5 bg-[#0B1F3A] hover:bg-[#132E54] disabled:opacity-50 text-white text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
            >
              <Lock className="w-4 h-4" />
              {submitting ? 'Verifying Session...' : 'Sign In with MFA'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
