import React, { useState } from 'react';
import { AlertTriangle, ArrowLeftRight, ShieldAlert, CheckCircle2, HelpCircle, X } from 'lucide-react';
import type { PatientDetailResponse, PatientSummary } from '../types.ts';
import { apiFetch } from '../api.ts';

interface PatientBannerProps {
  detail: PatientDetailResponse | null;
  patients: PatientSummary[];
  restrictedError: { patientId: string; message: string; policy?: string } | null;
  onSelectPatient: (patientId: string) => void;
  onBreakGlassGranted: (patientId: string) => void;
}

function calculateAge(dob: string): number {
  const birth = new Date(dob);
  const now = new Date('2026-11-24T00:00:00Z');
  let age = now.getUTCFullYear() - birth.getUTCFullYear();
  const m = now.getUTCMonth() - birth.getUTCMonth();
  if (m < 0 || (m === 0 && now.getUTCDate() < birth.getUTCDate())) {
    age--;
  }
  return age;
}

export const PatientBanner: React.FC<PatientBannerProps> = ({
  detail,
  patients,
  restrictedError,
  onSelectPatient,
  onBreakGlassGranted,
}) => {
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const [switchQuery, setSwitchQuery] = useState('');
  const [breakGlassOpen, setBreakGlassOpen] = useState(false);
  const [breakGlassReason, setBreakGlassReason] = useState('');
  const [breakGlassError, setBreakGlassError] = useState<string | null>(null);
  const [submittingBg, setSubmittingBg] = useState(false);

  const handleBreakGlass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restrictedError) return;
    setSubmittingBg(true);
    setBreakGlassError(null);
    try {
      await apiFetch(`/api/patients/${restrictedError.patientId}/break-glass`, {
        method: 'POST',
        body: JSON.stringify({ reason: breakGlassReason }),
      });
      setBreakGlassOpen(false);
      setBreakGlassReason('');
      onBreakGlassGranted(restrictedError.patientId);
    } catch (err) {
      setBreakGlassError(err instanceof Error ? err.message : 'Unable to grant emergency access');
    } finally {
      setSubmittingBg(false);
    }
  };

  if (restrictedError) {
    return (
      <>
        <div className="bg-amber-50 border-b border-amber-200 px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0" />
            <div>
              <div className="text-sm font-semibold text-slate-900">
                Restricted Patient Record — Access Denied ({restrictedError.policy || 'sensitivity_policy'})
              </div>
              <div className="text-xs text-slate-700">{restrictedError.message}</div>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setBreakGlassOpen(true)}
              className="px-3.5 py-2 text-xs font-medium bg-amber-700 hover:bg-amber-800 text-white rounded-lg transition-colors whitespace-nowrap"
            >
              Emergency Break-Glass Access
            </button>
            <button
              type="button"
              onClick={() => setSwitcherOpen(true)}
              className="px-3.5 py-2 text-xs font-medium bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              Switch Patient
            </button>
          </div>
        </div>

        {breakGlassOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4">
            <div className="bg-white border border-slate-200 rounded-xl max-w-lg w-full p-6 shadow-lg">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-slate-900">Emergency Break-Glass Access Justification</h3>
                <button type="button" onClick={() => setBreakGlassOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <p className="mt-2 text-sm text-slate-600">
                This action grants temporary 2-hour access to a restricted record, creates an immediate high-priority audit log entry, and queues the event for Caldicott Guardian review.
              </p>
              <form onSubmit={handleBreakGlass} className="mt-4 space-y-4">
                {breakGlassError && <div className="p-2.5 bg-red-50 border border-red-200 rounded text-xs text-red-800">{breakGlassError}</div>}
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Clinical Emergency Justification (required)</label>
                  <textarea
                    rows={3}
                    required
                    minLength={10}
                    value={breakGlassReason}
                    onChange={(e) => setBreakGlassReason(e.target.value)}
                    placeholder="e.g. Patient presented to Acute Assessment Unit unconscious; immediate allergy and medication check required for emergency resuscitation."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-600"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setBreakGlassOpen(false)} className="px-4 py-2 text-xs font-medium border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50">
                    Cancel
                  </button>
                  <button type="submit" disabled={submittingBg} className="px-4 py-2 text-xs font-medium bg-amber-700 hover:bg-amber-800 text-white rounded-lg">
                    {submittingBg ? 'Recording Audit Grant...' : 'Confirm Break-Glass Access'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {switcherOpen && renderSwitcherModal(patients, switchQuery, setSwitchQuery, onSelectPatient, () => setSwitcherOpen(false))}
      </>
    );
  }

  if (!detail) {
    return (
      <>
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-2.5 flex items-center justify-between gap-4">
          <span className="text-sm text-slate-600">No patient context selected. Choose an authorised patient record before charting.</span>
          <button
            type="button"
            onClick={() => setSwitcherOpen(true)}
            className="px-3.5 py-1.5 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg hover:bg-[#132E54] flex items-center gap-1.5 whitespace-nowrap"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            Select Patient
          </button>
        </div>
        {switcherOpen && renderSwitcherModal(patients, switchQuery, setSwitchQuery, onSelectPatient, () => setSwitcherOpen(false))}
      </>
    );
  }

  const officialName = detail.names.find((n) => n.name_use === 'official' && !n.effective_to) || detail.names[0];
  const nhsId = detail.identifiers.find((i) => i.identifier_type === 'nhs_number' && !i.effective_to);
  const activeEncounter = detail.encounters.find((e) => e.status === 'in_progress');
  const allergyStatus = detail.patient.allergy_assessment_status;

  const formatNhs = (val?: string) => (val && val.length === 10 ? `${val.slice(0, 3)} ${val.slice(3, 6)} ${val.slice(6)}` : val || 'Unverified / Absent');

  let allergyDisplay: { text: string; toneClass: string; Icon: React.ComponentType<{ className?: string }> };
  if (allergyStatus === 'assessed_present' && detail.allergyCount > 0) {
    allergyDisplay = {
      text: `Allergies: ${detail.allergyCount} Documented`,
      toneClass: 'text-red-700 font-semibold',
      Icon: AlertTriangle,
    };
  } else if (allergyStatus === 'assessed_no_known_allergies') {
    allergyDisplay = {
      text: 'Allergies: Assessed — No Known Allergies',
      toneClass: 'text-teal-800 font-medium',
      Icon: CheckCircle2,
    };
  } else {
    allergyDisplay = {
      text: `Allergies: ${allergyStatus === 'unknown' ? 'Unknown' : allergyStatus === 'unavailable' ? 'Unavailable' : 'Not Assessed'}`,
      toneClass: 'text-amber-800 font-semibold',
      Icon: HelpCircle,
    };
  }
  const AllergyIcon = allergyDisplay.Icon;

  return (
    <>
      <section aria-label="Active Patient Context Banner" className="bg-slate-50 border-b border-slate-200 px-6 py-3">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-baseline gap-x-6 gap-y-1">
            <div className="flex items-baseline gap-2.5">
              <span className="text-base font-bold text-slate-900">
                {officialName ? `${officialName.prefix ? officialName.prefix + ' ' : ''}${officialName.family_name.toUpperCase()}, ${officialName.given_names}` : detail.patient.internal_mrn}
              </span>
              <span className="text-xs text-slate-600 tabular-nums">
                DOB {detail.patient.birth_date} ({calculateAge(detail.patient.birth_date)}y) · {detail.patient.administrative_gender}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-700 font-mono tabular-nums">
              <span>
                NHS: <strong className="text-slate-900">{formatNhs(nhsId?.identifier_value)}</strong> ({nhsId?.verification_status || 'none'})
              </span>
              <span aria-hidden="true">·</span>
              <span>
                MRN: <strong className="text-slate-900">{detail.patient.internal_mrn}</strong>
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-sans">
                Encounter:{' '}
                <strong className="text-slate-900">
                  {activeEncounter ? `${activeEncounter.encounter_class} (${activeEncounter.location_name})` : 'No active encounter'}
                </strong>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <div className={`flex items-center gap-1.5 text-xs ${allergyDisplay.toneClass}`}>
              <AllergyIcon className="w-4 h-4 shrink-0" />
              <span>{allergyDisplay.text}</span>
            </div>

            {detail.accessContext.viaBreakGlass && (
              <span className="text-xs font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                Break-Glass Active
              </span>
            )}

            <button
              type="button"
              onClick={() => setSwitcherOpen(true)}
              className="px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              Switch Patient
            </button>
          </div>
        </div>
      </section>

      {switcherOpen && renderSwitcherModal(patients, switchQuery, setSwitchQuery, onSelectPatient, () => setSwitcherOpen(false))}
    </>
  );
};

function renderSwitcherModal(
  patients: PatientSummary[],
  query: string,
  setQuery: (q: string) => void,
  onSelect: (id: string) => void,
  onClose: () => void
) {
  const filtered = patients.filter((p) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return (
      `${p.given_names} ${p.family_name}`.toLowerCase().includes(q) ||
      p.internal_mrn.toLowerCase().includes(q) ||
      (p.nhs_number || '').includes(q.replace(/\s+/g, ''))
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">Explicit Patient Context Switch</h3>
            <p className="text-xs text-slate-600">Verify full name, date of birth, and NHS Number before opening a clinical chart.</p>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-4 border-b border-slate-200 bg-slate-50">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter by surname, given name, MRN, or NHS Number..."
            className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
          />
        </div>
        <div className="max-h-96 overflow-y-auto divide-y divide-slate-200">
          {filtered.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                onSelect(p.id);
                onClose();
              }}
              className="w-full text-left px-6 py-3 hover:bg-teal-50/50 transition-colors flex items-center justify-between gap-4"
            >
              <div>
                <div className="text-sm font-semibold text-slate-900">
                  {p.family_name.toUpperCase()}, {p.given_names}
                  {p.sensitivity_level !== 'normal' && (
                    <span className="ml-2 text-xs font-medium text-amber-800">· Restricted Record</span>
                  )}
                </div>
                <div className="text-xs text-slate-600 font-mono tabular-nums mt-0.5">
                  DOB {p.birth_date} · NHS {p.nhs_formatted || 'Unverified'} · MRN {p.internal_mrn}
                </div>
              </div>
              <span className="text-xs font-medium text-teal-800 whitespace-nowrap shrink-0">
                {p.accessAllowed ? 'Open Chart' : 'Restricted · Request Access'}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
