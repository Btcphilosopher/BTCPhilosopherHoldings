import React, { useEffect, useState } from 'react';
import { AlertTriangle, Check, Download, FileText, FlaskConical, Plus, Send } from 'lucide-react';
import { apiFetch } from '../api.ts';
import type { NavSection, PatientDetailResponse } from '../types.ts';

interface ClinicalSectionsViewProps {
  section: Extract<NavSection, 'encounters' | 'timeline' | 'problems' | 'medications' | 'allergies' | 'observations' | 'results' | 'documents' | 'tasks'>;
  patientDetail: PatientDetailResponse | null;
  onRefreshPatient: () => void;
  onNavigate: (section: NavSection) => void;
}

interface ClinicalRecordPayload {
  allergyAssessmentStatus: string;
  allergyAssessedAt: string | null;
  problems: Array<{ id: string; snomed_code: string; display_term: string; clinical_status: string; verification_status: string; onset_date: string | null; source_system: string; notes: string | null }>;
  allergies: Array<{ id: string; substance_code: string; substance_name: string; reaction_manifestation: string; severity: string; criticality: string; verification_status: string; clinical_status: string; source_system: string; conflict_flag: number }>;
  medicationStatements: Array<{ id: string; medication_name: string; reported_dose_text: string; information_source: string; status: string; source_system: string; recorded_at: string }>;
  prescriptions: Array<{ id: string; dmd_code: string; medication_name: string; dose_value: number | null; dose_unit: string | null; route: string; frequency: string; indication: string | null; status: string; prescriber_name: string; authored_at: string }>;
  dispensingRecords: Array<{ id: string; medication_name: string; quantity_value: number; quantity_unit: string; batch_number: string | null; dispensed_by: string; dispensed_at: string; status: string }>;
  administrations: Array<{ id: string; medication_name: string; dose_given: string; route: string; administered_by_name: string; administered_at: string; status: string; notes: string | null }>;
  observations: Array<{ id: string; code_system: string; code: string; display_name: string; value_numeric: number; unit: string; ref_range_low: number | null; ref_range_high: number | null; source_interpretation: string | null; status: string; effective_time: string; source_system: string; collection_time: string | null }>;
  results: Array<{ id: string; report_code: string; report_title: string; result_summary: string; structuredValues: Array<{ analyte: string; value: number; unit: string; refLow?: number; refHigh?: number; flag?: string }>; status: string; replaces_result_id: string | null; correction_reason: string | null; review_state: string; reviewer_name: string | null; effective_time: string; source_system: string; source_record_id: string }>;
  tasks: Array<{ id: string; title: string; instructions: string; priority: string; status: string; due_at: string; assignee_name: string; linked_result_id: string | null }>;
  documents: Array<{ id: string; title: string; document_type: string; byte_size: number; sha256_checksum: string; uploaded_by_name: string; created_at: string; sensitivity_level: string }>;
  imagingReferences: Array<{ id: string; modality: string; body_site: string; study_description: string; accession_number: string; study_instance_uid: string; archive_endpoint_uri: string; performed_at: string; status: string }>;
}

interface TimelineItem {
  id: string;
  category: string;
  occurredAt: string;
  title: string;
  summary: string;
  status: string;
  sourceSystem: string;
  targetRoute: NavSection;
}

export const ClinicalSectionsView: React.FC<ClinicalSectionsViewProps> = ({
  section,
  patientDetail,
  onRefreshPatient,
  onNavigate,
}) => {
  const [record, setRecord] = useState<ClinicalRecordPayload | null>(null);
  const [timeline, setTimeline] = useState<TimelineItem[]>([]);
  const [timelineCats, setTimelineCats] = useState<string[]>([]);
  const [locations, setLocations] = useState<Array<{ id: string; name: string; location_type: string }>>([]);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Forms
  const [encLocationId, setEncLocationId] = useState('');
  const [encClass, setEncClass] = useState('outpatient');
  const [encReason, setEncReason] = useState('');

  const [obsName, setObsName] = useState('Systolic blood pressure');
  const [obsVal, setObsVal] = useState('132');
  const [obsUnit, setObsUnit] = useState('mmHg');
  const [obsLow, setObsLow] = useState('90');
  const [obsHigh, setObsHigh] = useState('139');

  const [algSub, setAlgSub] = useState('');
  const [algReact, setAlgReact] = useState('');
  const [algSev, setAlgSev] = useState('moderate');

  const [probTerm, setProbTerm] = useState('');
  const [probCode, setProbCode] = useState('');

  const [rxMed, setRxMed] = useState('');
  const [rxDose, setRxDose] = useState('');
  const [rxUnit, setRxUnit] = useState('mg');
  const [rxRoute, setRxRoute] = useState('Oral');
  const [rxFreq, setRxFreq] = useState('Once daily');

  const [docTitle, setDocTitle] = useState('');
  const [docBody, setDocBody] = useState('');
  const [docPreview, setDocPreview] = useState<{ title: string; contentText: string; sha256: string; checksumValid: boolean } | null>(null);

  const [taskTitle, setTaskTitle] = useState('');
  const [taskNotes, setTaskNotes] = useState('');

  const [fhirMsgId, setFhirMsgId] = useState('msg-lis-demo-101');
  const [fhirReportId, setFhirReportId] = useState('LIS-99100');
  const [fhirStatus, setFhirStatus] = useState<'preliminary' | 'final' | 'corrected'>('preliminary');
  const [fhirValue, setFhirValue] = useState('158');
  const [fhirReplaces, setFhirReplaces] = useState('');

  const patientId = patientDetail?.patient.id;

  const loadData = () => {
    if (!patientId) return;
    apiFetch<ClinicalRecordPayload>(`/api/patients/${patientId}/clinical-record`).then(setRecord).catch(() => {});
    const catQuery = timelineCats.length > 0 ? `?categories=${timelineCats.join(',')}` : '';
    apiFetch<{ timeline: TimelineItem[] }>(`/api/patients/${patientId}/timeline${catQuery}`).then((r) => setTimeline(r.timeline)).catch(() => {});
    apiFetch<{ locations: Array<{ id: string; name: string; location_type: string }> }>(`/api/encounters?patientId=${patientId}`)
      .then((r) => {
        setLocations(r.locations);
        if (r.locations.length > 0 && !encLocationId) setEncLocationId(r.locations[0].id);
      })
      .catch(() => {});
  };

  useEffect(() => {
    setFeedback(null);
    setDocPreview(null);
    loadData();
  }, [patientId, section, timelineCats.join(',')]);

  if (!patientDetail) {
    return <div className="p-6 text-sm text-slate-600">Select an authorised patient to view {section}.</div>;
  }

  const handleOpenEncounter = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await apiFetch('/api/encounters', {
        method: 'POST',
        body: JSON.stringify({ patientId, locationId: encLocationId, encounterClass: encClass, reasonText: encReason }),
      });
      setEncReason('');
      setFeedback({ type: 'ok', text: 'Encounter opened and added to patient timeline.' });
      onRefreshPatient();
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to open encounter' });
    }
  };

  const handleRecordObservation = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await apiFetch(`/api/patients/${patientId}/observations`, {
        method: 'POST',
        body: JSON.stringify({
          displayName: obsName,
          valueNumeric: Number(obsVal),
          unit: obsUnit,
          refRangeLow: obsLow ? Number(obsLow) : undefined,
          refRangeHigh: obsHigh ? Number(obsHigh) : undefined,
        }),
      });
      setFeedback({ type: 'ok', text: `Observation "${obsName}: ${obsVal} ${obsUnit}" recorded.` });
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to record observation' });
    }
  };

  const handleRecordAllergy = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await apiFetch(`/api/patients/${patientId}/allergies`, {
        method: 'POST',
        body: JSON.stringify({ substanceName: algSub, reactionManifestation: algReact, severity: algSev }),
      });
      setAlgSub('');
      setAlgReact('');
      setFeedback({ type: 'ok', text: 'Allergy recorded and patient allergy assessment updated.' });
      onRefreshPatient();
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to record allergy' });
    }
  };

  const handleAllergyStatusChange = async (status: string) => {
    setFeedback(null);
    try {
      await apiFetch(`/api/patients/${patientId}/allergy-status`, { method: 'PATCH', body: JSON.stringify({ status }) });
      onRefreshPatient();
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Update failed' });
    }
  };

  const handleResultReview = async (resultId: string, reviewState: string) => {
    setFeedback(null);
    try {
      await apiFetch(`/api/results/${resultId}/review`, {
        method: 'POST',
        body: JSON.stringify({
          reviewState,
          followUpTitle: reviewState === 'assigned_for_followup' ? 'Clinical follow-up on diagnostic report' : undefined,
          followUpInstructions: reviewState === 'assigned_for_followup' ? 'Review updated laboratory values with patient.' : undefined,
        }),
      });
      setFeedback({ type: 'ok', text: `Result review state updated to "${reviewState}".` });
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Failed to update review state' });
    }
  };

  const handleIngestFhir = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      const res = await apiFetch<{ status: string; message: string; createdResultIds: string[] }>('/api/fhir/ingest', {
        method: 'POST',
        body: JSON.stringify({
          resourceType: 'Bundle',
          id: fhirMsgId,
          type: 'message',
          sourceSystem: 'berkshire_pathology_lis',
          entry: [
            {
              resource: {
                resourceType: 'DiagnosticReport',
                id: fhirReportId,
                status: fhirStatus,
                code: { text: `Serum Troponin / Renal Panel (${fhirStatus})` },
                subject: { reference: `Patient/${patientId}` },
                effectiveDateTime: new Date().toISOString(),
                conclusion: `Imported ${fhirStatus} value: ${fhirValue} umol/L (Source ref 60–110 umol/L)`,
                replacesReference: fhirReplaces.trim() || undefined,
                correctionReason: fhirStatus === 'corrected' ? 'Corrected assay calibration from LIS' : undefined,
                _structuredValues: [{ analyte: 'Serum Creatinine', value: Number(fhirValue), unit: 'umol/L', refLow: 60, refHigh: 110, flag: 'LIS Source' }],
              },
            },
          ],
        }),
      });
      setFeedback({ type: 'ok', text: res.message });
      if (res.createdResultIds[0] && !fhirReplaces) {
        setFhirReplaces(fhirReportId);
      }
      loadData();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'FHIR ingest failed' });
    }
  };

  const handleDownloadDoc = async (docId: string) => {
    setFeedback(null);
    try {
      const res = await apiFetch<{ title: string; contentText: string; sha256: string; checksumValid: boolean }>(`/api/documents/${docId}/download`);
      setDocPreview(res);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Download failed' });
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px]">
      {feedback && (
        <div role="status" className={`p-3 rounded-lg border text-sm ${feedback.type === 'ok' ? 'bg-teal-50 border-teal-200 text-teal-900' : 'bg-red-50 border-red-200 text-red-800'}`}>
          {feedback.text}
        </div>
      )}

      {section === 'encounters' && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-900">Encounters & Care Episodes</h2>
            <p className="text-sm text-slate-600">Open, review, and close outpatient, inpatient, emergency, and home-visit encounters.</p>
          </div>
          <form onSubmit={handleOpenEncounter} className="border border-slate-200 rounded-lg p-5 bg-slate-50 grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Location</label>
              <select value={encLocationId} onChange={(e) => setEncLocationId(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg">
                {locations.map((l) => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Class</label>
              <select value={encClass} onChange={(e) => setEncClass(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg">
                <option value="outpatient">Outpatient</option>
                <option value="inpatient">Inpatient</option>
                <option value="emergency">Emergency</option>
                <option value="telephone">Telephone</option>
                <option value="home_visit">Home Visit</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Clinical Reason *</label>
              <input required value={encReason} onChange={(e) => setEncReason(e.target.value)} placeholder="e.g. Follow-up blood pressure review" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg hover:bg-[#132E54] whitespace-nowrap">
              Open New Encounter
            </button>
          </form>

          <div className="border border-slate-200 rounded-lg divide-y divide-slate-200 bg-white">
            {patientDetail.encounters.map((e) => (
              <div key={e.id} className="p-4 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-semibold text-slate-900">{e.reason_text}</div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {e.encounter_class} · {e.location_name} · Attending: {e.attending_name} · Started <span className="font-mono">{e.started_at.slice(0, 16).replace('T', ' ')}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-semibold text-slate-800">Status: {e.status}</span>
                  {e.status === 'in_progress' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await apiFetch(`/api/encounters/${e.id}/status`, { method: 'PATCH', body: JSON.stringify({ status: 'finished' }) });
                        onRefreshPatient();
                      }}
                      className="px-3 py-1 text-xs border border-slate-300 rounded hover:bg-slate-50"
                    >
                      Finish Encounter
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {section === 'timeline' && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h2 className="text-xl font-semibold text-slate-900">Chronological Clinical Timeline</h2>
              <p className="text-sm text-slate-600">Unified longitudinal view across encounters, notes, medications, results, observations, and documents.</p>
            </div>
            <div className="flex flex-wrap gap-1 p-1 bg-slate-100 rounded-lg">
              {['encounters', 'notes', 'medications', 'results', 'observations', 'documents', 'imaging'].map((cat) => {
                const active = timelineCats.includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setTimelineCats((prev) => (prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]))}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md capitalize transition-colors ${
                      active ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
              {timelineCats.length > 0 && (
                <button type="button" onClick={() => setTimelineCats([])} className="px-2.5 py-1 text-xs text-teal-800 font-medium">
                  Clear
                </button>
              )}
            </div>
          </div>

          <div className="border border-slate-200 rounded-lg divide-y divide-slate-200 bg-white">
            {timeline.length === 0 ? (
              <div className="p-6 text-sm text-slate-500">No timeline events match the current filter.</div>
            ) : (
              timeline.map((item) => (
                <div key={`${item.category}-${item.id}`} className="p-4 flex flex-wrap items-center justify-between gap-4 hover:bg-slate-50">
                  <div>
                    <div className="text-xs font-mono text-slate-500">
                      {item.occurredAt.slice(0, 16).replace('T', ' ')} · <span className="font-sans uppercase tracking-wide text-teal-800 font-semibold">{item.category}</span> · {item.sourceSystem}
                    </div>
                    <div className="text-sm font-semibold text-slate-900 mt-0.5">{item.title}</div>
                    <div className="text-xs text-slate-600 mt-0.5">{item.summary}</div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-medium text-slate-700">{item.status}</span>
                    <button type="button" onClick={() => onNavigate(item.targetRoute)} className="px-3 py-1 text-xs border border-slate-300 rounded hover:bg-white">
                      Open
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {section === 'problems' && record && (
        <div className="space-y-5">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-900">Problems & Diagnoses (SNOMED CT)</h2>
            <p className="text-sm text-slate-600">Structured problem assertions separated from free-text clinical notes.</p>
          </div>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              await apiFetch(`/api/patients/${patientId}/problems`, { method: 'POST', body: JSON.stringify({ displayTerm: probTerm, snomedCode: probCode || '404684003' }) });
              setProbTerm('');
              setProbCode('');
              loadData();
            }}
            className="flex flex-wrap gap-3 p-4 bg-slate-50 border border-slate-200 rounded-lg"
          >
            <input required value={probTerm} onChange={(e) => setProbTerm(e.target.value)} placeholder="Problem / SNOMED term..." className="flex-1 min-w-[240px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            <input value={probCode} onChange={(e) => setProbCode(e.target.value)} placeholder="SNOMED CT code (e.g. 73211009)" className="w-56 px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono" />
            <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg">Add Problem</button>
          </form>
          <div className="border border-slate-200 rounded-lg divide-y divide-slate-200 bg-white">
            {record.problems.map((p) => (
              <div key={p.id} className="p-4 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-semibold text-slate-900">{p.display_term}</div>
                  <div className="text-xs text-slate-600 font-mono mt-0.5">SNOMED {p.snomed_code} · Onset {p.onset_date || 'Unknown'} · Source: {p.source_system}</div>
                  {p.notes && <div className="text-xs text-slate-700 mt-1">{p.notes}</div>}
                </div>
                <span className="text-xs font-medium text-slate-800">{p.clinical_status} · {p.verification_status}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {section === 'medications' && record && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-900">Medications (Separated Provenance Streams)</h2>
            <p className="text-sm text-slate-600">Prescriptions, patient/GP-reported medication statements, pharmacy dispensing, and ward administrations are strictly separated.</p>
          </div>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              await apiFetch(`/api/patients/${patientId}/prescriptions`, {
                method: 'POST',
                body: JSON.stringify({ medicationName: rxMed, doseValue: Number(rxDose) || undefined, doseUnit: rxUnit, route: rxRoute, frequency: rxFreq }),
              });
              setRxMed('');
              setRxDose('');
              setFeedback({ type: 'ok', text: 'Prescription authored.' });
              loadData();
            }}
            className="grid grid-cols-1 md:grid-cols-6 gap-3 p-4 bg-slate-50 border border-slate-200 rounded-lg items-end"
          >
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">Medication (NHS dm+d)</label>
              <input required value={rxMed} onChange={(e) => setRxMed(e.target.value)} placeholder="e.g. Bisoprolol 2.5mg tablets" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Dose</label>
              <input value={rxDose} onChange={(e) => setRxDose(e.target.value)} placeholder="2.5" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Route</label>
              <input value={rxRoute} onChange={(e) => setRxRoute(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Frequency</label>
              <input value={rxFreq} onChange={(e) => setRxFreq(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg">Author Prescription</button>
          </form>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800">1. Clinician Prescriptions</div>
              <div className="divide-y divide-slate-200">
                {record.prescriptions.map((rx) => (
                  <div key={rx.id} className="p-4 text-xs">
                    <div className="text-sm font-semibold text-slate-900">{rx.medication_name}</div>
                    <div className="text-slate-600 mt-0.5">{rx.route} · {rx.frequency} · Prescriber: {rx.prescriber_name} · Status: <strong>{rx.status}</strong></div>
                  </div>
                ))}
              </div>
            </section>

            <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800">2. Patient-Reported & GP Summary Statements</div>
              <div className="divide-y divide-slate-200">
                {record.medicationStatements.map((ms) => (
                  <div key={ms.id} className="p-4 text-xs">
                    <div className="text-sm font-semibold text-slate-900">{ms.medication_name}</div>
                    <div className="text-slate-700 mt-0.5">{ms.reported_dose_text}</div>
                    <div className="text-slate-500 mt-0.5">Source: {ms.information_source} ({ms.source_system}) · Status: {ms.status}</div>
                  </div>
                ))}
              </div>
            </section>

            <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800">3. Pharmacy Dispensing Records</div>
              <div className="divide-y divide-slate-200">
                {record.dispensingRecords.map((d) => (
                  <div key={d.id} className="p-4 text-xs">
                    <div className="font-semibold text-slate-900">{d.medication_name} — {d.quantity_value} {d.quantity_unit}</div>
                    <div className="text-slate-600 mt-0.5">{d.dispensed_by} · Batch {d.batch_number || 'N/A'} · {d.dispensed_at.slice(0, 16).replace('T', ' ')}</div>
                  </div>
                ))}
              </div>
            </section>

            <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800">4. Ward Medication Administrations (MAR)</div>
              <div className="divide-y divide-slate-200">
                {record.administrations.map((a) => (
                  <div key={a.id} className="p-4 text-xs">
                    <div className="font-semibold text-slate-900">{a.medication_name} — Given {a.dose_given} ({a.route})</div>
                    <div className="text-slate-600 mt-0.5">By {a.administered_by_name} · {a.administered_at.slice(0, 16).replace('T', ' ')} · {a.status}</div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      )}

      {section === 'allergies' && record && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h2 className="text-xl font-semibold text-slate-900">Allergies & Adverse Reactions</h2>
              <p className="text-sm text-slate-600">An empty allergy list never implies "No Known Allergies". Contradictory source reports are preserved explicitly for clinician reconciliation.</p>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-600 font-medium">Assessment State:</span>
              <select
                value={record.allergyAssessmentStatus}
                onChange={(e) => handleAllergyStatusChange(e.target.value)}
                className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg font-medium text-slate-900"
              >
                <option value="assessed_present">Assessed — Allergies Present</option>
                <option value="assessed_no_known_allergies">Assessed — No Known Allergies (NKDA)</option>
                <option value="not_assessed">Not Assessed</option>
                <option value="unknown">Unknown</option>
                <option value="unavailable">Unavailable</option>
              </select>
            </div>
          </div>

          <form onSubmit={handleRecordAllergy} className="grid grid-cols-1 md:grid-cols-4 gap-3 p-4 bg-slate-50 border border-slate-200 rounded-lg items-end">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Substance *</label>
              <input required value={algSub} onChange={(e) => setAlgSub(e.target.value)} placeholder="e.g. Ibuprofen" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Reaction Manifestation *</label>
              <input required value={algReact} onChange={(e) => setAlgReact(e.target.value)} placeholder="e.g. Bronchospasm" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Documented Severity</label>
              <select value={algSev} onChange={(e) => setAlgSev(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg">
                <option value="mild">Mild</option>
                <option value="moderate">Moderate</option>
                <option value="severe">Severe</option>
                <option value="life_threatening">Life Threatening</option>
                <option value="unknown">Unknown</option>
              </select>
            </div>
            <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg">Record Allergy</button>
          </form>

          {record.allergies.length === 0 ? (
            <div className="p-6 border border-slate-200 rounded-lg bg-white text-sm text-slate-700">
              No allergy records stored. Explicit Assessment Status: <strong>{record.allergyAssessmentStatus}</strong>.
            </div>
          ) : (
            <div className="border border-slate-200 rounded-lg divide-y divide-slate-200 bg-white">
              {record.allergies.map((a) => (
                <div key={a.id} className="p-4 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-900">{a.substance_name}</span>
                      {a.conflict_flag === 1 && (
                        <span className="text-xs font-semibold text-amber-800 flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Source Discrepancy — Review Required
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-700 mt-0.5">Reaction: {a.reaction_manifestation}</div>
                    <div className="text-xs text-slate-500 mt-0.5">Source: {a.source_system} · Verification: {a.verification_status}</div>
                  </div>
                  <div className="text-xs font-semibold text-red-700">Severity: {a.severity} · {a.clinical_status}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {section === 'observations' && record && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-900">Clinical Observations & Vital Signs</h2>
            <p className="text-sm text-slate-600">Preserves source units, specimen collection timestamps, and source-supplied reference intervals.</p>
          </div>
          <form onSubmit={handleRecordObservation} className="grid grid-cols-1 md:grid-cols-6 gap-3 p-4 bg-slate-50 border border-slate-200 rounded-lg items-end">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">Observation Name</label>
              <input required value={obsName} onChange={(e) => setObsName(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Value</label>
              <input required type="number" step="any" value={obsVal} onChange={(e) => setObsVal(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Unit (UCUM)</label>
              <input required value={obsUnit} onChange={(e) => setObsUnit(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Source Ref Interval</label>
              <div className="flex gap-1">
                <input value={obsLow} onChange={(e) => setObsLow(e.target.value)} placeholder="Low" className="w-1/2 px-2 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
                <input value={obsHigh} onChange={(e) => setObsHigh(e.target.value)} placeholder="High" className="w-1/2 px-2 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
              </div>
            </div>
            <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg">Record Observation</button>
          </form>

          <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Observation</th>
                  <th className="py-2.5 px-4">Value & Unit</th>
                  <th className="py-2.5 px-4">Source Reference Interval</th>
                  <th className="py-2.5 px-4">Effective Time</th>
                  <th className="py-2.5 px-4">Source & Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {record.observations.map((o) => (
                  <tr key={o.id}>
                    <td className="py-3 px-4 font-medium text-slate-900">{o.display_name} <span className="text-xs font-mono text-slate-500">({o.code})</span></td>
                    <td className="py-3 px-4 font-mono tabular-nums font-semibold text-slate-900">{o.value_numeric} {o.unit}</td>
                    <td className="py-3 px-4 font-mono text-xs tabular-nums text-slate-600">{o.ref_range_low ?? '—'} to {o.ref_range_high ?? '—'} {o.unit}</td>
                    <td className="py-3 px-4 font-mono text-xs tabular-nums text-slate-600">{o.effective_time.slice(0, 16).replace('T', ' ')}</td>
                    <td className="py-3 px-4 text-xs text-slate-600">{o.source_system} · {o.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {section === 'results' && record && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-900">Diagnostic Results & UK Core FHIR R4 Ingestion</h2>
            <p className="text-sm text-slate-600">
              Retains preliminary → corrected replacement chains and separates Viewed, Acknowledged, Assigned for Follow-Up, and Action Completed states.
            </p>
          </div>

          {/* Interactive FHIR R4 Bundle Ingestion Simulator */}
          <form onSubmit={handleIngestFhir} className="border border-slate-200 rounded-lg p-5 bg-slate-50 space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <FlaskConical className="w-4 h-4 text-teal-700" /> Import Diagnostic Report via UK Core FHIR R4 Adapter
            </div>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">FHIR Bundle Message ID</label>
                <input required value={fhirMsgId} onChange={(e) => setFhirMsgId(e.target.value)} className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">LIS Report ID</label>
                <input required value={fhirReportId} onChange={(e) => setFhirReportId(e.target.value)} className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Result Status</label>
                <select value={fhirStatus} onChange={(e) => setFhirStatus(e.target.value as 'preliminary' | 'final' | 'corrected')} className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg">
                  <option value="preliminary">preliminary</option>
                  <option value="final">final</option>
                  <option value="corrected">corrected</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Creatinine (umol/L)</label>
                <input value={fhirValue} onChange={(e) => setFhirValue(e.target.value)} className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Replaces Report ID (optional)</label>
                <input value={fhirReplaces} onChange={(e) => setFhirReplaces(e.target.value)} placeholder="e.g. LIS-99100" className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-mono" />
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5" /> Ingest FHIR Bundle
              </button>
              <span className="text-xs text-slate-600">Tip: Re-submitting the exact same Message ID tests idempotent duplicate suppression.</span>
            </div>
          </form>

          <div className="space-y-4">
            {record.results.map((r) => (
              <div key={r.id} className="border border-slate-200 rounded-lg p-5 bg-white space-y-3">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="text-base font-semibold text-slate-900">{r.report_title}</div>
                    <div className="text-xs text-slate-600 font-mono mt-0.5">
                      {r.source_system} · {r.source_record_id} · Status: <strong>{r.status}</strong> · Review: <strong>{r.review_state}</strong>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(['viewed', 'acknowledged', 'assigned_for_followup', 'action_completed'] as const).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => handleResultReview(r.id, st)}
                        className={`px-2.5 py-1 text-xs rounded border transition-colors ${
                          r.review_state === st ? 'bg-teal-700 text-white border-teal-700' : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        {st.replace(/_/g, ' ')}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-sm text-slate-800">{r.result_summary}</p>
                {r.replaces_result_id && (
                  <div className="text-xs text-amber-900 bg-amber-50 border border-amber-200 rounded p-2.5">
                    <strong>Replaces Previous Result:</strong> {r.replaces_result_id.slice(0, 12)}... · Reason: {r.correction_reason || 'Laboratory correction'}
                  </div>
                )}
                {r.structuredValues.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 pt-1">
                    {r.structuredValues.map((sv, idx) => (
                      <div key={idx} className="p-2.5 border border-slate-200 rounded bg-slate-50 text-xs">
                        <div className="font-semibold text-slate-900">{sv.analyte}</div>
                        <div className="font-mono tabular-nums text-sm text-slate-900 mt-0.5">{sv.value} {sv.unit}</div>
                        <div className="text-slate-600 font-mono">Source ref: {sv.refLow ?? '—'}–{sv.refHigh ?? '—'} · {sv.flag || 'Reported'}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {section === 'documents' && record && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-900">Protected Documents & Imaging References</h2>
            <p className="text-sm text-slate-600">Attachments reside in patient-scoped object storage verified by SHA-256 checksums; imaging studies link to external PACS/DICOMweb archives.</p>
          </div>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              await apiFetch(`/api/patients/${patientId}/documents`, { method: 'POST', body: JSON.stringify({ title: docTitle, contentText: docBody }) });
              setDocTitle('');
              setDocBody('');
              setFeedback({ type: 'ok', text: 'Document stored in protected object storage with SHA-256 integrity hash.' });
              loadData();
            }}
            className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3"
          >
            <div className="text-xs font-semibold text-slate-800">Upload Clinical Document</div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <input required value={docTitle} onChange={(e) => setDocTitle(e.target.value)} placeholder="Document title..." className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
              <input required value={docBody} onChange={(e) => setDocBody(e.target.value)} placeholder="Document text content..." className="md:col-span-2 px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            </div>
            <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5" /> Store Protected Attachment
            </button>
          </form>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="border border-slate-200 rounded-lg bg-white divide-y divide-slate-200">
              <div className="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-800">Stored Documents ({record.documents.length})</div>
              {record.documents.map((d) => (
                <div key={d.id} className="p-4 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-teal-700 shrink-0" /> {d.title}
                    </div>
                    <div className="text-xs font-mono text-slate-500 mt-0.5 truncate">
                      {d.byte_size} bytes · SHA-256 {d.sha256_checksum.slice(0, 16)}...
                    </div>
                  </div>
                  <button type="button" onClick={() => handleDownloadDoc(d.id)} className="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded-lg hover:bg-slate-50 flex items-center gap-1 shrink-0">
                    <Download className="w-3.5 h-3.5" /> Verify & Read
                  </button>
                </div>
              ))}
            </section>

            <section className="border border-slate-200 rounded-lg bg-white divide-y divide-slate-200">
              <div className="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-800">Authorised Imaging Archive References ({record.imagingReferences.length})</div>
              {record.imagingReferences.length === 0 ? (
                <div className="p-4 text-xs text-slate-500">No external PACS study references recorded for this patient.</div>
              ) : (
                record.imagingReferences.map((im) => (
                  <div key={im.id} className="p-4 text-xs space-y-1">
                    <div className="text-sm font-semibold text-slate-900">{im.modality} · {im.study_description}</div>
                    <div className="font-mono text-slate-600">Accession: {im.accession_number} · Study UID: {im.study_instance_uid}</div>
                    <div className="font-mono text-teal-800 break-all">{im.archive_endpoint_uri}</div>
                  </div>
                ))
              )}
            </section>
          </div>

          {docPreview && (
            <div className="border border-teal-200 rounded-lg p-5 bg-teal-50/40 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <strong className="text-slate-900 text-sm">{docPreview.title}</strong>
                <span className="font-mono text-teal-900">Checksum Verified: {docPreview.checksumValid ? 'YES' : 'MISMATCH'}</span>
              </div>
              <pre className="text-xs font-mono whitespace-pre-wrap bg-white p-4 border border-slate-200 rounded-lg text-slate-800">{docPreview.contentText}</pre>
            </div>
          )}
        </div>
      )}

      {section === 'tasks' && record && (
        <div className="space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <h2 className="text-xl font-semibold text-slate-900">Follow-Up Tasks & Referrals</h2>
            <p className="text-sm text-slate-600">Tracked clinical actions linked to diagnostic results and encounters.</p>
          </div>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              await apiFetch(`/api/patients/${patientId}/tasks`, { method: 'POST', body: JSON.stringify({ title: taskTitle, instructions: taskNotes, priority: 'urgent' }) });
              setTaskTitle('');
              setTaskNotes('');
              loadData();
            }}
            className="grid grid-cols-1 md:grid-cols-3 gap-3 p-4 bg-slate-50 border border-slate-200 rounded-lg"
          >
            <input required value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} placeholder="Follow-up task title..." className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            <input value={taskNotes} onChange={(e) => setTaskNotes(e.target.value)} placeholder="Clinical instructions..." className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
            <button type="submit" className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg">Create Follow-Up Task</button>
          </form>

          <div className="border border-slate-200 rounded-lg divide-y divide-slate-200 bg-white">
            {record.tasks.map((t) => (
              <div key={t.id} className="p-4 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-semibold text-slate-900">{t.title}</div>
                  <div className="text-xs text-slate-600 mt-0.5">{t.instructions}</div>
                  <div className="text-xs text-slate-500 mt-0.5">Assigned: {t.assignee_name} · Priority: {t.priority} · Status: <strong>{t.status}</strong></div>
                </div>
                {t.status !== 'completed' && (
                  <button
                    type="button"
                    onClick={async () => {
                      await apiFetch(`/api/tasks/${t.id}`, { method: 'PATCH', body: JSON.stringify({ status: 'completed' }) });
                      loadData();
                    }}
                    className="px-3 py-1.5 text-xs font-medium bg-teal-700 text-white rounded-lg flex items-center gap-1 shrink-0"
                  >
                    <Check className="w-3.5 h-3.5" /> Complete
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
