import React, { useEffect, useState } from 'react';
import { UserPlus, GitMerge, Undo2, Search, History } from 'lucide-react';
import { apiFetch } from '../api.ts';
import type { PatientDetailResponse, PatientSummary } from '../types.ts';

interface PatientsViewProps {
  patients: PatientSummary[];
  activePatientDetail: PatientDetailResponse | null;
  onSelectPatient: (id: string) => void;
  onRefreshPatients: () => void;
}

interface DuplicateCandidate {
  id: string;
  patient_a_id: string;
  patient_b_id: string;
  match_score: number;
  match_rationale: string;
  review_status: string;
  mrn_a: string;
  dob_a: string;
  name_a: string;
  nhs_a: string | null;
  addr_a: string | null;
  mrn_b: string;
  dob_b: string;
  name_b: string;
  ident_b: string | null;
  ident_type_b: string | null;
  addr_b: string | null;
}

interface MergeEvent {
  id: string;
  source_patient_id: string;
  target_patient_id: string;
  action: string;
  reason: string;
  performed_by_name: string;
  performed_at: string;
  reversed_by_event_id: string | null;
}

export const PatientsView: React.FC<PatientsViewProps> = ({
  patients,
  activePatientDetail,
  onSelectPatient,
  onRefreshPatients,
}) => {
  const [subTab, setSubTab] = useState<'register_list' | 'demographics' | 'duplicates'>('register_list');
  const [query, setQuery] = useState('');
  const [showNewForm, setShowNewForm] = useState(false);
  const [duplicates, setDuplicates] = useState<DuplicateCandidate[]>([]);
  const [mergeEvents, setMergeEvents] = useState<MergeEvent[]>([]);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Registration form
  const [givenNames, setGivenNames] = useState('');
  const [familyName, setFamilyName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState('female');
  const [nhsNumber, setNhsNumber] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [postcode, setPostcode] = useState('');
  const [allergyStatus, setAllergyStatus] = useState('not_assessed');

  // Demographic update form
  const [editGiven, setEditGiven] = useState('');
  const [editFamily, setEditFamily] = useState('');
  const [editLine1, setEditLine1] = useState('');
  const [editPostcode, setEditPostcode] = useState('');
  const [editReason, setEditReason] = useState('');

  // Merge reason
  const [mergeReason, setMergeReason] = useState('Verified matching identity with patient photo ID and PDS record; consolidating walk-in duplicate into primary NHS-verified chart.');
  const [unmergeReason, setUnmergeReason] = useState('Mistaken merge identified during audit; restoring original independent patient records.');

  const loadGovernance = () => {
    apiFetch<{ candidates: DuplicateCandidate[]; mergeEvents: MergeEvent[] }>('/api/patients-governance/duplicates')
      .then((res) => {
        setDuplicates(res.candidates);
        setMergeEvents(res.mergeEvents);
      })
      .catch(() => {});
  };

  useEffect(() => {
    loadGovernance();
  }, []);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      const res = await apiFetch<{ id: string; internalMrn: string }>('/api/patients', {
        method: 'POST',
        body: JSON.stringify({
          givenNames,
          familyName,
          birthDate,
          administrativeGender: gender,
          nhsNumber: nhsNumber.trim() || undefined,
          addressLine1,
          postcode,
          allergyAssessmentStatus: allergyStatus,
        }),
      });
      setFeedback({ type: 'ok', text: `Registered patient ${givenNames} ${familyName} (${res.internalMrn}).` });
      setShowNewForm(false);
      setGivenNames('');
      setFamilyName('');
      setNhsNumber('');
      onRefreshPatients();
      onSelectPatient(res.id);
      loadGovernance();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Registration failed' });
    }
  };

  const handleUpdateDemographics = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatientDetail) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/patients/${activePatientDetail.patient.id}/demographics`, {
        method: 'PATCH',
        body: JSON.stringify({
          givenNames: editGiven || undefined,
          familyName: editFamily || undefined,
          addressLine1: editLine1 || undefined,
          postcode: editPostcode || undefined,
          reason: editReason || 'Patient demographic update',
        }),
      });
      setFeedback({ type: 'ok', text: 'Demographics updated with prior name/address preserved in history.' });
      setEditGiven('');
      setEditFamily('');
      setEditLine1('');
      setEditPostcode('');
      setEditReason('');
      onSelectPatient(activePatientDetail.patient.id);
      onRefreshPatients();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Update failed' });
    }
  };

  const handleMerge = async (cand: DuplicateCandidate) => {
    setFeedback(null);
    try {
      await apiFetch('/api/patients-governance/merge', {
        method: 'POST',
        body: JSON.stringify({
          sourcePatientId: cand.patient_b_id,
          targetPatientId: cand.patient_a_id,
          candidateId: cand.id,
          reason: mergeReason,
        }),
      });
      setFeedback({ type: 'ok', text: `Merged ${cand.mrn_b} into ${cand.mrn_a} while preserving original provenance.` });
      loadGovernance();
      onRefreshPatients();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Merge failed' });
    }
  };

  const handleUnmerge = async (mergeEventId: string) => {
    setFeedback(null);
    try {
      await apiFetch(`/api/patients-governance/unmerge/${mergeEventId}`, {
        method: 'POST',
        body: JSON.stringify({ reason: unmergeReason }),
      });
      setFeedback({ type: 'ok', text: 'Controlled unmerge completed; original patient records and identifiers restored.' });
      loadGovernance();
      onRefreshPatients();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unmerge failed' });
    }
  };

  const filtered = patients.filter((p) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return (
      `${p.given_names} ${p.family_name}`.toLowerCase().includes(q) ||
      p.internal_mrn.toLowerCase().includes(q) ||
      (p.nhs_number || '').includes(q.replace(/\s+/g, '')) ||
      p.birth_date.includes(q)
    );
  });

  return (
    <div className="p-6 space-y-6 max-w-[1400px]">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Patient Register & Identity Governance</h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Stable internal identifiers, Modulus-11 NHS Number verification, demographic history, and duplicate-candidate review.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            type="button"
            onClick={() => setSubTab('register_list')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              subTab === 'register_list' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Patient Directory
          </button>
          <button
            type="button"
            onClick={() => setSubTab('demographics')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              subTab === 'demographics' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Demographics & History
          </button>
          <button
            type="button"
            onClick={() => setSubTab('duplicates')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              subTab === 'duplicates' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Duplicate Review & Merge ({duplicates.filter((d) => d.review_status === 'pending_review').length})
          </button>
        </div>
      </div>

      {feedback && (
        <div
          role="status"
          className={`p-3 rounded-lg border text-sm ${
            feedback.type === 'ok' ? 'bg-teal-50 border-teal-200 text-teal-900' : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {subTab === 'register_list' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[260px] max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by name, NHS Number, MRN, or DOB..."
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>
            <button
              type="button"
              onClick={() => setShowNewForm((v) => !v)}
              className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] hover:bg-[#132E54] text-white rounded-lg flex items-center gap-2 whitespace-nowrap"
            >
              <UserPlus className="w-4 h-4" />
              {showNewForm ? 'Close Registration Form' : 'Register New Patient'}
            </button>
          </div>

          {showNewForm && (
            <form onSubmit={handleRegister} className="border border-slate-200 rounded-lg p-5 bg-slate-50 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900">New Patient Registration (Independent Internal MRN + Mod-11 NHS Check)</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Given Names *</label>
                  <input required value={givenNames} onChange={(e) => setGivenNames(e.target.value)} placeholder="e.g. Beatrice" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Family Name *</label>
                  <input required value={familyName} onChange={(e) => setFamilyName(e.target.value)} placeholder="e.g. Hawthorne" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Date of Birth *</label>
                  <input type="date" required value={birthDate} onChange={(e) => setBirthDate(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Administrative Gender *</label>
                  <select value={gender} onChange={(e) => setGender(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg">
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                    <option value="other">Other</option>
                    <option value="not_stated">Not Stated</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">NHS Number (optional, Mod-11 checked)</label>
                  <input value={nhsNumber} onChange={(e) => setNhsNumber(e.target.value)} placeholder="e.g. 9990000077" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Home Address Line 1</label>
                  <input value={addressLine1} onChange={(e) => setAddressLine1(e.target.value)} placeholder="e.g. 19 Bath Road" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Postcode</label>
                  <input value={postcode} onChange={(e) => setPostcode(e.target.value)} placeholder="e.g. RG1 6HH" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Initial Allergy Assessment</label>
                  <select value={allergyStatus} onChange={(e) => setAllergyStatus(e.target.value)} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg">
                    <option value="not_assessed">Not Assessed (Default)</option>
                    <option value="assessed_no_known_allergies">Assessed — No Known Allergies</option>
                    <option value="unknown">Unknown</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setShowNewForm(false)} className="px-4 py-2 text-xs font-medium border border-slate-300 bg-white rounded-lg text-slate-700">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 text-xs font-medium bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
                  Create Patient Record
                </button>
              </div>
            </form>
          )}

          <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Patient Name</th>
                  <th className="py-2.5 px-4">Internal MRN</th>
                  <th className="py-2.5 px-4">NHS Number</th>
                  <th className="py-2.5 px-4">DOB & Gender</th>
                  <th className="py-2.5 px-4">Allergy Status</th>
                  <th className="py-2.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {filtered.map((pt) => (
                  <tr key={pt.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-medium text-slate-900">
                      {pt.family_name.toUpperCase()}, {pt.given_names}
                      {pt.sensitivity_level !== 'normal' && <span className="ml-2 text-xs text-amber-800 font-normal">· Restricted</span>}
                    </td>
                    <td className="py-3 px-4 font-mono text-xs tabular-nums text-slate-700">{pt.internal_mrn}</td>
                    <td className="py-3 px-4 font-mono text-xs tabular-nums text-slate-700">
                      {pt.nhs_formatted || 'Unverified'} · <span className="font-sans text-slate-500">{pt.nhs_verification || 'none'}</span>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs tabular-nums text-slate-700">
                      {pt.birth_date} · <span className="font-sans">{pt.administrative_gender}</span>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-700">{pt.allergy_assessment_status}</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => onSelectPatient(pt.id)}
                        className="px-3 py-1 text-xs font-medium text-teal-800 hover:bg-teal-50 border border-teal-200 rounded-md whitespace-nowrap"
                      >
                        Open Chart
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {subTab === 'demographics' && (
        <div className="space-y-6">
          {!activePatientDetail ? (
            <div className="p-6 border border-slate-200 rounded-lg text-sm text-slate-600">Select an authorised patient to view or update demographic history.</div>
          ) : (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <section className="border border-slate-200 rounded-lg p-5 bg-white space-y-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                    <History className="w-4 h-4 text-teal-700" /> Identifier Provenance & Name/Address History
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-500 mb-2">External & Internal Identifiers</h4>
                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg text-xs">
                      {activePatientDetail.identifiers.map((id) => (
                        <div key={id.id} className="p-2.5 flex items-center justify-between gap-2">
                          <div>
                            <span className="font-mono font-semibold text-slate-900">{id.identifier_value}</span>
                            <span className="text-slate-600 ml-2">({id.identifier_type} · {id.issuing_authority})</span>
                          </div>
                          <span className="text-slate-600">{id.verification_status}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-500 mb-2">Name History</h4>
                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg text-xs">
                      {activePatientDetail.names.map((nm) => (
                        <div key={nm.id} className="p-2.5 flex items-center justify-between">
                          <span className="font-medium text-slate-900">{nm.prefix ? `${nm.prefix} ` : ''}{nm.given_names} {nm.family_name} ({nm.name_use})</span>
                          <span className="font-mono text-slate-500">{nm.effective_from.slice(0, 10)} → {nm.effective_to ? nm.effective_to.slice(0, 10) : 'Current'}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-500 mb-2">Address History</h4>
                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg text-xs">
                      {activePatientDetail.addresses.map((ad) => (
                        <div key={ad.id} className="p-2.5 flex items-center justify-between">
                          <span className="text-slate-800">{ad.line1}, {ad.city}, {ad.postcode}</span>
                          <span className="font-mono text-slate-500">{ad.effective_to ? `Ended ${ad.effective_to.slice(0, 10)}` : 'Current'}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>

                <form onSubmit={handleUpdateDemographics} className="border border-slate-200 rounded-lg p-5 bg-white space-y-4">
                  <h3 className="text-sm font-semibold text-slate-900">Record Demographic Update (Preserves Historical Entries)</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Updated Given Names</label>
                      <input value={editGiven} onChange={(e) => setEditGiven(e.target.value)} placeholder="Leave blank to keep current" className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Updated Family Name</label>
                      <input value={editFamily} onChange={(e) => setEditFamily(e.target.value)} placeholder="Leave blank to keep current" className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">New Address Line 1</label>
                      <input value={editLine1} onChange={(e) => setEditLine1(e.target.value)} placeholder="Leave blank to keep current" className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">New Postcode</label>
                      <input value={editPostcode} onChange={(e) => setEditPostcode(e.target.value)} placeholder="e.g. RG2 7AX" className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Reason for Update</label>
                    <input value={editReason} onChange={(e) => setEditReason(e.target.value)} placeholder="e.g. Patient notified change of address" className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg" />
                  </div>
                  <button type="submit" className="px-4 py-2 text-xs font-medium bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
                    Save Demographic History Update
                  </button>
                </form>
              </div>
            </>
          )}
        </div>
      )}

      {subTab === 'duplicates' && (
        <div className="space-y-6">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700">
            <strong>Identity Safety Rule:</strong> Matching names and dates of birth never trigger automatic merges. Duplicate candidates require side-by-side verification, authorised merge, and retain full provenance snapshots for controlled reversal if needed.
          </div>

          {duplicates.map((cand) => (
            <div key={cand.id} className="border border-slate-200 rounded-lg p-5 bg-white space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-sm font-semibold text-slate-900">Duplicate Candidate · Match Score {(cand.match_score * 100).toFixed(0)}%</span>
                  <p className="text-xs text-slate-600 mt-0.5">{cand.match_rationale}</p>
                </div>
                <span className="text-xs font-semibold text-slate-800">Status: {cand.review_status}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
                  <div className="font-semibold text-slate-900 mb-1">Primary Target Candidate: {cand.name_a}</div>
                  <div className="font-mono text-slate-700">MRN: {cand.mrn_a} · DOB: {cand.dob_a}</div>
                  <div className="font-mono text-slate-700">NHS: {cand.nhs_a || 'None'}</div>
                  <div className="text-slate-600 mt-1">Address: {cand.addr_a || 'None'}</div>
                </div>
                <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
                  <div className="font-semibold text-slate-900 mb-1">Secondary Source Candidate: {cand.name_b}</div>
                  <div className="font-mono text-slate-700">MRN: {cand.mrn_b} · DOB: {cand.dob_b}</div>
                  <div className="font-mono text-slate-700">ID: {cand.ident_b || 'None'} ({cand.ident_type_b || 'local'})</div>
                  <div className="text-slate-600 mt-1">Address: {cand.addr_b || 'None'}</div>
                </div>
              </div>

              {cand.review_status === 'pending_review' && (
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <input
                    value={mergeReason}
                    onChange={(e) => setMergeReason(e.target.value)}
                    className="flex-1 min-w-[260px] px-3 py-2 text-xs border border-slate-300 rounded-lg"
                    placeholder="Documented verification reason..."
                  />
                  <button
                    type="button"
                    onClick={() => handleMerge(cand)}
                    className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] hover:bg-[#132E54] text-white rounded-lg flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <GitMerge className="w-3.5 h-3.5" />
                    Authorise Merge into {cand.mrn_a}
                  </button>
                </div>
              )}
            </div>
          ))}

          {mergeEvents.length > 0 && (
            <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
              <div className="px-5 py-3 border-b border-slate-200 font-semibold text-sm text-slate-900">
                Patient Merge & Unmerge Correction History
              </div>
              <div className="divide-y divide-slate-200">
                {mergeEvents.map((me) => (
                  <div key={me.id} className="p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">
                        Action: {me.action.toUpperCase()} · By {me.performed_by_name} · {me.performed_at.slice(0, 19).replace('T', ' ')}
                      </div>
                      <div className="text-slate-600 mt-0.5">{me.reason}</div>
                    </div>
                    {me.action === 'merge' && !me.reversed_by_event_id && (
                      <div className="flex items-center gap-2">
                        <input
                          value={unmergeReason}
                          onChange={(e) => setUnmergeReason(e.target.value)}
                          className="w-64 px-2.5 py-1.5 border border-slate-300 rounded-md"
                        />
                        <button
                          type="button"
                          onClick={() => handleUnmerge(me.id)}
                          className="px-3 py-1.5 bg-amber-700 hover:bg-amber-800 text-white font-medium rounded-md flex items-center gap-1 whitespace-nowrap"
                        >
                          <Undo2 className="w-3.5 h-3.5" />
                          Controlled Unmerge
                        </button>
                      </div>
                    )}
                    {me.reversed_by_event_id && <span className="text-amber-800 font-medium">Reversed by controlled unmerge</span>}
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
};
