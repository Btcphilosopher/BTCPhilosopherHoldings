import React, { useEffect, useState } from 'react';
import { DatabaseBackup, RefreshCw, ShieldCheck, CheckCircle2, Sparkles } from 'lucide-react';
import { apiFetch } from '../api.ts';
import type { ActorSession } from '../types.ts';

interface AdministrationViewProps {
  actor: ActorSession;
  onSessionRefresh: () => void;
}

export const AdministrationView: React.FC<AdministrationViewProps> = ({ actor, onSessionRefresh }) => {
  const [subTab, setSubTab] = useState<'governance' | 'audit' | 'interop' | 'backup' | 'demo'>('governance');
  const [overview, setOverview] = useState<any>(null);
  const [auditData, setAuditData] = useState<{ events: any[]; scope: string; verification: any } | null>(null);
  const [interopData, setInteropData] = useState<{ inbox: any[]; outbox: any[] } | null>(null);
  const [drillResult, setDrillResult] = useState<any>(null);
  const [runningDrill, setRunningDrill] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const loadAll = () => {
    apiFetch('/api/admin/overview').then(setOverview).catch(() => {});
    apiFetch<{ events: any[]; scope: string; verification: any }>('/api/admin/audit').then(setAuditData).catch(() => {});
    apiFetch<{ inbox: any[]; outbox: any[] }>('/api/interoperability/inbox').then(setInteropData).catch(() => {});
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleToggleAi = async (enabled: boolean) => {
    setFeedback(null);
    try {
      await apiFetch('/api/admin/ai-config', { method: 'PATCH', body: JSON.stringify({ enabled }) });
      setFeedback({ type: 'ok', text: `Optional AI Clinical Draft Assistant ${enabled ? 'enabled' : 'disabled'} at organisation level.` });
      onSessionRefresh();
      loadAll();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to change AI policy' });
    }
  };

  const handleRunBackupDrill = async () => {
    setRunningDrill(true);
    setFeedback(null);
    try {
      const res = await apiFetch('/api/admin/backup-restore-drill', { method: 'POST' });
      setDrillResult(res);
      setFeedback({ type: 'ok', text: 'Isolated backup & restoration verification completed.' });
      loadAll();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Restore drill failed' });
    } finally {
      setRunningDrill(false);
    }
  };

  const handleRetryInbox = async (id: string) => {
    setFeedback(null);
    try {
      const res = await apiFetch<{ message: string }>(`/api/interoperability/inbox/${id}/retry`, { method: 'POST' });
      setFeedback({ type: 'ok', text: res.message });
      loadAll();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Retry failed' });
    }
  };

  const demoSteps = [
    '1. Register a patient (Patients → Register New Patient with Mod-11 NHS check)',
    '2. Open an encounter (Encounters → Open New Encounter)',
    '3. Record observations and an allergy (Observations & Allergies tabs)',
    '4. Write and sign a consultation note (Notes → Draft → Test 409 Conflict → Review & Sign)',
    '5. Add an attributed amendment (Notes → Sign Addendum on immutable signed note)',
    '6. Import a diagnostic result via UK Core FHIR R4 (Results → Ingest FHIR Bundle)',
    '7. Receive a corrected version retaining replacement link (Results → status="corrected" with Replaces ID)',
    '8. Assign follow-up task on result (Results → assigned for followup)',
    '9. Search chronological timeline & global zero-leakage search (Timeline & Top Search bar)',
    '10. Review potential duplicate patient & test merge/unmerge (Patients → Duplicate Review)',
    '11. Inspect append-only hash-chained access audit & Break-Glass IG review (Administration → Audit)',
    '12. Restore database & attachments into isolated environment (Administration → Backup & Restore)',
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1400px]">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Administration, Governance & Audit</h2>
          <p className="text-sm text-slate-600">Organisational controls, Break-Glass IG review, UK Core interoperability queue, hash-chained audit, and backup restoration verification.</p>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
          {([
            ['governance', 'Governance & AI'],
            ['audit', 'Access Audit'],
            ['interop', 'FHIR Inbox/Outbox'],
            ['backup', 'Backup & Restore'],
            ['demo', '12-Step Verification'],
          ] as const).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setSubTab(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                subTab === key ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {feedback && (
        <div className={`p-3 rounded-lg border text-sm ${feedback.type === 'ok' ? 'bg-teal-50 border-teal-200 text-teal-900' : 'bg-red-50 border-red-200 text-red-800'}`}>
          {feedback.text}
        </div>
      )}

      {subTab === 'governance' && overview && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="border border-slate-200 rounded-lg p-5 bg-white space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-teal-700" /> Optional AI Clinical Assistant Adapter
                </h3>
                <span className="text-xs font-semibold text-slate-800">
                  {overview.organisation.ai_assistant_enabled === 1 ? 'Enabled' : 'Disabled (Default)'}
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Disabled by default. Requires Caldicott Guardian / IG Lead authorisation. Respects patient consent directives (`ai_draft_assistance`) and user sensitivity restrictions; never signs, prescribes, or runs SQL.
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleAi(overview.organisation.ai_assistant_enabled !== 1)}
                  className="px-3.5 py-2 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg hover:bg-[#132E54]"
                >
                  {overview.organisation.ai_assistant_enabled === 1 ? 'Disable AI Assistant' : 'Enable AI Assistant (Caldicott Only)'}
                </button>
              </div>
            </section>

            <section className="border border-slate-200 rounded-lg p-5 bg-white space-y-3">
              <h3 className="text-sm font-semibold text-slate-900">Retention Policies (Records Management Code of Practice)</h3>
              <div className="divide-y divide-slate-200 text-xs">
                {overview.retentionPolicies.map((rp: any) => (
                  <div key={rp.id} className="py-2 flex justify-between gap-4">
                    <div>
                      <div className="font-semibold text-slate-900">{rp.record_category}</div>
                      <div className="text-slate-500">{rp.statutory_basis}</div>
                    </div>
                    <span className="font-mono font-semibold text-slate-800 shrink-0">{rp.retention_years} yrs</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 text-sm font-semibold text-slate-900">
              Break-Glass Emergency Access Review Queue ({overview.breakGlassGrants.length})
            </div>
            {overview.breakGlassGrants.length === 0 ? (
              <div className="p-5 text-xs text-slate-500">No emergency Break-Glass overrides recorded yet.</div>
            ) : (
              <div className="divide-y divide-slate-200">
                {overview.breakGlassGrants.map((g: any) => (
                  <div key={g.id} className="p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">{g.user_name} ({g.role_code}) → Patient: {g.patient_name}</div>
                      <div className="text-slate-700 mt-0.5">Reason: {g.reason}</div>
                      <div className="font-mono text-slate-500 mt-0.5">Granted: {g.granted_at} · Status: {g.ig_review_status}</div>
                    </div>
                    {g.ig_review_status === 'pending_review' && (
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            await apiFetch(`/api/admin/break-glass/${g.id}/review`, { method: 'POST', body: JSON.stringify({ status: 'justified' }) });
                            loadAll();
                          }}
                          className="px-3 py-1.5 bg-teal-700 text-white rounded font-medium"
                        >
                          Mark Justified
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await apiFetch(`/api/admin/break-glass/${g.id}/review`, { method: 'POST', body: JSON.stringify({ status: 'flagged_inappropriate' }) });
                            loadAll();
                          }}
                          className="px-3 py-1.5 bg-red-700 text-white rounded font-medium"
                        >
                          Flag Inappropriate
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {subTab === 'audit' && auditData && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-700" />
              <span>
                <strong>Hash-Chain Verification:</strong> {auditData.verification.valid ? 'VALID' : 'BROKEN'} ({auditData.verification.totalEvents} events) · Scope: {auditData.scope}
              </span>
            </div>
            <span className="text-slate-600">{auditData.verification.note}</span>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-semibold">
                  <th className="py-2.5 px-3">Seq</th>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">Actor & Role</th>
                  <th className="py-2.5 px-3">Action & Outcome</th>
                  <th className="py-2.5 px-3">Resource</th>
                  <th className="py-2.5 px-3">Event SHA-256</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {auditData.events.map((ev) => (
                  <tr key={ev.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono tabular-nums">{ev.seq_id}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-600">{ev.occurred_at.slice(0, 19).replace('T', ' ')}</td>
                    <td className="py-2.5 px-3">{ev.actor_name || 'System'} · <span className="text-slate-500">{ev.actor_role}</span></td>
                    <td className="py-2.5 px-3">
                      <span className="font-semibold text-slate-900">{ev.action}</span> ·{' '}
                      <span className={ev.outcome === 'denied' ? 'text-red-700 font-semibold' : 'text-teal-800'}>{ev.outcome}</span>
                      {ev.reason && <div className="text-slate-500">{ev.reason}</div>}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{ev.resource_type}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-500">{ev.event_hash.slice(0, 16)}...</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {subTab === 'interop' && interopData && (
        <div className="space-y-6">
          <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 text-sm font-semibold text-slate-900">
              Integration Inbox (UK Core FHIR R4 · Mapping & Failed Message Retry)
            </div>
            <div className="divide-y divide-slate-200">
              {interopData.inbox.map((m) => (
                <div key={m.id} className="p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="font-semibold text-slate-900">{m.source_system} · Message ID: <span className="font-mono">{m.external_message_id}</span></div>
                    <div className="text-slate-600 mt-0.5">Format: {m.message_format} · Mapping: {m.mapping_version} · Status: <strong>{m.processing_status}</strong> · Retries: {m.retry_count}</div>
                    {m.error_detail && <div className="text-red-700 mt-1">{m.error_detail}</div>}
                  </div>
                  {m.processing_status === 'failed_retrying' && (
                    <button
                      type="button"
                      onClick={() => handleRetryInbox(m.id)}
                      className="px-3 py-1.5 bg-[#0B1F3A] text-white rounded-lg font-medium flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> Retry Processing
                    </button>
                  )}
                </div>
              ))}
            </div>
          </section>

          <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 text-sm font-semibold text-slate-900">
              Durable Integration Outbox
            </div>
            <div className="divide-y divide-slate-200">
              {interopData.outbox.map((o) => (
                <div key={o.id} className="p-4 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-900">{o.event_type} ({o.aggregate_type})</div>
                    <div className="font-mono text-slate-500">{o.aggregate_id} · Created {o.created_at}</div>
                  </div>
                  <span className="font-medium text-teal-800">{o.delivery_status} (attempts: {o.attempts})</span>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}

      {subTab === 'backup' && overview && (
        <div className="space-y-6">
          <div className="border border-slate-200 rounded-lg p-5 bg-white flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <DatabaseBackup className="w-4 h-4 text-teal-700" /> Backup & Isolated Restoration Verification Drill
              </h3>
              <p className="text-xs text-slate-600 mt-1">
                Creates an online snapshot of the live SQLite database and all protected attachments in an isolated folder, runs `PRAGMA integrity_check`, verifies SHA-256 attachment hashes, and measures RTO against targets (RPO ≤ 300s, RTO ≤ 900s).
              </p>
            </div>
            <button
              type="button"
              disabled={runningDrill}
              onClick={handleRunBackupDrill}
              className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] hover:bg-[#132E54] disabled:opacity-50 text-white rounded-lg whitespace-nowrap"
            >
              {runningDrill ? 'Running Isolated Restore...' : 'Run Backup & Restore Drill Now'}
            </button>
          </div>

          {drillResult && (
            <div className="border border-teal-200 rounded-lg p-5 bg-teal-50/50 space-y-3 text-xs">
              <div className="font-semibold text-teal-900 text-sm">
                Latest Isolated Restore Result — Integrity: {drillResult.integrityCheckPassed ? 'PASSED (ok)' : 'FAILED'} · Measured RTO: {drillResult.measuredRtoMs} ms
              </div>
              <div className="font-mono text-slate-700">Isolated Path: {drillResult.isolatedRestorePath}</div>
              <div className="font-mono text-slate-700">Attachments Verified: {drillResult.attachmentsVerified} (Failures: {drillResult.attachmentFailures})</div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                {Object.entries(drillResult.verifiedRowCounts).map(([tbl, count]) => (
                  <div key={tbl} className="p-2 bg-white border border-slate-200 rounded">
                    <div className="text-slate-500">{tbl}</div>
                    <div className="font-mono font-semibold text-slate-900 text-sm tabular-nums">{String(count)} rows</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="border border-slate-200 rounded-lg bg-white divide-y divide-slate-200">
            <div className="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-800">Recorded Drill History</div>
            {overview.backupDrills.map((d: any) => (
              <div key={d.id} className="p-4 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-slate-900">Drill {d.id.slice(0, 8)} · {d.started_at}</div>
                  <div className="text-slate-600">{d.notes}</div>
                </div>
                <div className="font-mono text-slate-800">RTO: {d.measured_rto_ms} ms · {d.integrity_check_passed === 1 ? 'PASS' : 'FAIL'}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {subTab === 'demo' && (
        <div className="border border-slate-200 rounded-lg p-6 bg-white space-y-4">
          <h3 className="text-base font-semibold text-slate-900">End-to-End Clinical Verification Scenarios</h3>
          <p className="text-xs text-slate-600">
            Every workflow below is live against the persistent SQL backend. You can also run `npm run verify` in the terminal to execute the automated API verification suite across all 12 steps plus concurrency conflicts, restricted record access denial, duplicate FHIR messages, and unauthorised rejection.
          </p>
          <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg">
            {demoSteps.map((step, i) => (
              <div key={i} className="p-3 text-sm text-slate-800 flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-700 shrink-0" />
                <span>{step}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
