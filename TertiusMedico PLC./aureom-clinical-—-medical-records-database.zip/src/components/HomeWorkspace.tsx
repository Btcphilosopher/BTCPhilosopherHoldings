import React, { useEffect, useState } from 'react';
import { FileEdit, FlaskConical, ListTodo, Stethoscope, Users } from 'lucide-react';
import { apiFetch } from '../api.ts';
import type { NavSection, PatientSummary } from '../types.ts';

interface HomeWorkspaceProps {
  onSelectPatient: (patientId: string, goTo?: NavSection) => void;
  onNavigate: (section: NavSection) => void;
}

interface HomePayload {
  patients: PatientSummary[];
  recentEncounters: Array<{
    id: string;
    patient_id: string;
    patient_name: string;
    internal_mrn: string;
    encounter_class: string;
    status: string;
    reason_text: string;
    started_at: string;
    location_name: string;
    attending_name: string;
  }>;
  draftNotes: Array<{
    id: string;
    patient_id: string;
    patient_name: string;
    internal_mrn: string;
    title: string;
    note_type: string;
    current_version: number;
    recorded_at: string;
  }>;
  resultsForReview: Array<{
    id: string;
    patient_id: string;
    patient_name: string;
    internal_mrn: string;
    report_title: string;
    status: string;
    review_state: string;
    effective_time: string;
    source_system: string;
  }>;
  openTasks: Array<{
    id: string;
    patient_id: string;
    patient_name: string;
    internal_mrn: string;
    title: string;
    priority: string;
    status: string;
    due_at: string;
    assignee_name: string;
  }>;
  pendingDuplicatesCount: number;
}

export const HomeWorkspace: React.FC<HomeWorkspaceProps> = ({ onSelectPatient, onNavigate }) => {
  const [data, setData] = useState<HomePayload | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch<HomePayload>('/api/workspace/home')
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !data) {
    return (
      <div className="p-6 space-y-4">
        <div className="h-24 bg-slate-100 rounded-lg animate-pulse" />
        <div className="h-64 bg-slate-100 rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 max-w-[1400px]">
      <div className="flex flex-wrap items-baseline justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 tracking-tight">Clinical Workspace Overview</h2>
          <p className="text-sm text-slate-600 mt-1">
            Thames Valley Integrated Care Clinic · Active caseload, unsigned drafts, results awaiting acknowledgement, and pending tasks.
          </p>
        </div>
        {data.pendingDuplicatesCount > 0 && (
          <button
            type="button"
            onClick={() => onNavigate('patients')}
            className="px-4 py-2 text-xs font-medium bg-amber-50 border border-amber-300 text-amber-900 rounded-lg hover:bg-amber-100 transition-colors whitespace-nowrap"
          >
            {data.pendingDuplicatesCount} Potential Duplicate Identity Review Pending
          </button>
        )}
      </div>

      {/* Summary KPI strip */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="border border-slate-200 rounded-lg p-4 bg-white">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-teal-700" /> Active Patients
          </div>
          <div className="text-2xl font-semibold text-slate-900 tabular-nums mt-1">{data.patients.length}</div>
        </div>
        <div className="border border-slate-200 rounded-lg p-4 bg-white">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Stethoscope className="w-3.5 h-3.5 text-teal-700" /> Recent Encounters
          </div>
          <div className="text-2xl font-semibold text-slate-900 tabular-nums mt-1">{data.recentEncounters.length}</div>
        </div>
        <div className="border border-slate-200 rounded-lg p-4 bg-white">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <FileEdit className="w-3.5 h-3.5 text-amber-600" /> Draft Notes
          </div>
          <div className="text-2xl font-semibold text-slate-900 tabular-nums mt-1">{data.draftNotes.length}</div>
        </div>
        <div className="border border-slate-200 rounded-lg p-4 bg-white">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <FlaskConical className="w-3.5 h-3.5 text-red-600" /> Results Requiring Review
          </div>
          <div className="text-2xl font-semibold text-slate-900 tabular-nums mt-1">{data.resultsForReview.length}</div>
        </div>
        <div className="border border-slate-200 rounded-lg p-4 bg-white">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <ListTodo className="w-3.5 h-3.5 text-teal-700" /> Open Follow-Up Tasks
          </div>
          <div className="text-2xl font-semibold text-slate-900 tabular-nums mt-1">{data.openTasks.length}</div>
        </div>
      </div>

      {/* Main 2-column grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Assigned Patients */}
        <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">Assigned & Registered Patients</h3>
            <button type="button" onClick={() => onNavigate('patients')} className="text-xs font-medium text-teal-800 hover:underline">
              Open Patient Register
            </button>
          </div>
          <div className="divide-y divide-slate-200">
            {data.patients.map((pt) => (
              <button
                key={pt.id}
                type="button"
                onClick={() => onSelectPatient(pt.id, 'timeline')}
                className="w-full text-left px-5 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900 truncate">
                    {pt.family_name.toUpperCase()}, {pt.given_names}
                  </div>
                  <div className="text-xs text-slate-600 font-mono tabular-nums mt-0.5">
                    DOB {pt.birth_date} · NHS {pt.nhs_formatted || 'Unverified'} · MRN {pt.internal_mrn}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs font-medium text-slate-700">
                    {pt.accessAllowed ? (pt.allergy_assessment_status === 'not_assessed' ? 'Allergies Not Assessed' : 'Authorised') : 'Restricted Policy'}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Results Requiring Review */}
        <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">Diagnostic Results Requiring Review</h3>
            <button type="button" onClick={() => onNavigate('results')} className="text-xs font-medium text-teal-800 hover:underline">
              Review Queue
            </button>
          </div>
          {data.resultsForReview.length === 0 ? (
            <div className="p-6 text-sm text-slate-500">All authorised diagnostic results have been acknowledged.</div>
          ) : (
            <div className="divide-y divide-slate-200">
              {data.resultsForReview.map((res) => (
                <button
                  key={res.id}
                  type="button"
                  onClick={() => onSelectPatient(res.patient_id, 'results')}
                  className="w-full text-left px-5 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-900 truncate">{res.report_title}</div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {res.patient_name} ({res.internal_mrn}) · {res.source_system} · {res.effective_time.slice(0, 16).replace('T', ' ')}
                    </div>
                  </div>
                  <div className="text-xs font-medium text-red-700 whitespace-nowrap shrink-0">
                    {res.status} · {res.review_state}
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>

        {/* Draft Documentation */}
        <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">Unsigned Draft Documentation</h3>
            <button type="button" onClick={() => onNavigate('notes')} className="text-xs font-medium text-teal-800 hover:underline">
              Notes Workbench
            </button>
          </div>
          {data.draftNotes.length === 0 ? (
            <div className="p-6 text-sm text-slate-500">No unsigned draft notes pending.</div>
          ) : (
            <div className="divide-y divide-slate-200">
              {data.draftNotes.map((dn) => (
                <button
                  key={dn.id}
                  type="button"
                  onClick={() => onSelectPatient(dn.patient_id, 'notes')}
                  className="w-full text-left px-5 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-900 truncate">{dn.title}</div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {dn.patient_name} · {dn.note_type} · Draft v{dn.current_version}
                    </div>
                  </div>
                  <span className="text-xs font-medium text-amber-800 whitespace-nowrap shrink-0">Review & Sign</span>
                </button>
              ))}
            </div>
          )}
        </section>

        {/* Recent Encounters & Outstanding Tasks */}
        <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">Outstanding Follow-Up Tasks & Active Encounters</h3>
            <button type="button" onClick={() => onNavigate('tasks')} className="text-xs font-medium text-teal-800 hover:underline">
              Manage Tasks
            </button>
          </div>
          <div className="divide-y divide-slate-200">
            {data.openTasks.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => onSelectPatient(t.patient_id, 'tasks')}
                className="w-full text-left px-5 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900 truncate">{t.title}</div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {t.patient_name} · Assigned to {t.assignee_name} · Priority: {t.priority}
                  </div>
                </div>
                <span className="text-xs font-mono tabular-nums text-slate-600 shrink-0">Due {t.due_at?.slice(0, 10)}</span>
              </button>
            ))}
            {data.recentEncounters.slice(0, 3).map((enc) => (
              <button
                key={enc.id}
                type="button"
                onClick={() => onSelectPatient(enc.patient_id, 'encounters')}
                className="w-full text-left px-5 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-4"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-slate-900 truncate">
                    Encounter: {enc.patient_name} — {enc.reason_text}
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {enc.location_name} · {enc.attending_name} · {enc.status}
                  </div>
                </div>
                <span className="text-xs font-mono tabular-nums text-slate-500 shrink-0">{enc.started_at.slice(0, 10)}</span>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
