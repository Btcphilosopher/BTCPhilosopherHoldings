import React, { useEffect, useState } from 'react';
import { CheckSquare, FilePlus2, FileWarning, Lock, Sparkles, AlertCircle } from 'lucide-react';
import { ApiError, apiFetch } from '../api.ts';
import type { ActorSession, PatientDetailResponse } from '../types.ts';

interface NotesViewProps {
  patientDetail: PatientDetailResponse | null;
  actor: ActorSession;
}

interface ClinicalNoteRow {
  id: string;
  patient_id: string;
  title: string;
  note_type: string;
  status: 'draft' | 'signed' | 'amended' | 'entered_in_error';
  current_version: number;
  author_name: string;
  signer_name: string | null;
  event_time: string;
  signed_at: string | null;
  body_text: string;
  copiedMaterialRefs: Array<{ source_record_id: string; label: string }>;
  amendments: Array<{
    id: string;
    amendment_type: string;
    reason: string;
    addendum_text: string;
    author_name: string;
    professional_reg_no: string | null;
    signed_at: string;
    content_sha256: string;
  }>;
  signature: {
    id: string;
    attestation_statement: string;
    idempotency_key: string;
    content_sha256: string;
    signed_at: string;
    signer_name: string;
    professional_reg_no: string | null;
  } | null;
  entered_in_error_reason?: string | null;
}

export const NotesView: React.FC<NotesViewProps> = ({ patientDetail, actor }) => {
  const [notes, setNotes] = useState<ClinicalNoteRow[]>([]);
  const [selectedNote, setSelectedNote] = useState<ClinicalNoteRow | null>(null);
  const [draftTitle, setDraftTitle] = useState('');
  const [draftBody, setDraftBody] = useState('');
  const [draftType, setDraftType] = useState('consultation');
  const [copiedLabel, setCopiedLabel] = useState('');
  const [expectedVersion, setExpectedVersion] = useState<number>(1);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [attestation, setAttestation] = useState('I clinically attest this record is accurate and complete at the time of signing.');
  const [amendReason, setAmendReason] = useState('');
  const [amendText, setAmendText] = useState('');
  const [errorReason, setErrorReason] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Optional AI Draft Assistant
  const [aiPrompt, setAiPrompt] = useState('Draft a source-linked clinical handover summary preserving any conflicting records or unconfirmed allergies.');
  const [aiResult, setAiResult] = useState<{
    draftSummary: string;
    sourceCitations: Array<{ recordId: string; recordType: string; label: string }>;
    conflictsDetected: string[];
    modelUsed: string;
  } | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  const patientId = patientDetail?.patient.id;

  const loadNotes = () => {
    if (!patientId) return;
    apiFetch<{ notes: ClinicalNoteRow[] }>(`/api/notes?patientId=${patientId}`)
      .then((res) => {
        setNotes(res.notes);
        if (res.notes.length > 0) {
          const match = selectedNote ? res.notes.find((n) => n.id === selectedNote.id) : null;
          const target = match || res.notes[0];
          setSelectedNote(target);
          setDraftTitle(target.title);
          setDraftBody(target.body_text);
          setExpectedVersion(target.current_version);
        } else {
          setSelectedNote(null);
        }
      })
      .catch((err) => setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to load notes' }));
  };

  useEffect(() => {
    loadNotes();
  }, [patientId]);

  if (!patientDetail) {
    return <div className="p-6 text-sm text-slate-600">Select an authorised patient to view or author clinical notes.</div>;
  }

  const handleCreateDraft = async () => {
    setFeedback(null);
    try {
      const copied = copiedLabel.trim() ? [{ source_record_id: 'manual-ref', label: copiedLabel.trim() }] : [];
      const res = await apiFetch<{ id: string }>('/api/notes', {
        method: 'POST',
        body: JSON.stringify({
          patientId,
          encounterId: patientDetail.encounters.find((e) => e.status === 'in_progress')?.id || null,
          noteType: draftType,
          title: draftTitle.trim() || 'Clinical Consultation Note',
          bodyText: draftBody.trim() || 'Initial clinical assessment:',
          copiedMaterialRefs: copied,
        }),
      });
      setFeedback({ type: 'ok', text: `Created draft note (${res.id.slice(0, 8)}).` });
      setCopiedLabel('');
      loadNotes();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Unable to create draft' });
    }
  };

  const handleSaveDraft = async (simulateStaleConflict = false) => {
    if (!selectedNote) return;
    setFeedback(null);
    try {
      const res = await apiFetch<{ currentVersion: number }>(`/api/notes/${selectedNote.id}/draft`, {
        method: 'PUT',
        body: JSON.stringify({
          title: draftTitle,
          bodyText: draftBody,
          expectedVersion: simulateStaleConflict ? Math.max(0, expectedVersion - 1) : expectedVersion,
        }),
      });
      setExpectedVersion(res.currentVersion);
      setFeedback({ type: 'ok', text: `Draft autosaved as version ${res.currentVersion}.` });
      loadNotes();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Failed to save draft';
      setFeedback({ type: 'err', text: msg });
    }
  };

  const handleSign = async () => {
    if (!selectedNote) return;
    setFeedback(null);
    try {
      const idempotencyKey = `sign-${selectedNote.id}-v${selectedNote.current_version}`;
      await apiFetch(`/api/notes/${selectedNote.id}/sign`, {
        method: 'POST',
        body: JSON.stringify({
          expectedVersion: selectedNote.current_version,
          idempotencyKey,
          attestationStatement: attestation,
        }),
      });
      setReviewOpen(false);
      setFeedback({ type: 'ok', text: 'Note signed atomically with immutable version lock and audit log entry.' });
      loadNotes();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Signing failed' });
    }
  };

  const handleAddAmendment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedNote) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/notes/${selectedNote.id}/amendments`, {
        method: 'POST',
        body: JSON.stringify({
          amendmentType: 'addendum',
          reason: amendReason,
          addendumText: amendText,
        }),
      });
      setAmendReason('');
      setAmendText('');
      setFeedback({ type: 'ok', text: 'Attributed addendum appended to signed note.' });
      loadNotes();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Amendment failed' });
    }
  };

  const handleEnterInError = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedNote) return;
    setFeedback(null);
    try {
      await apiFetch(`/api/notes/${selectedNote.id}/enter-in-error`, {
        method: 'POST',
        body: JSON.stringify({ reason: errorReason }),
      });
      setErrorReason('');
      setFeedback({ type: 'ok', text: 'Note marked entered-in-error; full history retained.' });
      loadNotes();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Action failed' });
    }
  };

  const handleAiSummary = async () => {
    setAiLoading(true);
    setFeedback(null);
    try {
      const res = await apiFetch<NonNullable<typeof aiResult>>(`/api/patients/${patientId}/ai-summary`, {
        method: 'POST',
        body: JSON.stringify({ prompt: aiPrompt }),
      });
      setAiResult(res);
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'AI summary unavailable' });
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px]">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Clinical Notes & Amendments</h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Draft → Review & Atomic Sign (Immutable) → Attributed Addendum Amendments · Optimistic concurrency enforced.
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            setSelectedNote(null);
            setDraftTitle('');
            setDraftBody('');
          }}
          className="px-4 py-2 text-xs font-medium bg-[#0B1F3A] hover:bg-[#132E54] text-white rounded-lg flex items-center gap-1.5 whitespace-nowrap"
        >
          <FilePlus2 className="w-4 h-4" />
          New Draft Note
        </button>
      </div>

      {feedback && (
        <div
          role="alert"
          className={`p-3 rounded-lg border text-sm ${
            feedback.type === 'ok' ? 'bg-teal-50 border-teal-200 text-teal-900' : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          {feedback.text}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Note List */}
        <div className="lg:col-span-4 border border-slate-200 rounded-lg bg-white overflow-hidden self-start">
          <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700">
            Patient Notes ({notes.length})
          </div>
          <div className="divide-y divide-slate-200">
            {notes.map((n) => (
              <button
                key={n.id}
                type="button"
                onClick={() => {
                  setSelectedNote(n);
                  setDraftTitle(n.title);
                  setDraftBody(n.body_text);
                  setExpectedVersion(n.current_version);
                }}
                className={`w-full text-left p-4 transition-colors ${
                  selectedNote?.id === n.id ? 'bg-teal-50/70' : 'hover:bg-slate-50'
                }`}
              >
                <div className="text-sm font-semibold text-slate-900">{n.title}</div>
                <div className="text-xs text-slate-600 mt-1">
                  {n.note_type} · Status: <strong>{n.status}</strong> · v{n.current_version}
                </div>
                <div className="text-xs font-mono text-slate-500 mt-0.5">{n.event_time.slice(0, 16).replace('T', ' ')} · {n.author_name}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Editor / Signed Record Viewer */}
        <div className="lg:col-span-8 space-y-6">
          {!selectedNote ? (
            <div className="border border-slate-200 rounded-lg p-5 bg-white space-y-4">
              <h3 className="text-base font-semibold text-slate-900">Author New Clinical Draft</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Note Type</label>
                  <select value={draftType} onChange={(e) => setDraftType(e.target.value)} className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg">
                    <option value="consultation">Consultation Note</option>
                    <option value="ward_round">Ward Round Note</option>
                    <option value="discharge_summary">Discharge Summary</option>
                    <option value="nursing_assessment">Nursing Assessment</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Title</label>
                  <input value={draftTitle} onChange={(e) => setDraftTitle(e.target.value)} placeholder="e.g. Cardiology Outpatient Consultation" className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Copied Material Attribution (optional)</label>
                <input value={copiedLabel} onChange={(e) => setCopiedLabel(e.target.value)} placeholder="e.g. Copied from LIS Creatinine result LIS-88291-C" className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Clinical Narrative</label>
                <textarea rows={7} value={draftBody} onChange={(e) => setDraftBody(e.target.value)} className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg" placeholder="Enter clinical findings, assessment, and plan..." />
              </div>
              <button type="button" onClick={handleCreateDraft} className="px-4 py-2 text-xs font-medium bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
                Save as Draft (v1)
              </button>
            </div>
          ) : (
            <div className="border border-slate-200 rounded-lg p-6 bg-white space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900">{selectedNote.title}</h3>
                  <div className="text-xs text-slate-600 mt-1">
                    Author: {selectedNote.author_name} · Version <span className="font-mono">v{selectedNote.current_version}</span> · Status: <strong className="text-slate-900">{selectedNote.status}</strong>
                  </div>
                </div>
                {selectedNote.status === 'draft' && (
                  <div className="flex flex-wrap items-center gap-2">
                    <button type="button" onClick={() => handleSaveDraft(false)} className="px-3 py-1.5 text-xs font-medium border border-slate-300 rounded-lg hover:bg-slate-50">
                      Save Draft
                    </button>
                    <button type="button" onClick={() => handleSaveDraft(true)} className="px-3 py-1.5 text-xs font-medium border border-amber-300 text-amber-800 rounded-lg hover:bg-amber-50">
                      Test 409 Conflict
                    </button>
                    <button type="button" onClick={() => setReviewOpen(true)} className="px-3.5 py-1.5 text-xs font-medium bg-teal-700 hover:bg-teal-800 text-white rounded-lg flex items-center gap-1.5">
                      <CheckSquare className="w-3.5 h-3.5" />
                      Review & Sign
                    </button>
                  </div>
                )}
              </div>

              {selectedNote.copiedMaterialRefs.length > 0 && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                  <strong>Attributed Copied Material:</strong>{' '}
                  {selectedNote.copiedMaterialRefs.map((c) => c.label).join(' · ')}
                </div>
              )}

              {selectedNote.status === 'draft' ? (
                <div className="space-y-3">
                  <input value={draftTitle} onChange={(e) => setDraftTitle(e.target.value)} className="w-full px-3 py-2 text-sm font-medium border border-slate-300 rounded-lg" />
                  <textarea rows={8} value={draftBody} onChange={(e) => setDraftBody(e.target.value)} className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg leading-relaxed" />
                </div>
              ) : (
                <div className="space-y-4">
                  {selectedNote.status === 'entered_in_error' && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-900">
                      <strong>Entered in Error:</strong> {selectedNote.entered_in_error_reason} (Retained for clinical audit history)
                    </div>
                  )}

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg whitespace-pre-wrap text-sm text-slate-900 leading-relaxed">
                    {selectedNote.body_text}
                  </div>

                  {selectedNote.signature && (
                    <div className="p-3 bg-teal-50/60 border border-teal-200 rounded-lg text-xs text-slate-800 space-y-1">
                      <div className="flex items-center gap-1.5 font-semibold text-teal-900">
                        <Lock className="w-3.5 h-3.5" />
                        Immutable Signed Record · {selectedNote.signature.signer_name} ({selectedNote.signature.professional_reg_no || 'Clinician'})
                      </div>
                      <div>Attestation: "{selectedNote.signature.attestation_statement}"</div>
                      <div className="font-mono text-[11px] text-slate-600">
                        Signed {selectedNote.signature.signed_at} · SHA-256: {selectedNote.signature.content_sha256.slice(0, 24)}...
                      </div>
                    </div>
                  )}

                  {selectedNote.amendments.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-semibold text-slate-700">Linked Addenda & Amendments ({selectedNote.amendments.length})</h4>
                      {selectedNote.amendments.map((amd) => (
                        <div key={amd.id} className="p-3.5 border border-slate-200 rounded-lg bg-white text-xs space-y-1">
                          <div className="font-semibold text-slate-900">
                            {amd.amendment_type.toUpperCase()} · {amd.author_name} ({amd.professional_reg_no || 'Clinician'}) · {amd.signed_at.slice(0, 16).replace('T', ' ')}
                          </div>
                          <div className="text-slate-600">Reason: {amd.reason}</div>
                          <div className="text-sm text-slate-800 pt-1">{amd.addendum_text}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  {selectedNote.status !== 'entered_in_error' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-200">
                      <form onSubmit={handleAddAmendment} className="space-y-2">
                        <h4 className="text-xs font-semibold text-slate-800">Add Attributed Addendum</h4>
                        <input required value={amendReason} onChange={(e) => setAmendReason(e.target.value)} placeholder="Reason for addendum..." className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg" />
                        <textarea required rows={3} value={amendText} onChange={(e) => setAmendText(e.target.value)} placeholder="Addendum clinical text..." className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg" />
                        <button type="submit" className="px-3.5 py-1.5 text-xs font-medium bg-[#0B1F3A] text-white rounded-lg hover:bg-[#132E54]">
                          Sign Addendum
                        </button>
                      </form>

                      <form onSubmit={handleEnterInError} className="space-y-2">
                        <h4 className="text-xs font-semibold text-red-800 flex items-center gap-1">
                          <FileWarning className="w-3.5 h-3.5" /> Mark Entered-in-Error
                        </h4>
                        <input required value={errorReason} onChange={(e) => setErrorReason(e.target.value)} placeholder="Required reason (e.g. Charted on wrong encounter)" className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg" />
                        <button type="submit" className="px-3.5 py-1.5 text-xs font-medium border border-red-300 text-red-800 rounded-lg hover:bg-red-50">
                          Mark Entered-in-Error (Retain History)
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Optional Disabled-by-Default AI Clinical Assistant Adapter */}
          <section className="border border-slate-200 rounded-lg p-5 bg-slate-50 space-y-3">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-teal-700" />
                <h3 className="text-sm font-semibold text-slate-900">Optional AI Clinical Draft Assistant (Disabled by Default)</h3>
              </div>
              <span className="text-xs font-medium text-slate-700">
                Org Policy: {actor.ai_assistant_enabled === 1 ? 'Enabled (Draft-Only)' : 'Disabled'}
              </span>
            </div>
            <p className="text-xs text-slate-600">
              Enforces the requesting clinician's exact patient & sensitivity permissions, preserves conflicting records, cannot execute SQL, sign notes, prescribe, or acknowledge results. Toggle in Administration → Governance.
            </p>
            <div className="flex flex-wrap gap-2">
              <input
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                className="flex-1 min-w-[240px] px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
              <button
                type="button"
                disabled={aiLoading}
                onClick={handleAiSummary}
                className="px-4 py-2 text-xs font-medium bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white rounded-lg whitespace-nowrap"
              >
                {aiLoading ? 'Generating Source-Linked Draft...' : 'Draft Source-Linked Summary'}
              </button>
            </div>
            {aiResult && (
              <div className="p-4 bg-white border border-slate-200 rounded-lg space-y-3 text-xs">
                {aiResult.conflictsDetected.length > 0 && (
                  <div className="p-2.5 bg-amber-50 border border-amber-200 rounded text-amber-900 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      <strong>Preserved Source Conflicts:</strong> {aiResult.conflictsDetected.join(' | ')}
                    </div>
                  </div>
                )}
                <div className="text-sm text-slate-800 whitespace-pre-wrap leading-relaxed">{aiResult.draftSummary}</div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <span className="text-slate-500">Model: {aiResult.modelUsed} · Citations: {aiResult.sourceCitations.length}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedNote(null);
                      setDraftTitle('AI-Assisted Clinical Summary (Clinician Review Required)');
                      setDraftBody(aiResult.draftSummary);
                      setCopiedLabel('AI Source-Linked Draft (Reviewed by Clinician)');
                    }}
                    className="px-3 py-1.5 bg-[#0B1F3A] text-white rounded font-medium"
                  >
                    Insert into New Draft Note for Review
                  </button>
                </div>
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Review Before Signing Modal */}
      {reviewOpen && selectedNote && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-xl w-full p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-semibold text-slate-900">Review Before Signing Clinical Note</h3>
            <p className="text-xs text-slate-600">
              Signing locks version v{selectedNote.current_version} permanently, computes a SHA-256 content digest, and atomically records an audit trail entry. Subsequent corrections require a linked addendum.
            </p>
            <div className="max-h-48 overflow-y-auto p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs whitespace-pre-wrap text-slate-800">
              {draftBody}
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Clinical Attestation Statement</label>
              <input value={attestation} onChange={(e) => setAttestation(e.target.value)} className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg" />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setReviewOpen(false)} className="px-4 py-2 text-xs font-medium border border-slate-300 rounded-lg text-slate-700">
                Return to Draft
              </button>
              <button type="button" onClick={handleSign} className="px-4 py-2 text-xs font-medium bg-teal-700 hover:bg-teal-800 text-white rounded-lg">
                Sign & Lock Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
