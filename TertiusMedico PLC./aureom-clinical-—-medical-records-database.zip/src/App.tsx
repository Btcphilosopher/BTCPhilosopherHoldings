import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  AlertOctagon,
  CalendarClock,
  ClipboardList,
  FileText,
  FlaskConical,
  FolderLock,
  Home,
  ListTodo,
  LogOut,
  Pill,
  Search,
  Settings,
  ShieldCheck,
  Stethoscope,
  Users,
  X,
} from 'lucide-react';
import { ApiError, apiFetch, setAuthToken } from './api.ts';
import { AdministrationView } from './components/AdministrationView.tsx';
import { ClinicalSectionsView } from './components/ClinicalSectionsView.tsx';
import { HomeWorkspace } from './components/HomeWorkspace.tsx';
import { NotesView } from './components/NotesView.tsx';
import { PatientBanner } from './components/PatientBanner.tsx';
import { PatientsView } from './components/PatientsView.tsx';
import { SignInView } from './components/SignInView.tsx';
import type { ActorSession, NavSection, PatientDetailResponse, PatientSummary } from './types.ts';

interface SearchHit {
  id: string;
  patientId: string;
  patientName: string;
  recordType: string;
  title: string;
  snippet: string;
  date: string;
  status: string;
  targetTab: NavSection;
}

const NAV_ITEMS: Array<{ id: NavSection; label: string; Icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'home', label: 'Workspace Home', Icon: Home },
  { id: 'patients', label: 'Patients', Icon: Users },
  { id: 'encounters', label: 'Encounters', Icon: Stethoscope },
  { id: 'timeline', label: 'Clinical Timeline', Icon: CalendarClock },
  { id: 'notes', label: 'Notes', Icon: FileText },
  { id: 'problems', label: 'Problems', Icon: ClipboardList },
  { id: 'medications', label: 'Medications', Icon: Pill },
  { id: 'allergies', label: 'Allergies', Icon: AlertOctagon },
  { id: 'observations', label: 'Observations', Icon: Activity },
  { id: 'results', label: 'Results', Icon: FlaskConical },
  { id: 'documents', label: 'Documents', Icon: FolderLock },
  { id: 'tasks', label: 'Tasks', Icon: ListTodo },
  { id: 'administration', label: 'Administration', Icon: Settings },
];

export default function App() {
  const [actor, setActor] = useState<ActorSession | null>(null);
  const [section, setSection] = useState<NavSection>('home');
  const [patients, setPatients] = useState<PatientSummary[]>([]);
  const [activePatientId, setActivePatientId] = useState<string | null>(null);
  const [patientDetail, setPatientDetail] = useState<PatientDetailResponse | null>(null);
  const [restrictedError, setRestrictedError] = useState<{ patientId: string; message: string; policy?: string } | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchHits, setSearchHits] = useState<SearchHit[] | null>(null);
  const [searching, setSearching] = useState(false);

  const loadPatients = useCallback(async () => {
    const res = await apiFetch<{ patients: PatientSummary[] }>('/api/patients');
    setPatients(res.patients);
    return res.patients;
  }, []);

  const loadPatientDetail = useCallback(async (patientId: string) => {
    setRestrictedError(null);
    try {
      const detail = await apiFetch<PatientDetailResponse>(`/api/patients/${patientId}`);
      setPatientDetail(detail);
    } catch (err) {
      if (err instanceof ApiError && err.status === 403 && err.payload.restricted) {
        setPatientDetail(null);
        setRestrictedError({
          patientId,
          message: err.message,
          policy: String(err.payload.restrictionPolicy || 'restricted'),
        });
      }
    }
  }, []);

  const refreshSession = useCallback(async () => {
    const res = await apiFetch<{ actor: ActorSession; organisation: { ai_assistant_enabled: number; name: string; ods_code: string } }>('/api/auth/session');
    setActor({
      ...res.actor,
      ai_assistant_enabled: res.organisation.ai_assistant_enabled,
      org_name: res.organisation.name,
      ods_code: res.organisation.ods_code,
    });
  }, []);

  useEffect(() => {
    if (!actor) return;
    loadPatients().then((list) => {
      if (!activePatientId && list.length > 0) {
        const defaultPt = list.find((p) => p.accessAllowed) || list[0];
        setActivePatientId(defaultPt.id);
        loadPatientDetail(defaultPt.id);
      }
    });
  }, [actor?.id]);

  const handleSelectPatient = (patientId: string, goTo?: NavSection) => {
    setActivePatientId(patientId);
    loadPatientDetail(patientId);
    if (goTo) setSection(goTo);
  };

  const handleGlobalSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim().length < 2) return;
    setSearching(true);
    try {
      const res = await apiFetch<{ results: SearchHit[] }>(`/api/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchHits(res.results);
    } finally {
      setSearching(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    setAuthToken(null);
    setActor(null);
    setActivePatientId(null);
    setPatientDetail(null);
    setRestrictedError(null);
    setSearchHits(null);
  };

  if (!actor) {
    return <SignInView onSignedIn={(a) => setActor(a)} />;
  }

  const activeNavLabel = NAV_ITEMS.find((n) => n.id === section)?.label || 'Workspace';

  return (
    <div className="min-h-screen flex bg-white text-slate-900">
      {/* Navy Navigation Sidebar */}
      <aside className="w-60 bg-[#0B1F3A] text-slate-100 flex flex-col shrink-0 border-r border-slate-900">
        <div className="px-5 py-4 border-b border-slate-800/80">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-teal-400 shrink-0" />
            <span className="font-semibold text-base tracking-tight text-white whitespace-nowrap">Aureom Clinical</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 truncate">
            {actor.org_name} · {actor.ods_code}
          </div>
        </div>

        <nav aria-label="Clinical Sections" className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map(({ id, label, Icon }) => {
            const active = section === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setSection(id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-teal-700 text-white'
                    : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800/80 space-y-3 text-xs">
          <div>
            <div className="font-semibold text-white truncate">{actor.full_name}</div>
            <div className="text-slate-400 truncate">
              {actor.role_display_name}
              {actor.professional_reg_no ? ` · ${actor.professional_reg_no}` : ''}
            </div>
            <div className="text-teal-400 mt-0.5">MFA Verified Session</div>
          </div>
          <button
            type="button"
            onClick={handleSignOut}
            className="w-full px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            Switch User / Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Clean Top Bar */}
        <header className="h-14 px-6 border-b border-slate-200 bg-white flex items-center justify-between gap-8 shrink-0">
          <div className="text-sm font-medium text-slate-700 whitespace-nowrap shrink-0">
            Aureom Clinical <span className="text-slate-400 mx-1.5">/</span> <span className="text-slate-900 font-semibold">{activeNavLabel}</span>
          </div>

          <form onSubmit={handleGlobalSearch} className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Permission-aware search across notes, results, problems..."
              className="w-full pl-9 pr-20 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white"
            />
            <button
              type="submit"
              disabled={searching}
              className="absolute right-1.5 top-1 px-2.5 py-1 text-[11px] font-medium bg-[#0B1F3A] text-white rounded hover:bg-[#132E54]"
            >
              {searching ? '...' : 'Search'}
            </button>
          </form>

          <div className="text-xs text-slate-600 whitespace-nowrap shrink-0">
            Session Role: <strong className="text-slate-900">{actor.role_display_name}</strong>
          </div>
        </header>

        {/* Global Search Results Drawer */}
        {searchHits !== null && (
          <div className="bg-slate-50 border-b border-slate-200 px-6 py-4">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-semibold text-slate-800">
                Permission-Aware Search Results ({searchHits.length} authorised match{searchHits.length === 1 ? '' : 'es'})
              </div>
              <button type="button" onClick={() => setSearchHits(null)} className="text-slate-500 hover:text-slate-800">
                <X className="w-4 h-4" />
              </button>
            </div>
            {searchHits.length === 0 ? (
              <div className="text-xs text-slate-600">
                No authorised records matched "{searchQuery}". Restricted records outside your access policy are excluded without count leakage.
              </div>
            ) : (
              <div className="divide-y divide-slate-200 bg-white border border-slate-200 rounded-lg max-h-60 overflow-y-auto">
                {searchHits.map((hit) => (
                  <button
                    key={`${hit.recordType}-${hit.id}`}
                    type="button"
                    onClick={() => {
                      handleSelectPatient(hit.patientId, hit.targetTab);
                      setSearchHits(null);
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-teal-50/50 flex items-center justify-between gap-4 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900">
                        [{hit.recordType}] {hit.title} — {hit.patientName}
                      </div>
                      <div className="text-slate-600 truncate">{hit.snippet}</div>
                    </div>
                    <div className="font-mono text-slate-500 whitespace-nowrap shrink-0">
                      {hit.date.slice(0, 10)} · {hit.status}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Persistent Patient Context Banner */}
        <PatientBanner
          detail={patientDetail}
          patients={patients}
          restrictedError={restrictedError}
          onSelectPatient={(id) => handleSelectPatient(id)}
          onBreakGlassGranted={(id) => {
            loadPatients();
            loadPatientDetail(id);
          }}
        />

        {/* Active View Viewport */}
        <main className="flex-1 overflow-y-auto bg-white">
          {section === 'home' && (
            <HomeWorkspace
              onSelectPatient={(id, goTo) => handleSelectPatient(id, goTo)}
              onNavigate={(s) => setSection(s)}
            />
          )}
          {section === 'patients' && (
            <PatientsView
              patients={patients}
              activePatientDetail={patientDetail}
              onSelectPatient={(id) => handleSelectPatient(id)}
              onRefreshPatients={() => {
                loadPatients();
              }}
            />
          )}
          {section === 'notes' && <NotesView patientDetail={patientDetail} actor={actor} />}
          {(section === 'encounters' ||
            section === 'timeline' ||
            section === 'problems' ||
            section === 'medications' ||
            section === 'allergies' ||
            section === 'observations' ||
            section === 'results' ||
            section === 'documents' ||
            section === 'tasks') && (
            <ClinicalSectionsView
              section={section}
              patientDetail={patientDetail}
              onRefreshPatient={() => {
                if (activePatientId) loadPatientDetail(activePatientId);
              }}
              onNavigate={(s) => setSection(s)}
            />
          )}
          {section === 'administration' && (
            <AdministrationView actor={actor} onSessionRefresh={refreshSession} />
          )}
        </main>
      </div>
    </div>
  );
}
