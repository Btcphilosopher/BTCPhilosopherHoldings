export type NavSection =
  | 'home'
  | 'patients'
  | 'encounters'
  | 'timeline'
  | 'notes'
  | 'problems'
  | 'medications'
  | 'allergies'
  | 'observations'
  | 'results'
  | 'documents'
  | 'tasks'
  | 'administration';

export interface StaffDirectoryEntry {
  id: string;
  username: string;
  email: string;
  full_name: string;
  professional_reg_no: string | null;
  role_code: string;
  role_display_name: string;
  identity_provider: string;
  mfa_enrolled: number;
  org_name: string;
  ods_code: string;
}

export interface ActorSession {
  id: string;
  username: string;
  full_name: string;
  professional_reg_no: string | null;
  role_code: string;
  role_display_name: string;
  organisation_id: string;
  org_name: string;
  ods_code: string;
  ai_assistant_enabled: number;
  permissions: string[];
  mfaVerified: boolean;
}

export interface PatientSummary {
  id: string;
  internal_mrn: string;
  birth_date: string;
  administrative_gender: string;
  allergy_assessment_status: string;
  sensitivity_level: string;
  record_status: string;
  prefix: string | null;
  given_names: string;
  family_name: string;
  nhs_number: string | null;
  nhs_formatted: string | null;
  nhs_verification: string | null;
  postcode?: string | null;
  city?: string | null;
  accessAllowed: boolean;
  viaBreakGlass: boolean;
  restrictionPolicy?: string | null;
  restrictionReason?: string | null;
}

export interface PatientDetailResponse {
  patient: {
    id: string;
    internal_mrn: string;
    birth_date: string;
    administrative_gender: string;
    allergy_assessment_status: string;
    allergy_assessed_at: string | null;
    record_status: string;
    sensitivity_level: string;
  };
  identifiers: Array<{
    id: string;
    origin_patient_id: string;
    identifier_type: string;
    identifier_value: string;
    issuing_authority: string;
    verification_status: string;
    effective_from: string;
    effective_to: string | null;
    is_primary: number;
  }>;
  names: Array<{
    id: string;
    name_use: string;
    prefix: string | null;
    given_names: string;
    family_name: string;
    effective_from: string;
    effective_to: string | null;
    source_system: string;
  }>;
  addresses: Array<{
    id: string;
    address_use: string;
    line1: string;
    city: string;
    postcode: string;
    effective_from: string;
    effective_to: string | null;
  }>;
  contacts: Array<{
    id: string;
    relationship_type: string;
    full_name: string;
    telecom_phone: string | null;
    organisation_ods: string | null;
  }>;
  encounters: Array<{
    id: string;
    encounter_class: string;
    status: string;
    reason_text: string;
    started_at: string;
    ended_at: string | null;
    location_name: string;
    attending_name: string;
  }>;
  consents: Array<{
    id: string;
    purpose: string;
    decision: string;
    scope_notes: string | null;
    effective_from: string;
    effective_to: string | null;
  }>;
  restrictions: Array<{
    id: string;
    policy_code: string;
    reason: string;
    allowed_roles_json: string;
  }>;
  allergyCount: number;
  accessContext: {
    allowed: boolean;
    viaBreakGlass: boolean;
    restrictionPolicy?: string;
    reason: string;
  };
}
