-- Aureom Clinical — PostgreSQL Migration 0003
-- Consent Directives, Access Restrictions, Break-Glass Emergency Access, Hash-Chained Audit, Interoperability & Lifecycle

-- 11. Consent Directives & Access Restrictions (Modelled separately!)
CREATE TABLE consent_directives (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    purpose VARCHAR(64) NOT NULL CHECK (purpose IN ('direct_care', 'national_summary_care', 'research_opt_in', 'hie_exchange', 'ai_draft_assistance')),
    decision VARCHAR(32) NOT NULL CHECK (decision IN ('permit', 'deny', 'ask')),
    scope_notes TEXT,
    recorded_by UUID NOT NULL REFERENCES users(id),
    effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to TIMESTAMPTZ
);

CREATE TABLE access_restrictions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    resource_type VARCHAR(64) NOT NULL, -- 'patient', 'clinical_note', 'diagnostic_result', 'document'
    resource_id UUID, -- NULL means patient-wide sensitivity restriction
    policy_code VARCHAR(64) NOT NULL CHECK (policy_code IN ('restricted_vip', 'sexual_health', 'mental_health', 'safeguarding', 'staff_member_record')),
    allowed_roles_json JSONB NOT NULL DEFAULT '["consultant_physician","caldicott_guardian"]'::jsonb,
    reason TEXT NOT NULL,
    created_by UUID NOT NULL REFERENCES users(id),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE emergency_access_grants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    reason TEXT NOT NULL,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    ig_review_status VARCHAR(32) NOT NULL DEFAULT 'pending_review' CHECK (ig_review_status IN ('pending_review', 'justified', 'flagged_inappropriate')),
    ig_reviewed_by UUID REFERENCES users(id),
    ig_reviewed_at TIMESTAMPTZ,
    ig_review_notes TEXT
);

-- 12. Provenance & Restricted Append-Only Audit Storage
CREATE TABLE provenance_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    target_table VARCHAR(64) NOT NULL,
    target_id UUID NOT NULL,
    activity VARCHAR(64) NOT NULL CHECK (activity IN ('create', 'update', 'sign', 'amend', 'import', 'merge', 'unmerge', 'enter_in_error')),
    agent_user_id UUID REFERENCES users(id),
    agent_system VARCHAR(64) NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    detail_json JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE audit_events (
    seq_id BIGSERIAL PRIMARY KEY,
    id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    actor_user_id UUID REFERENCES users(id),
    actor_role VARCHAR(64) NOT NULL,
    organisation_id UUID REFERENCES organisations(id),
    action VARCHAR(64) NOT NULL, -- 'patient.view', 'note.sign', 'search.query', 'access.denied', 'break_glass.grant', etc.
    resource_type VARCHAR(64) NOT NULL,
    resource_id VARCHAR(128),
    patient_id UUID REFERENCES patients(id),
    outcome VARCHAR(32) NOT NULL CHECK (outcome IN ('success', 'denied', 'conflict', 'error')),
    reason TEXT,
    minimised_metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb, -- Never stores copied clinical prose
    prev_hash VARCHAR(128) NOT NULL,
    event_hash VARCHAR(128) NOT NULL,
    retain_until DATE NOT NULL
);
CREATE INDEX idx_audit_patient_time ON audit_events(patient_id, occurred_at DESC);
CREATE INDEX idx_audit_actor_time ON audit_events(actor_user_id, occurred_at DESC);

-- Prevent UPDATE/DELETE on audit_events at the database role/trigger layer
-- Note: Trigger provides defence-in-depth; true immutability also requires WORM archival & restricted DB permissions.
CREATE OR REPLACE FUNCTION prevent_audit_mutation() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'audit_events is append-only; updates and deletes are prohibited';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_audit_events_no_update
    BEFORE UPDATE OR DELETE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION prevent_audit_mutation();

-- 13. Interoperability (FHIR Inbox, Outbox, Field Authority & Retries)
CREATE TABLE integration_inbox_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system VARCHAR(64) NOT NULL,
    external_message_id VARCHAR(128) NOT NULL,
    message_format VARCHAR(32) NOT NULL CHECK (message_format IN ('fhir_r4_uk_core_bundle', 'hl7_v2', 'gp_connect_json')),
    mapping_version VARCHAR(32) NOT NULL,
    payload_sha256 VARCHAR(128) NOT NULL,
    raw_payload_json JSONB NOT NULL,
    processing_status VARCHAR(32) NOT NULL CHECK (processing_status IN ('received', 'processed', 'duplicate_ignored', 'failed_retrying', 'dead_letter')),
    error_detail TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed_at TIMESTAMPTZ,
    UNIQUE (source_system, external_message_id)
);

CREATE TABLE integration_outbox_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aggregate_type VARCHAR(64) NOT NULL,
    aggregate_id UUID NOT NULL,
    event_type VARCHAR(128) NOT NULL,
    payload_json JSONB NOT NULL,
    delivery_status VARCHAR(32) NOT NULL DEFAULT 'pending' CHECK (delivery_status IN ('pending', 'dispatched', 'failed')),
    attempts INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 14. Retention Policies, Legal Holds & Backup Restoration Drills
CREATE TABLE retention_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organisation_id UUID NOT NULL REFERENCES organisations(id),
    record_category VARCHAR(64) NOT NULL,
    retention_years INTEGER NOT NULL,
    statutory_basis VARCHAR(255) NOT NULL, -- e.g. 'NHS Records Management Code of Practice 2023'
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE legal_holds (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    reason TEXT NOT NULL,
    placed_by UUID NOT NULL REFERENCES users(id),
    placed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    released_at TIMESTAMPTZ,
    released_by UUID REFERENCES users(id),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE backup_restore_drills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    target_rpo_seconds INTEGER NOT NULL DEFAULT 300,
    target_rto_seconds INTEGER NOT NULL DEFAULT 900,
    measured_rto_ms BIGINT,
    verified_row_counts_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    attachments_verified INTEGER NOT NULL DEFAULT 0,
    integrity_check_passed BOOLEAN NOT NULL DEFAULT FALSE,
    performed_by UUID REFERENCES users(id),
    notes TEXT
);
