-- Aureom Clinical — PostgreSQL Migration 0002
-- Clinical Notes (Versions, Signatures, Amendments), Problems, Allergies, Medications, Observations, Results, Tasks, Documents

-- 5. Clinical Notes, Versions, Signatures & Amendments
CREATE TABLE clinical_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    note_type VARCHAR(64) NOT NULL CHECK (note_type IN ('consultation', 'ward_round', 'discharge_summary', 'nursing_assessment', 'procedure_note', 'referral_letter')),
    title VARCHAR(255) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'signed', 'amended', 'entered_in_error')),
    current_version INTEGER NOT NULL DEFAULT 1, -- Optimistic concurrency token
    author_id UUID NOT NULL REFERENCES users(id),
    event_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signed_at TIMESTAMPTZ,
    signed_by UUID REFERENCES users(id),
    entered_in_error_reason TEXT,
    entered_in_error_by UUID REFERENCES users(id),
    entered_in_error_at TIMESTAMPTZ,
    sensitivity_level VARCHAR(32) NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr',
    source_record_id VARCHAR(128)
);
CREATE INDEX idx_notes_patient_time ON clinical_notes(patient_id, event_time DESC);

CREATE TABLE clinical_note_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    note_id UUID NOT NULL REFERENCES clinical_notes(id) ON DELETE RESTRICT,
    version_number INTEGER NOT NULL,
    body_text TEXT NOT NULL,
    copied_material_refs JSONB NOT NULL DEFAULT '[]'::jsonb, -- Explicit attribution [{source_record_id, excerpt_hash, label}]
    is_immutable BOOLEAN NOT NULL DEFAULT FALSE,
    saved_by UUID NOT NULL REFERENCES users(id),
    saved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (note_id, version_number)
);

CREATE TABLE clinical_signatures (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    note_id UUID NOT NULL REFERENCES clinical_notes(id) ON DELETE RESTRICT,
    version_number INTEGER NOT NULL,
    signer_id UUID NOT NULL REFERENCES users(id),
    attestation_statement TEXT NOT NULL, -- Separate from cryptographic signature
    idempotency_key VARCHAR(128) NOT NULL UNIQUE, -- Duplicate-safe signing requests
    content_sha256 VARCHAR(128), -- Optional cryptographic digest
    signature_algorithm VARCHAR(64),
    signed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE clinical_note_amendments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    note_id UUID NOT NULL REFERENCES clinical_notes(id) ON DELETE RESTRICT,
    amendment_type VARCHAR(32) NOT NULL CHECK (amendment_type IN ('addendum', 'correction', 'clarification')),
    reason TEXT NOT NULL,
    addendum_text TEXT NOT NULL,
    copied_material_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    author_id UUID NOT NULL REFERENCES users(id),
    signed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    content_sha256 VARCHAR(128) NOT NULL
);

-- 6. Problems & Diagnoses
CREATE TABLE problems (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    snomed_code VARCHAR(32) NOT NULL,
    display_term VARCHAR(255) NOT NULL,
    clinical_status VARCHAR(32) NOT NULL CHECK (clinical_status IN ('active', 'recurrence', 'relapse', 'inactive', 'remission', 'resolved', 'unknown')),
    verification_status VARCHAR(32) NOT NULL CHECK (verification_status IN ('unconfirmed', 'provisional', 'differential', 'confirmed', 'refuted', 'entered_in_error')),
    onset_date DATE,
    abatement_date DATE,
    author_id UUID REFERENCES users(id),
    event_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr',
    source_record_id VARCHAR(128),
    sensitivity_level VARCHAR(32) NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
    notes TEXT
);

-- 7. Allergies & Adverse Reactions (Contradictory sources preserved for review)
CREATE TABLE allergies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    substance_code VARCHAR(64) NOT NULL,
    substance_name VARCHAR(255) NOT NULL,
    reaction_manifestation VARCHAR(255) NOT NULL,
    severity VARCHAR(32) NOT NULL CHECK (severity IN ('mild', 'moderate', 'severe', 'life_threatening', 'unknown')),
    criticality VARCHAR(32) NOT NULL CHECK (criticality IN ('low', 'high', 'unable_to_assess')),
    verification_status VARCHAR(32) NOT NULL CHECK (verification_status IN ('unconfirmed', 'presumed', 'confirmed', 'refuted', 'entered_in_error')),
    clinical_status VARCHAR(32) NOT NULL CHECK (clinical_status IN ('active', 'inactive', 'resolved')),
    author_id UUID REFERENCES users(id),
    event_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr',
    source_record_id VARCHAR(128),
    conflict_flag BOOLEAN NOT NULL DEFAULT FALSE
);

-- 8. Medications (Strictly separated: Statement, Prescription, Dispensing, Administration)
CREATE TABLE medication_statements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    dmd_code VARCHAR(64) NOT NULL,
    medication_name VARCHAR(255) NOT NULL,
    reported_dose_text VARCHAR(255) NOT NULL,
    information_source VARCHAR(64) NOT NULL CHECK (information_source IN ('patient_reported', 'carer_reported', 'gp_summary_import', 'community_pharmacy')),
    status VARCHAR(32) NOT NULL CHECK (status IN ('active', 'completed', 'stopped', 'intended', 'unknown', 'not_taken', 'entered_in_error')),
    event_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    recorded_by UUID REFERENCES users(id),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr'
);

CREATE TABLE prescriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    dmd_code VARCHAR(64) NOT NULL,
    medication_name VARCHAR(255) NOT NULL,
    dose_value NUMERIC(12,4),
    dose_unit VARCHAR(32),
    route VARCHAR(64) NOT NULL,
    frequency VARCHAR(128) NOT NULL,
    indication TEXT,
    prescriber_id UUID NOT NULL REFERENCES users(id),
    status VARCHAR(32) NOT NULL CHECK (status IN ('draft', 'active', 'on_hold', 'cancelled', 'completed', 'stopped', 'entered_in_error')),
    authored_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr'
);

CREATE TABLE dispensing_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prescription_id UUID NOT NULL REFERENCES prescriptions(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    quantity_value NUMERIC(12,2) NOT NULL,
    quantity_unit VARCHAR(32) NOT NULL,
    batch_number VARCHAR(64),
    dispensed_by VARCHAR(255) NOT NULL,
    dispensed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status VARCHAR(32) NOT NULL CHECK (status IN ('completed', 'partial', 'returned', 'entered_in_error'))
);

CREATE TABLE medication_administrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    prescription_id UUID NOT NULL REFERENCES prescriptions(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    dose_given VARCHAR(128) NOT NULL,
    route VARCHAR(64) NOT NULL,
    administered_by UUID NOT NULL REFERENCES users(id),
    administered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status VARCHAR(32) NOT NULL CHECK (status IN ('completed', 'not_done', 'refused', 'held', 'entered_in_error')),
    notes TEXT
);

-- 9. Observations, Specimens, Diagnostic Requests & Results
CREATE TABLE specimens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    specimen_type VARCHAR(128) NOT NULL,
    collection_time TIMESTAMPTZ NOT NULL,
    received_time TIMESTAMPTZ,
    collector_name VARCHAR(255),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr'
);

CREATE TABLE observations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    specimen_id UUID REFERENCES specimens(id),
    code_system VARCHAR(64) NOT NULL, -- 'SNOMED-CT' or 'LOINC'
    code VARCHAR(64) NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    value_numeric NUMERIC(14,4),
    value_text TEXT,
    unit VARCHAR(32),
    ref_range_low NUMERIC(14,4),
    ref_range_high NUMERIC(14,4),
    ref_range_text VARCHAR(128),
    source_interpretation VARCHAR(64), -- Strictly source-supplied, never invented
    status VARCHAR(32) NOT NULL CHECK (status IN ('registered', 'preliminary', 'final', 'amended', 'corrected', 'cancelled', 'entered_in_error')),
    effective_time TIMESTAMPTZ NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    author_id UUID REFERENCES users(id),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr',
    source_record_id VARCHAR(128),
    sensitivity_level VARCHAR(32) NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential'))
);
CREATE INDEX idx_observations_patient_time ON observations(patient_id, effective_time DESC);

CREATE TABLE diagnostic_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    requester_id UUID NOT NULL REFERENCES users(id),
    test_code VARCHAR(64) NOT NULL,
    test_name VARCHAR(255) NOT NULL,
    priority VARCHAR(32) NOT NULL CHECK (priority IN ('routine', 'urgent', 'stat')),
    status VARCHAR(32) NOT NULL CHECK (status IN ('requested', 'in_progress', 'completed', 'cancelled')),
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE diagnostic_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    request_id UUID REFERENCES diagnostic_requests(id),
    specimen_id UUID REFERENCES specimens(id),
    report_code VARCHAR(64) NOT NULL,
    report_title VARCHAR(255) NOT NULL,
    result_summary TEXT NOT NULL,
    structured_values_json JSONB NOT NULL DEFAULT '[]'::jsonb, -- Preserves units and source reference intervals
    status VARCHAR(32) NOT NULL CHECK (status IN ('preliminary', 'final', 'corrected', 'cancelled', 'entered_in_error')),
    replaces_result_id UUID REFERENCES diagnostic_results(id),
    correction_reason TEXT,
    review_state VARCHAR(32) NOT NULL DEFAULT 'unviewed'
        CHECK (review_state IN ('unviewed', 'viewed', 'acknowledged', 'assigned_for_followup', 'action_completed')),
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMPTZ,
    effective_time TIMESTAMPTZ NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source_system VARCHAR(64) NOT NULL,
    source_record_id VARCHAR(128) NOT NULL,
    sensitivity_level VARCHAR(32) NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
    UNIQUE (source_system, source_record_id, status)
);

-- 10. Care Plans, Referrals, Follow-Up Tasks, Documents & Imaging References
CREATE TABLE care_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    title VARCHAR(255) NOT NULL,
    plan_summary TEXT NOT NULL,
    status VARCHAR(32) NOT NULL CHECK (status IN ('draft', 'active', 'on_hold', 'completed', 'revoked')),
    author_id UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE follow_up_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    linked_result_id UUID REFERENCES diagnostic_results(id),
    title VARCHAR(255) NOT NULL,
    instructions TEXT NOT NULL,
    priority VARCHAR(32) NOT NULL CHECK (priority IN ('routine', 'urgent', 'critical')),
    status VARCHAR(32) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled')),
    assigned_to UUID NOT NULL REFERENCES users(id),
    created_by UUID NOT NULL REFERENCES users(id),
    due_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE referrals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    referred_by UUID NOT NULL REFERENCES users(id),
    target_specialty VARCHAR(255) NOT NULL,
    target_organisation VARCHAR(255) NOT NULL,
    urgency VARCHAR(32) NOT NULL CHECK (urgency IN ('routine', 'urgent', 'two_week_wait')),
    reason TEXT NOT NULL,
    status VARCHAR(32) NOT NULL CHECK (status IN ('draft', 'sent', 'accepted', 'rejected', 'completed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    origin_patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    title VARCHAR(255) NOT NULL,
    document_type VARCHAR(64) NOT NULL,
    mime_type VARCHAR(128) NOT NULL,
    byte_size BIGINT NOT NULL,
    object_storage_key VARCHAR(512) NOT NULL UNIQUE,
    sha256_checksum VARCHAR(128) NOT NULL,
    uploaded_by UUID NOT NULL REFERENCES users(id),
    sensitivity_level VARCHAR(32) NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE imaging_references (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    study_instance_uid VARCHAR(128) NOT NULL UNIQUE,
    accession_number VARCHAR(64) NOT NULL,
    modality VARCHAR(16) NOT NULL,
    body_site VARCHAR(128) NOT NULL,
    study_description VARCHAR(255) NOT NULL,
    archive_endpoint_uri VARCHAR(512) NOT NULL, -- Authorised PACS/VNA reference; never store binary DICOM in SQL rows
    performed_at TIMESTAMPTZ NOT NULL,
    status VARCHAR(32) NOT NULL CHECK (status IN ('available', 'pending', 'entered_in_error'))
);
