-- Aureom Clinical — PostgreSQL Migration 0001
-- Core Identity, Organisation, Access Control, Patient Identity & Enrolments

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1. Organisations & Locations
CREATE TABLE organisations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ods_code VARCHAR(32) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    org_type VARCHAR(64) NOT NULL CHECK (org_type IN ('nhs_trust', 'gp_practice', 'community_provider', 'icb_hub')),
    country VARCHAR(16) NOT NULL DEFAULT 'GB-ENG',
    config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    ai_assistant_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
    code VARCHAR(64) NOT NULL,
    name VARCHAR(255) NOT NULL,
    location_type VARCHAR(64) NOT NULL CHECK (location_type IN ('ward', 'outpatient_clinic', 'emergency_dept', 'diagnostic_suite', 'virtual')),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (organisation_id, code)
);

-- 2. Users, Roles, Care Teams & Sessions
CREATE TABLE roles (
    code VARCHAR(64) PRIMARY KEY,
    display_name VARCHAR(128) NOT NULL,
    permissions_json JSONB NOT NULL
);

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
    username VARCHAR(128) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    full_name VARCHAR(255) NOT NULL,
    professional_reg_no VARCHAR(64), -- GMC / NMC / GPhC
    role_code VARCHAR(64) NOT NULL REFERENCES roles(code),
    identity_provider VARCHAR(64) NOT NULL DEFAULT 'local_oidc_adapter',
    external_subject_id VARCHAR(255),
    password_hash TEXT,
    mfa_enrolled BOOLEAN NOT NULL DEFAULT TRUE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE care_teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
    name VARCHAR(255) NOT NULL,
    specialty_snomed VARCHAR(64),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE care_team_memberships (
    care_team_id UUID NOT NULL REFERENCES care_teams(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    team_role VARCHAR(64) NOT NULL,
    effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to TIMESTAMPTZ,
    PRIMARY KEY (care_team_id, user_id)
);

CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(128) NOT NULL UNIQUE,
    mfa_verified BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_method VARCHAR(32),
    care_context_org_id UUID NOT NULL REFERENCES organisations(id),
    issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    revocation_reason VARCHAR(255)
);
CREATE INDEX idx_user_sessions_user ON user_sessions(user_id, expires_at) WHERE revoked_at IS NULL;

-- 3. Patients & Identity Governance (Never auto-merge)
CREATE TABLE patients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Stable internal UUID independent of external IDs
    internal_mrn VARCHAR(32) NOT NULL UNIQUE,
    organisation_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
    birth_date DATE NOT NULL,
    birth_date_accuracy VARCHAR(32) NOT NULL DEFAULT 'exact' CHECK (birth_date_accuracy IN ('exact', 'month_year', 'year_only', 'unknown')),
    administrative_gender VARCHAR(32) NOT NULL CHECK (administrative_gender IN ('female', 'male', 'other', 'unknown', 'not_stated')),
    deceased_flag BOOLEAN NOT NULL DEFAULT FALSE,
    deceased_at TIMESTAMPTZ,
    preferred_language VARCHAR(32) NOT NULL DEFAULT 'en-GB',
    allergy_assessment_status VARCHAR(32) NOT NULL DEFAULT 'not_assessed'
        CHECK (allergy_assessment_status IN ('assessed_present', 'assessed_no_known_allergies', 'not_assessed', 'unknown', 'unavailable')),
    allergy_assessed_at TIMESTAMPTZ,
    allergy_assessed_by UUID REFERENCES users(id),
    record_status VARCHAR(32) NOT NULL DEFAULT 'active' CHECK (record_status IN ('active', 'merged', 'inactive', 'entered_in_error')),
    merged_into_patient_id UUID REFERENCES patients(id),
    sensitivity_level VARCHAR(32) NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'vip_restricted')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_patients_org_status ON patients(organisation_id, record_status);

CREATE TABLE patient_identifiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    origin_patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT, -- Preserved provenance across merges
    identifier_type VARCHAR(32) NOT NULL CHECK (identifier_type IN ('nhs_number', 'local_mrn', 'spine_id', 'external_clinic_id')),
    identifier_value VARCHAR(64) NOT NULL,
    issuing_authority VARCHAR(128) NOT NULL, -- e.g. 'NHS England PDS', 'Y99001'
    verification_status VARCHAR(32) NOT NULL CHECK (verification_status IN ('verified_pds', 'verified_mod11', 'unverified', 'superseded', 'invalid')),
    effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to DATE,
    is_primary BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX idx_patient_identifiers_active_unique
    ON patient_identifiers(identifier_type, issuing_authority, identifier_value)
    WHERE effective_to IS NULL;
CREATE INDEX idx_patient_identifiers_patient ON patient_identifiers(patient_id);

CREATE TABLE patient_names (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    name_use VARCHAR(32) NOT NULL CHECK (name_use IN ('official', 'usual', 'maiden', 'old', 'nickname')),
    prefix VARCHAR(32),
    given_names VARCHAR(255) NOT NULL,
    family_name VARCHAR(255) NOT NULL,
    effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to TIMESTAMPTZ,
    recorded_by UUID REFERENCES users(id),
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr'
);
CREATE INDEX idx_patient_names_search ON patient_names(family_name, given_names);

CREATE TABLE patient_addresses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    address_use VARCHAR(32) NOT NULL CHECK (address_use IN ('home', 'temporary', 'old', 'billing')),
    line1 VARCHAR(255) NOT NULL,
    line2 VARCHAR(255),
    city VARCHAR(128) NOT NULL,
    county VARCHAR(128),
    postcode VARCHAR(16) NOT NULL,
    country VARCHAR(16) NOT NULL DEFAULT 'GB',
    effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to TIMESTAMPTZ,
    recorded_by UUID REFERENCES users(id)
);

CREATE TABLE patient_contacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    relationship_type VARCHAR(64) NOT NULL CHECK (relationship_type IN ('next_of_kin', 'emergency_contact', 'registered_gp', 'carer', 'parent_guardian')),
    full_name VARCHAR(255) NOT NULL,
    telecom_phone VARCHAR(64),
    telecom_email VARCHAR(255),
    organisation_ods VARCHAR(32),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Duplicate Candidate Review & Controlled Merge / Unmerge History
CREATE TABLE patient_duplicate_candidates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_a_id UUID NOT NULL REFERENCES patients(id),
    patient_b_id UUID NOT NULL REFERENCES patients(id),
    match_score NUMERIC(5,2) NOT NULL,
    match_rationale TEXT NOT NULL,
    review_status VARCHAR(32) NOT NULL DEFAULT 'pending_review' CHECK (review_status IN ('pending_review', 'confirmed_distinct', 'merged', 'unmerged')),
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (patient_a_id <> patient_b_id)
);

CREATE TABLE patient_merge_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_patient_id UUID NOT NULL REFERENCES patients(id),
    target_patient_id UUID NOT NULL REFERENCES patients(id),
    action VARCHAR(16) NOT NULL CHECK (action IN ('merge', 'unmerge')),
    reason TEXT NOT NULL,
    moved_records_snapshot JSONB NOT NULL, -- Exact record IDs reassigned so unmerge can safely reverse controlled merges
    performed_by UUID NOT NULL REFERENCES users(id),
    performed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reversed_by_event_id UUID REFERENCES patient_merge_events(id)
);

-- 4. Enrolments & Encounters
CREATE TABLE enrolments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    organisation_id UUID NOT NULL REFERENCES organisations(id),
    care_team_id UUID REFERENCES care_teams(id),
    enrolment_type VARCHAR(64) NOT NULL CHECK (enrolment_type IN ('registered_gp', 'outpatient_pathway', 'inpatient_spell', 'community_caseload')),
    status VARCHAR(32) NOT NULL CHECK (status IN ('active', 'completed', 'suspended', 'entered_in_error')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at TIMESTAMPTZ
);

CREATE TABLE encounters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    organisation_id UUID NOT NULL REFERENCES organisations(id),
    location_id UUID NOT NULL REFERENCES locations(id),
    care_team_id UUID REFERENCES care_teams(id),
    attending_user_id UUID NOT NULL REFERENCES users(id),
    encounter_class VARCHAR(32) NOT NULL CHECK (encounter_class IN ('outpatient', 'inpatient', 'emergency', 'telephone', 'home_visit')),
    status VARCHAR(32) NOT NULL CHECK (status IN ('planned', 'in_progress', 'finished', 'cancelled', 'entered_in_error')),
    reason_text TEXT NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at TIMESTAMPTZ,
    source_system VARCHAR(64) NOT NULL DEFAULT 'aureom_ehr',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_encounters_patient ON encounters(patient_id, started_at DESC);
