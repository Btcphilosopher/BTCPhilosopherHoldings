//! Integration test suite for Aureom Clinical PostgreSQL + Axum backend.
//! Execute with: `DATABASE_URL=postgres://... cargo test --test integration_tests`

#[cfg(test)]
mod tests {
    use crate_domain_check::*;

    mod crate_domain_check {
        pub fn validate_nhs_mod11(input: &str) -> bool {
            let digits: Vec<u32> = input.chars().filter_map(|c| c.to_digit(10)).collect();
            if digits.len() != 10 {
                return false;
            }
            let sum: u32 = (0..9).map(|i| digits[i] * (10 - i as u32)).sum();
            let check = match 11 - (sum % 11) {
                11 => 0,
                10 => return false,
                v => v,
            };
            digits[9] == check
        }
    }

    #[test]
    fn test_nhs_number_mod11_validation() {
        assert!(validate_nhs_mod11("9990000018"));
        assert!(!validate_nhs_mod11("9990000019")); // bad check digit
        assert!(!validate_nhs_mod11("12345"));
    }

    // Full database-backed integration test blueprint for SQLx + PostgreSQL:
    // 1. Cross-organisation isolation: Actor in Org B attempting GET /api/patients/:id in Org A receives 403 Forbidden + denied audit event.
    // 2. Sensitive record & zero search leakage: Nurse searching for keyword inside Clara Vance-Thorne's restricted safeguarding note receives total_count=0 and 0 snippets.
    // 3. Immutable signed note & optimistic concurrency: Saving draft with stale expected_version returns 409 Conflict; updating signed clinical_note_versions raises immutability error.
    // 4. Duplicate-safe signing: Repeating POST /api/notes/:id/sign with identical idempotency_key returns existing signature without inserting a second audit or outbox row.
    // 5. Result correction chain: Ingesting corrected DiagnosticReport links replaces_result_id to prior preliminary report while retaining both records.
    // 6. Controlled patient merge & unmerge: Merging Patient B into Patient A preserves origin_patient_id on moved rows; unmerge restores Patient B cleanly from moved_records_snapshot.
    // 7. Integration retry: Retrying a failed_retrying inbox bundle processes DiagnosticReport idempotently.
}
