mod audit;
mod auth;
mod config;
mod domain;
mod error;
mod interoperability;

use std::time::Duration;
use axum::{Json, Router, routing::{get, post, put}};
use serde_json::json;
use sqlx::{PgPool, postgres::PgPoolOptions};
use tower_http::trace::TraceLogging;

use crate::{
    auth::{AuthState, FromRef},
    config::AppConfig,
};

#[derive(Clone)]
pub struct AppState {
    pub pool: PgPool,
    pub auth: AuthState,
}

impl FromRef<AppState> for PgPool {
    fn from_ref(input: &AppState) -> Self {
        input.pool.clone()
    }
}

impl FromRef<AppState> for AuthState {
    fn from_ref(input: &AppState) -> Self {
        input.auth.clone()
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt::init();

    let cfg = AppConfig::from_env()?;
    let pool = PgPoolOptions::new()
        .max_connections(16)
        .connect(&cfg.database_url)
        .await?;

    // Background Durable Integration Outbox Worker
    let worker_pool = pool.clone();
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(Duration::from_secs(15));
        loop {
            interval.tick().await;
            let res = sqlx::query(
                r#"
                UPDATE integration_outbox_events
                SET delivery_status = 'dispatched', attempts = attempts + 1
                WHERE id IN (
                    SELECT id FROM integration_outbox_events
                    WHERE delivery_status = 'pending' AND next_attempt_at <= NOW()
                    LIMIT 25
                    FOR UPDATE SKIP LOCKED
                )
                "#,
            )
            .execute(&worker_pool)
            .await;

            if let Err(err) = res {
                tracing::warn!(error = %err, "Outbox worker tick failed");
            }
        }
    });

    let state = AppState {
        pool: pool.clone(),
        auth: AuthState {
            pool,
            session_hmac_secret: cfg.session_hmac_secret.clone(),
        },
    };

    let app = Router::new()
        .route("/api/health", get(|| async { Json(json!({ "status": "ok", "engine": "rust-axum" })) }))
        .route("/api/patients", post(domain::patients::register_patient))
        .route("/api/patients/{id}", get(domain::patients::get_patient_summary))
        .route("/api/search", get(domain::patients::permission_aware_search))
        .route("/api/notes/{id}/draft", put(domain::notes::save_draft_with_concurrency))
        .route("/api/notes/{id}/sign", post(domain::notes::sign_note_atomic))
        .route("/api/notes/{id}/amendments", post(domain::notes::add_amendment))
        .route("/api/fhir/ingest", post(interoperability::fhir::ingest_uk_core_bundle))
        .layer(tower_http::trace::TraceLayer::new_for_http())
        .with_state(state);

    let listener = tokio::net::TcpListener::bind(&cfg.bind_addr).await?;
    tracing::info!("Aureom Clinical Rust/Axum server listening on {}", cfg.bind_addr);
    axum::serve(listener, app).await?;

    Ok(())
}
