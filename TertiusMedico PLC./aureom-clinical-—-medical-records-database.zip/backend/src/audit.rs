use chrono::{Duration, Utc};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use sqlx::{Postgres, Transaction};
use uuid::Uuid;

pub struct AuditEntryInput {
    pub actor_user_id: Option<Uuid>,
    pub actor_role: String,
    pub organisation_id: Option<Uuid>,
    pub action: String,
    pub resource_type: String,
    pub resource_id: Option<String>,
    pub patient_id: Option<Uuid>,
    pub outcome: &'static str,
    pub reason: Option<String>,
    pub minimised_metadata: Value,
}

pub async fn append_audit_event_tx(
    tx: &mut Transaction<'_, Postgres>,
    entry: AuditEntryInput,
) -> Result<Uuid, sqlx::Error> {
    let id = Uuid::new_v4();
    let occurred_at = Utc::now();
    let retain_until = (occurred_at + Duration::days(365 * 8)).date_naive();

    let prev_hash: String = sqlx::query_scalar(
        "SELECT event_hash FROM audit_events ORDER BY seq_id DESC LIMIT 1",
    )
    .fetch_optional(&mut **tx)
    .await?
    .unwrap_or_else(|| "0".repeat(64));

    let canonical = json!({
        "prevHash": prev_hash,
        "id": id,
        "occurredAt": occurred_at.to_rfc3339(),
        "actorUserId": entry.actor_user_id,
        "actorRole": entry.actor_role,
        "action": entry.action,
        "resourceType": entry.resource_type,
        "resourceId": entry.resource_id,
        "patientId": entry.patient_id,
        "outcome": entry.outcome,
    });

    let mut hasher = Sha256::new();
    hasher.update(canonical.to_string().as_bytes());
    let event_hash = hex::encode(hasher.finalize());

    sqlx::query(
        r#"
        INSERT INTO audit_events (
            id, occurred_at, actor_user_id, actor_role, organisation_id,
            action, resource_type, resource_id, patient_id, outcome,
            reason, minimised_metadata_json, prev_hash, event_hash, retain_until
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
        "#,
    )
    .bind(id)
    .bind(occurred_at)
    .bind(entry.actor_user_id)
    .bind(&entry.actor_role)
    .bind(entry.organisation_id)
    .bind(&entry.action)
    .bind(&entry.resource_type)
    .bind(&entry.resource_id)
    .bind(entry.patient_id)
    .bind(entry.outcome)
    .bind(&entry.reason)
    .bind(&entry.minimised_metadata)
    .bind(&prev_hash)
    .bind(&event_hash)
    .bind(retain_until)
    .execute(&mut **tx)
    .await?;

    Ok(id)
}
