use axum::{Json, extract::{Path, Query, State}};
use chrono::{NaiveDate, Utc};
use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::PgPool;
use uuid::Uuid;

use crate::{
    audit::{AuditEntryInput, append_audit_event_tx},
    auth::{AuthenticatedActor, evaluate_patient_access},
    error::ClinicalError,
};

#[derive(Deserialize)]
pub struct RegisterPatientRequest {
    pub given_names: String,
    pub family_name: String,
    pub birth_date: NaiveDate,
    pub administrative_gender: String,
    pub nhs_number: Option<String>,
    pub allergy_assessment_status: Option<String>,
}

#[derive(Serialize)]
pub struct RegisterPatientResponse {
    pub id: Uuid,
    pub internal_mrn: String,
    pub nhs_number: Option<String>,
}

pub fn validate_nhs_mod11(input: &str) -> Result<String, String> {
    let digits: String = input.chars().filter(|c| c.is_ascii_digit()).collect();
    if digits.len() != 10 {
        return Err("NHS Number must contain exactly 10 digits".into());
    }
    let bytes = digits.as_bytes();
    let mut sum = 0u32;
    for i in 0..9 {
        let d = (bytes[i] - b'0') as u32;
        sum += d * (10 - i as u32);
    }
    let check = match 11 - (sum % 11) {
        11 => 0,
        10 => return Err("Invalid NHS Number check digit (10)".into()),
        v => v,
    };
    if (bytes[9] - b'0') as u32 != check {
        return Err("NHS Number Modulus-11 verification failed".into());
    }
    Ok(digits)
}

pub async fn register_patient(
    State(pool): State<PgPool>,
    actor: AuthenticatedActor,
    Json(req): Json<RegisterPatientRequest>,
) -> Result<Json<RegisterPatientResponse>, ClinicalError> {
    if !actor.has_permission("patient.write") {
        return Err(ClinicalError::Forbidden("Role lacks patient.write permission".into()));
    }

    let normalized_nhs = match req.nhs_number {
        Some(ref raw) if !raw.trim().is_empty() => {
            Some(validate_nhs_mod11(raw).map_err(ClinicalError::BadRequest)?)
        }
        _ => None,
    };

    let patient_id = Uuid::new_v4();
    let internal_mrn = format!("AUR-{}", &patient_id.simple().to_string()[..6].to_uppercase());
    let allergy_status = req.allergy_assessment_status.unwrap_or_else(|| "not_assessed".into());

    let mut tx = pool.begin().await?;

    sqlx::query(
        r#"
        INSERT INTO patients (id, internal_mrn, organisation_id, birth_date, administrative_gender, allergy_assessment_status)
        VALUES ($1, $2, $3, $4, $5, $6)
        "#,
    )
    .bind(patient_id)
    .bind(&internal_mrn)
    .bind(actor.organisation_id)
    .bind(req.birth_date)
    .bind(&req.administrative_gender)
    .bind(&allergy_status)
    .execute(&mut *tx)
    .await?;

    sqlx::query(
        r#"
        INSERT INTO patient_names (id, patient_id, name_use, given_names, family_name, recorded_by)
        VALUES ($1, $2, 'official', $3, $4, $5)
        "#,
    )
    .bind(Uuid::new_v4())
    .bind(patient_id)
    .bind(req.given_names.trim())
    .bind(req.family_name.trim())
    .bind(actor.user_id)
    .execute(&mut *tx)
    .await?;

    if let Some(ref nhs) = normalized_nhs {
        sqlx::query(
            r#"
            INSERT INTO patient_identifiers (id, patient_id, origin_patient_id, identifier_type, identifier_value, issuing_authority, verification_status, is_primary)
            VALUES ($1, $2, $2, 'nhs_number', $3, 'Local Registration', 'verified_mod11', TRUE)
            "#,
        )
        .bind(Uuid::new_v4())
        .bind(patient_id)
        .bind(nhs)
        .execute(&mut *tx)
        .await?;
    }

    append_audit_event_tx(
        &mut tx,
        AuditEntryInput {
            actor_user_id: Some(actor.user_id),
            actor_role: actor.role_code.clone(),
            organisation_id: Some(actor.organisation_id),
            action: "patient.register".into(),
            resource_type: "patient".into(),
            resource_id: Some(patient_id.to_string()),
            patient_id: Some(patient_id),
            outcome: "success",
            reason: None,
            minimised_metadata: json!({ "internal_mrn": internal_mrn }),
        },
    )
    .await?;

    tx.commit().await?;

    Ok(Json(RegisterPatientResponse {
        id: patient_id,
        internal_mrn,
        nhs_number: normalized_nhs,
    }))
}

#[derive(Deserialize)]
pub struct SearchQuery {
    pub q: String,
}

pub async fn permission_aware_search(
    State(pool): State<PgPool>,
    actor: AuthenticatedActor,
    Query(query): Query<SearchQuery>,
) -> Result<Json<serde_json::Value>, ClinicalError> {
    let pattern = format!("%{}%", query.q.trim());

    // Fetch candidate notes within org, then filter strictly using evaluate_patient_access
    // before computing totals or returning snippets (prevents restricted count/snippet leakage).
    let rows: Vec<(Uuid, Uuid, String, String, String)> = sqlx::query_as(
        r#"
        SELECT cn.id, cn.patient_id, cn.title, cn.status, cn.sensitivity_level
        FROM clinical_notes cn
        JOIN clinical_note_versions v ON v.note_id = cn.id AND v.version_number = cn.current_version
        JOIN patients p ON p.id = cn.patient_id
        WHERE p.organisation_id = $1
          AND (cn.title ILIKE $2 OR v.body_text ILIKE $2)
        ORDER BY cn.event_time DESC
        LIMIT 50
        "#,
    )
    .bind(actor.organisation_id)
    .bind(&pattern)
    .fetch_all(&pool)
    .await?;

    let mut authorised_results = Vec::new();
    for (note_id, patient_id, title, status, sensitivity) in rows {
        let (allowed, via_bg, _) = evaluate_patient_access(&pool, &actor, patient_id).await?;
        if !allowed {
            continue;
        }
        if sensitivity != "normal" && !via_bg && actor.role_code != "consultant_physician" && actor.role_code != "caldicott_guardian" {
            continue;
        }
        authorised_results.push(json!({
            "id": note_id,
            "patient_id": patient_id,
            "title": title,
            "status": status,
        }));
    }

    Ok(Json(json!({
        "total_count": authorised_results.len(),
        "results": authorised_results,
    })))
}

pub async fn get_patient_summary(
    State(pool): State<PgPool>,
    actor: AuthenticatedActor,
    Path(patient_id): Path<Uuid>,
) -> Result<Json<serde_json::Value>, ClinicalError> {
    let (allowed, via_break_glass, reason) = evaluate_patient_access(&pool, &actor, patient_id).await?;
    if !allowed {
        let mut tx = pool.begin().await?;
        append_audit_event_tx(
            &mut tx,
            AuditEntryInput {
                actor_user_id: Some(actor.user_id),
                actor_role: actor.role_code.clone(),
                organisation_id: Some(actor.organisation_id),
                action: "patient.view".into(),
                resource_type: "patient".into(),
                resource_id: Some(patient_id.to_string()),
                patient_id: Some(patient_id),
                outcome: "denied",
                reason: Some(reason.clone()),
                minimised_metadata: json!({}),
            },
        )
        .await?;
        tx.commit().await?;
        return Err(ClinicalError::Forbidden(reason));
    }

    let row: (String, NaiveDate, String, String) = sqlx::query_as(
        "SELECT internal_mrn, birth_date, administrative_gender, allergy_assessment_status FROM patients WHERE id = $1",
    )
    .bind(patient_id)
    .fetch_one(&pool)
    .await?;

    Ok(Json(json!({
        "id": patient_id,
        "internal_mrn": row.0,
        "birth_date": row.1,
        "administrative_gender": row.2,
        "allergy_assessment_status": row.3,
        "via_break_glass": via_break_glass,
        "retrieved_at": Utc::now(),
    })))
}
