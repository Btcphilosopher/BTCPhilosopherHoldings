use axum::{Json, extract::{Path, State}};
use chrono::Utc;
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};
use sqlx::PgPool;
use uuid::Uuid;

use crate::{
    audit::{AuditEntryInput, append_audit_event_tx},
    auth::{AuthenticatedActor, evaluate_patient_access},
    error::ClinicalError,
};

#[derive(Deserialize)]
pub struct SaveDraftRequest {
    pub title: String,
    pub body_text: String,
    pub expected_version: i32,
}

#[derive(Deserialize)]
pub struct SignNoteRequest {
    pub expected_version: i32,
    pub idempotency_key: String,
    pub attestation_statement: String,
}

#[derive(Deserialize)]
pub struct AmendNoteRequest {
    pub amendment_type: String,
    pub reason: String,
    pub addendum_text: String,
}

pub async fn save_draft_with_concurrency(
    State(pool): State<PgPool>,
    actor: AuthenticatedActor,
    Path(note_id): Path<Uuid>,
    Json(req): Json<SaveDraftRequest>,
) -> Result<Json<serde_json::Value>, ClinicalError> {
    if !actor.has_permission("note.write") {
        return Err(ClinicalError::Forbidden("Role lacks note.write permission".into()));
    }

    let mut tx = pool.begin().await?;

    let row: Option<(Uuid, String, i32)> = sqlx::query_as(
        "SELECT patient_id, status, current_version FROM clinical_notes WHERE id = $1 FOR UPDATE",
    )
    .bind(note_id)
    .fetch_optional(&mut *tx)
    .await?;

    let (patient_id, status, current_version) =
        row.ok_or_else(|| ClinicalError::NotFound("Clinical note not found".into()))?;

    let (allowed, _, reason) = evaluate_patient_access(&pool, &actor, patient_id).await?;
    if !allowed {
        return Err(ClinicalError::Forbidden(reason));
    }

    if status != "draft" {
        return Err(ClinicalError::Conflict(
            "Signed or amended notes are immutable; add an attributed addendum instead.".into(),
        ));
    }

    if current_version != req.expected_version {
        return Err(ClinicalError::Conflict(format!(
            "Optimistic concurrency mismatch: expected v{}, current v{}",
            req.expected_version, current_version
        )));
    }

    let next_version = current_version + 1;
    sqlx::query("UPDATE clinical_notes SET current_version = $1, title = $2 WHERE id = $3")
        .bind(next_version)
        .bind(req.title.trim())
        .bind(note_id)
        .execute(&mut *tx)
        .await?;

    sqlx::query(
        r#"
        INSERT INTO clinical_note_versions (id, note_id, version_number, body_text, is_immutable, saved_by)
        VALUES ($1, $2, $3, $4, FALSE, $5)
        "#,
    )
    .bind(Uuid::new_v4())
    .bind(note_id)
    .bind(next_version)
    .bind(&req.body_text)
    .bind(actor.user_id)
    .execute(&mut *tx)
    .await?;

    tx.commit().await?;

    Ok(Json(json!({ "id": note_id, "current_version": next_version })))
}

pub async fn sign_note_atomic(
    State(pool): State<PgPool>,
    actor: AuthenticatedActor,
    Path(note_id): Path<Uuid>,
    Json(req): Json<SignNoteRequest>,
) -> Result<Json<serde_json::Value>, ClinicalError> {
    if !actor.has_permission("note.sign") {
        return Err(ClinicalError::Forbidden("Role lacks note.sign permission".into()));
    }
    if !actor.mfa_verified {
        return Err(ClinicalError::Forbidden("MFA-verified session required for signing".into()));
    }

    // Duplicate-safe idempotency check
    let existing_sig: Option<Uuid> = sqlx::query_scalar(
        "SELECT id FROM clinical_signatures WHERE idempotency_key = $1",
    )
    .bind(&req.idempotency_key)
    .fetch_optional(&pool)
    .await?;

    if let Some(sig_id) = existing_sig {
        return Ok(Json(json!({ "status": "signed", "signature_id": sig_id, "duplicate_safe_replay": true })));
    }

    let mut tx = pool.begin().await?;
    let row: Option<(Uuid, String, i32)> = sqlx::query_as(
        "SELECT patient_id, status, current_version FROM clinical_notes WHERE id = $1 FOR UPDATE",
    )
    .bind(note_id)
    .fetch_optional(&mut *tx)
    .await?;

    let (patient_id, status, current_version) =
        row.ok_or_else(|| ClinicalError::NotFound("Clinical note not found".into()))?;

    if status != "draft" {
        return Err(ClinicalError::Conflict("Clinical note is already signed".into()));
    }
    if current_version != req.expected_version {
        return Err(ClinicalError::Conflict("Draft version changed before signing".into()));
    }

    let body_text: String = sqlx::query_scalar(
        "SELECT body_text FROM clinical_note_versions WHERE note_id = $1 AND version_number = $2",
    )
    .bind(note_id)
    .bind(current_version)
    .fetch_one(&mut *tx)
    .await?;

    let mut hasher = Sha256::new();
    hasher.update(body_text.as_bytes());
    let content_sha256 = hex::encode(hasher.finalize());
    let sig_id = Uuid::new_v4();
    let now = Utc::now();

    sqlx::query("UPDATE clinical_note_versions SET is_immutable = TRUE WHERE note_id = $1 AND version_number = $2")
        .bind(note_id)
        .bind(current_version)
        .execute(&mut *tx)
        .await?;

    sqlx::query("UPDATE clinical_notes SET status = 'signed', signed_at = $1, signed_by = $2 WHERE id = $3")
        .bind(now)
        .bind(actor.user_id)
        .bind(note_id)
        .execute(&mut *tx)
        .await?;

    sqlx::query(
        r#"
        INSERT INTO clinical_signatures (id, note_id, version_number, signer_id, attestation_statement, idempotency_key, content_sha256, signature_algorithm, signed_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, 'SHA-256-DIGEST-ONLY', $8)
        "#,
    )
    .bind(sig_id)
    .bind(note_id)
    .bind(current_version)
    .bind(actor.user_id)
    .bind(&req.attestation_statement)
    .bind(&req.idempotency_key)
    .bind(&content_sha256)
    .bind(now)
    .execute(&mut *tx)
    .await?;

    sqlx::query(
        r#"
        INSERT INTO integration_outbox_events (id, aggregate_type, aggregate_id, event_type, payload_json)
        VALUES ($1, 'clinical_note', $2, 'clinical_note.signed', $3)
        "#,
    )
    .bind(Uuid::new_v4())
    .bind(note_id)
    .bind(json!({ "note_id": note_id, "patient_id": patient_id, "version": current_version }))
    .execute(&mut *tx)
    .await?;

    append_audit_event_tx(
        &mut tx,
        AuditEntryInput {
            actor_user_id: Some(actor.user_id),
            actor_role: actor.role_code.clone(),
            organisation_id: Some(actor.organisation_id),
            action: "note.sign".into(),
            resource_type: "clinical_note".into(),
            resource_id: Some(note_id.to_string()),
            patient_id: Some(patient_id),
            outcome: "success",
            reason: None,
            minimised_metadata: json!({ "version": current_version, "content_sha256": content_sha256 }),
        },
    )
    .await?;

    tx.commit().await?;

    Ok(Json(json!({ "status": "signed", "signature_id": sig_id, "content_sha256": content_sha256 })))
}

pub async fn add_amendment(
    State(pool): State<PgPool>,
    actor: AuthenticatedActor,
    Path(note_id): Path<Uuid>,
    Json(req): Json<AmendNoteRequest>,
) -> Result<Json<serde_json::Value>, ClinicalError> {
    if !actor.has_permission("note.amend") {
        return Err(ClinicalError::Forbidden("Role lacks note.amend permission".into()));
    }

    let mut tx = pool.begin().await?;
    let row: Option<(Uuid, String)> = sqlx::query_as(
        "SELECT patient_id, status FROM clinical_notes WHERE id = $1 FOR UPDATE",
    )
    .bind(note_id)
    .fetch_optional(&mut *tx)
    .await?;

    let (patient_id, status) = row.ok_or_else(|| ClinicalError::NotFound("Note not found".into()))?;
    if status != "signed" && status != "amended" {
        return Err(ClinicalError::Conflict("Only signed or amended notes can receive addenda".into()));
    }

    let mut hasher = Sha256::new();
    hasher.update(req.addendum_text.as_bytes());
    let content_sha256 = hex::encode(hasher.finalize());
    let amd_id = Uuid::new_v4();

    sqlx::query(
        r#"
        INSERT INTO clinical_note_amendments (id, note_id, amendment_type, reason, addendum_text, author_id, content_sha256)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        "#,
    )
    .bind(amd_id)
    .bind(note_id)
    .bind(&req.amendment_type)
    .bind(&req.reason)
    .bind(&req.addendum_text)
    .bind(actor.user_id)
    .bind(&content_sha256)
    .execute(&mut *tx)
    .await?;

    sqlx::query("UPDATE clinical_notes SET status = 'amended' WHERE id = $1")
        .bind(note_id)
        .execute(&mut *tx)
        .await?;

    append_audit_event_tx(
        &mut tx,
        AuditEntryInput {
            actor_user_id: Some(actor.user_id),
            actor_role: actor.role_code.clone(),
            organisation_id: Some(actor.organisation_id),
            action: "note.amend".into(),
            resource_type: "clinical_note_amendment".into(),
            resource_id: Some(amd_id.to_string()),
            patient_id: Some(patient_id),
            outcome: "success",
            reason: Some(req.reason),
            minimised_metadata: json!({ "note_id": note_id, "content_sha256": content_sha256 }),
        },
    )
    .await?;

    tx.commit().await?;

    Ok(Json(json!({ "id": amd_id, "note_status": "amended", "content_sha256": content_sha256 })))
}
