use axum::{
    extract::FromRequestParts,
    http::request::Parts,
};
use chrono::{DateTime, Utc};
use hmac::{Hmac, Mac};
use sha2::Sha256;
use sqlx::PgPool;
use uuid::Uuid;

use crate::error::ClinicalError;

#[derive(Clone, Debug)]
pub struct AuthenticatedActor {
    pub session_id: Uuid,
    pub user_id: Uuid,
    pub organisation_id: Uuid,
    pub role_code: String,
    pub permissions: Vec<String>,
    pub mfa_verified: bool,
}

impl AuthenticatedActor {
    pub fn has_permission(&self, perm: &str) -> bool {
        self.permissions.iter().any(|p| p == perm)
    }
}

pub fn hash_session_token(secret: &str, raw_token: &str) -> String {
    let mut mac = Hmac::<Sha256>::new_from_slice(secret.as_bytes()).expect("HMAC key");
    mac.update(raw_token.as_bytes());
    hex::encode(mac.finalize().into_bytes())
}

#[derive(Clone)]
pub struct AuthState {
    pub pool: PgPool,
    pub session_hmac_secret: String,
}

impl<S> FromRequestParts<S> for AuthenticatedActor
where
    AuthState: FromRef<S>,
    S: Send + Sync,
{
    type Rejection = ClinicalError;

    async fn from_request_parts(parts: &mut Parts, state: &S) -> Result<Self, Self::Rejection> {
        let auth_state = AuthState::from_ref(state);
        let header = parts
            .headers
            .get(axum::http::header::AUTHORIZATION)
            .and_then(|v| v.to_str().ok())
            .ok_or_else(|| ClinicalError::Unauthorized("Missing Authorization Bearer header".into()))?;

        let raw_token = header
            .strip_prefix("Bearer ")
            .ok_or_else(|| ClinicalError::Unauthorized("Expected Bearer token".into()))?;

        let token_hash = hash_session_token(&auth_state.session_hmac_secret, raw_token);

        let row: Option<(Uuid, Uuid, Uuid, String, serde_json::Value, bool, DateTime<Utc>, Option<DateTime<Utc>>)> = sqlx::query_as(
            r#"
            SELECT s.id, u.id, u.organisation_id, u.role_code, r.permissions_json,
                   s.mfa_verified, s.expires_at, s.revoked_at
            FROM user_sessions s
            JOIN users u ON u.id = s.user_id
            JOIN roles r ON r.code = u.role_code
            WHERE s.token_hash = $1 AND u.is_active = TRUE
            "#,
        )
        .bind(&token_hash)
        .fetch_optional(&auth_state.pool)
        .await?;

        let (session_id, user_id, organisation_id, role_code, perms_json, mfa_verified, expires_at, revoked_at) =
            row.ok_or_else(|| ClinicalError::Unauthorized("Invalid session token".into()))?;

        if revoked_at.is_some() || expires_at <= Utc::now() {
            return Err(ClinicalError::Unauthorized("Session expired or revoked".into()));
        }

        let permissions: Vec<String> = serde_json::from_value(perms_json).unwrap_or_default();

        Ok(AuthenticatedActor {
            session_id,
            user_id,
            organisation_id,
            role_code,
            permissions,
            mfa_verified,
        })
    }
}

pub trait FromRef<T> {
    fn from_ref(input: &T) -> Self;
}

pub async fn evaluate_patient_access(
    pool: &PgPool,
    actor: &AuthenticatedActor,
    patient_id: Uuid,
) -> Result<(bool, bool, String), ClinicalError> {
    let row: Option<(Uuid, String)> = sqlx::query_as(
        "SELECT organisation_id, sensitivity_level FROM patients WHERE id = $1",
    )
    .bind(patient_id)
    .fetch_optional(pool)
    .await?;

    let (patient_org_id, sensitivity_level) =
        row.ok_or_else(|| ClinicalError::NotFound("Patient not found".into()))?;

    if patient_org_id != actor.organisation_id {
        return Ok((false, false, "Cross-organisation isolation policy denied access".into()));
    }

    if sensitivity_level == "normal" {
        return Ok((true, false, "Standard direct care policy".into()));
    }

    if actor.role_code == "consultant_physician" || actor.role_code == "caldicott_guardian" {
        return Ok((true, false, "Role explicitly authorised under restricted policy".into()));
    }

    let grant_id: Option<Uuid> = sqlx::query_scalar(
        "SELECT id FROM emergency_access_grants WHERE user_id = $1 AND patient_id = $2 AND expires_at > NOW() LIMIT 1",
    )
    .bind(actor.user_id)
    .bind(patient_id)
    .fetch_optional(pool)
    .await?;

    if grant_id.is_some() {
        return Ok((true, true, "Active Break-Glass emergency grant".into()));
    }

    Ok((false, false, "Restricted record requires Consultant, Caldicott Guardian, or Break-Glass access".into()))
}
