use std::env;

#[derive(Clone, Debug)]
pub struct AppConfig {
    pub database_url: String,
    pub bind_addr: String,
    pub storage_root: String,
    pub session_hmac_secret: String,
    pub gemini_api_key: Option<String>,
}

impl AppConfig {
    pub fn from_env() -> Result<Self, String> {
        let database_url = env::var("DATABASE_URL")
            .map_err(|_| "DATABASE_URL must be set for PostgreSQL connection".to_string())?;
        let bind_addr = env::var("BIND_ADDR").unwrap_or_else(|_| "0.0.0.0:8080".to_string());
        let storage_root = env::var("AUREOM_STORAGE_DIR").unwrap_or_else(|_| "/var/lib/aureom/storage".to_string());
        let session_hmac_secret = env::var("AUREOM_SESSION_SECRET")
            .unwrap_or_else(|_| "dev-ephemeral-secret-override-in-production".to_string());
        let gemini_api_key = env::var("GEMINI_API_KEY").ok();

        Ok(Self {
            database_url,
            bind_addr,
            storage_root,
            session_hmac_secret,
            gemini_api_key,
        })
    }
}
