use axum::{Json, extract::State};
use chrono::Utc;
use serde::Deserialize;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use sqlx::PgPool;
use uuid::Uuid;

use crate::{
    audit::{AuditEntryInput, append_audit_event_tx},
    auth::AuthenticatedActor,
    error::ClinicalError,
};

#[derive(Deserialize)]
pub struct FhirBundle {
    #[serde(rename = "resourceType")]
    pub resource_type: String,
    pub id: String,
    #[serde(rename = "sourceSystem")]
    pub source_system: Option<String>,
    pub entry: Vec<FhirBundleEntry>,
}

#[derive(Deserialize)]
pub struct FhirBundleEntry {
    pub resource: FhirDiagnosticReport,
}

#[derive(Deserialize)]
pub struct FhirDiagnosticReport {
    #[serde(rename = "resourceType")]
    pub resource_type: String,
    pub id: String,
    pub status: String,
    pub subject_patient_id: Uuid,
    pub report_title: String,
    pub conclusion: String,
    pub replaces_source_record_id: Option<String>,
    pub correction_reason: Option<String>,
    pub structured_values: Option<Value>,
}

pub async fn ingest_uk_core_bundle(
    State(pool): State<PgPool>,
    actor: AuthenticatedActor,
    Json(bundle): Json<FhirBundle>,
) -> Result<Json<Value>, ClinicalError> {
    if bundle.resource_type != "Bundle" {
        return Err(ClinicalError::BadRequest("Expected FHIR R4 Bundle".into()));
    }
    let source_system = bundle.source_system.clone().unwrap_or_else(|| "berkshire_pathology_lis".into());

    let existing_status: Option<String> = sqlx::query_scalar(
        "SELECT processing_status FROM integration_inbox_messages WHERE source_system = $1 AND external_message_id = $2",
    )
    .bind(&source_system)
    .bind(&bundle.id)
    .fetch_optional(&pool)
    .await?;

    if existing_status.as_deref() == Some("processed") {
        return Ok(Json(json!({
            "status": "duplicate_ignored",
            "message": format!("Duplicate message {} from {} ignored idempotently", bundle.id, source_system)
        })));
    }

    let mut tx = pool.begin().await?;
    let inbox_id = Uuid::new_v4();
    let payload_str = json!({ "id": bundle.id, "source": source_system }).to_string();
    let mut hasher = Sha256::new();
    hasher.update(payload_str.as_bytes());
    let payload_sha256 = hex::encode(hasher.finalize());

    sqlx::query(
        r#"
        INSERT INTO integration_inbox_messages (id, source_system, external_message_id, message_format, mapping_version, payload_sha256, raw_payload_json, processing_status, processed_at)
        VALUES ($1, $2, $3, 'fhir_r4_uk_core_bundle', 'uk-core-r4-v1.2.0', $4, $5, 'processed', NOW())
        "#,
    )
    .bind(inbox_id)
    .bind(&source_system)
    .bind(&bundle.id)
    .bind(&payload_sha256)
    .bind(json!({ "id": bundle.id }))
    .execute(&mut *tx)
    .await?;

    let mut created_ids = Vec::new();
    for entry in bundle.entry {
        let rep = entry.resource;
        if rep.resource_type != "DiagnosticReport" {
            continue;
        }
        let replaces_id: Option<Uuid> = if let Some(ref prev_src) = rep.replaces_source_record_id {
            sqlx::query_scalar(
                "SELECT id FROM diagnostic_results WHERE source_record_id = $1 AND patient_id = $2 ORDER BY recorded_at DESC LIMIT 1",
            )
            .bind(prev_src)
            .bind(rep.subject_patient_id)
            .fetch_optional(&mut *tx)
            .await?
        } else {
            None
        };

        let result_id = Uuid::new_v4();
        sqlx::query(
            r#"
            INSERT INTO diagnostic_results (
                id, patient_id, origin_patient_id, report_code, report_title, result_summary,
                structured_values_json, status, replaces_result_id, correction_reason,
                effective_time, source_system, source_record_id
            ) VALUES ($1, $2, $2, 'UKCORE-LAB', $3, $4, $5, $6, $7, $8, $9, $10, $11)
            "#,
        )
        .bind(result_id)
        .bind(rep.subject_patient_id)
        .bind(&rep.report_title)
        .bind(&rep.conclusion)
        .bind(rep.structured_values.unwrap_or_else(|| json!([])))
        .bind(&rep.status)
        .bind(replaces_id)
        .bind(&rep.correction_reason)
        .bind(Utc::now())
        .bind(&source_system)
        .bind(&rep.id)
        .execute(&mut *tx)
        .await?;

        append_audit_event_tx(
            &mut tx,
            AuditEntryInput {
                actor_user_id: Some(actor.user_id),
                actor_role: actor.role_code.clone(),
                organisation_id: Some(actor.organisation_id),
                action: "fhir.import_result".into(),
                resource_type: "diagnostic_result".into(),
                resource_id: Some(result_id.to_string()),
                patient_id: Some(rep.subject_patient_id),
                outcome: "success",
                reason: None,
                minimised_metadata: json!({ "status": rep.status, "replaces_result_id": replaces_id }),
            },
        )
        .await?;

        created_ids.push(result_id);
    }

    tx.commit().await?;

    Ok(Json(json!({
        "inbox_id": inbox_id,
        "status": "processed",
        "created_result_ids": created_ids,
    })))
}
