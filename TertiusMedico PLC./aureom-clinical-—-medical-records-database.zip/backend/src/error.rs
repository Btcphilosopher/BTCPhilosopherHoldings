use axum::{
    Json,
    http::StatusCode,
    response::{IntoResponse, Response},
};
use serde_json::json;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum ClinicalError {
    #[error("Authentication required: {0}")]
    Unauthorized(String),
    #[error("Access denied: {0}")]
    Forbidden(String),
    #[error("Record not found: {0}")]
    NotFound(String),
    #[error("Concurrency or state conflict: {0}")]
    Conflict(String),
    #[error("Validation error: {0}")]
    BadRequest(String),
    #[error("Database error: {0}")]
    Database(#[from] sqlx::Error),
}

impl IntoResponse for ClinicalError {
    fn into_response(self) -> Response {
        let (status, msg) = match &self {
            ClinicalError::Unauthorized(m) => (StatusCode::UNAUTHORIZED, m.clone()),
            ClinicalError::Forbidden(m) => (StatusCode::FORBIDDEN, m.clone()),
            ClinicalError::NotFound(m) => (StatusCode::NOT_FOUND, m.clone()),
            ClinicalError::Conflict(m) => (StatusCode::CONFLICT, m.clone()),
            ClinicalError::BadRequest(m) => (StatusCode::BAD_REQUEST, m.clone()),
            ClinicalError::Database(err) => {
                tracing::error!(error = %err, "Database operation failed");
                (StatusCode::INTERNAL_SERVER_ERROR, "Internal clinical database error".to_string())
            }
        };
        (status, Json(json!({ "error": msg }))).into_response()
    }
}
