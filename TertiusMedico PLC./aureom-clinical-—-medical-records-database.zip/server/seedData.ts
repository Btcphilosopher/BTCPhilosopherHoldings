import crypto from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { appendAuditEvent } from './audit.ts';
import { makeSyntheticNhsNumber } from './nhsNumber.ts';
import { storePatientObject } from './storage.ts';

export const ORG_ID = '11111111-1111-1111-1111-111111111111';

export const USER_IDS = {
  consultant: '33333333-3333-3333-3333-333333333301',
  registrar: '33333333-3333-3333-3333-333333333302',
  nurse: '33333333-3333-3333-3333-333333333303',
  admin: '33333333-3333-3333-3333-333333333304',
  caldicott: '33333333-3333-3333-3333-333333333305',
};

export const PATIENT_IDS = {
  arthur: 'aaaa0001-1111-4111-8111-000000000001',
  maya: 'aaaa0002-1111-4111-8111-000000000002',
  oliverA: 'aaaa0003-1111-4111-8111-000000000003',
  oliverB: 'aaaa0004-1111-4111-8111-000000000004',
  clara: 'aaaa0005-1111-4111-8111-000000000005',
  tariq: 'aaaa0006-1111-4111-8111-000000000006',
};

export function seedClinicData(db: DatabaseSync): void {
  const existing = db.prepare('SELECT COUNT(*) as c FROM organisations').get() as { c: number };
  if (existing.c > 0) return;

  const now = '2026-11-24T09:00:00.000Z';

  // 1. Roles
  const roles = [
    ['consultant_physician', 'Consultant Physician', ['patient.read', 'patient.write', 'patient.merge', 'encounter.write', 'note.write', 'note.sign', 'note.amend', 'allergy.write', 'medication.prescribe', 'observation.write', 'result.review', 'task.write', 'document.write', 'document.read', 'audit.read_own', 'ai.assist', 'fhir.ingest']],
    ['specialty_registrar', 'Specialty Registrar', ['patient.read', 'patient.write', 'encounter.write', 'note.write', 'note.sign', 'note.amend', 'allergy.write', 'medication.prescribe', 'observation.write', 'result.review', 'task.write', 'document.write', 'document.read', 'ai.assist', 'fhir.ingest']],
    ['ward_nurse', 'Senior Ward Nurse', ['patient.read', 'encounter.read', 'note.write', 'allergy.write', 'medication.administer', 'observation.write', 'result.view', 'task.write', 'document.read']],
    ['clinical_admin', 'Clinical Records Administrator', ['patient.read', 'patient.write', 'patient.merge', 'encounter.write', 'document.write', 'document.read', 'task.write']],
    ['caldicott_guardian', 'Caldicott Guardian / IG Lead', ['patient.read', 'audit.read_all', 'break_glass.review', 'retention.manage', 'ai.configure', 'fhir.manage', 'document.read']],
  ] as const;

  const insertRole = db.prepare('INSERT INTO roles (code, display_name, permissions_json) VALUES (?, ?, ?)');
  for (const [code, name, perms] of roles) {
    insertRole.run(code, name, JSON.stringify(perms));
  }

  // 2. Organisation & Locations
  db.prepare(
    `INSERT INTO organisations (id, ods_code, name, org_type, country, config_json, ai_assistant_enabled, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    ORG_ID,
    'Y99001',
    'Thames Valley Integrated Care Clinic',
    'community_provider',
    'GB-ENG',
    JSON.stringify({
      nhsNumberValidation: 'mod11',
      fhirProfile: 'NHS England UK Core R4',
      terminologies: ['SNOMED CT UK Edition', 'NHS dm+d', 'UCUM'],
      timezone: 'Europe/London',
    }),
    0, // AI assistant explicitly disabled by default
    now,
    now
  );

  const locOpd = '22222222-2222-2222-2222-222222222201';
  const locWard = '22222222-2222-2222-2222-222222222202';
  const locDiag = '22222222-2222-2222-2222-222222222203';
  db.prepare('INSERT INTO locations (id, organisation_id, code, name, location_type, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(locOpd, ORG_ID, 'TV-OPD-1', 'Reading Medical Outpatients Suite', 'outpatient_clinic', now);
  db.prepare('INSERT INTO locations (id, organisation_id, code, name, location_type, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(locWard, ORG_ID, 'TV-WARD-A', 'Kennet Acute Assessment Unit', 'ward', now);
  db.prepare('INSERT INTO locations (id, organisation_id, code, name, location_type, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(locDiag, ORG_ID, 'TV-DIAG-1', 'Berkshire Diagnostics & Imaging Hub', 'diagnostic_suite', now);

  // 3. Users & Care Team
  const users = [
    [USER_IDS.consultant, 'e.whitaker', 'e.whitaker@thamesvalley.example.nhs.uk', 'Dr Eleanor Whitaker', 'GMC-6140928', 'consultant_physician'],
    [USER_IDS.registrar, 'r.patel', 'r.patel@thamesvalley.example.nhs.uk', 'Dr Rohan Patel', 'GMC-7429104', 'specialty_registrar'],
    [USER_IDS.nurse, 'h.okafor', 'h.okafor@thamesvalley.example.nhs.uk', 'Hannah Okafor RN', 'NMC-18B0412E', 'ward_nurse'],
    [USER_IDS.admin, 'm.bennett', 'm.bennett@thamesvalley.example.nhs.uk', 'Marcus Bennett', null, 'clinical_admin'],
    [USER_IDS.caldicott, 's.aldridge', 's.aldridge@thamesvalley.example.nhs.uk', 'Sarah Aldridge', 'IG-900412', 'caldicott_guardian'],
  ] as const;
  const insertUser = db.prepare(
    `INSERT INTO users (id, organisation_id, username, email, full_name, professional_reg_no, role_code, identity_provider, mfa_enrolled, is_active, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'cis2_oidc_adapter', 1, 1, ?)`
  );
  for (const [id, un, em, fn, reg, role] of users) {
    insertUser.run(id, ORG_ID, un, em, fn, reg, role, now);
  }

  const teamCardio = '44444444-4444-4444-4444-444444444401';
  db.prepare('INSERT INTO care_teams (id, organisation_id, name, specialty_snomed, created_at) VALUES (?, ?, ?, ?, ?)').run(
    teamCardio, ORG_ID, 'General Medicine & Cardiorenal Team', '394802001', now
  );
  db.prepare('INSERT INTO care_team_memberships (care_team_id, user_id, team_role, effective_from) VALUES (?, ?, ?, ?)').run(teamCardio, USER_IDS.consultant, 'Lead Consultant', now);
  db.prepare('INSERT INTO care_team_memberships (care_team_id, user_id, team_role, effective_from) VALUES (?, ?, ?, ?)').run(teamCardio, USER_IDS.registrar, 'Specialty Registrar', now);
  db.prepare('INSERT INTO care_team_memberships (care_team_id, user_id, team_role, effective_from) VALUES (?, ?, ?, ?)').run(teamCardio, USER_IDS.nurse, 'Named Ward Nurse', now);

  // 4. Synthetic Patients with mathematically valid Mod-11 NHS Numbers (999-xxx-xxxx synthetic range)
  const nhsArthur = makeSyntheticNhsNumber('999000001'); // 9990000018
  const nhsMaya = makeSyntheticNhsNumber('999000002');   // 9990000026
  const nhsOliver = makeSyntheticNhsNumber('999000003'); // 9990000034
  const nhsClara = makeSyntheticNhsNumber('999000005');  // 9990000050
  const nhsTariq = makeSyntheticNhsNumber('999000006');  // 9990000069

  const insertPatient = db.prepare(
    `INSERT INTO patients (
      id, internal_mrn, organisation_id, birth_date, birth_date_accuracy, administrative_gender,
      allergy_assessment_status, allergy_assessed_at, allergy_assessed_by, record_status, sensitivity_level, created_at, updated_at
    ) VALUES (?, ?, ?, ?, 'exact', ?, ?, ?, ?, 'active', ?, ?, ?)`
  );

  insertPatient.run(PATIENT_IDS.arthur, 'AUR-100412', ORG_ID, '1954-04-12', 'male', 'assessed_present', '2026-11-20T10:15:00.000Z', USER_IDS.consultant, 'normal', '2024-03-10T09:00:00.000Z', now);
  insertPatient.run(PATIENT_IDS.maya, 'AUR-100419', ORG_ID, '1982-09-23', 'female', 'assessed_no_known_allergies', '2026-11-22T14:00:00.000Z', USER_IDS.registrar, 'normal', '2025-01-14T11:20:00.000Z', now);
  insertPatient.run(PATIENT_IDS.oliverA, 'AUR-100425', ORG_ID, '1948-11-03', 'male', 'assessed_present', '2026-10-05T09:30:00.000Z', USER_IDS.consultant, 'normal', '2025-06-01T08:45:00.000Z', now);
  insertPatient.run(PATIENT_IDS.oliverB, 'AUR-100488', ORG_ID, '1948-11-03', 'male', 'not_assessed', null, null, 'normal', '2026-11-18T16:10:00.000Z', now);
  insertPatient.run(PATIENT_IDS.clara, 'AUR-100431', ORG_ID, '1991-06-18', 'female', 'assessed_no_known_allergies', '2026-11-10T11:00:00.000Z', USER_IDS.consultant, 'restricted', '2025-09-12T10:00:00.000Z', now);
  insertPatient.run(PATIENT_IDS.tariq, 'AUR-100447', ORG_ID, '1971-01-30', 'male', 'not_assessed', null, null, 'normal', '2026-11-23T08:00:00.000Z', now);

  // Identifiers
  const insertIdent = db.prepare(
    `INSERT INTO patient_identifiers (id, patient_id, origin_patient_id, identifier_type, identifier_value, issuing_authority, verification_status, effective_from, is_primary, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  insertIdent.run('id-arthur-nhs', PATIENT_IDS.arthur, PATIENT_IDS.arthur, 'nhs_number', nhsArthur, 'NHS England PDS', 'verified_pds', '2024-03-10', 1, now);
  insertIdent.run('id-arthur-mrn', PATIENT_IDS.arthur, PATIENT_IDS.arthur, 'local_mrn', 'AUR-100412', 'Y99001', 'verified_mod11', '2024-03-10', 0, now);
  insertIdent.run('id-maya-nhs', PATIENT_IDS.maya, PATIENT_IDS.maya, 'nhs_number', nhsMaya, 'NHS England PDS', 'verified_pds', '2025-01-14', 1, now);
  insertIdent.run('id-olivera-nhs', PATIENT_IDS.oliverA, PATIENT_IDS.oliverA, 'nhs_number', nhsOliver, 'NHS England PDS', 'verified_pds', '2025-06-01', 1, now);
  insertIdent.run('id-oliverb-ext', PATIENT_IDS.oliverB, PATIENT_IDS.oliverB, 'external_clinic_id', 'WEST-BERKS-7741', 'West Berks Walk-in', 'unverified', '2026-11-18', 1, now);
  insertIdent.run('id-clara-nhs', PATIENT_IDS.clara, PATIENT_IDS.clara, 'nhs_number', nhsClara, 'NHS England PDS', 'verified_pds', '2025-09-12', 1, now);
  insertIdent.run('id-tariq-nhs', PATIENT_IDS.tariq, PATIENT_IDS.tariq, 'nhs_number', nhsTariq, 'Local Registration', 'verified_mod11', '2026-11-23', 1, now);

  // Names (including historical name on Maya)
  const insertName = db.prepare(
    'INSERT INTO patient_names (id, patient_id, name_use, prefix, given_names, family_name, effective_from, effective_to, recorded_by, source_system) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  insertName.run('nm-arthur', PATIENT_IDS.arthur, 'official', 'Mr', 'Arthur George', 'Pendelton', '2024-03-10T09:00:00Z', null, USER_IDS.admin, 'aureom_ehr');
  insertName.run('nm-maya-old', PATIENT_IDS.maya, 'maiden', 'Ms', 'Maya', 'Lin', '2025-01-14T11:20:00Z', '2026-02-01T00:00:00Z', USER_IDS.admin, 'aureom_ehr');
  insertName.run('nm-maya', PATIENT_IDS.maya, 'official', 'Mrs', 'Maya', 'Lin-Kowalski', '2026-02-01T00:00:00Z', null, USER_IDS.admin, 'aureom_ehr');
  insertName.run('nm-olivera', PATIENT_IDS.oliverA, 'official', 'Mr', 'Oliver', 'Henderson', '2025-06-01T08:45:00Z', null, USER_IDS.admin, 'aureom_ehr');
  insertName.run('nm-oliverb', PATIENT_IDS.oliverB, 'official', 'Mr', 'Oliver J.', 'Henderson', '2026-11-18T16:10:00Z', null, USER_IDS.admin, 'west_berks_import');
  insertName.run('nm-clara', PATIENT_IDS.clara, 'official', 'Ms', 'Clara', 'Vance-Thorne', '2025-09-12T10:00:00Z', null, USER_IDS.admin, 'aureom_ehr');
  insertName.run('nm-tariq', PATIENT_IDS.tariq, 'official', 'Mr', 'Tariq', 'Al-Mansoor', '2026-11-23T08:00:00Z', null, USER_IDS.admin, 'aureom_ehr');

  // Addresses & Contacts
  const insertAddr = db.prepare(
    'INSERT INTO patient_addresses (id, patient_id, address_use, line1, city, county, postcode, effective_from, effective_to, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  insertAddr.run('ad-arthur', PATIENT_IDS.arthur, 'home', '14 Caversham Bridge Road', 'Reading', 'Berkshire', 'RG1 8AA', '2024-03-10T09:00:00Z', null, USER_IDS.admin);
  insertAddr.run('ad-maya', PATIENT_IDS.maya, 'home', '88 Erleigh Road', 'Reading', 'Berkshire', 'RG1 5NA', '2026-02-01T00:00:00Z', null, USER_IDS.admin);
  insertAddr.run('ad-olivera', PATIENT_IDS.oliverA, 'home', '7 Pangbourne Lane', 'Pangbourne', 'Berkshire', 'RG8 7JL', '2025-06-01T08:45:00Z', null, USER_IDS.admin);
  insertAddr.run('ad-oliverb', PATIENT_IDS.oliverB, 'temporary', '7 Pangbourne Ln (Walk-in entry)', 'Reading', 'Berkshire', 'RG8 7JL', '2026-11-18T16:10:00Z', null, USER_IDS.admin);
  insertAddr.run('ad-clara', PATIENT_IDS.clara, 'home', '22 Abbey Square (Confidential)', 'Reading', 'Berkshire', 'RG1 3BE', '2025-09-12T10:00:00Z', null, USER_IDS.admin);
  insertAddr.run('ad-tariq', PATIENT_IDS.tariq, 'home', '103 London Road', 'Reading', 'Berkshire', 'RG1 5BY', '2026-11-23T08:00:00Z', null, USER_IDS.admin);

  db.prepare('INSERT INTO patient_contacts (id, patient_id, relationship_type, full_name, telecom_phone, organisation_ods, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    'ct-arthur-gp', PATIENT_IDS.arthur, 'registered_gp', 'Dr Simon Bellamy (Tilehurst Surgery)', '0118 555 0142', 'K81042', now
  );
  db.prepare('INSERT INTO patient_contacts (id, patient_id, relationship_type, full_name, telecom_phone, organisation_ods, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    'ct-arthur-nok', PATIENT_IDS.arthur, 'next_of_kin', 'Margaret Pendelton (Spouse)', '07700 900412', null, now
  );

  // Duplicate candidate (NOT auto-merged!)
  db.prepare(
    `INSERT INTO patient_duplicate_candidates (id, patient_a_id, patient_b_id, match_score, match_rationale, review_status, created_at)
     VALUES (?, ?, ?, ?, ?, 'pending_review', ?)`
  ).run(
    'dup-oliver-001',
    PATIENT_IDS.oliverA,
    PATIENT_IDS.oliverB,
    0.91,
    'Exact date of birth (1948-11-03), matching postcode (RG8 7JL), and phonetically identical name ("Oliver Henderson" vs "Oliver J. Henderson"). Manual verification required before merge.',
    now
  );

  // Access Restriction on Clara Vance-Thorne (Safeguarding / Mental Health)
  db.prepare(
    `INSERT INTO access_restrictions (id, patient_id, resource_type, resource_id, policy_code, allowed_roles_json, reason, created_by, active, created_at)
     VALUES (?, ?, 'patient', NULL, 'safeguarding', ?, ?, ?, 1, ?)`
  ).run(
    'rest-clara-001',
    PATIENT_IDS.clara,
    JSON.stringify(['consultant_physician', 'caldicott_guardian']),
    'Restricted safeguarding & perinatal mental health record; requires Consultant, Caldicott Guardian, or justified Break-Glass access.',
    USER_IDS.caldicott,
    now
  );

  // Separate Consent Directives (demonstrating consent != access decision)
  db.prepare('INSERT INTO consent_directives (id, patient_id, purpose, decision, scope_notes, recorded_by, effective_from) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    'con-arthur-1', PATIENT_IDS.arthur, 'direct_care', 'permit', 'Standard direct care sharing across Berkshire ICB', USER_IDS.consultant, now
  );
  db.prepare('INSERT INTO consent_directives (id, patient_id, purpose, decision, scope_notes, recorded_by, effective_from) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    'con-arthur-2', PATIENT_IDS.arthur, 'research_opt_in', 'deny', 'Patient opted out of secondary research exports', USER_IDS.admin, now
  );
  db.prepare('INSERT INTO consent_directives (id, patient_id, purpose, decision, scope_notes, recorded_by, effective_from) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    'con-clara-1', PATIENT_IDS.clara, 'hie_exchange', 'deny', 'Do not publish sensitive clinic correspondence to regional HIE', USER_IDS.consultant, now
  );

  // Encounters
  const encArthur1 = 'eeee0001-1111-4111-8111-000000000001';
  const encArthur2 = 'eeee0002-1111-4111-8111-000000000002';
  const encMaya1 = 'eeee0003-1111-4111-8111-000000000003';
  const encClara1 = 'eeee0004-1111-4111-8111-000000000004';
  const encTariq1 = 'eeee0005-1111-4111-8111-000000000005';

  const insertEnc = db.prepare(
    `INSERT INTO encounters (id, patient_id, organisation_id, location_id, care_team_id, attending_user_id, encounter_class, status, reason_text, started_at, ended_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  insertEnc.run(encArthur1, PATIENT_IDS.arthur, ORG_ID, locOpd, teamCardio, USER_IDS.consultant, 'outpatient', 'finished', 'Annual cardiorenal & CKD stage 3b follow-up', '2026-10-14T09:30:00.000Z', '2026-10-14T10:15:00.000Z', '2026-10-14T09:30:00.000Z');
  insertEnc.run(encArthur2, PATIENT_IDS.arthur, ORG_ID, locWard, teamCardio, USER_IDS.consultant, 'inpatient', 'in_progress', 'Acute ankle oedema and rising serum creatinine review', '2026-11-23T14:20:00.000Z', null, '2026-11-23T14:20:00.000Z');
  insertEnc.run(encMaya1, PATIENT_IDS.maya, ORG_ID, locOpd, teamCardio, USER_IDS.registrar, 'outpatient', 'in_progress', 'Persistent nocturnal cough & spirometry review', '2026-11-24T08:15:00.000Z', null, '2026-11-24T08:15:00.000Z');
  insertEnc.run(encClara1, PATIENT_IDS.clara, ORG_ID, locOpd, teamCardio, USER_IDS.consultant, 'outpatient', 'finished', 'Confidential safeguarding & perinatal medication review', '2026-11-10T11:00:00.000Z', '2026-11-10T11:45:00.000Z', '2026-11-10T11:00:00.000Z');
  insertEnc.run(encTariq1, PATIENT_IDS.tariq, ORG_ID, locOpd, teamCardio, USER_IDS.registrar, 'outpatient', 'in_progress', 'New GP referral for newly detected hypertension', '2026-11-24T08:40:00.000Z', null, '2026-11-24T08:40:00.000Z');

  // Problems
  const insertProb = db.prepare(
    `INSERT INTO problems (id, patient_id, origin_patient_id, encounter_id, snomed_code, display_term, clinical_status, verification_status, onset_date, author_id, event_time, recorded_at, source_system, sensitivity_level, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  insertProb.run('pr-arthur-1', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur1, '709044004', 'Chronic kidney disease stage 3B (disorder)', 'active', 'confirmed', '2023-05-12', USER_IDS.consultant, '2026-10-14T09:40:00Z', '2026-10-14T09:40:00Z', 'aureom_ehr', 'normal', 'Baseline eGFR 38–42 mL/min/1.73m2');
  insertProb.run('pr-arthur-2', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur1, '38341003', 'Essential hypertension', 'active', 'confirmed', '2018-02-01', USER_IDS.consultant, '2024-03-10T09:15:00Z', '2024-03-10T09:15:00Z', 'gp_connect_import', 'normal', null);
  insertProb.run('pr-maya-1', PATIENT_IDS.maya, PATIENT_IDS.maya, encMaya1, '195967001', 'Asthma (disorder)', 'active', 'confirmed', '2011-08-20', USER_IDS.registrar, '2026-11-24T08:20:00Z', '2026-11-24T08:20:00Z', 'aureom_ehr', 'normal', 'Seasonal exacerbation noted');
  insertProb.run('pr-clara-1', PATIENT_IDS.clara, PATIENT_IDS.clara, encClara1, '35489007', 'Depressive disorder (restricted safeguarding context)', 'active', 'confirmed', '2025-04-01', USER_IDS.consultant, '2026-11-10T11:10:00Z', '2026-11-10T11:10:00Z', 'aureom_ehr', 'restricted', 'Safeguarding care plan active');

  // Allergies (including conflicting external GP summary entry on Arthur!)
  const insertAllergy = db.prepare(
    `INSERT INTO allergies (id, patient_id, origin_patient_id, encounter_id, substance_code, substance_name, reaction_manifestation, severity, criticality, verification_status, clinical_status, author_id, event_time, recorded_at, source_system, conflict_flag)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  insertAllergy.run('al-arthur-1', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur1, '764146007', 'Penicillin V', 'Generalised urticaria and lip angioedema', 'severe', 'high', 'confirmed', 'active', USER_IDS.consultant, '2024-03-10T09:20:00Z', '2024-03-10T09:20:00Z', 'aureom_ehr', 0);
  insertAllergy.run('al-arthur-2', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, '372687004', 'Cefalexin (Contradictory GP report)', 'Possible GI upset vs rash — unverified external GP entry; patient denies rash', 'unknown', 'unable_to_assess', 'unconfirmed', 'active', USER_IDS.registrar, '2026-11-23T14:35:00Z', '2026-11-23T14:35:00Z', 'gp_connect_import', 1);
  insertAllergy.run('al-olivera-1', PATIENT_IDS.oliverA, PATIENT_IDS.oliverA, null, '387458008', 'Aspirin', 'Bronchospasm', 'moderate', 'high', 'confirmed', 'active', USER_IDS.consultant, '2025-06-01T09:00:00Z', '2025-06-01T09:00:00Z', 'aureom_ehr', 0);

  // Medications (Distinct Statements vs Prescriptions vs Dispensing vs Administrations)
  db.prepare(
    `INSERT INTO medication_statements (id, patient_id, origin_patient_id, encounter_id, dmd_code, medication_name, reported_dose_text, information_source, status, event_time, recorded_at, recorded_by, source_system)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run('ms-arthur-1', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, '318851002', 'Ramipril 5mg capsules', 'Patient reports taking 5mg once daily in morning', 'patient_reported', 'active', '2026-11-23T14:30:00Z', '2026-11-23T14:30:00Z', USER_IDS.nurse, 'aureom_ehr');

  db.prepare(
    `INSERT INTO medication_statements (id, patient_id, origin_patient_id, encounter_id, dmd_code, medication_name, reported_dose_text, information_source, status, event_time, recorded_at, recorded_by, source_system)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run('ms-arthur-2', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, '318851002', 'Ramipril 2.5mg capsules (GP Summary)', 'GP summary lists 2.5mg OD — dose discrepancy flagged for reconciliation', 'gp_summary_import', 'active', '2026-11-20T08:00:00Z', '2026-11-23T14:32:00Z', USER_IDS.registrar, 'gp_connect_import');

  db.prepare(
    `INSERT INTO prescriptions (id, patient_id, origin_patient_id, encounter_id, dmd_code, medication_name, dose_value, dose_unit, route, frequency, indication, prescriber_id, status, authored_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run('rx-arthur-1', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, '317304008', 'Furosemide 40mg tablets', 40, 'mg', 'Oral', 'Once daily in the morning', 'Acute peripheral oedema in CKD 3b', USER_IDS.consultant, 'active', '2026-11-23T15:00:00Z');

  db.prepare(
    `INSERT INTO dispensing_records (id, prescription_id, patient_id, quantity_value, quantity_unit, batch_number, dispensed_by, dispensed_at, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run('disp-arthur-1', 'rx-arthur-1', PATIENT_IDS.arthur, 28, 'tablets', 'BCH-88412A', 'Kennet Ward Dispensary (GPhC-2088412)', '2026-11-23T15:30:00Z', 'completed');

  db.prepare(
    `INSERT INTO medication_administrations (id, prescription_id, patient_id, encounter_id, dose_given, route, administered_by, administered_at, status, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run('mar-arthur-1', 'rx-arthur-1', PATIENT_IDS.arthur, encArthur2, '40 mg', 'Oral', USER_IDS.nurse, '2026-11-24T08:00:00Z', 'completed', 'Administered with breakfast; urinary output chart commenced.');

  // Clinical Notes: Signed + Amended note on Arthur; Draft note on Maya; Restricted note on Clara
  const noteArthurId = 'nnnn0001-1111-4111-8111-000000000001';
  const arthurNoteText = `Consultation Summary — Cardiorenal Follow-up\n\nPresenting Complaint: Progressive bilateral ankle swelling over 10 days alongside mild exertional breathlessness.\n\nExamination: BP 148/86 mmHg, HR 74 bpm regular, JVP +3cm, pitting oedema to mid-shin bilaterally.\n\nPlan:\n1. Commence Furosemide 40mg PO OD with daily weights.\n2. Repeat U&Es and eGFR within 48 hours.\n3. Reconcile Ramipril dose discrepancy between patient report (5mg) and GP summary (2.5mg).`;
  const arthurNoteHash = crypto.createHash('sha256').update(arthurNoteText).digest('hex');

  db.prepare(
    `INSERT INTO clinical_notes (id, patient_id, origin_patient_id, encounter_id, note_type, title, status, current_version, author_id, event_time, recorded_at, signed_at, signed_by, sensitivity_level)
     VALUES (?, ?, ?, ?, 'ward_round', ?, 'amended', 1, ?, '2026-11-23T15:10:00Z', '2026-11-23T15:10:00Z', '2026-11-23T15:25:00Z', ?, 'normal')`
  ).run(noteArthurId, PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, 'Acute Cardiorenal Admission Note', USER_IDS.consultant, USER_IDS.consultant);

  db.prepare(
    `INSERT INTO clinical_note_versions (id, note_id, version_number, body_text, copied_material_refs, is_immutable, saved_by, saved_at)
     VALUES (?, ?, 1, ?, ?, 1, ?, '2026-11-23T15:25:00Z')`
  ).run('nv-arthur-1', noteArthurId, arthurNoteText, JSON.stringify([{ source_record_id: 'ms-arthur-2', label: 'GP Summary Ramipril 2.5mg discrepancy' }]), USER_IDS.consultant);

  db.prepare(
    `INSERT INTO clinical_signatures (id, note_id, version_number, signer_id, attestation_statement, idempotency_key, content_sha256, signature_algorithm, signed_at)
     VALUES (?, ?, 1, ?, ?, ?, ?, 'SHA-256-DIGEST-ONLY', '2026-11-23T15:25:00Z')`
  ).run('sig-arthur-1', noteArthurId, USER_IDS.consultant, 'I attest this clinical record is accurate at the time of signing.', 'seed-sign-arthur-1', arthurNoteHash);

  const addendumText = 'Addendum (Dr R. Patel): Spoke with Tilehurst Surgery pharmacist — Ramipril was increased to 5mg OD on 2026-10-28, GP summary feed lagged by 3 weeks. Patient taking correct 5mg dose.';
  db.prepare(
    `INSERT INTO clinical_note_amendments (id, note_id, amendment_type, reason, addendum_text, copied_material_refs, author_id, signed_at, content_sha256)
     VALUES (?, ?, 'addendum', 'Medication reconciliation clarification', ?, '[]', ?, '2026-11-23T17:40:00Z', ?)`
  ).run('amd-arthur-1', noteArthurId, addendumText, USER_IDS.registrar, crypto.createHash('sha256').update(addendumText).digest('hex'));

  // Draft note on Maya
  const noteMayaId = 'nnnn0002-1111-4111-8111-000000000002';
  db.prepare(
    `INSERT INTO clinical_notes (id, patient_id, origin_patient_id, encounter_id, note_type, title, status, current_version, author_id, event_time, recorded_at, sensitivity_level)
     VALUES (?, ?, ?, ?, 'consultation', ?, 'draft', 1, ?, '2026-11-24T08:30:00Z', '2026-11-24T08:30:00Z', 'normal')`
  ).run(noteMayaId, PATIENT_IDS.maya, PATIENT_IDS.maya, encMaya1, 'Respiratory Outpatient Review (Draft)', USER_IDS.registrar);
  db.prepare(
    `INSERT INTO clinical_note_versions (id, note_id, version_number, body_text, copied_material_refs, is_immutable, saved_by, saved_at)
     VALUES (?, ?, 1, ?, '[]', 0, ?, '2026-11-24T08:30:00Z')`
  ).run('nv-maya-1', noteMayaId, 'Draft consultation note: Nocturnal wheeze 3 nights/week over past month. Peak flow 390 L/min (predicted 440 L/min). Awaiting Chest X-Ray report before finalising step-up inhaler plan.', USER_IDS.registrar);

  // Restricted note on Clara
  const noteClaraId = 'nnnn0003-1111-4111-8111-000000000003';
  const claraText = 'Confidential safeguarding review: Multi-agency perinatal support plan active. Crisis team contact verified. Do not disclose location details.';
  db.prepare(
    `INSERT INTO clinical_notes (id, patient_id, origin_patient_id, encounter_id, note_type, title, status, current_version, author_id, event_time, recorded_at, signed_at, signed_by, sensitivity_level)
     VALUES (?, ?, ?, ?, 'consultation', ?, 'signed', 1, ?, '2026-11-10T11:30:00Z', '2026-11-10T11:30:00Z', '2026-11-10T11:40:00Z', ?, 'restricted')`
  ).run(noteClaraId, PATIENT_IDS.clara, PATIENT_IDS.clara, encClara1, 'Safeguarding & Perinatal Review', USER_IDS.consultant, USER_IDS.consultant);
  db.prepare(
    `INSERT INTO clinical_note_versions (id, note_id, version_number, body_text, copied_material_refs, is_immutable, saved_by, saved_at)
     VALUES (?, ?, 1, ?, '[]', 1, ?, '2026-11-10T11:40:00Z')`
  ).run('nv-clara-1', noteClaraId, claraText, USER_IDS.consultant);
  db.prepare(
    `INSERT INTO clinical_signatures (id, note_id, version_number, signer_id, attestation_statement, idempotency_key, content_sha256, signature_algorithm, signed_at)
     VALUES (?, ?, 1, ?, 'I attest this restricted clinical record.', 'seed-sign-clara-1', ?, 'SHA-256-DIGEST-ONLY', '2026-11-10T11:40:00Z')`
  ).run('sig-clara-1', noteClaraId, USER_IDS.consultant, crypto.createHash('sha256').update(claraText).digest('hex'));

  // Observations & Specimens
  db.prepare(
    'INSERT INTO specimens (id, patient_id, specimen_type, collection_time, received_time, collector_name, source_system) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run('spec-arthur-1', PATIENT_IDS.arthur, 'Venous blood (Serum Separator Tube)', '2026-11-23T14:45:00Z', '2026-11-23T15:05:00Z', 'Hannah Okafor RN', 'berkshire_pathology_lis');

  const insertObs = db.prepare(
    `INSERT INTO observations (id, patient_id, origin_patient_id, encounter_id, specimen_id, code_system, code, display_name, value_numeric, unit, ref_range_low, ref_range_high, source_interpretation, status, effective_time, recorded_at, author_id, source_system)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  insertObs.run('obs-arthur-bp', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, null, 'SNOMED-CT', '271649006', 'Systolic blood pressure', 148, 'mmHg', 90, 139, 'Above reference interval (source)', 'final', '2026-11-23T14:25:00Z', '2026-11-23T14:26:00Z', USER_IDS.nurse, 'aureom_ehr');
  insertObs.run('obs-arthur-k', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, 'spec-arthur-1', 'LOINC', '2823-3', 'Serum Potassium', 4.9, 'mmol/L', 3.5, 5.3, 'Within source interval', 'final', '2026-11-23T14:45:00Z', '2026-11-23T16:10:00Z', null, 'berkshire_pathology_lis');
  insertObs.run('obs-maya-spo2', PATIENT_IDS.maya, PATIENT_IDS.maya, encMaya1, null, 'SNOMED-CT', '431314004', 'Peripheral oxygen saturation', 97, '%', 94, 98, 'Within source interval', 'final', '2026-11-24T08:18:00Z', '2026-11-24T08:19:00Z', USER_IDS.nurse, 'aureom_ehr');

  // Diagnostic Results: Preliminary -> Corrected chain on Arthur + Unviewed Final on Maya
  const resPrelimId = 'res-arthur-prelim-1';
  const resCorrId = 'res-arthur-corr-1';
  const resMayaId = 'res-maya-1';

  db.prepare(
    `INSERT INTO diagnostic_results (id, patient_id, origin_patient_id, encounter_id, specimen_id, report_code, report_title, result_summary, structured_values_json, status, replaces_result_id, review_state, reviewed_by, reviewed_at, effective_time, recorded_at, source_system, source_record_id)
     VALUES (?, ?, ?, ?, ?, 'UE-RENAL', 'Renal Profile & eGFR (Preliminary)', 'Serum Creatinine 198 umol/L; eGFR 29 mL/min/1.73m2 (Preliminary haemolysis check pending)', ?, 'preliminary', NULL, 'acknowledged', ?, '2026-11-23T16:00:00Z', '2026-11-23T14:45:00Z', '2026-11-23T15:50:00Z', 'berkshire_pathology_lis', 'LIS-88291-P')`
  ).run(
    resPrelimId,
    PATIENT_IDS.arthur,
    PATIENT_IDS.arthur,
    encArthur2,
    'spec-arthur-1',
    JSON.stringify([{ analyte: 'Serum Creatinine', value: 198, unit: 'umol/L', refLow: 60, refHigh: 110, flag: 'High (source LIS)' }]),
    USER_IDS.consultant
  );

  db.prepare(
    `INSERT INTO diagnostic_results (id, patient_id, origin_patient_id, encounter_id, specimen_id, report_code, report_title, result_summary, structured_values_json, status, replaces_result_id, correction_reason, review_state, effective_time, recorded_at, source_system, source_record_id)
     VALUES (?, ?, ?, ?, ?, 'UE-RENAL', 'Renal Profile & eGFR (Corrected)', 'Corrected Creatinine 176 umol/L (previous 198 affected by sample dilution error); eGFR 33 mL/min/1.73m2', ?, 'corrected', ?, 'Laboratory corrected sample dilution factor on repeat assay', 'unviewed', '2026-11-23T14:45:00Z', '2026-11-24T07:55:00Z', 'berkshire_pathology_lis', 'LIS-88291-C')`
  ).run(
    resCorrId,
    PATIENT_IDS.arthur,
    PATIENT_IDS.arthur,
    encArthur2,
    'spec-arthur-1',
    JSON.stringify([
      { analyte: 'Serum Creatinine', value: 176, unit: 'umol/L', refLow: 60, refHigh: 110, flag: 'High (source LIS)' },
      { analyte: 'eGFR (CKD-EPI)', value: 33, unit: 'mL/min/1.73m2', refLow: 60, refHigh: 120, flag: 'Low (source LIS)' },
    ]),
    resPrelimId
  );

  db.prepare(
    `INSERT INTO diagnostic_results (id, patient_id, origin_patient_id, encounter_id, report_code, report_title, result_summary, structured_values_json, status, review_state, effective_time, recorded_at, source_system, source_record_id)
     VALUES (?, ?, ?, ?, 'CBC-DIFF', 'Full Blood Count & Eosinophils', 'Haemoglobin 134 g/L, WCC 7.2 x10^9/L, Eosinophils 0.62 x10^9/L (mildly elevated per lab range)', ?, 'final', 'unviewed', '2026-11-24T07:30:00Z', '2026-11-24T08:10:00Z', 'berkshire_pathology_lis', 'LIS-88340-F')`
  ).run(
    resMayaId,
    PATIENT_IDS.maya,
    PATIENT_IDS.maya,
    encMaya1,
    JSON.stringify([
      { analyte: 'Haemoglobin', value: 134, unit: 'g/L', refLow: 115, refHigh: 165, flag: 'Normal' },
      { analyte: 'Eosinophils', value: 0.62, unit: 'x10^9/L', refLow: 0.04, refHigh: 0.40, flag: 'High (source LIS)' },
    ])
  );

  // Follow-up Task
  db.prepare(
    `INSERT INTO follow_up_tasks (id, patient_id, encounter_id, linked_result_id, title, instructions, priority, status, assigned_to, created_by, due_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'urgent', 'open', ?, ?, '2026-11-24T17:00:00Z', ?)`
  ).run(
    'task-arthur-1',
    PATIENT_IDS.arthur,
    encArthur2,
    resCorrId,
    'Review corrected eGFR & repeat U&Es at 48 hours',
    'Confirm corrected Creatinine (176 umol/L) with Consultant and schedule repeat venous U&E on 2026-11-25.',
    USER_IDS.registrar,
    USER_IDS.consultant,
    now
  );

  // Protected Document in Object Storage + Imaging Reference
  const letterText = `THAMES VALLEY INTEGRATED CARE CLINIC (ODS: Y99001)\nGP Summary Correspondence — Arthur Pendelton (MRN: AUR-100412)\n\nDear Dr Bellamy,\nArthur was admitted to Kennet Acute Assessment Unit on 23 Nov 2026 with bilateral ankle oedema.\nCommenced on Furosemide 40mg OD. Confirmed Ramipril 5mg OD with Tilehurst Pharmacy.\nKind regards,\nDr Eleanor Whitaker, Consultant Physician`;
  const storedDoc = storePatientObject(PATIENT_IDS.arthur, 'gp_update_pendelton_2026_11_23.txt', Buffer.from(letterText, 'utf8'));
  db.prepare(
    `INSERT INTO documents (id, patient_id, origin_patient_id, encounter_id, title, document_type, mime_type, byte_size, object_storage_key, sha256_checksum, uploaded_by, sensitivity_level, created_at)
     VALUES (?, ?, ?, ?, ?, 'gp_correspondence', 'text/plain', ?, ?, ?, ?, 'normal', ?)`
  ).run('doc-arthur-1', PATIENT_IDS.arthur, PATIENT_IDS.arthur, encArthur2, 'GP Update Letter — Cardiorenal Admission', storedDoc.byteSize, storedDoc.objectKey, storedDoc.sha256, USER_IDS.consultant, now);

  const restrictedDocText = `CONFIDENTIAL SAFEGUARDING CASE CONFERENCE NOTE\nPatient: Clara Vance-Thorne\nAuthorised distribution: Consultant & Caldicott Guardian only.`;
  const storedClaraDoc = storePatientObject(PATIENT_IDS.clara, 'safeguarding_conference_2026_11_10.txt', Buffer.from(restrictedDocText, 'utf8'));
  db.prepare(
    `INSERT INTO documents (id, patient_id, origin_patient_id, encounter_id, title, document_type, mime_type, byte_size, object_storage_key, sha256_checksum, uploaded_by, sensitivity_level, created_at)
     VALUES (?, ?, ?, ?, ?, 'safeguarding_report', 'text/plain', ?, ?, ?, ?, 'restricted', ?)`
  ).run('doc-clara-1', PATIENT_IDS.clara, PATIENT_IDS.clara, encClara1, 'Safeguarding Multi-Agency Summary', storedClaraDoc.byteSize, storedClaraDoc.objectKey, storedClaraDoc.sha256, USER_IDS.consultant, now);

  db.prepare(
    `INSERT INTO imaging_references (id, patient_id, encounter_id, study_instance_uid, accession_number, modality, body_site, study_description, archive_endpoint_uri, performed_at, status)
     VALUES (?, ?, ?, ?, ?, 'DX', 'Chest', 'Chest PA Radiograph — persistent cough assessment', 'dicomweb://pacs.thamesvalley.local/studies/1.2.826.0.1.3680043.8.498.100419', '2026-11-24T08:05:00Z', 'available')`
  ).run('img-maya-cxr', PATIENT_IDS.maya, encMaya1, '1.2.826.0.1.3680043.8.498.100419', 'ACC-2026-99104', );

  // Interoperability: Pre-seeded failed FHIR inbox message ready for review & retry + durable outbox event
  const failedBundle = {
    resourceType: 'Bundle',
    id: 'msg-lis-failed-009',
    type: 'message',
    meta: { profile: ['https://fhir.hl7.org.uk/StructureDefinition/UKCore-Bundle'] },
    entry: [
      {
        resource: {
          resourceType: 'DiagnosticReport',
          id: 'LIS-88401-F',
          status: 'final',
          code: { text: 'NT-proBNP Assay' },
          subject: { reference: `Patient/${PATIENT_IDS.arthur}` },
          effectiveDateTime: '2026-11-24T08:25:00Z',
          conclusion: 'NT-proBNP 1,420 pg/mL (Source ref < 400 pg/mL)',
          _structuredValues: [{ analyte: 'NT-proBNP', value: 1420, unit: 'pg/mL', refLow: 0, refHigh: 400, flag: 'High (source LIS)' }],
        },
      },
    ],
  };
  const failedPayloadStr = JSON.stringify(failedBundle);
  db.prepare(
    `INSERT INTO integration_inbox_messages (id, source_system, external_message_id, message_format, mapping_version, payload_sha256, raw_payload_json, processing_status, error_detail, retry_count, received_at)
     VALUES (?, 'berkshire_pathology_lis', 'msg-lis-failed-009', 'fhir_r4_uk_core_bundle', 'uk-core-r4-v1.2.0', ?, ?, 'failed_retrying', 'Transient downstream terminology lookup timeout during initial receipt; ready for retry.', 1, ?)`
  ).run('inbox-fail-1', crypto.createHash('sha256').update(failedPayloadStr).digest('hex'), failedPayloadStr, now);

  db.prepare(
    `INSERT INTO integration_outbox_events (id, aggregate_type, aggregate_id, event_type, payload_json, delivery_status, attempts, next_attempt_at, created_at)
     VALUES (?, 'clinical_note', ?, 'clinical_note.signed', ?, 'dispatched', 1, ?, ?)`
  ).run('outbox-1', noteArthurId, JSON.stringify({ noteId: noteArthurId, patientId: PATIENT_IDS.arthur, status: 'amended' }), now, now);

  // Retention Policies (NHS Records Management Code of Practice 2023)
  db.prepare('INSERT INTO retention_policies (id, organisation_id, record_category, retention_years, statutory_basis, active) VALUES (?, ?, ?, ?, ?, 1)').run(
    'ret-1', ORG_ID, 'Adult Acute & Outpatient Health Record', 8, 'NHS Records Management Code of Practice (8 years post last clinical contact)'
  );
  db.prepare('INSERT INTO retention_policies (id, organisation_id, record_category, retention_years, statutory_basis, active) VALUES (?, ?, ?, ?, ?, 1)').run(
    'ret-2', ORG_ID, 'Access & Security Audit Trail', 8, 'DSPT & NHS Records Management Code of Practice'
  );
  db.prepare('INSERT INTO retention_policies (id, organisation_id, record_category, retention_years, statutory_basis, active) VALUES (?, ?, ?, ?, ?, 1)').run(
    'ret-3', ORG_ID, 'Paediatric / Maternity Records', 25, 'NHS Records Management Code of Practice (until 25th/26th birthday or 25 years)'
  );

  // Initial Audit Chain Events
  appendAuditEvent(db, {
    actorUserId: USER_IDS.consultant,
    actorRole: 'consultant_physician',
    organisationId: ORG_ID,
    action: 'note.sign',
    resourceType: 'clinical_note',
    resourceId: noteArthurId,
    patientId: PATIENT_IDS.arthur,
    outcome: 'success',
    minimisedMetadata: { version: 1, idempotencyKey: 'seed-sign-arthur-1' },
  });
  appendAuditEvent(db, {
    actorUserId: USER_IDS.caldicott,
    actorRole: 'caldicott_guardian',
    organisationId: ORG_ID,
    action: 'restriction.apply',
    resourceType: 'patient',
    resourceId: PATIENT_IDS.clara,
    patientId: PATIENT_IDS.clara,
    outcome: 'success',
    reason: 'Safeguarding restriction configured',
    minimisedMetadata: { policyCode: 'safeguarding' },
  });
}
