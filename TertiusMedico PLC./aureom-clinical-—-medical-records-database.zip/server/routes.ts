import crypto from 'node:crypto';
import type { Express, Request, Response } from 'express';
import type { DatabaseSync } from 'node:sqlite';
import { canAccessResourceSensitivity, evaluatePatientAccess, hasPermission } from './accessControl.ts';
import { generateSourceLinkedSummary } from './aiAdapter.ts';
import { appendAuditEvent, verifyAuditHashChain } from './audit.ts';
import { type AuthedRequest, issueUserSession, requireAuth, revokeSession, verifyOtpCode } from './auth.ts';
import { runBackupAndIsolatedRestoreDrill } from './backup.ts';
import { withTransaction } from './db.ts';
import { ingestFhirBundle, type FhirBundleInput } from './fhir.ts';
import { formatNhsNumber, validateNhsNumber } from './nhsNumber.ts';
import { registerClinicalRoutes } from './routesClinical.ts';

export function registerRoutes(app: Express, db: DatabaseSync): void {
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', service: 'aureom-clinical', timestamp: new Date().toISOString() });
  });

  // --- Authentication & Identity Adapter ---
  app.get('/api/auth/directory', (_req: Request, res: Response) => {
    const users = db
      .prepare(
        `SELECT u.id, u.username, u.email, u.full_name, u.professional_reg_no, u.role_code,
                r.display_name as role_display_name, u.identity_provider, u.mfa_enrolled, o.name as org_name, o.ods_code
         FROM users u
         JOIN roles r ON r.code = u.role_code
         JOIN organisations o ON o.id = u.organisation_id
         WHERE u.is_active = 1
         ORDER BY u.full_name ASC`
      )
      .all();
    res.json({ users });
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { userId, otpCode } = req.body as { userId?: string; otpCode?: string };
    if (!userId) {
      res.status(400).json({ error: 'userId is required' });
      return;
    }
    if (!otpCode || !verifyOtpCode(otpCode)) {
      res.status(401).json({ error: 'Valid 6-digit MFA verification code is required' });
      return;
    }
    try {
      const session = issueUserSession(db, userId, true, 'cis2_totp_mfa');
      const user = db
        .prepare(
          `SELECT u.id, u.username, u.full_name, u.professional_reg_no, u.role_code, u.organisation_id,
                  r.display_name as role_display_name, r.permissions_json, o.name as org_name, o.ods_code, o.ai_assistant_enabled
           FROM users u
           JOIN roles r ON r.code = u.role_code
           JOIN organisations o ON o.id = u.organisation_id
           WHERE u.id = ?`
        )
        .get(userId) as Record<string, unknown>;
      res.json({
        token: session.token,
        sessionId: session.sessionId,
        expiresAt: session.expiresAt,
        actor: {
          ...user,
          permissions: JSON.parse(String(user.permissions_json)),
          mfaVerified: true,
        },
      });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Login failed' });
    }
  });

  const auth = requireAuth(db);

  app.get('/api/auth/session', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const org = db
      .prepare('SELECT id, ods_code, name, org_type, country, ai_assistant_enabled, config_json FROM organisations WHERE id = ?')
      .get(actor.organisationId) as Record<string, unknown>;
    const activeGrants = db
      .prepare('SELECT id, patient_id, reason, expires_at FROM emergency_access_grants WHERE user_id = ? AND expires_at > ?')
      .all(actor.userId, new Date().toISOString());
    res.json({ actor, organisation: org, activeBreakGlassGrants: activeGrants });
  });

  app.post('/api/auth/logout', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    revokeSession(db, actor.sessionId, actor, 'User signed out');
    res.json({ status: 'revoked' });
  });

  app.post('/api/auth/sessions/:id/revoke', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'audit.read_all') && req.params.id !== actor.sessionId) {
      res.status(403).json({ error: 'Only Caldicott Guardian/IG Lead can revoke another user session' });
      return;
    }
    revokeSession(db, req.params.id, actor, (req.body?.reason as string) || 'Administrative session revocation');
    res.json({ status: 'revoked', sessionId: req.params.id });
  });

  // --- Home Workspace Overview ---
  app.get('/api/workspace/home', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patients = db
      .prepare(
        `SELECT p.id, p.internal_mrn, p.birth_date, p.administrative_gender, p.allergy_assessment_status,
                p.sensitivity_level, p.record_status,
                n.prefix, n.given_names, n.family_name,
                pi.identifier_value as nhs_number, pi.verification_status as nhs_verification
         FROM patients p
         JOIN patient_names n ON n.patient_id = p.id AND n.effective_to IS NULL AND n.name_use = 'official'
         LEFT JOIN patient_identifiers pi ON pi.patient_id = p.id AND pi.identifier_type = 'nhs_number' AND pi.effective_to IS NULL
         WHERE p.organisation_id = ? AND p.record_status = 'active'
         ORDER BY p.updated_at DESC`
      )
      .all(actor.organisationId) as Array<Record<string, unknown>>;

    const accessiblePatients = patients.map((pt) => {
      const dec = evaluatePatientAccess(db, actor, String(pt.id), { logDenial: false });
      return {
        ...pt,
        nhs_formatted: pt.nhs_number ? formatNhsNumber(String(pt.nhs_number)) : null,
        accessAllowed: dec.allowed,
        viaBreakGlass: dec.viaBreakGlass,
        restrictionReason: dec.allowed ? null : dec.reason,
      };
    });

    const recentEncounters = (
      db
        .prepare(
          `SELECT e.id, e.patient_id, e.encounter_class, e.status, e.reason_text, e.started_at,
                  l.name as location_name, u.full_name as attending_name,
                  pn.given_names || ' ' || pn.family_name as patient_name, p.internal_mrn
           FROM encounters e
           JOIN patients p ON p.id = e.patient_id
           JOIN locations l ON l.id = e.location_id
           JOIN users u ON u.id = e.attending_user_id
           JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
           WHERE e.organisation_id = ? AND p.record_status = 'active'
           ORDER BY e.started_at DESC LIMIT 12`
        )
        .all(actor.organisationId) as Array<Record<string, unknown>>
    ).filter((e) => evaluatePatientAccess(db, actor, String(e.patient_id), { logDenial: false }).allowed);

    const draftNotes = (
      db
        .prepare(
          `SELECT cn.id, cn.patient_id, cn.title, cn.note_type, cn.status, cn.current_version, cn.recorded_at, cn.sensitivity_level,
                  pn.given_names || ' ' || pn.family_name as patient_name, p.internal_mrn
           FROM clinical_notes cn
           JOIN patients p ON p.id = cn.patient_id
           JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
           WHERE p.organisation_id = ? AND cn.status = 'draft'
           ORDER BY cn.recorded_at DESC`
        )
        .all(actor.organisationId) as Array<Record<string, unknown>>
    ).filter((n) => canAccessResourceSensitivity(db, actor, String(n.patient_id), String(n.sensitivity_level)));

    const resultsForReview = (
      db
        .prepare(
          `SELECT r.id, r.patient_id, r.report_title, r.status, r.review_state, r.effective_time, r.source_system, r.sensitivity_level,
                  pn.given_names || ' ' || pn.family_name as patient_name, p.internal_mrn
           FROM diagnostic_results r
           JOIN patients p ON p.id = r.patient_id
           JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
           WHERE p.organisation_id = ? AND r.review_state IN ('unviewed', 'viewed', 'assigned_for_followup')
           ORDER BY r.recorded_at DESC`
        )
        .all(actor.organisationId) as Array<Record<string, unknown>>
    ).filter((r) => canAccessResourceSensitivity(db, actor, String(r.patient_id), String(r.sensitivity_level)));

    const openTasks = (
      db
        .prepare(
          `SELECT t.id, t.patient_id, t.title, t.priority, t.status, t.due_at, u.full_name as assignee_name,
                  pn.given_names || ' ' || pn.family_name as patient_name, p.internal_mrn
           FROM follow_up_tasks t
           JOIN patients p ON p.id = t.patient_id
           JOIN users u ON u.id = t.assigned_to
           JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
           WHERE p.organisation_id = ? AND t.status IN ('open', 'in_progress')
           ORDER BY t.due_at ASC`
        )
        .all(actor.organisationId) as Array<Record<string, unknown>>
    ).filter((t) => evaluatePatientAccess(db, actor, String(t.patient_id), { logDenial: false }).allowed);

    const pendingDuplicates = db
      .prepare(`SELECT COUNT(*) as c FROM patient_duplicate_candidates WHERE review_status = 'pending_review'`)
      .get() as { c: number };

    res.json({
      patients: accessiblePatients,
      recentEncounters,
      draftNotes,
      resultsForReview,
      openTasks,
      pendingDuplicatesCount: pendingDuplicates.c,
    });
  });

  // --- Patients: Search, Register, Demographics History, Break-Glass, Duplicate Merge/Unmerge ---
  app.get('/api/patients', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const q = String(req.query.q || '').trim().toLowerCase();
    const includeMerged = req.query.includeMerged === 'true';

    const rows = db
      .prepare(
        `SELECT p.id, p.internal_mrn, p.birth_date, p.administrative_gender, p.allergy_assessment_status,
                p.sensitivity_level, p.record_status, p.merged_into_patient_id, p.updated_at,
                n.prefix, n.given_names, n.family_name,
                pi.identifier_value as nhs_number, pi.verification_status as nhs_verification,
                pa.postcode, pa.city
         FROM patients p
         JOIN patient_names n ON n.patient_id = p.id AND n.effective_to IS NULL AND n.name_use = 'official'
         LEFT JOIN patient_identifiers pi ON pi.patient_id = p.id AND pi.identifier_type = 'nhs_number' AND pi.effective_to IS NULL
         LEFT JOIN patient_addresses pa ON pa.patient_id = p.id AND pa.effective_to IS NULL
         WHERE p.organisation_id = ? ${includeMerged ? '' : "AND p.record_status = 'active'"}
         ORDER BY n.family_name ASC, n.given_names ASC`
      )
      .all(actor.organisationId) as Array<Record<string, unknown>>;

    const filtered = rows
      .map((pt): Record<string, unknown> => {
        const dec = evaluatePatientAccess(db, actor, String(pt.id), { logDenial: false });
        return {
          ...pt,
          nhs_formatted: pt.nhs_number ? formatNhsNumber(String(pt.nhs_number)) : null,
          accessAllowed: dec.allowed,
          viaBreakGlass: dec.viaBreakGlass,
          restrictionPolicy: dec.restrictionPolicy ?? null,
        };
      })
      .filter((pt) => {
        if (!q) return true;
        if (!pt.accessAllowed) {
          return String(pt.internal_mrn).toLowerCase().includes(q);
        }
        return (
          String(pt.given_names).toLowerCase().includes(q) ||
          String(pt.family_name).toLowerCase().includes(q) ||
          String(pt.internal_mrn).toLowerCase().includes(q) ||
          String(pt.nhs_number || '').includes(q.replace(/\s+/g, '')) ||
          String(pt.birth_date).includes(q)
        );
      });

    res.json({ patients: filtered });
  });

  app.post('/api/patients', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'patient.write')) {
      res.status(403).json({ error: 'Role lacks permission to register patients' });
      return;
    }
    const {
      givenNames,
      familyName,
      prefix,
      birthDate,
      administrativeGender,
      nhsNumber,
      nhsIssuingAuthority,
      addressLine1,
      city,
      postcode,
      allergyAssessmentStatus,
      gpName,
      sensitivityLevel,
    } = req.body as Record<string, string | undefined>;

    if (!givenNames?.trim() || !familyName?.trim() || !birthDate || !administrativeGender) {
      res.status(400).json({ error: 'givenNames, familyName, birthDate, and administrativeGender are required' });
      return;
    }

    let normalizedNhs: string | null = null;
    if (nhsNumber && nhsNumber.trim()) {
      const check = validateNhsNumber(nhsNumber);
      if (!check.valid) {
        res.status(400).json({ error: `Invalid NHS Number: ${check.reason}` });
        return;
      }
      normalizedNhs = check.normalized;
      const duplicateNhs = db
        .prepare("SELECT patient_id FROM patient_identifiers WHERE identifier_type = 'nhs_number' AND identifier_value = ? AND effective_to IS NULL")
        .get(normalizedNhs) as { patient_id: string } | undefined;
      if (duplicateNhs) {
        res.status(409).json({
          error: 'An active patient record with this NHS Number already exists. Use duplicate-candidate review rather than creating a duplicate.',
          existingPatientId: duplicateNhs.patient_id,
        });
        return;
      }
    }

    const patientId = crypto.randomUUID();
    const internalMrn = `AUR-${Math.floor(100500 + Math.random() * 899000)}`;
    const now = new Date().toISOString();
    const validAllergyStatus = ['assessed_no_known_allergies', 'not_assessed', 'unknown', 'unavailable'].includes(allergyAssessmentStatus || '')
      ? allergyAssessmentStatus!
      : 'not_assessed';

    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO patients (
          id, internal_mrn, organisation_id, birth_date, administrative_gender,
          allergy_assessment_status, allergy_assessed_at, allergy_assessed_by,
          record_status, sensitivity_level, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?)`
      ).run(
        patientId,
        internalMrn,
        actor.organisationId,
        birthDate,
        administrativeGender,
        validAllergyStatus,
        validAllergyStatus === 'assessed_no_known_allergies' ? now : null,
        validAllergyStatus === 'assessed_no_known_allergies' ? actor.userId : null,
        sensitivityLevel === 'restricted' ? 'restricted' : 'normal',
        now,
        now
      );

      if (normalizedNhs) {
        db.prepare(
          `INSERT INTO patient_identifiers (id, patient_id, origin_patient_id, identifier_type, identifier_value, issuing_authority, verification_status, effective_from, is_primary, created_at)
           VALUES (?, ?, ?, 'nhs_number', ?, ?, 'verified_mod11', ?, 1, ?)`
        ).run(crypto.randomUUID(), patientId, patientId, normalizedNhs, nhsIssuingAuthority || 'Local Registration', now.slice(0, 10), now);
      }
      db.prepare(
        `INSERT INTO patient_identifiers (id, patient_id, origin_patient_id, identifier_type, identifier_value, issuing_authority, verification_status, effective_from, is_primary, created_at)
         VALUES (?, ?, ?, 'local_mrn', ?, 'Y99001', 'verified_mod11', ?, ?, ?)`
      ).run(crypto.randomUUID(), patientId, patientId, internalMrn, now.slice(0, 10), normalizedNhs ? 0 : 1, now);

      db.prepare(
        `INSERT INTO patient_names (id, patient_id, name_use, prefix, given_names, family_name, effective_from, recorded_by)
         VALUES (?, ?, 'official', ?, ?, ?, ?, ?)`
      ).run(crypto.randomUUID(), patientId, prefix || null, givenNames.trim(), familyName.trim(), now, actor.userId);

      if (addressLine1?.trim() && postcode?.trim()) {
        db.prepare(
          `INSERT INTO patient_addresses (id, patient_id, address_use, line1, city, postcode, effective_from, recorded_by)
           VALUES (?, ?, 'home', ?, ?, ?, ?, ?)`
        ).run(crypto.randomUUID(), patientId, addressLine1.trim(), city?.trim() || 'Reading', postcode.trim().toUpperCase(), now, actor.userId);
      }

      if (gpName?.trim()) {
        db.prepare(
          `INSERT INTO patient_contacts (id, patient_id, relationship_type, full_name, created_at)
           VALUES (?, ?, 'registered_gp', ?, ?)`
        ).run(crypto.randomUUID(), patientId, gpName.trim(), now);
      }

      // Check for potential duplicate by DOB + family_name without auto-merging
      const potentialMatches = db
        .prepare(
          `SELECT p.id FROM patients p
           JOIN patient_names n ON n.patient_id = p.id AND n.effective_to IS NULL
           WHERE p.organisation_id = ? AND p.id <> ? AND p.record_status = 'active'
             AND p.birth_date = ? AND LOWER(n.family_name) = LOWER(?)`
        )
        .all(actor.organisationId, patientId, birthDate, familyName.trim()) as Array<{ id: string }>;

      for (const m of potentialMatches) {
        db.prepare(
          `INSERT INTO patient_duplicate_candidates (id, patient_a_id, patient_b_id, match_score, match_rationale, review_status, created_at)
           VALUES (?, ?, ?, 0.85, ?, 'pending_review', ?)`
        ).run(crypto.randomUUID(), m.id, patientId, `Matching DOB (${birthDate}) and family name (${familyName.trim()}) detected at registration. Manual review required.`, now);
      }

      db.prepare(
        `INSERT INTO provenance_records (id, target_table, target_id, activity, agent_user_id, agent_system, recorded_at, detail_json)
         VALUES (?, 'patients', ?, 'create', ?, 'aureom_ehr', ?, ?)`
      ).run(crypto.randomUUID(), patientId, actor.userId, now, JSON.stringify({ internalMrn, hasNhsNumber: Boolean(normalizedNhs) }));

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'patient.register',
        resourceType: 'patient',
        resourceId: patientId,
        patientId,
        outcome: 'success',
        minimisedMetadata: { internalMrn, allergyAssessmentStatus: validAllergyStatus },
      });
    });

    res.status(201).json({ id: patientId, internalMrn, nhsNumber: normalizedNhs });
  });

  app.get('/api/patients/:id', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'patient.view' });
    if (!access.allowed) {
      res.status(403).json({
        error: access.reason,
        restricted: true,
        restrictionPolicy: access.restrictionPolicy,
        breakGlassEligible: true,
      });
      return;
    }

    const patient = db.prepare('SELECT * FROM patients WHERE id = ?').get(patientId) as Record<string, unknown>;
    const identifiers = db.prepare('SELECT * FROM patient_identifiers WHERE patient_id = ? ORDER BY is_primary DESC, effective_from DESC').all(patientId);
    const names = db.prepare('SELECT * FROM patient_names WHERE patient_id = ? ORDER BY effective_from DESC').all(patientId);
    const addresses = db.prepare('SELECT * FROM patient_addresses WHERE patient_id = ? ORDER BY effective_from DESC').all(patientId);
    const contacts = db.prepare('SELECT * FROM patient_contacts WHERE patient_id = ? ORDER BY created_at DESC').all(patientId);
    const encounters = db
      .prepare(
        `SELECT e.*, l.name as location_name, u.full_name as attending_name
         FROM encounters e
         JOIN locations l ON l.id = e.location_id
         JOIN users u ON u.id = e.attending_user_id
         WHERE e.patient_id = ? ORDER BY e.started_at DESC`
      )
      .all(patientId);
    const consents = db.prepare('SELECT * FROM consent_directives WHERE patient_id = ? ORDER BY effective_from DESC').all(patientId);
    const restrictions = db.prepare('SELECT * FROM access_restrictions WHERE patient_id = ? AND active = 1').all(patientId);
    const allergyCount = (db.prepare("SELECT COUNT(*) as c FROM allergies WHERE patient_id = ? AND verification_status <> 'entered_in_error'").get(patientId) as { c: number }).c;

    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'patient.view',
      resourceType: 'patient',
      resourceId: patientId,
      patientId,
      outcome: 'success',
      minimisedMetadata: { viaBreakGlass: access.viaBreakGlass },
    });

    res.json({
      patient,
      identifiers,
      names,
      addresses,
      contacts,
      encounters,
      consents,
      restrictions,
      allergyCount,
      accessContext: access,
    });
  });

  app.patch('/api/patients/:id/demographics', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    if (!hasPermission(actor, 'patient.write')) {
      res.status(403).json({ error: 'Role lacks demographic update permission' });
      return;
    }
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'patient.update_demographics' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }

    const { givenNames, familyName, prefix, addressLine1, city, postcode, reason } = req.body as Record<string, string | undefined>;
    const now = new Date().toISOString();

    withTransaction(db, () => {
      if (givenNames?.trim() && familyName?.trim()) {
        db.prepare("UPDATE patient_names SET effective_to = ? WHERE patient_id = ? AND name_use = 'official' AND effective_to IS NULL").run(now, patientId);
        db.prepare(
          `INSERT INTO patient_names (id, patient_id, name_use, prefix, given_names, family_name, effective_from, recorded_by)
           VALUES (?, ?, 'official', ?, ?, ?, ?, ?)`
        ).run(crypto.randomUUID(), patientId, prefix || null, givenNames.trim(), familyName.trim(), now, actor.userId);
      }

      if (addressLine1?.trim() && postcode?.trim()) {
        db.prepare("UPDATE patient_addresses SET effective_to = ? WHERE patient_id = ? AND address_use = 'home' AND effective_to IS NULL").run(now, patientId);
        db.prepare(
          `INSERT INTO patient_addresses (id, patient_id, address_use, line1, city, postcode, effective_from, recorded_by)
           VALUES (?, ?, 'home', ?, ?, ?, ?, ?)`
        ).run(crypto.randomUUID(), patientId, addressLine1.trim(), city?.trim() || 'Reading', postcode.trim().toUpperCase(), now, actor.userId);
      }

      db.prepare('UPDATE patients SET updated_at = ? WHERE id = ?').run(now, patientId);
      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'patient.demographics_update',
        resourceType: 'patient',
        resourceId: patientId,
        patientId,
        outcome: 'success',
        reason: reason || 'Demographic history updated',
      });
    });

    res.json({ status: 'updated', updatedAt: now });
  });

  app.post('/api/patients/:id/break-glass', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    const { reason } = req.body as { reason?: string };
    if (!reason || reason.trim().length < 10) {
      res.status(400).json({ error: 'A specific clinical emergency reason (minimum 10 characters) is required for Break-Glass access' });
      return;
    }

    const patient = db.prepare('SELECT id, organisation_id FROM patients WHERE id = ?').get(patientId) as { id: string; organisation_id: string } | undefined;
    if (!patient || patient.organisation_id !== actor.organisationId) {
      res.status(404).json({ error: 'Patient not found within organisation' });
      return;
    }

    const grantId = crypto.randomUUID();
    const grantedAt = new Date();
    const expiresAt = new Date(grantedAt.getTime() + 2 * 60 * 60 * 1000).toISOString();

    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO emergency_access_grants (id, user_id, patient_id, reason, granted_at, expires_at, ig_review_status)
         VALUES (?, ?, ?, ?, ?, ?, 'pending_review')`
      ).run(grantId, actor.userId, patientId, reason.trim(), grantedAt.toISOString(), expiresAt);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'break_glass.grant',
        resourceType: 'emergency_access_grant',
        resourceId: grantId,
        patientId,
        outcome: 'success',
        reason: reason.trim(),
        minimisedMetadata: { expiresAt, requiresIgReview: true },
      });
    });

    res.status(201).json({ grantId, expiresAt, igReviewStatus: 'pending_review' });
  });

  // --- Duplicate Candidate Review, Merge & Controlled Unmerge ---
  app.get('/api/patients-governance/duplicates', auth, (req: AuthedRequest, res: Response) => {
    const candidates = db
      .prepare(
        `SELECT dc.*,
                pa.internal_mrn as mrn_a, pa.birth_date as dob_a, pa.record_status as status_a,
                na.given_names || ' ' || na.family_name as name_a,
                pia.identifier_value as nhs_a, pia.verification_status as nhs_ver_a,
                aa.line1 || ', ' || aa.postcode as addr_a,
                pb.internal_mrn as mrn_b, pb.birth_date as dob_b, pb.record_status as status_b,
                nb.given_names || ' ' || nb.family_name as name_b,
                pib.identifier_value as ident_b, pib.identifier_type as ident_type_b, pib.verification_status as ident_ver_b,
                ab.line1 || ', ' || ab.postcode as addr_b
         FROM patient_duplicate_candidates dc
         JOIN patients pa ON pa.id = dc.patient_a_id
         JOIN patient_names na ON na.patient_id = pa.id AND na.effective_to IS NULL
         LEFT JOIN patient_identifiers pia ON pia.patient_id = pa.id AND pia.is_primary = 1 AND pia.effective_to IS NULL
         LEFT JOIN patient_addresses aa ON aa.patient_id = pa.id AND aa.effective_to IS NULL
         JOIN patients pb ON pb.id = dc.patient_b_id
         JOIN patient_names nb ON nb.patient_id = pb.id AND nb.effective_to IS NULL
         LEFT JOIN patient_identifiers pib ON pib.patient_id = pb.id AND pib.is_primary = 1 AND pib.effective_to IS NULL
         LEFT JOIN patient_addresses ab ON ab.patient_id = pb.id AND ab.effective_to IS NULL
         ORDER BY dc.created_at DESC`
      )
      .all();

    const mergeEvents = db
      .prepare(
        `SELECT me.*, u.full_name as performed_by_name
         FROM patient_merge_events me
         JOIN users u ON u.id = me.performed_by
         ORDER BY me.performed_at DESC`
      )
      .all();

    res.json({ candidates, mergeEvents });
  });

  app.post('/api/patients-governance/merge', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'patient.merge')) {
      res.status(403).json({ error: 'Role lacks authority to merge patient identities' });
      return;
    }
    const { sourcePatientId, targetPatientId, candidateId, reason } = req.body as {
      sourcePatientId?: string;
      targetPatientId?: string;
      candidateId?: string;
      reason?: string;
    };
    if (!sourcePatientId || !targetPatientId || sourcePatientId === targetPatientId || !reason?.trim()) {
      res.status(400).json({ error: 'Distinct sourcePatientId, targetPatientId, and explicit reason are required' });
      return;
    }

    const mergeEventId = crypto.randomUUID();
    const now = new Date().toISOString();

    withTransaction(db, () => {
      const src = db.prepare('SELECT id, record_status FROM patients WHERE id = ?').get(sourcePatientId) as { id: string; record_status: string } | undefined;
      const tgt = db.prepare('SELECT id, record_status FROM patients WHERE id = ?').get(targetPatientId) as { id: string; record_status: string } | undefined;
      if (!src || !tgt || src.record_status !== 'active' || tgt.record_status !== 'active') {
        throw new Error('Both source and target patients must be active records');
      }

      const tablesToMove = [
        'patient_identifiers',
        'encounters',
        'clinical_notes',
        'problems',
        'allergies',
        'medication_statements',
        'prescriptions',
        'observations',
        'diagnostic_results',
        'follow_up_tasks',
        'documents',
      ];
      const movedSnapshot: Record<string, string[]> = {};
      for (const tbl of tablesToMove) {
        const rows = db.prepare(`SELECT id FROM ${tbl} WHERE patient_id = ?`).all(sourcePatientId) as Array<{ id: string }>;
        movedSnapshot[tbl] = rows.map((r) => r.id);
        db.prepare(`UPDATE ${tbl} SET patient_id = ? WHERE patient_id = ?`).run(targetPatientId, sourcePatientId);
      }

      db.prepare("UPDATE patients SET record_status = 'merged', merged_into_patient_id = ?, updated_at = ? WHERE id = ?").run(targetPatientId, now, sourcePatientId);

      if (candidateId) {
        db.prepare("UPDATE patient_duplicate_candidates SET review_status = 'merged', reviewed_by = ?, reviewed_at = ? WHERE id = ?").run(actor.userId, now, candidateId);
      }

      db.prepare(
        `INSERT INTO patient_merge_events (id, source_patient_id, target_patient_id, action, reason, moved_records_snapshot, performed_by, performed_at)
         VALUES (?, ?, ?, 'merge', ?, ?, ?, ?)`
      ).run(mergeEventId, sourcePatientId, targetPatientId, reason.trim(), JSON.stringify(movedSnapshot), actor.userId, now);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'patient.merge',
        resourceType: 'patient_merge_event',
        resourceId: mergeEventId,
        patientId: targetPatientId,
        outcome: 'success',
        reason: reason.trim(),
        minimisedMetadata: { sourcePatientId, targetPatientId },
      });
    });

    res.json({ mergeEventId, status: 'merged' });
  });

  app.post('/api/patients-governance/unmerge/:mergeEventId', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'patient.merge')) {
      res.status(403).json({ error: 'Role lacks authority to reverse a patient merge' });
      return;
    }
    const { reason } = req.body as { reason?: string };
    if (!reason?.trim()) {
      res.status(400).json({ error: 'Explicit clinical/IG reason is required to unmerge a patient record' });
      return;
    }

    const orig = db.prepare("SELECT * FROM patient_merge_events WHERE id = ? AND action = 'merge' AND reversed_by_event_id IS NULL").get(req.params.mergeEventId) as
      | { id: string; source_patient_id: string; target_patient_id: string; moved_records_snapshot: string }
      | undefined;

    if (!orig) {
      res.status(404).json({ error: 'Active merge event not found or already reversed' });
      return;
    }

    const unmergeId = crypto.randomUUID();
    const now = new Date().toISOString();
    const snapshot = JSON.parse(orig.moved_records_snapshot) as Record<string, string[]>;

    withTransaction(db, () => {
      for (const [tbl, ids] of Object.entries(snapshot)) {
        const stmt = db.prepare(`UPDATE ${tbl} SET patient_id = ? WHERE id = ?`);
        for (const recId of ids) {
          stmt.run(orig.source_patient_id, recId);
        }
      }

      db.prepare("UPDATE patients SET record_status = 'active', merged_into_patient_id = NULL, updated_at = ? WHERE id = ?").run(now, orig.source_patient_id);
      db.prepare(
        `INSERT INTO patient_merge_events (id, source_patient_id, target_patient_id, action, reason, moved_records_snapshot, performed_by, performed_at)
         VALUES (?, ?, ?, 'unmerge', ?, ?, ?, ?)`
      ).run(unmergeId, orig.source_patient_id, orig.target_patient_id, reason.trim(), orig.moved_records_snapshot, actor.userId, now);

      db.prepare('UPDATE patient_merge_events SET reversed_by_event_id = ? WHERE id = ?').run(unmergeId, orig.id);
      db.prepare(
        `UPDATE patient_duplicate_candidates SET review_status = 'unmerged', reviewed_by = ?, reviewed_at = ?
         WHERE (patient_a_id = ? AND patient_b_id = ?) OR (patient_a_id = ? AND patient_b_id = ?)`
      ).run(actor.userId, now, orig.source_patient_id, orig.target_patient_id, orig.target_patient_id, orig.source_patient_id);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'patient.unmerge',
        resourceType: 'patient_merge_event',
        resourceId: unmergeId,
        patientId: orig.source_patient_id,
        outcome: 'success',
        reason: reason.trim(),
        minimisedMetadata: { reversedMergeEventId: orig.id, targetPatientId: orig.target_patient_id },
      });
    });

    res.json({ unmergeEventId: unmergeId, status: 'unmerged', restoredPatientId: orig.source_patient_id });
  });

  // Register encounters, notes, clinical assertions, search, timeline, FHIR, admin & AI routes
  registerClinicalRoutes(app, db, {
    auth,
    ingestFhirBundle,
    generateSourceLinkedSummary,
    runBackupAndIsolatedRestoreDrill,
    verifyAuditHashChain,
  });
}
