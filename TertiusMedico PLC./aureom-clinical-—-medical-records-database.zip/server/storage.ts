import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export function getStorageRoot(): string {
  const configured = process.env.AUREOM_STORAGE_DIR || './data/object_storage';
  const resolved = path.resolve(configured);
  fs.mkdirSync(resolved, { recursive: true });
  return resolved;
}

export function resolveProtectedObjectPath(objectKey: string): string {
  const root = getStorageRoot();
  const normalizedKey = objectKey.replace(/^\/+/, '');
  if (!normalizedKey || normalizedKey.includes('..')) {
    throw new Error('Invalid object storage key');
  }
  const candidate = path.resolve(root, normalizedKey);
  if (!candidate.startsWith(root + path.sep)) {
    throw new Error('Object storage path traversal blocked');
  }
  return candidate;
}

export function storePatientObject(
  patientId: string,
  fileName: string,
  content: Buffer
): { objectKey: string; sha256: string; byteSize: number } {
  const safeBase = fileName.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80) || 'document.txt';
  const objectKey = path.join('patients', patientId, `${crypto.randomUUID()}_${safeBase}`);
  const target = resolveProtectedObjectPath(objectKey);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, content);
  const sha256 = crypto.createHash('sha256').update(content).digest('hex');
  return { objectKey, sha256, byteSize: content.byteLength };
}

export function readProtectedPatientObject(
  objectKey: string,
  expectedSha256?: string
): { content: Buffer; checksumValid: boolean } {
  const target = resolveProtectedObjectPath(objectKey);
  if (!fs.existsSync(target)) {
    throw new Error('Stored document object not found');
  }
  const content = fs.readFileSync(target);
  const actualSha256 = crypto.createHash('sha256').update(content).digest('hex');
  return {
    content,
    checksumValid: expectedSha256 ? actualSha256 === expectedSha256 : true,
  };
}
