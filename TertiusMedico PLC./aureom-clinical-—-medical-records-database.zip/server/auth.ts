import crypto from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';
import type { DatabaseSync } from 'node:sqlite';
import { appendAuditEvent } from './audit.ts';

export interface AuthenticatedActor {
  sessionId: string;
  userId: string;
  username: string;
  fullName: string;
  professionalRegNo: string | null;
  roleCode: string;
  roleDisplayName: string;
  organisationId: string;
  permissions: string[];
  mfaVerified: boolean;
  expiresAt: string;
}

function hashToken(rawToken: string): string {
  const secret = process.env.AUREOM_SESSION_SECRET || 'aureom-ephemeral-dev-salt';
  return crypto.createHmac('sha256', secret).update(rawToken).digest('hex');
}

export function issueUserSession(
  db: DatabaseSync,
  userId: string,
  mfaVerified: boolean,
  mfaMethod: string
): { token: string; sessionId: string; expiresAt: string } {
  const user = db
    .prepare('SELECT id, organisation_id, role_code, is_active FROM users WHERE id = ?')
    .get(userId) as { id: string; organisation_id: string; role_code: string; is_active: number } | undefined;

  if (!user || user.is_active !== 1) {
    throw new Error('User account is inactive or not found');
  }

  const rawToken = `aur_${crypto.randomBytes(32).toString('base64url')}`;
  const tokenHash = hashToken(rawToken);
  const sessionId = crypto.randomUUID();
  const issuedAt = new Date();
  const expiresAt = new Date(issuedAt.getTime() + 8 * 60 * 60 * 1000).toISOString();

  db.prepare(
    `INSERT INTO user_sessions (id, user_id, token_hash, mfa_verified, mfa_method, care_context_org_id, issued_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(sessionId, user.id, tokenHash, mfaVerified ? 1 : 0, mfaMethod, user.organisation_id, issuedAt.toISOString(), expiresAt);

  appendAuditEvent(db, {
    actorUserId: user.id,
    actorRole: user.role_code,
    organisationId: user.organisation_id,
    action: 'session.login',
    resourceType: 'user_session',
    resourceId: sessionId,
    outcome: 'success',
    minimisedMetadata: { mfaVerified, mfaMethod },
  });

  return { token: rawToken, sessionId, expiresAt };
}

export function revokeSession(db: DatabaseSync, sessionId: string, actor: AuthenticatedActor, reason: string): void {
  const now = new Date().toISOString();
  db.prepare('UPDATE user_sessions SET revoked_at = ?, revocation_reason = ? WHERE id = ?').run(now, reason, sessionId);
  appendAuditEvent(db, {
    actorUserId: actor.userId,
    actorRole: actor.roleCode,
    organisationId: actor.organisationId,
    action: 'session.revoke',
    resourceType: 'user_session',
    resourceId: sessionId,
    outcome: 'success',
    reason,
  });
}

export function resolveSessionFromRequest(db: DatabaseSync, req: Request): AuthenticatedActor | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const rawToken = authHeader.slice(7).trim();
  if (!rawToken) return null;

  const tokenHash = hashToken(rawToken);
  const row = db
    .prepare(
      `SELECT s.id as session_id, s.mfa_verified, s.expires_at, s.revoked_at,
              u.id as user_id, u.username, u.full_name, u.professional_reg_no,
              u.role_code, u.organisation_id, u.is_active,
              r.display_name as role_display_name, r.permissions_json
       FROM user_sessions s
       JOIN users u ON u.id = s.user_id
       JOIN roles r ON r.code = u.role_code
       WHERE s.token_hash = ?`
    )
    .get(tokenHash) as
    | {
        session_id: string;
        mfa_verified: number;
        expires_at: string;
        revoked_at: string | null;
        user_id: string;
        username: string;
        full_name: string;
        professional_reg_no: string | null;
        role_code: string;
        organisation_id: string;
        is_active: number;
        role_display_name: string;
        permissions_json: string;
      }
    | undefined;

  if (!row || row.revoked_at !== null || row.is_active !== 1) {
    return null;
  }
  if (new Date(row.expires_at).getTime() <= Date.now()) {
    return null;
  }

  return {
    sessionId: row.session_id,
    userId: row.user_id,
    username: row.username,
    fullName: row.full_name,
    professionalRegNo: row.professional_reg_no,
    roleCode: row.role_code,
    roleDisplayName: row.role_display_name,
    organisationId: row.organisation_id,
    permissions: JSON.parse(row.permissions_json) as string[],
    mfaVerified: row.mfa_verified === 1,
    expiresAt: row.expires_at,
  };
}

export interface AuthedRequest extends Request {
  actor?: AuthenticatedActor;
}

export function requireAuth(db: DatabaseSync) {
  return (req: AuthedRequest, res: Response, next: NextFunction): void => {
    const actor = resolveSessionFromRequest(db, req);
    if (!actor) {
      res.status(401).json({ error: 'Authentication required. Session missing, expired, or revoked.' });
      return;
    }
    req.actor = actor;
    next();
  };
}

export function verifyOtpCode(code: string): boolean {
  // Development CIS2 / TOTP adapter accepts standard 6-digit codes (e.g. 123456 or 482910)
  return /^\d{6}$/.test(code.trim());
}
