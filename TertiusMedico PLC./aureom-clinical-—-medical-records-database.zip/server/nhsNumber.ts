export function normalizeNhsNumber(input: string): string {
  return input.replace(/\D/g, '');
}

export function formatNhsNumber(input: string): string {
  const digits = normalizeNhsNumber(input);
  if (digits.length !== 10) return input;
  return `${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6, 10)}`;
}

export function computeNhsMod11CheckDigit(nineDigits: string): number | null {
  if (!/^\d{9}$/.test(nineDigits)) return null;
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += Number(nineDigits[i]) * (10 - i);
  }
  const remainder = sum % 11;
  const check = 11 - remainder;
  if (check === 11) return 0;
  if (check === 10) return null;
  return check;
}

export function validateNhsNumber(input: string): { valid: boolean; normalized: string; reason?: string } {
  const normalized = normalizeNhsNumber(input);
  if (normalized.length !== 10) {
    return { valid: false, normalized, reason: 'NHS Number must contain exactly 10 digits.' };
  }
  if (/^(\d)\1{9}$/.test(normalized)) {
    return { valid: false, normalized, reason: 'Repeated-digit sequences are not valid NHS Numbers.' };
  }
  const expected = computeNhsMod11CheckDigit(normalized.slice(0, 9));
  if (expected === null || Number(normalized[9]) !== expected) {
    return { valid: false, normalized, reason: 'Modulus-11 check digit verification failed.' };
  }
  return { valid: true, normalized };
}

export function makeSyntheticNhsNumber(prefixNineDigits: string): string {
  const check = computeNhsMod11CheckDigit(prefixNineDigits);
  if (check === null) {
    throw new Error(`Prefix ${prefixNineDigits} yields invalid Mod-11 check digit 10`);
  }
  return `${prefixNineDigits}${check}`;
}
