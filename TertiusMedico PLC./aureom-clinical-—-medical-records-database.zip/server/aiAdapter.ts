import { GoogleGenAI } from '@google/genai';
import type { DatabaseSync } from 'node:sqlite';
import { canAccessResourceSensitivity, evaluatePatientAccess, hasPermission } from './accessControl.ts';
import { appendAuditEvent } from './audit.ts';
import type { AuthenticatedActor } from './auth.ts';

export interface AiDraftResult {
  draftSummary: string;
  sourceCitations: Array<{ recordId: string; recordType: string; label: string }>;
  conflictsDetected: string[];
  modelUsed: string;
  requiresClinicianReview: true;
}

export async function generateSourceLinkedSummary(
  db: DatabaseSync,
  actor: AuthenticatedActor,
  patientId: string,
  clinicianPrompt: string
): Promise<AiDraftResult> {
  const org = db
    .prepare('SELECT id, ai_assistant_enabled FROM organisations WHERE id = ?')
    .get(actor.organisationId) as { id: string; ai_assistant_enabled: number } | undefined;

  if (!org || org.ai_assistant_enabled !== 1) {
    throw new Error('Optional AI Clinical Assistant adapter is disabled by organisational policy.');
  }

  if (!hasPermission(actor, 'ai.assist')) {
    throw new Error('Current clinical role is not permitted to invoke the AI draft assistant.');
  }

  const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'ai.summarize' });
  if (!access.allowed) {
    throw new Error(`Access denied: ${access.reason}`);
  }

  const aiConsent = db
    .prepare(
      `SELECT decision FROM consent_directives
       WHERE patient_id = ? AND purpose = 'ai_draft_assistance' AND effective_to IS NULL
       ORDER BY effective_from DESC LIMIT 1`
    )
    .get(patientId) as { decision: string } | undefined;

  if (aiConsent?.decision === 'deny') {
    throw new Error('Patient consent directive denies AI draft assistance for this record.');
  }

  // Gather ONLY records the requesting user is authorised to read
  const patient = db
    .prepare('SELECT internal_mrn, birth_date, administrative_gender, allergy_assessment_status FROM patients WHERE id = ?')
    .get(patientId) as { internal_mrn: string; birth_date: string; administrative_gender: string; allergy_assessment_status: string };

  const problems = (
    db.prepare('SELECT id, snomed_code, display_term, clinical_status, verification_status, sensitivity_level FROM problems WHERE patient_id = ?').all(patientId) as Array<{
      id: string;
      snomed_code: string;
      display_term: string;
      clinical_status: string;
      verification_status: string;
      sensitivity_level: string;
    }>
  ).filter((p) => canAccessResourceSensitivity(db, actor, patientId, p.sensitivity_level));

  const allergies = db
    .prepare('SELECT id, substance_name, reaction_manifestation, severity, verification_status, source_system, conflict_flag FROM allergies WHERE patient_id = ?')
    .all(patientId) as Array<{
    id: string;
    substance_name: string;
    reaction_manifestation: string;
    severity: string;
    verification_status: string;
    source_system: string;
    conflict_flag: number;
  }>;

  const notes = (
    db
      .prepare(
        `SELECT n.id, n.title, n.status, n.event_time, n.sensitivity_level, v.body_text
         FROM clinical_notes n
         JOIN clinical_note_versions v ON v.note_id = n.id AND v.version_number = n.current_version
         WHERE n.patient_id = ? AND n.status <> 'entered_in_error'
         ORDER BY n.event_time DESC LIMIT 8`
      )
      .all(patientId) as Array<{
      id: string;
      title: string;
      status: string;
      event_time: string;
      sensitivity_level: string;
      body_text: string;
    }>
  ).filter((n) => canAccessResourceSensitivity(db, actor, patientId, n.sensitivity_level));

  const results = (
    db
      .prepare(
        `SELECT id, report_title, result_summary, status, effective_time, sensitivity_level
         FROM diagnostic_results WHERE patient_id = ? ORDER BY effective_time DESC LIMIT 8`
      )
      .all(patientId) as Array<{
      id: string;
      report_title: string;
      result_summary: string;
      status: string;
      effective_time: string;
      sensitivity_level: string;
    }>
  ).filter((r) => canAccessResourceSensitivity(db, actor, patientId, r.sensitivity_level));

  const citations: Array<{ recordId: string; recordType: string; label: string }> = [];
  const conflicts: string[] = [];

  for (const a of allergies) {
    citations.push({ recordId: a.id, recordType: 'allergy', label: `${a.substance_name} (${a.verification_status}, ${a.source_system})` });
    if (a.conflict_flag === 1) {
      conflicts.push(`Unresolved allergy discrepancy: ${a.substance_name} from ${a.source_system} (${a.reaction_manifestation})`);
    }
  }
  for (const p of problems) {
    citations.push({ recordId: p.id, recordType: 'problem', label: `${p.display_term} [SNOMED ${p.snomed_code}]` });
  }
  for (const n of notes) {
    citations.push({ recordId: n.id, recordType: 'clinical_note', label: `${n.title} (${n.status})` });
  }
  for (const r of results) {
    citations.push({ recordId: r.id, recordType: 'diagnostic_result', label: `${r.report_title} (${r.status})` });
  }

  const contextPayload = {
    patient: {
      internalMrn: patient.internal_mrn,
      birthDate: patient.birth_date,
      gender: patient.administrative_gender,
      allergyAssessmentStatus: patient.allergy_assessment_status,
    },
    problems,
    allergies,
    recentNotes: notes.map((n) => ({ id: n.id, title: n.title, status: n.status, date: n.event_time, text: n.body_text })),
    diagnosticResults: results.map((r) => ({ id: r.id, title: r.report_title, status: r.status, date: r.effective_time, summary: r.result_summary })),
  };

  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is not configured in server environment; cannot invoke Gemini assistant adapter.');
  }

  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const systemInstruction = `You are a clinical record summarisation assistant embedded in Aureom Clinical.
STRICT SAFETY RULES:
1. Summarise ONLY the authorised structured records and notes supplied in the JSON context.
2. Cite exact record IDs inline in square brackets e.g. [Record: id].
3. Preserve ALL uncertainty, unconfirmed statuses, preliminary/corrected distinctions, and conflicting source entries explicitly—never silently choose one version as fact.
4. Do NOT invent diagnoses, dosing advice, clinical thresholds, or treatment recommendations.
5. Output plain professional UK clinical prose formatted cleanly as a draft for clinician review.`;

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `Clinician request: ${clinicianPrompt}\n\nAuthorised Patient Context JSON:\n${JSON.stringify(contextPayload, null, 2)}`,
    config: {
      systemInstruction,
    },
  });

  const draftSummary = response.text?.trim();
  if (!draftSummary) {
    throw new Error('AI assistant returned an empty response');
  }

  appendAuditEvent(db, {
    actorUserId: actor.userId,
    actorRole: actor.roleCode,
    organisationId: actor.organisationId,
    action: 'ai.draft_summary',
    resourceType: 'patient',
    resourceId: patientId,
    patientId,
    outcome: 'success',
    minimisedMetadata: { model: 'gemini-4-hydrogen', citedCount: citations.length, viaBreakGlass: access.viaBreakGlass },
  });

  return {
    draftSummary,
    sourceCitations: citations,
    conflictsDetected: conflicts,
    modelUsed: 'gemini-4-hydrogen',
    requiresClinicianReview: true,
  };
}
