import crypto from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';

export interface AuditWriteInput {
  actorUserId: string | null;
  actorRole: string;
  organisationId: string | null;
  action: string;
  resourceType: string;
  resourceId?: string | null;
  patientId?: string | null;
  outcome: 'success' | 'denied' | 'conflict' | 'error';
  reason?: string | null;
  minimisedMetadata?: Record<string, unknown>;
  retentionYears?: number;
}

const GENESIS_HASH = '0'.repeat(64);

function computeAuditHash(
  prevHash: string,
  id: string,
  occurredAt: string,
  input: AuditWriteInput,
  metadataJson: string
): string {
  const canonical = JSON.stringify({
    prevHash,
    id,
    occurredAt,
    actorUserId: input.actorUserId,
    actorRole: input.actorRole,
    organisationId: input.organisationId,
    action: input.action,
    resourceType: input.resourceType,
    resourceId: input.resourceId ?? null,
    patientId: input.patientId ?? null,
    outcome: input.outcome,
    reason: input.reason ?? null,
    metadataJson,
  });
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

export function appendAuditEvent(db: DatabaseSync, input: AuditWriteInput): string {
  const id = crypto.randomUUID();
  const occurredAt = new Date().toISOString();
  const retainYears = input.retentionYears ?? 8;
  const retainDate = new Date();
  retainDate.setUTCFullYear(retainDate.getUTCFullYear() + retainYears);
  const retainUntil = retainDate.toISOString().slice(0, 10);

  // Strip any accidental clinical note body or narrative fields from audit metadata
  const safeMeta: Record<string, unknown> = {};
  if (input.minimisedMetadata) {
    for (const [k, v] of Object.entries(input.minimisedMetadata)) {
      if (['body_text', 'note_body', 'addendum_text', 'clinical_text', 'raw_payload'].includes(k)) continue;
      safeMeta[k] = v;
    }
  }
  const metadataJson = JSON.stringify(safeMeta);

  const lastRow = db.prepare('SELECT event_hash FROM audit_events ORDER BY seq_id DESC LIMIT 1').get() as
    | { event_hash: string }
    | undefined;
  const prevHash = lastRow?.event_hash ?? GENESIS_HASH;
  const eventHash = computeAuditHash(prevHash, id, occurredAt, input, metadataJson);

  db.prepare(
    `INSERT INTO audit_events (
      id, occurred_at, actor_user_id, actor_role, organisation_id,
      action, resource_type, resource_id, patient_id, outcome,
      reason, minimised_metadata_json, prev_hash, event_hash, retain_until
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    occurredAt,
    input.actorUserId,
    input.actorRole,
    input.organisationId,
    input.action,
    input.resourceType,
    input.resourceId ?? null,
    input.patientId ?? null,
    input.outcome,
    input.reason ?? null,
    metadataJson,
    prevHash,
    eventHash,
    retainUntil
  );

  return id;
}

export function verifyAuditHashChain(db: DatabaseSync): {
  valid: boolean;
  totalEvents: number;
  brokenAtSeqId?: number;
  note: string;
} {
  const rows = db
    .prepare(
      `SELECT seq_id, id, occurred_at, actor_user_id, actor_role, organisation_id,
              action, resource_type, resource_id, patient_id, outcome, reason,
              minimised_metadata_json, prev_hash, event_hash
       FROM audit_events ORDER BY seq_id ASC`
    )
    .all() as Array<{
    seq_id: number;
    id: string;
    occurred_at: string;
    actor_user_id: string | null;
    actor_role: string;
    organisation_id: string | null;
    action: string;
    resource_type: string;
    resource_id: string | null;
    patient_id: string | null;
    outcome: 'success' | 'denied' | 'conflict' | 'error';
    reason: string | null;
    minimised_metadata_json: string;
    prev_hash: string;
    event_hash: string;
  }>;

  let expectedPrev = GENESIS_HASH;
  for (const row of rows) {
    if (row.prev_hash !== expectedPrev) {
      return {
        valid: false,
        totalEvents: rows.length,
        brokenAtSeqId: row.seq_id,
        note: `Previous hash mismatch at seq_id=${row.seq_id}`,
      };
    }
    const recomputed = computeAuditHash(
      row.prev_hash,
      row.id,
      row.occurred_at,
      {
        actorUserId: row.actor_user_id,
        actorRole: row.actor_role,
        organisationId: row.organisation_id,
        action: row.action,
        resourceType: row.resource_type,
        resourceId: row.resource_id,
        patientId: row.patient_id,
        outcome: row.outcome,
        reason: row.reason,
      },
      row.minimised_metadata_json
    );
    if (recomputed !== row.event_hash) {
      return {
        valid: false,
        totalEvents: rows.length,
        brokenAtSeqId: row.seq_id,
        note: `Event hash mismatch at seq_id=${row.seq_id}`,
      };
    }
    expectedPrev = row.event_hash;
  }

  return {
    valid: true,
    totalEvents: rows.length,
    note: 'Hash chain verified across append-only audit log (note: database triggers + WORM archival are required alongside hash chaining for production assurance).',
  };
}
