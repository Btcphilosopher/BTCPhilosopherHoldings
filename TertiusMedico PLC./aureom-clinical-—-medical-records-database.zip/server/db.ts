import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { seedClinicData } from './seedData.ts';

let dbInstance: DatabaseSync | null = null;

export function getDbPath(): string {
  return path.resolve(process.env.AUREOM_SQLITE_PATH || './data/aureom_clinical.sqlite');
}

export function openClinicalDatabase(customPath?: string): DatabaseSync {
  const dbPath = customPath ? path.resolve(customPath) : getDbPath();
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA synchronous = NORMAL;');
  initializeSchema(db);
  return db;
}

export function getDb(): DatabaseSync {
  if (!dbInstance) {
    dbInstance = openClinicalDatabase();
    seedClinicData(dbInstance);
  }
  return dbInstance;
}

export function withTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE;');
  try {
    const result = fn();
    db.exec('COMMIT;');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // ignore rollback error
    }
    throw err;
  }
}

export function initializeSchema(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS organisations (
      id TEXT PRIMARY KEY,
      ods_code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      org_type TEXT NOT NULL CHECK (org_type IN ('nhs_trust', 'gp_practice', 'community_provider', 'icb_hub')),
      country TEXT NOT NULL DEFAULT 'GB-ENG',
      config_json TEXT NOT NULL DEFAULT '{}',
      ai_assistant_enabled INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS locations (
      id TEXT PRIMARY KEY,
      organisation_id TEXT NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      location_type TEXT NOT NULL CHECK (location_type IN ('ward', 'outpatient_clinic', 'emergency_dept', 'diagnostic_suite', 'virtual')),
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      UNIQUE (organisation_id, code)
    );

    CREATE TABLE IF NOT EXISTS roles (
      code TEXT PRIMARY KEY,
      display_name TEXT NOT NULL,
      permissions_json TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      organisation_id TEXT NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      professional_reg_no TEXT,
      role_code TEXT NOT NULL REFERENCES roles(code),
      identity_provider TEXT NOT NULL DEFAULT 'local_oidc_adapter',
      external_subject_id TEXT,
      password_hash TEXT,
      mfa_enrolled INTEGER NOT NULL DEFAULT 1,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS system_security_config (
      id TEXT PRIMARY KEY,
      admin_passcode_hash TEXT,
      claimed_by TEXT,
      claimed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS care_teams (
      id TEXT PRIMARY KEY,
      organisation_id TEXT NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
      name TEXT NOT NULL,
      specialty_snomed TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS care_team_memberships (
      care_team_id TEXT NOT NULL REFERENCES care_teams(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      team_role TEXT NOT NULL,
      effective_from TEXT NOT NULL,
      effective_to TEXT,
      PRIMARY KEY (care_team_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS user_sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      mfa_verified INTEGER NOT NULL DEFAULT 0,
      mfa_method TEXT,
      care_context_org_id TEXT NOT NULL REFERENCES organisations(id),
      issued_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      revoked_at TEXT,
      revocation_reason TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_user_sessions_user ON user_sessions(user_id, expires_at);

    CREATE TABLE IF NOT EXISTS patients (
      id TEXT PRIMARY KEY,
      internal_mrn TEXT NOT NULL UNIQUE,
      organisation_id TEXT NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
      birth_date TEXT NOT NULL,
      birth_date_accuracy TEXT NOT NULL DEFAULT 'exact' CHECK (birth_date_accuracy IN ('exact', 'month_year', 'year_only', 'unknown')),
      administrative_gender TEXT NOT NULL CHECK (administrative_gender IN ('female', 'male', 'other', 'unknown', 'not_stated')),
      deceased_flag INTEGER NOT NULL DEFAULT 0,
      deceased_at TEXT,
      preferred_language TEXT NOT NULL DEFAULT 'en-GB',
      allergy_assessment_status TEXT NOT NULL DEFAULT 'not_assessed'
        CHECK (allergy_assessment_status IN ('assessed_present', 'assessed_no_known_allergies', 'not_assessed', 'unknown', 'unavailable')),
      allergy_assessed_at TEXT,
      allergy_assessed_by TEXT REFERENCES users(id),
      record_status TEXT NOT NULL DEFAULT 'active' CHECK (record_status IN ('active', 'merged', 'inactive', 'entered_in_error')),
      merged_into_patient_id TEXT REFERENCES patients(id),
      sensitivity_level TEXT NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'vip_restricted')),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_patients_org_status ON patients(organisation_id, record_status);

    CREATE TABLE IF NOT EXISTS patient_identifiers (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
      origin_patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
      identifier_type TEXT NOT NULL CHECK (identifier_type IN ('nhs_number', 'local_mrn', 'spine_id', 'external_clinic_id')),
      identifier_value TEXT NOT NULL,
      issuing_authority TEXT NOT NULL,
      verification_status TEXT NOT NULL CHECK (verification_status IN ('verified_pds', 'verified_mod11', 'unverified', 'superseded', 'invalid')),
      effective_from TEXT NOT NULL,
      effective_to TEXT,
      is_primary INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_patient_identifiers_active_unique
      ON patient_identifiers(identifier_type, issuing_authority, identifier_value)
      WHERE effective_to IS NULL;

    CREATE TABLE IF NOT EXISTS patient_names (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
      name_use TEXT NOT NULL CHECK (name_use IN ('official', 'usual', 'maiden', 'old', 'nickname')),
      prefix TEXT,
      given_names TEXT NOT NULL,
      family_name TEXT NOT NULL,
      effective_from TEXT NOT NULL,
      effective_to TEXT,
      recorded_by TEXT REFERENCES users(id),
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr'
    );
    CREATE INDEX IF NOT EXISTS idx_patient_names_search ON patient_names(family_name, given_names);

    CREATE TABLE IF NOT EXISTS patient_addresses (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
      address_use TEXT NOT NULL CHECK (address_use IN ('home', 'temporary', 'old', 'billing')),
      line1 TEXT NOT NULL,
      line2 TEXT,
      city TEXT NOT NULL,
      county TEXT,
      postcode TEXT NOT NULL,
      country TEXT NOT NULL DEFAULT 'GB',
      effective_from TEXT NOT NULL,
      effective_to TEXT,
      recorded_by TEXT REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS patient_contacts (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
      relationship_type TEXT NOT NULL CHECK (relationship_type IN ('next_of_kin', 'emergency_contact', 'registered_gp', 'carer', 'parent_guardian')),
      full_name TEXT NOT NULL,
      telecom_phone TEXT,
      telecom_email TEXT,
      organisation_ods TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS patient_duplicate_candidates (
      id TEXT PRIMARY KEY,
      patient_a_id TEXT NOT NULL REFERENCES patients(id),
      patient_b_id TEXT NOT NULL REFERENCES patients(id),
      match_score REAL NOT NULL,
      match_rationale TEXT NOT NULL,
      review_status TEXT NOT NULL DEFAULT 'pending_review' CHECK (review_status IN ('pending_review', 'confirmed_distinct', 'merged', 'unmerged')),
      reviewed_by TEXT REFERENCES users(id),
      reviewed_at TEXT,
      created_at TEXT NOT NULL,
      CHECK (patient_a_id <> patient_b_id)
    );

    CREATE TABLE IF NOT EXISTS patient_merge_events (
      id TEXT PRIMARY KEY,
      source_patient_id TEXT NOT NULL REFERENCES patients(id),
      target_patient_id TEXT NOT NULL REFERENCES patients(id),
      action TEXT NOT NULL CHECK (action IN ('merge', 'unmerge')),
      reason TEXT NOT NULL,
      moved_records_snapshot TEXT NOT NULL,
      performed_by TEXT NOT NULL REFERENCES users(id),
      performed_at TEXT NOT NULL,
      reversed_by_event_id TEXT REFERENCES patient_merge_events(id)
    );

    CREATE TABLE IF NOT EXISTS enrolments (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      organisation_id TEXT NOT NULL REFERENCES organisations(id),
      care_team_id TEXT REFERENCES care_teams(id),
      enrolment_type TEXT NOT NULL CHECK (enrolment_type IN ('registered_gp', 'outpatient_pathway', 'inpatient_spell', 'community_caseload')),
      status TEXT NOT NULL CHECK (status IN ('active', 'completed', 'suspended', 'entered_in_error')),
      started_at TEXT NOT NULL,
      ended_at TEXT
    );

    CREATE TABLE IF NOT EXISTS encounters (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      organisation_id TEXT NOT NULL REFERENCES organisations(id),
      location_id TEXT NOT NULL REFERENCES locations(id),
      care_team_id TEXT REFERENCES care_teams(id),
      attending_user_id TEXT NOT NULL REFERENCES users(id),
      encounter_class TEXT NOT NULL CHECK (encounter_class IN ('outpatient', 'inpatient', 'emergency', 'telephone', 'home_visit')),
      status TEXT NOT NULL CHECK (status IN ('planned', 'in_progress', 'finished', 'cancelled', 'entered_in_error')),
      reason_text TEXT NOT NULL,
      started_at TEXT NOT NULL,
      ended_at TEXT,
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_encounters_patient ON encounters(patient_id, started_at DESC);

    CREATE TABLE IF NOT EXISTS clinical_notes (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      note_type TEXT NOT NULL CHECK (note_type IN ('consultation', 'ward_round', 'discharge_summary', 'nursing_assessment', 'procedure_note', 'referral_letter')),
      title TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'signed', 'amended', 'entered_in_error')),
      current_version INTEGER NOT NULL DEFAULT 1,
      author_id TEXT NOT NULL REFERENCES users(id),
      event_time TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      signed_at TEXT,
      signed_by TEXT REFERENCES users(id),
      entered_in_error_reason TEXT,
      entered_in_error_by TEXT REFERENCES users(id),
      entered_in_error_at TEXT,
      sensitivity_level TEXT NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr',
      source_record_id TEXT
    );

    CREATE TABLE IF NOT EXISTS clinical_note_versions (
      id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL REFERENCES clinical_notes(id) ON DELETE RESTRICT,
      version_number INTEGER NOT NULL,
      body_text TEXT NOT NULL,
      copied_material_refs TEXT NOT NULL DEFAULT '[]',
      is_immutable INTEGER NOT NULL DEFAULT 0,
      saved_by TEXT NOT NULL REFERENCES users(id),
      saved_at TEXT NOT NULL,
      UNIQUE (note_id, version_number)
    );

    CREATE TRIGGER IF NOT EXISTS trg_note_version_immutable_update
      BEFORE UPDATE ON clinical_note_versions
      WHEN OLD.is_immutable = 1
      BEGIN
        SELECT RAISE(ABORT, 'Signed clinical note versions are immutable and cannot be modified');
      END;

    CREATE TRIGGER IF NOT EXISTS trg_note_version_no_delete
      BEFORE DELETE ON clinical_note_versions
      BEGIN
        SELECT RAISE(ABORT, 'Clinical note version history cannot be deleted');
      END;

    CREATE TABLE IF NOT EXISTS clinical_signatures (
      id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL REFERENCES clinical_notes(id) ON DELETE RESTRICT,
      version_number INTEGER NOT NULL,
      signer_id TEXT NOT NULL REFERENCES users(id),
      attestation_statement TEXT NOT NULL,
      idempotency_key TEXT NOT NULL UNIQUE,
      content_sha256 TEXT,
      signature_algorithm TEXT,
      signed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS clinical_note_amendments (
      id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL REFERENCES clinical_notes(id) ON DELETE RESTRICT,
      amendment_type TEXT NOT NULL CHECK (amendment_type IN ('addendum', 'correction', 'clarification')),
      reason TEXT NOT NULL,
      addendum_text TEXT NOT NULL,
      copied_material_refs TEXT NOT NULL DEFAULT '[]',
      author_id TEXT NOT NULL REFERENCES users(id),
      signed_at TEXT NOT NULL,
      content_sha256 TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS problems (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      snomed_code TEXT NOT NULL,
      display_term TEXT NOT NULL,
      clinical_status TEXT NOT NULL CHECK (clinical_status IN ('active', 'recurrence', 'relapse', 'inactive', 'remission', 'resolved', 'unknown')),
      verification_status TEXT NOT NULL CHECK (verification_status IN ('unconfirmed', 'provisional', 'differential', 'confirmed', 'refuted', 'entered_in_error')),
      onset_date TEXT,
      abatement_date TEXT,
      author_id TEXT REFERENCES users(id),
      event_time TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr',
      source_record_id TEXT,
      sensitivity_level TEXT NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS allergies (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      substance_code TEXT NOT NULL,
      substance_name TEXT NOT NULL,
      reaction_manifestation TEXT NOT NULL,
      severity TEXT NOT NULL CHECK (severity IN ('mild', 'moderate', 'severe', 'life_threatening', 'unknown')),
      criticality TEXT NOT NULL CHECK (criticality IN ('low', 'high', 'unable_to_assess')),
      verification_status TEXT NOT NULL CHECK (verification_status IN ('unconfirmed', 'presumed', 'confirmed', 'refuted', 'entered_in_error')),
      clinical_status TEXT NOT NULL CHECK (clinical_status IN ('active', 'inactive', 'resolved')),
      author_id TEXT REFERENCES users(id),
      event_time TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr',
      source_record_id TEXT,
      conflict_flag INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS medication_statements (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      dmd_code TEXT NOT NULL,
      medication_name TEXT NOT NULL,
      reported_dose_text TEXT NOT NULL,
      information_source TEXT NOT NULL CHECK (information_source IN ('patient_reported', 'carer_reported', 'gp_summary_import', 'community_pharmacy')),
      status TEXT NOT NULL CHECK (status IN ('active', 'completed', 'stopped', 'intended', 'unknown', 'not_taken', 'entered_in_error')),
      event_time TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      recorded_by TEXT REFERENCES users(id),
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr'
    );

    CREATE TABLE IF NOT EXISTS prescriptions (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      dmd_code TEXT NOT NULL,
      medication_name TEXT NOT NULL,
      dose_value REAL,
      dose_unit TEXT,
      route TEXT NOT NULL,
      frequency TEXT NOT NULL,
      indication TEXT,
      prescriber_id TEXT NOT NULL REFERENCES users(id),
      status TEXT NOT NULL CHECK (status IN ('draft', 'active', 'on_hold', 'cancelled', 'completed', 'stopped', 'entered_in_error')),
      authored_at TEXT NOT NULL,
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr'
    );

    CREATE TABLE IF NOT EXISTS dispensing_records (
      id TEXT PRIMARY KEY,
      prescription_id TEXT NOT NULL REFERENCES prescriptions(id),
      patient_id TEXT NOT NULL REFERENCES patients(id),
      quantity_value REAL NOT NULL,
      quantity_unit TEXT NOT NULL,
      batch_number TEXT,
      dispensed_by TEXT NOT NULL,
      dispensed_at TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('completed', 'partial', 'returned', 'entered_in_error'))
    );

    CREATE TABLE IF NOT EXISTS medication_administrations (
      id TEXT PRIMARY KEY,
      prescription_id TEXT NOT NULL REFERENCES prescriptions(id),
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      dose_given TEXT NOT NULL,
      route TEXT NOT NULL,
      administered_by TEXT NOT NULL REFERENCES users(id),
      administered_at TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('completed', 'not_done', 'refused', 'held', 'entered_in_error')),
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS specimens (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      specimen_type TEXT NOT NULL,
      collection_time TEXT NOT NULL,
      received_time TEXT,
      collector_name TEXT,
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr'
    );

    CREATE TABLE IF NOT EXISTS observations (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      specimen_id TEXT REFERENCES specimens(id),
      code_system TEXT NOT NULL,
      code TEXT NOT NULL,
      display_name TEXT NOT NULL,
      value_numeric REAL,
      value_text TEXT,
      unit TEXT,
      ref_range_low REAL,
      ref_range_high REAL,
      ref_range_text TEXT,
      source_interpretation TEXT,
      status TEXT NOT NULL CHECK (status IN ('registered', 'preliminary', 'final', 'amended', 'corrected', 'cancelled', 'entered_in_error')),
      effective_time TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      author_id TEXT REFERENCES users(id),
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr',
      source_record_id TEXT,
      sensitivity_level TEXT NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential'))
    );

    CREATE TABLE IF NOT EXISTS diagnostic_requests (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      requester_id TEXT NOT NULL REFERENCES users(id),
      test_code TEXT NOT NULL,
      test_name TEXT NOT NULL,
      priority TEXT NOT NULL CHECK (priority IN ('routine', 'urgent', 'stat')),
      status TEXT NOT NULL CHECK (status IN ('requested', 'in_progress', 'completed', 'cancelled')),
      requested_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS diagnostic_results (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      request_id TEXT REFERENCES diagnostic_requests(id),
      specimen_id TEXT REFERENCES specimens(id),
      report_code TEXT NOT NULL,
      report_title TEXT NOT NULL,
      result_summary TEXT NOT NULL,
      structured_values_json TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL CHECK (status IN ('preliminary', 'final', 'corrected', 'cancelled', 'entered_in_error')),
      replaces_result_id TEXT REFERENCES diagnostic_results(id),
      correction_reason TEXT,
      review_state TEXT NOT NULL DEFAULT 'unviewed'
        CHECK (review_state IN ('unviewed', 'viewed', 'acknowledged', 'assigned_for_followup', 'action_completed')),
      reviewed_by TEXT REFERENCES users(id),
      reviewed_at TEXT,
      effective_time TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      source_system TEXT NOT NULL,
      source_record_id TEXT NOT NULL,
      sensitivity_level TEXT NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
      UNIQUE (source_system, source_record_id, status)
    );

    CREATE TABLE IF NOT EXISTS care_plans (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      title TEXT NOT NULL,
      plan_summary TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('draft', 'active', 'on_hold', 'completed', 'revoked')),
      author_id TEXT NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS follow_up_tasks (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      linked_result_id TEXT REFERENCES diagnostic_results(id),
      title TEXT NOT NULL,
      instructions TEXT NOT NULL,
      priority TEXT NOT NULL CHECK (priority IN ('routine', 'urgent', 'critical')),
      status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled')),
      assigned_to TEXT NOT NULL REFERENCES users(id),
      created_by TEXT NOT NULL REFERENCES users(id),
      due_at TEXT,
      completed_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS referrals (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      referred_by TEXT NOT NULL REFERENCES users(id),
      target_specialty TEXT NOT NULL,
      target_organisation TEXT NOT NULL,
      urgency TEXT NOT NULL CHECK (urgency IN ('routine', 'urgent', 'two_week_wait')),
      reason TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('draft', 'sent', 'accepted', 'rejected', 'completed')),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      origin_patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      title TEXT NOT NULL,
      document_type TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      byte_size INTEGER NOT NULL,
      object_storage_key TEXT NOT NULL UNIQUE,
      sha256_checksum TEXT NOT NULL,
      uploaded_by TEXT NOT NULL REFERENCES users(id),
      sensitivity_level TEXT NOT NULL DEFAULT 'normal' CHECK (sensitivity_level IN ('normal', 'restricted', 'confidential')),
      source_system TEXT NOT NULL DEFAULT 'aureom_ehr',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS imaging_references (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      study_instance_uid TEXT NOT NULL UNIQUE,
      accession_number TEXT NOT NULL,
      modality TEXT NOT NULL,
      body_site TEXT NOT NULL,
      study_description TEXT NOT NULL,
      archive_endpoint_uri TEXT NOT NULL,
      performed_at TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('available', 'pending', 'entered_in_error'))
    );

    CREATE TABLE IF NOT EXISTS consent_directives (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      purpose TEXT NOT NULL CHECK (purpose IN ('direct_care', 'national_summary_care', 'research_opt_in', 'hie_exchange', 'ai_draft_assistance')),
      decision TEXT NOT NULL CHECK (decision IN ('permit', 'deny', 'ask')),
      scope_notes TEXT,
      recorded_by TEXT NOT NULL REFERENCES users(id),
      effective_from TEXT NOT NULL,
      effective_to TEXT
    );

    CREATE TABLE IF NOT EXISTS access_restrictions (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      resource_type TEXT NOT NULL,
      resource_id TEXT,
      policy_code TEXT NOT NULL CHECK (policy_code IN ('restricted_vip', 'sexual_health', 'mental_health', 'safeguarding', 'staff_member_record')),
      allowed_roles_json TEXT NOT NULL,
      reason TEXT NOT NULL,
      created_by TEXT NOT NULL REFERENCES users(id),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS emergency_access_grants (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      patient_id TEXT NOT NULL REFERENCES patients(id),
      reason TEXT NOT NULL,
      granted_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      ig_review_status TEXT NOT NULL DEFAULT 'pending_review' CHECK (ig_review_status IN ('pending_review', 'justified', 'flagged_inappropriate')),
      ig_reviewed_by TEXT REFERENCES users(id),
      ig_reviewed_at TEXT,
      ig_review_notes TEXT
    );

    CREATE TABLE IF NOT EXISTS provenance_records (
      id TEXT PRIMARY KEY,
      target_table TEXT NOT NULL,
      target_id TEXT NOT NULL,
      activity TEXT NOT NULL CHECK (activity IN ('create', 'update', 'sign', 'amend', 'import', 'merge', 'unmerge', 'enter_in_error')),
      agent_user_id TEXT REFERENCES users(id),
      agent_system TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      detail_json TEXT NOT NULL DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS audit_events (
      seq_id INTEGER PRIMARY KEY AUTOINCREMENT,
      id TEXT NOT NULL UNIQUE,
      occurred_at TEXT NOT NULL,
      actor_user_id TEXT REFERENCES users(id),
      actor_role TEXT NOT NULL,
      organisation_id TEXT REFERENCES organisations(id),
      action TEXT NOT NULL,
      resource_type TEXT NOT NULL,
      resource_id TEXT,
      patient_id TEXT REFERENCES patients(id),
      outcome TEXT NOT NULL CHECK (outcome IN ('success', 'denied', 'conflict', 'error')),
      reason TEXT,
      minimised_metadata_json TEXT NOT NULL DEFAULT '{}',
      prev_hash TEXT NOT NULL,
      event_hash TEXT NOT NULL,
      retain_until TEXT NOT NULL
    );

    CREATE TRIGGER IF NOT EXISTS trg_audit_events_no_update
      BEFORE UPDATE ON audit_events
      BEGIN
        SELECT RAISE(ABORT, 'audit_events is append-only; updates are prohibited');
      END;

    CREATE TRIGGER IF NOT EXISTS trg_audit_events_no_delete
      BEFORE DELETE ON audit_events
      BEGIN
        SELECT RAISE(ABORT, 'audit_events is append-only; deletes are prohibited');
      END;

    CREATE TABLE IF NOT EXISTS integration_inbox_messages (
      id TEXT PRIMARY KEY,
      source_system TEXT NOT NULL,
      external_message_id TEXT NOT NULL,
      message_format TEXT NOT NULL CHECK (message_format IN ('fhir_r4_uk_core_bundle', 'hl7_v2', 'gp_connect_json')),
      mapping_version TEXT NOT NULL,
      payload_sha256 TEXT NOT NULL,
      raw_payload_json TEXT NOT NULL,
      processing_status TEXT NOT NULL CHECK (processing_status IN ('received', 'processed', 'duplicate_ignored', 'failed_retrying', 'dead_letter')),
      error_detail TEXT,
      retry_count INTEGER NOT NULL DEFAULT 0,
      received_at TEXT NOT NULL,
      processed_at TEXT,
      UNIQUE (source_system, external_message_id)
    );

    CREATE TABLE IF NOT EXISTS integration_outbox_events (
      id TEXT PRIMARY KEY,
      aggregate_type TEXT NOT NULL,
      aggregate_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      delivery_status TEXT NOT NULL DEFAULT 'pending' CHECK (delivery_status IN ('pending', 'dispatched', 'failed')),
      attempts INTEGER NOT NULL DEFAULT 0,
      next_attempt_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS retention_policies (
      id TEXT PRIMARY KEY,
      organisation_id TEXT NOT NULL REFERENCES organisations(id),
      record_category TEXT NOT NULL,
      retention_years INTEGER NOT NULL,
      statutory_basis TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS legal_holds (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      reason TEXT NOT NULL,
      placed_by TEXT NOT NULL REFERENCES users(id),
      placed_at TEXT NOT NULL,
      released_at TEXT,
      released_by TEXT REFERENCES users(id),
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS backup_restore_drills (
      id TEXT PRIMARY KEY,
      started_at TEXT NOT NULL,
      completed_at TEXT,
      target_rpo_seconds INTEGER NOT NULL DEFAULT 300,
      target_rto_seconds INTEGER NOT NULL DEFAULT 900,
      measured_rto_ms INTEGER,
      verified_row_counts_json TEXT NOT NULL DEFAULT '{}',
      attachments_verified INTEGER NOT NULL DEFAULT 0,
      integrity_check_passed INTEGER NOT NULL DEFAULT 0,
      performed_by TEXT REFERENCES users(id),
      notes TEXT
    );
  `);
}
