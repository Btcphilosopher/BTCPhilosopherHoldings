import crypto from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { appendAuditEvent } from './audit.ts';
import { withTransaction } from './db.ts';
import { PATIENT_IDS, USER_IDS } from './seedData.ts';

export const MAPPING_VERSION = 'uk-core-r4-v1.2.0';

export interface FhirBundleInput {
  resourceType?: string;
  id?: string;
  type?: string;
  sourceSystem?: string;
  simulateFailure?: boolean;
  entry?: Array<{
    resource?: {
      resourceType?: string;
      id?: string;
      status?: string;
      code?: { text?: string; coding?: Array<{ code?: string; display?: string; system?: string }> };
      subject?: { reference?: string };
      effectiveDateTime?: string;
      conclusion?: string;
      replacesReference?: string;
      correctionReason?: string;
      _structuredValues?: Array<{
        analyte: string;
        value: number;
        unit: string;
        refLow?: number;
        refHigh?: number;
        flag?: string;
      }>;
    };
  }>;
}

export function ingestFhirBundle(
  db: DatabaseSync,
  sourceSystem: string,
  bundle: FhirBundleInput,
  actorUserId: string | null,
  actorRole: string,
  organisationId: string
): {
  inboxId: string;
  status: 'processed' | 'duplicate_ignored' | 'failed_retrying';
  createdResultIds: string[];
  message: string;
} {
  if (bundle.resourceType !== 'Bundle' || !bundle.id || !Array.isArray(bundle.entry)) {
    throw new Error('Invalid FHIR R4 Bundle: resourceType="Bundle", id, and entry[] are required');
  }

  const rawJson = JSON.stringify(bundle);
  const payloadSha256 = crypto.createHash('sha256').update(rawJson).digest('hex');

  // Duplicate message handling via (source_system, external_message_id)
  const existing = db
    .prepare('SELECT id, processing_status FROM integration_inbox_messages WHERE source_system = ? AND external_message_id = ?')
    .get(sourceSystem, bundle.id) as { id: string; processing_status: string } | undefined;

  if (existing && existing.processing_status === 'processed') {
    appendAuditEvent(db, {
      actorUserId,
      actorRole,
      organisationId,
      action: 'fhir.ingest_duplicate',
      resourceType: 'integration_inbox_message',
      resourceId: existing.id,
      outcome: 'conflict',
      reason: `Duplicate external message ${bundle.id} from ${sourceSystem} ignored idempotently`,
    });
    return {
      inboxId: existing.id,
      status: 'duplicate_ignored',
      createdResultIds: [],
      message: `Duplicate message ${bundle.id} from ${sourceSystem} already processed; idempotently ignored.`,
    };
  }

  const bundleId = bundle.id;
  const now = new Date().toISOString();
  const inboxId = existing?.id ?? crypto.randomUUID();

  if (bundle.simulateFailure) {
    if (!existing) {
      db.prepare(
        `INSERT INTO integration_inbox_messages (id, source_system, external_message_id, message_format, mapping_version, payload_sha256, raw_payload_json, processing_status, error_detail, retry_count, received_at)
         VALUES (?, ?, ?, 'fhir_r4_uk_core_bundle', ?, ?, ?, 'failed_retrying', 'Simulated downstream terminology/network validation failure', 1, ?)`
      ).run(inboxId, sourceSystem, bundleId, MAPPING_VERSION, payloadSha256, rawJson, now);
    }
    return {
      inboxId,
      status: 'failed_retrying',
      createdResultIds: [],
      message: `Message ${bundleId} persisted to integration inbox in failed_retrying state for manual review/retry.`,
    };
  }

  const createdResultIds: string[] = [];

  withTransaction(db, () => {
    if (!existing) {
      db.prepare(
        `INSERT INTO integration_inbox_messages (id, source_system, external_message_id, message_format, mapping_version, payload_sha256, raw_payload_json, processing_status, retry_count, received_at, processed_at)
         VALUES (?, ?, ?, 'fhir_r4_uk_core_bundle', ?, ?, ?, 'processed', 0, ?, ?)`
      ).run(inboxId, sourceSystem, bundleId, MAPPING_VERSION, payloadSha256, rawJson, now, now);
    } else {
      db.prepare(
        `UPDATE integration_inbox_messages
         SET processing_status = 'processed', error_detail = NULL, processed_at = ?, retry_count = retry_count + 1
         WHERE id = ?`
      ).run(now, inboxId);
    }

    for (const item of bundle.entry ?? []) {
      const res = item.resource;
      if (!res || res.resourceType !== 'DiagnosticReport') continue;

      const patientRef = res.subject?.reference?.replace(/^Patient\//, '') || PATIENT_IDS.arthur;
      const patientRow = db.prepare('SELECT id FROM patients WHERE id = ?').get(patientRef) as { id: string } | undefined;
      if (!patientRow) {
        throw new Error(`Referenced patient ${patientRef} does not exist in local repository`);
      }

      const sourceRecordId = res.id || `EXT-${crypto.randomUUID().slice(0, 8)}`;
      const status = (['preliminary', 'final', 'corrected', 'cancelled', 'entered_in_error'].includes(res.status ?? '')
        ? res.status
        : 'final') as 'preliminary' | 'final' | 'corrected' | 'cancelled' | 'entered_in_error';

      let replacesId: string | null = null;
      if (res.replacesReference) {
        const prev = db
          .prepare(
            `SELECT id FROM diagnostic_results
             WHERE (id = ? OR source_record_id = ?) AND patient_id = ?
             ORDER BY recorded_at DESC LIMIT 1`
          )
          .get(res.replacesReference, res.replacesReference, patientRow.id) as { id: string } | undefined;
        replacesId = prev?.id ?? null;
      }

      const existingSame = db
        .prepare('SELECT id FROM diagnostic_results WHERE source_system = ? AND source_record_id = ? AND status = ?')
        .get(sourceSystem, sourceRecordId, status) as { id: string } | undefined;
      if (existingSame) {
        continue;
      }

      const resultId = crypto.randomUUID();
      const reportCode = res.code?.coding?.[0]?.code || 'UKCORE-LAB';
      const reportTitle = res.code?.text || res.code?.coding?.[0]?.display || 'Imported Diagnostic Report';
      const structuredValues = JSON.stringify(res._structuredValues ?? []);

      db.prepare(
        `INSERT INTO diagnostic_results (
          id, patient_id, origin_patient_id, report_code, report_title, result_summary,
          structured_values_json, status, replaces_result_id, correction_reason, review_state,
          effective_time, recorded_at, source_system, source_record_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'unviewed', ?, ?, ?, ?)`
      ).run(
        resultId,
        patientRow.id,
        patientRow.id,
        reportCode,
        reportTitle,
        res.conclusion || 'Diagnostic report imported via UK Core FHIR R4 adapter',
        structuredValues,
        status,
        replacesId,
        res.correctionReason ?? null,
        res.effectiveDateTime || now,
        now,
        sourceSystem,
        sourceRecordId
      );

      db.prepare(
        `INSERT INTO provenance_records (id, target_table, target_id, activity, agent_user_id, agent_system, recorded_at, detail_json)
         VALUES (?, 'diagnostic_results', ?, 'import', ?, ?, ?, ?)`
      ).run(
        crypto.randomUUID(),
        resultId,
        actorUserId,
        sourceSystem,
        now,
        JSON.stringify({ mappingVersion: MAPPING_VERSION, externalMessageId: bundle.id, replacesResultId: replacesId })
      );

      appendAuditEvent(db, {
        actorUserId: actorUserId ?? USER_IDS.consultant,
        actorRole,
        organisationId,
        action: 'fhir.import_result',
        resourceType: 'diagnostic_result',
        resourceId: resultId,
        patientId: patientRow.id,
        outcome: 'success',
        minimisedMetadata: { sourceSystem, sourceRecordId, status, replacesId, mappingVersion: MAPPING_VERSION },
      });

      createdResultIds.push(resultId);
    }
  });

  return {
    inboxId,
    status: 'processed',
    createdResultIds,
    message: `Ingested UK Core FHIR R4 bundle ${bundle.id} (${createdResultIds.length} diagnostic report(s) recorded).`,
  };
}
