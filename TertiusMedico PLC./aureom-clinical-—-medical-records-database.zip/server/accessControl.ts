import type { DatabaseSync } from 'node:sqlite';
import type { AuthenticatedActor } from './auth.ts';
import { appendAuditEvent } from './audit.ts';

export interface AccessDecision {
  allowed: boolean;
  viaBreakGlass: boolean;
  restrictionPolicy?: string;
  reason: string;
}

export function hasPermission(actor: AuthenticatedActor, permission: string): boolean {
  return actor.permissions.includes(permission);
}

export function evaluatePatientAccess(
  db: DatabaseSync,
  actor: AuthenticatedActor,
  patientId: string,
  options?: { logDenial?: boolean; actionName?: string }
): AccessDecision {
  const patient = db
    .prepare('SELECT id, organisation_id, sensitivity_level, record_status FROM patients WHERE id = ?')
    .get(patientId) as
    | { id: string; organisation_id: string; sensitivity_level: string; record_status: string }
    | undefined;

  if (!patient) {
    return { allowed: false, viaBreakGlass: false, reason: 'Patient record not found' };
  }

  if (patient.organisation_id !== actor.organisationId) {
    if (options?.logDenial !== false) {
      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: options?.actionName ?? 'patient.access',
        resourceType: 'patient',
        resourceId: patientId,
        patientId,
        outcome: 'denied',
        reason: 'Cross-organisation access denied without explicit HIE authority',
      });
    }
    return { allowed: false, viaBreakGlass: false, reason: 'Cross-organisation isolation policy denied access' };
  }

  const restrictions = db
    .prepare(
      `SELECT policy_code, allowed_roles_json, reason
       FROM access_restrictions
       WHERE patient_id = ? AND resource_type = 'patient' AND resource_id IS NULL AND active = 1`
    )
    .all(patientId) as Array<{ policy_code: string; allowed_roles_json: string; reason: string }>;

  if (restrictions.length === 0 && patient.sensitivity_level === 'normal') {
    return { allowed: true, viaBreakGlass: false, reason: 'Standard organisational direct-care policy' };
  }

  // Check if role is explicitly permitted by all active patient-level restrictions
  let rolePermitted = restrictions.length > 0;
  for (const r of restrictions) {
    const allowedRoles = JSON.parse(r.allowed_roles_json) as string[];
    if (!allowedRoles.includes(actor.roleCode)) {
      rolePermitted = false;
      break;
    }
  }
  if (restrictions.length === 0 && patient.sensitivity_level !== 'normal') {
    rolePermitted = ['consultant_physician', 'caldicott_guardian'].includes(actor.roleCode);
  }

  if (rolePermitted) {
    return {
      allowed: true,
      viaBreakGlass: false,
      restrictionPolicy: restrictions[0]?.policy_code ?? patient.sensitivity_level,
      reason: 'Role explicitly authorised under restricted-record policy',
    };
  }

  // Check active non-expired Break-Glass emergency grant
  const nowIso = new Date().toISOString();
  const grant = db
    .prepare(
      `SELECT id, reason, expires_at FROM emergency_access_grants
       WHERE user_id = ? AND patient_id = ? AND expires_at > ?
       ORDER BY granted_at DESC LIMIT 1`
    )
    .get(actor.userId, patientId, nowIso) as { id: string; reason: string; expires_at: string } | undefined;

  if (grant) {
    return {
      allowed: true,
      viaBreakGlass: true,
      restrictionPolicy: restrictions[0]?.policy_code ?? patient.sensitivity_level,
      reason: `Active Break-Glass emergency grant until ${grant.expires_at}`,
    };
  }

  if (options?.logDenial !== false) {
    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: options?.actionName ?? 'patient.access',
      resourceType: 'patient',
      resourceId: patientId,
      patientId,
      outcome: 'denied',
      reason: restrictions[0]?.reason ?? 'Restricted sensitivity policy requires Consultant, Caldicott Guardian, or Break-Glass justification',
    });
  }

  return {
    allowed: false,
    viaBreakGlass: false,
    restrictionPolicy: restrictions[0]?.policy_code ?? patient.sensitivity_level,
    reason: restrictions[0]?.reason ?? 'Restricted record: authorisation or Break-Glass override required.',
  };
}

export function canAccessResourceSensitivity(
  db: DatabaseSync,
  actor: AuthenticatedActor,
  patientId: string,
  sensitivityLevel: string
): boolean {
  const patientDecision = evaluatePatientAccess(db, actor, patientId, { logDenial: false });
  if (!patientDecision.allowed) return false;
  if (sensitivityLevel === 'normal') return true;
  if (patientDecision.viaBreakGlass) return true;
  return ['consultant_physician', 'caldicott_guardian'].includes(actor.roleCode);
}
