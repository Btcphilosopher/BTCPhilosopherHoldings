import crypto from 'node:crypto';
import type { Express, RequestHandler, Response } from 'express';
import type { DatabaseSync } from 'node:sqlite';
import { canAccessResourceSensitivity, evaluatePatientAccess, hasPermission } from './accessControl.ts';
import { appendAuditEvent } from './audit.ts';
import type { AuthedRequest } from './auth.ts';
import { withTransaction } from './db.ts';
import type { FhirBundleInput } from './fhir.ts';
import { readProtectedPatientObject, storePatientObject } from './storage.ts';

interface RouteDeps {
  auth: RequestHandler;
  ingestFhirBundle: (
    db: DatabaseSync,
    sourceSystem: string,
    bundle: FhirBundleInput,
    actorUserId: string | null,
    actorRole: string,
    organisationId: string
  ) => unknown;
  generateSourceLinkedSummary: (db: DatabaseSync, actor: NonNullable<AuthedRequest['actor']>, patientId: string, prompt: string) => Promise<unknown>;
  runBackupAndIsolatedRestoreDrill: (db: DatabaseSync, actor: NonNullable<AuthedRequest['actor']>) => Promise<unknown>;
  verifyAuditHashChain: (db: DatabaseSync) => unknown;
}

export function registerClinicalRoutes(app: Express, db: DatabaseSync, deps: RouteDeps): void {
  const { auth } = deps;

  // --- Encounters ---
  app.get('/api/encounters', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.query.patientId ? String(req.query.patientId) : null;
    const rows = (
      db
        .prepare(
          `SELECT e.*, l.name as location_name, u.full_name as attending_name,
                  pn.given_names || ' ' || pn.family_name as patient_name, p.internal_mrn
           FROM encounters e
           JOIN locations l ON l.id = e.location_id
           JOIN users u ON u.id = e.attending_user_id
           JOIN patients p ON p.id = e.patient_id
           JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
           WHERE e.organisation_id = ? ${patientId ? 'AND e.patient_id = ?' : ''}
           ORDER BY e.started_at DESC`
        )
        .all(...(patientId ? [actor.organisationId, patientId] : [actor.organisationId])) as Array<Record<string, unknown>>
    ).filter((e) => evaluatePatientAccess(db, actor, String(e.patient_id), { logDenial: false }).allowed);

    const locations = db.prepare('SELECT id, code, name, location_type FROM locations WHERE organisation_id = ? AND is_active = 1').all(actor.organisationId);
    res.json({ encounters: rows, locations });
  });

  app.post('/api/encounters', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'encounter.write')) {
      res.status(403).json({ error: 'Role lacks permission to open encounters' });
      return;
    }
    const { patientId, locationId, encounterClass, reasonText } = req.body as Record<string, string>;
    if (!patientId || !locationId || !encounterClass || !reasonText?.trim()) {
      res.status(400).json({ error: 'patientId, locationId, encounterClass, and reasonText are required' });
      return;
    }
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'encounter.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO encounters (id, patient_id, organisation_id, location_id, attending_user_id, encounter_class, status, reason_text, started_at, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'in_progress', ?, ?, ?)`
      ).run(id, patientId, actor.organisationId, locationId, actor.userId, encounterClass, reasonText.trim(), now, now);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'encounter.open',
        resourceType: 'encounter',
        resourceId: id,
        patientId,
        outcome: 'success',
        minimisedMetadata: { encounterClass, locationId },
      });
    });

    res.status(201).json({ id, status: 'in_progress', startedAt: now });
  });

  app.patch('/api/encounters/:id/status', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'encounter.write')) {
      res.status(403).json({ error: 'Role lacks permission to update encounters' });
      return;
    }
    const enc = db.prepare('SELECT id, patient_id FROM encounters WHERE id = ?').get(req.params.id) as { id: string; patient_id: string } | undefined;
    if (!enc) {
      res.status(404).json({ error: 'Encounter not found' });
      return;
    }
    const { status } = req.body as { status?: string };
    if (!['planned', 'in_progress', 'finished', 'cancelled', 'entered_in_error'].includes(status || '')) {
      res.status(400).json({ error: 'Invalid encounter status' });
      return;
    }
    const validStatus = status!;
    const endedAt = validStatus === 'finished' || validStatus === 'cancelled' ? new Date().toISOString() : null;
    db.prepare('UPDATE encounters SET status = ?, ended_at = COALESCE(?, ended_at) WHERE id = ?').run(validStatus, endedAt, enc.id);
    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'encounter.status_change',
      resourceType: 'encounter',
      resourceId: enc.id,
      patientId: enc.patient_id,
      outcome: 'success',
      minimisedMetadata: { status },
    });
    res.json({ id: enc.id, status, endedAt });
  });

  // --- Clinical Notes: Draft -> Signed -> Amended / Entered in Error ---
  app.get('/api/notes', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.query.patientId ? String(req.query.patientId) : null;
    const notes = (
      db
        .prepare(
          `SELECT cn.*, u.full_name as author_name, su.full_name as signer_name,
                  pn.given_names || ' ' || pn.family_name as patient_name, p.internal_mrn,
                  v.body_text, v.copied_material_refs, v.is_immutable
           FROM clinical_notes cn
           JOIN users u ON u.id = cn.author_id
           LEFT JOIN users su ON su.id = cn.signed_by
           JOIN patients p ON p.id = cn.patient_id
           JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
           JOIN clinical_note_versions v ON v.note_id = cn.id AND v.version_number = cn.current_version
           WHERE p.organisation_id = ? ${patientId ? 'AND cn.patient_id = ?' : ''}
           ORDER BY cn.event_time DESC`
        )
        .all(...(patientId ? [actor.organisationId, patientId] : [actor.organisationId])) as Array<Record<string, unknown>>
    )
      .filter((n) => canAccessResourceSensitivity(db, actor, String(n.patient_id), String(n.sensitivity_level)))
      .map((n) => {
        const amendments = db
          .prepare(
            `SELECT a.*, au.full_name as author_name, au.professional_reg_no
             FROM clinical_note_amendments a
             JOIN users au ON au.id = a.author_id
             WHERE a.note_id = ? ORDER BY a.signed_at ASC`
          )
          .all(String(n.id));
        const signature = db
          .prepare(
            `SELECT cs.*, su.full_name as signer_name, su.professional_reg_no
             FROM clinical_signatures cs
             JOIN users su ON su.id = cs.signer_id
             WHERE cs.note_id = ? ORDER BY cs.signed_at DESC LIMIT 1`
          )
          .get(String(n.id));
        return {
          ...n,
          copiedMaterialRefs: JSON.parse(String(n.copied_material_refs || '[]')),
          amendments,
          signature: signature ?? null,
        };
      });

    res.json({ notes });
  });

  app.post('/api/notes', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'note.write')) {
      res.status(403).json({ error: 'Role lacks note authoring permission' });
      return;
    }
    const { patientId, encounterId, noteType, title, bodyText, copiedMaterialRefs, sensitivityLevel } = req.body as {
      patientId?: string;
      encounterId?: string | null;
      noteType?: string;
      title?: string;
      bodyText?: string;
      copiedMaterialRefs?: Array<{ source_record_id: string; label: string }>;
      sensitivityLevel?: string;
    };

    if (!patientId || !title?.trim() || !bodyText?.trim()) {
      res.status(400).json({ error: 'patientId, title, and bodyText are required' });
      return;
    }
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'note.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }

    const noteId = crypto.randomUUID();
    const now = new Date().toISOString();
    const validType = ['consultation', 'ward_round', 'discharge_summary', 'nursing_assessment', 'procedure_note', 'referral_letter'].includes(noteType || '')
      ? noteType!
      : 'consultation';

    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO clinical_notes (id, patient_id, origin_patient_id, encounter_id, note_type, title, status, current_version, author_id, event_time, recorded_at, sensitivity_level)
         VALUES (?, ?, ?, ?, ?, ?, 'draft', 1, ?, ?, ?, ?)`
      ).run(noteId, patientId, patientId, encounterId || null, validType, title.trim(), actor.userId, now, now, sensitivityLevel === 'restricted' ? 'restricted' : 'normal');

      db.prepare(
        `INSERT INTO clinical_note_versions (id, note_id, version_number, body_text, copied_material_refs, is_immutable, saved_by, saved_at)
         VALUES (?, ?, 1, ?, ?, 0, ?, ?)`
      ).run(crypto.randomUUID(), noteId, bodyText, JSON.stringify(copiedMaterialRefs ?? []), actor.userId, now);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'note.create_draft',
        resourceType: 'clinical_note',
        resourceId: noteId,
        patientId,
        outcome: 'success',
        minimisedMetadata: { noteType: validType, version: 1 },
      });
    });

    res.status(201).json({ id: noteId, status: 'draft', currentVersion: 1 });
  });

  // Autosave draft with Optimistic Concurrency Control
  app.put('/api/notes/:id/draft', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'note.write')) {
      res.status(403).json({ error: 'Role lacks note editing permission' });
      return;
    }
    const noteId = req.params.id;
    const { title, bodyText, expectedVersion, copiedMaterialRefs } = req.body as {
      title?: string;
      bodyText?: string;
      expectedVersion?: number;
      copiedMaterialRefs?: Array<{ source_record_id: string; label: string }>;
    };

    if (typeof expectedVersion !== 'number' || typeof bodyText !== 'string') {
      res.status(400).json({ error: 'expectedVersion (number) and bodyText are required' });
      return;
    }

    const note = db.prepare('SELECT * FROM clinical_notes WHERE id = ?').get(noteId) as
      | { id: string; patient_id: string; status: string; current_version: number; title: string }
      | undefined;

    if (!note) {
      res.status(404).json({ error: 'Clinical note not found' });
      return;
    }
    if (note.status !== 'draft') {
      res.status(409).json({
        error: `Signed or amended clinical notes are immutable (status="${note.status}"). Create an attributed addendum amendment instead.`,
      });
      return;
    }
    if (note.current_version !== expectedVersion) {
      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'note.draft_conflict',
        resourceType: 'clinical_note',
        resourceId: noteId,
        patientId: note.patient_id,
        outcome: 'conflict',
        reason: `Optimistic concurrency mismatch: expected v${expectedVersion}, current v${note.current_version}`,
      });
      res.status(409).json({
        error: `Concurrency conflict: another clinician saved version ${note.current_version} while you were editing version ${expectedVersion}. Reload latest draft before saving.`,
        currentVersion: note.current_version,
      });
      return;
    }

    const newVersion = note.current_version + 1;
    const now = new Date().toISOString();

    withTransaction(db, () => {
      db.prepare('UPDATE clinical_notes SET current_version = ?, title = ? WHERE id = ?').run(newVersion, title?.trim() || note.title, noteId);
      db.prepare(
        `INSERT INTO clinical_note_versions (id, note_id, version_number, body_text, copied_material_refs, is_immutable, saved_by, saved_at)
         VALUES (?, ?, ?, ?, ?, 0, ?, ?)`
      ).run(crypto.randomUUID(), noteId, newVersion, bodyText, JSON.stringify(copiedMaterialRefs ?? []), actor.userId, now);
    });

    res.json({ id: noteId, currentVersion: newVersion, savedAt: now });
  });

  // Duplicate-safe atomic signing
  app.post('/api/notes/:id/sign', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'note.sign')) {
      res.status(403).json({ error: 'Only authorised clinicians with note.sign permission can sign clinical notes' });
      return;
    }
    if (!actor.mfaVerified) {
      res.status(403).json({ error: 'MFA-verified session is required before signing clinical documentation' });
      return;
    }

    const noteId = req.params.id;
    const { expectedVersion, idempotencyKey, attestationStatement } = req.body as {
      expectedVersion?: number;
      idempotencyKey?: string;
      attestationStatement?: string;
    };

    if (!idempotencyKey?.trim()) {
      res.status(400).json({ error: 'idempotencyKey is required for duplicate-safe signing' });
      return;
    }

    // Idempotent replay check
    const existingSig = db.prepare('SELECT * FROM clinical_signatures WHERE idempotency_key = ?').get(idempotencyKey.trim()) as
      | Record<string, unknown>
      | undefined;
    if (existingSig) {
      res.json({ status: 'signed', duplicateSafeReplay: true, signature: existingSig });
      return;
    }

    const note = db.prepare('SELECT * FROM clinical_notes WHERE id = ?').get(noteId) as
      | { id: string; patient_id: string; status: string; current_version: number }
      | undefined;
    if (!note) {
      res.status(404).json({ error: 'Clinical note not found' });
      return;
    }
    if (note.status !== 'draft') {
      res.status(409).json({ error: `Note is already in status "${note.status}" and cannot be re-signed` });
      return;
    }
    if (typeof expectedVersion === 'number' && note.current_version !== expectedVersion) {
      res.status(409).json({
        error: `Concurrency conflict before signing: expected v${expectedVersion}, current v${note.current_version}`,
        currentVersion: note.current_version,
      });
      return;
    }

    const latestVersion = db
      .prepare('SELECT body_text FROM clinical_note_versions WHERE note_id = ? AND version_number = ?')
      .get(noteId, note.current_version) as { body_text: string };

    const now = new Date().toISOString();
    const sigId = crypto.randomUUID();
    const contentSha256 = crypto.createHash('sha256').update(latestVersion.body_text).digest('hex');
    const statement = attestationStatement?.trim() || 'I clinically attest this record is accurate and complete at the time of signing.';

    withTransaction(db, () => {
      db.prepare('UPDATE clinical_note_versions SET is_immutable = 1 WHERE note_id = ? AND version_number = ?').run(noteId, note.current_version);
      db.prepare("UPDATE clinical_notes SET status = 'signed', signed_at = ?, signed_by = ? WHERE id = ?").run(now, actor.userId, noteId);

      db.prepare(
        `INSERT INTO clinical_signatures (id, note_id, version_number, signer_id, attestation_statement, idempotency_key, content_sha256, signature_algorithm, signed_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'SHA-256-DIGEST-ONLY', ?)`
      ).run(sigId, noteId, note.current_version, actor.userId, statement, idempotencyKey.trim(), contentSha256, now);

      db.prepare(
        `INSERT INTO provenance_records (id, target_table, target_id, activity, agent_user_id, agent_system, recorded_at, detail_json)
         VALUES (?, 'clinical_notes', ?, 'sign', ?, 'aureom_ehr', ?, ?)`
      ).run(crypto.randomUUID(), noteId, actor.userId, now, JSON.stringify({ version: note.current_version, contentSha256 }));

      db.prepare(
        `INSERT INTO integration_outbox_events (id, aggregate_type, aggregate_id, event_type, payload_json, delivery_status, next_attempt_at, created_at)
         VALUES (?, 'clinical_note', ?, 'clinical_note.signed', ?, 'pending', ?, ?)`
      ).run(crypto.randomUUID(), noteId, JSON.stringify({ noteId, patientId: note.patient_id, version: note.current_version, signedAt: now }), now, now);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'note.sign',
        resourceType: 'clinical_note',
        resourceId: noteId,
        patientId: note.patient_id,
        outcome: 'success',
        minimisedMetadata: { version: note.current_version, signatureId: sigId, contentSha256 },
      });
    });

    res.json({ status: 'signed', signatureId: sigId, contentSha256, signedAt: now });
  });

  // Attributed Addendum Amendment
  app.post('/api/notes/:id/amendments', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'note.amend')) {
      res.status(403).json({ error: 'Role lacks permission to amend signed clinical notes' });
      return;
    }
    const noteId = req.params.id;
    const { amendmentType, reason, addendumText, copiedMaterialRefs } = req.body as {
      amendmentType?: string;
      reason?: string;
      addendumText?: string;
      copiedMaterialRefs?: Array<{ source_record_id: string; label: string }>;
    };

    if (!reason?.trim() || !addendumText?.trim()) {
      res.status(400).json({ error: 'reason and addendumText are required' });
      return;
    }

    const note = db.prepare('SELECT id, patient_id, status FROM clinical_notes WHERE id = ?').get(noteId) as
      | { id: string; patient_id: string; status: string }
      | undefined;
    if (!note) {
      res.status(404).json({ error: 'Clinical note not found' });
      return;
    }
    if (note.status !== 'signed' && note.status !== 'amended') {
      res.status(409).json({ error: 'Only signed or previously amended notes can receive linked addendum amendments' });
      return;
    }

    const amdId = crypto.randomUUID();
    const now = new Date().toISOString();
    const contentSha256 = crypto.createHash('sha256').update(addendumText.trim()).digest('hex');
    const validKind = ['addendum', 'correction', 'clarification'].includes(amendmentType || '') ? amendmentType! : 'addendum';

    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO clinical_note_amendments (id, note_id, amendment_type, reason, addendum_text, copied_material_refs, author_id, signed_at, content_sha256)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(amdId, noteId, validKind, reason.trim(), addendumText.trim(), JSON.stringify(copiedMaterialRefs ?? []), actor.userId, now, contentSha256);

      db.prepare("UPDATE clinical_notes SET status = 'amended' WHERE id = ?").run(noteId);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'note.amend',
        resourceType: 'clinical_note_amendment',
        resourceId: amdId,
        patientId: note.patient_id,
        outcome: 'success',
        reason: reason.trim(),
        minimisedMetadata: { noteId, amendmentType: validKind, contentSha256 },
      });
    });

    res.status(201).json({ id: amdId, noteStatus: 'amended', signedAt: now, contentSha256 });
  });

  app.post('/api/notes/:id/enter-in-error', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'note.amend')) {
      res.status(403).json({ error: 'Role lacks permission to mark records entered-in-error' });
      return;
    }
    const { reason } = req.body as { reason?: string };
    if (!reason?.trim()) {
      res.status(400).json({ error: 'An explicit reason is required to mark a record entered-in-error' });
      return;
    }
    const note = db.prepare('SELECT id, patient_id FROM clinical_notes WHERE id = ?').get(req.params.id) as { id: string; patient_id: string } | undefined;
    if (!note) {
      res.status(404).json({ error: 'Clinical note not found' });
      return;
    }
    const now = new Date().toISOString();
    withTransaction(db, () => {
      db.prepare(
        "UPDATE clinical_notes SET status = 'entered_in_error', entered_in_error_reason = ?, entered_in_error_by = ?, entered_in_error_at = ? WHERE id = ?"
      ).run(reason.trim(), actor.userId, now, note.id);

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'note.enter_in_error',
        resourceType: 'clinical_note',
        resourceId: note.id,
        patientId: note.patient_id,
        outcome: 'success',
        reason: reason.trim(),
      });
    });
    res.json({ id: note.id, status: 'entered_in_error' });
  });

  // --- Full Patient Clinical Record (Problems, Allergies, Meds, Observations, Results, Tasks, Docs, Imaging) ---
  app.get('/api/patients/:id/clinical-record', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'clinical_record.view' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason, restricted: true });
      return;
    }

    const patient = db.prepare('SELECT allergy_assessment_status, allergy_assessed_at FROM patients WHERE id = ?').get(patientId) as {
      allergy_assessment_status: string;
      allergy_assessed_at: string | null;
    };

    const problems = (
      db
        .prepare('SELECT p.*, u.full_name as author_name FROM problems p LEFT JOIN users u ON u.id = p.author_id WHERE p.patient_id = ? ORDER BY p.event_time DESC')
        .all(patientId) as Array<Record<string, unknown>>
    ).filter((r) => canAccessResourceSensitivity(db, actor, patientId, String(r.sensitivity_level || 'normal')));

    const allergies = db
      .prepare('SELECT a.*, u.full_name as author_name FROM allergies a LEFT JOIN users u ON u.id = a.author_id WHERE a.patient_id = ? ORDER BY a.recorded_at DESC')
      .all(patientId);

    const medicationStatements = db
      .prepare('SELECT ms.*, u.full_name as recorded_by_name FROM medication_statements ms LEFT JOIN users u ON u.id = ms.recorded_by WHERE ms.patient_id = ? ORDER BY ms.recorded_at DESC')
      .all(patientId);

    const prescriptions = db
      .prepare('SELECT rx.*, u.full_name as prescriber_name FROM prescriptions rx JOIN users u ON u.id = rx.prescriber_id WHERE rx.patient_id = ? ORDER BY rx.authored_at DESC')
      .all(patientId);

    const dispensingRecords = db
      .prepare('SELECT d.*, rx.medication_name FROM dispensing_records d JOIN prescriptions rx ON rx.id = d.prescription_id WHERE d.patient_id = ? ORDER BY d.dispensed_at DESC')
      .all(patientId);

    const administrations = db
      .prepare('SELECT ma.*, rx.medication_name, u.full_name as administered_by_name FROM medication_administrations ma JOIN prescriptions rx ON rx.id = ma.prescription_id JOIN users u ON u.id = ma.administered_by WHERE ma.patient_id = ? ORDER BY ma.administered_at DESC')
      .all(patientId);

    const observations = (
      db
        .prepare(
          `SELECT o.*, s.specimen_type, s.collection_time, u.full_name as author_name
           FROM observations o
           LEFT JOIN specimens s ON s.id = o.specimen_id
           LEFT JOIN users u ON u.id = o.author_id
           WHERE o.patient_id = ? ORDER BY o.effective_time DESC`
        )
        .all(patientId) as Array<Record<string, unknown>>
    ).filter((r) => canAccessResourceSensitivity(db, actor, patientId, String(r.sensitivity_level || 'normal')));

    const results = (
      db
        .prepare(
          `SELECT r.*, s.specimen_type, s.collection_time, u.full_name as reviewer_name
           FROM diagnostic_results r
           LEFT JOIN specimens s ON s.id = r.specimen_id
           LEFT JOIN users u ON u.id = r.reviewed_by
           WHERE r.patient_id = ? ORDER BY r.recorded_at DESC`
        )
        .all(patientId) as Array<Record<string, unknown>>
    )
      .filter((r) => canAccessResourceSensitivity(db, actor, patientId, String(r.sensitivity_level || 'normal')))
      .map((r) => ({ ...r, structuredValues: JSON.parse(String(r.structured_values_json || '[]')) }));

    const tasks = db
      .prepare('SELECT t.*, u.full_name as assignee_name, cu.full_name as creator_name FROM follow_up_tasks t JOIN users u ON u.id = t.assigned_to JOIN users cu ON cu.id = t.created_by WHERE t.patient_id = ? ORDER BY t.created_at DESC')
      .all(patientId);

    const referrals = db
      .prepare('SELECT r.*, u.full_name as referred_by_name FROM referrals r JOIN users u ON u.id = r.referred_by WHERE r.patient_id = ? ORDER BY r.created_at DESC')
      .all(patientId);

    const documents = (
      db
        .prepare('SELECT d.*, u.full_name as uploaded_by_name FROM documents d JOIN users u ON u.id = d.uploaded_by WHERE d.patient_id = ? ORDER BY d.created_at DESC')
        .all(patientId) as Array<Record<string, unknown>>
    ).filter((d) => canAccessResourceSensitivity(db, actor, patientId, String(d.sensitivity_level || 'normal')));

    const imagingReferences = db.prepare('SELECT * FROM imaging_references WHERE patient_id = ? ORDER BY performed_at DESC').all(patientId);

    res.json({
      allergyAssessmentStatus: patient.allergy_assessment_status,
      allergyAssessedAt: patient.allergy_assessed_at,
      problems,
      allergies,
      medicationStatements,
      prescriptions,
      dispensingRecords,
      administrations,
      observations,
      results,
      tasks,
      referrals,
      documents,
      imagingReferences,
    });
  });

  // --- Record Observations, Allergies, Problems, Prescriptions, Tasks, Documents ---
  app.post('/api/patients/:id/observations', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'observation.write')) {
      res.status(403).json({ error: 'Role lacks permission to record observations' });
      return;
    }
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'observation.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }

    const { encounterId, codeSystem, code, displayName, valueNumeric, unit, refRangeLow, refRangeHigh, sourceInterpretation } = req.body as {
      encounterId?: string;
      codeSystem?: string;
      code?: string;
      displayName?: string;
      valueNumeric?: number;
      unit?: string;
      refRangeLow?: number;
      refRangeHigh?: number;
      sourceInterpretation?: string;
    };

    if (!displayName?.trim() || valueNumeric === undefined || !unit?.trim()) {
      res.status(400).json({ error: 'displayName, valueNumeric, and unit are required' });
      return;
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO observations (
          id, patient_id, origin_patient_id, encounter_id, code_system, code, display_name,
          value_numeric, unit, ref_range_low, ref_range_high, source_interpretation,
          status, effective_time, recorded_at, author_id, source_system
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'final', ?, ?, ?, 'aureom_ehr')`
      ).run(
        id,
        patientId,
        patientId,
        encounterId || null,
        codeSystem || 'SNOMED-CT',
        code || '271649006',
        displayName.trim(),
        Number(valueNumeric),
        unit.trim(),
        refRangeLow ?? null,
        refRangeHigh ?? null,
        sourceInterpretation || null,
        now,
        now,
        actor.userId
      );

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'observation.record',
        resourceType: 'observation',
        resourceId: id,
        patientId,
        outcome: 'success',
        minimisedMetadata: { code: code || 'SNOMED-CT', unit },
      });
    });
    res.status(201).json({ id, recordedAt: now });
  });

  app.post('/api/patients/:id/allergies', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'allergy.write')) {
      res.status(403).json({ error: 'Role lacks permission to record allergies' });
      return;
    }
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'allergy.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }

    const { encounterId, substanceCode, substanceName, reactionManifestation, severity, criticality, verificationStatus, sourceSystem } = req.body as Record<string, string | undefined>;
    if (!substanceName?.trim() || !reactionManifestation?.trim()) {
      res.status(400).json({ error: 'substanceName and reactionManifestation are required' });
      return;
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    withTransaction(db, () => {
      db.prepare(
        `INSERT INTO allergies (
          id, patient_id, origin_patient_id, encounter_id, substance_code, substance_name,
          reaction_manifestation, severity, criticality, verification_status, clinical_status,
          author_id, event_time, recorded_at, source_system
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)`
      ).run(
        id,
        patientId,
        patientId,
        encounterId || null,
        substanceCode || '764146007',
        substanceName.trim(),
        reactionManifestation.trim(),
        severity || 'moderate',
        criticality || 'high',
        verificationStatus || 'confirmed',
        actor.userId,
        now,
        now,
        sourceSystem || 'aureom_ehr'
      );

      db.prepare("UPDATE patients SET allergy_assessment_status = 'assessed_present', allergy_assessed_at = ?, allergy_assessed_by = ?, updated_at = ? WHERE id = ?").run(
        now,
        actor.userId,
        now,
        patientId
      );

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'allergy.record',
        resourceType: 'allergy',
        resourceId: id,
        patientId,
        outcome: 'success',
        minimisedMetadata: { severity: severity || 'moderate', verificationStatus: verificationStatus || 'confirmed' },
      });
    });

    res.status(201).json({ id, recordedAt: now });
  });

  app.patch('/api/patients/:id/allergy-status', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'allergy.write')) {
      res.status(403).json({ error: 'Role lacks permission to update allergy assessment status' });
      return;
    }
    const patientId = req.params.id;
    const { status } = req.body as { status?: string };
    if (!['assessed_present', 'assessed_no_known_allergies', 'not_assessed', 'unknown', 'unavailable'].includes(status || '')) {
      res.status(400).json({ error: 'Invalid allergy assessment status' });
      return;
    }
    const validStatus = status!;
    const now = new Date().toISOString();
    db.prepare('UPDATE patients SET allergy_assessment_status = ?, allergy_assessed_at = ?, allergy_assessed_by = ?, updated_at = ? WHERE id = ?').run(
      validStatus,
      now,
      actor.userId,
      now,
      patientId
    );
    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'allergy_status.update',
      resourceType: 'patient',
      resourceId: patientId,
      patientId,
      outcome: 'success',
      minimisedMetadata: { status },
    });
    res.json({ patientId, allergyAssessmentStatus: status });
  });

  app.post('/api/patients/:id/problems', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'note.write')) {
      res.status(403).json({ error: 'Role lacks permission to record problems' });
      return;
    }
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'problem.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }
    const { snomedCode, displayTerm, clinicalStatus, verificationStatus, onsetDate, notes } = req.body as Record<string, string | undefined>;
    if (!displayTerm?.trim()) {
      res.status(400).json({ error: 'displayTerm is required' });
      return;
    }
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO problems (id, patient_id, origin_patient_id, snomed_code, display_term, clinical_status, verification_status, onset_date, author_id, event_time, recorded_at, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, patientId, patientId, snomedCode || '404684003', displayTerm.trim(), clinicalStatus || 'active', verificationStatus || 'confirmed', onsetDate || null, actor.userId, now, now, notes || null);
    res.status(201).json({ id });
  });

  app.post('/api/patients/:id/prescriptions', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'medication.prescribe')) {
      res.status(403).json({ error: 'Only authorised prescribers can author prescriptions' });
      return;
    }
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'prescription.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }
    const { dmdCode, medicationName, doseValue, doseUnit, route, frequency, indication, encounterId } = req.body as Record<string, string | number | undefined>;
    if (!medicationName || !route || !frequency) {
      res.status(400).json({ error: 'medicationName, route, and frequency are required' });
      return;
    }
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO prescriptions (id, patient_id, origin_patient_id, encounter_id, dmd_code, medication_name, dose_value, dose_unit, route, frequency, indication, prescriber_id, status, authored_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)`
    ).run(id, patientId, patientId, encounterId || null, String(dmdCode || '317304008'), String(medicationName), doseValue ? Number(doseValue) : null, doseUnit ? String(doseUnit) : null, String(route), String(frequency), indication ? String(indication) : null, actor.userId, now);
    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'medication.prescribe',
      resourceType: 'prescription',
      resourceId: id,
      patientId,
      outcome: 'success',
    });
    res.status(201).json({ id });
  });

  app.post('/api/patients/:id/medication-statements', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'med_statement.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }
    const { medicationName, reportedDoseText, informationSource } = req.body as Record<string, string | undefined>;
    if (!medicationName?.trim() || !reportedDoseText?.trim()) {
      res.status(400).json({ error: 'medicationName and reportedDoseText are required' });
      return;
    }
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO medication_statements (id, patient_id, origin_patient_id, dmd_code, medication_name, reported_dose_text, information_source, status, event_time, recorded_at, recorded_by)
       VALUES (?, ?, ?, '000000', ?, ?, ?, 'active', ?, ?, ?)`
    ).run(id, patientId, patientId, medicationName.trim(), reportedDoseText.trim(), informationSource || 'patient_reported', now, now, actor.userId);
    res.status(201).json({ id });
  });

  app.post('/api/patients/:id/administrations', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'medication.administer') && !hasPermission(actor, 'medication.prescribe')) {
      res.status(403).json({ error: 'Role lacks permission to record medication administrations' });
      return;
    }
    const patientId = req.params.id;
    const { prescriptionId, doseGiven, route, status, notes } = req.body as Record<string, string | undefined>;
    if (!prescriptionId || !doseGiven || !route) {
      res.status(400).json({ error: 'prescriptionId, doseGiven, and route are required' });
      return;
    }
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO medication_administrations (id, prescription_id, patient_id, dose_given, route, administered_by, administered_at, status, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, prescriptionId, patientId, doseGiven, route, actor.userId, now, status || 'completed', notes || null);
    res.status(201).json({ id });
  });

  // --- Diagnostic Results Review & Follow-up Tasks ---
  app.post('/api/results/:id/review', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const resultId = req.params.id;
    const { reviewState, followUpTitle, followUpInstructions, assignedToUserId } = req.body as {
      reviewState?: string;
      followUpTitle?: string;
      followUpInstructions?: string;
      assignedToUserId?: string;
    };

    if (!['viewed', 'acknowledged', 'assigned_for_followup', 'action_completed'].includes(reviewState || '')) {
      res.status(400).json({ error: 'Invalid reviewState' });
      return;
    }

    if (reviewState !== 'viewed' && !hasPermission(actor, 'result.review')) {
      res.status(403).json({ error: 'Role lacks permission to acknowledge or assign follow-up on diagnostic results' });
      return;
    }

    const result = db.prepare('SELECT id, patient_id, sensitivity_level FROM diagnostic_results WHERE id = ?').get(resultId) as
      | { id: string; patient_id: string; sensitivity_level: string }
      | undefined;
    if (!result) {
      res.status(404).json({ error: 'Diagnostic result not found' });
      return;
    }
    if (!canAccessResourceSensitivity(db, actor, result.patient_id, result.sensitivity_level)) {
      res.status(403).json({ error: 'Access denied to this diagnostic result' });
      return;
    }

    const validReviewState = reviewState!;
    const now = new Date().toISOString();
    let createdTaskId: string | null = null;

    withTransaction(db, () => {
      db.prepare('UPDATE diagnostic_results SET review_state = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?').run(validReviewState, actor.userId, now, resultId);

      if (reviewState === 'assigned_for_followup' && followUpTitle?.trim()) {
        createdTaskId = crypto.randomUUID();
        db.prepare(
          `INSERT INTO follow_up_tasks (id, patient_id, linked_result_id, title, instructions, priority, status, assigned_to, created_by, due_at, created_at)
           VALUES (?, ?, ?, ?, ?, 'urgent', 'open', ?, ?, ?, ?)`
        ).run(
          createdTaskId,
          result.patient_id,
          resultId,
          followUpTitle.trim(),
          followUpInstructions?.trim() || 'Follow up on diagnostic result',
          assignedToUserId || actor.userId,
          actor.userId,
          new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          now
        );
      }

      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'result.review_state_update',
        resourceType: 'diagnostic_result',
        resourceId: resultId,
        patientId: result.patient_id,
        outcome: 'success',
        minimisedMetadata: { reviewState, createdTaskId },
      });
    });

    res.json({ resultId, reviewState, createdTaskId });
  });

  app.post('/api/patients/:id/tasks', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'task.create' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }
    const { title, instructions, priority, assignedTo } = req.body as Record<string, string | undefined>;
    if (!title?.trim()) {
      res.status(400).json({ error: 'Task title is required' });
      return;
    }
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO follow_up_tasks (id, patient_id, title, instructions, priority, status, assigned_to, created_by, due_at, created_at)
       VALUES (?, ?, ?, ?, ?, 'open', ?, ?, ?, ?)`
    ).run(id, patientId, title.trim(), instructions?.trim() || '', priority || 'routine', assignedTo || actor.userId, actor.userId, new Date(Date.now() + 48 * 3600 * 1000).toISOString(), now);
    res.status(201).json({ id });
  });

  app.patch('/api/tasks/:id', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const { status } = req.body as { status?: string };
    if (!['open', 'in_progress', 'completed', 'cancelled'].includes(status || '')) {
      res.status(400).json({ error: 'Invalid task status' });
      return;
    }
    const validTaskStatus = status!;
    const completedAt = validTaskStatus === 'completed' ? new Date().toISOString() : null;
    db.prepare('UPDATE follow_up_tasks SET status = ?, completed_at = COALESCE(?, completed_at) WHERE id = ?').run(validTaskStatus, completedAt, req.params.id);
    res.json({ id: req.params.id, status: validTaskStatus, completedAt });
  });

  // --- Protected Documents (Patient-Scoped Storage) ---
  app.post('/api/patients/:id/documents', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'document.write')) {
      res.status(403).json({ error: 'Role lacks permission to upload clinical documents' });
      return;
    }
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'document.upload' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason });
      return;
    }
    const { title, documentType, fileName, contentText, sensitivityLevel } = req.body as Record<string, string | undefined>;
    if (!title?.trim() || !contentText?.trim()) {
      res.status(400).json({ error: 'title and contentText are required' });
      return;
    }
    const stored = storePatientObject(patientId, fileName || `${title.trim().slice(0, 24)}.txt`, Buffer.from(contentText, 'utf8'));
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO documents (id, patient_id, origin_patient_id, title, document_type, mime_type, byte_size, object_storage_key, sha256_checksum, uploaded_by, sensitivity_level, created_at)
       VALUES (?, ?, ?, ?, ?, 'text/plain', ?, ?, ?, ?, ?, ?)`
    ).run(id, patientId, patientId, title.trim(), documentType || 'clinical_correspondence', stored.byteSize, stored.objectKey, stored.sha256, actor.userId, sensitivityLevel === 'restricted' ? 'restricted' : 'normal', now);

    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'document.upload',
      resourceType: 'document',
      resourceId: id,
      patientId,
      outcome: 'success',
      minimisedMetadata: { sha256: stored.sha256, byteSize: stored.byteSize },
    });

    res.status(201).json({ id, sha256Checksum: stored.sha256, byteSize: stored.byteSize });
  });

  app.get('/api/documents/:id/download', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id) as
      | { id: string; patient_id: string; title: string; mime_type: string; object_storage_key: string; sha256_checksum: string; sensitivity_level: string }
      | undefined;
    if (!doc) {
      res.status(404).json({ error: 'Document not found' });
      return;
    }
    if (!canAccessResourceSensitivity(db, actor, doc.patient_id, doc.sensitivity_level)) {
      appendAuditEvent(db, {
        actorUserId: actor.userId,
        actorRole: actor.roleCode,
        organisationId: actor.organisationId,
        action: 'document.download',
        resourceType: 'document',
        resourceId: doc.id,
        patientId: doc.patient_id,
        outcome: 'denied',
        reason: 'Patient/sensitivity access restriction denied document download',
      });
      res.status(403).json({ error: 'Access denied to restricted document' });
      return;
    }

    const { content, checksumValid } = readProtectedPatientObject(doc.object_storage_key, doc.sha256_checksum);
    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'document.download',
      resourceType: 'document',
      resourceId: doc.id,
      patientId: doc.patient_id,
      outcome: 'success',
      minimisedMetadata: { checksumValid },
    });

    res.json({
      id: doc.id,
      title: doc.title,
      mimeType: doc.mime_type,
      checksumValid,
      sha256: doc.sha256_checksum,
      contentText: content.toString('utf8'),
    });
  });

  // --- Chronological Clinical Timeline ---
  app.get('/api/patients/:id/timeline', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    const access = evaluatePatientAccess(db, actor, patientId, { actionName: 'timeline.view' });
    if (!access.allowed) {
      res.status(403).json({ error: access.reason, restricted: true });
      return;
    }
    const filterParam = String(req.query.categories || '').trim();
    const allowedCategories = filterParam ? new Set(filterParam.split(',')) : null;

    type TimelineEntry = {
      id: string;
      category: 'encounters' | 'notes' | 'medications' | 'results' | 'observations' | 'problems' | 'documents' | 'imaging';
      occurredAt: string;
      title: string;
      summary: string;
      status: string;
      sourceSystem: string;
      targetRoute: string;
    };
    const items: TimelineEntry[] = [];

    const encs = db.prepare('SELECT id, started_at, encounter_class, status, reason_text, source_system FROM encounters WHERE patient_id = ?').all(patientId) as Array<Record<string, string>>;
    for (const e of encs) {
      items.push({ id: e.id, category: 'encounters', occurredAt: e.started_at, title: `${e.encounter_class} encounter`, summary: e.reason_text, status: e.status, sourceSystem: e.source_system, targetRoute: 'encounters' });
    }

    const notes = db.prepare('SELECT id, event_time, title, note_type, status, source_system, sensitivity_level FROM clinical_notes WHERE patient_id = ?').all(patientId) as Array<Record<string, string>>;
    for (const n of notes) {
      if (!canAccessResourceSensitivity(db, actor, patientId, n.sensitivity_level)) continue;
      items.push({ id: n.id, category: 'notes', occurredAt: n.event_time, title: n.title, summary: `${n.note_type} note`, status: n.status, sourceSystem: n.source_system, targetRoute: 'notes' });
    }

    const rxs = db.prepare('SELECT id, authored_at, medication_name, route, frequency, status, source_system FROM prescriptions WHERE patient_id = ?').all(patientId) as Array<Record<string, string>>;
    for (const rx of rxs) {
      items.push({ id: rx.id, category: 'medications', occurredAt: rx.authored_at, title: `Prescription: ${rx.medication_name}`, summary: `${rx.route} · ${rx.frequency}`, status: rx.status, sourceSystem: rx.source_system, targetRoute: 'medications' });
    }

    const results = db.prepare('SELECT id, effective_time, report_title, result_summary, status, review_state, source_system, sensitivity_level FROM diagnostic_results WHERE patient_id = ?').all(patientId) as Array<Record<string, string>>;
    for (const r of results) {
      if (!canAccessResourceSensitivity(db, actor, patientId, r.sensitivity_level)) continue;
      items.push({ id: r.id, category: 'results', occurredAt: r.effective_time, title: r.report_title, summary: r.result_summary, status: `${r.status} · ${r.review_state}`, sourceSystem: r.source_system, targetRoute: 'results' });
    }

    const obs = db.prepare('SELECT id, effective_time, display_name, value_numeric, unit, status, source_system, sensitivity_level FROM observations WHERE patient_id = ?').all(patientId) as Array<Record<string, unknown>>;
    for (const o of obs) {
      if (!canAccessResourceSensitivity(db, actor, patientId, String(o.sensitivity_level))) continue;
      items.push({ id: String(o.id), category: 'observations', occurredAt: String(o.effective_time), title: String(o.display_name), summary: `${o.value_numeric} ${o.unit}`, status: String(o.status), sourceSystem: String(o.source_system), targetRoute: 'observations' });
    }

    const docs = db.prepare('SELECT id, created_at, title, document_type, source_system, sensitivity_level FROM documents WHERE patient_id = ?').all(patientId) as Array<Record<string, string>>;
    for (const d of docs) {
      if (!canAccessResourceSensitivity(db, actor, patientId, d.sensitivity_level)) continue;
      items.push({ id: d.id, category: 'documents', occurredAt: d.created_at, title: d.title, summary: d.document_type, status: 'stored', sourceSystem: d.source_system, targetRoute: 'documents' });
    }

    const imgs = db.prepare('SELECT id, performed_at, study_description, modality, status FROM imaging_references WHERE patient_id = ?').all(patientId) as Array<Record<string, string>>;
    for (const im of imgs) {
      items.push({ id: im.id, category: 'imaging', occurredAt: im.performed_at, title: `${im.modality}: ${im.study_description}`, summary: 'External PACS imaging reference', status: im.status, sourceSystem: 'pacs_archive', targetRoute: 'documents' });
    }

    const filtered = items
      .filter((i) => (!allowedCategories ? true : allowedCategories.has(i.category)))
      .sort((a, b) => (a.occurredAt < b.occurredAt ? 1 : -1));

    res.json({ timeline: filtered });
  });

  // --- Permission-Aware Search (Zero Leakage) ---
  app.get('/api/search', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const q = String(req.query.q || '').trim();
    const patientFilter = req.query.patientId ? String(req.query.patientId) : null;
    if (!q || q.length < 2) {
      res.json({ results: [], totalCount: 0 });
      return;
    }

    const pattern = `%${q}%`;
    const hits: Array<{
      id: string;
      patientId: string;
      patientName: string;
      recordType: string;
      title: string;
      snippet: string;
      date: string;
      status: string;
      targetTab: string;
    }> = [];

    // 1. Notes search (apply sensitivity & patient access BEFORE counting/returning)
    const noteHits = db
      .prepare(
        `SELECT cn.id, cn.patient_id, cn.title, cn.status, cn.event_time, cn.sensitivity_level,
                v.body_text, pn.given_names || ' ' || pn.family_name as patient_name
         FROM clinical_notes cn
         JOIN clinical_note_versions v ON v.note_id = cn.id AND v.version_number = cn.current_version
         JOIN patients p ON p.id = cn.patient_id
         JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
         WHERE p.organisation_id = ? AND p.record_status = 'active'
           ${patientFilter ? 'AND cn.patient_id = ?' : ''}
           AND (cn.title LIKE ? OR v.body_text LIKE ?)`
      )
      .all(...(patientFilter ? [actor.organisationId, patientFilter, pattern, pattern] : [actor.organisationId, pattern, pattern])) as Array<Record<string, string>>;

    for (const r of noteHits) {
      if (!canAccessResourceSensitivity(db, actor, r.patient_id, r.sensitivity_level)) continue;
      hits.push({
        id: r.id,
        patientId: r.patient_id,
        patientName: r.patient_name,
        recordType: 'Clinical Note',
        title: r.title,
        snippet: r.body_text.slice(0, 140),
        date: r.event_time,
        status: r.status,
        targetTab: 'notes',
      });
    }

    // 2. Results search
    const resHits = db
      .prepare(
        `SELECT dr.id, dr.patient_id, dr.report_title, dr.result_summary, dr.status, dr.effective_time, dr.sensitivity_level,
                pn.given_names || ' ' || pn.family_name as patient_name
         FROM diagnostic_results dr
         JOIN patients p ON p.id = dr.patient_id
         JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
         WHERE p.organisation_id = ? AND p.record_status = 'active'
           ${patientFilter ? 'AND dr.patient_id = ?' : ''}
           AND (dr.report_title LIKE ? OR dr.result_summary LIKE ?)`
      )
      .all(...(patientFilter ? [actor.organisationId, patientFilter, pattern, pattern] : [actor.organisationId, pattern, pattern])) as Array<Record<string, string>>;

    for (const r of resHits) {
      if (!canAccessResourceSensitivity(db, actor, r.patient_id, r.sensitivity_level)) continue;
      hits.push({
        id: r.id,
        patientId: r.patient_id,
        patientName: r.patient_name,
        recordType: 'Diagnostic Result',
        title: r.report_title,
        snippet: r.result_summary.slice(0, 140),
        date: r.effective_time,
        status: r.status,
        targetTab: 'results',
      });
    }

    // 3. Problems search
    const probHits = db
      .prepare(
        `SELECT pr.id, pr.patient_id, pr.display_term, pr.snomed_code, pr.clinical_status, pr.event_time, pr.sensitivity_level,
                pn.given_names || ' ' || pn.family_name as patient_name
         FROM problems pr
         JOIN patients p ON p.id = pr.patient_id
         JOIN patient_names pn ON pn.patient_id = p.id AND pn.effective_to IS NULL AND pn.name_use = 'official'
         WHERE p.organisation_id = ? AND p.record_status = 'active'
           ${patientFilter ? 'AND pr.patient_id = ?' : ''}
           AND (pr.display_term LIKE ? OR pr.snomed_code LIKE ?)`
      )
      .all(...(patientFilter ? [actor.organisationId, patientFilter, pattern, pattern] : [actor.organisationId, pattern, pattern])) as Array<Record<string, string>>;

    for (const r of probHits) {
      if (!canAccessResourceSensitivity(db, actor, r.patient_id, r.sensitivity_level)) continue;
      hits.push({
        id: r.id,
        patientId: r.patient_id,
        patientName: r.patient_name,
        recordType: 'Problem / Diagnosis',
        title: r.display_term,
        snippet: `SNOMED CT: ${r.snomed_code}`,
        date: r.event_time,
        status: r.clinical_status,
        targetTab: 'problems',
      });
    }

    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'search.query',
      resourceType: 'search',
      patientId: patientFilter,
      outcome: 'success',
      minimisedMetadata: { authorisedHitsCount: hits.length, queryLength: q.length },
    });

    res.json({ results: hits, totalCount: hits.length });
  });

  // --- Interoperability (UK Core FHIR R4) ---
  app.post('/api/fhir/ingest', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'fhir.ingest') && !hasPermission(actor, 'fhir.manage')) {
      res.status(403).json({ error: 'Role lacks interoperability ingestion permission' });
      return;
    }
    try {
      const bundle = req.body as FhirBundleInput;
      const sourceSystem = bundle.sourceSystem || 'berkshire_pathology_lis';
      const outcome = deps.ingestFhirBundle(db, sourceSystem, bundle, actor.userId, actor.roleCode, actor.organisationId);
      res.json(outcome);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'FHIR ingestion error' });
    }
  });

  app.get('/api/interoperability/inbox', auth, (_req: AuthedRequest, res: Response) => {
    const inbox = db.prepare('SELECT * FROM integration_inbox_messages ORDER BY received_at DESC LIMIT 30').all();
    const outbox = db.prepare('SELECT * FROM integration_outbox_events ORDER BY created_at DESC LIMIT 30').all();
    res.json({ inbox, outbox });
  });

  app.post('/api/interoperability/inbox/:id/retry', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const msg = db.prepare('SELECT * FROM integration_inbox_messages WHERE id = ?').get(req.params.id) as
      | { id: string; source_system: string; raw_payload_json: string }
      | undefined;
    if (!msg) {
      res.status(404).json({ error: 'Inbox message not found' });
      return;
    }
    const payload = JSON.parse(msg.raw_payload_json) as FhirBundleInput;
    delete payload.simulateFailure;
    const result = deps.ingestFhirBundle(db, msg.source_system, payload, actor.userId, actor.roleCode, actor.organisationId);
    res.json(result);
  });

  // --- Administration, Audit, Legal Holds, AI Config, Backup/Restore Drill ---
  app.get('/api/admin/overview', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const org = db.prepare('SELECT * FROM organisations WHERE id = ?').get(actor.organisationId);
    const sessions = db
      .prepare(
        `SELECT s.id, s.mfa_verified, s.mfa_method, s.issued_at, s.expires_at, s.revoked_at, u.full_name, u.role_code
         FROM user_sessions s JOIN users u ON u.id = s.user_id
         ORDER BY s.issued_at DESC LIMIT 20`
      )
      .all();
    const breakGlassGrants = db
      .prepare(
        `SELECT g.*, u.full_name as user_name, u.role_code, pn.given_names || ' ' || pn.family_name as patient_name
         FROM emergency_access_grants g
         JOIN users u ON u.id = g.user_id
         JOIN patient_names pn ON pn.patient_id = g.patient_id AND pn.effective_to IS NULL AND pn.name_use = 'official'
         ORDER BY g.granted_at DESC`
      )
      .all();
    const retentionPolicies = db.prepare('SELECT * FROM retention_policies WHERE organisation_id = ?').all(actor.organisationId);
    const legalHolds = db
      .prepare(
        `SELECT lh.*, pn.given_names || ' ' || pn.family_name as patient_name, u.full_name as placed_by_name
         FROM legal_holds lh
         JOIN patient_names pn ON pn.patient_id = lh.patient_id AND pn.effective_to IS NULL AND pn.name_use = 'official'
         JOIN users u ON u.id = lh.placed_by
         ORDER BY lh.placed_at DESC`
      )
      .all();
    const backupDrills = db.prepare('SELECT * FROM backup_restore_drills ORDER BY started_at DESC LIMIT 10').all();
    const auditChain = deps.verifyAuditHashChain(db);

    res.json({
      organisation: org,
      sessions,
      breakGlassGrants,
      retentionPolicies,
      legalHolds,
      backupDrills,
      auditChain,
    });
  });

  app.get('/api/admin/audit', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const canReadAll = hasPermission(actor, 'audit.read_all');
    const events = canReadAll
      ? db
          .prepare(
            `SELECT ae.*, u.full_name as actor_name
             FROM audit_events ae
             LEFT JOIN users u ON u.id = ae.actor_user_id
             ORDER BY ae.seq_id DESC LIMIT 100`
          )
          .all()
      : db
          .prepare(
            `SELECT ae.*, u.full_name as actor_name
             FROM audit_events ae
             LEFT JOIN users u ON u.id = ae.actor_user_id
             WHERE ae.actor_user_id = ?
             ORDER BY ae.seq_id DESC LIMIT 50`
          )
          .all(actor.userId);

    res.json({ events, scope: canReadAll ? 'organisation_all' : 'actor_own_only', verification: deps.verifyAuditHashChain(db) });
  });

  app.patch('/api/admin/ai-config', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'ai.configure')) {
      res.status(403).json({ error: 'Only Caldicott Guardian / IG Lead can enable or disable the AI assistant adapter' });
      return;
    }
    const { enabled } = req.body as { enabled?: boolean };
    const now = new Date().toISOString();
    db.prepare('UPDATE organisations SET ai_assistant_enabled = ?, updated_at = ? WHERE id = ?').run(enabled ? 1 : 0, now, actor.organisationId);
    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'admin.ai_config_change',
      resourceType: 'organisation',
      resourceId: actor.organisationId,
      outcome: 'success',
      minimisedMetadata: { aiAssistantEnabled: Boolean(enabled) },
    });
    res.json({ aiAssistantEnabled: Boolean(enabled) });
  });

  app.post('/api/admin/break-glass/:id/review', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'break_glass.review')) {
      res.status(403).json({ error: 'Only Caldicott Guardian / IG Lead can review Break-Glass grants' });
      return;
    }
    const { status, notes } = req.body as { status?: string; notes?: string };
    if (!['justified', 'flagged_inappropriate'].includes(status || '')) {
      res.status(400).json({ error: 'Invalid review status' });
      return;
    }
    const validReviewStatus = status!;
    const now = new Date().toISOString();
    db.prepare('UPDATE emergency_access_grants SET ig_review_status = ?, ig_reviewed_by = ?, ig_reviewed_at = ?, ig_review_notes = ? WHERE id = ?').run(
      validReviewStatus,
      actor.userId,
      now,
      notes || null,
      req.params.id
    );
    appendAuditEvent(db, {
      actorUserId: actor.userId,
      actorRole: actor.roleCode,
      organisationId: actor.organisationId,
      action: 'break_glass.ig_review',
      resourceType: 'emergency_access_grant',
      resourceId: req.params.id,
      outcome: 'success',
      minimisedMetadata: { status },
    });
    res.json({ id: req.params.id, igReviewStatus: status });
  });

  app.post('/api/admin/legal-holds', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'retention.manage')) {
      res.status(403).json({ error: 'Only Caldicott Guardian / IG Lead can place legal holds' });
      return;
    }
    const { patientId, reason } = req.body as { patientId?: string; reason?: string };
    if (!patientId || !reason?.trim()) {
      res.status(400).json({ error: 'patientId and reason are required' });
      return;
    }
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare('INSERT INTO legal_holds (id, patient_id, reason, placed_by, placed_at, is_active) VALUES (?, ?, ?, ?, ?, 1)').run(
      id,
      patientId,
      reason.trim(),
      actor.userId,
      now
    );
    res.status(201).json({ id, placedAt: now });
  });

  app.post('/api/admin/backup-restore-drill', auth, async (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    if (!hasPermission(actor, 'retention.manage') && !hasPermission(actor, 'audit.read_all')) {
      res.status(403).json({ error: 'Only Caldicott Guardian / IG Lead can trigger an isolated backup restore drill' });
      return;
    }
    try {
      const drill = await deps.runBackupAndIsolatedRestoreDrill(db, actor);
      res.json(drill);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : 'Backup drill failed' });
    }
  });

  app.post('/api/patients/:id/consent', auth, (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const patientId = req.params.id;
    const { purpose, decision, scopeNotes } = req.body as { purpose?: string; decision?: string; scopeNotes?: string };
    if (!['direct_care', 'national_summary_care', 'research_opt_in', 'hie_exchange', 'ai_draft_assistance'].includes(purpose || '')) {
      res.status(400).json({ error: 'Invalid consent purpose' });
      return;
    }
    if (!['permit', 'deny', 'ask'].includes(decision || '')) {
      res.status(400).json({ error: 'Invalid consent decision' });
      return;
    }
    const validPurpose = purpose!;
    const validDecision = decision!;
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    withTransaction(db, () => {
      db.prepare('UPDATE consent_directives SET effective_to = ? WHERE patient_id = ? AND purpose = ? AND effective_to IS NULL').run(now, patientId, validPurpose);
      db.prepare(
        'INSERT INTO consent_directives (id, patient_id, purpose, decision, scope_notes, recorded_by, effective_from) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).run(id, patientId, validPurpose, validDecision, scopeNotes || null, actor.userId, now);
    });
    res.status(201).json({ id, purpose: validPurpose, decision: validDecision });
  });

  app.post('/api/patients/:id/ai-summary', auth, async (req: AuthedRequest, res: Response) => {
    const actor = req.actor!;
    const { prompt } = req.body as { prompt?: string };
    try {
      const result = await deps.generateSourceLinkedSummary(db, actor, req.params.id, prompt || 'Summarise key clinical problems, allergies (preserving conflicts), recent results, and active plans.');
      res.json(result);
    } catch (err) {
      res.status(403).json({ error: err instanceof Error ? err.message : 'AI assistant error' });
    }
  });
}
