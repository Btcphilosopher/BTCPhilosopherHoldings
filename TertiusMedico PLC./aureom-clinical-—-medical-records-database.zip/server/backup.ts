import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { backup, DatabaseSync } from 'node:sqlite';
import { appendAuditEvent } from './audit.ts';
import type { AuthenticatedActor } from './auth.ts';
import { getStorageRoot, resolveProtectedObjectPath } from './storage.ts';

export interface BackupDrillResult {
  drillId: string;
  startedAt: string;
  completedAt: string;
  measuredRtoMs: number;
  targetRpoSeconds: number;
  targetRtoSeconds: number;
  integrityCheckPassed: boolean;
  integrityMessage: string;
  verifiedRowCounts: Record<string, number>;
  attachmentsVerified: number;
  attachmentFailures: number;
  isolatedRestorePath: string;
}

export async function runBackupAndIsolatedRestoreDrill(
  db: DatabaseSync,
  actor: AuthenticatedActor
): Promise<BackupDrillResult> {
  const drillId = crypto.randomUUID();
  const startedMs = Date.now();
  const startedAt = new Date(startedMs).toISOString();

  const restoreRoot = path.resolve('./data/restore_verification', drillId);
  fs.mkdirSync(restoreRoot, { recursive: true });
  const restoredDbPath = path.join(restoreRoot, 'restored_aureom.sqlite');
  const restoredStorageRoot = path.join(restoreRoot, 'object_storage');
  fs.mkdirSync(restoredStorageRoot, { recursive: true });

  // 1. Perform online SQLite backup to isolated file
  await backup(db, restoredDbPath);

  // 2. Copy protected object storage files to isolated restore directory & verify SHA-256
  const docs = db.prepare('SELECT id, object_storage_key, sha256_checksum FROM documents').all() as Array<{
    id: string;
    object_storage_key: string;
    sha256_checksum: string;
  }>;

  let attachmentsVerified = 0;
  let attachmentFailures = 0;
  for (const doc of docs) {
    try {
      const srcPath = resolveProtectedObjectPath(doc.object_storage_key);
      const destPath = path.resolve(restoredStorageRoot, doc.object_storage_key);
      if (!destPath.startsWith(restoredStorageRoot + path.sep)) {
        attachmentFailures++;
        continue;
      }
      fs.mkdirSync(path.dirname(destPath), { recursive: true });
      fs.copyFileSync(srcPath, destPath);
      const buf = fs.readFileSync(destPath);
      const actualHash = crypto.createHash('sha256').update(buf).digest('hex');
      if (actualHash === doc.sha256_checksum) {
        attachmentsVerified++;
      } else {
        attachmentFailures++;
      }
    } catch {
      attachmentFailures++;
    }
  }

  // 3. Open restored DB in isolation and verify integrity & row counts
  const isolatedDb = new DatabaseSync(restoredDbPath, { readOnly: true });
  let integrityCheckPassed = false;
  let integrityMessage = 'unknown';
  const verifiedRowCounts: Record<string, number> = {};

  try {
    const ic = isolatedDb.prepare('PRAGMA integrity_check;').get() as { integrity_check: string };
    integrityMessage = ic?.integrity_check ?? 'failed';
    integrityCheckPassed = integrityMessage === 'ok' && attachmentFailures === 0;

    const tables = ['patients', 'encounters', 'clinical_notes', 'diagnostic_results', 'allergies', 'prescriptions', 'documents', 'audit_events'];
    for (const table of tables) {
      const c = isolatedDb.prepare(`SELECT COUNT(*) as c FROM ${table}`).get() as { c: number };
      verifiedRowCounts[table] = c.c;
    }
  } finally {
    isolatedDb.close();
  }

  const completedMs = Date.now();
  const completedAt = new Date(completedMs).toISOString();
  const measuredRtoMs = completedMs - startedMs;

  db.prepare(
    `INSERT INTO backup_restore_drills (
      id, started_at, completed_at, target_rpo_seconds, target_rto_seconds,
      measured_rto_ms, verified_row_counts_json, attachments_verified,
      integrity_check_passed, performed_by, notes
    ) VALUES (?, ?, ?, 300, 900, ?, ?, ?, ?, ?, ?)`
  ).run(
    drillId,
    startedAt,
    completedAt,
    measuredRtoMs,
    JSON.stringify(verifiedRowCounts),
    attachmentsVerified,
    integrityCheckPassed ? 1 : 0,
    actor.userId,
    `Isolated restore drill verified (${integrityMessage}); storage root ${getStorageRoot()}`
  );

  appendAuditEvent(db, {
    actorUserId: actor.userId,
    actorRole: actor.roleCode,
    organisationId: actor.organisationId,
    action: 'admin.backup_restore_drill',
    resourceType: 'backup_restore_drill',
    resourceId: drillId,
    outcome: integrityCheckPassed ? 'success' : 'error',
    minimisedMetadata: { measuredRtoMs, attachmentsVerified, attachmentFailures, integrityCheckPassed },
  });

  return {
    drillId,
    startedAt,
    completedAt,
    measuredRtoMs,
    targetRpoSeconds: 300,
    targetRtoSeconds: 900,
    integrityCheckPassed,
    integrityMessage,
    verifiedRowCounts,
    attachmentsVerified,
    attachmentFailures,
    isolatedRestorePath: restoredDbPath,
  };
}
