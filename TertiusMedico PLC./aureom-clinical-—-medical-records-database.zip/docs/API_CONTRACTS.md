# Aureom Clinical — API Contracts

All protected endpoints require `Authorization: Bearer <token>` issued via `/api/auth/login` with MFA verification (`mfaVerified = true` required for clinical signing and privileged mutations).

## Authentication & Sessions
- `GET /api/auth/directory` — Lists active clinic staff accounts via identity adapter.
- `POST /api/auth/login` — `{ userId, otpCode }` → `{ token, sessionId, expiresAt, actor }`.
- `GET /api/auth/session` — Returns active session, permissions, and active Break-Glass grants.
- `POST /api/auth/logout` — Revokes current session token.
- `POST /api/auth/sessions/:id/revoke` — Administrative or self-service session revocation.

## Patients & Identity Governance
- `GET /api/patients?q=...` — Permission-aware patient directory search.
- `POST /api/patients` — Registers patient; validates NHS Number with Modulus-11; assigns independent UUID + `AUR-xxxxxx` MRN; flags DOB+surname collisions in `patient_duplicate_candidates` without auto-merging.
- `GET /api/patients/:id` — Returns full patient summary, identifier provenance, name/address history, encounters, consents, and active restrictions. Returns `403` with `restricted: true` if policy denies access.
- `PATCH /api/patients/:id/demographics` — Closes previous official name/address effective window and inserts new version.
- `POST /api/patients/:id/break-glass` — `{ reason }` (≥10 chars) → creates 2-hour `emergency_access_grants` row, logs audit event, queues for Caldicott review.
- `GET /api/patients-governance/duplicates` — Lists duplicate candidates and merge/unmerge history.
- `POST /api/patients-governance/merge` — Moves records to target preserving `origin_patient_id` and recording `moved_records_snapshot`.
- `POST /api/patients-governance/unmerge/:mergeEventId` — Reverses a mistaken merge atomically using `moved_records_snapshot`.

## Encounters & Clinical Notes
- `POST /api/encounters` / `PATCH /api/encounters/:id/status`
- `GET /api/notes?patientId=...` — Sensitivity-filtered clinical notes with versions, signature, and amendments.
- `POST /api/notes` — Creates `draft` note v1 with optional `copiedMaterialRefs`.
- `PUT /api/notes/:id/draft` — `{ title, bodyText, expectedVersion }`. Enforces optimistic concurrency (`409 Conflict` on version mismatch or if note is no longer `draft`).
- `POST /api/notes/:id/sign` — `{ expectedVersion, idempotencyKey, attestationStatement }`. Requires `note.sign` + `mfaVerified`. Duplicate `idempotencyKey` returns idempotent replay without creating duplicate signatures/audit rows. Atomically locks `clinical_note_versions.is_immutable = true`, inserts `clinical_signatures`, `provenance_records`, `integration_outbox_events`, and `audit_events`.
- `POST /api/notes/:id/amendments` — Appends attributed `addendum`/`correction`/`clarification` to signed/amended notes.
- `POST /api/notes/:id/enter-in-error` — Marks note `entered_in_error` with mandatory reason; retains full history.

## Clinical Assertions, Timeline & Search
- `GET /api/patients/:id/clinical-record` — Returns problems, allergies + explicit `allergyAssessmentStatus`, separated medication tables, observations, results, tasks, documents, imaging references.
- `POST /api/patients/:id/observations`, `allergies`, `problems`, `prescriptions`, `medication-statements`, `administrations`, `tasks`, `documents`
- `PATCH /api/patients/:id/allergy-status` — Explicit `assessed_present | assessed_no_known_allergies | not_assessed | unknown | unavailable`.
- `POST /api/results/:id/review` — Transitions `review_state` (`viewed`, `acknowledged`, `assigned_for_followup`, `action_completed`).
- `GET /api/documents/:id/download` — Verifies patient/sensitivity permission + SHA-256 checksum before returning content; writes audit entry.
- `GET /api/patients/:id/timeline?categories=...` — Chronological unified timeline.
- `GET /api/search?q=...` — Applies patient & resource sensitivity access checks *before* returning counts or snippets.

## Interoperability, AI & Administration
- `POST /api/fhir/ingest` — UK Core FHIR R4 Bundle ingestion (`external_message_id` idempotency + `replacesReference` correction linking).
- `GET /api/interoperability/inbox` & `POST /api/interoperability/inbox/:id/retry`
- `GET /api/admin/audit` — Scope-limited audit viewer + SHA-256 hash-chain integrity check.
- `PATCH /api/admin/ai-config` — Caldicott Guardian toggle for optional AI draft assistant (default `false`).
- `POST /api/patients/:id/ai-summary` — Server-side Gemini draft summary strictly over records the requesting user can access.
- `POST /api/admin/backup-restore-drill` — Executes online backup + isolated restore + integrity & attachment checksum verification + measured RTO.
