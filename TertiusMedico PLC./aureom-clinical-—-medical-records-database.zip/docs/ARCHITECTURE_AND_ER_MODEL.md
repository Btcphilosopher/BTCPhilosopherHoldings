# Aureom Clinical — Architecture, Entity-Relationship Model & Repository Structure

## 1. Entity-Relationship Model (Normalised Core)

```
organisations (1) ──< locations (N)
organisations (1) ──< users (N) >── roles (1)
organisations (1) ──< care_teams (N) ──< care_team_memberships >── users
users (1) ──< user_sessions (N)

organisations (1) ──< patients (N)  [stable internal UUID + internal_mrn]
patients (1) ──< patient_identifiers (N)  [origin_patient_id preserved across merges]
patients (1) ──< patient_names (N)        [effective_from / effective_to history]
patients (1) ──< patient_addresses (N)    [effective_from / effective_to history]
patients (1) ──< patient_contacts (N)
patients (1) ──< patient_duplicate_candidates (N)
patients (1) ──< patient_merge_events (N) [moved_records_snapshot JSONB for controlled unmerge]

patients (1) ──< enrolments (N)
patients (1) ──< encounters (N) >── locations / care_teams / users

patients (1) ──< clinical_notes (N) ──< clinical_note_versions (N) [is_immutable lock]
clinical_notes (1) ──< clinical_signatures (N) [idempotency_key + attestation + SHA-256]
clinical_notes (1) ──< clinical_note_amendments (N) [addendum / correction / clarification]

patients (1) ──< problems (N)
patients (1) ──< allergies (N)            [explicit allergy_assessment_status on patient]
patients (1) ──< medication_statements (N)
patients (1) ──< prescriptions (N) ──< dispensing_records (N)
prescriptions (1) ──< medication_administrations (N)

patients (1) ──< specimens (N)
patients (1) ──< observations (N)
patients (1) ──< diagnostic_requests (N)
patients (1) ──< diagnostic_results (N) [self-FK replaces_result_id + separate review_state]
patients (1) ──< follow_up_tasks (N)
patients (1) ──< referrals (N)
patients (1) ──< documents (N)          [object_storage_key + sha256_checksum]
patients (1) ──< imaging_references (N) [PACS/DICOMweb URI; no DICOM blobs in SQL]

patients (1) ──< consent_directives (N) [purpose-scoped: direct_care, research_opt_in, hie_exchange, ai_draft_assistance]
patients (1) ──< access_restrictions (N)
patients (1) ──< emergency_access_grants (N) [Break-Glass + IG review]

audit_events [append-only trigger + prev_hash/event_hash SHA-256 chain]
integration_inbox_messages [UNIQUE(source_system, external_message_id)]
integration_outbox_events  [durable worker dispatch]
retention_policies / legal_holds / backup_restore_drills
```

## 2. Repository Structure

```
/migrations/            # PostgreSQL 16 SQLx migrations (0001–0003)
/seeds/                 # Synthetic English clinic SQL seed (Thames Valley Clinic Y99001)
/backend/               # Rust (Axum 0.8 + Tokio 1 + SQLx 0.8 + PostgreSQL) modular monolith
  /src/
    main.rs             # Axum router, PgPool, durable outbox worker
    config.rs           # Env configuration
    error.rs            # Typed HTTP/domain errors (401/403/404/409/400)
    auth.rs             # Replaceable OIDC/CIS2 session extractor + RBAC + Break-Glass evaluator
    audit.rs            # Hash-chained append-only audit logger inside SQLx transactions
    domain/             # patients.rs, notes.rs (domain services; no unrestricted table APIs)
    interoperability/   # fhir.rs (UK Core FHIR R4 bundle ingestion & correction linking)
  /tests/               # Rust integration tests
/server.ts & /server/   # Live Express + Node SQLite runtime for port-3000 AI Studio preview
/src/                   # React 19 + TypeScript + Tailwind CSS clinical workstation UI
/scripts/               # backup_and_restore_drill.sh & verify_demo_workflow.ts
/docs/                  # Architecture, API contracts, UK regulatory compliance
/docker-compose.yml     # Local PostgreSQL 16 + MinIO object storage + Rust backend deployment
```

## 3. Implementation Sequence
1. Normalised PostgreSQL schema & triggers (`/migrations/0001–0003`).
2. Core Patient → Encounter → Clinical Note → Atomic Signature → Attributed Amendment → Authorised Retrieval → Audit History workflow.
3. Identity governance (Mod-11 NHS Number check, duplicate candidate review, merge/unmerge).
4. Medications separation, allergies explicit assessment states, observations & corrected diagnostic results with follow-up tasks.
5. Zero-leakage chronological timeline & search, protected object storage, UK Core FHIR R4 inbox/outbox.
6. Disabled-by-default AI draft summary adapter, hash-chain verification, and isolated backup/restore drill.
