# English Healthcare Regulatory, Clinical Safety & Compliance Assessment

## 1. Intended Organisation Context
- **Fictional Organisation**: Thames Valley Integrated Care Clinic (Synthetic ODS: `Y99001`), an English community and outpatient diagnostic provider operating under NHS England integrated care pathways.

## 2. Verified Standards & Regulatory Frameworks (England)
1. **Clinical Safety (DCB0129 & DCB0160)** — Statutory requirements under the Health and Social Care Act 2012.
   - *DCB0129* applies to the software manufacturer (Clinical Safety Officer, Hazard Log, Clinical Safety Case Report).
   - *DCB0160* applies to the deploying healthcare organisation (local hazard assessment, go-live sign-off).
2. **Data Protection & IG (UK GDPR, Data Protection Act 2018, DSPT)**
   - Special category health data requires Article 6 (e.g. Public Task / Legitimate Interests) + Article 9(2)(h) (provision of health/social care) lawful bases, a completed DPIA, and annual Data Security and Protection Toolkit (DSPT) assertion.
3. **Retention & Disposal (NHS Records Management Code of Practice)**
   - Adult health records: minimum 8 years after last clinical contact; paediatric/maternity records: 25 years / until 25th–26th birthday; access audit trails aligned with statutory retention and legal holds.
4. **Interoperability & Terminologies (UK Core FHIR R4, SNOMED CT UK Edition, NHS dm+d, NHS Number Mod-11)**
   - Requires valid TRUD/SNOMED CT UK licensing for production terminology servers, PDS Spine integration + CIS2 smartcard/OIDC authentication via NHS Digital onboarding (generic FHIR endpoints alone do **not** establish NHS Spine connectivity).
5. **MHRA Software as a Medical Device (SaMD)**
   - As an electronic patient record (EPR) storing and displaying clinician-authored records and source-supplied lab reference ranges without automated diagnostic thresholds, dosing calculators, or autonomous clinical conclusions, core record storage falls outside SaMD therapeutic/diagnostic claims; any future decision-support module would require MHRA classification review under UK Medical Devices Regulations 2002.

## 3. Implemented Technical Controls vs. Independently Assessed Compliance

| Control Area | Implemented in This Codebase | Requires Independent Assessment / External Integration |
| :--- | :--- | :--- |
| Patient Identity | Stable internal UUIDs, Mod-11 NHS check, effective-dated identifiers/names/addresses, duplicate candidate queue, reversible merge | Live NHS Spine PDS synchronisation & demographic tracing accreditation |
| Clinical Safety | Optimistic concurrency (`409`), immutable signed notes, attributed addenda, explicit `not_assessed` allergy state, source-supplied lab intervals | Formal DCB0129 Hazard Log, Clinical Safety Case, and local DCB0160 sign-off by registered CSO |
| Access & Audit | MFA-gated sessions, RBAC + org isolation, Break-Glass emergency grants with IG review, zero-leakage search, hash-chained append-only audit triggers | Penetration testing, WORM/SIEM off-host log shipping, live NHS CIS2 OIDC federation, DSPT submission |
| Interoperability | UK Core FHIR R4 Bundle adapter, `external_message_id` idempotency, correction chaining, failed-message retry, durable outbox | NHS Digital Spine / MESH / GP Connect onboarding & terminology server licensing (SNOMED CT UK / dm+d) |
| Reliability & Lifecycle | Transactional updates, protected path-confined storage + SHA-256 verification, retention & legal-hold tables, automated isolated restore drill measuring RTO | Multi-AZ encrypted RDS/PostgreSQL backups, KMS key rotation, SOC/DR tabletop exercises |

## 4. Accurate Summary of Capabilities
- **Implemented & Live (Port 3000 Preview)**: Full React + TypeScript workstation backed by Express + transactional `node:sqlite`, enforcing Mod-11 NHS validation, demographic history, reversible merges, Draft→Signed→Amended notes, 409 concurrency checks, duplicate-safe signing, separated medication streams, explicit allergy assessment states, corrected result chains, zero-leakage search, Break-Glass overrides, hash-chained audit verification, protected object storage, FHIR bundle ingest/retry, disabled-by-default Gemini draft assistant, and live isolated backup/restore drills.
- **Delivered as Production Target Source (Uncompiled in Container)**: Complete Rust (`axum = "0.8"`, `tokio = "1"`, `sqlx = "0.8"`) modular monolith, PostgreSQL 16 migrations (`0001`–`0003`), synthetic SQL seed, Docker Compose (`postgres` + `minio` + `backend`), and `pg_dump`/`pg_restore` drill script (Rust/Docker toolchains are not installed in this Node sandbox container, so the Rust crate is delivered as source alongside the runnable Node runtime).
- **Simulated / Adapter-Backed**: NHS CIS2 OIDC + 6-digit TOTP MFA adapter, Berkshire Pathology LIS UK Core FHIR R4 feed, and PACS/DICOMweb study URI references.
