package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineRecord
import com.example.data.MedicineRequest
import com.example.ui.theme.*

@Composable
fun MedicinesScreen(
    medicines: List<MedicineRecord>,
    latestRequest: MedicineRequest,
    onToggleMedicine: (String) -> Unit,
    onSubmitRequest: (List<String>) -> Unit,
    onBackHome: () -> Unit
) {
    var showReviewDialog by remember { mutableStateOf(false) }
    var showConfirmationSnack by remember { mutableStateOf(false) }

    val selectedMedicines = medicines.filter { it.isSelected }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaleBlueBackground)
    ) {
        Surface(
            color = RoyalBlue,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onBackHome() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Repeat medicines",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(medicines) { med ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleMedicine(med.id) }
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Medication,
                                contentDescription = null,
                                tint = RoyalBlue,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = med.name,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyText
                                )
                                Text(
                                    text = med.subtitle,
                                    fontSize = 13.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = med.directions,
                            fontSize = 14.sp,
                            color = BodyText
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { onToggleMedicine(med.id) }
                        ) {
                            Checkbox(
                                checked = med.isSelected,
                                onCheckedChange = { onToggleMedicine(med.id) },
                                colors = CheckboxDefaults.colors(checkedColor = RoyalBlue)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Request this medicine",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NavyText
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Schedule,
                                contentDescription = null,
                                tint = RoyalBlue,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Previous request (${latestRequest.medicineName})",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyText
                                )
                                Text(
                                    text = "Submitted ${latestRequest.timestamp}",
                                    fontSize = 13.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            color = Color(0xFFE2E8F0),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = latestRequest.status,
                                color = NavyText,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        if (selectedMedicines.isNotEmpty()) {
                            showReviewDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    enabled = selectedMedicines.isNotEmpty()
                ) {
                    Text("Review request", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "A request is not a prescription approval.",
                        fontSize = 13.sp,
                        color = BodyText
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showReviewDialog) {
        AlertDialog(
            onDismissRequest = { showReviewDialog = false },
            title = { Text("Review Medicine Request", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("You are requesting the following repeat medicines:")
                    Spacer(modifier = Modifier.height(8.dp))
                    selectedMedicines.forEach {
                        Text("• ${it.name}", fontWeight = FontWeight.Bold, color = NavyText)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("A request is not a prescription approval. Requests are reviewed by your practice clinicians.")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSubmitRequest(selectedMedicines.map { it.name })
                        showReviewDialog = false
                        showConfirmationSnack = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                ) {
                    Text("Submit Request")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showReviewDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showConfirmationSnack) {
        AlertDialog(
            onDismissRequest = { showConfirmationSnack = false },
            title = { Text("Request Submitted", fontWeight = FontWeight.Bold) },
            text = { Text("Your repeat medicine request has been sent to your practice. Status: Awaiting review.") },
            confirmButton = {
                Button(
                    onClick = { showConfirmationSnack = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                ) {
                    Text("OK")
                }
            }
        )
    }
}
