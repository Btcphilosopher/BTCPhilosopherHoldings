package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class PatientRepository {
    private val _user = MutableStateFlow(PatientUser())
    val user: StateFlow<PatientUser> = _user.asStateFlow()

    private val _confirmedAppointment = MutableStateFlow(
        Appointment(
            id = "apt-1",
            date = "2026-12-08",
            displayDate = "Tuesday 8 December 2026",
            time = "10:30",
            clinician = "Dr Patel",
            type = "In person · Main surgery",
            durationMinutes = 15,
            status = "Confirmed",
            preparation = "Please bring any current medication containers. Check in at the main reception kiosk upon arrival."
        )
    )
    val confirmedAppointment: StateFlow<Appointment> = _confirmedAppointment.asStateFlow()

    private val _appointmentsList = MutableStateFlow(
        listOf(
            _confirmedAppointment.value,
            Appointment(
                id = "apt-2",
                date = "2026-11-15",
                displayDate = "Sunday 15 November 2026",
                time = "09:00",
                clinician = "Dr Evans",
                type = "Telephone consultation",
                durationMinutes = 10,
                status = "Completed",
                preparation = "Routine blood test follow-up discussion."
            )
        )
    )
    val appointmentsList: StateFlow<List<Appointment>> = _appointmentsList.asStateFlow()

    private val _availableSlots = MutableStateFlow(
        listOf(
            AppointmentSlot("slot-7a", "2026-12-07", "Mon 7", "09:15", "Dr Evans", "In person · Main surgery", "Available"),
            AppointmentSlot("slot-7b", "2026-12-07", "Mon 7", "11:00", "Dr Patel", "In person · Main surgery", "Available"),
            AppointmentSlot("slot-8a", "2026-12-08", "Tue 8", "09:15", "Dr Evans", "In person · Main surgery", "Available"),
            AppointmentSlot("slot-8b", "2026-12-08", "Tue 8", "10:30", "Dr Patel", "In person · Main surgery", "Available"),
            AppointmentSlot("slot-8c", "2026-12-08", "Tue 8", "11:45", "Dr Evans", "In person · Main surgery", "Available"),
            AppointmentSlot("slot-9a", "2026-12-09", "Wed 9", "10:00", "Dr Patel", "In person · Main surgery", "Available"),
            AppointmentSlot("slot-9b", "2026-12-09", "Wed 9", "14:15", "Dr Evans", "Telephone consultation", "Available")
        )
    )
    val availableSlots: StateFlow<List<AppointmentSlot>> = _availableSlots.asStateFlow()

    private val _medicines = MutableStateFlow(
        listOf(
            MedicineRecord("med-1", "Example medicine A", "Demonstration record", "Directions recorded by your clinician.", false),
            MedicineRecord("med-2", "Example medicine B", "Demonstration record", "Directions recorded by your clinician.", true)
        )
    )
    val medicines: StateFlow<List<MedicineRecord>> = _medicines.asStateFlow()

    private val _latestMedicineRequest = MutableStateFlow(
        MedicineRequest(
            id = "req-1",
            medicineName = "Example medicine B",
            status = "Received by your practice",
            timestamp = "Today at 09:15"
        )
    )
    val latestMedicineRequest: StateFlow<MedicineRequest> = _latestMedicineRequest.asStateFlow()

    private val _messages = MutableStateFlow(
        listOf(
            PracticeMessage(
                id = "msg-1",
                title = "New message from your practice",
                sender = "Pennine Medical Practice",
                snippet = "Your repeat medicine request for Example medicine B has been received...",
                body = "Dear Alex,\n\nYour repeat medicine request for Example medicine B has been received by your practice and is currently Awaiting review by our clinical team.\n\nPlease note: A request is not a prescription approval.\n\nPennine Medical Practice",
                timestamp = "Today, 09:15",
                isUnread = true
            ),
            PracticeMessage(
                id = "msg-2",
                title = "Appointment confirmation",
                sender = "Dr Patel's Team",
                snippet = "Your appointment is confirmed for Tuesday 8 December 2026 at 10:30...",
                body = "Your appointment with Dr Patel is confirmed for Tuesday 8 December 2026 at 10:30 at Main surgery.\nPlease arrive 5 minutes early.",
                timestamp = "Yesterday",
                isUnread = false
            )
        )
    )
    val messages: StateFlow<List<PracticeMessage>> = _messages.asStateFlow()

    private val _healthRecords = MutableStateFlow(
        listOf(
            HealthRecordItem(
                id = "rec-1",
                category = "Consultation summaries",
                title = "Routine health review",
                date = "15 Nov 2026",
                source = "Dr Evans (Pennine Medical Practice)",
                details = "Patient reports feeling well overall. Blood pressure stable at 120/80. Advised on regular exercise and balanced diet."
            ),
            HealthRecordItem(
                id = "rec-2",
                category = "Allergies",
                title = "No known drug allergies",
                date = "Verified 10 Jan 2026",
                source = "Clinical System",
                details = "Patient has no known adverse drug reactions or allergies recorded."
            ),
            HealthRecordItem(
                id = "rec-3",
                category = "Immunisations",
                title = "Annual Influenza Vaccine",
                date = "12 Oct 2025",
                source = "Practice Nurse Sarah Jenkins",
                details = "Quadrivalent influenza vaccine administered intramuscularly left deltoid."
            ),
            HealthRecordItem(
                id = "rec-4",
                category = "Results",
                title = "Full Blood Count (FBC)",
                date = "14 Nov 2026",
                source = "Pathology Lab Services",
                details = "All parameters within normal limits. Clinician comment: Satisfactory result, no action required."
            )
        )
    )
    val healthRecords: StateFlow<List<HealthRecordItem>> = _healthRecords.asStateFlow()

    fun toggleMedicineSelection(id: String) {
        _medicines.value = _medicines.value.map {
            if (it.id == id) it.copy(isSelected = !it.isSelected) else it
        }
    }

    fun submitMedicineRequest(selectedNames: List<String>) {
        if (selectedNames.isNotEmpty()) {
            val nameStr = selectedNames.joinToString(", ")
            _latestMedicineRequest.value = MedicineRequest(
                id = "req-${System.currentTimeMillis()}",
                medicineName = nameStr,
                status = "Awaiting review",
                timestamp = "Just now"
            )
            val newMsg = PracticeMessage(
                id = "msg-${System.currentTimeMillis()}",
                title = "Medicine request submitted",
                sender = "Dispensary Team",
                snippet = "Your request for $nameStr is awaiting review.",
                body = "Your repeat request for $nameStr has been submitted successfully.\nStatus: Awaiting review.\n\nA request is not a prescription approval.",
                timestamp = "Just now",
                isUnread = true
            )
            _messages.value = listOf(newMsg) + _messages.value
        }
    }

    fun bookAppointment(slot: AppointmentSlot) {
        val newApt = Appointment(
            id = "apt-${System.currentTimeMillis()}",
            date = slot.date,
            displayDate = when(slot.date) {
                "2026-12-07" -> "Monday 7 December 2026"
                "2026-12-08" -> "Tuesday 8 December 2026"
                "2026-12-09" -> "Wednesday 9 December 2026"
                else -> slot.date
            },
            time = slot.time,
            clinician = slot.clinician,
            type = slot.type,
            status = "Confirmed"
        )
        _confirmedAppointment.value = newApt
        _appointmentsList.value = listOf(newApt) + _appointmentsList.value

        val newMsg = PracticeMessage(
            id = "msg-${System.currentTimeMillis()}",
            title = "New appointment confirmed",
            sender = "Pennine Medical Practice",
            snippet = "Your appointment with ${slot.clinician} on ${newApt.displayDate} is confirmed.",
            body = "Your appointment is confirmed for ${newApt.displayDate} at ${slot.time} with ${slot.clinician} (${slot.type}).",
            timestamp = "Just now",
            isUnread = true
        )
        _messages.value = listOf(newMsg) + _messages.value
    }

    fun cancelAppointment(appointmentId: String) {
        _appointmentsList.value = _appointmentsList.value.map {
            if (it.id == appointmentId) it.copy(status = "Cancelled") else it
        }
        if (_confirmedAppointment.value.id == appointmentId) {
            // Find another confirmed or mark empty
            val nextConf = _appointmentsList.value.firstOrNull { it.status == "Confirmed" }
            if (nextConf != null) {
                _confirmedAppointment.value = nextConf
            }
        }
    }

    fun updateMedicineRequestStatus(requestId: String, newStatus: String) {
        _latestMedicineRequest.value = _latestMedicineRequest.value.copy(status = newStatus)
    }

    fun setOfflineMode(offline: Boolean) {
        _user.value = _user.value.copy(isOffline = offline)
    }

    fun markMessageRead(msgId: String) {
        _messages.value = _messages.value.map {
            if (it.id == msgId) it.copy(isUnread = false) else it
        }
    }
}
