package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RoyalBlue = Color(0xFF005EB8)
val RoyalBlueDark = Color(0xFF003087)
val RoyalBlueLight = Color(0xFF1D70B8)
val NavyText = Color(0xFF0B0C0C)
val BodyText = Color(0xFF1E293B)
val PaleBlueBackground = Color(0xFFF0F4F8)
val BorderGrey = Color(0xFFD8DDE0)
val SuccessGreen = Color(0xFF00703C)
val SuccessGreenBg = Color(0xFFD4EDDA)
val WarningOrange = Color(0xFFD97706)
val WarningOrangeBg = Color(0xFFFEF3C7)
val SurfaceWhite = Color(0xFFFFFFFF)
