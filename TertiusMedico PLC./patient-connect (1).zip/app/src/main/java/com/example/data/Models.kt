package com.example.data

data class PatientUser(
    val name: String = "Alex",
    val fullName: String = "Alex Morgan",
    val nhsNumber: String = "948 204 7192",
    val dob: String = "14 May 1984",
    val practiceName: String = "Pennine Medical Practice",
    val isOffline: Boolean = false,
    val lastSyncTime: String = "Today at 09:42"
)

data class Appointment(
    val id: String,
    val date: String,       // e.g. "2026-12-08"
    val displayDate: String, // e.g. "Tuesday 8 December 2026"
    val time: String,       // e.g. "10:30"
    val clinician: String,  // e.g. "Dr Patel"
    val type: String,       // e.g. "In person · Main surgery"
    val durationMinutes: Int = 15,
    val status: String,     // "Confirmed", "Held", "Awaiting review", "Cancelled", "Expired"
    val preparation: String = "Please arrive 5 minutes before your appointment. Check in at reception kiosk."
)

data class AppointmentSlot(
    val id: String,
    val date: String,       // "2026-12-07", "2026-12-08", "2026-12-09"
    val dayLabel: String,   // "Mon 7", "Tue 8", "Wed 9"
    val time: String,       // "09:15", "10:30", "11:45"
    val clinician: String,  // "Dr Evans", "Dr Patel"
    val type: String,       // "In person · Main surgery"
    val status: String      // "Available", "Held", "Booked"
)

data class MedicineRecord(
    val id: String,
    val name: String,       // "Example medicine A"
    val subtitle: String = "Demonstration record",
    val directions: String = "Directions recorded by your clinician.",
    val isSelected: Boolean = false
)

data class MedicineRequest(
    val id: String,
    val medicineName: String,
    val status: String,     // "Received by your practice", "Submitted", "Awaiting review", "Approved", "Declined"
    val timestamp: String
)

data class PracticeMessage(
    val id: String,
    val title: String,
    val sender: String,
    val snippet: String,
    val body: String,
    val timestamp: String,
    val isUnread: Boolean = true
)

data class HealthRecordItem(
    val id: String,
    val category: String,   // "Consultation summaries", "Allergies", "Immunisations", "Letters", "Results"
    val title: String,
    val date: String,
    val source: String,
    val details: String
)
