package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.AppointmentSlot
import com.example.data.PatientRepository
import kotlinx.coroutines.flow.StateFlow

class PatientViewModel : ViewModel() {
    private val repository = PatientRepository()

    val user = repository.user
    val confirmedAppointment = repository.confirmedAppointment
    val appointmentsList = repository.appointmentsList
    val availableSlots = repository.availableSlots
    val medicines = repository.medicines
    val latestMedicineRequest = repository.latestMedicineRequest
    val messages = repository.messages
    val healthRecords = repository.healthRecords

    fun toggleMedicine(id: String) {
        repository.toggleMedicineSelection(id)
    }

    fun submitMedicineRequest(selectedNames: List<String>) {
        repository.submitMedicineRequest(selectedNames)
    }

    fun bookAppointment(slot: AppointmentSlot) {
        repository.bookAppointment(slot)
    }

    fun cancelAppointment(id: String) {
        repository.cancelAppointment(id)
    }

    fun updateMedicineStatus(requestId: String, status: String) {
        repository.updateMedicineRequestStatus(requestId, status)
    }

    fun setOffline(offline: Boolean) {
        repository.setOfflineMode(offline)
    }

    fun markMessageRead(msgId: String) {
        repository.markMessageRead(msgId)
    }
}
