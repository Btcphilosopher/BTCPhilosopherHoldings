package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Appointment
import com.example.data.AppointmentSlot
import com.example.ui.theme.*

@Composable
fun AppointmentsScreen(
    appointments: List<Appointment>,
    slots: List<AppointmentSlot>,
    onBookSlot: (AppointmentSlot) -> Unit,
    onCancelAppointment: (String) -> Unit,
    onOpenContact: () -> Unit,
    onBackHome: () -> Unit
) {
    var selectedDateTab by remember { mutableStateOf("Tue 8") }
    var selectedSlotId by remember { mutableStateOf("slot-8b") }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var bookedMessage by remember { mutableStateOf("") }

    val filteredSlots = slots.filter { it.dayLabel == selectedDateTab }
    val currentSelectedSlot = slots.firstOrNull { it.id == selectedSlotId } ?: slots.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaleBlueBackground)
    ) {
        Surface(
            color = RoyalBlue,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onBackHome() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Choose an appointment",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Routine GP appointment",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyText
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "In person · Main surgery",
                            fontSize = 15.sp,
                            color = BodyText
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            listOf("Mon 7", "Tue 8", "Wed 9").forEach { day ->
                                val isSelected = (day == selectedDateTab)
                                Surface(
                                    color = if (isSelected) RoyalBlue else SurfaceWhite,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (isSelected) RoyalBlue else BorderGrey),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp)
                                        .clickable { selectedDateTab = day }
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        Text(
                                            text = day,
                                            color = if (isSelected) Color.White else NavyText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = when(selectedDateTab) {
                        "Mon 7" -> "Monday 7 December 2026"
                        "Tue 8" -> "Tuesday 8 December 2026"
                        else -> "Wednesday 9 December 2026"
                    },
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyText
                )
            }

            items(filteredSlots) { slot ->
                val isSelected = (slot.id == selectedSlotId)
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(2.dp, if (isSelected) RoyalBlue else BorderGrey),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedSlotId = slot.id }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedSlotId = slot.id },
                                colors = RadioButtonDefaults.colors(selectedColor = RoyalBlue)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "${slot.time} · ${slot.clinician}",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyText
                            )
                        }
                        Text(
                            text = slot.type.substringBefore("·").trim(),
                            fontSize = 14.sp,
                            color = BodyText
                        )
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Selected appointment",
                            fontSize = 14.sp,
                            color = RoyalBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${currentSelectedSlot.time} · ${currentSelectedSlot.clinician}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyText
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "15 minutes · ${currentSelectedSlot.type.substringBefore("·").trim()}",
                            fontSize = 14.sp,
                            color = BodyText
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                onBookSlot(currentSelectedSlot)
                                bookedMessage = "Successfully booked appointment for ${currentSelectedSlot.time} with ${currentSelectedSlot.clinician}."
                                showSuccessDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text("Confirm appointment", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Times are confirmed when booking completes.",
                            fontSize = 13.sp,
                            color = BodyText
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Need help booking? ",
                                fontSize = 14.sp,
                                color = BodyText
                            )
                            Text(
                                text = "Contact reception",
                                fontSize = 14.sp,
                                color = RoyalBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { onOpenContact() }
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Upcoming & Past Appointments",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyText
                )
            }

            items(appointments) { apt ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = apt.displayDate,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = NavyText
                            )
                            Surface(
                                color = if (apt.status == "Confirmed") SuccessGreenBg else Color(
                                    0xFFE2E8F0
                                ),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = apt.status,
                                    color = if (apt.status == "Confirmed") SuccessGreen else NavyText,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${apt.time} · ${apt.clinician} (${apt.type})",
                            fontSize = 14.sp,
                            color = BodyText
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = apt.preparation,
                            fontSize = 13.sp,
                            color = Color.Gray
                        )

                        if (apt.status == "Confirmed") {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { onCancelAppointment(apt.id) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                                    border = BorderStroke(1.dp, Color.Red),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text("Cancel", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            title = { Text("Appointment Confirmed", fontWeight = FontWeight.Bold) },
            text = { Text(bookedMessage) },
            confirmButton = {
                Button(
                    onClick = { showSuccessDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                ) {
                    Text("OK")
                }
            }
        )
    }
}
