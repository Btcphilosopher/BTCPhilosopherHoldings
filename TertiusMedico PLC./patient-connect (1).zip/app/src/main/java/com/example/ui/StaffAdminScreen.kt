package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineRequest
import com.example.ui.theme.*

@Composable
fun StaffAdminScreen(
    latestRequest: MedicineRequest,
    onUpdateMedicineStatus: (String, String) -> Unit,
    onBackHome: () -> Unit
) {
    var currentStatus by remember { mutableStateOf(latestRequest.status) }
    var showUpdatedSnack by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaleBlueBackground)
            .verticalScroll(scrollState)
    ) {
        Surface(
            color = RoyalBlueDark,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onBackHome() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Staff Administration Console",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = RoyalBlueDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Pennine Medical Staff Portal", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NavyText)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Manage patient requests, update prescription statuses, and review clinical queues.", fontSize = 14.sp, color = BodyText)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Patient Medicine Request", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NavyText)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Medicine: ${latestRequest.medicineName}", fontSize = 15.sp, color = BodyText)
                    Text(text = "Submitted: ${latestRequest.timestamp}", fontSize = 13.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Current Status: $currentStatus", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RoyalBlue)

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Update Status:", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = NavyText)
                    Spacer(modifier = Modifier.height(8.dp))

                    val statuses = listOf("Received by your practice", "Awaiting review", "Approved", "Declined", "Further information required")
                    statuses.forEach { st ->
                        OutlinedButton(
                            onClick = {
                                currentStatus = st
                                onUpdateMedicineStatus(latestRequest.id, st)
                                showUpdatedSnack = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (currentStatus == st) RoyalBlue else BorderGrey),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (currentStatus == st) RoyalBlue.copy(alpha = 0.1f) else SurfaceWhite
                            )
                        ) {
                            Text(st, color = if (currentStatus == st) RoyalBlueDark else NavyText, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showUpdatedSnack) {
        AlertDialog(
            onDismissRequest = { showUpdatedSnack = false },
            title = { Text("Status Updated", fontWeight = FontWeight.Bold) },
            text = { Text("Medicine request status has been updated to: $currentStatus.") },
            confirmButton = {
                Button(
                    onClick = { showUpdatedSnack = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                ) {
                    Text("OK")
                }
            }
        )
    }
}
