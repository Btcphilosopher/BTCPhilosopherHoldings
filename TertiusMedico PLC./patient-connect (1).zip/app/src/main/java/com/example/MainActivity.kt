package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RoyalBlue
import com.example.viewmodel.PatientViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PatientConnectApp()
            }
        }
    }
}

@Composable
fun PatientConnectApp(viewModel: PatientViewModel = viewModel()) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var currentSubScreen by remember { mutableStateOf<String?>(null) }

    val user by viewModel.user.collectAsState()
    val confirmedApt by viewModel.confirmedAppointment.collectAsState()
    val appointments by viewModel.appointmentsList.collectAsState()
    val slots by viewModel.availableSlots.collectAsState()
    val medicines by viewModel.medicines.collectAsState()
    val latestRequest by viewModel.latestMedicineRequest.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val records by viewModel.healthRecords.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (currentSubScreen == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = RoyalBlue
                ) {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home") },
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RoyalBlue,
                            selectedTextColor = RoyalBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.DateRange, contentDescription = "Appointments") },
                        label = { Text("Appointments") },
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RoyalBlue,
                            selectedTextColor = RoyalBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Medication, contentDescription = "Medicines") },
                        label = { Text("Medicines") },
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RoyalBlue,
                            selectedTextColor = RoyalBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Email, contentDescription = "Messages") },
                        label = { Text("Messages") },
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RoyalBlue,
                            selectedTextColor = RoyalBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Person, contentDescription = "Account") },
                        label = { Text("Account") },
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RoyalBlue,
                            selectedTextColor = RoyalBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            if (currentSubScreen == "records") {
                HealthRecordsScreen(
                    records = records,
                    onBackHome = { currentSubScreen = null }
                )
            } else if (currentSubScreen == "admin") {
                StaffAdminScreen(
                    latestRequest = latestRequest,
                    onUpdateMedicineStatus = { id, st -> viewModel.updateMedicineStatus(id, st) },
                    onBackHome = { currentSubScreen = null }
                )
            } else if (currentSubScreen == "contact") {
                MessagesScreen(
                    messages = messages,
                    onMarkRead = { id -> viewModel.markMessageRead(id) },
                    onBackHome = { currentSubScreen = null }
                )
            } else {
                when (selectedTab) {
                    0 -> HomeScreen(
                        user = user,
                        confirmedAppointment = confirmedApt,
                        onNavigateTab = { tab -> selectedTab = tab },
                        onOpenRecords = { currentSubScreen = "records" },
                        onOpenContact = { currentSubScreen = "contact" },
                        onOpenAdmin = { currentSubScreen = "admin" }
                    )
                    1 -> AppointmentsScreen(
                        appointments = appointments,
                        slots = slots,
                        onBookSlot = { slot -> viewModel.bookAppointment(slot) },
                        onCancelAppointment = { id -> viewModel.cancelAppointment(id) },
                        onOpenContact = { currentSubScreen = "contact" },
                        onBackHome = { selectedTab = 0 }
                    )
                    2 -> MedicinesScreen(
                        medicines = medicines,
                        latestRequest = latestRequest,
                        onToggleMedicine = { id -> viewModel.toggleMedicine(id) },
                        onSubmitRequest = { names -> viewModel.submitMedicineRequest(names) },
                        onBackHome = { selectedTab = 0 }
                    )
                    3 -> MessagesScreen(
                        messages = messages,
                        onMarkRead = { id -> viewModel.markMessageRead(id) },
                        onBackHome = { selectedTab = 0 }
                    )
                    4 -> AccountScreen(
                        user = user,
                        onToggleOffline = { off -> viewModel.setOffline(off) },
                        onOpenAdmin = { currentSubScreen = "admin" },
                        onBackHome = { selectedTab = 0 }
                    )
                }
            }
        }
    }
}
