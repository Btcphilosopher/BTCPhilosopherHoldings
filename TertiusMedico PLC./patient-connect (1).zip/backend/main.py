from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
import datetime

app = FastAPI(title="TertiusMedico Patient Connect API", version="1.0.0")

class PatientProfile(BaseModel):
    id: str = "alex-1"
    name: str = "Alex"
    full_name: str = "Alex Morgan"
    nhs_number: str = "948 204 7192"
    dob: str = "14 May 1984"
    practice_name: str = "Pennine Medical Practice"

class AppointmentSlot(BaseModel):
    id: str
    date: str
    time: str
    clinician: str
    type: str
    status: str

class HoldRequest(BaseModel):
    slot_id: str
    patient_id: str

class AppointmentCreate(BaseModel):
    slot_id: str
    patient_id: str
    idempotency_key: str

class MedicineRequestCreate(BaseModel):
    medicine_ids: List[str]
    patient_id: str

# In-memory fixture stores for backend demonstration
db_appointments = [
    {
        "id": "apt-1",
        "date": "2026-12-08",
        "display_date": "Tuesday 8 December 2026",
        "time": "10:30",
        "clinician": "Dr Patel",
        "type": "In person · Main surgery",
        "status": "Confirmed"
    }
]

db_medicine_requests = [
    {
        "id": "req-1",
        "medicine_name": "Example medicine B",
        "status": "Received by your practice",
        "timestamp": "Today at 09:15"
    }
]

db_messages = [
    {
        "id": "msg-1",
        "title": "New message from your practice",
        "sender": "Pennine Medical Practice",
        "snippet": "Your repeat medicine request for Example medicine B has been received...",
        "body": "Dear Alex,\n\nYour repeat medicine request for Example medicine B has been received by your practice and is currently Awaiting review.\n\nA request is not a prescription approval.",
        "timestamp": "Today, 09:15",
        "is_unread": True
    }
]

@app.get("/v1/me", response_model=PatientProfile)
def get_me():
    return PatientProfile()

@app.get("/v1/me/home")
def get_home_data():
    return {
        "profile": PatientProfile(),
        "next_appointment": db_appointments[0],
        "latest_medicine_request": db_medicine_requests[0],
        "unread_messages_count": len([m for m in db_messages if m["is_unread"]])
    }

@app.get("/v1/appointment-slots")
def get_appointment_slots(date: Optional[str] = None):
    slots = [
        {"id": "slot-7a", "date": "2026-12-07", "time": "09:15", "clinician": "Dr Evans", "type": "In person · Main surgery", "status": "Available"},
        {"id": "slot-8b", "date": "2026-12-08", "time": "10:30", "clinician": "Dr Patel", "type": "In person · Main surgery", "status": "Available"},
        {"id": "slot-8c", "date": "2026-12-08", "time": "11:45", "clinician": "Dr Evans", "type": "In person · Main surgery", "status": "Available"}
    ]
    if date:
        slots = [s for s in slots if s["date"] == date]
    return slots

@app.post("/v1/appointment-holds")
def create_appointment_hold(hold: HoldRequest):
    return {"hold_id": f"hold-{hold.slot_id}", "expires_in_seconds": 300, "status": "Held"}

@app.post("/v1/appointments")
def create_appointment(apt: AppointmentCreate):
    new_apt = {
        "id": f"apt-{datetime.datetime.utcnow().timestamp()}",
        "date": "2026-12-08",
        "display_date": "Tuesday 8 December 2026",
        "time": "10:30",
        "clinician": "Dr Patel",
        "type": "In person · Main surgery",
        "status": "Confirmed"
    }
    db_appointments.insert(0, new_apt)
    return {"status": "Confirmed", "appointment": new_apt}

@app.get("/v1/me/appointments")
def get_my_appointments():
    return db_appointments

@app.get("/v1/me/medicine-requests")
def get_my_medicine_requests():
    return db_medicine_requests

@app.post("/v1/medicine-requests")
def submit_medicine_request(req: MedicineRequestCreate):
    new_req = {
        "id": f"req-{datetime.datetime.utcnow().timestamp()}",
        "medicine_name": "Example medicine B",
        "status": "Awaiting review",
        "timestamp": "Just now"
    }
    db_medicine_requests.insert(0, new_req)
    return {"status": "Submitted", "request": new_req}

@app.get("/v1/me/messages")
def get_my_messages():
    return db_messages

@app.get("/v1/me/released-records")
def get_released_records():
    return [
        {"id": "rec-1", "category": "Consultation summaries", "title": "Routine health review", "date": "15 Nov 2026", "source": "Dr Evans", "details": "Patient reports feeling well."}
    ]
