# TERTIUSMEDICO — GP Practice (Independent Prototype)

**Disclaimer:** *TERTIUSMEDICO — GP Practice* is an independent prototype built with synthetic data for the fictional **Pennine Medical Practice** (*Millbrook Surgery* & *Valley View Branch*). It does not claim NHS endorsement, clinical safety certification, or live NHS Spine/EPS/e-RS/Pathology integration, and does not issue real prescriptions.

## Architecture & Module Boundaries

- **Frontend (`src/app/`)**: Angular 21 (Zoneless, Standalone, Reactive Forms, Signals, Tailwind CSS v4)
  - **Staff Workstation (`src/app/staff/`)**: Desktop-first 12-section workspace (`Today`, `Appointments`, `Patients`, `Consultations`, `Requests`, `Results`, `Prescriptions`, `Referrals`, `Documents`, `Tasks`, `Reports`, `Administration`)
  - **Patient Portal (`src/app/portal/patient-portal.ts`)**: Mobile-first thumb-ergonomic portal (`Home`, `Appointments`, `Requests`, `Medicines`, `Messages`, `My information`, `Account`)
- **Backend (`src/server/`)**: Express 5 modular monolith with atomic file-backed persistence (`data/practice-db.json`) and transactional async mutex (`src/server/store.ts`)
  - `modules/identity.ts`: Registration, mock PDS verification, manual duplicate review (no auto-merge), contact updates, scoped proxy relationships
  - `modules/scheduling.ts`: `Europe/London` sessions, slot holds, transactional double-booking/leave/travel buffer checks, safe template versioning
  - `modules/clinical.ts`: `Draft -> Reviewed -> Signed -> Amended` lifecycle, SHA-256 signed-note immutability, wrong-patient guard, interrupted-save recovery
  - `modules/medicines.ts`: Repeat requests, prescriber-only RBAC, `PrototypeDrugSafetyAdapter` coverage reporting, simulated EPS label
  - `modules/results.ts`: Idempotent lab ingestion, unmatched quarantine, viewing vs clinical review separation, lab amendments
  - `modules/documents.ts`: OCR provenance requiring clinician review, manual matching, referral draft vs external e-RS acceptance separation
  - `modules/communications.ts`: Dependency-aware tasks with completion evidence, recall registers, lock-screen safe comms, failed notification retry, worker tick
  - `adapters.ts`: Typed replaceable integration boundaries (`PDS`, `GP Connect`, `EPS`, `Pathology`, `e-RS`, `NHS Notify`, `Shared Care Record`) and prototype Clinical Hazard Log

## Running & Testing

```bash
npm install
npm run dev      # Starts Angular 21 + Express API on http://localhost:3000
npm run build    # Production SSR + browser build
npm run lint     # ESLint + Angular template checks
npx vitest run src/server/practice.spec.ts
```
