export type StaffRole =
  | 'GP_PARTNER'
  | 'PRACTICE_NURSE'
  | 'PHARMACIST'
  | 'RECEPTIONIST'
  | 'PRACTICE_MANAGER';

export type ActorRole = StaffRole | 'PATIENT';

export type ProxyScope =
  | 'appointments'
  | 'requests'
  | 'medicines'
  | 'messages'
  | 'records';

export interface SessionUser {
  id: string;
  name: string;
  role: ActorRole;
  title: string;
  mfaVerified: boolean;
  siteId?: string;
  patientId?: string;
  linkedPatientIds?: string[];
}

export type NhsVerificationStatus =
  | 'verified'
  | 'unverified'
  | 'trace_pending'
  | 'not_supplied';

export type RegistrationStatus =
  | 'registered'
  | 'temporary'
  | 'pending_verification'
  | 'deducted';

export type AllergyStatus =
  | 'none_recorded'
  | 'confirmed_nkda'
  | 'known_allergies';

export interface AllergyRecord {
  id: string;
  substance: string;
  reaction: string;
  severity: 'mild' | 'moderate' | 'severe';
  recordedAt: string;
  recordedBy: string;
  verificationStatus: 'clinician_verified' | 'patient_reported';
}

export interface ProxyRelationship {
  id: string;
  proxyUserId: string;
  proxyName: string;
  relationship: string;
  verificationStatus: 'verified' | 'pending' | 'revoked';
  scopes: ProxyScope[];
  verifiedBy?: string;
  verifiedAt?: string;
}

export interface Patient {
  internalId: string;
  nhsNumber: string | null;
  nhsVerificationStatus: NhsVerificationStatus;
  title: string;
  firstName: string;
  lastName: string;
  preferredName?: string;
  dob: string;
  sexAtBirth: 'Female' | 'Male' | 'Indeterminate' | 'Not specified';
  addressLine1: string;
  city: string;
  postcode: string;
  phone: string;
  email: string;
  preferredChannel: 'sms' | 'email' | 'letter' | 'portal';
  interpreterRequired: boolean;
  preferredLanguage: string;
  accessibilityNeeds: string[];
  registrationStatus: RegistrationStatus;
  registeredSiteId: string;
  usualGpId: string;
  allergyStatus: AllergyStatus;
  allergies: AllergyRecord[];
  proxies: ProxyRelationship[];
  sourceSystemIds: {
    pds?: string;
    legacyPracticeId?: string;
    portalAccountId?: string;
  };
  recordReleasePolicy: {
    allowProspectiveNotes: boolean;
    allowReviewedResults: boolean;
    allowCorrespondenceSummary: boolean;
  };
  createdAt: string;
  updatedAt: string;
}

export interface DuplicateCandidate {
  id: string;
  patientAId: string;
  patientBId: string;
  matchReason: string;
  confidence: 'high' | 'moderate';
  status: 'pending_review' | 'confirmed_distinct' | 'linked_duplicate';
  reviewedBy?: string;
  reviewedAt?: string;
  notes?: string;
}

export interface PatientContactUpdateRequest {
  id: string;
  patientId: string;
  submittedByUserId: string;
  requestedChanges: {
    phone?: string;
    email?: string;
    addressLine1?: string;
    postcode?: string;
    preferredChannel?: 'sms' | 'email' | 'letter' | 'portal';
  };
  status: 'pending_review' | 'approved' | 'rejected';
  submittedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewReason?: string;
}

export interface PracticeSite {
  id: string;
  name: string;
  odsCode: string;
  address: string;
  postcode: string;
  phone: string;
  travelBufferMinutesFromOtherSite: number;
}

export interface Room {
  id: string;
  siteId: string;
  name: string;
  floor: string;
  stepFreeAccess: boolean;
  equipment: string[];
  active: boolean;
}

export interface Clinician {
  id: string;
  name: string;
  role: StaffRole;
  gmcOrNmcNumber: string;
  competencies: string[];
  defaultSiteId: string;
  active: boolean;
}

export interface SessionTemplate {
  id: string;
  version: number;
  name: string;
  clinicianId: string;
  siteId: string;
  roomId: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  slotDurationMinutes: number;
  protectedSlotIndices: number[];
  patientSelfBookAllowed: boolean;
  allowedModes: AppointmentMode[];
  updatedAt: string;
  updatedBy: string;
}

export interface ClinicianSession {
  id: string;
  templateId: string;
  templateVersion: number;
  clinicianId: string;
  siteId: string;
  roomId: string;
  date: string;
  startTime: string;
  endTime: string;
  timezone: 'Europe/London';
  slotDurationMinutes: number;
  protectedSlots: string[];
  breakStart?: string;
  breakEnd?: string;
  travelBufferMinutes: number;
  status: 'active' | 'unavailable_leave' | 'cancelled';
  unavailableReason?: string;
  allowedAppointmentTypes: string[];
  patientSelfBookAllowed: boolean;
}

export type AppointmentMode = 'in_person' | 'telephone' | 'video';

export type AppointmentStatus =
  | 'booked'
  | 'arrived'
  | 'in_consultation'
  | 'completed'
  | 'cancelled'
  | 'dna';

export interface Appointment {
  id: string;
  patientId: string;
  sessionId: string;
  clinicianId: string;
  siteId: string;
  roomId: string;
  date: string;
  startTime: string;
  endTime: string;
  timezone: 'Europe/London';
  mode: AppointmentMode;
  appointmentType: string;
  status: AppointmentStatus;
  reason: string;
  bookingSource: 'staff' | 'patient_portal';
  linkedRequestId?: string;
  arrivedAt?: string;
  arrivedBy?: string;
  cancelledReason?: string;
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface SlotHold {
  id: string;
  sessionId: string;
  date: string;
  startTime: string;
  endTime: string;
  patientId: string;
  heldByUserId: string;
  expiresAt: string;
}

export type RequestCategory =
  | 'booking_enquiry'
  | 'administrative'
  | 'clinician_callback'
  | 'fit_note'
  | 'medication_enquiry'
  | 'registration_issue'
  | 'document_enquiry'
  | 'follow_up';

export type ClinicalUrgency =
  | 'unassigned'
  | 'routine'
  | 'soon'
  | 'urgent_today';

export interface PatientRequest {
  id: string;
  patientId: string;
  submittedByUserId: string;
  submittedViaProxy: boolean;
  category: RequestCategory;
  patientDescription: string;
  staffSummary: string;
  status:
    | 'submitted'
    | 'in_admin_review'
    | 'awaiting_clinician_review'
    | 'appointment_offered'
    | 'resolved'
    | 'closed';
  routingRuleApplied: string;
  clinicalUrgency: ClinicalUrgency;
  urgencyAssignedBy?: string;
  urgencyAssignedRole?: StaffRole;
  urgencyAssignedAt?: string;
  clinicalRationale?: string;
  linkedAppointmentId?: string;
  createdAt: string;
  updatedAt: string;
}

export type ConsultationStatus = 'Draft' | 'Reviewed' | 'Signed' | 'Amended';

export interface TerminologyConcept {
  system: 'SNOMED_CT_DEMO' | 'DMD_DEMO';
  code: string;
  term: string;
  adapterStatus: 'prototype_unvalidated_terminology';
}

export interface ConsultationAmendment {
  id: string;
  consultationId: string;
  authorId: string;
  authorName: string;
  authorRole: StaffRole;
  reason: string;
  amendmentText: string;
  recordedAt: string;
}

export interface Consultation {
  id: string;
  patientId: string;
  appointmentId?: string;
  clinicianId: string;
  authorName: string;
  authorRole: StaffRole;
  siteId: string;
  mode: AppointmentMode;
  encounterTime: string;
  recordedAt: string;
  provenance: 'clinician_entry' | 'portal_intake' | 'imported_record';
  status: ConsultationStatus;
  presentingComplaint: string;
  history: string;
  examination: string;
  assessment: string;
  plan: string;
  freeText: string;
  codedConcepts: TerminologyConcept[];
  signedAt?: string;
  signedBy?: string;
  contentHash?: string;
  amendments: ConsultationAmendment[];
  version: number;
  updatedAt: string;
}

export interface ProblemRecord {
  id: string;
  patientId: string;
  title: string;
  onsetDate: string;
  status: 'active' | 'resolved';
  significance: 'significant' | 'minor';
  recordedBy: string;
  recordedAt: string;
}

export interface ObservationRecord {
  id: string;
  patientId: string;
  type: 'Blood Pressure' | 'Heart Rate' | 'Temperature' | 'SpO2' | 'Weight' | 'HbA1c (POC)';
  value: string;
  unit: string;
  recordedAt: string;
  recordedBy: string;
  siteName: string;
}

export interface MedicationHistoryItem {
  id: string;
  patientId: string;
  drugName: string;
  doseInstruction: string;
  form: string;
  isRepeat: boolean;
  status: 'active' | 'historical' | 'stopped';
  startedAt: string;
  lastIssuedAt?: string;
  prescribedBy: string;
}

export interface RepeatAuthorisation {
  id: string;
  patientId: string;
  medicationId: string;
  drugName: string;
  doseInstruction: string;
  authorisedBy: string;
  authorisedRole: StaffRole;
  maxIssues: number;
  issuesUsed: number;
  reviewDate: string;
  status: 'active' | 'review_overdue' | 'suspended';
}

export interface DrugSafetyCheckResult {
  checkedAt: string;
  knowledgeSource: string;
  coverageStatus: 'partial_prototype_rules' | 'unknown_coverage';
  allergyConflict: 'conflict_detected' | 'not_checked_unknown_allergy_status' | 'no_match_in_prototype_rules';
  warnings: string[];
}

export interface RepeatMedicineRequest {
  id: string;
  patientId: string;
  authorisationId: string;
  drugName: string;
  patientNote: string;
  nominatedPharmacy: string;
  submittedByUserId: string;
  submittedAt: string;
  status:
    | 'submitted'
    | 'admin_checked'
    | 'awaiting_prescriber'
    | 'approved_simulated'
    | 'rejected';
  adminCheckedBy?: string;
  adminCheckedAt?: string;
  prescribingDecision?: {
    decision: 'approved' | 'rejected';
    decidedBy: string;
    decidedRole: StaffRole;
    decidedAt: string;
    reason: string;
    safetyCheck: DrugSafetyCheckResult;
  };
  simulatedTransmission?: {
    transmissionId: string;
    transmittedAt: string;
    label: 'SIMULATED TRANSMISSION — NO REAL PRESCRIPTION ISSUED';
    dispensingStatus: 'queued_for_pharmacy_mock' | 'dispensed_mock';
  };
}

export type LabResultStatus =
  | 'received'
  | 'matched'
  | 'awaiting_clinical_review'
  | 'reviewed'
  | 'action_assigned'
  | 'follow_up_completed';

export interface LabResultAmendment {
  version: number;
  previousValue: string;
  newValue: string;
  amendedAt: string;
  reason: string;
}

export interface LabResult {
  id: string;
  externalMessageId: string;
  patientId: string | null;
  rawPatientSummary: string;
  matchStatus: 'matched' | 'unmatched' | 'uncertain_match';
  testName: string;
  originalValue: string;
  units: string;
  referenceRange: string | null;
  referenceRangeAvailable: boolean;
  abnormalFlag: 'normal' | 'high' | 'low' | 'critical' | 'unknown';
  sourceLab: string;
  specimenCollectedAt: string;
  reportedAt: string;
  status: LabResultStatus;
  version: number;
  amendments: LabResultAmendment[];
  viewedByIds: string[];
  reviewedBy?: string;
  reviewedByRole?: StaffRole;
  reviewedAt?: string;
  reviewNote?: string;
  outstandingActionTaskId?: string;
  patientCommunicationId?: string;
}

export interface IncomingDocument {
  id: string;
  externalMessageId: string;
  patientId: string | null;
  rawPatientLabel: string;
  matchStatus: 'matched' | 'unmatched' | 'uncertain_match';
  documentType: 'hospital_discharge' | 'outpatient_letter' | 'radiology_report' | 'insurance_enquiry';
  senderOrganisation: string;
  receivedAt: string;
  title: string;
  ocrExtractedText: string;
  ocrProvenance: {
    engine: string;
    confidencePercent: number;
    requiresClinicianReview: boolean;
    enteredAuthoritativeRecord: boolean;
  };
  classification: string;
  status: 'queued' | 'matched' | 'awaiting_clinician_review' | 'reviewed' | 'filed';
  reviewedBy?: string;
  reviewedAt?: string;
  assignedTaskId?: string;
  visibleToPatient: boolean;
}

export type ReferralStatus =
  | 'draft'
  | 'ready_for_submission'
  | 'submitted_to_external_service'
  | 'accepted_by_service'
  | 'rejected_by_service'
  | 'follow_up_completed';

export interface Referral {
  id: string;
  patientId: string;
  clinicianId: string;
  authorName: string;
  specialty: string;
  targetService: string;
  urgency: 'routine' | 'urgent' | 'two_week_wait_pathway';
  clinicalSummary: string;
  supportingDocumentIds: string[];
  supportingResultIds: string[];
  status: ReferralStatus;
  externalServiceReference?: string;
  submittedAt?: string;
  externalStatusNote?: string;
  followUpTaskId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PracticeTask {
  id: string;
  patientId?: string;
  title: string;
  description: string;
  category: 'follow_up' | 'admin' | 'results' | 'correspondence' | 'recall' | 'registration';
  ownerId: string;
  ownerName: string;
  ownerRole: StaffRole;
  dueDate: string;
  dependsOnTaskId?: string;
  escalationRule: string;
  escalated: boolean;
  status: 'open' | 'in_progress' | 'completed';
  completionEvidence?: string;
  completedBy?: string;
  completedAt?: string;
  linkedEntityType?: 'consultation' | 'lab_result' | 'document' | 'referral' | 'request' | 'recall';
  linkedEntityId?: string;
  createdAt: string;
}

export interface RecallRule {
  id: string;
  name: string;
  registerCriteria: string;
  intervalMonths: number;
  clinicianApprovedBy: string;
  active: boolean;
  eligiblePatientIds: string[];
  lastRunAt?: string;
}

export type CommChannel = 'sms' | 'email' | 'letter' | 'portal_message';
export type CommDeliveryStatus = 'queued' | 'sent' | 'delivered' | 'failed';

export interface CommunicationRecord {
  id: string;
  patientId: string;
  channel: CommChannel;
  subject: string;
  lockScreenSafePreview: string;
  body: string;
  deliveryStatus: CommDeliveryStatus;
  failureReason?: string;
  attempts: number;
  linkedTaskId?: string;
  sentBy: string;
  createdAt: string;
  updatedAt: string;
  patientVisible: boolean;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: ActorRole;
  action: string;
  entityType: string;
  entityId: string;
  patientId?: string;
  summary: string;
  outcome: 'success' | 'denied' | 'conflict' | 'failed';
}

export interface ConfigurationChange {
  id: string;
  timestamp: string;
  changedBy: string;
  area: 'session_template' | 'routing_rule' | 'recall_rule' | 'record_release_policy' | 'practice_site';
  summary: string;
}

export interface IntegrationBoundarySpec {
  id: string;
  name: string;
  mode: 'simulated_mock_adapter';
  authoritativeSource: string;
  supportedOperations: string[];
  authentication: string;
  dataMapping: string;
  deliveryGuarantees: string;
  duplicateHandling: string;
  reconciliation: string;
  failureRecovery: string;
}

export interface HazardLogEntry {
  id: string;
  hazardTitle: string;
  clinicalRisk: string;
  severity: 'High' | 'Critical' | 'Moderate';
  mitigationsImplemented: string[];
  verificationStatus: 'verified_in_tests' | 'mitigated_in_prototype';
}

export interface OperationalMetrics {
  generatedAt: string;
  disclaimer: string;
  totalAppointmentSlots: number;
  bookedAppointments: number;
  arrivedOrAttended: number;
  cancelledAppointments: number;
  dnaCount: number;
  requestsAwaitingReview: number;
  outstandingResultActions: number;
  unmatchedResults: number;
  unprocessedCorrespondence: number;
  failedCommunications: number;
  openTasks: number;
}

export interface CapabilityMatrixEntry {
  capability: string;
  status: 'implemented' | 'simulated' | 'deferred';
  details: string;
}

export interface DemoStepStatus {
  stepNumber: number;
  title: string;
  completed: boolean;
  evidence?: string;
}

export interface PracticeDatabase {
  users: (SessionUser & {passwordHash: string})[];
  sites: PracticeSite[];
  rooms: Room[];
  clinicians: Clinician[];
  sessionTemplates: SessionTemplate[];
  sessions: ClinicianSession[];
  patients: Patient[];
  duplicateCandidates: DuplicateCandidate[];
  contactUpdateRequests: PatientContactUpdateRequest[];
  appointments: Appointment[];
  slotHolds: SlotHold[];
  requests: PatientRequest[];
  consultations: Consultation[];
  problems: ProblemRecord[];
  observations: ObservationRecord[];
  medications: MedicationHistoryItem[];
  repeatAuthorisations: RepeatAuthorisation[];
  repeatRequests: RepeatMedicineRequest[];
  labResults: LabResult[];
  documents: IncomingDocument[];
  referrals: Referral[];
  tasks: PracticeTask[];
  recallRules: RecallRule[];
  communications: CommunicationRecord[];
  auditEvents: AuditEvent[];
  configurationHistory: ConfigurationChange[];
  processedExternalMessageIds: string[];
}
