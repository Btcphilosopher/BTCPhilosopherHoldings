import crypto from 'node:crypto';
import type {
  ActorRole,
  AuditEvent,
  PracticeDatabase,
  ProxyScope,
  SessionUser,
  StaffRole,
} from '../shared/models';

const SESSION_SECRET =
  process.env['SESSION_SECRET'] || crypto.randomBytes(32).toString('hex');

export const STAFF_ROLES: readonly StaffRole[] = [
  'GP_PARTNER',
  'PRACTICE_NURSE',
  'PHARMACIST',
  'RECEPTIONIST',
  'PRACTICE_MANAGER',
] as const;

export const CLINICAL_SIGNING_ROLES: readonly StaffRole[] = [
  'GP_PARTNER',
  'PRACTICE_NURSE',
  'PHARMACIST',
] as const;

export const PRESCRIBING_ROLES: readonly StaffRole[] = [
  'GP_PARTNER',
  'PHARMACIST',
] as const;

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) {
    return false;
  }
  const [salt, key] = parts;
  if (!salt || !key) {
    return false;
  }
  const derived = crypto.scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(key, 'hex');
  if (derived.length !== keyBuf.length) {
    return false;
  }
  return crypto.timingSafeEqual(derived, keyBuf);
}

interface TokenPayload {
  uid: string;
  role: ActorRole;
  exp: number;
}

export function issueSessionToken(user: SessionUser): string {
  const payload: TokenPayload = {
    uid: user.id,
    role: user.role,
    exp: Date.now() + 8 * 60 * 60 * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(
  token: string | undefined,
  db: Readonly<PracticeDatabase>,
): SessionUser | null {
  if (!token) {
    return null;
  }
  const dotIdx = token.indexOf('.');
  if (dotIdx <= 0) {
    return null;
  }
  const encoded = token.slice(0, dotIdx);
  const sig = token.slice(dotIdx + 1);
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(
      Buffer.from(encoded, 'base64url').toString('utf8'),
    ) as TokenPayload;
    if (!parsed.uid || parsed.exp < Date.now()) {
      return null;
    }
    const found = db.users.find((u) => u.id === parsed.uid);
    if (!found) {
      return null;
    }
    return sanitizeUser(found);
  } catch {
    return null;
  }
}

export function sanitizeUser(
  user: SessionUser & {passwordHash?: string},
): SessionUser {
  return {
    id: user.id,
    name: user.name,
    role: user.role,
    title: user.title,
    mfaVerified: user.mfaVerified,
    siteId: user.siteId,
    patientId: user.patientId,
    linkedPatientIds: user.linkedPatientIds,
  };
}

export function isStaffRole(role: ActorRole): role is StaffRole {
  return (STAFF_ROLES as readonly string[]).includes(role);
}

export function canClinicallySign(role: ActorRole): boolean {
  return (CLINICAL_SIGNING_ROLES as readonly string[]).includes(role);
}

export function canPrescribe(role: ActorRole): boolean {
  return (PRESCRIBING_ROLES as readonly string[]).includes(role);
}

export function assertPatientPortalAccess(
  user: SessionUser,
  targetPatientId: string,
  requiredScope: ProxyScope,
  db: Readonly<PracticeDatabase>,
): {allowed: boolean; viaProxy: boolean; reason?: string} {
  if (isStaffRole(user.role)) {
    return {allowed: true, viaProxy: false};
  }
  if (user.patientId === targetPatientId) {
    return {allowed: true, viaProxy: false};
  }
  const targetPatient = db.patients.find((p) => p.internalId === targetPatientId);
  if (!targetPatient) {
    return {allowed: false, viaProxy: false, reason: 'Patient record not found'};
  }
  const proxy = targetPatient.proxies.find(
    (pr) => pr.proxyUserId === user.id && pr.verificationStatus === 'verified',
  );
  if (!proxy) {
    return {
      allowed: false,
      viaProxy: false,
      reason: 'Access denied: no verified identity or proxy relationship for this patient',
    };
  }
  if (!proxy.scopes.includes(requiredScope)) {
    return {
      allowed: false,
      viaProxy: true,
      reason: `Proxy access is verified but does not include the "${requiredScope}" scope`,
    };
  }
  return {allowed: true, viaProxy: true};
}

export function recordAudit(
  db: PracticeDatabase,
  params: {
    actor: Pick<SessionUser, 'id' | 'name' | 'role'>;
    action: string;
    entityType: string;
    entityId: string;
    patientId?: string;
    summary: string;
    outcome: AuditEvent['outcome'];
  },
): AuditEvent {
  const event: AuditEvent = {
    id: `AUD-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`,
    timestamp: new Date().toISOString(),
    actorId: params.actor.id,
    actorName: params.actor.name,
    actorRole: params.actor.role,
    action: params.action,
    entityType: params.entityType,
    entityId: params.entityId,
    patientId: params.patientId,
    summary: params.summary,
    outcome: params.outcome,
  };
  db.auditEvents.unshift(event);
  return event;
}
