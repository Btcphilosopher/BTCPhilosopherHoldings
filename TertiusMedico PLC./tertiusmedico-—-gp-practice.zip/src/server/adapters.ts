import type {
  AllergyRecord,
  AllergyStatus,
  CapabilityMatrixEntry,
  DrugSafetyCheckResult,
  HazardLogEntry,
  IntegrationBoundarySpec,
  TerminologyConcept,
} from '../shared/models';

export interface TerminologyAdapter {
  searchConcepts(query: string): TerminologyConcept[];
}

export class PrototypeTerminologyAdapter implements TerminologyAdapter {
  private readonly concepts: TerminologyConcept[] = [
    {
      system: 'SNOMED_CT_DEMO',
      code: '38341003',
      term: 'Essential hypertension (prototype reference)',
      adapterStatus: 'prototype_unvalidated_terminology',
    },
    {
      system: 'SNOMED_CT_DEMO',
      code: '44054006',
      term: 'Type 2 diabetes mellitus (prototype reference)',
      adapterStatus: 'prototype_unvalidated_terminology',
    },
    {
      system: 'SNOMED_CT_DEMO',
      code: '195967001',
      term: 'Asthma (prototype reference)',
      adapterStatus: 'prototype_unvalidated_terminology',
    },
    {
      system: 'SNOMED_CT_DEMO',
      code: '49727002',
      term: 'Cough (prototype reference)',
      adapterStatus: 'prototype_unvalidated_terminology',
    },
    {
      system: 'SNOMED_CT_DEMO',
      code: '30148001',
      term: 'Lower back pain (prototype reference)',
      adapterStatus: 'prototype_unvalidated_terminology',
    },
    {
      system: 'DMD_DEMO',
      code: '322236009',
      term: 'Ramipril 5mg capsules (prototype dm+d reference)',
      adapterStatus: 'prototype_unvalidated_terminology',
    },
    {
      system: 'DMD_DEMO',
      code: '318248001',
      term: 'Metformin 500mg tablets (prototype dm+d reference)',
      adapterStatus: 'prototype_unvalidated_terminology',
    },
  ];

  searchConcepts(query: string): TerminologyConcept[] {
    const q = query.trim().toLowerCase();
    if (!q) {
      return this.concepts;
    }
    return this.concepts.filter(
      (c) =>
        c.term.toLowerCase().includes(q) || c.code.toLowerCase().includes(q),
    );
  }
}

export interface DrugSafetyAdapter {
  checkRepeatPrescribing(params: {
    drugName: string;
    allergyStatus: AllergyStatus;
    allergies: AllergyRecord[];
    activeMedications: string[];
  }): DrugSafetyCheckResult;
}

export class PrototypeDrugSafetyAdapter implements DrugSafetyAdapter {
  checkRepeatPrescribing(params: {
    drugName: string;
    allergyStatus: AllergyStatus;
    allergies: AllergyRecord[];
    activeMedications: string[];
  }): DrugSafetyCheckResult {
    const warnings: string[] = [];
    const lowerDrug = params.drugName.toLowerCase();

    let allergyConflict: DrugSafetyCheckResult['allergyConflict'] =
      'no_match_in_prototype_rules';

    if (params.allergyStatus === 'none_recorded') {
      allergyConflict = 'not_checked_unknown_allergy_status';
      warnings.push(
        'Allergy status is "No allergies recorded (unverified)" — do not treat as confirmed No Known Allergies.',
      );
    } else {
      for (const allergy of params.allergies) {
        const sub = allergy.substance.toLowerCase();
        if (
          (sub.includes('penicillin') && lowerDrug.includes('amoxicillin')) ||
          lowerDrug.includes(sub)
        ) {
          allergyConflict = 'conflict_detected';
          warnings.push(
            `Recorded ${allergy.severity} allergy to ${allergy.substance} (${allergy.reaction}).`,
          );
        }
      }
    }

    const activeLower = params.activeMedications.map((m) => m.toLowerCase());
    if (
      lowerDrug.includes('ramipril') &&
      activeLower.some((m) => m.includes('ibuprofen') || m.includes('naproxen'))
    ) {
      warnings.push(
        'Prototype rule notice: ACE inhibitor concurrent with NSAID — verify renal function and BP.',
      );
    }

    const knownInPrototype =
      lowerDrug.includes('ramipril') ||
      lowerDrug.includes('metformin') ||
      lowerDrug.includes('atorvastatin') ||
      lowerDrug.includes('salbutamol') ||
      lowerDrug.includes('amoxicillin') ||
      lowerDrug.includes('omeprazole');

    const coverageStatus = knownInPrototype
      ? 'partial_prototype_rules'
      : 'unknown_coverage';

    if (coverageStatus === 'unknown_coverage') {
      warnings.push(
        'Checking coverage is UNKNOWN in this prototype — must not be interpreted as a clean safety check.',
      );
    }

    return {
      checkedAt: new Date().toISOString(),
      knowledgeSource:
        'Prototype Local Ruleset (NOT BNF / First Databank / NHS dm+d validated)',
      coverageStatus,
      allergyConflict,
      warnings,
    };
  }
}

export const INTEGRATION_BOUNDARIES: IntegrationBoundarySpec[] = [
  {
    id: 'INT-PDS',
    name: 'Personal Demographics Service (PDS) Identity Adapter',
    mode: 'simulated_mock_adapter',
    authoritativeSource: 'NHS Spine PDS (Simulated locally via MockPdsAdapter)',
    supportedOperations: ['Trace NHS Number', 'Verify Demographics', 'Retrieve Death/Deducted Flag'],
    authentication: 'Production requires NHS CIS2 + mTLS + signed JWT; prototype uses local mock',
    dataMapping: 'FHIR R4 Patient (UK Core) <-> Internal Patient Record (internalId primary)',
    deliveryGuarantees: 'Synchronous request-response with trace status tracking',
    duplicateHandling: 'Flags potential duplicates to DuplicateCandidate queue without auto-merging',
    reconciliation: 'Nightly demographic drift check compares local record vs simulated PDS trace',
    failureRecovery: 'Falls back to "trace_pending" status; never blocks emergency clinical entry',
  },
  {
    id: 'INT-GPCONNECT',
    name: 'Registration & Shared Record Adapter (GP Connect / GP2GP boundary)',
    mode: 'simulated_mock_adapter',
    authoritativeSource: 'Previous GP Practice / GP Connect Access Record (Simulated)',
    supportedOperations: ['New Registration Intake', 'Record Summary Preview', 'Deduction Notification'],
    authentication: 'Production requires Spine ASID + JWT; prototype uses mock adapter',
    dataMapping: 'UK Core Bundle -> Imported Record with explicit provenance tag',
    deliveryGuarantees: 'At-least-once MESH transfer with idempotent externalMessageId',
    duplicateHandling: 'Deduplicates by externalMessageId; clinical conflicts routed to review',
    reconciliation: 'Tracks pending_verification registrations until staff sign-off',
    failureRecovery: 'Dead-letter queue with retry and manual registration task fallback',
  },
  {
    id: 'INT-EPS',
    name: 'Electronic Prescription Service (EPS) Boundary',
    mode: 'simulated_mock_adapter',
    authoritativeSource: 'NHS EPS Spine Broker (Simulated — NO REAL PRESCRIPTIONS ISSUED)',
    supportedOperations: ['Validate Prescriber Role', 'Simulate Prescription Transmission', 'Poll Dispensing Mock'],
    authentication: 'Production requires Smartcard / CIS2 prescribing token; prototype enforces GP/Pharmacist RBAC',
    dataMapping: 'MedicationRequest -> Simulated EPS Payload (dm+d demo codes)',
    deliveryGuarantees: 'Idempotent request ID per approved prescribing decision',
    duplicateHandling: 'One transmission per approved RepeatMedicineRequest',
    reconciliation: 'Compares approved requests against simulated dispensing confirmation',
    failureRecovery: 'Failed transmission stays in prescriber queue with explicit error banner',
  },
  {
    id: 'INT-PATHOLOGY',
    name: 'Pathology Laboratory Results Feed (HL7 v2 / FHIR DiagnosticReport)',
    mode: 'simulated_mock_adapter',
    authoritativeSource: 'Pennine Acute Pathology Laboratory (Simulated feed)',
    supportedOperations: ['Ingest Result', 'Ingest Corrected/Amended Result', 'Flag Unmatched Patient'],
    authentication: 'Production requires MESH mailbox TLS + NHS Digital cert; prototype uses signed internal route',
    dataMapping: 'Lab payload -> LabResult preserving originalValue, units, sourceLab, referenceRange',
    deliveryGuarantees: 'At-least-once ingestion with strict externalMessageId deduplication',
    duplicateHandling: 'Duplicate externalMessageId returns existing record without creating duplicate work',
    reconciliation: 'Unmatched results held in unmatched queue; daily reconciliation flags >24h unreviewed',
    failureRecovery: 'Malformed/unmatched payloads stored intact for manual matching',
  },
  {
    id: 'INT-ERS',
    name: 'NHS e-Referral Service (e-RS) Boundary',
    mode: 'simulated_mock_adapter',
    authoritativeSource: 'Secondary Care Referral Broker (Simulated)',
    supportedOperations: ['Prepare Referral Draft', 'Submit to Simulated Service', 'Poll Acceptance Status'],
    authentication: 'Production requires CIS2 clinician context; prototype enforces clinical author role',
    dataMapping: 'Internal Referral + selected supporting documents -> Simulated e-RS UBRN',
    deliveryGuarantees: 'Explicit two-stage state: Drafted locally vs Submitted/Accepted externally',
    duplicateHandling: 'Prevents double-submission of active referral',
    reconciliation: 'Background worker checks for unacknowledged submissions >48h',
    failureRecovery: 'Failed submissions stay at "ready_for_submission" with follow-up task',
  },
  {
    id: 'INT-NOTIFY',
    name: 'Patient Messaging Gateway (SMS / Email / Letter / Portal)',
    mode: 'simulated_mock_adapter',
    authoritativeSource: 'NHS Notify / Practice Gateway (Simulated)',
    supportedOperations: ['Dispatch Lock-Screen Safe SMS', 'Dispatch Email', 'Log Postal Letter', 'Retry Failed'],
    authentication: 'Server-side API key in production; mock delivery status generator in prototype',
    dataMapping: 'CommunicationRecord -> Channel payload stripping clinical details from SMS/lock-screen preview',
    deliveryGuarantees: 'At-least-once queued dispatch; delivery tracked independently of clinical task closure',
    duplicateHandling: 'Retry increments attempts counter on single CommunicationRecord',
    reconciliation: 'Failed deliveries remain flagged in reception/task reports until retried or resolved',
    failureRecovery: 'Visible failed state + one-click retry or switch to postal letter',
  },
  {
    id: 'INT-SHARED-CARE',
    name: 'Regional Shared Care Record Viewer Boundary',
    mode: 'simulated_mock_adapter',
    authoritativeSource: 'Regional Integrated Care Record (Simulated read-only boundary)',
    supportedOperations: ['Read External Encounters Summary', 'View Hospital Discharge Provenance'],
    authentication: 'Role-based clinical viewing audit logged per access',
    dataMapping: 'External summary kept distinct from locally authored GP notes',
    deliveryGuarantees: 'Read-only on-demand fetch with timeout fallback',
    duplicateHandling: 'Keyed by source organisation + external document ID',
    reconciliation: 'Provenance displayed alongside local GP record',
    failureRecovery: 'Graceful degraded banner when external viewer unavailable',
  },
];

export const PROTOTYPE_HAZARD_LOG: HazardLogEntry[] = [
  {
    id: 'HAZ-001',
    hazardTitle: 'Wrong-patient clinical note, prescribing, or order entry',
    clinicalRisk: 'Clinician switches patient record while drafting notes or orders, causing entry against wrong patient.',
    severity: 'Critical',
    mitigationsImplemented: [
      'Persistent Patient Context Banner pinned across clinical views showing Full Name, DOB, Internal ID, NHS Number & verification status.',
      'Client dirty-state guard blocks patient switching when unsaved consultation/order changes exist.',
      'Server validates expectedPatientId on consultation, medication, and referral mutations.',
    ],
    verificationStatus: 'verified_in_tests',
  },
  {
    id: 'HAZ-002',
    hazardTitle: 'Lost or unactioned patient portal requests',
    clinicalRisk: 'Urgent clinical callback or fit-note request submitted online goes unseen or is closed without clinician triage.',
    severity: 'High',
    mitigationsImplemented: [
      'Clear non-emergency 999/111 warning on portal submission.',
      'Patient submission status accurately states "Submitted — awaiting practice review".',
      'Server-side RBAC blocks receptionists from assigning clinical urgency; routes clinical items to clinician queue.',
    ],
    verificationStatus: 'verified_in_tests',
  },
  {
    id: 'HAZ-003',
    hazardTitle: 'Incomplete results follow-up or silent auto-review',
    clinicalRisk: 'Abnormal or amended lab result is opened briefly and mistakenly treated as reviewed, or follow-up closes on SMS send.',
    severity: 'Critical',
    mitigationsImplemented: [
      'Viewing a result records viewedByIds only and NEVER transitions status to reviewed.',
      'Sending patient communication never auto-completes the linked PracticeTask; completion requires explicit evidence.',
      'Unmatched results remain quarantined until manual staff match.',
    ],
    verificationStatus: 'verified_in_tests',
  },
  {
    id: 'HAZ-004',
    hazardTitle: 'Stale medicine lists & misleading allergy/safety status',
    clinicalRisk: 'Clinician assumes "no allergy recorded" means "no known allergies", or unknown drug check coverage appears clean.',
    severity: 'Critical',
    mitigationsImplemented: [
      'Explicit distinction between "No allergies recorded (unverified)" and "Confirmed No Known Drug Allergies (NKDA)".',
      'DrugSafetyAdapter explicitly surfaces "unknown_coverage" warning and never reports clean safety when coverage is unknown.',
      'Repeat requests strictly separate patient request from clinician prescribing decision.',
    ],
    verificationStatus: 'verified_in_tests',
  },
  {
    id: 'HAZ-005',
    hazardTitle: 'Incorrect access, privilege escalation, or proxy over-reach',
    clinicalRisk: 'Receptionist signs clinical notes/prescriptions, or proxy accesses unpermitted records/medicines.',
    severity: 'High',
    mitigationsImplemented: [
      'Server-side RBAC on every API endpoint: signing, clinical urgency, result review, and prescribing restricted to authorised clinicians.',
      'Verified proxy relationships enforce per-scope checks (appointments, requests, medicines, messages, records).',
      'All denied and sensitive actions written to immutable-style AuditEvent log.',
    ],
    verificationStatus: 'verified_in_tests',
  },
  {
    id: 'HAZ-006',
    hazardTitle: 'Failed synchronisation, duplicate imports, or interrupted save',
    clinicalRisk: 'Network drop loses consultation draft or duplicate lab feed creates conflicting actions.',
    severity: 'High',
    mitigationsImplemented: [
      'Client preserves unsaved draft during interrupted save with explicit retry banner.',
      'Idempotent externalMessageId deduplication on lab and correspondence imports.',
      'Transactional mutex prevents double-booking and preserves optimistic version checks.',
    ],
    verificationStatus: 'verified_in_tests',
  },
];

export const CAPABILITY_MATRIX: CapabilityMatrixEntry[] = [
  {
    capability: 'Staff Workstation (12-section NHS-inspired UI) & Mobile-first Patient Portal',
    status: 'implemented',
    details: 'Live Angular 21 zoneless standalone application served with Express API backend.',
  },
  {
    capability: 'Patient Identity, Duplicate Review, Proxy Scopes & Wrong-Patient Guard',
    status: 'implemented',
    details: 'Full server-enforced patient isolation, manual duplicate review, verified proxy scopes, and unsaved-draft patient switch lock.',
  },
  {
    capability: 'Transactional Scheduling (Europe/London), Slot Holds & Reschedule Validation',
    status: 'implemented',
    details: 'Atomic mutex prevents double-booking, enforces clinician leave/breaks/travel buffers, and preserves bookings on template change.',
  },
  {
    capability: 'Consultations (Draft -> Reviewed -> Signed -> Amended) & Hash Immutability',
    status: 'implemented',
    details: 'Signed notes are SHA-256 locked on server; amendments append linked records preserving originals.',
  },
  {
    capability: 'Results, Correspondence OCR Provenance, Tasks, Recalls & Audit Trail',
    status: 'implemented',
    details: 'Full workflow state machines, manual matching queues, background worker reconciliation, and audit search.',
  },
  {
    capability: 'NHS Spine PDS, EPS Prescribing, Pathology HL7/FHIR, e-RS & SMS/Email Gateways',
    status: 'simulated',
    details: 'Implemented via typed replaceable mock adapters with explicit prototype disclaimers; no real prescriptions or NHS network calls.',
  },
  {
    capability: 'SNOMED CT / dm+d Terminology & BNF Drug Interaction Knowledgebase',
    status: 'simulated',
    details: 'Prototype reference subset; unknown coverage explicitly flagged rather than showing clean checks.',
  },
  {
    capability: 'Live NHS CIS2 Smartcard MFA, External PostgreSQL/FastAPI Split & S3 HSM',
    status: 'deferred',
    details: 'Current runtime executes as an integrated Angular 21 + Express modular monolith with atomic JSON persistence; external NHS/PostgreSQL deployment documented for pre-production.',
  },
];
