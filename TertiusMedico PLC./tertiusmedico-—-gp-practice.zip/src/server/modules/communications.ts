import type {
  CommChannel,
  CommunicationRecord,
  PracticeDatabase,
  PracticeTask,
  SessionUser,
} from '../../shared/models';
import {isStaffRole, recordAudit} from '../auth';
import {DomainError} from './identity';
import {purgeExpiredSlotHolds} from './scheduling';

export function createPracticeTask(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId?: string;
    title: string;
    description: string;
    category: PracticeTask['category'];
    ownerId: string;
    dueDate: string;
    dependsOnTaskId?: string;
    escalationRule?: string;
    linkedEntityType?: PracticeTask['linkedEntityType'];
    linkedEntityId?: string;
  },
): PracticeTask {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const owner = db.users.find((u) => u.id === input.ownerId) ?? actor;
  const task: PracticeTask = {
    id: `TSK-${800 + db.tasks.length + 1}`,
    patientId: input.patientId,
    title: input.title.trim(),
    description: input.description.trim(),
    category: input.category,
    ownerId: owner.id,
    ownerName: owner.name,
    ownerRole: isStaffRole(owner.role) ? owner.role : 'RECEPTIONIST',
    dueDate: input.dueDate,
    dependsOnTaskId: input.dependsOnTaskId || undefined,
    escalationRule: input.escalationRule?.trim() || 'Escalate to Duty Lead after due date',
    escalated: false,
    status: 'open',
    linkedEntityType: input.linkedEntityType,
    linkedEntityId: input.linkedEntityId,
    createdAt: new Date().toISOString(),
  };

  db.tasks.unshift(task);
  recordAudit(db, {
    actor,
    action: 'TASK_CREATED',
    entityType: 'task',
    entityId: task.id,
    patientId: task.patientId,
    summary: `Created task "${task.title}" assigned to ${task.ownerName}.`,
    outcome: 'success',
  });
  return task;
}

export function completePracticeTask(
  db: PracticeDatabase,
  actor: SessionUser,
  taskId: string,
  completionEvidence: string,
): PracticeTask {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const task = db.tasks.find((t) => t.id === taskId);
  if (!task) {
    throw new DomainError(404, 'Task not found.');
  }
  if (task.dependsOnTaskId) {
    const dep = db.tasks.find((d) => d.id === task.dependsOnTaskId);
    if (dep && dep.status !== 'completed') {
      throw new DomainError(
        409,
        `Cannot complete task: dependent task ${dep.id} ("${dep.title}") is still ${dep.status}.`,
      );
    }
  }
  if (!completionEvidence?.trim()) {
    throw new DomainError(400, 'Completion evidence is required to close a practice task.');
  }

  const now = new Date().toISOString();
  task.status = 'completed';
  task.completionEvidence = completionEvidence.trim();
  task.completedBy = actor.name;
  task.completedAt = now;

  // If task is linked to a lab result, transition result to follow_up_completed
  if (task.linkedEntityType === 'lab_result' && task.linkedEntityId) {
    const res = db.labResults.find((r) => r.id === task.linkedEntityId);
    if (res && (res.status === 'reviewed' || res.status === 'action_assigned')) {
      res.status = 'follow_up_completed';
    }
  }

  recordAudit(db, {
    actor,
    action: 'TASK_COMPLETED',
    entityType: 'task',
    entityId: task.id,
    patientId: task.patientId,
    summary: `Completed task ${task.id} with evidence: "${task.completionEvidence}".`,
    outcome: 'success',
  });
  return task;
}

export function sendSimulatedCommunication(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    channel: CommChannel;
    subject: string;
    body: string;
    linkedTaskId?: string;
    simulateFailure?: boolean;
  },
): CommunicationRecord {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const patient = db.patients.find((p) => p.internalId === input.patientId);
  if (!patient) {
    throw new DomainError(404, 'Patient not found.');
  }

  const now = new Date().toISOString();
  // Lock-screen safe preview MUST omit sensitive clinical info
  const lockScreenSafePreview =
    'Pennine Medical Practice: You have a secure practice notification. Open your portal to view details.';

  const comm: CommunicationRecord = {
    id: `COMM-${4001 + db.communications.length}`,
    patientId: patient.internalId,
    channel: input.channel,
    subject: input.subject.trim(),
    lockScreenSafePreview,
    body: input.body.trim(),
    deliveryStatus: input.simulateFailure ? 'failed' : 'delivered',
    failureReason: input.simulateFailure
      ? 'Simulated Gateway Timeout: Recipient carrier rejected message'
      : undefined,
    attempts: 1,
    linkedTaskId: input.linkedTaskId,
    sentBy: actor.name,
    createdAt: now,
    updatedAt: now,
    patientVisible: !input.simulateFailure,
  };

  db.communications.unshift(comm);

  // CRITICAL INVARIANT: Sending a message MUST NOT automatically close linkedTaskId!
  recordAudit(db, {
    actor,
    action: input.simulateFailure ? 'COMMUNICATION_FAILED' : 'COMMUNICATION_SENT_SIMULATED',
    entityType: 'communication',
    entityId: comm.id,
    patientId: comm.patientId,
    summary: `${input.channel.toUpperCase()} status: ${comm.deliveryStatus}. Linked clinical task remains open until explicit completion.`,
    outcome: input.simulateFailure ? 'failed' : 'success',
  });

  return comm;
}

export function retryCommunication(
  db: PracticeDatabase,
  actor: SessionUser,
  commId: string,
  fallbackChannel?: CommChannel,
): CommunicationRecord {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const comm = db.communications.find((c) => c.id === commId);
  if (!comm) {
    throw new DomainError(404, 'Communication record not found.');
  }
  if (fallbackChannel) {
    comm.channel = fallbackChannel;
  }
  comm.attempts += 1;
  comm.deliveryStatus = 'delivered';
  comm.failureReason = undefined;
  comm.patientVisible = true;
  comm.updatedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: 'COMMUNICATION_RETRIED',
    entityType: 'communication',
    entityId: comm.id,
    patientId: comm.patientId,
    summary: `Retried communication ${comm.id} via ${comm.channel}; status now delivered (attempt #${comm.attempts}).`,
    outcome: 'success',
  });
  return comm;
}

export function runBackgroundWorkerTick(
  db: PracticeDatabase,
  actor: SessionUser,
): {
  expiredHoldsRemoved: number;
  tasksEscalated: number;
  recallsGenerated: number;
} {
  const expiredHoldsRemoved = purgeExpiredSlotHolds(db);
  const today = new Date().toISOString().slice(0, 10);
  let tasksEscalated = 0;

  for (const task of db.tasks) {
    if (task.status !== 'completed' && !task.escalated && task.dueDate < today) {
      task.escalated = true;
      tasksEscalated += 1;
    }
  }

  let recallsGenerated = 0;
  for (const rule of db.recallRules) {
    if (!rule.active) continue;
    for (const patientId of rule.eligiblePatientIds) {
      const exists = db.tasks.some(
        (t) =>
          t.patientId === patientId &&
          t.category === 'recall' &&
          t.status !== 'completed' &&
          t.title.includes(rule.name),
      );
      if (!exists) {
        db.tasks.unshift({
          id: `TSK-${800 + db.tasks.length + 1}`,
          patientId,
          title: `Recall due: ${rule.name}`,
          description: `Generated by clinician-approved register (${rule.registerCriteria}).`,
          category: 'recall',
          ownerId: 'USR-NURSE-1',
          ownerName: 'Sarah Booth',
          ownerRole: 'PRACTICE_NURSE',
          dueDate: new Date(Date.now() + 7 * 86400_000).toISOString().slice(0, 10),
          escalationRule: 'Escalate to Recall Lead after 14 days',
          escalated: false,
          status: 'open',
          linkedEntityType: 'recall',
          linkedEntityId: rule.id,
          createdAt: new Date().toISOString(),
        });
        recallsGenerated += 1;
      }
    }
    rule.lastRunAt = new Date().toISOString();
  }

  recordAudit(db, {
    actor,
    action: 'BACKGROUND_WORKER_RECONCILED',
    entityType: 'worker',
    entityId: 'RECONCILER',
    summary: `Worker tick: ${expiredHoldsRemoved} expired holds purged, ${tasksEscalated} tasks escalated, ${recallsGenerated} recall tasks queued.`,
    outcome: 'success',
  });

  return {expiredHoldsRemoved, tasksEscalated, recallsGenerated};
}
