import type {
  ClinicalUrgency,
  PatientRequest,
  PracticeDatabase,
  RequestCategory,
  SessionUser,
} from '../../shared/models';
import {assertPatientPortalAccess, canClinicallySign, isStaffRole, recordAudit} from '../auth';
import {DomainError} from './identity';

const ROUTING_RULES: Record<RequestCategory, string> = {
  booking_enquiry: 'Rule R-01: Booking enquiry -> Reception Care Navigation queue',
  administrative: 'Rule R-02: Administrative enquiry -> Reception Admin queue',
  clinician_callback: 'Rule R-03: Clinical callback -> Authorised Clinician Triage queue',
  fit_note: 'Rule R-05: Fit-note request -> Usual GP review queue',
  medication_enquiry: 'Rule R-04: Medication enquiry -> Clinical Pharmacist / Prescriber queue',
  registration_issue: 'Rule R-06: Registration issue -> Practice Registration Administrator',
  document_enquiry: 'Rule R-07: Document enquiry -> Secretarial & Correspondence queue',
  follow_up: 'Rule R-08: Follow-up enquiry -> Care Coordinator / Clinician review',
};

export function submitPatientRequest(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    category: RequestCategory;
    patientDescription: string;
  },
): PatientRequest {
  const access = assertPatientPortalAccess(actor, input.patientId, 'requests', db);
  if (!access.allowed) {
    recordAudit(db, {
      actor,
      action: 'PATIENT_REQUEST_ACCESS_DENIED',
      entityType: 'patient_request',
      entityId: 'NEW',
      patientId: input.patientId,
      summary: access.reason || 'Denied patient request submission',
      outcome: 'denied',
    });
    throw new DomainError(403, access.reason || 'Access denied.');
  }
  if (!input.patientDescription?.trim()) {
    throw new DomainError(400, 'Please enter a description of your request.');
  }

  const now = new Date().toISOString();
  const clinicalCategories: RequestCategory[] = [
    'clinician_callback',
    'fit_note',
    'medication_enquiry',
    'follow_up',
  ];
  const isClinical = clinicalCategories.includes(input.category);

  const req: PatientRequest = {
    id: `REQ-${200 + db.requests.length + 1}`,
    patientId: input.patientId,
    submittedByUserId: actor.id,
    submittedViaProxy: access.viaProxy,
    category: input.category,
    patientDescription: input.patientDescription.trim(),
    staffSummary: '',
    status: isClinical ? 'awaiting_clinician_review' : 'submitted',
    routingRuleApplied: ROUTING_RULES[input.category],
    clinicalUrgency: 'unassigned',
    createdAt: now,
    updatedAt: now,
  };

  db.requests.unshift(req);
  recordAudit(db, {
    actor,
    action: 'PATIENT_REQUEST_SUBMITTED',
    entityType: 'patient_request',
    entityId: req.id,
    patientId: req.patientId,
    summary: `Submitted ${req.category} request (via proxy: ${req.submittedViaProxy}).`,
    outcome: 'success',
  });
  return req;
}

export function handleRequestAdminAction(
  db: PracticeDatabase,
  actor: SessionUser,
  requestId: string,
  input: {
    staffSummary: string;
    routeToClinician?: boolean;
    markResolved?: boolean;
  },
): PatientRequest {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Only practice staff may update reception summaries.');
  }
  const req = db.requests.find((r) => r.id === requestId);
  if (!req) {
    throw new DomainError(404, 'Request not found.');
  }

  req.staffSummary = input.staffSummary.trim();
  if (input.routeToClinician) {
    req.status = 'awaiting_clinician_review';
  } else if (input.markResolved) {
    req.status = 'resolved';
  } else if (req.status === 'submitted') {
    req.status = 'in_admin_review';
  }
  req.updatedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: 'REQUEST_ADMIN_UPDATED',
    entityType: 'patient_request',
    entityId: req.id,
    patientId: req.patientId,
    summary: `Updated staff summary (patient description preserved verbatim). Status: ${req.status}.`,
    outcome: 'success',
  });
  return req;
}

export function assignRequestClinicalUrgency(
  db: PracticeDatabase,
  actor: SessionUser,
  requestId: string,
  input: {
    clinicalUrgency: ClinicalUrgency;
    clinicalRationale: string;
  },
): PatientRequest {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    recordAudit(db, {
      actor,
      action: 'CLINICAL_URGENCY_DENIED',
      entityType: 'patient_request',
      entityId: requestId,
      summary: `Role ${actor.role} attempted to assign clinical urgency without clinical authorisation.`,
      outcome: 'denied',
    });
    throw new DomainError(
      403,
      'Clinical urgency may only be assigned by an authorised clinician (GP, Nurse, or Pharmacist).',
    );
  }
  const req = db.requests.find((r) => r.id === requestId);
  if (!req) {
    throw new DomainError(404, 'Request not found.');
  }
  if (!input.clinicalRationale?.trim()) {
    throw new DomainError(400, 'Please provide a clinical rationale for urgency triage.');
  }
  const now = new Date().toISOString();
  req.clinicalUrgency = input.clinicalUrgency;
  req.urgencyAssignedBy = actor.name;
  req.urgencyAssignedRole = actor.role;
  req.urgencyAssignedAt = now;
  req.clinicalRationale = input.clinicalRationale.trim();
  req.updatedAt = now;

  recordAudit(db, {
    actor,
    action: 'REQUEST_CLINICAL_URGENCY_ASSIGNED',
    entityType: 'patient_request',
    entityId: req.id,
    patientId: req.patientId,
    summary: `Assigned clinical urgency "${req.clinicalUrgency}" by ${actor.name} (${actor.role}).`,
    outcome: 'success',
  });
  return req;
}
