import crypto from 'node:crypto';
import type {
  PracticeDatabase,
  RepeatMedicineRequest,
  SessionUser,
} from '../../shared/models';
import {PrototypeDrugSafetyAdapter} from '../adapters';
import {assertPatientPortalAccess, canPrescribe, isStaffRole, recordAudit} from '../auth';
import {DomainError} from './identity';

const safetyAdapter = new PrototypeDrugSafetyAdapter();

export function submitRepeatMedicineRequest(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    authorisationId: string;
    patientNote?: string;
    nominatedPharmacy: string;
  },
): RepeatMedicineRequest {
  const access = assertPatientPortalAccess(actor, input.patientId, 'medicines', db);
  if (!access.allowed) {
    recordAudit(db, {
      actor,
      action: 'REPEAT_MED_ACCESS_DENIED',
      entityType: 'repeat_medicine_request',
      entityId: 'NEW',
      patientId: input.patientId,
      summary: access.reason || 'Denied repeat medication access',
      outcome: 'denied',
    });
    throw new DomainError(403, access.reason || 'Access denied.');
  }

  const auth = db.repeatAuthorisations.find(
    (a) => a.id === input.authorisationId && a.patientId === input.patientId,
  );
  if (!auth) {
    throw new DomainError(404, 'Repeat authorisation not found for this patient.');
  }
  if (auth.status === 'suspended') {
    throw new DomainError(409, 'Repeat authorisation is suspended pending clinician review.');
  }

  const req: RepeatMedicineRequest = {
    id: `RREQ-${db.repeatRequests.length + 1}`,
    patientId: input.patientId,
    authorisationId: auth.id,
    drugName: auth.drugName,
    patientNote: input.patientNote?.trim() ?? '',
    nominatedPharmacy: input.nominatedPharmacy.trim() || 'Millbrook Community Pharmacy',
    submittedByUserId: actor.id,
    submittedAt: new Date().toISOString(),
    status: 'submitted',
  };

  db.repeatRequests.unshift(req);
  recordAudit(db, {
    actor,
    action: 'REPEAT_MED_REQUEST_SUBMITTED',
    entityType: 'repeat_medicine_request',
    entityId: req.id,
    patientId: req.patientId,
    summary: `Submitted repeat request for ${req.drugName} (not yet clinically approved).`,
    outcome: 'success',
  });
  return req;
}

export function adminCheckRepeatRequest(
  db: PracticeDatabase,
  actor: SessionUser,
  requestId: string,
): RepeatMedicineRequest {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const req = db.repeatRequests.find((r) => r.id === requestId);
  if (!req) {
    throw new DomainError(404, 'Repeat medicine request not found.');
  }
  req.status = 'awaiting_prescriber';
  req.adminCheckedBy = actor.name;
  req.adminCheckedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: 'REPEAT_MED_ADMIN_CHECKED',
    entityType: 'repeat_medicine_request',
    entityId: req.id,
    patientId: req.patientId,
    summary: `Administrative check completed; routed to prescriber queue.`,
    outcome: 'success',
  });
  return req;
}

export function decideRepeatMedicineRequest(
  db: PracticeDatabase,
  actor: SessionUser,
  requestId: string,
  input: {
    expectedPatientId: string;
    decision: 'approved' | 'rejected';
    reason: string;
  },
): RepeatMedicineRequest {
  if (!isStaffRole(actor.role) || !canPrescribe(actor.role)) {
    recordAudit(db, {
      actor,
      action: 'PRESCRIBING_DECISION_DENIED',
      entityType: 'repeat_medicine_request',
      entityId: requestId,
      summary: `Role ${actor.role} attempted repeat prescribing decision without prescriber authority.`,
      outcome: 'denied',
    });
    throw new DomainError(
      403,
      'Only an authorised prescriber (GP Partner or Independent Pharmacist) may approve or reject repeat medication.',
    );
  }
  const req = db.repeatRequests.find((r) => r.id === requestId);
  if (!req) {
    throw new DomainError(404, 'Repeat medicine request not found.');
  }
  if (req.patientId !== input.expectedPatientId) {
    throw new DomainError(409, 'Wrong-patient guard: request patient mismatch.');
  }
  if (!input.reason?.trim()) {
    throw new DomainError(400, 'Prescribing decision reason is required.');
  }

  const patient = db.patients.find((p) => p.internalId === req.patientId);
  if (!patient) {
    throw new DomainError(404, 'Patient not found.');
  }
  const activeMeds = db.medications
    .filter((m) => m.patientId === patient.internalId && m.status === 'active')
    .map((m) => m.drugName);

  const safetyCheck = safetyAdapter.checkRepeatPrescribing({
    drugName: req.drugName,
    allergyStatus: patient.allergyStatus,
    allergies: patient.allergies,
    activeMedications: activeMeds,
  });

  const now = new Date().toISOString();
  req.prescribingDecision = {
    decision: input.decision,
    decidedBy: actor.name,
    decidedRole: actor.role,
    decidedAt: now,
    reason: input.reason.trim(),
    safetyCheck,
  };

  if (input.decision === 'approved') {
    req.status = 'approved_simulated';
    req.simulatedTransmission = {
      transmissionId: `SIM-EPS-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      transmittedAt: now,
      label: 'SIMULATED TRANSMISSION — NO REAL PRESCRIPTION ISSUED',
      dispensingStatus: 'queued_for_pharmacy_mock',
    };
    const auth = db.repeatAuthorisations.find((a) => a.id === req.authorisationId);
    if (auth) {
      auth.issuesUsed += 1;
    }
    const med = db.medications.find(
      (m) => m.patientId === req.patientId && m.drugName === req.drugName,
    );
    if (med) {
      med.lastIssuedAt = now.slice(0, 10);
    }
  } else {
    req.status = 'rejected';
  }

  recordAudit(db, {
    actor,
    action:
      input.decision === 'approved'
        ? 'REPEAT_MED_APPROVED_SIMULATED'
        : 'REPEAT_MED_REJECTED',
    entityType: 'repeat_medicine_request',
    entityId: req.id,
    patientId: req.patientId,
    summary: `Prescriber ${actor.name} ${input.decision} ${req.drugName} (${safetyCheck.coverageStatus}).`,
    outcome: 'success',
  });

  return req;
}
