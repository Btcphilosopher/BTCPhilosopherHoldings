import type {
  IncomingDocument,
  PracticeDatabase,
  PracticeTask,
  Referral,
  SessionUser,
} from '../../shared/models';
import {canClinicallySign, isStaffRole, recordAudit} from '../auth';
import {DomainError} from './identity';

export function matchDocumentToPatient(
  db: PracticeDatabase,
  actor: SessionUser,
  documentId: string,
  patientId: string,
): IncomingDocument {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const doc = db.documents.find((d) => d.id === documentId);
  if (!doc) {
    throw new DomainError(404, 'Document not found.');
  }
  const patient = db.patients.find((p) => p.internalId === patientId);
  if (!patient) {
    throw new DomainError(404, 'Patient not found.');
  }
  doc.patientId = patient.internalId;
  doc.matchStatus = 'matched';
  doc.status = 'awaiting_clinician_review';

  recordAudit(db, {
    actor,
    action: 'DOCUMENT_PATIENT_MATCHED',
    entityType: 'document',
    entityId: doc.id,
    patientId: patient.internalId,
    summary: `Matched uncertain correspondence ${doc.id} to ${patient.firstName} ${patient.lastName}; queued for clinician review.`,
    outcome: 'success',
  });
  return doc;
}

export function reviewIncomingDocument(
  db: PracticeDatabase,
  actor: SessionUser,
  documentId: string,
  input: {
    classification?: string;
    fileIntoRecord: boolean;
    visibleToPatient?: boolean;
    assignTaskTitle?: string;
  },
): {document: IncomingDocument; createdTask?: PracticeTask} {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    throw new DomainError(
      403,
      'Only an authorised clinician may review OCR correspondence and file it into authoritative clinical records.',
    );
  }
  const doc = db.documents.find((d) => d.id === documentId);
  if (!doc) {
    throw new DomainError(404, 'Document not found.');
  }
  if (!doc.patientId || doc.matchStatus !== 'matched') {
    throw new DomainError(409, 'Document must be explicitly matched to a patient before filing.');
  }

  const now = new Date().toISOString();
  if (input.classification?.trim()) {
    doc.classification = input.classification.trim();
  }
  doc.reviewedBy = actor.name;
  doc.reviewedAt = now;
  doc.ocrProvenance.requiresClinicianReview = false;
  doc.ocrProvenance.enteredAuthoritativeRecord = input.fileIntoRecord;
  doc.status = input.fileIntoRecord ? 'filed' : 'reviewed';
  if (input.visibleToPatient !== undefined) {
    doc.visibleToPatient = input.visibleToPatient;
  }

  let createdTask: PracticeTask | undefined;
  if (input.assignTaskTitle?.trim()) {
    createdTask = {
      id: `TSK-${800 + db.tasks.length + 1}`,
      patientId: doc.patientId,
      title: input.assignTaskTitle.trim(),
      description: `From correspondence: ${doc.title} (${doc.senderOrganisation})`,
      category: 'correspondence',
      ownerId: actor.id,
      ownerName: actor.name,
      ownerRole: actor.role,
      dueDate: new Date(Date.now() + 2 * 86400_000).toISOString().slice(0, 10),
      escalationRule: 'Escalate to Practice Manager after 72h',
      escalated: false,
      status: 'open',
      linkedEntityType: 'document',
      linkedEntityId: doc.id,
      createdAt: now,
    };
    db.tasks.unshift(createdTask);
    doc.assignedTaskId = createdTask.id;
  }

  recordAudit(db, {
    actor,
    action: 'DOCUMENT_CLINICALLY_REVIEWED',
    entityType: 'document',
    entityId: doc.id,
    patientId: doc.patientId,
    summary: `Clinician ${actor.name} reviewed OCR correspondence (${doc.status}).`,
    outcome: 'success',
  });
  return {document: doc, createdTask};
}

export function createReferralDraft(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    expectedPatientId: string;
    specialty: string;
    targetService: string;
    urgency: Referral['urgency'];
    clinicalSummary: string;
    supportingDocumentIds?: string[];
    supportingResultIds?: string[];
  },
): Referral {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    throw new DomainError(403, 'Only authorised clinicians may prepare clinical referrals.');
  }
  if (input.patientId !== input.expectedPatientId) {
    throw new DomainError(409, 'Wrong-patient protection: referral patient mismatch.');
  }
  const now = new Date().toISOString();
  const referral: Referral = {
    id: `REF-${700 + db.referrals.length + 1}`,
    patientId: input.patientId,
    clinicianId: actor.id,
    authorName: actor.name,
    specialty: input.specialty.trim(),
    targetService: input.targetService.trim(),
    urgency: input.urgency,
    clinicalSummary: input.clinicalSummary.trim(),
    supportingDocumentIds: input.supportingDocumentIds ?? [],
    supportingResultIds: input.supportingResultIds ?? [],
    status: 'draft',
    createdAt: now,
    updatedAt: now,
  };
  db.referrals.unshift(referral);

  recordAudit(db, {
    actor,
    action: 'REFERRAL_DRAFT_CREATED',
    entityType: 'referral',
    entityId: referral.id,
    patientId: referral.patientId,
    summary: `Prepared local referral draft ${referral.id} to ${referral.targetService} (not yet submitted externally).`,
    outcome: 'success',
  });
  return referral;
}

export function submitReferralSimulated(
  db: PracticeDatabase,
  actor: SessionUser,
  referralId: string,
): Referral {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    throw new DomainError(403, 'Only authorised clinicians may submit referrals.');
  }
  const ref = db.referrals.find((r) => r.id === referralId);
  if (!ref) {
    throw new DomainError(404, 'Referral not found.');
  }
  if (
    ref.status === 'submitted_to_external_service' ||
    ref.status === 'accepted_by_service'
  ) {
    throw new DomainError(409, 'Referral has already been submitted to the external service.');
  }
  const now = new Date().toISOString();
  ref.status = 'submitted_to_external_service';
  ref.submittedAt = now;
  ref.externalServiceReference = `SIM-UBRN-${Date.now().toString().slice(-6)}`;
  ref.externalStatusNote =
    'Simulated e-RS submission sent — awaiting external service acceptance (not yet accepted).';
  ref.updatedAt = now;

  // Create automatic follow-up task for external acknowledgement
  const task: PracticeTask = {
    id: `TSK-${800 + db.tasks.length + 1}`,
    patientId: ref.patientId,
    title: `Track external acceptance for referral ${ref.id} (${ref.specialty})`,
    description: `Verify ${ref.targetService} accepts simulated UBRN ${ref.externalServiceReference}.`,
    category: 'follow_up',
    ownerId: actor.id,
    ownerName: actor.name,
    ownerRole: actor.role,
    dueDate: new Date(Date.now() + 5 * 86400_000).toISOString().slice(0, 10),
    escalationRule: 'Escalate if external acceptance not received within 5 days',
    escalated: false,
    status: 'open',
    linkedEntityType: 'referral',
    linkedEntityId: ref.id,
    createdAt: now,
  };
  db.tasks.unshift(task);
  ref.followUpTaskId = task.id;

  recordAudit(db, {
    actor,
    action: 'REFERRAL_SUBMITTED_SIMULATED',
    entityType: 'referral',
    entityId: ref.id,
    patientId: ref.patientId,
    summary: `Submitted simulated referral ${ref.id} (${ref.externalServiceReference}); awaiting external acceptance.`,
    outcome: 'success',
  });
  return ref;
}

export function simulateExternalReferralAcceptance(
  db: PracticeDatabase,
  actor: SessionUser,
  referralId: string,
  accepted: boolean,
  note: string,
): Referral {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const ref = db.referrals.find((r) => r.id === referralId);
  if (!ref) {
    throw new DomainError(404, 'Referral not found.');
  }
  if (ref.status !== 'submitted_to_external_service') {
    throw new DomainError(409, 'Referral must be submitted before external acceptance can occur.');
  }
  ref.status = accepted ? 'accepted_by_service' : 'rejected_by_service';
  ref.externalStatusNote = note.trim() || (accepted ? 'Accepted by secondary care triage (simulated).' : 'Returned by secondary care triage (simulated).');
  ref.updatedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: accepted ? 'REFERRAL_ACCEPTED_SIMULATED' : 'REFERRAL_REJECTED_SIMULATED',
    entityType: 'referral',
    entityId: ref.id,
    patientId: ref.patientId,
    summary: `External service status updated to ${ref.status}.`,
    outcome: 'success',
  });
  return ref;
}
