import crypto from 'node:crypto';
import type {
  DuplicateCandidate,
  Patient,
  PatientContactUpdateRequest,
  PracticeDatabase,
  ProxyScope,
  SessionUser,
} from '../../shared/models';
import {recordAudit} from '../auth';

export class DomainError extends Error {
  constructor(
    public readonly statusCode: number,
    message: string,
  ) {
    super(message);
  }
}

export function registerPatient(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    title: string;
    firstName: string;
    lastName: string;
    dob: string;
    sexAtBirth: Patient['sexAtBirth'];
    nhsNumber?: string | null;
    addressLine1: string;
    city: string;
    postcode: string;
    phone: string;
    email: string;
    preferredChannel: Patient['preferredChannel'];
    interpreterRequired?: boolean;
    preferredLanguage?: string;
    accessibilityNeeds?: string[];
    registeredSiteId: string;
    usualGpId: string;
  },
): {patient: Patient; duplicateWarnings: DuplicateCandidate[]} {
  if (!input.firstName?.trim() || !input.lastName?.trim() || !input.dob?.trim()) {
    throw new DomainError(400, 'First name, last name, and date of birth are required.');
  }
  const cleanNhs = input.nhsNumber?.trim() ? input.nhsNumber.trim() : null;
  const now = new Date().toISOString();
  const nextNum = 1001 + db.patients.length;
  const internalId = `PT-${nextNum}`;

  const patient: Patient = {
    internalId,
    nhsNumber: cleanNhs,
    nhsVerificationStatus: cleanNhs ? 'trace_pending' : 'not_supplied',
    title: input.title.trim() || 'Mx',
    firstName: input.firstName.trim(),
    lastName: input.lastName.trim(),
    dob: input.dob.trim(),
    sexAtBirth: input.sexAtBirth || 'Not specified',
    addressLine1: input.addressLine1.trim(),
    city: input.city.trim(),
    postcode: input.postcode.trim().toUpperCase(),
    phone: input.phone.trim(),
    email: input.email.trim(),
    preferredChannel: input.preferredChannel || 'portal',
    interpreterRequired: Boolean(input.interpreterRequired),
    preferredLanguage: input.preferredLanguage?.trim() || 'English',
    accessibilityNeeds: input.accessibilityNeeds ?? [],
    registrationStatus: cleanNhs ? 'registered' : 'pending_verification',
    registeredSiteId: input.registeredSiteId || 'SITE-MILLBROOK',
    usualGpId: input.usualGpId || 'CLN-VANCE',
    allergyStatus: 'none_recorded',
    allergies: [],
    proxies: [],
    sourceSystemIds: {
      legacyPracticeId: `REG-${internalId}`,
    },
    recordReleasePolicy: {
      allowProspectiveNotes: false,
      allowReviewedResults: true,
      allowCorrespondenceSummary: false,
    },
    createdAt: now,
    updatedAt: now,
  };

  // Detect possible duplicates without automatic merging
  const duplicateWarnings: DuplicateCandidate[] = [];
  for (const existing of db.patients) {
    const sameDob = existing.dob === patient.dob;
    const samePostcode =
      existing.postcode.replace(/\s+/g, '').toUpperCase() ===
      patient.postcode.replace(/\s+/g, '').toUpperCase();
    const sameNhs =
      cleanNhs &&
      existing.nhsNumber &&
      cleanNhs.replace(/\s+/g, '') === existing.nhsNumber.replace(/\s+/g, '');
    const similarSurname =
      existing.lastName.toLowerCase().slice(0, 4) ===
      patient.lastName.toLowerCase().slice(0, 4);

    if (sameNhs || (sameDob && (samePostcode || similarSurname))) {
      const candidate: DuplicateCandidate = {
        id: `DUP-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        patientAId: existing.internalId,
        patientBId: patient.internalId,
        matchReason: sameNhs
          ? `Matching NHS Number (${cleanNhs}) — requires manual duplicate review.`
          : `Matching DOB (${patient.dob}) with ${samePostcode ? 'same postcode' : 'similar surname'}.`,
        confidence: sameNhs || (sameDob && samePostcode) ? 'high' : 'moderate',
        status: 'pending_review',
      };
      db.duplicateCandidates.unshift(candidate);
      duplicateWarnings.push(candidate);
    }
  }

  db.patients.push(patient);
  recordAudit(db, {
    actor,
    action: 'PATIENT_REGISTERED',
    entityType: 'patient',
    entityId: patient.internalId,
    patientId: patient.internalId,
    summary: `Registered patient ${patient.firstName} ${patient.lastName} (${patient.internalId}). Duplicate flags: ${duplicateWarnings.length}.`,
    outcome: 'success',
  });

  return {patient, duplicateWarnings};
}

export function verifyNhsNumberMock(
  db: PracticeDatabase,
  actor: SessionUser,
  patientId: string,
): Patient {
  const patient = db.patients.find((p) => p.internalId === patientId);
  if (!patient) {
    throw new DomainError(404, 'Patient not found.');
  }
  if (!patient.nhsNumber) {
    throw new DomainError(400, 'Cannot trace PDS: NHS number has not been supplied.');
  }
  patient.nhsVerificationStatus = 'verified';
  patient.registrationStatus = 'registered';
  patient.sourceSystemIds.pds = `PDS-SYNTH-${patient.nhsNumber.replace(/\s+/g, '')}`;
  patient.updatedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: 'PDS_NHS_NUMBER_VERIFIED_MOCK',
    entityType: 'patient',
    entityId: patient.internalId,
    patientId: patient.internalId,
    summary: 'Simulated PDS trace verified NHS number.',
    outcome: 'success',
  });
  return patient;
}

export function resolveDuplicateCandidate(
  db: PracticeDatabase,
  actor: SessionUser,
  candidateId: string,
  resolution: 'confirmed_distinct' | 'linked_duplicate',
  notes: string,
): DuplicateCandidate {
  const candidate = db.duplicateCandidates.find((d) => d.id === candidateId);
  if (!candidate) {
    throw new DomainError(404, 'Duplicate candidate record not found.');
  }
  candidate.status = resolution;
  candidate.reviewedBy = actor.name;
  candidate.reviewedAt = new Date().toISOString();
  candidate.notes = notes.trim() || 'Reviewed manually by practice staff (records preserved without auto-merge).';

  recordAudit(db, {
    actor,
    action: 'DUPLICATE_PATIENT_REVIEWED',
    entityType: 'duplicate_candidate',
    entityId: candidate.id,
    patientId: candidate.patientAId,
    summary: `Marked duplicate candidate ${candidate.patientAId} / ${candidate.patientBId} as ${resolution}.`,
    outcome: 'success',
  });
  return candidate;
}

export function submitContactUpdateRequest(
  db: PracticeDatabase,
  actor: SessionUser,
  patientId: string,
  requestedChanges: PatientContactUpdateRequest['requestedChanges'],
): PatientContactUpdateRequest {
  const req: PatientContactUpdateRequest = {
    id: `CUR-${Date.now().toString().slice(-5)}`,
    patientId,
    submittedByUserId: actor.id,
    requestedChanges,
    status: 'pending_review',
    submittedAt: new Date().toISOString(),
  };
  db.contactUpdateRequests.unshift(req);
  recordAudit(db, {
    actor,
    action: 'CONTACT_UPDATE_SUBMITTED',
    entityType: 'contact_update_request',
    entityId: req.id,
    patientId,
    summary: 'Submitted demographic/contact update for staff verification.',
    outcome: 'success',
  });
  return req;
}

export function reviewContactUpdateRequest(
  db: PracticeDatabase,
  actor: SessionUser,
  requestId: string,
  decision: 'approved' | 'rejected',
  reason: string,
): PatientContactUpdateRequest {
  const req = db.contactUpdateRequests.find((c) => c.id === requestId);
  if (!req) {
    throw new DomainError(404, 'Contact update request not found.');
  }
  req.status = decision;
  req.reviewedBy = actor.name;
  req.reviewedAt = new Date().toISOString();
  req.reviewReason = reason.trim();

  if (decision === 'approved') {
    const patient = db.patients.find((p) => p.internalId === req.patientId);
    if (patient) {
      if (req.requestedChanges.phone) patient.phone = req.requestedChanges.phone;
      if (req.requestedChanges.email) patient.email = req.requestedChanges.email;
      if (req.requestedChanges.addressLine1) patient.addressLine1 = req.requestedChanges.addressLine1;
      if (req.requestedChanges.postcode) patient.postcode = req.requestedChanges.postcode;
      if (req.requestedChanges.preferredChannel) {
        patient.preferredChannel = req.requestedChanges.preferredChannel;
      }
      patient.updatedAt = new Date().toISOString();
    }
  }

  recordAudit(db, {
    actor,
    action: `CONTACT_UPDATE_${decision.toUpperCase()}`,
    entityType: 'contact_update_request',
    entityId: req.id,
    patientId: req.patientId,
    summary: `Contact update ${decision} by ${actor.name}.`,
    outcome: 'success',
  });
  return req;
}

export function updateProxyScopes(
  db: PracticeDatabase,
  actor: SessionUser,
  patientId: string,
  proxyId: string,
  verificationStatus: 'verified' | 'pending' | 'revoked',
  scopes: ProxyScope[],
): Patient {
  const patient = db.patients.find((p) => p.internalId === patientId);
  if (!patient) {
    throw new DomainError(404, 'Patient not found.');
  }
  const proxy = patient.proxies.find((pr) => pr.id === proxyId);
  if (!proxy) {
    throw new DomainError(404, 'Proxy relationship not found.');
  }
  proxy.verificationStatus = verificationStatus;
  proxy.scopes = scopes;
  proxy.verifiedBy = actor.name;
  proxy.verifiedAt = new Date().toISOString();
  patient.updatedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: 'PROXY_RELATIONSHIP_UPDATED',
    entityType: 'patient',
    entityId: patient.internalId,
    patientId: patient.internalId,
    summary: `Updated proxy ${proxy.proxyName} status to ${verificationStatus} with scopes [${scopes.join(', ')}].`,
    outcome: 'success',
  });
  return patient;
}
