import type {
  LabResult,
  PracticeDatabase,
  PracticeTask,
  SessionUser,
} from '../../shared/models';
import {canClinicallySign, isStaffRole, recordAudit} from '../auth';
import {DomainError} from './identity';

export function ingestLabResult(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    externalMessageId: string;
    patientId: string | null;
    rawPatientSummary: string;
    testName: string;
    originalValue: string;
    units: string;
    referenceRange: string | null;
    abnormalFlag: LabResult['abnormalFlag'];
    sourceLab: string;
    specimenCollectedAt: string;
    amendsResultId?: string;
    amendmentReason?: string;
  },
): {result: LabResult; deduplicated: boolean} {
  if (db.processedExternalMessageIds.includes(input.externalMessageId)) {
    const existing = db.labResults.find(
      (r) => r.externalMessageId === input.externalMessageId,
    );
    if (existing) {
      recordAudit(db, {
        actor,
        action: 'LAB_IMPORT_DEDUPLICATED',
        entityType: 'lab_result',
        entityId: existing.id,
        patientId: existing.patientId ?? undefined,
        summary: `Ignored duplicate lab message ${input.externalMessageId}.`,
        outcome: 'success',
      });
      return {result: existing, deduplicated: true};
    }
  }

  const now = new Date().toISOString();

  if (input.amendsResultId) {
    const target = db.labResults.find((r) => r.id === input.amendsResultId);
    if (!target) {
      throw new DomainError(404, 'Original lab result to amend not found.');
    }
    target.amendments.push({
      version: target.version + 1,
      previousValue: target.originalValue,
      newValue: input.originalValue,
      amendedAt: now,
      reason: input.amendmentReason?.trim() || 'Laboratory corrected report',
    });
    target.originalValue = input.originalValue;
    target.abnormalFlag = input.abnormalFlag;
    target.version += 1;
    target.reportedAt = now;
    // Amended results MUST return to awaiting clinical review!
    target.status = target.patientId ? 'awaiting_clinical_review' : 'received';
    db.processedExternalMessageIds.push(input.externalMessageId);

    recordAudit(db, {
      actor,
      action: 'LAB_RESULT_AMENDED',
      entityType: 'lab_result',
      entityId: target.id,
      patientId: target.patientId ?? undefined,
      summary: `Received laboratory amendment v${target.version} for ${target.testName}; reset to ${target.status}.`,
      outcome: 'success',
    });
    return {result: target, deduplicated: false};
  }

  const matchedPatient = input.patientId
    ? db.patients.find((p) => p.internalId === input.patientId)
    : undefined;

  const result: LabResult = {
    id: `RES-${9001 + db.labResults.length}`,
    externalMessageId: input.externalMessageId,
    patientId: matchedPatient ? matchedPatient.internalId : null,
    rawPatientSummary: input.rawPatientSummary.trim(),
    matchStatus: matchedPatient ? 'matched' : 'unmatched',
    testName: input.testName.trim(),
    originalValue: input.originalValue.trim(),
    units: input.units.trim(),
    referenceRange: input.referenceRange ? input.referenceRange.trim() : null,
    referenceRangeAvailable: Boolean(input.referenceRange?.trim()),
    abnormalFlag: input.abnormalFlag,
    sourceLab: input.sourceLab.trim(),
    specimenCollectedAt: input.specimenCollectedAt,
    reportedAt: now,
    status: matchedPatient ? 'awaiting_clinical_review' : 'received',
    version: 1,
    amendments: [],
    viewedByIds: [],
  };

  db.labResults.unshift(result);
  db.processedExternalMessageIds.push(input.externalMessageId);

  recordAudit(db, {
    actor,
    action: 'LAB_RESULT_INGESTED',
    entityType: 'lab_result',
    entityId: result.id,
    patientId: result.patientId ?? undefined,
    summary: `Ingested ${result.testName} (${result.originalValue} ${result.units}) — matchStatus: ${result.matchStatus}.`,
    outcome: 'success',
  });
  return {result, deduplicated: false};
}

export function matchUnmatchedResult(
  db: PracticeDatabase,
  actor: SessionUser,
  resultId: string,
  patientId: string,
): LabResult {
  if (!isStaffRole(actor.role)) {
    throw new DomainError(403, 'Staff access required.');
  }
  const result = db.labResults.find((r) => r.id === resultId);
  if (!result) {
    throw new DomainError(404, 'Lab result not found.');
  }
  const patient = db.patients.find((p) => p.internalId === patientId);
  if (!patient) {
    throw new DomainError(404, 'Target patient record not found.');
  }
  result.patientId = patient.internalId;
  result.matchStatus = 'matched';
  result.status = 'awaiting_clinical_review';

  recordAudit(db, {
    actor,
    action: 'LAB_RESULT_MATCHED',
    entityType: 'lab_result',
    entityId: result.id,
    patientId: patient.internalId,
    summary: `Matched unmatched result ${result.id} to ${patient.firstName} ${patient.lastName}; queued for clinician review.`,
    outcome: 'success',
  });
  return result;
}

export function recordResultViewed(
  db: PracticeDatabase,
  actor: SessionUser,
  resultId: string,
): LabResult {
  const result = db.labResults.find((r) => r.id === resultId);
  if (!result) {
    throw new DomainError(404, 'Lab result not found.');
  }
  if (!result.viewedByIds.includes(actor.id)) {
    result.viewedByIds.push(actor.id);
  }
  // CRITICAL SAFETY RULE: Viewing a result MUST NOT mark it clinically reviewed or close follow-up!
  return result;
}

export function reviewLabResult(
  db: PracticeDatabase,
  actor: SessionUser,
  resultId: string,
  input: {
    reviewNote: string;
    assignFollowUpTask?: boolean;
    followUpTitle?: string;
    followUpOwnerId?: string;
  },
): {result: LabResult; createdTask?: PracticeTask} {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    recordAudit(db, {
      actor,
      action: 'LAB_REVIEW_DENIED',
      entityType: 'lab_result',
      entityId: resultId,
      summary: `Role ${actor.role} attempted to clinically review a lab result.`,
      outcome: 'denied',
    });
    throw new DomainError(
      403,
      'Only an authorised clinician may mark a laboratory result as reviewed.',
    );
  }
  const result = db.labResults.find((r) => r.id === resultId);
  if (!result) {
    throw new DomainError(404, 'Lab result not found.');
  }
  if (!result.patientId || result.matchStatus !== 'matched') {
    throw new DomainError(409, 'Unmatched results must be matched to a patient before clinical review.');
  }
  if (!input.reviewNote?.trim()) {
    throw new DomainError(400, 'Please enter a clinical review comment.');
  }

  const now = new Date().toISOString();
  result.reviewedBy = actor.name;
  result.reviewedByRole = actor.role;
  result.reviewedAt = now;
  result.reviewNote = input.reviewNote.trim();
  result.status = input.assignFollowUpTask ? 'action_assigned' : 'reviewed';

  let createdTask: PracticeTask | undefined;
  if (input.assignFollowUpTask) {
    const owner =
      db.users.find((u) => u.id === input.followUpOwnerId) ??
      db.users.find((u) => u.id === actor.id)!;
    createdTask = {
      id: `TSK-${800 + db.tasks.length + 1}`,
      patientId: result.patientId,
      title:
        input.followUpTitle?.trim() ||
        `Follow-up for ${result.testName} (${result.originalValue} ${result.units})`,
      description: input.reviewNote.trim(),
      category: 'results',
      ownerId: owner.id,
      ownerName: owner.name,
      ownerRole: isStaffRole(owner.role) ? owner.role : 'GP_PARTNER',
      dueDate: new Date(Date.now() + 2 * 86400_000).toISOString().slice(0, 10),
      escalationRule: 'Escalate to Duty GP Partner if overdue by 24h',
      escalated: false,
      status: 'open',
      linkedEntityType: 'lab_result',
      linkedEntityId: result.id,
      createdAt: now,
    };
    db.tasks.unshift(createdTask);
    result.outstandingActionTaskId = createdTask.id;
  }

  recordAudit(db, {
    actor,
    action: 'LAB_RESULT_CLINICALLY_REVIEWED',
    entityType: 'lab_result',
    entityId: result.id,
    patientId: result.patientId,
    summary: `Clinician ${actor.name} reviewed ${result.testName} (status: ${result.status}).`,
    outcome: 'success',
  });

  return {result, createdTask};
}
