import crypto from 'node:crypto';
import type {
  Appointment,
  AppointmentMode,
  ClinicianSession,
  PracticeDatabase,
  SessionTemplate,
  SessionUser,
  SlotHold,
} from '../../shared/models';
import {recordAudit} from '../auth';
import {DomainError} from './identity';

export interface ComputedSlot {
  sessionId: string;
  clinicianId: string;
  siteId: string;
  roomId: string;
  date: string;
  startTime: string;
  endTime: string;
  status: 'available' | 'booked' | 'protected' | 'break' | 'held' | 'unavailable_leave';
  appointmentId?: string;
  holdId?: string;
  patientSelfBookAllowed: boolean;
}

function toMinutes(hhmm: string): number {
  const [hStr, mStr] = hhmm.split(':');
  return Number(hStr) * 60 + Number(mStr);
}

function fromMinutes(mins: number): string {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function purgeExpiredSlotHolds(db: PracticeDatabase): number {
  const now = Date.now();
  const before = db.slotHolds.length;
  db.slotHolds = db.slotHolds.filter((h) => new Date(h.expiresAt).getTime() > now);
  return before - db.slotHolds.length;
}

export function computeSessionSlots(
  db: Readonly<PracticeDatabase>,
  session: ClinicianSession,
): ComputedSlot[] {
  const slots: ComputedSlot[] = [];
  const start = toMinutes(session.startTime);
  const end = toMinutes(session.endTime);
  const duration = session.slotDurationMinutes;
  const breakStart = session.breakStart ? toMinutes(session.breakStart) : -1;
  const breakEnd = session.breakEnd ? toMinutes(session.breakEnd) : -1;
  const now = Date.now();

  for (let t = start; t + duration <= end; t += duration) {
    const slotStart = fromMinutes(t);
    const slotEnd = fromMinutes(t + duration);

    if (session.status !== 'active') {
      slots.push({
        sessionId: session.id,
        clinicianId: session.clinicianId,
        siteId: session.siteId,
        roomId: session.roomId,
        date: session.date,
        startTime: slotStart,
        endTime: slotEnd,
        status: 'unavailable_leave',
        patientSelfBookAllowed: false,
      });
      continue;
    }

    if (breakStart >= 0 && t >= breakStart && t < breakEnd) {
      slots.push({
        sessionId: session.id,
        clinicianId: session.clinicianId,
        siteId: session.siteId,
        roomId: session.roomId,
        date: session.date,
        startTime: slotStart,
        endTime: slotEnd,
        status: 'break',
        patientSelfBookAllowed: false,
      });
      continue;
    }

    const activeBooking = db.appointments.find(
      (a) =>
        a.date === session.date &&
        a.clinicianId === session.clinicianId &&
        a.status !== 'cancelled' &&
        toMinutes(a.startTime) < t + duration &&
        toMinutes(a.endTime) > t,
    );

    if (activeBooking) {
      slots.push({
        sessionId: session.id,
        clinicianId: session.clinicianId,
        siteId: session.siteId,
        roomId: session.roomId,
        date: session.date,
        startTime: slotStart,
        endTime: slotEnd,
        status: 'booked',
        appointmentId: activeBooking.id,
        patientSelfBookAllowed: false,
      });
      continue;
    }

    const activeHold = db.slotHolds.find(
      (h) =>
        h.sessionId === session.id &&
        h.startTime === slotStart &&
        new Date(h.expiresAt).getTime() > now,
    );
    if (activeHold) {
      slots.push({
        sessionId: session.id,
        clinicianId: session.clinicianId,
        siteId: session.siteId,
        roomId: session.roomId,
        date: session.date,
        startTime: slotStart,
        endTime: slotEnd,
        status: 'held',
        holdId: activeHold.id,
        patientSelfBookAllowed: false,
      });
      continue;
    }

    const isProtected = session.protectedSlots.includes(slotStart);
    slots.push({
      sessionId: session.id,
      clinicianId: session.clinicianId,
      siteId: session.siteId,
      roomId: session.roomId,
      date: session.date,
      startTime: slotStart,
      endTime: slotEnd,
      status: isProtected ? 'protected' : 'available',
      patientSelfBookAllowed: session.patientSelfBookAllowed && !isProtected,
    });
  }
  return slots;
}

function validateBookingSlot(
  db: Readonly<PracticeDatabase>,
  params: {
    session: ClinicianSession;
    startTime: string;
    patientId: string;
    bookingSource: 'staff' | 'patient_portal';
    appointmentType: string;
    ignoreAppointmentId?: string;
    ignoreHoldId?: string;
  },
): {endTime: string} {
  const {session, startTime, patientId, bookingSource, appointmentType} = params;

  if (session.status !== 'active') {
    throw new DomainError(
      409,
      session.unavailableReason ||
        'Clinician session is unavailable (leave or cancelled) — cannot book into this session.',
    );
  }

  const slotStartMin = toMinutes(startTime);
  const slotEndMin = slotStartMin + session.slotDurationMinutes;
  const endTime = fromMinutes(slotEndMin);

  if (slotStartMin < toMinutes(session.startTime) || slotEndMin > toMinutes(session.endTime)) {
    throw new DomainError(400, 'Requested slot falls outside clinician session hours.');
  }

  if (
    session.breakStart &&
    session.breakEnd &&
    slotStartMin < toMinutes(session.breakEnd) &&
    slotEndMin > toMinutes(session.breakStart)
  ) {
    throw new DomainError(409, 'Requested time overlaps with clinician protected break.');
  }

  if (bookingSource === 'patient_portal') {
    if (!session.patientSelfBookAllowed) {
      throw new DomainError(403, 'This session is not eligible for patient self-booking.');
    }
    if (session.protectedSlots.includes(startTime)) {
      throw new DomainError(
        403,
        'Protected urgent/triage slot cannot be self-booked via the patient portal.',
      );
    }
  }

  if (
    session.allowedAppointmentTypes.length > 0 &&
    !session.allowedAppointmentTypes.includes(appointmentType)
  ) {
    throw new DomainError(
      400,
      `Appointment type "${appointmentType}" is not permitted in this clinician session.`,
    );
  }

  // Check clinician double-booking & cross-site travel buffer
  for (const existing of db.appointments) {
    if (
      existing.id === params.ignoreAppointmentId ||
      existing.status === 'cancelled' ||
      existing.date !== session.date
    ) {
      continue;
    }
    const exStart = toMinutes(existing.startTime);
    const exEnd = toMinutes(existing.endTime);

    if (existing.clinicianId === session.clinicianId) {
      if (exStart < slotEndMin && exEnd > slotStartMin) {
        throw new DomainError(
          409,
          `Double-booking prevented: clinician already has appointment ${existing.id} at ${existing.startTime}.`,
        );
      }
      if (existing.siteId !== session.siteId) {
        const gapBefore = slotStartMin - exEnd;
        const gapAfter = exStart - slotEndMin;
        const minGap = Math.min(
          gapBefore >= 0 ? gapBefore : 999,
          gapAfter >= 0 ? gapAfter : 999,
        );
        if (minGap < session.travelBufferMinutes) {
          throw new DomainError(
            409,
            `Cross-site travel buffer violation: requires ${session.travelBufferMinutes} mins between sites.`,
          );
        }
      }
    }

    if (existing.roomId === session.roomId && exStart < slotEndMin && exEnd > slotStartMin) {
      throw new DomainError(
        409,
        `Room conflict prevented: room ${session.roomId} is occupied by ${existing.id}.`,
      );
    }

    if (existing.patientId === patientId && exStart < slotEndMin && exEnd > slotStartMin) {
      throw new DomainError(
        409,
        `Patient already has an overlapping appointment (${existing.id}) at ${existing.startTime}.`,
      );
    }
  }

  // Check active slot holds held by other users
  const now = Date.now();
  const conflictingHold = db.slotHolds.find(
    (h) =>
      h.id !== params.ignoreHoldId &&
      h.sessionId === session.id &&
      h.startTime === startTime &&
      new Date(h.expiresAt).getTime() > now &&
      h.patientId !== patientId,
  );
  if (conflictingHold) {
    throw new DomainError(409, 'Slot is currently held by another patient booking in progress.');
  }

  return {endTime};
}

export function createSlotHold(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {sessionId: string; startTime: string; patientId: string},
): SlotHold {
  purgeExpiredSlotHolds(db);
  const session = db.sessions.find((s) => s.id === input.sessionId);
  if (!session) {
    throw new DomainError(404, 'Clinician session not found.');
  }
  const {endTime} = validateBookingSlot(db, {
    session,
    startTime: input.startTime,
    patientId: input.patientId,
    bookingSource: 'patient_portal',
    appointmentType: session.allowedAppointmentTypes[0] ?? 'Routine GP',
  });

  // Remove any prior hold by same user on same slot
  db.slotHolds = db.slotHolds.filter(
    (h) => !(h.heldByUserId === actor.id && h.sessionId === session.id && h.startTime === input.startTime),
  );

  const hold: SlotHold = {
    id: `HOLD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
    sessionId: session.id,
    date: session.date,
    startTime: input.startTime,
    endTime,
    patientId: input.patientId,
    heldByUserId: actor.id,
    expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
  };
  db.slotHolds.push(hold);
  return hold;
}

export function bookAppointment(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    sessionId: string;
    startTime: string;
    mode: AppointmentMode;
    appointmentType: string;
    reason: string;
    bookingSource: 'staff' | 'patient_portal';
    linkedRequestId?: string;
    holdId?: string;
  },
): Appointment {
  purgeExpiredSlotHolds(db);
  const patient = db.patients.find((p) => p.internalId === input.patientId);
  if (!patient) {
    throw new DomainError(404, 'Patient record not found.');
  }
  const session = db.sessions.find((s) => s.id === input.sessionId);
  if (!session) {
    throw new DomainError(404, 'Clinician session not found.');
  }

  const {endTime} = validateBookingSlot(db, {
    session,
    startTime: input.startTime,
    patientId: input.patientId,
    bookingSource: input.bookingSource,
    appointmentType: input.appointmentType,
    ignoreHoldId: input.holdId,
  });

  if (input.holdId) {
    db.slotHolds = db.slotHolds.filter((h) => h.id !== input.holdId);
  }

  const now = new Date().toISOString();
  const appointment: Appointment = {
    id: `APT-${100 + db.appointments.length + 1}`,
    patientId: patient.internalId,
    sessionId: session.id,
    clinicianId: session.clinicianId,
    siteId: session.siteId,
    roomId: session.roomId,
    date: session.date,
    startTime: input.startTime,
    endTime,
    timezone: 'Europe/London',
    mode: input.mode,
    appointmentType: input.appointmentType,
    status: 'booked',
    reason: input.reason.trim() || 'Clinical review',
    bookingSource: input.bookingSource,
    linkedRequestId: input.linkedRequestId,
    version: 1,
    createdAt: now,
    updatedAt: now,
  };

  db.appointments.push(appointment);

  if (input.linkedRequestId) {
    const req = db.requests.find((r) => r.id === input.linkedRequestId);
    if (req) {
      req.status = 'appointment_offered';
      req.linkedAppointmentId = appointment.id;
      req.updatedAt = now;
    }
  }

  recordAudit(db, {
    actor,
    action: 'APPOINTMENT_BOOKED',
    entityType: 'appointment',
    entityId: appointment.id,
    patientId: patient.internalId,
    summary: `Booked ${appointment.appointmentType} (${appointment.mode}) on ${appointment.date} at ${appointment.startTime} Europe/London.`,
    outcome: 'success',
  });

  return appointment;
}

export function rescheduleAppointment(
  db: PracticeDatabase,
  actor: SessionUser,
  appointmentId: string,
  targetSessionId: string,
  targetStartTime: string,
): Appointment {
  const appt = db.appointments.find((a) => a.id === appointmentId);
  if (!appt) {
    throw new DomainError(404, 'Appointment not found.');
  }
  if (appt.status === 'cancelled' || appt.status === 'completed') {
    throw new DomainError(409, `Cannot reschedule a ${appt.status} appointment.`);
  }
  const session = db.sessions.find((s) => s.id === targetSessionId);
  if (!session) {
    throw new DomainError(404, 'Target clinician session not found.');
  }

  const {endTime} = validateBookingSlot(db, {
    session,
    startTime: targetStartTime,
    patientId: appt.patientId,
    bookingSource: 'staff',
    appointmentType: appt.appointmentType,
    ignoreAppointmentId: appt.id,
  });

  const previous = `${appt.date} ${appt.startTime}`;
  appt.sessionId = session.id;
  appt.clinicianId = session.clinicianId;
  appt.siteId = session.siteId;
  appt.roomId = session.roomId;
  appt.date = session.date;
  appt.startTime = targetStartTime;
  appt.endTime = endTime;
  appt.version += 1;
  appt.updatedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: 'APPOINTMENT_RESCHEDULED',
    entityType: 'appointment',
    entityId: appt.id,
    patientId: appt.patientId,
    summary: `Rescheduled appointment ${appt.id} from ${previous} to ${appt.date} ${appt.startTime}.`,
    outcome: 'success',
  });
  return appt;
}

export function recordArrival(
  db: PracticeDatabase,
  actor: SessionUser,
  appointmentId: string,
): Appointment {
  const appt = db.appointments.find((a) => a.id === appointmentId);
  if (!appt) {
    throw new DomainError(404, 'Appointment not found.');
  }
  if (appt.status === 'cancelled') {
    throw new DomainError(409, 'Cannot record arrival for a cancelled appointment.');
  }
  const now = new Date().toISOString();
  appt.status = 'arrived';
  appt.arrivedAt = now;
  appt.arrivedBy = actor.name;
  appt.updatedAt = now;
  appt.version += 1;

  recordAudit(db, {
    actor,
    action: 'APPOINTMENT_ARRIVAL_RECORDED',
    entityType: 'appointment',
    entityId: appt.id,
    patientId: appt.patientId,
    summary: `Recorded patient arrival at ${now}.`,
    outcome: 'success',
  });
  return appt;
}

export function cancelAppointment(
  db: PracticeDatabase,
  actor: SessionUser,
  appointmentId: string,
  reason: string,
): Appointment {
  const appt = db.appointments.find((a) => a.id === appointmentId);
  if (!appt) {
    throw new DomainError(404, 'Appointment not found.');
  }
  if (appt.status === 'completed') {
    throw new DomainError(409, 'Completed appointments cannot be cancelled.');
  }
  appt.status = 'cancelled';
  appt.cancelledReason = reason.trim() || 'Cancelled on request';
  appt.updatedAt = new Date().toISOString();
  appt.version += 1;

  recordAudit(db, {
    actor,
    action: 'APPOINTMENT_CANCELLED',
    entityType: 'appointment',
    entityId: appt.id,
    patientId: appt.patientId,
    summary: `Cancelled appointment ${appt.id}: ${appt.cancelledReason}`,
    outcome: 'success',
  });
  return appt;
}

export function updateSessionTemplate(
  db: PracticeDatabase,
  actor: SessionUser,
  templateId: string,
  changes: Partial<Pick<SessionTemplate, 'name' | 'slotDurationMinutes' | 'patientSelfBookAllowed' | 'endTime'>>,
): SessionTemplate {
  const tpl = db.sessionTemplates.find((t) => t.id === templateId);
  if (!tpl) {
    throw new DomainError(404, 'Session template not found.');
  }
  if (changes.name !== undefined) tpl.name = changes.name.trim();
  if (changes.slotDurationMinutes !== undefined) {
    tpl.slotDurationMinutes = Number(changes.slotDurationMinutes);
  }
  if (changes.patientSelfBookAllowed !== undefined) {
    tpl.patientSelfBookAllowed = Boolean(changes.patientSelfBookAllowed);
  }
  if (changes.endTime !== undefined) tpl.endTime = changes.endTime;

  tpl.version += 1;
  tpl.updatedAt = new Date().toISOString();
  tpl.updatedBy = actor.name;

  // CRITICAL INVARIANT: existing appointments are NOT silently altered!
  db.configurationHistory.unshift({
    id: `CFG-${Date.now()}`,
    timestamp: tpl.updatedAt,
    changedBy: actor.name,
    area: 'session_template',
    summary: `Updated template "${tpl.name}" to v${tpl.version} (existing booked appointments preserved unchanged).`,
  });

  recordAudit(db, {
    actor,
    action: 'SESSION_TEMPLATE_UPDATED',
    entityType: 'session_template',
    entityId: tpl.id,
    summary: `Updated session template ${tpl.id} to v${tpl.version}; existing appointments untouched.`,
    outcome: 'success',
  });

  return tpl;
}
