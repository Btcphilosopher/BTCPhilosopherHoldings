import crypto from 'node:crypto';
import type {
  AppointmentMode,
  Consultation,
  ConsultationAmendment,
  ObservationRecord,
  PracticeDatabase,
  ProblemRecord,
  SessionUser,
  TerminologyConcept,
} from '../../shared/models';
import {canClinicallySign, isStaffRole, recordAudit} from '../auth';
import {DomainError} from './identity';

export function createConsultationDraft(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    expectedPatientId: string;
    appointmentId?: string;
    siteId: string;
    mode: AppointmentMode;
    presentingComplaint: string;
    history?: string;
    examination?: string;
    assessment?: string;
    plan?: string;
    freeText?: string;
    codedConcepts?: TerminologyConcept[];
  },
): Consultation {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    throw new DomainError(
      403,
      'Only authorised clinicians (GP, Nurse, Pharmacist) may author clinical consultations.',
    );
  }
  if (input.patientId !== input.expectedPatientId) {
    recordAudit(db, {
      actor,
      action: 'WRONG_PATIENT_GUARD_TRIGGERED',
      entityType: 'consultation',
      entityId: 'NEW',
      patientId: input.patientId,
      summary: `Blocked consultation creation: target ${input.patientId} did not match active patient ${input.expectedPatientId}.`,
      outcome: 'conflict',
    });
    throw new DomainError(
      409,
      'Wrong-patient protection triggered: selected patient context mismatch.',
    );
  }

  const patient = db.patients.find((p) => p.internalId === input.patientId);
  if (!patient) {
    throw new DomainError(404, 'Patient not found.');
  }

  const now = new Date().toISOString();
  const consultation: Consultation = {
    id: `CON-${300 + db.consultations.length + 1}`,
    patientId: patient.internalId,
    appointmentId: input.appointmentId,
    clinicianId: actor.id,
    authorName: actor.name,
    authorRole: actor.role,
    siteId: input.siteId || patient.registeredSiteId,
    mode: input.mode || 'in_person',
    encounterTime: now,
    recordedAt: now,
    provenance: 'clinician_entry',
    status: 'Draft',
    presentingComplaint: input.presentingComplaint.trim(),
    history: input.history?.trim() ?? '',
    examination: input.examination?.trim() ?? '',
    assessment: input.assessment?.trim() ?? '',
    plan: input.plan?.trim() ?? '',
    freeText: input.freeText?.trim() ?? '',
    codedConcepts: input.codedConcepts ?? [],
    amendments: [],
    version: 1,
    updatedAt: now,
  };

  if (input.appointmentId) {
    const appt = db.appointments.find((a) => a.id === input.appointmentId);
    if (appt && appt.patientId === patient.internalId) {
      appt.status = 'in_consultation';
      appt.updatedAt = now;
    }
  }

  db.consultations.unshift(consultation);
  recordAudit(db, {
    actor,
    action: 'CONSULTATION_DRAFT_CREATED',
    entityType: 'consultation',
    entityId: consultation.id,
    patientId: patient.internalId,
    summary: `Created Draft consultation ${consultation.id}.`,
    outcome: 'success',
  });
  return consultation;
}

export function updateConsultationDraft(
  db: PracticeDatabase,
  actor: SessionUser,
  consultationId: string,
  input: {
    expectedPatientId: string;
    presentingComplaint?: string;
    history?: string;
    examination?: string;
    assessment?: string;
    plan?: string;
    freeText?: string;
    codedConcepts?: TerminologyConcept[];
    markReviewed?: boolean;
    simulateFailure?: boolean;
  },
): Consultation {
  if (!canClinicallySign(actor.role)) {
    throw new DomainError(403, 'Only authorised clinicians may edit consultation drafts.');
  }
  const con = db.consultations.find((c) => c.id === consultationId);
  if (!con) {
    throw new DomainError(404, 'Consultation not found.');
  }
  if (con.patientId !== input.expectedPatientId) {
    throw new DomainError(
      409,
      'Wrong-patient protection: active patient does not match consultation patient.',
    );
  }
  if (con.status === 'Signed' || con.status === 'Amended') {
    recordAudit(db, {
      actor,
      action: 'SIGNED_NOTE_EDIT_BLOCKED',
      entityType: 'consultation',
      entityId: con.id,
      patientId: con.patientId,
      summary: 'Blocked direct modification of immutable signed consultation.',
      outcome: 'denied',
    });
    throw new DomainError(
      409,
      'Signed consultations are immutable. Create a linked amendment instead.',
    );
  }

  if (input.simulateFailure) {
    recordAudit(db, {
      actor,
      action: 'CONSULTATION_SAVE_INTERRUPTED',
      entityType: 'consultation',
      entityId: con.id,
      patientId: con.patientId,
      summary: 'Simulated network interruption during draft save — original draft preserved.',
      outcome: 'failed',
    });
    throw new DomainError(503, 'Simulated save interruption: network timeout while saving draft.');
  }

  if (input.presentingComplaint !== undefined) {
    con.presentingComplaint = input.presentingComplaint.trim();
  }
  if (input.history !== undefined) con.history = input.history.trim();
  if (input.examination !== undefined) con.examination = input.examination.trim();
  if (input.assessment !== undefined) con.assessment = input.assessment.trim();
  if (input.plan !== undefined) con.plan = input.plan.trim();
  if (input.freeText !== undefined) con.freeText = input.freeText.trim();
  if (input.codedConcepts !== undefined) con.codedConcepts = input.codedConcepts;
  if (input.markReviewed) {
    con.status = 'Reviewed';
  }
  con.version += 1;
  con.updatedAt = new Date().toISOString();

  recordAudit(db, {
    actor,
    action: input.markReviewed ? 'CONSULTATION_REVIEWED' : 'CONSULTATION_DRAFT_SAVED',
    entityType: 'consultation',
    entityId: con.id,
    patientId: con.patientId,
    summary: `Saved consultation ${con.id} (status: ${con.status}, v${con.version}).`,
    outcome: 'success',
  });
  return con;
}

export function signConsultation(
  db: PracticeDatabase,
  actor: SessionUser,
  consultationId: string,
  expectedPatientId: string,
): Consultation {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    recordAudit(db, {
      actor,
      action: 'CONSULTATION_SIGN_DENIED',
      entityType: 'consultation',
      entityId: consultationId,
      summary: `Role ${actor.role} attempted to sign consultation without clinical authority.`,
      outcome: 'denied',
    });
    throw new DomainError(403, 'Only authorised clinicians may sign clinical consultations.');
  }
  const con = db.consultations.find((c) => c.id === consultationId);
  if (!con) {
    throw new DomainError(404, 'Consultation not found.');
  }
  if (con.patientId !== expectedPatientId) {
    throw new DomainError(409, 'Wrong-patient protection: consultation patient mismatch.');
  }
  if (con.status === 'Signed' || con.status === 'Amended') {
    throw new DomainError(409, 'Consultation is already signed.');
  }
  if (!con.presentingComplaint.trim() || !con.assessment.trim()) {
    throw new DomainError(
      400,
      'Presenting complaint and clinical assessment are required before signing.',
    );
  }

  const now = new Date().toISOString();
  const payloadToHash = JSON.stringify({
    id: con.id,
    patientId: con.patientId,
    presentingComplaint: con.presentingComplaint,
    history: con.history,
    examination: con.examination,
    assessment: con.assessment,
    plan: con.plan,
    freeText: con.freeText,
  });
  con.status = 'Signed';
  con.signedAt = now;
  con.signedBy = actor.name;
  con.contentHash = crypto.createHash('sha256').update(payloadToHash).digest('hex');
  con.updatedAt = now;
  con.version += 1;

  if (con.appointmentId) {
    const appt = db.appointments.find((a) => a.id === con.appointmentId);
    if (appt) {
      appt.status = 'completed';
      appt.updatedAt = now;
    }
  }

  recordAudit(db, {
    actor,
    action: 'CONSULTATION_SIGNED',
    entityType: 'consultation',
    entityId: con.id,
    patientId: con.patientId,
    summary: `Signed consultation ${con.id} (SHA-256 ${con.contentHash.slice(0, 12)}...).`,
    outcome: 'success',
  });
  return con;
}

export function amendConsultation(
  db: PracticeDatabase,
  actor: SessionUser,
  consultationId: string,
  expectedPatientId: string,
  reason: string,
  amendmentText: string,
): Consultation {
  if (!isStaffRole(actor.role) || !canClinicallySign(actor.role)) {
    throw new DomainError(403, 'Only authorised clinicians may append clinical amendments.');
  }
  const con = db.consultations.find((c) => c.id === consultationId);
  if (!con) {
    throw new DomainError(404, 'Consultation not found.');
  }
  if (con.patientId !== expectedPatientId) {
    throw new DomainError(409, 'Wrong-patient protection: consultation patient mismatch.');
  }
  if (con.status !== 'Signed' && con.status !== 'Amended') {
    throw new DomainError(400, 'Only signed consultations require amendments; edit the draft directly.');
  }
  if (!reason.trim() || !amendmentText.trim()) {
    throw new DomainError(400, 'Amendment reason and text are both required.');
  }

  const amendment: ConsultationAmendment = {
    id: `AMD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
    consultationId: con.id,
    authorId: actor.id,
    authorName: actor.name,
    authorRole: actor.role,
    reason: reason.trim(),
    amendmentText: amendmentText.trim(),
    recordedAt: new Date().toISOString(),
  };

  con.amendments.push(amendment);
  con.status = 'Amended';
  con.updatedAt = amendment.recordedAt;
  con.version += 1;

  recordAudit(db, {
    actor,
    action: 'CONSULTATION_AMENDED',
    entityType: 'consultation',
    entityId: con.id,
    patientId: con.patientId,
    summary: `Appended attributable amendment ${amendment.id} preserving original signed note.`,
    outcome: 'success',
  });
  return con;
}

export function addObservation(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    type: ObservationRecord['type'];
    value: string;
    unit: string;
    siteName: string;
  },
): ObservationRecord {
  if (!canClinicallySign(actor.role)) {
    throw new DomainError(403, 'Only clinicians may record clinical observations.');
  }
  const obs: ObservationRecord = {
    id: `OBS-${db.observations.length + 1}`,
    patientId: input.patientId,
    type: input.type,
    value: input.value.trim(),
    unit: input.unit.trim(),
    recordedAt: new Date().toISOString(),
    recordedBy: actor.name,
    siteName: input.siteName,
  };
  db.observations.unshift(obs);
  recordAudit(db, {
    actor,
    action: 'OBSERVATION_RECORDED',
    entityType: 'observation',
    entityId: obs.id,
    patientId: obs.patientId,
    summary: `Recorded ${obs.type}: ${obs.value} ${obs.unit}.`,
    outcome: 'success',
  });
  return obs;
}

export function addProblem(
  db: PracticeDatabase,
  actor: SessionUser,
  input: {
    patientId: string;
    title: string;
    onsetDate: string;
    significance: 'significant' | 'minor';
  },
): ProblemRecord {
  if (!canClinicallySign(actor.role)) {
    throw new DomainError(403, 'Only clinicians may add clinical problems.');
  }
  const problem: ProblemRecord = {
    id: `PRB-${db.problems.length + 1}`,
    patientId: input.patientId,
    title: input.title.trim(),
    onsetDate: input.onsetDate,
    status: 'active',
    significance: input.significance,
    recordedBy: actor.name,
    recordedAt: new Date().toISOString(),
  };
  db.problems.unshift(problem);
  recordAudit(db, {
    actor,
    action: 'PROBLEM_RECORDED',
    entityType: 'problem',
    entityId: problem.id,
    patientId: problem.patientId,
    summary: `Added active problem: ${problem.title}.`,
    outcome: 'success',
  });
  return problem;
}
