import express, {type Request, type Response, type Router} from 'express';
import type {
  AppointmentMode,
  ClinicalUrgency,
  CommChannel,
  OperationalMetrics,
  Patient,
  PracticeDatabase,
  ProxyScope,
  RequestCategory,
  SessionUser,
} from '../shared/models';
import {
  CAPABILITY_MATRIX,
  INTEGRATION_BOUNDARIES,
  PROTOTYPE_HAZARD_LOG,
  PrototypeTerminologyAdapter,
} from './adapters';
import {
  assertPatientPortalAccess,
  isStaffRole,
  issueSessionToken,
  recordAudit,
  sanitizeUser,
  verifyPassword,
  verifySessionToken,
} from './auth';
import {
  addObservation,
  addProblem,
  amendConsultation,
  createConsultationDraft,
  signConsultation,
  updateConsultationDraft,
} from './modules/clinical';
import {
  completePracticeTask,
  createPracticeTask,
  retryCommunication,
  runBackgroundWorkerTick,
  sendSimulatedCommunication,
} from './modules/communications';
import {
  createReferralDraft,
  matchDocumentToPatient,
  reviewIncomingDocument,
  simulateExternalReferralAcceptance,
  submitReferralSimulated,
} from './modules/documents';
import {
  DomainError,
  registerPatient,
  resolveDuplicateCandidate,
  reviewContactUpdateRequest,
  submitContactUpdateRequest,
  updateProxyScopes,
  verifyNhsNumberMock,
} from './modules/identity';
import {
  adminCheckRepeatRequest,
  decideRepeatMedicineRequest,
  submitRepeatMedicineRequest,
} from './modules/medicines';
import {
  assignRequestClinicalUrgency,
  handleRequestAdminAction,
  submitPatientRequest,
} from './modules/requests';
import {
  ingestLabResult,
  matchUnmatchedResult,
  recordResultViewed,
  reviewLabResult,
} from './modules/results';
import {
  bookAppointment,
  cancelAppointment,
  computeSessionSlots,
  createSlotHold,
  recordArrival,
  rescheduleAppointment,
  updateSessionTemplate,
} from './modules/scheduling';
import {redactedLog, type PracticeStore} from './store';

const terminologyAdapter = new PrototypeTerminologyAdapter();

function extractBearer(req: Request): string | undefined {
  const auth = req.headers.authorization;
  if (!auth?.startsWith('Bearer ')) {
    return undefined;
  }
  return auth.slice(7).trim();
}

function handleError(res: Response, err: unknown): void {
  if (err instanceof DomainError) {
    res.status(err.statusCode).json({error: err.message});
    return;
  }
  const message = err instanceof Error ? err.message : 'Unexpected server error';
  redactedLog('api_error', {message});
  res.status(500).json({error: message});
}

function buildOperationalMetrics(db: Readonly<PracticeDatabase>): OperationalMetrics {
  const activeSessions = db.sessions.filter((s) => s.status === 'active');
  let totalSlots = 0;
  for (const s of activeSessions) {
    totalSlots += computeSessionSlots(db, s).filter(
      (sl) => sl.status !== 'break',
    ).length;
  }
  const activeAppts = db.appointments.filter((a) => a.status !== 'cancelled');
  return {
    generatedAt: new Date().toISOString(),
    disclaimer:
      'Operational Prototype Metrics for Pennine Medical Practice — NOT an official NHS statutory or contractual submission.',
    totalAppointmentSlots: totalSlots,
    bookedAppointments: activeAppts.length,
    arrivedOrAttended: activeAppts.filter(
      (a) =>
        a.status === 'arrived' ||
        a.status === 'in_consultation' ||
        a.status === 'completed',
    ).length,
    cancelledAppointments: db.appointments.filter((a) => a.status === 'cancelled').length,
    dnaCount: db.appointments.filter((a) => a.status === 'dna').length,
    requestsAwaitingReview: db.requests.filter(
      (r) =>
        r.status === 'submitted' ||
        r.status === 'in_admin_review' ||
        r.status === 'awaiting_clinician_review',
    ).length,
    outstandingResultActions: db.labResults.filter(
      (r) =>
        r.status === 'received' ||
        r.status === 'matched' ||
        r.status === 'awaiting_clinical_review' ||
        r.status === 'action_assigned',
    ).length,
    unmatchedResults: db.labResults.filter((r) => r.matchStatus !== 'matched').length,
    unprocessedCorrespondence: db.documents.filter((d) => d.status !== 'filed').length,
    failedCommunications: db.communications.filter((c) => c.deliveryStatus === 'failed')
      .length,
    openTasks: db.tasks.filter((t) => t.status !== 'completed').length,
  };
}

export function createApiRouter(store: PracticeStore): Router {
  const router = express.Router();
  router.use(express.json({limit: '1mb'}));

  async function requireAuth(req: Request, res: Response): Promise<SessionUser | null> {
    const db = await store.ensureLoaded();
    const user = verifySessionToken(extractBearer(req), db);
    if (!user) {
      res.status(401).json({error: 'Authentication required. Please sign in.'});
      return null;
    }
    return user;
  }

  async function requireStaff(req: Request, res: Response): Promise<SessionUser | null> {
    const user = await requireAuth(req, res);
    if (!user) return null;
    if (!isStaffRole(user.role)) {
      res.status(403).json({error: 'Staff authorisation required.'});
      return null;
    }
    return user;
  }

  // --- AUTH ---
  router.get('/auth/personas', async (_req, res) => {
    try {
      const db = await store.ensureLoaded();
      res.json({
        demoMode: process.env['DEMO_MODE'] !== 'false',
        personas: db.users.map((u) => sanitizeUser(u)),
      });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/auth/demo-login', async (req, res) => {
    try {
      if (process.env['DEMO_MODE'] === 'false') {
        res.status(403).json({error: 'Demo sign-in is disabled.'});
        return;
      }
      const {userId, mfaCode} = req.body as {userId?: string; mfaCode?: string};
      const result = await store.transact((db) => {
        const found = db.users.find((u) => u.id === userId);
        if (!found) {
          throw new DomainError(404, 'Persona account not found.');
        }
        const safe = sanitizeUser(found);
        safe.mfaVerified = mfaCode ? mfaCode.trim().length >= 6 : found.mfaVerified;
        const token = issueSessionToken(safe);
        recordAudit(db, {
          actor: safe,
          action: 'USER_SIGNED_IN_DEMO',
          entityType: 'session',
          entityId: safe.id,
          patientId: safe.patientId,
          summary: `${safe.name} (${safe.role}) signed in.`,
          outcome: 'success',
        });
        return {token, user: safe};
      });
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/auth/login', async (req, res) => {
    try {
      const {userId, password} = req.body as {userId?: string; password?: string};
      if (!userId || !password) {
        res.status(400).json({error: 'User ID and password are required.'});
        return;
      }
      const result = await store.transact((db) => {
        const found = db.users.find((u) => u.id === userId);
        if (!found || !verifyPassword(password, found.passwordHash)) {
          throw new DomainError(401, 'Invalid credentials.');
        }
        const safe = sanitizeUser(found);
        const token = issueSessionToken(safe);
        recordAudit(db, {
          actor: safe,
          action: 'USER_SIGNED_IN_PASSWORD',
          entityType: 'session',
          entityId: safe.id,
          patientId: safe.patientId,
          summary: `${safe.name} (${safe.role}) authenticated.`,
          outcome: 'success',
        });
        return {token, user: safe};
      });
      res.json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.get('/auth/me', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    res.json({user});
  });

  // --- STAFF WORKSPACE BOOTSTRAP ---
  router.get('/staff/workspace', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const db = await store.ensureLoaded();
      const computedSlots = db.sessions.flatMap((s) => computeSessionSlots(db, s));
      res.json({
        sites: db.sites,
        rooms: db.rooms,
        clinicians: db.clinicians,
        staffUsers: db.users.filter((u) => isStaffRole(u.role)).map((u) => sanitizeUser(u)),
        sessionTemplates: db.sessionTemplates,
        sessions: db.sessions,
        slots: computedSlots,
        patients: db.patients,
        duplicateCandidates: db.duplicateCandidates,
        contactUpdateRequests: db.contactUpdateRequests,
        appointments: db.appointments,
        requests: db.requests,
        consultations: db.consultations,
        problems: db.problems,
        observations: db.observations,
        medications: db.medications,
        repeatAuthorisations: db.repeatAuthorisations,
        repeatRequests: db.repeatRequests,
        labResults: db.labResults,
        documents: db.documents,
        referrals: db.referrals,
        tasks: db.tasks,
        recallRules: db.recallRules,
        communications: db.communications,
        auditEvents: db.auditEvents.slice(0, 150),
        configurationHistory: db.configurationHistory,
        metrics: buildOperationalMetrics(db),
        integrationBoundaries: INTEGRATION_BOUNDARIES,
        hazardLog: PROTOTYPE_HAZARD_LOG,
        capabilityMatrix: CAPABILITY_MATRIX,
      });
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- PATIENTS & IDENTITY ---
  router.post('/patients', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const result = await store.transact((db) =>
        registerPatient(
          db,
          user,
          req.body as Parameters<typeof registerPatient>[2],
        ),
      );
      res.status(201).json(result);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/patients/:patientId/verify-pds', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const patient = await store.transact((db) =>
        verifyNhsNumberMock(db, user, String(req.params['patientId'])),
      );
      res.json({patient});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/patients/duplicates/:candidateId/resolve', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {resolution, notes} = req.body as {
        resolution: 'confirmed_distinct' | 'linked_duplicate';
        notes: string;
      };
      const candidate = await store.transact((db) =>
        resolveDuplicateCandidate(
          db,
          user,
          String(req.params['candidateId']),
          resolution,
          notes ?? '',
        ),
      );
      res.json({candidate});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/patients/contact-updates/:requestId/review', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {decision, reason} = req.body as {
        decision: 'approved' | 'rejected';
        reason: string;
      };
      const updated = await store.transact((db) =>
        reviewContactUpdateRequest(
          db,
          user,
          String(req.params['requestId']),
          decision,
          reason ?? '',
        ),
      );
      res.json({contactUpdateRequest: updated});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/patients/:patientId/proxies/:proxyId', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {verificationStatus, scopes} = req.body as {
        verificationStatus: 'verified' | 'pending' | 'revoked';
        scopes: ProxyScope[];
      };
      const patient = await store.transact((db) =>
        updateProxyScopes(
          db,
          user,
          String(req.params['patientId']),
          String(req.params['proxyId']),
          verificationStatus,
          scopes,
        ),
      );
      res.json({patient});
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- SCHEDULING & APPOINTMENTS ---
  router.post('/appointments', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const body = req.body as {
        patientId: string;
        sessionId: string;
        startTime: string;
        mode: AppointmentMode;
        appointmentType: string;
        reason: string;
        linkedRequestId?: string;
      };
      const appointment = await store.transact((db) =>
        bookAppointment(db, user, {...body, bookingSource: 'staff'}),
      );
      res.status(201).json({appointment});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/appointments/:appointmentId/reschedule', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {targetSessionId, targetStartTime} = req.body as {
        targetSessionId: string;
        targetStartTime: string;
      };
      const appointment = await store.transact((db) =>
        rescheduleAppointment(
          db,
          user,
          String(req.params['appointmentId']),
          targetSessionId,
          targetStartTime,
        ),
      );
      res.json({appointment});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/appointments/:appointmentId/arrive', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const appointment = await store.transact((db) =>
        recordArrival(db, user, String(req.params['appointmentId'])),
      );
      res.json({appointment});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/appointments/:appointmentId/cancel', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {reason} = req.body as {reason?: string};
      const appointment = await store.transact((db) =>
        cancelAppointment(
          db,
          user,
          String(req.params['appointmentId']),
          reason ?? 'Cancelled by staff',
        ),
      );
      res.json({appointment});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.patch('/session-templates/:templateId', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const template = await store.transact((db) =>
        updateSessionTemplate(
          db,
          user,
          String(req.params['templateId']),
          req.body as {
            name?: string;
            slotDurationMinutes?: number;
            patientSelfBookAllowed?: boolean;
            endTime?: string;
          },
        ),
      );
      res.json({template});
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- REQUESTS & RECEPTION ---
  router.post('/requests/:requestId/admin', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const body = req.body as {
        staffSummary: string;
        routeToClinician?: boolean;
        markResolved?: boolean;
      };
      const request = await store.transact((db) =>
        handleRequestAdminAction(db, user, String(req.params['requestId']), body),
      );
      res.json({request});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/requests/:requestId/urgency', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {clinicalUrgency, clinicalRationale} = req.body as {
        clinicalUrgency: ClinicalUrgency;
        clinicalRationale: string;
      };
      const request = await store.transact((db) =>
        assignRequestClinicalUrgency(db, user, String(req.params['requestId']), {
          clinicalUrgency,
          clinicalRationale,
        }),
      );
      res.json({request});
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- CONSULTATIONS & TERMINOLOGY ---
  router.get('/terminology/search', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    const q = String(req.query['q'] ?? '');
    res.json({concepts: terminologyAdapter.searchConcepts(q)});
  });

  router.post('/consultations', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const consultation = await store.transact((db) =>
        createConsultationDraft(
          db,
          user,
          req.body as Parameters<typeof createConsultationDraft>[2],
        ),
      );
      res.status(201).json({consultation});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.patch('/consultations/:consultationId', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const consultation = await store.transact((db) =>
        updateConsultationDraft(
          db,
          user,
          String(req.params['consultationId']),
          req.body as Parameters<typeof updateConsultationDraft>[3],
        ),
      );
      res.json({consultation});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/consultations/:consultationId/sign', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {expectedPatientId} = req.body as {expectedPatientId: string};
      const consultation = await store.transact((db) =>
        signConsultation(
          db,
          user,
          String(req.params['consultationId']),
          expectedPatientId,
        ),
      );
      res.json({consultation});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/consultations/:consultationId/amend', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {expectedPatientId, reason, amendmentText} = req.body as {
        expectedPatientId: string;
        reason: string;
        amendmentText: string;
      };
      const consultation = await store.transact((db) =>
        amendConsultation(
          db,
          user,
          String(req.params['consultationId']),
          expectedPatientId,
          reason,
          amendmentText,
        ),
      );
      res.json({consultation});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/patients/:patientId/observations', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const body = req.body as {
        type: 'Blood Pressure' | 'Heart Rate' | 'Temperature' | 'SpO2' | 'Weight' | 'HbA1c (POC)';
        value: string;
        unit: string;
        siteName: string;
      };
      const observation = await store.transact((db) =>
        addObservation(db, user, {
          patientId: String(req.params['patientId']),
          ...body,
        }),
      );
      res.status(201).json({observation});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/patients/:patientId/problems', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const body = req.body as {
        title: string;
        onsetDate: string;
        significance: 'significant' | 'minor';
      };
      const problem = await store.transact((db) =>
        addProblem(db, user, {
          patientId: String(req.params['patientId']),
          ...body,
        }),
      );
      res.status(201).json({problem});
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- MEDICINES & REPEAT REQUESTS ---
  router.post('/repeat-requests/:requestId/admin-check', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const repeatRequest = await store.transact((db) =>
        adminCheckRepeatRequest(db, user, String(req.params['requestId'])),
      );
      res.json({repeatRequest});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/repeat-requests/:requestId/decide', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const body = req.body as {
        expectedPatientId: string;
        decision: 'approved' | 'rejected';
        reason: string;
      };
      const repeatRequest = await store.transact((db) =>
        decideRepeatMedicineRequest(
          db,
          user,
          String(req.params['requestId']),
          body,
        ),
      );
      res.json({repeatRequest});
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- RESULTS ---
  router.post('/results/ingest', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const outcome = await store.transact((db) =>
        ingestLabResult(
          db,
          user,
          req.body as Parameters<typeof ingestLabResult>[2],
        ),
      );
      res.status(outcome.deduplicated ? 200 : 201).json(outcome);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/results/:resultId/view', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const result = await store.transact((db) =>
        recordResultViewed(db, user, String(req.params['resultId'])),
      );
      res.json({result});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/results/:resultId/match', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {patientId} = req.body as {patientId: string};
      const result = await store.transact((db) =>
        matchUnmatchedResult(db, user, String(req.params['resultId']), patientId),
      );
      res.json({result});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/results/:resultId/review', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const outcome = await store.transact((db) =>
        reviewLabResult(
          db,
          user,
          String(req.params['resultId']),
          req.body as Parameters<typeof reviewLabResult>[3],
        ),
      );
      res.json(outcome);
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- DOCUMENTS & REFERRALS ---
  router.post('/documents/:documentId/match', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {patientId} = req.body as {patientId: string};
      const document = await store.transact((db) =>
        matchDocumentToPatient(
          db,
          user,
          String(req.params['documentId']),
          patientId,
        ),
      );
      res.json({document});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/documents/:documentId/review', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const outcome = await store.transact((db) =>
        reviewIncomingDocument(
          db,
          user,
          String(req.params['documentId']),
          req.body as Parameters<typeof reviewIncomingDocument>[3],
        ),
      );
      res.json(outcome);
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/referrals', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const referral = await store.transact((db) =>
        createReferralDraft(
          db,
          user,
          req.body as Parameters<typeof createReferralDraft>[2],
        ),
      );
      res.status(201).json({referral});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/referrals/:referralId/submit', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const referral = await store.transact((db) =>
        submitReferralSimulated(db, user, String(req.params['referralId'])),
      );
      res.json({referral});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/referrals/:referralId/external-status', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {accepted, note} = req.body as {accepted: boolean; note: string};
      const referral = await store.transact((db) =>
        simulateExternalReferralAcceptance(
          db,
          user,
          String(req.params['referralId']),
          Boolean(accepted),
          note ?? '',
        ),
      );
      res.json({referral});
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- TASKS, COMMUNICATIONS & WORKERS ---
  router.post('/tasks', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const task = await store.transact((db) =>
        createPracticeTask(
          db,
          user,
          req.body as Parameters<typeof createPracticeTask>[2],
        ),
      );
      res.status(201).json({task});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/tasks/:taskId/complete', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {completionEvidence} = req.body as {completionEvidence: string};
      const task = await store.transact((db) =>
        completePracticeTask(
          db,
          user,
          String(req.params['taskId']),
          completionEvidence ?? '',
        ),
      );
      res.json({task});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/communications', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const comm = await store.transact((db) =>
        sendSimulatedCommunication(
          db,
          user,
          req.body as {
            patientId: string;
            channel: CommChannel;
            subject: string;
            body: string;
            linkedTaskId?: string;
            simulateFailure?: boolean;
          },
        ),
      );
      res.status(201).json({communication: comm});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/communications/:commId/retry', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const {fallbackChannel} = req.body as {fallbackChannel?: CommChannel};
      const comm = await store.transact((db) =>
        retryCommunication(db, user, String(req.params['commId']), fallbackChannel),
      );
      res.json({communication: comm});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/workers/reconcile', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      const summary = await store.transact((db) =>
        runBackgroundWorkerTick(db, user),
      );
      res.json(summary);
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- PATIENT PORTAL (STRICT ISOLATION & SCOPED PROXY ACCESS) ---
  router.get('/portal/summary/:patientId', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    const patientId = String(req.params['patientId']);
    try {
      const db = await store.ensureLoaded();
      const baseAccess = assertPatientPortalAccess(user, patientId, 'appointments', db);
      if (!baseAccess.allowed) {
        res.status(403).json({error: baseAccess.reason || 'Access denied.'});
        return;
      }

      const patient = db.patients.find((p) => p.internalId === patientId);
      if (!patient) {
        res.status(404).json({error: 'Patient not found.'});
        return;
      }

      const recordsAccess = assertPatientPortalAccess(user, patientId, 'records', db);
      const medsAccess = assertPatientPortalAccess(user, patientId, 'medicines', db);
      const msgsAccess = assertPatientPortalAccess(user, patientId, 'messages', db);
      const reqAccess = assertPatientPortalAccess(user, patientId, 'requests', db);

      // Determine granted scopes for active user
      const proxy = patient.proxies.find(
        (pr) => pr.proxyUserId === user.id && pr.verificationStatus === 'verified',
      );
      const activeScopes: ProxyScope[] =
        user.patientId === patientId || isStaffRole(user.role)
          ? ['appointments', 'requests', 'medicines', 'messages', 'records']
          : proxy?.scopes ?? [];

      // Self-bookable slots only
      const eligibleSlots = db.sessions
        .filter((s) => s.status === 'active' && s.patientSelfBookAllowed)
        .flatMap((s) => computeSessionSlots(db, s))
        .filter((sl) => sl.status === 'available' && sl.patientSelfBookAllowed);

      // Released records follow practice configured policy + proxy scope
      const releasedNotes =
        recordsAccess.allowed && patient.recordReleasePolicy.allowProspectiveNotes
          ? db.consultations
              .filter(
                (c) =>
                  c.patientId === patientId &&
                  (c.status === 'Signed' || c.status === 'Amended'),
              )
              .map((c) => ({
                id: c.id,
                encounterTime: c.encounterTime,
                authorName: c.authorName,
                authorRole: c.authorRole,
                presentingComplaint: c.presentingComplaint,
                plan: c.plan,
                status: c.status,
                amendments: c.amendments,
              }))
          : [];

      const releasedResults =
        recordsAccess.allowed && patient.recordReleasePolicy.allowReviewedResults
          ? db.labResults.filter(
              (r) =>
                r.patientId === patientId &&
                (r.status === 'reviewed' ||
                  r.status === 'action_assigned' ||
                  r.status === 'follow_up_completed'),
            )
          : [];

      const releasedDocuments =
        recordsAccess.allowed && patient.recordReleasePolicy.allowCorrespondenceSummary
          ? db.documents.filter(
              (d) => d.patientId === patientId && d.visibleToPatient && d.status === 'filed',
            )
          : [];

      res.json({
        patient,
        viaProxy: baseAccess.viaProxy,
        activeScopes,
        sites: db.sites,
        clinicians: db.clinicians,
        sessions: db.sessions,
        eligibleSlots,
        appointments: db.appointments.filter((a) => a.patientId === patientId),
        requests: reqAccess.allowed
          ? db.requests.filter((r) => r.patientId === patientId)
          : [],
        medications: medsAccess.allowed
          ? db.medications.filter((m) => m.patientId === patientId)
          : [],
        repeatAuthorisations: medsAccess.allowed
          ? db.repeatAuthorisations.filter((a) => a.patientId === patientId)
          : [],
        repeatRequests: medsAccess.allowed
          ? db.repeatRequests.filter((r) => r.patientId === patientId)
          : [],
        messages: msgsAccess.allowed
          ? db.communications.filter(
              (c) => c.patientId === patientId && c.patientVisible,
            )
          : [],
        releasedNotes,
        releasedResults,
        releasedDocuments,
        contactUpdateRequests: db.contactUpdateRequests.filter(
          (c) => c.patientId === patientId,
        ),
        linkedPatients: (user.linkedPatientIds ?? (user.patientId ? [user.patientId] : []))
          .map((id) => db.patients.find((p) => p.internalId === id))
          .filter((p): p is Patient => Boolean(p))
          .map((p) => ({
            internalId: p.internalId,
            fullName: `${p.firstName} ${p.lastName}`,
            dob: p.dob,
          })),
      });
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/portal/:patientId/hold', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    const patientId = String(req.params['patientId']);
    try {
      const hold = await store.transact((db) => {
        const access = assertPatientPortalAccess(user, patientId, 'appointments', db);
        if (!access.allowed) {
          throw new DomainError(403, access.reason || 'Access denied.');
        }
        const {sessionId, startTime} = req.body as {
          sessionId: string;
          startTime: string;
        };
        return createSlotHold(db, user, {sessionId, startTime, patientId});
      });
      res.status(201).json({hold});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/portal/:patientId/book', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    const patientId = String(req.params['patientId']);
    try {
      const appointment = await store.transact((db) => {
        const access = assertPatientPortalAccess(user, patientId, 'appointments', db);
        if (!access.allowed) {
          throw new DomainError(403, access.reason || 'Access denied.');
        }
        const body = req.body as {
          sessionId: string;
          startTime: string;
          mode: AppointmentMode;
          appointmentType: string;
          reason: string;
          holdId?: string;
        };
        return bookAppointment(db, user, {
          ...body,
          patientId,
          bookingSource: 'patient_portal',
        });
      });
      res.status(201).json({appointment});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/portal/:patientId/appointments/:appointmentId/cancel', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    const patientId = String(req.params['patientId']);
    try {
      const appointment = await store.transact((db) => {
        const access = assertPatientPortalAccess(user, patientId, 'appointments', db);
        if (!access.allowed) {
          throw new DomainError(403, access.reason || 'Access denied.');
        }
        const appt = db.appointments.find(
          (a) => a.id === String(req.params['appointmentId']) && a.patientId === patientId,
        );
        if (!appt) {
          throw new DomainError(404, 'Appointment not found for this patient.');
        }
        const {reason} = req.body as {reason?: string};
        return cancelAppointment(
          db,
          user,
          appt.id,
          reason ?? 'Cancelled by patient via portal',
        );
      });
      res.json({appointment});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/portal/:patientId/requests', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    const patientId = String(req.params['patientId']);
    try {
      const {category, patientDescription} = req.body as {
        category: RequestCategory;
        patientDescription: string;
      };
      const request = await store.transact((db) =>
        submitPatientRequest(db, user, {
          patientId,
          category,
          patientDescription,
        }),
      );
      res.status(201).json({request});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/portal/:patientId/repeat-requests', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    const patientId = String(req.params['patientId']);
    try {
      const {authorisationId, patientNote, nominatedPharmacy} = req.body as {
        authorisationId: string;
        patientNote?: string;
        nominatedPharmacy: string;
      };
      const repeatRequest = await store.transact((db) =>
        submitRepeatMedicineRequest(db, user, {
          patientId,
          authorisationId,
          patientNote,
          nominatedPharmacy,
        }),
      );
      res.status(201).json({repeatRequest});
    } catch (err) {
      handleError(res, err);
    }
  });

  router.post('/portal/:patientId/contact-update', async (req, res) => {
    const user = await requireAuth(req, res);
    if (!user) return;
    const patientId = String(req.params['patientId']);
    try {
      const contactUpdateRequest = await store.transact((db) => {
        const access = assertPatientPortalAccess(user, patientId, 'requests', db);
        if (!access.allowed) {
          throw new DomainError(403, access.reason || 'Access denied.');
        }
        return submitContactUpdateRequest(
          db,
          user,
          patientId,
          req.body as Parameters<typeof submitContactUpdateRequest>[3],
        );
      });
      res.status(201).json({contactUpdateRequest});
    } catch (err) {
      handleError(res, err);
    }
  });

  // --- DEMO RESET FOR REPRODUCIBILITY ---
  router.post('/demo/reset', async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    try {
      await store.resetToSeed();
      res.json({reset: true});
    } catch (err) {
      handleError(res, err);
    }
  });

  return router;
}
