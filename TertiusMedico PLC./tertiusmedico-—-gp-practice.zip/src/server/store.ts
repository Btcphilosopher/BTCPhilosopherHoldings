import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import type {PracticeDatabase} from '../shared/models';

export interface StoreOptions {
  dbPath?: string;
  initialData?: PracticeDatabase;
  ephemeral?: boolean;
}

export class PracticeStore {
  private readonly dbPath: string;
  private readonly ephemeral: boolean;
  private cache: PracticeDatabase | null = null;
  private mutex: Promise<void> = Promise.resolve();
  private initFactory: () => PracticeDatabase;

  constructor(initFactory: () => PracticeDatabase, options: StoreOptions = {}) {
    this.initFactory = initFactory;
    this.ephemeral = Boolean(options.ephemeral);
    this.dbPath = path.resolve(
      options.dbPath ||
        process.env['PRACTICE_DB_PATH'] ||
        path.join(process.cwd(), 'data', 'practice-db.json'),
    );
    if (options.initialData) {
      this.cache = structuredClone(options.initialData);
    }
  }

  async ensureLoaded(): Promise<PracticeDatabase> {
    if (this.cache) {
      return this.cache;
    }
    if (this.ephemeral) {
      this.cache = this.initFactory();
      return this.cache;
    }
    try {
      const raw = await fs.readFile(this.dbPath, 'utf8');
      this.cache = JSON.parse(raw) as PracticeDatabase;
      return this.cache;
    } catch {
      const seeded = this.initFactory();
      this.cache = seeded;
      await this.persist(seeded);
      return seeded;
    }
  }

  async read<T>(fn: (db: Readonly<PracticeDatabase>) => T | Promise<T>): Promise<T> {
    const db = await this.ensureLoaded();
    return fn(db);
  }

  async transact<T>(
    fn: (db: PracticeDatabase) => T | Promise<T>,
  ): Promise<T> {
    let release!: () => void;
    const prev = this.mutex;
    this.mutex = new Promise<void>((resolve) => {
      release = resolve;
    });
    await prev;
    try {
      const db = await this.ensureLoaded();
      const snapshot = structuredClone(db);
      try {
        const result = await fn(db);
        if (!this.ephemeral) {
          await this.persist(db);
        }
        return result;
      } catch (err) {
        this.cache = snapshot;
        throw err;
      }
    } finally {
      release();
    }
  }

  async resetToSeed(): Promise<PracticeDatabase> {
    return this.transact((db) => {
      const fresh = this.initFactory();
      Object.assign(db, fresh);
      return fresh;
    });
  }

  private async persist(db: PracticeDatabase): Promise<void> {
    const dir = path.dirname(this.dbPath);
    await fs.mkdir(dir, {recursive: true});
    const tmpPath = `${this.dbPath}.${crypto.randomUUID()}.tmp`;
    await fs.writeFile(tmpPath, JSON.stringify(db, null, 2), 'utf8');
    await fs.rename(tmpPath, this.dbPath);
  }
}

export function redactedLog(event: string, meta: Record<string, string | number | boolean>): void {
  const safeMeta: Record<string, string | number | boolean> = {};
  for (const [k, v] of Object.entries(meta)) {
    const lower = k.toLowerCase();
    if (
      lower.includes('nhs') ||
      lower.includes('password') ||
      lower.includes('token') ||
      lower.includes('secret') ||
      lower.includes('dob') ||
      lower.includes('email') ||
      lower.includes('phone')
    ) {
      safeMeta[k] = '[REDACTED]';
    } else {
      safeMeta[k] = v;
    }
  }
  console.info(`[TERTIUSMEDICO] ${event}`, JSON.stringify(safeMeta));
}
