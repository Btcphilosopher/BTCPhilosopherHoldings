import express from 'express';
import http from 'node:http';
import {afterAll, beforeAll, beforeEach, describe, expect, it} from 'vitest';
import {createApiRouter} from './api';
import {createSeedDatabase} from './seed';
import {PracticeStore} from './store';

describe('TERTIUSMEDICO GP Practice Safety & Workflow Invariants', () => {
  let server: http.Server;
  let baseUrl = '';
  let store: PracticeStore;

  async function api(
    method: string,
    path: string,
    token?: string,
    body?: unknown,
  ): Promise<{status: number; data: Record<string, unknown>}> {
    const res = await fetch(`${baseUrl}/api${path}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? {Authorization: `Bearer ${token}`} : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const data = (await res.json()) as Record<string, unknown>;
    return {status: res.status, data};
  }

  async function loginDemo(userId: string): Promise<string> {
    const res = await api('POST', '/auth/demo-login', undefined, {userId});
    expect(res.status).toBe(200);
    return String(res.data['token']);
  }

  beforeAll(async () => {
    store = new PracticeStore(createSeedDatabase, {ephemeral: true});
    const app = express();
    app.use('/api', createApiRouter(store));
    await new Promise<void>((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        const addr = server.address();
        if (addr && typeof addr === 'object') {
          baseUrl = `http://127.0.0.1:${addr.port}`;
        }
        resolve();
      });
    });
  });

  afterAll(async () => {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  });

  beforeEach(async () => {
    await store.resetToSeed();
  });

  it('1. Enforces patient isolation and scoped proxy access', async () => {
    const claraToken = await loginDemo('USR-PAT-1001'); // Clara PT-1001
    const mayaToken = await loginDemo('USR-PAT-1004'); // Maya PT-1004, verified proxy for Leo PT-1005 (appointments, requests, messages ONLY)

    // Clara cannot view Owen's summary
    const deniedOther = await api('GET', '/portal/summary/PT-1006', claraToken);
    expect(deniedOther.status).toBe(403);

    // Maya CAN view Leo's summary (allowed scopes)
    const leoSummary = await api('GET', '/portal/summary/PT-1005', mayaToken);
    expect(leoSummary.status).toBe(200);
    expect(leoSummary.data['viaProxy']).toBe(true);
    expect(leoSummary.data['activeScopes']).toEqual([
      'appointments',
      'requests',
      'messages',
    ]);

    // Maya CANNOT submit repeat medication request for Leo because 'medicines' scope is not granted
    const deniedMed = await api('POST', '/portal/PT-1005/repeat-requests', mayaToken, {
      authorisationId: 'RAU-3',
      nominatedPharmacy: 'Local',
    });
    expect(deniedMed.status).toBe(403);
  });

  it('2. Prevents wrong-patient clinical entry and repeat-med decisions', async () => {
    const gpToken = await loginDemo('USR-GP-1');

    // Consultation draft rejects mismatched expectedPatientId
    const wrongDraft = await api('POST', '/consultations', gpToken, {
      patientId: 'PT-1001',
      expectedPatientId: 'PT-1006',
      siteId: 'SITE-MILLBROOK',
      mode: 'in_person',
      presentingComplaint: 'Cough',
    });
    expect(wrongDraft.status).toBe(409);

    // Repeat decision rejects mismatched expectedPatientId
    const wrongMed = await api('POST', '/repeat-requests/RREQ-1/decide', gpToken, {
      expectedPatientId: 'PT-1006',
      decision: 'approved',
      reason: 'Continue',
    });
    expect(wrongMed.status).toBe(409);
  });

  it('3. Enforces booking concurrency, unavailable clinician block, and template preservation', async () => {
    const recepToken = await loginDemo('USR-RECEP-1');
    const claraToken = await loginDemo('USR-PAT-1001');

    // Unavailable clinician session (Dr Mahmood on annual leave) is rejected
    const leaveBook = await api('POST', '/appointments', recepToken, {
      patientId: 'PT-1002',
      sessionId: 'SES-TODAY-MAHMOOD-LEAVE',
      startTime: '09:00',
      mode: 'in_person',
      appointmentType: 'Routine GP',
      reason: 'Checkup',
    });
    expect(leaveBook.status).toBe(409);

    // Patient self-booking protected slot 09:30 is rejected
    const protectedBook = await api('POST', '/portal/PT-1001/book', claraToken, {
      sessionId: 'SES-TODAY-VANCE-AM',
      startTime: '09:30',
      mode: 'in_person',
      appointmentType: 'Routine GP',
      reason: 'Self-book test',
    });
    expect(protectedBook.status).toBe(403);

    // Concurrent booking of the same available slot 11:00 -> exactly 1 succeeds, 1 conflicts
    const [b1, b2] = await Promise.all([
      api('POST', '/appointments', recepToken, {
        patientId: 'PT-1002',
        sessionId: 'SES-TODAY-VANCE-AM',
        startTime: '11:00',
        mode: 'in_person',
        appointmentType: 'Routine GP',
        reason: 'Slot race 1',
      }),
      api('POST', '/appointments', recepToken, {
        patientId: 'PT-1006',
        sessionId: 'SES-TODAY-VANCE-AM',
        startTime: '11:00',
        mode: 'telephone',
        appointmentType: 'Routine GP',
        reason: 'Slot race 2',
      }),
    ]);
    const statuses = [b1.status, b2.status].sort();
    expect(statuses).toEqual([201, 409]);

    // Updating a session template does NOT silently alter existing booked appointments
    const beforeAppt = await api('GET', '/staff/workspace', recepToken);
    const apptsBefore = beforeAppt.data['appointments'] as {id: string; startTime: string}[];
    const apt101Before = apptsBefore.find((a) => a.id === 'APT-101');

    const tplUpdate = await api('PATCH', '/session-templates/TPL-VANCE-AM', recepToken, {
      slotDurationMinutes: 20,
    });
    expect(tplUpdate.status).toBe(200);

    const afterAppt = await api('GET', '/staff/workspace', recepToken);
    const apptsAfter = afterAppt.data['appointments'] as {id: string; startTime: string}[];
    const apt101After = apptsAfter.find((a) => a.id === 'APT-101');
    expect(apt101After).toEqual(apt101Before);
  });

  it('4. Enforces clinical permissions (receptionist cannot sign, triage urgency, review results, or prescribe)', async () => {
    const recepToken = await loginDemo('USR-RECEP-1');
    const gpToken = await loginDemo('USR-GP-1');

    // Receptionist blocked from assigning clinical urgency
    const urgencyDenied = await api('POST', '/requests/REQ-201/urgency', recepToken, {
      clinicalUrgency: 'routine',
      clinicalRationale: 'Looks mild',
    });
    expect(urgencyDenied.status).toBe(403);

    // Receptionist blocked from reviewing lab result
    const labDenied = await api('POST', '/results/RES-9001/review', recepToken, {
      reviewNote: 'Checked',
    });
    expect(labDenied.status).toBe(403);

    // Receptionist blocked from approving repeat meds
    const medDenied = await api('POST', '/repeat-requests/RREQ-1/decide', recepToken, {
      expectedPatientId: 'PT-1001',
      decision: 'approved',
      reason: 'OK',
    });
    expect(medDenied.status).toBe(403);

    // GP Partner succeeds on urgency, lab review, and prescribing (simulated)
    const urgencyOk = await api('POST', '/requests/REQ-201/urgency', gpToken, {
      clinicalUrgency: 'urgent_today',
      clinicalRationale: 'ACE-inhibitor cough with dizziness requires same-day GP assessment.',
    });
    expect(urgencyOk.status).toBe(200);
  });

  it('5. Enforces signed consultation immutability, attributable amendments, and interrupted save recovery', async () => {
    const gpToken = await loginDemo('USR-GP-1');

    // Create draft
    const created = await api('POST', '/consultations', gpToken, {
      patientId: 'PT-1001',
      expectedPatientId: 'PT-1001',
      appointmentId: 'APT-101',
      siteId: 'SITE-MILLBROOK',
      mode: 'in_person',
      presentingComplaint: 'Dry cough on Ramipril',
      assessment: 'Probable ACE-inhibitor cough',
      plan: 'Switch Ramipril to Losartan',
    });
    expect(created.status).toBe(201);
    const conId = (created.data['consultation'] as {id: string}).id;

    // Simulate interrupted save -> returns 503 and preserves prior draft
    const failedSave = await api('PATCH', `/consultations/${conId}`, gpToken, {
      expectedPatientId: 'PT-1001',
      freeText: 'Unsaved addition during network drop',
      simulateFailure: true,
    });
    expect(failedSave.status).toBe(503);

    // Retry save succeeds
    const retrySave = await api('PATCH', `/consultations/${conId}`, gpToken, {
      expectedPatientId: 'PT-1001',
      freeText: 'Recovered after retry save.',
    });
    expect(retrySave.status).toBe(200);

    // Sign consultation
    const signed = await api('POST', `/consultations/${conId}/sign`, gpToken, {
      expectedPatientId: 'PT-1001',
    });
    expect(signed.status).toBe(200);
    expect((signed.data['consultation'] as {status: string}).status).toBe('Signed');

    // Direct edit of signed note MUST fail with 409
    const editBlocked = await api('PATCH', `/consultations/${conId}`, gpToken, {
      expectedPatientId: 'PT-1001',
      assessment: 'Overwritten assessment',
    });
    expect(editBlocked.status).toBe(409);

    // Attributable amendment succeeds and preserves original note
    const amended = await api('POST', `/consultations/${conId}/amend`, gpToken, {
      expectedPatientId: 'PT-1001',
      reason: 'Clarify potassium follow-up interval',
      amendmentText: 'Advised repeat U&Es in 7 days.',
    });
    expect(amended.status).toBe(200);
    const amendedCon = amended.data['consultation'] as {
      status: string;
      assessment: string;
      amendments: {amendmentText: string}[];
    };
    expect(amendedCon.status).toBe('Amended');
    expect(amendedCon.assessment).toBe('Probable ACE-inhibitor cough');
    expect(amendedCon.amendments).toHaveLength(1);
  });

  it('6. Preserves result viewing vs clinical review, handles result amendments, and keeps follow-up open when sending messages', async () => {
    const gpToken = await loginDemo('USR-GP-1');

    // Viewing RES-9001 does NOT mark it reviewed
    const viewed = await api('POST', '/results/RES-9001/view', gpToken, {});
    expect(viewed.status).toBe(200);
    expect((viewed.data['result'] as {status: string}).status).toBe(
      'awaiting_clinical_review',
    );

    // Clinician reviews RES-9001 and creates follow-up task
    const reviewed = await api('POST', '/results/RES-9001/review', gpToken, {
      reviewNote: 'Repeat potassium within 48h.',
      assignFollowUpTask: true,
      followUpTitle: 'Repeat U&Es for Clara Bennett',
    });
    expect(reviewed.status).toBe(200);
    const taskId = (reviewed.data['createdTask'] as {id: string}).id;

    // Sending a communication linked to that task does NOT auto-complete the clinical task
    const sentMsg = await api('POST', '/communications', gpToken, {
      patientId: 'PT-1001',
      channel: 'portal_message',
      subject: 'Blood test follow-up',
      body: 'Please book a repeat blood test.',
      linkedTaskId: taskId,
    });
    expect(sentMsg.status).toBe(201);

    const ws = await api('GET', '/staff/workspace', gpToken);
    const tasks = ws.data['tasks'] as {id: string; status: string}[];
    const linkedTask = tasks.find((t) => t.id === taskId);
    expect(linkedTask?.status).toBe('open');

    // Amended lab result resets status to awaiting_clinical_review
    const amendedRes = await api('POST', '/results/ingest', gpToken, {
      externalMessageId: 'PATH-MSG-AMEND-9001',
      patientId: 'PT-1001',
      rawPatientSummary: 'BENNETT, Clara',
      testName: 'Serum Potassium (K+)',
      originalValue: '5.8',
      units: 'mmol/L',
      referenceRange: '3.5 - 5.0',
      abnormalFlag: 'critical',
      sourceLab: 'Pennine Acute Pathology Lab',
      specimenCollectedAt: new Date().toISOString(),
      amendsResultId: 'RES-9001',
      amendmentReason: 'Dilution correction by biochemistry lab',
    });
    expect(amendedRes.status).toBe(201);
    expect((amendedRes.data['result'] as {status: string; version: number}).status).toBe(
      'awaiting_clinical_review',
    );
    expect((amendedRes.data['result'] as {version: number}).version).toBe(2);
  });

  it('7. Deduplicates duplicate lab imports and requires manual review for duplicate patients without auto-merge', async () => {
    const recepToken = await loginDemo('USR-RECEP-1');

    // Duplicate lab message ID returns existing record with deduplicated: true
    const dupImport = await api('POST', '/results/ingest', recepToken, {
      externalMessageId: 'PATH-MSG-2026-9001',
      patientId: 'PT-1001',
      rawPatientSummary: 'BENNETT, Clara',
      testName: 'Serum Potassium (K+)',
      originalValue: '5.6',
      units: 'mmol/L',
      referenceRange: '3.5 - 5.0',
      abnormalFlag: 'high',
      sourceLab: 'Pennine Acute Pathology Lab',
      specimenCollectedAt: new Date().toISOString(),
    });
    expect(dupImport.status).toBe(200);
    expect(dupImport.data['deduplicated']).toBe(true);

    // Registering a patient with matching DOB & postcode flags a duplicate candidate without merging
    const reg = await api('POST', '/patients', recepToken, {
      title: 'Mr',
      firstName: 'Arthur',
      lastName: 'Pendelton',
      dob: '1954-11-03',
      sexAtBirth: 'Male',
      addressLine1: '9 Stoneleigh Terrace',
      city: 'Todmorden',
      postcode: 'OL14 5BP',
      phone: '07700 900221',
      email: 'arthur2@synthetic.example',
      preferredChannel: 'sms',
      registeredSiteId: 'SITE-VALLEY',
      usualGpId: 'CLN-MAHMOOD',
    });
    expect(reg.status).toBe(201);
    expect(
      (reg.data['duplicateWarnings'] as unknown[]).length,
    ).toBeGreaterThanOrEqual(1);
  });
});
