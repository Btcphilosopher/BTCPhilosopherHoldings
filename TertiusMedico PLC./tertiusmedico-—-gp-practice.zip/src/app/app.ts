import {ChangeDetectionStrategy, Component, OnInit, inject} from '@angular/core';
import {AuthGateway} from './components/auth-gateway';
import {StaffShell} from './components/staff-shell';
import {PatientPortal} from './portal/patient-portal';
import {PracticeApi} from './services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [AuthGateway, StaffShell, PatientPortal],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  protected readonly api = inject(PracticeApi);

  ngOnInit(): void {
    void this.api.loadPersonas();
  }
}
