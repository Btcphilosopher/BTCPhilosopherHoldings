import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable, computed, inject, signal} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import type {
  Appointment,
  AppointmentMode,
  CapabilityMatrixEntry,
  ClinicalUrgency,
  Clinician,
  ClinicianSession,
  CommChannel,
  CommunicationRecord,
  ConfigurationChange,
  Consultation,
  DuplicateCandidate,
  HazardLogEntry,
  IncomingDocument,
  IntegrationBoundarySpec,
  LabResult,
  MedicationHistoryItem,
  ObservationRecord,
  OperationalMetrics,
  Patient,
  PatientContactUpdateRequest,
  PatientRequest,
  PracticeSite,
  PracticeTask,
  ProblemRecord,
  RecallRule,
  Referral,
  RepeatAuthorisation,
  RepeatMedicineRequest,
  RequestCategory,
  Room,
  SessionTemplate,
  SessionUser,
  SlotHold,
  TerminologyConcept,
  AuditEvent,
} from '../../shared/models';
import type {ComputedSlot} from '../../server/modules/scheduling';

export interface StaffWorkspacePayload {
  sites: PracticeSite[];
  rooms: Room[];
  clinicians: Clinician[];
  staffUsers: SessionUser[];
  sessionTemplates: SessionTemplate[];
  sessions: ClinicianSession[];
  slots: ComputedSlot[];
  patients: Patient[];
  duplicateCandidates: DuplicateCandidate[];
  contactUpdateRequests: PatientContactUpdateRequest[];
  appointments: Appointment[];
  requests: PatientRequest[];
  consultations: Consultation[];
  problems: ProblemRecord[];
  observations: ObservationRecord[];
  medications: MedicationHistoryItem[];
  repeatAuthorisations: RepeatAuthorisation[];
  repeatRequests: RepeatMedicineRequest[];
  labResults: LabResult[];
  documents: IncomingDocument[];
  referrals: Referral[];
  tasks: PracticeTask[];
  recallRules: RecallRule[];
  communications: CommunicationRecord[];
  auditEvents: AuditEvent[];
  configurationHistory: ConfigurationChange[];
  metrics: OperationalMetrics;
  integrationBoundaries: IntegrationBoundarySpec[];
  hazardLog: HazardLogEntry[];
  capabilityMatrix: CapabilityMatrixEntry[];
}

export interface PortalSummaryPayload {
  patient: Patient;
  viaProxy: boolean;
  activeScopes: string[];
  sites: PracticeSite[];
  clinicians: Clinician[];
  sessions: ClinicianSession[];
  eligibleSlots: ComputedSlot[];
  appointments: Appointment[];
  requests: PatientRequest[];
  medications: MedicationHistoryItem[];
  repeatAuthorisations: RepeatAuthorisation[];
  repeatRequests: RepeatMedicineRequest[];
  messages: CommunicationRecord[];
  releasedNotes: {
    id: string;
    encounterTime: string;
    authorName: string;
    authorRole: string;
    presentingComplaint: string;
    plan: string;
    status: string;
  }[];
  releasedResults: LabResult[];
  releasedDocuments: IncomingDocument[];
  contactUpdateRequests: PatientContactUpdateRequest[];
  linkedPatients: {internalId: string; fullName: string; dob: string}[];
}

export type StaffSection =
  | 'today'
  | 'appointments'
  | 'patients'
  | 'consultations'
  | 'requests'
  | 'results'
  | 'prescriptions'
  | 'referrals'
  | 'documents'
  | 'tasks'
  | 'reports'
  | 'administration';

export type PortalSection =
  | 'home'
  | 'appointments'
  | 'requests'
  | 'medicines'
  | 'messages'
  | 'my-information'
  | 'account';

@Injectable({providedIn: 'root'})
export class PracticeApi {
  private readonly http = inject(HttpClient);

  // Security: Keep Bearer token exclusively in JS memory (never localStorage/sessionStorage)
  private readonly authToken = signal<string | null>(null);
  readonly currentUser = signal<SessionUser | null>(null);
  readonly personas = signal<SessionUser[]>([]);
  readonly demoMode = signal<boolean>(true);

  readonly staffSection = signal<StaffSection>('today');
  readonly portalSection = signal<PortalSection>('home');

  readonly workspace = signal<StaffWorkspacePayload | null>(null);
  readonly portalData = signal<PortalSummaryPayload | null>(null);

  readonly activePatientId = signal<string>('PT-1001');
  readonly activeConsultationId = signal<string | null>(null);
  readonly hasUnsavedClinicalChanges = signal<boolean>(false);
  readonly pendingPatientSwitchId = signal<string | null>(null);

  readonly saveState = signal<'idle' | 'saving' | 'saved' | 'error'>('idle');
  readonly lastSyncAt = signal<string | null>(null);
  readonly bannerMessage = signal<{type: 'info' | 'success' | 'error'; text: string} | null>(
    null,
  );
  readonly showDemoGuide = signal<boolean>(false);

  readonly activePatient = computed<Patient | null>(() => {
    const ws = this.workspace();
    const pid = this.activePatientId();
    return ws?.patients.find((p) => p.internalId === pid) ?? ws?.patients[0] ?? null;
  });

  readonly isStaff = computed(() => {
    const u = this.currentUser();
    return Boolean(u && u.role !== 'PATIENT');
  });

  readonly isClinician = computed(() => {
    const role = this.currentUser()?.role;
    return role === 'GP_PARTNER' || role === 'PRACTICE_NURSE' || role === 'PHARMACIST';
  });

  readonly isPrescriber = computed(() => {
    const role = this.currentUser()?.role;
    return role === 'GP_PARTNER' || role === 'PHARMACIST';
  });

  private headers(): HttpHeaders {
    const token = this.authToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      ...(token ? {Authorization: `Bearer ${token}`} : {}),
    });
  }

  private async get<T>(path: string): Promise<T> {
    return firstValueFrom(
      this.http.get<T>(`/api${path}`, {headers: this.headers()}),
    );
  }

  private async post<T>(path: string, body: unknown): Promise<T> {
    this.saveState.set('saving');
    try {
      const res = await firstValueFrom(
        this.http.post<T>(`/api${path}`, body, {headers: this.headers()}),
      );
      this.saveState.set('saved');
      this.lastSyncAt.set(new Date().toISOString());
      return res;
    } catch (err) {
      this.saveState.set('error');
      throw err;
    }
  }

  private async patch<T>(path: string, body: unknown): Promise<T> {
    this.saveState.set('saving');
    try {
      const res = await firstValueFrom(
        this.http.patch<T>(`/api${path}`, body, {headers: this.headers()}),
      );
      this.saveState.set('saved');
      this.lastSyncAt.set(new Date().toISOString());
      return res;
    } catch (err) {
      this.saveState.set('error');
      throw err;
    }
  }

  notify(type: 'info' | 'success' | 'error', text: string): void {
    this.bannerMessage.set({type, text});
  }

  clearBanner(): void {
    this.bannerMessage.set(null);
  }

  async loadPersonas(): Promise<void> {
    const data = await firstValueFrom(
      this.http.get<{demoMode: boolean; personas: SessionUser[]}>('/api/auth/personas'),
    );
    this.demoMode.set(data.demoMode);
    this.personas.set(data.personas);
  }

  async loginDemo(userId: string, mfaCode?: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{token: string; user: SessionUser}>('/api/auth/demo-login', {
        userId,
        mfaCode,
      }),
    );
    this.authToken.set(res.token);
    this.currentUser.set(res.user);
    this.hasUnsavedClinicalChanges.set(false);
    this.pendingPatientSwitchId.set(null);

    if (res.user.role === 'PATIENT') {
      this.portalSection.set('home');
      await this.refreshPortal(res.user.patientId ?? 'PT-1001');
    } else {
      this.staffSection.set('today');
      await this.refreshWorkspace();
    }
  }

  async loginPassword(userId: string, password: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{token: string; user: SessionUser}>('/api/auth/login', {
        userId,
        password,
      }),
    );
    this.authToken.set(res.token);
    this.currentUser.set(res.user);
    if (res.user.role === 'PATIENT') {
      await this.refreshPortal(res.user.patientId ?? 'PT-1001');
    } else {
      await this.refreshWorkspace();
    }
  }

  signOut(): void {
    this.authToken.set(null);
    this.currentUser.set(null);
    this.workspace.set(null);
    this.portalData.set(null);
    this.hasUnsavedClinicalChanges.set(false);
    this.pendingPatientSwitchId.set(null);
    this.saveState.set('idle');
    this.bannerMessage.set(null);
  }

  requestPatientSwitch(patientId: string): boolean {
    if (patientId === this.activePatientId()) {
      return true;
    }
    if (this.hasUnsavedClinicalChanges()) {
      this.pendingPatientSwitchId.set(patientId);
      this.notify(
        'error',
        'Unsaved clinical changes exist. Save or discard before switching patient records.',
      );
      return false;
    }
    this.activePatientId.set(patientId);
    this.activeConsultationId.set(null);
    this.pendingPatientSwitchId.set(null);
    return true;
  }

  confirmDiscardAndSwitchPatient(): void {
    const nextId = this.pendingPatientSwitchId();
    if (!nextId) return;
    this.hasUnsavedClinicalChanges.set(false);
    this.activePatientId.set(nextId);
    this.activeConsultationId.set(null);
    this.pendingPatientSwitchId.set(null);
    this.clearBanner();
  }

  cancelPatientSwitch(): void {
    this.pendingPatientSwitchId.set(null);
  }

  async refreshWorkspace(): Promise<void> {
    const data = await this.get<StaffWorkspacePayload>('/staff/workspace');
    this.workspace.set(data);
    this.lastSyncAt.set(new Date().toISOString());
    if (
      !data.patients.some((p) => p.internalId === this.activePatientId()) &&
      data.patients[0]
    ) {
      this.activePatientId.set(data.patients[0].internalId);
    }
  }

  async refreshPortal(patientId: string): Promise<void> {
    const data = await this.get<PortalSummaryPayload>(`/portal/summary/${patientId}`);
    this.portalData.set(data);
    this.lastSyncAt.set(new Date().toISOString());
  }

  // --- STAFF ACTIONS ---
  async registerPatient(payload: Record<string, unknown>): Promise<{
    patient: Patient;
    duplicateWarnings: DuplicateCandidate[];
  }> {
    const res = await this.post<{patient: Patient; duplicateWarnings: DuplicateCandidate[]}>(
      '/patients',
      payload,
    );
    await this.refreshWorkspace();
    this.activePatientId.set(res.patient.internalId);
    return res;
  }

  async verifyPdsMock(patientId: string): Promise<void> {
    await this.post(`/patients/${patientId}/verify-pds`, {});
    await this.refreshWorkspace();
  }

  async resolveDuplicate(
    candidateId: string,
    resolution: 'confirmed_distinct' | 'linked_duplicate',
    notes: string,
  ): Promise<void> {
    await this.post(`/patients/duplicates/${candidateId}/resolve`, {resolution, notes});
    await this.refreshWorkspace();
  }

  async reviewContactUpdate(
    requestId: string,
    decision: 'approved' | 'rejected',
    reason: string,
  ): Promise<void> {
    await this.post(`/patients/contact-updates/${requestId}/review`, {decision, reason});
    await this.refreshWorkspace();
  }

  async bookAppointmentStaff(payload: {
    patientId: string;
    sessionId: string;
    startTime: string;
    mode: AppointmentMode;
    appointmentType: string;
    reason: string;
    linkedRequestId?: string;
  }): Promise<Appointment> {
    const res = await this.post<{appointment: Appointment}>('/appointments', payload);
    await this.refreshWorkspace();
    return res.appointment;
  }

  async rescheduleAppointment(
    appointmentId: string,
    targetSessionId: string,
    targetStartTime: string,
  ): Promise<void> {
    await this.post(`/appointments/${appointmentId}/reschedule`, {
      targetSessionId,
      targetStartTime,
    });
    await this.refreshWorkspace();
  }

  async recordArrival(appointmentId: string): Promise<void> {
    await this.post(`/appointments/${appointmentId}/arrive`, {});
    await this.refreshWorkspace();
  }

  async cancelAppointmentStaff(appointmentId: string, reason: string): Promise<void> {
    await this.post(`/appointments/${appointmentId}/cancel`, {reason});
    await this.refreshWorkspace();
  }

  async updateSessionTemplate(
    templateId: string,
    changes: {slotDurationMinutes?: number; patientSelfBookAllowed?: boolean},
  ): Promise<void> {
    await this.patch(`/session-templates/${templateId}`, changes);
    await this.refreshWorkspace();
  }

  async updateRequestAdmin(
    requestId: string,
    staffSummary: string,
    routeToClinician: boolean,
    markResolved = false,
  ): Promise<void> {
    await this.post(`/requests/${requestId}/admin`, {
      staffSummary,
      routeToClinician,
      markResolved,
    });
    await this.refreshWorkspace();
  }

  async assignRequestUrgency(
    requestId: string,
    clinicalUrgency: ClinicalUrgency,
    clinicalRationale: string,
  ): Promise<void> {
    await this.post(`/requests/${requestId}/urgency`, {
      clinicalUrgency,
      clinicalRationale,
    });
    await this.refreshWorkspace();
  }

  async searchTerminology(query: string): Promise<TerminologyConcept[]> {
    const res = await this.get<{concepts: TerminologyConcept[]}>(
      `/terminology/search?q=${encodeURIComponent(query)}`,
    );
    return res.concepts;
  }

  async createConsultationDraft(payload: {
    patientId: string;
    expectedPatientId: string;
    appointmentId?: string;
    siteId: string;
    mode: AppointmentMode;
    presentingComplaint: string;
    history: string;
    examination: string;
    assessment: string;
    plan: string;
    freeText: string;
    codedConcepts: TerminologyConcept[];
  }): Promise<Consultation> {
    const res = await this.post<{consultation: Consultation}>('/consultations', payload);
    this.hasUnsavedClinicalChanges.set(false);
    await this.refreshWorkspace();
    this.activeConsultationId.set(res.consultation.id);
    return res.consultation;
  }

  async saveConsultationDraft(
    consultationId: string,
    payload: {
      expectedPatientId: string;
      presentingComplaint?: string;
      history?: string;
      examination?: string;
      assessment?: string;
      plan?: string;
      freeText?: string;
      codedConcepts?: TerminologyConcept[];
      markReviewed?: boolean;
      simulateFailure?: boolean;
    },
  ): Promise<Consultation> {
    const res = await this.patch<{consultation: Consultation}>(
      `/consultations/${consultationId}`,
      payload,
    );
    this.hasUnsavedClinicalChanges.set(false);
    await this.refreshWorkspace();
    return res.consultation;
  }

  async signConsultation(consultationId: string, expectedPatientId: string): Promise<void> {
    await this.post(`/consultations/${consultationId}/sign`, {expectedPatientId});
    this.hasUnsavedClinicalChanges.set(false);
    await this.refreshWorkspace();
  }

  async amendConsultation(
    consultationId: string,
    expectedPatientId: string,
    reason: string,
    amendmentText: string,
  ): Promise<void> {
    await this.post(`/consultations/${consultationId}/amend`, {
      expectedPatientId,
      reason,
      amendmentText,
    });
    await this.refreshWorkspace();
  }

  async addObservation(
    patientId: string,
    payload: {
      type: ObservationRecord['type'];
      value: string;
      unit: string;
      siteName: string;
    },
  ): Promise<void> {
    await this.post(`/patients/${patientId}/observations`, payload);
    await this.refreshWorkspace();
  }

  async addProblem(
    patientId: string,
    payload: {title: string; onsetDate: string; significance: 'significant' | 'minor'},
  ): Promise<void> {
    await this.post(`/patients/${patientId}/problems`, payload);
    await this.refreshWorkspace();
  }

  async adminCheckRepeat(requestId: string): Promise<void> {
    await this.post(`/repeat-requests/${requestId}/admin-check`, {});
    await this.refreshWorkspace();
  }

  async decideRepeat(
    requestId: string,
    expectedPatientId: string,
    decision: 'approved' | 'rejected',
    reason: string,
  ): Promise<void> {
    await this.post(`/repeat-requests/${requestId}/decide`, {
      expectedPatientId,
      decision,
      reason,
    });
    await this.refreshWorkspace();
  }

  async ingestLabResult(payload: {
    externalMessageId: string;
    patientId: string | null;
    rawPatientSummary: string;
    testName: string;
    originalValue: string;
    units: string;
    referenceRange: string | null;
    abnormalFlag: LabResult['abnormalFlag'];
    sourceLab: string;
    specimenCollectedAt: string;
    amendsResultId?: string;
    amendmentReason?: string;
  }): Promise<{result: LabResult; deduplicated: boolean}> {
    const res = await this.post<{result: LabResult; deduplicated: boolean}>(
      '/results/ingest',
      payload,
    );
    await this.refreshWorkspace();
    return res;
  }

  async viewLabResult(resultId: string): Promise<void> {
    await this.post(`/results/${resultId}/view`, {});
    await this.refreshWorkspace();
  }

  async matchLabResult(resultId: string, patientId: string): Promise<void> {
    await this.post(`/results/${resultId}/match`, {patientId});
    await this.refreshWorkspace();
  }

  async reviewLabResult(
    resultId: string,
    payload: {
      reviewNote: string;
      assignFollowUpTask: boolean;
      followUpTitle?: string;
    },
  ): Promise<void> {
    await this.post(`/results/${resultId}/review`, payload);
    await this.refreshWorkspace();
  }

  async matchDocument(documentId: string, patientId: string): Promise<void> {
    await this.post(`/documents/${documentId}/match`, {patientId});
    await this.refreshWorkspace();
  }

  async reviewDocument(
    documentId: string,
    payload: {
      classification?: string;
      fileIntoRecord: boolean;
      visibleToPatient: boolean;
      assignTaskTitle?: string;
    },
  ): Promise<void> {
    await this.post(`/documents/${documentId}/review`, payload);
    await this.refreshWorkspace();
  }

  async createReferralDraft(payload: {
    patientId: string;
    expectedPatientId: string;
    specialty: string;
    targetService: string;
    urgency: Referral['urgency'];
    clinicalSummary: string;
    supportingDocumentIds: string[];
    supportingResultIds: string[];
  }): Promise<void> {
    await this.post('/referrals', payload);
    await this.refreshWorkspace();
  }

  async submitReferral(referralId: string): Promise<void> {
    await this.post(`/referrals/${referralId}/submit`, {});
    await this.refreshWorkspace();
  }

  async simulateExternalReferralStatus(
    referralId: string,
    accepted: boolean,
    note: string,
  ): Promise<void> {
    await this.post(`/referrals/${referralId}/external-status`, {accepted, note});
    await this.refreshWorkspace();
  }

  async createTask(payload: {
    patientId?: string;
    title: string;
    description: string;
    category: PracticeTask['category'];
    ownerId: string;
    dueDate: string;
    dependsOnTaskId?: string;
  }): Promise<void> {
    await this.post('/tasks', payload);
    await this.refreshWorkspace();
  }

  async completeTask(taskId: string, completionEvidence: string): Promise<void> {
    await this.post(`/tasks/${taskId}/complete`, {completionEvidence});
    await this.refreshWorkspace();
  }

  async sendCommunication(payload: {
    patientId: string;
    channel: CommChannel;
    subject: string;
    body: string;
    linkedTaskId?: string;
    simulateFailure?: boolean;
  }): Promise<void> {
    await this.post('/communications', payload);
    await this.refreshWorkspace();
  }

  async retryCommunication(commId: string, fallbackChannel?: CommChannel): Promise<void> {
    await this.post(`/communications/${commId}/retry`, {fallbackChannel});
    await this.refreshWorkspace();
  }

  async runWorkers(): Promise<{
    expiredHoldsRemoved: number;
    tasksEscalated: number;
    recallsGenerated: number;
  }> {
    const res = await this.post<{
      expiredHoldsRemoved: number;
      tasksEscalated: number;
      recallsGenerated: number;
    }>('/workers/reconcile', {});
    await this.refreshWorkspace();
    return res;
  }

  async resetDemo(): Promise<void> {
    await this.post('/demo/reset', {});
    this.hasUnsavedClinicalChanges.set(false);
    await this.refreshWorkspace();
    this.notify('info', 'Pennine Medical Practice synthetic demonstration reset to initial state.');
  }

  // --- PATIENT PORTAL ACTIONS ---
  async holdPortalSlot(
    patientId: string,
    sessionId: string,
    startTime: string,
  ): Promise<SlotHold> {
    const res = await this.post<{hold: SlotHold}>(`/portal/${patientId}/hold`, {
      sessionId,
      startTime,
    });
    return res.hold;
  }

  async bookPortalAppointment(
    patientId: string,
    payload: {
      sessionId: string;
      startTime: string;
      mode: AppointmentMode;
      appointmentType: string;
      reason: string;
      holdId?: string;
    },
  ): Promise<void> {
    await this.post(`/portal/${patientId}/book`, payload);
    await this.refreshPortal(patientId);
  }

  async cancelPortalAppointment(
    patientId: string,
    appointmentId: string,
    reason: string,
  ): Promise<void> {
    await this.post(`/portal/${patientId}/appointments/${appointmentId}/cancel`, {
      reason,
    });
    await this.refreshPortal(patientId);
  }

  async submitPortalRequest(
    patientId: string,
    category: RequestCategory,
    patientDescription: string,
  ): Promise<void> {
    await this.post(`/portal/${patientId}/requests`, {category, patientDescription});
    await this.refreshPortal(patientId);
  }

  async submitPortalRepeatRequest(
    patientId: string,
    authorisationId: string,
    nominatedPharmacy: string,
    patientNote: string,
  ): Promise<void> {
    await this.post(`/portal/${patientId}/repeat-requests`, {
      authorisationId,
      nominatedPharmacy,
      patientNote,
    });
    await this.refreshPortal(patientId);
  }

  async submitPortalContactUpdate(
    patientId: string,
    changes: {phone?: string; email?: string; preferredChannel?: Patient['preferredChannel']},
  ): Promise<void> {
    await this.post(`/portal/${patientId}/contact-update`, changes);
    await this.refreshPortal(patientId);
  }
}
