import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {AppointmentMode, Patient, RequestCategory, SlotHold} from '../../shared/models';
import {PracticeApi, type PortalSection} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-patient-portal',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (portal(); as data) {
      <div class="min-h-screen bg-[#F4F6F8] flex flex-col pb-20 md:pb-8">
        <!-- Mobile-Compact & Desktop Sticky Top Header (<= 56px height) -->
        <header class="bg-[#003087] text-white sticky top-0 z-30 h-14 px-4 md:px-6 flex items-center justify-between gap-3">
          <div class="flex items-center gap-2.5 min-w-0">
            <span class="font-bold text-sm tracking-tight whitespace-nowrap">Pennine Patient Portal</span>
            @if (data.viaProxy) {
              <span class="text-[11px] bg-white/15 px-2 py-0.5 rounded truncate">
                Proxy for {{ data.patient.firstName }}
              </span>
            }
          </div>

          <div class="flex items-center gap-2 shrink-0">
            @if (data.linkedPatients.length > 1) {
              <select
                [value]="data.patient.internalId"
                (change)="switchPortalPatient($event)"
                aria-label="Switch patient or proxy profile"
                class="text-xs bg-white/15 text-white border border-white/25 rounded-lg px-2 py-1"
              >
                @for (lp of data.linkedPatients; track lp.internalId) {
                  <option [value]="lp.internalId" class="text-slate-900">
                    {{ lp.fullName }}
                  </option>
                }
              </select>
            }

            <button
              type="button"
              (click)="api.signOut()"
              class="text-xs bg-white/10 hover:bg-white/20 px-2.5 py-1.5 rounded-lg font-medium whitespace-nowrap"
            >
              Sign Out
            </button>
          </div>
        </header>

        <!-- Desktop Horizontal Navigation Bar (Hidden on mobile where bottom tab bar is used) -->
        <nav
          aria-label="Patient Portal Navigation"
          class="hidden md:flex bg-white border-b border-slate-200 px-6 py-2 gap-2 overflow-x-auto"
        >
          @for (item of navItems; track item.id) {
            <button
              type="button"
              (click)="api.portalSection.set(item.id)"
              class="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap"
              [class.bg-[#005EB8]]="api.portalSection() === item.id"
              [class.text-white]="api.portalSection() === item.id"
              [class.text-slate-700]="api.portalSection() !== item.id"
              [class.hover:bg-slate-100]="api.portalSection() !== item.id"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">{{ item.icon }}</mat-icon>
              <span>{{ item.label }}</span>
            </button>
          }
        </nav>

        <!-- Main Responsive Content Canvas -->
        <main class="flex-1 max-w-5xl w-full mx-auto px-4 md:px-6 py-5 space-y-5">
          <!-- Mandatory Non-Emergency Guidance -->
          <div class="bg-amber-50 border border-amber-300 rounded-2xl p-4 text-xs text-amber-950 flex items-start gap-2.5">
            <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-amber-700 shrink-0">emergency</mat-icon>
            <div>
              <strong>Not an emergency service:</strong> For life-threatening emergencies call <strong>999</strong>. For urgent medical advice call <strong>NHS 111</strong>. Submitting a portal request is not confirmation that a clinician has reviewed it.
            </div>
          </div>

          @if (data.viaProxy) {
            <div class="bg-blue-50 border border-blue-200 rounded-2xl p-3.5 text-xs text-blue-950">
              <strong>Verified Proxy Access Active:</strong> You are viewing
              {{ data.patient.firstName }} {{ data.patient.lastName }} with granted scopes:
              <span class="font-mono font-semibold">{{ data.activeScopes.join(' · ') }}</span>.
            </div>
          }

          @if (api.bannerMessage(); as msg) {
            <div
              class="p-3.5 rounded-2xl border text-xs flex items-center justify-between gap-2"
              [class.bg-emerald-50]="msg.type === 'success'"
              [class.border-emerald-200]="msg.type === 'success'"
              [class.text-emerald-950]="msg.type === 'success'"
              [class.bg-red-50]="msg.type === 'error'"
              [class.border-red-200]="msg.type === 'error'"
              [class.text-red-950]="msg.type === 'error'"
              [class.bg-blue-50]="msg.type === 'info'"
              [class.border-blue-200]="msg.type === 'info'"
              [class.text-blue-950]="msg.type === 'info'"
            >
              <span>{{ msg.text }}</span>
              <button type="button" (click)="api.clearBanner()" class="underline font-semibold">Close</button>
            </div>
          }

          @switch (api.portalSection()) {
            @case ('home') {
              <div class="space-y-4">
                <div class="bg-white border border-slate-200 rounded-2xl p-5">
                  <h1 class="text-xl font-bold text-slate-900">
                    Welcome, {{ data.patient.firstName }} {{ data.patient.lastName }}
                  </h1>
                  <p class="text-xs text-slate-600 mt-1">
                    Pennine Medical Practice · Independent Prototype Portal (Synthetic Data)
                  </p>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <button
                    type="button"
                    (click)="api.portalSection.set('appointments')"
                    class="text-left bg-white border border-slate-200 rounded-2xl p-5 hover:border-[#005EB8] min-h-[44px]"
                  >
                    <div class="text-xs text-slate-500">Upcoming Appointments</div>
                    <div class="text-2xl font-bold text-slate-900 mt-1 tabular-nums">{{ upcomingAppointments().length }}</div>
                    <div class="text-xs text-[#005EB8] font-semibold mt-2">View or book slot →</div>
                  </button>

                  <button
                    type="button"
                    (click)="api.portalSection.set('requests')"
                    class="text-left bg-white border border-slate-200 rounded-2xl p-5 hover:border-[#005EB8] min-h-[44px]"
                  >
                    <div class="text-xs text-slate-500">Practice Requests</div>
                    <div class="text-2xl font-bold text-slate-900 mt-1 tabular-nums">{{ data.requests.length }}</div>
                    <div class="text-xs text-[#005EB8] font-semibold mt-2">Submit or track request →</div>
                  </button>

                  <button
                    type="button"
                    (click)="api.portalSection.set('messages')"
                    class="text-left bg-white border border-slate-200 rounded-2xl p-5 hover:border-[#005EB8] min-h-[44px]"
                  >
                    <div class="text-xs text-slate-500">Approved Messages</div>
                    <div class="text-2xl font-bold text-slate-900 mt-1 tabular-nums">{{ data.messages.length }}</div>
                    <div class="text-xs text-[#005EB8] font-semibold mt-2">Open secure inbox →</div>
                  </button>
                </div>
              </div>
            }

            @case ('appointments') {
              <div class="space-y-5">
                <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <h2 class="text-lg font-bold text-slate-900">Your Appointments</h2>
                  @for (apt of data.appointments; track apt.id) {
                    <div class="p-3.5 border border-slate-200 rounded-xl text-xs flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <div class="font-bold text-slate-900">
                          {{ apt.date }} at {{ apt.startTime }} · {{ apt.appointmentType }} ({{ apt.mode }})
                        </div>
                        <div class="text-slate-600 mt-0.5">
                          {{ clinicianName(apt.clinicianId) }} · {{ siteName(apt.siteId) }} · Status: {{ apt.status }}
                        </div>
                      </div>
                      @if (apt.status === 'booked') {
                        <button
                          type="button"
                          (click)="cancelAppt(apt.id)"
                          class="px-3 py-2 min-h-[44px] font-medium text-red-700 border border-red-200 rounded-xl hover:bg-red-50"
                        >
                          Cancel
                        </button>
                      }
                    </div>
                  } @empty {
                    <p class="text-xs text-slate-500">No appointments currently booked.</p>
                  }
                </div>

                <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                  <div>
                    <h2 class="text-lg font-bold text-slate-900">Book an Eligible Slot</h2>
                    <p class="text-xs text-slate-600">
                      Protected urgent triage slots are reserved for clinician/reception booking. Selecting a slot places a 5-minute hold.
                    </p>
                  </div>

                  @if (activeHold(); as hold) {
                    <div class="p-4 bg-blue-50 border border-blue-200 rounded-xl space-y-3 text-xs">
                      <div class="font-bold text-blue-950">
                        5-Minute Slot Hold Active: {{ hold.date }} at {{ hold.startTime }} (Expires {{ hold.expiresAt }})
                      </div>
                      <form [formGroup]="portalBookForm" (ngSubmit)="confirmHoldBooking()" class="space-y-2.5">
                        <select formControlName="mode" class="w-full border border-slate-300 rounded-xl px-3 py-2.5 bg-white">
                          <option value="in_person">In-person</option>
                          <option value="telephone">Telephone</option>
                          <option value="video">Video</option>
                        </select>
                        <input type="text" formControlName="reason" placeholder="Brief reason for appointment" class="w-full border border-slate-300 rounded-xl px-3 py-2.5 bg-white" />
                        <div class="flex gap-2">
                          <button type="submit" class="px-4 py-2.5 min-h-[44px] bg-[#005EB8] text-white font-semibold rounded-xl">
                            Confirm Booking
                          </button>
                          <button type="button" (click)="activeHold.set(null)" class="px-4 py-2.5 min-h-[44px] bg-white border border-slate-300 rounded-xl">
                            Release Hold
                          </button>
                        </div>
                      </form>
                    </div>
                  }

                  <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    @for (sl of data.eligibleSlots; track sl.sessionId + sl.startTime) {
                      <button
                        type="button"
                        (click)="holdSlot(sl.sessionId, sl.startTime)"
                        class="p-3 min-h-[48px] text-left border border-slate-200 rounded-xl hover:border-[#005EB8] text-xs"
                      >
                        <div class="font-mono font-bold text-slate-900 tabular-nums">{{ sl.startTime }}</div>
                        <div class="text-[11px] text-slate-600 truncate">{{ clinicianName(sl.clinicianId) }}</div>
                      </button>
                    }
                  </div>
                </div>
              </div>
            }

            @case ('requests') {
              <div class="space-y-5">
                <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                  <h2 class="text-lg font-bold text-slate-900">Submit a Practice Request</h2>
                  <form [formGroup]="reqForm" (ngSubmit)="submitRequest()" class="space-y-3 text-xs">
                    <label class="block text-slate-700">
                      <span>Request Type</span>
                      <select formControlName="category" class="mt-1 w-full border border-slate-300 rounded-xl px-3 py-2.5 bg-white">
                        <option value="clinician_callback">Clinician Callback Enquiry</option>
                        <option value="administrative">Administrative Enquiry</option>
                        <option value="fit_note">Fit-Note Request</option>
                        <option value="booking_enquiry">Appointment Help</option>
                        <option value="document_enquiry">Letter / Document Enquiry</option>
                      </select>
                    </label>
                    <label class="block text-slate-700">
                      <span>Your Description (Stored verbatim for the practice team)</span>
                      <textarea rows="3" formControlName="patientDescription" class="mt-1 w-full border border-slate-300 rounded-xl px-3 py-2.5 bg-white"></textarea>
                    </label>
                    <button type="submit" class="w-full sm:w-auto px-5 py-3 min-h-[44px] bg-[#005EB8] text-white font-semibold rounded-xl">
                      Submit Request
                    </button>
                  </form>
                </div>

                <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                  <h2 class="text-base font-bold text-slate-900">Your Submitted Requests</h2>
                  @for (r of data.requests; track r.id) {
                    <div class="p-3.5 border border-slate-200 rounded-xl text-xs space-y-1">
                      <div class="flex flex-wrap items-center justify-between gap-2">
                        <span class="font-semibold text-slate-900">{{ r.category }}</span>
                        <span class="font-medium text-[#005EB8]">
                          @if (r.status === 'submitted') {
                            Submitted — awaiting practice review
                          } @else if (r.status === 'awaiting_clinician_review') {
                            Queued — awaiting clinician review
                          } @else {
                            {{ r.status }}
                          }
                        </span>
                      </div>
                      <p class="text-slate-700">{{ r.patientDescription }}</p>
                    </div>
                  }
                </div>
              </div>
            }

            @case ('medicines') {
              <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <h2 class="text-lg font-bold text-slate-900">Repeat Medicines</h2>
                @if (!hasScope('medicines')) {
                  <div class="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-950">
                    Your verified proxy access for {{ data.patient.firstName }} does not include the <strong>medicines</strong> scope.
                  </div>
                } @else {
                  <div class="space-y-3 text-xs">
                    @for (auth of data.repeatAuthorisations; track auth.id) {
                      <div class="p-3.5 border border-slate-200 rounded-xl flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <div class="font-bold text-slate-900">{{ auth.drugName }}</div>
                          <div class="text-slate-600">{{ auth.doseInstruction }} · Remaining: {{ auth.maxIssues - auth.issuesUsed }}</div>
                        </div>
                        <button
                          type="button"
                          (click)="requestRepeat(auth.id)"
                          class="px-4 py-2.5 min-h-[44px] font-semibold bg-[#005EB8] text-white rounded-xl"
                        >
                          Request Repeat
                        </button>
                      </div>
                    }
                  </div>

                  <div class="pt-3 border-t border-slate-100 space-y-2 text-xs">
                    <h3 class="font-bold text-slate-900">Recent Repeat Requests</h3>
                    @for (rr of data.repeatRequests; track rr.id) {
                      <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                        <div class="font-semibold">{{ rr.drugName }} — {{ rr.status }}</div>
                        @if (rr.simulatedTransmission) {
                          <div class="text-amber-900 mt-0.5">{{ rr.simulatedTransmission.label }}</div>
                        }
                      </div>
                    }
                  </div>
                }
              </div>
            }

            @case ('messages') {
              <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-3">
                <h2 class="text-lg font-bold text-slate-900">Practice Messages</h2>
                @for (m of data.messages; track m.id) {
                  <div class="p-4 border border-slate-200 rounded-xl text-xs space-y-1">
                    <div class="font-bold text-slate-900">{{ m.subject }}</div>
                    <div class="text-slate-500">{{ m.createdAt }} · From {{ m.sentBy }}</div>
                    <p class="text-slate-800 pt-1">{{ m.body }}</p>
                  </div>
                } @empty {
                  <p class="text-xs text-slate-500">No messages released to your inbox.</p>
                }
              </div>
            }

            @case ('my-information') {
              <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <h2 class="text-lg font-bold text-slate-900">Released Health Record</h2>
                @if (!hasScope('records')) {
                  <div class="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-950">
                    Your verified proxy access for {{ data.patient.firstName }} does not include the <strong>records</strong> scope. Only practice-approved items within your granted scopes are accessible.
                  </div>
                } @else {
                  <p class="text-xs text-slate-600">
                    Showing only signed notes, clinically reviewed results, and approved correspondence under Pennine Medical Practice release policy.
                  </p>
                  <div class="space-y-3 text-xs">
                    <div class="font-bold text-slate-900">Clinically Reviewed Results ({{ data.releasedResults.length }})</div>
                    @for (r of data.releasedResults; track r.id) {
                      <div class="p-3 border border-slate-200 rounded-xl">
                        <div class="font-semibold">{{ r.testName }}: {{ r.originalValue }} {{ r.units }}</div>
                        <div class="text-slate-600">Reviewed by {{ r.reviewedBy }}: {{ r.reviewNote }}</div>
                      </div>
                    }
                    <div class="font-bold text-slate-900 pt-2">Signed Consultation Summaries ({{ data.releasedNotes.length }})</div>
                    @for (n of data.releasedNotes; track n.id) {
                      <div class="p-3 border border-slate-200 rounded-xl">
                        <div class="font-semibold">{{ n.presentingComplaint }} · {{ n.encounterTime }}</div>
                        <div class="text-slate-600">Plan: {{ n.plan }}</div>
                      </div>
                    }
                  </div>
                }
              </div>
            }

            @case ('account') {
              <div class="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
                <h2 class="text-lg font-bold text-slate-900">Account & Contact Preferences</h2>
                <div class="text-xs text-slate-700 space-y-1">
                  <div><strong>Name:</strong> {{ data.patient.title }} {{ data.patient.firstName }} {{ data.patient.lastName }}</div>
                  <div><strong>Internal ID:</strong> {{ data.patient.internalId }} · <strong>DOB:</strong> {{ data.patient.dob }}</div>
                  <div><strong>Phone:</strong> {{ data.patient.phone }} · <strong>Email:</strong> {{ data.patient.email }}</div>
                  <div><strong>Preferred Channel:</strong> {{ data.patient.preferredChannel }}</div>
                </div>

                <form [formGroup]="contactForm" (ngSubmit)="submitContactUpdate()" class="pt-3 border-t border-slate-100 space-y-3 text-xs">
                  <div class="font-bold text-slate-900">Request Contact Detail Update (Reviewed by Practice)</div>
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input type="text" formControlName="phone" placeholder="New mobile phone" class="border border-slate-300 rounded-xl px-3 py-2.5 bg-white" />
                    <select formControlName="preferredChannel" class="border border-slate-300 rounded-xl px-3 py-2.5 bg-white">
                      <option value="portal">Portal</option>
                      <option value="sms">SMS</option>
                      <option value="email">Email</option>
                      <option value="letter">Letter</option>
                    </select>
                  </div>
                  <button type="submit" class="px-4 py-2.5 min-h-[44px] bg-[#005EB8] text-white font-semibold rounded-xl">
                    Submit Contact Update for Review
                  </button>
                </form>
              </div>
            }
          }
        </main>

        <!-- Mobile Thumb-Zone Bottom Tab Bar (Fixed <= 64px height to respect 15% mobile sticky cap) -->
        <nav
          aria-label="Mobile Patient Navigation"
          class="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-5 items-center"
        >
          @for (item of mobileTabs; track item.id) {
            <button
              type="button"
              (click)="api.portalSection.set(item.id)"
              class="min-h-[44px] flex flex-col items-center justify-center text-[10px] font-medium"
              [class.text-[#005EB8]]="api.portalSection() === item.id"
              [class.font-bold]="api.portalSection() === item.id"
              [class.text-slate-600]="api.portalSection() !== item.id"
            >
              <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">{{ item.icon }}</mat-icon>
              <span class="mt-0.5 truncate max-w-full px-1">{{ item.label }}</span>
            </button>
          }
        </nav>
      </div>
    }
  `,
})
export class PatientPortal {
  protected readonly api = inject(PracticeApi);
  protected readonly portal = this.api.portalData;
  protected readonly activeHold = signal<SlotHold | null>(null);

  protected readonly navItems: {id: PortalSection; label: string; icon: string}[] = [
    {id: 'home', label: 'Home', icon: 'home'},
    {id: 'appointments', label: 'Appointments', icon: 'calendar_month'},
    {id: 'requests', label: 'Requests', icon: 'chat_bubble_outline'},
    {id: 'medicines', label: 'Medicines', icon: 'medication'},
    {id: 'messages', label: 'Messages', icon: 'mail'},
    {id: 'my-information', label: 'My information', icon: 'folder_shared'},
    {id: 'account', label: 'Account', icon: 'manage_accounts'},
  ];

  protected readonly mobileTabs: {id: PortalSection; label: string; icon: string}[] = [
    {id: 'home', label: 'Home', icon: 'home'},
    {id: 'appointments', label: 'Appts', icon: 'calendar_month'},
    {id: 'requests', label: 'Requests', icon: 'chat_bubble_outline'},
    {id: 'medicines', label: 'Meds', icon: 'medication'},
    {id: 'account', label: 'More', icon: 'manage_accounts'},
  ];

  protected readonly upcomingAppointments = computed(() =>
    (this.portal()?.appointments ?? []).filter((a) => a.status !== 'cancelled'),
  );

  protected readonly portalBookForm = new FormGroup({
    mode: new FormControl<AppointmentMode>('in_person', {nonNullable: true}),
    reason: new FormControl('Routine review', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly reqForm = new FormGroup({
    category: new FormControl<RequestCategory>('clinician_callback', {nonNullable: true}),
    patientDescription: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly contactForm = new FormGroup({
    phone: new FormControl('', {nonNullable: true}),
    preferredChannel: new FormControl<Patient['preferredChannel']>('portal', {nonNullable: true}),
  });

  protected hasScope(scope: string): boolean {
    return (this.portal()?.activeScopes ?? []).includes(scope);
  }

  protected clinicianName(id: string): string {
    return this.portal()?.clinicians.find((c) => c.id === id)?.name ?? id;
  }

  protected siteName(id: string): string {
    return this.portal()?.sites.find((s) => s.id === id)?.name ?? id;
  }

  protected async switchPortalPatient(event: Event): Promise<void> {
    const pid = (event.target as HTMLSelectElement).value;
    this.activeHold.set(null);
    await this.api.refreshPortal(pid);
  }

  protected async holdSlot(sessionId: string, startTime: string): Promise<void> {
    const pid = this.portal()?.patient.internalId;
    if (!pid) return;
    try {
      const hold = await this.api.holdPortalSlot(pid, sessionId, startTime);
      this.activeHold.set(hold);
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async confirmHoldBooking(): Promise<void> {
    const hold = this.activeHold();
    const pid = this.portal()?.patient.internalId;
    if (!hold || !pid || this.portalBookForm.invalid) return;
    const {mode, reason} = this.portalBookForm.getRawValue();
    try {
      await this.api.bookPortalAppointment(pid, {
        sessionId: hold.sessionId,
        startTime: hold.startTime,
        mode,
        appointmentType: 'Routine GP',
        reason,
        holdId: hold.id,
      });
      this.activeHold.set(null);
      this.api.notify('success', 'Appointment booked.');
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async cancelAppt(appointmentId: string): Promise<void> {
    const pid = this.portal()?.patient.internalId;
    if (!pid) return;
    await this.api.cancelPortalAppointment(pid, appointmentId, 'Cancelled via portal');
    this.api.notify('info', 'Appointment cancelled.');
  }

  protected async submitRequest(): Promise<void> {
    const pid = this.portal()?.patient.internalId;
    if (!pid || this.reqForm.invalid) return;
    const {category, patientDescription} = this.reqForm.getRawValue();
    await this.api.submitPortalRequest(pid, category, patientDescription);
    this.reqForm.patchValue({patientDescription: ''});
    this.api.notify(
      'success',
      'Submitted — awaiting practice review (not yet reviewed by a clinician).',
    );
  }

  protected async requestRepeat(authorisationId: string): Promise<void> {
    const pid = this.portal()?.patient.internalId;
    if (!pid) return;
    await this.api.submitPortalRepeatRequest(
      pid,
      authorisationId,
      'Millbrook Community Pharmacy',
      'Requested via patient portal',
    );
    this.api.notify('success', 'Repeat request submitted for administrative and prescriber review.');
  }

  protected async submitContactUpdate(): Promise<void> {
    const pid = this.portal()?.patient.internalId;
    if (!pid) return;
    const {phone, preferredChannel} = this.contactForm.getRawValue();
    await this.api.submitPortalContactUpdate(pid, {
      phone: phone || undefined,
      preferredChannel,
    });
    this.contactForm.patchValue({phone: ''});
    this.api.notify('success', 'Contact update submitted for practice verification.');
  }

  private extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as {error?: {error?: string}}).error;
      if (inner?.error) return inner.error;
    }
    return 'Portal action failed.';
  }
}
