import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi, type PortalSection, type StaffSection} from '../services/practice-api';

interface DemoStepItem {
  num: string;
  title: string;
  detail: string;
  targetRole: 'staff' | 'patient';
  staffSection?: StaffSection;
  portalSection?: PortalSection;
  patientId?: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-demo-guide-drawer',
  imports: [MatIconModule],
  template: `
    @if (api.showDemoGuide()) {
      <div class="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-[1px]">
        <aside
          aria-label="Reproducible Demonstration Walkthrough"
          class="w-full max-w-lg bg-white h-full overflow-y-auto border-l border-slate-200 p-6 space-y-5"
        >
          <div class="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h2 class="text-lg font-bold text-slate-900">Pennine Medical Practice Walkthrough</h2>
              <p class="text-xs text-slate-600 mt-0.5">
                14-step end-to-end demonstration & 5 clinical safety edge cases
              </p>
            </div>
            <button
              type="button"
              (click)="api.showDemoGuide.set(false)"
              class="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50"
              aria-label="Close demonstration guide"
            >
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">close</mat-icon>
            </button>
          </div>

          <div class="space-y-2.5 text-xs">
            @for (step of steps; track step.num) {
              <div class="p-3 border border-slate-200 rounded-xl flex items-start justify-between gap-3">
                <div>
                  <div class="font-bold text-slate-900">{{ step.num }}. {{ step.title }}</div>
                  <div class="text-slate-600 mt-0.5">{{ step.detail }}</div>
                </div>
                <button
                  type="button"
                  (click)="jumpTo(step)"
                  class="px-2.5 py-1.5 bg-[#005EB8] text-white rounded-lg font-medium shrink-0 hover:bg-[#003087]"
                >
                  Open
                </button>
              </div>
            }
          </div>
        </aside>
      </div>
    }
  `,
})
export class DemoGuideDrawer {
  protected readonly api = inject(PracticeApi);

  protected readonly steps: DemoStepItem[] = [
    {
      num: '01',
      title: 'Register a patient & review duplicate',
      detail: 'Register a synthetic patient or resolve duplicate Arthur Pendelton / Pendleton.',
      targetRole: 'staff',
      staffSection: 'patients',
    },
    {
      num: '02',
      title: 'Submit a portal request',
      detail: 'Switch to Patient Portal (Clara Bennett) and submit a request (shows non-emergency 999/111 notice).',
      targetRole: 'patient',
      portalSection: 'requests',
    },
    {
      num: '03',
      title: 'Route for authorised review',
      detail: 'In Requests, reception updates summary while GP Partner assigns clinical urgency.',
      targetRole: 'staff',
      staffSection: 'requests',
    },
    {
      num: '04',
      title: 'Book an appointment (check unavailable clinician)',
      detail: 'Book into Dr Vance AM clinic or verify Dr Mahmood annual leave session is blocked.',
      targetRole: 'staff',
      staffSection: 'appointments',
    },
    {
      num: '05',
      title: 'Record arrival',
      detail: 'Mark booked patient as Arrived on Today queue.',
      targetRole: 'staff',
      staffSection: 'today',
    },
    {
      num: '06–08',
      title: 'Open record, draft, simulate interrupted save, sign & amend',
      detail: 'Author consultation for PT-1001, test interrupted save recovery, sign (SHA-256), and append amendment.',
      targetRole: 'staff',
      staffSection: 'consultations',
      patientId: 'PT-1001',
    },
    {
      num: '09',
      title: 'Process repeat medication (simulated only)',
      detail: 'Approve/reject RREQ-1 as GP Partner or Pharmacist; see safety coverage & non-real EPS label.',
      targetRole: 'staff',
      staffSection: 'prescriptions',
    },
    {
      num: '10–11',
      title: 'Receive lab result, match unmatched & complete follow-up',
      detail: 'View RES-9001 (remains unreviewed), match RES-9003, review, and complete follow-up task with evidence.',
      targetRole: 'staff',
      staffSection: 'results',
    },
    {
      num: '12',
      title: 'Process incoming OCR correspondence',
      detail: 'Match uncertain letter DOC-502 and review OCR text before filing.',
      targetRole: 'staff',
      staffSection: 'documents',
    },
    {
      num: '13',
      title: 'Prepare simulated referral',
      detail: 'Create local referral draft REF-701 and submit to simulated e-RS separately from acceptance.',
      targetRole: 'staff',
      staffSection: 'referrals',
    },
    {
      num: '14',
      title: 'Failed notification recovery & Audit history',
      detail: 'Retry failed SMS COMM-4002 in Tasks, then inspect Audit, Hazard Log, and Capabilities in Administration.',
      targetRole: 'staff',
      staffSection: 'tasks',
    },
    {
      num: '15',
      title: 'Audit, Hazard Log & Integration Boundaries',
      detail: 'Inspect full audit trail, 7 integration boundaries, 6 clinical hazards, and capability matrix.',
      targetRole: 'staff',
      staffSection: 'administration',
    },
  ];

  protected async jumpTo(step: DemoStepItem): Promise<void> {
    if (step.targetRole === 'patient') {
      await this.api.loginDemo('USR-PAT-1001');
      if (step.portalSection) {
        this.api.portalSection.set(step.portalSection);
      }
      this.api.showDemoGuide.set(false);
      return;
    }

    if (!this.api.isStaff()) {
      await this.api.loginDemo('USR-GP-1');
    }
    if (step.patientId) {
      this.api.requestPatientSwitch(step.patientId);
    }
    if (step.staffSection) {
      this.api.staffSection.set(step.staffSection);
    }
    this.api.showDemoGuide.set(false);
  }
}
