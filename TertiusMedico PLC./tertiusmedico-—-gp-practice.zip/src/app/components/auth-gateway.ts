import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-auth-gateway',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="min-h-screen bg-[#F4F6F8] flex flex-col">
      <!-- Top Prototype Notice Bar -->
      <header class="bg-[#003087] text-white px-6 py-4 border-b border-white/15">
        <div class="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-lg bg-white text-[#003087] font-bold flex items-center justify-center text-sm tracking-tight">
              TM
            </div>
            <div>
              <h1 class="text-lg font-bold tracking-tight">TERTIUSMEDICO — GP Practice</h1>
              <p class="text-xs text-blue-100">
                Pennine Medical Practice · Millbrook Surgery & Valley View Branch
              </p>
            </div>
          </div>
          <span class="text-xs font-medium bg-white/10 border border-white/20 px-3 py-1.5 rounded-lg">
            Independent Prototype · Synthetic Data Only · Not NHS Certified
          </span>
        </div>
      </header>

      <main class="flex-1 max-w-6xl w-full mx-auto px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <!-- Left Column: Governance & Clinical Safety Overview -->
        <div class="lg:col-span-5 space-y-6">
          <div class="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
            <h2 class="text-xl font-bold text-slate-900">
              Connected General Practice & Patient Access
            </h2>
            <p class="text-sm text-slate-600 leading-relaxed">
              An integrated British general-practice prototype connecting reception navigation,
              Europe/London rota scheduling, attributable clinical consultations, repeat
              medication governance, laboratory results, correspondence, and a mobile-optimised
              patient portal.
            </p>
            <div class="border-t border-slate-100 pt-4 space-y-2.5 text-xs text-slate-700">
              <div class="flex items-start gap-2.5">
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#005EB8] shrink-0">verified_user</mat-icon>
                <span>
                  <strong>Explicit Role Boundaries:</strong> Prescribing, clinical signing,
                  urgency triage, and result sign-off are enforced server-side.
                </span>
              </div>
              <div class="flex items-start gap-2.5">
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#005EB8] shrink-0">shield</mat-icon>
                <span>
                  <strong>Wrong-Patient & Immutability Safeguards:</strong> Unsaved drafts lock
                  to the active patient; signed notes remain immutable with linked amendments.
                </span>
              </div>
              <div class="flex items-start gap-2.5">
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-amber-700 shrink-0">info</mat-icon>
                <span>
                  <strong>Simulated Integrations:</strong> PDS, EPS, Pathology, e-RS, and SMS
                  gateways use typed local mocks. No real prescriptions are issued.
                </span>
              </div>
            </div>
          </div>

          <div class="bg-amber-50 border border-amber-200 rounded-2xl p-5 text-xs text-amber-950 space-y-1.5">
            <p class="font-semibold flex items-center gap-1.5">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">emergency</mat-icon>
              Urgent & Emergency Medical Guidance
            </p>
            <p class="leading-relaxed">
              This software is an independent prototype for Pennine Medical Practice. In a real
              clinical emergency always call <strong>999</strong>, or contact <strong>NHS 111</strong>
              for urgent medical help.
            </p>
          </div>
        </div>

        <!-- Right Column: Persona Sign-In (Staff & Patient Portal) -->
        <div class="lg:col-span-7 space-y-6">
          @if (errorMsg()) {
            <div class="bg-red-50 border border-red-200 text-red-900 rounded-xl px-4 py-3 text-sm flex items-center gap-2">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">error</mat-icon>
              <span>{{ errorMsg() }}</span>
            </div>
          }

          <div class="bg-white border border-slate-200 rounded-2xl p-6 space-y-5">
            <div class="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 class="text-lg font-bold text-slate-900">Practice Staff Sign-In (Desktop)</h2>
                <p class="text-xs text-slate-500">
                  Organisational sign-in with simulated MFA check and role-based permissions
                </p>
              </div>
              <span class="text-xs text-slate-500 font-mono">Site: Pennine Medical Practice</span>
            </div>

            <div class="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#005EB8]">phonelink_lock</mat-icon>
              <label class="text-xs text-slate-700 flex items-center gap-2 flex-1">
                <span>Simulated MFA Token (6 digits)</span>
                <input
                  type="text"
                  [formControl]="mfaControl"
                  maxlength="6"
                  class="w-24 font-mono border border-slate-300 rounded-md px-2 py-1 text-xs bg-white"
                />
              </label>
              <span class="text-xs text-emerald-700 font-medium">CIS2 Mock Ready</span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              @for (staff of staffPersonas(); track staff.id) {
                <button
                  type="button"
                  (click)="signInAs(staff.id)"
                  class="text-left p-3.5 rounded-xl border border-slate-200 hover:border-[#005EB8] hover:bg-blue-50/40 transition-colors flex items-start justify-between gap-3"
                >
                  <div>
                    <div class="text-sm font-semibold text-slate-900">{{ staff.name }}</div>
                    <div class="text-xs text-slate-600 mt-0.5">{{ staff.title }}</div>
                    <div class="text-[11px] font-mono text-[#005EB8] mt-1">{{ staff.role }}</div>
                  </div>
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-slate-400 shrink-0">login</mat-icon>
                </button>
              }
            </div>
          </div>

          <div class="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
            <div>
              <h2 class="text-lg font-bold text-slate-900">Patient Portal Sign-In (Mobile & Web)</h2>
              <p class="text-xs text-slate-500">
                Verified patient identity & scoped proxy access (NHS number is never used for login)
              </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              @for (pat of patientPersonas(); track pat.id) {
                <button
                  type="button"
                  (click)="signInAs(pat.id)"
                  class="text-left p-3.5 rounded-xl border border-slate-200 hover:border-[#005EB8] hover:bg-blue-50/40 transition-colors flex items-start justify-between gap-3"
                >
                  <div>
                    <div class="text-sm font-semibold text-slate-900">{{ pat.name }}</div>
                    <div class="text-xs text-slate-600 mt-0.5">{{ pat.title }}</div>
                    <div class="text-[11px] font-mono text-slate-500 mt-1">
                      Patient ID: {{ pat.patientId }}
                      @if ((pat.linkedPatientIds?.length ?? 0) > 1) {
                        · +Proxy Link
                      }
                    </div>
                  </div>
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-[#005EB8] shrink-0">smartphone</mat-icon>
                </button>
              }
            </div>
          </div>

          <!-- Standard Password Login Form -->
          <details class="bg-white border border-slate-200 rounded-2xl p-5">
            <summary class="text-xs font-semibold text-slate-700 cursor-pointer">
              Standard Password Sign-In (for server scrypt credential verification)
            </summary>
            <form [formGroup]="loginForm" (ngSubmit)="submitPasswordLogin()" class="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
              <label class="text-xs text-slate-600 block">
                <span>User ID</span>
                <input
                  type="text"
                  formControlName="userId"
                  placeholder="USR-GP-1"
                  class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 text-xs bg-white"
                />
              </label>
              <label class="text-xs text-slate-600 block">
                <span>Password</span>
                <input
                  type="password"
                  formControlName="password"
                  class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 text-xs bg-white"
                />
              </label>
              <button
                type="submit"
                class="px-4 py-2 text-xs font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087] transition-colors"
              >
                Verify & Sign In
              </button>
            </form>
          </details>
        </div>
      </main>
    </div>
  `,
})
export class AuthGateway {
  protected readonly api = inject(PracticeApi);
  protected readonly errorMsg = signal<string | null>(null);
  protected readonly mfaControl = new FormControl('482910', {nonNullable: true});
  protected readonly loginForm = new FormGroup({
    userId: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
    password: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly staffPersonas = computed(() =>
    this.api.personas().filter((p) => p.role !== 'PATIENT'),
  );
  protected readonly patientPersonas = computed(() =>
    this.api.personas().filter((p) => p.role === 'PATIENT'),
  );

  protected async signInAs(userId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      await this.api.loginDemo(userId, this.mfaControl.value);
    } catch {
      this.errorMsg.set('Unable to sign in with selected demo account.');
    }
  }

  protected async submitPasswordLogin(): Promise<void> {
    if (this.loginForm.invalid) return;
    this.errorMsg.set(null);
    const {userId, password} = this.loginForm.getRawValue();
    try {
      await this.api.loginPassword(userId, password);
    } catch {
      this.errorMsg.set('Invalid User ID or password.');
    }
  }
}
