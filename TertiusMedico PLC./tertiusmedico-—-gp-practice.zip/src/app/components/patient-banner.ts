import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-patient-banner',
  imports: [MatIconModule],
  template: `
    @if (patient(); as p) {
      <section
        aria-label="Active Patient Clinical Identity Banner"
        class="bg-white border-b border-slate-200 px-6 py-3"
      >
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div class="flex flex-wrap items-baseline gap-x-4 gap-y-1">
            <h2 class="text-lg font-bold text-slate-900">
              {{ p.title }} {{ p.firstName }} {{ p.lastName }}
            </h2>
            <div class="flex flex-wrap items-center gap-2 text-xs text-slate-600 tabular-nums">
              <span>Born {{ p.dob }} ({{ ageYears() }} yrs)</span>
              <span aria-hidden="true">·</span>
              <span>{{ p.sexAtBirth }}</span>
              <span aria-hidden="true">·</span>
              <span class="font-mono font-medium text-slate-800">ID: {{ p.internalId }}</span>
              <span aria-hidden="true">·</span>
              <span class="font-mono">
                NHS:
                @if (p.nhsNumber) {
                  {{ p.nhsNumber }}
                } @else {
                  Not supplied
                }
              </span>
              <span aria-hidden="true">·</span>
              <span
                class="font-medium"
                [class.text-emerald-700]="p.nhsVerificationStatus === 'verified'"
                [class.text-amber-700]="p.nhsVerificationStatus !== 'verified'"
              >
                PDS: {{ verificationLabel() }}
              </span>
            </div>
          </div>

          <div class="flex items-center gap-3">
            @if (api.hasUnsavedClinicalChanges()) {
              <span class="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-300 rounded-md px-2.5 py-1">
                <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">lock</mat-icon>
                Unsaved Draft Locked to {{ p.internalId }}
              </span>
            }

            <label class="text-xs font-medium text-slate-600 flex items-center gap-2">
              <span class="whitespace-nowrap">Active Record</span>
              <select
                class="border border-slate-300 rounded-lg bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-[#005EB8]"
                [value]="p.internalId"
                (change)="onPatientSelect($event)"
              >
                @for (item of patients(); track item.internalId) {
                  <option [value]="item.internalId">
                    {{ item.lastName }}, {{ item.firstName }} ({{ item.internalId }} · {{ item.dob }})
                  </option>
                }
              </select>
            </label>
          </div>
        </div>

        <div class="mt-2 flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
          <div class="flex flex-wrap items-center gap-3">
            @if (p.allergyStatus === 'known_allergies') {
              <span class="inline-flex items-center gap-1.5 font-semibold text-red-800 bg-red-50 border border-red-200 rounded-md px-2.5 py-1">
                <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">warning</mat-icon>
                Allergy Alert:
                @for (alg of p.allergies; track alg.id) {
                  {{ alg.substance }} ({{ alg.severity }})
                }
              </span>
            } @else if (p.allergyStatus === 'confirmed_nkda') {
              <span class="inline-flex items-center gap-1.5 font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-md px-2.5 py-1">
                <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">verified_user</mat-icon>
                Confirmed No Known Drug Allergies (NKDA)
              </span>
            } @else {
              <span class="inline-flex items-center gap-1.5 font-semibold text-amber-900 bg-amber-50 border border-amber-300 rounded-md px-2.5 py-1">
                <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">help_outline</mat-icon>
                No allergies recorded (Status: Unverified — Do NOT treat as No Known Allergies)
              </span>
            }

            @if (p.accessibilityNeeds.length > 0 || p.interpreterRequired) {
              <span class="text-slate-700">
                Access needs:
                {{ p.accessibilityNeeds.join(', ') }}
                @if (p.interpreterRequired) {
                  (Interpreter: {{ p.preferredLanguage }})
                }
              </span>
            }
          </div>

          <div class="text-slate-500">
            <span>Registration: {{ p.registrationStatus }}</span>
            <span aria-hidden="true" class="mx-1.5">·</span>
            <span>Prefers {{ p.preferredChannel }}</span>
          </div>
        </div>

        @if (api.pendingPatientSwitchId(); as targetId) {
          <div class="mt-3 p-3 bg-amber-50 border border-amber-300 rounded-xl flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-2 text-xs text-amber-950 font-medium">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-amber-700">gpp_maybe</mat-icon>
              <span>
                Wrong-patient protection: you have unsaved consultation edits for
                <strong>{{ p.firstName }} {{ p.lastName }} ({{ p.internalId }})</strong>.
                Switching to <strong>{{ targetId }}</strong> will discard unsaved text unless saved first.
              </span>
            </div>
            <div class="flex items-center gap-2">
              <button
                type="button"
                (click)="api.cancelPatientSwitch()"
                class="px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-800 rounded-lg hover:bg-slate-50"
              >
                Stay on {{ p.internalId }}
              </button>
              <button
                type="button"
                (click)="api.confirmDiscardAndSwitchPatient()"
                class="px-3 py-1.5 text-xs font-medium bg-amber-700 text-white rounded-lg hover:bg-amber-800"
              >
                Discard Draft & Switch to {{ targetId }}
              </button>
            </div>
          </div>
        }
      </section>
    }
  `,
})
export class PatientBanner {
  protected readonly api = inject(PracticeApi);
  protected readonly patient = this.api.activePatient;
  protected readonly patients = computed(() => this.api.workspace()?.patients ?? []);

  protected readonly ageYears = computed(() => {
    const p = this.patient();
    if (!p) return 0;
    const birthYear = Number(p.dob.slice(0, 4));
    return Math.max(0, 2026 - birthYear);
  });

  protected readonly verificationLabel = computed(() => {
    const status = this.patient()?.nhsVerificationStatus;
    switch (status) {
      case 'verified':
        return 'Verified (Mock PDS)';
      case 'trace_pending':
        return 'Trace pending';
      case 'unverified':
        return 'Unverified';
      default:
        return 'Not supplied';
    }
  });

  protected onPatientSelect(event: Event): void {
    const select = event.target as HTMLSelectElement;
    const ok = this.api.requestPatientSwitch(select.value);
    if (!ok) {
      select.value = this.api.activePatientId();
    }
  }
}
