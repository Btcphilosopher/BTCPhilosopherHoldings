import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi, type StaffSection} from '../services/practice-api';
import {AdminView} from '../staff/admin-view';
import {AppointmentsView} from '../staff/appointments-view';
import {ConsultationsView} from '../staff/consultations-view';
import {DocumentsView} from '../staff/documents-view';
import {PatientsView} from '../staff/patients-view';
import {PrescriptionsView} from '../staff/prescriptions-view';
import {ReferralsView} from '../staff/referrals-view';
import {ReportsView} from '../staff/reports-view';
import {RequestsView} from '../staff/requests-view';
import {ResultsView} from '../staff/results-view';
import {TasksView} from '../staff/tasks-view';
import {TodayView} from '../staff/today-view';
import {DemoGuideDrawer} from './demo-guide-drawer';
import {PatientBanner} from './patient-banner';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-staff-shell',
  imports: [
    MatIconModule,
    PatientBanner,
    DemoGuideDrawer,
    TodayView,
    AppointmentsView,
    PatientsView,
    ConsultationsView,
    RequestsView,
    ResultsView,
    PrescriptionsView,
    ReferralsView,
    DocumentsView,
    TasksView,
    ReportsView,
    AdminView,
  ],
  template: `
    <div class="min-h-screen flex bg-[#F4F6F8]">
      <!-- Deep-Blue NHS-Inspired Staff Sidebar (240px) -->
      <aside class="w-60 bg-[#003087] text-white flex flex-col shrink-0">
        <div class="px-5 py-4 border-b border-white/15">
          <div class="text-sm font-bold tracking-tight">TERTIUSMEDICO</div>
          <div class="text-[11px] text-blue-100 mt-0.5">Pennine Medical Practice</div>
        </div>

        <nav aria-label="Staff Navigation" class="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          @for (item of navItems; track item.id) {
            <button
              type="button"
              (click)="selectSection(item.id)"
              class="w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center gap-2.5 transition-colors whitespace-nowrap"
              [class.bg-white]="api.staffSection() === item.id"
              [class.text-[#003087]]="api.staffSection() === item.id"
              [class.font-bold]="api.staffSection() === item.id"
              [class.text-blue-100]="api.staffSection() !== item.id"
              [class.hover:bg-white/10]="api.staffSection() !== item.id"
            >
              <mat-icon class="!text-[17px] !w-[17px] !h-[17px]">{{ item.icon }}</mat-icon>
              <span>{{ item.label }}</span>
            </button>
          }
        </nav>

        <div class="p-4 border-t border-white/15 space-y-2 text-[11px] text-blue-100">
          <div class="font-semibold text-white">Independent Prototype</div>
          <div>Synthetic patients only. Not NHS certified. No real prescriptions.</div>
          <button
            type="button"
            (click)="api.showDemoGuide.set(true)"
            class="w-full mt-1 py-1.5 px-2.5 bg-white/15 hover:bg-white/25 text-white rounded-lg font-medium flex items-center justify-center gap-1.5"
          >
            <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">playlist_play</mat-icon>
            14-Step Demo Guide
          </button>
        </div>
      </aside>

      <!-- Main Staff Workspace -->
      <div class="flex-1 min-w-0 flex flex-col">
        <!-- Top Bar -->
        <header class="bg-white border-b border-slate-200 px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          <div class="flex items-center gap-3 text-xs">
            <span class="font-semibold text-slate-900">Staff Workstation</span>
            <span class="text-slate-400">/</span>
            <span class="text-[#005EB8] font-semibold capitalize">{{ api.staffSection() }}</span>
            <span class="text-slate-300">|</span>
            <span class="text-slate-600 font-mono">
              @switch (api.saveState()) {
                @case ('saving') { Saving... }
                @case ('saved') { Synced }
                @case ('error') { Save error }
                @default { Ready }
              }
            </span>
          </div>

          <div class="flex flex-wrap items-center gap-3 text-xs">
            <label class="flex items-center gap-1.5 text-slate-600">
              <span>Role:</span>
              <select
                [value]="api.currentUser()?.id"
                (change)="switchPersona($event)"
                class="border border-slate-300 rounded-lg px-2.5 py-1 bg-slate-50 font-medium text-slate-900"
              >
                @for (p of api.personas(); track p.id) {
                  <option [value]="p.id">{{ p.name }} ({{ p.role }})</option>
                }
              </select>
            </label>

            <button
              type="button"
              (click)="api.signOut()"
              class="inline-flex items-center gap-1 px-3 py-1.5 border border-slate-300 rounded-lg font-medium text-slate-700 hover:bg-slate-50"
            >
              <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">logout</mat-icon>
              Sign Out
            </button>
          </div>
        </header>

        <!-- Persistent Patient Identity Banner on Clinical / Patient-Scoped Views -->
        @if (showPatientBanner()) {
          <app-patient-banner />
        }

        <!-- Global Feedback Banner -->
        @if (api.bannerMessage(); as msg) {
          <div
            class="mx-6 mt-4 px-4 py-3 rounded-xl border text-xs flex items-center justify-between gap-3"
            [class.bg-emerald-50]="msg.type === 'success'"
            [class.border-emerald-200]="msg.type === 'success'"
            [class.text-emerald-950]="msg.type === 'success'"
            [class.bg-red-50]="msg.type === 'error'"
            [class.border-red-200]="msg.type === 'error'"
            [class.text-red-950]="msg.type === 'error'"
            [class.bg-blue-50]="msg.type === 'info'"
            [class.border-blue-200]="msg.type === 'info'"
            [class.text-blue-950]="msg.type === 'info'"
          >
            <span>{{ msg.text }}</span>
            <button type="button" (click)="api.clearBanner()" class="font-semibold underline shrink-0">
              Dismiss
            </button>
          </div>
        }

        <!-- Active Staff Module Viewport -->
        <main class="flex-1 p-6 max-w-7xl w-full">
          @switch (api.staffSection()) {
            @case ('today') { <app-today-view /> }
            @case ('appointments') { <app-appointments-view /> }
            @case ('patients') { <app-patients-view /> }
            @case ('consultations') { <app-consultations-view /> }
            @case ('requests') { <app-requests-view /> }
            @case ('results') { <app-results-view /> }
            @case ('prescriptions') { <app-prescriptions-view /> }
            @case ('referrals') { <app-referrals-view /> }
            @case ('documents') { <app-documents-view /> }
            @case ('tasks') { <app-tasks-view /> }
            @case ('reports') { <app-reports-view /> }
            @case ('administration') { <app-admin-view /> }
          }
        </main>
      </div>
    </div>

    <app-demo-guide-drawer />
  `,
})
export class StaffShell {
  protected readonly api = inject(PracticeApi);
  protected readonly switching = signal(false);

  protected readonly navItems: {id: StaffSection; label: string; icon: string}[] = [
    {id: 'today', label: 'Today', icon: 'today'},
    {id: 'appointments', label: 'Appointments', icon: 'calendar_month'},
    {id: 'patients', label: 'Patients', icon: 'groups'},
    {id: 'consultations', label: 'Consultations', icon: 'clinical_notes'},
    {id: 'requests', label: 'Requests', icon: 'inbox'},
    {id: 'results', label: 'Results', icon: 'biotech'},
    {id: 'prescriptions', label: 'Prescriptions', icon: 'medication'},
    {id: 'referrals', label: 'Referrals', icon: 'outgoing_mail'},
    {id: 'documents', label: 'Documents', icon: 'description'},
    {id: 'tasks', label: 'Tasks', icon: 'task_alt'},
    {id: 'reports', label: 'Reports', icon: 'analytics'},
    {id: 'administration', label: 'Administration', icon: 'admin_panel_settings'},
  ];

  protected readonly showPatientBanner = computed(() => {
    const sec = this.api.staffSection();
    return (
      sec === 'patients' ||
      sec === 'consultations' ||
      sec === 'prescriptions' ||
      sec === 'referrals'
    );
  });

  protected selectSection(section: StaffSection): void {
    this.api.staffSection.set(section);
  }

  protected async switchPersona(event: Event): Promise<void> {
    const userId = (event.target as HTMLSelectElement).value;
    if (!userId || this.switching()) return;
    this.switching.set(true);
    try {
      await this.api.loginDemo(userId);
    } finally {
      this.switching.set(false);
    }
  }
}
