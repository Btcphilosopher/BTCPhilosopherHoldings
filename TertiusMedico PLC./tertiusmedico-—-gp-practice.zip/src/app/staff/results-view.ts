import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-results-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Laboratory & Investigation Results</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Received → Matched → Awaiting Review → Reviewed → Action Assigned → Follow-Up Completed
            </p>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <button
              type="button"
              (click)="simulateLabFeed(false)"
              class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">science</mat-icon>
              Ingest Synthetic Result
            </button>
            <button
              type="button"
              (click)="simulateLabFeed(true)"
              class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">content_copy</mat-icon>
              Test Duplicate Lab Message
            </button>
          </div>
        </div>

        <div class="space-y-4">
          @for (res of data.labResults; track res.id) {
            <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <div class="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <div class="flex flex-wrap items-center gap-2">
                    <span class="font-mono text-xs text-slate-500">{{ res.id }}</span>
                    <h2 class="text-base font-bold text-slate-900">{{ res.testName }}</h2>
                    <span class="font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {{ res.originalValue }} {{ res.units }}
                    </span>
                    <span
                      class="text-xs font-semibold px-2 py-0.5 rounded border"
                      [class.bg-red-50]="res.abnormalFlag === 'high' || res.abnormalFlag === 'critical'"
                      [class.text-red-800]="res.abnormalFlag === 'high' || res.abnormalFlag === 'critical'"
                      [class.border-red-200]="res.abnormalFlag === 'high' || res.abnormalFlag === 'critical'"
                      [class.bg-amber-50]="res.abnormalFlag === 'unknown'"
                      [class.text-amber-900]="res.abnormalFlag === 'unknown'"
                      [class.border-amber-200]="res.abnormalFlag === 'unknown'"
                      [class.bg-emerald-50]="res.abnormalFlag === 'normal'"
                      [class.text-emerald-800]="res.abnormalFlag === 'normal'"
                      [class.border-emerald-200]="res.abnormalFlag === 'normal'"
                    >
                      Lab flag: {{ res.abnormalFlag }}
                    </span>
                  </div>
                  <div class="text-xs text-slate-600 mt-1">
                    Source: {{ res.sourceLab }} · Message ID: <span class="font-mono">{{ res.externalMessageId }}</span> ·
                    Reference range:
                    @if (res.referenceRangeAvailable) {
                      <span class="font-mono">{{ res.referenceRange }} {{ res.units }}</span>
                    } @else {
                      <span class="font-semibold text-amber-800">Unavailable from source laboratory</span>
                    }
                  </div>
                  <div class="text-xs text-slate-500 mt-0.5">
                    Specimen: {{ res.specimenCollectedAt }} · Reported: {{ res.reportedAt }} · v{{ res.version }}
                  </div>
                </div>

                <div class="text-right text-xs space-y-1">
                  <div class="font-semibold px-2.5 py-1 rounded border border-slate-200 bg-slate-50">
                    {{ res.status }}
                  </div>
                  @if (res.matchStatus !== 'matched') {
                    <div class="text-red-700 font-semibold">UNMATCHED PATIENT</div>
                  } @else {
                    <div class="text-slate-600">Patient: {{ patientName(res.patientId!) }}</div>
                  }
                </div>
              </div>

              <!-- Unmatched Patient Handling -->
              @if (res.matchStatus !== 'matched') {
                <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div class="font-bold text-amber-950">Unmatched Result Held Safely Outside Patient Charts</div>
                    <div>Raw laboratory label: {{ res.rawPatientSummary }}</div>
                  </div>
                  <form [formGroup]="matchForm" (ngSubmit)="matchResult(res.id)" class="flex items-center gap-2">
                    <select formControlName="patientId" class="border border-slate-300 rounded px-2.5 py-1.5 bg-white">
                      @for (p of data.patients; track p.internalId) {
                        <option [value]="p.internalId">{{ p.lastName }}, {{ p.firstName }} ({{ p.dob }})</option>
                      }
                    </select>
                    <button type="submit" class="px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg">
                      Match Patient
                    </button>
                  </form>
                </div>
              }

              <!-- Amendments History -->
              @if (res.amendments.length > 0) {
                <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                  <div class="font-bold text-slate-900">Laboratory Corrections / Amendments</div>
                  @for (a of res.amendments; track a.version) {
                    <div>
                      v{{ a.version }}: {{ a.previousValue }} → <strong>{{ a.newValue }}</strong> ({{ a.reason }})
                    </div>
                  }
                </div>
              }

              <!-- Viewing vs Clinical Review Action -->
              <div class="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
                <div class="text-slate-600">
                  Viewed by {{ res.viewedByIds.length }} user(s)
                  <span class="text-slate-400">· Viewing never marks a result reviewed</span>
                  @if (res.reviewedBy) {
                    <span class="text-emerald-800 font-medium">
                      · Reviewed by {{ res.reviewedBy }} ({{ res.reviewedAt }}) — "{{ res.reviewNote }}"
                    </span>
                  }
                </div>

                <div class="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    (click)="recordView(res.id)"
                    class="px-3 py-1.5 font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    View Result (Audit Only)
                  </button>

                  @if (res.matchStatus === 'matched' && api.isClinician() && res.status === 'awaiting_clinical_review') {
                    <button
                      type="button"
                      (click)="reviewTargetId.set(res.id)"
                      class="inline-flex items-center gap-1 px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                    >
                      <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">fact_check</mat-icon>
                      Clinically Review & Assign Follow-Up
                    </button>
                  }
                </div>
              </div>

              @if (reviewTargetId() === res.id) {
                <form [formGroup]="reviewForm" (ngSubmit)="submitReview(res.id)" class="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
                  <label class="block text-slate-800">
                    <span class="font-semibold">Clinical Review Comment (Required)</span>
                    <input type="text" formControlName="reviewNote" placeholder="e.g. Borderline raised potassium; repeat U&Es in 48h" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white" />
                  </label>
                  <label class="flex items-center gap-2 text-slate-800">
                    <input type="checkbox" formControlName="assignFollowUpTask" />
                    <span>Create mandatory follow-up task</span>
                  </label>
                  <label class="block text-slate-800">
                    <span>Follow-Up Task Title</span>
                    <input type="text" formControlName="followUpTitle" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white" />
                  </label>
                  <div class="flex items-center gap-2">
                    <button type="submit" class="px-4 py-2 font-semibold bg-[#005EB8] text-white rounded-lg">
                      Sign Off Result Review
                    </button>
                    <button type="button" (click)="reviewTargetId.set(null)" class="px-3 py-2 bg-white border border-slate-300 rounded-lg">
                      Cancel
                    </button>
                  </div>
                </form>
              }
            </article>
          }
        </div>
      </div>
    }
  `,
})
export class ResultsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly reviewTargetId = signal<string | null>(null);

  protected readonly matchForm = new FormGroup({
    patientId: new FormControl('PT-1001', {nonNullable: true}),
  });

  protected readonly reviewForm = new FormGroup({
    reviewNote: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
    assignFollowUpTask: new FormControl(true, {nonNullable: true}),
    followUpTitle: new FormControl('Arrange repeat test & confirm patient contacted', {nonNullable: true}),
  });

  protected patientName(id: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === id);
    return p ? `${p.firstName} ${p.lastName} (${id})` : id;
  }

  protected async recordView(resultId: string): Promise<void> {
    await this.api.viewLabResult(resultId);
    this.api.notify(
      'info',
      `Recorded view for ${resultId}. Status remains unchanged (viewing does not review).`,
    );
  }

  protected async matchResult(resultId: string): Promise<void> {
    const {patientId} = this.matchForm.getRawValue();
    await this.api.matchLabResult(resultId, patientId);
    this.api.notify('success', `Matched ${resultId} to ${patientId}; queued for clinician review.`);
  }

  protected async submitReview(resultId: string): Promise<void> {
    if (this.reviewForm.invalid) return;
    const v = this.reviewForm.getRawValue();
    await this.api.reviewLabResult(resultId, {
      reviewNote: v.reviewNote,
      assignFollowUpTask: v.assignFollowUpTask,
      followUpTitle: v.followUpTitle,
    });
    this.reviewForm.patchValue({reviewNote: ''});
    this.reviewTargetId.set(null);
    this.api.notify('success', `Clinically reviewed ${resultId}.`);
  }

  protected async simulateLabFeed(duplicate: boolean): Promise<void> {
    const msgId = duplicate ? 'PATH-MSG-2026-9001' : `PATH-MSG-${Date.now().toString().slice(-6)}`;
    const outcome = await this.api.ingestLabResult({
      externalMessageId: msgId,
      patientId: this.api.activePatientId(),
      rawPatientSummary: 'Synthetic Laboratory Feed',
      testName: 'Serum Creatinine',
      originalValue: '108',
      units: 'umol/L',
      referenceRange: '59 - 104',
      abnormalFlag: 'high',
      sourceLab: 'Pennine Acute Pathology Lab',
      specimenCollectedAt: new Date().toISOString(),
    });
    this.api.notify(
      outcome.deduplicated ? 'info' : 'success',
      outcome.deduplicated
        ? `Duplicate message ${msgId} safely deduplicated (no duplicate result created).`
        : `Ingested synthetic result ${outcome.result.id}.`,
    );
  }
}
