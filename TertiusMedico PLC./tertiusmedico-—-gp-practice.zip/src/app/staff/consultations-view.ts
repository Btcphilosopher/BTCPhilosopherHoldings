import {ChangeDetectionStrategy, Component, computed, effect, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {AppointmentMode, TerminologyConcept} from '../../shared/models';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-consultations-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (patient(); as p) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Clinical Consultation Workspace</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Draft → Reviewed → Signed (immutable) → Attributable Amendments
            </p>
          </div>
          <div class="flex items-center gap-2">
            @if (api.isClinician()) {
              <button
                type="button"
                (click)="startNewDraft()"
                class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087] transition-colors"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">note_add</mat-icon>
                New Consultation Draft
              </button>
            }
          </div>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <!-- Left Column: Patient-Centred Context Summary -->
          <div class="xl:col-span-4 space-y-4">
            <!-- Problems -->
            <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
              <div class="flex items-center justify-between">
                <h2 class="text-sm font-bold text-slate-900">Problems & Conditions</h2>
                <span class="text-xs text-slate-500 tabular-nums">{{ patientProblems().length }}</span>
              </div>
              @for (prb of patientProblems(); track prb.id) {
                <div class="text-xs border-b border-slate-100 pb-2 last:border-0 last:pb-0">
                  <div class="font-semibold text-slate-900">{{ prb.title }}</div>
                  <div class="text-slate-500">
                    {{ prb.status }} · Onset {{ prb.onsetDate }} · {{ prb.recordedBy }}
                  </div>
                </div>
              } @empty {
                <p class="text-xs text-slate-500">No coded problems recorded.</p>
              }
            </div>

            <!-- Active Medications -->
            <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
              <div class="flex items-center justify-between">
                <h2 class="text-sm font-bold text-slate-900">Medicines Summary</h2>
                <span class="text-xs text-slate-500 tabular-nums">{{ patientMeds().length }}</span>
              </div>
              @for (med of patientMeds(); track med.id) {
                <div class="text-xs border-b border-slate-100 pb-2 last:border-0 last:pb-0">
                  <div class="font-semibold text-slate-900">{{ med.drugName }}</div>
                  <div class="text-slate-600">{{ med.doseInstruction }}</div>
                  <div class="text-slate-500">
                    {{ med.isRepeat ? 'Repeat' : 'Acute' }} · Last issued {{ med.lastIssuedAt || '—' }}
                  </div>
                </div>
              } @empty {
                <p class="text-xs text-slate-500">No medicines recorded.</p>
              }
            </div>

            <!-- Observations -->
            <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
              <h2 class="text-sm font-bold text-slate-900">Recent Observations</h2>
              @for (obs of patientObservations(); track obs.id) {
                <div class="text-xs flex items-center justify-between border-b border-slate-100 pb-1.5 last:border-0">
                  <div>
                    <div class="font-medium text-slate-900">{{ obs.type }}</div>
                    <div class="text-slate-500">{{ obs.recordedBy }}</div>
                  </div>
                  <div class="font-mono font-semibold text-slate-900 tabular-nums">
                    {{ obs.value }} {{ obs.unit }}
                  </div>
                </div>
              } @empty {
                <p class="text-xs text-slate-500">No recent observations.</p>
              }

              @if (api.isClinician()) {
                <form [formGroup]="obsForm" (ngSubmit)="submitObservation()" class="pt-2 border-t border-slate-100 grid grid-cols-3 gap-2 text-xs">
                  <select formControlName="type" class="col-span-2 border border-slate-300 rounded px-2 py-1.5 bg-white">
                    <option value="Blood Pressure">Blood Pressure (mmHg)</option>
                    <option value="Heart Rate">Heart Rate (bpm)</option>
                    <option value="SpO2">SpO2 (%)</option>
                    <option value="Temperature">Temperature (C)</option>
                    <option value="Weight">Weight (kg)</option>
                  </select>
                  <input type="text" formControlName="value" placeholder="124/76" class="font-mono border border-slate-300 rounded px-2 py-1.5 bg-white" />
                  <button type="submit" class="col-span-3 py-1.5 font-medium bg-slate-100 border border-slate-300 rounded hover:bg-slate-200">
                    Record Observation
                  </button>
                </form>
              }
            </div>

            <!-- Recent Results & Correspondence -->
            <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
              <h2 class="text-sm font-bold text-slate-900">Recent Results & Letters</h2>
              @for (res of patientResults(); track res.id) {
                <div class="text-xs border-b border-slate-100 pb-1.5">
                  <span class="font-semibold text-slate-900">{{ res.testName }}</span>:
                  <span class="font-mono">{{ res.originalValue }} {{ res.units }}</span>
                  <div class="text-slate-500">Status: {{ res.status }}</div>
                </div>
              }
              @for (doc of patientDocs(); track doc.id) {
                <div class="text-xs border-b border-slate-100 pb-1.5 last:border-0">
                  <div class="font-semibold text-slate-900">{{ doc.title }}</div>
                  <div class="text-slate-500">{{ doc.senderOrganisation }} · {{ doc.status }}</div>
                </div>
              }
            </div>
          </div>

          <!-- Right Column: Consultation Timeline & Structured Editor -->
          <div class="xl:col-span-8 space-y-5">
            <!-- Interrupted Save Recovery Alert -->
            @if (interruptedDraftRecovery()) {
              <div class="bg-amber-50 border border-amber-300 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-amber-950">
                <div class="flex items-start gap-2">
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-amber-700 shrink-0">sync_problem</mat-icon>
                  <div>
                    <div class="font-bold">Save Interrupted — Local Draft Preserved</div>
                    <p class="mt-0.5">
                      The previous save attempt was interrupted. Your edits remain intact in the editor below.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  (click)="saveDraft(false)"
                  class="px-3 py-1.5 font-semibold bg-amber-800 text-white rounded-lg hover:bg-amber-900"
                >
                  Retry Save Now
                </button>
              </div>
            }

            <!-- Consultation Editor (Draft / New) -->
            @if (editingMode() === 'new' || editingMode() === 'draft') {
              <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <h2 class="text-base font-bold text-slate-900">
                      @if (selectedConsultation(); as con) {
                        Editing {{ con.id }} ({{ con.status }} · v{{ con.version }})
                      } @else {
                        New Consultation Draft for {{ p.firstName }} {{ p.lastName }} ({{ p.internalId }})
                      }
                    </h2>
                    <p class="text-xs text-slate-500">
                      Author: {{ api.currentUser()?.name }} ({{ api.currentUser()?.role }}) · Locked to {{ p.internalId }}
                    </p>
                  </div>
                  @if (!api.isClinician()) {
                    <span class="text-xs font-semibold text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded">
                      Read-only for non-clinical role
                    </span>
                  }
                </div>

                <form [formGroup]="noteForm" class="space-y-3 text-xs">
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label class="block text-slate-700">
                      <span>Presenting Complaint (Required to sign)</span>
                      <input
                        type="text"
                        formControlName="presentingComplaint"
                        class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"
                      />
                    </label>
                    <label class="block text-slate-700">
                      <span>Consultation Mode</span>
                      <select formControlName="mode" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                        <option value="in_person">In-person</option>
                        <option value="telephone">Telephone</option>
                        <option value="video">Video</option>
                      </select>
                    </label>
                  </div>

                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label class="block text-slate-700">
                      <span>History</span>
                      <textarea rows="3" formControlName="history" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"></textarea>
                    </label>
                    <label class="block text-slate-700">
                      <span>Examination / Vitals</span>
                      <textarea rows="3" formControlName="examination" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"></textarea>
                    </label>
                  </div>

                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label class="block text-slate-700">
                      <span>Clinical Assessment (Required to sign)</span>
                      <textarea rows="3" formControlName="assessment" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"></textarea>
                    </label>
                    <label class="block text-slate-700">
                      <span>Agreed Plan & Safety Netting</span>
                      <textarea rows="3" formControlName="plan" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"></textarea>
                    </label>
                  </div>

                  <label class="block text-slate-700">
                    <span>Free-Text Clinical Notes</span>
                    <textarea rows="2" formControlName="freeText" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"></textarea>
                  </label>

                  <!-- Replaceable Terminology Adapter Lookup -->
                  <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                      <span class="font-semibold text-slate-800">
                        Prototype Terminology Adapter (Unvalidated Demo Reference)
                      </span>
                      <div class="flex items-center gap-1.5">
                        <input
                          type="text"
                          [formControl]="termSearchControl"
                          placeholder="Search SNOMED / dm+d demo..."
                          class="border border-slate-300 rounded px-2 py-1 bg-white text-xs"
                        />
                        <button
                          type="button"
                          (click)="searchTerms()"
                          class="px-2.5 py-1 bg-white border border-slate-300 rounded font-medium hover:bg-slate-100"
                        >
                          Search
                        </button>
                      </div>
                    </div>
                    @if (termResults().length > 0) {
                      <div class="flex flex-wrap gap-1.5">
                        @for (concept of termResults(); track concept.code) {
                          <button
                            type="button"
                            (click)="attachConcept(concept)"
                            class="px-2 py-1 bg-white border border-slate-300 rounded text-[11px] hover:border-[#005EB8]"
                          >
                            + {{ concept.term }} [{{ concept.code }}]
                          </button>
                        }
                      </div>
                    }
                    @if (selectedConcepts().length > 0) {
                      <div class="text-[11px] text-slate-700">
                        Attached:
                        @for (c of selectedConcepts(); track c.code) {
                          <span class="mr-2 font-mono">{{ c.code }} ({{ c.term }})</span>
                        }
                      </div>
                    }
                  </div>

                  @if (api.isClinician()) {
                    <div class="pt-2 flex flex-wrap items-center justify-between gap-3">
                      <div class="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          (click)="saveDraft(false)"
                          class="inline-flex items-center gap-1.5 px-4 py-2 font-semibold bg-white border border-slate-300 text-slate-800 rounded-lg hover:bg-slate-50"
                        >
                          <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">save</mat-icon>
                          Save Draft
                        </button>
                        @if (selectedConsultation()) {
                          <button
                            type="button"
                            (click)="saveDraft(true)"
                            class="inline-flex items-center gap-1.5 px-3 py-2 font-medium bg-amber-50 border border-amber-300 text-amber-900 rounded-lg hover:bg-amber-100"
                          >
                            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">wifi_off</mat-icon>
                            Simulate Interrupted Save
                          </button>
                        }
                      </div>

                      <button
                        type="button"
                        (click)="signActiveNote()"
                        class="inline-flex items-center gap-1.5 px-4 py-2 font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                      >
                        <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">verified</mat-icon>
                        Sign & Lock Consultation
                      </button>
                    </div>
                  }
                </form>
              </div>
            }

            <!-- Consultation Timeline (Signed / Draft / Amended) -->
            <div class="space-y-4">
              <h2 class="text-base font-bold text-slate-900">
                Consultation Record History ({{ patientConsultations().length }})
              </h2>

              @for (con of patientConsultations(); track con.id) {
                <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                  <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                    <div>
                      <div class="flex flex-wrap items-center gap-2">
                        <span class="text-sm font-bold text-slate-900">{{ con.presentingComplaint }}</span>
                        <span
                          class="text-xs font-semibold px-2 py-0.5 rounded border"
                          [class.bg-emerald-50]="con.status === 'Signed' || con.status === 'Amended'"
                          [class.text-emerald-800]="con.status === 'Signed' || con.status === 'Amended'"
                          [class.border-emerald-200]="con.status === 'Signed' || con.status === 'Amended'"
                          [class.bg-amber-50]="con.status === 'Draft' || con.status === 'Reviewed'"
                          [class.text-amber-900]="con.status === 'Draft' || con.status === 'Reviewed'"
                          [class.border-amber-200]="con.status === 'Draft' || con.status === 'Reviewed'"
                        >
                          {{ con.status }}
                        </span>
                      </div>
                      <div class="text-xs text-slate-500 mt-1">
                        Author: {{ con.authorName }} ({{ con.authorRole }}) · Encounter: {{ con.encounterTime }} ·
                        Provenance: {{ con.provenance }}
                      </div>
                    </div>

                    @if (con.status === 'Draft' || con.status === 'Reviewed') {
                      <button
                        type="button"
                        (click)="loadDraftIntoEditor(con.id)"
                        class="px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                      >
                        Resume Draft
                      </button>
                    }
                  </div>

                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-700">
                    <div><strong class="text-slate-900">History:</strong> {{ con.history || '—' }}</div>
                    <div><strong class="text-slate-900">Examination:</strong> {{ con.examination || '—' }}</div>
                    <div><strong class="text-slate-900">Assessment:</strong> {{ con.assessment || '—' }}</div>
                    <div><strong class="text-slate-900">Plan:</strong> {{ con.plan || '—' }}</div>
                  </div>
                  @if (con.freeText) {
                    <div class="text-xs text-slate-700"><strong class="text-slate-900">Notes:</strong> {{ con.freeText }}</div>
                  }

                  @if (con.contentHash) {
                    <div class="text-[11px] font-mono text-slate-500">
                      Signed by {{ con.signedBy }} at {{ con.signedAt }} · Immutable SHA-256: {{ con.contentHash.slice(0, 20) }}...
                    </div>
                  }

                  <!-- Attributable Linked Amendments -->
                  @if (con.amendments.length > 0) {
                    <div class="pt-3 border-t border-slate-100 space-y-2">
                      <div class="text-xs font-bold text-slate-800">Linked Attributable Amendments</div>
                      @for (amd of con.amendments; track amd.id) {
                        <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                          <div class="font-semibold text-slate-900">
                            {{ amd.authorName }} ({{ amd.authorRole }}) · {{ amd.recordedAt }}
                          </div>
                          <div class="text-slate-600">Reason: {{ amd.reason }}</div>
                          <div class="text-slate-900">{{ amd.amendmentText }}</div>
                        </div>
                      }
                    </div>
                  }

                  <!-- Append Amendment Control for Signed Notes -->
                  @if ((con.status === 'Signed' || con.status === 'Amended') && api.isClinician()) {
                    @if (amendTargetId() === con.id) {
                      <form [formGroup]="amendForm" (ngSubmit)="submitAmendment(con.id)" class="pt-3 border-t border-slate-100 space-y-2 text-xs">
                        <input
                          type="text"
                          formControlName="reason"
                          placeholder="Reason for clinical amendment (original signed note remains intact)"
                          class="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"
                        />
                        <textarea
                          rows="2"
                          formControlName="amendmentText"
                          placeholder="Amendment text..."
                          class="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"
                        ></textarea>
                        <div class="flex items-center gap-2">
                          <button type="submit" class="px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg">
                            Append Amendment
                          </button>
                          <button type="button" (click)="amendTargetId.set(null)" class="px-3 py-1.5 bg-white border border-slate-300 rounded-lg">
                            Cancel
                          </button>
                        </div>
                      </form>
                    } @else {
                      <div class="pt-2">
                        <button
                          type="button"
                          (click)="amendTargetId.set(con.id)"
                          class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                        >
                          <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">edit_note</mat-icon>
                          Append Attributable Amendment
                        </button>
                      </div>
                    }
                  }
                </article>
              } @empty {
                <div class="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
                  No consultations recorded yet for this patient.
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class ConsultationsView {
  protected readonly api = inject(PracticeApi);
  protected readonly patient = this.api.activePatient;
  protected readonly editingMode = signal<'new' | 'draft' | 'none'>('new');
  protected readonly interruptedDraftRecovery = signal(false);
  protected readonly amendTargetId = signal<string | null>(null);
  protected readonly termResults = signal<TerminologyConcept[]>([]);
  protected readonly selectedConcepts = signal<TerminologyConcept[]>([]);

  protected readonly termSearchControl = new FormControl('', {nonNullable: true});

  protected readonly noteForm = new FormGroup({
    presentingComplaint: new FormControl('', {nonNullable: true}),
    mode: new FormControl<AppointmentMode>('in_person', {nonNullable: true}),
    history: new FormControl('', {nonNullable: true}),
    examination: new FormControl('', {nonNullable: true}),
    assessment: new FormControl('', {nonNullable: true}),
    plan: new FormControl('', {nonNullable: true}),
    freeText: new FormControl('', {nonNullable: true}),
  });

  protected readonly obsForm = new FormGroup({
    type: new FormControl<'Blood Pressure' | 'Heart Rate' | 'Temperature' | 'SpO2' | 'Weight'>(
      'Blood Pressure',
      {nonNullable: true},
    ),
    value: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly amendForm = new FormGroup({
    reason: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
    amendmentText: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly patientProblems = computed(() =>
    (this.api.workspace()?.problems ?? []).filter(
      (x) => x.patientId === this.api.activePatientId(),
    ),
  );
  protected readonly patientMeds = computed(() =>
    (this.api.workspace()?.medications ?? []).filter(
      (x) => x.patientId === this.api.activePatientId(),
    ),
  );
  protected readonly patientObservations = computed(() =>
    (this.api.workspace()?.observations ?? []).filter(
      (x) => x.patientId === this.api.activePatientId(),
    ),
  );
  protected readonly patientResults = computed(() =>
    (this.api.workspace()?.labResults ?? []).filter(
      (x) => x.patientId === this.api.activePatientId(),
    ),
  );
  protected readonly patientDocs = computed(() =>
    (this.api.workspace()?.documents ?? []).filter(
      (x) => x.patientId === this.api.activePatientId(),
    ),
  );
  protected readonly patientConsultations = computed(() =>
    (this.api.workspace()?.consultations ?? []).filter(
      (x) => x.patientId === this.api.activePatientId(),
    ),
  );
  protected readonly selectedConsultation = computed(() => {
    const cid = this.api.activeConsultationId();
    return this.patientConsultations().find((c) => c.id === cid) ?? null;
  });

  constructor() {
    this.noteForm.valueChanges.subscribe(() => {
      if (this.noteForm.dirty) {
        this.api.hasUnsavedClinicalChanges.set(true);
      }
    });

    effect(() => {
      // When patient changes cleanly, reset editor form
      this.api.activePatientId();
      if (!this.api.hasUnsavedClinicalChanges()) {
        this.noteForm.reset({
          presentingComplaint: '',
          mode: 'in_person',
          history: '',
          examination: '',
          assessment: '',
          plan: '',
          freeText: '',
        });
        this.selectedConcepts.set([]);
        this.interruptedDraftRecovery.set(false);
        this.editingMode.set('new');
      }
    });
  }

  protected startNewDraft(): void {
    this.api.activeConsultationId.set(null);
    this.noteForm.reset({
      presentingComplaint: '',
      mode: 'in_person',
      history: '',
      examination: '',
      assessment: '',
      plan: '',
      freeText: '',
    });
    this.selectedConcepts.set([]);
    this.api.hasUnsavedClinicalChanges.set(false);
    this.editingMode.set('new');
  }

  protected loadDraftIntoEditor(consultationId: string): void {
    const con = this.patientConsultations().find((c) => c.id === consultationId);
    if (!con) return;
    this.api.activeConsultationId.set(con.id);
    this.noteForm.patchValue({
      presentingComplaint: con.presentingComplaint,
      mode: con.mode,
      history: con.history,
      examination: con.examination,
      assessment: con.assessment,
      plan: con.plan,
      freeText: con.freeText,
    });
    this.noteForm.markAsPristine();
    this.selectedConcepts.set(con.codedConcepts);
    this.api.hasUnsavedClinicalChanges.set(false);
    this.editingMode.set('draft');
  }

  protected async searchTerms(): Promise<void> {
    const concepts = await this.api.searchTerminology(this.termSearchControl.value);
    this.termResults.set(concepts);
  }

  protected attachConcept(concept: TerminologyConcept): void {
    const existing = this.selectedConcepts();
    if (!existing.some((c) => c.code === concept.code)) {
      this.selectedConcepts.set([...existing, concept]);
      this.api.hasUnsavedClinicalChanges.set(true);
    }
  }

  protected async saveDraft(simulateFailure: boolean): Promise<void> {
    const pid = this.api.activePatientId();
    const v = this.noteForm.getRawValue();
    try {
      const activeId = this.api.activeConsultationId();
      if (!activeId) {
        const created = await this.api.createConsultationDraft({
          patientId: pid,
          expectedPatientId: pid,
          siteId: this.patient()?.registeredSiteId ?? 'SITE-MILLBROOK',
          mode: v.mode,
          presentingComplaint: v.presentingComplaint || 'Consultation draft',
          history: v.history,
          examination: v.examination,
          assessment: v.assessment,
          plan: v.plan,
          freeText: v.freeText,
          codedConcepts: this.selectedConcepts(),
        });
        this.editingMode.set('draft');
        this.noteForm.markAsPristine();
        this.interruptedDraftRecovery.set(false);
        this.api.notify('success', `Saved draft ${created.id}.`);
      } else {
        await this.api.saveConsultationDraft(activeId, {
          expectedPatientId: pid,
          presentingComplaint: v.presentingComplaint,
          history: v.history,
          examination: v.examination,
          assessment: v.assessment,
          plan: v.plan,
          freeText: v.freeText,
          codedConcepts: this.selectedConcepts(),
          simulateFailure,
        });
        this.noteForm.markAsPristine();
        this.interruptedDraftRecovery.set(false);
        this.api.notify('success', `Saved draft ${activeId}.`);
      }
    } catch (err) {
      if (simulateFailure) {
        this.interruptedDraftRecovery.set(true);
      }
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async signActiveNote(): Promise<void> {
    const pid = this.api.activePatientId();
    const v = this.noteForm.getRawValue();
    try {
      let id = this.api.activeConsultationId();
      if (!id) {
        const created = await this.api.createConsultationDraft({
          patientId: pid,
          expectedPatientId: pid,
          siteId: this.patient()?.registeredSiteId ?? 'SITE-MILLBROOK',
          mode: v.mode,
          presentingComplaint: v.presentingComplaint,
          history: v.history,
          examination: v.examination,
          assessment: v.assessment,
          plan: v.plan,
          freeText: v.freeText,
          codedConcepts: this.selectedConcepts(),
        });
        id = created.id;
      } else {
        await this.api.saveConsultationDraft(id, {
          expectedPatientId: pid,
          presentingComplaint: v.presentingComplaint,
          history: v.history,
          examination: v.examination,
          assessment: v.assessment,
          plan: v.plan,
          freeText: v.freeText,
          codedConcepts: this.selectedConcepts(),
        });
      }
      await this.api.signConsultation(id, pid);
      this.startNewDraft();
      this.api.notify('success', `Signed and locked consultation ${id}.`);
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async submitAmendment(consultationId: string): Promise<void> {
    if (this.amendForm.invalid) return;
    const {reason, amendmentText} = this.amendForm.getRawValue();
    try {
      await this.api.amendConsultation(
        consultationId,
        this.api.activePatientId(),
        reason,
        amendmentText,
      );
      this.amendForm.reset({reason: '', amendmentText: ''});
      this.amendTargetId.set(null);
      this.api.notify('success', `Appended attributable amendment to ${consultationId}.`);
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async submitObservation(): Promise<void> {
    if (this.obsForm.invalid) return;
    const {type, value} = this.obsForm.getRawValue();
    const unitMap: Record<string, string> = {
      'Blood Pressure': 'mmHg',
      'Heart Rate': 'bpm',
      SpO2: '%',
      Temperature: 'C',
      Weight: 'kg',
    };
    try {
      await this.api.addObservation(this.api.activePatientId(), {
        type,
        value,
        unit: unitMap[type] ?? '',
        siteName: 'Millbrook Surgery (Main)',
      });
      this.obsForm.patchValue({value: ''});
      this.api.notify('success', 'Recorded observation.');
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  private extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as {error?: {error?: string}}).error;
      if (inner?.error) return inner.error;
    }
    return 'Clinical action failed.';
  }
}
