import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-documents-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Incoming Correspondence & Documents</h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Uncertain documents are held outside patient records · OCR extraction requires clinician review before filing
          </p>
        </div>

        <div class="space-y-4">
          @for (doc of data.documents; track doc.id) {
            <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs">
              <div class="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <div class="flex flex-wrap items-center gap-2">
                    <span class="font-mono text-slate-500">{{ doc.id }}</span>
                    <h2 class="text-base font-bold text-slate-900">{{ doc.title }}</h2>
                  </div>
                  <div class="text-slate-600 mt-0.5">
                    From: {{ doc.senderOrganisation }} · Type: {{ doc.documentType }} · Received: {{ doc.receivedAt }}
                  </div>
                </div>

                <div class="text-right space-y-1">
                  <span class="font-semibold px-2.5 py-1 rounded border border-slate-200 bg-slate-50">
                    {{ doc.status }}
                  </span>
                  <div class="text-slate-600">
                    @if (doc.matchStatus === 'matched') {
                      Patient: {{ patientName(doc.patientId!) }}
                    } @else {
                      <span class="text-amber-800 font-semibold">Uncertain Match — Hold</span>
                    }
                  </div>
                </div>
              </div>

              <!-- OCR Extraction with Provenance -->
              <div class="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <span class="font-bold text-slate-900">
                    OCR Extracted Preview ({{ doc.ocrProvenance.engine }} · {{ doc.ocrProvenance.confidencePercent }}% confidence)
                  </span>
                  <span class="text-slate-600">
                    Entered authoritative record:
                    <strong>{{ doc.ocrProvenance.enteredAuthoritativeRecord ? 'Yes' : 'No (Awaiting review)' }}</strong>
                  </span>
                </div>
                <p class="text-slate-800 leading-relaxed">{{ doc.ocrExtractedText }}</p>
              </div>

              @if (doc.matchStatus !== 'matched') {
                <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div class="font-bold text-amber-950">Manual Patient Matching Required</div>
                    <div>Document label: {{ doc.rawPatientLabel }} (not automatically filed)</div>
                  </div>
                  <form [formGroup]="matchForm" (ngSubmit)="matchDoc(doc.id)" class="flex items-center gap-2">
                    <select formControlName="patientId" class="border border-slate-300 rounded px-2.5 py-1.5 bg-white">
                      @for (p of data.patients; track p.internalId) {
                        <option [value]="p.internalId">{{ p.lastName }}, {{ p.firstName }} ({{ p.internalId }})</option>
                      }
                    </select>
                    <button type="submit" class="px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg">
                      Match Patient
                    </button>
                  </form>
                </div>
              } @else if (doc.status !== 'filed' && api.isClinician()) {
                @if (reviewingId() === doc.id) {
                  <form [formGroup]="reviewForm" (ngSubmit)="reviewDoc(doc.id)" class="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2.5">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <label class="block text-slate-700">
                        <span>Classification</span>
                        <input type="text" formControlName="classification" class="mt-1 w-full border border-slate-300 rounded px-2.5 py-1.5 bg-white" />
                      </label>
                      <label class="block text-slate-700">
                        <span>Follow-Up Task Title (Optional)</span>
                        <input type="text" formControlName="assignTaskTitle" placeholder="e.g. Action medication change" class="mt-1 w-full border border-slate-300 rounded px-2.5 py-1.5 bg-white" />
                      </label>
                    </div>
                    <div class="flex flex-wrap items-center gap-4">
                      <label class="flex items-center gap-1.5">
                        <input type="checkbox" formControlName="fileIntoRecord" />
                        <span>Approve & file into authoritative clinical record</span>
                      </label>
                      <label class="flex items-center gap-1.5">
                        <input type="checkbox" formControlName="visibleToPatient" />
                        <span>Release summary to Patient Portal</span>
                      </label>
                    </div>
                    <div class="flex gap-2">
                      <button type="submit" class="px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg">
                        Confirm Clinician Review
                      </button>
                      <button type="button" (click)="reviewingId.set(null)" class="px-3 py-1.5 bg-white border border-slate-300 rounded-lg">
                        Cancel
                      </button>
                    </div>
                  </form>
                } @else {
                  <button
                    type="button"
                    (click)="openReview(doc.id, doc.classification)"
                    class="inline-flex items-center gap-1 px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                  >
                    <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">assignment_turned_in</mat-icon>
                    Clinician Review & File
                  </button>
                }
              } @else if (doc.reviewedBy) {
                <div class="text-emerald-800 font-medium">
                  Reviewed & filed by {{ doc.reviewedBy }} at {{ doc.reviewedAt }} · Portal visible: {{ doc.visibleToPatient ? 'Yes' : 'No' }}
                </div>
              }
            </article>
          }
        </div>
      </div>
    }
  `,
})
export class DocumentsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly reviewingId = signal<string | null>(null);

  protected readonly matchForm = new FormGroup({
    patientId: new FormControl('PT-1002', {nonNullable: true}),
  });

  protected readonly reviewForm = new FormGroup({
    classification: new FormControl('', {nonNullable: true}),
    fileIntoRecord: new FormControl(true, {nonNullable: true}),
    visibleToPatient: new FormControl(true, {nonNullable: true}),
    assignTaskTitle: new FormControl('', {nonNullable: true}),
  });

  protected patientName(id: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === id);
    return p ? `${p.firstName} ${p.lastName} (${id})` : id;
  }

  protected async matchDoc(docId: string): Promise<void> {
    const {patientId} = this.matchForm.getRawValue();
    await this.api.matchDocument(docId, patientId);
    this.api.notify('success', `Matched document ${docId} to ${patientId}.`);
  }

  protected openReview(docId: string, classification: string): void {
    this.reviewingId.set(docId);
    this.reviewForm.patchValue({
      classification,
      fileIntoRecord: true,
      visibleToPatient: true,
      assignTaskTitle: '',
    });
  }

  protected async reviewDoc(docId: string): Promise<void> {
    const v = this.reviewForm.getRawValue();
    await this.api.reviewDocument(docId, v);
    this.reviewingId.set(null);
    this.api.notify('success', `Document ${docId} reviewed and processed.`);
  }
}
