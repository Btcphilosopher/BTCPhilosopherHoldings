import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {ClinicalUrgency} from '../../shared/models';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-requests-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Reception & Patient Requests</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Patient's own description preserved verbatim · Clinical urgency restricted to authorised clinicians
            </p>
          </div>
          <div class="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1 text-xs">
            <button
              type="button"
              (click)="filterMode.set('all')"
              class="px-3 py-1.5 rounded-md font-medium"
              [class.bg-[#005EB8]]="filterMode() === 'all'"
              [class.text-white]="filterMode() === 'all'"
            >
              All ({{ data.requests.length }})
            </button>
            <button
              type="button"
              (click)="filterMode.set('clinician')"
              class="px-3 py-1.5 rounded-md font-medium"
              [class.bg-[#005EB8]]="filterMode() === 'clinician'"
              [class.text-white]="filterMode() === 'clinician'"
            >
              Awaiting Clinician Review
            </button>
          </div>
        </div>

        <div class="space-y-4">
          @for (req of filteredRequests(); track req.id) {
            <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div class="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <div class="flex flex-wrap items-center gap-2">
                    <span class="font-mono text-xs font-semibold text-slate-500">{{ req.id }}</span>
                    <span class="text-base font-bold text-slate-900">{{ patientName(req.patientId) }}</span>
                    <span class="text-xs font-mono text-slate-500">{{ req.patientId }}</span>
                    @if (req.submittedViaProxy) {
                      <span class="text-xs font-medium text-[#005EB8]">Submitted via Verified Proxy</span>
                    }
                  </div>
                  <div class="text-xs text-slate-600 mt-0.5">
                    Category: {{ req.category }} · {{ req.routingRuleApplied }}
                  </div>
                </div>

                <div class="flex flex-wrap items-center gap-2 text-xs">
                  <span class="font-medium px-2.5 py-1 rounded border border-slate-200 bg-slate-50 text-slate-800">
                    Status: {{ req.status }}
                  </span>
                  <span
                    class="font-semibold px-2.5 py-1 rounded border"
                    [class.bg-red-50]="req.clinicalUrgency === 'urgent_today'"
                    [class.text-red-800]="req.clinicalUrgency === 'urgent_today'"
                    [class.border-red-200]="req.clinicalUrgency === 'urgent_today'"
                    [class.bg-amber-50]="req.clinicalUrgency === 'unassigned'"
                    [class.text-amber-900]="req.clinicalUrgency === 'unassigned'"
                    [class.border-amber-200]="req.clinicalUrgency === 'unassigned'"
                    [class.bg-emerald-50]="req.clinicalUrgency === 'routine' || req.clinicalUrgency === 'soon'"
                    [class.text-emerald-800]="req.clinicalUrgency === 'routine' || req.clinicalUrgency === 'soon'"
                    [class.border-emerald-200]="req.clinicalUrgency === 'routine' || req.clinicalUrgency === 'soon'"
                  >
                    Urgency: {{ req.clinicalUrgency }}
                  </span>
                </div>
              </div>

              <!-- Strict Separation: Patient's Own Words vs Staff Summary vs Clinical Triage -->
              <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
                <div class="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <div class="font-bold text-slate-900">Patient's Own Description (Immutable)</div>
                  <p class="text-slate-700 leading-relaxed">{{ req.patientDescription }}</p>
                </div>

                <div class="p-3.5 bg-white border border-slate-200 rounded-lg space-y-2">
                  <div class="font-bold text-slate-900">Reception / Admin Summary</div>
                  <p class="text-slate-700">{{ req.staffSummary || 'No staff summary added yet.' }}</p>
                  @if (selectedAdminId() === req.id) {
                    <form [formGroup]="adminForm" (ngSubmit)="saveAdmin(req.id)" class="space-y-2 pt-2 border-t border-slate-100">
                      <textarea rows="2" formControlName="staffSummary" placeholder="Enter administrative summary..." class="w-full border border-slate-300 rounded px-2 py-1.5 bg-white"></textarea>
                      <label class="flex items-center gap-1.5 text-slate-700">
                        <input type="checkbox" formControlName="routeToClinician" />
                        <span>Route to Clinician Triage Queue</span>
                      </label>
                      <div class="flex items-center gap-2">
                        <button type="submit" class="px-2.5 py-1 bg-[#005EB8] text-white rounded font-medium">Save Summary</button>
                        <button type="button" (click)="selectedAdminId.set(null)" class="px-2.5 py-1 bg-white border border-slate-300 rounded">Cancel</button>
                      </div>
                    </form>
                  } @else {
                    <div class="flex flex-wrap gap-2 pt-1">
                      <button
                        type="button"
                        (click)="openAdminForm(req.id, req.staffSummary)"
                        class="px-2.5 py-1 bg-white border border-slate-300 rounded font-medium hover:bg-slate-50"
                      >
                        Update Admin Summary
                      </button>
                      <button
                        type="button"
                        (click)="bookFromRequest(req.patientId)"
                        class="px-2.5 py-1 bg-white border border-slate-300 rounded font-medium hover:bg-slate-50"
                      >
                        Offer Appointment
                      </button>
                    </div>
                  }
                </div>

                <div class="p-3.5 bg-white border border-slate-200 rounded-lg space-y-2">
                  <div class="font-bold text-slate-900">Authorised Clinical Triage</div>
                  @if (req.urgencyAssignedBy) {
                    <div class="text-slate-700">
                      Assigned <strong>{{ req.clinicalUrgency }}</strong> by {{ req.urgencyAssignedBy }} ({{ req.urgencyAssignedRole }})
                    </div>
                    <div class="text-slate-600">{{ req.clinicalRationale }}</div>
                  } @else {
                    <div class="text-amber-800">Awaiting clinician urgency assessment.</div>
                  }

                  @if (api.isClinician()) {
                    @if (selectedTriageId() === req.id) {
                      <form [formGroup]="triageForm" (ngSubmit)="saveUrgency(req.id)" class="space-y-2 pt-2 border-t border-slate-100">
                        <select formControlName="clinicalUrgency" class="w-full border border-slate-300 rounded px-2 py-1.5 bg-white">
                          <option value="routine">Routine</option>
                          <option value="soon">Soon (48–72 hours)</option>
                          <option value="urgent_today">Urgent Today</option>
                        </select>
                        <input type="text" formControlName="clinicalRationale" placeholder="Clinical rationale (required)" class="w-full border border-slate-300 rounded px-2 py-1.5 bg-white" />
                        <div class="flex items-center gap-2">
                          <button type="submit" class="px-2.5 py-1 bg-[#005EB8] text-white rounded font-medium">Assign Urgency</button>
                          <button type="button" (click)="selectedTriageId.set(null)" class="px-2.5 py-1 bg-white border border-slate-300 rounded">Cancel</button>
                        </div>
                      </form>
                    } @else {
                      <button
                        type="button"
                        (click)="selectedTriageId.set(req.id)"
                        class="inline-flex items-center gap-1 px-2.5 py-1 bg-[#005EB8] text-white rounded font-medium hover:bg-[#003087]"
                      >
                        <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">medical_services</mat-icon>
                        Assign Clinical Urgency
                      </button>
                    }
                  } @else {
                    <div class="text-[11px] text-slate-500">
                      Clinical urgency locked: requires GP, Nurse, or Pharmacist sign-in.
                    </div>
                  }
                </div>
              </div>
            </article>
          }
        </div>
      </div>
    }
  `,
})
export class RequestsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly filterMode = signal<'all' | 'clinician'>('all');
  protected readonly selectedAdminId = signal<string | null>(null);
  protected readonly selectedTriageId = signal<string | null>(null);

  protected readonly adminForm = new FormGroup({
    staffSummary: new FormControl('', {nonNullable: true}),
    routeToClinician: new FormControl(true, {nonNullable: true}),
  });

  protected readonly triageForm = new FormGroup({
    clinicalUrgency: new FormControl<ClinicalUrgency>('urgent_today', {nonNullable: true}),
    clinicalRationale: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly filteredRequests = computed(() => {
    const all = this.ws()?.requests ?? [];
    return this.filterMode() === 'clinician'
      ? all.filter((r) => r.status === 'awaiting_clinician_review')
      : all;
  });

  protected patientName(id: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === id);
    return p ? `${p.firstName} ${p.lastName}` : id;
  }

  protected openAdminForm(reqId: string, existingSummary: string): void {
    this.selectedAdminId.set(reqId);
    this.adminForm.patchValue({staffSummary: existingSummary, routeToClinician: true});
  }

  protected async saveAdmin(reqId: string): Promise<void> {
    const {staffSummary, routeToClinician} = this.adminForm.getRawValue();
    await this.api.updateRequestAdmin(reqId, staffSummary, routeToClinician);
    this.selectedAdminId.set(null);
    this.api.notify('success', `Updated request ${reqId}.`);
  }

  protected async saveUrgency(reqId: string): Promise<void> {
    if (this.triageForm.invalid) return;
    const {clinicalUrgency, clinicalRationale} = this.triageForm.getRawValue();
    await this.api.assignRequestUrgency(reqId, clinicalUrgency, clinicalRationale);
    this.triageForm.patchValue({clinicalRationale: ''});
    this.selectedTriageId.set(null);
    this.api.notify('success', `Assigned clinical urgency (${clinicalUrgency}) for ${reqId}.`);
  }

  protected bookFromRequest(patientId: string): void {
    if (this.api.requestPatientSwitch(patientId)) {
      this.api.staffSection.set('appointments');
    }
  }
}
