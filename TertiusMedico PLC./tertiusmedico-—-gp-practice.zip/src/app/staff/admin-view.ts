import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-admin-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Administration, Governance & Audit</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Locations, rooms, roles, audit search, integration boundaries, hazard log, and capability status
            </p>
          </div>
          <button
            type="button"
            (click)="api.resetDemo()"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-white border border-slate-300 text-slate-800 rounded-lg hover:bg-slate-50"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">restart_alt</mat-icon>
            Reset Synthetic Demo Data
          </button>
        </div>

        <!-- Sub-navigation Tabs -->
        <div class="flex flex-wrap items-center gap-1 bg-white border border-slate-200 rounded-xl p-1 text-xs">
          @for (t of tabs; track t.id) {
            <button
              type="button"
              (click)="activeTab.set(t.id)"
              class="px-3.5 py-2 rounded-lg font-medium transition-colors whitespace-nowrap"
              [class.bg-[#005EB8]]="activeTab() === t.id"
              [class.text-white]="activeTab() === t.id"
              [class.text-slate-700]="activeTab() !== t.id"
            >
              {{ t.label }}
            </button>
          }
        </div>

        @switch (activeTab()) {
          @case ('audit') {
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-3">
                <h2 class="text-base font-bold text-slate-900">Immutable-Style Audit Trail</h2>
                <input
                  type="text"
                  [formControl]="auditSearch"
                  placeholder="Filter actor, action, patient ID, outcome..."
                  class="border border-slate-300 rounded-lg px-3 py-1.5 text-xs w-72 bg-white"
                />
              </div>

              <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr class="bg-slate-50 border-b border-slate-200 text-slate-600">
                      <th class="px-3 py-2.5 font-semibold">Timestamp</th>
                      <th class="px-3 py-2.5 font-semibold">Actor & Role</th>
                      <th class="px-3 py-2.5 font-semibold">Action</th>
                      <th class="px-3 py-2.5 font-semibold">Patient</th>
                      <th class="px-3 py-2.5 font-semibold">Outcome</th>
                      <th class="px-3 py-2.5 font-semibold">Summary</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100">
                    @for (ev of filteredAudit(); track ev.id) {
                      <tr>
                        <td class="px-3 py-2.5 font-mono text-slate-500 whitespace-nowrap tabular-nums">{{ ev.timestamp }}</td>
                        <td class="px-3 py-2.5 whitespace-nowrap">{{ ev.actorName }} ({{ ev.actorRole }})</td>
                        <td class="px-3 py-2.5 font-mono font-semibold text-slate-800">{{ ev.action }}</td>
                        <td class="px-3 py-2.5 font-mono">{{ ev.patientId || '—' }}</td>
                        <td class="px-3 py-2.5 font-semibold" [class.text-red-700]="ev.outcome === 'denied' || ev.outcome === 'failed'" [class.text-emerald-700]="ev.outcome === 'success'">
                          {{ ev.outcome }}
                        </td>
                        <td class="px-3 py-2.5 text-slate-700">{{ ev.summary }}</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>
          }

          @case ('sites') {
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                <h2 class="text-base font-bold text-slate-900">Practice Locations & Rooms</h2>
                @for (site of data.sites; track site.id) {
                  <div class="p-3.5 border border-slate-200 rounded-lg text-xs space-y-1">
                    <div class="font-bold text-slate-900">{{ site.name }} ({{ site.odsCode }})</div>
                    <div class="text-slate-600">{{ site.address }}, {{ site.postcode }} · Tel: {{ site.phone }}</div>
                    <div class="text-slate-500">Cross-site clinician travel buffer: {{ site.travelBufferMinutesFromOtherSite }} mins</div>
                  </div>
                }
                <div class="pt-2 space-y-2">
                  <div class="text-xs font-bold text-slate-800">Clinical Rooms & Equipment</div>
                  @for (rm of data.rooms; track rm.id) {
                    <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs flex justify-between gap-2">
                      <div>
                        <span class="font-semibold text-slate-900">{{ rm.name }}</span>
                        <span class="text-slate-500"> · {{ rm.floor }} · {{ rm.stepFreeAccess ? 'Step-free' : 'Stairs' }}</span>
                      </div>
                      <span class="text-slate-600">{{ rm.equipment.join(', ') }}</span>
                    </div>
                  }
                </div>
              </div>

              <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                <h2 class="text-base font-bold text-slate-900">Staff Roles & Configuration History</h2>
                @for (staff of data.staffUsers; track staff.id) {
                  <div class="p-2.5 border border-slate-200 rounded-lg text-xs flex justify-between">
                    <span class="font-semibold text-slate-900">{{ staff.name }}</span>
                    <span class="font-mono text-[#005EB8]">{{ staff.role }}</span>
                  </div>
                }
                <div class="pt-2 space-y-2">
                  <div class="text-xs font-bold text-slate-800">Configuration History</div>
                  @for (cfg of data.configurationHistory; track cfg.id) {
                    <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                      <div class="font-mono text-slate-500">{{ cfg.timestamp }} · {{ cfg.changedBy }}</div>
                      <div class="text-slate-800 mt-0.5">{{ cfg.summary }}</div>
                    </div>
                  }
                </div>
              </div>
            </div>
          }

          @case ('integrations') {
            <div class="space-y-4">
              @for (spec of data.integrationBoundaries; track spec.id) {
                <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-2 text-xs">
                  <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
                    <h2 class="text-sm font-bold text-slate-900">{{ spec.name }}</h2>
                    <span class="font-mono bg-amber-50 text-amber-900 border border-amber-200 px-2 py-0.5 rounded">
                      {{ spec.mode }}
                    </span>
                  </div>
                  <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-700">
                    <div><strong>Authoritative Source:</strong> {{ spec.authoritativeSource }}</div>
                    <div><strong>Authentication:</strong> {{ spec.authentication }}</div>
                    <div><strong>Supported Operations:</strong> {{ spec.supportedOperations.join(', ') }}</div>
                    <div><strong>Data Mapping:</strong> {{ spec.dataMapping }}</div>
                    <div><strong>Delivery Guarantees:</strong> {{ spec.deliveryGuarantees }}</div>
                    <div><strong>Duplicate Handling:</strong> {{ spec.duplicateHandling }}</div>
                    <div><strong>Reconciliation:</strong> {{ spec.reconciliation }}</div>
                    <div><strong>Failure Recovery:</strong> {{ spec.failureRecovery }}</div>
                  </div>
                </article>
              }
            </div>
          }

          @case ('hazards') {
            <div class="space-y-4">
              @for (haz of data.hazardLog; track haz.id) {
                <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-2 text-xs">
                  <div class="flex flex-wrap items-center justify-between gap-2">
                    <div class="flex items-center gap-2">
                      <span class="font-mono font-bold text-slate-500">{{ haz.id }}</span>
                      <h2 class="text-sm font-bold text-slate-900">{{ haz.hazardTitle }}</h2>
                    </div>
                    <span class="font-semibold px-2 py-0.5 rounded border border-red-200 bg-red-50 text-red-900">
                      {{ haz.severity }} · {{ haz.verificationStatus }}
                    </span>
                  </div>
                  <p class="text-slate-700">{{ haz.clinicalRisk }}</p>
                  <ul class="list-disc pl-5 space-y-1 text-slate-700">
                    @for (m of haz.mitigationsImplemented; track m) {
                      <li>{{ m }}</li>
                    }
                  </ul>
                </article>
              }
            </div>
          }

          @case ('capabilities') {
            <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div class="p-5 border-b border-slate-200">
                <h2 class="text-base font-bold text-slate-900">
                  Implemented vs Simulated vs Deferred Capabilities
                </h2>
                <p class="text-xs text-slate-600 mt-0.5">
                  Explicit boundary between verified prototype implementation and external NHS deployment prerequisites.
                </p>
              </div>
              <div class="divide-y divide-slate-100 text-xs">
                @for (cap of data.capabilityMatrix; track cap.capability) {
                  <div class="px-5 py-3.5 flex flex-wrap items-start justify-between gap-4">
                    <div class="space-y-0.5 max-w-3xl">
                      <div class="font-bold text-slate-900">{{ cap.capability }}</div>
                      <div class="text-slate-600">{{ cap.details }}</div>
                    </div>
                    <span
                      class="font-mono font-semibold px-2.5 py-1 rounded border shrink-0"
                      [class.bg-emerald-50]="cap.status === 'implemented'"
                      [class.text-emerald-800]="cap.status === 'implemented'"
                      [class.border-emerald-200]="cap.status === 'implemented'"
                      [class.bg-amber-50]="cap.status === 'simulated'"
                      [class.text-amber-900]="cap.status === 'simulated'"
                      [class.border-amber-200]="cap.status === 'simulated'"
                      [class.bg-slate-100]="cap.status === 'deferred'"
                      [class.text-slate-700]="cap.status === 'deferred'"
                      [class.border-slate-300]="cap.status === 'deferred'"
                    >
                      {{ cap.status.toUpperCase() }}
                    </span>
                  </div>
                }
              </div>
            </div>
          }
        }
      </div>
    }
  `,
})
export class AdminView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly activeTab = signal<'audit' | 'sites' | 'integrations' | 'hazards' | 'capabilities'>('audit');
  protected readonly auditSearch = new FormControl('', {nonNullable: true});
  private readonly auditTerm = signal('');

  protected readonly tabs = [
    {id: 'audit' as const, label: 'Audit Search'},
    {id: 'sites' as const, label: 'Sites, Rooms & Roles'},
    {id: 'integrations' as const, label: 'Integration Boundaries'},
    {id: 'hazards' as const, label: 'Clinical Hazard Log'},
    {id: 'capabilities' as const, label: 'Implemented vs Simulated'},
  ];

  constructor() {
    this.auditSearch.valueChanges.subscribe((v) => this.auditTerm.set(v));
  }

  protected readonly filteredAudit = computed(() => {
    const events = this.ws()?.auditEvents ?? [];
    const q = this.auditTerm().trim().toLowerCase();
    if (!q) return events;
    return events.filter(
      (e) =>
        e.actorName.toLowerCase().includes(q) ||
        e.action.toLowerCase().includes(q) ||
        e.summary.toLowerCase().includes(q) ||
        (e.patientId ?? '').toLowerCase().includes(q) ||
        e.outcome.toLowerCase().includes(q),
    );
  });
}
