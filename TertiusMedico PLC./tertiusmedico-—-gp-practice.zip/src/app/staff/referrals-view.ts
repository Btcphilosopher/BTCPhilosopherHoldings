import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {Referral} from '../../shared/models';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-referrals-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Referrals & External Pathways</h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Local referral drafts remain strictly separate from simulated external e-RS acceptance
          </p>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <div class="xl:col-span-7 space-y-4">
            @for (ref of data.referrals; track ref.id) {
              <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs">
                <div class="flex flex-wrap items-start justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="font-mono text-slate-500">{{ ref.id }}</span>
                      <span class="text-sm font-bold text-slate-900">
                        {{ ref.specialty }} · {{ patientName(ref.patientId) }}
                      </span>
                    </div>
                    <div class="text-slate-600 mt-0.5">
                      Target: {{ ref.targetService }} · Urgency: {{ ref.urgency }} · Author: {{ ref.authorName }}
                    </div>
                  </div>
                  <span class="font-semibold px-2.5 py-1 rounded border border-slate-200 bg-slate-50">
                    {{ ref.status }}
                  </span>
                </div>

                <p class="text-slate-700 leading-relaxed">{{ ref.clinicalSummary }}</p>

                <div class="text-slate-500">
                  Attached results: {{ ref.supportingResultIds.join(', ') || 'None' }} ·
                  Attached documents: {{ ref.supportingDocumentIds.join(', ') || 'None' }}
                </div>

                @if (ref.externalServiceReference) {
                  <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                    <div class="font-mono font-semibold text-slate-900">
                      Simulated Reference: {{ ref.externalServiceReference }}
                    </div>
                    <div class="text-slate-600 mt-0.5">{{ ref.externalStatusNote }}</div>
                  </div>
                }

                <div class="flex flex-wrap items-center gap-2 pt-1">
                  @if (ref.status === 'draft' && api.isClinician()) {
                    <button
                      type="button"
                      (click)="submitRef(ref.id)"
                      class="inline-flex items-center gap-1 px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                    >
                      <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">send</mat-icon>
                      Submit via Simulated e-RS
                    </button>
                  }
                  @if (ref.status === 'submitted_to_external_service') {
                    <button
                      type="button"
                      (click)="simulateAccept(ref.id, true)"
                      class="px-3 py-1.5 font-medium bg-emerald-700 text-white rounded-lg hover:bg-emerald-800"
                    >
                      Simulate External Acceptance
                    </button>
                    <button
                      type="button"
                      (click)="simulateAccept(ref.id, false)"
                      class="px-3 py-1.5 font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      Simulate External Return
                    </button>
                  }
                </div>
              </article>
            }
          </div>

          <div class="xl:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <h2 class="text-base font-bold text-slate-900">
              Prepare Referral Draft ({{ patientName(api.activePatientId()) }})
            </h2>
            @if (api.isClinician()) {
              <form [formGroup]="refForm" (ngSubmit)="createDraft()" class="space-y-3 text-xs">
                <label class="block text-slate-700">
                  <span>Specialty</span>
                  <input type="text" formControlName="specialty" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>Target Service</span>
                  <input type="text" formControlName="targetService" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>Urgency Pathway</span>
                  <select formControlName="urgency" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                    <option value="routine">Routine</option>
                    <option value="urgent">Urgent</option>
                    <option value="two_week_wait_pathway">Urgent Suspected Cancer (2WW Pathway)</option>
                  </select>
                </label>
                <label class="block text-slate-700">
                  <span>Clinical Summary</span>
                  <textarea rows="3" formControlName="clinicalSummary" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"></textarea>
                </label>

                <div class="text-slate-600">
                  Supporting items for {{ api.activePatientId() }}:
                  {{ patientResults().length }} lab result(s), {{ patientDocs().length }} document(s) will be linked when selected.
                </div>

                <button
                  type="submit"
                  class="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">outgoing_mail</mat-icon>
                  Create Referral Draft
                </button>
              </form>
            } @else {
              <p class="text-xs text-slate-500">Clinician sign-in required to prepare referrals.</p>
            }
          </div>
        </div>
      </div>
    }
  `,
})
export class ReferralsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;

  protected readonly refForm = new FormGroup({
    specialty: new FormControl('Respiratory Medicine', {nonNullable: true, validators: [Validators.required]}),
    targetService: new FormControl('Calderdale & Huddersfield Respiratory Clinic', {nonNullable: true, validators: [Validators.required]}),
    urgency: new FormControl<Referral['urgency']>('routine', {nonNullable: true}),
    clinicalSummary: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly patientResults = computed(() =>
    (this.ws()?.labResults ?? []).filter(
      (r) => r.patientId === this.api.activePatientId(),
    ),
  );
  protected readonly patientDocs = computed(() =>
    (this.ws()?.documents ?? []).filter(
      (d) => d.patientId === this.api.activePatientId(),
    ),
  );

  protected patientName(id: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === id);
    return p ? `${p.firstName} ${p.lastName}` : id;
  }

  protected async createDraft(): Promise<void> {
    if (this.refForm.invalid) return;
    const pid = this.api.activePatientId();
    const v = this.refForm.getRawValue();
    await this.api.createReferralDraft({
      patientId: pid,
      expectedPatientId: pid,
      specialty: v.specialty,
      targetService: v.targetService,
      urgency: v.urgency,
      clinicalSummary: v.clinicalSummary,
      supportingDocumentIds: this.patientDocs().map((d) => d.id),
      supportingResultIds: this.patientResults().map((r) => r.id),
    });
    this.refForm.patchValue({clinicalSummary: ''});
    this.api.notify('success', 'Created local referral draft (not yet submitted externally).');
  }

  protected async submitRef(referralId: string): Promise<void> {
    await this.api.submitReferral(referralId);
    this.api.notify('success', `Submitted ${referralId} to simulated e-RS; follow-up task created.`);
  }

  protected async simulateAccept(referralId: string, accepted: boolean): Promise<void> {
    await this.api.simulateExternalReferralStatus(
      referralId,
      accepted,
      accepted
        ? 'Accepted by outpatient booking desk (simulated).'
        : 'Returned for additional blood results (simulated).',
    );
    this.api.notify('info', `Simulated external service update for ${referralId}.`);
  }
}
