import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {CommChannel, PracticeTask} from '../../shared/models';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-tasks-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Tasks, Recalls & Communications</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Sending a message never auto-closes clinical follow-up · Failed deliveries stay visible for recovery
            </p>
          </div>
          <button
            type="button"
            (click)="runWorkers()"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">sync</mat-icon>
            Run Recall & Escalation Worker
          </button>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <!-- Left: Practice Tasks -->
          <div class="xl:col-span-7 space-y-5">
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-base font-bold text-slate-900">
                Owned Practice Tasks ({{ data.tasks.length }})
              </h2>
              <div class="space-y-3">
                @for (task of data.tasks; track task.id) {
                  <div class="p-4 border border-slate-200 rounded-xl space-y-2 text-xs">
                    <div class="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div class="flex flex-wrap items-center gap-2">
                          <span class="font-mono text-slate-500">{{ task.id }}</span>
                          <span class="font-bold text-slate-900 text-sm">{{ task.title }}</span>
                        </div>
                        <div class="text-slate-600 mt-0.5">
                          Owner: {{ task.ownerName }} ({{ task.ownerRole }}) · Due: {{ task.dueDate }}
                          @if (task.patientId) { · Patient: {{ patientName(task.patientId) }} }
                        </div>
                      </div>
                      <span
                        class="font-semibold px-2 py-0.5 rounded border"
                        [class.bg-emerald-50]="task.status === 'completed'"
                        [class.text-emerald-800]="task.status === 'completed'"
                        [class.border-emerald-200]="task.status === 'completed'"
                        [class.bg-amber-50]="task.status !== 'completed'"
                        [class.text-amber-900]="task.status !== 'completed'"
                        [class.border-amber-200]="task.status !== 'completed'"
                      >
                        {{ task.status }}
                      </span>
                    </div>

                    <p class="text-slate-700">{{ task.description }}</p>
                    <div class="text-slate-500">Escalation: {{ task.escalationRule }}</div>

                    @if (task.status !== 'completed') {
                      @if (completingTaskId() === task.id) {
                        <form [formGroup]="completeForm" (ngSubmit)="completeTask(task.id)" class="pt-2 flex flex-wrap gap-2">
                          <input
                            type="text"
                            formControlName="completionEvidence"
                            placeholder="Enter completion evidence (required)..."
                            class="flex-1 min-w-48 border border-slate-300 rounded-lg px-3 py-1.5 bg-white"
                          />
                          <button type="submit" class="px-3 py-1.5 font-semibold bg-[#005EB8] text-white rounded-lg">
                            Record Evidence & Complete
                          </button>
                          <button type="button" (click)="completingTaskId.set(null)" class="px-3 py-1.5 bg-white border border-slate-300 rounded-lg">
                            Cancel
                          </button>
                        </form>
                      } @else {
                        <button
                          type="button"
                          (click)="completingTaskId.set(task.id)"
                          class="inline-flex items-center gap-1 px-3 py-1.5 font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                        >
                          <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">task_alt</mat-icon>
                          Complete with Evidence
                        </button>
                      }
                    } @else {
                      <div class="text-emerald-800">
                        Completed by {{ task.completedBy }}: "{{ task.completionEvidence }}"
                      </div>
                    }
                  </div>
                }
              </div>
            </div>

            <!-- Recall Registers -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-base font-bold text-slate-900">Clinician-Approved Recall Registers</h2>
              @for (rec of data.recallRules; track rec.id) {
                <div class="p-3 border border-slate-200 rounded-lg text-xs flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div class="font-semibold text-slate-900">{{ rec.name }}</div>
                    <div class="text-slate-600">
                      {{ rec.registerCriteria }} · Every {{ rec.intervalMonths }} months · Approved by {{ rec.clinicianApprovedBy }}
                    </div>
                  </div>
                  <span class="font-mono text-slate-600 tabular-nums">
                    {{ rec.eligiblePatientIds.length }} patient(s)
                  </span>
                </div>
              }
            </div>
          </div>

          <!-- Right: Outbound Communications & Create Task -->
          <div class="xl:col-span-5 space-y-5">
            <!-- Send Lock-Screen Safe Message -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-base font-bold text-slate-900">Send Lock-Screen Safe Communication</h2>
              <p class="text-xs text-slate-500">
                SMS and lock-screen previews strip clinical details automatically. Delivery never closes clinical tasks.
              </p>
              <form [formGroup]="commForm" (ngSubmit)="sendComm()" class="space-y-2.5 text-xs">
                <label class="block text-slate-700">
                  <span>Patient</span>
                  <select formControlName="patientId" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white">
                    @for (p of data.patients; track p.internalId) {
                      <option [value]="p.internalId">{{ p.lastName }}, {{ p.firstName }} ({{ p.internalId }})</option>
                    }
                  </select>
                </label>
                <div class="grid grid-cols-2 gap-2">
                  <label class="block text-slate-700">
                    <span>Channel</span>
                    <select formControlName="channel" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white">
                      <option value="portal_message">Portal Message</option>
                      <option value="sms">Simulated SMS</option>
                      <option value="email">Simulated Email</option>
                      <option value="letter">Postal Letter</option>
                    </select>
                  </label>
                  <label class="block text-slate-700">
                    <span>Link Task (Optional)</span>
                    <select formControlName="linkedTaskId" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white">
                      <option value="">None</option>
                      @for (t of data.tasks; track t.id) {
                        <option [value]="t.id">{{ t.id }} ({{ t.status }})</option>
                      }
                    </select>
                  </label>
                </div>
                <label class="block text-slate-700">
                  <span>Subject</span>
                  <input type="text" formControlName="subject" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>Message Body (Visible inside secure portal)</span>
                  <textarea rows="2" formControlName="body" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white"></textarea>
                </label>
                <label class="flex items-center gap-2 text-slate-700">
                  <input type="checkbox" formControlName="simulateFailure" />
                  <span>Simulate delivery failure (to verify visible recovery)</span>
                </label>
                <button type="submit" class="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">send</mat-icon>
                  Dispatch Simulated Message
                </button>
              </form>
            </div>

            <!-- Communications Delivery Log -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-base font-bold text-slate-900">Delivery Log</h2>
              <div class="space-y-2.5 text-xs">
                @for (comm of data.communications; track comm.id) {
                  <div class="p-3 border rounded-lg space-y-1.5" [class.border-red-300]="comm.deliveryStatus === 'failed'" [class.bg-red-50]="comm.deliveryStatus === 'failed'" [class.border-slate-200]="comm.deliveryStatus !== 'failed'">
                    <div class="flex items-center justify-between">
                      <span class="font-semibold text-slate-900">
                        {{ patientName(comm.patientId) }} · {{ comm.channel.toUpperCase() }}
                      </span>
                      <span class="font-mono font-semibold" [class.text-red-800]="comm.deliveryStatus === 'failed'" [class.text-emerald-800]="comm.deliveryStatus === 'delivered'">
                        {{ comm.deliveryStatus }} (x{{ comm.attempts }})
                      </span>
                    </div>
                    <div class="text-slate-700">Lock-screen preview: "{{ comm.lockScreenSafePreview }}"</div>
                    @if (comm.failureReason) {
                      <div class="text-red-800 font-medium">{{ comm.failureReason }}</div>
                      <div class="flex gap-2 pt-1">
                        <button type="button" (click)="retry(comm.id)" class="px-2.5 py-1 bg-white border border-red-300 text-red-900 rounded font-medium">
                          Retry Same Channel
                        </button>
                        <button type="button" (click)="retry(comm.id, 'letter')" class="px-2.5 py-1 bg-[#005EB8] text-white rounded font-medium">
                          Fallback to Letter
                        </button>
                      </div>
                    }
                  </div>
                }
              </div>
            </div>

            <!-- Create New Task -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-sm font-bold text-slate-900">Create Practice Task</h2>
              <form [formGroup]="taskForm" (ngSubmit)="createNewTask()" class="space-y-2 text-xs">
                <input type="text" formControlName="title" placeholder="Task title" class="w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                <div class="grid grid-cols-2 gap-2">
                  <select formControlName="ownerId" class="border border-slate-300 rounded-lg px-2.5 py-2 bg-white">
                    @for (u of data.staffUsers; track u.id) {
                      <option [value]="u.id">{{ u.name }}</option>
                    }
                  </select>
                  <input type="date" formControlName="dueDate" class="border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </div>
                <button type="submit" class="w-full py-2 font-semibold bg-slate-800 text-white rounded-lg hover:bg-slate-900">
                  Assign Task
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class TasksView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly completingTaskId = signal<string | null>(null);

  protected readonly completeForm = new FormGroup({
    completionEvidence: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly commForm = new FormGroup({
    patientId: new FormControl('PT-1001', {nonNullable: true}),
    channel: new FormControl<CommChannel>('portal_message', {nonNullable: true}),
    linkedTaskId: new FormControl('', {nonNullable: true}),
    subject: new FormControl('Follow-up blood test arranged', {nonNullable: true, validators: [Validators.required]}),
    body: new FormControl('Please book a repeat blood test within 48 hours via the portal or reception.', {nonNullable: true, validators: [Validators.required]}),
    simulateFailure: new FormControl(false, {nonNullable: true}),
  });

  protected readonly taskForm = new FormGroup({
    title: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
    ownerId: new FormControl('USR-RECEP-1', {nonNullable: true}),
    dueDate: new FormControl('2026-11-28', {nonNullable: true}),
  });

  protected patientName(id: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === id);
    return p ? `${p.firstName} ${p.lastName}` : id;
  }

  protected async completeTask(taskId: string): Promise<void> {
    if (this.completeForm.invalid) return;
    const {completionEvidence} = this.completeForm.getRawValue();
    try {
      await this.api.completeTask(taskId, completionEvidence);
      this.completeForm.patchValue({completionEvidence: ''});
      this.completingTaskId.set(null);
      this.api.notify('success', `Task ${taskId} completed with evidence.`);
    } catch (err) {
      const msg =
        err && typeof err === 'object' && 'error' in err
          ? (err as {error?: {error?: string}}).error?.error || 'Cannot complete task'
          : 'Cannot complete task';
      this.api.notify('error', msg);
    }
  }

  protected async sendComm(): Promise<void> {
    if (this.commForm.invalid) return;
    const v = this.commForm.getRawValue();
    await this.api.sendCommunication({
      patientId: v.patientId,
      channel: v.channel,
      subject: v.subject,
      body: v.body,
      linkedTaskId: v.linkedTaskId || undefined,
      simulateFailure: v.simulateFailure,
    });
    this.api.notify(
      v.simulateFailure ? 'error' : 'info',
      v.simulateFailure
        ? 'Simulated delivery failure recorded — remains visible in log.'
        : 'Message dispatched (linked clinical task remains open until explicitly completed).',
    );
  }

  protected async retry(commId: string, fallbackChannel?: CommChannel): Promise<void> {
    await this.api.retryCommunication(commId, fallbackChannel);
    this.api.notify('success', `Retried communication ${commId}.`);
  }

  protected async createNewTask(): Promise<void> {
    if (this.taskForm.invalid) return;
    const v = this.taskForm.getRawValue();
    const category: PracticeTask['category'] = 'admin';
    await this.api.createTask({
      patientId: this.api.activePatientId(),
      title: v.title,
      description: 'Assigned from Practice Task Worklist',
      category,
      ownerId: v.ownerId,
      dueDate: v.dueDate,
    });
    this.taskForm.patchValue({title: ''});
    this.api.notify('success', 'Task assigned.');
  }

  protected async runWorkers(): Promise<void> {
    const res = await this.api.runWorkers();
    this.api.notify(
      'info',
      `Worker run complete: ${res.expiredHoldsRemoved} holds expired, ${res.tasksEscalated} escalated, ${res.recallsGenerated} recalls queued.`,
    );
  }
}
