import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-patients-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Patient Register & Identity</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Internal ID primary keys, PDS verification status, duplicate review without auto-merge, and proxy scopes
            </p>
          </div>
          <label class="flex items-center gap-2 bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-slate-400">search</mat-icon>
            <input
              type="text"
              [formControl]="searchControl"
              placeholder="Filter name, ID, postcode..."
              class="bg-transparent focus:outline-none w-52"
            />
          </label>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <!-- Left: Patient Directory & Duplicate Review -->
          <div class="xl:col-span-7 space-y-5">
            <!-- Duplicate Candidates Queue -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <div class="flex items-center justify-between">
                <h2 class="text-base font-bold text-slate-900">
                  Duplicate Record Review (No Auto-Merge)
                </h2>
                <span class="text-xs font-mono text-slate-500">
                  {{ data.duplicateCandidates.length }} candidate(s)
                </span>
              </div>

              @for (dup of data.duplicateCandidates; track dup.id) {
                <div class="p-4 border border-slate-200 rounded-xl space-y-2 text-xs">
                  <div class="flex flex-wrap items-center justify-between gap-2">
                    <span class="font-semibold text-slate-900">
                      {{ patientSummary(dup.patientAId) }} vs {{ patientSummary(dup.patientBId) }}
                    </span>
                    <span
                      class="font-medium px-2 py-0.5 rounded border"
                      [class.bg-amber-50]="dup.status === 'pending_review'"
                      [class.text-amber-900]="dup.status === 'pending_review'"
                      [class.border-amber-200]="dup.status === 'pending_review'"
                      [class.bg-emerald-50]="dup.status !== 'pending_review'"
                      [class.text-emerald-800]="dup.status !== 'pending_review'"
                      [class.border-emerald-200]="dup.status !== 'pending_review'"
                    >
                      {{ dup.status }}
                    </span>
                  </div>
                  <p class="text-slate-600">{{ dup.matchReason }}</p>

                  @if (dup.status === 'pending_review') {
                    <div class="flex flex-wrap items-center gap-2 pt-1">
                      <button
                        type="button"
                        (click)="resolveDuplicate(dup.id, 'confirmed_distinct')"
                        class="px-3 py-1.5 font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                      >
                        Confirm Distinct People
                      </button>
                      <button
                        type="button"
                        (click)="resolveDuplicate(dup.id, 'linked_duplicate')"
                        class="px-3 py-1.5 font-medium bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                      >
                        Flag as Linked Duplicate (Keep Audit Trail)
                      </button>
                    </div>
                  } @else {
                    <div class="text-slate-500">
                      Reviewed by {{ dup.reviewedBy }} · {{ dup.notes }}
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Patient Directory Table -->
            <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
                <h2 class="text-base font-bold text-slate-900">Registered Patients</h2>
                <span class="text-xs text-slate-500 tabular-nums">{{ filteredPatients().length }} records</span>
              </div>
              <div class="divide-y divide-slate-100">
                @for (p of filteredPatients(); track p.internalId) {
                  <div class="px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 hover:bg-slate-50/70">
                    <div class="space-y-0.5 text-xs">
                      <div class="flex flex-wrap items-center gap-2">
                        <span class="text-sm font-semibold text-slate-900">
                          {{ p.title }} {{ p.firstName }} {{ p.lastName }}
                        </span>
                        <span class="font-mono text-slate-500">{{ p.internalId }}</span>
                        <span class="font-mono text-slate-600">DOB {{ p.dob }}</span>
                      </div>
                      <div class="text-slate-600">
                        NHS: {{ p.nhsNumber ?? 'Not supplied' }} ({{ p.nhsVerificationStatus }}) ·
                        {{ p.postcode }} · Status: {{ p.registrationStatus }}
                      </div>
                      @if (p.proxies.length > 0) {
                        <div class="text-[#005EB8]">
                          Proxy: {{ p.proxies[0].proxyName }} ({{ p.proxies[0].verificationStatus }} ·
                          Scopes: {{ p.proxies[0].scopes.join(', ') }})
                        </div>
                      }
                    </div>

                    <div class="flex items-center gap-2">
                      @if (p.nhsNumber && p.nhsVerificationStatus !== 'verified') {
                        <button
                          type="button"
                          (click)="verifyPds(p.internalId)"
                          class="px-2.5 py-1.5 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                        >
                          Trace PDS (Mock)
                        </button>
                      }
                      <button
                        type="button"
                        (click)="selectPatient(p.internalId)"
                        class="px-3 py-1.5 text-xs font-medium bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                      >
                        Open Consultation
                      </button>
                    </div>
                  </div>
                }
              </div>
            </div>

            <!-- Patient Contact Update Requests -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-base font-bold text-slate-900">
                Portal Demographic Update Queue
              </h2>
              @for (cur of data.contactUpdateRequests; track cur.id) {
                <div class="p-3 border border-slate-200 rounded-lg text-xs flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div class="font-semibold text-slate-900">
                      {{ patientSummary(cur.patientId) }} · Status: {{ cur.status }}
                    </div>
                    <div class="text-slate-600 mt-0.5">
                      Requested: Phone {{ cur.requestedChanges.phone || '—' }} ·
                      Channel {{ cur.requestedChanges.preferredChannel || '—' }}
                    </div>
                  </div>
                  @if (cur.status === 'pending_review') {
                    <div class="flex items-center gap-2">
                      <button
                        type="button"
                        (click)="reviewContact(cur.id, 'approved')"
                        class="px-3 py-1.5 font-medium bg-emerald-700 text-white rounded-lg hover:bg-emerald-800"
                      >
                        Approve & Update
                      </button>
                      <button
                        type="button"
                        (click)="reviewContact(cur.id, 'rejected')"
                        class="px-3 py-1.5 font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                      >
                        Reject
                      </button>
                    </div>
                  }
                </div>
              }
            </div>
          </div>

          <!-- Right: Register New Patient -->
          <div class="xl:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <h2 class="text-base font-bold text-slate-900">Register Synthetic Patient</h2>
            <p class="text-xs text-slate-500">
              Creates an internal primary ID and checks for duplicate candidates without auto-merging.
            </p>
            <form [formGroup]="regForm" (ngSubmit)="submitRegistration()" class="space-y-3 text-xs">
              <div class="grid grid-cols-3 gap-2">
                <label class="block text-slate-700">
                  <span>Title</span>
                  <input type="text" formControlName="title" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>First Name</span>
                  <input type="text" formControlName="firstName" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>Last Name</span>
                  <input type="text" formControlName="lastName" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
              </div>

              <div class="grid grid-cols-2 gap-2">
                <label class="block text-slate-700">
                  <span>Date of Birth</span>
                  <input type="date" formControlName="dob" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>Sex at Birth</span>
                  <select formControlName="sexAtBirth" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white">
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Not specified">Not specified</option>
                  </select>
                </label>
              </div>

              <label class="block text-slate-700">
                <span>NHS Number (Optional — never used for login)</span>
                <input type="text" formControlName="nhsNumber" placeholder="e.g. 943 812 4401" class="mt-1 w-full font-mono border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
              </label>

              <div class="grid grid-cols-2 gap-2">
                <label class="block text-slate-700">
                  <span>Address Line 1</span>
                  <input type="text" formControlName="addressLine1" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>Postcode</span>
                  <input type="text" formControlName="postcode" class="mt-1 w-full font-mono border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
              </div>

              <div class="grid grid-cols-2 gap-2">
                <label class="block text-slate-700">
                  <span>Phone</span>
                  <input type="text" formControlName="phone" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
                <label class="block text-slate-700">
                  <span>Email</span>
                  <input type="email" formControlName="email" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white" />
                </label>
              </div>

              <div class="grid grid-cols-2 gap-2">
                <label class="block text-slate-700">
                  <span>Preferred Contact</span>
                  <select formControlName="preferredChannel" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white">
                    <option value="portal">Portal</option>
                    <option value="sms">SMS</option>
                    <option value="email">Email</option>
                    <option value="letter">Letter</option>
                  </select>
                </label>
                <label class="block text-slate-700">
                  <span>Registered Site</span>
                  <select formControlName="registeredSiteId" class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white">
                    @for (site of data.sites; track site.id) {
                      <option [value]="site.id">{{ site.name }}</option>
                    }
                  </select>
                </label>
              </div>

              <label class="block text-slate-700">
                <span>Accessibility / Communication Needs</span>
                <input
                  type="text"
                  formControlName="accessibilityNote"
                  placeholder="e.g. Step-free access, Large print"
                  class="mt-1 w-full border border-slate-300 rounded-lg px-2.5 py-2 bg-white"
                />
              </label>

              <button
                type="submit"
                [disabled]="submitting()"
                class="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087] transition-colors disabled:opacity-50"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">person_add</mat-icon>
                Register Patient
              </button>
            </form>
          </div>
        </div>
      </div>
    }
  `,
})
export class PatientsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly submitting = signal(false);
  protected readonly searchControl = new FormControl('', {nonNullable: true});
  private readonly searchTerm = signal('');

  protected readonly regForm = new FormGroup({
    title: new FormControl('Ms', {nonNullable: true}),
    firstName: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
    lastName: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
    dob: new FormControl('1984-05-14', {nonNullable: true, validators: [Validators.required]}),
    sexAtBirth: new FormControl<'Female' | 'Male' | 'Not specified'>('Female', {nonNullable: true}),
    nhsNumber: new FormControl('', {nonNullable: true}),
    addressLine1: new FormControl('14 Calder Bank', {nonNullable: true}),
    postcode: new FormControl('HX1 2AB', {nonNullable: true}),
    phone: new FormControl('07700 900777', {nonNullable: true}),
    email: new FormControl('new.patient@synthetic.example', {nonNullable: true}),
    preferredChannel: new FormControl<'portal' | 'sms' | 'email' | 'letter'>('portal', {nonNullable: true}),
    registeredSiteId: new FormControl('SITE-MILLBROOK', {nonNullable: true}),
    accessibilityNote: new FormControl('', {nonNullable: true}),
  });

  constructor() {
    this.searchControl.valueChanges.subscribe((v) => this.searchTerm.set(v));
  }

  protected readonly filteredPatients = computed(() => {
    const q = this.searchTerm().trim().toLowerCase();
    const list = this.ws()?.patients ?? [];
    if (!q) return list;
    return list.filter(
      (p) =>
        `${p.firstName} ${p.lastName}`.toLowerCase().includes(q) ||
        p.internalId.toLowerCase().includes(q) ||
        p.postcode.toLowerCase().includes(q) ||
        (p.nhsNumber ?? '').includes(q),
    );
  });

  protected patientSummary(id: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === id);
    return p ? `${p.firstName} ${p.lastName} (${p.internalId})` : id;
  }

  protected selectPatient(id: string): void {
    if (this.api.requestPatientSwitch(id)) {
      this.api.staffSection.set('consultations');
    }
  }

  protected async verifyPds(patientId: string): Promise<void> {
    try {
      await this.api.verifyPdsMock(patientId);
      this.api.notify('success', `Mock PDS trace verified NHS number for ${patientId}.`);
    } catch {
      this.api.notify('error', 'PDS verification failed.');
    }
  }

  protected async resolveDuplicate(
    candidateId: string,
    resolution: 'confirmed_distinct' | 'linked_duplicate',
  ): Promise<void> {
    await this.api.resolveDuplicate(
      candidateId,
      resolution,
      'Manually reviewed by staff without automatic record merging.',
    );
    this.api.notify('success', `Duplicate review recorded (${resolution}).`);
  }

  protected async reviewContact(
    requestId: string,
    decision: 'approved' | 'rejected',
  ): Promise<void> {
    await this.api.reviewContactUpdate(
      requestId,
      decision,
      `Reviewed by staff (${decision})`,
    );
    this.api.notify('success', `Contact update request ${decision}.`);
  }

  protected async submitRegistration(): Promise<void> {
    if (this.regForm.invalid) return;
    this.submitting.set(true);
    const v = this.regForm.getRawValue();
    try {
      const res = await this.api.registerPatient({
        title: v.title,
        firstName: v.firstName,
        lastName: v.lastName,
        dob: v.dob,
        sexAtBirth: v.sexAtBirth,
        nhsNumber: v.nhsNumber || null,
        addressLine1: v.addressLine1,
        city: 'Calderdale',
        postcode: v.postcode,
        phone: v.phone,
        email: v.email,
        preferredChannel: v.preferredChannel,
        registeredSiteId: v.registeredSiteId,
        usualGpId: 'CLN-VANCE',
        accessibilityNeeds: v.accessibilityNote.trim() ? [v.accessibilityNote.trim()] : [],
      });
      this.regForm.patchValue({firstName: '', lastName: '', nhsNumber: '', accessibilityNote: ''});
      this.api.notify(
        'success',
        `Registered ${res.patient.firstName} ${res.patient.lastName} (${res.patient.internalId}). Duplicate warnings: ${res.duplicateWarnings.length}.`,
      );
    } catch {
      this.api.notify('error', 'Registration failed.');
    } finally {
      this.submitting.set(false);
    }
  }
}
