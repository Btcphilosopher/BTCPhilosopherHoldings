import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-reports-view',
  imports: [MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Operational Reports</h1>
            <p class="text-sm text-slate-600 mt-0.5">{{ data.metrics.disclaimer }}</p>
          </div>
          <button
            type="button"
            (click)="api.refreshWorkspace()"
            class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">refresh</mat-icon>
            Refresh Metrics
          </button>
        </div>

        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-950">
          <strong>Reporting Scope Notice:</strong> Figures below are live prototype operational counts for Pennine Medical Practice. They are not official NHS statutory, QOF, or contractual GPAD submissions.
        </div>

        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <table class="w-full text-left border-collapse text-sm">
            <thead>
              <tr class="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                <th class="px-5 py-3 font-semibold">Operational Measure</th>
                <th class="px-5 py-3 font-semibold">Definition</th>
                <th class="px-5 py-3 font-semibold text-right">Current Count</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 text-xs">
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Appointment Slot Availability</td>
                <td class="px-5 py-3.5 text-slate-600">Active non-break slots across active clinician sessions</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold tabular-nums">{{ data.metrics.totalAppointmentSlots }}</td>
              </tr>
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Booked Activity</td>
                <td class="px-5 py-3.5 text-slate-600">Non-cancelled appointments across both sites</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold tabular-nums">{{ data.metrics.bookedAppointments }}</td>
              </tr>
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Arrived & Attended Activity</td>
                <td class="px-5 py-3.5 text-slate-600">Appointments with recorded arrival, in-consultation, or completed status</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold tabular-nums">{{ data.metrics.arrivedOrAttended }}</td>
              </tr>
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Cancellations & DNA</td>
                <td class="px-5 py-3.5 text-slate-600">Cancelled appointments / Did-Not-Attend records</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold tabular-nums">{{ data.metrics.cancelledAppointments }} / {{ data.metrics.dnaCount }}</td>
              </tr>
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Requests Awaiting Review</td>
                <td class="px-5 py-3.5 text-slate-600">Portal & reception requests in submitted, admin review, or clinician triage</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold tabular-nums">{{ data.metrics.requestsAwaitingReview }}</td>
              </tr>
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Outstanding Results Actions</td>
                <td class="px-5 py-3.5 text-slate-600">Results not yet reaching follow_up_completed (including unmatched: {{ data.metrics.unmatchedResults }})</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold tabular-nums">{{ data.metrics.outstandingResultActions }}</td>
              </tr>
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Unprocessed Correspondence</td>
                <td class="px-5 py-3.5 text-slate-600">Incoming OCR letters awaiting matching or clinician filing</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold tabular-nums">{{ data.metrics.unprocessedCorrespondence }}</td>
              </tr>
              <tr>
                <td class="px-5 py-3.5 font-semibold text-slate-900">Failed Communications</td>
                <td class="px-5 py-3.5 text-slate-600">SMS / Email deliveries in failed state requiring retry or postal fallback</td>
                <td class="px-5 py-3.5 text-right font-mono font-bold text-red-700 tabular-nums">{{ data.metrics.failedCommunications }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    }
  `,
})
export class ReportsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
}
