import {ChangeDetectionStrategy, Component, computed, inject} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-today-view',
  imports: [MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Today at Pennine Medical Practice</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Millbrook Surgery (Main) & Valley View Branch · Europe/London
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            <button
              type="button"
              (click)="api.staffSection.set('appointments')"
              class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087] transition-colors whitespace-nowrap"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">calendar_add_on</mat-icon>
              Book Appointment
            </button>
            <button
              type="button"
              (click)="api.staffSection.set('patients')"
              class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-white border border-slate-300 text-slate-800 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">person_add</mat-icon>
              Register Patient
            </button>
          </div>
        </div>

        <!-- Operational Summary Row -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            type="button"
            (click)="api.staffSection.set('appointments')"
            class="text-left bg-white border border-slate-200 rounded-xl p-4 hover:border-[#005EB8] transition-colors"
          >
            <div class="text-xs text-slate-500">Booked Today</div>
            <div class="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
              {{ data.metrics.bookedAppointments }} / {{ data.metrics.totalAppointmentSlots }}
            </div>
            <div class="text-xs text-slate-600 mt-1 tabular-nums">
              {{ data.metrics.arrivedOrAttended }} arrived or attended
            </div>
          </button>

          <button
            type="button"
            (click)="api.staffSection.set('requests')"
            class="text-left bg-white border border-slate-200 rounded-xl p-4 hover:border-[#005EB8] transition-colors"
          >
            <div class="text-xs text-slate-500">Requests Awaiting Review</div>
            <div class="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
              {{ data.metrics.requestsAwaitingReview }}
            </div>
            <div class="text-xs text-slate-600 mt-1">Reception & clinician triage</div>
          </button>

          <button
            type="button"
            (click)="api.staffSection.set('results')"
            class="text-left bg-white border border-slate-200 rounded-xl p-4 hover:border-[#005EB8] transition-colors"
          >
            <div class="text-xs text-slate-500">Outstanding Results</div>
            <div class="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
              {{ data.metrics.outstandingResultActions }}
            </div>
            <div class="text-xs text-amber-700 mt-1 tabular-nums">
              {{ data.metrics.unmatchedResults }} unmatched patient
            </div>
          </button>

          <button
            type="button"
            (click)="api.staffSection.set('tasks')"
            class="text-left bg-white border border-slate-200 rounded-xl p-4 hover:border-[#005EB8] transition-colors"
          >
            <div class="text-xs text-slate-500">Open Tasks & Failed Comms</div>
            <div class="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
              {{ data.metrics.openTasks }}
            </div>
            <div class="text-xs text-red-700 mt-1 tabular-nums">
              {{ data.metrics.failedCommunications }} failed notification
            </div>
          </button>
        </div>

        <!-- Main 2-Column Operational Workspace -->
        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <!-- Left: Today's Arrival & Consultation Queue -->
          <div class="xl:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
              <div>
                <h2 class="text-base font-bold text-slate-900">Today's Clinic Queue</h2>
                <p class="text-xs text-slate-500">Record arrival or open clinical consultation directly</p>
              </div>
              <span class="text-xs font-mono text-slate-500 tabular-nums">
                {{ activeAppointments().length }} active
              </span>
            </div>

            <div class="divide-y divide-slate-100">
              @for (apt of activeAppointments(); track apt.id) {
                <div class="px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 hover:bg-slate-50/70">
                  <div class="space-y-0.5 min-w-0">
                    <div class="flex flex-wrap items-center gap-2">
                      <span class="font-mono text-xs font-semibold text-slate-900 tabular-nums">
                        {{ apt.startTime }}
                      </span>
                      <span class="text-sm font-semibold text-slate-900">
                        {{ patientName(apt.patientId) }}
                      </span>
                      <span class="text-xs font-mono text-slate-500">{{ apt.patientId }}</span>
                    </div>
                    <div class="text-xs text-slate-600">
                      {{ clinicianName(apt.clinicianId) }} · {{ siteName(apt.siteId) }} ·
                      {{ apt.appointmentType }} ({{ apt.mode }})
                    </div>
                    <div class="text-xs text-slate-500 truncate">{{ apt.reason }}</div>
                  </div>

                  <div class="flex items-center gap-2 shrink-0">
                    <span
                      class="text-xs font-medium px-2 py-0.5 rounded border"
                      [class.bg-emerald-50]="apt.status === 'arrived' || apt.status === 'completed'"
                      [class.text-emerald-800]="apt.status === 'arrived' || apt.status === 'completed'"
                      [class.border-emerald-200]="apt.status === 'arrived' || apt.status === 'completed'"
                      [class.bg-blue-50]="apt.status === 'booked' || apt.status === 'in_consultation'"
                      [class.text-blue-800]="apt.status === 'booked' || apt.status === 'in_consultation'"
                      [class.border-blue-200]="apt.status === 'booked' || apt.status === 'in_consultation'"
                    >
                      {{ apt.status }}
                    </span>

                    @if (apt.status === 'booked') {
                      <button
                        type="button"
                        (click)="markArrived(apt.id)"
                        class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-800 rounded-lg hover:bg-slate-50"
                      >
                        <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">how_to_reg</mat-icon>
                        Record Arrival
                      </button>
                    }

                    <button
                      type="button"
                      (click)="openInConsultations(apt.patientId)"
                      class="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-[#005EB8] text-white rounded-lg hover:bg-[#003087]"
                    >
                      <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">clinical_notes</mat-icon>
                      Open Record
                    </button>
                  </div>
                </div>
              } @empty {
                <div class="p-8 text-center text-sm text-slate-500">
                  No active appointments scheduled for today.
                </div>
              }
            </div>
          </div>

          <!-- Right: Safety Alerts & Priority Work -->
          <div class="xl:col-span-5 space-y-5">
            <!-- Session Alerts (e.g., Unavailable Clinician) -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-base font-bold text-slate-900">Rota & Staffing Alerts</h2>
              @for (ses of unavailableSessions(); track ses.id) {
                <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-950 flex items-start gap-2">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-amber-700 shrink-0">event_busy</mat-icon>
                  <div>
                    <div class="font-semibold">
                      {{ clinicianName(ses.clinicianId) }} · {{ siteName(ses.siteId) }} ({{ ses.startTime }}–{{ ses.endTime }})
                    </div>
                    <div class="mt-0.5">{{ ses.unavailableReason }}</div>
                  </div>
                </div>
              }
            </div>

            <!-- Action Queues Snapshot -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-base font-bold text-slate-900">Attention Required</h2>

              <div class="divide-y divide-slate-100 text-xs">
                <div class="py-2.5 flex items-center justify-between gap-2">
                  <div>
                    <div class="font-semibold text-slate-900">Pending Duplicate Identity Review</div>
                    <div class="text-slate-500">Manual check required without auto-merge</div>
                  </div>
                  <button
                    type="button"
                    (click)="api.staffSection.set('patients')"
                    class="text-[#005EB8] font-semibold hover:underline whitespace-nowrap"
                  >
                    {{ pendingDuplicates() }} candidate
                  </button>
                </div>

                <div class="py-2.5 flex items-center justify-between gap-2">
                  <div>
                    <div class="font-semibold text-slate-900">Unmatched Laboratory Result</div>
                    <div class="text-slate-500">Held safely outside patient chart</div>
                  </div>
                  <button
                    type="button"
                    (click)="api.staffSection.set('results')"
                    class="text-[#005EB8] font-semibold hover:underline whitespace-nowrap"
                  >
                    {{ data.metrics.unmatchedResults }} unmatched
                  </button>
                </div>

                <div class="py-2.5 flex items-center justify-between gap-2">
                  <div>
                    <div class="font-semibold text-slate-900">Failed SMS Communication</div>
                    <div class="text-slate-500">Requires retry or postal fallback</div>
                  </div>
                  <button
                    type="button"
                    (click)="api.staffSection.set('tasks')"
                    class="text-red-700 font-semibold hover:underline whitespace-nowrap"
                  >
                    {{ data.metrics.failedCommunications }} failed
                  </button>
                </div>

                <div class="py-2.5 flex items-center justify-between gap-2">
                  <div>
                    <div class="font-semibold text-slate-900">OCR Correspondence Awaiting Review</div>
                    <div class="text-slate-500">Not yet filed into authoritative clinical record</div>
                  </div>
                  <button
                    type="button"
                    (click)="api.staffSection.set('documents')"
                    class="text-[#005EB8] font-semibold hover:underline whitespace-nowrap"
                  >
                    {{ data.metrics.unprocessedCorrespondence }} documents
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class TodayView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;

  protected readonly activeAppointments = computed(() =>
    (this.ws()?.appointments ?? []).filter((a) => a.status !== 'cancelled'),
  );

  protected readonly unavailableSessions = computed(() =>
    (this.ws()?.sessions ?? []).filter((s) => s.status !== 'active'),
  );

  protected readonly pendingDuplicates = computed(
    () =>
      (this.ws()?.duplicateCandidates ?? []).filter(
        (d) => d.status === 'pending_review',
      ).length,
  );

  protected patientName(patientId: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === patientId);
    return p ? `${p.firstName} ${p.lastName}` : patientId;
  }

  protected clinicianName(clinicianId: string): string {
    return (
      this.ws()?.clinicians.find((c) => c.id === clinicianId)?.name ?? clinicianId
    );
  }

  protected siteName(siteId: string): string {
    return this.ws()?.sites.find((s) => s.id === siteId)?.name ?? siteId;
  }

  protected async markArrived(appointmentId: string): Promise<void> {
    try {
      await this.api.recordArrival(appointmentId);
      this.api.notify('success', `Recorded arrival for ${appointmentId}.`);
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected openInConsultations(patientId: string): void {
    if (this.api.requestPatientSwitch(patientId)) {
      this.api.staffSection.set('consultations');
    }
  }

  private extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as {error?: {error?: string}}).error;
      if (inner?.error) return inner.error;
    }
    return 'Operation failed.';
  }
}
