import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {AppointmentMode} from '../../shared/models';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-appointments-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Appointments & Clinician Rotas</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Europe/London scheduling · Transactional conflict checks & cross-site travel buffers
            </p>
          </div>
          <div class="flex items-center gap-2 bg-white border border-slate-200 rounded-lg p-1">
            <button
              type="button"
              (click)="siteFilter.set('ALL')"
              class="px-3 py-1.5 text-xs font-medium rounded-md transition-colors"
              [class.bg-[#005EB8]]="siteFilter() === 'ALL'"
              [class.text-white]="siteFilter() === 'ALL'"
              [class.text-slate-700]="siteFilter() !== 'ALL'"
            >
              All Sites
            </button>
            @for (site of data.sites; track site.id) {
              <button
                type="button"
                (click)="siteFilter.set(site.id)"
                class="px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap"
                [class.bg-[#005EB8]]="siteFilter() === site.id"
                [class.text-white]="siteFilter() === site.id"
                [class.text-slate-700]="siteFilter() !== site.id"
              >
                {{ site.name }}
              </button>
            }
          </div>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <!-- Left: Clinician Sessions & Slots -->
          <div class="xl:col-span-8 space-y-5">
            @for (ses of filteredSessions(); track ses.id) {
              <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div class="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div class="flex flex-wrap items-center gap-2">
                      <h2 class="text-base font-bold text-slate-900">
                        {{ clinicianName(ses.clinicianId) }}
                      </h2>
                      <span class="text-xs font-mono text-slate-500">
                        {{ ses.date }} · {{ ses.startTime }}–{{ ses.endTime }} (Europe/London)
                      </span>
                    </div>
                    <p class="text-xs text-slate-600 mt-0.5">
                      {{ siteName(ses.siteId) }} · {{ roomName(ses.roomId) }} ·
                      Types: {{ ses.allowedAppointmentTypes.join(', ') }}
                    </p>
                  </div>

                  @if (ses.status === 'unavailable_leave') {
                    <span class="inline-flex items-center gap-1 text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-300 px-2.5 py-1 rounded-md">
                      <mat-icon class="!text-[15px] !w-[15px] !h-[15px]">event_busy</mat-icon>
                      Unavailable (Annual Leave)
                    </span>
                  } @else {
                    <span class="text-xs text-slate-600">
                      {{ ses.patientSelfBookAllowed ? 'Portal self-booking enabled' : 'Staff booking only' }}
                    </span>
                  }
                </div>

                @if (ses.status === 'unavailable_leave') {
                  <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-950">
                    {{ ses.unavailableReason }}
                    <button
                      type="button"
                      (click)="testUnavailableBooking(ses.id)"
                      class="ml-3 underline font-semibold text-amber-900 hover:text-amber-950"
                    >
                      Verify booking block
                    </button>
                  </div>
                } @else {
                  <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2">
                    @for (slot of slotsForSession(ses.id); track slot.startTime) {
                      @if (slot.status === 'booked') {
                        <div class="p-2.5 rounded-lg border border-blue-200 bg-blue-50/70 text-xs space-y-1">
                          <div class="flex items-center justify-between font-mono font-semibold text-blue-950 tabular-nums">
                            <span>{{ slot.startTime }}</span>
                            <span class="text-[10px]">Booked</span>
                          </div>
                          @if (appointmentById(slot.appointmentId); as apt) {
                            <div class="font-medium text-slate-900 truncate">
                              {{ patientName(apt.patientId) }}
                            </div>
                            <div class="text-[11px] text-slate-600 truncate">{{ apt.status }} · {{ apt.mode }}</div>
                            <div class="flex items-center gap-1 pt-1">
                              @if (apt.status === 'booked') {
                                <button
                                  type="button"
                                  (click)="arrive(apt.id)"
                                  class="px-1.5 py-0.5 text-[10px] font-semibold bg-white border border-slate-300 rounded hover:bg-slate-50"
                                >
                                  Arrive
                                </button>
                              }
                              <button
                                type="button"
                                (click)="selectForReschedule(apt.id)"
                                class="px-1.5 py-0.5 text-[10px] font-semibold bg-white border border-slate-300 rounded hover:bg-slate-50"
                              >
                                Move
                              </button>
                              <button
                                type="button"
                                (click)="cancel(apt.id)"
                                class="px-1.5 py-0.5 text-[10px] font-semibold text-red-700 bg-white border border-red-200 rounded hover:bg-red-50"
                              >
                                Cancel
                              </button>
                            </div>
                          }
                        </div>
                      } @else if (slot.status === 'break') {
                        <div class="p-2.5 rounded-lg border border-slate-200 bg-slate-100 text-xs text-slate-500 flex flex-col justify-center">
                          <span class="font-mono tabular-nums">{{ slot.startTime }}</span>
                          <span>Clinician Break</span>
                        </div>
                      } @else {
                        <button
                          type="button"
                          (click)="pickSlot(ses.id, slot.startTime, ses.allowedAppointmentTypes[0])"
                          class="text-left p-2.5 rounded-lg border transition-colors text-xs"
                          [class.border-amber-300]="slot.status === 'protected'"
                          [class.bg-amber-50]="slot.status === 'protected'"
                          [class.border-slate-200]="slot.status === 'available'"
                          [class.bg-white]="slot.status === 'available'"
                          [class.hover:border-[#005EB8]]="true"
                        >
                          <div class="font-mono font-semibold text-slate-900 tabular-nums">
                            {{ slot.startTime }}
                          </div>
                          <div class="text-[11px] text-slate-600 mt-0.5">
                            @if (rescheduleTargetId()) {
                              Move here
                            } @else if (slot.status === 'protected') {
                              Protected (Staff)
                            } @else {
                              Available
                            }
                          </div>
                        </button>
                      }
                    }
                  </div>
                }
              </div>
            }
          </div>

          <!-- Right: Booking & Rota Template Controls -->
          <div class="xl:col-span-4 space-y-5">
            @if (rescheduleTargetId(); as moveId) {
              <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-2 text-xs text-blue-950">
                <div class="font-bold flex items-center gap-1.5">
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">swap_horiz</mat-icon>
                  Reschedule Proposal Active ({{ moveId }})
                </div>
                <p>Click any available slot on the calendar to validate and move this appointment via the server.</p>
                <button
                  type="button"
                  (click)="rescheduleTargetId.set(null)"
                  class="px-3 py-1 bg-white border border-blue-300 rounded-md font-medium"
                >
                  Cancel Move
                </button>
              </div>
            }

            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <h2 class="text-base font-bold text-slate-900">Book Appointment</h2>
              <form [formGroup]="bookForm" (ngSubmit)="submitBooking()" class="space-y-3 text-xs">
                <label class="block text-slate-700">
                  <span>Patient</span>
                  <select formControlName="patientId" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                    @for (p of data.patients; track p.internalId) {
                      <option [value]="p.internalId">
                        {{ p.lastName }}, {{ p.firstName }} ({{ p.internalId }})
                      </option>
                    }
                  </select>
                </label>

                <label class="block text-slate-700">
                  <span>Clinician Session</span>
                  <select formControlName="sessionId" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                    @for (s of data.sessions; track s.id) {
                      <option [value]="s.id">
                        {{ clinicianName(s.clinicianId) }} · {{ s.date }} {{ s.startTime }}
                        @if (s.status !== 'active') { [UNAVAILABLE] }
                      </option>
                    }
                  </select>
                </label>

                <div class="grid grid-cols-2 gap-2">
                  <label class="block text-slate-700">
                    <span>Start Time (HH:MM)</span>
                    <input
                      type="text"
                      formControlName="startTime"
                      class="mt-1 w-full font-mono border border-slate-300 rounded-lg px-3 py-2 bg-white"
                    />
                  </label>

                  <label class="block text-slate-700">
                    <span>Mode</span>
                    <select formControlName="mode" class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
                      <option value="in_person">In-person</option>
                      <option value="telephone">Telephone</option>
                      <option value="video">Video</option>
                    </select>
                  </label>
                </div>

                <label class="block text-slate-700">
                  <span>Appointment Type</span>
                  <input
                    type="text"
                    formControlName="appointmentType"
                    class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"
                  />
                </label>

                <label class="block text-slate-700">
                  <span>Reason</span>
                  <textarea
                    rows="2"
                    formControlName="reason"
                    class="mt-1 w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"
                  ></textarea>
                </label>

                <button
                  type="submit"
                  class="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-semibold bg-[#005EB8] text-white rounded-lg hover:bg-[#003087] transition-colors"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">event_available</mat-icon>
                  Confirm Booking
                </button>
              </form>
            </div>

            <!-- Session Template Versioning -->
            <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
              <h2 class="text-sm font-bold text-slate-900">Rota Templates (Safe Versioning)</h2>
              <p class="text-xs text-slate-500">
                Updating a future template increments its version and never silently alters existing booked appointments.
              </p>
              <div class="space-y-2.5 text-xs">
                @for (tpl of data.sessionTemplates; track tpl.id) {
                  <div class="p-3 border border-slate-200 rounded-lg space-y-2">
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-semibold text-slate-900">{{ tpl.name }}</span>
                      <span class="font-mono text-slate-500">v{{ tpl.version }}</span>
                    </div>
                    <div class="text-slate-600">
                      {{ tpl.slotDurationMinutes }} min slots · Self-book: {{ tpl.patientSelfBookAllowed ? 'Yes' : 'No' }}
                    </div>
                    <button
                      type="button"
                      (click)="toggleSelfBook(tpl.id, !tpl.patientSelfBookAllowed)"
                      class="px-2.5 py-1 text-[11px] font-medium bg-slate-50 border border-slate-300 rounded hover:bg-slate-100"
                    >
                      Toggle Self-Booking Rule (v{{ tpl.version + 1 }})
                    </button>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class AppointmentsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly siteFilter = signal<string>('ALL');
  protected readonly rescheduleTargetId = signal<string | null>(null);

  protected readonly bookForm = new FormGroup({
    patientId: new FormControl('PT-1001', {nonNullable: true, validators: [Validators.required]}),
    sessionId: new FormControl('SES-TODAY-VANCE-AM', {nonNullable: true, validators: [Validators.required]}),
    startTime: new FormControl('10:45', {nonNullable: true, validators: [Validators.required]}),
    mode: new FormControl<AppointmentMode>('in_person', {nonNullable: true}),
    appointmentType: new FormControl('Routine GP', {nonNullable: true, validators: [Validators.required]}),
    reason: new FormControl('Clinical review', {nonNullable: true}),
  });

  protected readonly filteredSessions = computed(() => {
    const sessions = this.ws()?.sessions ?? [];
    const filter = this.siteFilter();
    return filter === 'ALL' ? sessions : sessions.filter((s) => s.siteId === filter);
  });

  protected slotsForSession(sessionId: string) {
    return (this.ws()?.slots ?? []).filter((sl) => sl.sessionId === sessionId);
  }

  protected appointmentById(id?: string) {
    if (!id) return undefined;
    return this.ws()?.appointments.find((a) => a.id === id);
  }

  protected patientName(patientId: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === patientId);
    return p ? `${p.firstName} ${p.lastName}` : patientId;
  }

  protected clinicianName(clinicianId: string): string {
    return this.ws()?.clinicians.find((c) => c.id === clinicianId)?.name ?? clinicianId;
  }

  protected siteName(siteId: string): string {
    return this.ws()?.sites.find((s) => s.id === siteId)?.name ?? siteId;
  }

  protected roomName(roomId: string): string {
    return this.ws()?.rooms.find((r) => r.id === roomId)?.name ?? roomId;
  }

  protected async pickSlot(
    sessionId: string,
    startTime: string,
    defaultType: string,
  ): Promise<void> {
    const moveId = this.rescheduleTargetId();
    if (moveId) {
      try {
        await this.api.rescheduleAppointment(moveId, sessionId, startTime);
        this.rescheduleTargetId.set(null);
        this.api.notify('success', `Rescheduled appointment ${moveId} to ${startTime}.`);
      } catch (err) {
        this.api.notify('error', this.extractError(err));
      }
      return;
    }

    this.bookForm.patchValue({
      sessionId,
      startTime,
      appointmentType: defaultType,
      patientId: this.api.activePatientId(),
    });
  }

  protected selectForReschedule(appointmentId: string): void {
    this.rescheduleTargetId.set(appointmentId);
  }

  protected async submitBooking(): Promise<void> {
    if (this.bookForm.invalid) return;
    const v = this.bookForm.getRawValue();
    try {
      const apt = await this.api.bookAppointmentStaff(v);
      this.api.notify('success', `Booked appointment ${apt.id} at ${apt.startTime} (${apt.date}).`);
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async testUnavailableBooking(sessionId: string): Promise<void> {
    try {
      await this.api.bookAppointmentStaff({
        patientId: this.api.activePatientId(),
        sessionId,
        startTime: '09:00',
        mode: 'in_person',
        appointmentType: 'Routine GP',
        reason: 'Test unavailable clinician block',
      });
    } catch (err) {
      this.api.notify('info', `Blocked as expected: ${this.extractError(err)}`);
    }
  }

  protected async arrive(appointmentId: string): Promise<void> {
    try {
      await this.api.recordArrival(appointmentId);
      this.api.notify('success', `Recorded arrival for ${appointmentId}.`);
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async cancel(appointmentId: string): Promise<void> {
    try {
      await this.api.cancelAppointmentStaff(appointmentId, 'Cancelled at reception desk');
      this.api.notify('info', `Cancelled appointment ${appointmentId}.`);
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  protected async toggleSelfBook(templateId: string, nextVal: boolean): Promise<void> {
    try {
      await this.api.updateSessionTemplate(templateId, {patientSelfBookAllowed: nextVal});
      this.api.notify(
        'success',
        'Updated template version; existing booked appointments preserved unchanged.',
      );
    } catch (err) {
      this.api.notify('error', this.extractError(err));
    }
  }

  private extractError(err: unknown): string {
    if (err && typeof err === 'object' && 'error' in err) {
      const inner = (err as {error?: {error?: string}}).error;
      if (inner?.error) return inner.error;
    }
    return 'Scheduling action rejected by validation.';
  }
}
