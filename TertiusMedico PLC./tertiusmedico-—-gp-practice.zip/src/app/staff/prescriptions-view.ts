import {ChangeDetectionStrategy, Component, computed, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {PracticeApi} from '../services/practice-api';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-prescriptions-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (ws(); as data) {
      <div class="space-y-6">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl font-bold text-slate-900">Medicines & Repeat Requests</h1>
            <p class="text-sm text-slate-600 mt-0.5">
              Prototype workflow only — does NOT issue real prescriptions or perform autonomous dose calculation
            </p>
          </div>
          <span class="text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-300 px-3 py-1.5 rounded-lg">
            Simulated EPS Boundary · No Real Prescriptions Issued
          </span>
        </div>

        <!-- Repeat Medication Requests Queue -->
        <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <h2 class="text-base font-bold text-slate-900">Repeat Medication Request Queue</h2>

          @for (req of data.repeatRequests; track req.id) {
            <div class="p-4 border border-slate-200 rounded-xl space-y-3 text-xs">
              <div class="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="font-mono text-slate-500">{{ req.id }}</span>
                    <span class="text-sm font-bold text-slate-900">{{ req.drugName }}</span>
                    <span class="text-slate-600">· {{ patientName(req.patientId) }}</span>
                  </div>
                  <div class="text-slate-600 mt-1">
                    Nominated pharmacy: {{ req.nominatedPharmacy }} · Submitted: {{ req.submittedAt }}
                  </div>
                  @if (req.patientNote) {
                    <div class="text-slate-700 mt-1">Patient note: "{{ req.patientNote }}"</div>
                  }
                </div>

                <span
                  class="font-semibold px-2.5 py-1 rounded border"
                  [class.bg-emerald-50]="req.status === 'approved_simulated'"
                  [class.text-emerald-800]="req.status === 'approved_simulated'"
                  [class.border-emerald-200]="req.status === 'approved_simulated'"
                  [class.bg-red-50]="req.status === 'rejected'"
                  [class.text-red-800]="req.status === 'rejected'"
                  [class.border-red-200]="req.status === 'rejected'"
                  [class.bg-amber-50]="req.status === 'submitted' || req.status === 'awaiting_prescriber'"
                  [class.text-amber-900]="req.status === 'submitted' || req.status === 'awaiting_prescriber'"
                  [class.border-amber-200]="req.status === 'submitted' || req.status === 'awaiting_prescriber'"
                >
                  {{ req.status }}
                </span>
              </div>

              <!-- Distinct Lifecycle Stages -->
              <div class="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-slate-100">
                <div class="p-2.5 bg-slate-50 rounded-lg">
                  <div class="font-semibold text-slate-800">1. Administrative Check</div>
                  @if (req.adminCheckedBy) {
                    <div class="text-slate-600 mt-0.5">Checked by {{ req.adminCheckedBy }}</div>
                  } @else {
                    <button
                      type="button"
                      (click)="adminCheck(req.id)"
                      class="mt-1 px-2.5 py-1 bg-white border border-slate-300 rounded font-medium hover:bg-slate-100"
                    >
                      Complete Admin Check
                    </button>
                  }
                </div>

                <div class="p-2.5 bg-slate-50 rounded-lg">
                  <div class="font-semibold text-slate-800">2. Clinician Prescribing Decision</div>
                  @if (req.prescribingDecision; as dec) {
                    <div class="text-slate-700 mt-0.5">
                      {{ dec.decision }} by {{ dec.decidedBy }} ({{ dec.decidedRole }})
                    </div>
                    <div class="text-slate-600">Reason: {{ dec.reason }}</div>
                    <div class="text-amber-900 mt-1">
                      Safety check ({{ dec.safetyCheck.coverageStatus }}):
                      @if (dec.safetyCheck.warnings.length > 0) {
                        {{ dec.safetyCheck.warnings.join(' ') }}
                      } @else {
                        Prototype subset checked; not BNF-validated.
                      }
                    </div>
                  } @else if (api.isPrescriber()) {
                    @if (decisionTargetId() === req.id) {
                      <form [formGroup]="decideForm" (ngSubmit)="submitDecision(req.id, req.patientId)" class="mt-1 space-y-2">
                        <select formControlName="decision" class="w-full border border-slate-300 rounded px-2 py-1 bg-white">
                          <option value="approved">Approve (Simulated Transmission)</option>
                          <option value="rejected">Reject with Reason</option>
                        </select>
                        <input type="text" formControlName="reason" placeholder="Clinical reason (mandatory)" class="w-full border border-slate-300 rounded px-2 py-1 bg-white" />
                        <div class="flex gap-1.5">
                          <button type="submit" class="px-2.5 py-1 bg-[#005EB8] text-white rounded font-medium">Confirm</button>
                          <button type="button" (click)="decisionTargetId.set(null)" class="px-2.5 py-1 bg-white border border-slate-300 rounded">Cancel</button>
                        </div>
                      </form>
                    } @else {
                      <button
                        type="button"
                        (click)="decisionTargetId.set(req.id)"
                        class="mt-1 inline-flex items-center gap-1 px-2.5 py-1 bg-[#005EB8] text-white rounded font-medium hover:bg-[#003087]"
                      >
                        <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">medication</mat-icon>
                        Review & Decide
                      </button>
                    }
                  } @else {
                    <div class="text-slate-500 mt-0.5">
                      Locked: Requires GP Partner or Independent Pharmacist prescriber.
                    </div>
                  }
                </div>

                <div class="p-2.5 bg-slate-50 rounded-lg">
                  <div class="font-semibold text-slate-800">3. Simulated EPS & Dispensing</div>
                  @if (req.simulatedTransmission; as tx) {
                    <div class="font-mono text-slate-900 mt-0.5">{{ tx.transmissionId }}</div>
                    <div class="text-amber-900 font-semibold mt-0.5">{{ tx.label }}</div>
                    <div class="text-slate-600">Status: {{ tx.dispensingStatus }}</div>
                  } @else {
                    <div class="text-slate-500 mt-0.5">Not transmitted</div>
                  }
                </div>
              </div>
            </div>
          }
        </div>

        <!-- Active Patient Repeat Authorisations -->
        <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <h2 class="text-base font-bold text-slate-900">
            Repeat Authorisations for {{ patientName(api.activePatientId()) }}
          </h2>
          <div class="divide-y divide-slate-100 text-xs">
            @for (auth of activePatientAuthorisations(); track auth.id) {
              <div class="py-3 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div class="font-semibold text-slate-900">{{ auth.drugName }}</div>
                  <div class="text-slate-600">
                    {{ auth.doseInstruction }} · Authorised by {{ auth.authorisedBy }}
                  </div>
                </div>
                <div class="text-right font-mono tabular-nums text-slate-700">
                  <div>Issues: {{ auth.issuesUsed }} / {{ auth.maxIssues }}</div>
                  <div class="text-slate-500">Review: {{ auth.reviewDate }}</div>
                </div>
              </div>
            } @empty {
              <p class="py-4 text-slate-500">No repeat authorisations on record for this patient.</p>
            }
          </div>
        </div>
      </div>
    }
  `,
})
export class PrescriptionsView {
  protected readonly api = inject(PracticeApi);
  protected readonly ws = this.api.workspace;
  protected readonly decisionTargetId = signal<string | null>(null);

  protected readonly decideForm = new FormGroup({
    decision: new FormControl<'approved' | 'rejected'>('approved', {nonNullable: true}),
    reason: new FormControl('', {nonNullable: true, validators: [Validators.required]}),
  });

  protected readonly activePatientAuthorisations = computed(() =>
    (this.ws()?.repeatAuthorisations ?? []).filter(
      (a) => a.patientId === this.api.activePatientId(),
    ),
  );

  protected patientName(id: string): string {
    const p = this.ws()?.patients.find((x) => x.internalId === id);
    return p ? `${p.firstName} ${p.lastName} (${id})` : id;
  }

  protected async adminCheck(requestId: string): Promise<void> {
    await this.api.adminCheckRepeat(requestId);
    this.api.notify('success', `Admin check recorded for ${requestId}.`);
  }

  protected async submitDecision(requestId: string, patientId: string): Promise<void> {
    if (this.decideForm.invalid) return;
    const {decision, reason} = this.decideForm.getRawValue();
    try {
      await this.api.decideRepeat(requestId, patientId, decision, reason);
      this.decideForm.patchValue({reason: ''});
      this.decisionTargetId.set(null);
      this.api.notify(
        'success',
        decision === 'approved'
          ? `Approved ${requestId} (simulated transmission only — no real prescription issued).`
          : `Rejected ${requestId} with reason.`,
      );
    } catch (err) {
      const msg =
        err && typeof err === 'object' && 'error' in err
          ? (err as {error?: {error?: string}}).error?.error || 'Decision failed'
          : 'Decision failed';
      this.api.notify('error', msg);
    }
  }
}
