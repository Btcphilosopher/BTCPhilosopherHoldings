// Minimal typings for the pre-built Plotly bundle. Only the calls used by <Plot> are declared.
declare module "plotly.js-dist-min" {
  export type PlotData = Record<string, unknown>;
  export type PlotLayout = Record<string, unknown>;
  export type PlotConfig = Record<string, unknown>;
  export interface PlotlyStatic {
    react(root: HTMLElement, data: PlotData[], layout?: PlotLayout, config?: PlotConfig): Promise<HTMLElement>;
    purge(root: HTMLElement): void;
    Plots: { resize(root: HTMLElement): void };
  }
  const Plotly: PlotlyStatic;
  export default Plotly;
}
