// Response shapes of the TERTIUSMEDICO API (see backend/tertius/api/routers/*.py).
// Only the fields the interface reads are typed; everything else is kept as unknown.

export type Json = null | boolean | number | string | Json[] | { [k: string]: Json };
export type Role = "researcher" | "reviewer" | "admin";

export interface Me {
  id: number;
  username: string;
  full_name: string;
  is_admin: boolean;
}

export interface ProjectListItem {
  id: number;
  code: string;
  name: string;
  description: string;
  role: Role;
  synthetic: boolean;
  confidential: boolean;
}

export interface ProjectSummary {
  id: number;
  code: string;
  name: string;
  role: Role;
  synthetic: boolean;
  materials: number;
  experiments_by_state: Record<string, number>;
  model_runs: number;
}

export interface Member {
  username: string;
  full_name: string;
  role: Role;
}

// ------------------------------------------------------------------ materials
export type PropertySource = "supplier_specification" | "literature" | "laboratory_measurement" | "model_estimate";

export interface MaterialProperty {
  name: string;
  source: PropertySource;
  value: number | null;
  unit: string | null;
  text: string | null;
  reference: string | null;
  method: string | null;
  uncertainty: number | null;
  recorded_on: string | null;
}

export interface MaterialContent {
  material_id: string;
  name: string;
  version: number;
  supplier: string | null;
  grade: string | null;
  lot: string | null;
  identity_reference: string | null;
  composition: Record<string, unknown> | null;
  purity_or_assay: MaterialProperty | null;
  physical_properties: MaterialProperty[];
  storage_requirements: string | null;
  expiry_or_retest_date: string | null;
  hazard_document_references: string[];
  source: string | null;
  verification_status: "unverified" | "identity_confirmed" | "verified" | "rejected";
  fictional: boolean;
}

export interface MaterialListItem {
  material_id: string;
  current_version: number;
  content: MaterialContent;
  content_hash: string;
  updated_at: string;
}

export interface MaterialVersion {
  version: number;
  content: MaterialContent;
  content_hash: string;
  change_note: string;
  created_by: string;
  created_at: string;
}

export interface MaterialHistory {
  material_id: string;
  current_version: number;
  versions: MaterialVersion[];
}

export interface MaterialRegistered {
  material_id: string;
  version: number;
  content_hash: string;
  missing_properties: string[];
}

// ------------------------------------------------------------------ formulations
export type FormulationStatus = "draft" | "in_review" | "approved" | "superseded";

export interface FormulationListItem {
  formulation_id: string;
  name: string;
  family: string | null;
  revisions: {
    revision: number;
    status: FormulationStatus;
    content_hash: string;
    valid: boolean | null;
    approved_by: string | null;
  }[];
}

export interface QuantityJson {
  value: number;
  unit: string;
}

export interface Ingredient {
  material_id: string;
  material_version?: number;
  role: string;
  amount: QuantityJson;
  lot?: string | null;
}

export interface Stage {
  order: number;
  name: string;
  equipment_id?: string;
  additions?: string[];
  parameters?: Record<string, QuantityJson>;
  duration?: QuantityJson;
}

export interface ValidationIssue {
  severity: "error" | "warning" | "info";
  code: string;
  message: string;
  subject: string | null;
}

export interface BatchQuantity {
  material_id: string;
  mass_g?: number | null;
  volume_mL?: number | null;
  note: string;
  status: "calculated" | "unresolved" | string;
}

export interface Validation {
  ok: boolean;
  issues: ValidationIssue[];
  calculated: {
    composition_total?: number;
    batch_quantities?: BatchQuantity[];
  };
}

export interface FormulationRevision {
  formulation_id: string;
  revision: number;
  status: FormulationStatus;
  content: {
    name?: string;
    dosage_form?: string;
    basis?: string;
    family?: string;
    target_batch_size?: QuantityJson;
    ingredients?: Ingredient[];
    stages?: Stage[];
    targets?: { name: string; unit: string; lower?: number; upper?: number; method?: string }[];
    evidence?: string[];
  };
  content_hash: string;
  validation: Validation | null;
  created_by: string;
  approved_by: string | null;
  approved_at: string | null;
}

// ------------------------------------------------------------------ domains & designs
export interface ProcessRange {
  name: string;
  lower: number | null;
  upper: number | null;
  unit: string;
  source: string;
}

export interface CompatibilityRecord {
  a: string;
  b: string;
  status: "compatible" | "incompatible" | "unknown" | string;
  source: string;
  reviewed: boolean;
}

export interface DomainContent {
  name: string;
  version: number;
  components: string[];
  bounds: Record<string, [number, number]>;
  total: number;
  excluded: string[];
  required: string[];
  min_inclusion: number;
  groups: { name: string; members: string[]; lower: number | null; upper: number | null }[];
  ratios: { numerator?: string; denominator?: string; lower?: number; upper?: number }[];
  process: Record<string, ProcessRange>;
  equipment: { equipment_id: string; parameter: string; lower: number | null; upper: number | null; unit: string }[];
  compatibility: CompatibilityRecord[];
  unknown_compatibility_policy: string;
  prices: Record<string, { component: string; amount: number; currency: string; per_unit: string; price_date: string }>;
  cost_limit: { max_cost: number; currency: string; per_unit: string } | null;
  information: unknown[];
}

export interface Feasibility {
  feasible: boolean;
  blocked: boolean;
  explanations: string[];
  conflicting_constraints: { name: string; kind: string; expression: string }[];
  feasible_ranges: Record<string, [number, number]>;
  process_ranges: Record<string, ProcessRange>;
  missing_information: string[];
  warnings: string[];
}

export interface Domain {
  id: number;
  name: string;
  version: number;
  status: "draft" | "approved" | string;
  content: DomainContent;
  feasibility: Feasibility;
  approved_by: string | null;
}

export interface Budget {
  runs: number;
  distinct_blends: number;
  replicates: number;
  controls: number;
  estimated_cost: number;
  currency: string;
}

export interface DesignListItem {
  id: number;
  domain_id: number;
  budget: Budget;
  created_at: string;
}

export type DesignRun = Record<string, number | string>;

export interface Design {
  id: number;
  domain_id: number;
  spec: Record<string, unknown>;
  runs: DesignRun[];
  coverage: {
    fill_distance_max?: number;
    fill_distance_p95?: number;
    min_pairwise_distance?: number;
    distinct_blends?: number;
    per_component?: Record<
      string,
      { design_min: number; design_max: number; domain_min: number; domain_max: number; range_covered_fraction: number }
    >;
    [k: string]: unknown;
  };
  limitations: string[];
  budget: Budget;
  rationale: string;
}

// ------------------------------------------------------------------ experiments
export type ExperimentState =
  | "draft"
  | "scientific_review"
  | "approved_for_experiment"
  | "performed"
  | "data_reviewed"
  | "accepted"
  | "rejected"
  | "superseded";

export interface ExperimentListItem {
  code: string;
  title: string;
  state: ExperimentState;
  revision: number;
  runs: number;
  approved_by: string | null;
  created_by: string;
  proposal_pk: number | null;
}

export interface ExperimentRevision {
  revision: number;
  state: ExperimentState;
  plan: Record<string, unknown> & { runs?: Record<string, unknown>[] };
  plan_hash: string;
  submitted_by: string | null;
  approved_by: string | null;
  approved_at: string | null;
  performed: Record<string, unknown> | null;
  data_reviewed_by: string | null;
  decision_reason: string | null;
}

export interface QualityFinding {
  severity: "info" | "warning" | "error";
  code: string;
  message: string;
  rows: string[];
}

export interface ExperimentDetail {
  code: string;
  title: string;
  state: ExperimentState;
  current_revision: number;
  revisions: ExperimentRevision[];
  deviations: { description: string; impact: string; recorded_by: string; created_at: string }[];
  quality_findings: QualityFinding[];
}

// ------------------------------------------------------------------ measurements
export interface Measurement {
  measurement_id: string;
  experiment: string;
  experiment_state: string;
  run_id: string;
  target: string;
  value: number | null;
  unit: string;
  status: "ok" | "failed" | "censored" | string;
  batch_id: string | null;
  lot_ids: string | null;
  block: string | null;
  role: string | null;
  replicate_group: string;
  mixture: Record<string, number>;
  process: Record<string, number>;
  measured_on: string;
  label: "MEASURED";
}

export interface ExperimentMeasurement {
  measurement_id: string;
  failure_reason: string | null;
  replicate: number;
  method: string | null;
}

export interface TargetDef {
  name: string;
  version: number;
  spec: {
    name: string;
    unit: string;
    method: string;
    horizon: string;
    log_transform: boolean;
    kind: "regression" | "classification";
    description: string;
  };
  supported_domain: string;
}

// ------------------------------------------------------------------ models
export interface CoverageLevel {
  nominal: number;
  empirical: number;
  mean_width_model_scale: number;
}

export interface RegressionResult {
  inner_cv_mae_model_scale: number;
  test: { mae: number; rmse: number; mae_model_scale: number; r2_model_scale: number; n_test: number };
  coverage: Record<string, CoverageLevel>;
  model: {
    name: string;
    family: string;
    uncertainty_method: string;
    noise_sd_model_scale?: number;
    conformal_factor?: number;
    raw_gaussian_coverage_at_nominal?: number;
    kernel?: string;
    fit_warnings?: string[];
  };
}

export interface ClassificationResult {
  brier: number;
  log_loss: number;
  ece_10bin: number;
  n_test: number;
  n_events_test: number;
}

export type ModelResult = RegressionResult | ClassificationResult;

export function isRegressionResult(r: ModelResult): r is RegressionResult {
  return (r as RegressionResult).test !== undefined;
}

export interface ModelListItem {
  id: number;
  target: string;
  selected_model: string;
  status: string;
  manifest_hash: string;
  created_at: string;
  created_by: string;
  results: Record<string, ModelResult> | null;
  warnings: string[] | null;
}

export interface Manifest {
  kind: "regression" | "classification";
  config: Record<string, unknown> & { target?: { unit?: string; log_transform?: boolean; method?: string } };
  dataset_sha256: string;
  n_rows_target?: number;
  n_used: number;
  exclusions: {
    status: string;
    count: number;
    reason: string;
    measurement_ids?: string[];
    failure_reasons?: Record<string, number>;
  }[];
  split: Record<string, unknown>;
  selected_model: string;
  selection_rule: string;
  calibration_status?: string;
  variability?: {
    pooled_replicate_sd_model_scale?: { sd: number | null; dof: number; groups: number; scale: string };
    gp_noise_sd_model_scale?: number | null;
    note?: string;
  };
  applicability_domain?: Record<string, unknown>;
  warnings: string[];
  claims?: string;
  versions?: Record<string, string>;
  manifest_sha256: string;
  results: Record<string, ModelResult>;
}

export interface ModelDetail {
  id: number;
  target: string;
  status: string;
  manifest: Manifest;
  artifact_sha256: string;
  dataset_id: number;
}

// ------------------------------------------------------------------ optimisation
export interface IntervalPrediction {
  mean: number;
  lower: number;
  upper: number;
  interval: string;
  unit: string;
  model: string;
  label: "PREDICTED";
  model_sd_model_scale: number | null;
  noise_sd_model_scale: number | null;
  scale: string;
}

export interface ScorePrediction {
  score: number;
  label: "PREDICTED";
  calibration_status?: string;
}

export type Prediction = IntervalPrediction | ScorePrediction;

export function isIntervalPrediction(p: Prediction): p is IntervalPrediction {
  return (p as IntervalPrediction).mean !== undefined;
}

export interface ConstraintCheck {
  name: string;
  status: "pass" | "fail" | "flag" | string;
  hard: boolean;
  detail: string;
}

export interface DomainAssessment {
  flags: string[];
  abstain: boolean;
  reasons: string[];
  knn_distance: number | null;
  knn_threshold: number | null;
  extrapolation: Record<string, number>;
}

export interface CalculatedValue {
  value: number;
  unit: string;
  label: "CALCULATED";
  basis: string;
}

export interface Neighbour {
  run_id: string;
  replicate_group: string;
  normalised_distance: number;
  observed_mean: number;
  n_replicates: number;
  target: string;
  unit: string;
  label: "MEASURED";
}

export interface Proposal {
  id: number;
  code: string;
  status: string;
  reviewed_by: string | null;
  review_reason: string | null;
  proposal_id: string;
  composition: Record<string, number>;
  process: Record<string, number>;
  predictions: Record<string, Prediction>;
  calculated: Record<string, CalculatedValue>;
  objective_values: Record<string, number>;
  constraint_checks: ConstraintCheck[];
  domain: DomainAssessment;
  neighbourhood: Neighbour[];
  reason: string;
  strategy: string;
  pareto_rank: number | null;
  warnings: string[];
}

export interface Objective {
  name: string;
  direction: "min" | "max" | "target_range";
  unit: string;
  source: "prediction" | "calculation";
  target: string | null;
  low: number | null;
  high: number | null;
  log_scale?: boolean;
  description: string;
}

export interface FrontierPoint {
  composition: Record<string, number>;
  process: Record<string, number>;
  objective_values: Record<string, number>;
  origin: string;
}

export interface ProposalBatch {
  batch_id: number;
  created_at: string;
  created_by: string;
  frontier: FrontierPoint[];
  stats: Record<string, number>;
  objectives: Objective[];
  notice: string;
  model_runs: number[];
  warnings: string[];
  strategy: string;
  proposals: Proposal[];
}

export interface CandidateEvaluation {
  prediction_id: number;
  composition: Record<string, number>;
  process: Record<string, number>;
  admissible: boolean;
  constraint_checks: ConstraintCheck[];
  domain: DomainAssessment;
  abstained: boolean;
  predictions: Record<string, Prediction>;
  calculated: Record<string, CalculatedValue>;
  decision: "rejected" | "abstained" | "evaluated" | string;
  reasons?: string[];
  neighbourhood?: Neighbour[];
  warnings: string[];
  model_runs: number[];
}

// ------------------------------------------------------------------ stability
export interface Forecast {
  time: number[];
  mean: number[];
  ci_lower: number[];
  ci_upper: number[];
  pi_lower: number[];
  pi_upper: number[];
  level: number;
  extrapolated: boolean[];
  label: string;
}

export interface Trend {
  key: Record<string, string | number>;
  attribute: string;
  unit: string;
  n: number;
  slope_per_month: number;
  intercept: number;
  se_slope: number;
  resid_sd: number;
  r2: number;
  max_time_months: number;
  excluded: string[];
  observations: { time: number; value: number; label: string }[];
  forecast: Forecast | { refused: string };
  exploratory_limit_crossing?: { crossing_time: number | null; extrapolated: boolean; label: string; message: string };
}

export interface Poolability {
  packaging?: string;
  condition?: string;
  testable: boolean;
  F?: number;
  p_value?: number;
  levels?: string[];
  alpha?: number;
  slopes_poolable?: boolean;
  label?: string;
  note?: string;
  reason?: string;
}

export interface StabilityTrends {
  trends: Trend[];
  poolability?: Poolability[];
  poolability_example: {
    testable: boolean;
    F?: number;
    p_value?: number;
    levels?: string[];
    alpha?: number;
    slopes_poolable?: boolean;
    label?: string;
    note?: string;
    reason?: string;
  } | null;
  censored_count: number;
  notice: string;
}

// ------------------------------------------------------------------ simulation
export interface SimulationResult {
  label: string;
  inputs: Record<string, number>;
  assumptions: { name: string; value: number; unit: string; uncertainty_sd: number; basis: string }[];
  outputs: Record<string, { p05: number; median: number; p95: number }>;
  flags: string[];
  limitations: string[];
}

// ------------------------------------------------------------------ reports, lineage, audit
export interface ReportTable {
  caption: string;
  rows: Record<string, unknown>[];
}

export interface ReportSection {
  title: string;
  label?: string;
  text?: string[];
  warnings?: string[];
  tables?: ReportTable[];
}

export interface Report {
  meta: { project: string; generated_by: string; generated_at: string; content_sha256: string };
  banner: string;
  [section: string]: unknown;
}

export interface ReportResponse {
  report: Report;
  html_key: string;
}

export interface Lineage {
  node: string;
  upstream: { kind: string; ref: string }[];
  edges: { parent: string; child: string; relation: string }[];
  chain: string[];
  missing_links: string[];
}

export interface AuditEntry {
  id: number;
  ts: string;
  actor: string;
  action: string;
  entity_type: string;
  entity_id: string;
  detail: Record<string, unknown> | null;
  hash: string;
}
