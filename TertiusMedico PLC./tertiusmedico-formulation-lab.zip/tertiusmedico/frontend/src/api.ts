// Typed fetch client for the TERTIUSMEDICO API. All requests use the relative /api base so the
// same bundle works behind the Vite proxy (dev) and the nginx proxy (production).
import type {
  AuditEntry,
  CandidateEvaluation,
  Design,
  DesignListItem,
  Domain,
  ExperimentDetail,
  ExperimentListItem,
  ExperimentMeasurement,
  FormulationListItem,
  FormulationRevision,
  Lineage,
  MaterialHistory,
  MaterialListItem,
  MaterialRegistered,
  Me,
  Measurement,
  Member,
  ModelDetail,
  ModelListItem,
  ProjectListItem,
  ProjectSummary,
  ProposalBatch,
  ReportResponse,
  SimulationResult,
  StabilityTrends,
  TargetDef,
} from "./types";

const BASE = "/api";
const TOKEN_KEY = "tertius.token";
export const UNAUTHORIZED_EVENT = "tertius:unauthorized";

let memoryToken: string | null = null;

export function getToken(): string | null {
  try {
    return window.sessionStorage.getItem(TOKEN_KEY) ?? memoryToken;
  } catch {
    return memoryToken;
  }
}

export function setToken(token: string | null): void {
  memoryToken = token;
  try {
    if (token) window.sessionStorage.setItem(TOKEN_KEY, token);
    else window.sessionStorage.removeItem(TOKEN_KEY);
  } catch {
    /* storage unavailable: keep the in-memory token only */
  }
}

/** An error returned by the server, with its HTTP status and the server's own message. */
export class ApiError extends Error {
  status: number;
  detail: unknown;
  constructor(status: number, message: string, detail: unknown) {
    super(message);
    this.status = status;
    this.detail = detail;
  }
}

function describeDetail(detail: unknown): string {
  if (detail == null) return "";
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    // FastAPI validation errors: [{loc, msg, type}]
    return detail
      .map((d) => {
        if (d && typeof d === "object" && "msg" in d) {
          const loc = Array.isArray((d as { loc?: unknown[] }).loc) ? (d as { loc: unknown[] }).loc.join(".") : "";
          return `${loc ? loc + ": " : ""}${String((d as { msg: unknown }).msg)}`;
        }
        return JSON.stringify(d);
      })
      .join("; ");
  }
  if (typeof detail === "object" && detail !== null && "message" in detail) {
    return String((detail as { message: unknown }).message);
  }
  return JSON.stringify(detail);
}

interface RequestOptions {
  method?: "GET" | "POST" | "PUT";
  json?: unknown;
  form?: URLSearchParams;
  query?: Record<string, string | number | undefined | null>;
  accept?: "json" | "text";
}

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  let body: BodyInit | undefined;
  if (opts.json !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.json);
  } else if (opts.form) {
    headers["Content-Type"] = "application/x-www-form-urlencoded";
    body = opts.form.toString();
  }
  let url = BASE + path;
  if (opts.query) {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(opts.query)) if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
    const s = q.toString();
    if (s) url += "?" + s;
  }
  let resp: Response;
  try {
    resp = await fetch(url, { method: opts.method ?? "GET", headers, body });
  } catch (e) {
    throw new ApiError(0, `network error: ${(e as Error).message}`, null);
  }
  if (!resp.ok) {
    let detail: unknown = null;
    try {
      const j = (await resp.json()) as { detail?: unknown };
      detail = j.detail ?? j;
    } catch {
      detail = resp.statusText;
    }
    if (resp.status === 401 && !path.startsWith("/auth/token")) {
      setToken(null);
      window.dispatchEvent(new CustomEvent(UNAUTHORIZED_EVENT));
    }
    const msg = describeDetail(detail) || resp.statusText || `HTTP ${resp.status}`;
    throw new ApiError(resp.status, msg, detail);
  }
  if (opts.accept === "text") return (await resp.text()) as unknown as T;
  return (await resp.json()) as T;
}

const p = (pid: number) => `/projects/${pid}`;
const enc = encodeURIComponent;

export const api = {
  // auth
  async login(username: string, password: string): Promise<string> {
    const form = new URLSearchParams({ username, password, grant_type: "password" });
    const r = await request<{ access_token: string }>("/auth/token", { method: "POST", form });
    setToken(r.access_token);
    return r.access_token;
  },
  me: () => request<Me>("/auth/me"),

  // projects
  projects: () => request<ProjectListItem[]>("/projects"),
  project: (pid: number) => request<ProjectSummary>(p(pid)),
  members: (pid: number) => request<Member[]>(`${p(pid)}/members`),

  // materials
  materials: (pid: number) => request<MaterialListItem[]>(`${p(pid)}/materials`),
  materialHistory: (pid: number, id: string) => request<MaterialHistory>(`${p(pid)}/materials/${enc(id)}`),
  registerMaterial: (pid: number, body: unknown) =>
    request<MaterialRegistered>(`${p(pid)}/materials`, { method: "POST", json: body }),

  // formulations
  formulations: (pid: number) => request<FormulationListItem[]>(`${p(pid)}/formulations`),
  formulationRevision: (pid: number, id: string, rev: number) =>
    request<FormulationRevision>(`${p(pid)}/formulations/${enc(id)}/revisions/${rev}`),
  reviewFormulation: (pid: number, id: string, rev: number, decision: "submit" | "approve" | "return", reason: string) =>
    request<{ status: string }>(`${p(pid)}/formulations/${enc(id)}/revisions/${rev}/review`, {
      method: "POST",
      json: { decision, reason: reason || null },
    }),

  // domains & designs
  domains: (pid: number) => request<Domain[]>(`${p(pid)}/domains`),
  approveDomain: (pid: number, id: number) =>
    request<{ id: number; status: string }>(`${p(pid)}/domains/${id}/approve`, { method: "POST" }),
  designs: (pid: number) => request<DesignListItem[]>(`${p(pid)}/designs`),
  design: (pid: number, id: number) => request<Design>(`${p(pid)}/designs/${id}`),
  designRationale: (pid: number) => request<{ why_not_unconstrained_sampling: string }>(`${p(pid)}/designs-rationale`),

  // experiments
  experiments: (pid: number) => request<ExperimentListItem[]>(`${p(pid)}/experiments`),
  experiment: (pid: number, code: string) => request<ExperimentDetail>(`${p(pid)}/experiments/${enc(code)}`),
  transition: (pid: number, code: string, target: string, reason: string, evidence?: Record<string, unknown>) =>
    request<{ code: string; revision: number; state: string }>(`${p(pid)}/experiments/${enc(code)}/transition`, {
      method: "POST",
      json: { target, reason: reason || null, evidence: evidence ?? null },
    }),
  experimentMeasurements: (pid: number, code: string) =>
    request<ExperimentMeasurement[]>(`${p(pid)}/experiments/${enc(code)}/measurements`),

  // measurements & targets
  measurements: (pid: number, target?: string) =>
    request<Measurement[]>(`${p(pid)}/measurements`, { query: { target } }),
  targets: (pid: number) => request<TargetDef[]>(`${p(pid)}/targets`),

  // models
  models: (pid: number) => request<ModelListItem[]>(`${p(pid)}/models`),
  model: (pid: number, id: number) => request<ModelDetail>(`${p(pid)}/models/${id}`),

  // optimisation
  proposals: (pid: number) => request<ProposalBatch[]>(`${p(pid)}/proposals`),
  reviewProposal: (pid: number, id: number, decision: "accept" | "reject", reason: string, replicates: number) =>
    request<{ id: number; code: string; status: string; experiment_code: string | null }>(
      `${p(pid)}/proposals/${id}/review`,
      { method: "POST", json: { decision, reason, replicates } },
    ),
  generateProposals: (pid: number, body: { domain_id: number; n: number; strategy: "baseline" | "bayesian" }) =>
    request<ProposalBatch>(`${p(pid)}/proposals`, { method: "POST", json: body }),
  evaluateCandidate: (
    pid: number,
    body: { domain_id: number; composition: Record<string, number>; process: Record<string, number> },
  ) => request<CandidateEvaluation>(`${p(pid)}/candidates/evaluate`, { method: "POST", json: body }),

  // stability & simulation
  stabilityTrends: (pid: number, attribute: string, formulationId: string, specLimit?: number | null) =>
    request<StabilityTrends>(`${p(pid)}/stability/trends`, {
      query: { attribute, formulation_id: formulationId, spec_limit: specLimit ?? undefined },
    }),
  simulateProcess: (pid: number, body: Record<string, number>) =>
    request<SimulationResult>(`${p(pid)}/simulations/process`, { method: "POST", json: body }),

  // reports, lineage, audit
  report: (pid: number, body: { proposal_batch_id: number | null; stability_formulation: string | null }) =>
    request<ReportResponse>(`${p(pid)}/reports`, { method: "POST", json: body }),
  reportHtml: (pid: number, body: { proposal_batch_id: number | null; stability_formulation: string | null }) =>
    request<string>(`${p(pid)}/reports/html`, { method: "POST", json: body, accept: "text" }),
  lineage: (pid: number, kind: string, ref: string) => request<Lineage>(`${p(pid)}/lineage`, { query: { kind, ref } }),
  audit: (pid: number, limit = 200) => request<AuditEntry[]>(`${p(pid)}/audit`, { query: { limit } }),
};
