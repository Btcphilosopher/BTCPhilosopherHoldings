import { useEffect, useRef, useState } from "react";
import type { PlotConfig, PlotData, PlotLayout, PlotlyStatic } from "plotly.js-dist-min";
import { useColorScheme } from "../hooks";

// Plotly is large; load it once, on first use, into its own chunk.
let plotlyPromise: Promise<PlotlyStatic> | null = null;
function loadPlotly(): Promise<PlotlyStatic> {
  if (!plotlyPromise) plotlyPromise = import("plotly.js-dist-min").then((m) => m.default);
  return plotlyPromise;
}

export interface ChartColors {
  measured: string;
  predicted: string;
  calculated: string;
  warning: string;
  error: string;
  ink: string;
  ink2: string;
  muted: string;
  line: string;
  surface: string;
  nav: string;
  approved: string;
}

/** Reads the semantic colour tokens from :root so charts follow light/dark mode. */
export function chartColors(): ChartColors {
  const cs = getComputedStyle(document.documentElement);
  const v = (n: string, fb: string) => cs.getPropertyValue(n).trim() || fb;
  return {
    measured: v("--measured", "#0f8b8d"),
    predicted: v("--predicted", "#6d4bd1"),
    calculated: v("--calculated", "#5a6577"),
    warning: v("--warning", "#b7791f"),
    error: v("--error", "#b42318"),
    ink: v("--ink", "#1a2233"),
    ink2: v("--ink-2", "#3f4a5e"),
    muted: v("--muted", "#667086"),
    line: v("--line", "#dde3ee"),
    surface: v("--surface", "#ffffff"),
    nav: v("--nav-bg", "#0f1a3a"),
    approved: v("--approved-line", "#1f7a54"),
  };
}

/** Readable ticks for a log axis (1-2-5 sequence) instead of Plotly's crowded minor digits. */
export const LOG_TICKS = { tickmode: "array", tickvals: [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000] };

/** Hex colour with alpha, for bands. */
export function alpha(hex: string, a: number): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return hex;
  const n = parseInt(m[1], 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
}

function baseLayout(c: ChartColors): PlotLayout {
  const axis = {
    gridcolor: c.line,
    zerolinecolor: c.line,
    linecolor: c.line,
    tickcolor: c.line,
    tickfont: { color: c.muted, size: 11 },
    title: { font: { color: c.ink2, size: 12 } },
    automargin: true,
  };
  return {
    paper_bgcolor: c.surface,
    plot_bgcolor: c.surface,
    font: { family: "Inter, system-ui, -apple-system, Segoe UI, sans-serif", size: 12, color: c.ink },
    margin: { l: 56, r: 16, t: 28, b: 48 },
    xaxis: axis,
    yaxis: axis,
    legend: { orientation: "h", y: -0.2, font: { size: 11, color: c.ink2 } },
    hoverlabel: { bgcolor: c.surface, bordercolor: c.line, font: { color: c.ink, size: 12 } },
  };
}

function isObj(x: unknown): x is Record<string, unknown> {
  return typeof x === "object" && x !== null && !Array.isArray(x);
}

function merge(a: Record<string, unknown>, b: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...a };
  for (const [k, v] of Object.entries(b)) out[k] = isObj(v) && isObj(out[k]) ? merge(out[k] as Record<string, unknown>, v) : v;
  // propagate axis styling to xaxis2.., yaxis2..
  return out;
}

/**
 * Thin wrapper around Plotly.react / Plotly.purge.
 * `build` receives the current colour tokens so traces can use them (re-run on theme change).
 */
export function Plot({
  build,
  height = 360,
  deps,
  ariaLabel,
  config,
}: {
  build: (c: ChartColors) => { data: PlotData[]; layout?: PlotLayout };
  height?: number;
  deps: unknown[];
  ariaLabel: string;
  config?: PlotConfig;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const scheme = useColorScheme();
  const buildRef = useRef(build);
  buildRef.current = build;

  useEffect(() => {
    let alive = true;
    const el = ref.current;
    if (!el) return;
    loadPlotly()
      .then((Plotly) => {
        if (!alive || !ref.current) return;
        const c = chartColors();
        const { data, layout } = buildRef.current(c);
        const base = baseLayout(c);
        let merged = merge(base, { height, ...(layout ?? {}) });
        // style every extra axis like the base axes
        for (const k of Object.keys(merged)) {
          if (/^[xy]axis\d+$/.test(k) && isObj(merged[k])) {
            merged = { ...merged, [k]: merge(base[k.startsWith("x") ? "xaxis" : "yaxis"] as Record<string, unknown>, merged[k] as Record<string, unknown>) };
          }
        }
        return Plotly.react(el, data, merged, {
          displaylogo: false,
          responsive: true,
          modeBarButtonsToRemove: ["lasso2d", "select2d"],
          ...(config ?? {}),
        }).then(() => {
          if (alive) setReady(true);
        });
      })
      .catch((e: unknown) => setErr(String(e)));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, scheme, height]);

  // purge on unmount; resize with container
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      if (plotlyPromise && el.childElementCount) plotlyPromise.then((P) => P.Plots.resize(el)).catch(() => undefined);
    });
    ro.observe(el);
    return () => {
      ro.disconnect();
      if (plotlyPromise) plotlyPromise.then((P) => P.purge(el)).catch(() => undefined);
    };
  }, []);

  return (
    <div className="plot" style={{ minHeight: height }} role="img" aria-label={ariaLabel}>
      <div ref={ref} style={{ width: "100%" }} />
      {!ready && !err && <div className="plot-loading">Rendering chart…</div>}
      {err && <div className="plot-loading">Chart failed to render: {err}</div>}
    </div>
  );
}
