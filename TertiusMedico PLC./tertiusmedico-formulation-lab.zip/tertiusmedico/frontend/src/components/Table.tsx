import type { ReactNode } from "react";

export interface Column<T> {
  key: string;
  header: ReactNode;
  render?: (row: T, index: number) => ReactNode;
  className?: string;
  headerClassName?: string;
  width?: number | string;
  title?: string;
}

/** Dense data table. Scrolls inside its own container; header is sticky. */
export function Table<T>({
  columns,
  rows,
  rowKey,
  onRowClick,
  selectedKey,
  rowClassName,
  maxHeight,
  empty = "No records.",
  caption,
}: {
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T, index: number) => string;
  onRowClick?: (row: T) => void;
  selectedKey?: string | null;
  rowClassName?: (row: T) => string | undefined;
  maxHeight?: number | string;
  empty?: ReactNode;
  caption?: ReactNode;
}) {
  return (
    <div className="table-wrap" style={maxHeight ? { maxHeight } : undefined}>
      <table className="data">
        {caption && <caption className="muted small" style={{ textAlign: "left", padding: "6px 9px" }}>{caption}</caption>}
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} className={c.headerClassName ?? c.className} style={c.width ? { width: c.width } : undefined} title={c.title}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 && (
            <tr>
              <td className="empty" colSpan={columns.length}>
                {empty}
              </td>
            </tr>
          )}
          {rows.map((r, i) => {
            const k = rowKey(r, i);
            const cls = [onRowClick ? "clickable" : "", selectedKey === k ? "selected" : "", rowClassName?.(r) ?? ""]
              .filter(Boolean)
              .join(" ");
            return (
              <tr
                key={k}
                className={cls || undefined}
                onClick={onRowClick ? () => onRowClick(r) : undefined}
                tabIndex={onRowClick ? 0 : undefined}
                onKeyDown={
                  onRowClick
                    ? (e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          onRowClick(r);
                        }
                      }
                    : undefined
                }
                aria-selected={onRowClick ? selectedKey === k : undefined}
              >
                {columns.map((c) => (
                  <td key={c.key} className={c.className}>
                    {c.render ? c.render(r, i) : String((r as Record<string, unknown>)[c.key] ?? "—")}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/** Renders an arbitrary JSON-ish cell (report tables, audit details). */
export function CellValue({ v }: { v: unknown }) {
  if (v === null || v === undefined) return <span className="muted">—</span>;
  if (typeof v === "boolean") return <span>{v ? "true" : "false"}</span>;
  if (typeof v === "number") return <span className="num">{Number.isInteger(v) ? v : Number(v.toPrecision(4))}</span>;
  if (typeof v === "string") {
    if (/^[0-9a-f]{12,64}$/.test(v)) return <span className="hash" title={v}>{v.length > 16 ? v.slice(0, 16) + "…" : v}</span>;
    return <span>{v}</span>;
  }
  if (Array.isArray(v) && v.every((x) => typeof x === "string")) {
    return <span>{(v as string[]).join("; ") || <span className="muted">—</span>}</span>;
  }
  const s = JSON.stringify(v);
  return (
    <span className="mono small" title={s} style={{ overflowWrap: "anywhere" }}>
      {s.length > 240 ? s.slice(0, 240) + "…" : s}
    </span>
  );
}

/** Generic table for an array of records with unknown columns. */
export function RecordTable({ rows, maxHeight = 360, caption }: { rows: Record<string, unknown>[]; maxHeight?: number; caption?: ReactNode }) {
  const cols = Array.from(new Set(rows.flatMap((r) => Object.keys(r))));
  return (
    <Table
      caption={caption}
      maxHeight={maxHeight}
      rows={rows}
      rowKey={(_, i) => String(i)}
      columns={cols.map((c) => ({ key: c, header: c.replace(/_/g, " "), render: (r: Record<string, unknown>) => <CellValue v={r[c]} /> }))}
      empty="none"
    />
  );
}
