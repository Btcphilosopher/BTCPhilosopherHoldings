import type { ReactNode } from "react";

export function Card({
  title,
  tag,
  actions,
  children,
  accent,
  flush,
  id,
}: {
  title?: ReactNode;
  tag?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  accent?: "measured" | "predicted" | "calculated" | "simulated" | "warning";
  flush?: boolean;
  id?: string;
}) {
  return (
    <section className={`card ${accent ?? ""}`} id={id}>
      {(title || actions || tag) && (
        <header className="card-head">
          <div className="title">
            {title && <h2>{title}</h2>}
            {tag}
          </div>
          {actions && <div className="row">{actions}</div>}
        </header>
      )}
      <div className={`card-body ${flush ? "flush" : ""}`}>{children}</div>
    </section>
  );
}

export function PageHead({ title, lede, actions }: { title: ReactNode; lede?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="page-head">
      <div>
        <h1>{title}</h1>
        {lede && <p className="lede">{lede}</p>}
      </div>
      {actions && <div className="row">{actions}</div>}
    </div>
  );
}

export function Stat({ label, value, tag }: { label: ReactNode; value: ReactNode; tag?: ReactNode }) {
  return (
    <div className="stat">
      <div className="k">
        <span>{label}</span>
        {tag}
      </div>
      <div className="v">{value}</div>
    </div>
  );
}

export function KV({ items }: { items: [ReactNode, ReactNode][] }) {
  return (
    <dl className="kv">
      {items.map(([k, v], i) => (
        <div key={i} style={{ display: "contents" }}>
          <dt>{k}</dt>
          <dd>{v}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Loading({ what }: { what?: string }) {
  return <div className="spinner">Loading{what ? ` ${what}` : ""}…</div>;
}

export function Tabs<T extends string>({
  tabs,
  value,
  onChange,
}: {
  tabs: { id: T; label: ReactNode }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t) => (
        <button key={t.id} role="tab" aria-selected={t.id === value} onClick={() => onChange(t.id)}>
          {t.label}
        </button>
      ))}
    </div>
  );
}
