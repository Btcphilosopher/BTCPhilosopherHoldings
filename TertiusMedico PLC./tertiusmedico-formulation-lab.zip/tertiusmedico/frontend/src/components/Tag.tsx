import type { ReactNode } from "react";

export type TagKind =
  | "measured"
  | "calculated"
  | "predicted"
  | "simulated"
  | "approved"
  | "warning"
  | "error"
  | "info"
  | "neutral"
  | "source"
  | "outline-measured"
  | "outline-predicted";

const DEFAULT_TEXT: Partial<Record<TagKind, string>> = {
  measured: "MEASURED",
  calculated: "CALCULATED",
  predicted: "PREDICTED",
  simulated: "SIMULATED",
  approved: "APPROVED",
  warning: "WARNING",
  error: "ERROR",
};

/** Text tag that names the epistemic class of a value. Colour always comes with this text. */
export function Tag({ kind, children, title }: { kind: TagKind; children?: ReactNode; title?: string }) {
  return (
    <span className={`tag ${kind}`} title={title}>
      {kind === "approved" && <span aria-hidden="true">✓</span>}
      {kind === "warning" && <span aria-hidden="true">▲</span>}
      {kind === "error" && <span aria-hidden="true">✕</span>}
      {children ?? DEFAULT_TEXT[kind] ?? kind.toUpperCase()}
    </span>
  );
}

/** A value with its tag, tinted by class (MEASURED / CALCULATED / PREDICTED / WARNING). */
export function ValueBlock({
  kind,
  children,
  tag,
  title,
}: {
  kind: "measured" | "calculated" | "predicted" | "warning";
  children: ReactNode;
  tag?: ReactNode;
  title?: string;
}) {
  return (
    <span className={`vb ${kind}`} title={title}>
      <span className="val">{children}</span>
      <Tag kind={kind}>{tag}</Tag>
    </span>
  );
}

const STATUS_KIND: Record<string, TagKind> = {
  approved: "approved",
  approved_for_use: "approved",
  approved_for_experiment: "info",
  accepted: "approved",
  accepted_for_planning: "approved",
  verified: "approved",
  identity_confirmed: "info",
  in_review: "info",
  scientific_review: "info",
  performed: "info",
  data_reviewed: "info",
  draft: "neutral",
  proposed: "neutral",
  evaluated: "neutral",
  superseded: "neutral",
  retired: "neutral",
  unverified: "warning",
  rejected: "error",
  failed: "warning",
  censored: "warning",
  ok: "neutral",
};

/** Workflow / record status badge; APPROVED states get the dedicated approved badge. */
export function StatusBadge({ status, title }: { status: string | null | undefined; title?: string }) {
  if (!status) return <Tag kind="neutral">—</Tag>;
  const kind = STATUS_KIND[status] ?? "neutral";
  const text = status.replace(/_/g, " ").toUpperCase();
  return (
    <Tag kind={kind} title={title}>
      {text}
    </Tag>
  );
}

const SOURCE_LABEL: Record<string, { text: string; kind: TagKind }> = {
  laboratory_measurement: { text: "LAB MEASUREMENT", kind: "measured" },
  supplier_specification: { text: "SUPPLIER SPEC", kind: "source" },
  literature: { text: "LITERATURE", kind: "source" },
  model_estimate: { text: "MODEL ESTIMATE", kind: "predicted" },
};

/** Provenance of a material property value. */
export function SourceTag({ source }: { source: string }) {
  const s = SOURCE_LABEL[source] ?? { text: source.toUpperCase(), kind: "source" as TagKind };
  return <Tag kind={s.kind}>{s.text}</Tag>;
}
