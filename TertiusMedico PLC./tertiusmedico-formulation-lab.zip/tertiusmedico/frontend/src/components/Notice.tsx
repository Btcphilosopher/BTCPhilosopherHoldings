import type { ReactNode } from "react";
import { Tag } from "./Tag";

type NoticeKind = "warning" | "error" | "info" | "predicted" | "simulated";

const LABEL: Record<NoticeKind, ReactNode> = {
  warning: <Tag kind="warning" />,
  error: <Tag kind="error" />,
  info: <Tag kind="info">NOTE</Tag>,
  predicted: <Tag kind="predicted" />,
  simulated: <Tag kind="simulated" />,
};

/** A written notice. Amber warnings always carry the WARNING label, never colour alone. */
export function Notice({
  kind = "warning",
  label,
  children,
}: {
  kind?: NoticeKind;
  label?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className={`notice ${kind}`} role={kind === "error" ? "alert" : "note"}>
      <span className="notice-label">{label ?? LABEL[kind]}</span>
      <div className="notice-body">{children}</div>
    </div>
  );
}

/** A list of warning strings, each with its own written label. Renders nothing when empty. */
export function WarningList({ items, label }: { items: (string | null | undefined)[] | null | undefined; label?: string }) {
  const xs = (items ?? []).filter((x): x is string => !!x);
  if (!xs.length) return null;
  return (
    <div className="notice-list">
      {xs.map((w, i) => (
        <Notice key={i} kind="warning" label={<Tag kind="warning">{label ?? "WARNING"}</Tag>}>
          {w}
        </Notice>
      ))}
    </div>
  );
}

export function ErrorBox({ error }: { error: string | Error | null | undefined }) {
  if (!error) return null;
  const msg = typeof error === "string" ? error : error.message;
  const status = typeof error === "string" ? undefined : (error as Error & { status?: number }).status;
  return (
    <Notice kind="error" label={<Tag kind="error">{status ? `SERVER ${status}` : "ERROR"}</Tag>}>
      {msg}
    </Notice>
  );
}
