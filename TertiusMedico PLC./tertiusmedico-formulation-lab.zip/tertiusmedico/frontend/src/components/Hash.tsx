import { shortHash } from "../format";

/** Monospace hash / identifier. Truncated by default; the full value is in the title and selectable. */
export function Hash({ value, full, n = 12, label }: { value: string | null | undefined; full?: boolean; n?: number; label?: string }) {
  if (!value) return <span className="muted">—</span>;
  return (
    <span className={`hash ${full ? "full" : ""}`} title={value} aria-label={label ? `${label} ${value}` : undefined}>
      {full ? value : shortHash(value, n)}
    </span>
  );
}
