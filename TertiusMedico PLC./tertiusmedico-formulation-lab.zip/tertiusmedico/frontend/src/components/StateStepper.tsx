import type { ExperimentState } from "../types";

const STEPS: { state: ExperimentState; label: string }[] = [
  { state: "draft", label: "Draft" },
  { state: "scientific_review", label: "Scientific review" },
  { state: "approved_for_experiment", label: "Approved for experiment" },
  { state: "performed", label: "Performed" },
  { state: "data_reviewed", label: "Data reviewed" },
];

/**
 * Draft → Scientific review → Approved for experiment → Performed → Data reviewed → Accepted/Rejected.
 * Each step shows its state in words (done / current / pending) — not only colour.
 */
export function StateStepper({
  state,
  who,
  rejectedAt,
}: {
  state: ExperimentState;
  who?: Partial<Record<ExperimentState, string | null | undefined>>;
  /** for a rejection: the state the experiment was rejected from (scientific review or data review) */
  rejectedAt?: ExperimentState;
}) {
  const order = STEPS.map((s) => s.state);
  let currentIdx: number;
  if (state === "accepted" || state === "rejected") currentIdx = STEPS.length;
  else if (state === "superseded") currentIdx = -1;
  else currentIdx = order.indexOf(state);
  const rejIdx = state === "rejected" && rejectedAt ? order.indexOf(rejectedAt) : STEPS.length;

  return (
    <div>
      <ol className="stepper" aria-label="experiment workflow">
        {STEPS.map((s, i) => {
          const skipped = state === "rejected" && i > rejIdx;
          const status = skipped ? "not reached" : i < currentIdx ? "done" : i === currentIdx ? "current" : "pending";
          const cls = status === "done" ? "done" : status === "current" ? "current" : "";
          return (
            <li key={s.state} className={`step ${cls}`} aria-current={status === "current" ? "step" : undefined}>
              <span className="dot">{status === "done" ? "✓" : i + 1}</span>
              <span className="lbl">{s.label}</span>
              <span className="state-word">{status}</span>
              {who?.[s.state] && <span className="who">{who[s.state]}</span>}
            </li>
          );
        })}
        <li
          className={`step ${state === "accepted" ? "done terminal-accepted" : state === "rejected" ? "done terminal-rejected" : ""}`}
          aria-current={state === "accepted" || state === "rejected" ? "step" : undefined}
        >
          <span className="dot">{state === "accepted" ? "✓" : state === "rejected" ? "✕" : 6}</span>
          <span className="lbl">Accepted / Rejected</span>
          <span className="state-word">
            {state === "accepted" ? "accepted" : state === "rejected" ? "rejected" : "pending"}
          </span>
          {who?.accepted && <span className="who">{who.accepted}</span>}
        </li>
      </ol>
      {state === "superseded" && <p className="muted small">This plan revision was superseded by a newer revision.</p>}
    </div>
  );
}
