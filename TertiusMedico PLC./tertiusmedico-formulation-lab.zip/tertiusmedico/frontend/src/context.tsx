import { createContext, useContext } from "react";
import type { Me, ProjectSummary, Role } from "./types";

export interface AuthCtx {
  me: Me | null;
  logout: () => void;
}
export const AuthContext = createContext<AuthCtx>({ me: null, logout: () => undefined });
export const useAuth = () => useContext(AuthContext);

export interface ProjectCtx {
  pid: number;
  summary: ProjectSummary | undefined;
  role: Role | undefined;
  reloadSummary: () => void;
  error?: Error;
}
export const ProjectContext = createContext<ProjectCtx | null>(null);

export function useProject(): ProjectCtx {
  const c = useContext(ProjectContext);
  if (!c) throw new Error("useProject outside a project route");
  return c;
}

const LAST_KEY = "tertius.lastProject";
export function rememberProject(pid: number): void {
  try {
    window.localStorage.setItem(LAST_KEY, String(pid));
  } catch {
    /* ignore */
  }
}
export function lastProject(): number | null {
  try {
    const v = window.localStorage.getItem(LAST_KEY);
    return v ? Number(v) || null : null;
  } catch {
    return null;
  }
}
