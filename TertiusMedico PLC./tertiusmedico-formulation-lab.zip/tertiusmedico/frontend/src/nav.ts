/** Primary navigation, in the required order. */
export const NAV: { path: string; label: string }[] = [
  { path: "", label: "Projects" },
  { path: "materials", label: "Materials" },
  { path: "formulations", label: "Formulations" },
  { path: "experiments", label: "Experiments" },
  { path: "measurements", label: "Measurements" },
  { path: "models", label: "Models" },
  { path: "optimisation", label: "Optimisation" },
  { path: "stability", label: "Stability" },
  { path: "batches", label: "Batches" },
  { path: "reports", label: "Reports" },
];
