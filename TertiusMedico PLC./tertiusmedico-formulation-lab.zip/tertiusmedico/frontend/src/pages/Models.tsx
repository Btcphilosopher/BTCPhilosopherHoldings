import { useState } from "react";
import { api } from "../api";
import { Card, KV, Loading, PageHead } from "../components/Card";
import { Hash } from "../components/Hash";
import { ErrorBox, Notice, WarningList } from "../components/Notice";
import { Plot } from "../components/Plot";
import { Table } from "../components/Table";
import { StatusBadge, Tag, ValueBlock } from "../components/Tag";
import { useProject } from "../context";
import { dateTime, fmt, humanize } from "../format";
import { useAsync } from "../hooks";
import { isIntervalPrediction, isRegressionResult, type ClassificationResult, type ModelDetail, type ModelListItem, type ProposalBatch, type RegressionResult } from "../types";

const MODEL_LABEL: Record<string, string> = {
  mean_baseline: "Mean baseline",
  scheffe_ridge: "Scheffé ridge",
  random_forest: "Random forest",
  gaussian_process: "Gaussian process",
  prevalence_baseline: "Prevalence baseline",
  logistic_scheffe: "Logistic Scheffé",
};

export function ModelsPage() {
  const { pid } = useProject();
  const data = useAsync(async () => {
    const list = await api.models(pid);
    // latest run per target (list is newest first)
    const latest = new Map<string, ModelListItem>();
    list.forEach((m) => {
      if (!latest.has(m.target)) latest.set(m.target, m);
    });
    const details = await Promise.all([...latest.values()].map((m) => api.model(pid, m.id)));
    const batches = await api.proposals(pid).catch(() => [] as ProposalBatch[]);
    return { list, latest: [...latest.values()], details, batches };
  }, [pid]);

  if (data.loading && !data.data) return <Loading what="model runs" />;
  if (data.error) return <ErrorBox error={data.error} />;
  const d = data.data!;
  const order = ["viscosity", "uniformity_cv", "assay_4w_40C", "phase_separation"];
  const rank = (t: string) => (order.indexOf(t) < 0 ? 99 : order.indexOf(t));
  const runs = [...d.latest].sort((a, b) => rank(a.target) - rank(b.target));

  return (
    <div className="stack">
      <PageHead
        title="Models"
        lede="Held-out evaluation of every candidate model against MEASURED data, with baselines. Selection uses grouped inner cross-validation on training data; held-out metrics are reported, not used to choose."
      />
      <Card title="Model runs" flush>
        <Table<ModelListItem>
          rows={d.list}
          rowKey={(r) => String(r.id)}
          columns={[
            { key: "id", header: "Run", className: "mono", render: (r) => `#${r.id}` },
            { key: "t", header: "Target", render: (r) => <a href={`#target-${r.target}`}>{r.target}</a> },
            { key: "s", header: "Selected model", render: (r) => <Tag kind="outline-predicted">{MODEL_LABEL[r.selected_model] ?? r.selected_model}</Tag> },
            { key: "st", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
            { key: "w", header: "Warnings", className: "num", render: (r) => ((r.warnings ?? []).length ? <Tag kind="warning">{(r.warnings ?? []).length}</Tag> : "0") },
            { key: "by", header: "Trained by", render: (r) => <span className="small">{r.created_by} · {dateTime(r.created_at)}</span> },
            { key: "h", header: "Manifest SHA-256", render: (r) => <Hash value={r.manifest_hash} /> },
          ]}
        />
      </Card>
      {runs.map((m) => {
        const det = d.details.find((x) => x.id === m.id);
        return det ? <TargetCard key={m.id} run={m} det={det} batches={d.batches} /> : null;
      })}
    </div>
  );
}

function TargetCard({ run, det, batches }: { run: ModelListItem; det: ModelDetail; batches: ProposalBatch[] }) {
  const man = det.manifest;
  const unit = (man.config.target?.unit as string | undefined) ?? "";
  const logScale = !!man.config.target?.log_transform;
  const names = Object.keys(man.results);
  const isClass = man.kind === "classification";
  const calibrationUnvalidated = (man.calibration_status ?? "").startsWith("UNVALIDATED");
  return (
    <Card
      id={`target-${run.target}`}
      title={<>Target: {run.target} <span className="mono muted">run #{run.id}</span></>}
      tag={
        <>
          <Tag kind="info">SELECTED · {MODEL_LABEL[man.selected_model] ?? man.selected_model}</Tag>
          <StatusBadge status={det.status} />
          <Tag kind="neutral">{man.kind.toUpperCase()}</Tag>
        </>
      }
    >
      <div className="stack">
        <WarningList items={man.warnings} />
        {man.calibration_status && (
          <Notice kind={calibrationUnvalidated ? "warning" : "info"} label={<Tag kind={calibrationUnvalidated ? "warning" : "info"}>CALIBRATION {calibrationUnvalidated ? "UNVALIDATED" : ""}</Tag>}>
            {man.calibration_status}
          </Notice>
        )}
        <div>
          <div className="row spread" style={{ marginBottom: 6 }}>
            <h3>Model comparison on held-out data <Tag kind="calculated" /></h3>
            <span className="small muted">{logScale ? "MAE (model scale) is on the log scale; test MAE is in original units" : `units: ${unit}`}</span>
          </div>
          {isClass ? (
            <Table
              rows={names}
              rowKey={(n) => n}
              rowClassName={(n) => (n === man.selected_model ? "selected" : undefined)}
              columns={[
                { key: "m", header: "Model", render: (n) => <>{MODEL_LABEL[n] ?? n} {n === man.selected_model && <Tag kind="info">SELECTED</Tag>}</> },
                { key: "b", header: "Brier", className: "num", render: (n) => fmt((man.results[n] as ClassificationResult).brier) },
                { key: "l", header: "Log loss", className: "num", render: (n) => fmt((man.results[n] as ClassificationResult).log_loss) },
                { key: "e", header: "ECE (10 bins)", className: "num", render: (n) => fmt((man.results[n] as ClassificationResult).ece_10bin) },
                { key: "nt", header: "n_test", className: "num", render: (n) => (man.results[n] as ClassificationResult).n_test },
                { key: "ne", header: "events in test", className: "num", render: (n) => (man.results[n] as ClassificationResult).n_events_test },
              ]}
            />
          ) : (
            <Table
              rows={names}
              rowKey={(n) => n}
              rowClassName={(n) => (n === man.selected_model ? "selected" : undefined)}
              columns={[
                { key: "m", header: "Model", render: (n) => <>{MODEL_LABEL[n] ?? n} {n === man.selected_model && <Tag kind="info">SELECTED</Tag>}</> },
                { key: "f", header: "Family", className: "small", render: (n) => humanize((man.results[n] as RegressionResult).model?.family ?? "—") },
                { key: "cv", header: "Inner-CV MAE (model scale)", className: "num", render: (n) => fmt((man.results[n] as RegressionResult).inner_cv_mae_model_scale) },
                { key: "tm", header: `Test MAE (${unit})`, className: "num", render: (n) => fmt((man.results[n] as RegressionResult).test.mae) },
                { key: "r2", header: "Test R² (model scale)", className: "num", render: (n) => fmt((man.results[n] as RegressionResult).test.r2_model_scale) },
                { key: "nt", header: "n_test", className: "num", render: (n) => (man.results[n] as RegressionResult).test.n_test },
                { key: "c90", header: "Coverage @90 %", className: "num", render: (n) => fmt((man.results[n] as RegressionResult).coverage["0.90"]?.empirical) },
                { key: "u", header: "Uncertainty method", render: (n) => <span className="small">{(man.results[n] as RegressionResult).model?.uncertainty_method ?? "—"}</span> },
              ]}
            />
          )}
          <p className="small muted" style={{ marginTop: 6 }}>Selection rule: {man.selection_rule}</p>
        </div>
        {!isClass && <CoverageChart run={run.id} results={man.results as Record<string, RegressionResult>} selected={man.selected_model} />}
        <div className="grid-2">
          <div className="stack" style={{ gap: 8 }}>
            <h3>Data used and explicit exclusions</h3>
            <KV
              items={[
                ["Rows for target", man.n_rows_target ?? "—"],
                ["Rows used", man.n_used],
                ["Split", `${String(man.split.method ?? "—")} · train ${String(man.split.n_train ?? "—")} / test ${String(man.split.n_test ?? "—")}${man.split.n_groups_test ? ` (${String(man.split.n_groups_train)} / ${String(man.split.n_groups_test)} groups)` : ""}`],
                ["Leakage check", man.split.leakage_check ? String(man.split.leakage_check) : "—"],
                ["Experiment states", ((man.config as Record<string, unknown>).experiment_states as string[] | undefined)?.join(", ") ?? "accepted"],
              ]}
            />
            <Table
              rows={man.exclusions}
              rowKey={(_, i) => String(i)}
              empty="no exclusions"
              rowClassName={() => "row-failed"}
              columns={[
                { key: "s", header: "Status", render: (x) => <Tag kind="warning">{x.status.toUpperCase()}</Tag> },
                { key: "n", header: "Count", className: "num", render: (x) => x.count },
                { key: "r", header: "Reason", render: (x) => x.reason },
                { key: "f", header: "Failure reasons", render: (x) => Object.entries(x.failure_reasons ?? {}).map(([k, v]) => `${k} (${v})`).join("; ") || "—" },
              ]}
            />
          </div>
          <div className="stack" style={{ gap: 8 }}>
            <h3>Variability: replicates vs model</h3>
            <Variability det={det} batches={batches} />
          </div>
        </div>
        <KV
          items={[
            ["Manifest SHA-256", <Hash value={man.manifest_sha256} full />],
            ["Dataset SHA-256", <Hash value={man.dataset_sha256} full />],
            ["Artefact SHA-256", <Hash value={det.artifact_sha256} full />],
            ["Claims", <span className="small">{man.claims ?? "—"}</span>],
            ["Software", <span className="mono small">{Object.entries(man.versions ?? {}).map(([k, v]) => `${k} ${v}`).join(" · ")}</span>],
          ]}
        />
      </div>
    </Card>
  );
}

function CoverageChart({ run, results, selected }: { run: number; results: Record<string, RegressionResult>; selected: string }) {
  const names = Object.keys(results).filter((n) => isRegressionResult(results[n]));
  const [model, setModel] = useState(selected);
  const r = results[model];
  const levels = Object.keys(r?.coverage ?? {}).sort();
  const nTest = r?.test.n_test ?? 0;
  return (
    <div>
      <div className="row spread" style={{ marginBottom: 4 }}>
        <h3>Interval coverage: empirical vs nominal <Tag kind="calculated" /></h3>
        <label className="row small">
          model
          <select className="inline" value={model} onChange={(e) => setModel(e.target.value)}>
            {names.map((n) => <option key={n} value={n}>{MODEL_LABEL[n] ?? n}{n === selected ? " (selected)" : ""}</option>)}
          </select>
        </label>
      </div>
      <Plot
        ariaLabel={`coverage of prediction intervals for run ${run}`}
        height={260}
        deps={[run, model]}
        build={(c) => {
          // binomial standard error of an empirical coverage estimate on n_test points
          const se = levels.map((l) => Math.sqrt((r.coverage[l].nominal * (1 - r.coverage[l].nominal)) / Math.max(1, nTest)));
          return {
            data: [
              {
                type: "bar",
                name: "nominal level",
                x: levels.map((l) => `${Math.round(r.coverage[l].nominal * 100)} %`),
                y: levels.map((l) => r.coverage[l].nominal),
                marker: { color: c.surface, line: { color: c.ink2, width: 1.5 }, pattern: { shape: "/", fgcolor: c.muted, size: 6 } },
                hovertemplate: "nominal %{y:.2f}<extra></extra>",
              },
              {
                type: "bar",
                name: `empirical on ${nTest} held-out points`,
                x: levels.map((l) => `${Math.round(r.coverage[l].nominal * 100)} %`),
                y: levels.map((l) => r.coverage[l].empirical),
                error_y: { type: "data", array: se, color: c.warning, thickness: 1.5, width: 6, visible: true },
                marker: { color: c.calculated },
                text: levels.map((l) => r.coverage[l].empirical.toFixed(2)),
                textposition: "inside",
                insidetextanchor: "start",
                textfont: { color: c.surface, size: 11 },
                hovertemplate: "empirical %{y:.2f} (±1 SE amber)<extra></extra>",
              },
            ],
            layout: {
              barmode: "group",
              bargap: 0.3,
              bargroupgap: 0.08,
              yaxis: { range: [0, 1.15], title: { text: "fraction of test points inside interval" }, tickformat: ".1f" },
              xaxis: { title: { text: "nominal interval level" }, type: "category" },
              legend: { orientation: "h", y: 1.18, x: 0 },
              margin: { l: 60, r: 16, t: 30, b: 44 },
            },
          };
        }}
      />
      <p className="small muted">Amber whiskers: ±1 binomial standard error for {nTest} held-out points — small test sets make coverage estimates imprecise.</p>
    </div>
  );
}

function Variability({ det, batches }: { det: ModelDetail; batches: ProposalBatch[] }) {
  const v = det.manifest.variability;
  const target = det.target;
  const modelSds = batches
    .flatMap((b) => b.proposals)
    .map((p) => p.predictions[target])
    .filter((p) => p && isIntervalPrediction(p))
    .map((p) => (isIntervalPrediction(p) ? p.model_sd_model_scale : null))
    .filter((x): x is number => x !== null && x !== undefined);
  if (!v)
    return <p className="muted small">No replicate-variability record in this manifest (classification targets report calibration instead).</p>;
  const rep = v.pooled_replicate_sd_model_scale;
  return (
    <div className="stack" style={{ gap: 8 }}>
      <KV
        items={[
          ["Pooled replicate SD", rep?.sd != null ? <ValueBlock kind="measured" tag="FROM REPLICATES">{fmt(rep.sd)} ({rep.scale} scale; dof {rep.dof}, {rep.groups} groups)</ValueBlock> : <span className="not-recorded">not estimable</span>],
          ["GP noise SD", v.gp_noise_sd_model_scale != null ? <ValueBlock kind="predicted" tag="MODEL ESTIMATE">{fmt(v.gp_noise_sd_model_scale)}</ValueBlock> : <span className="not-recorded">no GP in this run</span>],
          [
            "Model (epistemic) SD",
            modelSds.length ? (
              <ValueBlock kind="predicted">{fmt(Math.min(...modelSds))} – {fmt(Math.max(...modelSds))} <span className="small">(across {modelSds.length} proposals)</span></ValueBlock>
            ) : (
              <span className="muted small">reported per prediction (not available for the selected model)</span>
            ),
          ],
        ]}
      />
      <p className="small muted">
        {v.note ??
          "Replicate SD estimates measurement + preparation repeatability; GP noise is the model's estimate of the same quantity; latent GP SD is model (epistemic) uncertainty."}
        {" "}When the GP noise SD is close to the pooled replicate SD, the model is not claiming more precision than the laboratory repeatability supports.
      </p>
    </div>
  );
}
