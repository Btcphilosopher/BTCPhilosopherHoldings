import { useState, type FormEvent } from "react";
import { api } from "../api";
import { Card, KV, Loading, PageHead } from "../components/Card";
import { Drawer } from "../components/Drawer";
import { Hash } from "../components/Hash";
import { ErrorBox, Notice, WarningList } from "../components/Notice";
import { Table } from "../components/Table";
import { SourceTag, StatusBadge, Tag } from "../components/Tag";
import { useProject } from "../context";
import { dateTime, fmt } from "../format";
import { useAction, useAsync } from "../hooks";
import type { MaterialContent, MaterialListItem, MaterialProperty, PropertySource } from "../types";

// Properties the backend checks for (density is needed for any mass↔volume conversion).
const KEY_PROPERTIES = ["density", "molar_mass", "particle_size_d50"];

function PropertyCell({ prop }: { prop: MaterialProperty | undefined }) {
  if (!prop) return <span className="not-recorded">not recorded</span>;
  return (
    <div style={{ display: "grid", gap: 2 }}>
      <span className="nowrap">
        <strong className="num">{prop.value !== null ? fmt(prop.value, 4) : prop.text ?? "—"}</strong> {prop.unit ?? ""}
        {prop.uncertainty !== null && <span className="muted"> ± {fmt(prop.uncertainty)}</span>}
      </span>
      <span><SourceTag source={prop.source} /></span>
      {(prop.reference || prop.method) && (
        <span className="muted small">{[prop.method, prop.reference].filter(Boolean).join(" · ")}</span>
      )}
    </div>
  );
}

export function MaterialsPage() {
  const { pid } = useProject();
  const materials = useAsync(() => api.materials(pid), [pid]);
  const [open, setOpen] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const extra = (c: MaterialContent) => c.physical_properties.filter((p) => !KEY_PROPERTIES.includes(p.name));

  return (
    <div className="stack">
      <PageHead
        title="Materials registry"
        lede="Versioned material records. Each property shows where its value came from; missing properties stay 'not recorded' and are never filled with default numbers."
        actions={<button className="btn primary" onClick={() => setShowForm((s) => !s)}>{showForm ? "Close form" : "Register material"}</button>}
      />
      {showForm && <RegisterForm pid={pid} onDone={materials.reload} />}
      <Card title="Registered materials" flush tag={<span className="muted small">click a row for version history</span>}>
        {materials.loading && <Loading />}
        <ErrorBox error={materials.error} />
        {materials.data && (
          <Table<MaterialListItem>
            rows={materials.data}
            rowKey={(r) => r.material_id}
            onRowClick={(r) => setOpen(r.material_id)}
            selectedKey={open}
            columns={[
              { key: "id", header: "Material", width: 190, render: (r) => <><span className="mono"><strong>{r.material_id}</strong></span><div className="small">{r.content.name}</div>{r.content.fictional && <Tag kind="neutral">FICTIONAL</Tag>}</> },
              { key: "ver", header: "Version", className: "num", render: (r) => <span className="mono">v{r.current_version}</span> },
              { key: "lot", header: "Lot", className: "mono", render: (r) => r.content.lot ?? <span className="not-recorded">not recorded</span> },
              { key: "sup", header: "Supplier / grade", render: (r) => <span className="small">{r.content.supplier ?? "—"}<br /><span className="muted">{r.content.grade ?? ""}</span></span> },
              { key: "ver_status", header: "Verification", render: (r) => <StatusBadge status={r.content.verification_status} /> },
              { key: "assay", header: "Purity / assay", render: (r) => <PropertyCell prop={r.content.purity_or_assay ?? undefined} /> },
              ...KEY_PROPERTIES.map((name) => ({
                key: name,
                header: name.replace(/_/g, " "),
                render: (r: MaterialListItem) => <PropertyCell prop={r.content.physical_properties.find((p) => p.name === name)} />,
              })),
              ...(materials.data.some((m) => extra(m.content).length)
                ? [
              {
                key: "other",
                header: "Other properties",
                render: (r: MaterialListItem) =>
                  extra(r.content).length ? (
                    <div className="stack" style={{ gap: 6 }}>
                      {extra(r.content).map((p) => <div key={p.name}><span className="small muted">{p.name}</span><PropertyCell prop={p} /></div>)}
                    </div>
                  ) : (
                    <span className="muted small">none</span>
                  ),
              }
                  ]
                : []),
              { key: "hash", header: "Content SHA-256", render: (r) => <Hash value={r.content_hash} /> },
            ]}
          />
        )}
      </Card>
      <div className="legend-inline">
        <span>Property sources:</span>
        <SourceTag source="laboratory_measurement" />
        <SourceTag source="supplier_specification" />
        <SourceTag source="literature" />
        <SourceTag source="model_estimate" />
        <span className="not-recorded">not recorded</span>
      </div>
      {open && <HistoryDrawer pid={pid} materialId={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

function diffKeys(a: MaterialContent | undefined, b: MaterialContent): string[] {
  if (!a) return [];
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  keys.delete("version");
  return [...keys].filter((k) => JSON.stringify((a as unknown as Record<string, unknown>)[k]) !== JSON.stringify((b as unknown as Record<string, unknown>)[k]));
}

function HistoryDrawer({ pid, materialId, onClose }: { pid: number; materialId: string; onClose: () => void }) {
  const h = useAsync(() => api.materialHistory(pid, materialId), [pid, materialId]);
  return (
    <Drawer title={<>Version history · <span className="mono">{materialId}</span></>} onClose={onClose}>
      {h.loading && <Loading />}
      <ErrorBox error={h.error} />
      {h.data &&
        [...h.data.versions].reverse().map((v) => {
          const prev = h.data!.versions.find((x) => x.version === v.version - 1);
          const changed = diffKeys(prev?.content, v.content);
          return (
            <Card
              key={v.version}
              title={<span className="mono">v{v.version}</span>}
              tag={v.version === h.data!.current_version ? <Tag kind="info">CURRENT</Tag> : <Tag kind="neutral">PREVIOUS</Tag>}
            >
              <KV
                items={[
                  ["Change note", v.change_note],
                  ["Recorded by", <>{v.created_by} · {dateTime(v.created_at)}</>],
                  ["Content SHA-256", <Hash value={v.content_hash} full />],
                  ["Lot", <span className="mono">{v.content.lot ?? "not recorded"}</span>],
                  ["Verification", <StatusBadge status={v.content.verification_status} />],
                  ["Changed vs previous", changed.length ? changed.map((k) => <code key={k} style={{ marginRight: 6 }}>{k}</code>) : <span className="muted">{prev ? "no field changes" : "initial registration"}</span>],
                  [
                    "Properties",
                    v.content.physical_properties.length ? (
                      <div className="stack" style={{ gap: 6 }}>
                        {v.content.physical_properties.map((p) => <div key={p.name}><span className="small muted">{p.name}</span> <PropertyCell prop={p} /></div>)}
                      </div>
                    ) : (
                      <span className="not-recorded">no physical properties recorded</span>
                    ),
                  ],
                  ["Storage", v.content.storage_requirements ?? "—"],
                  ["Expiry / retest", v.content.expiry_or_retest_date ?? "—"],
                  ["Hazard documents", v.content.hazard_document_references.join(", ") || "—"],
                ]}
              />
            </Card>
          );
        })}
    </Drawer>
  );
}

const SOURCES: PropertySource[] = ["laboratory_measurement", "supplier_specification", "literature", "model_estimate"];

function RegisterForm({ pid, onDone }: { pid: number; onDone: () => void }) {
  const [f, setF] = useState({
    material_id: "",
    name: "",
    supplier: "",
    grade: "",
    lot: "",
    verification_status: "unverified",
    fictional: true,
    prop_name: "density",
    prop_source: "laboratory_measurement" as PropertySource,
    prop_value: "",
    prop_unit: "g/mL",
    prop_reference: "",
  });
  const act = useAction((body: unknown) => api.registerMaterial(pid, body));
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });

  async function submit(e: FormEvent) {
    e.preventDefault();
    const props = f.prop_value.trim()
      ? [{ name: f.prop_name, source: f.prop_source, value: Number(f.prop_value), unit: f.prop_unit || null, reference: f.prop_reference || null }]
      : [];
    const r = await act.run({
      material_id: f.material_id,
      name: f.name,
      supplier: f.supplier || null,
      grade: f.grade || null,
      lot: f.lot || null,
      verification_status: f.verification_status,
      fictional: f.fictional,
      physical_properties: props,
    });
    if (r) onDone();
  }

  return (
    <Card title="Register material" tag={<span className="muted small">creates version 1 (POST /materials)</span>}>
      <form onSubmit={submit}>
        <div className="form-grid">
          <label className="field"><span>Material ID *</span><input required pattern="[A-Za-z0-9_.\-]{1,64}" value={f.material_id} onChange={set("material_id")} /></label>
          <label className="field"><span>Name *</span><input required value={f.name} onChange={set("name")} /></label>
          <label className="field"><span>Supplier</span><input value={f.supplier} onChange={set("supplier")} /></label>
          <label className="field"><span>Grade</span><input value={f.grade} onChange={set("grade")} /></label>
          <label className="field"><span>Lot</span><input value={f.lot} onChange={set("lot")} /></label>
          <label className="field">
            <span>Verification status</span>
            <select value={f.verification_status} onChange={set("verification_status")}>
              {["unverified", "identity_confirmed", "verified", "rejected"].map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
            </select>
          </label>
          <label className="field check" style={{ alignSelf: "end" }}>
            <input type="checkbox" checked={f.fictional} onChange={(e) => setF({ ...f, fictional: e.target.checked })} /> fictional / demo material
          </label>
        </div>
        <hr className="sep" />
        <p className="small muted">Optional property — leave the value empty to record nothing (it will show as "not recorded").</p>
        <div className="form-grid">
          <label className="field"><span>Property</span><input value={f.prop_name} onChange={set("prop_name")} /></label>
          <label className="field">
            <span>Source</span>
            <select value={f.prop_source} onChange={set("prop_source")}>
              {SOURCES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
            </select>
          </label>
          <label className="field"><span>Value</span><input type="number" step="any" value={f.prop_value} onChange={set("prop_value")} /></label>
          <label className="field"><span>Unit</span><input value={f.prop_unit} onChange={set("prop_unit")} /></label>
          <label className="field"><span>Reference</span><input value={f.prop_reference} onChange={set("prop_reference")} /></label>
        </div>
        <div className="form-actions">
          <button className="btn primary" disabled={act.busy}>{act.busy ? "Registering…" : "Register"}</button>
        </div>
      </form>
      <div className="stack" style={{ marginTop: 10, gap: 8 }}>
        <ErrorBox error={act.error} />
        {act.result && (
          <>
            <Notice kind="info">
              Registered <span className="mono">{act.result.material_id}</span> v{act.result.version} · SHA-256 <Hash value={act.result.content_hash} />
            </Notice>
            <WarningList items={act.result.missing_properties.map((m) => `${m}: not recorded — calculations needing it will stay unresolved`)} label="MISSING PROPERTY" />
          </>
        )}
      </div>
    </Card>
  );
}
