import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../api";
import { Card, KV, Loading, PageHead } from "../components/Card";
import { Hash } from "../components/Hash";
import { ErrorBox, Notice } from "../components/Notice";
import { StateStepper } from "../components/StateStepper";
import { CellValue, Table } from "../components/Table";
import { StatusBadge, Tag } from "../components/Tag";
import { useProject } from "../context";
import { dateTime } from "../format";
import { useAction, useAsync } from "../hooks";
import type { ExperimentDetail, ExperimentRevision, ExperimentState } from "../types";

// Mirrors EXPERIMENT_TRANSITIONS in backend/tertius/science/workflow.py (server remains the authority).
const NEXT: Record<string, { target: ExperimentState; label: string; role: string }[]> = {
  draft: [{ target: "scientific_review", label: "Submit for scientific review", role: "researcher" }],
  scientific_review: [
    { target: "approved_for_experiment", label: "Approve for experiment", role: "reviewer" },
    { target: "draft", label: "Return to draft", role: "reviewer" },
    { target: "rejected", label: "Reject", role: "reviewer" },
  ],
  approved_for_experiment: [{ target: "performed", label: "Record as performed", role: "researcher" }],
  performed: [{ target: "data_reviewed", label: "Mark data reviewed", role: "reviewer" }],
  data_reviewed: [
    { target: "accepted", label: "Accept", role: "reviewer" },
    { target: "rejected", label: "Reject", role: "reviewer" },
  ],
};

export function ExperimentsPage() {
  const { pid } = useProject();
  const [params, setParams] = useSearchParams();
  const list = useAsync(() => api.experiments(pid), [pid]);
  const sel = params.get("code");
  useEffect(() => {
    if (!sel && list.data?.length) setParams({ code: list.data[0].code }, { replace: true });
  }, [list.data, sel, setParams]);

  return (
    <div className="stack">
      <PageHead
        title="Experiments"
        lede="Versioned experiment plans and their review workflow. Plans become immutable once submitted; execution, data review and acceptance are separate, attributed steps."
      />
      <Card title="Experiments" flush>
        {list.loading && !list.data && <Loading />}
        <ErrorBox error={list.error} />
        {list.data && (
          <Table
            rows={list.data}
            rowKey={(r) => r.code}
            selectedKey={sel}
            onRowClick={(r) => setParams({ code: r.code })}
            columns={[
              { key: "code", header: "Code", className: "mono", render: (r) => <strong>{r.code}</strong> },
              { key: "title", header: "Title", render: (r) => r.title },
              { key: "state", header: "Workflow state", render: (r) => <StatusBadge status={r.state} /> },
              { key: "rev", header: "Plan rev.", className: "num", render: (r) => r.revision },
              { key: "runs", header: "Runs", className: "num", render: (r) => r.runs },
              { key: "by", header: "Created by", render: (r) => r.created_by },
              { key: "appr", header: "Approved by", render: (r) => r.approved_by ?? "—" },
              { key: "src", header: "Origin", render: (r) => (r.proposal_pk ? <Tag kind="outline-predicted">FROM PROPOSAL #{r.proposal_pk}</Tag> : <Tag kind="neutral">DESIGN</Tag>) },
            ]}
          />
        )}
      </Card>
      {sel && <ExperimentView key={sel} code={sel} onChanged={list.reload} />}
    </div>
  );
}

function ExperimentView({ code, onChanged }: { code: string; onChanged: () => void }) {
  const { pid } = useProject();
  const e = useAsync(() => api.experiment(pid, code), [pid, code]);
  if (e.loading && !e.data) return <Loading what="experiment" />;
  if (e.error) return <ErrorBox error={e.error} />;
  const d = e.data as ExperimentDetail;
  const cur = d.revisions.find((r) => r.revision === d.current_revision) ?? d.revisions[d.revisions.length - 1];
  const perf = (cur.performed ?? {}) as Record<string, unknown>;
  const rejectedFrom: ExperimentState | undefined = d.state === "rejected" ? (cur.data_reviewed_by ? "data_reviewed" : "scientific_review") : undefined;
  const plan = cur.plan;
  const runs = (plan.runs ?? []) as Record<string, unknown>[];
  const runCols = runs.length ? Object.keys(runs[0]) : [];

  return (
    <div className="stack">
      <Card title={<><span className="mono">{d.code}</span> · {d.title}</>} tag={<StatusBadge status={d.state} />}>
        <div className="stack">
          <StateStepper
            state={d.state}
            rejectedAt={rejectedFrom}
            who={{
              scientific_review: cur.submitted_by ? `submitted by ${cur.submitted_by}` : undefined,
              approved_for_experiment: cur.approved_by ? `approved by ${cur.approved_by}` : undefined,
              performed: perf.recorded_by ? `recorded by ${String(perf.recorded_by)}` : undefined,
              data_reviewed: cur.data_reviewed_by ? `reviewed by ${cur.data_reviewed_by}` : undefined,
            }}
          />
          <div className="grid-3">
            <KV
              items={[
                ["Plan revision", `${cur.revision} (${cur.state.replace(/_/g, " ")})`],
                ["Plan SHA-256", <Hash value={cur.plan_hash} full />],
                ["Objective", String(plan.objective ?? "—")],
              ]}
            />
            <KV
              items={[
                ["Submitted by", cur.submitted_by ?? "—"],
                ["Approver", cur.approved_by ? <>{cur.approved_by} <span className="muted small">{dateTime(cur.approved_at)}</span></> : "—"],
                ["Performer (operator)", perf.operator ? String(perf.operator) : "—"],
                ["Recorded by", perf.recorded_by ? String(perf.recorded_by) : "—"],
                ["Data reviewer", cur.data_reviewed_by ?? "—"],
              ]}
            />
            <KV
              items={[
                ["Performed on", perf.performed_on ? String(perf.performed_on) : "—"],
                ["Material lots", Array.isArray(perf.material_lots) ? <span className="mono small">{(perf.material_lots as string[]).join(", ")}</span> : "—"],
                ["Equipment", Array.isArray(perf.equipment) ? <span className="mono small">{(perf.equipment as string[]).join(", ")}</span> : "—"],
                ["Decision reason", cur.decision_reason ?? "—"],
              ]}
            />
          </div>
        </div>
      </Card>

      <TransitionPanel code={d.code} state={d.state} onDone={() => { e.reload(); onChanged(); }} />

      <div className="grid-2">
        <Card title="Deviations" flush tag={<Tag kind="neutral">{d.deviations.length}</Tag>}>
          <Table
            rows={d.deviations}
            rowKey={(_, i) => String(i)}
            empty="No deviations recorded."
            columns={[
              { key: "d", header: "Description", render: (x) => x.description },
              { key: "i", header: "Impact", render: (x) => x.impact || "—" },
              { key: "b", header: "Recorded", render: (x) => <span className="small">{x.recorded_by}<br />{dateTime(x.created_at)}</span> },
            ]}
          />
        </Card>
        <Card title="Data-quality findings" flush tag={<Tag kind="neutral">{d.quality_findings.length}</Tag>}>
          <Table
            rows={d.quality_findings}
            rowKey={(_, i) => String(i)}
            maxHeight={320}
            empty="No findings."
            rowClassName={(q) => (q.severity === "warning" ? "row-warning" : q.severity === "error" ? "row-error" : undefined)}
            columns={[
              {
                key: "s",
                header: "Severity",
                render: (q) => (q.severity === "error" ? <Tag kind="error" /> : q.severity === "warning" ? <Tag kind="warning" /> : <Tag kind="info">INFO</Tag>),
              },
              { key: "c", header: "Code", className: "mono", render: (q) => q.code },
              { key: "m", header: "Message", render: (q) => q.message },
              {
                key: "r",
                header: "Rows",
                render: (q) => (
                  <details>
                    <summary>{q.rows.length}</summary>
                    <span className="mono small">{q.rows.join(", ")}</span>
                  </details>
                ),
              },
            ]}
          />
        </Card>
      </div>

      <Card title="Plan revisions" flush>
        <Table<ExperimentRevision>
          rows={d.revisions}
          rowKey={(r) => String(r.revision)}
          columns={[
            { key: "r", header: "Rev.", className: "num", render: (r) => r.revision },
            { key: "s", header: "State", render: (r) => <StatusBadge status={r.state} /> },
            { key: "h", header: "Plan SHA-256", render: (r) => <Hash value={r.plan_hash} n={16} /> },
            { key: "sb", header: "Submitted by", render: (r) => r.submitted_by ?? "—" },
            { key: "ab", header: "Approved by", render: (r) => r.approved_by ?? "—" },
            { key: "pf", header: "Performed (recorded by)", render: (r) => (r.performed ? String((r.performed as Record<string, unknown>).recorded_by ?? "yes") : "—") },
            { key: "dr", header: "Data reviewed by", render: (r) => r.data_reviewed_by ?? "—" },
            { key: "re", header: "Decision / change note", render: (r) => r.decision_reason ?? "—" },
          ]}
        />
      </Card>

      <Card title={`Planned runs (${runs.length})`} flush tag={<span className="muted small">approved plan content; not measurements</span>}>
        <details style={{ padding: "10px 14px" }}>
          <summary>Show plan details and {runs.length} runs</summary>
          <div className="stack" style={{ gap: 8 }}>
            <KV
              items={Object.entries(plan)
                .filter(([k]) => k !== "runs")
                .map(([k, v]) => [k.replace(/_/g, " "), <CellValue v={v} />])}
            />
            <Table
              rows={runs}
              rowKey={(_, i) => String(i)}
              maxHeight={360}
              columns={runCols.map((k) => ({ key: k, header: k, className: k.startsWith("mix:") || k.startsWith("proc:") ? "num" : undefined, render: (r: Record<string, unknown>) => <CellValue v={r[k]} /> }))}
            />
          </div>
        </details>
      </Card>
    </div>
  );
}

function TransitionPanel({ code, state, onDone }: { code: string; state: ExperimentState; onDone: () => void }) {
  const { pid, role } = useProject();
  const options = NEXT[state] ?? [];
  const [target, setTarget] = useState<string>(options[0]?.target ?? "");
  const [reason, setReason] = useState("");
  const [ev, setEv] = useState({ operator: "", performed_on: "", material_lots: "", equipment: "" });
  useEffect(() => setTarget(options[0]?.target ?? ""), [state]); // eslint-disable-line react-hooks/exhaustive-deps
  const act = useAction(() => {
    const evidence =
      target === "performed"
        ? {
            operator: ev.operator,
            performed_on: ev.performed_on,
            material_lots: ev.material_lots.split(",").map((s) => s.trim()).filter(Boolean),
            equipment: ev.equipment.split(",").map((s) => s.trim()).filter(Boolean),
          }
        : undefined;
    return api.transition(pid, code, target, reason, evidence);
  });

  if (!options.length)
    return (
      <Notice kind="info">
        No further transitions from <StatusBadge status={state} />. Executed plans cannot be edited; record a deviation or create a new experiment.
      </Notice>
    );
  const opt = options.find((o) => o.target === target);
  return (
    <Card title="Workflow transition" tag={<span className="muted small">your role: {role}; the server checks role and separation of duties</span>}>
      <div className="form-grid" style={{ gridTemplateColumns: "minmax(200px, 260px) minmax(0, 1fr)" }}>
        <label className="field">
          <span>Move to</span>
          <select value={target} onChange={(e) => setTarget(e.target.value)}>
            {options.map((o) => (
              <option key={o.target} value={o.target}>
                {o.label} (requires {o.role})
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Reason {target === "rejected" ? "(required for rejection)" : ""}</span>
          <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="documented in the plan revision and the audit trail" />
        </label>
      </div>
      {target === "performed" && (
        <div className="form-grid" style={{ marginTop: 10 }}>
          <label className="field"><span>Operator *</span><input value={ev.operator} onChange={(e) => setEv({ ...ev, operator: e.target.value })} /></label>
          <label className="field"><span>Performed on *</span><input value={ev.performed_on} placeholder="YYYY-MM-DD" onChange={(e) => setEv({ ...ev, performed_on: e.target.value })} /></label>
          <label className="field"><span>Material lots * (comma-separated)</span><input value={ev.material_lots} onChange={(e) => setEv({ ...ev, material_lots: e.target.value })} /></label>
          <label className="field"><span>Equipment * (comma-separated)</span><input value={ev.equipment} onChange={(e) => setEv({ ...ev, equipment: e.target.value })} /></label>
        </div>
      )}
      <div className="form-actions">
        <button className={`btn ${target === "rejected" ? "danger" : target === "accepted" || target === "approved_for_experiment" ? "approve" : "primary"}`} disabled={act.busy || !target} onClick={async () => { if (await act.run()) onDone(); }}>
          {opt?.label ?? "Apply"}
        </button>
        {act.result && <span className="small">Now <StatusBadge status={act.result.state} /></span>}
      </div>
      <div style={{ marginTop: 8 }}>
        <ErrorBox error={act.error} />
      </div>
    </Card>
  );
}
