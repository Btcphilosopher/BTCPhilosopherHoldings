import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../api";
import { Card, KV, Loading, PageHead, Stat, Tabs } from "../components/Card";
import { Hash } from "../components/Hash";
import { ErrorBox, Notice, WarningList } from "../components/Notice";
import { Plot } from "../components/Plot";
import { Table } from "../components/Table";
import { StatusBadge, Tag, ValueBlock } from "../components/Tag";
import { useProject } from "../context";
import { dateTime, fmt, pct } from "../format";
import { useAction, useAsync } from "../hooks";
import type { BatchQuantity, Design, Domain, FormulationListItem, FormulationRevision, Ingredient } from "../types";

type TabId = "formulations" | "domains" | "designs";

export function FormulationsPage() {
  const [params, setParams] = useSearchParams();
  const tab = (params.get("tab") as TabId) || "formulations";
  return (
    <div className="stack">
      <PageHead
        title="Formulations, research domains & designs"
        lede="Formulation revisions with server-side validation; the constrained research domains they live in; and the designs of experiments generated inside those domains."
      />
      <Tabs<TabId>
        value={tab}
        onChange={(t) => setParams({ tab: t }, { replace: true })}
        tabs={[
          { id: "formulations", label: "Formulations" },
          { id: "domains", label: "Research domains" },
          { id: "designs", label: "Designs of experiments" },
        ]}
      />
      {tab === "formulations" && <FormulationsTab />}
      {tab === "domains" && <DomainsTab />}
      {tab === "designs" && <DesignsTab />}
    </div>
  );
}

// ================================================================== formulations
function FormulationsTab() {
  const { pid } = useProject();
  const list = useAsync(() => api.formulations(pid), [pid]);
  const [sel, setSel] = useState<{ id: string; rev: number } | null>(null);
  useEffect(() => {
    if (!sel && list.data?.length) {
      const f = list.data[0];
      setSel({ id: f.formulation_id, rev: f.revisions[f.revisions.length - 1].revision });
    }
  }, [list.data, sel]);

  const rows = (list.data ?? []).flatMap((f) => f.revisions.map((r) => ({ f, r })));
  return (
    <div className="stack">
      <Card title="Formulation revisions" flush>
        {list.loading && <Loading />}
        <ErrorBox error={list.error} />
        <Table<{ f: FormulationListItem; r: FormulationListItem["revisions"][number] }>
          rows={rows}
          rowKey={({ f, r }) => `${f.formulation_id}@${r.revision}`}
          selectedKey={sel ? `${sel.id}@${sel.rev}` : null}
          onRowClick={({ f, r }) => setSel({ id: f.formulation_id, rev: r.revision })}
          columns={[
            { key: "id", header: "Formulation", className: "mono", render: ({ f }) => <strong>{f.formulation_id}</strong> },
            { key: "rev", header: "Rev.", className: "num", render: ({ r }) => r.revision },
            { key: "name", header: "Name", render: ({ f }) => <span className="small">{f.name}</span> },
            { key: "family", header: "Family", className: "mono", render: ({ f }) => f.family ?? "—" },
            { key: "status", header: "Status", render: ({ r }) => <StatusBadge status={r.status} /> },
            {
              key: "valid",
              header: "Validation",
              render: ({ r }) =>
                r.valid ? <Tag kind="calculated">VALID</Tag> : r.valid === false ? <Tag kind="error">ERRORS</Tag> : <Tag kind="neutral">—</Tag>,
            },
            { key: "appr", header: "Approved by", render: ({ r }) => r.approved_by ?? "—" },
            { key: "hash", header: "Content SHA-256", render: ({ r }) => <Hash value={r.content_hash} /> },
          ]}
        />
      </Card>
      {sel && <RevisionDetail key={`${sel.id}@${sel.rev}`} id={sel.id} rev={sel.rev} onChanged={list.reload} />}
    </div>
  );
}

function QuantityCell({ q, basis }: { q: BatchQuantity | undefined; basis?: string }) {
  if (!q) return <span className="not-recorded">not calculated</span>;
  if (q.status === "unresolved")
    return (
      <span className="row" style={{ gap: 6 }}>
        {q.volume_mL != null && <ValueBlock kind="calculated">{fmt(q.volume_mL, 5)} mL</ValueBlock>}
        <span className="vb warning" title={q.note}>
          <span>mass unresolved — no recorded density</span>
          <Tag kind="warning" />
        </span>
      </span>
    );
  const parts: string[] = [];
  if (q.mass_g !== null && q.mass_g !== undefined) parts.push(`${fmt(q.mass_g, 5)} g`);
  if (basis === "volume_fraction" && q.volume_mL !== null && q.volume_mL !== undefined) parts.unshift(`${fmt(q.volume_mL, 5)} mL`);
  return <ValueBlock kind="calculated" title={q.note}>{parts.join(" · ")}</ValueBlock>;
}

function RevisionDetail({ id, rev, onChanged }: { id: string; rev: number; onChanged: () => void }) {
  const { pid } = useProject();
  const r = useAsync(() => api.formulationRevision(pid, id, rev), [pid, id, rev]);
  const [reason, setReason] = useState("");
  const act = useAction((d: "submit" | "approve" | "return") => api.reviewFormulation(pid, id, rev, d, reason));

  if (r.loading && !r.data) return <Loading what="revision" />;
  if (r.error) return <ErrorBox error={r.error} />;
  const d = r.data as FormulationRevision;
  const c = d.content;
  const v = d.validation;
  const qty = new Map((v?.calculated.batch_quantities ?? []).map((q) => [q.material_id, q]));
  const errors = (v?.issues ?? []).filter((i) => i.severity === "error");
  const warnings = (v?.issues ?? []).filter((i) => i.severity !== "error");

  async function decide(dec: "submit" | "approve" | "return") {
    const res = await act.run(dec);
    if (res) {
      r.reload();
      onChanged();
    }
  }

  return (
    <div className="stack">
      <Card
        title={<><span className="mono">{d.formulation_id}</span> · revision {d.revision}</>}
        tag={<StatusBadge status={d.status} />}
        actions={
          <span className="muted small">
            created by {d.created_by}
            {d.approved_by && <> · approved by <strong>{d.approved_by}</strong> {dateTime(d.approved_at)}</>}
          </span>
        }
      >
        <div className="grid-2">
          <KV
            items={[
              ["Name", c.name ?? "—"],
              ["Dosage form", c.dosage_form ?? "—"],
              ["Basis", <code>{c.basis ?? "—"}</code>],
              ["Target batch size", c.target_batch_size ? `${c.target_batch_size.value} ${c.target_batch_size.unit}` : "—"],
              ["Content SHA-256", <Hash value={d.content_hash} full />],
            ]}
          />
          <KV
            items={[
              [
                "Composition total",
                v?.calculated.composition_total !== undefined ? (
                  <ValueBlock kind="calculated">{fmt(v.calculated.composition_total, 6)}</ValueBlock>
                ) : (
                  <span className="not-recorded">not calculated</span>
                ),
              ],
              ["Validation", v?.ok ? <Tag kind="calculated">PASSED</Tag> : <Tag kind="error">FAILED — {errors.length} error(s)</Tag>],
              ["Evidence", (c.evidence ?? []).join("; ") || "—"],
              [
                "Targets",
                (c.targets ?? []).map((t) => (
                  <div key={t.name} className="small">
                    {t.name}: {t.lower ?? "…"}–{t.upper ?? "…"} {t.unit} <span className="muted">({t.method})</span>
                  </div>
                )),
              ],
            ]}
          />
        </div>
      </Card>

      {(errors.length > 0 || warnings.length > 0) && (
        <Card title="Validation issues" accent={errors.length ? undefined : "warning"}>
          <div className="notice-list">
            {errors.map((i, k) => (
              <Notice key={`e${k}`} kind="error" label={<Tag kind="error">ERROR · {i.code}</Tag>}>
                {i.message}
              </Notice>
            ))}
            {warnings.map((i, k) => (
              <Notice key={`w${k}`} kind="warning" label={<Tag kind="warning">WARNING · {i.code}</Tag>}>
                {i.message}
              </Notice>
            ))}
          </div>
        </Card>
      )}

      <Card title="Ingredients and batch quantities" tag={<Tag kind="calculated" />} flush>
        <Table<Ingredient>
          rows={c.ingredients ?? []}
          rowKey={(i) => i.material_id}
          rowClassName={(i) => (qty.get(i.material_id)?.status === "unresolved" ? "row-warning" : undefined)}
          columns={[
            { key: "m", header: "Material", className: "mono", render: (i) => <strong>{i.material_id}</strong> },
            { key: "v", header: "Version", className: "mono", render: (i) => (i.material_version ? `v${i.material_version}` : "—") },
            { key: "lot", header: "Lot", className: "mono", render: (i) => i.lot ?? <span className="not-recorded">unspecified</span> },
            { key: "role", header: "Role", render: (i) => i.role },
            { key: "amt", header: "Amount (as recorded)", className: "num", render: (i) => `${fmt(i.amount.value, 6)} ${i.amount.unit}` },
            { key: "q", header: `Batch quantity (${c.target_batch_size ? `${c.target_batch_size.value} ${c.target_batch_size.unit}` : "batch"})`, render: (i) => <QuantityCell q={qty.get(i.material_id)} basis={c.basis} /> },
            { key: "note", header: "Calculation note", render: (i) => <span className="small muted">{qty.get(i.material_id)?.note ?? "—"}</span> },
          ]}
        />
      </Card>

      <Card title="Process stages · order of addition" flush>
        <Table
          rows={[...(c.stages ?? [])].sort((a, b) => a.order - b.order)}
          rowKey={(s) => String(s.order)}
          columns={[
            { key: "o", header: "#", className: "num", render: (s) => s.order },
            { key: "n", header: "Stage", render: (s) => s.name },
            { key: "add", header: "Additions", render: (s) => (s.additions ?? []).map((a) => <code key={a} style={{ marginRight: 6 }}>{a}</code>) },
            { key: "eq", header: "Equipment", className: "mono", render: (s) => s.equipment_id ?? "—" },
            {
              key: "p",
              header: "Parameters",
              render: (s) =>
                Object.entries(s.parameters ?? {})
                  .map(([k, q]) => `${k} ${q.value} ${q.unit}`)
                  .join("; ") || "—",
            },
            { key: "d", header: "Duration", render: (s) => (s.duration ? `${s.duration.value} ${s.duration.unit}` : "—") },
          ]}
        />
      </Card>

      <Card title="Review" tag={<span className="muted small">the server enforces roles and separation of duties</span>}>
        <div className="row" style={{ alignItems: "flex-end" }}>
          <label className="field" style={{ flex: 1, minWidth: 240 }}>
            <span>Reason / comment</span>
            <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="optional for submit; recorded in the audit trail" />
          </label>
          <button className="btn" disabled={act.busy || d.status !== "draft"} onClick={() => decide("submit")}>Submit for review</button>
          <button className="btn approve" disabled={act.busy || d.status !== "in_review"} onClick={() => decide("approve")}>Approve</button>
          <button className="btn danger" disabled={act.busy || d.status !== "in_review"} onClick={() => decide("return")}>Return to draft</button>
        </div>
        <div style={{ marginTop: 8 }}>
          <ErrorBox error={act.error} />
          {act.result && <Notice kind="info">Status is now <StatusBadge status={act.result.status} /></Notice>}
          {d.status === "approved" && <p className="small muted" style={{ marginTop: 6 }}>Approved revisions are immutable; changes require a new revision.</p>}
        </div>
      </Card>
    </div>
  );
}

// ================================================================== domains
function rangeText(lo: number | null | undefined, hi: number | null | undefined, digits = 4) {
  return `${lo === null || lo === undefined ? "−∞" : fmt(lo, digits)} – ${hi === null || hi === undefined ? "+∞" : fmt(hi, digits)}`;
}

function DomainsTab() {
  const { pid } = useProject();
  const domains = useAsync(() => api.domains(pid), [pid]);
  if (domains.loading && !domains.data) return <Loading what="domains" />;
  if (domains.error) return <ErrorBox error={domains.error} />;
  return (
    <div className="stack">
      {(domains.data ?? []).map((d) => <DomainCard key={d.id} d={d} onChanged={domains.reload} />)}
    </div>
  );
}

function DomainCard({ d, onChanged }: { d: Domain; onChanged: () => void }) {
  const { pid } = useProject();
  const act = useAction(() => api.approveDomain(pid, d.id));
  const c = d.content;
  const f = d.feasibility;
  return (
    <Card
      title={<>{c.name} <span className="mono muted">#{d.id} · v{d.version}</span></>}
      tag={
        <>
          {d.status === "approved" ? <Tag kind="approved">APPROVED · {d.approved_by}</Tag> : <StatusBadge status={d.status} />}
          {f.feasible ? <Tag kind="calculated">FEASIBLE</Tag> : <Tag kind="error">INFEASIBLE</Tag>}
          {f.blocked && <Tag kind="error">BLOCKED</Tag>}
        </>
      }
      actions={
        d.status !== "approved" && (
          <button className="btn approve small" disabled={act.busy} onClick={async () => { if (await act.run()) onChanged(); }}>
            Approve domain
          </button>
        )
      }
    >
      <div className="stack">
        <ErrorBox error={act.error} />
        {!f.feasible && (
          <Notice kind="error" label={<Tag kind="error">INFEASIBLE — CONFLICTING CONSTRAINTS</Tag>}>
            {f.explanations.map((e, i) => <p key={i}>{e}</p>)}
            <Table
              rows={f.conflicting_constraints}
              rowKey={(x) => x.name}
              columns={[
                { key: "n", header: "Constraint", className: "mono", render: (x) => x.name },
                { key: "k", header: "Kind", render: (x) => x.kind },
                { key: "e", header: "Expression", className: "mono", render: (x) => x.expression },
              ]}
            />
          </Notice>
        )}
        <WarningList items={[...f.warnings, ...f.missing_information.map((m) => `missing information: ${m}`)]} />
        <div className="grid-2">
          <div className="stack" style={{ gap: 8 }}>
            <h3>Component bounds (mass fraction; total = {c.total})</h3>
            <Table
              rows={c.components}
              rowKey={(x) => x}
              columns={[
                { key: "c", header: "Component", className: "mono", render: (x) => <strong>{x}</strong> },
                { key: "b", header: "Configured", className: "num", render: (x) => rangeText(c.bounds[x]?.[0], c.bounds[x]?.[1]) },
                {
                  key: "e",
                  header: "Effective range",
                  render: (x) =>
                    f.feasible_ranges[x] ? (
                      <ValueBlock kind="calculated">{rangeText(f.feasible_ranges[x][0], f.feasible_ranges[x][1])}</ValueBlock>
                    ) : (
                      <span className="not-recorded">none (no feasible point)</span>
                    ),
                },
                { key: "r", header: "Flags", render: (x) => <>{c.required.includes(x) && <Tag kind="neutral">REQUIRED</Tag>} {c.excluded.includes(x) && <Tag kind="neutral">EXCLUDED</Tag>}</> },
              ]}
            />
            <h3>Groups</h3>
            <Table
              rows={c.groups}
              rowKey={(g) => g.name}
              empty="no group constraints"
              columns={[
                { key: "n", header: "Group", render: (g) => g.name },
                { key: "m", header: "Members", className: "mono", render: (g) => g.members.join(" + ") },
                { key: "r", header: "Range", className: "num", render: (g) => rangeText(g.lower, g.upper) },
              ]}
            />
            {c.cost_limit && (
              <KV
                items={[
                  ["Cost limit", `≤ ${c.cost_limit.max_cost} ${c.cost_limit.currency}/${c.cost_limit.per_unit}`],
                  ["Prices", Object.values(c.prices).map((p) => `${p.component} ${p.amount} ${p.currency}/${p.per_unit} (${p.price_date})`).join("; ")],
                  ["Unknown-compatibility policy", <code>{c.unknown_compatibility_policy}</code>],
                ]}
              />
            )}
          </div>
          <div className="stack" style={{ gap: 8 }}>
            <h3>Process ranges</h3>
            <Table
              rows={Object.keys(c.process)}
              rowKey={(k) => k}
              columns={[
                { key: "n", header: "Parameter", className: "mono", render: (k) => k },
                { key: "c", header: "Permitted", className: "num", render: (k) => `${rangeText(c.process[k].lower, c.process[k].upper)} ${c.process[k].unit}` },
                {
                  key: "e",
                  header: "Effective (∩ equipment)",
                  render: (k) => {
                    const pr = f.process_ranges[k];
                    return pr ? <ValueBlock kind="calculated" title={pr.source}>{rangeText(pr.lower, pr.upper)} {pr.unit}</ValueBlock> : "—";
                  },
                },
                { key: "s", header: "Source", render: (k) => <span className="small muted">{f.process_ranges[k]?.source ?? c.process[k].source}</span> },
              ]}
            />
            {c.equipment.length > 0 && (
              <p className="small muted">
                Equipment limits:{" "}
                {c.equipment.map((e) => `${e.equipment_id} ${e.parameter} ${rangeText(e.lower, e.upper)} ${e.unit}`).join("; ")}
              </p>
            )}
          </div>
        </div>
        <div className="stack" style={{ gap: 8 }}>
        <h3>Compatibility records</h3>
        <Table
          rows={c.compatibility}
          rowKey={(x) => `${x.a}+${x.b}`}
          rowClassName={(x) => (x.status === "unknown" ? "row-warning" : x.status === "incompatible" ? "row-error" : undefined)}
          columns={[
            { key: "p", header: "Pair", className: "mono", render: (x) => `${x.a} + ${x.b}` },
            {
              key: "s",
              header: "Status",
              render: (x) =>
                x.status === "unknown" ? (
                  <Tag kind="warning">UNKNOWN — not assumed compatible</Tag>
                ) : x.status === "incompatible" ? (
                  <Tag kind="error">INCOMPATIBLE</Tag>
                ) : (
                  <Tag kind="neutral">{x.status.toUpperCase()}</Tag>
                ),
            },
            { key: "r", header: "Reviewed", render: (x) => (x.reviewed ? "yes" : "no") },
            { key: "src", header: "Source", render: (x) => <span className="small">{x.source}</span> },
          ]}
        />
        </div>
      </div>
    </Card>
  );
}

// ================================================================== designs
function DesignsTab() {
  const { pid } = useProject();
  const rationale = useAsync(() => api.designRationale(pid), [pid]);
  const designs = useAsync(() => api.designs(pid), [pid]);
  return (
    <div className="stack">
      <Card title="Why designs are generated inside the constrained mixture polytope" accent="calculated">
        {rationale.loading && <Loading />}
        <ErrorBox error={rationale.error} />
        {rationale.data && <p className="prose" style={{ margin: 0 }}>{rationale.data.why_not_unconstrained_sampling}</p>}
      </Card>
      {designs.loading && <Loading what="designs" />}
      <ErrorBox error={designs.error} />
      {designs.data?.length === 0 && <Notice kind="info">No designs have been generated yet.</Notice>}
      {(designs.data ?? []).map((d) => <DesignDetail key={d.id} id={d.id} />)}
    </div>
  );
}

function DesignDetail({ id }: { id: number }) {
  const { pid } = useProject();
  const d = useAsync(() => api.design(pid, id), [pid, id]);
  if (d.loading && !d.data) return <Loading what={`design ${id}`} />;
  if (d.error) return <ErrorBox error={d.error} />;
  const des = d.data as Design;
  const b = des.budget;
  const comps = Object.keys(des.coverage.per_component ?? {});
  const spec = des.spec as Record<string, unknown>;
  return (
    <Card
      title={<>Design #{des.id} <span className="muted">· domain #{des.domain_id}</span></>}
      tag={<><Tag kind="calculated">GENERATED DESIGN</Tag><span className="mono small">{String(spec.mixture_strategy ?? "")}</span></>}
    >
      <div className="stack">
        <div className="stat-row">
          <Stat label="Runs" value={b.runs} tag={<Tag kind="calculated" />} />
          <Stat label="Distinct blends" value={b.distinct_blends} />
          <Stat label="Replicates" value={b.replicates} />
          <Stat label="Control runs" value={b.controls} />
          <Stat label="Estimated cost" value={`${b.estimated_cost.toLocaleString("en-GB")} ${b.currency}`} tag={<Tag kind="calculated" />} />
        </div>
        <div className="grid-2">
          <div className="stack" style={{ gap: 8 }}>
            <h3>Coverage of the feasible region <Tag kind="calculated" /></h3>
            <KV
              items={[
                ["Fill distance (max)", fmt(des.coverage.fill_distance_max)],
                ["Fill distance (p95)", fmt(des.coverage.fill_distance_p95)],
                ["Min pairwise distance", fmt(des.coverage.min_pairwise_distance)],
                ["Blocking", `${String(spec.blocking_factor ?? "—")}: ${((spec.blocks as string[]) ?? []).join(", ")}`],
                ["Process pairing", String(spec.process_strategy ?? "—")],
                ["Scheffé order", String(spec.scheffe_order ?? "—")],
              ]}
            />
            <Table
              rows={comps}
              rowKey={(k) => k}
              columns={[
                { key: "c", header: "Component", className: "mono", render: (k) => k },
                { key: "d", header: "Design range", className: "num", render: (k) => rangeText(des.coverage.per_component![k].design_min, des.coverage.per_component![k].design_max, 3) },
                { key: "f", header: "Feasible range", className: "num", render: (k) => rangeText(des.coverage.per_component![k].domain_min, des.coverage.per_component![k].domain_max, 3) },
                { key: "p", header: "Covered", className: "num", render: (k) => pct(des.coverage.per_component![k].range_covered_fraction, 0) },
              ]}
            />
          </div>
          <div className="stack" style={{ gap: 8 }}>
            <h3>Limitations</h3>
            <WarningList items={des.limitations} label="LIMITATION" />
          </div>
        </div>
        <div>
          <h3 style={{ marginBottom: 4 }}>Design blends — pairwise component projections</h3>
          <p className="small muted">Each panel projects the 4-component blends onto two components (mass fractions). Circles: design runs; diamonds: control blend. Planned compositions, not measurements.</p>
          <DesignMatrix design={des} components={comps} />
          <div className="legend-inline">
            <span><span className="sw" style={{ background: "var(--calculated)", borderRadius: "50%" }} />design run (planned composition)</span>
            <span><span className="sw" style={{ background: "var(--nav-bg)", transform: "rotate(45deg) scale(.8)" }} />control blend (planned composition)</span>
          </div>
        </div>
      </div>
    </Card>
  );
}

function DesignMatrix({ design, components }: { design: Design; components: string[] }) {
  const pairs: [string, string][] = [];
  for (let i = 0; i < components.length; i++) for (let j = i + 1; j < components.length; j++) pairs.push([components[i], components[j]]);
  const cols = 3;
  const rows = Math.ceil(pairs.length / cols);
  const runs = design.runs;
  const isCtl = (r: Record<string, unknown>) => r.role === "control";
  return (
    <Plot
      ariaLabel="pairwise scatter of design blend compositions"
      height={rows * 250 + 30}
      deps={[design.id]}
      build={(c) => {
        const data: Record<string, unknown>[] = [];
        const layout: Record<string, unknown> = {
          grid: { rows, columns: cols, pattern: "independent", xgap: 0.12, ygap: 0.28 },
          margin: { l: 56, r: 16, t: 16, b: 40 },
          showlegend: false,
        };
        pairs.forEach(([a, b], k) => {
          const ax = k === 0 ? "" : String(k + 1);
          const groups = [
            { name: "design run (planned)", rs: runs.filter((r) => !isCtl(r)), symbol: "circle", color: c.calculated, size: 8 },
            { name: "control blend (planned)", rs: runs.filter(isCtl), symbol: "diamond", color: c.nav, size: 11 },
          ];
          for (const g of groups) {
            data.push({
              type: "scatter",
              mode: "markers",
              x: g.rs.map((r) => r[`mix:${a}`]),
              y: g.rs.map((r) => r[`mix:${b}`]),
              text: g.rs.map((r) => `${r.run_id} · ${r.design_point} · ${r.block}`),
              hovertemplate: `%{text}<br>${a} %{x:.3f}<br>${b} %{y:.3f}<extra>${g.name}</extra>`,
              marker: { symbol: g.symbol, size: g.size, color: g.color, opacity: 0.85, line: { color: c.surface, width: 1.5 } },
              name: g.name,
              legendgroup: g.name,
              showlegend: k === 0,
              xaxis: `x${ax}`,
              yaxis: `y${ax}`,
            });
          }
          layout[`xaxis${ax}`] = { title: { text: a }, tickformat: ".2f" };
          layout[`yaxis${ax}`] = { title: { text: b }, tickformat: ".2f" };
        });
        return { data, layout };
      }}
    />
  );
}
