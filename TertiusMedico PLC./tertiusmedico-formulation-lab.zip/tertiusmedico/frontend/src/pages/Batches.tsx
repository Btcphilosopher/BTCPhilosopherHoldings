import { useMemo, useState, type FormEvent } from "react";
import { api } from "../api";
import { Card, Loading, PageHead } from "../components/Card";
import { ErrorBox, Notice, WarningList } from "../components/Notice";
import { LOG_TICKS, Plot } from "../components/Plot";
import { Table } from "../components/Table";
import { Tag, ValueBlock } from "../components/Tag";
import { useProject } from "../context";
import { fmt, groupBy, mean, sd, uniq } from "../format";
import { useAction } from "../hooks";
import type { SimulationResult } from "../types";
import { StatusTag, useMeasurements, type MeasurementWithReason } from "./Measurements";

interface GroupStat {
  key: string;
  n: number;
  nFailed: number;
  mean: number | null;
  sd: number | null;
  cv: number | null;
}

function stats(key: string, rows: MeasurementWithReason[]): GroupStat {
  const vals = rows.filter((r) => r.value !== null).map((r) => r.value as number);
  const m = mean(vals);
  const s = sd(vals);
  return { key, n: vals.length, nFailed: rows.length - vals.length, mean: m, sd: s, cv: m && s !== null ? s / m : null };
}

export function BatchesPage() {
  const { pid } = useProject();
  const m = useMeasurements(pid);
  const [target, setTarget] = useState("viscosity");
  const rows = useMemo(() => (m.data?.rows ?? []).filter((r) => r.target === target), [m.data, target]);
  const tdef = m.data?.targets.find((t) => t.name === target);
  const unit = tdef?.spec.unit ?? rows[0]?.unit ?? "";
  const log = !!tdef?.spec.log_transform;
  const blocks = uniq(rows.map((r) => r.block ?? "—")).sort();
  const lots = uniq(rows.map((r) => r.lot_ids ?? "—")).sort();
  const controls = rows.filter((r) => r.role === "control");

  const byBlockLot = useMemo(() => {
    const g = groupBy(rows, (r) => `${r.block ?? "—"}|${r.lot_ids ?? "—"}`);
    return [...g.entries()].map(([k, rs]) => ({ block: k.split("|")[0], lot: k.split("|")[1], ...stats(k, rs) })).sort((a, b) => a.key.localeCompare(b.key));
  }, [rows]);
  const ctlBlocks = useMemo(() => [...groupBy(controls, (r) => r.block ?? "—").entries()].map(([k, rs]) => stats(k, rs)).sort((a, b) => a.key.localeCompare(b.key)), [controls]);

  if (m.loading && !m.data) return <Loading what="measurements" />;
  if (m.error) return <ErrorBox error={m.error} />;

  return (
    <div className="stack">
      <PageHead
        title="Batch consistency"
        lede="MEASURED values grouped by block (manufacturing day), material lot and batch, plus the repeated control blend, so day and lot effects are visible before they are absorbed into a model."
        actions={
          <label className="row small">
            Target
            <select className="inline" value={target} onChange={(e) => setTarget(e.target.value)}>
              {(m.data?.targets ?? []).filter((t) => t.spec.kind === "regression").map((t) => <option key={t.name} value={t.name}>{t.name} ({t.spec.unit})</option>)}
            </select>
          </label>
        }
      />
      <div className="grid-2">
        <Card title="Values per block (day)" accent="measured" tag={<Tag kind="measured" />}>
          <StripPlot rows={rows} groupOf={(r) => r.block ?? "—"} groups={blocks} unit={unit} log={log} xTitle="block (manufacturing day)" />
        </Card>
        <Card title="Values per material lot" accent="measured" tag={<Tag kind="measured" />}>
          <StripPlot rows={rows} groupOf={(r) => r.lot_ids ?? "—"} groups={lots} unit={unit} log={log} xTitle="material lot (lot_ids)" />
        </Card>
      </div>
      <p className="small muted" style={{ marginTop: -8 }}>
        Circles: design runs (different compositions, so spread mixes formulation and day/lot effects). Diamonds: control blend (same composition every block). Black bar: block/lot mean (CALCULATED). Failed runs have no value and are counted in the tables.
      </p>

      <Card title={`Control sample (role = control) across blocks — ${target}`} accent="measured" tag={<><Tag kind="measured" /><Tag kind="info">CONTROL</Tag></>}>
        {controls.length === 0 ? (
          <Notice kind="info">No control samples recorded for {target}.</Notice>
        ) : (
          <div className="grid-2">
            <ControlPlot rows={controls} unit={unit} />
            <div className="stack" style={{ gap: 8 }}>
              <Table<GroupStat>
                rows={ctlBlocks}
                rowKey={(s) => s.key}
                columns={[
                  { key: "b", header: "Block", className: "mono", render: (s) => s.key },
                  { key: "n", header: "n", className: "num", render: (s) => s.n },
                  { key: "m", header: "Mean", render: (s) => <ValueBlock kind="calculated">{fmt(s.mean, 4)} {unit}</ValueBlock> },
                  { key: "sd", header: "SD", className: "num", render: (s) => fmt(s.sd, 3) },
                  { key: "f", header: "Failed", className: "num", render: (s) => (s.nFailed ? <Tag kind="warning">{s.nFailed} FAILED</Tag> : "0") },
                ]}
              />
              <BlockEffectNote stats={ctlBlocks} unit={unit} />
              <Table<MeasurementWithReason>
                rows={controls}
                rowKey={(r) => r.measurement_id}
                maxHeight={200}
                columns={[
                  { key: "id", header: "Measurement", className: "mono", render: (r) => r.measurement_id },
                  { key: "b", header: "Batch", className: "mono", render: (r) => r.batch_id ?? "—" },
                  { key: "blk", header: "Block", className: "mono", render: (r) => r.block ?? "—" },
                  { key: "lot", header: "Lot", className: "mono", render: (r) => r.lot_ids ?? "—" },
                  { key: "v", header: "Value", render: (r) => (r.value === null ? <StatusTag status={r.status} /> : <ValueBlock kind="measured">{fmt(r.value, 4)} {unit}</ValueBlock>) },
                ]}
              />
            </div>
          </div>
        )}
      </Card>

      <Card title="Block × lot summary" flush tag={<Tag kind="calculated" />}>
        <Table
          rows={byBlockLot}
          rowKey={(s) => s.key}
          columns={[
            { key: "b", header: "Block", className: "mono", render: (s) => s.block },
            { key: "l", header: "Lot", className: "mono", render: (s) => s.lot },
            { key: "n", header: "n valid", className: "num", render: (s) => s.n },
            { key: "f", header: "Failed", className: "num", render: (s) => (s.nFailed ? <Tag kind="warning">{s.nFailed} FAILED</Tag> : "0") },
            { key: "m", header: `Mean (${unit})`, className: "num", render: (s) => fmt(s.mean, 4) },
            { key: "sd", header: "SD", className: "num", render: (s) => fmt(s.sd, 3) },
            { key: "cv", header: "CV", className: "num", render: (s) => (s.cv === null ? "—" : `${(s.cv * 100).toFixed(1)} %`) },
          ]}
        />
      </Card>

      <SimulationForm />
    </div>
  );
}

function BlockEffectNote({ stats, unit }: { stats: GroupStat[]; unit: string }) {
  const ms = stats.map((s) => s.mean).filter((x): x is number => x !== null);
  if (ms.length < 2) return null;
  const range = Math.max(...ms) - Math.min(...ms);
  const pooledSd = mean(stats.map((s) => s.sd).filter((x): x is number => x !== null));
  const big = pooledSd !== null && range > 2 * pooledSd;
  return big ? (
    <Notice kind="warning" label={<Tag kind="warning">POSSIBLE DAY EFFECT</Tag>}>
      Control means differ by {fmt(range, 3)} {unit} across blocks, more than twice the within-block SD ({fmt(pooledSd, 3)}). Check blocking before pooling.
    </Notice>
  ) : (
    <p className="small muted">
      Spread of control means across blocks: {fmt(range, 3)} {unit} (within-block SD {fmt(pooledSd, 3)}). <Tag kind="calculated" />
    </p>
  );
}

function StripPlot({ rows, groupOf, groups, unit, log, xTitle }: { rows: MeasurementWithReason[]; groupOf: (r: MeasurementWithReason) => string; groups: string[]; unit: string; log: boolean; xTitle: string }) {
  return (
    <Plot
      ariaLabel={`measured values per ${xTitle}`}
      height={320}
      deps={[rows.length, rows[0]?.target, groups.join(","), log]}
      build={(c) => {
        const ok = rows.filter((r) => r.value !== null);
        // deterministic jitter so screenshots are stable
        const jit = (id: string) => {
          let h = 0;
          for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
          return ((Math.abs(h) % 1000) / 1000 - 0.5) * 0.5;
        };
        const xi = (r: MeasurementWithReason) => groups.indexOf(groupOf(r)) + jit(r.measurement_id);
        const sets = [
          { name: "design run", rs: ok.filter((r) => r.role !== "control"), symbol: "circle", size: 8 },
          { name: "control", rs: ok.filter((r) => r.role === "control"), symbol: "diamond", size: 11 },
        ];
        const means = groups.map((g) => mean(ok.filter((r) => groupOf(r) === g).map((r) => r.value as number)));
        return {
          data: [
            ...sets.map((s) => ({
              type: "scatter", mode: "markers", name: s.name, x: s.rs.map(xi), y: s.rs.map((r) => r.value),
              text: s.rs.map((r) => `${r.measurement_id} · ${r.batch_id ?? ""}<br>${r.block ?? ""} · ${r.lot_ids ?? ""}`),
              hovertemplate: `%{text}<br>%{y:.4g} ${unit}<extra>MEASURED · ${s.name}</extra>`,
              marker: { color: c.measured, symbol: s.symbol, size: s.size, opacity: s.symbol === "diamond" ? 1 : 0.6, line: { color: s.symbol === "diamond" ? c.ink : c.surface, width: s.symbol === "diamond" ? 1.5 : 1 } },
            })),
            {
              type: "scatter", mode: "markers", name: "mean (CALCULATED)", x: groups.map((_, i) => i), y: means,
              marker: { symbol: "line-ew", size: 34, color: c.ink, line: { width: 3, color: c.ink } },
              hovertemplate: `mean %{y:.4g} ${unit}<extra>CALCULATED</extra>`,
            },
          ],
          layout: {
            showlegend: false,
            xaxis: { title: { text: xTitle }, tickmode: "array", tickvals: groups.map((_, i) => i), ticktext: groups, range: [-0.6, groups.length - 0.4], zeroline: false },
            yaxis: { title: { text: `${unit}${log ? " (log)" : ""}` }, type: log ? "log" : "linear", ...(log ? LOG_TICKS : {}) },
            margin: { l: 60, r: 12, t: 12, b: 48 },
          },
        };
      }}
    />
  );
}

function ControlPlot({ rows, unit }: { rows: MeasurementWithReason[]; unit: string }) {
  const blocks = uniq(rows.map((r) => r.block ?? "—")).sort();
  const lots = uniq(rows.map((r) => r.lot_ids ?? "—")).sort();
  const symbols = ["diamond", "square", "triangle-up", "circle"];
  return (
    <div>
      <Plot
        ariaLabel="control sample values across blocks"
        height={330}
        deps={[rows.length, rows[0]?.target]}
        build={(c) => {
          const ok = rows.filter((r) => r.value !== null);
          const means = blocks.map((b) => mean(ok.filter((r) => (r.block ?? "—") === b).map((r) => r.value as number)));
          return {
            data: [
              { type: "scatter", mode: "lines+markers", name: "block mean", x: blocks, y: means, line: { color: c.calculated, width: 2 }, marker: { symbol: "line-ew", size: 24, line: { width: 3, color: c.calculated } }, hovertemplate: `block mean %{y:.4g} ${unit}<extra>CALCULATED</extra>` },
              ...lots.map((l, i) => {
                const rs = ok.filter((r) => (r.lot_ids ?? "—") === l);
                return {
                  type: "scatter", mode: "markers", name: `lot ${l}`, x: rs.map((r) => r.block), y: rs.map((r) => r.value),
                  text: rs.map((r) => `${r.measurement_id} · ${r.batch_id}`),
                  hovertemplate: `%{text}<br>lot ${l}<br>%{y:.4g} ${unit}<extra>MEASURED · control</extra>`,
                  marker: { color: c.measured, symbol: symbols[i % symbols.length], size: 12, line: { color: c.surface, width: 1.5 } },
                };
              }),
            ],
            layout: {
              showlegend: true,
              legend: { orientation: "h", y: -0.28, x: 0 },
              xaxis: { title: { text: "block (manufacturing day)" }, type: "category" },
              yaxis: { title: { text: `${unit} (linear)` } },
              margin: { l: 60, r: 12, t: 16, b: 48 },
            },
          };
        }}
      />
      <p className="small muted">Teal markers: MEASURED control values; marker shape = material lot. Grey line: block mean (CALCULATED).</p>
    </div>
  );
}

// ------------------------------------------------------------------ process simulation
const SIM_FIELDS: { k: string; label: string; step: string }[] = [
  { k: "batch_mass_g", label: "Batch mass (g)", step: "any" },
  { k: "mix_speed_rpm", label: "Mix speed (rpm)", step: "any" },
  { k: "mix_time_min", label: "Mix time (min)", step: "any" },
  { k: "hold_time_h", label: "Hold time (h)", step: "any" },
  { k: "fill_target_g", label: "Fill target (g)", step: "any" },
  { k: "fill_tolerance_g", label: "Fill tolerance (± g)", step: "any" },
  { k: "n_sims", label: "Monte-Carlo runs", step: "1" },
  { k: "seed", label: "Seed", step: "1" },
];

function SimulationForm() {
  const { pid } = useProject();
  const [f, setF] = useState<Record<string, string>>({
    batch_mass_g: "5000", mix_speed_rpm: "600", mix_time_min: "20", hold_time_h: "4", fill_target_g: "50", fill_tolerance_g: "0.75", n_sims: "2000", seed: "1",
  });
  const act = useAction((body: Record<string, number>) => api.simulateProcess(pid, body));
  function submit(e: FormEvent) {
    e.preventDefault();
    act.run(Object.fromEntries(Object.entries(f).map(([k, v]) => [k, Number(v)])));
  }
  return (
    <Card title="Process simulation" accent="simulated" tag={<Tag kind="simulated">SIMULATED — NOT PROCESS VALIDATION</Tag>} id="simulation">
      <form onSubmit={submit}>
        <div className="form-grid">
          {SIM_FIELDS.map((x) => (
            <label key={x.k} className="field">
              <span>{x.label}</span>
              <input type="number" step={x.step} value={f[x.k]} onChange={(e) => setF({ ...f, [x.k]: e.target.value })} required />
            </label>
          ))}
        </div>
        <div className="form-actions">
          <button className="btn primary" disabled={act.busy}>{act.busy ? "Simulating…" : "Run simulation"}</button>
          <span className="small muted">Monte-Carlo propagation of assumed (not measured) parameters through a well-mixed-vessel model.</span>
        </div>
      </form>
      <div style={{ marginTop: 10 }}>
        <ErrorBox error={act.error} />
        {act.result && <SimulationView r={act.result} />}
      </div>
    </Card>
  );
}

function SimulationView({ r }: { r: SimulationResult }) {
  return (
    <div className="stack" style={{ gap: 10 }}>
      <Notice kind="simulated" label={<Tag kind="simulated">{r.label || "SIMULATED — NOT PROCESS VALIDATION"}</Tag>}>
        These numbers describe the model under stated assumptions. They are not measurements and do not validate the process.
      </Notice>
      <WarningList items={r.flags} label="SIMULATION FLAG" />
      <div className="grid-2">
        <div>
          <h3 style={{ marginBottom: 4 }}>Outputs (5th percentile / median / 95th percentile)</h3>
          <Table
            rows={Object.entries(r.outputs)}
            rowKey={([k]) => k}
            columns={[
              { key: "k", header: "Output", render: ([k]) => k.replace(/_/g, " ") },
              { key: "a", header: "p05", className: "num", render: ([, v]) => fmt(v.p05, 4) },
              { key: "m", header: "median", className: "num", render: ([, v]) => <strong>{fmt(v.median, 4)}</strong> },
              { key: "b", header: "p95", className: "num", render: ([, v]) => fmt(v.p95, 4) },
              { key: "t", header: "", render: () => <Tag kind="simulated" /> },
            ]}
          />
        </div>
        <div className="stack" style={{ gap: 8 }}>
          <h3>Assumptions</h3>
          <Table
            rows={r.assumptions}
            rowKey={(a) => a.name}
            columns={[
              { key: "n", header: "Assumption", render: (a) => a.name },
              { key: "v", header: "Value", className: "num", render: (a) => `${fmt(a.value, 4)} ${a.unit}` },
              { key: "u", header: "Uncertainty (rel. SD)", className: "num", render: (a) => fmt(a.uncertainty_sd) },
              { key: "b", header: "Basis", render: (a) => <Tag kind="warning">{a.basis.toUpperCase()}</Tag> },
            ]}
          />
          <h3>Limitations</h3>
          <WarningList items={r.limitations} label="LIMITATION" />
        </div>
      </div>
    </div>
  );
}
