import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";
import { Card, Loading, PageHead, Stat } from "../components/Card";
import { ErrorBox, Notice } from "../components/Notice";
import { Table } from "../components/Table";
import { StatusBadge, Tag } from "../components/Tag";
import { ProjectContext } from "../context";
import { useAsync } from "../hooks";
import { useContext } from "react";
import { NAV } from "../nav";

const STATE_ORDER = ["draft", "scientific_review", "approved_for_experiment", "performed", "data_reviewed", "accepted", "rejected", "superseded"];

export function ProjectsPage() {
  const ctx = useContext(ProjectContext);
  const navigate = useNavigate();
  const projects = useAsync(() => api.projects(), []);
  const pid = ctx?.pid;

  return (
    <div className="stack">
      <PageHead title="Projects" lede="Projects you are a member of. Data access is project-scoped; your role governs which reviews you may perform." />
      <Card title="My projects" flush>
        {projects.loading && <Loading />}
        <ErrorBox error={projects.error} />
        {projects.data && (
          <Table
            rows={projects.data}
            rowKey={(r) => String(r.id)}
            selectedKey={pid ? String(pid) : null}
            onRowClick={(r) => navigate(`/p/${r.id}`)}
            columns={[
              { key: "code", header: "Code", className: "mono", render: (r) => r.code },
              { key: "name", header: "Name", render: (r) => <><strong>{r.name}</strong><div className="muted small">{r.description}</div></> },
              { key: "role", header: "My role", render: (r) => <span className="role-chip">{r.role}</span> },
              {
                key: "flags",
                header: "Flags",
                render: (r) => (
                  <div className="row">
                    {r.synthetic && <span className="synthetic-flag">SYNTHETIC DEMONSTRATION</span>}
                    {r.confidential && <Tag kind="neutral">CONFIDENTIAL</Tag>}
                  </div>
                ),
              },
              { key: "open", header: "", render: (r) => <Link className="btn small" to={`/p/${r.id}`} onClick={(e) => e.stopPropagation()}>Open</Link> },
            ]}
          />
        )}
      </Card>
      {pid && <ProjectSummaryView pid={pid} />}
      {!pid && <Notice kind="info">Select a project to open its workspaces.</Notice>}
    </div>
  );
}

function ProjectSummaryView({ pid }: { pid: number }) {
  const ctx = useContext(ProjectContext);
  const members = useAsync(() => api.members(pid), [pid]);
  const s = ctx?.summary;
  if (!s) return <Loading what="project" />;
  const states = Object.entries(s.experiments_by_state).sort((a, b) => STATE_ORDER.indexOf(a[0]) - STATE_ORDER.indexOf(b[0]));
  const totalExp = states.reduce((a, [, n]) => a + n, 0);
  const maxN = Math.max(1, ...states.map(([, n]) => n));
  return (
    <>
      <Card
        title={<>{s.code} — summary</>}
        tag={<>{s.synthetic && <span className="synthetic-flag">SYNTHETIC DEMONSTRATION</span>}<span className="role-chip">your role: {s.role}</span></>}
      >
        <div className="stack">
          <p className="muted">{s.name}</p>
          <div className="stat-row">
            <Stat label="Materials registered" value={s.materials} />
            <Stat label="Experiments" value={totalExp} />
            <Stat label="Model runs" value={s.model_runs} />
            <Stat label="Accepted experiments" value={s.experiments_by_state["accepted"] ?? 0} tag={<Tag kind="approved">ACCEPTED</Tag>} />
          </div>
          <div className="grid-2">
            <div>
              <h3 style={{ marginBottom: 8 }}>Experiments by workflow state</h3>
              <div className="mini-bars" role="list">
                {states.length === 0 && <span className="muted">No experiments yet.</span>}
                {states.map(([st, n]) => (
                  <div className="mini-bar" key={st} role="listitem">
                    <span><StatusBadge status={st} /></span>
                    <span className="track"><span className="fill" style={{ width: `${(n / maxN) * 100}%`, display: "block" }} /></span>
                    <span className="num">{n}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 style={{ marginBottom: 8 }}>Workspaces</h3>
              <div className="row">
                {NAV.filter((n) => n.path).map((n) => (
                  <Link key={n.path} className="btn small" to={`/p/${pid}/${n.path}`}>{n.label}</Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Card>
      <Card title="Members" flush>
        {members.loading && <Loading />}
        <ErrorBox error={members.error} />
        {members.data && (
          <Table
            rows={members.data}
            rowKey={(r) => r.username}
            columns={[
              { key: "username", header: "Username", className: "mono", render: (r) => r.username },
              { key: "full_name", header: "Name", render: (r) => r.full_name || "—" },
              { key: "role", header: "Project role", render: (r) => <span className="role-chip">{r.role}</span> },
            ]}
          />
        )}
      </Card>
    </>
  );
}
