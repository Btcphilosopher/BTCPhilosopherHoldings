import { useEffect, useState } from "react";
import { api } from "../api";
import { Card, KV, Loading, PageHead } from "../components/Card";
import { Hash } from "../components/Hash";
import { ErrorBox, Notice, WarningList } from "../components/Notice";
import { CellValue, RecordTable, Table } from "../components/Table";
import { StatusBadge, Tag, type TagKind } from "../components/Tag";
import { useProject } from "../context";
import { dateTime } from "../format";
import { useAction, useAsync } from "../hooks";
import type { AuditEntry, Lineage, Report, ReportSection } from "../types";
import { effectiveStatus } from "./Optimisation";

const STABILITY_FORMULATION = "SUS-DEMO-REF";

function labelKind(label: string): TagKind {
  const w = label.split(/[\s(/]/)[0];
  return ({ MEASURED: "measured", PREDICTED: "predicted", CALCULATED: "calculated", SIMULATED: "simulated" } as Record<string, TagKind>)[w] ?? "neutral";
}

function download(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

export function ReportsPage() {
  const { pid, role } = useProject();
  const ctx = useAsync(async () => {
    const [batches, experiments] = await Promise.all([api.proposals(pid), api.experiments(pid)]);
    return { batches, experiments };
  }, [pid]);
  const latestBatch = ctx.data?.batches[0]?.batch_id ?? null;
  const body = { proposal_batch_id: latestBatch, stability_formulation: STABILITY_FORMULATION };
  const gen = useAction(() => api.report(pid, body));
  const html = useAction(async () => {
    const doc = await api.reportHtml(pid, body);
    const url = URL.createObjectURL(new Blob([doc], { type: "text/html" }));
    const w = window.open(url, "_blank");
    if (w) w.opener = null;
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return w ? "opened" : "blocked";
  });

  const reviewed = (ctx.data?.batches ?? []).flatMap((b) => b.proposals).map((p) => ({ p, st: effectiveStatus(p, ctx.data?.experiments ?? []) })).filter((x) => x.p.reviewed_by);

  return (
    <div className="stack">
      <PageHead
        title="Reports, lineage & audit"
        lede="Traceable research reports with a content hash, the lineage from material lot to reviewed decision, and the hash-chained audit trail."
      />
      <Card
        title="Research report"
        actions={
          <>
            <button className="btn primary" disabled={gen.busy || ctx.loading} onClick={() => gen.run()}>{gen.busy ? "Generating…" : "Generate report"}</button>
            <button className="btn" disabled={html.busy || ctx.loading} onClick={() => html.run()}>{html.busy ? "Rendering…" : "Open HTML version"}</button>
            <button className="btn" disabled={!gen.result} onClick={() => gen.result && download(`report-${gen.result.report.meta.content_sha256.slice(0, 12)}.json`, JSON.stringify(gen.result.report, null, 2), "application/json")}>
              Download JSON
            </button>
          </>
        }
      >
        <div className="stack" style={{ gap: 8 }}>
          <p className="small muted" style={{ margin: 0 }}>
            Includes proposal batch {latestBatch !== null ? <span className="mono">#{latestBatch}</span> : "— (none yet)"} (latest) and stability trends for <span className="mono">{STABILITY_FORMULATION}</span>.
          </p>
          <ErrorBox error={gen.error} />
          <ErrorBox error={html.error} />
          {html.result === "blocked" && <Notice kind="warning">The browser blocked the new tab. Allow pop-ups for this site to open the HTML report.</Notice>}
          {!gen.result && !gen.busy && <Notice kind="info">Generate a report to view its sections here.</Notice>}
        </div>
      </Card>
      {gen.result && <ReportView report={gen.result.report} htmlKey={gen.result.html_key} />}

      <LineageExplorer pid={pid} options={reviewed.map((x) => ({ code: x.p.code, status: x.st.status }))} />
      <AuditTrail pid={pid} role={role} />
    </div>
  );
}

function ReportView({ report, htmlKey }: { report: Report; htmlKey: string }) {
  const sections = Object.entries(report).filter(([k]) => k !== "meta" && k !== "banner") as [string, ReportSection][];
  return (
    <div className="stack">
      <Card title="Report metadata" accent="calculated">
        <div className="stack" style={{ gap: 8 }}>
          <KV
            items={[
              ["Project", report.meta.project],
              ["Generated", <>{report.meta.generated_by} · {dateTime(report.meta.generated_at)}</>],
              ["Content SHA-256", <Hash value={report.meta.content_sha256} full />],
              ["Stored HTML", <span className="mono small">{htmlKey}</span>],
            ]}
          />
          <Notice kind="warning" label={<Tag kind="warning">STATUS</Tag>}>{report.banner}</Notice>
          <div className="row small">
            Sections: {sections.map(([k, s]) => <a key={k} href={`#sec-${k}`} className="mono">{s.title?.split(".")[0] ?? k}</a>)}
          </div>
        </div>
      </Card>
      {sections.map(([k, s]) => (
        <Card key={k} id={`sec-${k}`} title={s.title ?? k} tag={s.label ? <Tag kind={labelKind(s.label)}>{s.label}</Tag> : undefined}>
          <div className="stack" style={{ gap: 8 }}>
            {(s.text ?? []).filter(Boolean).map((t, i) => <p key={i} style={{ margin: 0 }}>{t}</p>)}
            <WarningList items={s.warnings} />
            {(s.tables ?? []).map((t, i) => (
              <div key={i}>
                <h3 style={{ marginBottom: 4 }}>{t.caption} <span className="muted small">({t.rows.length} rows)</span></h3>
                <RecordTable rows={t.rows} maxHeight={320} />
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}

const KIND_TAG: Record<string, TagKind> = {
  raw_measurement: "measured",
  training_dataset: "calculated",
  model: "calculated",
  prediction: "predicted",
  reviewed_decision: "approved",
};

function LineageExplorer({ pid, options }: { pid: number; options: { code: string; status: string }[] }) {
  const accepted = options.filter((o) => o.status === "accepted_for_planning");
  const [code, setCode] = useState<string>("");
  useEffect(() => {
    if (!code && options.length) setCode((accepted[0] ?? options[0]).code);
  }, [options, accepted, code]);
  const lin = useAsync(() => (code ? api.lineage(pid, "reviewed_decision", `review:${code}`) : Promise.resolve(null)), [pid, code]);
  return (
    <Card
      title="Lineage explorer"
      tag={<span className="muted small">GET /lineage?kind=reviewed_decision&amp;ref=review:&lt;proposal&gt;</span>}
      actions={
        <label className="row small">
          Reviewed proposal
          <select className="inline" value={code} onChange={(e) => setCode(e.target.value)}>
            {options.map((o) => <option key={o.code} value={o.code}>{o.code} — {o.status.replace(/_/g, " ")}</option>)}
          </select>
        </label>
      }
    >
      {!options.length && <Notice kind="info">No reviewed proposals yet; lineage starts from a reviewed decision.</Notice>}
      {lin.loading && code && <Loading what="lineage" />}
      <ErrorBox error={lin.error} />
      {lin.data && <LineageChain l={lin.data} status={options.find((o) => o.code === code)?.status} />}
    </Card>
  );
}

function LineageChain({ l, status }: { l: Lineage; status?: string }) {
  const byKind = new Map<string, string[]>();
  l.upstream.forEach((n) => byKind.set(n.kind, [...(byKind.get(n.kind) ?? []), n.ref]));
  return (
    <div className="stack" style={{ gap: 10 }}>
      <div className="row small">
        Node <span className="mono">{l.node}</span> {status && <StatusBadge status={status} />}
        <span className="muted">· {l.upstream.length} upstream records · {l.edges.length} edges</span>
      </div>
      <div className="chain" aria-label="lineage chain from material lot to reviewed decision">
        {l.chain.map((kind, i) => {
          const refs = byKind.get(kind) ?? [];
          return (
            <div key={kind} style={{ display: "contents" }}>
              {i > 0 && <div className="chain-arrow" aria-hidden="true">→</div>}
              <div className="chain-node">
                <div className="chain-kind">
                  <span className="idx">{i + 1}</span>
                  {kind.replace(/_/g, " ")}
                </div>
                {KIND_TAG[kind] && <span><Tag kind={KIND_TAG[kind]}>{KIND_TAG[kind] === "approved" ? "REVIEWED" : undefined}</Tag></span>}
                <div className="chain-refs">
                  {refs.length ? refs.map((r) => <span key={r} className="chain-ref" title={`${kind}:${r}`}>{kind === "model" ? `model run #${r}` : r}</span>) : <span className="chain-ref missing">▲ missing link</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {l.missing_links.length > 0 ? (
        <WarningList items={[`missing lineage links: ${l.missing_links.join(", ")}`]} label="INCOMPLETE LINEAGE" />
      ) : (
        <p className="small muted" style={{ margin: 0 }}>Complete chain: every stage from material lot to reviewed decision is recorded.</p>
      )}
      <details>
        <summary>{l.edges.length} lineage edges</summary>
        <Table
          rows={l.edges}
          rowKey={(_, i) => String(i)}
          maxHeight={300}
          columns={[
            { key: "p", header: "Parent", className: "mono", render: (e) => e.parent },
            { key: "r", header: "Relation", render: (e) => e.relation.replace(/_/g, " ") },
            { key: "c", header: "Child", className: "mono", render: (e) => e.child },
          ]}
        />
      </details>
    </div>
  );
}

function AuditTrail({ pid, role }: { pid: number; role?: string }) {
  const audit = useAsync(() => api.audit(pid, 200), [pid]);
  const [actor, setActor] = useState("");
  const rows = (audit.data ?? []).filter((a) => !actor || a.actor === actor);
  const actors = Array.from(new Set((audit.data ?? []).map((a) => a.actor)));
  return (
    <Card
      title="Audit trail"
      tag={<span className="muted small">hash-chained · reviewer role required · your role: {role}</span>}
      actions={
        audit.data && (
          <select className="inline" value={actor} onChange={(e) => setActor(e.target.value)} aria-label="filter by actor">
            <option value="">all actors</option>
            {actors.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        )
      }
      flush
    >
      {audit.loading && <Loading />}
      {audit.error && <div style={{ padding: 12 }}><ErrorBox error={audit.error} /></div>}
      {audit.data && (
        <Table<AuditEntry>
          rows={rows}
          rowKey={(a) => String(a.id)}
          maxHeight={460}
          columns={[
            { key: "id", header: "#", className: "num", render: (a) => a.id },
            { key: "ts", header: "Timestamp", className: "nowrap small", render: (a) => dateTime(a.ts) },
            { key: "ac", header: "Actor", render: (a) => a.actor },
            { key: "ax", header: "Action", className: "mono", render: (a) => a.action },
            { key: "e", header: "Entity", className: "mono", render: (a) => `${a.entity_type}:${a.entity_id}` },
            { key: "d", header: "Detail", render: (a) => (a.detail && Object.keys(a.detail).length ? <CellValue v={a.detail} /> : <span className="muted">—</span>) },
            { key: "h", header: "Hash", render: (a) => <Hash value={a.hash} n={16} /> },
          ]}
        />
      )}
    </Card>
  );
}
