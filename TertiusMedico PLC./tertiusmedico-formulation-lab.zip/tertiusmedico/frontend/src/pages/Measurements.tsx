import { useMemo, useState } from "react";
import { api } from "../api";
import { Card, Loading, PageHead, Stat } from "../components/Card";
import { ErrorBox, Notice } from "../components/Notice";
import { LOG_TICKS, Plot } from "../components/Plot";
import { Table } from "../components/Table";
import { Tag, ValueBlock } from "../components/Tag";
import { useProject } from "../context";
import { fmt, uniq } from "../format";
import { useAsync } from "../hooks";
import type { Measurement } from "../types";

export interface MeasurementWithReason extends Measurement {
  failure_reason: string | null;
}

/** Project measurements (failed and censored rows included, with failure reasons). */
export function useMeasurements(pid: number) {
  return useAsync(async () => {
    const [rows, targets] = await Promise.all([api.measurements(pid), api.targets(pid)]);
    return { rows: rows as MeasurementWithReason[], targets };
  }, [pid]);
}

export function StatusTag({ status }: { status: string }) {
  if (status === "ok") return <Tag kind="neutral">OK</Tag>;
  if (status === "failed") return <Tag kind="warning">FAILED</Tag>;
  if (status === "censored") return <Tag kind="warning">CENSORED</Tag>;
  return <Tag kind="neutral">{status.toUpperCase()}</Tag>;
}

export function MeasurementsPage() {
  const { pid } = useProject();
  const m = useMeasurements(pid);
  const [target, setTarget] = useState<string>("");
  const [status, setStatus] = useState<string>("");
  const [component, setComponent] = useState<string>("VM-2");
  const [chartTarget, setChartTarget] = useState<string>("viscosity");

  const rows = m.data?.rows ?? [];
  const targets = m.data?.targets ?? [];
  const filtered = rows.filter((r) => (!target || r.target === target) && (!status || r.status === status));
  const counts = useMemo(() => {
    const c = { total: filtered.length, ok: 0, failed: 0, censored: 0 };
    filtered.forEach((r) => {
      if (r.status === "ok") c.ok++;
      else if (r.status === "failed") c.failed++;
      else if (r.status === "censored") c.censored++;
    });
    return c;
  }, [filtered]);
  const components = uniq(rows.flatMap((r) => Object.keys(r.mixture)));
  const procVars = uniq(rows.flatMap((r) => Object.keys(r.process)));
  const tdef = targets.find((t) => t.name === chartTarget);

  if (m.loading && !m.data) return <Loading what="measurements" />;
  if (m.error) return <ErrorBox error={m.error} />;

  return (
    <div className="stack">
      <PageHead
        title="Measurements"
        lede="Every imported observation, including failed and censored results. Failed runs are retained and tagged; they are excluded from model training only by an explicit, recorded rule."
      />
      <div className="filters">
        <label className="field">
          <span>Target</span>
          <select value={target} onChange={(e) => setTarget(e.target.value)}>
            <option value="">all targets</option>
            {targets.map((t) => <option key={t.name} value={t.name}>{t.name} ({t.spec.unit})</option>)}
          </select>
        </label>
        <label className="field">
          <span>Status</span>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">all statuses (failed & censored shown)</option>
            <option value="ok">ok</option>
            <option value="failed">failed</option>
            <option value="censored">censored</option>
          </select>
        </label>
      </div>
      <div className="stat-row">
        <Stat label="Rows shown" value={counts.total} tag={<Tag kind="measured" />} />
        <Stat label="OK" value={counts.ok} />
        <Stat label="Failed (retained)" value={counts.failed} tag={<Tag kind="warning">FAILED</Tag>} />
        <Stat label="Censored (retained)" value={counts.censored} tag={<Tag kind="warning">CENSORED</Tag>} />
      </div>

      <Card
        title="Target vs mixture component"
        accent="measured"
        tag={<Tag kind="measured" />}
        actions={
          <>
            <select className="inline" value={chartTarget} onChange={(e) => setChartTarget(e.target.value)} aria-label="chart target">
              {targets.map((t) => <option key={t.name} value={t.name}>{t.name}</option>)}
            </select>
            <span className="muted small">vs</span>
            <select className="inline" value={component} onChange={(e) => setComponent(e.target.value)} aria-label="mixture component">
              {components.map((c) => <option key={c} value={c}>{c} (mass fraction)</option>)}
              {procVars.map((c) => <option key={`p:${c}`} value={`proc:${c}`}>{c} (process)</option>)}
            </select>
          </>
        }
      >
        <MeasurementScatter rows={rows.filter((r) => r.target === chartTarget)} component={component} unit={tdef?.spec.unit ?? ""} log={!!tdef?.spec.log_transform} />
        <div className="legend-inline">
          <span><span className="sw" style={{ background: "var(--measured)", borderRadius: "50%" }} />design run — MEASURED</span>
          <span><span className="sw" style={{ background: "var(--measured)", transform: "rotate(45deg) scale(.8)" }} />control sample — MEASURED</span>
          <span><span style={{ color: "var(--warning)", fontWeight: 700, marginRight: 4 }}>✕</span>FAILED run — no valid value (strip below the axis)</span>
        </div>
      </Card>

      <Card title={`Measurement records (${filtered.length})`} flush>
        <Table<MeasurementWithReason>
          rows={filtered}
          rowKey={(r) => r.measurement_id}
          maxHeight={520}
          rowClassName={(r) => (r.status !== "ok" ? "row-failed" : undefined)}
          columns={[
            { key: "id", header: "Measurement", className: "mono", render: (r) => r.measurement_id },
            { key: "exp", header: "Experiment", className: "mono", render: (r) => r.experiment },
            { key: "run", header: "Run", className: "mono", render: (r) => r.run_id },
            { key: "t", header: "Target", render: (r) => r.target },
            {
              key: "v",
              header: "Value",
              render: (r) =>
                r.value === null ? (
                  <span className="vb warning"><span>no valid value</span><Tag kind="warning">{r.status.toUpperCase()}</Tag></span>
                ) : (
                  <ValueBlock kind="measured">{fmt(r.value, 4)} {r.unit === "1" ? "" : r.unit}</ValueBlock>
                ),
            },
            { key: "s", header: "Status", render: (r) => <StatusTag status={r.status} /> },
            { key: "fr", header: "Failure reason", render: (r) => (r.failure_reason ? <span className="small">{r.failure_reason}</span> : <span className="muted">—</span>) },
            { key: "role", header: "Role", render: (r) => (r.role === "control" ? <Tag kind="info">CONTROL</Tag> : <span className="small">{r.role}</span>) },
            { key: "rg", header: "Replicate group", className: "mono", render: (r) => r.replicate_group },
            { key: "b", header: "Batch", className: "mono", render: (r) => r.batch_id ?? "—" },
            { key: "blk", header: "Block", className: "mono", render: (r) => r.block ?? "—" },
            { key: "lot", header: "Lots", className: "mono", render: (r) => r.lot_ids ?? "—" },
            { key: "mix", header: "Mixture", className: "mono", render: (r) => Object.entries(r.mixture).map(([k, v]) => `${k} ${v.toFixed(3)}`).join(" · ") },
            { key: "d", header: "Measured on", className: "nowrap", render: (r) => r.measured_on },
          ]}
        />
      </Card>
      {rows.some((r) => r.status === "failed") && (
        <Notice kind="warning" label={<Tag kind="warning">FAILED RUNS RETAINED</Tag>}>
          Failed observations have no valid value. They stay in the record and in this table; model manifests list them as explicit exclusions with their reasons.
        </Notice>
      )}
    </div>
  );
}

function MeasurementScatter({ rows, component, unit, log }: { rows: MeasurementWithReason[]; component: string; unit: string; log: boolean }) {
  const getX = (r: Measurement) => (component.startsWith("proc:") ? r.process[component.slice(5)] : r.mixture[component]);
  const ok = rows.filter((r) => r.value !== null);
  const failed = rows.filter((r) => r.value === null);
  const xlabel = component.startsWith("proc:") ? component.slice(5) : `${component} (mass fraction)`;
  return (
    <Plot
      ariaLabel={`measured values against ${xlabel}`}
      height={400}
      deps={[rows.length, rows[0]?.target, component, log, unit]}
      build={(c) => {
        const groups = [
          { name: "design run (MEASURED)", rs: ok.filter((r) => r.role !== "control"), symbol: "circle", size: 9 },
          { name: "control sample (MEASURED)", rs: ok.filter((r) => r.role === "control"), symbol: "diamond", size: 10 },
        ];
        const data: Record<string, unknown>[] = groups.map((g) => ({
          type: "scatter",
          mode: "markers",
          name: g.name,
          x: g.rs.map(getX),
          y: g.rs.map((r) => r.value),
          text: g.rs.map((r) => `${r.measurement_id}<br>run ${r.run_id} · ${r.block ?? ""} · ${r.lot_ids ?? ""}`),
          hovertemplate: `%{text}<br>${xlabel} %{x:.3f}<br>value %{y:.4g} ${unit}<extra>MEASURED</extra>`,
          marker: { color: c.measured, symbol: g.symbol, size: g.size, opacity: 0.85, line: { color: c.surface, width: 1.5 } },
        }));
        data.push({
          type: "scatter",
          mode: "markers",
          name: "FAILED — no valid value",
          x: failed.map(getX),
          y: failed.map(() => 0),
          yaxis: "y2",
          text: failed.map((r) => `${r.measurement_id}<br>${r.failure_reason ?? "failed"}`),
          hovertemplate: `%{text}<br>${xlabel} %{x:.3f}<extra>FAILED</extra>`,
          marker: { color: c.warning, symbol: "x-thin-open", size: 12, line: { width: 2.5, color: c.warning } },
        });
        return {
          data,
          layout: {
            margin: { l: 64, r: 16, t: 12, b: 48 },
            showlegend: false,
            xaxis: { title: { text: xlabel }, anchor: "y2" },
            yaxis: { title: { text: `measured (${unit})${log ? " · log scale" : ""}` }, type: log ? "log" : "linear", domain: [0.18, 1], ...(log ? LOG_TICKS : {}) },
            yaxis2: { domain: [0, 0.1], showticklabels: false, showgrid: false, zeroline: false, range: [-1, 1], title: { text: "FAILED", font: { size: 10, color: c.warning } } },
          },
        };
      }}
    />
  );
}
