import { useState, type FormEvent } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { api } from "../api";
import { ErrorBox, Notice } from "../components/Notice";
import { Tag } from "../components/Tag";
import type { Me } from "../types";

export function LoginPage({ onLoggedIn }: { onLoggedIn: (me: Me) => void }) {
  const navigate = useNavigate();
  const location = useLocation();
  const state = (location.state ?? {}) as { from?: string; expired?: boolean };
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.login(username, password);
      const me = await api.me();
      onLoggedIn(me);
      const from = state.from && state.from.startsWith("/") && !state.from.startsWith("/login") ? state.from : "/projects";
      navigate(from, { replace: true });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-wrap">
      <div className="login-art">
        <div>
          <h1>TERTIUSMEDICO</h1>
          <p style={{ fontSize: 15, marginTop: 6 }}>Formulation Lab — researcher interface</p>
          <div className="stack" style={{ marginTop: 28, maxWidth: 520, gap: 10 }}>
            <div className="row"><Tag kind="measured" /> experimental data, with failures and censoring kept visible</div>
            <div className="row"><Tag kind="calculated" /> quantities derived from recorded data</div>
            <div className="row"><Tag kind="predicted" /> model outputs with intervals — not evidence</div>
            <div className="row"><Tag kind="simulated" /> process simulations — not process validation</div>
            <div className="row"><Tag kind="approved" /> records approved through review</div>
            <div className="row"><Tag kind="warning" /> uncertainty and validation warnings</div>
          </div>
        </div>
        <p className="small" style={{ opacity: 0.8 }}>
          Non-clinical research use only. Nothing here is a laboratory instruction, manufacturing release, shelf-life
          assignment or treatment recommendation. No regulatory compliance is claimed.
        </p>
      </div>
      <form className="login-panel" onSubmit={submit}>
        <h2>Sign in</h2>
        {state.expired && <Notice kind="info">Your session ended. Sign in again to continue.</Notice>}
        <label className="field">
          <span>Username</span>
          <input autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </label>
        <label className="field">
          <span>Password</span>
          <input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        <ErrorBox error={error} />
        <div className="form-actions">
          <button className="btn primary" type="submit" disabled={busy}>
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </div>
        <p className="muted small">Access is project-scoped: you only see projects you are a member of, with your project role.</p>
      </form>
    </div>
  );
}
