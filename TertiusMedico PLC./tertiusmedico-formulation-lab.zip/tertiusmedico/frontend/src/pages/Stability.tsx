import { useState } from "react";
import { api } from "../api";
import { alpha, Plot } from "../components/Plot";
import { Card, Loading, PageHead, Stat } from "../components/Card";
import { ErrorBox, Notice } from "../components/Notice";
import { Table } from "../components/Table";
import { Tag, ValueBlock } from "../components/Tag";
import { useProject } from "../context";
import { fmt, uniq } from "../format";
import { useAsync } from "../hooks";
import type { Forecast, Poolability, StabilityTrends, Trend } from "../types";

const FORMULATIONS = ["SUS-DEMO-REF", "SUS-DEMO-HISURF"];
const DEFAULT_LIMIT: Record<string, number> = { assay: 95, degradant: 1.0 };
const LOT_SYMBOL = ["circle", "square", "triangle-up", "diamond"];
const LOT_DASH = ["dash", "dot", "dashdot", "longdash"];

function hasForecast(f: Trend["forecast"]): f is Forecast {
  return (f as Forecast).time !== undefined;
}

export function StabilityPage() {
  const { pid } = useProject();
  const [attribute, setAttribute] = useState("assay");
  const [formulation, setFormulation] = useState(FORMULATIONS[0]);
  const [limit, setLimit] = useState<string>(String(DEFAULT_LIMIT.assay));
  const limitNum = limit.trim() === "" ? null : Number(limit);
  const st = useAsync(() => api.stabilityTrends(pid, attribute, formulation, limitNum), [pid, attribute, formulation, limitNum]);

  return (
    <div className="stack">
      <PageHead
        title="Stability trends"
        lede="MEASURED stability results per storage condition, packaging and lot, with exploratory linear trends. Trends and forecasts are PREDICTED quantities."
      />
      <Notice kind="warning" label={<Tag kind="warning">EXPLORATORY — NOT A SHELF-LIFE ASSIGNMENT</Tag>}>
        {st.data?.notice ??
          "Regression or accelerated data alone do not establish shelf life; that requires a governed stability protocol, long-term data, applicable guidance and quality approval."}
      </Notice>
      <div className="filters">
        <label className="field">
          <span>Attribute</span>
          <select
            value={attribute}
            onChange={(e) => {
              setAttribute(e.target.value);
              setLimit(String(DEFAULT_LIMIT[e.target.value] ?? ""));
            }}
          >
            <option value="assay">assay (% of initial; lower limit)</option>
            <option value="degradant">degradant (%; upper limit)</option>
          </select>
        </label>
        <label className="field">
          <span>Formulation</span>
          <select value={formulation} onChange={(e) => setFormulation(e.target.value)}>
            {FORMULATIONS.map((f) => <option key={f} value={f}>{f}</option>)}
          </select>
        </label>
        <label className="field" style={{ width: 170 }}>
          <span>Exploratory limit ({attribute === "assay" ? "lower" : "upper"})</span>
          <input type="number" step="any" value={limit} onChange={(e) => setLimit(e.target.value)} />
        </label>
      </div>
      {st.loading && !st.data && <Loading what="trends" />}
      <ErrorBox error={st.error} />
      {st.data && <TrendsView data={st.data} attribute={attribute} limit={limitNum} />}
    </div>
  );
}

function TrendsView({ data, attribute, limit }: { data: StabilityTrends; attribute: string; limit: number | null }) {
  const trends = data.trends;
  if (!trends.length) return <Notice kind="info">No stability results for this selection.</Notice>;
  const facets = uniq(trends.map((t) => `${t.key.condition}|${t.key.packaging}`)).sort();
  const lots = uniq(trends.map((t) => String(t.key.lot))).sort();
  const unit = trends[0].unit;
  const cols = 2;
  const rows = Math.ceil(facets.length / cols);
  const excludedTotal = trends.reduce((a, t) => a + t.excluded.length, 0);

  return (
    <>
      <div className="stat-row">
        <Stat label="Trend fits" value={trends.length} tag={<Tag kind="predicted">TREND</Tag>} />
        <Stat label="Measured points" value={trends.reduce((a, t) => a + t.observations.length, 0)} tag={<Tag kind="measured" />} />
        <Stat label="Censored results (< LOD)" value={data.censored_count} tag={data.censored_count ? <Tag kind="warning">CENSORED</Tag> : undefined} />
        <Stat label="Excluded from fits" value={excludedTotal} tag={excludedTotal ? <Tag kind="warning">EXCLUDED</Tag> : undefined} />
      </div>
      {data.censored_count > 0 && (
        <Notice kind="warning" label={<Tag kind="warning">CENSORED DATA</Tag>}>
          {data.censored_count} {attribute} result(s) were below the detection limit. They are not plotted as values and are excluded from the linear fits (listed per trend below), which biases early-time slopes.
        </Notice>
      )}
      <Card title={`${attribute} vs time — by condition and packaging`} accent="measured" tag={<><Tag kind="measured" /><Tag kind="predicted">TREND / FORECAST</Tag></>}>
        <Plot
          ariaLabel={`stability ${attribute} trends by condition, packaging and lot`}
          height={rows * 300 + 40}
          deps={[data, limit]}
          build={(c) => {
            const out: Record<string, unknown>[] = [];
            const layout: Record<string, unknown> = {
              grid: { rows, columns: cols, pattern: "independent", xgap: 0.1, ygap: 0.22 },
              showlegend: false,
              margin: { l: 60, r: 16, t: 30, b: 44 },
              annotations: [] as Record<string, unknown>[],
              shapes: [] as Record<string, unknown>[],
            };
            const anns = layout.annotations as Record<string, unknown>[];
            const shapes = layout.shapes as Record<string, unknown>[];
            facets.forEach((fk, i) => {
              const ax = i === 0 ? "" : String(i + 1);
              const [cond, pack] = fk.split("|");
              const ts = trends.filter((t) => `${t.key.condition}|${t.key.packaging}` === fk);
              let tmax = 0;
              ts.forEach((t) => {
                const li = Math.max(0, lots.indexOf(String(t.key.lot)));
                const f = t.forecast;
                if (hasForecast(f)) {
                  tmax = Math.max(tmax, ...f.time);
                  out.push({
                    type: "scatter", mode: "lines", x: [...f.time, ...[...f.time].reverse()], y: [...f.ci_upper, ...[...f.ci_lower].reverse()],
                    fill: "toself", fillcolor: alpha(c.predicted, 0.1), line: { width: 0 }, hoverinfo: "skip", xaxis: `x${ax}`, yaxis: `y${ax}`,
                  });
                  out.push({
                    type: "scatter", mode: "lines", x: f.time, y: f.mean, line: { color: c.predicted, width: 2, dash: LOT_DASH[li] },
                    name: `trend ${t.key.lot}`, hovertemplate: `lot ${t.key.lot}<br>t %{x:.1f} mo<br>trend %{y:.3f} ${unit}<extra>PREDICTED (trend)</extra>`,
                    xaxis: `x${ax}`, yaxis: `y${ax}`,
                  });
                  const firstExt = f.time.find((_, k) => f.extrapolated[k]);
                  if (firstExt !== undefined) {
                    shapes.push({ type: "rect", xref: `x${ax}`, yref: `y${ax} domain`, x0: t.max_time_months, x1: Math.max(...f.time), y0: 0, y1: 1, fillcolor: c.line, opacity: 0.25, line: { width: 0 }, layer: "below" });
                  }
                }
                out.push({
                  type: "scatter", mode: "markers", x: t.observations.map((o) => o.time), y: t.observations.map((o) => o.value),
                  marker: { color: c.measured, size: 8, symbol: LOT_SYMBOL[li], line: { color: c.surface, width: 1.5 } },
                  name: `measured ${t.key.lot}`, hovertemplate: `lot ${t.key.lot}<br>t %{x} mo<br>%{y:.3f} ${unit}<extra>MEASURED</extra>`,
                  xaxis: `x${ax}`, yaxis: `y${ax}`,
                });
              });
              if (limit !== null && Number.isFinite(limit)) {
                shapes.push({ type: "line", xref: `x${ax} domain`, yref: `y${ax}`, x0: 0, x1: 1, y0: limit, y1: limit, line: { color: c.warning, width: 1.5, dash: "dot" } });
              }
              anns.push({ text: `<b>${cond}</b> · ${pack}`, xref: `x${ax} domain`, yref: `y${ax} domain`, x: 0, y: 1.1, showarrow: false, xanchor: "left", font: { size: 12, color: c.ink } });
              layout[`xaxis${ax}`] = { title: { text: "time (months)" }, range: [-0.3, tmax + 0.3] };
              layout[`yaxis${ax}`] = { title: { text: `${attribute} (${unit})` } };
            });
            return { data: out, layout };
          }}
        />
        <div className="legend-inline">
          {lots.map((l, i) => (
            <span key={l}>
              <span className="sw" style={{ background: "var(--measured)", borderRadius: LOT_SYMBOL[i] === "circle" ? "50%" : 2 }} />
              lot {l} — MEASURED ({LOT_SYMBOL[i]})
            </span>
          ))}
          {lots.map((l, i) => (
            <span key={`t${l}`}>
              <span className="sw dash" style={{ borderColor: "var(--predicted)", borderTopStyle: LOT_DASH[i] === "dot" ? "dotted" : "dashed" }} />
              lot {l} — trend, PREDICTED ({LOT_DASH[i]})
            </span>
          ))}
          <span><span className="sw" style={{ background: "color-mix(in srgb, var(--predicted) 18%, transparent)" }} />95 % CI of the mean</span>
          <span><span className="sw" style={{ background: "var(--line)" }} />beyond the data (extrapolated)</span>
          {limit !== null && <span><span className="sw dash" style={{ borderColor: "var(--warning)", borderTopStyle: "dotted" }} />exploratory limit {limit} — WARNING: not a specification decision</span>}
        </div>
      </Card>

      <div className="grid-2">
        <Card title="Poolability diagnostic" tag={<Tag kind="calculated">DIAGNOSTIC</Tag>}>
          {(data.poolability ?? []).length ? (
            <div className="stack" style={{ gap: 8 }}>
              <Table<Poolability>
                rows={data.poolability ?? []}
                rowKey={(r, i) => `${r.condition}-${r.packaging}-${i}`}
                columns={[
                  { key: "c", header: "Condition", render: (r) => <span className="mono">{r.condition}</span> },
                  { key: "p", header: "Packaging", render: (r) => <span className="mono">{r.packaging}</span> },
                  { key: "f", header: "F", render: (r) => fmt(r.F) },
                  { key: "pv", header: "p-value", render: (r) => fmt(r.p_value) },
                  {
                    key: "ok",
                    header: "Slopes poolable across lots?",
                    render: (r) =>
                      !r.testable ? (
                        <Tag kind="warning">NOT TESTABLE</Tag>
                      ) : r.slopes_poolable ? (
                        <ValueBlock kind="calculated">yes (p ≥ {fmt(r.alpha)})</ValueBlock>
                      ) : (
                        <ValueBlock kind="warning" tag="NOT POOLABLE">no (p &lt; {fmt(r.alpha)})</ValueBlock>
                      ),
                  },
                ]}
              />
              <p className="small muted">
                Equal-slope F-test across lots for each storage condition and packaging (α = 0.25 by convention). Pooling
                decisions belong to the stability protocol.
              </p>
            </div>
          ) : (
            <p className="muted">No poolability diagnostic for this selection.</p>
          )}
        </Card>
        <Card title="Exploratory limit crossings" tag={<Tag kind="warning">EXPLORATORY</Tag>}>
          <div className="stack" style={{ gap: 6 }}>
            {trends.map((t, i) => {
              const x = t.exploratory_limit_crossing;
              return (
                <div key={i} className="small">
                  <span className="mono">{t.key.condition} · {t.key.packaging} · {t.key.lot}</span>:{" "}
                  {x ? (
                    <span className="vb warning"><span>{x.message}</span>{x.extrapolated && <Tag kind="warning">EXTRAPOLATED</Tag>}</span>
                  ) : (
                    <span className="muted">no limit given</span>
                  )}
                </div>
              );
            })}
            <p className="small muted" style={{ marginTop: 6 }}>These are statistical crossings of a confidence bound — not shelf-life assignments.</p>
          </div>
        </Card>
      </div>

      <Card title="Trend fits" flush tag={<Tag kind="predicted">TREND</Tag>}>
        <Table<Trend>
          rows={trends}
          rowKey={(_, i) => String(i)}
          columns={[
            { key: "c", header: "Condition", className: "mono", render: (t) => String(t.key.condition) },
            { key: "p", header: "Packaging", className: "mono", render: (t) => String(t.key.packaging) },
            { key: "l", header: "Lot", className: "mono", render: (t) => String(t.key.lot) },
            { key: "m", header: "Method", className: "mono", render: (t) => String(t.key.method) },
            { key: "n", header: "n", className: "num", render: (t) => t.n },
            { key: "s", header: `Slope (${t0(trends)}/month) ± SE`, className: "num", render: (t) => `${fmt(t.slope_per_month, 4)} ± ${fmt(t.se_slope, 2)}` },
            { key: "i", header: "Intercept", className: "num", render: (t) => fmt(t.intercept, 5) },
            { key: "r2", header: "R²", className: "num", render: (t) => fmt(t.r2, 3) },
            { key: "rs", header: "Resid. SD", className: "num", render: (t) => fmt(t.resid_sd, 3) },
            { key: "mt", header: "Last time (mo)", className: "num", render: (t) => t.max_time_months },
            { key: "x", header: "Excluded rows", render: (t) => (t.excluded.length ? <Tag kind="warning" title={t.excluded.join(", ")}>{t.excluded.length} EXCLUDED</Tag> : "—") },
            { key: "f", header: "Forecast", render: (t) => (hasForecast(t.forecast) ? <span className="small">to {fmt(Math.max(...t.forecast.time), 3)} mo</span> : <Tag kind="warning" title={(t.forecast as { refused: string }).refused}>REFUSED</Tag>) },
          ]}
        />
      </Card>
    </>
  );
}

function t0(trends: Trend[]) {
  return trends[0]?.unit ?? "";
}
