import { useCallback, useContext, useEffect, useState } from "react";
import { Navigate, NavLink, Outlet, Route, Routes, useLocation, useMatch, useNavigate } from "react-router-dom";
import { api, getToken, setToken, UNAUTHORIZED_EVENT } from "./api";
import { AuthContext, lastProject, ProjectContext, rememberProject, useAuth } from "./context";
import { useAsync } from "./hooks";
import type { Me } from "./types";
import { LoginPage } from "./pages/Login";
import { ProjectsPage } from "./pages/Projects";
import { MaterialsPage } from "./pages/Materials";
import { FormulationsPage } from "./pages/Formulations";
import { ExperimentsPage } from "./pages/Experiments";
import { MeasurementsPage } from "./pages/Measurements";
import { ModelsPage } from "./pages/Models";
import { OptimisationPage } from "./pages/Optimisation";
import { StabilityPage } from "./pages/Stability";
import { BatchesPage } from "./pages/Batches";
import { ReportsPage } from "./pages/Reports";
import { Tag } from "./components/Tag";
import { NAV } from "./nav";


export function App() {
  const navigate = useNavigate();
  const location = useLocation();
  const [me, setMe] = useState<Me | null>(null);
  const [checked, setChecked] = useState(false);

  const logout = useCallback(() => {
    setToken(null);
    setMe(null);
    navigate("/login", { replace: true });
  }, [navigate]);

  useEffect(() => {
    const h = () => {
      setMe(null);
      navigate("/login", { replace: true, state: { from: location.pathname, expired: true } });
    };
    window.addEventListener(UNAUTHORIZED_EVENT, h);
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, h);
  }, [navigate, location.pathname]);

  useEffect(() => {
    if (!getToken()) {
      setChecked(true);
      return;
    }
    api
      .me()
      .then(setMe)
      .catch(() => setMe(null))
      .finally(() => setChecked(true));
  }, []);

  if (!checked) return <div className="spinner">Checking session…</div>;

  return (
    <AuthContext.Provider value={{ me, logout }}>
      <Routes>
        <Route path="/login" element={<LoginPage onLoggedIn={setMe} />} />
        <Route element={me ? <Shell /> : <Navigate to="/login" replace state={{ from: location.pathname }} />}>
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/p/:pid" element={<ProjectScope />}>
            <Route index element={<ProjectsPage />} />
            <Route path="materials" element={<MaterialsPage />} />
            <Route path="formulations" element={<FormulationsPage />} />
            <Route path="experiments" element={<ExperimentsPage />} />
            <Route path="measurements" element={<MeasurementsPage />} />
            <Route path="models" element={<ModelsPage />} />
            <Route path="optimisation" element={<OptimisationPage />} />
            <Route path="stability" element={<StabilityPage />} />
            <Route path="batches" element={<BatchesPage />} />
            <Route path="reports" element={<ReportsPage />} />
          </Route>
        </Route>
        <Route path="*" element={<Navigate to={me ? "/projects" : "/login"} replace />} />
      </Routes>
    </AuthContext.Provider>
  );
}

/** Project-scoped routes: shows the server's refusal (e.g. not a member) instead of the page. */
function ProjectScope() {
  const ctx = useContext(ProjectContext);
  if (ctx?.error)
    return (
      <div className="notice error">
        <Tag kind="error">SERVER</Tag>
        <div>{ctx.error.message}</div>
      </div>
    );
  if (!ctx?.summary) return <div className="spinner">Loading project…</div>;
  return <Outlet />;
}

function Shell() {
  const { me, logout } = useAuth();
  const m = useMatch("/p/:pid/*");
  const pidFromRoute = m ? Number(m.params.pid) : null;
  const pid = pidFromRoute ?? lastProject();
  const summary = useAsync(() => (pidFromRoute ? api.project(pidFromRoute) : Promise.resolve(undefined)), [pidFromRoute]);
  const s = summary.data;
  useEffect(() => {
    if (pidFromRoute && s) rememberProject(pidFromRoute);
  }, [pidFromRoute, s]);
  const ctx = pidFromRoute
    ? { pid: pidFromRoute, summary: s, role: s?.role, reloadSummary: summary.reload, error: summary.error }
    : null;

  return (
    <div className="shell">
      <nav className="nav" aria-label="primary">
        <div className="nav-brand">
          <div className="wordmark">TERTIUSMEDICO</div>
          <div className="sub">Formulation Lab · research interface</div>
        </div>
        <ol>
          {NAV.map((n) => (
            <li key={n.label}>
              {n.path === "" ? (
                <NavLink to={pid ? `/p/${pid}` : "/projects"} end className={({ isActive }) => (isActive ? "active" : "")}>
                  {n.label}
                </NavLink>
              ) : pid ? (
                <NavLink to={`/p/${pid}/${n.path}`} className={({ isActive }) => (isActive ? "active" : "")}>
                  {n.label}
                </NavLink>
              ) : (
                <span className="disabled" title="pick a project first">
                  {n.label}
                </span>
              )}
            </li>
          ))}
        </ol>
        <div className="nav-legend" aria-label="value classes">
          <div className="row"><span className="sw" style={{ background: "#0f8b8d" }} />MEASURED · experimental data</div>
          <div className="row"><span className="sw" style={{ background: "#6d4bd1" }} />PREDICTED · model output</div>
          <div className="row"><span className="sw" style={{ background: "#7c8699" }} />CALCULATED · derived</div>
          <div className="row"><span className="sw" style={{ background: "#b7791f" }} />WARNING · uncertainty</div>
        </div>
      </nav>
      <div className="main">
        <header className="topbar">
          <div className="proj">
            {s ? (
              <>
                <span className="code">{s.code}</span>
                <span className="name" title={s.name}>{s.name}</span>
                <span className="role-chip" title="your role in this project">role: {s.role}</span>
              </>
            ) : (
              <span className="muted">No project selected</span>
            )}
          </div>
          <div className="user">
            <span>
              {me?.full_name || me?.username} <span className="mono muted">({me?.username})</span>
            </span>
            <button className="btn small" onClick={logout}>
              Sign out
            </button>
          </div>
        </header>
        <div className="status-banner" role="note">
          <strong>NON-CLINICAL RESEARCH USE ONLY</strong>
          <span>Predictions and simulations are not experimental evidence.</span>
          <span>Not a laboratory instruction, manufacturing release, shelf-life assignment or treatment recommendation.</span>
          {s?.synthetic && <span className="synthetic-flag">SYNTHETIC DEMONSTRATION — fictional materials and data</span>}
        </div>
        <main className="content">
          <ProjectContext.Provider value={ctx}>
            <Outlet />
          </ProjectContext.Provider>
        </main>
        <footer className="footer">
          <span>TERTIUSMEDICO — Formulation Lab · non-clinical formulation research decision support</span>
          <span>Predictions are not evidence; every value is tagged MEASURED / CALCULATED / PREDICTED / SIMULATED.</span>
          <span>No regulatory compliance is claimed.</span>
          {s?.synthetic && <strong>Project {s.code} is a SYNTHETIC DEMONSTRATION.</strong>}
        </footer>
      </div>
    </div>
  );
}
