import { useCallback, useEffect, useRef, useState } from "react";

export interface AsyncState<T> {
  data: T | undefined;
  error: Error | undefined;
  loading: boolean;
  reload: () => void;
}

/** Runs an async loader whenever `deps` change; exposes data/error/loading and a reload(). */
export function useAsync<T>(loader: () => Promise<T>, deps: unknown[]): AsyncState<T> {
  const [data, setData] = useState<T | undefined>(undefined);
  const [error, setError] = useState<Error | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  const loaderRef = useRef(loader);
  loaderRef.current = loader;

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(undefined);
    loaderRef
      .current()
      .then((d) => {
        if (alive) setData(d);
      })
      .catch((e: unknown) => {
        if (alive) setError(e instanceof Error ? e : new Error(String(e)));
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { data, error, loading, reload };
}

/** Wraps a mutating call: tracks busy state and the server's error message. */
export function useAction<A extends unknown[], R>(fn: (...args: A) => Promise<R>) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<R | null>(null);
  const run = useCallback(
    async (...args: A): Promise<R | null> => {
      setBusy(true);
      setError(null);
      try {
        const r = await fn(...args);
        setResult(r);
        return r;
      } catch (e) {
        const err = e as Error & { status?: number };
        setError(err.status ? `HTTP ${err.status}: ${err.message}` : err.message);
        return null;
      } finally {
        setBusy(false);
      }
    },
    [fn],
  );
  return { run, busy, error, result, setError, setResult };
}

/** Tracks the colour scheme so charts can re-read CSS tokens when it changes. */
export function useColorScheme(): "light" | "dark" {
  const [q] = useState<MediaQueryList | null>(() =>
    typeof window !== "undefined" && window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null,
  );
  const [dark, setDark] = useState<boolean>(q ? q.matches : false);
  useEffect(() => {
    if (!q) return;
    const h = (e: MediaQueryListEvent) => setDark(e.matches);
    q.addEventListener("change", h);
    return () => q.removeEventListener("change", h);
  }, [q]);
  return dark ? "dark" : "light";
}
