# TERTIUSMEDICO — Formulation Lab · researcher interface

React 18 + TypeScript (strict) single-page app for the non-clinical formulation research API in `../backend`.
It talks only to the relative `/api` base, so the same bundle runs behind the Vite dev proxy and the nginx
proxy in production.

> Non-clinical research use only. Predictions and simulations are not experimental evidence. The interface
> labels every value as MEASURED (teal), CALCULATED (slate), PREDICTED (violet), SIMULATED or APPROVED, and
> shows warnings in amber with a written label.

## Stack

| Package | Version |
|---|---|
| vite / @vitejs/plugin-react | 6.4.5 / 4.7.0 |
| react / react-dom | 18.3.1 |
| react-router-dom | 6.30.6 |
| plotly.js-dist-min | 3.7.0 (wrapped by `src/components/Plot.tsx`; lazy-loaded into its own chunk) |
| typescript | 5.9.3 |

Versions are pinned exactly (`.npmrc` sets `save-exact`). There is no UI kit. The styles are hand-written
CSS with design tokens on `:root` in `src/styles.css`, and dark mode follows `prefers-color-scheme`.

## Development

You need Node 22 and a running backend on `http://localhost:8000`.

```bash
# backend with demo data (from the repository root)
cd backend
export TERTIUS_DATABASE_URL=sqlite:////tmp/ui_demo.db TERTIUS_STORAGE_ROOT=/tmp/ui_store \
       TERTIUS_SECRET_KEY=ui-dev-secret-ui-dev-secret-ui-dev-secret
python3 -m tertius.cli demo --out /tmp/ui_demo_out
uvicorn tertius.api.main:app --port 8000

# frontend
cd frontend
npm ci
npm run dev        # http://localhost:5173, proxies /api → http://localhost:8000
```

The demo creates project `SUS-DEMO` with the users `rhea` (researcher), `rowan` (reviewer) and `admin`.
Their demo-only passwords are defined in `backend/tertius/demo.py` (overridable via `TERTIUS_DEMO_*_PASSWORD`).

## Build and preview

```bash
npm run build      # tsc -b (strict type check) && vite build → dist/
npm run preview    # http://localhost:4173, serves dist/ with the production CSP + security headers and the /api proxy
```

## Production image

```bash
docker build -t tertius-ui frontend/
docker run -p 8080:80 --network <net-with-api> tertius-ui
```

The image is built in two stages: `node:22-alpine` runs `npm ci && npm run build`, then `nginx:1.27-alpine`
serves `dist/` with `nginx.conf`. The nginx configuration:

- serves the SPA with a history fallback to `index.html`;
- proxies `/api/` to `http://api:8000`, so the API container must be reachable as `api`;
- sets `client_max_body_size 25m`;
- sends `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer` and a
  Content-Security-Policy. The policy allows self, inline styles (the chart library needs them), and `blob:`
  so the HTML report can open in a new tab;
- serves `/healthz` for container health checks.

## Layout

```
src/
  api.ts            typed fetch client (bearer token, 401 → back to login, server error messages surfaced)
  types.ts          response shapes of the backend routers
  App.tsx, nav.ts   routing, shell (navigation, project header with role, persistent status banner/footer)
  components/       Tag/StatusBadge/SourceTag, Notice/WarningList/ErrorBox, Table/RecordTable, Plot,
                    StateStepper, Drawer, Card/KV/Stat/Tabs, Hash
  pages/            Projects, Materials, Formulations (+ research domains, designs), Experiments,
                    Measurements, Models, Optimisation, Stability, Batches, Reports
```

The server enforces roles and separation of duties. The UI shows the server's 403/409 messages as they are
returned and does not pre-empt them.

## Known backend quirk handled in the UI

`GET /api/projects/{id}/proposals` spreads the stored proposal content over the record. The content holds
its own `"status": "proposed"`, which overrides the reviewed status. The Optimisation and Reports pages
therefore derive the real status from the review record: a reviewed proposal with a follow-up experiment is
shown as *accepted for planning*, otherwise as *rejected*. The derived status is marked as derived in the UI.
