import pandas as pd

from tertius.science.quality import TargetSpec, pooled_replicate_sd, validate_measurements

SPEC = {"visc": TargetSpec("visc", "mPa*s", "M", "t0", 0, 1e6, True), "deg": TargetSpec("deg", "%", "HPLC", "t0", 0, 100)}


def row(i, **kw):
    r = dict(measurement_id=f"m{i}", run_id=f"r{i}", target="visc", value=10.0, unit="mPa*s", status="ok",
             replicate_group="g1", batch_id=f"b{i}", measured_on="2026-01-10", instrument_id="I1", lod=None,
             failure_reason=None, **{"mix:A": 0.6, "mix:B": 0.4})
    r.update(kw)
    return r


def codes(df, **kw):
    return {f.code for f in validate_measurements(pd.DataFrame(df), SPEC, mixture_cols=["mix:A", "mix:B"], **kw)}


def test_clean_data_has_no_errors():
    f = validate_measurements(pd.DataFrame([row(1), row(2, value=10.5)]), SPEC, mixture_cols=["mix:A", "mix:B"])
    assert not [x for x in f if x.severity == "error"]


def test_each_defect_is_detected():
    assert "unit_mismatch" in codes([row(1, unit="g")])
    assert "missing_value" in codes([row(1, value=None)])
    assert "out_of_physical_bounds" in codes([row(1, value=-3.0)])
    assert "missing_batch_id" in codes([row(1, batch_id=None)])
    assert "composition_total" in codes([row(1, **{"mix:A": 0.5})])
    assert "below_lod_not_censored" in codes([row(1, target="deg", unit="%", value=0.01, lod=0.05)])
    assert "replicate_mismatch" in codes([row(1), row(2, **{"mix:A": 0.5, "mix:B": 0.5})])
    assert "conflicting_replicates" in codes([row(1, value=10.0), row(2, value=20.0)])
    assert "unknown_target" in codes([row(1, target="zeta")])
    assert "duplicate_measurement_id" in codes([row(1), row(1)])
    assert "calibration_expired" in codes([row(1)], instruments={"I1": {"calibration_due": "2026-01-01"}})
    assert "instrument_unknown" in codes([row(1)], instruments={})


def test_failed_and_censored_are_retained_and_reported():
    df = pd.DataFrame([row(1, status="failed", value=None, failure_reason="phase separation"),
                       row(2, target="deg", unit="%", status="censored", value=None, lod=0.05), row(3)])
    f = validate_measurements(df, SPEC, mixture_cols=["mix:A", "mix:B"])
    assert {"failed_runs", "censored"} <= {x.code for x in f}
    assert not [x for x in f if x.severity == "error"]
    assert len(df) == 3  # nothing removed


def test_pooled_replicate_sd():
    df = pd.DataFrame([row(1, value=10.0), row(2, value=12.0), row(3, value=20.0, replicate_group="g2"),
                       row(4, value=22.0, replicate_group="g2")])
    r = pooled_replicate_sd(df, "visc")
    assert r["dof"] == 2 and abs(r["sd"] - 2 ** 0.5) < 1e-9
