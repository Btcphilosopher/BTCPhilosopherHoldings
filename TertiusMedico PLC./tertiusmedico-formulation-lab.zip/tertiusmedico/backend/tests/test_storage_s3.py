"""S3-compatible object storage adapter, exercised against moto's in-process S3 mock."""
import pytest

moto = pytest.importorskip("moto")


def test_s3_storage_roundtrip(monkeypatch):
    from moto import mock_aws
    monkeypatch.setenv("AWS_DEFAULT_REGION", "us-east-1")
    from tertius.config import Settings
    from tertius.storage import S3Storage
    with mock_aws():
        s = Settings(storage_backend="s3", s3_endpoint=None, s3_bucket="tertius-test", s3_access_key="k",
                     s3_secret_key="s")
        st = S3Storage(s)
        st.put("projects/1/raw/abc/x.csv", b"a,b\n1,2\n", "text/csv")
        assert st.get("projects/1/raw/abc/x.csv") == b"a,b\n1,2\n"
        S3Storage(s)  # existing bucket is reused


def test_local_storage_rejects_path_traversal(tmp_path):
    from tertius.storage import LocalStorage, UploadRejected
    st = LocalStorage(str(tmp_path))
    with pytest.raises(UploadRejected):
        st.put("../../escape.txt", b"x", "text/plain")
