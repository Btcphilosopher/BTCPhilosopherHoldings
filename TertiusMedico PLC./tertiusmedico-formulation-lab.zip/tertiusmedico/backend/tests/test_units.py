import pytest

from tertius.science.units import (DENSITY, DimensionError, Quantity, Temperature, UnitParseError, amount_to_mass,
                                   dimension_of, divide, mass_to_volume, multiply, volume_to_mass)


def test_conversions_and_dimensions():
    assert Quantity(1, "kg").to("g").value == pytest.approx(1000)
    assert Quantity(250, "mL").to("L").value == pytest.approx(0.25)
    assert Quantity(1, "mPa*s").to("Pa*s").value == pytest.approx(1e-3)
    assert Quantity(1, "cP").to("mPa*s").value == pytest.approx(1)
    assert Quantity(5, "%").to("fraction").value == pytest.approx(0.05)
    assert dimension_of("mg/mL") == DENSITY
    assert Quantity(1, "M").to("mmol/mL").value == pytest.approx(1.0)


def test_incompatible_dimensions_raise():
    with pytest.raises(DimensionError):
        Quantity(1, "g").to("mL")
    with pytest.raises(DimensionError):
        Quantity(1, "g") + Quantity(1, "mL")
    with pytest.raises(DimensionError):
        Quantity(1, "mg/unit").to("mg/mL")  # per dosage unit is not per volume
    with pytest.raises(DimensionError):
        multiply(Quantity(1, "g"), Quantity(1, "mL"), "g")


def test_mass_volume_requires_density():
    with pytest.raises(DimensionError, match="requires a density"):
        mass_to_volume(Quantity(10, "g"), None)
    with pytest.raises(DimensionError):
        mass_to_volume(Quantity(10, "g"), Quantity(1, "g"))  # not a density
    assert mass_to_volume(Quantity(10, "g"), Quantity(2, "g/mL")).value == pytest.approx(5)
    assert volume_to_mass(Quantity(5, "mL"), Quantity(1.2, "g/mL")).value == pytest.approx(6)
    with pytest.raises(DimensionError):
        amount_to_mass(Quantity(1, "mol"), None)
    assert amount_to_mass(Quantity(2, "mmol"), Quantity(100, "g/mol")).value == pytest.approx(0.2)
    assert divide(Quantity(10, "mg"), Quantity(2, "mL"), "mg/mL").value == pytest.approx(5)


def test_celsius_is_affine_and_units_validated():
    with pytest.raises(UnitParseError):
        Quantity(25, "°C")
    assert Temperature.celsius(25).kelvin == pytest.approx(298.15)
    with pytest.raises(ValueError):
        Temperature.celsius(-300)
    with pytest.raises(UnitParseError):
        Quantity(1, "furlong")
    with pytest.raises(ValueError):
        Quantity(float("nan"), "g")
