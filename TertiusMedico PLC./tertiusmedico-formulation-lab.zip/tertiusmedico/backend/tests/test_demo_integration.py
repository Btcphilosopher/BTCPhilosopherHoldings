"""Runs the complete 12-step synthetic demonstration through the HTTP API and checks its claims."""
import json

import pytest


@pytest.fixture(scope="module")
def summary(tmp_path_factory):
    import os
    from tertius import config, storage
    d = tmp_path_factory.mktemp("demo")
    old = {k: os.environ.get(k) for k in ("TERTIUS_DATABASE_URL", "TERTIUS_STORAGE_ROOT", "TERTIUS_SECRET_KEY")}
    os.environ.update(TERTIUS_DATABASE_URL=f"sqlite:///{d}/demo.db", TERTIUS_STORAGE_ROOT=str(d / "store"),
                      TERTIUS_SECRET_KEY="demo-secret-demo-secret-demo-secret-x")
    config.get_settings.cache_clear(); storage.reset_storage()
    from tertius.demo import run_demo
    s = run_demo(str(d / "out"))
    s["_out"] = d / "out"
    yield s
    for k, v in old.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    config.get_settings.cache_clear(); storage.reset_storage()


def test_steps_1_to_3(summary):
    v = summary["2_3_formulation_validation"]
    assert v["reference"]["ok"] and not v["bad_total"]["ok"] and not v["bad_unit"]["ok"]
    assert any(i["code"] == "unresolved_mass" for i in v["volume_basis"]["issues"])
    assert summary["1_materials"]["revision"]["version"] == 2
    assert not summary["constraints"]["infeasible_example"]["feasible"]
    assert summary["constraints"]["infeasible_example"]["conflicting_constraints"]


def test_steps_4_to_7(summary):
    assert summary["4_design"]["budget"]["runs"] >= 40
    assert summary["5_import"]["quality"]["errors"] == 0
    failed = [r for r in summary["5_import"]["status_counts"] if r["status"] == "failed"]
    assert failed  # failed experiments are kept
    sel = {r["target"]: r["model"] for r in summary["6_models"] if r["selected"]}
    assert set(sel) == {"viscosity", "uniformity_cv", "assay_4w_40C", "phase_separation"}
    assert "UNVALIDATED" in summary["7_uncertainty"]["classification"]


def test_steps_8_to_12(summary):
    props = summary["8_proposals"]["proposals"]
    assert len(props) == 5 and any(p["strategy"] == "bayesian_optimisation" for p in props)
    assert {r["status"] for r in summary["8_proposals"]["reviews"]} == {"accepted_for_planning", "rejected"}
    assert summary["9_pareto"]["frontier_size"] > 0
    ood = summary["10_out_of_domain"]
    assert ood["bounds_and_equipment_violation"]["decision"] == "rejected"
    assert not ood["bounds_and_equipment_violation"]["predictions_offered"]
    assert ood["unregistered_ingredient"]["decision"] == "rejected"
    assert "refused" in summary["11_stability"]["forecast_beyond_bound"]
    assert "NOT A SHELF-LIFE" in summary["11_stability"]["notice"]
    lin = summary["12_report"]["lineage_example"]
    assert lin["missing_links"] == []  # material lot → … → reviewed decision is complete
    assert summary["audit_chain"]["valid"]
    assert summary["extras"]["combination_without_authorisation"] == 422
    assert summary["extras"]["simulation"]["label"].startswith("SIMULATED")
    html = (summary["_out"] / "research_report.html").read_text()
    assert "NON-CLINICAL" in html and "PREDICTED" in html
    rep = json.loads((summary["_out"] / "research_report.json").read_text())
    assert rep["meta"]["content_sha256"]


def test_api_reports_reviewed_status_and_failure_reasons(summary):
    """Regression: GET /proposals must not let stored content overwrite the reviewed status;
    the project-wide measurements endpoint must include failure reasons."""
    from fastapi.testclient import TestClient
    from conftest import token
    from tertius.api.main import create_app
    c = TestClient(create_app())
    h = token(c, "rowan")
    props = c.get("/api/projects/1/proposals", headers=h).json()[0]["proposals"]
    assert sorted(p["status"] for p in props) == sorted(
        ["accepted_for_planning"] * 3 + ["rejected", "proposed"])
    ms = c.get("/api/projects/1/measurements", headers=h).json()
    failed = [m for m in ms if m["status"] == "failed"]
    assert failed and all(m["failure_reason"] for m in failed)
    models = c.get("/api/projects/1/models", headers=h).json()
    clf = next(m for m in models if m["target"] == "phase_separation")
    assert clf["calibration_status"] and clf["dataset_sha256"]
