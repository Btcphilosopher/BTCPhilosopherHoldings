from decimal import Decimal

import numpy as np
import pandas as pd
import pytest

from tertius.science.combination import CombinationContext, CombinationScopeError, analyse_combination
from tertius.science.costs import FXRate, LineItem, PriceRecord, scenario_cost
from tertius.science.simulation import SimulationConfig, simulate_process
from tertius.science.stability import NOT_SHELF_LIFE, fit_trends, slope_poolability
from tertius.science.units import DimensionError, Quantity
from tertius.synthetic.generator import generate_combination_dataset, generate_stability_study

REF = {"SV-1": 0.70, "VM-2": 0.15, "SF-3": 0.05, "TR-4": 0.10}


def test_stability_trends_bounded_and_not_shelf_life():
    df = generate_stability_study(3, {"F1": REF})
    trends = fit_trends(df, "assay")
    assert len(trends) == 8  # 2 conditions × 2 packs × 2 lots, never pooled silently
    t = next(t for t in trends if t.key["condition"] == "40C/75RH")
    assert t.slope < 0
    with pytest.raises(ValueError, match="refused"):
        t.predict([t.max_time * 2])
    p = t.predict([0, t.max_time])
    assert p["ci_lower"][1] < p["mean"][1] < p["ci_upper"][1] and p["pi_lower"][1] < p["ci_lower"][1]
    cr = t.exploratory_crossing(95.0)
    assert cr["label"] == NOT_SHELF_LIFE
    deg = fit_trends(df, "degradant")
    assert any(tr.excluded for tr in deg)  # censored results excluded and listed
    pool = slope_poolability(df, "assay", "lot", {"packaging": "glass_vial", "condition": "25C/60RH"})
    assert pool["testable"] and 0 <= pool["p_value"] <= 1


def test_process_simulation_is_labelled_and_mass_conserving():
    r = simulate_process(SimulationConfig(5000, 600, 20, 4, 50, 0.75, n_sims=500))
    assert r["label"].startswith("SIMULATED")
    assert r["outputs"]["simulated_mass_closure"]["median"] == pytest.approx(1.0)
    assert len(r["assumptions"]) >= 7 and r["limitations"]
    slow = simulate_process(SimulationConfig(5000, 200, 2, 4, 50, 0.75, n_sims=500))
    assert slow["flags"]  # under-mixing flagged


def ctx(**kw):
    base = dict(authorisation_reference="AUTH-1", permitted_use="research", system="cell-free", exposure="48 h",
                endpoint="signal")
    base.update(kw)
    return CombinationContext(**base)


def test_combination_reference_models_and_scope():
    df = generate_combination_dataset(1)
    r = analyse_combination(df, ctx())
    assert r["n_dose_pairs"] == 16 and "Loewe" not in r["reference_models"]["bliss"]
    mid = [x for x in r["results"] if x["dose_a"] in (1.0, 3.0) and x["dose_b"] in (3.0, 10.0)]
    assert all(x["bliss_excess"] > 0.05 for x in mid)  # the planted +0.12 excess is recovered
    assert "not evidence of therapeutic benefit" in r["disclaimer"].lower() or "Not evidence" in r["disclaimer"]
    with pytest.raises(CombinationScopeError):
        analyse_combination(df, ctx(authorisation_reference=""))
    with pytest.raises(CombinationScopeError):
        analyse_combination(df, ctx(subject_type="patient cohort"))
    few = df[df.replicate <= 2]
    r2 = analyse_combination(few, ctx())
    assert all(x["conclusion"] == "insufficient data" for x in r2["results"])


def test_bliss_exact_independence_gives_no_excess():
    rows = []
    for a, ea in [(0, 0), (1, 0.3)]:
        for b, eb in [(0, 0), (1, 0.5)]:
            for rep in range(3):
                rows.append({"dose_a": a, "dose_b": b, "replicate": rep, "response": ea + eb - ea * eb})
    r = analyse_combination(pd.DataFrame(rows), ctx())
    assert r["results"][0]["bliss_excess"] == pytest.approx(0.0, abs=1e-12)


def test_costs_currency_dates_and_units():
    p = PriceRecord("A", Decimal("10"), "EUR", "kg", "2026-01-01", "quote")
    out = scenario_cost([LineItem("ingredient", "A", Quantity(500, "g"), p)], "EUR")
    assert out["total"] == "5.00" and out["lines"][0]["price_date"] == "2026-01-01"
    usd = PriceRecord("V", Decimal("1"), "USD", "unit", "2026-01-01", "quote")
    with pytest.raises(ValueError, match="exchange rate"):
        scenario_cost([LineItem("packaging", "V", Quantity(10, "unit"), usd)], "EUR")
    fx = {("USD", "EUR"): FXRate("USD", "EUR", Decimal("0.9"), "2026-01-02", "bank")}
    assert scenario_cost([LineItem("packaging", "V", Quantity(10, "unit"), usd)], "EUR", fx)["total"] == "9.00"
    with pytest.raises(DimensionError):
        scenario_cost([LineItem("ingredient", "A", Quantity(1, "L"), p)], "EUR")  # volume priced per kg
