import dataclasses

import numpy as np
import pytest

from tertius.science.constraints import check_candidate, is_admissible
from tertius.science.doe import DesignSpec, generate_design
from tertius.science.ml.pipeline import ModelBundle, TrainingConfig, train_and_evaluate
from tertius.science.optimisation.bo_adapter import Observation, OptunaAdapter, _stick_forward, _stick_inverse
from tertius.science.optimisation.pareto import Objective, crowding_distance, non_dominated_sort
from tertius.science.optimisation.recommend import Recommender
from tertius.synthetic.demo_config import MIX_COLS, PROC_COLS, TARGETS, demo_domain
from tertius.synthetic.generator import generate_experiment_results


def test_pareto_sort_and_crowding():
    F = np.array([[1, 5], [2, 2], [5, 1], [3, 3], [6, 6]], float)
    assert list(non_dominated_sort(F)) == [0, 0, 0, 1, 2]
    cd = crowding_distance(F[:3])
    assert np.isinf(cd[0]) and np.isinf(cd[2]) and np.isfinite(cd[1])
    o = Objective("v", "target_range", "mPa*s", "prediction", "viscosity", 30, 60, True)
    assert o.to_min(np.array([45.0]))[0] == 0 and o.to_min(np.array([90.0]))[0] == pytest.approx(np.log(1.5))
    assert Objective("a", "max", "%", "prediction").to_min(np.array([3.0]))[0] == -3.0


def test_stick_breaking_roundtrip():
    rng = np.random.default_rng(0)
    for _ in range(50):
        z = rng.dirichlet([1, 1, 1, 1])
        np.testing.assert_allclose(_stick_forward(_stick_inverse(z)), z, atol=1e-12)


@pytest.fixture(scope="module")
def trained():
    dom = demo_domain()
    des = generate_design(dom, DesignSpec(n_mixture_points=22, replicates=2, blocks=("d1", "d2", "d3"), seed=4))
    df = generate_experiment_results(des.runs, seed=5)
    res = {t: train_and_evaluate(df, TrainingConfig(TARGETS[t], MIX_COLS, PROC_COLS, "batch_id", seed=1,
                                                    models=("mean_baseline", "scheffe_ridge", "gaussian_process")))
           for t in ("viscosity", "uniformity_cv")}
    return dom, df, ModelBundle(res)


def _history(df):
    out = []
    for run, g in df.groupby("run_id"):
        v = g[g.target == "viscosity"].iloc[0]; u = g[g.target == "uniformity_cv"].iloc[0]
        failed = v.status == "failed"
        out.append(Observation({c[4:]: v[c] for c in MIX_COLS}, {c[5:]: v[c] for c in PROC_COLS},
                               [None, None] if failed else [abs(np.log(v.value / 45)), u.value], failed, run))
    return out


def test_bo_never_returns_inadmissible_or_excluded(trained):
    dom, df, _ = trained
    dom2 = dataclasses.replace(dom, excluded=frozenset({"SF-3"}),
                               bounds={**dom.bounds, "SF-3": (0.0, 0.1)})
    sugg = OptunaAdapter(dom2, ["min", "min"], "tpe", seed=1).suggest(_history(df), 6)
    assert len(sugg) == 6
    for s in sugg:
        assert s.composition["SF-3"] == 0.0
        assert is_admissible(check_candidate(dom2, s.composition, s.process))
        assert abs(sum(s.composition.values()) - 1) < 1e-9


def test_recommender_respects_hard_constraints_and_reports_evidence(trained):
    dom, df, bundle = trained
    objs = [Objective("viscosity_in_range", "target_range", "mPa*s", "prediction", "viscosity", 30, 60, True),
            Objective("uniformity_cv", "min", "%", "prediction", "uniformity_cv"),
            Objective("material_cost", "min", "EUR/kg", "calculation")]
    train = bundle.results["viscosity"].train_frame
    rec = Recommender(dom, bundle, objs, train, MIX_COLS, PROC_COLS, "viscosity")
    out = rec.recommend(5, pool_size=400, seed=2)
    assert len(out["proposals"]) == 5
    for p in out["proposals"]:
        assert is_admissible(check_candidate(dom, p["composition"], p["process"]))
        assert not p["domain"]["abstain"]
        assert p["reason"] and p["neighbourhood"] and p["constraint_checks"]
        v = p["predictions"]["viscosity"]
        assert v["lower"] <= v["mean"] <= v["upper"] and v["label"] == "PREDICTED"
        assert p["calculated"]["material_cost"]["label"] == "CALCULATED"
    assert {p["strategy"] for p in out["proposals"]} >= {"pareto_diverse", "exploration"}
    # an excluded ingredient cannot be "rescued" by a good predicted score
    ev = rec.evaluate({"SV-1": 0.40, "VM-2": 0.35, "SF-3": 0.05, "TR-4": 0.20},
                      {"mix_speed": 600, "mix_time": 20, "temperature": 25})
    assert ev["decision"] == "rejected" and not ev["predictions"]
