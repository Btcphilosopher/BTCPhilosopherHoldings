import numpy as np
import pytest

from tertius.science.constraints import (CompatibilityRecord, CostLimit, EquipmentLimit, InformationRequirement, Price,
                                         ProcessRange, ResearchDomain, _feasible, analyse_feasibility, check_candidate,
                                         is_admissible)
from tertius.science.doe import (WHY_NOT_BOX_SAMPLING, DesignSpec, Polytope, d_optimal, generate_design, simplex_centroid,
                                 simplex_lattice)
from tertius.synthetic.demo_config import demo_domain


def box(**kw):
    base = dict(name="t", components=("A", "B", "C"), bounds={"A": (0.2, 0.8), "B": (0.1, 0.6), "C": (0.0, 0.5)})
    base.update(kw)
    return ResearchDomain(**base)


def test_feasible_domain_ranges():
    r = analyse_feasibility(demo_domain())
    assert r.feasible and not r.blocked
    assert r.feasible_ranges["SV-1"][0] > 0.5  # lower bound inactive → reported
    assert any("UNKNOWN" in w for w in r.warnings)


def test_infeasible_explained_with_irreducible_subset():
    d = box(bounds={"A": (0.6, 1), "B": (0.3, 1), "C": (0.2, 1)})
    r = analyse_feasibility(d)
    assert not r.feasible and any("sum of lower bounds" in e for e in r.explanations)
    names = [c["name"] for c in r.conflicting_constraints]
    cons = {c.name: c for c in d.linear_constraints()}
    subset = [cons[n] for n in names]
    assert not _feasible(d.components, subset)
    for i in range(len(subset)):  # irreducible: dropping any member restores feasibility
        assert _feasible(d.components, subset[:i] + subset[i + 1:])


def test_reviewed_incompatibility_and_unknown_compatibility():
    inc = (CompatibilityRecord("A", "B", "incompatible", "review-1", True),)
    r = analyse_feasibility(box(compatibility=inc))
    assert not r.feasible and "incompatible" in " ".join(r.explanations)
    ok = box(bounds={"A": (0.2, 0.8), "B": (0.0, 0.6), "C": (0.0, 0.5)}, compatibility=inc)
    assert analyse_feasibility(ok).feasible
    checks = check_candidate(ok, {"A": 0.5, "B": 0.2, "C": 0.3})
    assert not is_admissible(checks)  # incompatible pair present
    blocked = check_candidate(box(), {"A": 0.5, "B": 0.2, "C": 0.3})  # no records = unknown, policy block
    assert not is_admissible(blocked)
    assert any(c.status == "fail" and "unknown" in c.detail for c in blocked)
    flagged = check_candidate(box(unknown_compatibility_policy="flag"), {"A": 0.5, "B": 0.2, "C": 0.3})
    assert is_admissible(flagged) and any(c.status == "flag" for c in flagged)


def test_exclusion_equipment_cost_and_missing_information():
    d = box(excluded=frozenset({"C"}), unknown_compatibility_policy="flag",
            process={"speed": ProcessRange("speed", 100, 1500, "rpm")},
            equipment=(EquipmentLimit("MX", "speed", None, 900, "rpm"),))
    assert not is_admissible(check_candidate(d, {"A": 0.5, "B": 0.4, "C": 0.1}, {"speed": 500}))
    assert not is_admissible(check_candidate(d, {"A": 0.5, "B": 0.5, "C": 0.0}, {"speed": 1000}))  # equipment
    assert is_admissible(check_candidate(d, {"A": 0.5, "B": 0.5, "C": 0.0}, {"speed": 800}))
    assert not is_admissible(check_candidate(d, {"A": 0.5, "B": 0.5}, {}))  # unspecified process = unknown
    c = box(cost_limit=CostLimit(10, "EUR"), prices={"A": Price("A", 5, "EUR", "kg", "2026-01-01")})
    r = analyse_feasibility(c)
    assert r.blocked and any("no dated price" in m for m in r.missing_information)
    info = box(information=(InformationRequirement("mixture density not measured", False, "fill-volume limit"),))
    assert analyse_feasibility(info).blocked


def test_simplex_designs():
    assert len(simplex_lattice(3, 2)) == 6 and len(simplex_lattice(4, 3)) == 20
    assert len(simplex_centroid(4)) == 15
    assert np.allclose(simplex_lattice(4, 3).sum(1), 1)


def test_polytope_vertices_and_sampling():
    d = box(bounds={"A": (0.2, 1), "B": (0.1, 1), "C": (0.0, 1)})
    v = Polytope.from_domain(d).vertices()
    expected = np.array([[0.9, 0.1, 0.0], [0.2, 0.8, 0.0], [0.2, 0.1, 0.7]])
    assert len(v) == 3 and all(any(np.allclose(e, x) for x in v) for e in expected)
    X = Polytope.from_domain(demo_domain()).hit_and_run(300, np.random.default_rng(0))
    assert np.allclose(X.sum(1), 1) and all(Polytope.from_domain(demo_domain()).contains(x, 1e-7) for x in X)


def test_constrained_design_properties():
    dom = demo_domain()
    spec = DesignSpec(n_mixture_points=14, replicates=3, control={"SV-1": 0.7, "VM-2": 0.15, "SF-3": 0.05, "TR-4": 0.1},
                      control_process={"mix_speed": 600, "mix_time": 20, "temperature": 25}, blocks=("d1", "d2", "d3"))
    a, b = generate_design(dom, spec), generate_design(dom, spec)
    assert a.runs.equals(b.runs)  # seeded → reproducible
    mix = [c for c in a.runs if c.startswith("mix:")]
    proc = [c for c in a.runs if c.startswith("proc:")]
    assert set(mix).isdisjoint(proc) and len(mix) == 4 and len(proc) == 3
    assert np.allclose(a.runs[mix].sum(axis=1), 1)
    for _, r in a.runs.iterrows():
        assert is_admissible(check_candidate(dom, {c[4:]: r[c] for c in mix}, {c[5:]: r[c] for c in proc}))
    # replicates of every design point are spread over different blocks
    assert (a.runs[a.runs.role == "design"].groupby("design_point").block.nunique() == 3).all()
    assert a.budget["runs"] == len(a.runs) and a.coverage["fill_distance_max"] > 0
    assert "sum to a fixed total" in WHY_NOT_BOX_SAMPLING
    bad = DesignSpec(n_mixture_points=12, control={"SV-1": 0.9, "VM-2": 0.05, "SF-3": 0.03, "TR-4": 0.02})
    with pytest.raises(ValueError, match="control sample"):
        generate_design(dom, bad)


def test_d_optimal_requires_enough_runs():
    with pytest.raises(ValueError, match="at least 10"):
        d_optimal(simplex_lattice(4, 3), 6, 2, np.random.default_rng(0))
