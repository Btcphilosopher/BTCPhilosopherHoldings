import io

import pandas as pd
import pytest
from sqlalchemy import text

from conftest import token
from tertius.synthetic.demo_config import TARGETS, demo_domain

REF = {"SV-1": 0.70, "VM-2": 0.15, "SF-3": 0.05, "TR-4": 0.10}


def test_authentication_required_and_bad_login(app_client):
    c = app_client
    assert c.get("/api/projects").status_code == 401
    assert c.get("/api/projects", headers={"Authorization": "Bearer nope"}).status_code == 401
    assert c.post("/api/auth/token", data={"username": "rhea", "password": "wrong-password"}).status_code == 401


def test_project_scoped_permissions(project):
    c, pid, h = project
    # outsider: valid user, not a member → no access to protected IP
    c.post("/api/admin/users", json={"username": "olive", "password": "outsider-pass-123"}, headers=h["admin"])
    o = {"Authorization": "Bearer " + c.post("/api/auth/token", data={"username": "olive",
                                                                      "password": "outsider-pass-123"}).json()["access_token"]}
    assert c.get(f"/api/projects/{pid}/materials", headers=o).status_code == 403
    assert c.get("/api/projects", headers=o).json() == []
    # researcher cannot administer or approve
    assert c.post("/api/projects", json={"code": "X-1", "name": "x"}, headers=h["rhea"]).status_code == 403
    assert c.post(f"/api/projects/{pid}/members", json={"username": "olive", "role": "admin"},
                  headers=h["rhea"]).status_code == 403
    assert c.get(f"/api/projects/{pid}/audit", headers=h["rhea"]).status_code == 403
    assert c.get(f"/api/projects/{pid}/audit", headers=h["rowan"]).status_code == 200
    r = c.post(f"/api/projects/{pid}/domains", json={"content": demo_domain().to_dict()}, headers=h["rhea"]).json()
    assert c.post(f"/api/projects/{pid}/domains/{r['id']}/approve", headers=h["rhea"]).status_code == 403
    assert c.post(f"/api/projects/{pid}/domains/{r['id']}/approve", headers=h["rowan"]).status_code == 200


def test_separation_of_duties(project):
    c, pid, h = project
    r = c.post(f"/api/projects/{pid}/domains", json={"content": demo_domain().to_dict()}, headers=h["rowan"]).json()
    assert c.post(f"/api/projects/{pid}/domains/{r['id']}/approve", headers=h["rowan"]).status_code == 403


def _material(c, pid, h, mid="SV-1", **extra):
    body = {"material_id": mid, "name": f"{mid} fictional", "lot": "L1", "fictional": True, **extra}
    return c.post(f"/api/projects/{pid}/materials", json=body, headers=h)


def test_material_versioning_preserves_history(project):
    c, pid, h = project
    assert _material(c, pid, h["rhea"]).status_code == 200
    assert _material(c, pid, h["rhea"]).status_code == 409
    rec = {"material_id": "SV-1", "name": "SV-1 fictional", "lot": "L2", "fictional": True}
    r = c.post(f"/api/projects/{pid}/materials/SV-1/versions", json={"record": rec, "change_note": "new lot"},
               headers=h["rhea"])
    assert r.json()["version"] == 2
    assert c.post(f"/api/projects/{pid}/materials/SV-1/versions", json={"record": rec, "change_note": "same"},
                  headers=h["rhea"]).status_code == 409
    hist = c.get(f"/api/projects/{pid}/materials/SV-1", headers=h["rhea"]).json()
    assert [v["content"]["lot"] for v in hist["versions"]] == ["L1", "L2"]
    bad = _material(c, pid, h["rhea"], "X-1", physical_properties=[
        {"name": "density", "source": "laboratory_measurement", "value": 1.0, "unit": "g/mL"}])
    assert bad.status_code == 422  # lab measurement without a method


def _formulation(total=1.0):
    comp = dict(REF, **{"SV-1": REF["SV-1"] - (1 - total)})
    return {"name": "f", "dosage_form": "suspension", "basis": "mass_fraction", "target_batch_size": {"value": 500, "unit": "g"},
            "ingredients": [{"material_id": k, "material_version": 1, "role": "other",
                             "amount": {"value": v, "unit": "fraction"}} for k, v in comp.items()]}


def test_formulation_revision_lifecycle(project):
    c, pid, h = project
    for m in REF:
        _material(c, pid, h["rhea"], m)
    bad = c.post(f"/api/projects/{pid}/formulations", json={"formulation_id": "F-BAD", "content": _formulation(0.97)},
                 headers=h["rhea"]).json()
    assert not bad["validation"]["ok"]
    assert c.post(f"/api/projects/{pid}/formulations/F-BAD/revisions/1/review", json={"decision": "submit"},
                  headers=h["rhea"]).status_code == 409  # invalid cannot go to review
    c.post(f"/api/projects/{pid}/formulations", json={"formulation_id": "F1", "content": _formulation()}, headers=h["rhea"])
    base = f"/api/projects/{pid}/formulations/F1/revisions"
    assert c.post(f"{base}/1/review", json={"decision": "submit"}, headers=h["rhea"]).status_code == 200
    assert c.post(f"{base}/1/review", json={"decision": "approve"}, headers=h["rhea"]).status_code == 403
    assert c.post(f"{base}/1/review", json={"decision": "approve"}, headers=h["rowan"]).json()["status"] == "approved"
    assert c.put(f"{base}/1", json={"content": _formulation()}, headers=h["rhea"]).status_code == 409  # immutable
    r2 = c.post(base, json={"content": _formulation()}, headers=h["rhea"]).json()
    assert r2["revision"] == 2
    c.post(f"{base}/2/review", json={"decision": "submit"}, headers=h["rhea"])
    c.post(f"{base}/2/review", json={"decision": "approve"}, headers=h["rowan"])
    revs = c.get(f"/api/projects/{pid}/formulations", headers=h["rhea"]).json()
    st = {r["revision"]: r["status"] for r in next(f for f in revs if f["formulation_id"] == "F1")["revisions"]}
    assert st == {1: "superseded", 2: "approved"}


def _experiment(c, pid, h):
    r = c.post(f"/api/projects/{pid}/domains", json={"content": demo_domain().to_dict()}, headers=h["rhea"]).json()
    c.post(f"/api/projects/{pid}/domains/{r['id']}/approve", headers=h["rowan"])
    d = c.post(f"/api/projects/{pid}/designs", json={"domain_id": r["id"], "spec": {"n_mixture_points": 12, "replicates": 2,
                                                                                    "blocks": ["d1", "d2"]}},
               headers=h["rhea"]).json()
    c.post(f"/api/projects/{pid}/experiments", json={"code": "E1", "title": "t", "design_id": d["id"]}, headers=h["rhea"])
    return d


def test_experiment_workflow_versioning_and_import(project):
    c, pid, h = project
    d = _experiment(c, pid, h)
    E = f"/api/projects/{pid}/experiments/E1"
    tr = lambda who, tgt, **kw: c.post(f"{E}/transition", json={"target": tgt, **kw}, headers=h[who])  # noqa: E731
    assert tr("rhea", "approved_for_experiment").status_code == 409  # must go through review
    assert tr("rhea", "scientific_review").status_code == 200
    assert tr("rhea", "approved_for_experiment").status_code == 403
    assert tr("rowan", "approved_for_experiment").status_code == 200
    assert c.put(f"{E}/plan", json={"plan": {"runs": []}}, headers=h["rhea"]).status_code == 409
    # import before performed is refused
    csv = io.BytesIO(b"measurement_id\nx\n")
    assert c.post(f"{E}/measurements", files={"file": ("r.csv", csv, "text/csv")}, headers=h["rhea"]).status_code == 409
    assert tr("rhea", "performed", evidence={"operator": "rhea"}).status_code == 409  # evidence incomplete
    # new revision of an approved (unexecuted) plan supersedes it and returns to draft
    r = c.post(f"{E}/revisions", json={"plan": {"runs": d["runs"]}, "change_note": "add control"}, headers=h["rhea"])
    assert r.json() == {"code": "E1", "revision": 2, "state": "draft"}
    exp = c.get(E, headers=h["rhea"]).json()
    assert [x["state"] for x in exp["revisions"]] == ["superseded", "draft"]
    tr("rhea", "scientific_review"); tr("rowan", "approved_for_experiment")
    ev = {"operator": "rhea", "performed_on": "2026-02-01", "material_lots": ["L1"], "equipment": ["MX"]}
    assert tr("rhea", "performed", evidence=ev).status_code == 200
    from tertius.synthetic.generator import generate_experiment_results
    df = generate_experiment_results(pd.DataFrame(d["runs"]), 3)
    for t in TARGETS.values():
        c.post(f"/api/projects/{pid}/targets", json={"spec": t.as_dict()}, headers=h["rhea"])
    bad = df.copy(); bad.loc[0, "unit"] = "g"
    r = c.post(f"{E}/measurements", files={"file": ("r.csv", bad.to_csv(index=False).encode(), "text/csv")},
               headers=h["rhea"]).json()
    assert r["imported"] == 0 and "unit_mismatch" in r["quality"]["codes"]  # errors block import, raw file kept
    r = c.post(f"{E}/measurements", files={"file": ("r2.csv", df.to_csv(index=False).encode(), "text/csv")},
               headers=h["rhea"]).json()
    assert r["imported"] == len(df)
    ms = c.get(f"{E}/measurements", headers=h["rhea"]).json()
    assert {m["status"] for m in ms} >= {"ok"} and len(ms) == len(df)
    assert tr("rhea", "data_reviewed").status_code == 403  # recorder cannot review own data
    assert tr("rowan", "data_reviewed").status_code == 200
    assert tr("rowan", "rejected").status_code == 409  # reason required
    assert tr("rowan", "accepted", reason="ok").status_code == 200


@pytest.mark.parametrize("name,data,code", [
    ("evil.exe", b"MZ\x90\x00", 415), ("data.csv", b"a,b\n\x00\x01", 415), ("fake.pdf", b"not a pdf", 415),
    ("../../etc/passwd.txt", b"hello", 200), (".hidden.csv", b"a", 400), ("big.csv", b"a" * (21 * 2 ** 20), 400),
])
def test_upload_restrictions(project, name, data, code):
    c, pid, h = project
    r = c.post(f"/api/projects/{pid}/files", files={"file": (name, data, "application/octet-stream")}, headers=h["rhea"])
    assert r.status_code == code, r.text
    if code == 200:
        assert "/" not in r.json()["filename"] and ".." not in r.json()["filename"].split("_")[0]
        got = c.get(f"/api/projects/{pid}/files/{r.json()['id']}", headers=h["rhea"])
        assert got.content == data and got.headers["x-content-sha256"] == r.json()["sha256"]


def test_audit_chain_detects_tampering(project):
    c, pid, h = project
    _material(c, pid, h["rhea"])
    assert c.get("/api/admin/audit/verify", headers=h["admin"]).json()["valid"]
    from tertius.db.session import get_engine
    with get_engine().begin() as conn:
        conn.execute(text("UPDATE audit_log SET actor='mallory' WHERE id = 3"))
    v = c.get("/api/admin/audit/verify", headers=h["admin"]).json()
    assert v["valid"] is False and v["broken_at"] == 3


def test_production_requires_secret(monkeypatch):
    from tertius import config
    monkeypatch.setenv("TERTIUS_ENV", "production"); monkeypatch.delenv("TERTIUS_SECRET_KEY", raising=False)
    config.get_settings.cache_clear()
    with pytest.raises(RuntimeError):
        config.get_settings().resolved_secret()
    monkeypatch.setenv("TERTIUS_SECRET_KEY", "short")
    config.get_settings.cache_clear()
    with pytest.raises(RuntimeError):
        config.get_settings().resolved_secret()
    config.get_settings.cache_clear()
