import pytest

from tertius.science.composition import (Basis, DocumentedLoss, DosageForm, Formulation, Ingredient, ProcessStage,
                                         Role, batch_quantities, mass_balance, validate_formulation)
from tertius.science.materials import MaterialRecord, PropertySource, PropertyValue
from tertius.science.units import DimensionError, Quantity


def mats():
    return {
        "A": MaterialRecord("A", "a", physical_properties=(PropertyValue("density", PropertySource.LABORATORY_MEASUREMENT,
                                                                         1.0, "g/mL", method="DENS"),)),
        "B": MaterialRecord("B", "b"),  # no density recorded
    }


def form(basis=Basis.MASS_FRACTION, a=0.8, b=0.2, unit="fraction", batch=Quantity(100, "g"), stages=()):
    return Formulation("F", "f", DosageForm.LIQUID, basis,
                       (Ingredient("A", 1, Role.VEHICLE, Quantity(a, unit)), Ingredient("B", 1, Role.THICKENER, Quantity(b, unit))),
                       batch, stages)


def codes(rep):
    return {i.code for i in rep.issues}


def test_valid_mass_fraction_and_batch_scaling():
    rep = validate_formulation(form(), mats())
    assert rep.ok
    bq = {r["material_id"]: r["mass_g"] for r in rep.calculated["batch_quantities"]}
    assert bq == pytest.approx({"A": 80.0, "B": 20.0})


def test_composition_total_enforced():
    rep = validate_formulation(form(a=0.7), mats())
    assert not rep.ok and "composition_total" in codes(rep)


def test_dimension_mismatch_with_basis():
    rep = validate_formulation(form(unit="mg/mL"), mats())
    assert "dimension_mismatch" in codes(rep)


def test_volume_fraction_not_additive_and_no_default_density():
    rep = validate_formulation(form(basis=Basis.VOLUME_FRACTION, batch=Quantity(100, "mL")), mats())
    assert "volume_non_additive" in codes(rep)
    rows = {r["material_id"]: r for r in rep.calculated["batch_quantities"]}
    assert rows["A"]["mass_g"] == pytest.approx(80.0)
    assert rows["B"]["mass_g"] is None and rows["B"]["status"] == "unresolved"


def test_mass_fraction_with_volume_batch_is_unresolved():
    rows = batch_quantities(form(batch=Quantity(100, "mL")), mats())
    assert all(r["mass_g"] is None for r in rows)


def test_molarity_requires_molar_mass():
    f = form(basis=Basis.MOLAR_CONCENTRATION, unit="mol/L", a=0.1, b=0.2, batch=Quantity(1, "L"))
    rows = {r["material_id"]: r for r in batch_quantities(f, mats())}
    assert rows["A"]["mass_g"] is None and rows["A"]["amount_mol"] == pytest.approx(0.1)


def test_process_stage_additions_checked():
    st = (ProcessStage(1, "mix", "MX", additions=("A", "Z")),)
    rep = validate_formulation(form(stages=st), mats())
    assert "addition_unknown" in codes(rep) and "not_added" in codes(rep)


def test_mass_balance_closure_and_flags():
    mb = mass_balance([Quantity(400, "g"), Quantity(0.1, "kg")], Quantity(480, "g"),
                      [DocumentedLoss("transfer", Quantity(15, "g"), "hold-up", True)])
    assert mb.input_g == pytest.approx(500) and mb.unaccounted_g == pytest.approx(5)
    assert mb.measured_yield_fraction == pytest.approx(0.96) and mb.flags == []
    mb2 = mass_balance([Quantity(100, "g")], Quantity(80, "g"), [])
    assert "unaccounted_mass_exceeds_tolerance" in mb2.flags
    mb3 = mass_balance([Quantity(100, "g")], Quantity(101, "g"), [])
    assert "output_exceeds_input" in mb3.flags
    mb4 = mass_balance([Quantity(100, "g")], None, [DocumentedLoss("s", Quantity(1, "g"), "est", False)])
    assert mb4.measured_yield_fraction is None and mb4.theoretical_yield_g == 100
    with pytest.raises(DimensionError):
        mass_balance([Quantity(100, "mL")], None, [])


def test_material_versioning_and_missing_properties():
    m = mats()["B"]
    assert m.get_quantity("density") is None and m.missing(["density"]) == ["density"]
    m2 = m.add_property(PropertyValue("density", PropertySource.MODEL_ESTIMATE, 1.1, "g/mL"))
    assert m2.version == 2 and m.version == 1 and m2.content_hash() != m.content_hash()
    assert m2.get_quantity("density") is None  # model estimates excluded unless explicitly allowed
    assert m2.get_quantity("density", allow_model_estimates=True).value == 1.1
    with pytest.raises(ValueError):
        m2.revise()  # no changes
    with pytest.raises(ValueError):
        PropertyValue("density", PropertySource.LABORATORY_MEASUREMENT, 1.0, "g/mL")  # no method
    assert MaterialRecord.from_dict(m2.to_dict()).content_hash() == m2.content_hash()
