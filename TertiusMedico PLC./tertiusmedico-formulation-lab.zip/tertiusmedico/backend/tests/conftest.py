import os
import sys
import warnings
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
warnings.filterwarnings("ignore", category=FutureWarning)


@pytest.fixture()
def app_client(tmp_path, monkeypatch):
    """Fresh SQLite database + local object store per test."""
    monkeypatch.setenv("TERTIUS_DATABASE_URL", f"sqlite:///{tmp_path}/t.db")
    monkeypatch.setenv("TERTIUS_STORAGE_ROOT", str(tmp_path / "store"))
    monkeypatch.setenv("TERTIUS_SECRET_KEY", "test-secret-test-secret-test-secret-xx")
    from tertius import config, storage
    config.get_settings.cache_clear()
    storage.reset_storage()
    from fastapi.testclient import TestClient

    from tertius.api.main import create_app
    from tertius.demo import bootstrap
    bootstrap()
    c = TestClient(create_app())
    yield c
    config.get_settings.cache_clear()
    storage.reset_storage()


def token(c, user):
    from tertius.demo import DEMO_USERS
    r = c.post("/api/auth/token", data={"username": user, "password": DEMO_USERS[user]})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture()
def project(app_client):
    c = app_client
    a = token(c, "admin")
    pid = c.post("/api/projects", json={"code": "T-1", "name": "test", "synthetic": True}, headers=a).json()["id"]
    c.post(f"/api/projects/{pid}/members", json={"username": "rhea", "role": "researcher"}, headers=a)
    c.post(f"/api/projects/{pid}/members", json={"username": "rowan", "role": "reviewer"}, headers=a)
    return c, pid, {"admin": a, "rhea": token(c, "rhea"), "rowan": token(c, "rowan")}
