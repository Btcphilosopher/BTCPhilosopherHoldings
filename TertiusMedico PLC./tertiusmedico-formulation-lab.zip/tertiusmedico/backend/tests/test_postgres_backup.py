"""PostgreSQL integration: migrations, full demo, append-only audit trigger, backup → restore round trip.

Skipped unless TERTIUS_TEST_PG_URL points at a server where the role may CREATE DATABASE, e.g.
  TERTIUS_TEST_PG_URL=postgresql://tertius:tertius_dev@localhost:5432/postgres
"""
import os
import shutil
import subprocess
import uuid
from pathlib import Path

import pytest

BASE = os.getenv("TERTIUS_TEST_PG_URL")
pytestmark = pytest.mark.skipif(not BASE or not shutil.which("pg_dump"), reason="PostgreSQL test server not configured")
ROOT = Path(__file__).resolve().parents[2]


def _db_url(name):
    return BASE.rsplit("/", 1)[0] + f"/{name}"


def _admin(sql):
    import psycopg
    with psycopg.connect(BASE, autocommit=True) as c:
        c.execute(sql)


@pytest.fixture()
def pg_dbs(tmp_path):
    a, b = f"tt_{uuid.uuid4().hex[:8]}", f"tt_{uuid.uuid4().hex[:8]}"
    _admin(f'CREATE DATABASE "{a}"'); _admin(f'CREATE DATABASE "{b}"')
    yield a, b
    from tertius.db.session import engine_for
    for n in (a, b):
        for url in (_db_url(n).replace("postgresql://", "postgresql+psycopg://"),):
            engine_for(url).dispose()
        _admin(f'DROP DATABASE IF EXISTS "{n}" WITH (FORCE)')


def test_migrate_demo_trigger_backup_restore(pg_dbs, tmp_path, monkeypatch):
    src, dst = pg_dbs
    url = _db_url(src).replace("postgresql://", "postgresql+psycopg://")
    monkeypatch.setenv("TERTIUS_DATABASE_URL", url)
    monkeypatch.setenv("TERTIUS_STORAGE_ROOT", str(tmp_path / "store"))
    monkeypatch.setenv("TERTIUS_SECRET_KEY", "pg-secret-pg-secret-pg-secret-pg-secret")
    from tertius import config, storage
    config.get_settings.cache_clear(); storage.reset_storage()
    from tertius.cli import main
    assert main(["init-db"]) == 0  # alembic upgrade head
    from tertius.demo import run_demo
    s = run_demo(str(tmp_path / "out"))
    assert s["audit_chain"]["valid"]

    import psycopg
    with psycopg.connect(_db_url(src)) as c:
        with pytest.raises(psycopg.errors.RaiseException, match="append-only"):
            c.execute("UPDATE audit_log SET actor='mallory' WHERE id=1")
        c.rollback()
        counts = {t: c.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0] for (t,) in c.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema='public'").fetchall()}
    assert counts["measurements"] > 100 and counts["model_runs"] == 4

    env = dict(os.environ, TERTIUS_PG_URL=_db_url(src), TERTIUS_STORAGE_ROOT=str(tmp_path / "store"))
    out = subprocess.run([str(ROOT / "scripts/backup.sh"), str(tmp_path / "bk")], env=env, check=True,
                         capture_output=True, text=True).stdout.strip().splitlines()[-1]
    subprocess.run([str(ROOT / "scripts/restore.sh"), out, _db_url(dst), str(tmp_path / "store2")], check=True,
                   capture_output=True, text=True)
    # refuses to restore over a populated database
    r = subprocess.run([str(ROOT / "scripts/restore.sh"), out, _db_url(dst)], capture_output=True, text=True)
    assert r.returncode == 2

    with psycopg.connect(_db_url(dst)) as c:
        restored = {t: c.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0] for t in counts}
    assert restored == counts
    # restored system is functional: audit chain verifies and model artefacts load with matching hashes
    monkeypatch.setenv("TERTIUS_DATABASE_URL", _db_url(dst).replace("postgresql://", "postgresql+psycopg://"))
    monkeypatch.setenv("TERTIUS_STORAGE_ROOT", str(tmp_path / "store2"))
    config.get_settings.cache_clear(); storage.reset_storage()
    from sqlalchemy import select
    from tertius.audit import verify_chain
    from tertius.db.models import ModelRun
    from tertius.db.session import session_factory
    from tertius.services import load_model
    db = session_factory()()
    assert verify_chain(db)["valid"]
    for run in db.execute(select(ModelRun)).scalars():
        assert load_model(run).manifest_hash == run.manifest_hash
    db.close()
    config.get_settings.cache_clear(); storage.reset_storage()
