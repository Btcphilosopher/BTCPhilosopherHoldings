import numpy as np
import pandas as pd
import pytest

from tertius.science.ml.domain import ApplicabilityDomain
from tertius.science.ml.features import MixtureProcessFeatures, closure, ilr, multiplicative_replacement
from tertius.science.ml.models import conformal_quantile
from tertius.science.ml.pipeline import TrainingConfig, dataset_hash, train_and_evaluate
from tertius.science.ml.splitting import (assert_no_leakage, grouped_split, leakage_safe_groups, near_duplicate_groups,
                                          time_split)
from tertius.science.quality import TargetSpec

MIX = ["mix:A", "mix:B", "mix:C"]
PROC = ["proc:s"]
SPEC = TargetSpec("y", "%", "M", "t0", kind="regression")


def synth(n_points=120, reps=2, noise=0.1, seed=0, fail_every=17):
    rng = np.random.default_rng(seed)
    Z = rng.dirichlet([2, 2, 2], n_points)
    s = rng.uniform(0, 1, n_points)
    rows = []
    for i in range(n_points):
        f = 2 * Z[i, 0] + 1 * Z[i, 1] + 0.5 * Z[i, 2] + 3 * Z[i, 1] * Z[i, 2] + 0.5 * s[i]
        for r in range(reps):
            failed = (i % fail_every == 0 and r == 0)
            rows.append({"measurement_id": f"m{i}-{r}", "run_id": f"r{i}-{r}", "replicate_group": f"g{i}",
                         "batch_id": f"b{i}-{r}", "target": "y", "unit": "%", "measured_on": f"2026-{1 + i % 12:02d}-01",
                         "status": "failed" if failed else "ok", "failure_reason": "fault" if failed else None,
                         "value": None if failed else f + rng.normal(0, noise),
                         "mix:A": Z[i, 0], "mix:B": Z[i, 1], "mix:C": Z[i, 2], "proc:s": s[i]})
    return pd.DataFrame(rows)


def test_replicates_and_near_duplicates_never_straddle_split():
    df = synth(40)
    df.loc[df.index[-2:], ["mix:A", "mix:B", "mix:C"]] = df.loc[df.index[0], ["mix:A", "mix:B", "mix:C"]].values + [
        0.001, -0.001, 0]  # near-identical to point 0 but a different replicate group
    df.loc[df.index[-2:], "proc:s"] = df.loc[df.index[0], "proc:s"]
    g = leakage_safe_groups(df, "batch_id", MIX, PROC)
    assert g[0] == g[len(df) - 1]  # near duplicate merged with point 0
    for seed in range(10):
        tr, te = grouped_split(g, 0.3, seed)
        assert_no_leakage(tr, te, g)
        rg_tr, rg_te = set(df.replicate_group.iloc[tr]), set(df.replicate_group.iloc[te])
        assert not rg_tr & rg_te
    with pytest.raises(AssertionError):
        assert_no_leakage(np.array([0]), np.array([1]), np.array([5, 5]))


def test_near_duplicate_tolerance_and_time_split():
    df = pd.DataFrame({"mix:A": [0.5, 0.502, 0.6], "mix:B": [0.5, 0.498, 0.4], "proc:s": [1, 1, 1]})
    g = near_duplicate_groups(df, ["mix:A", "mix:B"], ["proc:s"])
    assert g[0] == g[1] != g[2]
    dates = pd.Series(["2026-01-01", "2026-03-01", "2026-03-02"])
    tr, te = time_split(dates, np.array([0, 0, 1]), "2026-02-01")
    assert list(tr) == [] and list(te) == [0, 1, 2]  # group 0 straddles cutoff → moved to test


def test_transformations_fitted_on_training_only():
    X = np.array([[0.5, 0.5, 0, 10.0], [0.2, 0.3, 0.5, 20.0], [0.1, 0.1, 0.8, 1000.0]])
    f = MixtureProcessFeatures(3).fit(X[:2])
    assert f.mu_[0] == pytest.approx(15.0)  # test row (1000) did not influence the scaler
    out = f.transform(X)
    assert out.shape == (3, 3 + 3 + 1)


def test_compositional_zero_handling():
    X = np.array([[0.5, 0.5, 0.0], [0.2, 0.3, 0.5]])
    with pytest.raises(ValueError, match="zeros"):
        ilr(X)
    R = multiplicative_replacement(X, 1e-3)
    assert np.allclose(R.sum(1), 1) and (R > 0).all()
    assert ilr(X, "multiplicative_replacement").shape == (2, 2)
    with pytest.raises(ValueError):
        ilr(np.array([[1.2, -0.2, 0.0]]))
    np.testing.assert_allclose(closure(np.array([[2.0, 2.0]])), [[0.5, 0.5]])


def test_failed_runs_excluded_explicitly_and_reproducible():
    df = synth(60)
    cfg = TrainingConfig(SPEC, MIX, PROC, "batch_id", seed=3, models=("mean_baseline", "scheffe_ridge"))
    a, b = train_and_evaluate(df, cfg), train_and_evaluate(df, cfg)
    assert a.manifest_hash == b.manifest_hash  # identical inputs → identical manifest
    ex = a.manifest["exclusions"][0]
    n_failed = int((df.status == "failed").sum())
    assert ex["status"] == "failed" and ex["count"] == n_failed and len(ex["measurement_ids"]) == n_failed
    assert a.manifest["n_used"] + n_failed == len(df)
    assert a.manifest["dataset_sha256"] == dataset_hash(df)
    c = train_and_evaluate(df, TrainingConfig(SPEC, MIX, PROC, "batch_id", seed=4, models=("mean_baseline",)))
    assert c.manifest_hash != a.manifest_hash
    # selection never uses the test set
    assert "test set not used" in a.manifest["selection_rule"]


def test_models_beat_baseline_and_intervals_are_calibrated():
    df = synth(200, noise=0.1, seed=1)
    cfg = TrainingConfig(SPEC, MIX, PROC, "batch_id", seed=5, test_fraction=0.3,
                         models=("mean_baseline", "scheffe_ridge", "random_forest", "gaussian_process"))
    r = train_and_evaluate(df, cfg).manifest["results"]
    assert r["scheffe_ridge"]["test"]["mae"] < 0.5 * r["mean_baseline"]["test"]["mae"]
    assert r["gaussian_process"]["test"]["mae"] < 0.5 * r["mean_baseline"]["test"]["mae"]
    for m in ("scheffe_ridge", "random_forest", "gaussian_process"):
        cov90 = r[m]["coverage"]["0.90"]["empirical"]
        cov50 = r[m]["coverage"]["0.50"]["empirical"]
        assert 0.80 <= cov90 <= 0.99, (m, cov90)
        assert 0.30 <= cov50 <= 0.70, (m, cov50)
    # measurement variability vs model uncertainty: GP noise estimate close to the true 0.1
    assert 0.06 < r["gaussian_process"]["model"]["noise_sd_model_scale"] < 0.16


def test_conformal_quantile():
    s = np.arange(1, 101, dtype=float)
    assert conformal_quantile(s, 0.1) == 91.0
    assert conformal_quantile(np.array([]), 0.1) == np.inf


def test_applicability_domain_flags_and_abstains():
    rng = np.random.default_rng(0)
    Z = rng.dirichlet([5, 5, 5], 80)
    Z[:, 2] = np.where(Z[:, 2] < 0.05, 0.05, Z[:, 2]); Z = Z / Z.sum(1, keepdims=True)
    X = np.hstack([Z, rng.uniform(0, 1, (80, 1))])
    ad = ApplicabilityDomain().fit(X, MIX + PROC, 3)
    inside = ad.assess(X[3])
    assert not inside.abstain and "sparse_support" not in inside.flags
    far = ad.assess(np.array([0.98, 0.02, 0.0, 3.0]))
    assert far.abstain and "excessive_extrapolation" in far.flags and "unseen_combination" in far.flags
    assert ad.assess(X[3], research_domain_ok=False).abstain
    assert ad.assess(X[3], missing_properties=["density"]).abstain


def test_conformal_quantile_small_n_is_infinite():
    assert conformal_quantile(np.array([1.0, 2.0, 3.0]), 0.1) == np.inf


def test_classifier_selected_on_training_cv_only():
    df = synth(80)
    df["target"] = "ps"
    df["value"] = (df["mix:A"] > 0.4).astype(float)
    df["status"] = "ok"
    spec = TargetSpec("ps", "1", "VIS", "24 h", kind="classification")
    r = train_and_evaluate(df, TrainingConfig(spec, MIX, PROC, "batch_id", seed=2))
    assert "test set not used" in r.manifest["selection_rule"]
    assert all("inner_cv_brier" in v for v in r.manifest["results"].values())
    assert r.selected == min(r.manifest["results"], key=lambda k: r.manifest["results"][k]["inner_cv_brier"])
