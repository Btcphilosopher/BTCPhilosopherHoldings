"""Object storage for raw experimental files and model artefacts, plus upload restrictions."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Protocol

from .config import Settings

ALLOWED = {".csv": "text/csv", ".json": "application/json", ".txt": "text/plain", ".pdf": "application/pdf"}


class UploadRejected(ValueError):
    pass


def validate_upload(filename: str, data: bytes, max_bytes: int) -> tuple[str, str, str]:
    """Return (safe_name, content_type, sha256) or raise UploadRejected."""
    if not data:
        raise UploadRejected("empty file")
    if len(data) > max_bytes:
        raise UploadRejected(f"file exceeds {max_bytes} bytes")
    name = Path(filename or "").name
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", name)[:120]
    if not safe or safe.startswith("."):
        raise UploadRejected("invalid file name")
    ext = Path(safe).suffix.lower()
    if ext not in ALLOWED:
        raise UploadRejected(f"file type {ext or '(none)'} not permitted; allowed: {sorted(ALLOWED)}")
    if ext == ".pdf":
        if not data.startswith(b"%PDF-"):
            raise UploadRejected("content does not match declared PDF type")
    else:
        if b"\x00" in data:
            raise UploadRejected("binary content in a text file")
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as e:
            raise UploadRejected("text files must be UTF-8") from e
    return safe, ALLOWED[ext], hashlib.sha256(data).hexdigest()


class ObjectStorage(Protocol):
    def put(self, key: str, data: bytes, content_type: str) -> None: ...
    def get(self, key: str) -> bytes: ...


class LocalStorage:
    def __init__(self, root: str):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise UploadRejected("invalid object key")
        return p

    def put(self, key: str, data: bytes, content_type: str) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()


class S3Storage:
    def __init__(self, s: Settings):
        import boto3

        self.bucket = s.s3_bucket
        self.client = boto3.client("s3", endpoint_url=s.s3_endpoint, aws_access_key_id=s.s3_access_key,
                                   aws_secret_access_key=s.s3_secret_key)
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except Exception:
            self.client.create_bucket(Bucket=self.bucket)

    def put(self, key: str, data: bytes, content_type: str) -> None:
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()


_store = None


def get_storage(s: Settings) -> ObjectStorage:
    global _store
    if _store is None:
        _store = S3Storage(s) if s.storage_backend == "s3" else LocalStorage(s.storage_root)
    return _store


def reset_storage() -> None:
    global _store
    _store = None
