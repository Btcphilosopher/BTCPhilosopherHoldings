"""Runtime settings from environment variables (no secrets in code)."""

from __future__ import annotations

import os
import secrets
from dataclasses import dataclass, field
from functools import lru_cache


@dataclass(frozen=True)
class Settings:
    env: str = field(default_factory=lambda: os.getenv("TERTIUS_ENV", "development"))
    database_url: str = field(default_factory=lambda: os.getenv(
        "TERTIUS_DATABASE_URL", "sqlite:///./tertius_dev.db"))
    secret_key: str = field(default_factory=lambda: os.getenv("TERTIUS_SECRET_KEY", ""))
    token_minutes: int = field(default_factory=lambda: int(os.getenv("TERTIUS_TOKEN_MINUTES", "60")))
    storage_backend: str = field(default_factory=lambda: os.getenv("TERTIUS_STORAGE", "local"))  # local | s3
    storage_root: str = field(default_factory=lambda: os.getenv("TERTIUS_STORAGE_ROOT", "./object_store"))
    s3_endpoint: str | None = field(default_factory=lambda: os.getenv("TERTIUS_S3_ENDPOINT"))
    s3_bucket: str = field(default_factory=lambda: os.getenv("TERTIUS_S3_BUCKET", "tertius-raw"))
    s3_access_key: str | None = field(default_factory=lambda: os.getenv("TERTIUS_S3_ACCESS_KEY"))
    s3_secret_key: str | None = field(default_factory=lambda: os.getenv("TERTIUS_S3_SECRET_KEY"))
    max_upload_bytes: int = field(default_factory=lambda: int(os.getenv("TERTIUS_MAX_UPLOAD_BYTES", str(20 * 2**20))))
    cors_origins: tuple[str, ...] = field(default_factory=lambda: tuple(
        o for o in os.getenv("TERTIUS_CORS_ORIGINS", "http://localhost:5173,http://localhost:8080").split(",") if o))

    def resolved_secret(self) -> str:
        if self.secret_key:
            if self.env == "production" and len(self.secret_key) < 32:
                raise RuntimeError("TERTIUS_SECRET_KEY must be at least 32 characters in production")
            return self.secret_key
        if self.env == "production":
            raise RuntimeError("TERTIUS_SECRET_KEY is required in production")
        return _ephemeral_secret()


@lru_cache
def _ephemeral_secret() -> str:
    # development only: tokens become invalid when the process restarts
    return secrets.token_urlsafe(48)


@lru_cache
def get_settings() -> Settings:
    return Settings()
