"""Command-line entry points.

  tertius init-db                  apply Alembic migrations (PostgreSQL) or create tables (SQLite)
  tertius create-admin USER        create an administrator (password from TERTIUS_ADMIN_PASSWORD or prompt)
  tertius demo [--out DIR]         run the 12-step synthetic demonstration through the API
  tertius synth --out DIR          write synthetic design/results/stability/combination CSVs
  tertius train CSV --target T     offline reproducible training from a measurement CSV; writes artefact+manifest
  tertius export-openapi PATH      write the OpenAPI schema
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="tertius")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init-db")
    a = sub.add_parser("create-admin"); a.add_argument("username")
    d = sub.add_parser("demo"); d.add_argument("--out", default="demo_output"); d.add_argument("--seed", type=int, default=11)
    s = sub.add_parser("synth"); s.add_argument("--out", required=True); s.add_argument("--seed", type=int, default=11)
    t = sub.add_parser("train")
    t.add_argument("csv"); t.add_argument("--target", required=True); t.add_argument("--out", default="artifacts")
    t.add_argument("--split-by", default="batch_id"); t.add_argument("--seed", type=int, default=7)
    o = sub.add_parser("export-openapi"); o.add_argument("path")
    args = ap.parse_args(argv)

    if args.cmd == "init-db":
        from .db.models import Base
        from .db.session import get_engine
        eng = get_engine()
        if eng.dialect.name == "sqlite":
            Base.metadata.create_all(eng)
        else:
            from alembic import command
            from alembic.config import Config
            base = next(p for p in (Path.cwd(), Path(__file__).resolve().parent.parent) if (p / "alembic.ini").exists())
            cfg = Config(str(base / "alembic.ini"))
            cfg.set_main_option("script_location", str(base / "alembic"))
            command.upgrade(cfg, "head")
        print("database ready")
    elif args.cmd == "create-admin":
        from .api.security import hash_password
        from .db.models import User
        from .db.session import session_factory
        pw = os.getenv("TERTIUS_ADMIN_PASSWORD") or getpass.getpass("password: ")
        db = session_factory()()
        db.add(User(username=args.username, full_name=args.username, password_hash=hash_password(pw), is_admin=True))
        db.commit()
        print(f"admin {args.username} created")
    elif args.cmd == "demo":
        from .demo import run_demo
        summary = run_demo(args.out, args.seed)
        print(json.dumps({k: summary[k] for k in ("notice", "audit_chain", "api_calls")}, indent=2))
        print(f"outputs written to {args.out}/")
    elif args.cmd == "synth":
        import pandas as pd
        from .science.doe import DesignSpec, generate_design
        from .synthetic.demo_config import demo_domain
        from .synthetic.generator import (generate_combination_dataset, generate_experiment_results,
                                          generate_stability_study)
        out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
        ref = {"SV-1": 0.70, "VM-2": 0.15, "SF-3": 0.05, "TR-4": 0.10}
        des = generate_design(demo_domain(), DesignSpec(n_mixture_points=22, replicates=2, control=ref,
                                                        control_process={"mix_speed": 600, "mix_time": 20,
                                                                         "temperature": 25},
                                                        blocks=("day1", "day2", "day3")))
        des.runs.to_csv(out / "design_runs.csv", index=False)
        generate_experiment_results(des.runs, args.seed).to_csv(out / "synthetic_results.csv", index=False)
        generate_stability_study(args.seed + 1, {"SUS-DEMO-REF": ref}).to_csv(out / "stability.csv", index=False)
        generate_combination_dataset(args.seed).to_csv(out / "combination.csv", index=False)
        print(f"synthetic data written to {out}/")
    elif args.cmd == "train":
        import pandas as pd
        from .science.ml.pipeline import TrainingConfig, save_artifact, train_and_evaluate
        from .synthetic.demo_config import TARGETS
        df = pd.read_csv(args.csv)
        if args.target not in TARGETS:
            print(f"unknown target {args.target}; offline CLI knows {sorted(TARGETS)}", file=sys.stderr)
            return 2
        mix = sorted(c for c in df.columns if c.startswith("mix:")); proc = sorted(c for c in df.columns if c.startswith("proc:"))
        res = train_and_evaluate(df, TrainingConfig(TARGETS[args.target], mix, proc, args.split_by, seed=args.seed))
        man = save_artifact(res, args.out)
        print(json.dumps({"target": args.target, "selected": res.selected, "manifest_sha256": res.manifest_hash,
                          "artifact": man["artifact_file"], "artifact_sha256": man["artifact_sha256"],
                          "test": {k: v.get("test") for k, v in res.manifest["results"].items()}}, indent=2))
    elif args.cmd == "export-openapi":
        from .api.main import app
        Path(args.path).write_text(json.dumps(app.openapi(), indent=2))
        print(f"OpenAPI schema written to {args.path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
