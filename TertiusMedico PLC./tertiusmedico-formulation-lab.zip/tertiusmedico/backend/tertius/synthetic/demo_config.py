"""Configuration of the fictional demonstration system (see generator.py for the response functions)."""

from __future__ import annotations

from ..science.constraints import (CompatibilityRecord, CostLimit, EquipmentLimit, GroupLimit, Price, ProcessRange,
                                   ResearchDomain)
from ..science.quality import TargetSpec
from .generator import COMPONENTS

MIX_COLS = [f"mix:{c}" for c in COMPONENTS]
PROC_COLS = ["proc:mix_speed", "proc:mix_time", "proc:temperature"]

TARGETS = {
    "viscosity": TargetSpec("viscosity", "mPa*s", "ROT-RHEO-50 (rotational rheometer, 50 s^-1, 25 °C)",
                            "at manufacture (t = 0)", lower_bound=0.0, upper_bound=1e6, log_transform=True,
                            repeatability_cv_limit=0.15, description="apparent viscosity"),
    "uniformity_cv": TargetSpec("uniformity_cv", "%", "HPLC-UNIF-10 (tracer content, 10 aliquots)",
                                "at manufacture (t = 0)", lower_bound=0.0, upper_bound=100.0,
                                repeatability_cv_limit=0.35, description="content uniformity (CV %) – reproducibility"),
    "assay_4w_40C": TargetSpec("assay_4w_40C", "%", "HPLC-ASSAY (marker % of initial)",
                               "after 4 weeks at 40 °C/75 %RH in glass (screening stress test)",
                               lower_bound=0.0, upper_bound=110.0, repeatability_cv_limit=0.02,
                               description="accelerated screening stability"),
    "phase_separation": TargetSpec("phase_separation", "1", "VISUAL-24H", "24 h after manufacture",
                                   lower_bound=0.0, upper_bound=1.0, kind="classification",
                                   description="visual phase separation (event)"),
}

INSTRUMENTS = {"RHEO-01": {"calibration_due": "2026-12-31", "last_calibrated": "2026-01-10"},
               "HPLC-02": {"calibration_due": "2026-12-31", "last_calibrated": "2026-01-05"}}

PRICE_DATE = "2026-01-15"


def demo_domain() -> ResearchDomain:
    pairs = [("SV-1", "VM-2"), ("SV-1", "SF-3"), ("SV-1", "TR-4"), ("VM-2", "SF-3"), ("SF-3", "TR-4")]
    compat = tuple(CompatibilityRecord(a, b, "compatible", "DEMO-COMPAT-REVIEW-001 (synthetic screening record)", True)
                   for a, b in pairs)
    compat += (CompatibilityRecord("VM-2", "TR-4", "unknown", "no reviewed evidence", False),)
    return ResearchDomain(
        name="Fictional suspension SUS-DEMO domain v1",
        components=COMPONENTS,
        bounds={"SV-1": (0.50, 0.85), "VM-2": (0.05, 0.30), "SF-3": (0.01, 0.10), "TR-4": (0.02, 0.20)},
        required=frozenset({"TR-4"}),
        groups=(GroupLimit("structurants", ("VM-2", "TR-4"), 0.10, 0.40),),
        process={"mix_speed": ProcessRange("mix_speed", 200, 1200, "rpm"),
                 "mix_time": ProcessRange("mix_time", 5, 40, "min"),
                 "temperature": ProcessRange("temperature", 20, 40, "degC")},
        equipment=(EquipmentLimit("MIXER-LAB-01", "mix_speed", None, 1000, "rpm"),),
        compatibility=compat,
        unknown_compatibility_policy="flag",
        prices={c: Price(c, p, "EUR", "kg", PRICE_DATE) for c, p in
                {"SV-1": 2.0, "VM-2": 48.0, "SF-3": 95.0, "TR-4": 30.0}.items()},
        cost_limit=CostLimit(25.0, "EUR", "kg"),
    )
