"""Synthetic data generator for the TERTIUSMEDICO demonstration.

EVERYTHING HERE IS FICTIONAL. The four ingredients are inert surrogates with
invented names and invented behaviour; the response functions below are
*documented toy physics* chosen to exercise the software (interactions, batch
effects, lot effects, noise, failures, censoring). They are not derived from
and must not be used as data about any real material or medicine.

Surrogate system: a four-component aqueous-like suspension
-----------------------------------------------------------
=========  ============================  ===========  ======================
id         fictional name                role         demo bounds (w/w)
=========  ============================  ===========  ======================
SV-1       Aqualine Base S-1             vehicle      0.50 – 0.85
VM-2       Viscogel VM-2                 thickener    0.05 – 0.30
SF-3       Tensiol SF-3                  surfactant   0.01 – 0.10
TR-4       Inertite TR-4 (tracer)        tracer       0.02 – 0.20
=========  ============================  ===========  ======================

Process variables: ``mix_speed`` (rpm, 200–1000), ``mix_time`` (min, 5–40),
``temperature`` (°C, 20–40).

Response functions (x = mass fractions, s = speed, t = time, T = temperature)
-------------------------------------------------------------------------------
* **Viscosity** (mPa·s, rotational rheometer @ 50 s⁻¹, 25 °C, t = 0)::

      ln η = 1.6·x_SV + 9.0·x_VM + 3.0·x_SF + 2.5·x_TR          (Scheffé linear)
           + 4.0·x_SV·x_VM + 3.0·x_VM·x_TR − 5.0·x_SF·x_TR      (binary interactions)
           − 0.15·(s − 600)/400 − 0.01·(T − 25)                (process)
           + lot_effect[VM-2 lot] + day_effect[day] + ε,  ε ~ N(0, 0.06²)

  lot effects: L-VM2-A 0, L-VM2-B +0.12, L-VM2-C −0.08; day effects ~ N(0, 0.05²) fixed per seed.

* **Phase separation within 24 h** (failure event)::

      logit p = −3 + 30·(x_TR − 0.12) − 50·(x_SF − 0.04) − 1.5·(ln η − 3.5) − 0.05·(t − 20)

  A phase-separated run is recorded with ``status = failed`` and no
  viscosity/uniformity value (the sample was not measurable). Independently,
  3 % of runs suffer an instrument fault (``status = failed``, reason recorded).

* **Content uniformity** (CV % of tracer across 10 aliquots)::

      CV = 1.2 + 4·exp(−t/10)·sqrt(600/s) + 3/(1 + exp(−30·(x_TR − 0.15))) + |N(0, 0.25²)|

* **Accelerated screening assay** (% of initial marker retained after 4 weeks at 40 °C/75 %RH, glass)::

      k = 0.030·(1 + 4·x_SF)·(1 − 1.5·x_VM)  per month;   A = 100·exp(−k·0.92) + N(0, 0.3²)

* **Stability study** (per formulation, packaging, condition, lot): first-order
  loss with Arrhenius-like temperature factor (×4.2 from 25 °C to 40 °C),
  packaging factor (PET ×1.4 vs glass), lot offsets, analytical noise
  N(0, 0.4²) %. Degradant (%) = 100 − assay − 0.2, censored below the LOD of 0.05 %.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Mapping

import numpy as np
import pandas as pd

COMPONENTS = ("SV-1", "VM-2", "SF-3", "TR-4")
FICTIONAL_MATERIALS = [
    {"material_id": "SV-1", "name": "Aqualine Base S-1 (fictional surrogate vehicle)", "role": "vehicle",
     "supplier": "Demo Supplier Alpha (fictional)", "grade": "demo", "density": 1.00, "price": 2.0},
    {"material_id": "VM-2", "name": "Viscogel VM-2 (fictional surrogate thickener)", "role": "thickener",
     "supplier": "Demo Supplier Beta (fictional)", "grade": "demo", "density": None, "price": 48.0},
    {"material_id": "SF-3", "name": "Tensiol SF-3 (fictional surrogate surfactant)", "role": "surfactant",
     "supplier": "Demo Supplier Alpha (fictional)", "grade": "demo", "density": 1.05, "price": 95.0},
    {"material_id": "TR-4", "name": "Inertite TR-4 (fictional inert tracer solid)", "role": "tracer",
     "supplier": "Demo Supplier Gamma (fictional)", "grade": "demo", "density": None, "price": 30.0},
]
LOT_EFFECT = {"L-VM2-A": 0.0, "L-VM2-B": 0.12, "L-VM2-C": -0.08}
LOTS = tuple(LOT_EFFECT)


def true_log_viscosity(x: Mapping[str, float], speed: float, temperature: float) -> float:
    sv, vm, sf, tr = (x[c] for c in COMPONENTS)
    return (1.6 * sv + 9.0 * vm + 3.0 * sf + 2.5 * tr + 4.0 * sv * vm + 3.0 * vm * tr - 5.0 * sf * tr
            - 0.15 * (speed - 600) / 400 - 0.01 * (temperature - 25))


def p_phase_separation(x: Mapping[str, float], log_visc: float, mix_time: float) -> float:
    z = -3 + 30 * (x["TR-4"] - 0.12) - 50 * (x["SF-3"] - 0.04) - 1.5 * (log_visc - 3.5) - 0.05 * (mix_time - 20)
    return 1 / (1 + math.exp(-z))


def true_uniformity_cv(x: Mapping[str, float], speed: float, mix_time: float) -> float:
    return 1.2 + 4 * math.exp(-mix_time / 10) * math.sqrt(600 / speed) + 3 / (1 + math.exp(-30 * (x["TR-4"] - 0.15)))


def true_assay_4w(x: Mapping[str, float]) -> float:
    k = 0.030 * (1 + 4 * x["SF-3"]) * (1 - 1.5 * x["VM-2"])
    return 100 * math.exp(-k * 0.92)


@dataclass
class SimContext:
    day: str
    lot: str
    day_effect: float


def simulate_run(x: Mapping[str, float], proc: Mapping[str, float], ctx: SimContext, rng: np.random.Generator,
                 instrument_fault_rate: float = 0.03) -> dict:
    s, t, T = proc["mix_speed"], proc["mix_time"], proc["temperature"]
    lv_true = true_log_viscosity(x, s, T) + LOT_EFFECT[ctx.lot] + ctx.day_effect
    lv = lv_true + rng.normal(0, 0.06)
    separated = rng.random() < p_phase_separation(x, lv_true, t)
    fault = rng.random() < instrument_fault_rate
    out: dict = {"phase_separated": bool(separated)}
    if separated:
        out["viscosity"] = {"status": "failed", "value": None, "failure_reason": "phase separation observed at 24 h"}
        out["uniformity_cv"] = {"status": "failed", "value": None, "failure_reason": "phase separation observed at 24 h"}
    else:
        out["viscosity"] = ({"status": "failed", "value": None, "failure_reason": "rheometer instrument fault (torque overload)"}
                            if fault else {"status": "ok", "value": float(math.exp(lv))})
        cv = true_uniformity_cv(x, s, t) + abs(rng.normal(0, 0.25))
        out["uniformity_cv"] = {"status": "ok", "value": float(cv)}
    out["assay_4w_40C"] = {"status": "ok", "value": float(true_assay_4w(x) + rng.normal(0, 0.3))}
    return out


def generate_experiment_results(runs: pd.DataFrame, seed: int, start_date: str = "2026-02-02") -> pd.DataFrame:
    """Simulate measurements for every run of a design (rows from :func:`tertius.science.doe.generate_design`)."""
    rng = np.random.default_rng(seed)
    days = sorted({b for b in runs.get("block", pd.Series(dtype=object)).dropna()}) or ["day1"]
    day_eff = {d: float(rng.normal(0, 0.05)) for d in days}
    day_date = {d: (pd.Timestamp(start_date) + pd.Timedelta(days=7 * i)).date().isoformat() for i, d in enumerate(days)}
    rows = []
    for _, r in runs.iterrows():
        x = {c: float(r[f"mix:{c}"]) for c in COMPONENTS}
        proc = {k: float(r[f"proc:{k}"]) for k in ("mix_speed", "mix_time", "temperature")}
        day = r.get("block") or days[0]
        lot = LOTS[int(rng.integers(len(LOTS)))]
        res = simulate_run(x, proc, SimContext(day, lot, day_eff[day]), rng)
        base = {"run_id": r["run_id"], "design_point": r["design_point"], "role": r["role"],
                "replicate": int(r["replicate"]), "replicate_group": r["replicate_group"], "block": day,
                "batch_id": f"B-{r['run_id']}", "lot_ids": f"VM-2:{lot}", "measured_on": day_date[day],
                **{f"mix:{c}": x[c] for c in COMPONENTS}, **{f"proc:{k}": v for k, v in proc.items()}}
        spec = {"viscosity": ("mPa*s", "ROT-RHEO-50", "RHEO-01"),
                "uniformity_cv": ("%", "HPLC-UNIF-10", "HPLC-02"),
                "assay_4w_40C": ("%", "HPLC-ASSAY", "HPLC-02")}
        for tgt, (unit, method, inst) in spec.items():
            m = res[tgt]
            rows.append({**base, "measurement_id": f"M-{r['run_id']}-{tgt}", "target": tgt, "value": m["value"],
                         "unit": unit, "method": method, "instrument_id": inst, "status": m["status"],
                         "failure_reason": m.get("failure_reason"), "lod": None})
        rows.append({**base, "measurement_id": f"M-{r['run_id']}-phase_separation", "target": "phase_separation",
                     "value": float(res["phase_separated"]), "unit": "1", "method": "VISUAL-24H", "instrument_id": None,
                     "status": "ok", "failure_reason": None, "lod": None})
    return pd.DataFrame(rows)


def generate_stability_study(seed: int, formulations: Mapping[str, Mapping[str, float]]) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    conds = {"25C/60RH": (1.0, [0, 1, 2, 3, 6, 9]), "40C/75RH": (4.2, [0, 1, 2, 3, 6])}
    packs = {"glass_vial": 1.0, "PET_bottle": 1.4}
    lot_off = {"L-VM2-A": 0.0, "L-VM2-B": 0.002}
    i = 0
    for fid, x in formulations.items():
        k25 = 0.004 * (1 + 4 * x["SF-3"]) * (1 - 1.5 * x["VM-2"])
        for cond, (tf, times) in conds.items():
            for pack, pf in packs.items():
                for lot, lo in lot_off.items():
                    for tm in times:
                        k = (k25 + lo) * tf * pf
                        assay = 100 * math.exp(-k * tm) + (rng.normal(0, 0.4) if tm > 0 else rng.normal(0, 0.2))
                        deg = max(0.0, 100 * (1 - math.exp(-k * tm)) - 0.2 + rng.normal(0, 0.03))
                        i += 1
                        common = {"formulation_id": fid, "formulation_revision": 1, "packaging": pack,
                                  "condition": cond, "time_months": tm, "lot": lot}
                        rows.append({**common, "stab_id": f"S{i:04d}a", "attribute": "assay", "value": round(assay, 2),
                                     "unit": "%", "method": "HPLC-ASSAY", "status": "ok", "lod": None})
                        status = "censored" if deg < 0.05 else "ok"
                        rows.append({**common, "stab_id": f"S{i:04d}d", "attribute": "degradant",
                                     "value": None if status == "censored" else round(deg, 3), "unit": "%",
                                     "method": "HPLC-RS", "status": status, "lod": 0.05})
    return pd.DataFrame(rows)


def generate_combination_dataset(seed: int) -> pd.DataFrame:
    """Fictional in-vitro response surface for two fictional research compounds CX-1 and CY-2.

    Single-agent responses follow Hill curves (EC50 1.0 and 3.0 µM-equivalent, Hill slope 1.2 and 1.0,
    Emax 0.9 and 0.8). The combined response is Bliss-independent plus an excess of +0.12 at the two middle
    dose levels of both compounds and 0 elsewhere. Replicates have N(0, 0.04²) noise; vehicle controls ~ N(0, 0.02²).
    This is an abstract assay used only to exercise reference-model calculations.
    """
    rng = np.random.default_rng(seed)
    da = [0.0, 0.3, 1.0, 3.0, 10.0]
    db = [0.0, 1.0, 3.0, 10.0, 30.0]

    def hill(d, ec, h, emax):
        return 0.0 if d == 0 else emax * d ** h / (ec ** h + d ** h)

    rows = []
    for i, a in enumerate(da):
        for j, b in enumerate(db):
            ea, eb = hill(a, 1.0, 1.2, 0.9), hill(b, 3.0, 1.0, 0.8)
            e = ea + eb - ea * eb + (0.12 if i in (2, 3) and j in (2, 3) else 0.0)
            for rep in range(3):
                noise = rng.normal(0, 0.02 if a == 0 and b == 0 else 0.04)
                rows.append({"compound_a": "CX-1", "dose_a": a, "compound_b": "CY-2", "dose_b": b,
                             "dose_unit": "uM", "replicate": rep + 1, "plate": f"P{rep + 1}",
                             "response": float(np.clip(e + noise, -0.2, 1.2)),
                             "endpoint": "fractional_inhibition_signal_48h",
                             "control": "vehicle" if a == 0 and b == 0 else None})
    return pd.DataFrame(rows)
