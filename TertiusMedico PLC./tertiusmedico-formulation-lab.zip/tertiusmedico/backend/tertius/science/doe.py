"""Design of experiments for mixtures and process variables.

Why ordinary unconstrained sampling is inappropriate for mixtures
-----------------------------------------------------------------
Ingredient fractions obey ``x_1 + … + x_q = 1``. If each fraction is sampled
independently on [0, 1] (box Latin hypercube, full factorial on fractions),
almost every point violates the total. Normalising afterwards (``x / Σx``)
distorts the distribution (mass piles up near the centroid, edges and vertices
are under-sampled) and ignores bounds, so a box design cannot express the
experimental region. The design space is a (q−1)-dimensional simplex, or a
polytope inside it once bounds and group limits apply, and designs must be
generated *in that polytope*. The same constraint makes mixture effects
non-identifiable in an ordinary polynomial with an intercept (perfect
collinearity), which is why Scheffé canonical polynomials are used.

Mixture and process variables are kept in separate column namespaces
(``mix:`` and ``proc:``) and are combined only by explicit crossing or
space-filling over the product space.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy.linalg import null_space
from scipy.optimize import linprog
from scipy.stats import qmc

from .constraints import ResearchDomain, check_candidate, is_admissible

WHY_NOT_BOX_SAMPLING = (
    "Ingredient fractions must sum to a fixed total, so the feasible region is a simplex/polytope of dimension q−1, "
    "not a q-dimensional box. Independent sampling of each fraction violates the total; renormalising afterwards "
    "distorts coverage (over-samples the centroid, under-samples edges/vertices) and can breach component bounds. "
    "Designs here are generated directly inside the constrained polytope (lattice, extreme vertices, hit-and-run "
    "space filling, D-optimal exchange) and analysed with Scheffé models without an intercept."
)


# --------------------------------------------------------------------------------------
# Classical simplex designs
# --------------------------------------------------------------------------------------
def simplex_lattice(q: int, m: int) -> np.ndarray:
    """{q, m} simplex-lattice: all points with x_i ∈ {0, 1/m, …, 1} and Σx = 1."""
    pts = [np.array(c) / m for c in itertools.product(range(m + 1), repeat=q) if sum(c) == m]
    return np.array(pts)


def simplex_centroid(q: int) -> np.ndarray:
    pts = []
    for r in range(1, q + 1):
        for subset in itertools.combinations(range(q), r):
            x = np.zeros(q); x[list(subset)] = 1.0 / r
            pts.append(x)
    return np.array(pts)


def to_pseudocomponents(lower: np.ndarray, total: float = 1.0):
    """L-pseudocomponent transform: x = L + (total − ΣL)·z with z on the unit simplex."""
    rest = total - lower.sum()
    if rest <= 0:
        raise ValueError("lower bounds leave no free mixture range")
    return lambda z: lower + rest * np.asarray(z)


# --------------------------------------------------------------------------------------
# Constrained polytope utilities
# --------------------------------------------------------------------------------------
@dataclass
class Polytope:
    """{x : A x ≤ b, 1ᵀx = total} for the linear part of a research domain."""
    components: tuple[str, ...]
    A: np.ndarray
    b: np.ndarray
    total: float
    names: list[str]

    @classmethod
    def from_domain(cls, d: ResearchDomain, zero: Iterable[str] = ()) -> "Polytope":
        idx = {c: i for i, c in enumerate(d.components)}
        A, b, names = [], [], []
        for c in d.linear_constraints():
            if c.sense == "=":
                continue  # the only equality is the total
            row = np.zeros(len(idx))
            for k, v in c.coeffs.items():
                row[idx[k]] = v
            if c.sense == "<=":
                A.append(row); b.append(c.rhs)
            else:
                A.append(-row); b.append(-c.rhs)
            names.append(c.name)
        for i in range(len(idx)):  # non-negativity
            row = np.zeros(len(idx)); row[i] = -1.0
            A.append(row); b.append(0.0); names.append(f"nonneg[{d.components[i]}]")
        for z in zero:
            row = np.zeros(len(idx)); row[idx[z]] = 1.0
            A.append(row); b.append(0.0); names.append(f"zero[{z}]")
        return cls(d.components, np.array(A), np.array(b), d.total, names)

    def contains(self, x: np.ndarray, tol: float = 1e-8) -> bool:
        return bool(np.all(self.A @ x <= self.b + tol) and abs(x.sum() - self.total) < 1e-6)

    def chebyshev_center(self) -> np.ndarray:
        """Interior point maximising the distance to the inequality faces within the affine hull."""
        q = len(self.components)
        N = null_space(np.ones((1, q)))  # basis for directions with Σ = 0
        norms = np.linalg.norm(self.A @ N, axis=1)
        # variables: x (q), r
        c = np.zeros(q + 1); c[-1] = -1.0
        A_ub = np.hstack([self.A, norms[:, None]])
        A_eq = np.hstack([np.ones((1, q)), np.zeros((1, 1))])
        res = linprog(c, A_ub=A_ub, b_ub=self.b, A_eq=A_eq, b_eq=[self.total],
                      bounds=[(None, None)] * q + [(0, None)], method="highs")
        if res.status != 0:
            raise ValueError("polytope is empty")
        return res.x[:q]

    def vertices(self) -> np.ndarray:
        """Extreme vertices: intersections of q−1 active inequality faces with the total (McLean–Anderson style)."""
        q = len(self.components)
        verts = []
        for combo in itertools.combinations(range(len(self.A)), q - 1):
            M = np.vstack([self.A[list(combo)], np.ones((1, q))])
            rhs = np.concatenate([self.b[list(combo)], [self.total]])
            if abs(np.linalg.det(M)) < 1e-12:
                continue
            x = np.linalg.solve(M, rhs)
            if self.contains(x, 1e-9):
                verts.append(np.round(x, 12))
        if not verts:
            return np.empty((0, q))
        return np.unique(np.array(verts), axis=0)

    def hit_and_run(self, n: int, rng: np.random.Generator, burn: int = 200, thin: int = 5) -> np.ndarray:
        """Approximately uniform samples from the polytope (hit-and-run MCMC)."""
        q = len(self.components)
        N = null_space(np.ones((1, q)))
        x = self.chebyshev_center()
        out = []
        steps = burn + n * thin
        for s in range(steps):
            d = N @ rng.normal(size=N.shape[1])
            d /= np.linalg.norm(d)
            Ad = self.A @ d
            slack = self.b - self.A @ x
            with np.errstate(divide="ignore", invalid="ignore"):
                t = slack / Ad
            t_hi = np.min(t[Ad > 1e-12]) if np.any(Ad > 1e-12) else 0.0
            t_lo = np.max(t[Ad < -1e-12]) if np.any(Ad < -1e-12) else 0.0
            if t_hi - t_lo > 1e-14:
                x = x + rng.uniform(t_lo, t_hi) * d
            if s >= burn and (s - burn) % thin == 0:
                out.append(np.clip(x, 0, None))
        X = np.array(out[:n])
        return X / X.sum(axis=1, keepdims=True) * self.total


def maximin_subset(X: np.ndarray, k: int, rng: np.random.Generator, start: np.ndarray | None = None) -> np.ndarray:
    """Greedy farthest-point selection of k rows from X (space filling)."""
    if k >= len(X):
        return X
    chosen = [int(rng.integers(len(X)))] if start is None else []
    base = start if start is not None else X[chosen]
    d = np.min(np.linalg.norm(X[:, None, :] - base[None, :, :], axis=2), axis=1)
    while len(chosen) < k:
        i = int(np.argmax(d))
        chosen.append(i)
        d = np.minimum(d, np.linalg.norm(X - X[i], axis=1))
    return X[chosen]


# --------------------------------------------------------------------------------------
# Scheffé model matrix and D-optimal exchange
# --------------------------------------------------------------------------------------
def scheffe_matrix(X: np.ndarray, order: int = 2) -> np.ndarray:
    cols = [X[:, i] for i in range(X.shape[1])]
    if order >= 2:
        cols += [X[:, i] * X[:, j] for i, j in itertools.combinations(range(X.shape[1]), 2)]
    if order >= 3:  # special cubic
        cols += [X[:, i] * X[:, j] * X[:, k] for i, j, k in itertools.combinations(range(X.shape[1]), 3)]
    return np.column_stack(cols)


def scheffe_terms(q: int, order: int = 2) -> int:
    return q + (math.comb(q, 2) if order >= 2 else 0) + (math.comb(q, 3) if order >= 3 else 0)


def d_optimal(candidates: np.ndarray, n: int, order: int, rng: np.random.Generator, iters: int = 50) -> np.ndarray:
    """Fedorov-style point exchange maximising log det(XᵀX) for a Scheffé model."""
    p = scheffe_terms(candidates.shape[1], order)
    if n < p:
        raise ValueError(f"D-optimal design needs at least {p} runs for a Scheffé order-{order} model with "
                         f"{candidates.shape[1]} components; requested {n}")
    F = scheffe_matrix(candidates, order)
    idx = list(rng.choice(len(candidates), size=n, replace=len(candidates) < n))

    def logdet(ix):
        M = F[ix].T @ F[ix] + 1e-10 * np.eye(p)
        s, v = np.linalg.slogdet(M)
        return v if s > 0 else -np.inf

    best = logdet(idx)
    for _ in range(iters):
        improved = False
        for pos in range(n):
            for cand in range(len(candidates)):
                if cand == idx[pos]:
                    continue
                trial = idx.copy(); trial[pos] = cand
                v = logdet(trial)
                if v > best + 1e-9:
                    best, idx, improved = v, trial, True
        if not improved:
            break
    return candidates[idx]


# --------------------------------------------------------------------------------------
# Process designs
# --------------------------------------------------------------------------------------
def full_factorial(levels: Mapping[str, Sequence[float]]) -> pd.DataFrame:
    keys = list(levels)
    return pd.DataFrame(list(itertools.product(*[levels[k] for k in keys])), columns=[f"proc:{k}" for k in keys])


def latin_hypercube(ranges: Mapping[str, tuple[float, float]], n: int, seed: int) -> pd.DataFrame:
    keys = list(ranges)
    s = qmc.LatinHypercube(d=len(keys), seed=seed).random(n)
    lo = np.array([ranges[k][0] for k in keys]); hi = np.array([ranges[k][1] for k in keys])
    return pd.DataFrame(qmc.scale(s, lo, hi) if len(keys) else np.empty((n, 0)), columns=[f"proc:{k}" for k in keys])


# --------------------------------------------------------------------------------------
# Full design assembly
# --------------------------------------------------------------------------------------
@dataclass
class DesignSpec:
    mixture_strategy: str = "extreme_vertices_d_optimal"  # | "simplex_lattice" | "simplex_centroid" | "space_filling"
    n_mixture_points: int = 12
    scheffe_order: int = 2
    lattice_degree: int = 3
    process_strategy: str = "latin_hypercube"  # | "full_factorial" | "none"
    process_levels: Mapping[str, Sequence[float]] = field(default_factory=dict)
    replicates: int = 2
    control: Mapping[str, float] | None = None  # reference composition
    control_process: Mapping[str, float] | None = None
    n_controls: int = 2
    blocking_factor: str | None = "day"  # "day" | "equipment" | "material_lot" | None
    blocks: Sequence[str] = ()
    seed: int = 20260101
    cost_per_run: float | None = None
    currency: str | None = None


@dataclass
class Design:
    runs: pd.DataFrame
    coverage: dict
    limitations: list[str]
    budget: dict
    rationale: str

    def as_dict(self) -> dict:
        return {"runs": self.runs.to_dict(orient="records"), "coverage": self.coverage,
                "limitations": self.limitations, "budget": self.budget, "rationale": self.rationale}


def _mixture_points(domain: ResearchDomain, spec: DesignSpec, rng: np.random.Generator) -> tuple[np.ndarray, list[str]]:
    notes: list[str] = []
    q = len(domain.components)
    poly = Polytope.from_domain(domain)
    if spec.mixture_strategy in ("simplex_lattice", "simplex_centroid"):
        base = simplex_lattice(q, spec.lattice_degree) if spec.mixture_strategy == "simplex_lattice" else simplex_centroid(q)
        keep = np.array([poly.contains(x) for x in base])
        if not keep.all():
            notes.append(f"{(~keep).sum()} of {len(base)} unconstrained simplex points fall outside the research domain "
                         "and were dropped; use a constrained design for bounded regions")
        return base[keep], notes
    cloud = poly.hit_and_run(2000, rng)
    if spec.mixture_strategy == "space_filling":
        return maximin_subset(cloud, spec.n_mixture_points, rng), notes
    verts = poly.vertices()
    centroid = verts.mean(axis=0) if len(verts) else poly.chebyshev_center()
    # candidate set: vertices, edge midpoints between vertex pairs on a common face, centroid, axial points, cloud
    mids = []
    for i, j in itertools.combinations(range(len(verts)), 2):
        m = (verts[i] + verts[j]) / 2
        if poly.contains(m):
            mids.append(m)
    axial = [(v + centroid) / 2 for v in verts]
    cand = np.vstack([v for v in (verts, np.array(mids).reshape(-1, q), np.array(axial).reshape(-1, q),
                                  centroid[None, :], maximin_subset(cloud, 40, rng)) if len(v)])
    cand = np.unique(np.round(cand, 10), axis=0)
    notes.append(f"candidate set: {len(verts)} extreme vertices, {len(mids)} edge midpoints, {len(axial)} axial points, "
                 "overall centroid and 40 space-filling interior points")
    pts = d_optimal(cand, spec.n_mixture_points, spec.scheffe_order, rng)
    # D-optimal concentrates on the boundary; ensure the centroid is present for lack-of-fit checks
    if not any(np.allclose(p, centroid, atol=1e-6) for p in pts):
        pts = np.vstack([pts, centroid])
        notes.append("overall centroid added to support lack-of-fit/curvature checks")
    return np.unique(np.round(pts, 10), axis=0), notes


def _coverage(domain: ResearchDomain, X: np.ndarray, rng: np.random.Generator) -> dict:
    poly = Polytope.from_domain(domain)
    ref = poly.hit_and_run(1500, rng)
    d = np.min(np.linalg.norm(ref[:, None, :] - X[None, :, :], axis=2), axis=1)
    nn = np.linalg.norm(X[:, None, :] - X[None, :, :], axis=2)
    np.fill_diagonal(nn, np.inf)
    per_comp = {}
    for i, c in enumerate(domain.components):
        lo, hi = ref[:, i].min(), ref[:, i].max()
        per_comp[c] = {"design_min": float(X[:, i].min()), "design_max": float(X[:, i].max()),
                       "domain_min": float(lo), "domain_max": float(hi),
                       "range_covered_fraction": float((X[:, i].max() - X[:, i].min()) / (hi - lo)) if hi > lo else 1.0}
    return {"fill_distance_max": float(d.max()), "fill_distance_p95": float(np.quantile(d, 0.95)),
            "min_pairwise_distance": float(nn.min()) if len(X) > 1 else None,
            "distinct_blends": int(len(X)), "per_component": per_comp,
            "note": "fill distance = largest Euclidean distance (fraction units) from any sampled domain point to its "
                    "nearest design blend; smaller is better"}


def generate_design(domain: ResearchDomain, spec: DesignSpec) -> Design:
    rng = np.random.default_rng(spec.seed)
    X, notes = _mixture_points(domain, spec, rng)
    limitations = list(notes)
    q = len(domain.components)
    p = scheffe_terms(q, spec.scheffe_order)
    if len(X) < p:
        limitations.append(f"only {len(X)} distinct blends; a Scheffé order-{spec.scheffe_order} model needs ≥ {p}")
    elif len(X) < p + 3:
        limitations.append(f"{len(X)} distinct blends vs {p} Scheffé terms: few degrees of freedom for lack-of-fit")

    mix = pd.DataFrame(X, columns=[f"mix:{c}" for c in domain.components])
    ranges = domain.effective_process_ranges()
    if spec.process_strategy == "none" or not ranges:
        runs = mix.copy()
    elif spec.process_strategy == "full_factorial":
        levels = spec.process_levels or {k: (r.lower, (r.lower + r.upper) / 2, r.upper) for k, r in ranges.items()}
        fac = full_factorial(levels)
        runs = mix.merge(fac, how="cross")
        limitations.append(f"crossed design: {len(mix)} blends × {len(fac)} process settings")
    else:
        proc = latin_hypercube({k: (r.lower, r.upper) for k, r in ranges.items()}, len(mix), spec.seed)
        runs = pd.concat([mix.reset_index(drop=True), proc], axis=1)
        limitations.append("process settings paired with blends by Latin hypercube (not crossed): mixture×process "
                           "interactions are only partially identifiable")
    runs["design_point"] = [f"DP{i + 1:03d}" for i in range(len(runs))]
    runs["role"] = "design"

    if spec.control:
        ctrl = {f"mix:{k}": v for k, v in spec.control.items()}
        cp = {f"proc:{k}": v for k, v in (spec.control_process or {}).items()}
        checks = check_candidate(domain, spec.control, spec.control_process or {})
        if not is_admissible(checks):
            raise ValueError("control sample is outside the research domain: " +
                             "; ".join(c.detail for c in checks if c.status == "fail"))
        ctrl_rows = pd.DataFrame([{**ctrl, **cp, "design_point": "CTRL", "role": "control"}] * spec.n_controls)
        runs = pd.concat([runs, ctrl_rows], ignore_index=True)

    reps = pd.concat([runs.assign(replicate=r + 1) for r in range(spec.replicates)], ignore_index=True)
    reps["replicate_group"] = reps["design_point"]
    # Blocking: replicates of a design point are spread across blocks; order randomised within block
    if spec.blocking_factor and spec.blocks:
        nb = len(spec.blocks)
        dp_codes = {dp: i for i, dp in enumerate(runs["design_point"].unique())}
        offset = rng.integers(nb, size=len(dp_codes))
        # replicates of the same design point rotate through blocks (no point confined to one block)
        reps["block"] = [spec.blocks[(offset[dp_codes[dp]] + r - 1) % nb]
                         for dp, r in zip(reps["design_point"], reps["replicate"])]
        reps["block_factor"] = spec.blocking_factor
        order = {b: i for i, b in enumerate(spec.blocks)}
        reps = reps.sample(frac=1.0, random_state=spec.seed)  # randomise within block
        reps = reps.assign(_b=reps["block"].map(order)).sort_values("_b", kind="stable").drop(columns="_b")
        reps = reps.reset_index(drop=True)
        if nb > 1 and spec.replicates < 2:
            limitations.append("single replicate per point: block effects are confounded with blend effects")
    else:
        reps = reps.sample(frac=1.0, random_state=spec.seed).reset_index(drop=True)
        reps["block"] = None
    reps["run_order"] = np.arange(1, len(reps) + 1)
    reps["run_id"] = [f"R{i:03d}" for i in reps["run_order"]]

    for _, row in reps.iterrows():
        comp = {c: row[f"mix:{c}"] for c in domain.components}
        proc = {k: row[f"proc:{k}"] for k in ranges if f"proc:{k}" in row}
        if not is_admissible(check_candidate(domain, comp, proc)):
            raise AssertionError(f"design generated an inadmissible run {row['run_id']}")

    coverage = _coverage(domain, X, rng)
    budget = {"runs": int(len(reps)), "distinct_blends": int(len(X)), "replicates": spec.replicates,
              "controls": int(spec.n_controls if spec.control else 0),
              "estimated_cost": (len(reps) * spec.cost_per_run) if spec.cost_per_run else None,
              "currency": spec.currency}
    limitations.append("design optimality is model-dependent (Scheffé order "
                       f"{spec.scheffe_order}); higher-order effects may be aliased")
    return Design(reps, coverage, limitations, budget, WHY_NOT_BOX_SAMPLING)
