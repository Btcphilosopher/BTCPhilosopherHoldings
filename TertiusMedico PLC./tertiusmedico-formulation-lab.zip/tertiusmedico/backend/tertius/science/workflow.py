"""Experiment and proposal state machines with role checks and separation of duties.

Experiment:  draft → scientific_review → approved_for_experiment → performed → data_reviewed → accepted | rejected

* Only ``draft`` plans are editable. Editing anything past ``draft`` requires a
  new revision (the previous revision stays, marked ``superseded``).
* A reviewer cannot approve their own submission or review their own data.
* ``performed`` records evidence of execution (operator, date, lots,
  equipment); it is separate from the approved plan.
"""

from __future__ import annotations

from dataclasses import dataclass

EXPERIMENT_STATES = ("draft", "scientific_review", "approved_for_experiment", "performed", "data_reviewed",
                     "accepted", "rejected", "superseded")

# (from, to) -> required project role
EXPERIMENT_TRANSITIONS = {
    ("draft", "scientific_review"): "researcher",
    ("scientific_review", "draft"): "reviewer",  # returned for changes
    ("scientific_review", "approved_for_experiment"): "reviewer",
    ("scientific_review", "rejected"): "reviewer",
    ("approved_for_experiment", "performed"): "researcher",
    ("performed", "data_reviewed"): "reviewer",
    ("data_reviewed", "accepted"): "reviewer",
    ("data_reviewed", "rejected"): "reviewer",
}

PROPOSAL_TRANSITIONS = {
    ("proposed", "accepted_for_planning"): "reviewer",
    ("proposed", "rejected"): "reviewer",
}

ROLE_RANK = {"researcher": 1, "reviewer": 2, "admin": 3}


class WorkflowError(ValueError):
    pass


class PermissionDenied(PermissionError):
    pass


def has_role(actual: str | None, required: str) -> bool:
    return actual is not None and ROLE_RANK.get(actual, 0) >= ROLE_RANK[required]


@dataclass
class TransitionRequest:
    current: str
    target: str
    actor: str
    actor_role: str | None
    author: str | None  # who submitted the plan / recorded the data
    reason: str | None = None
    evidence: dict | None = None


def check_transition(req: TransitionRequest, table=EXPERIMENT_TRANSITIONS) -> None:
    key = (req.current, req.target)
    if key not in table:
        raise WorkflowError(f"transition {req.current} → {req.target} is not allowed")
    need = table[key]
    if not has_role(req.actor_role, need):
        raise PermissionDenied(f"{req.current} → {req.target} requires role '{need}'")
    if need == "reviewer" and req.author is not None and req.actor == req.author:
        raise PermissionDenied("separation of duties: reviewers cannot review their own submission")
    if req.target == "rejected" and not req.reason:
        raise WorkflowError("rejection requires a documented reason")
    if req.target == "performed":
        ev = req.evidence or {}
        missing = [k for k in ("operator", "performed_on", "material_lots", "equipment") if not ev.get(k)]
        if missing:
            raise WorkflowError(f"recording performance requires evidence fields: {missing}")
    if req.target == "data_reviewed" and not (req.evidence or {}).get("measurement_count"):
        raise WorkflowError("data review requires recorded measurements")


def editable(state: str) -> bool:
    return state == "draft"
