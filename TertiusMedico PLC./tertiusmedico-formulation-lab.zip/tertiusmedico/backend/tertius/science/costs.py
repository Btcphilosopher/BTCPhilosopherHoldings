"""Scenario costing with explicit currencies, price dates and quantity units.

Rules: every price carries currency, date and per-unit; quantities are
dimension-checked against the price unit; mixing currencies requires an
explicit, dated exchange rate. Results are CALCULATED estimates.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Mapping, Sequence

from .units import DimensionError, Quantity


@dataclass(frozen=True)
class PriceRecord:
    item: str
    amount: Decimal
    currency: str
    per: str  # unit, e.g. "kg", "unit", "h", "run"
    price_date: str
    source: str


@dataclass(frozen=True)
class FXRate:
    from_currency: str
    to_currency: str
    rate: Decimal
    rate_date: str
    source: str


@dataclass(frozen=True)
class LineItem:
    category: str  # ingredient | packaging | waste | processing | experiment
    item: str
    quantity: Quantity
    price: PriceRecord


def _amount_in_price_unit(q: Quantity, per: str) -> Decimal:
    if per in ("run", "batch"):
        return Decimal(str(q.value))
    try:
        return Decimal(str(q.to(per).value))
    except DimensionError as e:
        raise DimensionError(f"quantity {q} cannot be priced per {per}: {e}") from e


def scenario_cost(items: Sequence[LineItem], currency: str, fx: Mapping[tuple[str, str], FXRate] | None = None) -> dict:
    fx = fx or {}
    lines, totals = [], {}
    for li in items:
        qty = _amount_in_price_unit(li.quantity, li.price.per)
        value = qty * li.price.amount
        conv = None
        if li.price.currency != currency:
            rate = fx.get((li.price.currency, currency))
            if rate is None:
                raise ValueError(f"{li.item}: price in {li.price.currency} but scenario in {currency} and no dated "
                                 "exchange rate supplied")
            value = value * rate.rate
            conv = {"rate": str(rate.rate), "rate_date": rate.rate_date, "source": rate.source}
        value = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
        totals[li.category] = totals.get(li.category, Decimal("0")) + value
        lines.append({"category": li.category, "item": li.item, "quantity": li.quantity.as_dict(),
                      "unit_price": str(li.price.amount), "price_currency": li.price.currency,
                      "price_per": li.price.per, "price_date": li.price.price_date, "price_source": li.price.source,
                      "fx": conv, "cost": str(value), "currency": currency})
    total = sum(totals.values(), Decimal("0"))
    return {"label": "CALCULATED", "currency": currency, "lines": lines,
            "by_category": {k: str(v) for k, v in totals.items()}, "total": str(total),
            "price_dates": sorted({l["price_date"] for l in lines})}
