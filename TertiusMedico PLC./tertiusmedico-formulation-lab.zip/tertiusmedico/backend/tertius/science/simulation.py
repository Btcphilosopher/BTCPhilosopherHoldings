"""Simplified, assumption-explicit process simulator: mixing → holding → transfer → filling.

SIMULATION OUTPUT IS NOT PROCESS VALIDATION. This is a Monte-Carlo model of a
few stylised mechanisms with every assumption listed in the output. It cannot
show that a process or a "digital twin" is suitable for manufacturing.

Mechanisms
----------
mixing     homogeneity CV(t) = CV₀ · exp(−t/τ),  τ = τ_ref · (N_ref / N)  (stirring speed N)
holding    evaporative mass loss at rate r_evap (fraction/h) ; first-order marker loss k_deg (1/h)
transfer   hold-up loss = fixed mass + fraction of transferred mass
filling    fill mass ~ Normal(target, σ_fill); containers outside ±tolerance are rejected (waste)
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np


@dataclass(frozen=True)
class Assumption:
    name: str
    value: float
    unit: str
    uncertainty_sd: float  # relative (lognormal sigma) unless unit says absolute
    basis: str


@dataclass
class SimulationConfig:
    batch_mass_g: float
    mix_speed_rpm: float
    mix_time_min: float
    hold_time_h: float
    fill_target_g: float
    fill_tolerance_g: float
    cv0_percent: Assumption = Assumption("initial heterogeneity CV₀", 25.0, "%", 0.2, "assumed; not measured")
    tau_ref_min: Assumption = Assumption("mixing time constant τ_ref at N_ref = 600 rpm", 6.0, "min", 0.3, "assumed")
    evap_rate: Assumption = Assumption("evaporative loss rate", 0.0015, "1/h", 0.3, "assumed for open vessel")
    k_deg: Assumption = Assumption("marker first-order loss", 0.0004, "1/h", 0.3, "assumed")
    holdup_fixed_g: Assumption = Assumption("transfer hold-up (fixed)", 12.0, "g", 0.2, "assumed line hold-up")
    holdup_fraction: Assumption = Assumption("transfer hold-up (proportional)", 0.01, "1", 0.3, "assumed")
    fill_sd_g: Assumption = Assumption("fill-weight SD", 0.25, "g", 0.2, "assumed filler capability")
    fill_rate_per_min: float = 20.0
    target_cv_percent: float = 2.0
    n_sims: int = 2000
    seed: int = 1


def _draw(a: Assumption, rng: np.random.Generator, n: int) -> np.ndarray:
    return a.value * rng.lognormal(0.0, a.uncertainty_sd, n)


def simulate_process(cfg: SimulationConfig) -> dict:
    rng = np.random.default_rng(cfg.seed)
    n = cfg.n_sims
    cv0, tau_ref = _draw(cfg.cv0_percent, rng, n), _draw(cfg.tau_ref_min, rng, n)
    tau = tau_ref * 600.0 / cfg.mix_speed_rpm
    cv_end = cv0 * np.exp(-cfg.mix_time_min / tau)
    t_to_target = tau * np.log(np.maximum(cv0 / cfg.target_cv_percent, 1.0))

    evap = _draw(cfg.evap_rate, rng, n)
    mass_after_hold = cfg.batch_mass_g * np.exp(-evap * cfg.hold_time_h)
    marker_retained = np.exp(-_draw(cfg.k_deg, rng, n) * cfg.hold_time_h)
    holdup = _draw(cfg.holdup_fixed_g, rng, n) + _draw(cfg.holdup_fraction, rng, n) * mass_after_hold
    to_filler = np.maximum(mass_after_hold - holdup, 0.0)

    fill_sd = _draw(cfg.fill_sd_g, rng, n)
    n_containers = np.floor(to_filler / cfg.fill_target_g).astype(int)
    # fraction of containers within tolerance under Normal(target, sd)
    from scipy.stats import norm
    p_ok = norm.cdf(cfg.fill_tolerance_g / fill_sd) - norm.cdf(-cfg.fill_tolerance_g / fill_sd)
    accepted = rng.binomial(n_containers, p_ok)
    rejected = n_containers - accepted
    remainder = to_filler - n_containers * cfg.fill_target_g
    good_mass = accepted * cfg.fill_target_g
    waste = cfg.batch_mass_g - mass_after_hold + holdup + rejected * cfg.fill_target_g + remainder
    # closure: evaporated + hold-up + rejected + remainder + accepted = batch (simulated, exact by construction)
    closure = (good_mass + waste) / cfg.batch_mass_g
    fill_time = n_containers / cfg.fill_rate_per_min
    total_time = cfg.mix_time_min + cfg.hold_time_h * 60 + fill_time

    def summ(x):
        return {"p05": float(np.percentile(x, 5)), "median": float(np.median(x)), "p95": float(np.percentile(x, 95))}

    flags = []
    if np.median(cv_end) > cfg.target_cv_percent:
        flags.append(f"median simulated homogeneity CV {np.median(cv_end):.2f}% exceeds target {cfg.target_cv_percent}%")
    return {
        "label": "SIMULATED — NOT PROCESS VALIDATION",
        "inputs": {k: v for k, v in asdict(cfg).items() if not isinstance(v, dict)},
        "assumptions": [asdict(a) for a in (cfg.cv0_percent, cfg.tau_ref_min, cfg.evap_rate, cfg.k_deg,
                                           cfg.holdup_fixed_g, cfg.holdup_fraction, cfg.fill_sd_g)],
        "outputs": {
            "homogeneity_cv_end_percent": summ(cv_end),
            "mixing_time_to_target_min": summ(t_to_target),
            "accepted_containers": summ(accepted), "rejected_containers": summ(rejected),
            "yield_fraction": summ(good_mass / cfg.batch_mass_g), "waste_g": summ(waste),
            "marker_retained_fraction": summ(marker_retained), "total_time_min": summ(total_time),
            "simulated_mass_closure": summ(closure),
        },
        "flags": flags,
        "limitations": [
            "single well-mixed-vessel idealisation; no spatial flow, shear or rheology coupling",
            "assumption values are illustrative defaults and must be replaced by measured process data",
            "no equipment qualification, cleaning, environmental or operator effects",
            "results describe the model, not the process; measured process validation is a separate record",
        ],
    }
