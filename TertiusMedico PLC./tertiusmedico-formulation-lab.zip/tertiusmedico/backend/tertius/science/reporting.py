"""Traceable research report rendering (JSON + self-contained HTML)."""

from __future__ import annotations

import hashlib
import html
import json
from datetime import datetime, timezone

STATUS_BANNER = ("RESEARCH REPORT — NON-CLINICAL. Contains measured results, calculated quantities and model "
                 "predictions, each labelled. Predictions and simulations are not experimental evidence. Nothing in "
                 "this report is an approved laboratory instruction, a manufacturing release, a shelf-life "
                 "assignment, or a treatment recommendation. Regulatory compliance is not claimed.")


def build_report(sections: dict, meta: dict) -> dict:
    body = {"meta": {**meta, "generated_at": datetime.now(timezone.utc).isoformat()}, "banner": STATUS_BANNER,
            **sections}
    digest = hashlib.sha256(json.dumps({k: v for k, v in body.items() if k != "meta"}, sort_keys=True,
                                       default=str).encode()).hexdigest()
    body["meta"]["content_sha256"] = digest
    return body


def _e(x) -> str:
    return html.escape(str(x))


def _table(rows: list[dict], cols: list[str] | None = None, max_rows: int = 200) -> str:
    if not rows:
        return "<p class='muted'>none</p>"
    cols = cols or list(rows[0].keys())
    head = "".join(f"<th>{_e(c)}</th>" for c in cols)
    body = []
    for r in rows[:max_rows]:
        cells = []
        for c in cols:
            v = r.get(c)
            if isinstance(v, float):
                v = f"{v:.4g}"
            elif isinstance(v, (dict, list)):
                v = json.dumps(v, default=str)[:300]
            cells.append(f"<td>{_e(v)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    more = f"<p class='muted'>… {len(rows) - max_rows} more rows in JSON</p>" if len(rows) > max_rows else ""
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>{more}"


def render_html(report: dict) -> str:
    css = """
    :root{--midnight:#0f1a3a;--teal:#0f8b8d;--violet:#6d4bd1;--amber:#b7791f;--ink:#1a2233;--line:#dde3ee}
    body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:var(--ink);margin:0;background:#fff}
    header{background:var(--midnight);color:#fff;padding:20px 28px} header h1{margin:0;font-size:20px}
    main{padding:20px 28px;max-width:1200px} h2{border-bottom:2px solid var(--line);padding-bottom:4px;margin-top:32px}
    .banner{border-left:4px solid var(--amber);background:#fff8eb;padding:10px 14px;margin:16px 0}
    table{border-collapse:collapse;font-size:12px;margin:8px 0;width:100%} th,td{border:1px solid var(--line);
    padding:4px 6px;text-align:left;vertical-align:top} th{background:#f3f5fa}
    .tag{display:inline-block;padding:1px 6px;border-radius:3px;font-size:11px;font-weight:600;color:#fff}
    .m{background:var(--teal)} .p{background:var(--violet)} .c{background:#4a5568} .w{background:var(--amber)}
    .muted{color:#667} code{font-size:11px}
    """
    r = report
    parts = [f"<header><h1>TERTIUSMEDICO — Formulation Lab · Research report</h1>"
             f"<div>{_e(r['meta'].get('project'))} · generated {_e(r['meta']['generated_at'])} · "
             f"content SHA-256 <code>{_e(r['meta']['content_sha256'])}</code></div></header><main>",
             f"<div class='banner'><strong>Status:</strong> {_e(r['banner'])}</div>",
             "<p><span class='tag m'>MEASURED</span> <span class='tag c'>CALCULATED</span> "
             "<span class='tag p'>PREDICTED</span> <span class='tag w'>WARNING</span></p>"]
    for key, sec in r.items():
        if key in ("meta", "banner"):
            continue
        parts.append(f"<h2>{_e(sec.get('title', key))}</h2>")
        if sec.get("label"):
            cls = {"MEASURED": "m", "PREDICTED": "p", "CALCULATED": "c", "SIMULATED": "w"}.get(
                sec["label"].split()[0], "c")
            parts.append(f"<span class='tag {cls}'>{_e(sec['label'])}</span>")
        for t in sec.get("text", []):
            parts.append(f"<p>{_e(t)}</p>")
        for w in sec.get("warnings", []):
            parts.append(f"<p><span class='tag w'>WARNING</span> {_e(w)}</p>")
        for tbl in sec.get("tables", []):
            parts.append(f"<h3>{_e(tbl.get('caption', ''))}</h3>")
            parts.append(_table(tbl["rows"], tbl.get("columns")))
    parts.append("</main>")
    return f"<!doctype html><html><head><meta charset='utf-8'><title>Research report</title><style>{css}</style>" \
           f"</head><body>{''.join(parts)}</body></html>"
