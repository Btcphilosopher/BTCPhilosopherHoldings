"""Dimensional analysis for formulation quantities.

Design rules
------------
* Every physical quantity carries a unit; arithmetic across incompatible
  dimensions raises :class:`DimensionError`.
* Mass and volume are *different dimensions*. Converting between them needs an
  explicit density quantity (:func:`mass_to_volume`, :func:`volume_to_mass`).
  There is no default density.
* Amount of substance (mol) and mass are different dimensions; conversion
  requires an explicit molar mass.
* "Dosage unit" (``unit``/``tablet``/``capsule``) is modelled as its own base
  dimension ``U`` so that "mg per tablet" can never be silently compared with
  "mg per mL".
* Fractions (mass fraction, volume fraction) are dimensionless, but their
  *basis* is tracked separately in :mod:`tertius.science.composition`; a mass
  fraction is never added to a volume fraction.
* Celsius is an affine scale. It may be converted to/from kelvin for absolute
  temperatures but never multiplied or divided.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Mapping

# Base dimensions: M mass, L length, N amount, T time, K temperature, U dosage unit, C currency-free count
BASE = ("M", "L", "N", "T", "K", "U")


class DimensionError(ValueError):
    """Raised when quantities with incompatible dimensions are combined."""


class UnitParseError(ValueError):
    pass


@dataclass(frozen=True)
class Dim:
    exps: tuple[int, ...] = (0, 0, 0, 0, 0, 0)

    def __mul__(self, other: "Dim") -> "Dim":
        return Dim(tuple(a + b for a, b in zip(self.exps, other.exps)))

    def __truediv__(self, other: "Dim") -> "Dim":
        return Dim(tuple(a - b for a, b in zip(self.exps, other.exps)))

    def __pow__(self, p: int) -> "Dim":
        return Dim(tuple(a * p for a in self.exps))

    @property
    def dimensionless(self) -> bool:
        return all(e == 0 for e in self.exps)

    def __str__(self) -> str:
        parts = [f"{b}^{e}" if e != 1 else b for b, e in zip(BASE, self.exps) if e]
        return "·".join(parts) or "1"


def _d(**kw: int) -> Dim:
    return Dim(tuple(kw.get(b, 0) for b in BASE))


MASS = _d(M=1)
LENGTH = _d(L=1)
VOLUME = _d(L=3)
AMOUNT = _d(N=1)
TIME = _d(T=1)
TEMPERATURE = _d(K=1)
DOSAGE_UNIT = _d(U=1)
DIMENSIONLESS = Dim()
DENSITY = MASS / VOLUME
MASS_CONCENTRATION = MASS / VOLUME
MOLAR_CONCENTRATION = AMOUNT / VOLUME
MOLAR_MASS = MASS / AMOUNT
MASS_PER_DOSAGE_UNIT = MASS / DOSAGE_UNIT
VISCOSITY = MASS / (LENGTH * TIME)  # Pa·s = kg m^-1 s^-1
PRESSURE = MASS / (LENGTH * TIME**2)
FORCE = MASS * LENGTH / TIME**2
FREQUENCY = DIMENSIONLESS / TIME

# unit symbol -> (scale to SI-coherent base [kg, m, mol, s, K, unit], dimension)
_UNITS: dict[str, tuple[float, Dim]] = {
    # mass
    "kg": (1.0, MASS), "g": (1e-3, MASS), "mg": (1e-6, MASS), "ug": (1e-9, MASS), "µg": (1e-9, MASS),
    # length / volume
    "m": (1.0, LENGTH), "cm": (1e-2, LENGTH), "mm": (1e-3, LENGTH), "um": (1e-6, LENGTH), "µm": (1e-6, LENGTH),
    "nm": (1e-9, LENGTH),
    "L": (1e-3, VOLUME), "mL": (1e-6, VOLUME), "uL": (1e-9, VOLUME), "µL": (1e-9, VOLUME), "m3": (1.0, VOLUME),
    "cm3": (1e-6, VOLUME),
    # amount
    "mol": (1.0, AMOUNT), "mmol": (1e-3, AMOUNT), "umol": (1e-6, AMOUNT), "µmol": (1e-6, AMOUNT),
    "M": (1e3, MOLAR_CONCENTRATION), "mM": (1.0, MOLAR_CONCENTRATION),  # mol/L
    # time
    "s": (1.0, TIME), "min": (60.0, TIME), "h": (3600.0, TIME), "day": (86400.0, TIME), "week": (604800.0, TIME),
    "month": (2629800.0, TIME),  # 30.4375 d: used only for stability time-point labels
    # temperature (absolute)
    "K": (1.0, TEMPERATURE),
    # dosage unit
    "unit": (1.0, DOSAGE_UNIT), "tablet": (1.0, DOSAGE_UNIT), "capsule": (1.0, DOSAGE_UNIT),
    "vial": (1.0, DOSAGE_UNIT), "container": (1.0, DOSAGE_UNIT),
    # derived
    "Pa": (1.0, PRESSURE), "kPa": (1e3, PRESSURE), "MPa": (1e6, PRESSURE), "bar": (1e5, PRESSURE),
    "N": (1.0, FORCE), "kN": (1e3, FORCE),
    "rpm": (1.0 / 60.0, FREQUENCY), "Hz": (1.0, FREQUENCY),
    # dimensionless
    "1": (1.0, DIMENSIONLESS), "fraction": (1.0, DIMENSIONLESS), "%": (1e-2, DIMENSIONLESS),
    "ppm": (1e-6, DIMENSIONLESS),
}
_ALIASES = {"mPa.s": "mPa*s", "mPa·s": "mPa*s", "cP": "mPa*s", "Pa.s": "Pa*s", "Pa·s": "Pa*s",
            "w/w": "fraction", "v/v": "fraction", "%w/w": "%", "%v/v": "%", "degC": "°C", "C": "°C"}
_PREFIXED = {"mPa": (1e-3, PRESSURE)}
_UNITS.update(_PREFIXED)

_TOKEN = re.compile(r"^([^\^]+)(?:\^(-?\d+))?$")


def parse_unit(unit: str) -> tuple[float, Dim]:
    """Parse a unit expression such as ``mg/mL``, ``mPa*s``, ``mol/L`` or ``kg*m^-3``."""
    if unit is None:
        raise UnitParseError("unit is required")
    u = unit.strip()
    u = _ALIASES.get(u, u)
    if u == "°C":
        raise UnitParseError("°C is an affine scale: use Temperature helpers, not multiplicative units")
    scale, dim = 1.0, DIMENSIONLESS
    # split on / keeping first numerator
    num, *dens = u.split("/")
    for part, sign in [(num, 1)] + [(d, -1) for d in dens]:
        for tok in part.split("*"):
            tok = tok.strip()
            if not tok:
                raise UnitParseError(f"empty token in unit {unit!r}")
            m = _TOKEN.match(tok)
            if not m:
                raise UnitParseError(f"cannot parse unit token {tok!r}")
            sym, p = m.group(1), int(m.group(2) or 1)
            sym = _ALIASES.get(sym, sym)
            if sym not in _UNITS:
                raise UnitParseError(f"unknown unit {sym!r} in {unit!r}")
            s, d = _UNITS[sym]
            scale *= s ** (p * sign)
            dim = dim * (d ** (p * sign))
    return scale, dim


def dimension_of(unit: str) -> Dim:
    return parse_unit(unit)[1]


@dataclass(frozen=True)
class Quantity:
    value: float
    unit: str

    def __post_init__(self) -> None:
        if self.value is None or (isinstance(self.value, float) and math.isnan(self.value)):
            raise ValueError("Quantity value must be a number; represent unknown values as None at the field level")
        parse_unit(self.unit)

    @property
    def dim(self) -> Dim:
        return dimension_of(self.unit)

    @property
    def si(self) -> float:
        s, _ = parse_unit(self.unit)
        return self.value * s

    def to(self, unit: str) -> "Quantity":
        s_from, d_from = parse_unit(self.unit)
        s_to, d_to = parse_unit(unit)
        if d_from != d_to:
            raise DimensionError(f"cannot convert {self.unit} [{d_from}] to {unit} [{d_to}]")
        return Quantity(self.value * s_from / s_to, unit)

    def _same(self, other: "Quantity") -> "Quantity":
        if self.dim != other.dim:
            raise DimensionError(f"incompatible dimensions: {self.unit} [{self.dim}] vs {other.unit} [{other.dim}]")
        return other.to(self.unit)

    def __add__(self, other: "Quantity") -> "Quantity":
        o = self._same(other)
        return Quantity(self.value + o.value, self.unit)

    def __sub__(self, other: "Quantity") -> "Quantity":
        o = self._same(other)
        return Quantity(self.value - o.value, self.unit)

    def __mul__(self, k: float) -> "Quantity":
        if isinstance(k, Quantity):
            raise TypeError("use multiply() for quantity × quantity to make the resulting unit explicit")
        return Quantity(self.value * k, self.unit)

    __rmul__ = __mul__

    def ratio(self, other: "Quantity") -> float:
        """Dimensionless ratio of two same-dimension quantities."""
        o = self._same(other)
        return self.si / o.si if o.si else math.inf

    def compatible(self, dim: Dim) -> bool:
        return self.dim == dim

    def as_dict(self) -> dict:
        return {"value": self.value, "unit": self.unit}

    @classmethod
    def from_dict(cls, d: Mapping) -> "Quantity":
        return cls(float(d["value"]), str(d["unit"]))

    def __str__(self) -> str:
        return f"{self.value:g} {self.unit}"


def multiply(a: Quantity, b: Quantity, result_unit: str) -> Quantity:
    """Multiply two quantities and express the result in ``result_unit`` (dimension-checked)."""
    s_res, d_res = parse_unit(result_unit)
    if a.dim * b.dim != d_res:
        raise DimensionError(f"{a.unit} × {b.unit} is [{a.dim * b.dim}], not {result_unit} [{d_res}]")
    return Quantity(a.si * b.si / s_res, result_unit)


def divide(a: Quantity, b: Quantity, result_unit: str) -> Quantity:
    s_res, d_res = parse_unit(result_unit)
    if a.dim / b.dim != d_res:
        raise DimensionError(f"{a.unit} ÷ {b.unit} is [{a.dim / b.dim}], not {result_unit} [{d_res}]")
    if b.si == 0:
        raise ZeroDivisionError("division by zero quantity")
    return Quantity(a.si / b.si / s_res, result_unit)


def require_dim(q: Quantity, dim: Dim, what: str) -> None:
    if q.dim != dim:
        raise DimensionError(f"{what} must have dimension [{dim}], got {q.unit} [{q.dim}]")


def mass_to_volume(mass: Quantity, density: Quantity | None, unit: str = "mL") -> Quantity:
    """Convert mass to volume. A measured or specified density is mandatory."""
    if density is None:
        raise DimensionError("mass→volume conversion requires a density; none is recorded (no default is assumed)")
    require_dim(mass, MASS, "mass")
    require_dim(density, DENSITY, "density")
    return divide(mass, density, unit)


def volume_to_mass(volume: Quantity, density: Quantity | None, unit: str = "g") -> Quantity:
    if density is None:
        raise DimensionError("volume→mass conversion requires a density; none is recorded (no default is assumed)")
    require_dim(volume, VOLUME, "volume")
    require_dim(density, DENSITY, "density")
    return multiply(volume, density, unit)


def amount_to_mass(amount: Quantity, molar_mass: Quantity | None, unit: str = "g") -> Quantity:
    if molar_mass is None:
        raise DimensionError("amount→mass conversion requires a molar mass; none is recorded")
    require_dim(amount, AMOUNT, "amount of substance")
    require_dim(molar_mass, MOLAR_MASS, "molar mass")
    return multiply(amount, molar_mass, unit)


@dataclass(frozen=True)
class Temperature:
    """Absolute temperature. Celsius input is converted on construction."""

    kelvin: float

    @classmethod
    def celsius(cls, c: float) -> "Temperature":
        k = c + 273.15
        if k < 0:
            raise ValueError("temperature below absolute zero")
        return cls(k)

    @property
    def degc(self) -> float:
        return self.kelvin - 273.15


def to_si_value(value: float, unit: str, expected: Dim | None = None) -> float:
    s, d = parse_unit(unit)
    if expected is not None and d != expected:
        raise DimensionError(f"expected [{expected}], got {unit} [{d}]")
    return value * s
