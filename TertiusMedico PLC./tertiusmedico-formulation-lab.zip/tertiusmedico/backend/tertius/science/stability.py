"""Stability trend analysis with bounded forecasting.

* Trends are fitted per (formulation revision, packaging, storage condition,
  analytical method, material lot) so that none of these factors is silently
  pooled.
* Censored results (below LOD) are excluded from the regression and listed.
* Forecasts are bounded to ``max_extrapolation_factor`` × the longest observed
  time point (default 1.5×); requests beyond that are refused.
* A limit-crossing estimate (one-sided 95 % confidence bound of the mean, in the
  style of regression-based stability evaluation) is reported as EXPLORATORY.
  It is not a shelf-life assignment: shelf life requires a governed stability
  protocol, long-term data at the intended storage condition, the applicable
  regulatory guidance, and quality-unit approval. Accelerated data alone never
  establish shelf life.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy import stats

GROUP_KEYS = ("formulation_id", "formulation_revision", "packaging", "condition", "method", "lot")
NOT_SHELF_LIFE = ("EXPLORATORY ESTIMATE — NOT A SHELF-LIFE ASSIGNMENT. Regression or accelerated data alone do not "
                  "establish shelf life; that requires a governed stability protocol, long-term data, applicable "
                  "guidance and quality approval.")


@dataclass
class Trend:
    key: dict
    attribute: str
    unit: str
    n: int
    times: np.ndarray
    values: np.ndarray
    slope: float
    intercept: float
    se_slope: float
    resid_sd: float
    r2: float
    max_time: float
    excluded: list

    def _se_mean(self, t: np.ndarray) -> np.ndarray:
        tb = self.times.mean()
        sxx = np.sum((self.times - tb) ** 2)
        return self.resid_sd * np.sqrt(1 / self.n + (t - tb) ** 2 / sxx)

    def predict(self, t, level: float = 0.95, max_extrapolation_factor: float = 1.5) -> dict:
        t = np.atleast_1d(np.asarray(t, float))
        limit = self.max_time * max_extrapolation_factor
        if np.any(t > limit + 1e-9):
            raise ValueError(f"forecast to {t.max():g} months refused: bounded to {max_extrapolation_factor}× the longest "
                             f"observed time point ({self.max_time:g} months → {limit:g})")
        m = self.intercept + self.slope * t
        dof = self.n - 2
        tq = stats.t.ppf(0.5 + level / 2, dof)
        se = self._se_mean(t)
        sp = np.sqrt(self.resid_sd ** 2 + se ** 2)
        return {"time": t.tolist(), "mean": m.tolist(), "ci_lower": (m - tq * se).tolist(),
                "ci_upper": (m + tq * se).tolist(), "pi_lower": (m - tq * sp).tolist(),
                "pi_upper": (m + tq * sp).tolist(), "level": level,
                "extrapolated": (t > self.max_time).tolist(), "label": "PREDICTED (trend model)"}

    def exploratory_crossing(self, limit: float, side: str = "lower", max_extrapolation_factor: float = 1.5) -> dict:
        grid = np.linspace(0, self.max_time * max_extrapolation_factor, 400)
        dof = self.n - 2
        tq = stats.t.ppf(0.95, dof)  # one-sided 95 %
        m = self.intercept + self.slope * grid
        se = self._se_mean(grid)
        bound = m - tq * se if side == "lower" else m + tq * se
        crossed = bound < limit if side == "lower" else bound > limit
        if not crossed.any():
            return {"crossing_time": None, "within_bounded_range": True,
                    "message": f"one-sided 95% bound does not cross {limit:g} within the bounded range "
                               f"(≤ {grid[-1]:g} months)", "label": NOT_SHELF_LIFE}
        tc = float(grid[np.argmax(crossed)])
        return {"crossing_time": tc, "extrapolated": tc > self.max_time, "label": NOT_SHELF_LIFE,
                "message": f"one-sided 95% confidence bound of the mean crosses {limit:g} at ≈{tc:.2f} months"}

    def as_dict(self) -> dict:
        return {"key": self.key, "attribute": self.attribute, "unit": self.unit, "n": self.n,
                "slope_per_month": self.slope, "intercept": self.intercept, "se_slope": self.se_slope,
                "resid_sd": self.resid_sd, "r2": self.r2, "max_time_months": self.max_time,
                "excluded": self.excluded, "observations": [{"time": float(a), "value": float(b), "label": "MEASURED"}
                                                            for a, b in zip(self.times, self.values)]}


def fit_trends(df: pd.DataFrame, attribute: str) -> list[Trend]:
    d = df[df["attribute"] == attribute]
    out = []
    keys = [k for k in GROUP_KEYS if k in d.columns]
    for key, g in d.groupby(keys):
        excluded = g[g["status"] != "ok"]["stab_id"].tolist()
        ok = g[g["status"] == "ok"]
        if len(ok) < 3 or ok["time_months"].nunique() < 3:
            continue
        t = ok["time_months"].to_numpy(float); y = ok["value"].to_numpy(float)
        res = stats.linregress(t, y)
        resid = y - (res.intercept + res.slope * t)
        sd = float(np.sqrt(np.sum(resid ** 2) / (len(t) - 2))) if len(t) > 2 else float("nan")
        out.append(Trend(dict(zip(keys, key if isinstance(key, tuple) else (key,))), attribute, str(ok["unit"].iloc[0]),
                         len(t), t, y, float(res.slope), float(res.intercept), float(res.stderr), sd,
                         float(res.rvalue ** 2), float(t.max()), excluded))
    return out


def slope_poolability(df: pd.DataFrame, attribute: str, by: str = "lot", fixed: dict | None = None) -> dict:
    """ANCOVA test of equal slopes across levels of ``by`` (diagnostic; 0.25 significance level by convention)."""
    d = df[(df["attribute"] == attribute) & (df["status"] == "ok")]
    for k, v in (fixed or {}).items():
        d = d[d[k] == v]
    levels = sorted(d[by].unique())
    if len(levels) < 2:
        return {"testable": False, "reason": f"only one level of {by}"}
    # full model: separate intercept and slope per level; reduced: separate intercepts, common slope
    y = d["value"].to_numpy(float); t = d["time_months"].to_numpy(float)
    L = np.column_stack([(d[by] == l).to_numpy(float) for l in levels])
    X_full = np.hstack([L, L * t[:, None]])
    X_red = np.hstack([L, t[:, None]])
    rss = lambda X: float(np.sum((y - X @ np.linalg.lstsq(X, y, rcond=None)[0]) ** 2))  # noqa: E731
    rf, rr = rss(X_full), rss(X_red)
    df1, df2 = len(levels) - 1, len(y) - X_full.shape[1]
    F = ((rr - rf) / df1) / (rf / df2)
    p = float(1 - stats.f.cdf(F, df1, df2))
    return {"testable": True, "F": float(F), "p_value": p, "levels": levels, "alpha": 0.25,
            "slopes_poolable": p > 0.25, "label": "DIAGNOSTIC",
            "note": "equal-slope test across " + by + "; pooling decisions belong to the stability protocol"}
