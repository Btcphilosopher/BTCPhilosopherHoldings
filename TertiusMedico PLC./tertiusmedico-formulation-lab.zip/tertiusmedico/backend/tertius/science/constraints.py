"""Research-domain constraints, feasibility analysis and candidate checking.

A :class:`ResearchDomain` is the *explicitly configured* region in which designs
and optimisers may generate candidates. Hard constraints (bounds, exclusions,
group limits, reviewed incompatibilities, process ranges, cost limits) can never
be traded against a predicted score.

Feasibility is decided with a linear program (``scipy.optimize.linprog``,
HiGHS). When the domain is infeasible, an *irreducible infeasible subset* (IIS)
is computed with the deletion filter (Chinneck & Dravnieks 1991): every
constraint in the reported subset is necessary for the conflict, so the
explanation points at the real cause instead of listing everything.

Known incompatibilities are disjunctive ("not both present") and are handled
by branch enumeration. Unknown compatibility is **unknown** — it is never
treated as compatible; the configured policy decides whether it blocks or is
flagged for reviewer attention.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping

import numpy as np
from scipy.optimize import linprog

PRESENCE_THRESHOLD = 1e-9


@dataclass(frozen=True)
class LinearConstraint:
    name: str
    coeffs: Mapping[str, float]
    sense: str  # "<=", ">=", "="
    rhs: float
    kind: str
    source: str | None = None

    def evaluate(self, x: Mapping[str, float]) -> tuple[float, bool]:
        lhs = sum(c * x.get(k, 0.0) for k, c in self.coeffs.items())
        tol = 1e-7
        ok = {"<=": lhs <= self.rhs + tol, ">=": lhs >= self.rhs - tol, "=": abs(lhs - self.rhs) <= 1e-6}[self.sense]
        return lhs, ok

    def describe(self) -> str:
        terms = " + ".join(f"{c:g}·{k}" if c != 1 else k for k, c in self.coeffs.items())
        return f"{terms} {self.sense} {self.rhs:g}"


@dataclass(frozen=True)
class GroupLimit:
    name: str
    members: tuple[str, ...]
    lower: float = 0.0
    upper: float = 1.0


@dataclass(frozen=True)
class RatioLimit:
    """numerator ≤ max_ratio × denominator (linear)."""
    numerator: str
    denominator: str
    max_ratio: float


@dataclass(frozen=True)
class ProcessRange:
    name: str
    lower: float
    upper: float
    unit: str
    source: str = "permitted process range"


@dataclass(frozen=True)
class EquipmentLimit:
    equipment_id: str
    parameter: str
    lower: float | None
    upper: float | None
    unit: str


@dataclass(frozen=True)
class CompatibilityRecord:
    a: str
    b: str
    status: str  # "incompatible" | "compatible" | "unknown"
    source: str | None = None
    reviewed: bool = False

    def key(self) -> frozenset:
        return frozenset((self.a, self.b))


@dataclass(frozen=True)
class Price:
    component: str
    amount: float
    currency: str
    per_unit: str  # e.g. "kg"
    price_date: str


@dataclass(frozen=True)
class CostLimit:
    max_cost: float
    currency: str
    per_unit: str = "kg"  # cost per kg of formulation


@dataclass(frozen=True)
class InformationRequirement:
    description: str
    satisfied: bool
    blocks: str  # what it blocks


@dataclass
class ResearchDomain:
    name: str
    components: tuple[str, ...]
    bounds: Mapping[str, tuple[float, float]]
    total: float = 1.0
    excluded: frozenset[str] = frozenset()
    required: frozenset[str] = frozenset()
    min_inclusion: float = 0.001
    groups: tuple[GroupLimit, ...] = ()
    ratios: tuple[RatioLimit, ...] = ()
    process: Mapping[str, ProcessRange] = field(default_factory=dict)
    equipment: tuple[EquipmentLimit, ...] = ()
    compatibility: tuple[CompatibilityRecord, ...] = ()
    unknown_compatibility_policy: str = "block"  # "block" | "flag"
    prices: Mapping[str, Price] = field(default_factory=dict)
    cost_limit: CostLimit | None = None
    information: tuple[InformationRequirement, ...] = ()
    version: int = 1

    # ---------- constraint assembly ----------
    def linear_constraints(self) -> list[LinearConstraint]:
        cons: list[LinearConstraint] = [
            LinearConstraint("composition_total", {c: 1.0 for c in self.components}, "=", self.total, "total")
        ]
        for c in self.components:
            lo, hi = self.bounds.get(c, (0.0, self.total))
            if c in self.excluded:
                cons.append(LinearConstraint(f"exclude[{c}]", {c: 1.0}, "<=", 0.0, "exclusion"))
            if c in self.required:
                cons.append(LinearConstraint(f"include[{c}]", {c: 1.0}, ">=", max(lo, self.min_inclusion), "inclusion"))
            cons.append(LinearConstraint(f"lower[{c}]", {c: 1.0}, ">=", lo, "bound"))
            cons.append(LinearConstraint(f"upper[{c}]", {c: 1.0}, "<=", hi, "bound"))
        for g in self.groups:
            cons.append(LinearConstraint(f"group_lower[{g.name}]", {m: 1.0 for m in g.members}, ">=", g.lower, "group"))
            cons.append(LinearConstraint(f"group_upper[{g.name}]", {m: 1.0 for m in g.members}, "<=", g.upper, "group"))
        for r in self.ratios:
            cons.append(LinearConstraint(f"ratio[{r.numerator}/{r.denominator}]",
                                         {r.numerator: 1.0, r.denominator: -r.max_ratio}, "<=", 0.0, "ratio"))
        if self.cost_limit is not None and self._prices_complete():
            coeffs = {c: self.prices[c].amount for c in self.components}
            cons.append(LinearConstraint("cost_limit", coeffs, "<=", self.cost_limit.max_cost, "cost",
                                         f"{self.cost_limit.currency}/{self.cost_limit.per_unit}"))
        return cons

    def _prices_complete(self) -> bool:
        return all(c in self.prices for c in self.components if c not in self.excluded)

    def incompatible_pairs(self) -> list[CompatibilityRecord]:
        return [r for r in self.compatibility if r.status == "incompatible"]

    def compatibility_status(self, a: str, b: str) -> CompatibilityRecord | None:
        k = frozenset((a, b))
        for r in self.compatibility:
            if r.key() == k:
                return r
        return None

    def effective_process_ranges(self) -> dict[str, ProcessRange]:
        """Intersect permitted process ranges with equipment limits."""
        out = dict(self.process)
        for e in self.equipment:
            if e.parameter in out:
                p = out[e.parameter]
                if p.unit != e.unit:
                    raise ValueError(f"equipment limit unit {e.unit} != process range unit {p.unit} for {e.parameter}")
                lo = max(p.lower, e.lower) if e.lower is not None else p.lower
                hi = min(p.upper, e.upper) if e.upper is not None else p.upper
                out[e.parameter] = ProcessRange(p.name, lo, hi, p.unit, f"{p.source} ∩ equipment {e.equipment_id}")
        return out

    def missing_information(self) -> list[str]:
        msgs = [f"{r.description} (blocks: {r.blocks})" for r in self.information if not r.satisfied]
        if self.cost_limit is not None:
            missing = [c for c in self.components if c not in self.excluded and c not in self.prices]
            if missing:
                msgs.append(f"cost limit configured but no dated price for: {', '.join(missing)} (blocks: cost constraint)")
            cur = {p.currency for p in self.prices.values()}
            if len(cur) > 1:
                msgs.append(f"prices in multiple currencies {sorted(cur)} without a dated exchange rate (blocks: cost constraint)")
            if any(p.currency != self.cost_limit.currency for p in self.prices.values()):
                msgs.append("price currency differs from cost-limit currency (blocks: cost constraint)")
        return msgs

    def to_dict(self) -> dict:
        return {
            "name": self.name, "version": self.version, "components": list(self.components),
            "bounds": {k: list(v) for k, v in self.bounds.items()}, "total": self.total,
            "excluded": sorted(self.excluded), "required": sorted(self.required), "min_inclusion": self.min_inclusion,
            "groups": [g.__dict__ | {"members": list(g.members)} for g in self.groups],
            "ratios": [r.__dict__ for r in self.ratios],
            "process": {k: v.__dict__ for k, v in self.process.items()},
            "equipment": [e.__dict__ for e in self.equipment],
            "compatibility": [r.__dict__ for r in self.compatibility],
            "unknown_compatibility_policy": self.unknown_compatibility_policy,
            "prices": {k: v.__dict__ for k, v in self.prices.items()},
            "cost_limit": self.cost_limit.__dict__ if self.cost_limit else None,
            "information": [i.__dict__ for i in self.information],
        }

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> "ResearchDomain":
        return cls(
            name=d["name"], version=int(d.get("version", 1)), components=tuple(d["components"]),
            bounds={k: (float(v[0]), float(v[1])) for k, v in d["bounds"].items()}, total=float(d.get("total", 1.0)),
            excluded=frozenset(d.get("excluded", [])), required=frozenset(d.get("required", [])),
            min_inclusion=float(d.get("min_inclusion", 0.001)),
            groups=tuple(GroupLimit(g["name"], tuple(g["members"]), g.get("lower", 0.0), g.get("upper", 1.0))
                         for g in d.get("groups", [])),
            ratios=tuple(RatioLimit(**r) for r in d.get("ratios", [])),
            process={k: ProcessRange(**v) for k, v in d.get("process", {}).items()},
            equipment=tuple(EquipmentLimit(**e) for e in d.get("equipment", [])),
            compatibility=tuple(CompatibilityRecord(**r) for r in d.get("compatibility", [])),
            unknown_compatibility_policy=d.get("unknown_compatibility_policy", "block"),
            prices={k: Price(**v) for k, v in d.get("prices", {}).items()},
            cost_limit=CostLimit(**d["cost_limit"]) if d.get("cost_limit") else None,
            information=tuple(InformationRequirement(**i) for i in d.get("information", [])),
        )


# --------------------------------------------------------------------------------------
# LP feasibility
# --------------------------------------------------------------------------------------
def _lp(components: tuple[str, ...], cons: list[LinearConstraint], objective: np.ndarray | None = None,
        zero: Iterable[str] = ()):
    idx = {c: i for i, c in enumerate(components)}
    n = len(components)
    A_ub, b_ub, A_eq, b_eq = [], [], [], []
    for c in cons:
        row = np.zeros(n)
        for k, v in c.coeffs.items():
            if k not in idx:
                raise ValueError(f"constraint {c.name} references unknown component {k}")
            row[idx[k]] = v
        if c.sense == "<=":
            A_ub.append(row); b_ub.append(c.rhs)
        elif c.sense == ">=":
            A_ub.append(-row); b_ub.append(-c.rhs)
        else:
            A_eq.append(row); b_eq.append(c.rhs)
    for z in zero:
        row = np.zeros(n); row[idx[z]] = 1.0
        A_eq.append(row); b_eq.append(0.0)
    res = linprog(
        c=objective if objective is not None else np.zeros(n),
        A_ub=np.array(A_ub) if A_ub else None, b_ub=np.array(b_ub) if b_ub else None,
        A_eq=np.array(A_eq) if A_eq else None, b_eq=np.array(b_eq) if b_eq else None,
        bounds=[(None, None)] * n, method="highs",
    )
    return res


def _feasible(components, cons, zero=()) -> bool:
    return _lp(components, cons, zero=zero).status == 0


def irreducible_infeasible_subset(components, cons: list[LinearConstraint], zero=()) -> list[LinearConstraint]:
    """Deletion filter: returns a minimal subset of constraints that is still infeasible."""
    working = list(cons)
    i = 0
    while i < len(working):
        trial = working[:i] + working[i + 1:]
        if not _feasible(components, trial, zero):
            working = trial
        else:
            i += 1
    return working


def _branches(domain: ResearchDomain) -> list[tuple[str, ...]]:
    """Each branch fixes one member of every reviewed-incompatible pair to zero."""
    pairs = [(r.a, r.b) for r in domain.incompatible_pairs()]
    if not pairs:
        return [()]
    out = set()
    for choice in itertools.product(*pairs):
        out.add(tuple(sorted(set(choice))))
    return sorted(out)


@dataclass
class FeasibilityReport:
    feasible: bool
    blocked: bool
    explanations: list[str]
    conflicting_constraints: list[dict]
    feasible_ranges: dict[str, tuple[float, float]]
    process_ranges: dict[str, dict]
    missing_information: list[str]
    warnings: list[str]

    def as_dict(self) -> dict:
        return {
            "feasible": self.feasible, "blocked": self.blocked, "explanations": self.explanations,
            "conflicting_constraints": self.conflicting_constraints,
            "feasible_ranges": {k: list(v) for k, v in self.feasible_ranges.items()},
            "process_ranges": self.process_ranges, "missing_information": self.missing_information,
            "warnings": self.warnings,
        }


def _quick_diagnostics(domain: ResearchDomain) -> list[str]:
    msgs = []
    lo_sum = sum(domain.bounds.get(c, (0, 1))[0] for c in domain.components)
    hi_sum = sum(0 if c in domain.excluded else domain.bounds.get(c, (0, 1))[1] for c in domain.components)
    if lo_sum > domain.total + 1e-12:
        msgs.append(f"sum of lower bounds {lo_sum:.4f} exceeds composition total {domain.total:g}")
    if hi_sum < domain.total - 1e-12:
        msgs.append(f"sum of available upper bounds {hi_sum:.4f} is below composition total {domain.total:g}")
    for c in domain.components:
        lo, hi = domain.bounds.get(c, (0, 1))
        if lo > hi:
            msgs.append(f"{c}: lower bound {lo:g} > upper bound {hi:g}")
        if c in domain.excluded and lo > 0:
            msgs.append(f"{c} is excluded but has lower bound {lo:g} > 0")
        if c in domain.excluded and c in domain.required:
            msgs.append(f"{c} is both required and excluded")
    for g in domain.groups:
        cap = sum(domain.bounds.get(m, (0, 1))[1] for m in g.members if m not in domain.excluded)
        if g.lower > cap + 1e-12:
            msgs.append(f"group {g.name}: lower limit {g.lower:g} exceeds members' combined upper bounds {cap:g}")
    for r in domain.incompatible_pairs():
        if domain.bounds.get(r.a, (0, 1))[0] > 0 and domain.bounds.get(r.b, (0, 1))[0] > 0:
            msgs.append(f"{r.a} and {r.b} are a reviewed incompatible pair but both have positive lower bounds")
    for k, p in domain.effective_process_ranges().items():
        if p.lower > p.upper:
            msgs.append(f"process {k}: permitted range ∩ equipment limits is empty ({p.lower:g} > {p.upper:g} {p.unit})")
    return msgs


def analyse_feasibility(domain: ResearchDomain) -> FeasibilityReport:
    """Explain whether a domain admits any candidate, before any optimisation runs."""
    cons = domain.linear_constraints()
    comps = domain.components
    missing = domain.missing_information()
    warnings: list[str] = []
    explanations = _quick_diagnostics(domain)
    proc = {k: v.__dict__ for k, v in domain.effective_process_ranges().items()}
    proc_ok = all(v["lower"] <= v["upper"] for v in proc.values())

    branches = _branches(domain)
    feasible_branches = [b for b in branches if _feasible(comps, cons, b)]
    conflicting: list[dict] = []
    if not feasible_branches:
        zero = branches[0]
        iis = irreducible_infeasible_subset(comps, cons, zero)
        conflicting = [{"name": c.name, "kind": c.kind, "expression": c.describe()} for c in iis]
        if zero:
            conflicting.append({"name": "incompatibility_branch", "kind": "incompatibility",
                                "expression": f"set to zero: {', '.join(zero)}"})
        explanations.append("no composition satisfies all hard constraints; the listed subset is irreducible — "
                            "relaxing any one of them removes this particular conflict")
    ranges: dict[str, tuple[float, float]] = {}
    if feasible_branches:
        for i, c in enumerate(comps):
            mins, maxs = [], []
            for b in feasible_branches:
                obj = np.zeros(len(comps)); obj[i] = 1.0
                r1 = _lp(comps, cons, obj, b); r2 = _lp(comps, cons, -obj, b)
                mins.append(r1.x[i]); maxs.append(r2.x[i])
            ranges[c] = (float(max(0.0, min(mins))), float(max(maxs)))
            lo, hi = domain.bounds.get(c, (0, 1))
            if ranges[c][1] < hi - 1e-6 and c not in domain.excluded:
                warnings.append(f"{c}: configured upper bound {hi:g} is unreachable; effective max {ranges[c][1]:.4f}")
            if ranges[c][0] > lo + 1e-6:
                warnings.append(f"{c}: configured lower bound {lo:g} is inactive; effective min {ranges[c][0]:.4f}")
    unknown_pairs = [r for r in domain.compatibility if r.status == "unknown"]
    for r in unknown_pairs:
        warnings.append(f"compatibility of {r.a} + {r.b} is UNKNOWN (policy: {domain.unknown_compatibility_policy})")
    if not proc_ok:
        explanations.append("process ranges are empty after applying equipment limits")
    blocked = bool(missing)
    if blocked:
        explanations.append("missing information blocks optimisation until resolved")
    return FeasibilityReport(bool(feasible_branches) and proc_ok, blocked, explanations, conflicting, ranges, proc,
                             missing, warnings)


# --------------------------------------------------------------------------------------
# Candidate checks
# --------------------------------------------------------------------------------------
@dataclass
class ConstraintCheck:
    name: str
    status: str  # "pass" | "fail" | "unknown" | "flag"
    hard: bool
    detail: str

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def check_candidate(domain: ResearchDomain, composition: Mapping[str, float],
                    process: Mapping[str, float] | None = None) -> list[ConstraintCheck]:
    checks: list[ConstraintCheck] = []
    unknown = set(composition) - set(domain.components)
    for u in sorted(unknown):
        present = composition[u] > PRESENCE_THRESHOLD
        checks.append(ConstraintCheck(f"domain_component[{u}]", "fail" if present else "pass", True,
                                      f"{u} is not part of the configured research domain"))
    x = {c: float(composition.get(c, 0.0)) for c in domain.components}
    for c in domain.linear_constraints():
        lhs, ok = c.evaluate(x)
        checks.append(ConstraintCheck(c.name, "pass" if ok else "fail", True, f"{c.describe()} (value {lhs:.6g})"))
    for c in domain.components:
        if x[c] < -1e-9:
            checks.append(ConstraintCheck(f"nonnegative[{c}]", "fail", True, f"{c} = {x[c]:g} < 0"))
    present = [c for c in domain.components if x[c] > PRESENCE_THRESHOLD]
    for a, b in itertools.combinations(present, 2):
        rec = domain.compatibility_status(a, b)
        if rec is None or rec.status == "unknown":
            st = "fail" if domain.unknown_compatibility_policy == "block" else "flag"
            checks.append(ConstraintCheck(f"compatibility[{a}+{b}]", st, domain.unknown_compatibility_policy == "block",
                                          "compatibility unknown — not assumed compatible" +
                                          ("" if rec is None else f" (record: {rec.source})")))
        elif rec.status == "incompatible":
            checks.append(ConstraintCheck(f"compatibility[{a}+{b}]", "fail", True,
                                          f"reviewed incompatibility ({rec.source})"))
        else:
            checks.append(ConstraintCheck(f"compatibility[{a}+{b}]", "pass", True,
                                          f"compatible per {rec.source}{'' if rec.reviewed else ' (UNREVIEWED)'}"))
    ranges = domain.effective_process_ranges()
    process = process or {}
    for k, r in ranges.items():
        if k not in process or process[k] is None:
            checks.append(ConstraintCheck(f"process[{k}]", "unknown", True, f"{k} not specified"))
            continue
        v = process[k]
        ok = r.lower - 1e-9 <= v <= r.upper + 1e-9
        checks.append(ConstraintCheck(f"process[{k}]", "pass" if ok else "fail", True,
                                      f"{v:g} {r.unit} within [{r.lower:g}, {r.upper:g}] ({r.source})"))
    for k in set(process) - set(ranges):
        checks.append(ConstraintCheck(f"process[{k}]", "fail", True, f"{k} is not a permitted process variable"))
    for m in domain.missing_information():
        checks.append(ConstraintCheck("missing_information", "fail", True, m))
    return checks


def is_admissible(checks: list[ConstraintCheck]) -> bool:
    return all(c.status in ("pass", "flag") for c in checks if c.hard)
