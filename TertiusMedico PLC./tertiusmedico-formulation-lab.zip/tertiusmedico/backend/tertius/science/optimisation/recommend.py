"""Evaluated experiment recommendations.

Pipeline: constrained candidate pool → hard-constraint checks → applicability
domain (abstain) → predictions with intervals → calculated objectives →
Pareto frontier → diverse selection + one exploration point → proposals with
full evidence. Optionally the constrained Bayesian optimiser adds suggestions
which go through *exactly the same* checks.

Proposals are recommendations only. They have status ``proposed`` and must be
accepted by a reviewer before an experiment plan is created; nothing here can
schedule or execute laboratory work.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Sequence

import numpy as np
import pandas as pd

from ..constraints import ResearchDomain, check_candidate, is_admissible
from ..doe import Polytope, latin_hypercube, maximin_subset
from ..ml.pipeline import ModelBundle
from .pareto import Objective, crowding_distance, non_dominated_sort

LABELS = {"prediction": "PREDICTED", "calculation": "CALCULATED", "simulation": "SIMULATED"}


@dataclass
class Proposal:
    proposal_id: str
    composition: dict
    process: dict
    predictions: dict
    calculated: dict
    objective_values: dict
    constraint_checks: list
    domain: dict
    neighbourhood: list
    reason: str
    strategy: str
    pareto_rank: int | None
    status: str = "proposed"
    warnings: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def material_cost(domain: ResearchDomain, comp: Mapping[str, float]) -> dict | None:
    if domain.missing_information() or not domain.prices:
        return None
    cur = {p.currency for p in domain.prices.values()}
    if len(cur) != 1:
        return None
    total = sum(comp.get(c, 0.0) * domain.prices[c].amount for c in domain.components if comp.get(c, 0) > 0)
    dates = sorted({p.price_date for p in domain.prices.values()})
    return {"value": float(total), "unit": f"{cur.pop()}/kg", "label": "CALCULATED",
            "basis": f"Σ fraction × price per kg; price dates {', '.join(dates)}"}


class Recommender:
    def __init__(self, domain: ResearchDomain, bundle: ModelBundle, objectives: Sequence[Objective],
                 training_frame: pd.DataFrame, mixture_cols: list[str], process_cols: list[str],
                 domain_target: str, alpha: float = 0.1):
        self.domain = domain
        self.bundle = bundle
        self.objectives = list(objectives)
        self.train = training_frame.reset_index(drop=True)
        self.mix_cols = mixture_cols
        self.proc_cols = process_cols
        self.domain_target = domain_target
        self.alpha = alpha
        self.proc_names = [c.split(":", 1)[1] for c in process_cols]

    # ---------- evaluation of single candidates ----------
    def _x(self, comp, proc) -> np.ndarray:
        return np.array([comp.get(c.split(":", 1)[1], 0.0) for c in self.mix_cols] +
                        [proc.get(p, np.nan) for p in self.proc_names], float)

    def neighbourhood(self, x: np.ndarray, k: int = 5) -> list[dict]:
        X = self.train[self.mix_cols + self.proc_cols].to_numpy(float)
        lo, hi = X.min(0), X.max(0)
        rng = np.where(hi > lo, hi - lo, 1.0)
        d = np.linalg.norm((X - x) / rng, axis=1)
        out, seen = [], set()
        for i in np.argsort(d):
            r = self.train.iloc[i]
            key = r.get("replicate_group", r.get("run_id"))
            if key in seen:
                continue
            seen.add(key)
            grp = self.train[self.train.get("replicate_group", self.train["run_id"]) == key]
            out.append({"run_id": r["run_id"], "replicate_group": key, "normalised_distance": float(d[i]),
                        "observed_mean": float(grp["value"].mean()), "n_replicates": int(len(grp)),
                        "target": r["target"], "unit": r["unit"], "label": "MEASURED"})
            if len(out) >= k:
                break
        return out

    def _screen(self, comp: Mapping[str, float], proc: Mapping[str, float]) -> dict:
        checks = check_candidate(self.domain, comp, proc)
        admissible = is_admissible(checks)
        x = self._x(comp, proc)
        ad = self.bundle.results[self.domain_target].domain.assess(np.nan_to_num(x, nan=0.0),
                                                                    research_domain_ok=admissible)
        result = {"composition": dict(comp), "process": dict(proc), "admissible": admissible,
                  "constraint_checks": [c.as_dict() for c in checks], "domain": ad.as_dict(),
                  "abstained": ad.abstain, "predictions": {}, "calculated": {}, "_x": x}
        if not admissible:
            result["decision"] = "rejected"
            result["reasons"] = [c.detail for c in checks if c.status == "fail"] + ad.reasons
        elif ad.abstain:
            result["decision"] = "abstained"
            result["reasons"] = ad.reasons
        else:
            result["decision"] = "evaluated"
        return result

    def _annotate(self, evs: list[dict]) -> None:
        """Batch predictions + calculated quantities for screened, in-domain candidates."""
        todo = [e for e in evs if e["decision"] == "evaluated"]
        if not todo:
            return
        X = np.vstack([e["_x"] for e in todo])
        for t in self.bundle.results:
            p = self.bundle.predict(t, X, self.alpha)
            for j, e in enumerate(todo):
                if p["kind"] == "classification":
                    e["predictions"][t] = {"score": float(p["score"][j]), "label": "PREDICTED",
                                           "calibration_status": p["calibration_status"]}
                else:
                    e["predictions"][t] = {
                        "mean": float(p["mean"][j]), "lower": float(p["lower"][j]), "upper": float(p["upper"][j]),
                        "interval": f"{int(round((1 - self.alpha) * 100))}% conformal (nominal)", "unit": p["unit"],
                        "model": p["model"], "label": "PREDICTED",
                        "model_sd_model_scale": None if p["model_sd"] is None else float(p["model_sd"][j]),
                        "noise_sd_model_scale": p["noise_sd"], "scale": p["scale"]}
        for e in todo:
            cost = material_cost(self.domain, e["composition"])
            if cost:
                e["calculated"]["material_cost"] = cost
            if "mix_time" in e["process"]:
                e["calculated"]["process_time"] = {"value": float(e["process"]["mix_time"]), "unit": "min",
                                                   "label": "CALCULATED", "basis": "mixing stage duration"}

    def evaluate(self, comp: Mapping[str, float], proc: Mapping[str, float]) -> dict:
        ev = self._screen(comp, proc)
        self._annotate([ev])
        ev.pop("_x", None)
        return ev

    def _objective_value(self, o: Objective, ev: dict) -> float | None:
        if o.source == "prediction":
            p = ev["predictions"].get(o.target)
            if p is None:
                return None
            return p.get("mean", p.get("score"))
        c = ev["calculated"].get(o.name)
        return None if c is None else c["value"]

    # ---------- batch recommendation ----------
    def candidate_pool(self, n: int, seed: int) -> list[tuple[dict, dict]]:
        rng = np.random.default_rng(seed)
        poly = Polytope.from_domain(self.domain)
        M = np.vstack([poly.hit_and_run(n, rng), poly.vertices()])
        ranges = self.domain.effective_process_ranges()
        P = latin_hypercube({k: (r.lower, r.upper) for k, r in ranges.items()}, len(M), seed)
        out = []
        for i in range(len(M)):
            comp = dict(zip(self.domain.components, map(float, M[i])))
            proc = {k: float(P.iloc[i][f"proc:{k}"]) for k in ranges}
            out.append((comp, proc))
        return out

    def recommend(self, n: int = 5, pool_size: int = 1500, seed: int = 0,
                  bo_suggestions: Sequence[tuple[dict, dict, str]] = ()) -> dict:
        pool = self.candidate_pool(pool_size, seed)
        evals, stats = [], {"pool": len(pool), "inadmissible": 0, "abstained": 0, "bo_suggestions": len(bo_suggestions)}
        for comp, proc in pool:
            ev = self._screen(comp, proc)
            if ev["decision"] == "rejected":
                stats["inadmissible"] += 1; continue
            if ev["decision"] == "abstained":
                stats["abstained"] += 1; continue
            ev["origin"] = "pool"
            evals.append(ev)
        bo_evals = []
        for comp, proc, backend in bo_suggestions:
            ev = self._screen(comp, proc)
            ev["origin"] = backend
            if ev["decision"] == "evaluated":
                bo_evals.append(ev)
            else:
                stats.setdefault("bo_rejected_or_abstained", 0)
                stats["bo_rejected_or_abstained"] += 1
        allev = evals + bo_evals
        self._annotate(allev)
        if not allev:
            return {"proposals": [], "frontier": [], "stats": stats,
                    "message": "no admissible, in-domain candidates; widen the research domain or add experiments"}
        F = np.array([[o.to_min(np.array([self._objective_value(o, ev)]))[0] for o in self.objectives] for ev in allev])
        ranks = non_dominated_sort(F)
        for ev, r, f in zip(allev, ranks, F):
            ev["pareto_rank"] = int(r)
            ev["objective_values"] = {o.name: self._objective_value(o, ev) for o in self.objectives}
            ev["objective_min_form"] = dict(zip([o.name for o in self.objectives], map(float, f)))
        front = [i for i in range(len(allev)) if ranks[i] == 0]

        chosen: list[tuple[int, str, str]] = []
        rng = np.random.default_rng(seed)
        # 1) constrained BO suggestions that are on or near the frontier
        for i in range(len(evals), len(allev)):
            if len(chosen) >= max(1, n // 3):
                break
            if ranks[i] <= 1:
                chosen.append((i, "bayesian_optimisation",
                               f"suggested by {allev[i]['origin']} (constrained acquisition on measured history); "
                               f"Pareto rank {ranks[i]} under current models"))
        # 2) diverse frontier members (spread across trade-offs)
        n_front = n - 1 - len(chosen)
        prim = [o for o in self.objectives if o.direction == "target_range"]
        pref = [i for i in front if all(allev[i]["objective_min_form"][o.name] == 0 for o in prim)] or front
        pref = [i for i in pref if i not in [c[0] for c in chosen]]
        if pref and n_front > 0:
            Fn = F[pref]
            span = np.where(Fn.max(0) > Fn.min(0), Fn.max(0) - Fn.min(0), 1.0)
            Z = (Fn - Fn.min(0)) / span
            cd = crowding_distance(Fn)
            start = int(np.argmax(np.where(np.isinf(cd), 1e9, cd)))
            sel = [start]
            while len(sel) < min(n_front, len(pref)):
                d = np.min(np.linalg.norm(Z[:, None, :] - Z[sel][None, :, :], axis=2), axis=1)
                d[sel] = -1
                sel.append(int(np.argmax(d)))
            for s in sel:
                i = pref[s]
                trade = ", ".join(f"{k}={v:.3g}" for k, v in allev[i]["objective_values"].items() if v is not None)
                chosen.append((i, "pareto_diverse",
                               f"non-dominated under current models and spread along the trade-off surface ({trade})"))
        # 3) one exploration point: widest predicted interval for the domain target among non-chosen candidates
        taken = {c[0] for c in chosen}
        rest = [i for i in range(len(allev)) if i not in taken]
        if rest and len(chosen) < n:
            def width(i):
                p = allev[i]["predictions"][self.domain_target]
                return np.log(p["upper"] / p["lower"]) if p["lower"] > 0 else p["upper"] - p["lower"]
            j = max(rest, key=width)
            chosen.append((j, "exploration",
                           f"widest {self.domain_target} interval among admissible in-domain candidates: reduces model "
                           "uncertainty where experimental support is thinnest"))
        # 4) top up from frontier/rank order if needed
        for i in np.argsort(ranks):
            if len(chosen) >= n:
                break
            if i not in {c[0] for c in chosen}:
                chosen.append((int(i), "pareto_rank", f"Pareto rank {ranks[i]}"))

        proposals = []
        for k, (i, strat, reason) in enumerate(chosen[:n]):
            ev = allev[i]
            x = ev.pop("_x")
            warns = [f"domain flag: {f}" for f in ev["domain"]["flags"]]
            warns += [c["detail"] for c in ev["constraint_checks"] if c["status"] == "flag"]
            for t, p in ev["predictions"].items():
                if "calibration_status" in p and p["calibration_status"].startswith("UNVALIDATED"):
                    warns.append(f"{t}: score is not a validated probability")
            proposals.append(Proposal(
                proposal_id=f"P{k + 1:02d}", composition=ev["composition"], process=ev["process"],
                predictions=ev["predictions"], calculated=ev["calculated"], objective_values=ev["objective_values"],
                constraint_checks=ev["constraint_checks"], domain=ev["domain"], neighbourhood=self.neighbourhood(x),
                reason=reason, strategy=strat, pareto_rank=ev["pareto_rank"], warnings=warns).as_dict())
        frontier = [{"composition": allev[i]["composition"], "process": allev[i]["process"],
                     "objective_values": allev[i]["objective_values"], "origin": allev[i]["origin"]} for i in front]
        return {"proposals": proposals, "frontier": frontier, "stats": stats,
                "objectives": [o.as_dict() for o in self.objectives],
                "notice": "Recommendations only. Each proposal requires scientific review before it can become an "
                          "experiment plan. Predictions describe laboratory measurements in the supported domain, "
                          "not efficacy, bioavailability or safety."}
