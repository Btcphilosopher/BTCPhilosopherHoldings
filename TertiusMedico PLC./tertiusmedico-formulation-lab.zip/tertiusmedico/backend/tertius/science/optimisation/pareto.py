"""Multi-objective utilities: objective definitions, non-dominated sorting, crowding distance.

The Pareto frontier is reported as is; trade-offs are never collapsed into a
hidden weighted score.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Objective:
    name: str
    direction: str  # "min" | "max" | "target_range"
    unit: str
    source: str  # "prediction" | "calculation" | "simulation"
    target: str | None = None  # model target for predictions
    low: float | None = None  # for target_range
    high: float | None = None
    log_scale: bool = False  # range deviation measured on log scale
    description: str = ""

    def to_min(self, v: np.ndarray) -> np.ndarray:
        v = np.asarray(v, float)
        if self.direction == "min":
            return v
        if self.direction == "max":
            return -v
        lo, hi = self.low, self.high
        if self.log_scale:
            v, lo, hi = np.log(v), np.log(lo), np.log(hi)
        return np.maximum(0.0, np.maximum(lo - v, v - hi))

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def dominates(a: np.ndarray, b: np.ndarray) -> bool:
    return bool(np.all(a <= b) and np.any(a < b))


def non_dominated_sort(F: np.ndarray) -> np.ndarray:
    """Return Pareto rank (0 = frontier) for each row of the minimisation matrix F."""
    n = len(F)
    ranks = np.full(n, -1)
    S = [[] for _ in range(n)]
    counts = np.zeros(n, int)
    for i in range(n):
        le = np.all(F[i] <= F, axis=1) & np.any(F[i] < F, axis=1)
        ge = np.all(F <= F[i], axis=1) & np.any(F < F[i], axis=1)
        S[i] = list(np.where(le)[0])
        counts[i] = int(ge.sum())
    front = list(np.where(counts == 0)[0])
    r = 0
    while front:
        nxt = []
        for i in front:
            ranks[i] = r
            for j in S[i]:
                counts[j] -= 1
                if counts[j] == 0:
                    nxt.append(j)
        front, r = nxt, r + 1
    return ranks


def crowding_distance(F: np.ndarray) -> np.ndarray:
    n, m = F.shape
    d = np.zeros(n)
    if n <= 2:
        return np.full(n, np.inf)
    for k in range(m):
        o = np.argsort(F[:, k])
        span = F[o[-1], k] - F[o[0], k]
        d[o[0]] = d[o[-1]] = np.inf
        if span <= 0:
            continue
        d[o[1:-1]] += (F[o[2:], k] - F[o[:-2], k]) / span
    return d
