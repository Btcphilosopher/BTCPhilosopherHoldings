"""Constrained Bayesian optimisation behind an adapter.

The platform depends only on :class:`BayesianOptimiser`. The shipped backend is
Optuna's ask-and-tell interface (verified against Optuna 5.1 source/docs):

* ``sampler="tpe"`` – ``optuna.samplers.TPESampler`` (Tree-structured Parzen
  Estimator, a sequential model-based / Bayesian optimisation method) with
  constraint and multi-objective support; no PyTorch needed. In Optuna ≥ 5.0
  constraints are read from each trial's recorded constraint values
  (``create_trial(constraints=...)``); ``constraints_func`` is deprecated.
* ``sampler="gp"`` – ``optuna.samplers.GPSampler`` (Matern-5/2 GP with logEI /
  logEHVI and constrained variants). Optuna requires PyTorch for this sampler;
  it is an optional extra (``pip install .[gp]``) and is the *only* reason the
  platform would install PyTorch.

Parameterisation keeps every suggestion inside the research domain by
construction where possible and by rejection otherwise:

* excluded ingredients are not parameters at all (fixed at zero);
* the free mixture fraction above the lower bounds is distributed by
  stick-breaking variables u_i ∈ [0, 1] (bijective onto the L-pseudocomponent
  simplex);
* any remaining linear constraint (upper bounds, group limits, cost) is
  checked with :func:`check_candidate`; inadmissible asks are told as FAILED
  and resampled, and are **never** returned.

Measured history is injected with ``optuna.trial.create_trial`` including a
black-box constraint: a failed/phase-separated run has constraint value +1,
a successful one −1 (Optuna: feasible iff all constraint values ≤ 0).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Protocol, Sequence

import numpy as np

from ..constraints import ResearchDomain, check_candidate, is_admissible


class BayesianOptimiser(Protocol):
    def suggest(self, history: Sequence["Observation"], n: int) -> list["Suggestion"]: ...


@dataclass
class Observation:
    composition: Mapping[str, float]
    process: Mapping[str, float]
    objectives: Sequence[float]  # in the declared directions
    failed: bool = False
    run_id: str | None = None


@dataclass
class Suggestion:
    composition: dict[str, float]
    process: dict[str, float]
    backend: str
    attempts: int


def _stick_forward(u: np.ndarray) -> np.ndarray:
    z, rest = [], 1.0
    for ui in u:
        z.append(rest * ui); rest -= rest * ui
    z.append(rest)
    return np.array(z)


def _stick_inverse(z: np.ndarray) -> np.ndarray:
    u, rest = [], 1.0
    for zi in z[:-1]:
        u.append(0.0 if rest <= 1e-15 else float(np.clip(zi / rest, 0, 1)))
        rest -= zi
    return np.array(u)


class OptunaAdapter:
    def __init__(self, domain: ResearchDomain, directions: Sequence[str], sampler: str = "tpe", seed: int = 0,
                 max_attempts: int = 400):
        self.domain = domain
        self.directions = [{"min": "minimize", "max": "maximize"}[d] for d in directions]
        self.sampler_name = sampler
        self.seed = seed
        self.max_attempts = max_attempts
        self.free = [c for c in domain.components if c not in domain.excluded]
        self.lower = np.array([domain.bounds.get(c, (0, 1))[0] for c in self.free])
        self.span = domain.total - self.lower.sum()
        if self.span <= 0:
            raise ValueError("research domain leaves no free mixture fraction")
        self.ranges = domain.effective_process_ranges()

    # --- parameter mapping
    def _distributions(self):
        from optuna.distributions import FloatDistribution
        d = {f"u{i}": FloatDistribution(0.0, 1.0) for i in range(len(self.free) - 1)}
        d.update({f"p:{k}": FloatDistribution(r.lower, r.upper) for k, r in self.ranges.items()})
        return d

    def to_params(self, comp: Mapping[str, float], proc: Mapping[str, float]) -> dict:
        x = np.array([comp.get(c, 0.0) for c in self.free])
        z = np.clip((x - self.lower) / self.span, 0, None)
        z = z / z.sum() if z.sum() > 0 else np.full(len(z), 1 / len(z))
        params = {f"u{i}": float(v) for i, v in enumerate(_stick_inverse(z))}
        params.update({f"p:{k}": float(np.clip(proc[k], r.lower, r.upper)) for k, r in self.ranges.items()})
        return params

    def from_params(self, params: Mapping[str, float]) -> tuple[dict, dict]:
        u = np.array([params[f"u{i}"] for i in range(len(self.free) - 1)])
        x = self.lower + self.span * _stick_forward(u)
        comp = {c: 0.0 for c in self.domain.components}
        comp.update({c: float(v) for c, v in zip(self.free, x)})
        proc = {k: float(params[f"p:{k}"]) for k in self.ranges}
        return comp, proc

    def _sampler(self):
        import optuna

        # Optuna ≥ 5.0: samplers read FrozenTrial.constraints (set via create_trial(constraints=...)) directly;
        # the older ``constraints_func`` argument is deprecated (verified in the installed 5.1 source).
        if self.sampler_name == "tpe":
            return optuna.samplers.TPESampler(seed=self.seed, multivariate=True, n_startup_trials=10,
                                              constant_liar=True)
        if self.sampler_name == "gp":
            try:
                import torch  # noqa: F401
            except ImportError as e:
                raise RuntimeError("GPSampler requires PyTorch (optional extra 'gp'); use sampler='tpe'") from e
            return optuna.samplers.GPSampler(seed=self.seed)
        raise ValueError(self.sampler_name)

    def suggest(self, history: Sequence[Observation], n: int) -> list[Suggestion]:
        import optuna
        from optuna.trial import TrialState, create_trial

        optuna.logging.set_verbosity(optuna.logging.WARNING)
        study = optuna.create_study(directions=self.directions, sampler=self._sampler())
        dist = self._distributions()
        for h in history:
            vals = list(h.objectives)
            if h.failed or any(v is None or not np.isfinite(v) for v in vals):
                # failed run: keep its location as an infeasible observation with placeholder worst values
                worst = [1e6 if d == "minimize" else -1e6 for d in self.directions]
                vals = worst
            study.add_trial(create_trial(params=self.to_params(h.composition, h.process), distributions=dist,
                                         values=vals, constraints={"failure": 1.0 if h.failed else -1.0},
                                         user_attrs={"run_id": h.run_id, "source": "measured"}))
        out: list[Suggestion] = []
        attempts = 0
        while len(out) < n and attempts < self.max_attempts:
            attempts += 1
            t = study.ask(dist)
            comp, proc = self.from_params(t.params)
            if is_admissible(check_candidate(self.domain, comp, proc)):
                out.append(Suggestion(comp, proc, f"optuna-{self.sampler_name}", attempts))
                # leave RUNNING so constant-liar diversifies the batch
            else:
                study.tell(t, state=TrialState.FAIL)
        if len(out) < n:
            raise RuntimeError(f"only {len(out)} admissible suggestions after {attempts} attempts")
        return out
