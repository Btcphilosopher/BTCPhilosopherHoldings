"""Combination-research module (separately bounded).

Scope: analysis of *authorised* experimental datasets in which two compounds
are tested alone and together. The module quantifies departure of the observed
combined response from named reference models, per dose pair, with replicate
bootstrap intervals.

Reference models
----------------
* **Bliss independence**: E_exp = E_A + E_B − E_A·E_B. Assumes fractional
  effects on [0, 1] and probabilistically independent action. Departures are
  reported as "excess over Bliss" / "deficit versus Bliss".
* **Highest single agent (HSA)**: E_exp = max(E_A, E_B). A weaker, more
  conservative reference.
* Loewe additivity is **not implemented** (requires fitted single-agent
  dose–response curves with compatible maximal effects); listed as unproven.

What this module does not do
----------------------------
An experimental interaction in an assay is not evidence of clinical benefit,
safety, or appropriate dosing. The module refuses datasets without an
authorisation reference, refuses human/patient-level data, keeps every result
tied to its dose pair and experimental context, and never produces combination
regimens, prescribing instructions or treatment recommendations.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

DISCLAIMER = ("Experimental interaction relative to a reference model in the stated assay only. Not evidence of "
              "therapeutic benefit, safety, or dosing; must not be extrapolated to patients or treatment regimens.")
FORBIDDEN_CONTEXT = {"human", "patient", "clinical", "subject"}


class CombinationScopeError(ValueError):
    pass


@dataclass
class CombinationContext:
    authorisation_reference: str
    permitted_use: str
    system: str  # e.g. "cell-free enzymatic assay (fictional)"
    exposure: str  # e.g. "48 h, 37 °C"
    endpoint: str
    response_scale: str = "fractional effect (0 = vehicle, 1 = maximal)"
    subject_type: str = "in_vitro"
    controls: list = field(default_factory=lambda: ["vehicle"])

    def validate(self) -> None:
        if not self.authorisation_reference or not self.permitted_use:
            raise CombinationScopeError("dataset lacks an authorisation reference / permitted use; analysis refused")
        if any(w in self.subject_type.lower() for w in FORBIDDEN_CONTEXT):
            raise CombinationScopeError("human or patient-level data are outside this module's scope")


def _boot_ci(samples_a, samples_b, samples_ab, ref: str, rng, n_boot=2000):
    a, b, ab = map(np.asarray, (samples_a, samples_b, samples_ab))
    ra = rng.choice(a, (n_boot, len(a))).mean(1)
    rb = rng.choice(b, (n_boot, len(b))).mean(1)
    rab = rng.choice(ab, (n_boot, len(ab))).mean(1)
    exp = ra + rb - ra * rb if ref == "bliss" else np.maximum(ra, rb)
    ex = rab - exp
    return float(np.percentile(ex, 2.5)), float(np.percentile(ex, 97.5))


def analyse_combination(df: pd.DataFrame, ctx: CombinationContext, min_replicates: int = 3, seed: int = 0) -> dict:
    ctx.validate()
    rng = np.random.default_rng(seed)
    need = {"dose_a", "dose_b", "response", "replicate"}
    if not need <= set(df.columns):
        raise ValueError(f"dataset needs columns {sorted(need)}")
    vehicle = df[(df.dose_a == 0) & (df.dose_b == 0)]["response"]
    if len(vehicle) < 2:
        raise CombinationScopeError("vehicle controls missing: responses cannot be normalised")
    base = float(vehicle.mean())
    d = df.assign(effect=df["response"] - base)
    notes = [f"responses baseline-corrected by vehicle mean {base:.4f} (n={len(vehicle)})"]
    out_of_range = d[(d.effect < -0.05) | (d.effect > 1.05)]
    if len(out_of_range):
        notes.append(f"{len(out_of_range)} replicate effects outside [0,1]; Bliss assumptions strained there")
    rows = []
    for (a, b), g in d[(d.dose_a > 0) & (d.dose_b > 0)].groupby(["dose_a", "dose_b"]):
        ea = d[(d.dose_a == a) & (d.dose_b == 0)]["effect"].to_numpy()
        eb = d[(d.dose_a == 0) & (d.dose_b == b)]["effect"].to_numpy()
        eab = g["effect"].to_numpy()
        row = {"dose_a": float(a), "dose_b": float(b), "n_a": len(ea), "n_b": len(eb), "n_ab": len(eab),
               "observed": float(eab.mean()) if len(eab) else None,
               "replicate_sd": float(eab.std(ddof=1)) if len(eab) > 1 else None}
        if min(len(ea), len(eb), len(eab)) < min_replicates:
            row.update({"conclusion": "insufficient data",
                        "reason": f"needs ≥{min_replicates} replicates of A alone, B alone and A+B at these doses"})
            rows.append(row); continue
        ma, mb = ea.mean(), eb.mean()
        for ref in ("bliss", "hsa"):
            exp = ma + mb - ma * mb if ref == "bliss" else max(ma, mb)
            lo, hi = _boot_ci(ea, eb, eab, ref, rng)
            row[f"{ref}_expected"] = float(exp)
            row[f"{ref}_excess"] = float(eab.mean() - exp)
            row[f"{ref}_ci95"] = [lo, hi]
        lo, hi = row["bliss_ci95"]
        row["conclusion"] = ("excess over Bliss (interval excludes 0)" if lo > 0 else
                             "deficit versus Bliss (interval excludes 0)" if hi < 0 else
                             "consistent with Bliss independence (interval includes 0)")
        rows.append(row)
    n_concl = sum(1 for r in rows if r["conclusion"] != "insufficient data")
    return {
        "context": ctx.__dict__, "reference_models": {
            "bliss": "E_exp = E_A + E_B − E_A·E_B; fractional effects in [0,1]; independent action",
            "hsa": "E_exp = max(E_A, E_B)",
            "loewe": "not implemented (unproven capability)"},
        "results": rows, "n_dose_pairs": len(rows), "n_with_conclusion": n_concl,
        "multiplicity_note": f"{n_concl} dose pairs tested without multiplicity correction; isolated departures may "
                             "be chance findings",
        "notes": notes, "label": "CALCULATED from MEASURED assay data", "disclaimer": DISCLAIMER,
    }
