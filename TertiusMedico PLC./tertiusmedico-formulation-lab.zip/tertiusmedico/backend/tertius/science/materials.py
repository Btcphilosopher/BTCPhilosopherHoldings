"""Materials registry domain model.

* Property values keep their provenance: supplier specification, literature,
  laboratory measurement or model estimate are separate source types and are
  never merged into one number.
* Missing properties stay missing (``None``). Nothing in this module fabricates
  defaults for unknown scientific values.
* Records are immutable; :meth:`MaterialRecord.revise` produces a new version
  with a new content hash so historical experiments keep pointing at the exact
  material record they used.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
from dataclasses import dataclass, field
from datetime import date
from enum import Enum
from typing import Any, Iterable

from .units import Quantity


class PropertySource(str, Enum):
    SUPPLIER_SPECIFICATION = "supplier_specification"
    LITERATURE = "literature"
    LABORATORY_MEASUREMENT = "laboratory_measurement"
    MODEL_ESTIMATE = "model_estimate"


class VerificationStatus(str, Enum):
    UNVERIFIED = "unverified"
    IDENTITY_CONFIRMED = "identity_confirmed"
    VERIFIED = "verified"
    REJECTED = "rejected"


@dataclass(frozen=True)
class PropertyValue:
    name: str
    source: PropertySource
    value: float | None = None
    unit: str | None = None
    text: str | None = None
    reference: str | None = None
    method: str | None = None
    uncertainty: float | None = None  # same unit as value, 1 SD unless stated in method
    recorded_on: str | None = None

    def __post_init__(self) -> None:
        if self.value is not None:
            if self.unit is None:
                raise ValueError(f"property {self.name}: numeric value requires a unit")
            Quantity(self.value, self.unit)  # validates unit
        if self.source == PropertySource.LABORATORY_MEASUREMENT and not self.method:
            raise ValueError(f"property {self.name}: laboratory measurements must cite a method")

    @property
    def quantity(self) -> Quantity | None:
        return Quantity(self.value, self.unit) if self.value is not None and self.unit else None


# default lookup preference: measured > supplier spec > literature > model estimate
DEFAULT_PREFERENCE = (
    PropertySource.LABORATORY_MEASUREMENT,
    PropertySource.SUPPLIER_SPECIFICATION,
    PropertySource.LITERATURE,
    PropertySource.MODEL_ESTIMATE,
)


@dataclass(frozen=True)
class MaterialRecord:
    material_id: str
    name: str
    version: int = 1
    supplier: str | None = None
    grade: str | None = None
    lot: str | None = None
    identity_reference: str | None = None
    composition: dict[str, Any] | None = None
    purity_or_assay: PropertyValue | None = None
    physical_properties: tuple[PropertyValue, ...] = ()
    storage_requirements: str | None = None
    expiry_or_retest_date: str | None = None  # ISO date
    hazard_document_references: tuple[str, ...] = ()
    source: str | None = None
    verification_status: VerificationStatus = VerificationStatus.UNVERIFIED
    fictional: bool = False  # demonstration surrogate flag

    # ----- property lookup -------------------------------------------------
    def properties(self, name: str) -> list[PropertyValue]:
        return [p for p in self.physical_properties if p.name == name]

    def get_property(self, name: str, preference: Iterable[PropertySource] = DEFAULT_PREFERENCE) -> PropertyValue | None:
        """Return the most preferred recorded value or ``None`` when unknown."""
        values = self.properties(name)
        for src in preference:
            for v in values:
                if v.source == src:
                    return v
        return None

    def get_quantity(self, name: str, allow_model_estimates: bool = False) -> Quantity | None:
        pref = DEFAULT_PREFERENCE if allow_model_estimates else DEFAULT_PREFERENCE[:3]
        v = self.get_property(name, pref)
        return v.quantity if v else None

    def missing(self, required: Iterable[str]) -> list[str]:
        return [r for r in required if not self.properties(r)]

    def is_expired(self, on: date) -> bool | None:
        if not self.expiry_or_retest_date:
            return None
        return date.fromisoformat(self.expiry_or_retest_date) < on

    # ----- versioning ------------------------------------------------------
    def to_dict(self) -> dict:
        d = dataclasses.asdict(self)
        d["verification_status"] = self.verification_status.value
        for p in d["physical_properties"]:
            p["source"] = p["source"].value if isinstance(p["source"], Enum) else p["source"]
        if d["purity_or_assay"]:
            s = d["purity_or_assay"]["source"]
            d["purity_or_assay"]["source"] = s.value if isinstance(s, Enum) else s
        d["hazard_document_references"] = list(self.hazard_document_references)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "MaterialRecord":
        d = dict(d)
        d["physical_properties"] = tuple(
            PropertyValue(**{**p, "source": PropertySource(p["source"])}) for p in d.get("physical_properties", [])
        )
        if d.get("purity_or_assay"):
            p = d["purity_or_assay"]
            d["purity_or_assay"] = PropertyValue(**{**p, "source": PropertySource(p["source"])})
        d["verification_status"] = VerificationStatus(d.get("verification_status", "unverified"))
        d["hazard_document_references"] = tuple(d.get("hazard_document_references", ()))
        return cls(**d)

    def content_hash(self) -> str:
        payload = self.to_dict()
        payload.pop("version", None)
        return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

    def revise(self, **changes: Any) -> "MaterialRecord":
        if "material_id" in changes and changes["material_id"] != self.material_id:
            raise ValueError("material_id is immutable across versions")
        new = dataclasses.replace(self, version=self.version + 1, **changes)
        if new.content_hash() == self.content_hash():
            raise ValueError("revision contains no changes")
        return new

    def add_property(self, prop: PropertyValue) -> "MaterialRecord":
        return self.revise(physical_properties=self.physical_properties + (prop,))
