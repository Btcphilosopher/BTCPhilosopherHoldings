"""Formulation model, composition bases, dimensional validation and mass balance.

Composition bases are kept distinct:

=====================  ==========================  =====================================
basis                  unit dimension              note
=====================  ==========================  =====================================
mass_fraction          dimensionless (sum = 1)     w/w
volume_fraction        dimensionless (sum = 1)     v/v of *component volumes before mixing*;
                                                   mixture volume is not assumed additive
mass_concentration     M L^-3                      e.g. mg/mL of final product
molar_concentration    N L^-3                      requires molar mass to convert
amount_per_unit        M U^-1                      e.g. mg/tablet
absolute               M (or L^3 with density)     batch record quantities
=====================  ==========================  =====================================
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from .materials import MaterialRecord
from .units import (
    DIMENSIONLESS,
    DOSAGE_UNIT,
    MASS,
    MASS_CONCENTRATION,
    MASS_PER_DOSAGE_UNIT,
    MOLAR_CONCENTRATION,
    VOLUME,
    DimensionError,
    Quantity,
    amount_to_mass,
    multiply,
    volume_to_mass,
)

FRACTION_TOLERANCE = 1e-6


class Basis(str, Enum):
    MASS_FRACTION = "mass_fraction"
    VOLUME_FRACTION = "volume_fraction"
    MASS_CONCENTRATION = "mass_concentration"
    MOLAR_CONCENTRATION = "molar_concentration"
    AMOUNT_PER_UNIT = "amount_per_unit"
    ABSOLUTE = "absolute"


BASIS_DIM = {
    Basis.MASS_FRACTION: (DIMENSIONLESS,),
    Basis.VOLUME_FRACTION: (DIMENSIONLESS,),
    Basis.MASS_CONCENTRATION: (MASS_CONCENTRATION,),
    Basis.MOLAR_CONCENTRATION: (MOLAR_CONCENTRATION,),
    Basis.AMOUNT_PER_UNIT: (MASS_PER_DOSAGE_UNIT,),
    Basis.ABSOLUTE: (MASS, VOLUME),
}


class DosageForm(str, Enum):
    LIQUID = "liquid"
    SUSPENSION = "suspension"
    EMULSION = "emulsion"
    POWDER_BLEND = "powder_blend"
    TABLET = "tablet"
    CAPSULE = "capsule"


class Role(str, Enum):
    ACTIVE_SURROGATE = "active_surrogate"
    SOLVENT = "solvent"
    VEHICLE = "vehicle"
    FILLER = "filler"
    BINDER = "binder"
    DISINTEGRANT = "disintegrant"
    LUBRICANT = "lubricant"
    GLIDANT = "glidant"
    SURFACTANT = "surfactant"
    THICKENER = "thickener"
    PRESERVATIVE = "preservative"
    BUFFER = "buffer"
    TRACER = "tracer"
    OTHER = "other"


@dataclass(frozen=True)
class Ingredient:
    material_id: str
    material_version: int
    role: Role
    amount: Quantity
    lot: str | None = None
    group: str | None = None  # e.g. "surfactants" for group limits


@dataclass(frozen=True)
class ProcessStage:
    order: int
    name: str
    equipment_id: str | None
    parameters: Mapping[str, Quantity] = field(default_factory=dict)
    additions: tuple[str, ...] = ()  # material_ids in order of addition
    duration: Quantity | None = None


@dataclass(frozen=True)
class TargetProperty:
    name: str
    unit: str
    lower: float | None = None
    upper: float | None = None
    method: str | None = None


@dataclass(frozen=True)
class Formulation:
    formulation_id: str
    name: str
    dosage_form: DosageForm
    basis: Basis
    ingredients: tuple[Ingredient, ...]
    target_batch_size: Quantity
    stages: tuple[ProcessStage, ...] = ()
    targets: tuple[TargetProperty, ...] = ()
    evidence: tuple[str, ...] = ()
    revision: int = 1
    family: str | None = None
    unit_count: int | None = None  # dosage units per batch for amount_per_unit basis

    def fractions(self) -> dict[str, float]:
        if self.basis not in (Basis.MASS_FRACTION, Basis.VOLUME_FRACTION):
            raise ValueError(f"fractions() only defined for fraction bases, not {self.basis.value}")
        return {i.material_id: i.amount.to("fraction").value for i in self.ingredients}


@dataclass
class ValidationIssue:
    severity: str  # "error" | "warning" | "info"
    code: str
    message: str
    subject: str | None = None

    def as_dict(self) -> dict:
        return {"severity": self.severity, "code": self.code, "message": self.message, "subject": self.subject}


@dataclass
class ValidationReport:
    issues: list[ValidationIssue] = field(default_factory=list)
    calculated: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not any(i.severity == "error" for i in self.issues)

    def add(self, severity: str, code: str, message: str, subject: str | None = None) -> None:
        self.issues.append(ValidationIssue(severity, code, message, subject))

    def as_dict(self) -> dict:
        return {"ok": self.ok, "issues": [i.as_dict() for i in self.issues], "calculated": self.calculated}


def validate_formulation(f: Formulation, materials: Mapping[str, MaterialRecord] | None = None) -> ValidationReport:
    """Dimensional and compositional validation. Returns calculated (not measured) quantities."""
    rep = ValidationReport()
    materials = materials or {}
    if not f.ingredients:
        rep.add("error", "no_ingredients", "formulation has no ingredients")
        return rep

    seen: set[str] = set()
    for ing in f.ingredients:
        if ing.material_id in seen:
            rep.add("error", "duplicate_ingredient", f"{ing.material_id} listed twice", ing.material_id)
        seen.add(ing.material_id)
        allowed = BASIS_DIM[f.basis]
        if ing.amount.dim not in allowed:
            rep.add("error", "dimension_mismatch",
                    f"{ing.material_id}: unit {ing.amount.unit} [{ing.amount.dim}] incompatible with basis "
                    f"{f.basis.value} (expects {' or '.join(str(a) for a in allowed)})", ing.material_id)
        if ing.amount.value < 0:
            rep.add("error", "negative_amount", f"{ing.material_id}: negative amount", ing.material_id)
        mat = materials.get(ing.material_id)
        if materials and mat is None:
            rep.add("error", "unknown_material", f"{ing.material_id} not in registry", ing.material_id)
        elif mat is not None and mat.version != ing.material_version:
            rep.add("warning", "material_version_mismatch",
                    f"{ing.material_id}: formulation references v{ing.material_version}, registry has v{mat.version}",
                    ing.material_id)

    if not rep.ok:
        return rep

    if f.basis in (Basis.MASS_FRACTION, Basis.VOLUME_FRACTION):
        total = sum(i.amount.to("fraction").value for i in f.ingredients)
        rep.calculated["composition_total"] = total
        if abs(total - 1.0) > FRACTION_TOLERANCE:
            rep.add("error", "composition_total",
                    f"{f.basis.value} total is {total:.6f}; must equal 1 (±{FRACTION_TOLERANCE:g})")
        if f.basis == Basis.VOLUME_FRACTION:
            rep.add("warning", "volume_non_additive",
                    "volume fractions refer to component volumes before mixing; final volume is not assumed "
                    "additive and must be measured")

    # target batch size dimension
    tb = f.target_batch_size
    if f.basis == Basis.AMOUNT_PER_UNIT:
        if tb.dim != DOSAGE_UNIT:
            rep.add("error", "batch_size_dimension", "amount_per_unit basis needs batch size in dosage units")
    elif tb.dim not in (MASS, VOLUME):
        rep.add("error", "batch_size_dimension", f"batch size {tb.unit} must be a mass or volume")

    if rep.ok:
        try:
            bq = batch_quantities(f, materials)
            rep.calculated["batch_quantities"] = bq
            for row in bq:
                if row["mass_g"] is None:
                    rep.add("warning", "unresolved_mass", row["note"], row["material_id"])
        except DimensionError as e:
            rep.add("warning", "batch_quantities_unresolved", str(e))

    # process stages: order of addition must reference ingredients
    orders = [s.order for s in f.stages]
    if len(set(orders)) != len(orders):
        rep.add("error", "stage_order", "process stage order numbers must be unique")
    added = [m for s in sorted(f.stages, key=lambda s: s.order) for m in s.additions]
    for m in added:
        if m not in seen:
            rep.add("error", "addition_unknown", f"stage adds {m} which is not an ingredient", m)
    if f.stages:
        missing = seen - set(added)
        for m in sorted(missing):
            rep.add("warning", "not_added", f"{m} is never added in any process stage", m)
        if len(added) != len(set(added)):
            rep.add("info", "multiple_additions", "an ingredient is added in more than one stage (split addition)")
    return rep


def batch_quantities(f: Formulation, materials: Mapping[str, MaterialRecord]) -> list[dict]:
    """Scale a formulation to its target batch size.

    Each row reports a mass in grams **only** when it can be computed from the
    recorded data. If conversion would need a density or molar mass that is not
    recorded, ``mass_g`` is ``None`` and ``note`` explains what is missing.
    """
    rows: list[dict] = []
    tb = f.target_batch_size

    def density(mid: str) -> Quantity | None:
        m = materials.get(mid)
        return m.get_quantity("density") if m else None

    if f.basis == Basis.MASS_FRACTION:
        if tb.dim == MASS:
            batch_g = tb.to("g").value
        else:
            rows_note = "batch size given as volume; mass fractions need the *mixture* density (measured) to scale"
            return [{"material_id": i.material_id, "mass_g": None, "note": rows_note, "status": "unresolved"}
                    for i in f.ingredients]
        for i in f.ingredients:
            rows.append({"material_id": i.material_id, "mass_g": i.amount.to("fraction").value * batch_g,
                         "note": "calculated: fraction × batch mass", "status": "calculated"})
    elif f.basis == Basis.VOLUME_FRACTION:
        if tb.dim != VOLUME:
            raise DimensionError("volume-fraction formulations need a volume batch size")
        for i in f.ingredients:
            v = Quantity(i.amount.to("fraction").value * tb.to("mL").value, "mL")
            d = density(i.material_id)
            if d is None:
                rows.append({"material_id": i.material_id, "mass_g": None, "volume_mL": v.value,
                             "note": f"{i.material_id}: no recorded density; mass not computed", "status": "unresolved"})
            else:
                rows.append({"material_id": i.material_id, "volume_mL": v.value,
                             "mass_g": volume_to_mass(v, d, "g").value,
                             "note": "calculated: component volume × component density (pre-mixing)",
                             "status": "calculated"})
    elif f.basis == Basis.MASS_CONCENTRATION:
        if tb.dim != VOLUME:
            raise DimensionError("mass-concentration formulations need a final-volume batch size")
        for i in f.ingredients:
            m = multiply(i.amount, tb, "g")
            rows.append({"material_id": i.material_id, "mass_g": m.value,
                         "note": "calculated: concentration × final volume", "status": "calculated"})
    elif f.basis == Basis.MOLAR_CONCENTRATION:
        if tb.dim != VOLUME:
            raise DimensionError("molar-concentration formulations need a final-volume batch size")
        for i in f.ingredients:
            n = multiply(i.amount, tb, "mol")
            mat = materials.get(i.material_id)
            mm = mat.get_quantity("molar_mass") if mat else None
            if mm is None:
                rows.append({"material_id": i.material_id, "mass_g": None, "amount_mol": n.value,
                             "note": f"{i.material_id}: no recorded molar mass", "status": "unresolved"})
            else:
                rows.append({"material_id": i.material_id, "amount_mol": n.value,
                             "mass_g": amount_to_mass(n, mm, "g").value,
                             "note": "calculated: molarity × volume × molar mass", "status": "calculated"})
    elif f.basis == Basis.AMOUNT_PER_UNIT:
        units = tb.to("unit").value
        for i in f.ingredients:
            rows.append({"material_id": i.material_id, "mass_g": i.amount.to("g/unit").value * units,
                         "note": "calculated: amount per unit × unit count", "status": "calculated"})
    elif f.basis == Basis.ABSOLUTE:
        for i in f.ingredients:
            if i.amount.dim == MASS:
                rows.append({"material_id": i.material_id, "mass_g": i.amount.to("g").value,
                             "note": "recorded mass", "status": "recorded"})
            else:
                d = density(i.material_id)
                if d is None:
                    rows.append({"material_id": i.material_id, "mass_g": None,
                                 "note": f"{i.material_id}: volume recorded without density", "status": "unresolved"})
                else:
                    rows.append({"material_id": i.material_id,
                                 "mass_g": volume_to_mass(i.amount, d, "g").value,
                                 "note": "calculated: volume × density", "status": "calculated"})
    return rows


# --------------------------------------------------------------------------------------
# Mass balance & yield
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DocumentedLoss:
    stage: str
    mass: Quantity
    reason: str
    measured: bool  # True if weighed, False if an estimate


@dataclass
class MassBalance:
    input_g: float
    output_g: float | None
    documented_losses_g: float
    estimated_losses_g: float
    unaccounted_g: float | None
    closure: float | None  # (output + documented losses) / input
    theoretical_yield_g: float
    measured_yield_fraction: float | None
    flags: list[str]

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def mass_balance(inputs: list[Quantity], output: Quantity | None, losses: list[DocumentedLoss],
                 tolerance: float = 0.02) -> MassBalance:
    """Mass balance across a batch.

    * ``theoretical_yield_g`` is the sum of charged inputs (no losses) — a calculated quantity.
    * ``measured_yield_fraction`` is the *measured* output mass ÷ theoretical yield.
    * Unaccounted mass beyond ``tolerance`` of input is flagged rather than absorbed into losses.
    """
    for q in inputs:
        if q.dim != MASS:
            raise DimensionError(f"mass balance inputs must be masses, got {q.unit}")
    if output is not None and output.dim != MASS:
        raise DimensionError("output must be a mass")
    in_g = sum(q.to("g").value for q in inputs)
    doc = sum(l.mass.to("g").value for l in losses if l.measured)
    est = sum(l.mass.to("g").value for l in losses if not l.measured)
    flags: list[str] = []
    if output is None:
        flags.append("output_not_measured")
        return MassBalance(in_g, None, doc, est, None, None, in_g, None, flags)
    out_g = output.to("g").value
    unacc = in_g - out_g - doc - est
    closure = (out_g + doc + est) / in_g if in_g else None
    if out_g > in_g * (1 + 1e-9):
        flags.append("output_exceeds_input")
    if abs(unacc) > tolerance * in_g:
        flags.append("unaccounted_mass_exceeds_tolerance")
    if est > 0:
        flags.append("includes_estimated_losses")
    return MassBalance(in_g, out_g, doc, est, unacc, closure, in_g, out_g / in_g if in_g else None, flags)


def formulation_to_dict(f: Formulation) -> dict:
    return {
        "formulation_id": f.formulation_id, "name": f.name, "dosage_form": f.dosage_form.value,
        "basis": f.basis.value, "revision": f.revision, "family": f.family,
        "target_batch_size": f.target_batch_size.as_dict(),
        "ingredients": [{"material_id": i.material_id, "material_version": i.material_version, "role": i.role.value,
                         "amount": i.amount.as_dict(), "lot": i.lot, "group": i.group} for i in f.ingredients],
        "stages": [{"order": s.order, "name": s.name, "equipment_id": s.equipment_id,
                    "parameters": {k: v.as_dict() for k, v in s.parameters.items()},
                    "additions": list(s.additions), "duration": s.duration.as_dict() if s.duration else None}
                   for s in f.stages],
        "targets": [t.__dict__ for t in f.targets],
        "evidence": list(f.evidence),
        "unit_count": f.unit_count,
    }


def formulation_from_dict(d: Mapping) -> Formulation:
    return Formulation(
        formulation_id=d["formulation_id"], name=d["name"], dosage_form=DosageForm(d["dosage_form"]),
        basis=Basis(d["basis"]), revision=int(d.get("revision", 1)), family=d.get("family"),
        target_batch_size=Quantity.from_dict(d["target_batch_size"]),
        ingredients=tuple(Ingredient(material_id=i["material_id"], material_version=int(i.get("material_version", 1)),
                                     role=Role(i["role"]), amount=Quantity.from_dict(i["amount"]), lot=i.get("lot"),
                                     group=i.get("group")) for i in d["ingredients"]),
        stages=tuple(ProcessStage(order=int(s["order"]), name=s["name"], equipment_id=s.get("equipment_id"),
                                  parameters={k: Quantity.from_dict(v) for k, v in (s.get("parameters") or {}).items()},
                                  additions=tuple(s.get("additions") or ()),
                                  duration=Quantity.from_dict(s["duration"]) if s.get("duration") else None)
                     for s in d.get("stages", [])),
        targets=tuple(TargetProperty(**t) for t in d.get("targets", [])),
        evidence=tuple(d.get("evidence", [])),
        unit_count=d.get("unit_count"),
    )
