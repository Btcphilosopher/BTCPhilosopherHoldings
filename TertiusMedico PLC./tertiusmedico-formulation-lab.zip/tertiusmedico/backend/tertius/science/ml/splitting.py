"""Leakage-safe evaluation splits.

Rules
-----
1. Replicates and near-identical formulations (same composition and process
   within a tolerance) are merged into one *leakage group*; a leakage group is
   never split between train and test.
2. The user-chosen grouping (formulation family, batch, material lot, project)
   is unioned with the leakage groups, so the final groups respect both.
3. ``time`` splits put everything measured on or after the cutoff in the test
   set, and then move any leakage group that straddles the cutoff wholly into
   the *test* set (so training never sees a replicate of a test formulation).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold, GroupShuffleSplit


class _UnionFind:
    def __init__(self, n: int):
        self.p = list(range(n))

    def find(self, i: int) -> int:
        while self.p[i] != i:
            self.p[i] = self.p[self.p[i]]
            i = self.p[i]
        return i

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[rb] = ra


def near_duplicate_groups(df: pd.DataFrame, mixture_cols: list[str], process_cols: list[str],
                          mix_tol: float = 0.005, proc_rel_tol: float = 0.02) -> np.ndarray:
    """Group rows whose compositions differ by ≤ mix_tol (max abs fraction) and process settings by ≤ proc_rel_tol
    of each variable's observed range."""
    M = df[mixture_cols].to_numpy(float)
    P = df[process_cols].to_numpy(float) if process_cols else np.zeros((len(df), 0))
    rng = P.max(axis=0) - P.min(axis=0) if len(P) else np.zeros(0)
    rng = np.where(rng > 0, rng, 1.0)
    uf = _UnionFind(len(df))
    for i in range(len(df)):
        dm = np.max(np.abs(M[i + 1:] - M[i]), axis=1) if i + 1 < len(df) else np.zeros(0)
        dp = np.max(np.abs(P[i + 1:] - P[i]) / rng, axis=1) if P.shape[1] and i + 1 < len(df) else np.zeros_like(dm)
        for j in np.where((dm <= mix_tol) & (dp <= proc_rel_tol))[0]:
            uf.union(i, i + 1 + int(j))
    return np.array([uf.find(i) for i in range(len(df))])


def leakage_safe_groups(df: pd.DataFrame, by: str | None, mixture_cols: list[str], process_cols: list[str],
                        **tol) -> np.ndarray:
    nd = near_duplicate_groups(df, mixture_cols, process_cols, **tol)
    uf = _UnionFind(len(df))
    keys = [nd]
    if "replicate_group" in df.columns:
        keys.append(pd.factorize(df["replicate_group"])[0])
    if by and by != "time":
        if by not in df.columns:
            raise KeyError(f"split column {by!r} not in data")
        keys.append(pd.factorize(df[by])[0])
    for k in keys:
        first: dict = {}
        for i, g in enumerate(k):
            if g in first:
                uf.union(first[g], i)
            else:
                first[g] = i
    return pd.factorize(np.array([uf.find(i) for i in range(len(df))]))[0]


def grouped_split(groups: np.ndarray, test_fraction: float, seed: int) -> tuple[np.ndarray, np.ndarray]:
    gss = GroupShuffleSplit(n_splits=1, test_size=test_fraction, random_state=seed)
    tr, te = next(gss.split(np.zeros(len(groups)), groups=groups))
    return np.sort(tr), np.sort(te)


def time_split(dates: pd.Series, groups: np.ndarray, cutoff: str) -> tuple[np.ndarray, np.ndarray]:
    d = pd.to_datetime(dates).to_numpy()
    test = d >= np.datetime64(pd.Timestamp(cutoff))
    test_groups = set(groups[test])
    test = np.isin(groups, list(test_groups))
    return np.where(~test)[0], np.where(test)[0]


def assert_no_leakage(train_idx: np.ndarray, test_idx: np.ndarray, groups: np.ndarray) -> None:
    overlap = set(groups[train_idx]) & set(groups[test_idx])
    if overlap:
        raise AssertionError(f"leakage: {len(overlap)} groups appear in both train and test")


def inner_group_folds(groups: np.ndarray, n_splits: int = 5):
    n = min(n_splits, len(np.unique(groups)))
    if n < 2:
        raise ValueError("need at least two groups for grouped cross-validation")
    return list(GroupKFold(n_splits=n).split(np.zeros(len(groups)), groups=groups))
