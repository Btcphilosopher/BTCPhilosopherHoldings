"""Feature construction for mixture + process data.

Compositional data
------------------
Mixture fractions live on the simplex. Two representations are supported:

* ``scheffe2`` (default): Scheffé quadratic terms x_i and x_i·x_j, **no
  intercept** (Σx = 1 already plays that role). Valid with structural zeros.
* ``ilr``: isometric log-ratio coordinates (Egozcue et al. 2003). Logarithms of
  zero are undefined, so zeros are handled *explicitly* by ``zero_policy``:

  - ``"error"`` (default) – refuse to transform compositions containing zeros;
  - ``"multiplicative_replacement"`` – for *rounded* zeros / below-detection
    values only (Martín-Fernández et al. 2003): zeros become δ and non-zero parts
    are shrunk multiplicatively so the total is preserved. Not valid for
    structural zeros (an ingredient deliberately absent).

Process variables are standardised with statistics learned on the training
fold only (the transformer is fitted inside the training pipeline).
"""

from __future__ import annotations

import itertools

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin


def closure(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, float)
    return X / X.sum(axis=1, keepdims=True)


def multiplicative_replacement(X: np.ndarray, delta: float) -> np.ndarray:
    X = closure(X)
    z = X <= 0
    nz = z.sum(axis=1, keepdims=True)
    out = np.where(z, delta, X * (1 - nz * delta))
    if np.any(out <= 0):
        raise ValueError("delta too large for the number of zeros")
    return out


def helmert_basis(D: int) -> np.ndarray:
    """Orthonormal (D−1)×D contrast matrix for ilr."""
    V = np.zeros((D - 1, D))
    for i in range(1, D):
        V[i - 1, :i] = 1.0 / i
        V[i - 1, i] = -1.0
        V[i - 1] *= np.sqrt(i / (i + 1))
    return V


def ilr(X: np.ndarray, zero_policy: str = "error", delta: float = 1e-4) -> np.ndarray:
    X = np.asarray(X, float)
    if np.any(X < 0):
        raise ValueError("negative fractions are not compositions")
    if np.any(X == 0):
        if zero_policy == "error":
            raise ValueError("composition contains zeros; log-ratio transform undefined. Use zero_policy="
                             "'multiplicative_replacement' only for rounded/below-detection zeros, or the "
                             "'scheffe2' representation for structural zeros")
        if zero_policy == "multiplicative_replacement":
            X = multiplicative_replacement(X, delta)
        else:
            raise ValueError(f"unknown zero_policy {zero_policy}")
    L = np.log(closure(X))
    clr = L - L.mean(axis=1, keepdims=True)
    return clr @ helmert_basis(X.shape[1]).T


class MixtureProcessFeatures(BaseEstimator, TransformerMixin):
    """Column layout: [mixture features…, standardised process features…]."""

    def __init__(self, n_mixture: int, representation: str = "scheffe2", zero_policy: str = "error",
                 process_quadratic: bool = False):
        self.n_mixture = n_mixture
        self.representation = representation
        self.zero_policy = zero_policy
        self.process_quadratic = process_quadratic

    def fit(self, X, y=None):
        X = np.asarray(X, float)
        P = X[:, self.n_mixture:]
        self.mu_ = P.mean(axis=0) if P.shape[1] else np.zeros(0)
        sd = P.std(axis=0) if P.shape[1] else np.zeros(0)
        self.sd_ = np.where(sd > 0, sd, 1.0)
        return self

    def transform(self, X):
        X = np.asarray(X, float)
        M, P = X[:, : self.n_mixture], X[:, self.n_mixture:]
        if self.representation == "scheffe2":
            cols = [M] + [(M[:, i] * M[:, j])[:, None] for i, j in itertools.combinations(range(M.shape[1]), 2)]
            mf = np.hstack(cols)
        elif self.representation == "raw":
            mf = M
        elif self.representation == "ilr":
            mf = ilr(M, self.zero_policy)
        else:
            raise ValueError(self.representation)
        Pz = (P - self.mu_) / self.sd_
        parts = [mf, Pz]
        if self.process_quadratic and Pz.shape[1]:
            parts.append(Pz ** 2)
        return np.hstack(parts)
