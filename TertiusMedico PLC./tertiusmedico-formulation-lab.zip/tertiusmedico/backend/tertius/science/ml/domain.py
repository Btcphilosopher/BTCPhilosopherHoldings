"""Applicability domain and abstention.

A prediction is only offered when the candidate is supported by the training
data. Flags:

* ``out_of_research_domain`` – violates the configured research domain (hard).
* ``extrapolation`` / ``excessive_extrapolation`` – a feature lies outside the
  training range (excessive: by more than ``max_extrapolation`` of that range).
* ``sparse_support`` – distance to the k-th nearest training point exceeds the
  95th percentile of leave-one-out k-NN distances within the training set.
* ``unseen_combination`` – the set of present ingredients never occurred in
  training.
* ``missing_critical_properties`` – a property the model needs is not
  recorded for an ingredient.
* ``conflicting_measurements`` – the nearest neighbours include replicate
  groups flagged for conflicting measurements.

Abstention rule (configurable): abstain on out-of-research-domain, excessive
extrapolation, missing critical properties, or sparse support combined with an
unseen ingredient combination.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class DomainAssessment:
    flags: list[str]
    abstain: bool
    reasons: list[str]
    knn_distance: float
    knn_threshold: float
    neighbours: list[int]
    neighbour_distances: list[float]
    extrapolation: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return self.__dict__.copy()


class ApplicabilityDomain:
    def __init__(self, k: int = 3, max_extrapolation: float = 0.10, presence_threshold: float = 1e-6):
        self.k = k
        self.max_extrapolation = max_extrapolation
        self.presence_threshold = presence_threshold

    def fit(self, X: np.ndarray, feature_names: list[str], n_mixture: int, conflicting_rows: np.ndarray | None = None):
        X = np.asarray(X, float)
        self.names_ = list(feature_names)
        self.n_mixture_ = n_mixture
        self.min_, self.max_ = X.min(axis=0), X.max(axis=0)
        rng = self.max_ - self.min_
        self.range_ = np.where(rng > 0, rng, 1.0)
        self.Z_ = (X - self.min_) / self.range_
        D = np.linalg.norm(self.Z_[:, None, :] - self.Z_[None, :, :], axis=2)
        np.fill_diagonal(D, np.inf)
        # exclude exact duplicates (replicates) from LOO distances so threshold reflects distinct support
        D[D < 1e-12] = np.inf
        kk = min(self.k, max(1, len(X) - 1))
        loo = np.sort(D, axis=1)[:, kk - 1]
        loo = loo[np.isfinite(loo)]
        self.threshold_ = float(np.quantile(loo, 0.95)) if len(loo) else np.inf
        self.patterns_ = {tuple((X[i, :n_mixture] > self.presence_threshold).astype(int)) for i in range(len(X))}
        self.conflicting_ = np.zeros(len(X), bool) if conflicting_rows is None else np.asarray(conflicting_rows, bool)
        return self

    def assess(self, x: np.ndarray, research_domain_ok: bool = True, missing_properties: list[str] | None = None
               ) -> DomainAssessment:
        x = np.asarray(x, float)
        flags, reasons = [], []
        if not research_domain_ok:
            flags.append("out_of_research_domain")
            reasons.append("candidate violates the configured research domain")
        below = (self.min_ - x) / self.range_
        above = (x - self.max_) / self.range_
        excess = np.maximum(below, above)
        ext = {self.names_[i]: float(excess[i]) for i in range(len(x)) if excess[i] > 1e-9}
        if ext:
            flags.append("extrapolation")
            worst = max(ext.values())
            if worst > self.max_extrapolation:
                flags.append("excessive_extrapolation")
                reasons.append(f"extrapolates {worst:.0%} of the training range beyond the data "
                               f"({', '.join(k for k, v in ext.items() if v > self.max_extrapolation)})")
        z = (x - self.min_) / self.range_
        d = np.linalg.norm(self.Z_ - z, axis=1)
        order = np.argsort(d)
        # distinct neighbours (skip exact replicate duplicates when computing kNN distance)
        distinct, seen = [], []
        for i in order:
            if any(np.allclose(self.Z_[i], self.Z_[j]) for j in seen):
                continue
            seen.append(i); distinct.append(i)
            if len(distinct) >= self.k:
                break
        kd = float(d[distinct[-1]]) if distinct else np.inf
        if kd > self.threshold_:
            flags.append("sparse_support")
        pattern = tuple((x[: self.n_mixture_] > self.presence_threshold).astype(int))
        if pattern not in self.patterns_:
            flags.append("unseen_combination")
        if missing_properties:
            flags.append("missing_critical_properties")
            reasons.append(f"missing properties: {', '.join(missing_properties)}")
        nb = [int(i) for i in order[:5]]
        if self.conflicting_[nb].any():
            flags.append("conflicting_measurements")
        if "sparse_support" in flags and "unseen_combination" in flags:
            reasons.append("sparse experimental support for an ingredient combination never tested")
        abstain = bool(reasons)
        return DomainAssessment(flags, abstain, reasons, kd, self.threshold_, nb, [float(d[i]) for i in nb], ext)
