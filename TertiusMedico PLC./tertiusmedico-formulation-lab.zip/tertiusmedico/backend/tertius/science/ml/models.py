"""Baseline → regularised → tree → Gaussian-process regressors with uncertainty.

Uncertainty methods (per model)
-------------------------------
* ``mean`` / ``scheffe_ridge``: *grouped CV+-style conformal* intervals — the
  (1−α)(1+1/n) quantile of absolute out-of-fold residuals from grouped
  cross-validation **inside the training set**; constant width (in the
  modelling scale, e.g. log viscosity).
* ``random_forest``: *normalised* conformal intervals — out-of-fold residuals
  divided by the across-tree spread, so width adapts locally. The tree spread
  alone is *not* treated as a calibrated standard deviation.
* ``gaussian_process``: Matern-5/2 ARD kernel + WhiteKernel. The posterior
  splits into latent-function variance (model/epistemic uncertainty) and the
  fitted white-noise variance (measurement + preparation variability).
  Intervals use the GP predictive SD rescaled by a conformal factor estimated
  on grouped out-of-fold standardised residuals; the raw Gaussian interval is
  reported alongside for comparison.

All nominal levels are *targets*; actual coverage must be checked on held-out
data (see :mod:`tertius.science.ml.pipeline`). Nothing here is presented as a
validated probability.
"""

from __future__ import annotations

import math
import warnings
from dataclasses import dataclass

import numpy as np
from scipy.stats import norm
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.dummy import DummyRegressor
from sklearn.exceptions import ConvergenceWarning
from sklearn.ensemble import RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern, WhiteKernel
from sklearn.linear_model import LogisticRegression, RidgeCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .features import MixtureProcessFeatures
from .splitting import inner_group_folds


def conformal_quantile(scores: np.ndarray, alpha: float) -> float:
    """Split-conformal threshold: the ⌈(n+1)(1−α)⌉-th smallest score (∞ if that exceeds n)."""
    n = len(scores)
    k = math.ceil((n + 1) * (1 - alpha))
    if n == 0 or k > n:
        return math.inf
    return float(np.sort(np.asarray(scores, float))[k - 1])


@dataclass
class Prediction:
    mean: np.ndarray
    lower: np.ndarray
    upper: np.ndarray
    model_sd: np.ndarray | None = None  # epistemic (GP latent) – modelling scale
    noise_sd: float | None = None  # aleatoric estimate – modelling scale


class UncertainRegressor:
    name = "base"
    family = "base"

    def __init__(self, n_mixture: int, seed: int = 0):
        self.n_mixture = n_mixture
        self.seed = seed

    # -- to implement
    def _make(self):
        raise NotImplementedError

    def _spread(self, est, X) -> np.ndarray:
        return np.ones(len(X))

    # -- common
    def fit(self, X: np.ndarray, y: np.ndarray, groups: np.ndarray, alpha: float = 0.1):
        self.alpha = alpha
        self.est_ = self._make().fit(X, y)
        scores, oof = [], np.full(len(y), np.nan)
        for tr, va in inner_group_folds(groups):
            e = self._make().fit(X[tr], y[tr])
            p = e.predict(X[va])
            oof[va] = p
            scores.append(np.abs(y[va] - p) / self._spread(e, X[va]))
        self.oof_pred_ = oof
        self.cv_mae_ = float(np.nanmean(np.abs(y - oof)))
        self.cv_scores_ = np.concatenate(scores)
        self.q_ = conformal_quantile(self.cv_scores_, alpha)
        return self

    def predict(self, X: np.ndarray, alpha: float | None = None) -> Prediction:
        alpha = self.alpha if alpha is None else alpha
        q = conformal_quantile(self.cv_scores_, alpha)
        m = self.est_.predict(X)
        w = q * self._spread(self.est_, X)
        return Prediction(m, m - w, m + w)

    def describe(self) -> dict:
        return {"name": self.name, "family": self.family, "cv_mae_model_scale": self.cv_mae_,
                "uncertainty_method": self.uncertainty_method}


class MeanBaseline(UncertainRegressor):
    name, family = "mean_baseline", "baseline"
    uncertainty_method = "grouped CV conformal, constant width"

    def _make(self):
        return DummyRegressor(strategy="mean")


class ScheffeRidge(UncertainRegressor):
    name, family = "scheffe_ridge", "regularised_regression"
    uncertainty_method = "grouped CV conformal, constant width"

    def _make(self):
        # Scheffé quadratic blending terms + linear process terms, standardised (fitted on the training fold),
        # ridge with intercept: the Σx = 1 collinearity is absorbed by the penalty. Chosen over the unscaled,
        # no-intercept form because it gave lower grouped-CV error on the demo data (see docs/scientific_notes.md);
        # coefficients are for prediction, not for reading off Scheffé blending effects.
        return Pipeline([("f", MixtureProcessFeatures(self.n_mixture, "scheffe2")), ("s", StandardScaler()),
                         ("m", RidgeCV(alphas=np.logspace(-4, 3, 40)))])


class Forest(UncertainRegressor):
    name, family = "random_forest", "tree_ensemble"
    uncertainty_method = "normalised grouped CV conformal (residual / tree spread)"

    def _make(self):
        return Pipeline([("f", MixtureProcessFeatures(self.n_mixture, "raw")),
                         ("m", RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=self.seed,
                                                     n_jobs=1))])

    def _spread(self, est, X):
        f = est.named_steps["f"].transform(X)
        trees = np.stack([t.predict(f) for t in est.named_steps["m"].estimators_])
        return trees.std(axis=0) + 1e-3


class GaussianProcess(UncertainRegressor):
    name, family = "gaussian_process", "gaussian_process"
    uncertainty_method = "GP predictive SD × grouped-CV conformal factor; latent vs noise variance reported"

    def _make(self):
        # dims: q mixture fractions + p standardised process variables
        return Pipeline([("f", MixtureProcessFeatures(self.n_mixture, "raw")),
                         ("m", _GP(self.seed))])

    def _spread(self, est, X):
        f = est.named_steps["f"].transform(X)
        _, sd = est.named_steps["m"].predict(f, return_std=True)
        return np.maximum(sd, 1e-6)

    def predict(self, X, alpha=None) -> Prediction:
        alpha = self.alpha if alpha is None else alpha
        f = self.est_.named_steps["f"].transform(X)
        gp = self.est_.named_steps["m"]
        m, sd = gp.predict(f, return_std=True)
        noise = gp.noise_sd
        latent = np.sqrt(np.maximum(sd ** 2 - noise ** 2, 0.0))
        q = conformal_quantile(self.cv_scores_, alpha)
        return Prediction(m, m - q * sd, m + q * sd, model_sd=latent, noise_sd=noise)

    def raw_gaussian_interval(self, X, alpha=None):
        alpha = self.alpha if alpha is None else alpha
        f = self.est_.named_steps["f"].transform(X)
        m, sd = self.est_.named_steps["m"].predict(f, return_std=True)
        z = norm.ppf(1 - alpha / 2)
        return m - z * sd, m + z * sd

    def describe(self) -> dict:
        d = super().describe()
        gp = self.est_.named_steps["m"]
        d.update({"kernel": str(gp.gpr_.kernel_), "noise_sd_model_scale": gp.noise_sd,
                  "conformal_factor": self.q_, "fit_warnings": gp.fit_warnings_})
        return d


class _GP(RegressorMixin, BaseEstimator):
    """Thin sklearn-compatible wrapper exposing the fitted white-noise SD."""

    def __init__(self, seed: int = 0):
        self.seed = seed

    def fit(self, X, y):
        d = X.shape[1]
        kernel = (ConstantKernel(1.0, (1e-3, 1e3)) * Matern(length_scale=np.ones(d), length_scale_bounds=(1e-2, 1e4),
                                                             nu=2.5)
                  + WhiteKernel(noise_level=0.01, noise_level_bounds=(1e-6, 1.0)))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always", ConvergenceWarning)
            self.gpr_ = GaussianProcessRegressor(kernel=kernel, normalize_y=True, n_restarts_optimizer=3,
                                                 random_state=self.seed).fit(X, y)
        # length scales at the upper bound mean the GP found that input nearly irrelevant; recorded, not hidden
        self.fit_warnings_ = sorted({str(w.message).split(" is close")[0] for w in caught})
        k = self.gpr_.kernel_
        # normalize_y scales targets; white noise level is in normalised units
        self.noise_sd = float(math.sqrt(k.k2.noise_level) * self.gpr_._y_train_std)
        return self

    def predict(self, X, return_std=False):
        if return_std:
            m, sd = self.gpr_.predict(X, return_std=True)
            return m, sd
        return self.gpr_.predict(X)


REGRESSORS = {c.name: c for c in (MeanBaseline, ScheffeRidge, Forest, GaussianProcess)}


# ---------------------------------------------------------------------------------------------
# Classification (phase separation) — probabilities are reported with their measured calibration
# ---------------------------------------------------------------------------------------------
class PrevalenceBaseline:
    name = "prevalence_baseline"

    def fit(self, X, y):
        self.p_ = float(np.mean(y))
        return self

    def predict_proba(self, X):
        return np.full(len(X), self.p_)


class LogisticScheffe:
    name = "logistic_scheffe"

    def __init__(self, n_mixture: int):
        self.n_mixture = n_mixture

    def fit(self, X, y):
        self.est_ = Pipeline([("f", MixtureProcessFeatures(self.n_mixture, "scheffe2")),
                              ("m", LogisticRegression(C=1.0, max_iter=2000, fit_intercept=False))]).fit(X, y)
        return self

    def predict_proba(self, X):
        return self.est_.predict_proba(X)[:, 1]


def expected_calibration_error(y: np.ndarray, p: np.ndarray, bins: int = 10) -> float:
    edges = np.linspace(0, 1, bins + 1)
    ece = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (p >= lo) & (p < hi if hi < 1 else p <= hi)
        if m.any():
            ece += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(ece)
