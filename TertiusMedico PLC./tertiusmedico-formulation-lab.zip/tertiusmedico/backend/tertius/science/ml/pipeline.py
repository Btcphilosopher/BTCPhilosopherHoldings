"""Reproducible training/evaluation pipeline.

Every run records a manifest with: dataset SHA-256 (canonical CSV of the exact
rows used), configuration, seed, library versions, the explicit list of
excluded observations and why, split membership, inner-CV model selection
(training data only), held-out metrics, interval coverage at several nominal
levels, and repeatability estimates. The manifest hash covers all of this and
excludes timestamps, so identical inputs give an identical hash.
"""

from __future__ import annotations

import hashlib
import json
import platform
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
import scipy
import sklearn

from ..quality import TargetSpec, pooled_replicate_sd
from .domain import ApplicabilityDomain
from .models import (REGRESSORS, LogisticScheffe, PrevalenceBaseline, UncertainRegressor,
                     expected_calibration_error)
from .splitting import assert_no_leakage, grouped_split, inner_group_folds, leakage_safe_groups, time_split

CODE_VERSION = "0.1.0"


@dataclass
class TrainingConfig:
    target: TargetSpec
    mixture_cols: list[str]
    process_cols: list[str]
    split_by: str | None = "batch_id"  # any grouping column, "time", or None (replicate/near-duplicate only)
    time_cutoff: str | None = None
    test_fraction: float = 0.25
    seed: int = 7
    alpha: float = 0.10
    models: tuple[str, ...] = ("mean_baseline", "scheffe_ridge", "random_forest", "gaussian_process")
    coverage_levels: tuple[float, ...] = (0.5, 0.8, 0.9, 0.95)
    prediction_horizon: str = ""
    supported_domain: str = ""

    def as_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "target"}
        d["target"] = self.target.as_dict()
        d["models"] = list(self.models)
        d["coverage_levels"] = list(self.coverage_levels)
        return d


def dataset_hash(df: pd.DataFrame) -> str:
    canon = df.sort_values("measurement_id").reset_index(drop=True)
    canon = canon.reindex(sorted(canon.columns), axis=1)
    return hashlib.sha256(canon.to_csv(index=False, float_format="%.10g").encode()).hexdigest()


def _versions() -> dict:
    return {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
            "scipy": scipy.__version__, "scikit-learn": sklearn.__version__, "tertius": CODE_VERSION}


def _to_model_scale(y: np.ndarray, spec: TargetSpec) -> np.ndarray:
    return np.log(y) if spec.log_transform else y


def _from_model_scale(y: np.ndarray, spec: TargetSpec) -> np.ndarray:
    return np.exp(y) if spec.log_transform else y


@dataclass
class TrainingResult:
    manifest: dict
    models: dict[str, Any]
    selected: str
    domain: ApplicabilityDomain
    feature_names: list[str]
    test_predictions: pd.DataFrame
    train_frame: pd.DataFrame = field(repr=False, default=None)

    @property
    def manifest_hash(self) -> str:
        return self.manifest["manifest_sha256"]


def prepare(df: pd.DataFrame, config: TrainingConfig) -> tuple[pd.DataFrame, list[dict]]:
    t = df[df["target"] == config.target.name].copy()
    exclusions = []
    for status, reason in (("failed", "failed experiment – no valid measurement"),
                           ("censored", "censored (below detection limit) – excluded from regression, retained in record")):
        sub = t[t["status"] == status]
        if len(sub):
            exclusions.append({"status": status, "count": int(len(sub)), "reason": reason,
                               "measurement_ids": sub["measurement_id"].tolist(),
                               "failure_reasons": sub.get("failure_reason", pd.Series(dtype=object)).dropna()
                               .value_counts().to_dict()})
    used = t[t["status"] == "ok"].copy()
    if config.target.log_transform and (used["value"] <= 0).any():
        raise ValueError("log transform requested but non-positive values present")
    return used.reset_index(drop=True), exclusions


def train_and_evaluate(df: pd.DataFrame, config: TrainingConfig) -> TrainingResult:
    if config.target.kind == "classification":
        return train_classifier(df, config)
    data, exclusions = prepare(df, config)
    if len(data) < 12:
        raise ValueError(f"only {len(data)} usable observations for {config.target.name}; refusing to train")
    cols = config.mixture_cols + config.process_cols
    X = data[cols].to_numpy(float)
    y_raw = data["value"].to_numpy(float)
    y = _to_model_scale(y_raw, config.target)

    groups = leakage_safe_groups(data, None if config.split_by == "time" else config.split_by,
                                 config.mixture_cols, config.process_cols)
    if config.split_by == "time":
        if not config.time_cutoff:
            raise ValueError("time split requires time_cutoff")
        tr, te = time_split(data["measured_on"], groups, config.time_cutoff)
    else:
        tr, te = grouped_split(groups, config.test_fraction, config.seed)
    assert_no_leakage(tr, te, groups)
    if len(np.unique(groups[tr])) < 3 or len(te) == 0:
        raise ValueError("not enough independent groups for a held-out evaluation")

    rep = pooled_replicate_sd(data.iloc[tr].assign(status="ok"), config.target.name, config.target.log_transform)

    results, fitted, test_rows = {}, {}, {"measurement_id": data["measurement_id"].iloc[te].tolist(),
                                          "observed": y_raw[te].tolist()}
    n_mix = len(config.mixture_cols)
    for name in config.models:
        m: UncertainRegressor = REGRESSORS[name](n_mix, config.seed)
        m.fit(X[tr], y[tr], groups[tr], config.alpha)
        pred = m.predict(X[te])
        cov = {}
        for lvl in config.coverage_levels:
            p = m.predict(X[te], alpha=1 - lvl)
            inside = (y[te] >= p.lower) & (y[te] <= p.upper)
            cov[f"{lvl:.2f}"] = {"nominal": lvl, "empirical": float(inside.mean()),
                                 "mean_width_model_scale": float(np.mean(p.upper - p.lower))}
        mean_o = _from_model_scale(pred.mean, config.target)
        err = mean_o - y_raw[te]
        metrics = {"mae": float(np.mean(np.abs(err))), "rmse": float(np.sqrt(np.mean(err ** 2))),
                   "mae_model_scale": float(np.mean(np.abs(pred.mean - y[te]))),
                   "r2_model_scale": float(1 - np.sum((pred.mean - y[te]) ** 2) / np.sum((y[te] - y[te].mean()) ** 2)),
                   "n_test": int(len(te))}
        info = m.describe()
        if name == "gaussian_process":
            lo, hi = m.raw_gaussian_interval(X[te], alpha=config.alpha)
            info["raw_gaussian_coverage_at_nominal"] = float(np.mean((y[te] >= lo) & (y[te] <= hi)))
        results[name] = {"inner_cv_mae_model_scale": m.cv_mae_, "test": metrics, "coverage": cov, "model": info}
        fitted[name] = m
        test_rows[f"{name}_mean"] = mean_o.tolist()
        test_rows[f"{name}_lower"] = _from_model_scale(pred.lower, config.target).tolist()
        test_rows[f"{name}_upper"] = _from_model_scale(pred.upper, config.target).tolist()

    # selection uses training-only inner CV; held-out metrics are reported, never used to choose
    selected = min(results, key=lambda k: results[k]["inner_cv_mae_model_scale"])
    baseline_cv = results.get("mean_baseline", {}).get("inner_cv_mae_model_scale")
    warnings = []
    if baseline_cv is not None and results[selected]["inner_cv_mae_model_scale"] > 0.9 * baseline_cv:
        warnings.append("selected model improves on the mean baseline by < 10% in inner CV")
    sel_cov = results[selected]["coverage"][f"{1 - config.alpha:.2f}"]["empirical"] if \
        f"{1 - config.alpha:.2f}" in results[selected]["coverage"] else None
    if sel_cov is not None and sel_cov < (1 - config.alpha) - 0.1:
        warnings.append(f"held-out coverage {sel_cov:.2f} is well below nominal {1 - config.alpha:.2f}: intervals "
                        "are over-confident on this split")
    if len(te) < 30:
        warnings.append(f"held-out set has only {len(te)} observations; coverage estimates are imprecise "
                        f"(±{1.96 * np.sqrt(0.09 / max(len(te), 1)):.2f} at 90%)")

    domain = ApplicabilityDomain().fit(X[tr], cols, n_mix)
    gp_noise = results.get("gaussian_process", {}).get("model", {}).get("noise_sd_model_scale")
    manifest = {
        "kind": "regression",
        "config": config.as_dict(),
        "dataset_sha256": dataset_hash(df[df["target"] == config.target.name]),
        "n_rows_target": int((df["target"] == config.target.name).sum()),
        "n_used": int(len(data)), "exclusions": exclusions,
        "split": {"method": config.split_by, "n_train": int(len(tr)), "n_test": int(len(te)),
                  "n_groups_train": int(len(np.unique(groups[tr]))), "n_groups_test": int(len(np.unique(groups[te]))),
                  "train_ids_sha256": hashlib.sha256(",".join(data["measurement_id"].iloc[tr]).encode()).hexdigest(),
                  "test_ids_sha256": hashlib.sha256(",".join(data["measurement_id"].iloc[te]).encode()).hexdigest(),
                  "leakage_check": "passed: no leakage group (replicates/near-duplicates/split key) in both sets"},
        "results": results, "selected_model": selected,
        "selection_rule": "lowest grouped inner-CV MAE on the training set (test set not used for selection)",
        "variability": {"pooled_replicate_sd_model_scale": rep, "gp_noise_sd_model_scale": gp_noise,
                        "note": "replicate SD estimates measurement+preparation repeatability; GP noise is a model "
                                "estimate of the same quantity; latent GP SD is model (epistemic) uncertainty"},
        "applicability_domain": {"k": domain.k, "knn_threshold": domain.threshold_,
                                 "max_extrapolation": domain.max_extrapolation,
                                 "patterns_seen": [list(p) for p in sorted(domain.patterns_)]},
        "warnings": warnings,
        "claims": "Predicts a laboratory measurement within the supported domain only. Does not establish efficacy, "
                  "bioavailability, patient safety or manufacturing suitability.",
        "versions": _versions(),
    }
    manifest["manifest_sha256"] = hashlib.sha256(json.dumps(manifest, sort_keys=True, default=str).encode()).hexdigest()
    return TrainingResult(manifest, fitted, selected, domain, cols, pd.DataFrame(test_rows), data.iloc[tr])


def train_classifier(df: pd.DataFrame, config: TrainingConfig) -> TrainingResult:
    t = df[(df["target"] == config.target.name) & (df["status"] == "ok")].reset_index(drop=True)
    cols = config.mixture_cols + config.process_cols
    X = t[cols].to_numpy(float); y = t["value"].to_numpy(int)
    groups = leakage_safe_groups(t, config.split_by if config.split_by != "time" else None,
                                 config.mixture_cols, config.process_cols)
    tr, te = grouped_split(groups, config.test_fraction, config.seed)
    assert_no_leakage(tr, te, groups)
    out, fitted = {}, {}
    folds = inner_group_folds(groups[tr])
    for make in (PrevalenceBaseline, lambda: LogisticScheffe(len(config.mixture_cols))):
        m = make()
        # inner grouped CV on the training set only → used for selection
        oof = np.full(len(tr), np.nan)
        for a, b in folds:
            ytr = y[tr][a]
            if len(np.unique(ytr)) < 2:
                oof[b] = ytr.mean()
                continue
            oof[b] = make().fit(X[tr][a], ytr).predict_proba(X[tr][b])
        m.fit(X[tr], y[tr])
        p = m.predict_proba(X[te])
        eps = 1e-12
        out[m.name] = {"inner_cv_brier": float(np.mean((oof - y[tr]) ** 2)),
                       "brier": float(np.mean((p - y[te]) ** 2)),
                       "log_loss": float(-np.mean(y[te] * np.log(p + eps) + (1 - y[te]) * np.log(1 - p + eps))),
                       "ece_10bin": expected_calibration_error(y[te], p), "n_test": int(len(te)),
                       "n_events_test": int(y[te].sum())}
        fitted[m.name] = m
    selected = min(out, key=lambda k: out[k]["inner_cv_brier"])
    domain = ApplicabilityDomain().fit(X[tr], cols, len(config.mixture_cols))
    n_ev = int(y[te].sum())
    manifest = {
        "kind": "classification", "config": config.as_dict(),
        "dataset_sha256": dataset_hash(df[df["target"] == config.target.name]),
        "n_used": int(len(t)), "exclusions": [],
        "split": {"method": config.split_by, "n_train": int(len(tr)), "n_test": int(len(te))},
        "results": out, "selected_model": selected,
        "selection_rule": "lowest grouped inner-CV Brier score on the training set (test set not used for selection)",
        "calibration_status": ("UNVALIDATED: fewer than 100 held-out observations or 20 events; outputs are scores "
                               "for ranking, not reliable probabilities") if len(te) < 100 or n_ev < 20 else
                              "calibration evaluated on held-out data (see ece_10bin)",
        "warnings": [], "versions": _versions(),
    }
    manifest["manifest_sha256"] = hashlib.sha256(json.dumps(manifest, sort_keys=True, default=str).encode()).hexdigest()
    return TrainingResult(manifest, fitted, selected, domain, cols, pd.DataFrame(), t.iloc[tr])


def save_artifact(result: TrainingResult, directory: str | Path) -> dict:
    d = Path(directory); d.mkdir(parents=True, exist_ok=True)
    model_path = d / f"model_{result.manifest_hash[:12]}.joblib"
    joblib.dump(artifact_payload(result), model_path)
    blob = model_path.read_bytes()
    man = dict(result.manifest, artifact_file=model_path.name, artifact_sha256=hashlib.sha256(blob).hexdigest())
    (d / f"manifest_{result.manifest_hash[:12]}.json").write_text(json.dumps(man, indent=2, default=str))
    return man


def artifact_payload(result: TrainingResult) -> dict:
    return {"models": result.models, "selected": result.selected, "domain": result.domain,
            "feature_names": result.feature_names, "manifest": result.manifest,
            "train_frame": result.train_frame, "test_predictions": result.test_predictions}


def result_from_payload(d: dict) -> TrainingResult:
    return TrainingResult(d["manifest"], d["models"], d["selected"], d["domain"], d["feature_names"],
                          d.get("test_predictions", pd.DataFrame()), d.get("train_frame"))


def load_artifact(path: str | Path) -> TrainingResult:
    return result_from_payload(joblib.load(path))


@dataclass
class ModelBundle:
    """Selected models for each target, used by the recommender."""
    results: dict[str, TrainingResult]

    def predict(self, target: str, X: np.ndarray, alpha: float = 0.1) -> dict:
        r = self.results[target]
        spec = TargetSpec(**r.manifest["config"]["target"])
        if spec.kind == "classification":
            p = r.models[r.selected].predict_proba(X)
            return {"score": p, "kind": "classification", "calibration_status": r.manifest["calibration_status"]}
        m = r.models[r.selected]
        p = m.predict(X, alpha)
        return {"mean": _from_model_scale(p.mean, spec), "lower": _from_model_scale(p.lower, spec),
                "upper": _from_model_scale(p.upper, spec), "unit": spec.unit, "model": r.selected,
                "model_sd": p.model_sd, "noise_sd": p.noise_sd, "scale": "log" if spec.log_transform else "linear",
                "kind": "regression"}
