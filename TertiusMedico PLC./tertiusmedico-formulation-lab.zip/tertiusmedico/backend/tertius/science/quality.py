"""Measurement data-quality validation.

Findings never delete data. Failed and censored observations stay in the table
with explicit status columns; downstream code decides — and records — how they
are used.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
import pandas as pd

from .units import UnitParseError, dimension_of


@dataclass(frozen=True)
class TargetSpec:
    """Definition of a measured/predicted property."""
    name: str
    unit: str
    method: str
    horizon: str  # when the property is measured, e.g. "at manufacture (t=0)"
    lower_bound: float | None = None  # physical bounds, not specification limits
    upper_bound: float | None = None
    log_transform: bool = False
    repeatability_cv_limit: float = 0.15  # replicate CV above which replicates are flagged as conflicting
    kind: str = "regression"  # "regression" | "classification"
    description: str = ""

    def as_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class Finding:
    severity: str  # "error" | "warning" | "info"
    code: str
    message: str
    rows: list

    def as_dict(self) -> dict:
        return {"severity": self.severity, "code": self.code, "message": self.message, "rows": self.rows}


REQUIRED_COLUMNS = ("measurement_id", "run_id", "target", "value", "unit", "status", "replicate_group", "batch_id",
                    "measured_on")


def validate_measurements(df: pd.DataFrame, targets: Mapping[str, TargetSpec],
                          instruments: Mapping[str, Mapping] | None = None,
                          mixture_cols: list[str] | None = None) -> list[Finding]:
    f: list[Finding] = []
    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        return [Finding("error", "missing_columns", f"missing required columns: {missing_cols}", [])]
    df = df.copy()
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    if "lod" in df.columns:
        df["lod"] = pd.to_numeric(df["lod"], errors="coerce")

    dup = df[df.duplicated("measurement_id", keep=False)]
    if len(dup):
        f.append(Finding("error", "duplicate_measurement_id", "measurement_id must be unique", dup.measurement_id.tolist()))

    # Units
    for t, g in df.groupby("target"):
        spec = targets.get(t)
        if spec is None:
            f.append(Finding("error", "unknown_target", f"target {t!r} has no TargetSpec (units/method undefined)",
                             g.measurement_id.tolist()))
            continue
        bad = []
        for mid, u in zip(g.measurement_id, g.unit):
            try:
                if dimension_of(u) != dimension_of(spec.unit):
                    bad.append(mid)
            except UnitParseError:
                bad.append(mid)
        if bad:
            f.append(Finding("error", "unit_mismatch", f"{t}: unit dimension differs from spec {spec.unit}", bad))

    # Missing values on rows that claim success
    ok = df["status"] == "ok"
    miss = df[ok & df["value"].isna()]
    if len(miss):
        f.append(Finding("error", "missing_value", "status 'ok' but no value", miss.measurement_id.tolist()))
    no_batch = df[df["batch_id"].isna() | (df["batch_id"].astype(str).str.len() == 0)]
    if len(no_batch):
        f.append(Finding("error", "missing_batch_id", "batch identifier missing", no_batch.measurement_id.tolist()))
    if "lot_ids" in df.columns:
        nolot = df[df["lot_ids"].isna()]
        if len(nolot):
            f.append(Finding("warning", "missing_lot_ids", "material lot identifiers missing", nolot.measurement_id.tolist()))
    if mixture_cols:
        comp = df[mixture_cols]
        if comp.isna().any(axis=1).any():
            f.append(Finding("error", "missing_composition", "mixture fractions missing",
                             df[comp.isna().any(axis=1)].measurement_id.tolist()))
        tot = comp.sum(axis=1)
        badtot = df[(tot - 1).abs() > 1e-6]
        if len(badtot):
            f.append(Finding("error", "composition_total", "mixture fractions do not sum to 1",
                             badtot.measurement_id.tolist()))

    # Bounds
    for t, g in df[ok].groupby("target"):
        spec = targets.get(t)
        if spec is None:
            continue
        v = g["value"]
        lo = g[v < spec.lower_bound] if spec.lower_bound is not None else g.iloc[0:0]
        hi = g[v > spec.upper_bound] if spec.upper_bound is not None else g.iloc[0:0]
        if len(lo) or len(hi):
            f.append(Finding("error", "out_of_physical_bounds",
                             f"{t}: values outside physical bounds [{spec.lower_bound}, {spec.upper_bound}]",
                             lo.measurement_id.tolist() + hi.measurement_id.tolist()))

    # Detection limits / censoring
    if "lod" in df.columns:
        below = df[ok & df["lod"].notna() & (df["value"] < df["lod"])]
        if len(below):
            f.append(Finding("error", "below_lod_not_censored",
                             "value below the limit of detection reported as 'ok'; must be status 'censored'",
                             below.measurement_id.tolist()))
    cens = df[df["status"] == "censored"]
    if len(cens):
        f.append(Finding("info", "censored", f"{len(cens)} censored observations retained and flagged",
                         cens.measurement_id.tolist()))
    failed = df[df["status"] == "failed"]
    if len(failed):
        f.append(Finding("info", "failed_runs", f"{len(failed)} failed observations retained and flagged",
                         failed.measurement_id.tolist()))
        if "failure_reason" in df.columns:
            nr = failed[failed["failure_reason"].isna()]
            if len(nr):
                f.append(Finding("warning", "failed_without_reason", "failed observations without a reason",
                                 nr.measurement_id.tolist()))

    # Replicate relationships: replicates must share target + composition + process
    for (rg, t), g in df.groupby(["replicate_group", "target"]):
        sig_cols = [c for c in df.columns if c.startswith("mix:") or c.startswith("proc:")]
        if sig_cols and len(g[sig_cols].round(9).drop_duplicates()) > 1:
            f.append(Finding("error", "replicate_mismatch",
                             f"replicate group {rg}/{t} has differing composition/process settings",
                             g.measurement_id.tolist()))
        gv = g[g["status"] == "ok"]["value"]
        spec = targets.get(t)
        if spec and spec.kind == "regression" and len(gv) >= 2 and gv.mean() != 0:
            cv = gv.std(ddof=1) / abs(gv.mean())
            if cv > spec.repeatability_cv_limit:
                f.append(Finding("warning", "conflicting_replicates",
                                 f"{rg}/{t}: replicate CV {cv:.2f} exceeds {spec.repeatability_cv_limit:.2f}",
                                 g.measurement_id.tolist()))

    # Calibration metadata
    if instruments is not None and "instrument_id" in df.columns:
        for inst, g in df.groupby("instrument_id"):
            meta = instruments.get(inst)
            if meta is None:
                f.append(Finding("warning", "instrument_unknown", f"instrument {inst} has no calibration record",
                                 g.measurement_id.tolist()))
                continue
            due = pd.Timestamp(meta["calibration_due"])
            late = g[pd.to_datetime(g["measured_on"]) > due]
            if len(late):
                f.append(Finding("error", "calibration_expired",
                                 f"{inst}: measured after calibration due date {due.date()}", late.measurement_id.tolist()))
    return f


def summarise(findings: list[Finding]) -> dict:
    return {
        "errors": sum(1 for x in findings if x.severity == "error"),
        "warnings": sum(1 for x in findings if x.severity == "warning"),
        "info": sum(1 for x in findings if x.severity == "info"),
        "codes": sorted({x.code for x in findings}),
    }


def pooled_replicate_sd(df: pd.DataFrame, target: str, log: bool = False) -> dict:
    """Pooled within-replicate-group SD (repeatability incl. preparation variability)."""
    g = df[(df["target"] == target) & (df["status"] == "ok")].copy()
    if log:
        g["value"] = np.log(g["value"])
    grp = g.groupby("replicate_group")["value"]
    n = grp.count(); var = grp.var(ddof=1)
    keep = n >= 2
    dof = int((n[keep] - 1).sum())
    if dof == 0:
        return {"sd": None, "dof": 0, "groups": 0, "scale": "log" if log else "linear"}
    pooled = float(np.sqrt(((n[keep] - 1) * var[keep]).sum() / dof))
    return {"sd": pooled, "dof": dof, "groups": int(keep.sum()), "scale": "log" if log else "linear"}
