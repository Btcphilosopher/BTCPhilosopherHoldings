"""Lineage graph: material lot → formulation revision → experiment → raw measurement → training dataset →
model → prediction → reviewed decision."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

CHAIN = ("material_lot", "formulation_revision", "experiment", "raw_measurement", "training_dataset", "model",
         "prediction", "reviewed_decision")


@dataclass(frozen=True)
class Node:
    kind: str
    ref: str
    label: str = ""
    content_hash: str | None = None

    @property
    def key(self) -> str:
        return f"{self.kind}:{self.ref}"


class LineageGraph:
    def __init__(self):
        self.nodes: dict[str, Node] = {}
        self.parents: dict[str, set[str]] = defaultdict(set)
        self.relations: dict[tuple[str, str], str] = {}

    def add(self, node: Node) -> Node:
        self.nodes[node.key] = node
        return node

    def link(self, parent: Node, child: Node, relation: str) -> None:
        self.add(parent); self.add(child)
        self.parents[child.key].add(parent.key)
        self.relations[(parent.key, child.key)] = relation

    def upstream(self, key: str) -> list[Node]:
        seen, order, stack = set(), [], [key]
        while stack:
            k = stack.pop()
            if k in seen:
                continue
            seen.add(k); order.append(self.nodes[k])
            stack.extend(sorted(self.parents.get(k, ())))
        return order

    def missing_links(self, key: str) -> list[str]:
        kinds = {n.kind for n in self.upstream(key)}
        start = CHAIN.index(self.nodes[key].kind)
        return [k for k in CHAIN[: start + 1] if k not in kinds]

    def edges(self) -> list[dict]:
        return [{"parent": p, "child": c, "relation": r} for (p, c), r in self.relations.items()]
