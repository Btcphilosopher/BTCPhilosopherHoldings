"""Service helpers bridging the database and the scientific core."""

from __future__ import annotations

import hashlib
import io
import json
from datetime import date, datetime
from decimal import Decimal
from typing import Iterable

import joblib
import numpy as np
import pandas as pd
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import get_settings
from .db.models import (Experiment, Material, MaterialVersion, Measurement, ModelRun, ResearchDomainRecord)
from .science.constraints import ResearchDomain
from .science.materials import MaterialRecord
from .science.ml.pipeline import ModelBundle, TrainingResult, artifact_payload, result_from_payload
from .science.optimisation.pareto import Objective
from .storage import get_storage


def content_hash(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()


def jsonable(obj):
    """Convert numpy/pandas objects to JSON-safe Python values (NaN → None)."""
    if isinstance(obj, dict):
        return {str(k): jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return jsonable(obj.tolist())
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating, float)):
        f = float(obj)
        return None if (np.isnan(f) or np.isinf(f)) else f
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, Decimal):
        return str(obj)
    return obj


def material_map(db: Session, project_id: int) -> dict[str, MaterialRecord]:
    out = {}
    for m in db.execute(select(Material).where(Material.project_id == project_id)).scalars():
        v = db.execute(select(MaterialVersion).where(MaterialVersion.material_pk == m.id,
                                                     MaterialVersion.version == m.current_version)).scalar_one()
        out[m.material_id] = MaterialRecord.from_dict(v.content)
    return out


def load_domain(db: Session, project_id: int, domain_id: int, require_approved: bool = False
                ) -> tuple[ResearchDomainRecord, ResearchDomain]:
    rec = db.get(ResearchDomainRecord, domain_id)
    if rec is None or rec.project_id != project_id:
        raise HTTPException(404, "research domain not found")
    if require_approved and rec.status != "approved":
        raise HTTPException(409, "research domain must be approved by a reviewer before use")
    return rec, ResearchDomain.from_dict(rec.content)


def measurement_frame(db: Session, project_id: int, experiment_states: Iterable[str] | None = None,
                      target: str | None = None) -> tuple[pd.DataFrame, dict]:
    q = select(Measurement, Experiment).join(Experiment, Measurement.experiment_pk == Experiment.id).where(
        Measurement.project_id == project_id)
    if target:
        q = q.where(Measurement.target == target)
    rows, excluded_states = [], {}
    states = set(experiment_states) if experiment_states else None
    for m, e in db.execute(q).all():
        if states is not None and e.state not in states:
            excluded_states[e.code] = e.state
            continue
        r = {c: getattr(m, c) for c in ("measurement_id", "run_id", "batch_id", "lot_ids", "replicate_group",
                                         "replicate", "block", "role", "target", "value", "unit", "method",
                                         "instrument_id", "status", "failure_reason", "lod", "measured_on",
                                         "raw_file_pk")}
        r["experiment"] = e.code
        r.update({f"mix:{k}": v for k, v in m.mixture.items()})
        r.update({f"proc:{k}": v for k, v in m.process.items()})
        rows.append(r)
    return pd.DataFrame(rows), {"excluded_experiments_by_state": excluded_states}


def store_model(project_id: int, result: TrainingResult) -> tuple[str, str]:
    buf = io.BytesIO()
    joblib.dump(artifact_payload(result), buf)
    data = buf.getvalue()
    key = f"projects/{project_id}/models/{result.manifest_hash}.joblib"
    get_storage(get_settings()).put(key, data, "application/octet-stream")
    return key, hashlib.sha256(data).hexdigest()


def load_model(run: ModelRun) -> TrainingResult:
    data = get_storage(get_settings()).get(run.artifact_key)
    if hashlib.sha256(data).hexdigest() != run.artifact_sha256:
        raise HTTPException(500, f"model artefact {run.id} failed integrity check")
    return result_from_payload(joblib.load(io.BytesIO(data)))


def latest_models(db: Session, project_id: int, targets: Iterable[str]) -> tuple[ModelBundle, list[ModelRun], list[str]]:
    results, runs, warnings = {}, [], []
    for t in targets:
        cands = db.execute(select(ModelRun).where(ModelRun.project_id == project_id, ModelRun.target == t,
                                                  ModelRun.status != "retired")
                           .order_by(ModelRun.id.desc())).scalars().all()
        if not cands:
            raise HTTPException(409, f"no trained model for target {t!r}")
        approved = [c for c in cands if c.status == "approved_for_use"]
        run = approved[0] if approved else cands[0]
        if not approved:
            warnings.append(f"{t}: using model run {run.id} which has not been approved for use by a reviewer")
        results[t] = load_model(run)
        runs.append(run)
    return ModelBundle(results), runs, warnings


DEFAULT_OBJECTIVES = [
    Objective("viscosity_in_range", "target_range", "mPa*s", "prediction", "viscosity", 30.0, 60.0, True,
              "predicted viscosity inside 30–60 mPa·s (deviation on log scale)"),
    Objective("uniformity_cv", "min", "%", "prediction", "uniformity_cv", description="content uniformity CV"),
    Objective("assay_4w_40C", "max", "%", "prediction", "assay_4w_40C", description="screening stability"),
    Objective("phase_separation_score", "min", "1", "prediction", "phase_separation",
              description="phase-separation score (unvalidated probability)"),
    Objective("material_cost", "min", "EUR/kg", "calculation", description="ingredient cost per kg"),
]
OPTIONAL_OBJECTIVES = {"process_time": Objective("process_time", "min", "min", "calculation",
                                                 description="mixing stage duration")}


def bo_history(frame: pd.DataFrame, low: float = 30.0, high: float = 60.0):
    """Measured history for the Bayesian optimiser (objectives: log-range deviation of viscosity, uniformity CV)."""
    from .science.optimisation.bo_adapter import Observation

    out = []
    comps = [c for c in frame.columns if c.startswith("mix:")]
    procs = [c for c in frame.columns if c.startswith("proc:")]
    for run_id, g in frame.groupby("run_id"):
        v = g[g.target == "viscosity"]; u = g[g.target == "uniformity_cv"]; ps = g[g.target == "phase_separation"]
        failed = bool((not ps.empty and ps["value"].iloc[0] == 1) or (not v.empty and v["status"].iloc[0] == "failed"))
        if not failed and (v.empty or u.empty or v["value"].isna().iloc[0] or u["value"].isna().iloc[0]):
            continue
        r = g.iloc[0]
        objs = [None, None]
        if not failed:
            lv = np.log(float(v["value"].iloc[0]))
            objs = [max(0.0, np.log(low) - lv, lv - np.log(high)), float(u["value"].iloc[0])]
        out.append(Observation({c[4:]: float(r[c]) for c in comps}, {c[5:]: float(r[c]) for c in procs}, objs,
                               failed, run_id))
    return out
