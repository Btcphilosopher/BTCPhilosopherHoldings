"""Relational schema (PostgreSQL in deployment; SQLite supported for tests).

Scientific payloads are stored as JSON validated by the science modules; every
versioned payload has a SHA-256 content hash. Approved revisions are immutable
(enforced in the service layer; audit_log is additionally protected by a
PostgreSQL trigger created in the initial migration).
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

JSONType = JSON().with_variant(JSONB(), "postgresql")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(200), default="")
    password_hash: Mapped[str] = mapped_column(String(200))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    confidential: Mapped[bool] = mapped_column(Boolean, default=True)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    memberships: Mapped[list["Membership"]] = relationship(back_populates="project")


class Membership(Base):
    __tablename__ = "memberships"
    __table_args__ = (UniqueConstraint("project_id", "user_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    role: Mapped[str] = mapped_column(String(20))  # researcher | reviewer | admin
    project: Mapped[Project] = relationship(back_populates="memberships")
    user: Mapped[User] = relationship()


class Material(Base):
    __tablename__ = "materials"
    __table_args__ = (UniqueConstraint("project_id", "material_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    material_id: Mapped[str] = mapped_column(String(64))
    current_version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    versions: Mapped[list["MaterialVersion"]] = relationship(back_populates="material", order_by="MaterialVersion.version")


class MaterialVersion(Base):
    __tablename__ = "material_versions"
    __table_args__ = (UniqueConstraint("material_pk", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    material_pk: Mapped[int] = mapped_column(ForeignKey("materials.id"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    content: Mapped[dict] = mapped_column(JSONType)
    content_hash: Mapped[str] = mapped_column(String(64))
    change_note: Mapped[str] = mapped_column(Text, default="")
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    material: Mapped[Material] = relationship(back_populates="versions")


class ResearchDomainRecord(Base):
    __tablename__ = "research_domains"
    __table_args__ = (UniqueConstraint("project_id", "name", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    version: Mapped[int] = mapped_column(Integer, default=1)
    content: Mapped[dict] = mapped_column(JSONType)
    content_hash: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft | approved | superseded
    feasibility: Mapped[dict | None] = mapped_column(JSONType, nullable=True)
    created_by: Mapped[str] = mapped_column(String(64))
    approved_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Formulation(Base):
    __tablename__ = "formulations"
    __table_args__ = (UniqueConstraint("project_id", "formulation_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    formulation_id: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    family: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    revisions: Mapped[list["FormulationRevision"]] = relationship(back_populates="formulation",
                                                                  order_by="FormulationRevision.revision")


class FormulationRevision(Base):
    __tablename__ = "formulation_revisions"
    __table_args__ = (UniqueConstraint("formulation_pk", "revision"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    formulation_pk: Mapped[int] = mapped_column(ForeignKey("formulations.id"), index=True)
    revision: Mapped[int] = mapped_column(Integer)
    content: Mapped[dict] = mapped_column(JSONType)
    content_hash: Mapped[str] = mapped_column(String(64))
    validation: Mapped[dict | None] = mapped_column(JSONType, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft | in_review | approved | superseded
    created_by: Mapped[str] = mapped_column(String(64))
    approved_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    formulation: Mapped[Formulation] = relationship(back_populates="revisions")


class DesignRecord(Base):
    __tablename__ = "designs"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    domain_pk: Mapped[int] = mapped_column(ForeignKey("research_domains.id"))
    spec: Mapped[dict] = mapped_column(JSONType)
    result: Mapped[dict] = mapped_column(JSONType)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Experiment(Base):
    __tablename__ = "experiments"
    __table_args__ = (UniqueConstraint("project_id", "code"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    code: Mapped[str] = mapped_column(String(64))
    title: Mapped[str] = mapped_column(String(300))
    current_revision: Mapped[int] = mapped_column(Integer, default=1)
    state: Mapped[str] = mapped_column(String(30), default="draft")
    design_pk: Mapped[int | None] = mapped_column(ForeignKey("designs.id"), nullable=True)
    proposal_pk: Mapped[int | None] = mapped_column(ForeignKey("proposals.id", use_alter=True), nullable=True)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    revisions: Mapped[list["ExperimentRevision"]] = relationship(back_populates="experiment",
                                                                 order_by="ExperimentRevision.revision")


class ExperimentRevision(Base):
    __tablename__ = "experiment_revisions"
    __table_args__ = (UniqueConstraint("experiment_pk", "revision"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_pk: Mapped[int] = mapped_column(ForeignKey("experiments.id"), index=True)
    revision: Mapped[int] = mapped_column(Integer)
    plan: Mapped[dict] = mapped_column(JSONType)
    plan_hash: Mapped[str] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(30), default="draft")
    submitted_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    approved_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    performed: Mapped[dict | None] = mapped_column(JSONType, nullable=True)
    data_reviewed_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    decision_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    experiment: Mapped[Experiment] = relationship(back_populates="revisions")


class RawFile(Base):
    __tablename__ = "raw_files"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    object_key: Mapped[str] = mapped_column(String(300))
    filename: Mapped[str] = mapped_column(String(200))
    content_type: Mapped[str] = mapped_column(String(100))
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    uploaded_by: Mapped[str] = mapped_column(String(64))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Measurement(Base):
    __tablename__ = "measurements"
    __table_args__ = (UniqueConstraint("project_id", "measurement_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    experiment_pk: Mapped[int] = mapped_column(ForeignKey("experiments.id"), index=True)
    experiment_revision: Mapped[int] = mapped_column(Integer)
    measurement_id: Mapped[str] = mapped_column(String(100))
    run_id: Mapped[str] = mapped_column(String(64))
    batch_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    lot_ids: Mapped[str | None] = mapped_column(String(300), nullable=True)
    replicate_group: Mapped[str] = mapped_column(String(64))
    replicate: Mapped[int] = mapped_column(Integer, default=1)
    block: Mapped[str | None] = mapped_column(String(64), nullable=True)
    role: Mapped[str] = mapped_column(String(20), default="design")
    target: Mapped[str] = mapped_column(String(64), index=True)
    value: Mapped[float | None] = mapped_column(Float, nullable=True)
    unit: Mapped[str] = mapped_column(String(32))
    method: Mapped[str | None] = mapped_column(String(100), nullable=True)
    instrument_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    status: Mapped[str] = mapped_column(String(20))  # ok | failed | censored
    failure_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    lod: Mapped[float | None] = mapped_column(Float, nullable=True)
    measured_on: Mapped[str] = mapped_column(String(10))
    mixture: Mapped[dict] = mapped_column(JSONType)
    process: Mapped[dict] = mapped_column(JSONType)
    raw_file_pk: Mapped[int | None] = mapped_column(ForeignKey("raw_files.id"), nullable=True)
    imported_by: Mapped[str] = mapped_column(String(64))
    imported_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Deviation(Base):
    __tablename__ = "deviations"
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_pk: Mapped[int] = mapped_column(ForeignKey("experiments.id"), index=True)
    description: Mapped[str] = mapped_column(Text)
    impact: Mapped[str] = mapped_column(Text, default="")
    recorded_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class QualityFinding(Base):
    __tablename__ = "quality_findings"
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_pk: Mapped[int] = mapped_column(ForeignKey("experiments.id"), index=True)
    severity: Mapped[str] = mapped_column(String(10))
    code: Mapped[str] = mapped_column(String(64))
    message: Mapped[str] = mapped_column(Text)
    rows: Mapped[list] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Dataset(Base):
    __tablename__ = "datasets"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    target: Mapped[str] = mapped_column(String(64))
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    measurement_ids: Mapped[list] = mapped_column(JSONType)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ModelRun(Base):
    __tablename__ = "model_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    dataset_pk: Mapped[int] = mapped_column(ForeignKey("datasets.id"))
    target: Mapped[str] = mapped_column(String(64), index=True)
    manifest: Mapped[dict] = mapped_column(JSONType)
    manifest_hash: Mapped[str] = mapped_column(String(64))
    artifact_key: Mapped[str] = mapped_column(String(300))
    artifact_sha256: Mapped[str] = mapped_column(String(64))
    selected_model: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(20), default="evaluated")  # evaluated | approved_for_use | retired
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ProposalBatch(Base):
    __tablename__ = "proposal_batches"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    domain_pk: Mapped[int] = mapped_column(ForeignKey("research_domains.id"))
    model_run_pks: Mapped[list] = mapped_column(JSONType)
    result: Mapped[dict] = mapped_column(JSONType)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Proposal(Base):
    __tablename__ = "proposals"
    id: Mapped[int] = mapped_column(primary_key=True)
    batch_pk: Mapped[int] = mapped_column(ForeignKey("proposal_batches.id"), index=True)
    code: Mapped[str] = mapped_column(String(20))
    content: Mapped[dict] = mapped_column(JSONType)
    status: Mapped[str] = mapped_column(String(30), default="proposed")
    reviewed_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    review_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    experiment_pk: Mapped[int | None] = mapped_column(Integer, nullable=True)


class PredictionRecord(Base):
    __tablename__ = "predictions"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    model_run_pks: Mapped[list] = mapped_column(JSONType)
    proposal_pk: Mapped[int | None] = mapped_column(ForeignKey("proposals.id"), nullable=True)
    input: Mapped[dict] = mapped_column(JSONType)
    output: Mapped[dict] = mapped_column(JSONType)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class StabilityResult(Base):
    __tablename__ = "stability_results"
    __table_args__ = (UniqueConstraint("project_id", "stab_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    stab_id: Mapped[str] = mapped_column(String(64))
    formulation_id: Mapped[str] = mapped_column(String(64))
    formulation_revision: Mapped[int] = mapped_column(Integer)
    packaging: Mapped[str] = mapped_column(String(64))
    condition: Mapped[str] = mapped_column(String(64))
    time_months: Mapped[float] = mapped_column(Float)
    lot: Mapped[str] = mapped_column(String(64))
    attribute: Mapped[str] = mapped_column(String(64))
    value: Mapped[float | None] = mapped_column(Float, nullable=True)
    unit: Mapped[str] = mapped_column(String(32))
    method: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(20))
    lod: Mapped[float | None] = mapped_column(Float, nullable=True)


class CombinationDataset(Base):
    __tablename__ = "combination_datasets"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    context: Mapped[dict] = mapped_column(JSONType)
    data: Mapped[list] = mapped_column(JSONType)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Review(Base):
    __tablename__ = "reviews"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    entity_type: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str] = mapped_column(String(64))
    entity_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    decision: Mapped[str] = mapped_column(String(40))
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewer: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class LineageEdge(Base):
    __tablename__ = "lineage_edges"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    parent_kind: Mapped[str] = mapped_column(String(40))
    parent_ref: Mapped[str] = mapped_column(String(100))
    child_kind: Mapped[str] = mapped_column(String(40))
    child_ref: Mapped[str] = mapped_column(String(100))
    relation: Mapped[str] = mapped_column(String(60))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    actor: Mapped[str] = mapped_column(String(64))
    project_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(80))
    entity_type: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str] = mapped_column(String(100))
    detail: Mapped[dict] = mapped_column(JSONType)
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64))


class TargetDefinition(Base):
    """Measured property definition: units, method, horizon, physical bounds, supported domain."""
    __tablename__ = "target_definitions"
    __table_args__ = (UniqueConstraint("project_id", "name", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"), index=True)
    name: Mapped[str] = mapped_column(String(64))
    version: Mapped[int] = mapped_column(Integer, default=1)
    spec: Mapped[dict] = mapped_column(JSONType)
    supported_domain: Mapped[str] = mapped_column(Text, default="")
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
