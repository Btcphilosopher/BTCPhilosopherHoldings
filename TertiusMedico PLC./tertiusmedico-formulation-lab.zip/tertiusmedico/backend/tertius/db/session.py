from __future__ import annotations

from functools import lru_cache

from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from ..config import get_settings


@lru_cache
def engine_for(url: str):
    kw = {"future": True, "pool_pre_ping": True}
    if url.startswith("sqlite"):
        kw["connect_args"] = {"check_same_thread": False}
    eng = create_engine(url, **kw)
    if url.startswith("sqlite"):
        @event.listens_for(eng, "connect")
        def _fk(dbapi_conn, _):  # enforce foreign keys in SQLite
            dbapi_conn.execute("PRAGMA foreign_keys=ON")
    return eng


def get_engine():
    return engine_for(get_settings().database_url)


def session_factory(url: str | None = None) -> sessionmaker:
    return sessionmaker(bind=engine_for(url or get_settings().database_url), expire_on_commit=False)


def get_db():
    s: Session = session_factory()()
    try:
        yield s
    finally:
        s.close()
