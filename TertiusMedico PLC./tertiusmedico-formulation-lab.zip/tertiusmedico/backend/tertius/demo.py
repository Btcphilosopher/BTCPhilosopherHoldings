"""End-to-end synthetic demonstration through the HTTP API (12 steps).

Runs against the configured database (``TERTIUS_DATABASE_URL``) and storage.
All materials, compounds and measurements are FICTIONAL. Outputs are written
to ``--out`` (default ``demo_output/``).
"""

from __future__ import annotations

import io
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from fastapi.testclient import TestClient

from .synthetic.demo_config import INSTRUMENTS, TARGETS, demo_domain
from .synthetic.generator import (COMPONENTS, FICTIONAL_MATERIALS, generate_combination_dataset,
                                  generate_experiment_results, generate_stability_study)

DEMO_USERS = {  # demonstration-only credentials; override with env vars
    "admin": os.getenv("TERTIUS_DEMO_ADMIN_PASSWORD", "demo-admin-change-me"),
    "rhea": os.getenv("TERTIUS_DEMO_RESEARCHER_PASSWORD", "demo-researcher-change-me"),
    "rowan": os.getenv("TERTIUS_DEMO_REVIEWER_PASSWORD", "demo-reviewer-change-me"),
}


class Api:
    def __init__(self, client: TestClient, log: list):
        self.c, self.log, self.tokens = client, log, {}

    def login(self, user: str):
        r = self.c.post("/api/auth/token", data={"username": user, "password": DEMO_USERS[user]})
        r.raise_for_status()
        self.tokens[user] = r.json()["access_token"]

    def call(self, user: str, method: str, path: str, expect: int | tuple = 200, **kw):
        r = self.c.request(method, path, headers={"Authorization": f"Bearer {self.tokens[user]}"}, **kw)
        exp = (expect,) if isinstance(expect, int) else expect
        if r.status_code not in exp:
            raise RuntimeError(f"{method} {path} → {r.status_code}: {r.text[:800]}")
        self.log.append({"user": user, "method": method, "path": path, "status": r.status_code})
        ct = r.headers.get("content-type", "")
        return r.json() if ct.startswith("application/json") else r.text


def bootstrap(db_url: str | None = None) -> None:
    """Create schema (if missing) and demo users."""
    from sqlalchemy import select

    from .api.security import hash_password
    from .db.models import Base, User
    from .db.session import get_engine, session_factory

    eng = get_engine()
    if eng.dialect.name == "sqlite":
        Base.metadata.create_all(eng)
    s = session_factory()()
    for u, pw in DEMO_USERS.items():
        if not s.execute(select(User).where(User.username == u)).scalar_one_or_none():
            s.add(User(username=u, full_name={"admin": "Demo Administrator", "rhea": "Rhea (researcher, demo)",
                                              "rowan": "Rowan (reviewer, demo)"}[u],
                       password_hash=hash_password(pw), is_admin=(u == "admin")))
    s.commit(); s.close()


def run_demo(out_dir: str = "demo_output", seed: int = 11) -> dict:
    from .api.main import create_app

    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    bootstrap()
    log: list = []
    api = Api(TestClient(create_app()), log)
    for u in DEMO_USERS:
        api.login(u)
    summary: dict = {"notice": "SYNTHETIC DEMONSTRATION — fictional materials and measurements"}

    # ---- project & roles
    existing = [p for p in api.call("admin", "GET", "/api/projects") if p["code"] == "SUS-DEMO"]
    if existing:
        raise RuntimeError("demo project SUS-DEMO already exists in this database; use a fresh database")
    pid = api.call("admin", "POST", "/api/projects", json={
        "code": "SUS-DEMO", "name": "Fictional four-component suspension (synthetic demonstration)",
        "description": "Inert surrogate ingredients; synthetic measurements from a documented generator.",
        "synthetic": True})["id"]
    api.call("admin", "POST", f"/api/projects/{pid}/members", json={"username": "rhea", "role": "researcher"})
    api.call("admin", "POST", f"/api/projects/{pid}/members", json={"username": "rowan", "role": "reviewer"})
    P = f"/api/projects/{pid}"

    # ---- 1. register materials
    mats = []
    for m in FICTIONAL_MATERIALS:
        props = []
        if m["density"] is not None:
            src = "laboratory_measurement" if m["material_id"] == "SV-1" else "supplier_specification"
            props.append({"name": "density", "source": src, "value": m["density"], "unit": "g/mL",
                          "method": "DENS-OSC-20C (demo)" if src == "laboratory_measurement" else None,
                          "reference": "fictional CoA" if src != "laboratory_measurement" else "DEMO-LAB-NB-001"})
        if m["material_id"] == "TR-4":
            props.append({"name": "particle_size_d50", "source": "literature", "value": 12.0, "unit": "um",
                          "reference": "fictional reference handbook (demo)"})
        body = {"material_id": m["material_id"], "name": m["name"], "supplier": m["supplier"], "grade": m["grade"],
                "lot": "L-VM2-A" if m["material_id"] == "VM-2" else f"LOT-{m['material_id']}-001",
                "identity_reference": "DEMO-ID (fictional)", "physical_properties": props,
                "purity_or_assay": {"name": "assay", "source": "supplier_specification", "value": 99.0, "unit": "%",
                                    "reference": "fictional CoA"},
                "storage_requirements": "15–25 °C, dry (fictional)", "expiry_or_retest_date": "2027-06-30",
                "hazard_document_references": ["SDS-DEMO-" + m["material_id"]], "source": "synthetic demo",
                "verification_status": "identity_confirmed", "fictional": True}
        mats.append(api.call("rhea", "POST", f"{P}/materials", json=body))
    vm2 = api.call("rhea", "GET", f"{P}/materials/VM-2")["versions"][-1]["content"]
    vm2_new = {k: v for k, v in vm2.items() if k != "version"}
    vm2_new["lot"] = "L-VM2-B"
    rev = api.call("rhea", "POST", f"{P}/materials/VM-2/versions",
                   json={"record": vm2_new, "change_note": "new lot received (fictional)"})
    summary["1_materials"] = {"registered": mats, "revision": rev,
                              "note": "VM-2 and TR-4 have no recorded density: left missing, not defaulted"}

    # ---- 2/3. constrained formulation + validation
    ref_comp = {"SV-1": 0.70, "VM-2": 0.15, "SF-3": 0.05, "TR-4": 0.10}
    roles = {m["material_id"]: m["role"] for m in FICTIONAL_MATERIALS}
    form = {"name": "SUS-DEMO reference suspension (fictional)", "dosage_form": "suspension", "basis": "mass_fraction",
            "family": "SUS-DEMO", "target_batch_size": {"value": 500, "unit": "g"},
            "ingredients": [{"material_id": c, "material_version": 2 if c == "VM-2" else 1, "role": roles[c],
                             "amount": {"value": ref_comp[c], "unit": "fraction"},
                             "lot": "L-VM2-B" if c == "VM-2" else f"LOT-{c}-001"} for c in COMPONENTS],
            "stages": [
                {"order": 1, "name": "charge vehicle and surfactant", "equipment_id": "MIXER-LAB-01",
                 "additions": ["SV-1", "SF-3"], "parameters": {"mix_speed": {"value": 400, "unit": "rpm"}}},
                {"order": 2, "name": "disperse thickener", "equipment_id": "MIXER-LAB-01", "additions": ["VM-2"],
                 "parameters": {"mix_speed": {"value": 600, "unit": "rpm"}}, "duration": {"value": 10, "unit": "min"}},
                {"order": 3, "name": "add tracer and homogenise", "equipment_id": "MIXER-LAB-01", "additions": ["TR-4"],
                 "parameters": {"mix_speed": {"value": 600, "unit": "rpm"}}, "duration": {"value": 20, "unit": "min"}}],
            "targets": [{"name": "viscosity", "unit": "mPa*s", "lower": 30, "upper": 60, "method": "ROT-RHEO-50"}],
            "evidence": ["DEMO-COMPAT-REVIEW-001 (synthetic)"]}
    f1 = api.call("rhea", "POST", f"{P}/formulations", json={"formulation_id": "SUS-DEMO-REF", "content": form})
    bad = dict(form, ingredients=[dict(i, amount={"value": i["amount"]["value"] - (0.02 if i["material_id"] == "SV-1" else 0),
                                                  "unit": "fraction"}) for i in form["ingredients"]])
    f_bad = api.call("rhea", "POST", f"{P}/formulations", json={"formulation_id": "SUS-DEMO-BAD-TOTAL", "content": bad})
    vol = dict(form, basis="volume_fraction", target_batch_size={"value": 500, "unit": "mL"})
    f_vol = api.call("rhea", "POST", f"{P}/formulations", json={"formulation_id": "SUS-DEMO-VOL", "content": vol})
    wrong_unit = dict(form, ingredients=[dict(form["ingredients"][0], amount={"value": 350, "unit": "mg/mL"})] +
                      form["ingredients"][1:])
    f_unit = api.call("rhea", "POST", f"{P}/formulations", json={"formulation_id": "SUS-DEMO-BAD-UNIT", "content": wrong_unit})
    api.call("rhea", "POST", f"{P}/formulations/SUS-DEMO-REF/revisions/1/review", json={"decision": "submit"})
    api.call("rowan", "POST", f"{P}/formulations/SUS-DEMO-REF/revisions/1/review", json={"decision": "approve"})
    mb = api.call("rhea", "POST", f"{P}/calculations/mass-balance", json={
        "inputs": [{"value": 350, "unit": "g"}, {"value": 75, "unit": "g"}, {"value": 25, "unit": "g"},
                   {"value": 50, "unit": "g"}], "output": {"value": 482.0, "unit": "g"},
        "losses": [{"stage": "transfer", "mass": {"value": 11.5, "unit": "g"}, "reason": "line hold-up (weighed)",
                    "measured": True}, {"stage": "sampling", "mass": {"value": 4000, "unit": "mg"},
                                        "reason": "QC samples", "measured": True}]})
    summary["2_3_formulation_validation"] = {"reference": f1["validation"], "bad_total": f_bad["validation"],
                                             "volume_basis": f_vol["validation"], "bad_unit": f_unit["validation"],
                                             "mass_balance": mb}

    # ---- constraints / feasibility
    dom = demo_domain()
    d_bad = dom.to_dict(); d_bad["name"] = "Deliberately infeasible domain"
    d_bad["bounds"] = dict(d_bad["bounds"], **{"SV-1": [0.80, 0.85], "VM-2": [0.12, 0.30]})
    d_bad["groups"] = [{"name": "structurants", "members": ["VM-2", "TR-4"], "lower": 0.25, "upper": 0.40}]
    infeasible = api.call("rhea", "POST", f"{P}/domains", json={"content": d_bad})
    dres = api.call("rhea", "POST", f"{P}/domains", json={"content": dom.to_dict()})
    did = dres["id"]
    api.call("rowan", "POST", f"{P}/domains/{infeasible['id']}/approve", expect=409)
    api.call("rowan", "POST", f"{P}/domains/{did}/approve")
    summary["constraints"] = {"infeasible_example": infeasible["feasibility"], "demo_domain": dres["feasibility"]}

    # ---- 4. experimental design
    design = api.call("rhea", "POST", f"{P}/designs", json={"domain_id": did, "spec": {
        "mixture_strategy": "extreme_vertices_d_optimal", "n_mixture_points": 22, "scheffe_order": 2,
        "process_strategy": "latin_hypercube", "replicates": 2, "control": ref_comp,
        "control_process": {"mix_speed": 600, "mix_time": 20, "temperature": 25}, "n_controls": 2,
        "blocking_factor": "day", "blocks": ["day1", "day2", "day3"], "seed": 20260101,
        "cost_per_run": 180.0, "currency": "EUR"}})
    pd.DataFrame(design["runs"]).to_csv(out / "design_runs.csv", index=False)
    summary["4_design"] = {"budget": design["budget"], "coverage": design["coverage"],
                           "limitations": design["limitations"], "rationale": design["rationale"]}

    for t in TARGETS.values():
        api.call("rhea", "POST", f"{P}/targets", json={"spec": t.as_dict(), "supported_domain": dom.name})

    # ---- 5. experiment workflow + import synthetic results
    api.call("rhea", "POST", f"{P}/experiments", json={
        "code": "EXP-DOE-01", "title": "Constrained mixture screening (synthetic)", "design_id": design["id"],
        "plan": {"formulation_refs": [{"formulation_id": "SUS-DEMO-REF", "revision": 1}], "instruments": INSTRUMENTS,
                 "objective": "map viscosity, uniformity and screening stability across the research domain"}})
    api.call("rhea", "POST", f"{P}/experiments/EXP-DOE-01/transition", json={"target": "scientific_review"})
    api.call("rhea", "POST", f"{P}/experiments/EXP-DOE-01/transition", json={"target": "approved_for_experiment"},
             expect=403)  # researchers cannot approve
    api.call("rowan", "POST", f"{P}/experiments/EXP-DOE-01/transition", json={"target": "approved_for_experiment"})
    api.call("rhea", "PUT", f"{P}/experiments/EXP-DOE-01/plan", json={"plan": {"runs": []}}, expect=409)  # immutable
    runs = pd.DataFrame(design["runs"])
    results = generate_experiment_results(runs, seed=seed)
    results.to_csv(out / "synthetic_results.csv", index=False)
    lots = sorted({x.split(":")[1] for x in results["lot_ids"]})
    api.call("rhea", "POST", f"{P}/experiments/EXP-DOE-01/transition", json={"target": "performed", "evidence": {
        "operator": "rhea", "performed_on": "2026-02-02..2026-02-16", "material_lots": ["LOT-SV-1-001", *lots,
                                                                                        "LOT-SF-3-001", "LOT-TR-4-001"],
        "equipment": ["MIXER-LAB-01", "RHEO-01", "HPLC-02"], "note": "synthetic execution record"}})
    api.call("rhea", "POST", f"{P}/experiments/EXP-DOE-01/deviations", json={
        "description": "two runs measured 1 day late due to instrument queue (synthetic)", "impact": "none expected"})
    imp = api.call("rhea", "POST", f"{P}/experiments/EXP-DOE-01/measurements",
                   files={"file": ("synthetic_results.csv", results.to_csv(index=False).encode(), "text/csv")})
    api.call("rhea", "POST", f"{P}/experiments/EXP-DOE-01/transition", json={"target": "data_reviewed"}, expect=403)
    api.call("rowan", "POST", f"{P}/experiments/EXP-DOE-01/transition", json={"target": "data_reviewed"})
    api.call("rowan", "POST", f"{P}/experiments/EXP-DOE-01/transition", json={
        "target": "accepted", "reason": "data complete; failures documented and retained"})
    summary["5_import"] = {"imported": imp["imported"], "quality": imp["quality"],
                           "status_counts": results.groupby(["target", "status"]).size().astype(int)
                           .reset_index().to_dict(orient="records")}

    # ---- 6/7. models + uncertainty
    models = {}
    for t in TARGETS:
        res = api.call("rhea", "POST", f"{P}/models/train", json={"target": t, "split_by": "batch_id", "seed": 7})
        models[t] = res
        api.call("rowan", "POST", f"{P}/models/{res['id']}/review", json={"decision": "approve",
                                                                         "reason": "reviewed held-out metrics"})
    comp_rows, cov_rows = [], []
    for t, res in models.items():
        man = res["manifest"]
        for name, r in man["results"].items():
            if "test" in r:
                comp_rows.append({"target": t, "model": name, "selected": name == res["selected_model"],
                                  "inner_cv_mae_model_scale": r["inner_cv_mae_model_scale"], **r["test"]})
                for lvl, c in r["coverage"].items():
                    cov_rows.append({"target": t, "model": name, **c})
            else:
                comp_rows.append({"target": t, "model": name, "selected": name == res["selected_model"], **r})
    pd.DataFrame(comp_rows).to_csv(out / "model_comparison.csv", index=False)
    pd.DataFrame(cov_rows).to_csv(out / "uncertainty_coverage.csv", index=False)
    summary["6_models"] = comp_rows
    summary["7_uncertainty"] = {"coverage": cov_rows, "variability": {t: m["manifest"].get("variability")
                                                                      for t, m in models.items()},
                                "warnings": {t: m["manifest"]["warnings"] for t, m in models.items()},
                                "classification": models["phase_separation"]["manifest"].get("calibration_status")}

    # ---- 8/9. proposals + Pareto frontier
    props = api.call("rhea", "POST", f"{P}/proposals", json={"domain_id": did, "n": 5, "strategy": "bayesian",
                                                             "seed": 3, "pool_size": 1500})
    (out / "proposals.json").write_text(json.dumps(props, indent=2, default=str))
    reviews = []
    for i, p in enumerate(props["proposals"]):
        if i < 3:
            reviews.append(api.call("rowan", "POST", f"{P}/proposals/{p['id']}/review", json={
                "decision": "accept", "reason": "within domain, informative trade-off", "replicates": 3}))
        elif i == 3:
            reviews.append(api.call("rowan", "POST", f"{P}/proposals/{p['id']}/review", json={
                "decision": "reject", "reason": "too close to existing design point; low information value"}))
    api.call("rhea", "POST", f"{P}/proposals/{props['proposals'][4]['id']}/review",
             json={"decision": "accept", "reason": "self-review attempt"}, expect=403)
    summary["8_proposals"] = {"stats": props["stats"], "proposals": [
        {"code": p["code"], "strategy": p["strategy"], "composition": p["composition"], "process": p["process"],
         "predictions": {k: {kk: v.get(kk) for kk in ("mean", "lower", "upper", "unit", "score")}
                         for k, v in p["predictions"].items()},
         "calculated": p["calculated"], "reason": p["reason"], "warnings": p["warnings"],
         "neighbours": [n["run_id"] for n in p["neighbourhood"]]} for p in props["proposals"]],
        "reviews": reviews, "warnings": props["warnings"]}
    summary["9_pareto"] = {"objectives": props["objectives"], "frontier_size": len(props["frontier"])}
    _pareto_html(props, out / "pareto_frontier.html")

    # ---- 10. out-of-domain candidate
    ood = api.call("rhea", "POST", f"{P}/candidates/evaluate", json={
        "domain_id": did, "composition": {"SV-1": 0.40, "VM-2": 0.35, "SF-3": 0.05, "TR-4": 0.20},
        "process": {"mix_speed": 1100, "mix_time": 20, "temperature": 25}})
    foreign = api.call("rhea", "POST", f"{P}/candidates/evaluate", json={
        "domain_id": did, "composition": {"SV-1": 0.70, "VM-2": 0.15, "SF-3": 0.05, "TR-4": 0.05, "XX-9": 0.05},
        "process": {"mix_speed": 600, "mix_time": 20, "temperature": 25}})
    inside = api.call("rhea", "POST", f"{P}/candidates/evaluate", json={
        "domain_id": did, "composition": ref_comp, "process": {"mix_speed": 600, "mix_time": 20, "temperature": 25}})
    summary["10_out_of_domain"] = {
        "bounds_and_equipment_violation": {"decision": ood["decision"], "reasons": ood["reasons"],
                                           "predictions_offered": bool(ood["predictions"])},
        "unregistered_ingredient": {"decision": foreign["decision"], "reasons": foreign["reasons"]},
        "reference_inside_domain": {"decision": inside["decision"], "flags": inside["domain"]["flags"],
                                    "viscosity": inside["predictions"].get("viscosity")}}

    # ---- 11. stability
    stab = generate_stability_study(seed + 1, {"SUS-DEMO-REF": ref_comp,
                                               "SUS-DEMO-HISURF": {"SV-1": 0.66, "VM-2": 0.12, "SF-3": 0.10, "TR-4": 0.12}})
    stab["formulation_revision"] = 1
    api.call("rhea", "POST", f"{P}/stability/results", json={"rows": json.loads(stab.to_json(orient="records"))})
    trends = api.call("rhea", "GET", f"{P}/stability/trends",
                      params={"attribute": "assay", "formulation_id": "SUS-DEMO-REF", "spec_limit": 95.0})
    refused = api.call("rhea", "GET", f"{P}/stability/trends",
                       params={"attribute": "assay", "formulation_id": "SUS-DEMO-REF", "forecast_to": 60})
    (out / "stability_trends.json").write_text(json.dumps(trends, indent=2, default=str))
    summary["11_stability"] = {"n_trends": len(trends["trends"]), "censored_degradant_results":
                               int((stab.status == "censored").sum()),
                               "trends": [{**t["key"], "slope_per_month": t["slope_per_month"],
                                           "exploratory_crossing": t.get("exploratory_limit_crossing")}
                                          for t in trends["trends"]],
                               "poolability": trends["poolability_example"],
                               "forecast_beyond_bound": refused["trends"][0]["forecast"], "notice": trends["notice"]}
    _stability_html(trends, out / "stability_trend.html")

    # ---- extras: simulation, costs, combination research
    sim = api.call("rhea", "POST", f"{P}/simulations/process", json={
        "batch_mass_g": 5000, "mix_speed_rpm": 600, "mix_time_min": 20, "hold_time_h": 4, "fill_target_g": 50,
        "fill_tolerance_g": 0.75})
    cost = api.call("rhea", "POST", f"{P}/costs/scenario", json={"currency": "EUR", "lines": [
        *[{"category": "ingredient", "item": c, "quantity": {"value": ref_comp[c] * 5, "unit": "kg"},
           "price": {"amount": dom.prices[c].amount, "currency": "EUR", "per": "kg", "price_date": dom.prices[c].price_date,
                     "source": "fictional quote"}} for c in COMPONENTS],
        {"category": "packaging", "item": "glass vial 50 mL (fictional)", "quantity": {"value": 96, "unit": "unit"},
         "price": {"amount": 0.42, "currency": "USD", "per": "unit", "price_date": "2026-01-10", "source": "fictional"}},
        {"category": "waste", "item": "disposal", "quantity": {"value": sim["outputs"]["waste_g"]["median"], "unit": "g"},
         "price": {"amount": 1.8, "currency": "EUR", "per": "kg", "price_date": "2026-01-10", "source": "fictional"}},
        {"category": "processing", "item": "lab mixer time", "quantity": {"value": 4.5, "unit": "h"},
         "price": {"amount": 35, "currency": "EUR", "per": "h", "price_date": "2026-01-10", "source": "assumed rate"}},
        {"category": "experiment", "item": "follow-up runs", "quantity": {"value": 9, "unit": "1"},
         "price": {"amount": 180, "currency": "EUR", "per": "run", "price_date": "2026-01-10", "source": "assumed"}}],
        "fx": [{"from_currency": "USD", "to_currency": "EUR", "rate": "0.92", "rate_date": "2026-01-10",
                "source": "fictional dated rate"}]})
    combo_df = generate_combination_dataset(seed)
    cds = api.call("rhea", "POST", f"{P}/combination/datasets", json={
        "name": "CX-1 × CY-2 fictional assay", "rows": json.loads(combo_df.to_json(orient="records")),
        "context": {"authorisation_reference": "DEMO-AUTH-0001 (synthetic dataset, internal demo use)",
                    "permitted_use": "software demonstration only", "system": "fictional cell-free assay",
                    "exposure": "48 h, 37 °C (fictional)", "endpoint": "fractional_inhibition_signal_48h"}})
    combo = api.call("rhea", "POST", f"{P}/combination/datasets/{cds['id']}/analyse")
    refused_combo = api.c.post(f"{P}/combination/datasets", headers={"Authorization": f"Bearer {api.tokens['rhea']}"},
                               json={"name": "x", "rows": [], "context": {
                                   "authorisation_reference": "", "permitted_use": "", "system": "s", "exposure": "e",
                                   "endpoint": "e"}})
    summary["extras"] = {"simulation": {"label": sim["label"], "outputs": sim["outputs"], "flags": sim["flags"]},
                         "cost": cost, "combination": {"n_pairs": combo["n_dose_pairs"],
                                                       "conclusions": pd.Series([r["conclusion"] for r in combo["results"]])
                                                       .value_counts().to_dict(), "disclaimer": combo["disclaimer"]},
                         "combination_without_authorisation": refused_combo.status_code}
    (out / "combination_analysis.json").write_text(json.dumps(combo, indent=2, default=str))

    # ---- 12. report + lineage
    rep = api.call("rhea", "POST", f"{P}/reports", json={"proposal_batch_id": props["batch_id"],
                                                         "stability_formulation": "SUS-DEMO-REF"})
    html = api.call("rhea", "POST", f"{P}/reports/html", json={"proposal_batch_id": props["batch_id"],
                                                               "stability_formulation": "SUS-DEMO-REF"})
    (out / "research_report.json").write_text(json.dumps(rep["report"], indent=2, default=str))
    (out / "research_report.html").write_text(html)
    accepted = [r for r in reviews if r["status"] == "accepted_for_planning"][0]
    lin = api.call("rhea", "GET", f"{P}/lineage", params={"kind": "reviewed_decision", "ref": f"review:{accepted['code']}"})
    summary["12_report"] = {"content_sha256": rep["report"]["meta"]["content_sha256"], "sections": list(rep["report"]),
                            "lineage_example": lin}
    summary["audit_chain"] = api.call("admin", "GET", "/api/admin/audit/verify")
    summary["permission_checks"] = {"outsider_access": _outsider(api, P)}
    summary["api_calls"] = len(log)
    (out / "demo_summary.json").write_text(json.dumps(summary, indent=2, default=str))
    return summary


def _outsider(api: Api, P: str) -> int:
    r = api.c.get(P, headers={"Authorization": "Bearer invalid"})
    return r.status_code


def _pareto_html(props: dict, path: Path) -> None:
    import plotly.graph_objects as go

    fr = props["frontier"]
    x = [f["objective_values"].get("material_cost") for f in fr]
    y = [f["objective_values"].get("uniformity_cv") for f in fr]
    c = [f["objective_values"].get("assay_4w_40C") for f in fr]
    fig = go.Figure(go.Scatter(x=x, y=y, mode="markers", name="Pareto frontier (PREDICTED)",
                               marker=dict(color=c, colorscale="Purples", showscale=True,
                                           colorbar=dict(title="assay 4w (%)"), size=7)))
    for p in props["proposals"]:
        fig.add_trace(go.Scatter(x=[p["calculated"].get("material_cost", {}).get("value")],
                                 y=[p["predictions"]["uniformity_cv"]["mean"]], mode="markers+text",
                                 text=[p["code"]], textposition="top center", name=f"{p['code']} ({p['strategy']})",
                                 marker=dict(symbol="diamond", size=12, line=dict(width=1, color="#0f1a3a"))))
    fig.update_layout(title="Pareto frontier — 2-D projection of a 5-objective frontier (PREDICTED; synthetic demo)<br>"
                            "<sup>points that look dominated here are non-dominated on another objective "
                            "(viscosity range, phase-separation score)</sup>",
                      xaxis_title="material cost (EUR/kg, CALCULATED)", yaxis_title="uniformity CV % (PREDICTED)",
                      template="plotly_white", legend=dict(orientation="h", y=-0.18, x=0), margin=dict(b=140))
    fig.write_html(path, include_plotlyjs=True)


def _stability_html(trends: dict, path: Path) -> None:
    import plotly.graph_objects as go

    fig = go.Figure()
    for t in trends["trends"]:
        k = t["key"]
        name = f"{k['condition']} · {k['packaging']} · {k['lot']}"
        obs = t["observations"]
        fig.add_trace(go.Scatter(x=[o["time"] for o in obs], y=[o["value"] for o in obs], mode="markers",
                                 name=f"MEASURED {name}", marker=dict(color="#0f8b8d")))
        fc = t["forecast"]
        if "mean" in fc:
            fig.add_trace(go.Scatter(x=fc["time"], y=fc["mean"], mode="lines", name=f"trend {name}",
                                     line=dict(color="#6d4bd1", dash="dot")))
    fig.add_hline(y=95, line=dict(color="#b7791f"), annotation_text="illustrative limit 95 % (not a specification)")
    fig.update_layout(title="Stability assay trend — EXPLORATORY, NOT A SHELF-LIFE ASSIGNMENT",
                      xaxis_title="months", yaxis_title="assay (% of initial)", template="plotly_white")
    fig.write_html(path, include_plotlyjs=True)
