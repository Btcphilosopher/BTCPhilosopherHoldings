"""Append-only, hash-chained audit log."""

from __future__ import annotations

import hashlib
import json

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from .db.models import AuditLog, LineageEdge

GENESIS = "0" * 64


def _digest(prev: str, actor: str, project_id, action: str, entity_type: str, entity_id: str, detail: dict) -> str:
    body = json.dumps({"prev": prev, "actor": actor, "project": project_id, "action": action, "type": entity_type,
                       "id": entity_id, "detail": detail}, sort_keys=True, default=str)
    return hashlib.sha256(body.encode()).hexdigest()


def record(db: Session, actor: str, action: str, entity_type: str, entity_id, project_id=None,
           detail: dict | None = None) -> AuditLog:
    if db.get_bind().dialect.name == "postgresql":  # serialise chain appends across concurrent transactions
        db.execute(text("SELECT pg_advisory_xact_lock(724411)"))
    last = db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(1)).scalar_one_or_none()
    prev = last.hash if last else GENESIS
    detail = json.loads(json.dumps(detail or {}, default=str))
    h = _digest(prev, actor, project_id, action, entity_type, str(entity_id), detail)
    entry = AuditLog(actor=actor, project_id=project_id, action=action, entity_type=entity_type,
                     entity_id=str(entity_id), detail=detail, prev_hash=prev, hash=h)
    db.add(entry)
    db.flush()
    return entry


def verify_chain(db: Session) -> dict:
    prev = GENESIS
    n = 0
    for e in db.execute(select(AuditLog).order_by(AuditLog.id)).scalars():
        n += 1
        if e.prev_hash != prev or _digest(prev, e.actor, e.project_id, e.action, e.entity_type, e.entity_id,
                                          e.detail) != e.hash:
            return {"valid": False, "broken_at": e.id, "checked": n}
        prev = e.hash
    return {"valid": True, "checked": n}


def link(db: Session, project_id: int, parent_kind: str, parent_ref, child_kind: str, child_ref, relation: str):
    db.add(LineageEdge(project_id=project_id, parent_kind=parent_kind, parent_ref=str(parent_ref),
                       child_kind=child_kind, child_ref=str(child_ref), relation=relation))
