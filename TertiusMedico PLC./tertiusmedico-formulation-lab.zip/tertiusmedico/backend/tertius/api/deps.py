from __future__ import annotations

from dataclasses import dataclass

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db.models import Membership, Project, User
from ..db.session import get_db
from ..science.workflow import has_role
from .security import decode_token

oauth2 = OAuth2PasswordBearer(tokenUrl="/api/auth/token")


def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)) -> User:
    try:
        username = decode_token(token)
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid or expired token",
                            headers={"WWW-Authenticate": "Bearer"})
    u = db.execute(select(User).where(User.username == username)).scalar_one_or_none()
    if u is None or not u.active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "unknown or inactive user")
    return u


def require_admin(u: User = Depends(current_user)) -> User:
    if not u.is_admin:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "administrator role required")
    return u


@dataclass
class ProjectAccess:
    project: Project
    user: User
    role: str


def project_access(min_role: str = "researcher"):
    """Project-scoped permission. Data access requires membership (global admins are not implicitly members)."""

    def dep(project_id: int, u: User = Depends(current_user), db: Session = Depends(get_db)) -> ProjectAccess:
        p = db.get(Project, project_id)
        if p is None:
            raise HTTPException(404, "project not found")
        m = db.execute(select(Membership).where(Membership.project_id == project_id,
                                                Membership.user_id == u.id)).scalar_one_or_none()
        if m is None:
            # do not reveal confidential project contents to non-members
            raise HTTPException(status.HTTP_403_FORBIDDEN, "not a member of this project")
        if not has_role(m.role, min_role):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"project role '{min_role}' required")
        return ProjectAccess(p, u, m.role)

    return dep
