"""FastAPI application: TERTIUSMEDICO — Formulation Lab."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from ..config import get_settings
from .routers import analysis, core, experiments, lab, ml

DESCRIPTION = """
Research platform for **non-clinical** formulation science: materials registry, constrained formulations,
design of experiments, measurement management, reproducible ML with uncertainty and abstention,
multi-objective recommendations with mandatory scientific review, stability trends, process simulation,
combination-research analysis and traceable reports.

Every response distinguishes **MEASURED**, **CALCULATED**, **PREDICTED** and **APPROVED** records.
Nothing produced here is a laboratory instruction, manufacturing release, shelf-life assignment or treatment
recommendation, and no regulatory compliance is claimed.
"""


def create_app() -> FastAPI:
    s = get_settings()
    s.resolved_secret()  # fail fast in production without a secret
    app = FastAPI(title="TERTIUSMEDICO — Formulation Lab API", version="0.1.0", description=DESCRIPTION)
    app.add_middleware(CORSMiddleware, allow_origins=list(s.cors_origins), allow_credentials=False,
                       allow_methods=["GET", "POST", "PUT"], allow_headers=["Authorization", "Content-Type"])
    for r in (core.router, lab.router, experiments.router, ml.router, analysis.router):
        app.include_router(r)

    @app.get("/api/health", tags=["meta"])
    def health():
        return {"status": "ok", "env": s.env}

    @app.middleware("http")
    async def security_headers(request, call_next):
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        return resp

    return app


app = create_app()
