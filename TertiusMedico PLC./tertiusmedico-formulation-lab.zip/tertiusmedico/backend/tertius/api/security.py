from __future__ import annotations

from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from ..config import get_settings

ALGORITHM = "HS256"


def hash_password(pw: str) -> str:
    if len(pw) < 10:
        raise ValueError("password must be at least 10 characters")
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(rounds=12)).decode()


def verify_password(pw: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), hashed.encode())
    except ValueError:
        return False


def create_token(username: str) -> str:
    s = get_settings()
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": username, "iat": now, "exp": now + timedelta(minutes=s.token_minutes)},
                      s.resolved_secret(), algorithm=ALGORITHM)


def decode_token(token: str) -> str:
    payload = jwt.decode(token, get_settings().resolved_secret(), algorithms=[ALGORITHM])
    return payload["sub"]
