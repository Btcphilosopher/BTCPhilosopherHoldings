"""Formulations, research domains (constraints), designs of experiments, mass balance."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ... import audit
from ...db.models import DesignRecord, Formulation, FormulationRevision, ResearchDomainRecord
from ...db.session import get_db
from ...science.composition import (DocumentedLoss, formulation_from_dict, formulation_to_dict, mass_balance,
                                    validate_formulation)
from ...science.constraints import ResearchDomain, analyse_feasibility, check_candidate, is_admissible
from ...science.doe import WHY_NOT_BOX_SAMPLING, DesignSpec, generate_design
from ...science.units import DimensionError, Quantity, UnitParseError
from ...science.workflow import has_role
from ...services import content_hash, jsonable, load_domain, material_map
from ..deps import ProjectAccess, project_access

router = APIRouter(prefix="/api/projects/{project_id}")


# ---------------------------------------------------------------- formulations
class FormulationIn(BaseModel):
    formulation_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,64}$")
    content: dict[str, Any]


def _link_materials(db, pid, content: dict, ref: str) -> None:
    for ing in content.get("ingredients", []):
        audit.link(db, pid, "material_lot", f"{ing['material_id']}@v{ing.get('material_version', 1)}:{ing.get('lot') or 'unspecified'}",
                   "formulation_revision", ref, "ingredient_of")


def _validate(db, pid, content: dict) -> dict:
    try:
        f = formulation_from_dict(content)
    except (KeyError, ValueError, UnitParseError, DimensionError) as e:
        raise HTTPException(422, f"invalid formulation: {e}")
    return validate_formulation(f, material_map(db, pid)).as_dict()


@router.post("/formulations", tags=["formulations"])
def create_formulation(body: FormulationIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    pid = acc.project.id
    if db.execute(select(Formulation).where(Formulation.project_id == pid,
                                            Formulation.formulation_id == body.formulation_id)).scalar_one_or_none():
        raise HTTPException(409, "formulation exists; create a revision")
    content = dict(body.content, formulation_id=body.formulation_id, revision=1)
    val = _validate(db, pid, content)
    f = Formulation(project_id=pid, formulation_id=body.formulation_id, name=content.get("name", body.formulation_id),
                    family=content.get("family"))
    db.add(f); db.flush()
    rev = FormulationRevision(formulation_pk=f.id, revision=1, content=content, content_hash=content_hash(content),
                              validation=jsonable(val), created_by=acc.user.username)
    db.add(rev)
    _link_materials(db, pid, content, f"{body.formulation_id}@1")
    audit.record(db, acc.user.username, "create_formulation", "formulation_revision", f"{body.formulation_id}@1",
                 pid, {"hash": rev.content_hash, "valid": val["ok"]})
    db.commit()
    return {"formulation_id": body.formulation_id, "revision": 1, "status": "draft", "validation": val}


@router.get("/formulations", tags=["formulations"])
def list_formulations(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    out = []
    for f in db.execute(select(Formulation).where(Formulation.project_id == acc.project.id)).scalars():
        out.append({"formulation_id": f.formulation_id, "name": f.name, "family": f.family,
                    "revisions": [{"revision": r.revision, "status": r.status, "content_hash": r.content_hash,
                                   "valid": (r.validation or {}).get("ok"), "approved_by": r.approved_by}
                                  for r in f.revisions]})
    return out


def _rev(db, pid, formulation_id, revision) -> tuple[Formulation, FormulationRevision]:
    f = db.execute(select(Formulation).where(Formulation.project_id == pid,
                                             Formulation.formulation_id == formulation_id)).scalar_one_or_none()
    if f is None:
        raise HTTPException(404, "formulation not found")
    r = next((r for r in f.revisions if r.revision == revision), None)
    if r is None:
        raise HTTPException(404, "revision not found")
    return f, r


@router.get("/formulations/{formulation_id}/revisions/{revision}", tags=["formulations"])
def get_revision(formulation_id: str, revision: int, acc: ProjectAccess = Depends(project_access()),
                 db: Session = Depends(get_db)):
    f, r = _rev(db, acc.project.id, formulation_id, revision)
    return {"formulation_id": formulation_id, "revision": r.revision, "status": r.status, "content": r.content,
            "content_hash": r.content_hash, "validation": r.validation, "created_by": r.created_by,
            "approved_by": r.approved_by, "approved_at": r.approved_at}


class ContentIn(BaseModel):
    content: dict[str, Any]


@router.put("/formulations/{formulation_id}/revisions/{revision}", tags=["formulations"])
def edit_revision(formulation_id: str, revision: int, body: ContentIn, acc: ProjectAccess = Depends(project_access()),
                  db: Session = Depends(get_db)):
    f, r = _rev(db, acc.project.id, formulation_id, revision)
    if r.status != "draft":
        raise HTTPException(409, f"revision is {r.status}; changes require a new revision")
    content = dict(body.content, formulation_id=formulation_id, revision=revision)
    r.validation = jsonable(_validate(db, acc.project.id, content))
    r.content, r.content_hash = content, content_hash(content)
    audit.record(db, acc.user.username, "edit_formulation", "formulation_revision", f"{formulation_id}@{revision}",
                 acc.project.id, {"hash": r.content_hash})
    db.commit()
    return {"revision": revision, "validation": r.validation}


@router.post("/formulations/{formulation_id}/revisions", tags=["formulations"])
def new_revision(formulation_id: str, body: ContentIn, acc: ProjectAccess = Depends(project_access()),
                 db: Session = Depends(get_db)):
    f = db.execute(select(Formulation).where(Formulation.project_id == acc.project.id,
                                             Formulation.formulation_id == formulation_id)).scalar_one_or_none()
    if f is None:
        raise HTTPException(404, "formulation not found")
    n = max(r.revision for r in f.revisions) + 1
    content = dict(body.content, formulation_id=formulation_id, revision=n)
    val = _validate(db, acc.project.id, content)
    r = FormulationRevision(formulation_pk=f.id, revision=n, content=content, content_hash=content_hash(content),
                            validation=jsonable(val), created_by=acc.user.username)
    db.add(r)
    _link_materials(db, acc.project.id, content, f"{formulation_id}@{n}")
    audit.record(db, acc.user.username, "new_formulation_revision", "formulation_revision", f"{formulation_id}@{n}",
                 acc.project.id, {"hash": r.content_hash})
    db.commit()
    return {"formulation_id": formulation_id, "revision": n, "validation": val}


class DecisionIn(BaseModel):
    decision: str = Field(pattern="^(submit|approve|return)$")
    reason: str | None = None


@router.post("/formulations/{formulation_id}/revisions/{revision}/review", tags=["formulations"])
def review_revision(formulation_id: str, revision: int, body: DecisionIn,
                    acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    f, r = _rev(db, acc.project.id, formulation_id, revision)
    if body.decision == "submit":
        if r.status != "draft":
            raise HTTPException(409, "only drafts can be submitted")
        if not (r.validation or {}).get("ok"):
            raise HTTPException(409, "validation errors must be resolved before review")
        r.status = "in_review"
    else:
        if not has_role(acc.role, "reviewer"):
            raise HTTPException(403, "reviewer role required")
        if r.created_by == acc.user.username:
            raise HTTPException(403, "separation of duties: cannot review own formulation")
        if r.status != "in_review":
            raise HTTPException(409, "revision is not in review")
        if body.decision == "approve":
            for other in f.revisions:
                if other.status == "approved":
                    other.status = "superseded"
            r.status, r.approved_by, r.approved_at = "approved", acc.user.username, datetime.now(timezone.utc)
        else:
            r.status = "draft"
    audit.record(db, acc.user.username, f"formulation_{body.decision}", "formulation_revision",
                 f"{formulation_id}@{revision}", acc.project.id, {"hash": r.content_hash, "reason": body.reason})
    db.commit()
    return {"formulation_id": formulation_id, "revision": revision, "status": r.status}


class MassBalanceIn(BaseModel):
    inputs: list[dict]
    output: dict | None = None
    losses: list[dict] = []
    tolerance: float = 0.02


@router.post("/calculations/mass-balance", tags=["formulations"])
def calc_mass_balance(body: MassBalanceIn, acc: ProjectAccess = Depends(project_access())):
    try:
        mb = mass_balance([Quantity.from_dict(q) for q in body.inputs],
                          Quantity.from_dict(body.output) if body.output else None,
                          [DocumentedLoss(l["stage"], Quantity.from_dict(l["mass"]), l["reason"], bool(l["measured"]))
                           for l in body.losses], body.tolerance)
    except (DimensionError, UnitParseError, KeyError) as e:
        raise HTTPException(422, str(e))
    return {"label": "CALCULATED", **mb.as_dict()}


# ---------------------------------------------------------------- research domains
class DomainIn(BaseModel):
    content: dict[str, Any]


@router.post("/domains", tags=["constraints"])
def create_domain(body: DomainIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    try:
        dom = ResearchDomain.from_dict(body.content)
    except (KeyError, TypeError, ValueError) as e:
        raise HTTPException(422, f"invalid research domain: {e}")
    existing = db.execute(select(ResearchDomainRecord).where(ResearchDomainRecord.project_id == acc.project.id,
                                                             ResearchDomainRecord.name == dom.name)).scalars().all()
    dom.version = 1 + max((e.version for e in existing), default=0)
    content = dom.to_dict()
    feas = analyse_feasibility(dom).as_dict()
    rec = ResearchDomainRecord(project_id=acc.project.id, name=dom.name, version=dom.version, content=content,
                               content_hash=content_hash(content), feasibility=jsonable(feas),
                               created_by=acc.user.username)
    db.add(rec); db.flush()
    audit.record(db, acc.user.username, "create_domain", "research_domain", rec.id, acc.project.id,
                 {"version": dom.version, "feasible": feas["feasible"], "hash": rec.content_hash})
    db.commit()
    return {"id": rec.id, "version": dom.version, "status": rec.status, "feasibility": feas}


@router.get("/domains", tags=["constraints"])
def list_domains(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    return [{"id": r.id, "name": r.name, "version": r.version, "status": r.status, "content": r.content,
             "feasibility": r.feasibility, "approved_by": r.approved_by}
            for r in db.execute(select(ResearchDomainRecord).where(ResearchDomainRecord.project_id == acc.project.id)
                                .order_by(ResearchDomainRecord.id)).scalars()]


@router.post("/domains/{domain_id}/approve", tags=["constraints"])
def approve_domain(domain_id: int, acc: ProjectAccess = Depends(project_access("reviewer")),
                   db: Session = Depends(get_db)):
    rec, dom = load_domain(db, acc.project.id, domain_id)
    if rec.created_by == acc.user.username:
        raise HTTPException(403, "separation of duties: cannot approve own research domain")
    feas = analyse_feasibility(dom)
    if not feas.feasible or feas.blocked:
        raise HTTPException(409, {"message": "domain is infeasible or blocked", "feasibility": jsonable(feas.as_dict())})
    rec.status, rec.approved_by, rec.approved_at = "approved", acc.user.username, datetime.now(timezone.utc)
    audit.record(db, acc.user.username, "approve_domain", "research_domain", rec.id, acc.project.id,
                 {"hash": rec.content_hash})
    db.commit()
    return {"id": rec.id, "status": rec.status}


class CandidateIn(BaseModel):
    composition: dict[str, float]
    process: dict[str, float] = {}


@router.post("/domains/{domain_id}/check", tags=["constraints"])
def check(domain_id: int, body: CandidateIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    _, dom = load_domain(db, acc.project.id, domain_id)
    checks = check_candidate(dom, body.composition, body.process)
    return {"admissible": is_admissible(checks), "checks": [c.as_dict() for c in checks]}


# ---------------------------------------------------------------- designs
class DesignIn(BaseModel):
    domain_id: int
    spec: dict[str, Any] = {}


@router.post("/designs", tags=["design"])
def create_design(body: DesignIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    rec, dom = load_domain(db, acc.project.id, body.domain_id, require_approved=True)
    try:
        spec = DesignSpec(**body.spec)
        design = generate_design(dom, spec)
    except (TypeError, ValueError) as e:
        raise HTTPException(422, str(e))
    result = jsonable(design.as_dict())
    d = DesignRecord(project_id=acc.project.id, domain_pk=rec.id, spec=jsonable(spec.__dict__), result=result,
                     created_by=acc.user.username)
    db.add(d); db.flush()
    audit.record(db, acc.user.username, "create_design", "design", d.id, acc.project.id,
                 {"runs": result["budget"]["runs"], "domain": rec.id})
    db.commit()
    return {"id": d.id, **result}


@router.get("/designs", tags=["design"])
def list_designs(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    return [{"id": d.id, "domain_id": d.domain_pk, "budget": d.result["budget"], "created_at": d.created_at}
            for d in db.execute(select(DesignRecord).where(DesignRecord.project_id == acc.project.id)).scalars()]


@router.get("/designs/{design_id}", tags=["design"])
def get_design(design_id: int, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    d = db.get(DesignRecord, design_id)
    if d is None or d.project_id != acc.project.id:
        raise HTTPException(404, "design not found")
    return {"id": d.id, "domain_id": d.domain_pk, "spec": d.spec, **d.result}


@router.get("/designs-rationale", tags=["design"])
def design_rationale(acc: ProjectAccess = Depends(project_access())):
    return {"why_not_unconstrained_sampling": WHY_NOT_BOX_SAMPLING}
