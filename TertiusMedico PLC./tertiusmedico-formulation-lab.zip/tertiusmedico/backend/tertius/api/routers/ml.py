"""Model training/evaluation, predictions with abstention, proposals and their review."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ... import audit
from ...db.models import RawFile, Dataset, ModelRun, PredictionRecord, Proposal, ProposalBatch
from ...db.session import get_db
from ...science.ml.pipeline import TrainingConfig, dataset_hash, train_and_evaluate
from ...science.optimisation.bo_adapter import OptunaAdapter
from ...science.optimisation.recommend import Recommender
from ...services import (DEFAULT_OBJECTIVES, OPTIONAL_OBJECTIVES, bo_history, jsonable, latest_models, load_domain,
                         measurement_frame, store_model)
from ..deps import ProjectAccess, project_access
from .experiments import create_experiment_record, target_specs

router = APIRouter(prefix="/api/projects/{project_id}")


class TrainIn(BaseModel):
    target: str
    split_by: str | None = "batch_id"
    time_cutoff: str | None = None
    test_fraction: float = Field(0.25, gt=0.05, lt=0.6)
    seed: int = 7
    alpha: float = Field(0.10, gt=0.0, lt=0.5)
    models: list[str] = ["mean_baseline", "scheffe_ridge", "random_forest", "gaussian_process"]
    experiment_states: list[str] = ["accepted"]
    supported_domain: str = ""


@router.post("/models/train", tags=["models"])
def train(body: TrainIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    specs = target_specs(db, acc.project.id)
    if body.target not in specs:
        raise HTTPException(422, f"target {body.target!r} is not defined (units, method, horizon required)")
    df, excl = measurement_frame(db, acc.project.id, body.experiment_states)
    if df.empty or (df["target"] == body.target).sum() == 0:
        raise HTTPException(409, f"no measurements from experiments in states {body.experiment_states}")
    mix = sorted(c for c in df.columns if c.startswith("mix:"))
    proc = sorted(c for c in df.columns if c.startswith("proc:"))
    cfg = TrainingConfig(specs[body.target], mix, proc, body.split_by, body.time_cutoff, body.test_fraction, body.seed,
                         body.alpha, tuple(body.models), supported_domain=body.supported_domain,
                         prediction_horizon=specs[body.target].horizon)
    try:
        result = train_and_evaluate(df, cfg)
    except (ValueError, KeyError) as e:
        raise HTTPException(422, str(e))
    result.manifest["experiment_selection"] = {"states": body.experiment_states, **excl}
    tdf = df[df["target"] == body.target]
    ds = Dataset(project_id=acc.project.id, target=body.target, sha256=dataset_hash(tdf),
                 measurement_ids=sorted(tdf["measurement_id"].tolist()))
    db.add(ds); db.flush()
    key, sha = store_model(acc.project.id, result)
    run = ModelRun(project_id=acc.project.id, dataset_pk=ds.id, target=body.target, manifest=jsonable(result.manifest),
                   manifest_hash=result.manifest_hash, artifact_key=key, artifact_sha256=sha,
                   selected_model=result.selected, created_by=acc.user.username)
    db.add(run); db.flush()
    for fpk in sorted({int(x) for x in tdf["raw_file_pk"].dropna()}):
        rf = db.get(RawFile, fpk)
        audit.link(db, acc.project.id, "raw_measurement", f"file:{rf.sha256[:16]}", "training_dataset",
                   ds.sha256[:16], "contributes")
    audit.link(db, acc.project.id, "training_dataset", ds.sha256[:16], "model", run.id, "trains")
    audit.record(db, acc.user.username, "train_model", "model_run", run.id, acc.project.id,
                 {"target": body.target, "dataset_sha256": ds.sha256, "manifest_sha256": run.manifest_hash,
                  "selected": result.selected})
    db.commit()
    return {"id": run.id, "target": body.target, "selected_model": result.selected, "manifest": run.manifest,
            "test_predictions": jsonable(result.test_predictions.to_dict(orient="list"))}


@router.get("/models", tags=["models"])
def list_models(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    return [{"id": r.id, "target": r.target, "selected_model": r.selected_model, "status": r.status,
             "manifest_hash": r.manifest_hash, "created_at": r.created_at, "created_by": r.created_by,
             "results": r.manifest.get("results"), "warnings": r.manifest.get("warnings"),
             "exclusions": r.manifest.get("exclusions"), "variability": r.manifest.get("variability"),
             "calibration_status": r.manifest.get("calibration_status"),
             "dataset_sha256": r.manifest.get("dataset_sha256")}
            for r in db.execute(select(ModelRun).where(ModelRun.project_id == acc.project.id)
                                .order_by(ModelRun.id.desc())).scalars()]


@router.get("/models/{run_id}", tags=["models"])
def get_model(run_id: int, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    r = db.get(ModelRun, run_id)
    if r is None or r.project_id != acc.project.id:
        raise HTTPException(404, "model run not found")
    return {"id": r.id, "target": r.target, "status": r.status, "manifest": r.manifest,
            "artifact_sha256": r.artifact_sha256, "dataset_id": r.dataset_pk}


class ReviewIn(BaseModel):
    decision: Literal["approve", "reject", "accept", "retire"]
    reason: str | None = None


@router.post("/models/{run_id}/review", tags=["models"])
def review_model(run_id: int, body: ReviewIn, acc: ProjectAccess = Depends(project_access("reviewer")),
                 db: Session = Depends(get_db)):
    r = db.get(ModelRun, run_id)
    if r is None or r.project_id != acc.project.id:
        raise HTTPException(404, "model run not found")
    if r.created_by == acc.user.username:
        raise HTTPException(403, "separation of duties: cannot approve own model run")
    r.status = {"approve": "approved_for_use", "accept": "approved_for_use", "reject": "retired",
                "retire": "retired"}[body.decision]
    audit.record(db, acc.user.username, f"model_{body.decision}", "model_run", r.id, acc.project.id,
                 {"reason": body.reason, "manifest_sha256": r.manifest_hash})
    db.commit()
    return {"id": r.id, "status": r.status}


class CandidateIn(BaseModel):
    domain_id: int
    composition: dict[str, float]
    process: dict[str, float] = {}
    targets: list[str] | None = None


def _recommender(db, pid, domain_id, targets=None):
    rec, dom = load_domain(db, pid, domain_id, require_approved=True)
    targets = targets or [o.target for o in DEFAULT_OBJECTIVES if o.target]
    bundle, runs, warns = latest_models(db, pid, targets)
    first = targets[0]
    rf = bundle.results[first].train_frame
    if rf is None:
        raise HTTPException(409, "model artefact lacks its training frame")
    mix = [c for c in bundle.results[first].feature_names if c.startswith("mix:")]
    proc = [c for c in bundle.results[first].feature_names if c.startswith("proc:")]
    return rec, dom, Recommender(dom, bundle, DEFAULT_OBJECTIVES, rf, mix, proc, first), runs, warns


@router.post("/candidates/evaluate", tags=["optimisation"])
def evaluate_candidate(body: CandidateIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    rec, dom, recm, runs, warns = _recommender(db, acc.project.id, body.domain_id, body.targets)
    ev = jsonable(recm.evaluate(body.composition, body.process))
    ev["model_runs"] = [r.id for r in runs]
    ev["warnings"] = warns
    pr = PredictionRecord(project_id=acc.project.id, model_run_pks=[r.id for r in runs],
                          input=jsonable(body.model_dump()), output=ev, created_by=acc.user.username)
    db.add(pr); db.flush()
    for r in runs:
        audit.link(db, acc.project.id, "model", r.id, "prediction", pr.id, "predicts")
    audit.record(db, acc.user.username, "evaluate_candidate", "prediction", pr.id, acc.project.id,
                 {"decision": ev["decision"]})
    db.commit()
    return {"prediction_id": pr.id, **ev}


class ProposeIn(BaseModel):
    domain_id: int
    n: int = Field(5, ge=1, le=20)
    strategy: Literal["baseline", "bayesian"] = "baseline"
    bo_sampler: Literal["tpe", "gp"] = "tpe"
    pool_size: int = Field(1500, ge=100, le=10000)
    seed: int = 0
    include_process_time: bool = False


@router.post("/proposals", tags=["optimisation"])
def propose(body: ProposeIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    rec, dom, recm, runs, warns = _recommender(db, acc.project.id, body.domain_id)
    if body.include_process_time:
        recm.objectives.append(OPTIONAL_OBJECTIVES["process_time"])
    bo = []
    if body.strategy == "bayesian":
        frame, _ = measurement_frame(db, acc.project.id, ["accepted"])
        hist = bo_history(frame)
        if len(hist) < 10:
            raise HTTPException(409, f"Bayesian optimisation needs ≥10 measured runs; have {len(hist)}")
        try:
            sugg = OptunaAdapter(dom, ["min", "min"], body.bo_sampler, body.seed).suggest(hist, max(2, body.n // 2))
        except RuntimeError as e:
            raise HTTPException(409, str(e))
        bo = [(s.composition, s.process, s.backend) for s in sugg]
    result = jsonable(recm.recommend(body.n, body.pool_size, body.seed, bo))
    result["model_runs"] = [r.id for r in runs]
    result["warnings"] = warns
    result["strategy"] = body.strategy
    batch = ProposalBatch(project_id=acc.project.id, domain_pk=rec.id, model_run_pks=[r.id for r in runs],
                          result={k: v for k, v in result.items() if k != "proposals"}, created_by=acc.user.username)
    db.add(batch); db.flush()
    out = []
    for p in result["proposals"]:
        pr = Proposal(batch_pk=batch.id, code=f"B{batch.id}-{p['proposal_id']}", content=p)
        db.add(pr); db.flush()
        db.add(PredictionRecord(project_id=acc.project.id, model_run_pks=[r.id for r in runs], proposal_pk=pr.id,
                                input={"composition": p["composition"], "process": p["process"]},
                                output={"predictions": p["predictions"]}, created_by=acc.user.username))
        for r in runs:
            audit.link(db, acc.project.id, "model", r.id, "prediction", pr.code, "predicts")
        out.append({**p, "id": pr.id, "code": pr.code, "status": pr.status})
    audit.record(db, acc.user.username, "propose_experiments", "proposal_batch", batch.id, acc.project.id,
                 {"n": len(out), "strategy": body.strategy, "stats": result["stats"]})
    db.commit()
    return {"batch_id": batch.id, **{k: v for k, v in result.items() if k != "proposals"}, "proposals": out}


@router.get("/proposals", tags=["optimisation"])
def list_batches(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    out = []
    for b in db.execute(select(ProposalBatch).where(ProposalBatch.project_id == acc.project.id)
                        .order_by(ProposalBatch.id.desc())).scalars():
        props = db.execute(select(Proposal).where(Proposal.batch_pk == b.id)).scalars().all()
        out.append({"batch_id": b.id, "created_at": b.created_at, "created_by": b.created_by, **b.result,
                    "proposals": [{**p.content, "id": p.id, "code": p.code, "status": p.status,
                                   "reviewed_by": p.reviewed_by, "review_reason": p.review_reason,
                                   "experiment_pk": p.experiment_pk} for p in props]})
    return out


class ProposalReviewIn(BaseModel):
    decision: Literal["accept", "reject"]
    reason: str = Field(min_length=3)
    replicates: int = Field(3, ge=1, le=10)
    experiment_code: str | None = None


@router.post("/proposals/{proposal_id}/review", tags=["optimisation"])
def review_proposal(proposal_id: int, body: ProposalReviewIn, acc: ProjectAccess = Depends(project_access("reviewer")),
                    db: Session = Depends(get_db)):
    p = db.get(Proposal, proposal_id)
    b = db.get(ProposalBatch, p.batch_pk) if p else None
    if p is None or b.project_id != acc.project.id:
        raise HTTPException(404, "proposal not found")
    if p.status != "proposed":
        raise HTTPException(409, f"proposal already {p.status}")
    if b.created_by == acc.user.username:
        raise HTTPException(403, "separation of duties: cannot review proposals you generated")
    now = datetime.now(timezone.utc)
    p.reviewed_by, p.reviewed_at, p.review_reason = acc.user.username, now, body.reason
    exp_code = None
    if body.decision == "reject":
        p.status = "rejected"
    else:
        c = p.content
        runs = [{"run_id": f"{p.code}-R{i + 1}", "design_point": p.code, "replicate": i + 1, "replicate_group": p.code,
                 "role": "proposal", **{f"mix:{k}": v for k, v in c["composition"].items()},
                 **{f"proc:{k}": v for k, v in c["process"].items()}} for i in range(body.replicates)]
        exp_code = body.experiment_code or f"EXP-{p.code}"
        plan = {"source": "reviewed_proposal", "proposal": p.code, "domain_id": b.domain_pk, "runs": runs,
                "predictions_at_proposal": c["predictions"], "review_reason": body.reason,
                "note": "Draft plan created from an accepted proposal. It must pass scientific review before execution."}
        e = create_experiment_record(db, acc.project.id, acc.user.username, exp_code,
                                     f"Follow-up of proposal {p.code}", jsonable(plan), proposal_pk=p.id)
        p.status, p.experiment_pk = "accepted_for_planning", e.id
        audit.link(db, acc.project.id, "prediction", p.code, "reviewed_decision", f"review:{p.code}", "reviewed")
        audit.link(db, acc.project.id, "reviewed_decision", f"review:{p.code}", "experiment", exp_code, "plans")
    if body.decision == "reject":
        audit.link(db, acc.project.id, "prediction", p.code, "reviewed_decision", f"review:{p.code}", "reviewed")
    audit.record(db, acc.user.username, f"proposal_{body.decision}", "proposal", p.code, acc.project.id,
                 {"reason": body.reason, "experiment": exp_code})
    db.commit()
    return {"id": p.id, "code": p.code, "status": p.status, "experiment_code": exp_code}
