"""Auth, users, projects, memberships, materials, files, audit."""

from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import Response
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ... import audit
from ...config import get_settings
from ...db.models import (AuditLog, Experiment, Material, MaterialVersion, Membership, ModelRun, Project, RawFile,
                          User)
from ...db.session import get_db
from ...science.materials import MaterialRecord
from ...storage import UploadRejected, get_storage, validate_upload
from ..deps import ProjectAccess, current_user, project_access, require_admin
from ..security import create_token, hash_password, verify_password

router = APIRouter(prefix="/api")


# ---------------------------------------------------------------- auth
class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


@router.post("/auth/token", response_model=TokenOut, tags=["auth"])
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.username == form.username)).scalar_one_or_none()
    if u is None or not u.active or not verify_password(form.password, u.password_hash):
        audit.record(db, form.username or "?", "login_failed", "user", form.username or "?")
        db.commit()
        raise HTTPException(401, "incorrect username or password")
    audit.record(db, u.username, "login", "user", u.username)
    db.commit()
    return TokenOut(access_token=create_token(u.username))


class UserOut(BaseModel):
    id: int
    username: str
    full_name: str
    is_admin: bool


@router.get("/auth/me", response_model=UserOut, tags=["auth"])
def me(u: User = Depends(current_user)):
    return UserOut(id=u.id, username=u.username, full_name=u.full_name, is_admin=u.is_admin)


class UserIn(BaseModel):
    username: str = Field(pattern=r"^[a-z0-9_.-]{3,64}$")
    full_name: str = ""
    password: str = Field(min_length=10)
    is_admin: bool = False


@router.post("/admin/users", response_model=UserOut, tags=["admin"])
def create_user(body: UserIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    if db.execute(select(User).where(User.username == body.username)).scalar_one_or_none():
        raise HTTPException(409, "username exists")
    u = User(username=body.username, full_name=body.full_name, password_hash=hash_password(body.password),
             is_admin=body.is_admin)
    db.add(u); db.flush()
    audit.record(db, admin.username, "create_user", "user", u.username, detail={"is_admin": body.is_admin})
    db.commit()
    return UserOut(id=u.id, username=u.username, full_name=u.full_name, is_admin=u.is_admin)


# ---------------------------------------------------------------- projects
class ProjectIn(BaseModel):
    code: str = Field(pattern=r"^[A-Z0-9-]{2,40}$")
    name: str
    description: str = ""
    confidential: bool = True
    synthetic: bool = False


@router.post("/projects", tags=["projects"])
def create_project(body: ProjectIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    p = Project(**body.model_dump(), created_by=admin.username)
    db.add(p); db.flush()
    db.add(Membership(project_id=p.id, user_id=admin.id, role="admin"))
    audit.record(db, admin.username, "create_project", "project", p.code, p.id)
    db.commit()
    return {"id": p.id, "code": p.code}


@router.get("/projects", tags=["projects"])
def my_projects(u: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.execute(select(Project, Membership.role).join(Membership, Membership.project_id == Project.id)
                      .where(Membership.user_id == u.id)).all()
    return [{"id": p.id, "code": p.code, "name": p.name, "description": p.description, "role": role,
             "synthetic": p.synthetic, "confidential": p.confidential} for p, role in rows]


@router.get("/projects/{project_id}", tags=["projects"])
def project_summary(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    pid = acc.project.id
    count = lambda model: db.execute(select(func.count()).select_from(model).where(model.project_id == pid)).scalar()  # noqa
    states = dict(db.execute(select(Experiment.state, func.count()).where(Experiment.project_id == pid)
                             .group_by(Experiment.state)).all())
    return {"id": pid, "code": acc.project.code, "name": acc.project.name, "role": acc.role,
            "synthetic": acc.project.synthetic, "materials": count(Material), "experiments_by_state": states,
            "model_runs": count(ModelRun)}


class MemberIn(BaseModel):
    username: str
    role: Literal["researcher", "reviewer", "admin"]


@router.post("/projects/{project_id}/members", tags=["projects"])
def add_member(body: MemberIn, acc: ProjectAccess = Depends(project_access("admin")), db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.username == body.username)).scalar_one_or_none()
    if u is None:
        raise HTTPException(404, "user not found")
    m = db.execute(select(Membership).where(Membership.project_id == acc.project.id,
                                            Membership.user_id == u.id)).scalar_one_or_none()
    if m:
        m.role = body.role
    else:
        db.add(Membership(project_id=acc.project.id, user_id=u.id, role=body.role))
    audit.record(db, acc.user.username, "set_member_role", "membership", body.username, acc.project.id,
                 {"role": body.role})
    db.commit()
    return {"username": body.username, "role": body.role}


@router.get("/projects/{project_id}/members", tags=["projects"])
def list_members(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    rows = db.execute(select(User.username, User.full_name, Membership.role).join(Membership, Membership.user_id == User.id)
                      .where(Membership.project_id == acc.project.id)).all()
    return [{"username": a, "full_name": b, "role": c} for a, b, c in rows]


# ---------------------------------------------------------------- materials
class PropertyIn(BaseModel):
    name: str
    source: Literal["supplier_specification", "literature", "laboratory_measurement", "model_estimate"]
    value: float | None = None
    unit: str | None = None
    text: str | None = None
    reference: str | None = None
    method: str | None = None
    uncertainty: float | None = None
    recorded_on: str | None = None


class MaterialIn(BaseModel):
    material_id: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,64}$")
    name: str
    supplier: str | None = None
    grade: str | None = None
    lot: str | None = None
    identity_reference: str | None = None
    composition: dict[str, Any] | None = None
    purity_or_assay: PropertyIn | None = None
    physical_properties: list[PropertyIn] = []
    storage_requirements: str | None = None
    expiry_or_retest_date: str | None = None
    hazard_document_references: list[str] = []
    source: str | None = None
    verification_status: Literal["unverified", "identity_confirmed", "verified", "rejected"] = "unverified"
    fictional: bool = False


def _to_record(body: MaterialIn, version: int) -> MaterialRecord:
    d = body.model_dump()
    d["version"] = version
    try:
        return MaterialRecord.from_dict(d)
    except (ValueError, TypeError) as e:
        raise HTTPException(422, str(e))


@router.post("/projects/{project_id}/materials", tags=["materials"])
def register_material(body: MaterialIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    pid = acc.project.id
    if db.execute(select(Material).where(Material.project_id == pid,
                                         Material.material_id == body.material_id)).scalar_one_or_none():
        raise HTTPException(409, "material exists; create a new version instead")
    rec = _to_record(body, 1)
    m = Material(project_id=pid, material_id=rec.material_id, current_version=1)
    db.add(m); db.flush()
    db.add(MaterialVersion(material_pk=m.id, version=1, content=rec.to_dict(), content_hash=rec.content_hash(),
                           created_by=acc.user.username, change_note="initial registration"))
    audit.record(db, acc.user.username, "register_material", "material", f"{rec.material_id}@1", pid,
                 {"hash": rec.content_hash()})
    db.commit()
    return {"material_id": rec.material_id, "version": 1, "content_hash": rec.content_hash(),
            "missing_properties": rec.missing(["density", "molar_mass"])}


class MaterialRevisionIn(BaseModel):
    record: MaterialIn
    change_note: str = Field(min_length=3)


@router.post("/projects/{project_id}/materials/{material_id}/versions", tags=["materials"])
def revise_material(material_id: str, body: MaterialRevisionIn, acc: ProjectAccess = Depends(project_access()),
                    db: Session = Depends(get_db)):
    m = db.execute(select(Material).where(Material.project_id == acc.project.id,
                                          Material.material_id == material_id)).scalar_one_or_none()
    if m is None:
        raise HTTPException(404, "material not found")
    if body.record.material_id != material_id:
        raise HTTPException(422, "material_id is immutable")
    prev = db.execute(select(MaterialVersion).where(MaterialVersion.material_pk == m.id,
                                                    MaterialVersion.version == m.current_version)).scalar_one()
    rec = _to_record(body.record, m.current_version + 1)
    if rec.content_hash() == prev.content_hash:
        raise HTTPException(409, "no changes relative to the current version")
    m.current_version = rec.version
    db.add(MaterialVersion(material_pk=m.id, version=rec.version, content=rec.to_dict(),
                           content_hash=rec.content_hash(), created_by=acc.user.username, change_note=body.change_note))
    audit.record(db, acc.user.username, "revise_material", "material", f"{material_id}@{rec.version}",
                 acc.project.id, {"prev_hash": prev.content_hash, "hash": rec.content_hash(), "note": body.change_note})
    db.commit()
    return {"material_id": material_id, "version": rec.version, "content_hash": rec.content_hash()}


@router.get("/projects/{project_id}/materials", tags=["materials"])
def list_materials(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    out = []
    for m in db.execute(select(Material).where(Material.project_id == acc.project.id)).scalars():
        v = m.versions[-1]
        out.append({"material_id": m.material_id, "current_version": m.current_version, "content": v.content,
                    "content_hash": v.content_hash, "updated_at": v.created_at})
    return out


@router.get("/projects/{project_id}/materials/{material_id}", tags=["materials"])
def material_history(material_id: str, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    m = db.execute(select(Material).where(Material.project_id == acc.project.id,
                                          Material.material_id == material_id)).scalar_one_or_none()
    if m is None:
        raise HTTPException(404, "material not found")
    return {"material_id": material_id, "current_version": m.current_version,
            "versions": [{"version": v.version, "content": v.content, "content_hash": v.content_hash,
                          "change_note": v.change_note, "created_by": v.created_by, "created_at": v.created_at}
                         for v in m.versions]}


# ---------------------------------------------------------------- files
@router.post("/projects/{project_id}/files", tags=["files"])
async def upload_file(file: UploadFile = File(...), acc: ProjectAccess = Depends(project_access()),
                      db: Session = Depends(get_db)):
    s = get_settings()
    data = await file.read(s.max_upload_bytes + 1)
    try:
        safe, ctype, sha = validate_upload(file.filename or "", data, s.max_upload_bytes)
    except UploadRejected as e:
        raise HTTPException(415 if "type" in str(e) or "content" in str(e) else 400, str(e))
    key = f"projects/{acc.project.id}/raw/{sha}/{safe}"
    get_storage(s).put(key, data, ctype)
    rf = RawFile(project_id=acc.project.id, object_key=key, filename=safe, content_type=ctype, size=len(data),
                 sha256=sha, uploaded_by=acc.user.username)
    db.add(rf); db.flush()
    audit.record(db, acc.user.username, "upload_file", "raw_file", rf.id, acc.project.id, {"sha256": sha, "name": safe})
    db.commit()
    return {"id": rf.id, "filename": safe, "sha256": sha, "size": len(data)}


@router.get("/projects/{project_id}/files/{file_id}", tags=["files"])
def download_file(file_id: int, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    rf = db.get(RawFile, file_id)
    if rf is None or rf.project_id != acc.project.id:
        raise HTTPException(404, "file not found")
    data = get_storage(get_settings()).get(rf.object_key)
    return Response(data, media_type=rf.content_type,
                    headers={"Content-Disposition": f'attachment; filename="{rf.filename}"',
                             "X-Content-SHA256": rf.sha256, "X-Content-Type-Options": "nosniff"})


# ---------------------------------------------------------------- audit
@router.get("/projects/{project_id}/audit", tags=["audit"])
def project_audit(limit: int = 200, acc: ProjectAccess = Depends(project_access("reviewer")),
                  db: Session = Depends(get_db)):
    rows = db.execute(select(AuditLog).where(AuditLog.project_id == acc.project.id).order_by(AuditLog.id.desc())
                      .limit(min(limit, 1000))).scalars()
    return [{"id": r.id, "ts": r.ts, "actor": r.actor, "action": r.action, "entity_type": r.entity_type,
             "entity_id": r.entity_id, "detail": r.detail, "hash": r.hash} for r in rows]


@router.get("/admin/audit/verify", tags=["admin"])
def verify_audit(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return audit.verify_chain(db)
