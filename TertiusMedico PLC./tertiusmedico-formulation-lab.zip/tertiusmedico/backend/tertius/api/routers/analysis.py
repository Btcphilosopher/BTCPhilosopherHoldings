"""Stability, process simulation, combination research, costs, lineage, reports."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ... import audit
from ...db.models import (AuditLog, CombinationDataset, Experiment, LineageEdge, Material, MaterialVersion, ModelRun,
                          PredictionRecord, Proposal, ProposalBatch, QualityFinding, RawFile, ResearchDomainRecord,
                          StabilityResult)
from ...db.session import get_db
from ...science.combination import CombinationContext, CombinationScopeError, analyse_combination
from ...science.costs import FXRate, LineItem, PriceRecord, scenario_cost
from ...science.lineage import CHAIN, LineageGraph, Node
from ...science.reporting import build_report, render_html
from ...science.simulation import Assumption, SimulationConfig, simulate_process
from ...science.stability import NOT_SHELF_LIFE, fit_trends, slope_poolability
from ...science.units import DimensionError, Quantity, UnitParseError
from ...services import jsonable
from ...storage import get_storage
from ...config import get_settings
from ..deps import ProjectAccess, project_access

router = APIRouter(prefix="/api/projects/{project_id}")


# ---------------------------------------------------------------- stability
class StabilityIn(BaseModel):
    rows: list[dict[str, Any]]


@router.post("/stability/results", tags=["stability"])
def import_stability(body: StabilityIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    need = {"stab_id", "formulation_id", "formulation_revision", "packaging", "condition", "time_months", "lot",
            "attribute", "unit", "method", "status"}
    n = 0
    for r in body.rows:
        miss = need - set(r)
        if miss:
            raise HTTPException(422, f"row {r.get('stab_id')}: missing {sorted(miss)}")
        if r["status"] == "ok" and r.get("value") is None:
            raise HTTPException(422, f"row {r['stab_id']}: status ok requires a value")
        if r["status"] == "censored" and r.get("lod") is None:
            raise HTTPException(422, f"row {r['stab_id']}: censored results need the detection limit")
        db.add(StabilityResult(project_id=acc.project.id, **{k: r.get(k) for k in need | {"value", "lod"}}))
        n += 1
    audit.record(db, acc.user.username, "import_stability", "stability", f"{n} rows", acc.project.id)
    db.commit()
    return {"imported": n}


def _stab_frame(db, pid) -> pd.DataFrame:
    rows = db.execute(select(StabilityResult).where(StabilityResult.project_id == pid)).scalars().all()
    return pd.DataFrame([{c: getattr(r, c) for c in ("stab_id", "formulation_id", "formulation_revision", "packaging",
                                                      "condition", "time_months", "lot", "attribute", "value", "unit",
                                                      "method", "status", "lod")} for r in rows])


@router.get("/stability/trends", tags=["stability"])
def stability_trends(attribute: str = "assay", formulation_id: str | None = None, forecast_to: float | None = None,
                     spec_limit: float | None = None, acc: ProjectAccess = Depends(project_access()),
                     db: Session = Depends(get_db)):
    df = _stab_frame(db, acc.project.id)
    if df.empty:
        return {"trends": [], "notice": NOT_SHELF_LIFE}
    if formulation_id:
        df = df[df.formulation_id == formulation_id]
    out = []
    for t in fit_trends(df, attribute):
        d = t.as_dict()
        horizon = forecast_to if forecast_to is not None else t.max_time * 1.5
        try:
            import numpy as np
            d["forecast"] = t.predict(np.linspace(0, horizon, 25))
        except ValueError as e:
            d["forecast"] = {"refused": str(e)}
        if spec_limit is not None:
            d["exploratory_limit_crossing"] = t.exploratory_crossing(spec_limit, "lower" if attribute == "assay" else "upper")
        out.append(d)
    pool, pools = None, []
    if formulation_id and not df.empty:
        for (pk, cond), _ in df[df.attribute == attribute].groupby(["packaging", "condition"]):
            r = slope_poolability(df, attribute, "lot", {"packaging": pk, "condition": cond})
            pools.append({"packaging": pk, "condition": cond, **r})
        pool = pools[0] if pools else None
    censored = df[(df.attribute == attribute) & (df.status == "censored")]
    return jsonable({"trends": out, "poolability_example": pool, "poolability": pools, "censored_count": int(len(censored)),
                     "notice": NOT_SHELF_LIFE})


# ---------------------------------------------------------------- simulation
class SimIn(BaseModel):
    batch_mass_g: float = Field(gt=0)
    mix_speed_rpm: float = Field(gt=0)
    mix_time_min: float = Field(ge=0)
    hold_time_h: float = Field(ge=0)
    fill_target_g: float = Field(gt=0)
    fill_tolerance_g: float = Field(gt=0)
    assumptions: dict[str, dict[str, Any]] = {}
    n_sims: int = Field(2000, ge=100, le=50000)
    seed: int = 1


@router.post("/simulations/process", tags=["simulation"])
def run_simulation(body: SimIn, acc: ProjectAccess = Depends(project_access())):
    kw = body.model_dump(exclude={"assumptions"})
    for k, a in body.assumptions.items():
        if k not in SimulationConfig.__dataclass_fields__:
            raise HTTPException(422, f"unknown assumption {k}")
        kw[k] = Assumption(**a)
    return simulate_process(SimulationConfig(**kw))


# ---------------------------------------------------------------- combination research
class CombinationIn(BaseModel):
    name: str
    context: dict[str, Any]
    rows: list[dict[str, Any]]


@router.post("/combination/datasets", tags=["combination"])
def add_combination(body: CombinationIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    try:
        ctx = CombinationContext(**body.context)
        ctx.validate()
    except (TypeError, CombinationScopeError) as e:
        raise HTTPException(422, str(e))
    for r in body.rows:
        bad = {"patient_id", "subject_id", "dose_per_kg", "prescription"} & set(r)
        if bad:
            raise HTTPException(422, f"fields {sorted(bad)} are outside the scope of this module")
    ds = CombinationDataset(project_id=acc.project.id, name=body.name, context=body.context, data=body.rows,
                            created_by=acc.user.username)
    db.add(ds); db.flush()
    audit.record(db, acc.user.username, "add_combination_dataset", "combination_dataset", ds.id, acc.project.id,
                 {"authorisation": ctx.authorisation_reference})
    db.commit()
    return {"id": ds.id}


@router.post("/combination/datasets/{ds_id}/analyse", tags=["combination"])
def analyse(ds_id: int, min_replicates: int = 3, acc: ProjectAccess = Depends(project_access()),
            db: Session = Depends(get_db)):
    ds = db.get(CombinationDataset, ds_id)
    if ds is None or ds.project_id != acc.project.id:
        raise HTTPException(404, "dataset not found")
    try:
        return jsonable(analyse_combination(pd.DataFrame(ds.data), CombinationContext(**ds.context), min_replicates))
    except CombinationScopeError as e:
        raise HTTPException(422, str(e))


# ---------------------------------------------------------------- costs
class CostLine(BaseModel):
    category: str = Field(pattern="^(ingredient|packaging|waste|processing|experiment)$")
    item: str
    quantity: dict
    price: dict


class CostIn(BaseModel):
    currency: str = Field(pattern="^[A-Z]{3}$")
    lines: list[CostLine]
    fx: list[dict] = []


@router.post("/costs/scenario", tags=["costs"])
def cost_scenario(body: CostIn, acc: ProjectAccess = Depends(project_access())):
    try:
        items = [LineItem(l.category, l.item, Quantity.from_dict(l.quantity),
                          PriceRecord(l.item, Decimal(str(l.price["amount"])), l.price["currency"], l.price["per"],
                                      l.price["price_date"], l.price.get("source", "unspecified")))
                 for l in body.lines]
        fx = {(f["from_currency"], f["to_currency"]): FXRate(f["from_currency"], f["to_currency"],
                                                             Decimal(str(f["rate"])), f["rate_date"], f["source"])
              for f in body.fx}
        return scenario_cost(items, body.currency, fx)
    except (KeyError, DimensionError, UnitParseError, ValueError) as e:
        raise HTTPException(422, str(e))


# ---------------------------------------------------------------- lineage
def _graph(db, pid) -> LineageGraph:
    g = LineageGraph()
    for e in db.execute(select(LineageEdge).where(LineageEdge.project_id == pid)).scalars():
        g.link(Node(e.parent_kind, e.parent_ref), Node(e.child_kind, e.child_ref), e.relation)
    return g


@router.get("/lineage", tags=["lineage"])
def lineage(kind: str, ref: str, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    g = _graph(db, acc.project.id)
    key = f"{kind}:{ref}"
    if key not in g.nodes:
        raise HTTPException(404, "no lineage recorded for this node")
    nodes = g.upstream(key)
    keys = {n.key for n in nodes}
    return {"node": key, "upstream": [{"kind": n.kind, "ref": n.ref} for n in nodes],
            "edges": [e for e in g.edges() if e["child"] in keys], "chain": list(CHAIN),
            "missing_links": g.missing_links(key)}


# ---------------------------------------------------------------- reports
class ReportIn(BaseModel):
    proposal_batch_id: int | None = None
    stability_formulation: str | None = None


@router.post("/reports", tags=["reports"])
def generate_report(body: ReportIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    pid = acc.project.id
    p = acc.project
    secs: dict[str, dict] = {}
    secs["scope"] = {"title": "1. Scope and status", "text": [
        f"Project {p.code} — {p.name}. {'SYNTHETIC DEMONSTRATION DATA: all materials and measurements are fictional.' if p.synthetic else ''}",
        "Intended use: non-clinical formulation research decision support."]}
    mats = []
    for m in db.execute(select(Material).where(Material.project_id == pid)).scalars():
        for v in m.versions:
            c = v.content
            mats.append({"material_id": m.material_id, "version": v.version, "name": c.get("name"),
                         "lot": c.get("lot"), "verification": c.get("verification_status"),
                         "properties": ", ".join(f"{q['name']}={q.get('value')} {q.get('unit') or ''} [{q['source']}]"
                                                 for q in c.get("physical_properties", [])) or "none recorded",
                         "hash": v.content_hash[:12]})
    secs["materials"] = {"title": "2. Materials (versioned)", "label": "MEASURED / SUPPLIER / LITERATURE as tagged",
                         "tables": [{"caption": "material versions", "rows": mats}],
                         "text": ["Missing properties are left blank; no default values are substituted."]}
    doms = db.execute(select(ResearchDomainRecord).where(ResearchDomainRecord.project_id == pid)).scalars().all()
    secs["domain"] = {"title": "3. Research domain and constraints", "label": "CALCULATED",
                      "tables": [{"caption": "domains", "rows": [{"id": d.id, "name": d.name, "version": d.version,
                                                                   "status": d.status, "approved_by": d.approved_by,
                                                                   "feasible": (d.feasibility or {}).get("feasible"),
                                                                   "warnings": (d.feasibility or {}).get("warnings")}
                                                                  for d in doms]}]}
    exps = db.execute(select(Experiment).where(Experiment.project_id == pid)).scalars().all()
    erows = []
    for e in exps:
        for r in e.revisions:
            erows.append({"experiment": e.code, "revision": r.revision, "state": r.state, "runs": len(r.plan.get("runs", [])),
                          "submitted_by": r.submitted_by, "approved_by": r.approved_by,
                          "performed_by": (r.performed or {}).get("operator"), "data_reviewed_by": r.data_reviewed_by,
                          "decision_reason": r.decision_reason})
    qf = db.execute(select(QualityFinding, Experiment.code).join(Experiment, QualityFinding.experiment_pk == Experiment.id)
                    .where(Experiment.project_id == pid)).all()
    secs["experiments"] = {"title": "4. Experiments, approvals and data quality", "label": "MEASURED",
                           "tables": [{"caption": "plan revisions and workflow", "rows": erows},
                                      {"caption": "data-quality findings",
                                       "rows": [{"experiment": c, "severity": q.severity, "code": q.code,
                                                 "message": q.message, "n_rows": len(q.rows)} for q, c in qf]}]}
    files = db.execute(select(RawFile).where(RawFile.project_id == pid)).scalars().all()
    secs["raw_files"] = {"title": "5. Raw files", "tables": [{"caption": "raw data files", "rows": [
        {"id": f.id, "filename": f.filename, "sha256": f.sha256, "size": f.size, "uploaded_by": f.uploaded_by}
        for f in files]}]}
    mrows, mwarn, excl = [], [], []
    for r in db.execute(select(ModelRun).where(ModelRun.project_id == pid)).scalars():
        man = r.manifest
        for name, res in man.get("results", {}).items():
            row = {"run": r.id, "target": r.target, "model": name, "selected": name == r.selected_model,
                   "status": r.status}
            if "test" in res:
                cov = res["coverage"].get("0.90", {})
                row.update({"inner_cv_mae": res["inner_cv_mae_model_scale"], "test_mae": res["test"]["mae"],
                            "test_r2_model_scale": res["test"]["r2_model_scale"], "n_test": res["test"]["n_test"],
                            "coverage90_empirical": cov.get("empirical")})
            else:
                row.update(res)
            mrows.append(row)
        mwarn += [f"run {r.id} ({r.target}): {w}" for w in man.get("warnings", [])]
        if man.get("calibration_status"):
            mwarn.append(f"run {r.id} ({r.target}): {man['calibration_status']}")
        for x in man.get("exclusions", []):
            excl.append({"run": r.id, "target": r.target, "status": x["status"], "count": x["count"],
                         "reason": x["reason"], "failure_reasons": x.get("failure_reasons")})
    secs["models"] = {"title": "6. Models: baselines, held-out evaluation and uncertainty coverage",
                      "label": "CALCULATED (evaluation of PREDICTED values against MEASURED held-out data)",
                      "tables": [{"caption": "model comparison", "rows": mrows},
                                 {"caption": "explicit exclusions (retained in the record)", "rows": excl}],
                      "warnings": mwarn,
                      "text": ["Model selection used grouped inner cross-validation on training data only; held-out "
                               "metrics are reported but were not used for selection. Splits are grouped so replicates "
                               "and near-identical formulations never straddle train and test."]}
    if body.proposal_batch_id:
        b = db.get(ProposalBatch, body.proposal_batch_id)
        if b is None or b.project_id != pid:
            raise HTTPException(404, "proposal batch not found")
        props = db.execute(select(Proposal).where(Proposal.batch_pk == b.id)).scalars().all()
        prow = []
        for pr in props:
            c = pr.content
            pv = c["predictions"].get("viscosity", {})
            prow.append({"code": pr.code, "strategy": c["strategy"], "status": pr.status, "reviewed_by": pr.reviewed_by,
                         "review_reason": pr.review_reason, "composition": c["composition"], "process": c["process"],
                         "viscosity_pred": f"{pv.get('mean', 0):.1f} [{pv.get('lower', 0):.1f}, {pv.get('upper', 0):.1f}]"
                         if pv else None, "reason": c["reason"], "warnings": c.get("warnings")})
        secs["proposals"] = {"title": "7. Proposed experiments and review", "label": "PREDICTED",
                             "tables": [{"caption": f"batch {b.id} ({b.result.get('strategy')})", "rows": prow},
                                        {"caption": "Pareto frontier (predicted)",
                                         "rows": [{"objective_values": f["objective_values"], "origin": f["origin"]}
                                                  for f in b.result.get("frontier", [])]}],
                             "text": [b.result.get("notice", ""), f"candidate statistics: {b.result.get('stats')}"],
                             "warnings": b.result.get("warnings", [])}
    rej = db.execute(select(PredictionRecord).where(PredictionRecord.project_id == pid,
                                                    PredictionRecord.proposal_pk.is_(None))).scalars().all()
    secs["evaluations"] = {"title": "8. Candidate evaluations (including rejections and abstentions)",
                           "tables": [{"caption": "evaluations", "rows": [
                               {"id": r.id, "decision": r.output.get("decision"), "composition": r.input.get("composition"),
                                "reasons": r.output.get("reasons"), "flags": r.output.get("domain", {}).get("flags")}
                               for r in rej]}]}
    if body.stability_formulation:
        st = stability_trends("assay", body.stability_formulation, None, 95.0, acc, db)
        secs["stability"] = {"title": "9. Stability trends (exploratory)", "label": "MEASURED + PREDICTED trend",
                             "warnings": [NOT_SHELF_LIFE],
                             "tables": [{"caption": "assay trends by condition/packaging/lot", "rows": [
                                 {**t["key"], "slope_per_month": t["slope_per_month"], "r2": t["r2"],
                                  "max_time_months": t["max_time_months"],
                                  "exploratory_crossing_95": (t.get("exploratory_limit_crossing") or {}).get("crossing_time")}
                                 for t in st["trends"]]}]}
    edges = db.execute(select(LineageEdge).where(LineageEdge.project_id == pid)).scalars().all()
    secs["lineage"] = {"title": "10. Lineage", "text": [" → ".join(CHAIN)], "tables": [{"caption": "edges", "rows": [
        {"parent": f"{e.parent_kind}:{e.parent_ref}", "relation": e.relation, "child": f"{e.child_kind}:{e.child_ref}"}
        for e in edges]}]}
    reviews = db.execute(select(AuditLog).where(AuditLog.project_id == pid).order_by(AuditLog.id)).scalars().all()
    secs["review_history"] = {"title": "11. Review and audit history", "tables": [{"caption": "audit trail (hash-chained)",
                              "rows": [{"id": a.id, "ts": a.ts, "actor": a.actor, "action": a.action,
                                        "entity": f"{a.entity_type}:{a.entity_id}", "hash": a.hash[:12]}
                                       for a in reviews]}]}
    secs["assumptions"] = {"title": "12. Assumptions, exclusions and limitations", "text": [
        "Mixture fractions are mass fractions; volumes are not assumed additive; no mass↔volume conversion without a "
        "recorded density.",
        "Unknown ingredient compatibility is treated as unknown and flagged, never as compatible.",
        "Uncertainty intervals are conformal/GP intervals at nominal levels; their empirical coverage on held-out data "
        "is reported above and small test sets make those estimates imprecise.",
        "Predictions concern laboratory measurements within the supported domain; they do not establish efficacy, "
        "bioavailability, safety, manufacturing suitability or shelf life.",
        "Regulatory compliance is not claimed. Before real pharmaceutical use, identify the jurisdiction and purpose "
        "and research applicable laboratory, manufacturing, electronic-record and quality requirements from current "
        "official sources."]}
    report = jsonable(build_report(secs, {"project": f"{p.code} — {p.name}", "generated_by": acc.user.username}))
    html_doc = render_html(report)
    key = f"projects/{pid}/reports/{report['meta']['content_sha256']}.html"
    get_storage(get_settings()).put(key, html_doc.encode(), "text/html")
    audit.record(db, acc.user.username, "generate_report", "report", report["meta"]["content_sha256"][:16], pid)
    db.commit()
    return {"report": report, "html_key": key}


@router.post("/reports/html", tags=["reports"], response_class=HTMLResponse)
def generate_report_html(body: ReportIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    out = generate_report(body, acc, db)
    return HTMLResponse(render_html(out["report"]))
