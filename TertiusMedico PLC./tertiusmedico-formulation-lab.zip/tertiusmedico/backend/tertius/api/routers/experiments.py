"""Experiments: versioned plans, workflow transitions, measurement import, deviations, data quality."""

from __future__ import annotations

import io
from datetime import datetime, timezone
from typing import Any

import pandas as pd
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ... import audit
from ...config import get_settings
from ...db.models import (DesignRecord, Deviation, Experiment, ExperimentRevision, Measurement, QualityFinding,
                          RawFile, TargetDefinition)
from ...db.session import get_db
from ...science.quality import TargetSpec, summarise, validate_measurements
from ...science.workflow import PermissionDenied, TransitionRequest, WorkflowError, check_transition
from ...services import content_hash, jsonable
from ...storage import UploadRejected, get_storage, validate_upload
from ..deps import ProjectAccess, project_access

router = APIRouter(prefix="/api/projects/{project_id}")


# ---------------------------------------------------------------- target definitions
class TargetIn(BaseModel):
    spec: dict[str, Any]
    supported_domain: str = ""


def target_specs(db: Session, pid: int) -> dict[str, TargetSpec]:
    out: dict[str, TargetSpec] = {}
    for t in db.execute(select(TargetDefinition).where(TargetDefinition.project_id == pid)
                        .order_by(TargetDefinition.version)).scalars():
        out[t.name] = TargetSpec(**t.spec)
    return out


@router.post("/targets", tags=["targets"])
def define_target(body: TargetIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    try:
        spec = TargetSpec(**body.spec)
    except TypeError as e:
        raise HTTPException(422, str(e))
    if not spec.unit or not spec.method or not spec.horizon:
        raise HTTPException(422, "a target needs units, measurement method and prediction horizon")
    prev = db.execute(select(TargetDefinition).where(TargetDefinition.project_id == acc.project.id,
                                                     TargetDefinition.name == spec.name)).scalars().all()
    t = TargetDefinition(project_id=acc.project.id, name=spec.name, version=1 + max((p.version for p in prev), default=0),
                         spec=spec.as_dict(), supported_domain=body.supported_domain, created_by=acc.user.username)
    db.add(t)
    audit.record(db, acc.user.username, "define_target", "target", f"{spec.name}@{t.version}", acc.project.id)
    db.commit()
    return {"name": spec.name, "version": t.version}


@router.get("/targets", tags=["targets"])
def list_targets(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    return [{"name": t.name, "version": t.version, "spec": t.spec, "supported_domain": t.supported_domain}
            for t in db.execute(select(TargetDefinition).where(TargetDefinition.project_id == acc.project.id)).scalars()]


# ---------------------------------------------------------------- experiments
class ExperimentIn(BaseModel):
    code: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,64}$")
    title: str
    design_id: int | None = None
    plan: dict[str, Any] = {}


def _exp(db, pid, code) -> Experiment:
    e = db.execute(select(Experiment).where(Experiment.project_id == pid, Experiment.code == code)).scalar_one_or_none()
    if e is None:
        raise HTTPException(404, "experiment not found")
    return e


def _current(e: Experiment) -> ExperimentRevision:
    return next(r for r in e.revisions if r.revision == e.current_revision)


def create_experiment_record(db: Session, pid: int, actor: str, code: str, title: str, plan: dict,
                             design_pk: int | None = None, proposal_pk: int | None = None) -> Experiment:
    if db.execute(select(Experiment).where(Experiment.project_id == pid, Experiment.code == code)).scalar_one_or_none():
        raise HTTPException(409, "experiment code exists")
    e = Experiment(project_id=pid, code=code, title=title, design_pk=design_pk, proposal_pk=proposal_pk,
                   created_by=actor)
    db.add(e); db.flush()
    db.add(ExperimentRevision(experiment_pk=e.id, revision=1, plan=plan, plan_hash=content_hash(plan),
                              created_by=actor))
    audit.record(db, actor, "create_experiment", "experiment", f"{code}@1", pid, {"plan_hash": content_hash(plan)})
    for ref in plan.get("formulation_refs", []):
        audit.link(db, pid, "formulation_revision", f"{ref['formulation_id']}@{ref['revision']}", "experiment",
                   f"{code}@1", "planned_in")
    return e


@router.post("/experiments", tags=["experiments"])
def create_experiment(body: ExperimentIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    plan = dict(body.plan)
    if body.design_id is not None:
        d = db.get(DesignRecord, body.design_id)
        if d is None or d.project_id != acc.project.id:
            raise HTTPException(404, "design not found")
        plan.setdefault("runs", d.result["runs"])
        plan.setdefault("domain_id", d.domain_pk)
        plan["design_id"] = d.id
    if not plan.get("runs"):
        raise HTTPException(422, "an experiment plan needs runs")
    e = create_experiment_record(db, acc.project.id, acc.user.username, body.code, body.title, jsonable(plan),
                                 body.design_id)
    db.commit()
    return {"code": e.code, "revision": 1, "state": e.state}


@router.get("/experiments", tags=["experiments"])
def list_experiments(acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    out = []
    for e in db.execute(select(Experiment).where(Experiment.project_id == acc.project.id).order_by(Experiment.id)).scalars():
        r = _current(e)
        out.append({"code": e.code, "title": e.title, "state": e.state, "revision": e.current_revision,
                    "runs": len(r.plan.get("runs", [])), "approved_by": r.approved_by, "created_by": e.created_by,
                    "proposal_pk": e.proposal_pk})
    return out


@router.get("/experiments/{code}", tags=["experiments"])
def get_experiment(code: str, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    e = _exp(db, acc.project.id, code)
    devs = db.execute(select(Deviation).where(Deviation.experiment_pk == e.id)).scalars().all()
    qf = db.execute(select(QualityFinding).where(QualityFinding.experiment_pk == e.id)).scalars().all()
    return {"code": e.code, "title": e.title, "state": e.state, "current_revision": e.current_revision,
            "revisions": [{"revision": r.revision, "state": r.state, "plan": r.plan, "plan_hash": r.plan_hash,
                           "submitted_by": r.submitted_by, "approved_by": r.approved_by, "approved_at": r.approved_at,
                           "performed": r.performed, "data_reviewed_by": r.data_reviewed_by,
                           "decision_reason": r.decision_reason} for r in e.revisions],
            "deviations": [{"description": d.description, "impact": d.impact, "recorded_by": d.recorded_by,
                            "created_at": d.created_at} for d in devs],
            "quality_findings": [{"severity": q.severity, "code": q.code, "message": q.message, "rows": q.rows}
                                 for q in qf]}


class PlanIn(BaseModel):
    plan: dict[str, Any]
    change_note: str | None = None


@router.put("/experiments/{code}/plan", tags=["experiments"])
def edit_plan(code: str, body: PlanIn, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    e = _exp(db, acc.project.id, code)
    r = _current(e)
    if r.state != "draft":
        raise HTTPException(409, f"plan revision {r.revision} is '{r.state}' and immutable; create a new revision")
    r.plan, r.plan_hash = jsonable(body.plan), content_hash(body.plan)
    audit.record(db, acc.user.username, "edit_plan", "experiment", f"{code}@{r.revision}", acc.project.id,
                 {"plan_hash": r.plan_hash})
    db.commit()
    return {"code": code, "revision": r.revision, "plan_hash": r.plan_hash}


@router.post("/experiments/{code}/revisions", tags=["experiments"])
def new_plan_revision(code: str, body: PlanIn, acc: ProjectAccess = Depends(project_access()),
                      db: Session = Depends(get_db)):
    e = _exp(db, acc.project.id, code)
    old = _current(e)
    if old.state in ("performed", "data_reviewed", "accepted"):
        raise HTTPException(409, "the plan has been executed; record a deviation or create a new experiment")
    if not body.change_note:
        raise HTTPException(422, "a change note is required for a new revision")
    if old.state != "draft":
        old.state = "superseded"
    n = old.revision + 1
    db.add(ExperimentRevision(experiment_pk=e.id, revision=n, plan=jsonable(body.plan), plan_hash=content_hash(body.plan),
                              created_by=acc.user.username, decision_reason=body.change_note))
    e.current_revision, e.state = n, "draft"
    audit.record(db, acc.user.username, "new_plan_revision", "experiment", f"{code}@{n}", acc.project.id,
                 {"supersedes": old.revision, "note": body.change_note})
    db.commit()
    return {"code": code, "revision": n, "state": "draft"}


class TransitionIn(BaseModel):
    target: str
    reason: str | None = None
    evidence: dict[str, Any] | None = None


@router.post("/experiments/{code}/transition", tags=["experiments"])
def transition(code: str, body: TransitionIn, acc: ProjectAccess = Depends(project_access()),
               db: Session = Depends(get_db)):
    e = _exp(db, acc.project.id, code)
    r = _current(e)
    evidence = dict(body.evidence or {})
    if body.target == "data_reviewed":
        evidence["measurement_count"] = len(db.execute(select(Measurement.id).where(
            Measurement.experiment_pk == e.id, Measurement.experiment_revision == r.revision)).all())
    if e.state == "scientific_review":
        author = r.submitted_by
    elif e.state in ("performed", "data_reviewed"):
        author = (r.performed or {}).get("recorded_by")  # data reviewer ≠ person who recorded the work
    else:
        author = None
    try:
        check_transition(TransitionRequest(e.state, body.target, acc.user.username, acc.role, author, body.reason,
                                           evidence))
    except PermissionDenied as ex:
        raise HTTPException(403, str(ex))
    except WorkflowError as ex:
        raise HTTPException(409, str(ex))
    now = datetime.now(timezone.utc)
    if body.target == "scientific_review":
        r.submitted_by = acc.user.username
    elif body.target == "approved_for_experiment":
        r.approved_by, r.approved_at = acc.user.username, now
    elif body.target == "performed":
        r.performed = jsonable({**evidence, "recorded_by": acc.user.username, "recorded_at": now})
    elif body.target == "data_reviewed":
        r.data_reviewed_by = acc.user.username
    if body.reason:
        r.decision_reason = body.reason
    prev = e.state
    e.state = r.state = body.target
    audit.record(db, acc.user.username, "experiment_transition", "experiment", f"{code}@{r.revision}", acc.project.id,
                 {"from": prev, "to": body.target, "reason": body.reason, "plan_hash": r.plan_hash})
    db.commit()
    return {"code": code, "revision": r.revision, "state": e.state}


class DeviationIn(BaseModel):
    description: str = Field(min_length=5)
    impact: str = ""


@router.post("/experiments/{code}/deviations", tags=["experiments"])
def add_deviation(code: str, body: DeviationIn, acc: ProjectAccess = Depends(project_access()),
                  db: Session = Depends(get_db)):
    e = _exp(db, acc.project.id, code)
    db.add(Deviation(experiment_pk=e.id, description=body.description, impact=body.impact, recorded_by=acc.user.username))
    audit.record(db, acc.user.username, "record_deviation", "experiment", code, acc.project.id, body.model_dump())
    db.commit()
    return {"ok": True}


@router.post("/experiments/{code}/measurements", tags=["measurements"])
async def import_measurements(code: str, file: UploadFile = File(...), acc: ProjectAccess = Depends(project_access()),
                              db: Session = Depends(get_db)):
    e = _exp(db, acc.project.id, code)
    r = _current(e)
    if e.state != "performed":
        raise HTTPException(409, "measurements can only be imported for experiments recorded as performed")
    s = get_settings()
    data = await file.read(s.max_upload_bytes + 1)
    try:
        safe, ctype, sha = validate_upload(file.filename or "results.csv", data, s.max_upload_bytes)
    except UploadRejected as ex:
        raise HTTPException(415, str(ex))
    if ctype != "text/csv":
        raise HTTPException(415, "measurement import expects CSV")
    try:
        df = pd.read_csv(io.BytesIO(data))
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(422, f"unreadable CSV: {ex}")
    key = f"projects/{acc.project.id}/raw/{sha}/{safe}"
    get_storage(s).put(key, data, ctype)
    rf = RawFile(project_id=acc.project.id, object_key=key, filename=safe, content_type=ctype, size=len(data),
                 sha256=sha, uploaded_by=acc.user.username)
    db.add(rf); db.flush()

    specs = target_specs(db, acc.project.id)
    mix_cols = [c for c in df.columns if c.startswith("mix:")]
    findings = validate_measurements(df, specs, (r.plan or {}).get("instruments"), mix_cols)
    # plan conformance: runs and compositions must match the approved plan
    plan_runs = {p["run_id"]: p for p in r.plan.get("runs", []) if "run_id" in p}
    from ...science.quality import Finding
    unknown = sorted(set(df["run_id"]) - set(plan_runs)) if plan_runs else []
    if unknown:
        findings.append(Finding("error", "run_not_in_plan", f"runs not in approved plan: {unknown[:10]}",
                                df[df.run_id.isin(unknown)].measurement_id.tolist()))
    mism = []
    for _, row in df.iterrows():
        p = plan_runs.get(row["run_id"])
        if p is None:
            continue
        for c in mix_cols:
            if c in p and abs(float(p[c]) - float(row[c])) > 1e-6:
                mism.append(row["measurement_id"]); break
    if mism:
        findings.append(Finding("warning", "composition_differs_from_plan",
                                "composition differs from the approved plan; record a deviation", mism))
    db.execute(delete(QualityFinding).where(QualityFinding.experiment_pk == e.id))
    for f in findings:
        db.add(QualityFinding(experiment_pk=e.id, severity=f.severity, code=f.code, message=f.message,
                              rows=jsonable(f.rows[:500])))
    summary = summarise(findings)
    if summary["errors"]:
        audit.record(db, acc.user.username, "measurement_import_rejected", "experiment", code, acc.project.id,
                     {"raw_file": rf.id, "summary": summary})
        db.commit()
        return {"imported": 0, "raw_file_id": rf.id, "quality": summary,
                "findings": [jsonable(f.as_dict()) for f in findings]}
    existing = {m for (m,) in db.execute(select(Measurement.measurement_id).where(
        Measurement.project_id == acc.project.id)).all()}
    dup = existing & set(df["measurement_id"])
    if dup:
        raise HTTPException(409, f"measurement ids already imported: {sorted(dup)[:5]}")
    proc_cols = [c for c in df.columns if c.startswith("proc:")]
    n = 0
    for _, row in df.iterrows():
        val = row.get("value")
        db.add(Measurement(
            project_id=acc.project.id, experiment_pk=e.id, experiment_revision=r.revision,
            measurement_id=str(row["measurement_id"]), run_id=str(row["run_id"]), batch_id=_s(row.get("batch_id")),
            lot_ids=_s(row.get("lot_ids")), replicate_group=str(row["replicate_group"]),
            replicate=int(row.get("replicate", 1)), block=_s(row.get("block")), role=_s(row.get("role")) or "design",
            target=str(row["target"]), value=None if pd.isna(val) else float(val), unit=str(row["unit"]),
            method=_s(row.get("method")), instrument_id=_s(row.get("instrument_id")), status=str(row["status"]),
            failure_reason=_s(row.get("failure_reason")), lod=None if pd.isna(row.get("lod")) else float(row["lod"]),
            measured_on=str(row["measured_on"]), mixture={c[4:]: float(row[c]) for c in mix_cols},
            process={c[5:]: float(row[c]) for c in proc_cols}, raw_file_pk=rf.id, imported_by=acc.user.username))
        n += 1
    audit.record(db, acc.user.username, "import_measurements", "experiment", f"{code}@{r.revision}", acc.project.id,
                 {"raw_file": rf.id, "sha256": sha, "rows": n, "summary": summary})
    audit.link(db, acc.project.id, "experiment", f"{code}@{r.revision}", "raw_measurement", f"file:{sha[:16]}",
               "produced")
    db.commit()
    return {"imported": n, "raw_file_id": rf.id, "quality": summary,
            "findings": [jsonable(f.as_dict()) for f in findings]}


def _s(v):
    return None if v is None or (isinstance(v, float) and pd.isna(v)) else str(v)


@router.get("/experiments/{code}/measurements", tags=["measurements"])
def list_measurements(code: str, acc: ProjectAccess = Depends(project_access()), db: Session = Depends(get_db)):
    e = _exp(db, acc.project.id, code)
    rows = db.execute(select(Measurement).where(Measurement.experiment_pk == e.id)).scalars()
    return [{"measurement_id": m.measurement_id, "run_id": m.run_id, "target": m.target, "value": m.value,
             "unit": m.unit, "status": m.status, "failure_reason": m.failure_reason, "replicate_group": m.replicate_group,
             "replicate": m.replicate, "batch_id": m.batch_id, "lot_ids": m.lot_ids, "block": m.block, "role": m.role,
             "mixture": m.mixture, "process": m.process, "method": m.method, "measured_on": m.measured_on,
             "label": "MEASURED"} for m in rows]


@router.get("/measurements", tags=["measurements"])
def project_measurements(target: str | None = None, acc: ProjectAccess = Depends(project_access()),
                         db: Session = Depends(get_db)):
    q = select(Measurement, Experiment.code, Experiment.state).join(Experiment, Measurement.experiment_pk == Experiment.id) \
        .where(Measurement.project_id == acc.project.id)
    if target:
        q = q.where(Measurement.target == target)
    return [{"measurement_id": m.measurement_id, "experiment": code, "experiment_state": st, "run_id": m.run_id,
             "target": m.target, "value": m.value, "unit": m.unit, "status": m.status,
             "failure_reason": m.failure_reason, "lod": m.lod, "method": m.method, "batch_id": m.batch_id,
             "lot_ids": m.lot_ids, "block": m.block, "role": m.role, "replicate_group": m.replicate_group,
             "mixture": m.mixture, "process": m.process, "measured_on": m.measured_on, "label": "MEASURED"}
            for m, code, st in db.execute(q).all()]
