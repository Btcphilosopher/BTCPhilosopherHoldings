# Capability status — read this first

This file separates what is **implemented and tested in software**, what is only **demonstrated on
synthetic data**, what has been **experimentally validated** (nothing), and what is **unproven or not
built**. Nothing here is a statement of regulatory compliance.

## 1. Implemented and covered by automated tests

| Area | What exists | Main tests |
|---|---|---|
| Units & dimensions | Base dimensions M, L, N, T, K, U (dosage unit); unit-expression parser; dimension-checked conversions; no mass↔volume without a density, no amount↔mass without a molar mass; °C treated as affine and refused as a multiplicative unit | `test_units.py` |
| Materials registry | Immutable versioned records with content hashes; property provenance kept separate (supplier spec / literature / lab measurement / model estimate); missing values stay missing; model estimates excluded unless explicitly allowed; lab measurements must cite a method | `test_composition.py`, `test_api.py` |
| Formulation model | Ingredients, roles, six composition bases, batch size, stages, order of addition, equipment, parameters, targets, evidence; dimensional validation; composition totals; batch scaling that reports *unresolved* rather than guessing; mass balance with theoretical vs measured yield and documented vs estimated losses; draft → in review → approved → superseded with separation of duties | `test_composition.py`, `test_api.py` |
| Constraints & feasibility | Bounds, totals, inclusion/exclusion, group limits, ratio limits, process ranges ∩ equipment limits, cost limit (dated prices, single currency), reviewed incompatibilities (disjunctive, branch-enumerated), unknown compatibility policy (block/flag, never "compatible"), missing-information blocks; LP feasibility (HiGHS) with irreducible infeasible subset explanation; effective feasible ranges | `test_constraints_doe.py` |
| Design of experiments | Simplex-lattice, simplex-centroid, extreme vertices of constrained polytopes, hit-and-run space filling, maximin selection, D-optimal point exchange for Scheffé models, full factorial & Latin hypercube process designs, mixture/process namespaces kept separate, replicates, control samples (checked against the domain), seeded randomisation, blocking by day/equipment/lot with replicates rotated across blocks, coverage (fill distance), budget, limitations | `test_constraints_doe.py` |
| Experiment management | Draft → Scientific review → Approved → Performed → Data reviewed → Accepted/Rejected; role checks and separation of duties; approved plans immutable; changes create new revisions (old marked superseded); execution evidence (operator, date, lots, equipment) separate from the plan; deviations; raw files stored by SHA-256; measurement import only after "performed" | `test_api.py`, demo |
| Data quality | Units vs target spec, missing values, physical bounds, LOD/censoring, failed-run retention, replicate consistency and conflicts, calibration expiry, batch/lot identifiers, composition totals, plan conformance; errors block import, raw file still retained | `test_quality.py`, `test_api.py` |
| ML pipeline | Target definitions (unit, method, horizon, bounds, domain); mean baseline → Scheffé ridge → random forest → Gaussian process; grouped splits by batch/lot/family/project/time with replicate & near-duplicate leakage groups; transformations fitted inside training folds; compositional ilr with explicit zero policy; failed/censored observations excluded **explicitly with IDs and reasons**; model selection on training-only inner CV; manifests with dataset/split/manifest hashes and library versions | `test_ml.py` |
| Uncertainty & abstention | Grouped-CV conformal intervals (constant or normalised), GP intervals with conformal rescaling, latent vs noise SD; empirical coverage at 50/80/90/95 % on held-out data; applicability domain (research-domain violation, extrapolation, sparse support, unseen combinations, missing properties, conflicting measurements) with abstention; classification probabilities marked UNVALIDATED unless enough held-out events | `test_ml.py` |
| Recommendations | Constrained candidate pool → hard checks → abstention → predictions → calculated objectives → Pareto frontier (no hidden weighted score) → diverse frontier picks + exploration point; each proposal carries composition, process, predictions with intervals, constraint checks, domain flags, measured neighbourhood, reason; reviewer approval required to create a draft plan | `test_optimisation.py`, demo |
| Bayesian optimisation | Adapter interface with Optuna 5.1 TPE backend (multi-objective, black-box failure constraint from measured history); excluded ingredients are not parameters; inadmissible asks are rejected and never returned; GP backend available only if PyTorch is installed | `test_optimisation.py` |
| Stability | Per formulation-revision/packaging/condition/method/lot OLS trends with CI/PI; censored results excluded and listed; forecasts bounded to 1.5× the longest time point; exploratory one-sided limit crossing labelled NOT A SHELF-LIFE ASSIGNMENT; slope poolability F-test as a diagnostic | `test_stability_sim_combo_costs.py` |
| Process simulation | Monte-Carlo mixing/holding/transfer/filling model with every assumption listed, mass closure check, flags and limitations, labelled SIMULATED — NOT PROCESS VALIDATION | same |
| Combination research | Requires authorisation reference & permitted use; refuses human/patient data; Bliss and HSA reference models per dose pair with replicate bootstrap CIs; "insufficient data" when replicates are missing; multiplicity note; disclaimers | same |
| Costs | Decimal money, explicit currency, price date, per-unit dimension check, dated FX required for mixed currencies | same |
| Lineage & reports | Material lot → formulation revision → experiment → raw measurement → training dataset → model → prediction → reviewed decision; missing-link detection; JSON + self-contained HTML report with content hash, assumptions, exclusions, uncertainty and review history | demo integration test |
| Security & governance | JWT auth (secret mandatory ≥32 chars in production), bcrypt, project-scoped roles (researcher/reviewer/admin), non-members get 403, separation of duties, upload restrictions (type allow-list, content sniffing, size, name sanitising, path-traversal-safe storage), hash-chained audit log with verification and tamper detection, PostgreSQL trigger making `audit_log` append-only, security headers | `test_api.py`, `test_postgres_backup.py` |
| Researcher interface | React + TypeScript workspace with the ten required sections, colour + text tags (MEASURED teal, PREDICTED violet, CALCULATED slate, APPROVED badge, amber labelled WARNINGs), Plotly charts, workflow steppers, proposal review, candidate evaluation, stability trends with bounded forecasts, batch consistency and simulation, report/lineage/audit views; served by nginx with CSP and security headers | `npm run build` (type-checked); Playwright pass over all pages via the Compose stack (manual, screenshots in `docs/screenshots/`) |
| Persistence & operations | SQLAlchemy models, Alembic migrations (upgrade/downgrade tested on PostgreSQL 16), local and S3-compatible object storage, backup/restore scripts with a tested PostgreSQL round trip (row counts, audit chain and model-artefact hashes verified after restore), Docker images and Compose | `test_postgres_backup.py`, `test_storage_s3.py`, manual Compose run |

## 2. Demonstrated only on synthetic data

* The whole 12-step demonstration (`tertius demo`) uses **fictional inert surrogate ingredients** and
  measurements from a **documented generator** (`backend/tertius/synthetic/generator.py`). Model accuracy,
  coverage, Pareto fronts, BO suggestions, stability trends and combination conclusions in `demo_output/`
  describe that toy generator, not any real material.
* The demo models are small (≈34 usable observations per target, ≈11 held out). Coverage estimates are
  correspondingly imprecise and the pipeline says so in its warnings.
* The phase-separation classifier is worse than the prevalence baseline on the demo data, and its output is
  labelled UNVALIDATED.
* Training-only model selection is noisy at this size: for uniformity CV it chose the random forest while
  the GP was clearly better on the held-out set (see `docs/TEST_RESULTS.md`). The platform reports both and
  does not re-select on test data.

## 3. Experimentally validated findings

**None.** No component has been validated against real laboratory measurements, real materials, real
equipment or real stability programmes.

## 4. Unproven, partial or not implemented

* Loewe additivity / dose-response surface fitting for combination research (not implemented).
* Arrhenius/kinetic extrapolation between storage conditions (deliberately not implemented).
* PyTorch-based models: not used; no task in the initial scope justified them. Optuna's GPSampler would
  need PyTorch — optional extra, untested here (PyTorch was not installable in the build environment).
* SeaweedFS S3 profile in Compose: the S3 adapter is tested against a mock (moto), but the SeaweedFS
  container could not be pulled in the build environment (registry rate limits) and is untested.
* Login rate limiting, MFA/SSO, password rotation, field-level encryption, e-signature semantics (e.g.
  signature meaning/manifestation), record retention policies, and formal computer-system validation.
* UI coverage: material revision, formulation create/edit, deviation entry, CSV measurement import, model
  training/approval, cost scenarios and combination research are available through the API (and the demo)
  but have no dedicated UI forms yet. No API endpoint lists stability formulations, so the UI selectors are
  fixed to the demo formulations.
* react-router 6.x carries two moderate `npm audit` advisories (fixed only in 7.x); the app navigates to
  internal paths only. Upgrade before deployment.
* Autonomous laboratory execution: intentionally absent.
* Regulatory compliance (GLP, GMP, 21 CFR Part 11, EU GMP Annex 11, etc.): **not claimed**. Before real
  pharmaceutical use, identify the jurisdiction and intended purpose and research the applicable
  laboratory, manufacturing, electronic-record, quality and medical-product requirements from current
  official sources.
