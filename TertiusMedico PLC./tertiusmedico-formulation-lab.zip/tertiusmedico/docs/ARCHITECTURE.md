# Architecture

A modular monolith: one FastAPI process over a set of **independently testable scientific modules** that
have no web or database dependencies.

```
frontend/ (React + TypeScript + Plotly, served by nginx; /api proxied)
   │
backend/tertius/api/            FastAPI routers, auth, project-scoped permissions
   ├── routers/core.py          auth, users, projects, members, materials, files, audit
   ├── routers/lab.py           formulations, research domains (constraints), designs, mass balance
   ├── routers/experiments.py   targets, experiments, plan revisions, workflow, measurements, deviations
   ├── routers/ml.py            training, model review, candidate evaluation, proposals & review
   └── routers/analysis.py      stability, simulation, combination research, costs, lineage, reports
backend/tertius/services.py     DB ⇄ science bridging (frames, artefacts, bundles)
backend/tertius/audit.py        hash-chained audit log + lineage edges
backend/tertius/storage.py      object storage (local / S3-compatible) + upload validation
backend/tertius/db/             SQLAlchemy models, sessions;  backend/alembic/ migrations
backend/tertius/science/        pure scientific core
   ├── units.py composition.py materials.py constraints.py doe.py quality.py
   ├── ml/ features.py splitting.py models.py domain.py pipeline.py
   ├── optimisation/ pareto.py bo_adapter.py recommend.py
   └── stability.py simulation.py combination.py costs.py workflow.py lineage.py reporting.py
backend/tertius/synthetic/      fictional demo system + documented data generator
```

## Data flow and lineage
```
material lot ─ingredient_of→ formulation revision ─planned_in→ experiment ─produced→ raw measurement file
   ─contributes→ training dataset (SHA-256 of exact rows) ─trains→ model run (manifest + artefact SHA-256)
   ─predicts→ prediction / proposal ─reviewed→ reviewed decision ─plans→ new draft experiment
```
Edges are stored in `lineage_edges`; `GET /api/projects/{id}/lineage?kind=…&ref=…` returns the upstream
chain and any missing links.

## Record types are kept distinct
| Kind | Examples | Where |
|---|---|---|
| MEASURED | `measurements`, `stability_results`, raw files | experiment import, stability import |
| CALCULATED | batch quantities, mass balance, cost, feasibility ranges, model evaluation metrics | science modules; `label: CALCULATED` |
| PREDICTED | model outputs, Pareto objectives, trend forecasts | `predictions`, `proposals`; `label: PREDICTED` |
| SIMULATED | process simulator outputs | `label: SIMULATED — NOT PROCESS VALIDATION` |
| APPROVED | approved formulation revisions, domains, plans, model runs | `status`/`state` fields with approver and time |

## Storage
* PostgreSQL 16 (JSONB for versioned scientific payloads, each with a content hash). SQLite supported for
  tests/dev.
* Object storage for raw files, model artefacts (joblib, SHA-256 checked on load) and HTML reports: local
  filesystem volume by default; S3-compatible API optional.

## Dependencies (pinned in `backend/pyproject.toml`)
NumPy, pandas, SciPy (HiGHS LP, QMC, stats), scikit-learn (ridge, RF, GP), Optuna (Bayesian optimisation
behind `BayesianOptimiser`), Plotly (charts in demo outputs and UI), FastAPI, SQLAlchemy 2, Alembic,
psycopg 3, PyJWT, bcrypt, boto3. PyTorch is **not** a dependency: dataset sizes (tens to hundreds of
formulations) do not justify deep models; it is needed only for Optuna's optional GP sampler.
