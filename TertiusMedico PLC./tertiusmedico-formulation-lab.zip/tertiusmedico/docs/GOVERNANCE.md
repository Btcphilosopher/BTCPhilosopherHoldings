# Security, governance and operations

## Roles and permissions (project-scoped)
Membership is per project; global administrators create users/projects but do **not** see project data
unless they are members. Non-members receive 403.

| Action | researcher | reviewer | admin |
|---|:-:|:-:|:-:|
| Read project data, register materials, create formulations/domains/designs/experiments, import data, train models, generate proposals and reports | ✓ | ✓ | ✓ |
| Submit formulation / experiment for review | ✓ | ✓ | ✓ |
| Approve/return/reject formulations, research domains, experiment plans, data review, acceptance | – | ✓ | ✓ |
| Approve model runs for use; accept/reject proposals | – | ✓ | ✓ |
| View the project audit trail | – | ✓ | ✓ |
| Manage project membership | – | – | ✓ |

**Separation of duties** (enforced server-side): nobody approves their own formulation, research domain,
plan submission, model run or proposal batch, and the person who recorded an experiment's execution cannot
perform its data review or acceptance.

## Versioning and approvals
* Material records, formulation revisions, research domains, experiment plans and target definitions are
  versioned with SHA-256 content hashes.
* Only drafts are editable. An approved experiment plan is immutable; changing it requires a new revision
  with a change note, and the previous revision is marked `superseded`. Executed plans cannot be revised —
  record a deviation or start a new experiment.
* Proposals become **draft** plans only after reviewer acceptance; that draft still needs scientific review.

## Audit trail
Every state change writes an `audit_log` row whose hash covers the previous row's hash (a hash chain).
`GET /api/admin/audit/verify` recomputes the chain and reports the first broken row. On PostgreSQL a
trigger (`0002_audit_protection`) rejects UPDATE/DELETE on `audit_log`; appends are serialised with an
advisory lock. Login successes and failures are recorded.

## Intellectual property and files
* Projects default to `confidential`; all data endpoints require membership.
* Uploads: allow-list (`.csv .json .txt .pdf`), content checks (PDF magic bytes; UTF-8 and no NUL for
  text), size limit (`TERTIUS_MAX_UPLOAD_BYTES`, default 20 MiB), sanitised names, storage key
  `projects/<id>/raw/<sha256>/<name>`, traversal-safe local storage, `X-Content-Type-Options: nosniff`.

## Credentials
* `TERTIUS_SECRET_KEY` is mandatory (≥ 32 chars) when `TERTIUS_ENV=production`; the API refuses to start
  otherwise. Development without a key uses a per-process random key.
* Passwords: bcrypt (12 rounds), minimum 10 characters. Demo passwords are for the synthetic demo only and
  are overridable via `TERTIUS_DEMO_*_PASSWORD`.
* Database/object-store credentials come from environment variables (`.env`, never committed).

## Backup and tested restoration
`scripts/backup.sh <dir>` → `pg_dump` custom format + object store archive + `SHA256SUMS`.
`scripts/restore.sh <backup> <empty-db-url> [storage-root]` → checksum verification, refuses non-empty
targets, `pg_restore`. `tests/test_postgres_backup.py` performs a real round trip on PostgreSQL 16 and
verifies identical row counts in every table, a valid audit chain, and matching model-artefact SHA-256s
after restore.

## Not claimed
Software features alone do not make a system compliant with GLP, GMP, GCP, 21 CFR Part 11, EU GMP
Annex 11 or any other regime. Compliance depends on intended use, jurisdiction, validated processes,
procedures, training and quality oversight. Before real pharmaceutical use, identify jurisdiction and
purpose and research the applicable requirements from current official sources.
