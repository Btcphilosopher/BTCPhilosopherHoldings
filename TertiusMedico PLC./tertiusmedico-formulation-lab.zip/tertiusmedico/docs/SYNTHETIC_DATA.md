# Synthetic data generator

Source: `backend/tertius/synthetic/generator.py` (`tertius synth --out DIR` writes CSVs).

Synthetic data generator for the TERTIUSMEDICO demonstration.

EVERYTHING HERE IS FICTIONAL. The four ingredients are inert surrogates with
invented names and invented behaviour; the response functions below are
*documented toy physics* chosen to exercise the software (interactions, batch
effects, lot effects, noise, failures, censoring). They are not derived from
and must not be used as data about any real material or medicine.

Surrogate system: a four-component aqueous-like suspension
-----------------------------------------------------------
=========  ============================  ===========  ======================
id         fictional name                role         demo bounds (w/w)
=========  ============================  ===========  ======================
SV-1       Aqualine Base S-1             vehicle      0.50 – 0.85
VM-2       Viscogel VM-2                 thickener    0.05 – 0.30
SF-3       Tensiol SF-3                  surfactant   0.01 – 0.10
TR-4       Inertite TR-4 (tracer)        tracer       0.02 – 0.20
=========  ============================  ===========  ======================

Process variables: ``mix_speed`` (rpm, 200–1000), ``mix_time`` (min, 5–40),
``temperature`` (°C, 20–40).

Response functions (x = mass fractions, s = speed, t = time, T = temperature)
-------------------------------------------------------------------------------
* **Viscosity** (mPa·s, rotational rheometer @ 50 s⁻¹, 25 °C, t = 0)::

      ln η = 1.6·x_SV + 9.0·x_VM + 3.0·x_SF + 2.5·x_TR          (Scheffé linear)
           + 4.0·x_SV·x_VM + 3.0·x_VM·x_TR − 5.0·x_SF·x_TR      (binary interactions)
           − 0.15·(s − 600)/400 − 0.01·(T − 25)                (process)
           + lot_effect[VM-2 lot] + day_effect[day] + ε,  ε ~ N(0, 0.06²)

  lot effects: L-VM2-A 0, L-VM2-B +0.12, L-VM2-C −0.08; day effects ~ N(0, 0.05²) fixed per seed.

* **Phase separation within 24 h** (failure event)::

      logit p = −3 + 30·(x_TR − 0.12) − 50·(x_SF − 0.04) − 1.5·(ln η − 3.5) − 0.05·(t − 20)

  A phase-separated run is recorded with ``status = failed`` and no
  viscosity/uniformity value (the sample was not measurable). Independently,
  3 % of runs suffer an instrument fault (``status = failed``, reason recorded).

* **Content uniformity** (CV % of tracer across 10 aliquots)::

      CV = 1.2 + 4·exp(−t/10)·sqrt(600/s) + 3/(1 + exp(−30·(x_TR − 0.15))) + |N(0, 0.25²)|

* **Accelerated screening assay** (% of initial marker retained after 4 weeks at 40 °C/75 %RH, glass)::

      k = 0.030·(1 + 4·x_SF)·(1 − 1.5·x_VM)  per month;   A = 100·exp(−k·0.92) + N(0, 0.3²)

* **Stability study** (per formulation, packaging, condition, lot): first-order
  loss with Arrhenius-like temperature factor (×4.2 from 25 °C to 40 °C),
  packaging factor (PET ×1.4 vs glass), lot offsets, analytical noise
  N(0, 0.4²) %. Degradant (%) = 100 − assay − 0.2, censored below the LOD of 0.05 %.


## Combination dataset
Fictional in-vitro response surface for two fictional research compounds CX-1 and CY-2.

Single-agent responses follow Hill curves (EC50 1.0 and 3.0 µM-equivalent, Hill slope 1.2 and 1.0,
Emax 0.9 and 0.8). The combined response is Bliss-independent plus an excess of +0.12 at the two middle
dose levels of both compounds and 0 elsewhere. Replicates have N(0, 0.04²) noise; vehicle controls ~ N(0, 0.02²).
This is an abstract assay used only to exercise reference-model calculations.

