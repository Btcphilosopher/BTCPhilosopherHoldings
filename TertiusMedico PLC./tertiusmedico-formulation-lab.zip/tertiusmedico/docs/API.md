# API reference

Interactive docs: run the API and open `http://localhost:8000/docs` (Swagger UI) or `/redoc`.
The full machine-readable schema is in [`openapi.json`](openapi.json) (regenerate with `tertius export-openapi docs/openapi.json`).

Authentication: `POST /api/auth/token` (OAuth2 password form) → `Authorization: Bearer <token>`. All project routes are
scoped by `{project_id}` and require membership; the role needed is enforced server-side (see GOVERNANCE.md).

Response labelling convention: values carry `label` fields — `MEASURED`, `CALCULATED`, `PREDICTED`, `SIMULATED` — and
workflow objects carry explicit `status`/`state` (`approved`, `approved_for_experiment`, `approved_for_use`, …).

## admin

| Method | Path | Summary |
|---|---|---|
| POST | `/api/admin/users` | Create User |
| GET | `/api/admin/audit/verify` | Verify Audit |

## audit

| Method | Path | Summary |
|---|---|---|
| GET | `/api/projects/{project_id}/audit` | Project Audit |

## auth

| Method | Path | Summary |
|---|---|---|
| POST | `/api/auth/token` | Login |
| GET | `/api/auth/me` | Me |

## combination

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/combination/datasets` | Add Combination |
| POST | `/api/projects/{project_id}/combination/datasets/{ds_id}/analyse` | Analyse |

## constraints

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/domains` | Create Domain |
| GET | `/api/projects/{project_id}/domains` | List Domains |
| POST | `/api/projects/{project_id}/domains/{domain_id}/approve` | Approve Domain |
| POST | `/api/projects/{project_id}/domains/{domain_id}/check` | Check |

## costs

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/costs/scenario` | Cost Scenario |

## design

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/designs` | Create Design |
| GET | `/api/projects/{project_id}/designs` | List Designs |
| GET | `/api/projects/{project_id}/designs/{design_id}` | Get Design |
| GET | `/api/projects/{project_id}/designs-rationale` | Design Rationale |

## experiments

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/experiments` | Create Experiment |
| GET | `/api/projects/{project_id}/experiments` | List Experiments |
| GET | `/api/projects/{project_id}/experiments/{code}` | Get Experiment |
| PUT | `/api/projects/{project_id}/experiments/{code}/plan` | Edit Plan |
| POST | `/api/projects/{project_id}/experiments/{code}/revisions` | New Plan Revision |
| POST | `/api/projects/{project_id}/experiments/{code}/transition` | Transition |
| POST | `/api/projects/{project_id}/experiments/{code}/deviations` | Add Deviation |

## files

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/files` | Upload File |
| GET | `/api/projects/{project_id}/files/{file_id}` | Download File |

## formulations

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/formulations` | Create Formulation |
| GET | `/api/projects/{project_id}/formulations` | List Formulations |
| GET | `/api/projects/{project_id}/formulations/{formulation_id}/revisions/{revision}` | Get Revision |
| PUT | `/api/projects/{project_id}/formulations/{formulation_id}/revisions/{revision}` | Edit Revision |
| POST | `/api/projects/{project_id}/formulations/{formulation_id}/revisions` | New Revision |
| POST | `/api/projects/{project_id}/formulations/{formulation_id}/revisions/{revision}/review` | Review Revision |
| POST | `/api/projects/{project_id}/calculations/mass-balance` | Calc Mass Balance |

## lineage

| Method | Path | Summary |
|---|---|---|
| GET | `/api/projects/{project_id}/lineage` | Lineage |

## materials

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/materials` | Register Material |
| GET | `/api/projects/{project_id}/materials` | List Materials |
| POST | `/api/projects/{project_id}/materials/{material_id}/versions` | Revise Material |
| GET | `/api/projects/{project_id}/materials/{material_id}` | Material History |

## measurements

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/experiments/{code}/measurements` | Import Measurements |
| GET | `/api/projects/{project_id}/experiments/{code}/measurements` | List Measurements |
| GET | `/api/projects/{project_id}/measurements` | Project Measurements |

## meta

| Method | Path | Summary |
|---|---|---|
| GET | `/api/health` | Health |

## models

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/models/train` | Train |
| GET | `/api/projects/{project_id}/models` | List Models |
| GET | `/api/projects/{project_id}/models/{run_id}` | Get Model |
| POST | `/api/projects/{project_id}/models/{run_id}/review` | Review Model |

## optimisation

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/candidates/evaluate` | Evaluate Candidate |
| POST | `/api/projects/{project_id}/proposals` | Propose |
| GET | `/api/projects/{project_id}/proposals` | List Batches |
| POST | `/api/projects/{project_id}/proposals/{proposal_id}/review` | Review Proposal |

## projects

| Method | Path | Summary |
|---|---|---|
| GET | `/api/projects` | My Projects |
| POST | `/api/projects` | Create Project |
| GET | `/api/projects/{project_id}` | Project Summary |
| POST | `/api/projects/{project_id}/members` | Add Member |
| GET | `/api/projects/{project_id}/members` | List Members |

## reports

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/reports` | Generate Report |
| POST | `/api/projects/{project_id}/reports/html` | Generate Report Html |

## simulation

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/simulations/process` | Run Simulation |

## stability

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/stability/results` | Import Stability |
| GET | `/api/projects/{project_id}/stability/trends` | Stability Trends |

## targets

| Method | Path | Summary |
|---|---|---|
| POST | `/api/projects/{project_id}/targets` | Define Target |
| GET | `/api/projects/{project_id}/targets` | List Targets |
