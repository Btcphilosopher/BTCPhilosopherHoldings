# Scientific notes and verified library assumptions

## Composition and units
* Fractions carry their basis (mass, volume). A volume fraction refers to component volumes **before**
  mixing; final volume is never assumed additive.
* Mass ↔ volume conversion requires a recorded density for the relevant material (or measured mixture
  density). Mass ↔ amount requires a molar mass. Unknowns produce an `unresolved` row — never a default.
* Mass balance: theoretical yield = Σ charged inputs (calculated); measured yield = weighed output ÷
  theoretical (measured/calculated); documented losses are split into weighed vs estimated; unaccounted
  mass beyond tolerance is flagged, not absorbed.

## Constraints and feasibility
Linear constraints are checked with `scipy.optimize.linprog(method="highs")`. When infeasible, the
deletion filter (Chinneck & Dravnieks, 1991) returns an irreducible infeasible subset: every listed
constraint is necessary for that conflict. Reviewed incompatibilities ("A and B not both present") are
non-convex and handled by enumerating zero-branches. Unknown compatibility is a separate state with a
configured policy (`block` or `flag`).

## Why not unconstrained sampling for mixtures
With Σxᵢ = 1 the region is a (q−1)-simplex (or polytope). Independent sampling of each fraction violates
the total; renormalising distorts coverage and breaches bounds. Designs here are generated inside the
polytope (lattice, extreme vertices, hit-and-run, D-optimal exchange). Scheffé polynomials omit the
intercept because Σx = 1 already provides it. Mixture (`mix:`) and process (`proc:`) variables are kept in
separate namespaces and only combined by explicit crossing or Latin-hypercube pairing.

## Models
* **Mean baseline** — the reference every model must beat; the pipeline warns when the selected model
  improves on it by < 10 % in inner CV.
* **Scheffé ridge** — Scheffé quadratic blending terms + linear process terms, standardised on the
  training fold, ridge with intercept. In a grouped-CV comparison on the demo data against the unscaled
  no-intercept form with quadratic process terms it was comparable for viscosity (log-MAE 0.157 vs 0.151)
  and clearly better for uniformity (0.657 vs 1.174) and screening assay (0.275 vs 0.566), so it is the
  default; its coefficients are not read as Scheffé blending effects.
* **Random forest** on raw fractions + standardised process variables.
* **Gaussian process** — Constant × Matern-5/2 (ARD) + WhiteKernel, `normalize_y=True`. Length scales at
  the upper bound (input judged irrelevant) are recorded in the manifest, not silenced.
* Viscosity is modelled on the log scale (positive, multiplicative noise).
* Compositional log-ratio (ilr) features are available but not default; zeros must be handled explicitly
  (refuse, or multiplicative replacement for rounded/below-detection zeros only).

## Uncertainty
* Conformal threshold: the ⌈(n+1)(1−α)⌉-th smallest out-of-fold score from **grouped** CV inside the
  training set (an off-by-one in an earlier draft was caught by `test_conformal_quantile`).
* RF uses normalised scores (residual ÷ across-tree spread); the spread alone is not treated as a SD.
* GP intervals use predictive SD × conformal factor; the raw Gaussian interval coverage is also reported.
* Variability: pooled within-replicate SD (measurement + preparation repeatability) is reported next to
  the GP white-noise estimate (model's estimate of the same) and the latent GP SD (model uncertainty).
* Empirical coverage at 50/80/90/95 % is computed on the held-out set; small held-out sets trigger a
  warning with the binomial imprecision.

## Applicability domain
Training-range extrapolation (excess as a fraction of each feature's range), k-NN (k = 3) distance vs the
95th percentile of leave-one-out distances among distinct training points, ingredient-presence patterns,
missing critical properties, conflicting replicate neighbourhoods. Abstain on research-domain violation,
> 10 % extrapolation, missing properties, or sparse support with an unseen combination.

## Optimisation
Pareto ranks by fast non-dominated sorting; selection = Bayesian-optimiser suggestions on/near the
frontier + crowding-seeded maximin spread across the frontier + one maximum-uncertainty exploration point.
Objectives: viscosity inside 30–60 mPa·s (log deviation), uniformity CV (min), screening assay (max),
phase-separation score (min, unvalidated), material cost (min, calculated); process time optional.

### Optuna (verified against the installed 5.1.0 source)
* `optuna.trial.create_trial(..., constraints={...})` stores constraint values; a trial is feasible when
  all values ≤ 0.
* In Optuna ≥ 5.0 `TPESampler`/`GPSampler` read `FrozenTrial.constraints` directly; the
  `constraints_func` argument is deprecated (FutureWarning; removal planned for 7.0), so it is not used.
* `GPSampler` requires PyTorch (stated in its docstring); `TPESampler` does not.

## Stability
Ordinary least squares per (formulation revision, packaging, condition, method, lot). Confidence and
prediction intervals from the t distribution. Forecasts beyond 1.5 × the longest observed time point are
refused. The one-sided 95 % confidence-bound crossing time is labelled exploratory and is not a shelf life.

## Process simulation
Exponential homogenisation CV(t) = CV₀·e^(−t/τ) with τ ∝ 1/speed, evaporative and first-order losses
during holding, fixed + proportional transfer hold-up, Normal fill weights with tolerance rejection.
Assumptions carry lognormal uncertainty and are listed in every output.

## Combination research
Bliss independence E_A + E_B − E_A·E_B and highest single agent, on vehicle-corrected fractional
effects, per dose pair, with bootstrap intervals over replicates. Requires ≥ 3 replicates for A alone,
B alone and A+B at the same doses. No multiplicity correction is applied — reported as such.
