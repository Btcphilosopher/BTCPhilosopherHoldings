#!/usr/bin/env bash
# Restore a backup made by backup.sh into an EMPTY database (refuses to overwrite a populated one).
#   scripts/restore.sh <backup-path> <target-postgres-url> [storage-root]
set -euo pipefail
SRC="${1:?backup path}"; TARGET="${2:?target postgres url}"; STORE="${3:-}"
( cd "$SRC" && sha256sum -c SHA256SUMS )
N=$(psql "$TARGET" -tAc "select count(*) from information_schema.tables where table_schema='public'")
if [[ "$N" != "0" ]]; then echo "target database is not empty ($N tables); refusing" >&2; exit 2; fi
pg_restore --no-owner --no-privileges --exit-on-error --dbname="$TARGET" "$SRC/db.dump"
if [[ -n "$STORE" && -f "$SRC/objects.tar.gz" ]]; then mkdir -p "$STORE"; tar -C "$STORE" -xzf "$SRC/objects.tar.gz"; fi
echo "restored into $TARGET"
