#!/usr/bin/env bash
# Back up the PostgreSQL database and the object store.
#   scripts/backup.sh <backup-dir>
# Env: TERTIUS_PG_URL (postgresql://user:pass@host:5432/db), optional TERTIUS_STORAGE_ROOT for local storage,
#      or MinIO/S3 via the `mc` client with alias $TERTIUS_MC_ALIAS and bucket $TERTIUS_S3_BUCKET.
set -euo pipefail
DEST="${1:?usage: backup.sh <backup-dir>}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$DEST/tertius-$STAMP"
mkdir -p "$OUT"
pg_dump --format=custom --no-owner --no-privileges --file="$OUT/db.dump" "${TERTIUS_PG_URL:?set TERTIUS_PG_URL}"
if [[ -n "${TERTIUS_MC_ALIAS:-}" ]]; then
  mc mirror --quiet "$TERTIUS_MC_ALIAS/${TERTIUS_S3_BUCKET:-tertius-raw}" "$OUT/objects"
elif [[ -n "${TERTIUS_STORAGE_ROOT:-}" && -d "$TERTIUS_STORAGE_ROOT" ]]; then
  tar -C "$TERTIUS_STORAGE_ROOT" -czf "$OUT/objects.tar.gz" .
fi
( cd "$OUT" && sha256sum * > SHA256SUMS )
echo "$OUT"
