# TERTIUSMEDICO — Formulation Lab

A research platform for **non-clinical** pharmaceutical formulation work: materials registry, constrained
formulations, design of experiments, experiment and measurement management, reproducible ML with
uncertainty and abstention, multi-objective recommendations that need scientific review, stability trends,
process simulation, combination-research analysis, costing, lineage and traceable reports.

> **Scope.** Recommendations are kept separate from approved laboratory instructions, manufacturing
> release and patient treatment. Predictions describe laboratory measurements inside a configured research
> domain. They do not establish efficacy, bioavailability, safety, manufacturing suitability or shelf
> life. The bundled demonstration uses **fictional inert surrogate ingredients and synthetic data**.
> No regulatory compliance is claimed. Read [`docs/STATUS.md`](docs/STATUS.md) before relying on anything.

## Contents
| Path | |
|---|---|
| `backend/` | Python scientific core (`tertius/science`), FastAPI app, SQLAlchemy models, Alembic migrations, tests |
| `frontend/` | React + TypeScript researcher workspace (Plotly charts) |
| `docker-compose.yml`, `.env.example` | PostgreSQL + API + web (+ optional S3 profile) |
| `scripts/backup.sh`, `scripts/restore.sh` | backup and tested restoration |
| `demo_output/` | outputs of the 12-step synthetic demonstration (report, Pareto chart, proposals, …) |
| `artifacts/` | model artefacts + manifests from the offline training command |
| `docs/` | status, architecture, scientific notes, governance, API reference, synthetic data, test results, screenshots |

## Quick start with Docker Compose
```bash
cp .env.example .env
```
Edit `.env` and set `POSTGRES_PASSWORD` and a ≥32-character `TERTIUS_SECRET_KEY`, then:
```bash
docker compose up --build -d
```
```bash
docker compose exec api tertius demo --out /tmp/demo
```
Open http://localhost:8080 and sign in as `rhea` / `demo-researcher-change-me` (researcher) or
`rowan` / `demo-reviewer-change-me` (reviewer). The API docs are at http://localhost:8000/docs.
Behind a TLS-intercepting proxy, build the API image with
`docker build --secret id=extra_ca,src=/path/ca.pem backend`.

## Local development
```bash
cd backend && pip install -e ".[test]"
```
```bash
cd backend && TERTIUS_DATABASE_URL=sqlite:///./dev.db tertius demo --out ../demo_output
```
```bash
cd backend && TERTIUS_DATABASE_URL=sqlite:///./dev.db TERTIUS_SECRET_KEY=dev-secret-dev-secret-dev-secret-xx uvicorn tertius.api.main:app --reload
```
```bash
cd frontend && npm ci && npm run dev
```
PostgreSQL instead of SQLite: `TERTIUS_DATABASE_URL=postgresql+psycopg://user:pass@host/db tertius init-db`
(applies Alembic migrations).

## Training commands
Through the API, `POST /api/projects/{id}/models/train` (uses only data from **accepted** experiments by
default). Offline and reproducible, from a measurement CSV:
```bash
cd backend && tertius synth --out ../demo_output/synthetic
```
```bash
cd backend && tertius train ../demo_output/synthetic/synthetic_results.csv --target viscosity --out ../artifacts
```
Each run writes `model_<hash>.joblib` and `manifest_<hash>.json` (dataset SHA-256, split, exclusions,
metrics, coverage, versions). Identical inputs and seed give an identical manifest hash.

## Tests
```bash
cd backend && python -m pytest -q
```
```bash
cd backend && TERTIUS_TEST_PG_URL=postgresql://user:pass@localhost:5432/postgres python -m pytest -q tests/test_postgres_backup.py
```
Actual results are recorded in [`docs/TEST_RESULTS.md`](docs/TEST_RESULTS.md).

## The demonstration (12 steps)
`tertius demo` drives the HTTP API as three users (admin, researcher, reviewer):
1. register four fictional materials (one revised to a new lot; unknown densities left missing);
2. create a constrained formulation and research domain (and an infeasible one, explained);
3. validate units, composition totals and mass balance (with deliberately broken variants);
4. generate a constrained D-optimal mixture × Latin-hypercube process design with controls, replicates and day blocks;
5. take the plan through review/approval/execution and import synthetic results (with failures);
6. compare mean baseline, Scheffé ridge, random forest and Gaussian process;
7. evaluate interval coverage and measurement vs model variability;
8. propose five experiments (constrained Bayesian optimisation + Pareto + exploration) and review them;
9. review the Pareto frontier (`demo_output/pareto_frontier.html`);
10. reject out-of-domain candidates without offering predictions;
11. inspect stability trends with bounded forecasts (`demo_output/stability_trend.html`);
12. export a traceable research report (`demo_output/research_report.html` / `.json`) and a lineage chain.

See `docs/ARCHITECTURE.md`, `docs/SCIENTIFIC_NOTES.md`, `docs/GOVERNANCE.md`, `docs/API.md`.
