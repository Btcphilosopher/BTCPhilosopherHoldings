"""
Tertius Response — FastAPI Modular Monolith Reference Implementation
Independent Prototype for British Emergency Dispatch & Resource Coordination.
"""

from datetime import datetime, timezone
from typing import Literal, Optional
from uuid import uuid4

from fastapi import Depends, FastAPI, Header, HTTPException, WebSocket, status
from pydantic import BaseModel, Field

app = FastAPI(
    title="Tertius Response API (Prototype)",
    version="0.1.0-prototype",
    description="Modular monolith backend for Pennine Emergency Coordination Demonstrator.",
)

Role = Literal["DISPATCHER", "SUPERVISOR", "CLINICAL_ADVISOR", "RESPONDER", "AUDITOR"]


class OperatorPrincipal(BaseModel):
    user_id: str
    role: Role
    agency: Literal["ambulance", "fire", "police", "joint"]
    mfa_verified: bool = True


def get_current_operator(authorization: Optional[str] = Header(default=None)) -> OperatorPrincipal:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Bearer token required")
    # In full deployment, validate signed OIDC/JWT token and MFA AMR claim
    return OperatorPrincipal(user_id="op-disp-joint", role="DISPATCHER", agency="joint", mfa_verified=True)


class DispatchCommandRequest(BaseModel):
    incident_id: str
    resource_id: str
    idempotency_key: str = Field(min_length=8)
    expected_incident_version: int
    expected_resource_version: int
    delivery_channel: Literal["MDT_PUSH_MOCK", "AIRWAVE_RADIO_MOCK", "VOICE_FALLBACK"] = "MDT_PUSH_MOCK"


class DispatchCommandResponse(BaseModel):
    command_id: str
    idempotency_key: str
    stage: Literal["DISPATCH_SUBMITTED", "DELIVERED_CONFIRMED", "OUTCOME_UNKNOWN"]
    authorised_at: str
    crew_acknowledged_at: Optional[str] = None


IDEMPOTENCY_CACHE: dict[str, DispatchCommandResponse] = {}


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "prototype": "true", "timestamp": datetime.now(timezone.utc).isoformat()}


@app.post("/api/dispatch", response_model=DispatchCommandResponse, status_code=status.HTTP_201_CREATED)
async def submit_dispatch(
    body: DispatchCommandRequest,
    operator: OperatorPrincipal = Depends(get_current_operator),
) -> DispatchCommandResponse:
    if operator.role not in ("DISPATCHER", "SUPERVISOR"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Dispatcher or Supervisor role required")

    # Idempotency check prevents duplicate dispatch on network retry/timeout
    if body.idempotency_key in IDEMPOTENCY_CACHE:
        return IDEMPOTENCY_CACHE[body.idempotency_key]

    # Production query executes inside PostGIS transaction with SELECT ... FOR UPDATE
    # and checks version = expected_version + uq_active_resource_assignment
    response = DispatchCommandResponse(
        command_id=str(uuid4()),
        idempotency_key=body.idempotency_key,
        stage="DELIVERED_CONFIRMED",
        authorised_at=datetime.now(timezone.utc).isoformat(),
        crew_acknowledged_at=None,  # Explicit crew acknowledgement required separately
    )
    IDEMPOTENCY_CACHE[body.idempotency_key] = response
    return response


@app.websocket("/api/ws")
async def dispatch_stream(websocket: WebSocket) -> None:
    await websocket.accept()
    await websocket.send_json({"type": "ws:connected", "prototype": True})
    try:
        while True:
            _msg = await websocket.receive_text()
            await websocket.send_json({"type": "heartbeat", "timestamp": datetime.now(timezone.utc).isoformat()})
    except Exception:
        await websocket.close()
