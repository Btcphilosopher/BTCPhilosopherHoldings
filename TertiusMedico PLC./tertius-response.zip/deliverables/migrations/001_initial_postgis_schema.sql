-- Tertius Response — Independent Prototype PostgreSQL + PostGIS Schema
-- Separates incident records, assessments, resource register, dispatch commands,
-- communications, geography, hospital handovers, and immutable audit history.

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE incidents (
    id TEXT PRIMARY KEY,
    external_ref TEXT NOT NULL,
    title TEXT NOT NULL,
    service_scope TEXT NOT NULL CHECK (service_scope IN ('ambulance', 'fire', 'police', 'multi_agency')),
    lead_agency TEXT NOT NULL,
    status TEXT NOT NULL,
    receiving_channel TEXT NOT NULL,
    reported_location_text TEXT NOT NULL,
    verified_address TEXT, -- Nullable by design: never invent exact address from incomplete info
    geom GEOMETRY(Point, 4326) NOT NULL,
    location_confidence TEXT NOT NULL,
    uncertainty_radius_m INTEGER NOT NULL DEFAULT 500,
    access_information TEXT NOT NULL DEFAULT '',
    assessment_status TEXT NOT NULL DEFAULT 'UNASSESSED',
    current_priority_code TEXT NOT NULL DEFAULT 'UNASSESSED',
    priority_source TEXT NOT NULL DEFAULT 'UNASSESSED',
    potential_duplicate_of_id TEXT REFERENCES incidents(id),
    duplicate_review_status TEXT NOT NULL DEFAULT 'NONE',
    assigned_operator_id TEXT,
    lease_expires_at TIMESTAMPTZ,
    version INTEGER NOT NULL DEFAULT 1,
    opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_incidents_geom ON incidents USING GIST (geom);

CREATE TABLE incident_fact_layers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id TEXT NOT NULL REFERENCES incidents(id) ON DELETE RESTRICT,
    layer_type TEXT NOT NULL CHECK (layer_type IN ('CALLER_STATEMENT', 'OPERATOR_OBSERVATION', 'EXTERNAL_INFO', 'CONFIRMED_FACT')),
    sharing_scope TEXT NOT NULL CHECK (sharing_scope IN ('SHARED_JESIP', 'AGENCY_ONLY', 'RESTRICTED_CLINICAL', 'RESTRICTED_POLICE')),
    source_label TEXT NOT NULL,
    content TEXT NOT NULL,
    recorded_by TEXT NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE assessments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id TEXT NOT NULL REFERENCES incidents(id) ON DELETE RESTRICT,
    pathway_adapter TEXT NOT NULL,
    pathway_category TEXT NOT NULL,
    priority_code TEXT NOT NULL,
    severity_rank SMALLINT NOT NULL CHECK (severity_rank BETWEEN 1 AND 4),
    source TEXT NOT NULL CHECK (source IN ('AUTHORISED_ASSESSMENT', 'SUPERVISOR_OVERRIDE')),
    rationale TEXT NOT NULL,
    assessed_by_user_id TEXT NOT NULL,
    assessed_by_role TEXT NOT NULL,
    assessed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_current BOOLEAN NOT NULL DEFAULT TRUE,
    superseded_reason TEXT
);

CREATE TABLE resources (
    id TEXT PRIMARY KEY,
    callsign TEXT NOT NULL UNIQUE,
    service TEXT NOT NULL CHECK (service IN ('ambulance', 'fire', 'police')),
    organisation TEXT NOT NULL,
    vehicle_or_team_type TEXT NOT NULL,
    jurisdiction_zone TEXT NOT NULL,
    verified_capabilities TEXT[] NOT NULL DEFAULT '{}',
    operational_restrictions TEXT[] NOT NULL DEFAULT '{}',
    staff_availability TEXT NOT NULL,
    vehicle_availability TEXT NOT NULL,
    crew_readiness TEXT NOT NULL,
    dispatch_authorisation TEXT NOT NULL,
    current_assignment_id UUID,
    observed_geom GEOMETRY(Point, 4326) NOT NULL,
    position_observed_at TIMESTAMPTZ NOT NULL,
    position_uncertainty_m INTEGER NOT NULL DEFAULT 25,
    communication_health TEXT NOT NULL,
    maintenance_status TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX idx_resources_geom ON resources USING GIST (observed_geom);

CREATE TABLE dispatch_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    command_id UUID NOT NULL UNIQUE,
    idempotency_key TEXT NOT NULL UNIQUE,
    incident_id TEXT NOT NULL REFERENCES incidents(id),
    resource_id TEXT NOT NULL REFERENCES resources(id),
    stage TEXT NOT NULL,
    authorised_by TEXT NOT NULL,
    authorised_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    command_submitted_at TIMESTAMPTZ,
    communication_delivered_at TIMESTAMPTZ,
    crew_acknowledged_at TIMESTAMPTZ,
    observed_movement_at TIMESTAMPTZ,
    arrived_at_scene_at TIMESTAMPTZ,
    cleared_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ NOT NULL,
    outcome_note TEXT NOT NULL DEFAULT '',
    version INTEGER NOT NULL DEFAULT 1
);

-- Enforce single active assignment per resource transactionally
CREATE UNIQUE INDEX uq_active_resource_assignment
ON dispatch_assignments (resource_id)
WHERE stage NOT IN ('CLEAR', 'REJECTED', 'WITHDRAWN', 'CANCELLED');

CREATE TABLE communications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id TEXT REFERENCES incidents(id),
    assignment_id UUID REFERENCES dispatch_assignments(id),
    channel TEXT NOT NULL,
    direction TEXT NOT NULL,
    sender TEXT NOT NULL,
    recipient TEXT NOT NULL,
    original_content TEXT NOT NULL,
    lock_screen_preview TEXT NOT NULL,
    amended_from_id UUID REFERENCES communications(id),
    attempt_status TEXT NOT NULL,
    delivery_status TEXT NOT NULL,
    ack_status TEXT NOT NULL,
    sharing_scope TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE audit_log (
    sequence BIGSERIAL PRIMARY KEY,
    event_id UUID NOT NULL DEFAULT gen_random_uuid(),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    actor_id TEXT NOT NULL,
    actor_role TEXT NOT NULL,
    actor_agency TEXT NOT NULL,
    action_type TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    sharing_scope TEXT NOT NULL,
    summary TEXT NOT NULL,
    integrity_hash TEXT NOT NULL
);

CREATE TABLE approved_attachments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id TEXT NOT NULL REFERENCES incidents(id),
    object_key TEXT NOT NULL,
    content_type TEXT NOT NULL,
    sha256_digest TEXT NOT NULL,
    sharing_scope TEXT NOT NULL,
    uploaded_by TEXT NOT NULL,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
