# Tertius Response — API Documentation (Prototype)

All endpoints are prefixed with `/api` and require `Authorization: Bearer <token>` (obtained via `/api/auth/login` + `/api/auth/mfa-verify`) except `/api/health` and `/api/auth/directory`.

## Authentication & MFA
- `GET /api/auth/directory` — List synthetic Pennine operator accounts for prototype sign-in.
- `POST /api/auth/login` — Body: `{ operatorId, mfaCode? }`. Issues session token.
- `POST /api/auth/mfa-verify` — Verifies 6-digit MFA challenge before permitting operational access.

## Incidents & Assessment
- `GET /api/state` — Returns full server-authoritative snapshot scoped & redacted by caller clearance (`canViewRestrictedClinical`, `canViewRestrictedPolice`).
- `POST /api/incidents` — Intake new incident (`DISPATCHER` / `SUPERVISOR`). Separates caller statement from operator observations & confirmed facts.
- `PATCH /api/incidents/:id/location` — Version-checked (`expectedVersion`) location review & uncertainty update.
- `POST /api/incidents/:id/duplicate-review` — Explicit review workflow (`CONFIRMED_SEPARATE` | `LINKED_RELATED`); never silently merges.
- `POST /api/incidents/:id/assessment` — Records structured pathway assessment. Priority overrides require `SUPERVISOR` or `CLINICAL_ADVISOR`.
- `POST /api/incidents/:id/circumstance-change` — Flags `REASSESSMENT_REQUIRED` without erasing prior assessments.
- `POST /api/incidents/:id/ownership` — Acquires, releases, hands over, or supervisor-takes-over incident editing lease.

## Recommendations & Idempotent Dispatch
- `GET /api/incidents/:id/recommendations` — Computes hard eligibility disqualifiers + advisory ranking + missing information.
- `POST /api/dispatch` — Requires `idempotencyKey`, `expectedIncidentVersion`, `expectedResourceVersion`. Prevents double-assignment and returns original command on retry.
- `GET /api/dispatch/command/:commandId` — Queries existing command outcome after network timeout instead of creating a duplicate assignment.
- `POST /api/dispatch/:assignmentId/stage` — Transitions lifecycle (`CREW_ACKNOWLEDGED`, `EN_ROUTE`, `AT_SCENE`, `CLEAR`, `REJECTED`, `WITHDRAWN`, `CANCELLED`).

## Hospitals, Multi-Agency & Replay
- `POST /api/dispatch/:assignmentId/handover` — Clinician destination selection, pre-alert, hospital arrival, and 3-stage handover milestones. Arrival never auto-clears crew.
- `POST /api/multi-agency/requests` — Issues JESIP assistance request without taking command of partner resources.
- `GET /api/replay` — Isolated, read-only replay frames separated from live command endpoints.
- `GET /api/reports/export/:incidentId` — Generates attributable, scope-redacted operational report JSON.
