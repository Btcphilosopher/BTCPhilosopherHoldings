# Tertius Response — Capability Status Matrix

| Capability | Status in Live App | Notes & Boundaries |
| :--- | :--- | :--- |
| **Control-Room Console (10 Views, Keyboard-First)** | **Implemented** | Angular 21 SSR + Express backend + live WebSocket updates on `/api/ws`. |
| **Incident Intake & Separated Fact Layers** | **Implemented** | Separates caller statements, operator observations, external telemetry, and confirmed facts. |
| **Authorised Assessment & Override Audit** | **Implemented** | Replaceable pathway adapter with fictional Pennine categories; role-gated overrides. |
| **Resource Register & Hard-Eligibility Recommender** | **Implemented** | Distinct staff/vehicle/readiness/authorisation states; transparent scores & disqualifiers. |
| **Idempotent Dispatch & Conflict/Lease Control** | **Implemented** | Unique `commandId`, `idempotencyKey`, version checks, timeout query, ownership leases. |
| **Pennine Local Operational Map & Route Planning** | **Implemented (Local Vector)** | Works without external API keys; shows uncertainty circles, stale markers, hazards, boundaries. |
| **Deterministic Simulator & Isolated Replay** | **Implemented** | Ground truth kept separate from dispatcher observations; Replay isolated from live state. |
| **Telephony, SMS, Airwave & MDT Push** | **Simulated (Mock Adapters)** | Preserves original + amended messages and separates attempts, delivery, and acks. |
| **Organisational Sign-In & MFA** | **Simulated (Prototype IAM)** | Enforces server-side RBAC, Bearer session tokens, and 6-digit MFA gate. |
| **Python FastAPI + PostGIS + Docker Compose** | **Delivered as Source Artifacts** | Provided under `/deliverables/` for multi-container PostgreSQL/PostGIS/MinIO deployment. |
| **Kotlin + Jetpack Compose Android App** | **Delivered as Source + Web MDT View** | Source under `/deliverables/android-responder/` plus interactive Responder MDT view in web UI. |
| **Live 999/112, NHS Pathways, Airwave, AML** | **Deferred (Requires Statutory Accreditation)** | Explicitly excluded until statutory governance, IG, and DSPT/PSN accreditation. |
