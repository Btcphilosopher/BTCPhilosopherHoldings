# Tertius Response — Degraded Operation & Continuity Procedure

**Important Notice**: This prototype continuity workflow supports evaluation and training only. It is **not** a substitute for an emergency service's statutory Business Continuity Plan (BCP), paper card fallback, or Airwave fall-back SOPs.

## 1. Degraded Modes Detected by the Interface
1. **Lost Connectivity / Backend Unreachable**: Prominent amber/red degraded banner appears. Cached read-only assignment snapshots remain viewable with an explicit `"CACHED — NOT CURRENT"` timestamp warning.
2. **Comms Adapter Outage**: MDT/SMS deliveries enter `OUTCOME_UNKNOWN` or `FAILED_LINK`. Dispatchers must NOT assume delivery and must initiate voice radio hail.
3. **Stale GPS (>180s / >300s Horizon)**: Unit pins switch to amber `STALE` outline and route extrapolation stops.
4. **Missing Map Tiles**: Interface falls back to local coordinate grid & OS National Grid reference display.

## 2. Manual Continuity & Reconciliation Workflow
1. Record verbal radio mobilisations, timestamps, and callsigns on the local continuity log with operator badge number.
2. Upon system restoration, verify backend restart timestamp and audit sequence continuity.
3. Reconcile manual actions in chronological order using `POST /api/dispatch` (with `AIRWAVE_RADIO_MOCK` / `VOICE_FALLBACK` channel) and explicit stage updates, noting `[RECONCILED FROM MANUAL CONTINUITY LOG]` in the outcome note.
4. Resolve any version conflicts (`HTTP 409`) with Supervisor review before closing incidents.
