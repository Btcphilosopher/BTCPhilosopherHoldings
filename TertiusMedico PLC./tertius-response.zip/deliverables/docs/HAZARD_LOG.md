# Tertius Response — Prototype Hazard Log (Safety & Governance)

**Status**: Independent Prototype (Synthetic Pennine Data Only). Not approved for live 999/112 operational dispatch.

| Hazard ID | Failure Mode | Operational Consequence | Prototype Mitigation | Residual Risk / Pre-Deployment Action |
| :--- | :--- | :--- | :--- | :--- |
| **HAZ-01** | **Wrong or fabricated incident location** | Resource dispatched to incorrect rural/urban address. | `verifiedAddress` remains `null` when confidence != `VERIFIED_EXACT`; map shows uncertainty radius & conflicting markers. | Integrate OS AddressBase / Gazetteer & AML/eCall verified feed before live use. |
| **HAZ-02** | **Lost or silently merged duplicate incident** | Unattended casualty from distinct secondary incident. | Potential duplicates enter explicit `PENDING_REVIEW` workflow; silent merging prohibited. | Enforce dual-operator check on multi-casualty major incidents. |
| **HAZ-03** | **Duplicate resource dispatch on timeout** | Two crews mobilised unnecessarily or same unit double-booked. | Unique `commandId`, `idempotencyKey`, version checks, and timeout outcome query (`/api/dispatch/command/:id`). | Verify PostGIS `uq_active_resource_assignment` partial unique index under failover. |
| **HAZ-04** | **Stale resource GPS / dead-reckoning error** | Dispatcher selects unit that has moved far from last fix. | Position age >180s flagged `STALE`; extrapolation halted past 300s horizon. | Require AVL heartbeat SLA monitoring and automated radio fallback prompts. |
| **HAZ-05** | **Failed delivery mistaken for crew acceptance** | Control believes crew is responding when MDT dropped packet. | Separate `DISPATCH_SUBMITTED`, `DELIVERED_CONFIRMED`, and `CREW_ACKNOWLEDGED`. | Enforce voice radio hail timer if `CREW_ACKNOWLEDGED` absent after 60s. |
| **HAZ-06** | **Incorrect permissions / data leakage** | Unauthorised user overrides priority or views medical/police intel. | Server-side RBAC, MFA verification gate, and `RESTRICTED_CLINICAL` / `RESTRICTED_POLICE` redaction. | Integrate NHS CIS2 / Police IAM OIDC and periodic access recertification. |
| **HAZ-07** | **Unavailable resource shown available** | Delayed response due to VOR vehicle, meal break, or short crew. | Four distinct dimensions (`staffAvailability`, `vehicleAvailability`, `crewReadiness`, `dispatchAuthorisation`) + hard disqualifiers. | Connect real fleet telemetry & rostering feeds. |
| **HAZ-08** | **Premature resource clearance at hospital** | Ambulance marked available while patient still on trolley. | Hospital arrival milestone separated from `TRIAGE_BRIEF`, `CLINICAL_HANDOVER`, `TROLLEY_TRANSFER`, and explicit `CLEAR`. | Train crews & control staff on mandatory explicit clear confirmation. |
