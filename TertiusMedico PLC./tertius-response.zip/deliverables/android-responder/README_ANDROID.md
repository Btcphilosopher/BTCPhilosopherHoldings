# Tertius Responder Android Application (Kotlin + Jetpack Compose)

## Scope & Safety Rules
- Designed for Android 14+ (API 34+) using Jetpack Compose Material 3.
- **No interaction while driving**: Motion/speed sensor lock hides interactive touch buttons while moving and instructs crews to use hands-free voice radio.
- **Lock-screen privacy**: Push notifications show only `"New assignment received — open secure MDT"` without clinical or police PII.
- **Reconnection reconciliation**: Queued offline updates remain marked `UNSYNCHRONISED_OFFLINE` until the handset fetches current server `assignment.version` and reconciles conflicts before committing consequential actions.

## Build Instructions
1. Open `/deliverables/android-responder/` in Android Studio Ladybug (2024.2+) with JDK 17.
2. Ensure `minSdk = 26`, `targetSdk = 35`, and Compose BOM `2025.01.00` in `app/build.gradle.kts`.
3. Configure `BASE_API_URL` in `BuildConfig` pointing to the FastAPI/Express prototype host (`https://10.0.2.2:3000` for Android Emulator).
4. Run `./gradlew assembleDebug` or `./gradlew testDebugUnitTest`.
