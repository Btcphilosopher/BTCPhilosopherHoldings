package uk.co.tertius.responder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

enum class SyncState { ACCEPTED, PENDING_SYNC, UNSYNCHRONISED_OFFLINE, REJECTED }

data class QueuedStatusUpdate(
    val id: String,
    val targetStage: String,
    val note: String,
    val syncState: SyncState,
)

data class ResponderAssignmentUiState(
    val assignmentId: String = "asg-415-1",
    val incidentId: String = "INC-2026-0412",
    val priorityLabel: String = "CRITICAL · CAT-A1",
    val locationText: String = "M62 Eastbound Marker 34/2B (Windy Hill)",
    val accessNotes: String = "Access via M62 J22 slip or A672 emergency gate.",
    val hazards: List<String> = listOf("Dense moorland fog (<40m)", "45 mph crosswinds"),
    val stage: String = "DELIVERED_CONFIRMED",
    val isDrivingInMotion: Boolean = false,
    val isOffline: Boolean = false,
    val queuedUpdates: List<QueuedStatusUpdate> = emptyList(),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ResponderScreen()
        }
    }
}

@Composable
fun ResponderScreen() {
    var state by remember { mutableStateOf(ResponderAssignmentUiState()) }

    val midnightNavy = Color(0xFF0B1426)
    val panelSlate = Color(0xFF132038)
    val cyanAccent = Color(0xFF22D3EE)
    val amberCaution = Color(0xFFF59E0B)
    val redCritical = Color(0xFFEF4444)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(midnightNavy)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = "TERTIUS RESPONDER MDT (PROTOTYPE)",
            color = cyanAccent,
            fontWeight = FontWeight.Bold,
        )

        if (state.isOffline) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, amberCaution)
                    .padding(12.dp),
            ) {
                Text(
                    text = "DEGRADED: OFFLINE MODE — Showing cached assignment. Reconcile before submitting queued actions.",
                    color = amberCaution,
                )
            }
        }

        if (state.isDrivingInMotion) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, amberCaution)
                    .padding(16.dp),
            ) {
                Text(
                    text = "VEHICLE IN MOTION — Screen interaction disabled for road safety. Use hands-free Airwave radio.",
                    color = Color.White,
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(panelSlate)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(text = "${state.incidentId} — ${state.priorityLabel}", color = redCritical, fontWeight = FontWeight.Bold)
                Text(text = "Stage: ${state.stage}", color = cyanAccent)
                Text(text = "Location: ${state.locationText}", color = Color.White)
                Text(text = "Access: ${state.accessNotes}", color = Color(0xFFCBD5E1))
                Text(text = "Hazards: ${state.hazards.joinToString(" · ")}", color = amberCaution)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val nextSync = if (state.isOffline) SyncState.UNSYNCHRONISED_OFFLINE else SyncState.ACCEPTED
                    state = state.copy(
                        stage = if (state.isOffline) state.stage else "CREW_ACKNOWLEDGED",
                        queuedUpdates = state.queuedUpdates + QueuedStatusUpdate(
                            id = "upd-${state.queuedUpdates.size + 1}",
                            targetStage = "CREW_ACKNOWLEDGED",
                            note = "Crew confirmed via MDT",
                            syncState = nextSync,
                        ),
                    )
                }) {
                    Text("Acknowledge")
                }

                Button(onClick = {
                    val nextSync = if (state.isOffline) SyncState.UNSYNCHRONISED_OFFLINE else SyncState.ACCEPTED
                    state = state.copy(
                        stage = if (state.isOffline) state.stage else "AT_SCENE",
                        queuedUpdates = state.queuedUpdates + QueuedStatusUpdate(
                            id = "upd-${state.queuedUpdates.size + 1}",
                            targetStage = "AT_SCENE",
                            note = "Arrived at scene",
                            syncState = nextSync,
                        ),
                    )
                }) {
                    Text("At Scene")
                }

                OutlinedButton(onClick = {
                    state = state.copy(isOffline = !state.isOffline)
                }) {
                    Text(if (state.isOffline) "Reconnect & Reconcile" else "Simulate Offline")
                }
            }
        }

        if (state.queuedUpdates.isNotEmpty()) {
            Text(text = "Update Synchronisation Queue", color = Color.White, fontWeight = FontWeight.SemiBold)
            state.queuedUpdates.forEach { upd ->
                Text(
                    text = "${upd.targetStage} [${upd.syncState.name}] — ${upd.note}",
                    color = if (upd.syncState == SyncState.ACCEPTED) cyanAccent else amberCaution,
                )
            }
        }
    }
}
