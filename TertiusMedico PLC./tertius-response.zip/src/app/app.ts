import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { OperationalMapComponent } from './components/operational-map';
import { ReplayConsoleComponent } from './components/replay-console';
import { ResponderConsoleComponent } from './components/responder-console';
import { ControlRoomService, type NavSection } from './core/control-room.service';
import type {
  AgencyCode,
  CommunicationRecord,
  DispatchAssignment,
  DispatchStage,
  Incident,
  LocationConfidence,
  ResourceUnit,
  ServiceType,
  SharingScope,
} from '../shared/domain';

interface NavItem {
  id: NavSection;
  label: string;
  icon: string;
  shortcut: string;
}

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    ReactiveFormsModule,
    MatIconModule,
    OperationalMapComponent,
    ResponderConsoleComponent,
    ReplayConsoleComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  host: {
    '(window:keydown)': 'onGlobalKeydown($event)',
  },
})
export class App implements OnInit, OnDestroy {
  readonly svc = inject(ControlRoomService);

  readonly navItems: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: 'dashboard', shortcut: '1' },
    { id: 'incidents', label: 'Incidents', icon: 'warning_amber', shortcut: '2' },
    { id: 'dispatch', label: 'Dispatch', icon: 'send', shortcut: '3' },
    { id: 'resources', label: 'Resources', icon: 'local_shipping', shortcut: '4' },
    { id: 'communications', label: 'Communications', icon: 'forum', shortcut: '5' },
    { id: 'hospitals', label: 'Hospitals', icon: 'local_hospital', shortcut: '6' },
    { id: 'multi_agency', label: 'Multi-agency', icon: 'hub', shortcut: '7' },
    { id: 'replay', label: 'Replay', icon: 'history', shortcut: '8' },
    { id: 'reports', label: 'Reports', icon: 'summarize', shortcut: '9' },
    { id: 'administration', label: 'Administration', icon: 'admin_panel_settings', shortcut: '0' },
  ];

  // Filter & UI state
  readonly queueServiceFilter = signal<'ALL' | ServiceType>('ALL');
  readonly queueSearch = signal<string>('');
  readonly detailTab = signal<'FACTS' | 'ASSESSMENT' | 'ALLOCATION' | 'DISPATCH'>('FACTS');

  // Modals & Drawers
  readonly showNewIncidentModal = signal(false);
  readonly showShortcutsModal = signal(false);
  readonly showMfaModal = signal(false);
  readonly pendingMfaOperatorId = signal<string>('');

  // Selected Deliverable & Report preview
  readonly selectedDeliverablePath = signal<string>('');
  readonly selectedDeliverableContent = signal<string>('');
  readonly exportedReportJson = signal<string>('');
  readonly backupSnapshotText = signal<string>('');

  // Reactive Forms
  readonly intakeForm = new FormGroup({
    title: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    serviceScope: new FormControl<ServiceType>('ambulance', { nonNullable: true }),
    incidentType: new FormControl('RTC / Medical Emergency', { nonNullable: true }),
    receivingChannel: new FormControl('999_SIM_VOICE', { nonNullable: true }),
    reportedLocationText: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    locationConfidence: new FormControl<LocationConfidence>('UNVERIFIED_LANDMARK', { nonNullable: true }),
    uncertaintyRadiusMeters: new FormControl(650, { nonNullable: true }),
    callerName: new FormControl('Synthetic Caller', { nonNullable: true }),
    callbackNumber: new FormControl('+44 7700 900555', { nonNullable: true }),
    safeToCall: new FormControl(true, { nonNullable: true }),
    callerStatement: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    knownHazardsText: new FormControl('', { nonNullable: true }),
    accessInformation: new FormControl('', { nonNullable: true }),
  });

  readonly assessmentForm = new FormGroup({
    pathwayAdapter: new FormControl('Pennine Clinical & Operational Pathways (Prototype)', { nonNullable: true }),
    pathwayPreset: new FormControl('CAT-A1', { nonNullable: true }),
    rationale: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    isOverride: new FormControl(false, { nonNullable: true }),
  });

  readonly locationReviewForm = new FormGroup({
    verifiedAddress: new FormControl('', { nonNullable: true }),
    locationConfidence: new FormControl<LocationConfidence>('VERIFIED_EXACT', { nonNullable: true }),
    uncertaintyRadiusMeters: new FormControl(35, { nonNullable: true }),
    factNote: new FormControl('Confirmed via Highways marker post & caller callback', { nonNullable: true }),
  });

  readonly commForm = new FormGroup({
    channel: new FormControl<CommunicationRecord['channel']>('AIRWAVE_RADIO_MOCK', { nonNullable: true }),
    recipient: new FormControl('AMB-41', { nonNullable: true, validators: [Validators.required] }),
    content: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    sharingScope: new FormControl<SharingScope>('AGENCY_ONLY', { nonNullable: true }),
  });

  readonly interAgencyForm = new FormGroup({
    incidentId: new FormControl('INC-2026-0412', { nonNullable: true }),
    requestedAgency: new FormControl<AgencyCode>('fire', { nonNullable: true }),
    requestedCapability: new FormControl('RTC_EXTRICATION', { nonNullable: true }),
    rationale: new FormControl('Suspected entrapped driver in fog collision; requires hydraulic rescue.', { nonNullable: true }),
    sharingScope: new FormControl<SharingScope>('SHARED_JESIP', { nonNullable: true }),
  });

  readonly mfaCodeControl = new FormControl('482910', { nonNullable: true });

  readonly filteredIncidents = computed(() => {
    const snap = this.svc.snapshot();
    if (!snap) return [];
    const svcFilter = this.queueServiceFilter();
    const query = this.queueSearch().trim().toLowerCase();

    return snap.incidents.filter((inc) => {
      if (svcFilter !== 'ALL' && inc.serviceScope !== svcFilter && !inc.participatingAgencies.includes(svcFilter as AgencyCode)) {
        return false;
      }
      if (!query) return true;
      return (
        inc.id.toLowerCase().includes(query) ||
        inc.title.toLowerCase().includes(query) ||
        inc.reportedLocationText.toLowerCase().includes(query)
      );
    });
  });

  readonly selectedIncidentAssignments = computed(() => {
    const inc = this.svc.selectedIncident();
    const snap = this.svc.snapshot();
    if (!inc || !snap) return [];
    return snap.assignments.filter((a) => a.incidentId === inc.id);
  });

  readonly activeAssignmentsCount = computed(() => {
    const snap = this.svc.snapshot();
    if (!snap) return 0;
    return snap.assignments.filter((a) => !['CLEAR', 'REJECTED', 'WITHDRAWN', 'CANCELLED'].includes(a.stage)).length;
  });

  readonly availableResourcesCount = computed(() => {
    const snap = this.svc.snapshot();
    if (!snap) return 0;
    return snap.resources.filter(
      (r) =>
        r.currentAssignmentId === null &&
        r.staffAvailability === 'ON_SHIFT' &&
        r.vehicleAvailability === 'SERVICEABLE' &&
        r.crewReadiness === 'READY' &&
        r.dispatchAuthorisation === 'AUTHORISED',
    ).length;
  });

  readonly duplicatePendingCount = computed(() => {
    const snap = this.svc.snapshot();
    if (!snap) return 0;
    return snap.incidents.filter((i) => i.duplicateReviewStatus === 'PENDING_REVIEW').length;
  });

  readonly formattedClock = computed(() => {
    const iso = this.svc.liveClockIso();
    return iso.slice(11, 19) + ' UTC';
  });

  ngOnInit(): void {
    void this.svc.init();
  }

  ngOnDestroy(): void {
    this.svc.destroy();
  }

  onGlobalKeydown(event: KeyboardEvent): void {
    const tag = (event.target as HTMLElement | null)?.tagName?.toLowerCase();
    const isTyping = tag === 'input' || tag === 'textarea' || tag === 'select';

    if (event.key === 'Escape') {
      this.showNewIncidentModal.set(false);
      this.showShortcutsModal.set(false);
      this.showMfaModal.set(false);
      return;
    }

    if (isTyping) return;

    if (event.key === '?') {
      event.preventDefault();
      this.showShortcutsModal.update((v) => !v);
      return;
    }

    if (event.key.toLowerCase() === 'n') {
      event.preventDefault();
      this.showNewIncidentModal.set(true);
      return;
    }

    if (event.key.toLowerCase() === 'r') {
      event.preventDefault();
      void this.svc.refreshState();
      return;
    }

    if (event.key.toLowerCase() === 'j' || event.key.toLowerCase() === 'k') {
      const list = this.filteredIncidents();
      if (list.length === 0) return;
      const curIdx = list.findIndex((i) => i.id === this.svc.selectedIncidentId());
      const delta = event.key.toLowerCase() === 'j' ? 1 : -1;
      const nextIdx = (curIdx + delta + list.length) % list.length;
      this.svc.selectIncident(list[nextIdx].id);
      return;
    }

    const matchedNav = this.navItems.find((n) => n.shortcut === event.key);
    if (matchedNav) {
      this.navigate(matchedNav.id);
    }
  }

  navigate(section: NavSection): void {
    this.svc.activeSection.set(section);
    if (section === 'replay') {
      void this.svc.loadIsolatedReplay();
    }
    if (section === 'administration') {
      void this.svc.fetchDeliverablesList();
    }
  }

  setQueueFilter(filter: 'ALL' | ServiceType): void {
    this.queueServiceFilter.set(filter);
  }

  onQueueSearch(event: Event): void {
    this.queueSearch.set((event.target as HTMLInputElement).value);
  }

  async onSwitchOperator(event: Event): Promise<void> {
    const opId = (event.target as HTMLSelectElement).value;
    if (!opId) return;
    // Trigger MFA verification step cleanly for operator switching
    this.pendingMfaOperatorId.set(opId);
    await this.svc.signIn(opId);
    this.showMfaModal.set(true);
  }

  async submitMfaVerification(): Promise<void> {
    const code = this.mfaCodeControl.value;
    const ok = await this.svc.verifyMfa(code);
    if (ok) {
      this.showMfaModal.set(false);
    }
  }

  async submitNewIncident(): Promise<void> {
    if (this.intakeForm.invalid) return;
    const v = this.intakeForm.getRawValue();
    const hazards = v.knownHazardsText
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    const id = await this.svc.createIncident({
      title: v.title,
      serviceScope: v.serviceScope,
      incidentType: v.incidentType,
      receivingChannel: v.receivingChannel,
      reportedLocationText: v.reportedLocationText,
      locationConfidence: v.locationConfidence,
      uncertaintyRadiusMeters: Number(v.uncertaintyRadiusMeters),
      callerName: v.callerName,
      callbackNumber: v.callbackNumber,
      safeToCall: v.safeToCall,
      callerStatement: v.callerStatement,
      knownHazards: hazards,
      accessInformation: v.accessInformation,
    });
    if (id) {
      this.intakeForm.reset({
        title: '',
        serviceScope: 'ambulance',
        incidentType: 'RTC / Medical Emergency',
        receivingChannel: '999_SIM_VOICE',
        reportedLocationText: '',
        locationConfidence: 'UNVERIFIED_LANDMARK',
        uncertaintyRadiusMeters: 650,
        callerName: 'Synthetic Caller',
        callbackNumber: '+44 7700 900555',
        safeToCall: true,
        callerStatement: '',
        knownHazardsText: '',
        accessInformation: '',
      });
      this.showNewIncidentModal.set(false);
      this.svc.activeSection.set('incidents');
    }
  }

  async submitLocationReview(inc: Incident): Promise<void> {
    const v = this.locationReviewForm.getRawValue();
    // If conflicting locations exist, converge towards eCall coordinate SE 033 151
    const targetCoords =
      inc.conflictingLocations.length > 1
        ? inc.conflictingLocations[1].coordinates
        : inc.coordinates;
    await this.svc.reviewLocation(inc.id, {
      expectedVersion: inc.version,
      verifiedAddress:
        v.locationConfidence === 'VERIFIED_EXACT' && v.verifiedAddress.trim()
          ? v.verifiedAddress.trim()
          : null,
      locationConfidence: v.locationConfidence,
      uncertaintyRadiusMeters: Number(v.uncertaintyRadiusMeters),
      coordinates: targetCoords,
      factNote: v.factNote.trim() || 'Location reviewed by operator',
    });
  }

  async submitAssessment(inc: Incident): Promise<void> {
    if (this.assessmentForm.invalid) return;
    const v = this.assessmentForm.getRawValue();
    const presets: Record<string, { cat: string; label: string; rank: 1 | 2 | 3 | 4 }> = {
      'CAT-A1': { cat: 'CAT-A1 — Immediate Life Threat (Prototype)', label: 'Category A1 — Immediate Response', rank: 1 },
      'CAT-A2': { cat: 'CAT-A2 — Urgent Clinical Need (Prototype)', label: 'Category A2 — Urgent Response', rank: 2 },
      'F1-LIFE': { cat: 'F1 — Life Risk / Entrapment (Prototype)', label: 'Fire F1 — Immediate Rescue', rank: 1 },
      'F3-HAZMAT': { cat: 'F3 — Hazardous Materials (Prototype)', label: 'Fire F3 — Specialist Hazmat', rank: 2 },
      'P-IMMEDIATE': { cat: 'Grade 1 — Immediate Police Risk (Prototype)', label: 'Police Grade 1 — Immediate', rank: 1 },
      'P-PRIORITY': { cat: 'Grade 2 — Priority Response (Prototype)', label: 'Police Grade 2 — Priority', rank: 2 },
    };
    const chosen = presets[v.pathwayPreset] ?? presets['CAT-A1'];

    const ok = await this.svc.recordAssessment(inc.id, {
      expectedVersion: inc.version,
      pathwayAdapter: v.pathwayAdapter,
      pathwayCategory: chosen.cat,
      priorityCode: v.pathwayPreset,
      priorityLabel: chosen.label,
      severityRank: chosen.rank,
      rationale: v.rationale,
      isOverride: v.isOverride,
    });
    if (ok) {
      this.assessmentForm.patchValue({ rationale: '', isOverride: false });
      this.detailTab.set('ALLOCATION');
    }
  }

  async dispatchRecommended(inc: Incident, resourceId: string, simulateTimeout = false): Promise<void> {
    const res = this.svc.snapshot()?.resources.find((r) => r.id === resourceId);
    if (!res) return;
    const idemKey = `idem-${inc.id}-${res.id}-${Date.now()}`;
    const cmdId = `cmd-${inc.id.slice(-4)}-${res.callsign}-${Date.now().toString(36)}`;
    const asg = await this.svc.submitDispatch({
      incidentId: inc.id,
      resourceId: res.id,
      idempotencyKey: idemKey,
      commandId: cmdId,
      expectedIncidentVersion: inc.version,
      expectedResourceVersion: res.version,
      deliveryChannel: 'MDT_PUSH_MOCK',
      simulateTimeout,
    });
    if (asg) {
      this.detailTab.set('DISPATCH');
    }
  }

  async updateStage(asg: DispatchAssignment, stage: DispatchStage, delayed = false): Promise<void> {
    await this.svc.updateAssignmentStage(
      asg.id,
      stage,
      `Control/Responder stage update -> ${stage}`,
      delayed,
    );
  }

  async sendComm(): Promise<void> {
    if (this.commForm.invalid) return;
    const v = this.commForm.getRawValue();
    await this.svc.sendCommunication({
      incidentId: this.svc.selectedIncident()?.id ?? null,
      resourceId: null,
      channel: v.channel,
      recipient: v.recipient,
      content: v.content,
      sharingScope: v.sharingScope,
    });
    this.commForm.patchValue({ content: '' });
  }

  async amendComm(comm: CommunicationRecord): Promise<void> {
    await this.svc.sendCommunication({
      incidentId: comm.incidentId,
      resourceId: comm.resourceId,
      channel: comm.channel,
      recipient: comm.recipient,
      content: `[AMENDMENT TO ${comm.id}] ${comm.originalContent} — Corrected details verified.`,
      sharingScope: comm.sharingScope,
      amendedFromId: comm.id,
      amendmentNote: 'Operator correction preserving original record',
    });
  }

  async submitInterAgencyRequest(): Promise<void> {
    const v = this.interAgencyForm.getRawValue();
    await this.svc.requestInterAgency(v);
  }

  async toggleResilience(flag: 'connectivityDegraded' | 'commsAdapterOutage' | 'staleGpsSimulation' | 'mapTilesMissing' | 'delayedAckMode'): Promise<void> {
    const cur = this.svc.snapshot()?.resilience;
    if (!cur) return;
    await this.svc.setResilienceFlags({ [flag]: !cur[flag] });
  }

  async generateAndPreviewReport(incidentId: string): Promise<void> {
    const report = await this.svc.exportReport(incidentId);
    if (report) {
      this.exportedReportJson.set(JSON.stringify(report, null, 2));
    }
  }

  downloadExportedReport(): void {
    const text = this.exportedReportJson();
    if (!text) return;
    const blob = new Blob([text], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tertius-operational-report-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async viewDeliverable(path: string): Promise<void> {
    this.selectedDeliverablePath.set(path);
    const content = await this.svc.fetchDeliverableFile(path);
    this.selectedDeliverableContent.set(content);
  }

  async createBackup(): Promise<void> {
    const json = await this.svc.exportBackupSnapshot();
    if (json) this.backupSnapshotText.set(json);
  }

  async restoreBackup(): Promise<void> {
    const json = this.backupSnapshotText();
    if (!json) return;
    await this.svc.restoreBackupSnapshot(json);
  }

  // Helper to run specific Pennine 14-step demonstration shortcuts directly from Overview
  async runDemonstratorStep(stepNumber: number): Promise<void> {
    const inc412 = this.svc.snapshot()?.incidents.find((i) => i.id === 'INC-2026-0412');
    const asgs = this.svc.snapshot()?.assignments ?? [];
    const active412 = asgs.find((a) => a.incidentId === 'INC-2026-0412' && a.stage !== 'CLEAR' && a.stage !== 'WITHDRAWN');

    switch (stepNumber) {
      case 1:
        this.svc.activeSection.set('incidents');
        this.showNewIncidentModal.set(true);
        break;
      case 2:
        this.svc.selectIncident('INC-2026-0412');
        this.svc.activeSection.set('incidents');
        this.detailTab.set('FACTS');
        break;
      case 3:
        if (inc412) {
          this.svc.selectIncident(inc412.id);
          await this.svc.recordAssessment(inc412.id, {
            expectedVersion: inc412.version,
            pathwayAdapter: 'Pennine Clinical & Operational Pathways (Prototype)',
            pathwayCategory: 'CAT-A1 — Multi-Vehicle RTC Entrapment',
            priorityCode: 'CAT-A1',
            priorityLabel: 'Category A1 — Immediate Life Threat',
            severityRank: 1,
            rationale: 'Demonstrator Step 3: Confirmed trapped driver with chest pain.',
            isOverride: false,
          });
          this.svc.activeSection.set('incidents');
          this.detailTab.set('ALLOCATION');
        }
        break;
      case 4:
        this.svc.selectIncident('INC-2026-0412');
        this.svc.activeSection.set('incidents');
        this.detailTab.set('ALLOCATION');
        break;
      case 5:
        if (inc412) {
          await this.dispatchRecommended(inc412, 'res-amb-41', false);
          this.svc.activeSection.set('incidents');
          this.detailTab.set('DISPATCH');
        }
        break;
      case 6:
        if (active412) {
          await this.svc.updateAssignmentStage(active412.id, 'CREW_ACKNOWLEDGED', 'Step 6: Crew confirmed via MDT');
        } else {
          this.svc.activeSection.set('responder');
        }
        break;
      case 7:
        if (active412) {
          await this.svc.updateAssignmentStage(active412.id, 'EN_ROUTE', 'Step 7: Unit mobile toward M62 J22');
          await this.svc.stepSimulator();
        }
        break;
      case 8:
        if (active412) {
          await this.svc.updateAssignmentStage(active412.id, 'AT_SCENE', 'Step 8: Delayed arrival update buffered', true);
          await this.svc.stepSimulator();
          await this.svc.stepSimulator();
        }
        break;
      case 9:
        await this.svc.requestInterAgency({
          incidentId: 'INC-2026-0412',
          requestedAgency: 'fire',
          requestedCapability: 'RTC_EXTRICATION',
          rationale: 'Step 9: Requesting Fire hydraulic extrication under JESIP shared reference.',
          sharingScope: 'SHARED_JESIP',
        });
        this.svc.activeSection.set('multi_agency');
        break;
      case 10: {
        const amb44 = this.svc.snapshot()?.resources.find((r) => r.id === 'res-amb-44');
        if (active412) {
          await this.svc.updateAssignmentStage(active412.id, 'WITHDRAWN', 'Step 10: Withdrawn through operator review after crew unavailability');
        } else if (amb44) {
          this.svc.activeSection.set('resources');
        }
        break;
      }
      case 11:
        await this.svc.updateHandover('asg-415-1', 'RECORD_HOSPITAL_ARRIVAL');
        await this.svc.updateHandover('asg-415-1', 'CLINICAL_HANDOVER');
        this.svc.activeSection.set('hospitals');
        break;
      case 12:
        await this.svc.updateAssignmentStage('asg-415-1', 'CLEAR', 'Step 12: Crew explicitly confirmed Clear & Make Ready');
        break;
      case 13:
        this.svc.activeSection.set('replay');
        await this.svc.loadIsolatedReplay();
        break;
      case 14:
        this.svc.activeSection.set('reports');
        await this.generateAndPreviewReport('INC-2026-0412');
        break;
    }
  }

  positionAgeSec(res: ResourceUnit): number {
    const now = Date.parse(this.svc.liveClockIso());
    const obs = Date.parse(res.positionObservedAt);
    if (!Number.isFinite(now) || !Number.isFinite(obs)) return 0;
    return Math.max(0, Math.round((now - obs) / 1000));
  }
}
