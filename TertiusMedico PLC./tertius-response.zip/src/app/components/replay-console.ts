import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ControlRoomService } from '../core/control-room.service';

@Component({
  selector: 'app-replay-console',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-4">
      <!-- Isolation Warning Banner -->
      <div class="bg-[#0b1426] text-slate-100 border border-cyan-500/40 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-xs font-mono text-cyan-300 font-semibold">
            REPLAY MODE — STRICTLY ISOLATED FROM LIVE COMMAND INTERFACES
          </div>
          <h2 class="text-lg font-display font-semibold mt-0.5">
            Incident Chronology & Synchronised Map Playback
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">{{ svc.replayNotice() }}</p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <select
            [value]="filterIncidentId()"
            (change)="onFilterIncident($event)"
            class="bg-[#111d35] border border-slate-700 text-slate-100 text-xs px-2.5 py-1.5 rounded focus-ring"
          >
            <option value="">All Incidents</option>
            @for (inc of incidents(); track inc.id) {
              <option [value]="inc.id">{{ inc.id }} — {{ inc.title }}</option>
            }
          </select>

          <button
            type="button"
            (click)="reload()"
            class="px-3 py-1.5 bg-[#111d35] border border-slate-700 text-xs rounded hover:bg-slate-800 flex items-center gap-1 focus-ring"
          >
            <mat-icon class="!text-base !w-4 !h-4">refresh</mat-icon>
            <span>Refresh Replay Stream</span>
          </button>
        </div>
      </div>

      <!-- Playback Controls -->
      <div class="bg-white border border-slate-200 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="step(-1)"
            [disabled]="currentIndex() <= 0"
            class="px-2.5 py-1.5 border border-slate-300 rounded text-xs hover:bg-slate-50 disabled:opacity-40 focus-ring"
          >
            Prev Frame
          </button>
          <button
            type="button"
            (click)="togglePlay()"
            class="px-3.5 py-1.5 bg-slate-900 text-white rounded text-xs font-medium hover:bg-slate-800 flex items-center gap-1.5 focus-ring"
          >
            <mat-icon class="!text-base !w-4 !h-4">{{ playing() ? 'pause' : 'play_arrow' }}</mat-icon>
            <span>{{ playing() ? 'Pause' : 'Play Chronology' }}</span>
          </button>
          <button
            type="button"
            (click)="step(1)"
            [disabled]="currentIndex() >= maxIndex()"
            class="px-2.5 py-1.5 border border-slate-300 rounded text-xs hover:bg-slate-50 disabled:opacity-40 focus-ring"
          >
            Next Frame
          </button>
        </div>

        <div class="flex-1 min-w-[220px] flex items-center gap-3">
          <input
            type="range"
            [min]="0"
            [max]="maxIndex()"
            [value]="currentIndex()"
            (input)="onScrub($event)"
            class="w-full accent-cyan-600"
            aria-label="Replay Timeline Scrubber"
          />
          <span class="text-xs font-mono text-slate-700 whitespace-nowrap">
            Frame {{ frames().length === 0 ? 0 : currentIndex() + 1 }} / {{ frames().length }}
          </span>
        </div>
      </div>

      <!-- Synchronised Map + Chronology Split -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div class="lg:col-span-7 bg-[#091224] border border-slate-800 rounded-lg overflow-hidden">
          <div class="px-3 py-2 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
            <span class="font-mono text-cyan-300">SYNCHRONISED REPLAY MAP (READ-ONLY)</span>
            @if (currentFrame(); as f) {
              <span class="font-mono">{{ f.timestamp }}</span>
            }
          </div>
          <svg viewBox="0 0 1000 640" class="w-full h-[380px] bg-[#070f1e]">
            <path
              d="M 40 310 Q 240 245 360 220 T 700 285 L 960 330"
              fill="none"
              stroke="#334155"
              stroke-width="5"
            />
            @if (currentFrame(); as frame) {
              @if (frame.routeLine) {
                <line
                  [attr.x1]="frame.routeLine.fromX"
                  [attr.y1]="frame.routeLine.fromY"
                  [attr.x2]="frame.routeLine.toX"
                  [attr.y2]="frame.routeLine.toY"
                  stroke="#22d3ee"
                  stroke-width="2.5"
                  stroke-dasharray="6 4"
                />
              }
              @for (m of frame.mapMarkers; track m.id) {
                <g>
                  @if (m.kind === 'INCIDENT') {
                    <circle [attr.cx]="m.x" [attr.cy]="m.y" r="12" fill="#ef4444" stroke="#fff" stroke-width="2" />
                  } @else if (m.kind === 'HOSPITAL') {
                    <rect [attr.x]="m.x - 9" [attr.y]="m.y - 9" width="18" height="18" fill="#065f46" stroke="#34d399" stroke-width="1.5" />
                  } @else {
                    <circle
                      [attr.cx]="m.x"
                      [attr.cy]="m.y"
                      r="8"
                      [attr.fill]="m.stale ? '#f59e0b' : '#22d3ee'"
                      stroke="#091224"
                      stroke-width="1.5"
                    />
                  }
                  <text [attr.x]="m.x + 13" [attr.y]="m.y + 4" fill="#e2e8f0" font-size="10" font-family="JetBrains Mono">
                    {{ m.label }}
                  </text>
                </g>
              }
            }
          </svg>
        </div>

        <div class="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-4 flex flex-col max-h-[430px]">
          <h3 class="text-sm font-display font-semibold text-slate-900 border-b border-slate-200 pb-2">
            Synchronised Event Log
          </h3>
          <div class="flex-1 overflow-y-auto divide-y divide-slate-100 mt-2">
            @for (frame of frames(); track frame.index) {
              <button
                type="button"
                (click)="jumpTo(frame.index)"
                class="w-full text-left py-2.5 px-2 transition-colors focus-ring"
                [class.bg-cyan-50]="frame.index === currentIndex()"
              >
                <div class="flex items-center justify-between text-[11px] font-mono text-slate-500">
                  <span>#{{ frame.index + 1 }} · {{ frame.category }} · {{ frame.incidentId }}</span>
                  <span>{{ frame.actor }}</span>
                </div>
                <div class="text-xs font-semibold text-slate-900 mt-0.5">{{ frame.title }}</div>
                <div class="text-xs text-slate-600 mt-0.5">{{ frame.detail }}</div>
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ReplayConsoleComponent implements OnInit, OnDestroy {
  readonly svc = inject(ControlRoomService);

  readonly filterIncidentId = signal<string>('');
  readonly currentIndex = signal<number>(0);
  readonly playing = signal<boolean>(false);
  private playTimer: ReturnType<typeof setInterval> | null = null;

  readonly incidents = computed(() => this.svc.snapshot()?.incidents ?? []);
  readonly frames = computed(() => this.svc.replayFrames());
  readonly maxIndex = computed(() => Math.max(0, this.frames().length - 1));
  readonly currentFrame = computed(() => this.frames()[this.currentIndex()] ?? null);

  ngOnInit(): void {
    void this.reload();
  }

  ngOnDestroy(): void {
    if (this.playTimer) clearInterval(this.playTimer);
  }

  async reload(): Promise<void> {
    await this.svc.loadIsolatedReplay(this.filterIncidentId() || undefined);
    this.currentIndex.set(0);
  }

  onFilterIncident(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.filterIncidentId.set(val);
    void this.reload();
  }

  step(delta: number): void {
    const next = Math.max(0, Math.min(this.maxIndex(), this.currentIndex() + delta));
    this.currentIndex.set(next);
  }

  jumpTo(idx: number): void {
    this.currentIndex.set(idx);
  }

  onScrub(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.currentIndex.set(val);
  }

  togglePlay(): void {
    if (this.playing()) {
      this.playing.set(false);
      if (this.playTimer) {
        clearInterval(this.playTimer);
        this.playTimer = null;
      }
      return;
    }
    this.playing.set(true);
    this.playTimer = setInterval(() => {
      if (this.currentIndex() >= this.maxIndex()) {
        this.togglePlay();
      } else {
        this.step(1);
      }
    }, 1100);
  }
}
