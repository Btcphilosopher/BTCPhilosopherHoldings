import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ControlRoomService } from '../core/control-room.service';
import type { DispatchStage } from '../../shared/domain';

interface QueuedResponderAction {
  id: string;
  assignmentId: string;
  stage: DispatchStage;
  note: string;
  createdAt: string;
  syncStatus: 'ACCEPTED' | 'PENDING' | 'UNSYNCHRONISED_OFFLINE' | 'REJECTED';
  errorText?: string;
}

@Component({
  selector: 'app-responder-console',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="max-w-5xl mx-auto space-y-4">
      <!-- Responder MDT Header Banner -->
      <div class="bg-[#0b1426] text-slate-100 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <p class="text-xs font-mono text-cyan-300">ANDROID JETPACK COMPOSE MDT · WEB PREVIEW & LIVE ADAPTER</p>
          <h2 class="text-lg font-display font-semibold mt-0.5">
            Focused Responder Unit Interface
          </h2>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <label class="text-xs text-slate-300 flex items-center gap-2">
            <span>Active Unit:</span>
            <select
              [value]="selectedResourceId()"
              (change)="onSelectResource($event)"
              class="bg-[#111d35] border border-slate-700 text-slate-100 text-xs px-2.5 py-1.5 rounded focus-ring"
            >
              @for (res of allResources(); track res.id) {
                <option [value]="res.id">{{ res.callsign }} ({{ res.service.toUpperCase() }})</option>
              }
            </select>
          </label>

          <button
            type="button"
            (click)="toggleDrivingMode()"
            class="px-3 py-1.5 text-xs font-medium border rounded flex items-center gap-1.5 focus-ring"
            [class.bg-amber-500]="drivingInMotion()"
            [class.text-slate-950]="drivingInMotion()"
            [class.border-amber-400]="drivingInMotion()"
            [class.bg-[#111d35]]="!drivingInMotion()"
            [class.text-slate-200]="!drivingInMotion()"
            [class.border-slate-700]="!drivingInMotion()"
          >
            <mat-icon class="!text-base !w-4 !h-4">directions_car</mat-icon>
            <span>{{ drivingInMotion() ? 'Motion Lock ACTIVE' : 'Simulate Driving Motion' }}</span>
          </button>

          <button
            type="button"
            (click)="toggleHandsetOffline()"
            class="px-3 py-1.5 text-xs font-medium border rounded flex items-center gap-1.5 focus-ring"
            [class.bg-red-600]="handsetOffline()"
            [class.text-white]="handsetOffline()"
            [class.border-red-500]="handsetOffline()"
            [class.bg-[#111d35]]="!handsetOffline()"
            [class.text-slate-200]="!handsetOffline()"
            [class.border-slate-700]="!handsetOffline()"
          >
            <mat-icon class="!text-base !w-4 !h-4">wifi_off</mat-icon>
            <span>{{ handsetOffline() ? 'Handset Offline (Buffering)' : 'Simulate Handset Offline' }}</span>
          </button>
        </div>
      </div>

      @if (handsetOffline()) {
        <div class="bg-amber-50 border border-amber-400 text-amber-950 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-sm">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-700">cloud_off</mat-icon>
            <span>
              <strong>HANDSET OFFLINE:</strong> Showing cached assignment only. Status updates are queued as UNSYNCHRONISED and will reconcile against server versions upon reconnection.
            </span>
          </div>
          <button
            type="button"
            (click)="reconnectAndReconcile()"
            class="px-3 py-1.5 bg-slate-900 text-white text-xs font-medium rounded hover:bg-slate-800 focus-ring"
          >
            Reconnect & Reconcile Queue
          </button>
        </div>
      }

      @if (drivingInMotion()) {
        <div class="bg-[#0b1426] border-2 border-amber-400 text-slate-100 rounded-lg p-8 text-center space-y-3">
          <mat-icon class="!text-4xl !w-10 !h-10 text-amber-400 mx-auto">warning</mat-icon>
          <h3 class="text-xl font-display font-semibold text-amber-300">
            VEHICLE IN MOTION — INTERACTION LOCKED
          </h3>
          <p class="text-sm text-slate-300 max-w-lg mx-auto">
            Responder touchscreen actions are suppressed while driving to comply with road-safety rules. Use hands-free Airwave radio for urgent status updates, or stop safely to unlock MDT controls.
          </p>
          <div class="pt-2 text-xs font-mono text-cyan-300">
            Active Assignment: {{ activeAssignment()?.incidentId ?? 'NONE' }} · Stage: {{ activeAssignment()?.stage ?? 'AVAILABLE' }}
          </div>
        </div>
      } @else {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <!-- Left: Assignment Card -->
          <div class="lg:col-span-7 bg-white border border-slate-200 rounded-lg p-5 space-y-4">
            @if (activeAssignment(); as asg) {
              <div class="flex flex-wrap items-start justify-between gap-2 border-b border-slate-200 pb-3">
                <div>
                  <div class="text-xs font-mono text-slate-500">
                    ASSIGNMENT {{ asg.id }} · CMD {{ asg.commandId.slice(0, 8) }}
                  </div>
                  <h3 class="text-lg font-display font-semibold text-slate-900 mt-0.5">
                    {{ activeIncident()?.id }} — {{ activeIncident()?.title }}
                  </h3>
                </div>
                <span
                  class="px-2.5 py-1 text-xs font-mono font-semibold border"
                  [class.bg-red-50]="activeIncident()?.currentSeverityRank === 1"
                  [class.text-red-700]="activeIncident()?.currentSeverityRank === 1"
                  [class.border-red-300]="activeIncident()?.currentSeverityRank === 1"
                  [class.bg-cyan-50]="activeIncident()?.currentSeverityRank !== 1"
                  [class.text-cyan-900]="activeIncident()?.currentSeverityRank !== 1"
                  [class.border-cyan-300]="activeIncident()?.currentSeverityRank !== 1"
                >
                  {{ activeIncident()?.currentPriorityCode }} · {{ asg.stage }}
                </span>
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <div class="p-3 bg-slate-50 border border-slate-200 rounded">
                  <div class="text-xs font-medium text-slate-500">Location & Confidence</div>
                  <div class="font-medium text-slate-900 mt-1">{{ activeIncident()?.reportedLocationText }}</div>
                  <div class="text-xs font-mono text-slate-600 mt-1">
                    {{ activeIncident()?.verifiedAddress ?? 'NO VERIFIED ADDRESS — USE GRID/COORDS' }}
                  </div>
                  <div class="text-xs font-mono text-amber-700 mt-1">
                    {{ activeIncident()?.locationConfidence }} (+/-{{ activeIncident()?.uncertaintyRadiusMeters }}m)
                  </div>
                </div>

                <div class="p-3 bg-slate-50 border border-slate-200 rounded">
                  <div class="text-xs font-medium text-slate-500">Access Notes & Known Hazards</div>
                  <div class="text-slate-900 mt-1">{{ activeIncident()?.accessInformation }}</div>
                  <div class="mt-2 space-y-1">
                    @for (haz of activeIncident()?.knownHazards ?? []; track haz) {
                      <div class="text-xs font-mono text-red-700 flex items-center gap-1">
                        <mat-icon class="!text-sm !w-3.5 !h-3.5">warning</mat-icon>
                        <span>HAZARD: {{ haz }}</span>
                      </div>
                    }
                  </div>
                </div>
              </div>

              <!-- Crew Status Actions -->
              <div class="space-y-2 pt-1">
                <div class="text-xs font-semibold text-slate-700">Responder Status Updates</div>
                <div class="flex flex-wrap gap-2">
                  <button
                    type="button"
                    (click)="sendStatus('CREW_ACKNOWLEDGED', 'Crew acknowledged assignment on MDT')"
                    class="px-3 py-2 bg-cyan-600 text-white text-xs font-medium rounded hover:bg-cyan-700 flex items-center gap-1.5 focus-ring"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">check_circle</mat-icon>
                    <span>Acknowledge</span>
                  </button>
                  <button
                    type="button"
                    (click)="sendStatus('EN_ROUTE', 'Unit mobile / en route to scene')"
                    class="px-3 py-2 bg-slate-900 text-white text-xs font-medium rounded hover:bg-slate-800 flex items-center gap-1.5 focus-ring"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">local_shipping</mat-icon>
                    <span>En Route</span>
                  </button>
                  <button
                    type="button"
                    (click)="sendStatus('AT_SCENE', 'Unit arrived at incident scene')"
                    class="px-3 py-2 bg-slate-900 text-white text-xs font-medium rounded hover:bg-slate-800 flex items-center gap-1.5 focus-ring"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">place</mat-icon>
                    <span>At Scene</span>
                  </button>
                  <button
                    type="button"
                    (click)="sendStatus('REJECTED', 'Crew unable to respond — vehicle/crew issue')"
                    class="px-3 py-2 bg-red-600 text-white text-xs font-medium rounded hover:bg-red-700 flex items-center gap-1.5 focus-ring"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">cancel</mat-icon>
                    <span>Reject Assignment</span>
                  </button>
                  <button
                    type="button"
                    (click)="sendStatus('CLEAR', 'Crew explicitly clear and available for next task')"
                    class="px-3 py-2 bg-emerald-700 text-white text-xs font-medium rounded hover:bg-emerald-800 flex items-center gap-1.5 focus-ring"
                  >
                    <mat-icon class="!text-base !w-4 !h-4">task_alt</mat-icon>
                    <span>Explicit Clear</span>
                  </button>
                </div>
              </div>

              <!-- Support Request & Structured Handover -->
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                <div class="space-y-2">
                  <div class="text-xs font-semibold text-slate-700">Request Backup / Multi-Agency Support</div>
                  <div class="flex gap-2">
                    <button
                      type="button"
                      (click)="requestBackup('fire', 'RTC Extrication / Hydraulic Rescue')"
                      class="px-2.5 py-1.5 border border-slate-300 text-xs rounded hover:bg-slate-50 focus-ring"
                    >
                      Request Fire Support
                    </button>
                    <button
                      type="button"
                      (click)="requestBackup('police', 'Fast-Road Traffic Cordon')"
                      class="px-2.5 py-1.5 border border-slate-300 text-xs rounded hover:bg-slate-50 focus-ring"
                    >
                      Request Police Support
                    </button>
                  </div>
                </div>

                @if (asg.service === 'ambulance') {
                  <div class="space-y-2">
                    <div class="text-xs font-semibold text-slate-700">Hospital Arrival & Handover</div>
                    <div class="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        (click)="handoverAction('RECORD_HOSPITAL_ARRIVAL')"
                        class="px-2.5 py-1.5 border border-slate-300 text-xs rounded hover:bg-slate-50 focus-ring"
                      >
                        Arrived Hospital
                      </button>
                      <button
                        type="button"
                        (click)="handoverAction('CLINICAL_HANDOVER')"
                        class="px-2.5 py-1.5 border border-slate-300 text-xs rounded hover:bg-slate-50 focus-ring"
                      >
                        Handover Complete
                      </button>
                    </div>
                  </div>
                }
              </div>
            } @else {
              <div class="py-10 text-center space-y-2">
                <mat-icon class="!text-3xl !w-8 !h-8 text-slate-400">assignment_late</mat-icon>
                <p class="text-sm font-medium text-slate-700">
                  No active assignment for {{ selectedResource()?.callsign }}
                </p>
                <p class="text-xs text-slate-500">
                  Administrative tasks are excluded from the active response view. Dispatch this unit from the Incidents workspace to test responder mobilisation.
                </p>
              </div>
            }
          </div>

          <!-- Right: Update Synchronisation Queue & Lock-Screen Privacy Preview -->
          <div class="lg:col-span-5 space-y-4">
            <div class="bg-white border border-slate-200 rounded-lg p-4 space-y-3">
              <div class="flex items-center justify-between">
                <h4 class="text-sm font-display font-semibold text-slate-900">
                  MDT Action Synchronisation Queue
                </h4>
                <span class="text-xs font-mono text-slate-500">{{ queue().length }} item(s)</span>
              </div>

              @if (queue().length === 0) {
                <p class="text-xs text-slate-500 py-3">
                  No actions submitted in this session yet. Actions show ACCEPTED, PENDING, REJECTED, or UNSYNCHRONISED_OFFLINE state.
                </p>
              } @else {
                <div class="space-y-2 max-h-64 overflow-y-auto">
                  @for (item of queue(); track item.id) {
                    <div class="p-2.5 border border-slate-200 rounded text-xs space-y-1">
                      <div class="flex items-center justify-between font-mono">
                        <span class="font-semibold text-slate-900">{{ item.stage }}</span>
                        <span
                          class="px-1.5 py-0.5 font-semibold"
                          [class.bg-emerald-50]="item.syncStatus === 'ACCEPTED'"
                          [class.text-emerald-800]="item.syncStatus === 'ACCEPTED'"
                          [class.bg-amber-50]="item.syncStatus === 'UNSYNCHRONISED_OFFLINE' || item.syncStatus === 'PENDING'"
                          [class.text-amber-800]="item.syncStatus === 'UNSYNCHRONISED_OFFLINE' || item.syncStatus === 'PENDING'"
                          [class.bg-red-50]="item.syncStatus === 'REJECTED'"
                          [class.text-red-700]="item.syncStatus === 'REJECTED'"
                        >
                          {{ item.syncStatus }}
                        </span>
                      </div>
                      <div class="text-slate-600">{{ item.note }}</div>
                      @if (item.errorText) {
                        <div class="text-red-700 font-mono">{{ item.errorText }}</div>
                      }
                    </div>
                  }
                </div>
              }
            </div>

            <div class="bg-[#0b1426] text-slate-100 border border-slate-800 rounded-lg p-4 space-y-2">
              <div class="text-xs font-mono text-cyan-300">LOCK-SCREEN NOTIFICATION PRIVACY</div>
              <p class="text-xs text-slate-300">
                Ordinary device lock-screen alerts omit patient names, medical codes, and police intelligence:
              </p>
              <div class="p-3 bg-[#111d35] border border-slate-700 rounded text-xs font-mono text-slate-200">
                TERTIUS MDT: New assignment alert for {{ selectedResource()?.callsign }}. Authenticate with biometric/PIN to view details.
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class ResponderConsoleComponent {
  private readonly svc = inject(ControlRoomService);

  readonly drivingInMotion = signal(false);
  readonly handsetOffline = signal(false);
  readonly manualResourceId = signal<string | null>(null);
  readonly queue = signal<QueuedResponderAction[]>([]);

  readonly allResources = computed(() => this.svc.snapshot()?.resources ?? []);

  readonly selectedResourceId = computed(() => {
    const manual = this.manualResourceId();
    if (manual) return manual;
    return this.svc.assignedResourceId() ?? 'res-amb-41';
  });

  readonly selectedResource = computed(
    () => this.allResources().find((r) => r.id === this.selectedResourceId()) ?? null,
  );

  readonly activeAssignment = computed(() => {
    const res = this.selectedResource();
    if (!res?.currentAssignmentId) return null;
    return (
      this.svc.snapshot()?.assignments.find((a) => a.id === res.currentAssignmentId) ?? null
    );
  });

  readonly activeIncident = computed(() => {
    const asg = this.activeAssignment();
    if (!asg) return null;
    return this.svc.snapshot()?.incidents.find((i) => i.id === asg.incidentId) ?? null;
  });

  onSelectResource(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.manualResourceId.set(target.value);
  }

  toggleDrivingMode(): void {
    this.drivingInMotion.update((v) => !v);
  }

  toggleHandsetOffline(): void {
    this.handsetOffline.update((v) => !v);
  }

  async sendStatus(stage: DispatchStage, note: string): Promise<void> {
    const asg = this.activeAssignment();
    if (!asg) return;

    const entryId = `q-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`;
    if (this.handsetOffline()) {
      this.queue.update((q) => [
        {
          id: entryId,
          assignmentId: asg.id,
          stage,
          note,
          createdAt: new Date().toISOString(),
          syncStatus: 'UNSYNCHRONISED_OFFLINE',
        },
        ...q,
      ]);
      return;
    }

    this.queue.update((q) => [
      {
        id: entryId,
        assignmentId: asg.id,
        stage,
        note,
        createdAt: new Date().toISOString(),
        syncStatus: 'PENDING',
      },
      ...q,
    ]);

    const ok = await this.svc.updateAssignmentStage(asg.id, stage, note);
    this.queue.update((q) =>
      q.map((item) =>
        item.id === entryId
          ? {
              ...item,
              syncStatus: ok ? 'ACCEPTED' : 'REJECTED',
              errorText: ok ? undefined : this.svc.lastError() ?? 'Rejected by server',
            }
          : item,
      ),
    );
  }

  async reconnectAndReconcile(): Promise<void> {
    this.handsetOffline.set(false);
    // Reconcile server state BEFORE submitting consequential queued actions
    await this.svc.refreshState();
    const pending = this.queue().filter((q) => q.syncStatus === 'UNSYNCHRONISED_OFFLINE');
    for (const item of [...pending].reverse()) {
      const ok = await this.svc.updateAssignmentStage(
        item.assignmentId,
        item.stage,
        `[RECONCILED AFTER OFFLINE] ${item.note}`,
      );
      this.queue.update((q) =>
        q.map((entry) =>
          entry.id === item.id
            ? {
                ...entry,
                syncStatus: ok ? 'ACCEPTED' : 'REJECTED',
                errorText: ok ? undefined : 'Conflict during reconciliation',
              }
            : entry,
        ),
      );
    }
  }

  async requestBackup(agency: 'fire' | 'police', capability: string): Promise<void> {
    const inc = this.activeIncident();
    if (!inc) return;
    await this.svc.requestInterAgency({
      incidentId: inc.id,
      requestedAgency: agency,
      requestedCapability: capability,
      rationale: `Requested by responder ${this.selectedResource()?.callsign} at scene.`,
      sharingScope: 'SHARED_JESIP',
    });
  }

  async handoverAction(action: 'RECORD_HOSPITAL_ARRIVAL' | 'CLINICAL_HANDOVER'): Promise<void> {
    const asg = this.activeAssignment();
    if (!asg) return;
    await this.svc.updateHandover(asg.id, action);
  }
}
