import {
  ChangeDetectionStrategy,
  Component,
  computed,
  input,
  output,
  signal,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import type {
  AllocationRecommendation,
  DispatchAssignment,
  HospitalFacility,
  Incident,
  MapHazardOverlay,
  ResourceUnit,
  ServiceBoundary,
} from '../../shared/domain';

@Component({
  selector: 'app-operational-map',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="flex flex-col h-full bg-[#091224] text-slate-100 border border-slate-800 rounded-lg overflow-hidden">
      <!-- Map Toolbar -->
      <div class="flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-[#0d1930] border-b border-slate-800 text-xs">
        <div class="flex items-center gap-3">
          <span class="font-display font-semibold text-slate-100 whitespace-nowrap">
            Pennine Operational Map (Local Adapter)
          </span>
          @if (mapTilesMissing()) {
            <span class="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono font-medium">
              DEGRADED: TILES MISSING · VECTOR FALLBACK
            </span>
          }
        </div>

        <div class="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            (click)="toggleLayer('boundaries')"
            class="px-2 py-1 border text-xs transition-colors focus-ring whitespace-nowrap"
            [class.bg-cyan-500/20]="showBoundaries()"
            [class.border-cyan-400]="showBoundaries()"
            [class.text-cyan-200]="showBoundaries()"
            [class.border-slate-700]="!showBoundaries()"
            [class.text-slate-400]="!showBoundaries()"
          >
            Boundaries
          </button>
          <button
            type="button"
            (click)="toggleLayer('hazards')"
            class="px-2 py-1 border text-xs transition-colors focus-ring whitespace-nowrap"
            [class.bg-amber-500/20]="showHazards()"
            [class.border-amber-400]="showHazards()"
            [class.text-amber-200]="showHazards()"
            [class.border-slate-700]="!showHazards()"
            [class.text-slate-400]="!showHazards()"
          >
            Hazards
          </button>
          <button
            type="button"
            (click)="toggleLayer('routes')"
            class="px-2 py-1 border text-xs transition-colors focus-ring whitespace-nowrap"
            [class.bg-cyan-500/20]="showRoutes()"
            [class.border-cyan-400]="showRoutes()"
            [class.text-cyan-200]="showRoutes()"
            [class.border-slate-700]="!showRoutes()"
            [class.text-slate-400]="!showRoutes()"
          >
            Est. Routes
          </button>
          <button
            type="button"
            (click)="toggleLayer('hospitals')"
            class="px-2 py-1 border text-xs transition-colors focus-ring whitespace-nowrap"
            [class.bg-emerald-500/20]="showHospitals()"
            [class.border-emerald-400]="showHospitals()"
            [class.text-emerald-200]="showHospitals()"
            [class.border-slate-700]="!showHospitals()"
            [class.text-slate-400]="!showHospitals()"
          >
            Hospitals
          </button>
        </div>
      </div>

      <!-- SVG Vector Map Viewport -->
      <div class="relative flex-1 min-h-[340px] bg-[#070f1e] overflow-hidden">
        <svg
          viewBox="0 0 1000 640"
          class="w-full h-full select-none"
          role="img"
          aria-label="Pennine Emergency Sector Operational Vector Map"
        >
          <!-- Coordinate Grid -->
          <defs>
            <pattern id="pennineGrid" width="80" height="80" patternUnits="userSpaceOnUse">
              <path d="M 80 0 L 0 0 0 80" fill="none" stroke="rgba(148, 163, 184, 0.1)" stroke-width="1" />
            </pattern>
          </defs>
          <rect width="1000" height="640" fill="url(#pennineGrid)" />

          <!-- Synthetic Pennine Topography & Corridors (hidden if mapTilesMissing simulates base layer outage) -->
          @if (!mapTilesMissing()) {
            <g>
              <!-- Moorland contour hint -->
              <path
                d="M 80 120 Q 250 70 420 150 T 760 110 L 920 160 L 920 520 Q 650 560 400 500 T 90 540 Z"
                fill="rgba(30, 41, 59, 0.28)"
                stroke="rgba(71, 85, 105, 0.35)"
                stroke-width="1"
              />
              <!-- M62 Motorway Corridor -->
              <path
                d="M 40 310 Q 240 245 360 220 T 700 285 L 960 330"
                fill="none"
                stroke="#334155"
                stroke-width="6"
              />
              <path
                d="M 40 310 Q 240 245 360 220 T 700 285 L 960 330"
                fill="none"
                stroke="#64748b"
                stroke-width="1.5"
                stroke-dasharray="10 6"
              />
              <text x="155" y="255" fill="#94a3b8" font-size="11" font-family="JetBrains Mono">M62 CORRIDOR</text>

              <!-- A629 / Calder Valley Axis -->
              <path d="M 550 55 L 575 180 L 670 315 L 690 560" fill="none" stroke="#334155" stroke-width="4" />
              <text x="585" y="100" fill="#94a3b8" font-size="10" font-family="JetBrains Mono">A629 HALIFAX–HUDDERSFIELD</text>

              <!-- Town Labels -->
              <text x="678" y="342" fill="#cbd5e1" font-size="12" font-weight="600">Huddersfield</text>
              <text x="588" y="145" fill="#cbd5e1" font-size="12" font-weight="600">Halifax</text>
              <text x="200" y="495" fill="#cbd5e1" font-size="11">Saddleworth Moor</text>
              <text x="515" y="425" fill="#cbd5e1" font-size="11">Slaithwaite</text>
            </g>
          }

          <!-- Service Boundaries -->
          @if (showBoundaries()) {
            @for (bnd of boundaries(); track bnd.id) {
              <g>
                <polygon
                  [attr.points]="bnd.polygonPoints"
                  fill="none"
                  [attr.stroke]="boundaryColor(bnd.agency)"
                  stroke-width="1.5"
                  stroke-dasharray="6 5"
                />
                <text
                  [attr.x]="bnd.labelPoint.x"
                  [attr.y]="bnd.labelPoint.y"
                  [attr.fill]="boundaryColor(bnd.agency)"
                  font-size="10"
                  font-family="JetBrains Mono"
                >
                  {{ bnd.name }}
                </text>
              </g>
            }
          }

          <!-- Map Hazards -->
          @if (showHazards()) {
            @for (haz of hazards(); track haz.id) {
              <g>
                <circle
                  [attr.cx]="haz.coordinates.x"
                  [attr.cy]="haz.coordinates.y"
                  [attr.r]="haz.severity === 'CRITICAL' ? 44 : 26"
                  [attr.fill]="haz.severity === 'CRITICAL' ? 'rgba(239, 68, 68, 0.12)' : 'rgba(245, 158, 11, 0.14)'"
                  [attr.stroke]="haz.severity === 'CRITICAL' ? '#ef4444' : '#f59e0b'"
                  stroke-width="1.5"
                  stroke-dasharray="4 3"
                />
                <text
                  [attr.x]="haz.coordinates.x"
                  [attr.y]="haz.coordinates.y - (haz.severity === 'CRITICAL' ? 48 : 30)"
                  text-anchor="middle"
                  [attr.fill]="haz.severity === 'CRITICAL' ? '#fca5a5' : '#fcd34d'"
                  font-size="10"
                  font-family="JetBrains Mono"
                >
                  {{ haz.severity }}: {{ haz.title }}
                </text>
              </g>
            }
          }

          <!-- Cyan Estimated Route Vectors (Planning Estimates Only) -->
          @if (showRoutes() && selectedIncident()) {
            @for (line of routeLines(); track line.id) {
              <g>
                <line
                  [attr.x1]="line.fromX"
                  [attr.y1]="line.fromY"
                  [attr.x2]="line.toX"
                  [attr.y2]="line.toY"
                  stroke="#22d3ee"
                  [attr.stroke-width]="line.active ? 2.5 : 1.5"
                  [attr.stroke-dasharray]="line.active ? 'none' : '5 5'"
                />
                <rect
                  [attr.x]="(line.fromX + line.toX) / 2 - 26"
                  [attr.y]="(line.fromY + line.toY) / 2 - 9"
                  width="52"
                  height="18"
                  rx="2"
                  fill="#0b1426"
                  stroke="#22d3ee"
                  stroke-width="1"
                />
                <text
                  [attr.x]="(line.fromX + line.toX) / 2"
                  [attr.y]="(line.fromY + line.toY) / 2 + 4"
                  text-anchor="middle"
                  fill="#67e8f9"
                  font-size="10"
                  font-family="JetBrains Mono"
                >
                  ~{{ line.minutes }}m
                </text>
              </g>
            }
          }

          <!-- Receiving Facilities / Hospitals -->
          @if (showHospitals()) {
            @for (hosp of hospitals(); track hosp.id) {
              <g>
                <rect
                  [attr.x]="hosp.coordinates.x - 11"
                  [attr.y]="hosp.coordinates.y - 11"
                  width="22"
                  height="22"
                  rx="3"
                  fill="#064e3b"
                  stroke="#34d399"
                  stroke-width="1.5"
                />
                <text
                  [attr.x]="hosp.coordinates.x"
                  [attr.y]="hosp.coordinates.y + 4"
                  text-anchor="middle"
                  fill="#ecfdf5"
                  font-size="12"
                  font-weight="700"
                >
                  H
                </text>
                <text
                  [attr.x]="hosp.coordinates.x + 15"
                  [attr.y]="hosp.coordinates.y + 4"
                  fill="#a7f3d0"
                  font-size="10"
                  font-family="Public Sans"
                >
                  {{ hosp.name }} ({{ hosp.edCapacityStatus }})
                </text>
              </g>
            }
          }

          <!-- Incidents & Uncertainty Circles -->
          @for (inc of incidents(); track inc.id) {
            <g
              class="cursor-pointer"
              (click)="incidentSelected.emit(inc.id)"
            >
              <!-- Location uncertainty halo -->
              @if (inc.locationConfidence !== 'VERIFIED_EXACT') {
                <circle
                  [attr.cx]="inc.coordinates.x"
                  [attr.cy]="inc.coordinates.y"
                  [attr.r]="uncertaintyRadiusPx(inc.uncertaintyRadiusMeters)"
                  fill="rgba(245, 158, 11, 0.12)"
                  stroke="#f59e0b"
                  stroke-width="1.5"
                  stroke-dasharray="5 4"
                />
              }

              <!-- Conflicting location markers for selected incident -->
              @if (inc.id === selectedIncident()?.id) {
                @for (conf of inc.conflictingLocations; track conf.id; let idx = $index) {
                  <g>
                    <line
                      [attr.x1]="inc.coordinates.x"
                      [attr.y1]="inc.coordinates.y"
                      [attr.x2]="conf.coordinates.x"
                      [attr.y2]="conf.coordinates.y"
                      stroke="#f59e0b"
                      stroke-width="1"
                      stroke-dasharray="3 3"
                    />
                    <circle
                      [attr.cx]="conf.coordinates.x"
                      [attr.cy]="conf.coordinates.y"
                      r="6"
                      fill="#78350f"
                      stroke="#fbbf24"
                      stroke-width="1.5"
                    />
                    <text
                      [attr.x]="conf.coordinates.x + 9"
                      [attr.y]="conf.coordinates.y + 3"
                      fill="#fde68a"
                      font-size="9"
                      font-family="JetBrains Mono"
                    >
                      RPT-{{ idx + 1 }}
                    </text>
                  </g>
                }
              }

              <!-- Selected Incident Outer Focus Ring -->
              @if (inc.id === selectedIncident()?.id) {
                <circle
                  [attr.cx]="inc.coordinates.x"
                  [attr.cy]="inc.coordinates.y"
                  r="17"
                  fill="none"
                  stroke="#f8fafc"
                  stroke-width="2"
                />
              }

              <!-- Incident Diamond Marker -->
              <polygon
                [attr.points]="diamondPoints(inc.coordinates.x, inc.coordinates.y, 11)"
                [attr.fill]="incidentFill(inc)"
                stroke="#ffffff"
                stroke-width="1.5"
              />
              <text
                [attr.x]="inc.coordinates.x + 15"
                [attr.y]="inc.coordinates.y - 4"
                fill="#f8fafc"
                font-size="11"
                font-weight="600"
                font-family="JetBrains Mono"
              >
                {{ inc.id }}
              </text>
              <text
                [attr.x]="inc.coordinates.x + 15"
                [attr.y]="inc.coordinates.y + 9"
                [attr.fill]="inc.currentSeverityRank === 1 ? '#fca5a5' : '#fde68a'"
                font-size="9.5"
                font-family="JetBrains Mono"
              >
                {{ inc.currentPriorityCode }} · {{ inc.locationConfidence === 'VERIFIED_EXACT' ? 'VERIFIED' : 'UNCERTAIN' }}
              </text>
            </g>
          }

          <!-- Resources (Cyan active markers, Amber dashed ring if STALE) -->
          @for (res of resources(); track res.id) {
            <g>
              @if (isStale(res)) {
                <circle
                  [attr.cx]="res.observedPosition.x"
                  [attr.cy]="res.observedPosition.y"
                  r="16"
                  fill="rgba(245, 158, 11, 0.14)"
                  stroke="#f59e0b"
                  stroke-width="1.5"
                  stroke-dasharray="3 2"
                />
              }
              <circle
                [attr.cx]="res.observedPosition.x"
                [attr.cy]="res.observedPosition.y"
                r="10"
                [attr.fill]="resourceFill(res)"
                [attr.stroke]="isStale(res) ? '#fbbf24' : '#22d3ee'"
                stroke-width="2"
              />
              <text
                [attr.x]="res.observedPosition.x"
                [attr.y]="res.observedPosition.y + 3.5"
                text-anchor="middle"
                fill="#0b1426"
                font-size="10"
                font-weight="700"
                font-family="JetBrains Mono"
              >
                {{ serviceInitial(res.service) }}
              </text>
              <text
                [attr.x]="res.observedPosition.x + 13"
                [attr.y]="res.observedPosition.y - 2"
                [attr.fill]="isStale(res) ? '#fcd34d' : '#67e8f9'"
                font-size="10"
                font-family="JetBrains Mono"
              >
                {{ res.callsign }}
              </text>
              <text
                [attr.x]="res.observedPosition.x + 13"
                [attr.y]="res.observedPosition.y + 9"
                [attr.fill]="isStale(res) ? '#f59e0b' : '#94a3b8'"
                font-size="9"
                font-family="JetBrains Mono"
              >
                {{ positionAgeLabel(res) }}
              </text>
            </g>
          }
        </svg>

        <!-- Map Legend Overlay -->
        <div class="absolute bottom-2 left-2 right-2 flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-[#091224]/90 border border-slate-700/80 text-[11px] text-slate-300">
          <div class="flex flex-wrap items-center gap-4">
            <span class="font-mono text-cyan-300">CYAN: Resource / Planning Route</span>
            <span class="font-mono text-amber-300">AMBER: Uncertainty / Stale GPS (&gt;180s)</span>
            <span class="font-mono text-red-400">RED: Critical Priority / Hazard</span>
            <span class="font-mono text-emerald-300">H: Authorised Facility</span>
          </div>
          <span class="text-slate-400">
            Planning telemetry only — not emergency turn-by-turn driving instructions.
          </span>
        </div>
      </div>
    </div>
  `,
})
export class OperationalMapComponent {
  readonly incidents = input.required<Incident[]>();
  readonly resources = input.required<ResourceUnit[]>();
  readonly assignments = input.required<DispatchAssignment[]>();
  readonly hospitals = input.required<HospitalFacility[]>();
  readonly hazards = input.required<MapHazardOverlay[]>();
  readonly boundaries = input.required<ServiceBoundary[]>();
  readonly selectedIncident = input<Incident | null>(null);
  readonly recommendations = input<AllocationRecommendation[]>([]);
  readonly mapTilesMissing = input<boolean>(false);
  readonly nowIso = input<string>(new Date().toISOString());

  readonly incidentSelected = output<string>();

  readonly showBoundaries = signal(true);
  readonly showHazards = signal(true);
  readonly showRoutes = signal(true);
  readonly showHospitals = signal(true);

  readonly routeLines = computed(() => {
    const inc = this.selectedIncident();
    if (!inc) return [];
    const lines: {
      id: string;
      fromX: number;
      fromY: number;
      toX: number;
      toY: number;
      minutes: number;
      active: boolean;
    }[] = [];

    const activeAsgs = this.assignments().filter(
      (a) =>
        a.incidentId === inc.id &&
        !['CLEAR', 'REJECTED', 'WITHDRAWN', 'CANCELLED'].includes(a.stage),
    );
    for (const asg of activeAsgs) {
      const res = this.resources().find((r) => r.id === asg.resourceId);
      if (res) {
        lines.push({
          id: `asg-${asg.id}`,
          fromX: res.observedPosition.x,
          fromY: res.observedPosition.y,
          toX: inc.coordinates.x,
          toY: inc.coordinates.y,
          minutes: asg.routeEstimateMinutes,
          active: true,
        });
      }
    }

    // Also show top 2 eligible advisory recommendations as dashed cyan planning lines
    const topRecs = this.recommendations().filter((r) => r.eligible).slice(0, 2);
    for (const rec of topRecs) {
      const res = this.resources().find((r) => r.id === rec.resourceId);
      if (res && !lines.some((l) => l.fromX === res.observedPosition.x && l.fromY === res.observedPosition.y)) {
        lines.push({
          id: `rec-${rec.resourceId}`,
          fromX: res.observedPosition.x,
          fromY: res.observedPosition.y,
          toX: inc.coordinates.x,
          toY: inc.coordinates.y,
          minutes: rec.estimatedTravelMinutes,
          active: false,
        });
      }
    }
    return lines;
  });

  toggleLayer(layer: 'boundaries' | 'hazards' | 'routes' | 'hospitals'): void {
    if (layer === 'boundaries') this.showBoundaries.update((v) => !v);
    if (layer === 'hazards') this.showHazards.update((v) => !v);
    if (layer === 'routes') this.showRoutes.update((v) => !v);
    if (layer === 'hospitals') this.showHospitals.update((v) => !v);
  }

  boundaryColor(agency: string): string {
    if (agency === 'ambulance') return 'rgba(34, 211, 238, 0.35)';
    if (agency === 'fire') return 'rgba(245, 158, 11, 0.35)';
    return 'rgba(148, 163, 184, 0.35)';
  }

  uncertaintyRadiusPx(meters: number): number {
    return Math.min(72, Math.max(18, Math.round(meters / 28)));
  }

  diamondPoints(x: number, y: number, r: number): string {
    return `${x},${y - r} ${x + r},${y} ${x},${y + r} ${x - r},${y}`;
  }

  incidentFill(inc: Incident): string {
    if (inc.currentSeverityRank === 1) return '#ef4444';
    if (inc.currentSeverityRank === 2 || inc.assessmentStatus === 'UNASSESSED') return '#f59e0b';
    return '#22d3ee';
  }

  resourceFill(res: ResourceUnit): string {
    if (res.vehicleAvailability !== 'SERVICEABLE' || res.dispatchAuthorisation === 'PROHIBITED') {
      return '#94a3b8';
    }
    if (res.currentAssignmentId) return '#38bdf8';
    return '#22d3ee';
  }

  serviceInitial(service: string): string {
    if (service === 'ambulance') return 'A';
    if (service === 'fire') return 'F';
    return 'P';
  }

  positionAgeSeconds(res: ResourceUnit): number {
    const nowMs = Date.parse(this.nowIso());
    const obsMs = Date.parse(res.positionObservedAt);
    if (!Number.isFinite(nowMs) || !Number.isFinite(obsMs)) return 0;
    return Math.max(0, Math.round((nowMs - obsMs) / 1000));
  }

  isStale(res: ResourceUnit): boolean {
    return this.positionAgeSeconds(res) > 180;
  }

  positionAgeLabel(res: ResourceUnit): string {
    const age = this.positionAgeSeconds(res);
    if (age > 300) return `STALE ${age}s (HALTED)`;
    if (age > 180) return `STALE ${age}s`;
    return `${age}s · ${res.currentAssignmentId ? 'BUSY' : res.crewReadiness}`;
  }
}
