import { isPlatformBrowser } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import type {
  AgencyCode,
  AllocationRecommendation,
  AuthSessionUser,
  CommunicationRecord,
  ControlRoomSnapshot,
  DispatchAssignment,
  DispatchStage,
  DuplicateReviewStatus,
  GeoPoint,
  LocationConfidence,
  ReplayFrame,
  ResilienceFlags,
  ResourceUnit,
  ServiceType,
  SharingScope,
} from '../../shared/domain';

export type NavSection =
  | 'overview'
  | 'incidents'
  | 'dispatch'
  | 'resources'
  | 'communications'
  | 'hospitals'
  | 'multi_agency'
  | 'replay'
  | 'reports'
  | 'administration'
  | 'responder';

export interface OperatorDirectorySummary {
  id: string;
  name: string;
  badgeNumber: string;
  role: AuthSessionUser['role'];
  agency: AgencyCode;
  assignedResourceId?: string;
}

@Injectable({ providedIn: 'root' })
export class ControlRoomService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);

  private ws: WebSocket | null = null;
  private clockTimer: ReturnType<typeof setInterval> | null = null;

  // Strictly in-memory session token (never stored in localStorage/sessionStorage)
  private readonly authToken = signal<string | null>(null);

  readonly activeSection = signal<NavSection>('incidents');
  readonly directory = signal<OperatorDirectorySummary[]>([]);
  readonly currentUser = signal<AuthSessionUser | null>(null);
  readonly pendingMfa = signal<boolean>(false);
  readonly assignedResourceId = signal<string | null>(null);

  readonly snapshot = signal<ControlRoomSnapshot | null>(null);
  readonly cachedAtIso = signal<string | null>(null);
  readonly wsStatus = signal<'CONNECTED' | 'CONNECTING' | 'DISCONNECTED'>('DISCONNECTED');
  readonly liveClockIso = signal<string>(new Date().toISOString());

  readonly selectedIncidentId = signal<string>('INC-2026-0412');
  readonly recommendations = signal<AllocationRecommendation[]>([]);
  readonly loadingRecommendations = signal<boolean>(false);

  readonly replayFrames = signal<ReplayFrame[]>([]);
  readonly replayNotice = signal<string>('');
  readonly deliverablesList = signal<string[]>([]);

  readonly lastError = signal<string | null>(null);
  readonly lastNotice = signal<string | null>(null);
  readonly lastTimedOutCommandId = signal<string | null>(null);

  readonly selectedIncident = computed(() => {
    const snap = this.snapshot();
    const id = this.selectedIncidentId();
    if (!snap) return null;
    return snap.incidents.find((i) => i.id === id) ?? snap.incidents[0] ?? null;
  });

  readonly isDegradedMode = computed(() => {
    const snap = this.snapshot();
    if (!snap) return false;
    const r = snap.resilience;
    return (
      this.wsStatus() !== 'CONNECTED' ||
      r.connectivityDegraded ||
      r.commsAdapterOutage ||
      r.staleGpsSimulation ||
      r.mapTilesMissing ||
      r.delayedAckMode
    );
  });

  private authHeaders(): HttpHeaders {
    const token = this.authToken();
    return token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders();
  }

  async init(): Promise<void> {
    if (!this.isBrowser) return;

    this.clockTimer = setInterval(() => {
      this.liveClockIso.set(new Date().toISOString());
    }, 1000);

    try {
      const dir = await firstValueFrom(
        this.http.get<{ operators: OperatorDirectorySummary[] }>('/api/auth/directory'),
      );
      this.directory.set(dir.operators);
      // Initial prototype sign-in as Joint Dispatcher with verified MFA
      await this.signIn('op-disp-joint', '482910');
    } catch {
      this.lastError.set('Unable to reach Tertius Response API on startup.');
    }
  }

  destroy(): void {
    if (this.clockTimer) clearInterval(this.clockTimer);
    if (this.ws) this.ws.close();
  }

  async signIn(operatorId: string, mfaCode?: string): Promise<boolean> {
    this.lastError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{
          token: string;
          user: AuthSessionUser;
          assignedResourceId?: string;
          mfaRequired: boolean;
        }>('/api/auth/login', { operatorId, mfaCode }),
      );
      this.authToken.set(res.token);
      this.currentUser.set(res.user);
      this.assignedResourceId.set(res.assignedResourceId ?? null);
      this.pendingMfa.set(res.mfaRequired);

      if (!res.mfaRequired) {
        await this.refreshState();
        this.connectWebSocket();
        this.lastNotice.set(`Signed in as ${res.user.name} (${res.user.role} · ${res.user.agency.toUpperCase()})`);
      }
      return true;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Sign-in failed');
      return false;
    }
  }

  async verifyMfa(code: string): Promise<boolean> {
    this.lastError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{ user: AuthSessionUser }>(
          '/api/auth/mfa-verify',
          { code },
          { headers: this.authHeaders() },
        ),
      );
      this.currentUser.set(res.user);
      this.pendingMfa.set(false);
      await this.refreshState();
      this.connectWebSocket();
      this.lastNotice.set(`MFA verified for ${res.user.name}`);
      return true;
    } catch (err: unknown) {
      this.handleHttpError(err, 'MFA verification failed');
      return false;
    }
  }

  private connectWebSocket(): void {
    if (!this.isBrowser) return;
    const token = this.authToken();
    if (!token) return;

    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${protocol}//${window.location.host}/api/ws?token=${encodeURIComponent(token)}`;
    this.wsStatus.set('CONNECTING');

    const socket = new WebSocket(url);
    this.ws = socket;

    socket.onopen = () => {
      this.wsStatus.set('CONNECTED');
    };

    socket.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data as string) as { type: string };
        if (msg.type === 'state:updated') {
          void this.refreshState();
        }
      } catch {
        // Ignore malformed frame
      }
    };

    socket.onclose = () => {
      this.wsStatus.set('DISCONNECTED');
    };

    socket.onerror = () => {
      this.wsStatus.set('DISCONNECTED');
    };
  }

  async refreshState(): Promise<void> {
    if (!this.authToken()) return;
    if (this.snapshot()?.resilience.connectivityDegraded) {
      // Keep cached read-only view when simulated connectivity loss is active
      return;
    }
    try {
      const snap = await firstValueFrom(
        this.http.get<ControlRoomSnapshot>('/api/state', { headers: this.authHeaders() }),
      );
      this.snapshot.set(snap);
      this.cachedAtIso.set(snap.serverTime);
      if (this.selectedIncidentId()) {
        await this.loadRecommendations(this.selectedIncidentId());
      }
    } catch (err: unknown) {
      this.handleHttpError(err, 'Failed to sync state — displaying last cached snapshot');
    }
  }

  selectIncident(id: string): void {
    this.selectedIncidentId.set(id);
    void this.loadRecommendations(id);
  }

  async loadRecommendations(incidentId: string): Promise<void> {
    if (!this.authToken() || !incidentId) return;
    this.loadingRecommendations.set(true);
    try {
      const res = await firstValueFrom(
        this.http.get<{ recommendations: AllocationRecommendation[] }>(
          `/api/incidents/${encodeURIComponent(incidentId)}/recommendations`,
          { headers: this.authHeaders() },
        ),
      );
      this.recommendations.set(res.recommendations);
    } catch {
      this.recommendations.set([]);
    } finally {
      this.loadingRecommendations.set(false);
    }
  }

  async createIncident(payload: {
    title: string;
    serviceScope: ServiceType;
    incidentType: string;
    receivingChannel: string;
    reportedLocationText: string;
    locationConfidence: LocationConfidence;
    uncertaintyRadiusMeters: number;
    callerName: string;
    callbackNumber: string;
    safeToCall: boolean;
    callerStatement: string;
    knownHazards: string[];
    accessInformation: string;
  }): Promise<string | null> {
    this.lastError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{ incident: { id: string } }>('/api/incidents', payload, {
          headers: this.authHeaders(),
        }),
      );
      await this.refreshState();
      this.selectedIncidentId.set(res.incident.id);
      await this.loadRecommendations(res.incident.id);
      this.lastNotice.set(`Incident ${res.incident.id} opened.`);
      return res.incident.id;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Unable to create incident');
      return null;
    }
  }

  async reviewLocation(
    incidentId: string,
    payload: {
      expectedVersion: number;
      verifiedAddress: string | null;
      locationConfidence: LocationConfidence;
      uncertaintyRadiusMeters: number;
      coordinates: GeoPoint;
      factNote: string;
    },
  ): Promise<boolean> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.patch(`/api/incidents/${encodeURIComponent(incidentId)}/location`, payload, {
          headers: this.authHeaders(),
        }),
      );
      await this.refreshState();
      this.lastNotice.set(`Location confidence updated on ${incidentId}.`);
      return true;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Location update conflict');
      return false;
    }
  }

  async resolveDuplicate(
    incidentId: string,
    decision: Exclude<DuplicateReviewStatus, 'NONE' | 'PENDING_REVIEW'>,
    note: string,
  ): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/incidents/${encodeURIComponent(incidentId)}/duplicate-review`,
          { decision, note },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set(`Duplicate review recorded (${decision}).`);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Duplicate review failed');
    }
  }

  async recordAssessment(
    incidentId: string,
    payload: {
      expectedVersion: number;
      pathwayAdapter: string;
      pathwayCategory: string;
      priorityCode: string;
      priorityLabel: string;
      severityRank: 1 | 2 | 3 | 4;
      rationale: string;
      isOverride: boolean;
    },
  ): Promise<boolean> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(`/api/incidents/${encodeURIComponent(incidentId)}/assessment`, payload, {
          headers: this.authHeaders(),
        }),
      );
      await this.refreshState();
      this.lastNotice.set(`Authorised priority ${payload.priorityCode} recorded on ${incidentId}.`);
      return true;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Assessment rejected');
      return false;
    }
  }

  async flagCircumstanceChange(incidentId: string, note: string, sharingScope: SharingScope): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/incidents/${encodeURIComponent(incidentId)}/circumstance-change`,
          { note, sharingScope },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set('Circumstance change recorded — reassessment task created.');
    } catch (err: unknown) {
      this.handleHttpError(err, 'Failed to flag circumstance change');
    }
  }

  async manageOwnership(
    incidentId: string,
    action: 'ACQUIRE' | 'RELEASE' | 'HANDOVER_REQUEST' | 'ACCEPT_HANDOVER' | 'SUPERVISOR_TAKEOVER',
  ): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/incidents/${encodeURIComponent(incidentId)}/ownership`,
          { action },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set(`Ownership action ${action} completed.`);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Ownership action blocked');
    }
  }

  async submitDispatch(payload: {
    incidentId: string;
    resourceId: string;
    idempotencyKey: string;
    commandId?: string;
    expectedIncidentVersion: number;
    expectedResourceVersion: number;
    deliveryChannel?: DispatchAssignment['deliveryChannel'];
    simulateTimeout?: boolean;
  }): Promise<DispatchAssignment | null> {
    this.lastError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{
          assignment: DispatchAssignment;
          idempotentReplay: boolean;
          timedOutQueryRequired?: boolean;
        }>('/api/dispatch', payload, { headers: this.authHeaders() }),
      );
      if (res.timedOutQueryRequired) {
        this.lastTimedOutCommandId.set(res.assignment.commandId);
        this.lastNotice.set(
          `Network timeout on delivery ack for command ${res.assignment.commandId}. Query existing outcome instead of re-dispatching.`,
        );
      } else if (res.idempotentReplay) {
        this.lastNotice.set(`Idempotent replay: returned existing command ${res.assignment.commandId}.`);
      } else {
        this.lastNotice.set(`Dispatch submitted for ${res.assignment.resourceCallsign} (${res.assignment.stage}).`);
      }
      await this.refreshState();
      return res.assignment;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Dispatch blocked');
      return null;
    }
  }

  async queryCommandOutcome(commandId: string): Promise<DispatchAssignment | null> {
    this.lastError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.get<{ assignment: DispatchAssignment }>(
          `/api/dispatch/command/${encodeURIComponent(commandId)}`,
          { headers: this.authHeaders() },
        ),
      );
      this.lastNotice.set(`Command ${commandId} outcome verified: ${res.assignment.stage}`);
      this.lastTimedOutCommandId.set(null);
      return res.assignment;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Command outcome query failed');
      return null;
    }
  }

  async updateAssignmentStage(
    assignmentId: string,
    stage: DispatchStage,
    note: string,
    delayed = false,
  ): Promise<boolean> {
    this.lastError.set(null);
    try {
      const res = await firstValueFrom(
        this.http.post<{ assignment: DispatchAssignment; queuedDelayed?: boolean }>(
          `/api/dispatch/${encodeURIComponent(assignmentId)}/stage`,
          { stage, note, delayed },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set(
        res.queuedDelayed
          ? `Delayed status update (${stage}) buffered — advance simulator tick to reconcile.`
          : `Assignment updated to ${stage}.`,
      );
      return true;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Stage update failed');
      return false;
    }
  }

  async updateResource(
    resourceId: string,
    patch: Partial<
      Pick<
        ResourceUnit,
        'staffAvailability' | 'vehicleAvailability' | 'crewReadiness' | 'dispatchAuthorisation' | 'communicationHealth' | 'maintenanceStatus'
      >
    > & { reason: string },
  ): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.patch(`/api/resources/${encodeURIComponent(resourceId)}`, patch, {
          headers: this.authHeaders(),
        }),
      );
      await this.refreshState();
      this.lastNotice.set('Resource register status updated.');
    } catch (err: unknown) {
      this.handleHttpError(err, 'Resource update rejected');
    }
  }

  async updateHandover(
    assignmentId: string,
    action:
      | 'SELECT_DESTINATION'
      | 'SEND_PRE_ALERT'
      | 'RECORD_HOSPITAL_ARRIVAL'
      | 'TRIAGE_BRIEF'
      | 'CLINICAL_HANDOVER'
      | 'TROLLEY_TRANSFER',
    facilityId?: string,
    notes?: string,
  ): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/dispatch/${encodeURIComponent(assignmentId)}/handover`,
          { action, facilityId, notes },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set(`Hospital handover milestone ${action} recorded.`);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Handover update failed');
    }
  }

  async resolveIncident(incidentId: string, summary: string): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/incidents/${encodeURIComponent(incidentId)}/resolve`,
          { summary },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set(`Incident ${incidentId} closed.`);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Cannot close incident');
    }
  }

  async requestInterAgency(payload: {
    incidentId: string;
    requestedAgency: AgencyCode;
    requestedCapability: string;
    rationale: string;
    sharingScope: SharingScope;
  }): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post('/api/multi-agency/requests', payload, { headers: this.authHeaders() }),
      );
      await this.refreshState();
      this.lastNotice.set(`JESIP assistance requested from ${payload.requestedAgency.toUpperCase()}.`);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Inter-agency request failed');
    }
  }

  async respondInterAgency(
    requestId: string,
    status: 'ACKNOWLEDGED' | 'RESOURCES_COMMITTED' | 'DECLINED',
    responseNote: string,
  ): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          `/api/multi-agency/requests/${encodeURIComponent(requestId)}/respond`,
          { status, responseNote },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set(`Inter-agency response recorded (${status}).`);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Inter-agency response blocked');
    }
  }

  async sendCommunication(payload: {
    incidentId: string | null;
    resourceId: string | null;
    channel: CommunicationRecord['channel'];
    recipient: string;
    content: string;
    sharingScope: SharingScope;
    amendedFromId?: string | null;
    amendmentNote?: string | null;
  }): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post('/api/communications', payload, { headers: this.authHeaders() }),
      );
      await this.refreshState();
      this.lastNotice.set(`Sent ${payload.channel} message to ${payload.recipient}.`);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Communication send failed');
    }
  }

  async setResilienceFlags(patch: Partial<ResilienceFlags>): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post('/api/resilience', patch, { headers: this.authHeaders() }),
      );
      // Force live fetch even if clearing connectivityDegraded
      const snap = await firstValueFrom(
        this.http.get<ControlRoomSnapshot>('/api/state', { headers: this.authHeaders() }),
      );
      this.snapshot.set(snap);
      this.cachedAtIso.set(snap.serverTime);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Failed to update resilience mode');
    }
  }

  async stepSimulator(travelTimeMultiplier?: number): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post(
          '/api/simulator/step',
          { travelTimeMultiplier },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
    } catch (err: unknown) {
      this.handleHttpError(err, 'Simulator step failed');
    }
  }

  async resetSimulator(): Promise<void> {
    this.lastError.set(null);
    try {
      await firstValueFrom(
        this.http.post('/api/simulator/reset', {}, { headers: this.authHeaders() }),
      );
      await this.refreshState();
      this.lastNotice.set('Pennine Demonstrator state reset to synthetic baseline.');
    } catch (err: unknown) {
      this.handleHttpError(err, 'Reset failed');
    }
  }

  async loadIsolatedReplay(incidentId?: string): Promise<void> {
    if (!this.authToken()) return;
    try {
      const url = incidentId
        ? `/api/replay?incidentId=${encodeURIComponent(incidentId)}`
        : '/api/replay';
      const res = await firstValueFrom(
        this.http.get<{
          isolated: true;
          readOnly: true;
          prototypeNotice: string;
          frames: ReplayFrame[];
        }>(url, { headers: this.authHeaders() }),
      );
      this.replayFrames.set(res.frames);
      this.replayNotice.set(res.prototypeNotice);
    } catch (err: unknown) {
      this.handleHttpError(err, 'Failed to load isolated replay');
    }
  }

  async exportReport(incidentId: string): Promise<Record<string, unknown> | null> {
    this.lastError.set(null);
    try {
      const report = await firstValueFrom(
        this.http.get<Record<string, unknown>>(
          `/api/reports/export/${encodeURIComponent(incidentId)}`,
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      return report;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Report export failed');
      return null;
    }
  }

  async fetchDeliverablesList(): Promise<void> {
    if (!this.authToken()) return;
    try {
      const res = await firstValueFrom(
        this.http.get<{ files: string[] }>('/api/deliverables', { headers: this.authHeaders() }),
      );
      this.deliverablesList.set(res.files);
    } catch {
      this.deliverablesList.set([]);
    }
  }

  async fetchDeliverableFile(path: string): Promise<string> {
    const res = await firstValueFrom(
      this.http.get<{ content: string }>(
        `/api/deliverables/file?path=${encodeURIComponent(path)}`,
        { headers: this.authHeaders() },
      ),
    );
    return res.content;
  }

  async exportBackupSnapshot(): Promise<string | null> {
    try {
      const res = await firstValueFrom(
        this.http.get<{ snapshotJson: string }>('/api/admin/backup', {
          headers: this.authHeaders(),
        }),
      );
      this.lastNotice.set('Backup snapshot exported.');
      return res.snapshotJson;
    } catch (err: unknown) {
      this.handleHttpError(err, 'Backup export requires Supervisor or Auditor role');
      return null;
    }
  }

  async restoreBackupSnapshot(snapshotJson: string): Promise<void> {
    try {
      await firstValueFrom(
        this.http.post(
          '/api/admin/restore',
          { snapshotJson },
          { headers: this.authHeaders() },
        ),
      );
      await this.refreshState();
      this.lastNotice.set('Backup snapshot restored.');
    } catch (err: unknown) {
      this.handleHttpError(err, 'Restore requires Supervisor role');
    }
  }

  clearMessages(): void {
    this.lastError.set(null);
    this.lastNotice.set(null);
  }

  private handleHttpError(err: unknown, fallback: string): void {
    const httpErr = err as { error?: { error?: string; message?: string } };
    const msg = httpErr?.error?.message ?? httpErr?.error?.error ?? fallback;
    this.lastError.set(msg);
  }
}
