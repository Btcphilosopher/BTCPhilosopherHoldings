import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { WebSocketServer, WebSocket } from 'ws';
import { authService } from './server/auth';
import { createApiRouter } from './server/routes';
import { controlRoomStore } from './server/store';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const server = createServer(app);
const angularApp = new AngularNodeAppEngine();

const wss = new WebSocketServer({ noServer: true });
const wsClients = new Set<WebSocket>();

wss.on('connection', (ws) => {
  wsClients.add(ws);
  ws.send(
    JSON.stringify({
      type: 'ws:connected',
      serverTime: new Date().toISOString(),
    }),
  );
  ws.on('close', () => {
    wsClients.delete(ws);
  });
});

controlRoomStore.subscribe((eventType, payload) => {
  const message = JSON.stringify({
    type: eventType,
    payload,
    serverTime: new Date().toISOString(),
  });
  for (const client of wsClients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  }
});

// Handle WebSocket upgrade on /api/ws before Angular SSR catch-all
app.use('/api', (req, res, next) => {
  if (req.path === '/ws' && req.headers.upgrade?.toLowerCase() === 'websocket') {
    const token = typeof req.query['token'] === 'string' ? req.query['token'] : undefined;
    const operator = authService.authenticateToken(token);
    if (!operator || !operator.mfaVerified) {
      req.socket.destroy();
      return;
    }
    wss.handleUpgrade(req, req.socket, Buffer.alloc(0), (ws) => {
      wss.emit('connection', ws, req);
    });
    return;
  }
  next();
});

app.use('/api', createApiRouter());

app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) => (response ? writeResponseToNodeResponse(response, res) : next()))
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  server.listen(port, () => {
    console.log(`Tertius Response server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
