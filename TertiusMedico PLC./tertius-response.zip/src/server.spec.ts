import { describe, expect, it, beforeEach } from 'vitest';
import { authService } from './server/auth';
import { computeRecommendations } from './server/recommender';
import { ControlRoomStore } from './server/store';

function makeActor(id: string) {
  const session = authService.createSessionForUser(id, '482910');
  if (!session) throw new Error(`Missing test user ${id}`);
  return session.user;
}

describe('Tertius Response — Core Safety, Concurrency, RBAC & Replay Suite', () => {
  let store: ControlRoomStore;

  beforeEach(() => {
    store = new ControlRoomStore();
  });

  it('1. Enforces hard resource concurrency & version checks on dispatch', () => {
    const dispatcher = makeActor('op-disp-joint');
    const inc1 = store.getIncidentById('INC-2026-0412')!;
    const inc2 = store.getIncidentById('INC-2026-0414')!;
    const amb41 = store.getResources().find((r) => r.id === 'res-amb-41')!;

    const first = store.submitDispatch(dispatcher, {
      incidentId: inc1.id,
      resourceId: amb41.id,
      idempotencyKey: 'idem-concurrent-1',
      expectedIncidentVersion: inc1.version,
      expectedResourceVersion: amb41.version,
    });
    expect(first.ok).toBe(true);

    // Second operator tries to assign same resource with stale or current version
    const secondStale = store.submitDispatch(dispatcher, {
      incidentId: inc2.id,
      resourceId: amb41.id,
      idempotencyKey: 'idem-concurrent-2',
      expectedIncidentVersion: inc2.version,
      expectedResourceVersion: 1,
    });
    expect(secondStale.ok).toBe(false);
    if (!secondStale.ok) {
      expect(secondStale.code).toBe(409);
    }

    const updatedAmb = store.getResources().find((r) => r.id === 'res-amb-41')!;
    const secondCurrent = store.submitDispatch(dispatcher, {
      incidentId: inc2.id,
      resourceId: amb41.id,
      idempotencyKey: 'idem-concurrent-3',
      expectedIncidentVersion: inc2.version,
      expectedResourceVersion: updatedAmb.version,
    });
    expect(secondCurrent.ok).toBe(false);
    if (!secondCurrent.ok) {
      expect(secondCurrent.code).toBe(409);
      expect(secondCurrent.error).toContain('already assigned');
    }
  });

  it('2. Enforces RBAC permissions & restricted clinical/police redaction', () => {
    const dispatcher = makeActor('op-disp-amb');
    const supervisor = makeActor('op-sup-joint');

    // Dispatcher cannot perform a Supervisor Priority Override
    const inc = store.getIncidentById('INC-2026-0412')!;
    const denied = store.recordAssessment(dispatcher, inc.id, {
      expectedVersion: inc.version,
      pathwayAdapter: 'Pennine Prototype',
      pathwayCategory: 'CAT-A1',
      priorityCode: 'CAT-A1',
      priorityLabel: 'Immediate',
      severityRank: 1,
      rationale: 'Attempting override as dispatcher',
      isOverride: true,
    });
    expect(denied.ok).toBe(false);
    if (!denied.ok) expect(denied.code).toBe(403);

    // Dispatcher snapshot redacts RESTRICTED_CLINICAL and RESTRICTED_POLICE notes
    const dispSnap = store.getSnapshot(dispatcher);
    const inc415 = dispSnap.incidents.find((i) => i.id === 'INC-2026-0415')!;
    const inc416 = dispSnap.incidents.find((i) => i.id === 'INC-2026-0416')!;
    expect(inc415.operatorObservations[0].note).toContain('REDACTED');
    expect(inc416.operatorObservations[0].note).toContain('REDACTED');

    // Supervisor snapshot sees restricted notes
    const supSnap = store.getSnapshot(supervisor);
    const sup416 = supSnap.incidents.find((i) => i.id === 'INC-2026-0416')!;
    expect(sup416.operatorObservations[0].note).toContain('Welfare intelligence flag');
  });

  it('3. Preserves incident and prevents collision under ownership lease controls', () => {
    const disp1 = makeActor('op-disp-joint');
    const disp2 = makeActor('op-disp-amb');
    const sup = makeActor('op-sup-joint');

    // INC-2026-0412 is owned by op-disp-joint
    const stealAttempt = store.manageOwnershipLease(disp2, 'INC-2026-0412', 'ACQUIRE');
    expect(stealAttempt.ok).toBe(false);
    if (!stealAttempt.ok) expect(stealAttempt.code).toBe(409);

    // Releasing lease never deletes or closes the incident
    const released = store.manageOwnershipLease(disp1, 'INC-2026-0412', 'RELEASE');
    expect(released.ok).toBe(true);
    const incAfterRelease = store.getIncidentById('INC-2026-0412')!;
    expect(incAfterRelease.status).not.toBe('CLOSED');
    expect(incAfterRelease.ownershipLease).toBeNull();

    // Supervisor takeover succeeds
    const takeover = store.manageOwnershipLease(sup, 'INC-2026-0412', 'SUPERVISOR_TAKEOVER');
    expect(takeover.ok).toBe(true);
    if (takeover.ok) expect(takeover.incident.ownershipLease?.operatorId).toBe(sup.id);
  });

  it('4. Guarantees command idempotency and timeout query recovery', () => {
    const dispatcher = makeActor('op-disp-joint');
    const inc = store.getIncidentById('INC-2026-0412')!;
    const amb41 = store.getResources().find((r) => r.id === 'res-amb-41')!;

    const first = store.submitDispatch(dispatcher, {
      incidentId: inc.id,
      resourceId: amb41.id,
      idempotencyKey: 'idem-timeout-check-99',
      commandId: 'cmd-timeout-99',
      expectedIncidentVersion: inc.version,
      expectedResourceVersion: amb41.version,
      simulateTimeout: true,
    });
    expect(first.ok).toBe(true);
    if (!first.ok) return;
    expect(first.assignment.stage).toBe('DISPATCH_SUBMITTED');

    // Retrying with the same idempotencyKey returns the exact existing assignment, not a duplicate
    const retry = store.submitDispatch(dispatcher, {
      incidentId: inc.id,
      resourceId: amb41.id,
      idempotencyKey: 'idem-timeout-check-99',
      expectedIncidentVersion: inc.version,
      expectedResourceVersion: amb41.version,
    });
    expect(retry.ok).toBe(true);
    if (retry.ok) {
      expect(retry.idempotentReplay).toBe(true);
      expect(retry.assignment.id).toBe(first.assignment.id);
    }

    // Querying command outcome directly
    const queried = store.queryCommandOutcome('cmd-timeout-99');
    expect(queried?.id).toBe(first.assignment.id);
  });

  it('5. Flags stale telemetry, enforces hard eligibility, and never strips active units', () => {
    const hazmatInc = store.getIncidentById('INC-2026-0414')!;
    const recs = computeRecommendations(hazmatInc, store.getResources(), Date.now());

    // FIRE-H2 has HAZMAT_LEVEL_2 and should be eligible
    const fireH2 = recs.find((r) => r.callsign === 'FIRE-H2')!;
    expect(fireH2.eligible).toBe(true);

    // FIRE-ALP1 violates 3.8m low bridge access constraint
    const fireAlp = recs.find((r) => r.callsign === 'FIRE-ALP1')!;
    expect(fireAlp.eligible).toBe(false);
    expect(fireAlp.disqualifiers.some((d) => d.includes('Low bridge'))).toBe(true);

    // FIRE-P3 is VOR_DEFECT / OUT_OF_SERVICE
    const fireP3 = recs.find((r) => r.callsign === 'FIRE-P3')!;
    expect(fireP3.eligible).toBe(false);

    // AMB-RR3 has stale GPS (>300s) flagged on INC-2026-0412
    const rtcInc = store.getIncidentById('INC-2026-0412')!;
    const rtcRecs = computeRecommendations(rtcInc, store.getResources(), Date.now());
    const rr3 = rtcRecs.find((r) => r.callsign === 'AMB-RR3')!;
    expect(rr3.isPositionStale).toBe(true);
    expect(rr3.missingInformation.some((m) => m.includes('extrapolation halted'))).toBe(true);

    // AMB-42 is assigned to INC-2026-0415 and must NOT be stripped to improve score
    const amb42 = rtcRecs.find((r) => r.callsign === 'AMB-42')!;
    expect(amb42.eligible).toBe(false);
    expect(amb42.disqualifiers.some((d) => d.includes('automatic reassignment prohibited'))).toBe(true);
  });

  it('6. Keeps network delivery distinct from explicit crew acknowledgement & hospital arrival distinct from clear', () => {
    const dispatcher = makeActor('op-disp-joint');
    const responder = makeActor('op-resp-amb');
    const inc = store.getIncidentById('INC-2026-0412')!;
    const amb41 = store.getResources().find((r) => r.id === 'res-amb-41')!;

    const disp = store.submitDispatch(dispatcher, {
      incidentId: inc.id,
      resourceId: amb41.id,
      idempotencyKey: 'idem-ack-sep-1',
      expectedIncidentVersion: inc.version,
      expectedResourceVersion: amb41.version,
    });
    expect(disp.ok).toBe(true);
    if (!disp.ok) return;

    // Delivered != Crew Acknowledged
    expect(disp.assignment.communicationDeliveredAt).not.toBeNull();
    expect(disp.assignment.crewAcknowledgedAt).toBeNull();
    expect(disp.assignment.stage).toBe('DELIVERED_CONFIRMED');

    // Explicit responder ack sets crewAcknowledgedAt
    const acked = store.updateAssignmentStage(responder, disp.assignment.id, {
      stage: 'CREW_ACKNOWLEDGED',
      note: 'Crew acknowledged on MDT',
    });
    expect(acked.ok).toBe(true);
    if (acked.ok) {
      expect(acked.assignment.crewAcknowledgedAt).not.toBeNull();
    }

    // Hospital arrival on AMB-42 does NOT auto-clear crew
    const arrived = store.updateHospitalHandover(responder, 'asg-415-1', 'RECORD_HOSPITAL_ARRIVAL');
    expect(arrived.ok).toBe(true);
    if (arrived.ok) {
      expect(arrived.assignment.stage).not.toBe('CLEAR');
      expect(arrived.assignment.hospitalHandover?.arrivedAtHospitalAt).not.toBeNull();
      expect(arrived.assignment.hospitalHandover?.resourceClearedAt).toBeNull();
    }
    const amb42 = store.getResources().find((r) => r.id === 'res-amb-42')!;
    expect(amb42.currentAssignmentId).toBe('asg-415-1');
  });

  it('7. Supports backup snapshot export and restart recovery restoration', () => {
    const sup = makeActor('op-sup-joint');
    const created = store.createIncident(sup, {
      title: 'Pre-Restart Incident',
      serviceScope: 'fire',
      incidentType: 'Building Alarm',
      receivingChannel: '999_SIM_VOICE',
      reportedLocationText: 'Halifax Mill Prototype',
      locationConfidence: 'VERIFIED_EXACT',
      uncertaintyRadiusMeters: 20,
      callerName: 'Test Caller',
      callbackNumber: '+44 7700 900111',
      safeToCall: true,
      callerStatement: 'Smoke visible on roof.',
      knownHazards: [],
      accessInformation: 'Front gate open',
    });

    const backup = store.exportBackupSnapshot();
    store.resetSeed();
    expect(store.getIncidentById(created.id)).toBeUndefined();

    store.restoreBackupSnapshot(sup, backup);
    expect(store.getIncidentById(created.id)?.title).toBe('Pre-Restart Incident');
  });

  it('8. Records hash-chained audit trail across mutations', () => {
    const sup = makeActor('op-sup-joint');
    const beforeCount = store.getSnapshot(sup).auditLog.length;
    store.flagCircumstanceChange(sup, 'INC-2026-0412', 'Second vehicle reported smoking', 'SHARED_JESIP');
    const afterLog = store.getSnapshot(sup).auditLog;
    expect(afterLog.length).toBe(beforeCount + 1);
    expect(afterLog[0].actionType).toBe('REASSESSMENT_FLAGGED');
    expect(afterLog[0].integrityHash).toMatch(/^[a-f0-9]{16}$/);
  });

  it('9. Isolates Replay mode from live incident and resource state', () => {
    const dispatcher = makeActor('op-disp-joint');
    const beforeSnap = store.getSnapshot(dispatcher);
    const replay = store.getIsolatedReplay(dispatcher, 'INC-2026-0412');
    expect(replay.isolated).toBe(true);
    expect(replay.readOnly).toBe(true);
    expect(replay.frames.length).toBeGreaterThanOrEqual(1);

    const afterSnap = store.getSnapshot(dispatcher);
    expect(afterSnap.incidents.length).toBe(beforeSnap.incidents.length);
    expect(afterSnap.assignments.length).toBe(beforeSnap.assignments.length);
  });
});
