export type ServiceType = 'ambulance' | 'fire' | 'police' | 'multi_agency';

export type AgencyCode = 'ambulance' | 'fire' | 'police' | 'joint';

export type UserRole =
  | 'DISPATCHER'
  | 'SUPERVISOR'
  | 'CLINICAL_ADVISOR'
  | 'RESPONDER'
  | 'AUDITOR';

export type ReceivingChannel =
  | '999_SIM_VOICE'
  | '111_TRANSFER'
  | 'ECALL_TELEMETRY'
  | 'INTER_AGENCY_LINK'
  | 'RADIO_HAIL';

export type LocationConfidence =
  | 'VERIFIED_EXACT'
  | 'CELL_SECTOR_APPROX'
  | 'CONFLICTING_REPORTS'
  | 'UNVERIFIED_LANDMARK';

export type AssessmentStatus =
  | 'UNASSESSED'
  | 'ASSESSED'
  | 'REASSESSMENT_REQUIRED';

export type DuplicateReviewStatus =
  | 'NONE'
  | 'PENDING_REVIEW'
  | 'CONFIRMED_SEPARATE'
  | 'LINKED_RELATED';

export type IncidentStatus =
  | 'INTAKE'
  | 'ASSESSED'
  | 'DISPATCHING'
  | 'ACTIVE'
  | 'HANDOVER'
  | 'RESOLVED'
  | 'CLOSED';

export type SharingScope =
  | 'SHARED_JESIP'
  | 'AGENCY_ONLY'
  | 'RESTRICTED_CLINICAL'
  | 'RESTRICTED_POLICE';

export interface GeoPoint {
  x: number; // Local synthetic map SVG coordinate (0..1000)
  y: number; // Local synthetic map SVG coordinate (0..640)
  lat: number; // Synthetic Pennine WGS84 latitude
  lon: number; // Synthetic Pennine WGS84 longitude
  gridRef: string; // Synthetic OS National Grid ref
}

export interface CallerStatement {
  id: string;
  recordedAt: string;
  channel: ReceivingChannel;
  callerName: string;
  callbackNumber: string;
  safeToCall: boolean;
  verbatimText: string;
  recordedBy: string;
}

export interface OperatorObservation {
  id: string;
  recordedAt: string;
  operatorId: string;
  operatorName: string;
  agency: AgencyCode;
  sharingScope: SharingScope;
  note: string;
}

export interface ExternalInfoItem {
  id: string;
  receivedAt: string;
  sourceSystem: string;
  reliability: 'AUTHORITATIVE' | 'UNVERIFIED_TELEMETRY' | 'EXTERNAL_REPORT';
  sharingScope: SharingScope;
  summary: string;
}

export interface ConfirmedFact {
  id: string;
  confirmedAt: string;
  confirmedBy: string;
  factType: 'LOCATION' | 'HAZARD' | 'ACCESS' | 'CLINICAL' | 'OPERATIONAL';
  statement: string;
  sharingScope: SharingScope;
}

export interface ConflictingLocationReport {
  id: string;
  reportedAt: string;
  source: string;
  description: string;
  coordinates: GeoPoint;
  uncertaintyMeters: number;
}

export interface AssessmentRecord {
  id: string;
  pathwayAdapter: string;
  pathwayCategory: string;
  priorityCode: string;
  priorityLabel: string;
  severityRank: 1 | 2 | 3 | 4; // 1 = Critical, 2 = Urgent, 3 = Timely, 4 = Routine
  source: 'AUTHORISED_ASSESSMENT' | 'SUPERVISOR_OVERRIDE' | 'UNASSESSED';
  rationale: string;
  assessedByUserId: string;
  assessedByName: string;
  assessedByRole: UserRole;
  assessedAt: string;
  isCurrent: boolean;
  supersededReason?: string;
}

export interface OwnershipLease {
  operatorId: string;
  operatorName: string;
  agency: AgencyCode;
  acquiredAt: string;
  expiresAt: string;
  handoverPendingTo?: string;
}

export interface Incident {
  id: string;
  externalRef: string;
  title: string;
  serviceScope: ServiceType;
  leadAgency: AgencyCode;
  participatingAgencies: AgencyCode[];
  status: IncidentStatus;
  receivingChannel: ReceivingChannel;
  openedAt: string;
  updatedAt: string;
  incidentType: string;
  reportedLocationText: string;
  verifiedAddress: string | null;
  coordinates: GeoPoint;
  locationConfidence: LocationConfidence;
  uncertaintyRadiusMeters: number;
  conflictingLocations: ConflictingLocationReport[];
  knownHazards: string[];
  accessInformation: string;
  assessmentStatus: AssessmentStatus;
  reassessmentReason?: string;
  currentPriorityCode: string;
  currentPriorityLabel: string;
  currentSeverityRank: 1 | 2 | 3 | 4 | 0; // 0 = Unassessed
  prioritySource: 'AUTHORISED_ASSESSMENT' | 'SUPERVISOR_OVERRIDE' | 'UNASSESSED';
  assessments: AssessmentRecord[];
  callerStatements: CallerStatement[];
  operatorObservations: OperatorObservation[];
  externalInfo: ExternalInfoItem[];
  confirmedFacts: ConfirmedFact[];
  assignedOperatorId: string | null;
  ownershipLease: OwnershipLease | null;
  potentialDuplicateOfId: string | null;
  duplicateReviewStatus: DuplicateReviewStatus;
  linkedIncidentIds: string[];
  commandRoles: {
    gold?: string;
    silver?: string;
    bronzeAmbulance?: string;
    bronzeFire?: string;
    bronzePolice?: string;
  };
  version: number;
}

export type StaffAvailability = 'ON_SHIFT' | 'MEAL_BREAK' | 'SHORT_CREWED' | 'OFF_SHIFT';
export type VehicleAvailability = 'SERVICEABLE' | 'VOR_DEFECT' | 'REFUELLING' | 'DECONTAMINATION';
export type CrewReadiness = 'READY' | 'STANDING_BY' | 'FATIGUE_REVIEW' | 'NOT_READY';
export type DispatchAuthorisation = 'AUTHORISED' | 'SUPERVISOR_HOLD' | 'PROHIBITED';
export type CommunicationHealth = 'NOMINAL' | 'INTERMITTENT' | 'NO_COMMS';
export type MaintenanceStatus = 'IN_SERVICE' | 'SCHEDULED_CHECK' | 'OUT_OF_SERVICE';

export interface CrewMember {
  id: string;
  name: string;
  role: string;
  qualifications: string[];
}

export interface ResourceUnit {
  id: string;
  callsign: string;
  service: Exclude<ServiceType, 'multi_agency'>;
  organisation: string;
  vehicleOrTeamType: string;
  homeStation: string;
  jurisdictionZone: string;
  crew: CrewMember[];
  verifiedCapabilities: string[];
  equipment: string[];
  operationalRestrictions: string[];
  staffAvailability: StaffAvailability;
  vehicleAvailability: VehicleAvailability;
  crewReadiness: CrewReadiness;
  dispatchAuthorisation: DispatchAuthorisation;
  currentAssignmentId: string | null;
  currentIncidentId: string | null;
  observedPosition: GeoPoint;
  positionObservedAt: string;
  positionUncertaintyMeters: number;
  headingDegrees: number;
  communicationHealth: CommunicationHealth;
  maintenanceStatus: MaintenanceStatus;
  version: number;
}

export type DispatchStage =
  | 'ASSIGNMENT_PROPOSED'
  | 'DISPATCHER_AUTHORISED'
  | 'DISPATCH_SUBMITTED'
  | 'DELIVERED_CONFIRMED'
  | 'CREW_ACKNOWLEDGED'
  | 'EN_ROUTE'
  | 'AT_SCENE'
  | 'FURTHER_DISPOSITION_RECORDED'
  | 'CLEAR'
  | 'REJECTED'
  | 'WITHDRAWN'
  | 'CANCELLED'
  | 'OUTCOME_UNKNOWN';

export interface DispatchAssignment {
  id: string;
  commandId: string;
  idempotencyKey: string;
  incidentId: string;
  resourceId: string;
  resourceCallsign: string;
  service: Exclude<ServiceType, 'multi_agency'>;
  stage: DispatchStage;
  proposedBy: string;
  authorisedBy: string;
  authorisedAt: string;
  commandSubmittedAt: string | null;
  communicationDeliveredAt: string | null;
  crewAcknowledgedAt: string | null;
  observedMovementAt: string | null;
  arrivedAtSceneAt: string | null;
  furtherDispositionAt: string | null;
  clearedAt: string | null;
  expiresAt: string;
  outcomeNote: string;
  deliveryChannel: 'MDT_PUSH_MOCK' | 'AIRWAVE_RADIO_MOCK' | 'VOICE_FALLBACK';
  routeEstimateMinutes: number;
  routeAssumptions: string;
  hospitalHandover?: HandoverRecord;
  version: number;
}

export interface AllocationRecommendation {
  resourceId: string;
  callsign: string;
  service: Exclude<ServiceType, 'multi_agency'>;
  vehicleOrTeamType: string;
  eligible: boolean;
  score: number; // 0..100, only meaningful when eligible === true
  estimatedTravelMinutes: number;
  travelAssumptions: string;
  positionAgeSeconds: number;
  isPositionStale: boolean;
  disqualifiers: string[];
  reasons: string[];
  missingInformation: string[];
  coverageNote: string;
}

export interface CommunicationRecord {
  id: string;
  incidentId: string | null;
  assignmentId: string | null;
  resourceId: string | null;
  channel: 'TELEPHONY_MOCK' | 'SMS_MOCK' | 'AIRWAVE_RADIO_MOCK' | 'MDT_PUSH_MOCK';
  direction: 'INBOUND' | 'OUTBOUND';
  sender: string;
  recipient: string;
  originalContent: string;
  lockScreenPreview: string; // Redacted safe preview
  amendedFromId: string | null;
  amendmentNote: string | null;
  attemptStatus: 'QUEUED' | 'SENT' | 'FAILED_LINK';
  deliveryStatus: 'PENDING' | 'DELIVERED' | 'UNDELIVERABLE' | 'TIMED_OUT';
  ackStatus: 'NONE' | 'ACKNOWLEDGED' | 'REJECTED';
  operationalOutcome: string;
  sharingScope: SharingScope;
  createdAt: string;
}

export interface HospitalFacility {
  id: string;
  name: string;
  trustName: string;
  coordinates: GeoPoint;
  authorisedCapabilities: string[];
  edCapacityStatus: 'NORMAL' | 'PRESSURE' | 'DIVERT_REVIEW';
  resusBaysAvailable: number;
  handoverQueueCount: number;
  capacityObservedAt: string;
  capacitySource: string;
}

export interface HandoverRecord {
  facilityId: string;
  facilityName: string;
  selectedByClinician: string;
  selectedAt: string;
  preAlertStatus: 'NOT_REQUIRED' | 'PENDING' | 'SENT' | 'ACKNOWLEDGED_BY_ED';
  preAlertSentAt: string | null;
  arrivedAtHospitalAt: string | null;
  triageBriefAt: string | null;
  clinicalHandoverAt: string | null;
  trolleyTransferAt: string | null;
  resourceClearedAt: string | null;
  handoverNotes: string;
}

export interface InterAgencyRequest {
  id: string;
  incidentId: string;
  requestingAgency: AgencyCode;
  requestedAgency: AgencyCode;
  requestedCapability: string;
  rationale: string;
  sharingScope: SharingScope;
  status: 'REQUESTED' | 'ACKNOWLEDGED' | 'RESOURCES_COMMITTED' | 'DECLINED';
  requestedBy: string;
  requestedAt: string;
  respondedBy: string | null;
  respondedAt: string | null;
  responseNote: string | null;
}

export interface AuditEvent {
  id: string;
  sequence: number;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  actorAgency: AgencyCode;
  actionType: string;
  entityType: 'INCIDENT' | 'ASSESSMENT' | 'DISPATCH' | 'RESOURCE' | 'COMMUNICATION' | 'HOSPITAL' | 'AUTH' | 'SIMULATOR' | 'SYSTEM';
  entityId: string;
  sharingScope: SharingScope;
  summary: string;
  redacted: boolean;
  integrityHash: string;
}

export interface MapHazardOverlay {
  id: string;
  title: string;
  severity: 'CAUTION' | 'CRITICAL';
  description: string;
  coordinates: GeoPoint;
  radiusMeters: number;
  source: string;
  observedAt: string;
}

export interface ServiceBoundary {
  id: string;
  name: string;
  agency: AgencyCode;
  polygonPoints: string;
  labelPoint: { x: number; y: number };
}

export interface ResilienceFlags {
  connectivityDegraded: boolean;
  commsAdapterOutage: boolean;
  staleGpsSimulation: boolean;
  mapTilesMissing: boolean;
  delayedAckMode: boolean;
  lastBackendRestartAt: string;
  degradedNotes: string[];
}

export interface DemonstratorStep {
  stepNumber: number;
  title: string;
  description: string;
  completed: boolean;
  actionEndpoint?: string;
}

export interface SimulatorStatus {
  seed: number;
  tickCount: number;
  running: boolean;
  travelTimeMultiplier: number;
  simTimeIso: string;
  groundTruthSummary: {
    activeEntities: number;
    hiddenTruePositionsCount: number;
    pendingDelayedMessages: number;
  };
  demonstratorSteps: DemonstratorStep[];
}

export interface ReplayFrame {
  index: number;
  timestamp: string;
  category: 'INTAKE' | 'ASSESSMENT' | 'DISPATCH' | 'COMMS' | 'TELEMETRY' | 'MULTI_AGENCY' | 'HANDOVER' | 'RESOLUTION';
  incidentId: string;
  title: string;
  detail: string;
  actor: string;
  mapMarkers: {
    id: string;
    label: string;
    kind: 'INCIDENT' | 'RESOURCE' | 'HOSPITAL';
    x: number;
    y: number;
    stale?: boolean;
    stage?: string;
  }[];
  routeLine?: { fromX: number; fromY: number; toX: number; toY: number };
}

export interface AuthSessionUser {
  id: string;
  name: string;
  badgeNumber: string;
  role: UserRole;
  agency: AgencyCode;
  mfaVerified: boolean;
  canViewRestrictedClinical: boolean;
  canViewRestrictedPolice: boolean;
}

export interface ControlRoomSnapshot {
  prototypeNotice: string;
  serverTime: string;
  incidents: Incident[];
  resources: ResourceUnit[];
  assignments: DispatchAssignment[];
  communications: CommunicationRecord[];
  hospitals: HospitalFacility[];
  interAgencyRequests: InterAgencyRequest[];
  mapHazards: MapHazardOverlay[];
  serviceBoundaries: ServiceBoundary[];
  auditLog: AuditEvent[];
  resilience: ResilienceFlags;
  simulator: SimulatorStatus;
}
