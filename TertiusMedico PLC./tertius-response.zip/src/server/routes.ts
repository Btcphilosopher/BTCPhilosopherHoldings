import express, { type Request, type Response } from 'express';
import { readFile } from 'node:fs/promises';
import { resolve, sep } from 'node:path';
import {
  authService,
  requireAuth,
  requireRoles,
  type AuthenticatedRequest,
} from './auth';
import { computeRecommendations } from './recommender';
import { controlRoomStore } from './store';
import type {
  AgencyCode,
  CommunicationRecord,
  DispatchStage,
  DuplicateReviewStatus,
  LocationConfidence,
  ServiceType,
  SharingScope,
} from '../shared/domain';

export function createApiRouter(): express.Router {
  const router = express.Router();
  router.use(express.json({ limit: '1mb' }));

  router.get('/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'tertius-response-prototype',
      serverTime: new Date().toISOString(),
    });
  });

  // --- Authentication & MFA ---
  router.get('/auth/directory', (_req: Request, res: Response) => {
    res.json({ operators: authService.listDirectorySummaries() });
  });

  router.post('/auth/login', (req: Request, res: Response) => {
    const { operatorId, mfaCode } = req.body as { operatorId?: string; mfaCode?: string };
    if (!operatorId || typeof operatorId !== 'string') {
      res.status(400).json({ error: 'operatorId is required' });
      return;
    }
    const result = authService.createSessionForUser(operatorId, mfaCode);
    if (!result) {
      res.status(404).json({ error: 'Operator not found in directory' });
      return;
    }
    res.json(result);
  });

  router.post('/auth/mfa-verify', (req: AuthenticatedRequest, res: Response) => {
    const header = req.headers.authorization;
    const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : '';
    const { code } = req.body as { code?: string };
    if (!token || !code) {
      res.status(400).json({ error: 'Bearer token and 6-digit MFA code required' });
      return;
    }
    const verified = authService.verifyMfa(token, code);
    if (!verified) {
      res.status(403).json({ error: 'Invalid 6-digit MFA code or expired session' });
      return;
    }
    res.json({ user: verified });
  });

  router.post('/auth/logout', (req: Request, res: Response) => {
    const header = req.headers.authorization;
    const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : '';
    if (token) authService.revokeToken(token);
    res.json({ ok: true });
  });

  // --- Full Snapshot ---
  router.get('/state', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    res.json(controlRoomStore.getSnapshot(req.operator!));
  });

  // --- Incident Intake & Management ---
  router.post(
    '/incidents',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        title?: string;
        serviceScope?: ServiceType;
        incidentType?: string;
        receivingChannel?:
          | '999_SIM_VOICE'
          | '111_TRANSFER'
          | 'ECALL_TELEMETRY'
          | 'INTER_AGENCY_LINK'
          | 'RADIO_HAIL';
        reportedLocationText?: string;
        locationConfidence?: LocationConfidence;
        uncertaintyRadiusMeters?: number;
        callerName?: string;
        callbackNumber?: string;
        safeToCall?: boolean;
        callerStatement?: string;
        knownHazards?: string[];
        accessInformation?: string;
      };

      if (!body.title?.trim() || !body.reportedLocationText?.trim() || !body.callerStatement?.trim()) {
        res.status(400).json({ error: 'title, reportedLocationText, and callerStatement are required.' });
        return;
      }

      const inc = controlRoomStore.createIncident(req.operator!, {
        title: body.title.trim(),
        serviceScope: body.serviceScope ?? 'ambulance',
        incidentType: body.incidentType?.trim() || 'Emergency Response',
        receivingChannel: body.receivingChannel ?? '999_SIM_VOICE',
        reportedLocationText: body.reportedLocationText.trim(),
        locationConfidence: body.locationConfidence ?? 'UNVERIFIED_LANDMARK',
        uncertaintyRadiusMeters: Number(body.uncertaintyRadiusMeters ?? 450),
        callerName: body.callerName?.trim() || 'Synthetic Caller',
        callbackNumber: body.callbackNumber?.trim() || '+44 7700 900000',
        safeToCall: body.safeToCall !== false,
        callerStatement: body.callerStatement.trim(),
        knownHazards: Array.isArray(body.knownHazards) ? body.knownHazards : [],
        accessInformation: body.accessInformation?.trim() || 'Awaiting access verification.',
      });
      res.status(201).json({ incident: inc });
    },
  );

  router.patch(
    '/incidents/:id/location',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        expectedVersion: number;
        verifiedAddress: string | null;
        locationConfidence: LocationConfidence;
        uncertaintyRadiusMeters: number;
        coordinates: { x: number; y: number; lat: number; lon: number; gridRef: string };
        factNote: string;
      };
      const result = controlRoomStore.verifyOrUpdateLocation(req.operator!, String(req.params['id']), body);
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  router.post(
    '/incidents/:id/duplicate-review',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const { decision, note } = req.body as {
        decision: Exclude<DuplicateReviewStatus, 'NONE' | 'PENDING_REVIEW'>;
        note: string;
      };
      if (decision !== 'CONFIRMED_SEPARATE' && decision !== 'LINKED_RELATED') {
        res.status(400).json({ error: 'decision must be CONFIRMED_SEPARATE or LINKED_RELATED' });
        return;
      }
      const result = controlRoomStore.resolveDuplicateReview(
        req.operator!,
        String(req.params['id']),
        decision,
        note || 'Reviewed by dispatcher',
      );
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  router.post(
    '/incidents/:id/assessment',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR', 'CLINICAL_ADVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        expectedVersion: number;
        pathwayAdapter: string;
        pathwayCategory: string;
        priorityCode: string;
        priorityLabel: string;
        severityRank: 1 | 2 | 3 | 4;
        rationale: string;
        isOverride?: boolean;
      };
      if (!body.priorityCode || !body.rationale?.trim()) {
        res.status(400).json({ error: 'priorityCode and rationale are required' });
        return;
      }
      const result = controlRoomStore.recordAssessment(req.operator!, String(req.params['id']), {
        ...body,
        isOverride: Boolean(body.isOverride),
      });
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  router.post(
    '/incidents/:id/circumstance-change',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR', 'CLINICAL_ADVISOR', 'RESPONDER']),
    (req: AuthenticatedRequest, res: Response) => {
      const { note, sharingScope } = req.body as { note: string; sharingScope?: SharingScope };
      if (!note?.trim()) {
        res.status(400).json({ error: 'Circumstance note is required' });
        return;
      }
      const result = controlRoomStore.flagCircumstanceChange(
        req.operator!,
        String(req.params['id']),
        note.trim(),
        sharingScope ?? 'SHARED_JESIP',
      );
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  router.post(
    '/incidents/:id/ownership',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const { action, targetOperatorId } = req.body as {
        action: 'ACQUIRE' | 'RELEASE' | 'HANDOVER_REQUEST' | 'ACCEPT_HANDOVER' | 'SUPERVISOR_TAKEOVER';
        targetOperatorId?: string;
      };
      const result = controlRoomStore.manageOwnershipLease(
        req.operator!,
        String(req.params['id']),
        action,
        targetOperatorId,
      );
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  router.post(
    '/incidents/:id/resolve',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const { summary } = req.body as { summary?: string };
      const result = controlRoomStore.resolveIncident(
        req.operator!,
        String(req.params['id']),
        summary?.trim() || 'Closed following explicit resource clearance.',
      );
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  // --- Recommendations & Dispatch ---
  router.get('/incidents/:id/recommendations', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const inc = controlRoomStore.getIncidentById(String(req.params['id']));
    if (!inc) {
      res.status(404).json({ error: 'Incident not found' });
      return;
    }
    const recs = computeRecommendations(
      inc,
      controlRoomStore.getResources(),
      Date.now(),
      controlRoomStore.getSimulatorMultiplier(),
    );
    res.json({ recommendations: recs });
  });

  router.post(
    '/dispatch',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        incidentId: string;
        resourceId: string;
        idempotencyKey: string;
        commandId?: string;
        expectedIncidentVersion: number;
        expectedResourceVersion: number;
        deliveryChannel?: 'MDT_PUSH_MOCK' | 'AIRWAVE_RADIO_MOCK' | 'VOICE_FALLBACK';
        simulateTimeout?: boolean;
      };
      if (!body.incidentId || !body.resourceId || !body.idempotencyKey) {
        res.status(400).json({ error: 'incidentId, resourceId, and idempotencyKey are required' });
        return;
      }
      const result = controlRoomStore.submitDispatch(req.operator!, body);
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.status(result.idempotentReplay ? 200 : 201).json(result);
    },
  );

  router.get('/dispatch/command/:commandId', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const asg = controlRoomStore.queryCommandOutcome(String(req.params['commandId']));
    if (!asg) {
      res.status(404).json({ error: 'No dispatch outcome found for commandId' });
      return;
    }
    res.json({ assignment: asg });
  });

  router.post(
    '/dispatch/:assignmentId/stage',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR', 'RESPONDER', 'CLINICAL_ADVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        stage: DispatchStage;
        note?: string;
        expectedVersion?: number;
        delayed?: boolean;
      };
      const result = controlRoomStore.updateAssignmentStage(
        req.operator!,
        String(req.params['assignmentId']),
        {
          stage: body.stage,
          note: body.note?.trim() || `Updated to ${body.stage}`,
          expectedVersion: body.expectedVersion,
          delayed: body.delayed,
        },
      );
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  // --- Resources ---
  router.patch(
    '/resources/:id',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR', 'RESPONDER']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as Record<string, unknown> & { reason?: string };
      const result = controlRoomStore.updateResourceStatus(req.operator!, String(req.params['id']), {
        ...(body as object),
        reason: typeof body.reason === 'string' && body.reason.trim() ? body.reason : 'Manual status update',
      });
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  // --- Hospitals & Handovers ---
  router.post(
    '/dispatch/:assignmentId/handover',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR', 'CLINICAL_ADVISOR', 'RESPONDER']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        action:
          | 'SELECT_DESTINATION'
          | 'SEND_PRE_ALERT'
          | 'RECORD_HOSPITAL_ARRIVAL'
          | 'TRIAGE_BRIEF'
          | 'CLINICAL_HANDOVER'
          | 'TROLLEY_TRANSFER';
        facilityId?: string;
        notes?: string;
      };
      const result = controlRoomStore.updateHospitalHandover(
        req.operator!,
        String(req.params['assignmentId']),
        body.action,
        body.facilityId,
        body.notes,
      );
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  // --- Multi-agency coordination ---
  router.post(
    '/multi-agency/requests',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR', 'CLINICAL_ADVISOR', 'RESPONDER']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        incidentId: string;
        requestedAgency: AgencyCode;
        requestedCapability: string;
        rationale: string;
        sharingScope?: SharingScope;
      };
      const result = controlRoomStore.createInterAgencyRequest(req.operator!, {
        incidentId: body.incidentId,
        requestedAgency: body.requestedAgency,
        requestedCapability: body.requestedCapability,
        rationale: body.rationale,
        sharingScope: body.sharingScope ?? 'SHARED_JESIP',
      });
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.status(201).json(result);
    },
  );

  router.post(
    '/multi-agency/requests/:id/respond',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const { status, responseNote } = req.body as {
        status: 'ACKNOWLEDGED' | 'RESOURCES_COMMITTED' | 'DECLINED';
        responseNote: string;
      };
      const result = controlRoomStore.respondInterAgencyRequest(
        req.operator!,
        String(req.params['id']),
        status,
        responseNote || 'Acknowledged',
      );
      if (!result.ok) {
        res.status(result.code).json(result);
        return;
      }
      res.json(result);
    },
  );

  // --- Communications ---
  router.post(
    '/communications',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR', 'CLINICAL_ADVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const body = req.body as {
        incidentId?: string | null;
        resourceId?: string | null;
        channel: CommunicationRecord['channel'];
        recipient: string;
        content: string;
        sharingScope?: SharingScope;
        amendedFromId?: string | null;
        amendmentNote?: string | null;
      };
      if (!body.recipient?.trim() || !body.content?.trim()) {
        res.status(400).json({ error: 'recipient and content are required' });
        return;
      }
      const record = controlRoomStore.sendCommunication(req.operator!, {
        incidentId: body.incidentId ?? null,
        resourceId: body.resourceId ?? null,
        channel: body.channel ?? 'AIRWAVE_RADIO_MOCK',
        recipient: body.recipient.trim(),
        content: body.content.trim(),
        sharingScope: body.sharingScope ?? 'AGENCY_ONLY',
        amendedFromId: body.amendedFromId,
        amendmentNote: body.amendmentNote,
      });
      res.status(201).json({ communication: record });
    },
  );

  // --- Resilience & Simulator ---
  router.post(
    '/resilience',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const flags = controlRoomStore.setResilienceFlags(req.operator!, req.body ?? {});
      res.json({ resilience: flags });
    },
  );

  router.post(
    '/simulator/step',
    requireAuth,
    requireRoles(['DISPATCHER', 'SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const { travelTimeMultiplier } = req.body as { travelTimeMultiplier?: number };
      const sim = controlRoomStore.stepSimulator(req.operator!, travelTimeMultiplier);
      res.json({ simulator: sim });
    },
  );

  router.post(
    '/simulator/reset',
    requireAuth,
    requireRoles(['SUPERVISOR', 'DISPATCHER']),
    (_req: AuthenticatedRequest, res: Response) => {
      controlRoomStore.resetSeed();
      res.json({ ok: true });
    },
  );

  // --- Isolated Replay (Read-Only, Isolated from Live Command) ---
  router.get('/replay', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const incidentId = typeof req.query['incidentId'] === 'string' ? req.query['incidentId'] : undefined;
    res.json(controlRoomStore.getIsolatedReplay(req.operator!, incidentId));
  });

  // --- Attributable Operational Report Export ---
  router.get('/reports/export/:incidentId', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const report = controlRoomStore.generateOperationalReport(req.operator!, String(req.params['incidentId']));
    if (!report) {
      res.status(404).json({ error: 'Incident not found' });
      return;
    }
    res.json(report);
  });

  // --- Backup & Restoration Test Endpoint ---
  router.get(
    '/admin/backup',
    requireAuth,
    requireRoles(['SUPERVISOR', 'AUDITOR']),
    (_req: AuthenticatedRequest, res: Response) => {
      res.json({ snapshotJson: controlRoomStore.exportBackupSnapshot() });
    },
  );

  router.post(
    '/admin/restore',
    requireAuth,
    requireRoles(['SUPERVISOR']),
    (req: AuthenticatedRequest, res: Response) => {
      const { snapshotJson } = req.body as { snapshotJson?: string };
      if (!snapshotJson) {
        res.status(400).json({ error: 'snapshotJson is required' });
        return;
      }
      controlRoomStore.restoreBackupSnapshot(req.operator!, snapshotJson);
      res.json({ ok: true });
    },
  );

  // --- Read-only Architecture Deliverables Browser ---
  const DELIVERABLE_FILES = [
    'docker-compose.yml',
    'migrations/001_initial_postgis_schema.sql',
    'backend/app/main.py',
    'backend/requirements.txt',
    'android-responder/MainActivity.kt',
    'android-responder/README_ANDROID.md',
    'docs/API.md',
    'docs/HAZARD_LOG.md',
    'docs/CONTINUITY_PROCEDURE.md',
    'docs/CAPABILITY_MATRIX.md',
  ];

  router.get('/deliverables', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
    res.json({ files: DELIVERABLE_FILES });
  });

  router.get('/deliverables/file', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
    const relPath = typeof req.query['path'] === 'string' ? req.query['path'] : '';
    if (!DELIVERABLE_FILES.includes(relPath)) {
      res.status(400).json({ error: 'Unknown deliverable file path' });
      return;
    }
    const baseDir = resolve(process.cwd(), 'deliverables');
    const resolvedPath = resolve(baseDir, relPath);
    if (!resolvedPath.startsWith(baseDir + sep)) {
      res.status(403).json({ error: 'Invalid path' });
      return;
    }
    try {
      const content = await readFile(resolvedPath, 'utf8');
      res.json({ path: relPath, content });
    } catch {
      res.status(404).json({ error: 'Deliverable file not yet generated on disk' });
    }
  });

  return router;
}
