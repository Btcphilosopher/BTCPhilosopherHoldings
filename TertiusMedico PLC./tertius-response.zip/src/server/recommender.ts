import type {
  AllocationRecommendation,
  Incident,
  ResourceUnit,
  ServiceType,
} from '../shared/domain';

const STALE_POSITION_THRESHOLD_SEC = 180;
const EXTRAPOLATION_HORIZON_SEC = 300;

export function requiredCapabilitiesForIncident(incident: Incident): string[] {
  const caps: string[] = [];
  const typeLower = incident.incidentType.toLowerCase();
  if (incident.serviceScope === 'ambulance' || incident.participatingAgencies.includes('ambulance')) {
    if (incident.currentSeverityRank === 1) {
      caps.push('ALS_PARAMEDIC');
    }
  }
  if (typeLower.includes('hazmat') || incident.knownHazards.some((h) => h.toLowerCase().includes('chemical'))) {
    caps.push('HAZMAT_LEVEL_2');
  }
  if (typeLower.includes('rtc') || typeLower.includes('trapped') || typeLower.includes('extrication')) {
    caps.push('RTC_EXTRICATION');
  }
  if (typeLower.includes('armed') || typeLower.includes('weapon')) {
    caps.push('ARV_CONTAINMENT');
  }
  return caps;
}

function compatibleServiceForIncident(incident: Incident, resourceService: Exclude<ServiceType, 'multi_agency'>): boolean {
  if (incident.serviceScope === 'multi_agency') {
    return incident.participatingAgencies.includes(resourceService) || incident.participatingAgencies.includes('joint');
  }
  return incident.serviceScope === resourceService || incident.participatingAgencies.includes(resourceService);
}

export function computeRecommendations(
  incident: Incident,
  resources: ResourceUnit[],
  nowMs: number,
  travelTimeMultiplier = 1.0,
): AllocationRecommendation[] {
  const requiredCaps = requiredCapabilitiesForIncident(incident);
  const accessLower = incident.accessInformation.toLowerCase();
  const hasLowBridge = accessLower.includes('3.8m') || accessLower.includes('low bridge');

  // Count how many authorised ambulances/pumps remain free to evaluate coverage impact
  const freeByService = resources.reduce<Record<string, number>>((acc, r) => {
    if (
      r.currentAssignmentId === null &&
      r.staffAvailability === 'ON_SHIFT' &&
      r.vehicleAvailability === 'SERVICEABLE' &&
      r.dispatchAuthorisation === 'AUTHORISED'
    ) {
      acc[r.service] = (acc[r.service] ?? 0) + 1;
    }
    return acc;
  }, {});

  const recommendations: AllocationRecommendation[] = resources.map((res) => {
    const disqualifiers: string[] = [];
    const reasons: string[] = [];
    const missingInformation: string[] = [];

    // 1. Hard service / jurisdiction check
    if (!compatibleServiceForIncident(incident, res.service)) {
      disqualifiers.push(`Service mismatch (${res.service.toUpperCase()} not requested for ${incident.serviceScope.toUpperCase()})`);
    }

    // 2. Distinct availability dimensions — never collapse them
    if (res.staffAvailability !== 'ON_SHIFT') {
      disqualifiers.push(`Staff availability: ${res.staffAvailability}`);
    }
    if (res.vehicleAvailability !== 'SERVICEABLE') {
      disqualifiers.push(`Vehicle availability: ${res.vehicleAvailability}`);
    }
    if (res.crewReadiness !== 'READY') {
      disqualifiers.push(`Crew readiness: ${res.crewReadiness}`);
    }
    if (res.dispatchAuthorisation !== 'AUTHORISED') {
      disqualifiers.push(`Dispatch authorisation: ${res.dispatchAuthorisation}`);
    }
    if (res.maintenanceStatus === 'OUT_OF_SERVICE') {
      disqualifiers.push(`Maintenance status: ${res.maintenanceStatus}`);
    }
    if (res.communicationHealth === 'NO_COMMS') {
      disqualifiers.push('Communication health: NO_COMMS (cannot guarantee dispatch delivery)');
    }

    // 3. Never automatically remove resources from active incidents
    if (res.currentAssignmentId !== null) {
      disqualifiers.push(`Currently assigned to active incident (${res.currentIncidentId ?? res.currentAssignmentId}); automatic reassignment prohibited`);
    }

    // 4. Access constraints
    if (hasLowBridge && res.operationalRestrictions.some((r) => r.includes('HEIGHT_OVER_3.8M'))) {
      disqualifiers.push('Access constraint violation: Low bridge (3.8m) blocks high-roof/aerial appliance');
    }

    // 5. Capability matching
    const relevantRequiredCaps = requiredCaps.filter((cap) => {
      if (cap === 'ALS_PARAMEDIC') return res.service === 'ambulance';
      if (cap === 'HAZMAT_LEVEL_2' || cap === 'RTC_EXTRICATION') return res.service === 'fire';
      if (cap === 'ARV_CONTAINMENT') return res.service === 'police';
      return true;
    });

    for (const cap of relevantRequiredCaps) {
      if (!res.verifiedCapabilities.includes(cap)) {
        disqualifiers.push(`Missing required capability: ${cap}`);
      } else {
        reasons.push(`Verified capability match: ${cap}`);
      }
    }

    // 6. Position freshness & uncertainty
    const observedMs = Date.parse(res.positionObservedAt);
    const positionAgeSeconds = Number.isFinite(observedMs)
      ? Math.max(0, Math.round((nowMs - observedMs) / 1000))
      : 9999;
    const isPositionStale = positionAgeSeconds > STALE_POSITION_THRESHOLD_SEC;

    if (isPositionStale) {
      missingInformation.push(
        positionAgeSeconds > EXTRAPOLATION_HORIZON_SEC
          ? `Position stale (${positionAgeSeconds}s old, past ${EXTRAPOLATION_HORIZON_SEC}s horizon — extrapolation halted)`
          : `Position telemetry ageing (${positionAgeSeconds}s old — verify via radio)`,
      );
    }

    if (incident.locationConfidence !== 'VERIFIED_EXACT') {
      missingInformation.push(`Incident location uncertainty (${incident.locationConfidence}, +/-${incident.uncertaintyRadiusMeters}m) affects ETA confidence`);
    }

    if (res.communicationHealth === 'INTERMITTENT') {
      missingInformation.push('Intermittent MDT/radio telemetry — voice confirmation advised');
    }

    // 7. Distance & planning travel estimate (synthetic Pennine grid scale: 100 SVG units ~ 4.2 km)
    const dx = incident.coordinates.x - res.observedPosition.x;
    const dy = incident.coordinates.y - res.observedPosition.y;
    const distanceKm = Math.hypot(dx, dy) * 0.042;
    const baseSpeedKmh = res.service === 'police' ? 62 : res.service === 'ambulance' ? 56 : 50;
    const estimatedTravelMinutes = Math.max(
      2,
      Math.round(((distanceKm / baseSpeedKmh) * 60 + 1.5) * travelTimeMultiplier),
    );

    const eligible = disqualifiers.length === 0;
    let score = 0;

    if (eligible) {
      const distanceScore = Math.max(10, 65 - estimatedTravelMinutes * 2.1);
      const capabilityBonus = relevantRequiredCaps.length > 0 ? 20 : 12;
      const freshnessBonus = isPositionStale ? 0 : 10;
      const commsBonus = res.communicationHealth === 'NOMINAL' ? 5 : 0;
      score = Math.min(99, Math.max(15, Math.round(distanceScore + capabilityBonus + freshnessBonus + commsBonus)));

      reasons.push(`Estimated ${estimatedTravelMinutes} min planning transit (${distanceKm.toFixed(1)} km straight-line Pennine corridor)`);
      reasons.push(`Distinct readiness verified: Staff ${res.staffAvailability}, Vehicle ${res.vehicleAvailability}, Crew ${res.crewReadiness}`);
      if (res.jurisdictionZone) {
        reasons.push(`Jurisdiction zone: ${res.jurisdictionZone}`);
      }
    }

    const remainingAfter = Math.max(0, (freeByService[res.service] ?? 0) - (eligible ? 1 : 0));
    const coverageNote =
      remainingAfter === 0
        ? `Caution: Assigning ${res.callsign} leaves 0 unallocated ${res.service.toUpperCase()} units in Pennine sector`
        : `${remainingAfter} other ${res.service.toUpperCase()} unit(s) remain unallocated`;

    return {
      resourceId: res.id,
      callsign: res.callsign,
      service: res.service,
      vehicleOrTeamType: res.vehicleOrTeamType,
      eligible,
      score,
      estimatedTravelMinutes,
      travelAssumptions: `Planning estimate only (avg ${baseSpeedKmh} km/h, x${travelTimeMultiplier.toFixed(1)} Pennine weather/traffic factor; not turn-by-turn routing).`,
      positionAgeSeconds,
      isPositionStale,
      disqualifiers,
      reasons,
      missingInformation,
      coverageNote,
    };
  });

  // Sort eligible resources first by descending score, then ineligible below
  return recommendations.sort((a, b) => {
    if (a.eligible !== b.eligible) return a.eligible ? -1 : 1;
    if (a.eligible && b.eligible) return b.score - a.score;
    return a.callsign.localeCompare(b.callsign);
  });
}
