import { createHash, randomBytes } from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';
import type { AgencyCode, AuthSessionUser, UserRole } from '../shared/domain';

export interface OperatorDirectoryEntry extends AuthSessionUser {
  assignedResourceId?: string;
  passcodeHash: string;
}

function hashPasscode(raw: string): string {
  return createHash('sha256').update(`tertius-proto:${raw}`).digest('hex');
}

export const OPERATOR_DIRECTORY: OperatorDirectoryEntry[] = [
  {
    id: 'op-disp-joint',
    name: 'Marcus Vance',
    badgeNumber: 'PJ-1088',
    role: 'DISPATCHER',
    agency: 'joint',
    mfaVerified: true,
    canViewRestrictedClinical: false,
    canViewRestrictedPolice: false,
    passcodeHash: hashPasscode('2026'),
  },
  {
    id: 'op-disp-amb',
    name: 'Sarah Jenkins',
    badgeNumber: 'PA-4102',
    role: 'DISPATCHER',
    agency: 'ambulance',
    mfaVerified: true,
    canViewRestrictedClinical: false,
    canViewRestrictedPolice: false,
    passcodeHash: hashPasscode('2026'),
  },
  {
    id: 'op-sup-joint',
    name: 'Claire Whitaker',
    badgeNumber: 'PJ-0042',
    role: 'SUPERVISOR',
    agency: 'joint',
    mfaVerified: true,
    canViewRestrictedClinical: true,
    canViewRestrictedPolice: true,
    passcodeHash: hashPasscode('2026'),
  },
  {
    id: 'op-clin-amb',
    name: 'Dr. Priya Patel',
    badgeNumber: 'PA-9014',
    role: 'CLINICAL_ADVISOR',
    agency: 'ambulance',
    mfaVerified: true,
    canViewRestrictedClinical: true,
    canViewRestrictedPolice: false,
    passcodeHash: hashPasscode('2026'),
  },
  {
    id: 'op-resp-amb',
    name: 'Owen Davies',
    badgeNumber: 'PA-7721',
    role: 'RESPONDER',
    agency: 'ambulance',
    assignedResourceId: 'res-amb-41',
    mfaVerified: true,
    canViewRestrictedClinical: false,
    canViewRestrictedPolice: false,
    passcodeHash: hashPasscode('2026'),
  },
  {
    id: 'op-resp-fire',
    name: 'Liam Bennett',
    badgeNumber: 'PF-3309',
    role: 'RESPONDER',
    agency: 'fire',
    assignedResourceId: 'res-fire-p1',
    mfaVerified: true,
    canViewRestrictedClinical: false,
    canViewRestrictedPolice: false,
    passcodeHash: hashPasscode('2026'),
  },
  {
    id: 'op-auditor',
    name: 'Hannah Reed',
    badgeNumber: 'PJ-AUD-01',
    role: 'AUDITOR',
    agency: 'joint',
    mfaVerified: true,
    canViewRestrictedClinical: false,
    canViewRestrictedPolice: false,
    passcodeHash: hashPasscode('2026'),
  },
];

interface ActiveSession {
  token: string;
  user: OperatorDirectoryEntry;
  mfaVerified: boolean;
  issuedAt: string;
  expiresAtMs: number;
}

export class AuthService {
  private sessions = new Map<string, ActiveSession>();

  createSessionForUser(userId: string, mfaCode?: string): {
    token: string;
    user: AuthSessionUser;
    assignedResourceId?: string;
    mfaRequired: boolean;
  } | null {
    const entry = OPERATOR_DIRECTORY.find((u) => u.id === userId);
    if (!entry) return null;

    // Prototype MFA verification: any 6-digit numeric code (e.g. "482910") verifies MFA;
    // omit mfaCode to get a pending-MFA token that must be verified via /api/auth/mfa-verify
    const mfaVerified = typeof mfaCode === 'string' && /^\d{6}$/.test(mfaCode.trim());
    const token = randomBytes(32).toString('hex');
    const session: ActiveSession = {
      token,
      user: { ...entry, mfaVerified },
      mfaVerified,
      issuedAt: new Date().toISOString(),
      expiresAtMs: Date.now() + 12 * 60 * 60 * 1000,
    };
    this.sessions.set(token, session);
    return {
      token,
      user: this.sanitizeUser(session.user),
      assignedResourceId: entry.assignedResourceId,
      mfaRequired: !mfaVerified,
    };
  }

  verifyMfa(token: string, code: string): AuthSessionUser | null {
    const session = this.sessions.get(token);
    if (!session || session.expiresAtMs < Date.now()) return null;
    if (!/^\d{6}$/.test(code.trim())) return null;
    session.mfaVerified = true;
    session.user = { ...session.user, mfaVerified: true };
    return this.sanitizeUser(session.user);
  }

  authenticateToken(token: string | undefined): OperatorDirectoryEntry | null {
    if (!token) return null;
    const session = this.sessions.get(token);
    if (!session) return null;
    if (session.expiresAtMs < Date.now()) {
      this.sessions.delete(token);
      return null;
    }
    return session.user;
  }

  revokeToken(token: string): void {
    this.sessions.delete(token);
  }

  listDirectorySummaries(): Omit<OperatorDirectoryEntry, 'passcodeHash'>[] {
    return OPERATOR_DIRECTORY.map((entry) => ({
      ...this.sanitizeUser(entry),
      assignedResourceId: entry.assignedResourceId,
    }));
  }

  private sanitizeUser(entry: OperatorDirectoryEntry): AuthSessionUser {
    return {
      id: entry.id,
      name: entry.name,
      badgeNumber: entry.badgeNumber,
      role: entry.role,
      agency: entry.agency,
      mfaVerified: entry.mfaVerified,
      canViewRestrictedClinical: entry.canViewRestrictedClinical,
      canViewRestrictedPolice: entry.canViewRestrictedPolice,
    };
  }
}

export const authService = new AuthService();

export interface AuthenticatedRequest extends Request {
  operator?: OperatorDirectoryEntry;
}

export function extractBearerToken(req: Request): string | undefined {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return undefined;
  return header.slice('Bearer '.length).trim();
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  const operator = authService.authenticateToken(token);
  if (!operator) {
    res.status(401).json({
      error: 'UNAUTHENTICATED',
      message: 'Organisational sign-in token required.',
    });
    return;
  }
  if (!operator.mfaVerified) {
    res.status(403).json({
      error: 'MFA_REQUIRED',
      message: 'Multi-factor authentication verification is required before accessing operational endpoints.',
    });
    return;
  }
  req.operator = operator;
  next();
}

export function requireRoles(allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.operator) {
      res.status(401).json({ error: 'UNAUTHENTICATED', message: 'Sign-in required.' });
      return;
    }
    if (!allowedRoles.includes(req.operator.role)) {
      res.status(403).json({
        error: 'FORBIDDEN_ROLE',
        message: `Role ${req.operator.role} is not authorised for this action. Required: ${allowedRoles.join(', ')}.`,
      });
      return;
    }
    next();
  };
}

export function canOperatorActForAgency(operatorAgency: AgencyCode, targetAgency: AgencyCode): boolean {
  if (operatorAgency === 'joint' || targetAgency === 'joint') return true;
  return operatorAgency === targetAgency;
}
