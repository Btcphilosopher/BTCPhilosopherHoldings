import { createHash, randomUUID } from 'node:crypto';
import type {
  AgencyCode,
  AssessmentRecord,
  AuditEvent,
  AuthSessionUser,
  CommunicationRecord,
  ControlRoomSnapshot,
  DemonstratorStep,
  DispatchAssignment,
  DispatchStage,
  DuplicateReviewStatus,
  GeoPoint,
  HospitalFacility,
  Incident,
  InterAgencyRequest,
  LocationConfidence,
  MapHazardOverlay,
  ReplayFrame,
  ResilienceFlags,
  ResourceUnit,
  ServiceBoundary,
  ServiceType,
  SharingScope,
  SimulatorStatus,
} from '../shared/domain';

const PROTOTYPE_NOTICE =
  'INDEPENDENT PROTOTYPE — Pennine Joint Emergency Coordination Authority (PJECA) is a fictional British emergency-service organisation using synthetic incidents, locations, callers, and responders. Not connected to 999/112, Airwave, or live clinical networks.';

const DEMONSTRATOR_TEMPLATE: Omit<DemonstratorStep, 'completed'>[] = [
  { stepNumber: 1, title: 'Receive a synthetic incident', description: 'Capture incoming emergency report with separated caller statement and channel.' },
  { stepNumber: 2, title: 'Review an uncertain location', description: 'Inspect conflicting location reports without inventing an unverified address.' },
  { stepNumber: 3, title: 'Record an authorised assessment', description: 'Apply structured pathway assessment with role, source, rationale, and timestamp.' },
  { stepNumber: 4, title: 'Identify eligible resources', description: 'Review hard eligibility checks, disqualifiers, stale telemetry, and advisory score.' },
  { stepNumber: 5, title: 'Confirm an assignment', description: 'Authorise idempotent dispatch command and observe submitted vs. delivered states.' },
  { stepNumber: 6, title: 'Receive crew acknowledgement', description: 'Record explicit responder MDT/radio acceptance separate from network delivery.' },
  { stepNumber: 7, title: 'Track reported progress', description: 'Monitor En Route and At Scene milestones with route planning assumptions.' },
  { stepNumber: 8, title: 'Handle a delayed status update', description: 'Inject or receive a delayed responder update and reconcile timeline order.' },
  { stepNumber: 9, title: 'Request another agency’s assistance', description: 'Issue a JESIP multi-agency request without assuming command of partner units.' },
  { stepNumber: 10, title: 'Withdraw an unavailable resource through review', description: 'Withdraw/cancel an assignment when a resource becomes unavailable or rejects.' },
  { stepNumber: 11, title: 'Record handover or incident resolution', description: 'Select authorised hospital destination, pre-alert, and record 3-stage handover.' },
  { stepNumber: 12, title: 'Clear resources explicitly', description: 'Confirm explicit crew clear status (never auto-cleared on hospital arrival).' },
  { stepNumber: 13, title: 'Replay the incident', description: 'Inspect synchronised map, messages, and decisions in isolated Replay mode.' },
  { stepNumber: 14, title: 'Export an attributable operational report', description: 'Generate signed/attributed chronology report with redaction metadata.' },
];

export class ControlRoomStore {
  private incidents: Incident[] = [];
  private resources: ResourceUnit[] = [];
  private assignments: DispatchAssignment[] = [];
  private communications: CommunicationRecord[] = [];
  private hospitals: HospitalFacility[] = [];
  private interAgencyRequests: InterAgencyRequest[] = [];
  private mapHazards: MapHazardOverlay[] = [];
  private serviceBoundaries: ServiceBoundary[] = [];
  private auditLog: AuditEvent[] = [];
  private replayFrames: ReplayFrame[] = [];
  private resilience!: ResilienceFlags;
  private simulator!: SimulatorStatus;

  // Idempotency & simulator hidden ground truth
  private idempotencyRegistry = new Map<string, DispatchAssignment>();
  private commandRegistry = new Map<string, DispatchAssignment>();
  private groundTruthPositions = new Map<string, GeoPoint>();
  private pendingDelayedUpdates: {
    id: string;
    deliverAtTick: number;
    assignmentId: string;
    targetStage: DispatchStage;
    note: string;
  }[] = [];
  private completedDemonstratorSteps = new Set<number>();
  private lastHash = '0000000000000000';
  private auditSeq = 0;
  private listeners = new Set<(eventType: string, payload: unknown) => void>();

  constructor() {
    this.resetSeed();
  }

  subscribe(listener: (eventType: string, payload: unknown) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(eventType: string, payload: unknown): void {
    for (const listener of this.listeners) {
      listener(eventType, payload);
    }
  }

  resetSeed(): void {
    const baseTime = Date.now();
    const ago = (sec: number) => new Date(baseTime - sec * 1000).toISOString();
    const ahead = (sec: number) => new Date(baseTime + sec * 1000).toISOString();

    this.auditLog = [];
    this.replayFrames = [];
    this.idempotencyRegistry.clear();
    this.commandRegistry.clear();
    this.groundTruthPositions.clear();
    this.pendingDelayedUpdates = [];
    this.completedDemonstratorSteps = new Set<number>([1]);
    this.lastHash = '0000000000000000';
    this.auditSeq = 0;

    this.serviceBoundaries = [
      {
        id: 'bnd-amb',
        name: 'Pennine Ambulance Sector',
        agency: 'ambulance',
        polygonPoints: '40,40 960,40 960,600 40,600',
        labelPoint: { x: 75, y: 68 },
      },
      {
        id: 'bnd-fire',
        name: 'Calder & Pennine Fire District',
        agency: 'fire',
        polygonPoints: '120,90 880,90 880,520 120,520',
        labelPoint: { x: 140, y: 118 },
      },
      {
        id: 'bnd-pol',
        name: 'Pennine Constabulary Division',
        agency: 'police',
        polygonPoints: '60,210 920,210 920,580 60,580',
        labelPoint: { x: 78, y: 562 },
      },
    ];

    this.mapHazards = [
      {
        id: 'haz-m62-fog',
        title: 'M62 Moorland Fog & 45 mph Crosswinds',
        severity: 'CRITICAL',
        description: 'Visibility < 40m between J22 and J24. High-sided vehicle advisory active.',
        coordinates: { x: 350, y: 215, lat: 53.635, lon: -1.964, gridRef: 'SE 024 148' },
        radiusMeters: 2200,
        source: 'Highways Telemetry Mock',
        observedAt: ago(240),
      },
      {
        id: 'haz-bridge-38',
        title: 'Slaithwaite Canal Bridge (3.8m Height Limit)',
        severity: 'CAUTION',
        description: 'Restricts Aerial Ladder Platforms and high-roof specialist appliances.',
        coordinates: { x: 545, y: 390, lat: 53.621, lon: -1.878, gridRef: 'SE 081 139' },
        radiusMeters: 450,
        source: 'Local Authority Access Register',
        observedAt: ago(86400),
      },
    ];

    this.hospitals = [
      {
        id: 'hosp-pri',
        name: 'Pennine Royal Infirmary',
        trustName: 'Pennine Acute Prototype NHS Trust',
        coordinates: { x: 720, y: 270, lat: 53.651, lon: -1.792, gridRef: 'SE 138 172' },
        authorisedCapabilities: ['MAJOR_TRAUMA_UNIT', 'PPCI_CARDIAC', 'STROKE_THROMBOLYSIS', 'PAEDIATRIC_ED'],
        edCapacityStatus: 'PRESSURE',
        resusBaysAvailable: 2,
        handoverQueueCount: 3,
        capacityObservedAt: ago(420),
        capacitySource: 'Authorised Regional Capacity Feed (7m old)',
      },
      {
        id: 'hosp-calder',
        name: 'Calder Valley General',
        trustName: 'Calderdale Prototype Hospital Trust',
        coordinates: { x: 560, y: 120, lat: 53.709, lon: -1.862, gridRef: 'SE 092 237' },
        authorisedCapabilities: ['GENERAL_ED', 'ORTHOPAEDIC_URGENT', 'MATERNITY_STABILISATION'],
        edCapacityStatus: 'NORMAL',
        resusBaysAvailable: 4,
        handoverQueueCount: 1,
        capacityObservedAt: ago(180),
        capacitySource: 'Authorised Regional Capacity Feed (3m old)',
      },
      {
        id: 'hosp-airedale',
        name: 'Airedale Moorland Urgent Care',
        trustName: 'West Pennine Prototype Trust',
        coordinates: { x: 240, y: 140, lat: 53.694, lon: -2.045, gridRef: 'SD 971 219' },
        authorisedCapabilities: ['MINOR_INJURIES', 'URGENT_TREATMENT_CENTRE'],
        edCapacityStatus: 'NORMAL',
        resusBaysAvailable: 0,
        handoverQueueCount: 0,
        capacityObservedAt: ago(1200),
        capacitySource: 'Authorised Regional Capacity Feed (20m old — verify before routing)',
      },
    ];

    this.incidents = [
      {
        id: 'INC-2026-0412',
        externalRef: 'CAD-PN-0412',
        title: 'M62 J22 Moorland Multi-Vehicle RTC (Suspected Entrapment)',
        serviceScope: 'multi_agency',
        leadAgency: 'ambulance',
        participatingAgencies: ['ambulance', 'fire', 'police'],
        status: 'INTAKE',
        receivingChannel: 'ECALL_TELEMETRY',
        openedAt: ago(420),
        updatedAt: ago(120),
        incidentType: 'RTC Entrapment / Multi-Vehicle',
        reportedLocationText: 'M62 Eastbound near J22 Windy Hill (approx 1 mile west of Summit)',
        verifiedAddress: null, // Intentionally null because location confidence is CONFLICTING_REPORTS
        coordinates: { x: 345, y: 222, lat: 53.635, lon: -1.964, gridRef: 'SE 024 148' },
        locationConfidence: 'CONFLICTING_REPORTS',
        uncertaintyRadiusMeters: 1450,
        conflictingLocations: [
          {
            id: 'loc-c1',
            reportedAt: ago(420),
            source: 'Caller Mobile Cell Sector (999 Voice)',
            description: 'Caller believes just past Windy Hill Farm layby eastbound.',
            coordinates: { x: 328, y: 230, lat: 53.632, lon: -1.976, gridRef: 'SE 016 144' },
            uncertaintyMeters: 1450,
          },
          {
            id: 'loc-c2',
            reportedAt: ago(380),
            source: 'Vehicle eCall Automated Telemetry',
            description: 'Automated impact coordinate near Marker Post 34/2B.',
            coordinates: { x: 365, y: 214, lat: 53.638, lon: -1.951, gridRef: 'SE 033 151' },
            uncertaintyMeters: 120,
          },
        ],
        knownHazards: ['Dense moorland fog (<40m)', '45 mph crosswinds', 'Live carriageway fast lane'],
        accessInformation: 'Access via M62 J22 slip or A672 Oldham Road emergency gate. Note fog hazard.',
        assessmentStatus: 'UNASSESSED',
        currentPriorityCode: 'UNASSESSED',
        currentPriorityLabel: 'Awaiting Authorised Assessment',
        currentSeverityRank: 0,
        prioritySource: 'UNASSESSED',
        assessments: [],
        callerStatements: [
          {
            id: 'cs-1',
            recordedAt: ago(420),
            channel: '999_SIM_VOICE',
            callerName: 'Claire Thornton (Synthetic Caller)',
            callbackNumber: '+44 7700 900412',
            safeToCall: true,
            verbatimText:
              'Two cars collided in thick fog on the M62 near the mast on the moor. One driver cannot open his door and is complaining of chest and leg pain.',
            recordedBy: 'Marcus Vance (PJ-1088)',
          },
        ],
        operatorObservations: [
          {
            id: 'obs-1',
            recordedAt: ago(310),
            operatorId: 'op-disp-joint',
            operatorName: 'Marcus Vance',
            agency: 'joint',
            sharingScope: 'SHARED_JESIP',
            note: 'Conflicting eastbound coordinates between mobile mast sector and eCall frame. Awaiting marker post confirmation.',
          },
        ],
        externalInfo: [
          {
            id: 'ext-1',
            receivedAt: ago(380),
            sourceSystem: 'eCall Gateway Mock',
            reliability: 'UNVERIFIED_TELEMETRY',
            sharingScope: 'SHARED_JESIP',
            summary: 'Airbag deployment detected; vehicle orientation inverted; occupants count unknown.',
          },
        ],
        confirmedFacts: [
          {
            id: 'cf-1',
            confirmedAt: ago(250),
            confirmedBy: 'Marcus Vance (PJ-1088)',
            factType: 'HAZARD',
            statement: 'Highways gantry confirms thick fog and reduced visibility at Marker 34.',
            sharingScope: 'SHARED_JESIP',
          },
        ],
        assignedOperatorId: 'op-disp-joint',
        ownershipLease: {
          operatorId: 'op-disp-joint',
          operatorName: 'Marcus Vance',
          agency: 'joint',
          acquiredAt: ago(400),
          expiresAt: ahead(1800),
        },
        potentialDuplicateOfId: null,
        duplicateReviewStatus: 'NONE',
        linkedIncidentIds: [],
        commandRoles: {
          silver: 'Insp. Claire Whitaker (PJ-0042)',
        },
        version: 1,
      },
      {
        id: 'INC-2026-0413',
        externalRef: 'CAD-PN-0413',
        title: 'Potential Duplicate: M62 Eastbound Fog Collision Report',
        serviceScope: 'ambulance',
        leadAgency: 'ambulance',
        participatingAgencies: ['ambulance'],
        status: 'INTAKE',
        receivingChannel: '999_SIM_VOICE',
        openedAt: ago(210),
        updatedAt: ago(210),
        incidentType: 'Road Traffic Collision',
        reportedLocationText: 'M62 near Pennine Summit mast, eastbound',
        verifiedAddress: null,
        coordinates: { x: 358, y: 218, lat: 53.637, lon: -1.955, gridRef: 'SE 030 149' },
        locationConfidence: 'UNVERIFIED_LANDMARK',
        uncertaintyRadiusMeters: 900,
        conflictingLocations: [],
        knownHazards: ['Fog on carriageway'],
        accessInformation: 'Passed by passing motorist; caller did not stop.',
        assessmentStatus: 'UNASSESSED',
        currentPriorityCode: 'UNASSESSED',
        currentPriorityLabel: 'Pending Duplicate Review',
        currentSeverityRank: 0,
        prioritySource: 'UNASSESSED',
        assessments: [],
        callerStatements: [
          {
            id: 'cs-2',
            recordedAt: ago(210),
            channel: '999_SIM_VOICE',
            callerName: 'David Hargreaves (Synthetic Caller)',
            callbackNumber: '+44 7700 900811',
            safeToCall: true,
            verbatimText:
              'Just drove past a black saloon sideways in the fog near the radio mast, hazard lights flashing. Couldn’t tell if anyone was inside.',
            recordedBy: 'Sarah Jenkins (PA-4102)',
          },
        ],
        operatorObservations: [
          {
            id: 'obs-2',
            recordedAt: ago(190),
            operatorId: 'op-disp-amb',
            operatorName: 'Sarah Jenkins',
            agency: 'ambulance',
            sharingScope: 'AGENCY_ONLY',
            note: 'Flagged for potential duplicate review against INC-2026-0412. Not silently merged.',
          },
        ],
        externalInfo: [],
        confirmedFacts: [],
        assignedOperatorId: 'op-disp-amb',
        ownershipLease: {
          operatorId: 'op-disp-amb',
          operatorName: 'Sarah Jenkins',
          agency: 'ambulance',
          acquiredAt: ago(200),
          expiresAt: ahead(1800),
        },
        potentialDuplicateOfId: 'INC-2026-0412',
        duplicateReviewStatus: 'PENDING_REVIEW',
        linkedIncidentIds: [],
        commandRoles: {},
        version: 1,
      },
      {
        id: 'INC-2026-0414',
        externalRef: 'CAD-FR-0414',
        title: 'Calder Wharf Warehouse 4 — Chemical Drum Leak (Hazmat)',
        serviceScope: 'fire',
        leadAgency: 'fire',
        participatingAgencies: ['fire'],
        status: 'ASSESSED',
        receivingChannel: '999_SIM_VOICE',
        openedAt: ago(900),
        updatedAt: ago(300),
        incidentType: 'Hazmat / Chemical Release',
        reportedLocationText: 'Unit 4, Calder Wharf Industrial Estate, Slaithwaite',
        verifiedAddress: 'Unit 4, Calder Wharf Industrial Estate, Slaithwaite, HD7 5UX (Synthetic)',
        coordinates: { x: 560, y: 405, lat: 53.619, lon: -1.871, gridRef: 'SE 086 136' },
        locationConfidence: 'VERIFIED_EXACT',
        uncertaintyRadiusMeters: 25,
        conflictingLocations: [],
        knownHazards: ['Corrosive vapour plume (UN 1789 suspected)', 'Forklift battery bank nearby'],
        accessInformation: 'Approach via Slaithwaite Canal Bridge — STRICT 3.8m low bridge clearance.',
        assessmentStatus: 'ASSESSED',
        currentPriorityCode: 'F3-HAZMAT',
        currentPriorityLabel: 'F3 Specialist Hazmat Response',
        currentSeverityRank: 2,
        prioritySource: 'AUTHORISED_ASSESSMENT',
        assessments: [
          {
            id: 'asm-414-1',
            pathwayAdapter: 'Pennine Fire Operational Risk Matrix (Prototype)',
            pathwayCategory: 'F3 — Hazardous Materials & Containment',
            priorityCode: 'F3-HAZMAT',
            priorityLabel: 'F3 Specialist Hazmat Response',
            severityRank: 2,
            source: 'AUTHORISED_ASSESSMENT',
            rationale: 'Confirmed punctured IBC drum inside ventilated bay; 1 worker evacuated with eye irritation.',
            assessedByUserId: 'op-sup-joint',
            assessedByName: 'Claire Whitaker',
            assessedByRole: 'SUPERVISOR',
            assessedAt: ago(780),
            isCurrent: true,
          },
        ],
        callerStatements: [
          {
            id: 'cs-414',
            recordedAt: ago(900),
            channel: '999_SIM_VOICE',
            callerName: 'Site Foreman Patel (Synthetic)',
            callbackNumber: '+44 7700 900199',
            safeToCall: true,
            verbatimText: 'Forklift clipped a chemical tote in Bay 4, sharp fumes coming off the floor. Staff out at muster point B.',
            recordedBy: 'Marcus Vance (PJ-1088)',
          },
        ],
        operatorObservations: [],
        externalInfo: [],
        confirmedFacts: [
          {
            id: 'cf-414',
            confirmedAt: ago(720),
            confirmedBy: 'Claire Whitaker (PJ-0042)',
            factType: 'ACCESS',
            statement: 'Approach bridge confirmed 3.8m clearance; high-reach aerial vehicles prohibited.',
            sharingScope: 'SHARED_JESIP',
          },
        ],
        assignedOperatorId: 'op-disp-joint',
        ownershipLease: null,
        potentialDuplicateOfId: null,
        duplicateReviewStatus: 'NONE',
        linkedIncidentIds: [],
        commandRoles: {
          bronzeFire: 'WM Liam Bennett (Pending turnout)',
        },
        version: 1,
      },
      {
        id: 'INC-2026-0415',
        externalRef: 'CAD-AM-0415',
        title: 'Huddersfield Station Concourse — Acute Chest Pain',
        serviceScope: 'ambulance',
        leadAgency: 'ambulance',
        participatingAgencies: ['ambulance'],
        status: 'ACTIVE',
        receivingChannel: '111_TRANSFER',
        openedAt: ago(1320),
        updatedAt: ago(180),
        incidentType: 'Cardiac / Acute Chest Pain',
        reportedLocationText: 'Main Concourse Ticket Hall, Huddersfield Rail Station',
        verifiedAddress: 'St George’s Square, Huddersfield, HD1 1JB (Synthetic)',
        coordinates: { x: 675, y: 315, lat: 53.648, lon: -1.784, gridRef: 'SE 144 168' },
        locationConfidence: 'VERIFIED_EXACT',
        uncertaintyRadiusMeters: 15,
        conflictingLocations: [],
        knownHazards: ['Busy commuter concourse'],
        accessInformation: 'Ambulance bay at St George’s Square west entrance; station staff holding barrier.',
        assessmentStatus: 'ASSESSED',
        currentPriorityCode: 'CAT-A1',
        currentPriorityLabel: 'Category A1 — Immediate Life Threat',
        currentSeverityRank: 1,
        prioritySource: 'AUTHORISED_ASSESSMENT',
        assessments: [
          {
            id: 'asm-415-1',
            pathwayAdapter: 'Pennine Clinical Pathways Adapter (Prototype)',
            pathwayCategory: 'CAT-A1 — Suspected Acute Coronary / Collapse',
            priorityCode: 'CAT-A1',
            priorityLabel: 'Category A1 — Immediate Life Threat',
            severityRank: 1,
            source: 'AUTHORISED_ASSESSMENT',
            rationale: '64yo male diaphoretic, central crushing chest pain radiating to jaw, conscious.',
            assessedByUserId: 'op-clin-amb',
            assessedByName: 'Dr. Priya Patel',
            assessedByRole: 'CLINICAL_ADVISOR',
            assessedAt: ago(1260),
            isCurrent: true,
          },
        ],
        callerStatements: [
          {
            id: 'cs-415',
            recordedAt: ago(1320),
            channel: '111_TRANSFER',
            callerName: 'Station Duty Manager (Synthetic)',
            callbackNumber: '+44 7700 900315',
            safeToCall: true,
            verbatimText: 'Gentleman collapsed by platform 1 gate, grey and sweating, holding chest. Defibrillator brought to scene.',
            recordedBy: 'Sarah Jenkins (PA-4102)',
          },
        ],
        operatorObservations: [
          {
            id: 'obs-415-clin',
            recordedAt: ago(300),
            operatorId: 'op-clin-amb',
            operatorName: 'Dr. Priya Patel',
            agency: 'ambulance',
            sharingScope: 'RESTRICTED_CLINICAL',
            note: 'RESTRICTED CLINICAL: 12-lead ECG transmitted by crew shows inferior ST elevation; clinical decision to convey to Pennine Royal Infirmary PPCI lab.',
          },
        ],
        externalInfo: [],
        confirmedFacts: [
          {
            id: 'cf-415',
            confirmedAt: ago(600),
            confirmedBy: 'Sarah Jenkins (PA-4102)',
            factType: 'LOCATION',
            statement: 'Crew AMB-42 confirmed with patient inside First Aid Room.',
            sharingScope: 'AGENCY_ONLY',
          },
        ],
        assignedOperatorId: 'op-disp-amb',
        ownershipLease: {
          operatorId: 'op-disp-amb',
          operatorName: 'Sarah Jenkins',
          agency: 'ambulance',
          acquiredAt: ago(1300),
          expiresAt: ahead(1800),
        },
        potentialDuplicateOfId: null,
        duplicateReviewStatus: 'NONE',
        linkedIncidentIds: [],
        commandRoles: {
          bronzeAmbulance: 'AMB-42 Senior Paramedic',
        },
        version: 2,
      },
      {
        id: 'INC-2026-0416',
        externalRef: 'CAD-PL-0416',
        title: 'Saddleworth Ridge — Vulnerable Missing Person Search',
        serviceScope: 'police',
        leadAgency: 'police',
        participatingAgencies: ['police'],
        status: 'ASSESSED',
        receivingChannel: '999_SIM_VOICE',
        openedAt: ago(1800),
        updatedAt: ago(600),
        incidentType: 'High-Risk Missing Person',
        reportedLocationText: 'Wessenden Moor footpath south of Marsden',
        verifiedAddress: null,
        coordinates: { x: 265, y: 455, lat: 53.588, lon: -1.936, gridRef: 'SE 043 102' },
        locationConfidence: 'CELL_SECTOR_APPROX',
        uncertaintyRadiusMeters: 1800,
        conflictingLocations: [],
        knownHazards: ['Dropping moorland temperature (2C)', 'Bog terrain off marked path'],
        accessInformation: '4x4 track access from Binn Green layby.',
        assessmentStatus: 'ASSESSED',
        currentPriorityCode: 'P-PRIORITY',
        currentPriorityLabel: 'Grade 2 — Priority Police Response',
        currentSeverityRank: 2,
        prioritySource: 'AUTHORISED_ASSESSMENT',
        assessments: [
          {
            id: 'asm-416-1',
            pathwayAdapter: 'Pennine Constabulary THRIVE Prototype',
            pathwayCategory: 'Grade 2 — High-Risk Vulnerability Search',
            priorityCode: 'P-PRIORITY',
            priorityLabel: 'Grade 2 — Priority Police Response',
            severityRank: 2,
            source: 'AUTHORISED_ASSESSMENT',
            rationale: 'Overdue walker without wet-weather kit; falling dusk.',
            assessedByUserId: 'op-sup-joint',
            assessedByName: 'Claire Whitaker',
            assessedByRole: 'SUPERVISOR',
            assessedAt: ago(1700),
            isCurrent: true,
          },
        ],
        callerStatements: [
          {
            id: 'cs-416',
            recordedAt: ago(1800),
            channel: '999_SIM_VOICE',
            callerName: 'Alan Mercer (Synthetic)',
            callbackNumber: '+44 7700 900772',
            safeToCall: true,
            verbatimText: 'My brother texted at 14:30 saying he was lost in mist above Marsden Reservoir and his phone is at 4%.',
            recordedBy: 'Marcus Vance (PJ-1088)',
          },
        ],
        operatorObservations: [
          {
            id: 'obs-416-pol',
            recordedAt: ago(1200),
            operatorId: 'op-sup-joint',
            operatorName: 'Claire Whitaker',
            agency: 'police',
            sharingScope: 'RESTRICTED_POLICE',
            note: 'RESTRICTED POLICE: Welfare intelligence flag on file — family protection order requires discreet approach without siren arrival at home address.',
          },
        ],
        externalInfo: [],
        confirmedFacts: [],
        assignedOperatorId: null,
        ownershipLease: null,
        potentialDuplicateOfId: null,
        duplicateReviewStatus: 'NONE',
        linkedIncidentIds: [],
        commandRoles: {},
        version: 1,
      },
    ];

    this.resources = [
      {
        id: 'res-amb-41',
        callsign: 'AMB-41',
        service: 'ambulance',
        organisation: 'Pennine Ambulance Service',
        vehicleOrTeamType: 'Double-Crewed ALS Ambulance',
        homeStation: 'Huddersfield West Hub',
        jurisdictionZone: 'Pennine Central & M62 West',
        crew: [
          { id: 'c-1', name: 'Owen Davies', role: 'Lead Paramedic', qualifications: ['ALS_PARAMEDIC', 'BLUE_LIGHT_C1'] },
          { id: 'c-2', name: 'Nadia Hussain', role: 'EMT', qualifications: ['EMT_TRAUMA'] },
        ],
        verifiedCapabilities: ['ALS_PARAMEDIC', 'TRAUMA_IMMOBILISATION', 'PRE_ALERT_ECG'],
        equipment: ['Zoll Monitor/Defib', 'Scoop & Vacuum Mattress', 'Entonox / IV Kit'],
        operationalRestrictions: [],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 470, y: 245, lat: 53.642, lon: -1.912, gridRef: 'SE 059 161' },
        positionObservedAt: ago(12),
        positionUncertaintyMeters: 18,
        headingDegrees: 280,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
      {
        id: 'res-amb-42',
        callsign: 'AMB-42',
        service: 'ambulance',
        organisation: 'Pennine Ambulance Service',
        vehicleOrTeamType: 'Double-Crewed ALS Ambulance',
        homeStation: 'Huddersfield Central',
        jurisdictionZone: 'Pennine Central & M62 West',
        crew: [
          { id: 'c-3', name: 'Grace Ellis', role: 'Senior Paramedic', qualifications: ['ALS_PARAMEDIC'] },
          { id: 'c-4', name: 'Samir Rao', role: 'AAP', qualifications: ['AAP_CORE'] },
        ],
        verifiedCapabilities: ['ALS_PARAMEDIC', 'PRE_ALERT_ECG'],
        equipment: ['Lifepak 15', 'Carry Chair', '12-Lead Telemetry'],
        operationalRestrictions: [],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: 'asg-415-1',
        currentIncidentId: 'INC-2026-0415',
        observedPosition: { x: 676, y: 316, lat: 53.648, lon: -1.784, gridRef: 'SE 144 168' },
        positionObservedAt: ago(18),
        positionUncertaintyMeters: 15,
        headingDegrees: 90,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 2,
      },
      {
        id: 'res-amb-43',
        callsign: 'AMB-RR3',
        service: 'ambulance',
        organisation: 'Pennine Ambulance Service',
        vehicleOrTeamType: 'Solo Paramedic Rapid Response Car',
        homeStation: 'Halifax Moor Standby',
        jurisdictionZone: 'Calder & Moorland',
        crew: [
          { id: 'c-5', name: 'Tessa Pritchard', role: 'Critical Care Paramedic', qualifications: ['ALS_PARAMEDIC', 'CRITICAL_CARE'] },
        ],
        verifiedCapabilities: ['ALS_PARAMEDIC', 'CRITICAL_CARE_SOLO'],
        equipment: ['Portable Vent', 'Ultrasound Mock', 'Major Trauma Pack'],
        operationalRestrictions: ['NO_PATIENT_CONVEYANCE'],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 420, y: 170, lat: 53.671, lon: -1.931, gridRef: 'SE 046 194' },
        positionObservedAt: ago(345), // Deliberately STALE (>300s horizon)
        positionUncertaintyMeters: 420,
        headingDegrees: 195,
        communicationHealth: 'INTERMITTENT',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
      {
        id: 'res-amb-44',
        callsign: 'AMB-44',
        service: 'ambulance',
        organisation: 'Pennine Ambulance Service',
        vehicleOrTeamType: 'Double-Crewed Ambulance',
        homeStation: 'Holmfirth Stand-By',
        jurisdictionZone: 'Pennine South',
        crew: [
          { id: 'c-6', name: 'Callum Briggs', role: 'Paramedic', qualifications: ['ALS_PARAMEDIC'] },
          { id: 'c-7', name: 'Freya Cole', role: 'ECA', qualifications: ['ECA_DRIVE'] },
        ],
        verifiedCapabilities: ['ALS_PARAMEDIC'],
        equipment: ['Standard ALS Pack'],
        operationalRestrictions: [],
        staffAvailability: 'MEAL_BREAK', // Distinct staff restriction
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'STANDING_BY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 520, y: 470, lat: 53.575, lon: -1.889, gridRef: 'SE 074 087' },
        positionObservedAt: ago(25),
        positionUncertaintyMeters: 20,
        headingDegrees: 0,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
      {
        id: 'res-fire-p1',
        callsign: 'FIRE-P1',
        service: 'fire',
        organisation: 'Pennine Fire & Rescue Service',
        vehicleOrTeamType: 'Heavy Rescue Pump Ladder',
        homeStation: 'Rastrick Fire Station',
        jurisdictionZone: 'M62 & Calder District',
        crew: [
          { id: 'c-8', name: 'Liam Bennett', role: 'Watch Manager', qualifications: ['IC_LEVEL_1', 'RTC_EXTRICATION'] },
          { id: 'c-9', name: '4x Firefighters', role: 'BA / Holmatro Crew', qualifications: ['BA_ENTRY', 'RTC_EXTRICATION'] },
        ],
        verifiedCapabilities: ['RTC_EXTRICATION', 'FIRE_SUPPRESSION', 'THERMAL_IMAGING'],
        equipment: ['Holmatro Battery Spreaders', '1800L Water Tank', 'BA Sets x4'],
        operationalRestrictions: [],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 495, y: 190, lat: 53.683, lon: -1.812, gridRef: 'SE 125 208' },
        positionObservedAt: ago(14),
        positionUncertaintyMeters: 22,
        headingDegrees: 245,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
      {
        id: 'res-fire-h2',
        callsign: 'FIRE-H2',
        service: 'fire',
        organisation: 'Pennine Fire & Rescue Service',
        vehicleOrTeamType: 'Hazmat & Environmental Protection Unit',
        homeStation: 'Halifax Specialist Hub',
        jurisdictionZone: 'Whole Pennine Sector',
        crew: [
          { id: 'c-10', name: 'Kieran Shaw', role: 'Hazmat Officer', qualifications: ['HAZMAT_LEVEL_2', 'DIM_ADVISOR'] },
          { id: 'c-11', name: '2x Specialist Techs', role: 'Decontamination', qualifications: ['HAZMAT_LEVEL_2'] },
        ],
        verifiedCapabilities: ['HAZMAT_LEVEL_2', 'DECON_TENT', 'GAS_DETECTION'],
        equipment: ['Gas-tight Suits', 'Chem-ID Spectrometer', 'Bunding Mats'],
        operationalRestrictions: [],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 590, y: 160, lat: 53.698, lon: -1.848, gridRef: 'SE 101 224' },
        positionObservedAt: ago(20),
        positionUncertaintyMeters: 20,
        headingDegrees: 180,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
      {
        id: 'res-fire-alp1',
        callsign: 'FIRE-ALP1',
        service: 'fire',
        organisation: 'Pennine Fire & Rescue Service',
        vehicleOrTeamType: '32m Aerial Ladder Platform',
        homeStation: 'Huddersfield Fire Station',
        jurisdictionZone: 'Pennine Urban & Industrial',
        crew: [
          { id: 'c-12', name: 'Gareth Miles', role: 'Crew Manager', qualifications: ['ALP_OPERATOR'] },
        ],
        verifiedCapabilities: ['HIGH_REACH_RESCUE', 'WATER_TOWER'],
        equipment: ['32m Hydraulic Platform'],
        operationalRestrictions: ['HEIGHT_OVER_3.8M', 'WEIGHT_OVER_18T'],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 640, y: 345, lat: 53.642, lon: -1.801, gridRef: 'SE 132 162' },
        positionObservedAt: ago(30),
        positionUncertaintyMeters: 20,
        headingDegrees: 270,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
      {
        id: 'res-fire-p3',
        callsign: 'FIRE-P3',
        service: 'fire',
        organisation: 'Pennine Fire & Rescue Service',
        vehicleOrTeamType: 'Standard Water Tender',
        homeStation: 'Meltham Retained',
        jurisdictionZone: 'Pennine South',
        crew: [{ id: 'c-13', name: 'Retained Watch', role: 'On-Call', qualifications: ['FIRE_SUPPRESSION'] }],
        verifiedCapabilities: ['FIRE_SUPPRESSION'],
        equipment: ['Pump & Hose Reels'],
        operationalRestrictions: [],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'VOR_DEFECT',
        crewReadiness: 'NOT_READY',
        dispatchAuthorisation: 'PROHIBITED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 455, y: 445, lat: 53.591, lon: -1.855, gridRef: 'SE 096 105' },
        positionObservedAt: ago(55),
        positionUncertaintyMeters: 30,
        headingDegrees: 0,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'OUT_OF_SERVICE',
        version: 1,
      },
      {
        id: 'res-pol-irv1',
        callsign: 'POL-IRV1',
        service: 'police',
        organisation: 'Pennine Constabulary',
        vehicleOrTeamType: 'Roads & Incident Response Vehicle',
        homeStation: 'M62 Traffic Hub',
        jurisdictionZone: 'M62 & Pennine West',
        crew: [
          { id: 'c-14', name: 'PC Maya Frost', role: 'Traffic Officer', qualifications: ['FAST_ROAD_CLOSURE', 'PURSUIT_PHASE_2'] },
          { id: 'c-15', name: 'PC Tariq Mahmood', role: 'Response Officer', qualifications: ['JESIP_BRONZE'] },
        ],
        verifiedCapabilities: ['FAST_ROAD_CLOSURE', 'SCENE_CORDON', 'BREATH_TEST'],
        equipment: ['Matrix Cones & Flares', 'ANPR Terminal', 'First Aid Trauma Kit'],
        operationalRestrictions: [],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'AUTHORISED',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 390, y: 265, lat: 53.628, lon: -1.942, gridRef: 'SE 039 140' },
        positionObservedAt: ago(8),
        positionUncertaintyMeters: 12,
        headingDegrees: 315,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
      {
        id: 'res-pol-arv2',
        callsign: 'POL-ARV2',
        service: 'police',
        organisation: 'Pennine Constabulary',
        vehicleOrTeamType: 'Armed Response & Containment Unit',
        homeStation: 'Pennine Force HQ',
        jurisdictionZone: 'Force-Wide Strategic',
        crew: [
          { id: 'c-16', name: 'Sgt. Ben Hargreaves', role: 'Tactical Firearms', qualifications: ['ARV_CONTAINMENT', 'MED_TRAUMA_D13'] },
        ],
        verifiedCapabilities: ['ARV_CONTAINMENT', 'SCENE_CORDON'],
        equipment: ['Ballistic Shield', 'Trauma Pack'],
        operationalRestrictions: ['REQUIRES_FORCE_SUPERVISOR_AUTHORISATION'],
        staffAvailability: 'ON_SHIFT',
        vehicleAvailability: 'SERVICEABLE',
        crewReadiness: 'READY',
        dispatchAuthorisation: 'SUPERVISOR_HOLD',
        currentAssignmentId: null,
        currentIncidentId: null,
        observedPosition: { x: 760, y: 395, lat: 53.619, lon: -1.751, gridRef: 'SE 166 135' },
        positionObservedAt: ago(16),
        positionUncertaintyMeters: 14,
        headingDegrees: 225,
        communicationHealth: 'NOMINAL',
        maintenanceStatus: 'IN_SERVICE',
        version: 1,
      },
    ];

    for (const res of this.resources) {
      this.groundTruthPositions.set(res.id, { ...res.observedPosition });
    }

    const seededAssignment: DispatchAssignment = {
      id: 'asg-415-1',
      commandId: 'cmd-seed-415-1',
      idempotencyKey: 'idem-seed-415-1',
      incidentId: 'INC-2026-0415',
      resourceId: 'res-amb-42',
      resourceCallsign: 'AMB-42',
      service: 'ambulance',
      stage: 'AT_SCENE',
      proposedBy: 'Recommender Baseline',
      authorisedBy: 'Sarah Jenkins (PA-4102)',
      authorisedAt: ago(1240),
      commandSubmittedAt: ago(1238),
      communicationDeliveredAt: ago(1235),
      crewAcknowledgedAt: ago(1210),
      observedMovementAt: ago(1180),
      arrivedAtSceneAt: ago(610),
      furtherDispositionAt: null,
      clearedAt: null,
      expiresAt: ahead(3600),
      outcomeNote: 'Crew with patient; 12-lead ECG sent to Clinical Advisor.',
      deliveryChannel: 'MDT_PUSH_MOCK',
      routeEstimateMinutes: 7,
      routeAssumptions: 'Planning estimate only (56 km/h urban arterial avg).',
      hospitalHandover: {
        facilityId: 'hosp-pri',
        facilityName: 'Pennine Royal Infirmary',
        selectedByClinician: 'Dr. Priya Patel (PA-9014)',
        selectedAt: ago(280),
        preAlertStatus: 'PENDING',
        preAlertSentAt: null,
        arrivedAtHospitalAt: null,
        triageBriefAt: null,
        clinicalHandoverAt: null,
        trolleyTransferAt: null,
        resourceClearedAt: null,
        handoverNotes: 'Clinician selected PPCI pathway destination; awaiting pre-alert transmission.',
      },
      version: 1,
    };

    this.assignments = [seededAssignment];
    this.idempotencyRegistry.set(seededAssignment.idempotencyKey, seededAssignment);
    this.commandRegistry.set(seededAssignment.commandId, seededAssignment);

    this.communications = [
      {
        id: 'comm-1',
        incidentId: 'INC-2026-0412',
        assignmentId: null,
        resourceId: null,
        channel: 'TELEPHONY_MOCK',
        direction: 'INBOUND',
        sender: '+44 7700 900412',
        recipient: 'Pennine 999 Intake Sim',
        originalContent:
          'Caller reports two-car collision in fog near M62 J22 Windy Hill. Possible chest injury and trapped occupant.',
        lockScreenPreview: 'New incoming synthetic intake alert (review in secure console)',
        amendedFromId: null,
        amendmentNote: null,
        attemptStatus: 'SENT',
        deliveryStatus: 'DELIVERED',
        ackStatus: 'ACKNOWLEDGED',
        operationalOutcome: 'Created synthetic incident INC-2026-0412.',
        sharingScope: 'SHARED_JESIP',
        createdAt: ago(420),
      },
      {
        id: 'comm-2',
        incidentId: 'INC-2026-0415',
        assignmentId: 'asg-415-1',
        resourceId: 'res-amb-42',
        channel: 'MDT_PUSH_MOCK',
        direction: 'OUTBOUND',
        sender: 'Sarah Jenkins (PA-4102)',
        recipient: 'AMB-42',
        originalContent: 'Mobilise to Huddersfield Station Concourse — CAT-A1 Chest Pain.',
        lockScreenPreview: 'New assignment received — open MDT to view details',
        amendedFromId: null,
        amendmentNote: null,
        attemptStatus: 'SENT',
        deliveryStatus: 'DELIVERED',
        ackStatus: 'ACKNOWLEDGED',
        operationalOutcome: 'Crew acknowledged 25s after MDT delivery.',
        sharingScope: 'AGENCY_ONLY',
        createdAt: ago(1238),
      },
    ];

    this.interAgencyRequests = [];

    this.resilience = {
      connectivityDegraded: false,
      commsAdapterOutage: false,
      staleGpsSimulation: false,
      mapTilesMissing: false,
      delayedAckMode: false,
      lastBackendRestartAt: ago(3600),
      degradedNotes: [],
    };

    this.simulator = {
      seed: 20260412,
      tickCount: 0,
      running: false,
      travelTimeMultiplier: 1.0,
      simTimeIso: new Date(baseTime).toISOString(),
      groundTruthSummary: {
        activeEntities: this.resources.length,
        hiddenTruePositionsCount: this.groundTruthPositions.size,
        pendingDelayedMessages: 0,
      },
      demonstratorSteps: this.buildDemonstratorSteps(),
    };

    this.recordAudit(
      {
        id: 'system',
        name: 'Pennine Prototype Seed',
        badgeNumber: 'SYS-00',
        role: 'SUPERVISOR',
        agency: 'joint',
        mfaVerified: true,
        canViewRestrictedClinical: true,
        canViewRestrictedPolice: true,
      },
      'SEED_INITIALISED',
      'SYSTEM',
      'PENNINE-DEMO',
      'SHARED_JESIP',
      'Initialised Pennine Emergency Coordination Demonstrator with synthetic data.',
    );

    this.pushReplayFrame(
      'INTAKE',
      'INC-2026-0412',
      'Incident INC-2026-0412 opened via eCall & 999 Mock Intake',
      'Conflicting coordinates recorded between mobile cell sector and eCall frame.',
      'Marcus Vance (PJ-1088)',
    );
  }

  private buildDemonstratorSteps(): DemonstratorStep[] {
    return DEMONSTRATOR_TEMPLATE.map((t) => ({
      ...t,
      completed: this.completedDemonstratorSteps.has(t.stepNumber),
    }));
  }

  private markDemoStep(step: number): void {
    this.completedDemonstratorSteps.add(step);
    this.simulator.demonstratorSteps = this.buildDemonstratorSteps();
  }

  private recordAudit(
    actor: AuthSessionUser,
    actionType: string,
    entityType: AuditEvent['entityType'],
    entityId: string,
    sharingScope: SharingScope,
    summary: string,
    redacted = false,
  ): AuditEvent {
    this.auditSeq += 1;
    const timestamp = new Date().toISOString();
    const payload = `${this.lastHash}|${this.auditSeq}|${timestamp}|${actor.id}|${actionType}|${entityId}|${summary}`;
    const integrityHash = createHash('sha256').update(payload).digest('hex').slice(0, 16);
    this.lastHash = integrityHash;
    const entry: AuditEvent = {
      id: `aud-${this.auditSeq.toString().padStart(5, '0')}`,
      sequence: this.auditSeq,
      timestamp,
      actorId: actor.id,
      actorName: actor.name,
      actorRole: actor.role,
      actorAgency: actor.agency,
      actionType,
      entityType,
      entityId,
      sharingScope,
      summary,
      redacted,
      integrityHash,
    };
    this.auditLog.unshift(entry);
    return entry;
  }

  private pushReplayFrame(
    category: ReplayFrame['category'],
    incidentId: string,
    title: string,
    detail: string,
    actor: string,
    routeLine?: { fromX: number; fromY: number; toX: number; toY: number },
  ): void {
    const inc = this.incidents.find((i) => i.id === incidentId);
    const markers: ReplayFrame['mapMarkers'] = [];
    if (inc) {
      markers.push({
        id: inc.id,
        label: `${inc.id} (${inc.currentPriorityCode})`,
        kind: 'INCIDENT',
        x: inc.coordinates.x,
        y: inc.coordinates.y,
      });
    }
    const nowMs = Date.now();
    for (const res of this.resources) {
      const age = (nowMs - Date.parse(res.positionObservedAt)) / 1000;
      const asg = this.assignments.find((a) => a.id === res.currentAssignmentId);
      markers.push({
        id: res.id,
        label: res.callsign,
        kind: 'RESOURCE',
        x: res.observedPosition.x,
        y: res.observedPosition.y,
        stale: age > 180,
        stage: asg?.stage ?? 'AVAILABLE',
      });
    }
    for (const hosp of this.hospitals) {
      markers.push({
        id: hosp.id,
        label: hosp.name,
        kind: 'HOSPITAL',
        x: hosp.coordinates.x,
        y: hosp.coordinates.y,
      });
    }
    this.replayFrames.push({
      index: this.replayFrames.length,
      timestamp: new Date().toISOString(),
      category,
      incidentId,
      title,
      detail,
      actor,
      mapMarkers: markers,
      routeLine,
    });
  }

  getSnapshot(viewer: AuthSessionUser): ControlRoomSnapshot {
    // Enforce agency & restricted-scope redaction on observations/facts/comms/audit
    const scopedIncidents = this.incidents.map((inc) => ({
      ...inc,
      operatorObservations: inc.operatorObservations.map((obs) => {
        if (obs.sharingScope === 'RESTRICTED_CLINICAL' && !viewer.canViewRestrictedClinical) {
          return {
            ...obs,
            note: '[REDACTED — RESTRICTED CLINICAL RECORD: Authorised Clinical Advisor or Supervisor clearance required]',
          };
        }
        if (obs.sharingScope === 'RESTRICTED_POLICE' && !viewer.canViewRestrictedPolice) {
          return {
            ...obs,
            note: '[REDACTED — RESTRICTED POLICE INTELLIGENCE: Authorised Police/Supervisor clearance required]',
          };
        }
        return obs;
      }),
    }));

    const scopedComms = this.communications.map((c) => {
      if (
        (c.sharingScope === 'RESTRICTED_CLINICAL' && !viewer.canViewRestrictedClinical) ||
        (c.sharingScope === 'RESTRICTED_POLICE' && !viewer.canViewRestrictedPolice)
      ) {
        return {
          ...c,
          originalContent: `[REDACTED — ${c.sharingScope}]`,
        };
      }
      return c;
    });

    return {
      prototypeNotice: PROTOTYPE_NOTICE,
      serverTime: new Date().toISOString(),
      incidents: scopedIncidents,
      resources: structuredClone(this.resources),
      assignments: structuredClone(this.assignments),
      communications: scopedComms,
      hospitals: structuredClone(this.hospitals),
      interAgencyRequests: structuredClone(this.interAgencyRequests),
      mapHazards: structuredClone(this.mapHazards),
      serviceBoundaries: structuredClone(this.serviceBoundaries),
      auditLog: structuredClone(this.auditLog.slice(0, 120)),
      resilience: structuredClone(this.resilience),
      simulator: {
        ...this.simulator,
        groundTruthSummary: {
          activeEntities: this.resources.length,
          hiddenTruePositionsCount: this.groundTruthPositions.size,
          pendingDelayedMessages: this.pendingDelayedUpdates.length,
        },
        demonstratorSteps: this.buildDemonstratorSteps(),
      },
    };
  }

  getIncidentById(id: string): Incident | undefined {
    return this.incidents.find((i) => i.id === id);
  }

  getResources(): ResourceUnit[] {
    return this.resources;
  }

  getSimulatorMultiplier(): number {
    return this.simulator.travelTimeMultiplier;
  }

  createIncident(
    actor: AuthSessionUser,
    input: {
      title: string;
      serviceScope: ServiceType;
      incidentType: string;
      receivingChannel: Incident['receivingChannel'];
      reportedLocationText: string;
      locationConfidence: LocationConfidence;
      uncertaintyRadiusMeters: number;
      coordinates?: GeoPoint;
      callerName: string;
      callbackNumber: string;
      safeToCall: boolean;
      callerStatement: string;
      knownHazards: string[];
      accessInformation: string;
    },
  ): Incident {
    const id = `INC-2026-${(417 + this.incidents.length).toString().padStart(4, '0')}`;
    const now = new Date().toISOString();
    const coords: GeoPoint = input.coordinates ?? {
      x: 430,
      y: 280,
      lat: 53.645,
      lon: -1.91,
      gridRef: 'SE 061 164',
    };

    const leadAgency: AgencyCode = input.serviceScope === 'multi_agency' ? 'ambulance' : input.serviceScope;
    const participatingAgencies: AgencyCode[] =
      input.serviceScope === 'multi_agency' ? ['ambulance', 'fire', 'police'] : [leadAgency];

    // Check if potential duplicate exists within 80 SVG units
    const nearby = this.incidents.find(
      (existing) =>
        existing.status !== 'CLOSED' &&
        Math.hypot(existing.coordinates.x - coords.x, existing.coordinates.y - coords.y) < 75,
    );

    const newIncident: Incident = {
      id,
      externalRef: `CAD-PN-${id.slice(-4)}`,
      title: input.title,
      serviceScope: input.serviceScope,
      leadAgency,
      participatingAgencies,
      status: 'INTAKE',
      receivingChannel: input.receivingChannel,
      openedAt: now,
      updatedAt: now,
      incidentType: input.incidentType,
      reportedLocationText: input.reportedLocationText,
      verifiedAddress: input.locationConfidence === 'VERIFIED_EXACT' ? input.reportedLocationText : null,
      coordinates: coords,
      locationConfidence: input.locationConfidence,
      uncertaintyRadiusMeters: input.uncertaintyRadiusMeters,
      conflictingLocations: [],
      knownHazards: input.knownHazards,
      accessInformation: input.accessInformation,
      assessmentStatus: 'UNASSESSED',
      currentPriorityCode: 'UNASSESSED',
      currentPriorityLabel: 'Awaiting Authorised Assessment',
      currentSeverityRank: 0,
      prioritySource: 'UNASSESSED',
      assessments: [],
      callerStatements: [
        {
          id: randomUUID(),
          recordedAt: now,
          channel: input.receivingChannel,
          callerName: input.callerName,
          callbackNumber: input.callbackNumber,
          safeToCall: input.safeToCall,
          verbatimText: input.callerStatement,
          recordedBy: `${actor.name} (${actor.badgeNumber})`,
        },
      ],
      operatorObservations: [],
      externalInfo: [],
      confirmedFacts: [],
      assignedOperatorId: actor.id,
      ownershipLease: {
        operatorId: actor.id,
        operatorName: actor.name,
        agency: actor.agency,
        acquiredAt: now,
        expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      },
      potentialDuplicateOfId: nearby ? nearby.id : null,
      duplicateReviewStatus: nearby ? 'PENDING_REVIEW' : 'NONE',
      linkedIncidentIds: [],
      commandRoles: {},
      version: 1,
    };

    this.incidents.unshift(newIncident);
    this.markDemoStep(1);
    this.recordAudit(actor, 'INCIDENT_CREATED', 'INCIDENT', id, 'SHARED_JESIP', `Opened ${id}: ${input.title}`);
    this.pushReplayFrame('INTAKE', id, `Incident ${id} opened`, input.callerStatement, `${actor.name} (${actor.badgeNumber})`);
    this.emit('state:updated', { reason: 'INCIDENT_CREATED', incidentId: id });
    return newIncident;
  }

  verifyOrUpdateLocation(
    actor: AuthSessionUser,
    incidentId: string,
    payload: {
      expectedVersion: number;
      verifiedAddress: string | null;
      locationConfidence: LocationConfidence;
      uncertaintyRadiusMeters: number;
      coordinates: GeoPoint;
      factNote: string;
    },
  ): { ok: true; incident: Incident } | { ok: false; code: number; error: string; currentVersion?: number } {
    const inc = this.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };
    if (inc.version !== payload.expectedVersion) {
      return {
        ok: false,
        code: 409,
        error: `Version conflict: expected v${payload.expectedVersion}, server is v${inc.version}. Reconcile concurrent updates before saving.`,
        currentVersion: inc.version,
      };
    }

    const now = new Date().toISOString();
    inc.verifiedAddress = payload.verifiedAddress;
    inc.locationConfidence = payload.locationConfidence;
    inc.uncertaintyRadiusMeters = payload.uncertaintyRadiusMeters;
    inc.coordinates = payload.coordinates;
    inc.updatedAt = now;
    inc.version += 1;
    inc.confirmedFacts.push({
      id: randomUUID(),
      confirmedAt: now,
      confirmedBy: `${actor.name} (${actor.badgeNumber})`,
      factType: 'LOCATION',
      statement: payload.factNote,
      sharingScope: 'SHARED_JESIP',
    });

    this.markDemoStep(2);
    this.recordAudit(
      actor,
      'LOCATION_REVIEWED',
      'INCIDENT',
      inc.id,
      'SHARED_JESIP',
      `Updated location confidence to ${payload.locationConfidence} (+/-${payload.uncertaintyRadiusMeters}m): ${payload.factNote}`,
    );
    this.pushReplayFrame(
      'INTAKE',
      inc.id,
      `Location reviewed on ${inc.id}`,
      `${payload.locationConfidence} (+/-${payload.uncertaintyRadiusMeters}m): ${payload.factNote}`,
      `${actor.name} (${actor.badgeNumber})`,
    );
    this.emit('state:updated', { reason: 'LOCATION_REVIEWED', incidentId: inc.id });
    return { ok: true, incident: inc };
  }

  resolveDuplicateReview(
    actor: AuthSessionUser,
    incidentId: string,
    decision: Exclude<DuplicateReviewStatus, 'NONE' | 'PENDING_REVIEW'>,
    note: string,
  ): { ok: true; incident: Incident } | { ok: false; code: number; error: string } {
    const inc = this.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };
    const now = new Date().toISOString();
    inc.duplicateReviewStatus = decision;
    inc.updatedAt = now;
    inc.version += 1;

    if (decision === 'LINKED_RELATED' && inc.potentialDuplicateOfId) {
      if (!inc.linkedIncidentIds.includes(inc.potentialDuplicateOfId)) {
        inc.linkedIncidentIds.push(inc.potentialDuplicateOfId);
      }
      const primary = this.incidents.find((p) => p.id === inc.potentialDuplicateOfId);
      if (primary && !primary.linkedIncidentIds.includes(inc.id)) {
        primary.linkedIncidentIds.push(inc.id);
        primary.confirmedFacts.push({
          id: randomUUID(),
          confirmedAt: now,
          confirmedBy: `${actor.name} (${actor.badgeNumber})`,
          factType: 'OPERATIONAL',
          statement: `Linked duplicate report ${inc.id} preserved without silent merge: ${note}`,
          sharingScope: 'SHARED_JESIP',
        });
        primary.version += 1;
      }
      inc.status = 'RESOLVED';
    }

    inc.operatorObservations.push({
      id: randomUUID(),
      recordedAt: now,
      operatorId: actor.id,
      operatorName: actor.name,
      agency: actor.agency,
      sharingScope: 'SHARED_JESIP',
      note: `Duplicate review outcome [${decision}]: ${note}`,
    });

    this.recordAudit(actor, 'DUPLICATE_REVIEWED', 'INCIDENT', inc.id, 'SHARED_JESIP', `Duplicate review set to ${decision}: ${note}`);
    this.emit('state:updated', { reason: 'DUPLICATE_REVIEWED', incidentId: inc.id });
    return { ok: true, incident: inc };
  }

  recordAssessment(
    actor: AuthSessionUser,
    incidentId: string,
    payload: {
      expectedVersion: number;
      pathwayAdapter: string;
      pathwayCategory: string;
      priorityCode: string;
      priorityLabel: string;
      severityRank: 1 | 2 | 3 | 4;
      rationale: string;
      isOverride: boolean;
    },
  ): { ok: true; incident: Incident } | { ok: false; code: number; error: string } {
    const inc = this.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };
    if (inc.version !== payload.expectedVersion) {
      return { ok: false, code: 409, error: `Version conflict: expected v${payload.expectedVersion}, server is v${inc.version}.` };
    }
    if (payload.isOverride && actor.role !== 'SUPERVISOR' && actor.role !== 'CLINICAL_ADVISOR') {
      return {
        ok: false,
        code: 403,
        error: 'Only Supervisor or Clinical Advisor roles may perform a priority override.',
      };
    }

    const now = new Date().toISOString();
    for (const prev of inc.assessments) {
      if (prev.isCurrent) {
        prev.isCurrent = false;
        prev.supersededReason = payload.isOverride ? 'Supervisor/Clinical Override' : 'Reassessment recorded';
      }
    }

    const record: AssessmentRecord = {
      id: randomUUID(),
      pathwayAdapter: payload.pathwayAdapter,
      pathwayCategory: payload.pathwayCategory,
      priorityCode: payload.priorityCode,
      priorityLabel: payload.priorityLabel,
      severityRank: payload.severityRank,
      source: payload.isOverride ? 'SUPERVISOR_OVERRIDE' : 'AUTHORISED_ASSESSMENT',
      rationale: payload.rationale,
      assessedByUserId: actor.id,
      assessedByName: actor.name,
      assessedByRole: actor.role,
      assessedAt: now,
      isCurrent: true,
    };

    inc.assessments.unshift(record);
    inc.assessmentStatus = 'ASSESSED';
    inc.reassessmentReason = undefined;
    inc.currentPriorityCode = payload.priorityCode;
    inc.currentPriorityLabel = payload.priorityLabel;
    inc.currentSeverityRank = payload.severityRank;
    inc.prioritySource = record.source;
    if (inc.status === 'INTAKE') inc.status = 'ASSESSED';
    inc.updatedAt = now;
    inc.version += 1;

    this.markDemoStep(3);
    this.markDemoStep(4);
    this.recordAudit(
      actor,
      payload.isOverride ? 'PRIORITY_OVERRIDDEN' : 'ASSESSMENT_RECORDED',
      'ASSESSMENT',
      inc.id,
      'SHARED_JESIP',
      `Priority set to ${payload.priorityCode} (${record.source}): ${payload.rationale}`,
    );
    this.pushReplayFrame(
      'ASSESSMENT',
      inc.id,
      `Priority ${payload.priorityCode} recorded`,
      `${record.source} via ${payload.pathwayAdapter}: ${payload.rationale}`,
      `${actor.name} (${actor.badgeNumber})`,
    );
    this.emit('state:updated', { reason: 'ASSESSMENT_RECORDED', incidentId: inc.id });
    return { ok: true, incident: inc };
  }

  flagCircumstanceChange(
    actor: AuthSessionUser,
    incidentId: string,
    note: string,
    sharingScope: SharingScope,
  ): { ok: true; incident: Incident } | { ok: false; code: number; error: string } {
    const inc = this.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };
    const now = new Date().toISOString();
    inc.assessmentStatus = 'REASSESSMENT_REQUIRED';
    inc.reassessmentReason = note;
    inc.updatedAt = now;
    inc.version += 1;
    inc.operatorObservations.push({
      id: randomUUID(),
      recordedAt: now,
      operatorId: actor.id,
      operatorName: actor.name,
      agency: actor.agency,
      sharingScope,
      note: `Circumstance change flagged — Reassessment task created: ${note}`,
    });

    this.recordAudit(actor, 'REASSESSMENT_FLAGGED', 'ASSESSMENT', inc.id, sharingScope, `Flagged reassessment: ${note}`);
    this.emit('state:updated', { reason: 'REASSESSMENT_FLAGGED', incidentId: inc.id });
    return { ok: true, incident: inc };
  }

  manageOwnershipLease(
    actor: AuthSessionUser,
    incidentId: string,
    action: 'ACQUIRE' | 'RELEASE' | 'HANDOVER_REQUEST' | 'ACCEPT_HANDOVER' | 'SUPERVISOR_TAKEOVER',
    targetOperatorId?: string,
  ): { ok: true; incident: Incident } | { ok: false; code: number; error: string } {
    const inc = this.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };
    const now = new Date().toISOString();

    if (action === 'ACQUIRE') {
      if (
        inc.ownershipLease &&
        inc.ownershipLease.operatorId !== actor.id &&
        Date.parse(inc.ownershipLease.expiresAt) > Date.now()
      ) {
        return {
          ok: false,
          code: 409,
          error: `Incident currently owned by ${inc.ownershipLease.operatorName} until ${inc.ownershipLease.expiresAt}. Request handover or supervisor takeover.`,
        };
      }
      inc.ownershipLease = {
        operatorId: actor.id,
        operatorName: actor.name,
        agency: actor.agency,
        acquiredAt: now,
        expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      };
      inc.assignedOperatorId = actor.id;
    } else if (action === 'RELEASE') {
      // Releasing an expired/active lease NEVER deletes or closes the incident
      if (inc.ownershipLease && inc.ownershipLease.operatorId === actor.id) {
        inc.ownershipLease = null;
      }
    } else if (action === 'HANDOVER_REQUEST') {
      if (!inc.ownershipLease || inc.ownershipLease.operatorId !== actor.id) {
        return { ok: false, code: 403, error: 'Only current incident owner can initiate controlled handover.' };
      }
      inc.ownershipLease.handoverPendingTo = targetOperatorId ?? 'Available Supervisor';
    } else if (action === 'ACCEPT_HANDOVER' || action === 'SUPERVISOR_TAKEOVER') {
      if (action === 'SUPERVISOR_TAKEOVER' && actor.role !== 'SUPERVISOR') {
        return { ok: false, code: 403, error: 'Only a Supervisor can force ownership takeover.' };
      }
      inc.ownershipLease = {
        operatorId: actor.id,
        operatorName: actor.name,
        agency: actor.agency,
        acquiredAt: now,
        expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      };
      inc.assignedOperatorId = actor.id;
    }

    inc.updatedAt = now;
    inc.version += 1;
    this.recordAudit(actor, `OWNERSHIP_${action}`, 'INCIDENT', inc.id, 'SHARED_JESIP', `Ownership action ${action} by ${actor.name}`);
    this.emit('state:updated', { reason: `OWNERSHIP_${action}`, incidentId: inc.id });
    return { ok: true, incident: inc };
  }

  submitDispatch(
    actor: AuthSessionUser,
    payload: {
      incidentId: string;
      resourceId: string;
      idempotencyKey: string;
      commandId?: string;
      expectedIncidentVersion: number;
      expectedResourceVersion: number;
      deliveryChannel?: DispatchAssignment['deliveryChannel'];
      simulateTimeout?: boolean;
    },
  ):
    | { ok: true; assignment: DispatchAssignment; idempotentReplay: boolean; timedOutQueryRequired?: boolean }
    | { ok: false; code: number; error: string } {
    // Idempotency guard: if this idempotencyKey already executed, return existing assignment
    const existingByIdem = this.idempotencyRegistry.get(payload.idempotencyKey);
    if (existingByIdem) {
      return { ok: true, assignment: existingByIdem, idempotentReplay: true };
    }

    const inc = this.incidents.find((i) => i.id === payload.incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };
    const res = this.resources.find((r) => r.id === payload.resourceId);
    if (!res) return { ok: false, code: 404, error: 'Resource not found' };

    if (inc.version !== payload.expectedIncidentVersion) {
      return {
        ok: false,
        code: 409,
        error: `Incident version mismatch (expected v${payload.expectedIncidentVersion}, current v${inc.version}). Refresh and reconcile.`,
      };
    }
    if (res.version !== payload.expectedResourceVersion) {
      return {
        ok: false,
        code: 409,
        error: `Resource version mismatch (expected v${payload.expectedResourceVersion}, current v${res.version}). Concurrent assignment detected.`,
      };
    }

    if (res.currentAssignmentId !== null) {
      return {
        ok: false,
        code: 409,
        error: `Resource ${res.callsign} is already assigned to ${res.currentIncidentId}. Cannot double-assign.`,
      };
    }

    if (
      res.staffAvailability !== 'ON_SHIFT' ||
      res.vehicleAvailability !== 'SERVICEABLE' ||
      res.crewReadiness !== 'READY' ||
      res.dispatchAuthorisation !== 'AUTHORISED' ||
      res.maintenanceStatus === 'OUT_OF_SERVICE'
    ) {
      return {
        ok: false,
        code: 409,
        error: `Resource ${res.callsign} fails hard availability/authorisation gate (${res.staffAvailability} / ${res.vehicleAvailability} / ${res.crewReadiness} / ${res.dispatchAuthorisation}).`,
      };
    }

    const now = new Date().toISOString();
    const commandId = payload.commandId ?? randomUUID();
    const commsFailed = this.resilience.commsAdapterOutage || res.communicationHealth === 'NO_COMMS';
    const delayed = this.resilience.delayedAckMode || payload.simulateTimeout;

    const stage: DispatchStage = commsFailed
      ? 'OUTCOME_UNKNOWN'
      : delayed
        ? 'DISPATCH_SUBMITTED'
        : 'DELIVERED_CONFIRMED';

    const dx = inc.coordinates.x - res.observedPosition.x;
    const dy = inc.coordinates.y - res.observedPosition.y;
    const estMin = Math.max(2, Math.round(((Math.hypot(dx, dy) * 0.042) / 54) * 60 * this.simulator.travelTimeMultiplier));

    const assignment: DispatchAssignment = {
      id: `asg-${randomUUID().slice(0, 8)}`,
      commandId,
      idempotencyKey: payload.idempotencyKey,
      incidentId: inc.id,
      resourceId: res.id,
      resourceCallsign: res.callsign,
      service: res.service,
      stage,
      proposedBy: 'Recommender / Operator Selection',
      authorisedBy: `${actor.name} (${actor.badgeNumber})`,
      authorisedAt: now,
      commandSubmittedAt: now,
      communicationDeliveredAt: stage === 'DELIVERED_CONFIRMED' ? now : null,
      crewAcknowledgedAt: null, // NEVER auto-marked acknowledged on network delivery!
      observedMovementAt: null,
      arrivedAtSceneAt: null,
      furtherDispositionAt: null,
      clearedAt: null,
      expiresAt: new Date(Date.now() + 300_000).toISOString(),
      outcomeNote: commsFailed
        ? 'Comms adapter outage: command submitted, delivery unknown — query outcome or use voice fallback.'
        : delayed
          ? 'Dispatch submitted; delivery confirmation delayed — query command ID rather than re-dispatching.'
          : 'Delivered to responder MDT. Awaiting explicit crew acknowledgement.',
      deliveryChannel: payload.deliveryChannel ?? 'MDT_PUSH_MOCK',
      routeEstimateMinutes: estMin,
      routeAssumptions: `Planning estimate only (x${this.simulator.travelTimeMultiplier.toFixed(1)} factor; no turn-by-turn instruction).`,
      version: 1,
    };

    // Transactional update of resource + incident + registries
    this.assignments.unshift(assignment);
    this.idempotencyRegistry.set(payload.idempotencyKey, assignment);
    this.commandRegistry.set(commandId, assignment);

    res.currentAssignmentId = assignment.id;
    res.currentIncidentId = inc.id;
    res.version += 1;

    if (inc.status === 'INTAKE' || inc.status === 'ASSESSED') {
      inc.status = 'DISPATCHING';
    }
    inc.updatedAt = now;
    inc.version += 1;

    this.communications.unshift({
      id: `comm-${randomUUID().slice(0, 8)}`,
      incidentId: inc.id,
      assignmentId: assignment.id,
      resourceId: res.id,
      channel: assignment.deliveryChannel === 'AIRWAVE_RADIO_MOCK' ? 'AIRWAVE_RADIO_MOCK' : 'MDT_PUSH_MOCK',
      direction: 'OUTBOUND',
      sender: `${actor.name} (${actor.badgeNumber})`,
      recipient: res.callsign,
      originalContent: `Dispatch ${res.callsign} to ${inc.id} (${inc.currentPriorityCode}): ${inc.reportedLocationText}`,
      lockScreenPreview: `Priority mobilisation alert — open secure MDT to view`,
      amendedFromId: null,
      amendmentNote: null,
      attemptStatus: commsFailed ? 'FAILED_LINK' : 'SENT',
      deliveryStatus: stage === 'DELIVERED_CONFIRMED' ? 'DELIVERED' : commsFailed ? 'UNDELIVERABLE' : 'PENDING',
      ackStatus: 'NONE',
      operationalOutcome: assignment.outcomeNote,
      sharingScope: 'AGENCY_ONLY',
      createdAt: now,
    });

    this.markDemoStep(5);
    this.recordAudit(
      actor,
      'DISPATCH_SUBMITTED',
      'DISPATCH',
      assignment.id,
      'AGENCY_ONLY',
      `Authorised & submitted ${res.callsign} to ${inc.id} [cmd:${commandId}] -> stage ${stage}`,
    );
    this.pushReplayFrame(
      'DISPATCH',
      inc.id,
      `${res.callsign} dispatched to ${inc.id}`,
      assignment.outcomeNote,
      `${actor.name} (${actor.badgeNumber})`,
      { fromX: res.observedPosition.x, fromY: res.observedPosition.y, toX: inc.coordinates.x, toY: inc.coordinates.y },
    );
    this.emit('state:updated', { reason: 'DISPATCH_SUBMITTED', assignmentId: assignment.id });

    return {
      ok: true,
      assignment,
      idempotentReplay: false,
      timedOutQueryRequired: Boolean(payload.simulateTimeout),
    };
  }

  queryCommandOutcome(commandId: string): DispatchAssignment | null {
    return this.commandRegistry.get(commandId) ?? null;
  }

  updateAssignmentStage(
    actor: AuthSessionUser,
    assignmentId: string,
    payload: {
      stage: DispatchStage;
      note: string;
      expectedVersion?: number;
      delayed?: boolean;
    },
  ): { ok: true; assignment: DispatchAssignment; queuedDelayed?: boolean } | { ok: false; code: number; error: string } {
    const asg = this.assignments.find((a) => a.id === assignmentId);
    if (!asg) return { ok: false, code: 404, error: 'Assignment not found' };

    if (payload.expectedVersion !== undefined && asg.version !== payload.expectedVersion) {
      return { ok: false, code: 409, error: `Assignment version conflict (expected v${payload.expectedVersion}, current v${asg.version}).` };
    }

    if (payload.delayed) {
      this.pendingDelayedUpdates.push({
        id: randomUUID(),
        deliverAtTick: this.simulator.tickCount + 2,
        assignmentId: asg.id,
        targetStage: payload.stage,
        note: payload.note,
      });
      this.recordAudit(
        actor,
        'STATUS_UPDATE_DELAYED',
        'DISPATCH',
        asg.id,
        'AGENCY_ONLY',
        `Queued delayed status update (${payload.stage}) due to radio/MDT buffering.`,
      );
      this.emit('state:updated', { reason: 'STATUS_DELAYED', assignmentId: asg.id });
      return { ok: true, assignment: asg, queuedDelayed: true };
    }

    const res = this.resources.find((r) => r.id === asg.resourceId);
    const inc = this.incidents.find((i) => i.id === asg.incidentId);
    const now = new Date().toISOString();

    asg.stage = payload.stage;
    asg.outcomeNote = payload.note;
    asg.version += 1;

    switch (payload.stage) {
      case 'DELIVERED_CONFIRMED':
        asg.communicationDeliveredAt = now;
        break;
      case 'CREW_ACKNOWLEDGED':
        asg.communicationDeliveredAt ??= now;
        asg.crewAcknowledgedAt = now;
        this.markDemoStep(6);
        break;
      case 'EN_ROUTE':
        asg.crewAcknowledgedAt ??= now;
        asg.observedMovementAt = now;
        if (inc && inc.status === 'DISPATCHING') inc.status = 'ACTIVE';
        this.markDemoStep(7);
        break;
      case 'AT_SCENE':
        asg.arrivedAtSceneAt = now;
        if (res && inc) {
          res.observedPosition = { ...inc.coordinates };
          res.positionObservedAt = now;
          this.groundTruthPositions.set(res.id, { ...inc.coordinates });
        }
        if (inc && inc.status !== 'RESOLVED' && inc.status !== 'CLOSED') inc.status = 'ACTIVE';
        this.markDemoStep(7);
        break;
      case 'FURTHER_DISPOSITION_RECORDED':
        asg.furtherDispositionAt = now;
        if (inc) inc.status = 'HANDOVER';
        break;
      case 'CLEAR':
        asg.clearedAt = now;
        if (res) {
          res.currentAssignmentId = null;
          res.currentIncidentId = null;
          res.version += 1;
        }
        if (asg.hospitalHandover) {
          asg.hospitalHandover.resourceClearedAt = now;
        }
        this.markDemoStep(12);
        break;
      case 'REJECTED':
      case 'WITHDRAWN':
      case 'CANCELLED':
        if (res) {
          res.currentAssignmentId = null;
          res.currentIncidentId = null;
          res.version += 1;
          if (payload.stage === 'REJECTED') {
            res.crewReadiness = 'NOT_READY';
          }
        }
        this.markDemoStep(10);
        break;
    }

    if (inc) {
      inc.updatedAt = now;
      inc.version += 1;
    }

    // Record comms outcome if crew acknowledged or rejected
    if (payload.stage === 'CREW_ACKNOWLEDGED' || payload.stage === 'REJECTED') {
      this.communications.unshift({
        id: `comm-${randomUUID().slice(0, 8)}`,
        incidentId: asg.incidentId,
        assignmentId: asg.id,
        resourceId: asg.resourceId,
        channel: 'MDT_PUSH_MOCK',
        direction: 'INBOUND',
        sender: asg.resourceCallsign,
        recipient: 'Pennine Control',
        originalContent: `${asg.resourceCallsign} ${payload.stage === 'CREW_ACKNOWLEDGED' ? 'ACKNOWLEDGED' : 'REJECTED'} assignment ${asg.incidentId}: ${payload.note}`,
        lockScreenPreview: 'Responder status response received',
        amendedFromId: null,
        amendmentNote: null,
        attemptStatus: 'SENT',
        deliveryStatus: 'DELIVERED',
        ackStatus: payload.stage === 'CREW_ACKNOWLEDGED' ? 'ACKNOWLEDGED' : 'REJECTED',
        operationalOutcome: payload.note,
        sharingScope: 'AGENCY_ONLY',
        createdAt: now,
      });
    }

    this.recordAudit(
      actor,
      `ASSIGNMENT_${payload.stage}`,
      'DISPATCH',
      asg.id,
      'AGENCY_ONLY',
      `${asg.resourceCallsign} -> ${payload.stage}: ${payload.note}`,
    );
    this.pushReplayFrame(
      payload.stage === 'CLEAR' ? 'RESOLUTION' : 'DISPATCH',
      asg.incidentId,
      `${asg.resourceCallsign} ${payload.stage}`,
      payload.note,
      `${actor.name} (${actor.badgeNumber})`,
    );
    this.emit('state:updated', { reason: `ASSIGNMENT_${payload.stage}`, assignmentId: asg.id });
    return { ok: true, assignment: asg };
  }

  updateResourceStatus(
    actor: AuthSessionUser,
    resourceId: string,
    patch: Partial<
      Pick<
        ResourceUnit,
        'staffAvailability' | 'vehicleAvailability' | 'crewReadiness' | 'dispatchAuthorisation' | 'communicationHealth' | 'maintenanceStatus'
      >
    > & { reason: string },
  ): { ok: true; resource: ResourceUnit } | { ok: false; code: number; error: string } {
    const res = this.resources.find((r) => r.id === resourceId);
    if (!res) return { ok: false, code: 404, error: 'Resource not found' };
    if (patch.dispatchAuthorisation && actor.role !== 'SUPERVISOR' && actor.role !== 'DISPATCHER') {
      return { ok: false, code: 403, error: 'Unauthorised to change dispatch authorisation.' };
    }

    if (patch.staffAvailability) res.staffAvailability = patch.staffAvailability;
    if (patch.vehicleAvailability) res.vehicleAvailability = patch.vehicleAvailability;
    if (patch.crewReadiness) res.crewReadiness = patch.crewReadiness;
    if (patch.dispatchAuthorisation) res.dispatchAuthorisation = patch.dispatchAuthorisation;
    if (patch.communicationHealth) res.communicationHealth = patch.communicationHealth;
    if (patch.maintenanceStatus) res.maintenanceStatus = patch.maintenanceStatus;
    res.version += 1;

    this.recordAudit(actor, 'RESOURCE_STATUS_UPDATED', 'RESOURCE', res.id, 'AGENCY_ONLY', `${res.callsign} updated: ${patch.reason}`);
    this.emit('state:updated', { reason: 'RESOURCE_UPDATED', resourceId: res.id });
    return { ok: true, resource: res };
  }

  createInterAgencyRequest(
    actor: AuthSessionUser,
    payload: {
      incidentId: string;
      requestedAgency: AgencyCode;
      requestedCapability: string;
      rationale: string;
      sharingScope: SharingScope;
    },
  ): { ok: true; request: InterAgencyRequest } | { ok: false; code: number; error: string } {
    const inc = this.incidents.find((i) => i.id === payload.incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };

    const now = new Date().toISOString();
    const reqObj: InterAgencyRequest = {
      id: `iar-${randomUUID().slice(0, 8)}`,
      incidentId: inc.id,
      requestingAgency: actor.agency,
      requestedAgency: payload.requestedAgency,
      requestedCapability: payload.requestedCapability,
      rationale: payload.rationale,
      sharingScope: payload.sharingScope,
      status: 'REQUESTED',
      requestedBy: `${actor.name} (${actor.badgeNumber})`,
      requestedAt: now,
      respondedBy: null,
      respondedAt: null,
      responseNote: null,
    };

    this.interAgencyRequests.unshift(reqObj);
    if (!inc.participatingAgencies.includes(payload.requestedAgency)) {
      inc.participatingAgencies.push(payload.requestedAgency);
      inc.serviceScope = 'multi_agency';
    }
    inc.updatedAt = now;
    inc.version += 1;

    this.markDemoStep(9);
    this.recordAudit(
      actor,
      'INTER_AGENCY_REQUESTED',
      'INCIDENT',
      inc.id,
      payload.sharingScope,
      `Requested ${payload.requestedAgency.toUpperCase()} (${payload.requestedCapability}) without assuming command: ${payload.rationale}`,
    );
    this.pushReplayFrame(
      'MULTI_AGENCY',
      inc.id,
      `JESIP Assistance Requested (${payload.requestedAgency.toUpperCase()})`,
      `${payload.requestedCapability}: ${payload.rationale}`,
      `${actor.name} (${actor.badgeNumber})`,
    );
    this.emit('state:updated', { reason: 'INTER_AGENCY_REQUESTED', incidentId: inc.id });
    return { ok: true, request: reqObj };
  }

  respondInterAgencyRequest(
    actor: AuthSessionUser,
    requestId: string,
    status: 'ACKNOWLEDGED' | 'RESOURCES_COMMITTED' | 'DECLINED',
    responseNote: string,
  ): { ok: true; request: InterAgencyRequest } | { ok: false; code: number; error: string } {
    const reqObj = this.interAgencyRequests.find((r) => r.id === requestId);
    if (!reqObj) return { ok: false, code: 404, error: 'Request not found' };
    if (actor.agency !== 'joint' && actor.agency !== reqObj.requestedAgency && actor.role !== 'SUPERVISOR') {
      return {
        ok: false,
        code: 403,
        error: `Only ${reqObj.requestedAgency.toUpperCase()} or Joint Supervisor may commit/decline ${reqObj.requestedAgency.toUpperCase()} agency assistance.`,
      };
    }
    reqObj.status = status;
    reqObj.respondedBy = `${actor.name} (${actor.badgeNumber})`;
    reqObj.respondedAt = new Date().toISOString();
    reqObj.responseNote = responseNote;

    this.recordAudit(actor, `INTER_AGENCY_${status}`, 'INCIDENT', reqObj.incidentId, reqObj.sharingScope, `${reqObj.requestedAgency.toUpperCase()} response: ${responseNote}`);
    this.emit('state:updated', { reason: 'INTER_AGENCY_RESPONDED', requestId });
    return { ok: true, request: reqObj };
  }

  updateHospitalHandover(
    actor: AuthSessionUser,
    assignmentId: string,
    action:
      | 'SELECT_DESTINATION'
      | 'SEND_PRE_ALERT'
      | 'RECORD_HOSPITAL_ARRIVAL'
      | 'TRIAGE_BRIEF'
      | 'CLINICAL_HANDOVER'
      | 'TROLLEY_TRANSFER',
    facilityId?: string,
    notes?: string,
  ): { ok: true; assignment: DispatchAssignment } | { ok: false; code: number; error: string } {
    const asg = this.assignments.find((a) => a.id === assignmentId);
    if (!asg) return { ok: false, code: 404, error: 'Assignment not found' };
    if (asg.service !== 'ambulance') return { ok: false, code: 400, error: 'Hospital handover applies to ambulance assignments.' };

    const now = new Date().toISOString();
    if (action === 'SELECT_DESTINATION') {
      const fac = this.hospitals.find((h) => h.id === facilityId);
      if (!fac) return { ok: false, code: 404, error: 'Authorised facility not found' };
      asg.hospitalHandover = {
        facilityId: fac.id,
        facilityName: fac.name,
        selectedByClinician: `${actor.name} (${actor.badgeNumber})`,
        selectedAt: now,
        preAlertStatus: 'PENDING',
        preAlertSentAt: null,
        arrivedAtHospitalAt: null,
        triageBriefAt: null,
        clinicalHandoverAt: null,
        trolleyTransferAt: null,
        resourceClearedAt: null,
        handoverNotes: notes ?? 'Clinician-selected destination from authorised directory.',
      };
      asg.stage = 'FURTHER_DISPOSITION_RECORDED';
      asg.furtherDispositionAt = now;
    } else {
      if (!asg.hospitalHandover) return { ok: false, code: 400, error: 'Select destination facility first.' };
      if (action === 'SEND_PRE_ALERT') {
        asg.hospitalHandover.preAlertStatus = 'SENT';
        asg.hospitalHandover.preAlertSentAt = now;
      } else if (action === 'RECORD_HOSPITAL_ARRIVAL') {
        // CRITICAL RULE: Arrival does NOT auto-complete handover or clear crew!
        asg.hospitalHandover.arrivedAtHospitalAt = now;
        const res = this.resources.find((r) => r.id === asg.resourceId);
        const fac = this.hospitals.find((h) => h.id === asg.hospitalHandover?.facilityId);
        if (res && fac) {
          res.observedPosition = { ...fac.coordinates };
          res.positionObservedAt = now;
        }
      } else if (action === 'TRIAGE_BRIEF') {
        asg.hospitalHandover.triageBriefAt = now;
      } else if (action === 'CLINICAL_HANDOVER') {
        asg.hospitalHandover.clinicalHandoverAt = now;
      } else if (action === 'TROLLEY_TRANSFER') {
        asg.hospitalHandover.trolleyTransferAt = now;
        const inc = this.incidents.find((i) => i.id === asg.incidentId);
        if (inc) inc.status = 'RESOLVED';
      }
      if (notes) asg.hospitalHandover.handoverNotes = notes;
    }
    asg.version += 1;

    this.markDemoStep(11);
    this.recordAudit(actor, `HOSPITAL_${action}`, 'HOSPITAL', asg.id, 'RESTRICTED_CLINICAL', `${asg.resourceCallsign} handover milestone ${action}`);
    this.pushReplayFrame('HANDOVER', asg.incidentId, `Hospital milestone: ${action}`, `${asg.resourceCallsign} at ${asg.hospitalHandover?.facilityName}`, actor.name);
    this.emit('state:updated', { reason: `HOSPITAL_${action}`, assignmentId: asg.id });
    return { ok: true, assignment: asg };
  }

  resolveIncident(actor: AuthSessionUser, incidentId: string, resolutionSummary: string): { ok: true; incident: Incident } | { ok: false; code: number; error: string } {
    const inc = this.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, code: 404, error: 'Incident not found' };

    const activeAssignments = this.assignments.filter(
      (a) =>
        a.incidentId === inc.id &&
        !['CLEAR', 'REJECTED', 'WITHDRAWN', 'CANCELLED'].includes(a.stage),
    );
    if (activeAssignments.length > 0) {
      return {
        ok: false,
        code: 409,
        error: `${activeAssignments.length} resource(s) still active on ${inc.id}. Clear or withdraw all resources explicitly before closing.`,
      };
    }

    const now = new Date().toISOString();
    inc.status = 'CLOSED';
    inc.updatedAt = now;
    inc.version += 1;
    inc.confirmedFacts.push({
      id: randomUUID(),
      confirmedAt: now,
      confirmedBy: `${actor.name} (${actor.badgeNumber})`,
      factType: 'OPERATIONAL',
      statement: `Incident closed: ${resolutionSummary}`,
      sharingScope: 'SHARED_JESIP',
    });

    this.markDemoStep(11);
    this.markDemoStep(12);
    this.recordAudit(actor, 'INCIDENT_CLOSED', 'INCIDENT', inc.id, 'SHARED_JESIP', resolutionSummary);
    this.pushReplayFrame('RESOLUTION', inc.id, `Incident ${inc.id} closed`, resolutionSummary, actor.name);
    this.emit('state:updated', { reason: 'INCIDENT_CLOSED', incidentId: inc.id });
    return { ok: true, incident: inc };
  }

  sendCommunication(
    actor: AuthSessionUser,
    payload: {
      incidentId: string | null;
      resourceId: string | null;
      channel: CommunicationRecord['channel'];
      recipient: string;
      content: string;
      sharingScope: SharingScope;
      amendedFromId?: string | null;
      amendmentNote?: string | null;
    },
  ): CommunicationRecord {
    const now = new Date().toISOString();
    const outage = this.resilience.commsAdapterOutage;
    const rec: CommunicationRecord = {
      id: `comm-${randomUUID().slice(0, 8)}`,
      incidentId: payload.incidentId,
      assignmentId: null,
      resourceId: payload.resourceId,
      channel: payload.channel,
      direction: 'OUTBOUND',
      sender: `${actor.name} (${actor.badgeNumber})`,
      recipient: payload.recipient,
      originalContent: payload.content,
      lockScreenPreview:
        payload.sharingScope === 'SHARED_JESIP'
          ? 'Operational message received — open secure console'
          : 'Restricted operational message — sign in to view',
      amendedFromId: payload.amendedFromId ?? null,
      amendmentNote: payload.amendmentNote ?? null,
      attemptStatus: outage ? 'FAILED_LINK' : 'SENT',
      deliveryStatus: outage ? 'UNDELIVERABLE' : 'DELIVERED',
      ackStatus: 'NONE',
      operationalOutcome: outage ? 'Failed during simulated comms adapter outage' : 'Delivered to mock adapter',
      sharingScope: payload.sharingScope,
      createdAt: now,
    };
    this.communications.unshift(rec);
    this.recordAudit(actor, 'COMMUNICATION_SENT', 'COMMUNICATION', rec.id, payload.sharingScope, `Sent ${payload.channel} to ${payload.recipient}`);
    if (payload.incidentId) {
      this.pushReplayFrame('COMMS', payload.incidentId, `${payload.channel} -> ${payload.recipient}`, payload.content, actor.name);
    }
    this.emit('state:updated', { reason: 'COMM_SENT', commId: rec.id });
    return rec;
  }

  setResilienceFlags(actor: AuthSessionUser, patch: Partial<ResilienceFlags>): ResilienceFlags {
    Object.assign(this.resilience, patch);
    if (patch.staleGpsSimulation) {
      const staleTime = new Date(Date.now() - 380_000).toISOString();
      for (const res of this.resources) {
        if (res.id === 'res-amb-41' || res.id === 'res-fire-p1') {
          res.positionObservedAt = staleTime;
        }
      }
    }
    this.resilience.degradedNotes = [];
    if (this.resilience.connectivityDegraded) this.resilience.degradedNotes.push('Control-room network link degraded — cached assignments read-only; follow continuity workflow.');
    if (this.resilience.commsAdapterOutage) this.resilience.degradedNotes.push('MDT/SMS gateway outage — use voice radio fallback and manual reconciliation.');
    if (this.resilience.staleGpsSimulation) this.resilience.degradedNotes.push('AVL GPS telemetry feed delayed >300s — positions marked STALE; extrapolation halted.');
    if (this.resilience.mapTilesMissing) this.resilience.degradedNotes.push('Base map tile layer unavailable — vector grid & coordinate fallback active.');
    if (this.resilience.delayedAckMode) this.resilience.degradedNotes.push('High latency on responder acknowledgements — query command ID on timeout.');

    this.recordAudit(actor, 'RESILIENCE_MODE_UPDATED', 'SYSTEM', 'RESILIENCE', 'SHARED_JESIP', `Updated resilience flags: ${JSON.stringify(patch)}`);
    this.emit('state:updated', { reason: 'RESILIENCE_UPDATED' });
    return this.resilience;
  }

  stepSimulator(actor: AuthSessionUser, travelTimeMultiplier?: number): SimulatorStatus {
    if (travelTimeMultiplier !== undefined) {
      this.simulator.travelTimeMultiplier = Math.max(0.5, Math.min(3.0, travelTimeMultiplier));
    }
    this.simulator.tickCount += 1;
    const tick = this.simulator.tickCount;
    const simNow = new Date(Date.now() + tick * 30_000).toISOString();
    this.simulator.simTimeIso = simNow;

    // Deterministic seeded movement of EN_ROUTE units toward incident in ground truth
    for (const asg of this.assignments) {
      if (asg.stage === 'EN_ROUTE') {
        const res = this.resources.find((r) => r.id === asg.resourceId);
        const inc = this.incidents.find((i) => i.id === asg.incidentId);
        if (res && inc) {
          const gt = this.groundTruthPositions.get(res.id) ?? { ...res.observedPosition };
          const dx = inc.coordinates.x - gt.x;
          const dy = inc.coordinates.y - gt.y;
          const dist = Math.hypot(dx, dy);
          if (dist > 12) {
            const step = Math.min(dist, 28 / this.simulator.travelTimeMultiplier);
            const nextGt: GeoPoint = {
              ...gt,
              x: Math.round(gt.x + (dx / dist) * step),
              y: Math.round(gt.y + (dy / dist) * step),
            };
            this.groundTruthPositions.set(res.id, nextGt);
            if (!this.resilience.staleGpsSimulation) {
              res.observedPosition = { ...nextGt };
              res.positionObservedAt = new Date().toISOString();
            }
          }
        }
      }
    }

    // Flush delayed updates whose tick arrived
    const due = this.pendingDelayedUpdates.filter((u) => u.deliverAtTick <= tick);
    this.pendingDelayedUpdates = this.pendingDelayedUpdates.filter((u) => u.deliverAtTick > tick);
    for (const item of due) {
      this.updateAssignmentStage(actor, item.assignmentId, {
        stage: item.targetStage,
        note: `[DELAYED UPDATE RECONCILED AT TICK ${tick}] ${item.note}`,
      });
      this.markDemoStep(8);
    }

    this.simulator.groundTruthSummary = {
      activeEntities: this.resources.length,
      hiddenTruePositionsCount: this.groundTruthPositions.size,
      pendingDelayedMessages: this.pendingDelayedUpdates.length,
    };

    this.emit('state:updated', { reason: 'SIMULATOR_TICK', tick });
    return this.simulator;
  }

  getIsolatedReplay(viewer: AuthSessionUser, incidentId?: string): {
    isolated: true;
    readOnly: true;
    prototypeNotice: string;
    frames: ReplayFrame[];
  } {
    this.markDemoStep(13);
    const filtered = incidentId
      ? this.replayFrames.filter((f) => f.incidentId === incidentId)
      : this.replayFrames;
    return {
      isolated: true,
      readOnly: true,
      prototypeNotice: `REPLAY MODE (ISOLATED FROM LIVE COMMAND) — Viewer: ${viewer.name} (${viewer.role})`,
      frames: structuredClone(filtered),
    };
  }

  generateOperationalReport(actor: AuthSessionUser, incidentId: string): Record<string, unknown> | null {
    const inc = this.incidents.find((i) => i.id === incidentId);
    if (!inc) return null;
    this.markDemoStep(14);
    const asgs = this.assignments.filter((a) => a.incidentId === incidentId);
    const comms = this.communications.filter((c) => c.incidentId === incidentId);
    const audits = this.auditLog.filter((a) => a.entityId === incidentId || asgs.some((x) => x.id === a.entityId));

    this.recordAudit(actor, 'REPORT_EXPORTED', 'INCIDENT', incidentId, 'SHARED_JESIP', `Exported attributable operational report for ${incidentId}`);

    return {
      reportId: `RPT-${randomUUID().slice(0, 8).toUpperCase()}`,
      generatedAt: new Date().toISOString(),
      generatedBy: `${actor.name} (${actor.badgeNumber} · ${actor.role})`,
      prototypeNotice: PROTOTYPE_NOTICE,
      incident: inc,
      assignments: asgs,
      communications: comms.map((c) => ({
        ...c,
        originalContent:
          (c.sharingScope === 'RESTRICTED_CLINICAL' && !actor.canViewRestrictedClinical) ||
          (c.sharingScope === 'RESTRICTED_POLICE' && !actor.canViewRestrictedPolice)
            ? `[REDACTED BY SCOPE ${c.sharingScope}]`
            : c.originalContent,
      })),
      auditTrail: audits,
    };
  }

  exportBackupSnapshot(): string {
    return JSON.stringify({
      incidents: this.incidents,
      resources: this.resources,
      assignments: this.assignments,
      communications: this.communications,
      interAgencyRequests: this.interAgencyRequests,
      auditLog: this.auditLog,
      replayFrames: this.replayFrames,
      resilience: this.resilience,
      lastHash: this.lastHash,
      auditSeq: this.auditSeq,
    });
  }

  restoreBackupSnapshot(actor: AuthSessionUser, json: string): void {
    const parsed = JSON.parse(json) as {
      incidents: Incident[];
      resources: ResourceUnit[];
      assignments: DispatchAssignment[];
      communications: CommunicationRecord[];
      interAgencyRequests: InterAgencyRequest[];
      auditLog: AuditEvent[];
      replayFrames: ReplayFrame[];
      resilience: ResilienceFlags;
      lastHash: string;
      auditSeq: number;
    };
    this.incidents = parsed.incidents;
    this.resources = parsed.resources;
    this.assignments = parsed.assignments;
    this.communications = parsed.communications;
    this.interAgencyRequests = parsed.interAgencyRequests;
    this.auditLog = parsed.auditLog;
    this.replayFrames = parsed.replayFrames;
    this.resilience = {
      ...parsed.resilience,
      lastBackendRestartAt: new Date().toISOString(),
    };
    this.lastHash = parsed.lastHash;
    this.auditSeq = parsed.auditSeq;
    this.idempotencyRegistry.clear();
    this.commandRegistry.clear();
    for (const a of this.assignments) {
      this.idempotencyRegistry.set(a.idempotencyKey, a);
      this.commandRegistry.set(a.commandId, a);
    }
    this.recordAudit(actor, 'BACKUP_RESTORED', 'SYSTEM', 'SNAPSHOT', 'SHARED_JESIP', 'Restored control-room state after simulated backend restart.');
    this.emit('state:updated', { reason: 'BACKUP_RESTORED' });
  }
}

export const controlRoomStore = new ControlRoomStore();
