# TERTIUSMEDICO — Outpatient Appointments: Architecture, Governance & Delivery Status

## 1. Prototype Identification & Scope
TERTIUSMEDICO is an **independent prototype** for **Pennine Outpatient Centre** (a fictional British hospital with two sites: *Pennine General Hospital — Outpatients Wing* and *Calder Valley Outpatient Annex*) using strictly **synthetic patient and clinician records**.

This software supports outpatient scheduling, patient self-booking, reception check-in, and operational reporting. **It does not independently diagnose patients or determine clinical urgency.**

## 2. Live Runtime vs Reference Deployment Artifacts

| Capability | Status | Details |
| :--- | :--- | :--- |
| **Patient Portal & Staff Website** | **Implemented (Live)** | Angular 21 SSR + Tailwind CSS v4 running on port `3000` (`src/app/patient/*`, `src/app/staff/*`). |
| **Transactional Scheduling & API** | **Implemented (Live)** | Express 5 REST API (`src/server/routes.ts`, `src/server/scheduling.ts`) with `BEGIN IMMEDIATE` ACID slot holds (`409 Conflict` on concurrency). |
| **Persistent Database & Storage** | **Implemented (Live)** | Node 22 built-in `node:sqlite` (`data/tertiusmedico.db` in WAL mode with foreign keys) + protected filesystem document store (`data/storage/`). |
| **Background Worker** | **Implemented (Live)** | Periodic & on-demand worker (`src/server/worker.ts`) releasing expired `Held` slots and routing failed notifications to Staff Contact Tasks. |
| **Automated Test Suite** | **Implemented (Verified)** | Vitest suite (`src/server/__tests__/tertius.spec.ts`) covering isolation, proxy scopes, clinical RBAC, concurrency, hold expiry, DST, rescheduling, and comms failures. |
| **External Systems (PAS/EPR/e-RS/NHS Login/CIS2/Notify)** | **Simulated Mock Adapters** | Typed boundaries (`src/server/adapters.ts`) with idempotency keys, conflict quarantine, and field ownership matrix. |
| **Python FastAPI + PostgreSQL + Docker Compose** | **Reference Template** | Provided in `backend-python/` and `docker-compose.yml` for containerised PostgreSQL/FastAPI deployment outside this Node/Angular sandbox. |

## 3. Authoritative Source Matrix

| Field / Domain | Authoritative Source | Local Role |
| :--- | :--- | :--- |
| Patient demographics & NHS verification status | PAS / NHS Spine PDS Adapter | Cached locally with provisional/verified flag |
| Referral clinical summary & UBRN | e-RS Referral Adapter | Imported once via unique idempotency key |
| Clinical priority & booking requirements | Local Outpatient Clinical Review | Owned by `CLINICIAN` / `TRIAGE_NURSE` / `CLINICAL_LEAD` |
| Clinic templates, slots, holds & bookings | Outpatient Scheduling Store | Authoritative transactional source of truth |
| Clinical outcomes & investigation requests | EPR Adapter / Local Clinician Entry | Emitted to EPR boundary on clinician sign-off |
| Delivery receipts & bounce reasons | GOV.UK Notify Messaging Adapter | Failed receipts create Staff Tasks; never cancel bookings |

## 4. NHS England / UK Deployment Prerequisites (Before Production)
Before proposing deployment in an NHS Trust in England:
1. **Clinical Safety (DCB0129 & DCB0160)**: Appoint a Clinical Safety Officer (CSO), complete formal Clinical Risk Management File, and sign off Hazard Log controls.
2. **Information Governance & Cybersecurity**: Complete NHS Data Security and Protection Toolkit (DSPT), DPIA, penetration testing, and Cyber Essentials Plus.
3. **Identity & Interoperability**: Onboard to NHS CIS2 (staff smartcard/role OIDC), NHS Login (patient P9 verification), Spine PDS, and e-RS FHIR APIs. Generic FHIR R4 support does **not** constitute NHS integration approval.
4. **Accessibility & Inclusion**: Full WCAG 2.2 AA audit, NHS Service Manual pattern alignment, and non-digital telephone/letter parity.

## 5. Prototype Hazard Log Summary
Full interactive table is available inside the application under **Administration → Prototype Clinical Safety Hazard Log** (`src/server/hazard-log.ts`):
- **HAZ-01**: Wrong-patient booking/disclosure → NHS number rejected as password; server-side patient isolation & proxy scope checks.
- **HAZ-02**: Lost referral or silent clock reset → Separate `waiting_list_entries` table preserving `original_joined_at` across cancellations.
- **HAZ-03**: Incorrect prep instructions / missing interpreter / wrong equipment → Slot compatibility filter + interpreter propagation.
- **HAZ-04**: Double-booking → `BEGIN IMMEDIATE` atomic slot holds + backend resource conflict checks; overbooking disabled.
- **HAZ-05**: Missed communication / silent cancellation → Unread reminders never cancel; failed deliveries auto-create Staff Tasks.
- **HAZ-06**: Failed sync / duplicate inbound event → Unique idempotency keys + conflict review queue.
- **HAZ-07**: Unauthorised clinical triage/outcome → Server-side `CLINICAL_ROLES` enforcement (`403 Forbidden`).
