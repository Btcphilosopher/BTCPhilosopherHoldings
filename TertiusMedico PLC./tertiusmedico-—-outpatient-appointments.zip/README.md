# TERTIUSMEDICO — Outpatient Appointments

Independent prototype for hospital outpatient booking, patient self-service, clinic scheduling, and clinical operations at **Pennine Outpatient Centre** (a fictional British hospital trust using strictly synthetic records).

## Quick Start (Live Runtime)

```bash
npm install
npm run dev
```

Open `http://localhost:3000` (or the AI Studio preview URL).

- **Synthetic Demo Passcode (all accounts)**: `PennineDemo2026!`
- **Patient Portal Personas**: `arthur.pendelton`, `nadia.begum`, `margaret.pendelton` (Verified Proxy)
- **Staff & Clinical Personas**: `priya.nair` (Cardiology Consultant), `eleanor.shaw` (Triage Nurse), `marcus.thorne` (Clinical Lead), `clara.jenkins` (Booking Clerk), `david.patel` (Receptionist)

## Automated Checks

```bash
npm run lint
npm run build
npx vitest run src/server/__tests__/tertius.spec.ts
```

## Architecture & Governance

See `docs/CLINICAL_GOVERNANCE_AND_ARCHITECTURE.md` for:
- Live Angular 21 SSR + Express 5 + `node:sqlite` implementation vs. reference `backend-python/` FastAPI + PostgreSQL + `docker-compose.yml` templates.
- Authoritative field-ownership matrix and simulated external adapter boundaries.
- Prototype clinical safety hazard log and NHS England deployment prerequisites.
