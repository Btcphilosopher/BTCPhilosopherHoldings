"""TERTIUSMEDICO — Reference Python FastAPI Backend Service.

Mirrors the live TypeScript/Express/SQLite outpatient API in src/server/routes.ts
for organisations deploying the Python + PostgreSQL container stack via docker-compose.yml.
"""

from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel

LONDON_TZ = ZoneInfo("Europe/London")

app = FastAPI(
    title="TERTIUSMEDICO Outpatient Appointments API",
    version="0.1.0-prototype",
    description="Independent prototype for Pennine Outpatient Centre (fictional British hospital).",
)


class ClinicalReviewRequest(BaseModel):
    review_status: str
    clinical_priority: str
    appointment_type: str = "New Outpatient"
    duration_minutes: int = 30
    required_equipment: str | None = None
    review_notes: str


@app.get("/api/health")
def health():
    now_london = datetime.now(timezone.utc).astimezone(LONDON_TZ)
    return {
        "status": "ok",
        "prototype": True,
        "organisation": "Pennine Outpatient Centre (Fictional Independent Prototype)",
        "timezone": "Europe/London",
        "london_time": now_london.isoformat(),
    }


@app.post("/api/referrals/{referral_id}/review")
def review_referral_guard(
    referral_id: str,
    payload: ClinicalReviewRequest,
    x_role: str = Header(default="PATIENT"),
):
    if x_role not in {"CLINICIAN", "TRIAGE_NURSE", "CLINICAL_LEAD"}:
        raise HTTPException(
            status_code=403,
            detail="Only authorised clinical roles may assign clinical priority or booking requirements.",
        )
    return {
        "referral_id": referral_id,
        "review_status": payload.review_status,
        "clinical_priority": payload.clinical_priority,
        "note": "Reference FastAPI guard — use PostgreSQL SERIALIZABLE/SELECT FOR UPDATE in production.",
    }
