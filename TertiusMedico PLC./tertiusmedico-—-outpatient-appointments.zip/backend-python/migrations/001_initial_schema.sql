-- PostgreSQL Reference Schema Migration 001 for TERTIUSMEDICO — Outpatient Appointments
-- Mirrors the live SQLite schema in src/server/db.ts for production PostgreSQL deployment.

CREATE TABLE IF NOT EXISTS sites (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  address TEXT NOT NULL,
  postcode TEXT NOT NULL,
  phone TEXT NOT NULL,
  accessibility_notes TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL REFERENCES sites(id),
  name TEXT NOT NULL,
  room_type TEXT NOT NULL,
  step_free BOOLEAN NOT NULL DEFAULT TRUE,
  hearing_loop BOOLEAN NOT NULL DEFAULT TRUE,
  equipment_list JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE IF NOT EXISTS clinicians (
  id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  gmc_or_nmc TEXT NOT NULL,
  role_title TEXT NOT NULL,
  specialty TEXT NOT NULL,
  primary_site_id TEXT NOT NULL REFERENCES sites(id),
  staff_directory_ref TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS patients (
  id TEXT PRIMARY KEY,
  nhs_number TEXT,
  nhs_verification_status TEXT NOT NULL,
  full_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  address TEXT NOT NULL,
  preferred_contact_channel TEXT NOT NULL DEFAULT 'SMS',
  marketing_consent BOOLEAN NOT NULL DEFAULT FALSE,
  appointment_comms_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  accessibility_requirements TEXT NOT NULL DEFAULT 'None',
  interpreter_required BOOLEAN NOT NULL DEFAULT FALSE,
  interpreter_language TEXT,
  preferred_modality TEXT NOT NULL DEFAULT 'In-person',
  preferred_site_id TEXT REFERENCES sites(id),
  pas_ref TEXT NOT NULL,
  epr_ref TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS referrals (
  id TEXT PRIMARY KEY,
  patient_id TEXT NOT NULL REFERENCES patients(id),
  source TEXT NOT NULL,
  external_ubrn TEXT,
  received_date DATE NOT NULL,
  specialty TEXT NOT NULL,
  service_name TEXT NOT NULL,
  reason_summary TEXT NOT NULL,
  clinical_priority TEXT,
  administrative_status TEXT NOT NULL,
  review_status TEXT NOT NULL,
  reviewed_by_user_id TEXT,
  reviewed_by_name TEXT,
  reviewed_at TIMESTAMPTZ,
  review_notes TEXT,
  appointment_type TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL DEFAULT 20,
  required_staff_role TEXT NOT NULL,
  required_room_type TEXT NOT NULL,
  required_equipment TEXT,
  requires_interpreter_booking BOOLEAN NOT NULL DEFAULT FALSE,
  booking_window_start DATE,
  booking_window_end DATE,
  admin_due_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS waiting_list_entries (
  id TEXT PRIMARY KEY,
  referral_id TEXT NOT NULL UNIQUE REFERENCES referrals(id),
  patient_id TEXT NOT NULL REFERENCES patients(id),
  specialty TEXT NOT NULL,
  clinical_priority TEXT NOT NULL,
  original_joined_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL,
  short_notice_opt_in BOOLEAN NOT NULL DEFAULT FALSE,
  preferred_site_id TEXT REFERENCES sites(id),
  preferred_modality TEXT NOT NULL DEFAULT 'In-person',
  notes TEXT
);

CREATE TABLE IF NOT EXISTS clinic_slots (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  specialty TEXT NOT NULL,
  site_id TEXT NOT NULL REFERENCES sites(id),
  room_id TEXT NOT NULL REFERENCES rooms(id),
  clinician_id TEXT NOT NULL REFERENCES clinicians(id),
  slot_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  start_utc TIMESTAMPTZ NOT NULL,
  end_utc TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER NOT NULL,
  modality TEXT NOT NULL,
  appointment_type TEXT NOT NULL,
  required_equipment TEXT,
  is_protected_urgent BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'Available',
  held_by_patient_id TEXT,
  held_by_referral_id TEXT,
  hold_expires_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS appointments (
  id TEXT PRIMARY KEY,
  patient_id TEXT NOT NULL REFERENCES patients(id),
  referral_id TEXT NOT NULL REFERENCES referrals(id),
  waiting_list_id TEXT REFERENCES waiting_list_entries(id),
  slot_id TEXT NOT NULL REFERENCES clinic_slots(id),
  session_id TEXT NOT NULL,
  site_id TEXT NOT NULL REFERENCES sites(id),
  room_id TEXT NOT NULL REFERENCES rooms(id),
  clinician_id TEXT NOT NULL REFERENCES clinicians(id),
  specialty TEXT NOT NULL,
  appointment_type TEXT NOT NULL,
  modality TEXT NOT NULL,
  scheduled_start_utc TIMESTAMPTZ NOT NULL,
  scheduled_end_utc TIMESTAMPTZ NOT NULL,
  local_date DATE NOT NULL,
  local_start_time TIME NOT NULL,
  local_end_time TIME NOT NULL,
  state TEXT NOT NULL,
  clinical_outcome TEXT,
  outcome_notes TEXT,
  rescheduled_from_id TEXT,
  rescheduled_to_id TEXT,
  reschedule_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
