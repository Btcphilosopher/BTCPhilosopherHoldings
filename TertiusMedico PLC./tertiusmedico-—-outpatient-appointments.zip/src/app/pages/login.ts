import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {AuthService} from '../core/auth.service';
import type {AuthUser} from '../core/models';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-[#F0F4F5] flex flex-col">
      <!-- Top Deep-Blue Civic Header (3-zone contract) -->
      <header class="bg-[#003087] text-white border-b border-[#00205B]">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          <span class="font-display font-bold text-lg tracking-tight whitespace-nowrap shrink-0">
            TERTIUSMEDICO
          </span>
          <span class="hidden sm:inline text-sm text-blue-100 whitespace-nowrap shrink-0">
            Outpatient Appointments · Pennine Outpatient Centre
          </span>
          <span class="text-xs font-medium text-blue-100 border border-blue-400/40 px-2.5 py-1 rounded whitespace-nowrap shrink-0">
            Independent Prototype
          </span>
        </div>
      </header>

      <!-- Main Workspace -->
      <main class="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-10">
        <!-- Prototype & Clinical Safety Notice -->
        <div class="bg-[#FFFBEB] border border-[#F59E0B] rounded-lg p-4 mb-8 flex items-start gap-3">
          <mat-icon class="text-[#B45309] shrink-0 mt-0.5" aria-hidden="true">info</mat-icon>
          <div class="text-sm text-[#212B32] leading-relaxed">
            <strong class="font-semibold text-[#92400E]">Independent Prototype Notice:</strong>
            Pennine Outpatient Centre is a fictional British hospital using synthetic patient records.
            This software supports outpatient booking and administration; it does not diagnose patients or determine clinical urgency.
            An NHS number is an identifier, never a password or proof of identity.
          </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <!-- Left: Sign-in Form -->
          <section class="lg:col-span-5 bg-white border border-[#D8DDE0] rounded-lg p-6 sm:p-8 shadow-sm">
            <h1 class="text-2xl font-bold text-[#003087] mb-2">Sign in to Outpatient Portal</h1>
            <p class="text-sm text-[#4C6272] mb-6">
              Enter your synthetic directory username and passcode, or select a demonstration account on the right.
            </p>

            @if (errorMsg()) {
              <div role="alert" class="mb-5 bg-[#FEF2F2] border border-[#EF4444] rounded p-3.5 flex items-start gap-2.5 text-sm text-[#991B1B]">
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] shrink-0 mt-0.5" aria-hidden="true">error</mat-icon>
                <span><strong>Sign-in blocked:</strong> {{ errorMsg() }}</span>
              </div>
            }

            <form [formGroup]="form" (ngSubmit)="submitLogin()" class="space-y-4">
              <div>
                <label for="username" class="block text-sm font-semibold text-[#212B32] mb-1.5">
                  Portal username
                </label>
                <input
                  id="username"
                  type="text"
                  formControlName="username"
                  autocomplete="username"
                  placeholder="e.g. arthur.pendelton or priya.nair"
                  class="w-full min-h-[44px] px-3.5 py-2 border border-[#768692] rounded bg-white text-[#212B32] text-sm"
                />
              </div>

              <div>
                <label for="password" class="block text-sm font-semibold text-[#212B32] mb-1.5">
                  Passcode
                </label>
                <input
                  id="password"
                  type="password"
                  formControlName="password"
                  autocomplete="current-password"
                  class="w-full min-h-[44px] px-3.5 py-2 border border-[#768692] rounded bg-white text-[#212B32] text-sm"
                />
                <p class="mt-1.5 text-xs text-[#4C6272]">
                  Prototype demonstration passcode for all synthetic accounts:
                  <code class="font-mono bg-[#F0F4F5] px-1.5 py-0.5 rounded text-[#212B32]">PennineDemo2026!</code>
                </p>
              </div>

              <button
                type="submit"
                [disabled]="loading()"
                class="w-full min-h-[46px] px-5 py-2.5 bg-[#005EB8] hover:bg-[#003087] disabled:opacity-60 text-white font-semibold rounded flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <mat-icon aria-hidden="true">login</mat-icon>
                <span>{{ loading() ? 'Signing in...' : 'Sign in' }}</span>
              </button>
            </form>

            <div class="mt-6 pt-5 border-t border-[#E8EDEE] text-xs text-[#4C6272] space-y-1.5">
              <p class="font-semibold text-[#212B32]">Identity integration boundary</p>
              <p>
                Production NHS Login (patients) and NHS CIS2 (staff smartcard) integrations sit behind the typed Identity Adapter.
              </p>
            </div>
          </section>

          <!-- Right: Synthetic Persona Launcher -->
          <section class="lg:col-span-7 bg-white border border-[#D8DDE0] rounded-lg p-6 sm:p-8 shadow-sm">
            <h2 class="text-xl font-bold text-[#212B32] mb-1">Reproducible Demonstration Accounts</h2>
            <p class="text-sm text-[#4C6272] mb-6">
              Choose a synthetic role to inspect patient self-booking, verified proxy access, clinical review restrictions, reception check-in, or clinic rescheduling.
            </p>

            @if (personasLoading()) {
              <div class="space-y-3">
                <div class="h-14 bg-[#F0F4F5] rounded animate-pulse"></div>
                <div class="h-14 bg-[#F0F4F5] rounded animate-pulse"></div>
                <div class="h-14 bg-[#F0F4F5] rounded animate-pulse"></div>
              </div>
            } @else {
              <div class="space-y-6">
                <div>
                  <h3 class="text-sm font-semibold text-[#003087] mb-3">
                    Patient Portal &amp; Verified Proxy Access
                  </h3>
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    @for (p of patientPersonas(); track p.id) {
                      <button
                        type="button"
                        (click)="quickSignIn(p.username)"
                        class="text-left p-3.5 rounded border border-[#D8DDE0] hover:border-[#005EB8] hover:bg-[#F8FAFC] transition-colors flex items-center justify-between gap-3 cursor-pointer min-h-[56px]"
                      >
                        <div class="min-w-0">
                          <div class="font-semibold text-sm text-[#212B32] truncate">{{ p.display_name }}</div>
                          <div class="text-xs text-[#4C6272] truncate">
                            {{ p.role === 'PROXY' ? 'Verified Carer Proxy (VIEW_AND_BOOK)' : 'Patient Self-Service' }}
                          </div>
                        </div>
                        <mat-icon class="text-[#005EB8] shrink-0" aria-hidden="true">arrow_forward</mat-icon>
                      </button>
                    }
                  </div>
                </div>

                <div>
                  <h3 class="text-sm font-semibold text-[#003087] mb-3">
                    Hospital Staff &amp; Clinical Operations
                  </h3>
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    @for (s of staffPersonas(); track s.id) {
                      <button
                        type="button"
                        (click)="quickSignIn(s.username)"
                        class="text-left p-3.5 rounded border border-[#D8DDE0] hover:border-[#005EB8] hover:bg-[#F8FAFC] transition-colors flex items-center justify-between gap-3 cursor-pointer min-h-[56px]"
                      >
                        <div class="min-w-0">
                          <div class="font-semibold text-sm text-[#212B32] truncate">{{ s.display_name }}</div>
                          <div class="text-xs text-[#4C6272] truncate">
                            {{ roleDescription(s.role) }}
                          </div>
                        </div>
                        <mat-icon class="text-[#005EB8] shrink-0" aria-hidden="true">arrow_forward</mat-icon>
                      </button>
                    }
                  </div>
                </div>
              </div>
            }
          </section>
        </div>
      </main>
    </div>
  `,
})
export class LoginPage implements OnInit {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly personas = signal<AuthUser[]>([]);
  readonly personasLoading = signal(true);
  readonly loading = signal(false);
  readonly errorMsg = signal<string | null>(null);

  readonly form = new FormGroup({
    username: new FormControl('arthur.pendelton', {nonNullable: true, validators: [Validators.required]}),
    password: new FormControl('PennineDemo2026!', {nonNullable: true, validators: [Validators.required]}),
  });

  readonly patientPersonas = () =>
    this.personas().filter((p) => p.role === 'PATIENT' || p.role === 'PROXY');

  readonly staffPersonas = () =>
    this.personas().filter((p) => p.role !== 'PATIENT' && p.role !== 'PROXY');

  async ngOnInit(): Promise<void> {
    try {
      const list = await this.auth.getPersonas();
      this.personas.set(list);
    } catch {
      this.errorMsg.set('Unable to load synthetic directory.');
    } finally {
      this.personasLoading.set(false);
    }
  }

  roleDescription(role: string): string {
    switch (role) {
      case 'CLINICAL_LEAD':
        return 'Clinical Lead · Review, Outcomes & Governance';
      case 'CLINICIAN':
        return 'Consultant · Clinical Review & Outcomes';
      case 'TRIAGE_NURSE':
        return 'Triage Nurse · Clinical Review';
      case 'BOOKING_CLERK':
        return 'Booking Clerk · Scheduling, Tasks & Clinics';
      case 'RECEPTIONIST':
        return 'Receptionist · Check-In & Clinic Queue';
      default:
        return role;
    }
  }

  async quickSignIn(username: string): Promise<void> {
    this.form.setValue({username, password: 'PennineDemo2026!'});
    await this.submitLogin();
  }

  async submitLogin(): Promise<void> {
    if (this.form.invalid) {
      this.errorMsg.set('Enter both username and passcode.');
      return;
    }
    this.loading.set(true);
    this.errorMsg.set(null);
    try {
      const {username, password} = this.form.getRawValue();
      const user = await this.auth.login(username, password);
      if (user.role === 'PATIENT' || user.role === 'PROXY') {
        void this.router.navigate(['/patient/home']);
      } else {
        void this.router.navigate(['/staff/overview']);
      }
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}; message?: string};
      this.errorMsg.set(e?.error?.error ?? e?.message ?? 'Sign-in failed.');
    } finally {
      this.loading.set(false);
    }
  }
}
