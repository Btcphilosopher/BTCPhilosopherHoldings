import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import type {AppointmentRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-patient-appointments',
  imports: [RouterLink, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-[#003087]">Your Appointments</h1>
          <p class="text-sm text-[#4C6272]">Review attendance instructions, confirm attendance, or request a change.</p>
        </div>
        <a
          routerLink="/patient/book"
          class="min-h-[44px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <mat-icon aria-hidden="true">edit_calendar</mat-icon>
          <span>Book or change</span>
        </a>
      </div>

      @if (feedback()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-center gap-2">
          <mat-icon aria-hidden="true">check_circle</mat-icon>
          <span>{{ feedback() }}</span>
        </div>
      }

      @if (errorMsg()) {
        <div role="alert" class="bg-[#FEF2F2] border border-[#EF4444] rounded p-4 text-sm text-[#991B1B] flex items-center gap-2">
          <mat-icon aria-hidden="true">error</mat-icon>
          <span>{{ errorMsg() }}</span>
        </div>
      }

      @if (loading()) {
        <div class="h-48 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
      } @else if (appointments().length === 0) {
        <div class="bg-white border border-[#D8DDE0] rounded-lg p-8 text-center">
          <p class="text-[#4C6272] mb-4">No appointments recorded for this patient yet.</p>
          <a routerLink="/patient/book" class="inline-flex items-center gap-2 px-4 py-2 bg-[#005EB8] text-white rounded font-semibold text-sm">
            <mat-icon aria-hidden="true">add</mat-icon>
            <span>Check available offers</span>
          </a>
        </div>
      } @else {
        <div class="space-y-4">
          @for (appt of appointments(); track appt.id) {
            <article class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
              <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div>
                  <div class="flex flex-wrap items-center gap-2.5">
                    <h2 class="text-lg font-bold text-[#212B32]">{{ appt.specialty }} · {{ appt.appointment_type }}</h2>
                    <app-status-label
                      [label]="appt.state"
                      [tone]="stateTone(appt.state)"
                    />
                  </div>
                  <p class="text-sm font-mono tabular-nums text-[#003087] font-semibold mt-1">
                    {{ appt.local_date }} · {{ appt.local_start_time }}–{{ appt.local_end_time }} ({{ appt.modality }})
                  </p>
                  <p class="text-xs text-[#4C6272] mt-0.5">
                    Ref: {{ appt.id }} · Clinician: {{ appt.clinician_name }}
                  </p>
                </div>

                @if (appt.state === 'Booked' || appt.state === 'Confirmed') {
                  <div class="flex flex-wrap items-center gap-2 shrink-0">
                    @if (appt.state === 'Booked') {
                      <button
                        type="button"
                        (click)="confirmAppt(appt.id)"
                        class="min-h-[40px] px-3.5 py-2 bg-[#007F3B] hover:bg-[#00662F] text-white text-xs font-semibold rounded inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                      >
                        <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">check</mat-icon>
                        <span>Confirm attendance</span>
                      </button>
                    }
                    <a
                      [routerLink]="['/patient/book']"
                      [queryParams]="{rescheduleId: appt.id, referralId: appt.referral_id}"
                      class="min-h-[40px] px-3.5 py-2 bg-white hover:bg-[#F8FAFC] text-[#005EB8] border border-[#005EB8] text-xs font-semibold rounded inline-flex items-center gap-1.5 whitespace-nowrap"
                    >
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">update</mat-icon>
                      <span>Change time</span>
                    </a>
                    <button
                      type="button"
                      (click)="cancelAppt(appt.id)"
                      class="min-h-[40px] px-3.5 py-2 bg-white hover:bg-[#FEF2F2] text-[#991B1B] border border-[#FCA5A5] text-xs font-semibold rounded inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">cancel</mat-icon>
                      <span>Cancel</span>
                    </button>
                  </div>
                }
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-[#E8EDEE] text-sm">
                <div>
                  <div class="font-semibold text-[#212B32] mb-1">Location &amp; Accessibility</div>
                  <p class="text-[#4C6272]">{{ appt.site_name }} · {{ appt.room_name }}</p>
                  <p class="text-xs text-[#4C6272]">{{ appt.site_address }}, {{ appt.site_postcode }}</p>
                  @if (appt.accessibility_notes) {
                    <p class="text-xs text-[#4C6272] mt-1">{{ appt.accessibility_notes }}</p>
                  }
                  @if (appt.interpreter_language) {
                    <p class="text-xs font-medium text-[#003087] mt-1">
                      Interpreter arranged: {{ appt.interpreter_language }}
                    </p>
                  }
                </div>
                <div>
                  <div class="font-semibold text-[#212B32] mb-1">Preparation Instructions</div>
                  <p class="text-[#4C6272]">{{ appt.preparation_instructions }}</p>
                  @if (appt.rescheduled_from_id) {
                    <p class="text-xs text-[#4C6272] mt-1">
                      Rescheduled from {{ appt.rescheduled_from_id }} ({{ appt.reschedule_reason }})
                    </p>
                  }
                  @if (appt.rescheduled_to_id) {
                    <p class="text-xs text-[#4C6272] mt-1">
                      Superseded by {{ appt.rescheduled_to_id }} ({{ appt.reschedule_reason }})
                    </p>
                  }
                </div>
              </div>
            </article>
          }
        </div>
      }
    </div>
  `,
})
export class PatientAppointments implements OnInit {
  private readonly api = inject(ApiService);
  private readonly auth = inject(AuthService);

  readonly loading = signal(true);
  readonly appointments = signal<AppointmentRecord[]>([]);
  readonly feedback = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  async load(): Promise<void> {
    const pid = this.auth.activePatientId();
    if (!pid) {
      this.loading.set(false);
      return;
    }
    try {
      const res = await this.api.getAppointments({patientId: pid});
      this.appointments.set(res.appointments);
    } finally {
      this.loading.set(false);
    }
  }

  stateTone(state: string): 'neutral' | 'info' | 'success' | 'warning' | 'urgent' {
    if (state === 'Completed' || state === 'Confirmed') return 'success';
    if (state === 'Booked' || state === 'Arrived' || state === 'In progress') return 'info';
    if (state.startsWith('Cancelled') || state === 'Did not attend' || state === 'Unable to complete') {
      return 'warning';
    }
    return 'neutral';
  }

  async confirmAppt(id: string): Promise<void> {
    this.errorMsg.set(null);
    this.feedback.set(null);
    try {
      await this.api.transitionAppointment(id, 'Confirmed', 'Confirmed by patient via portal');
      this.feedback.set(`Appointment ${id} confirmed.`);
      await this.load();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Could not confirm appointment.');
    }
  }

  async cancelAppt(id: string): Promise<void> {
    this.errorMsg.set(null);
    this.feedback.set(null);
    try {
      await this.api.transitionAppointment(
        id,
        'Cancelled by patient',
        'Patient requested cancellation via portal',
      );
      this.feedback.set(
        `Appointment ${id} cancelled. Your referral and original waiting-list date remain preserved.`,
      );
      await this.load();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Could not cancel appointment.');
    }
  }
}
