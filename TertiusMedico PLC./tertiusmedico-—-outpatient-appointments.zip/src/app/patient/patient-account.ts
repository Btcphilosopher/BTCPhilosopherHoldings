import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import type {PatientRecord, ProxyRelationship} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-patient-account',
  imports: [ReactiveFormsModule, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold text-[#003087]">Account, Preferences &amp; Proxies</h1>
        <p class="text-sm text-[#4C6272]">
          Review your synthetic NHS identity record, communication consent, accessibility needs, and verified carers.
        </p>
      </div>

      @if (savedMsg()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-center gap-2">
          <mat-icon aria-hidden="true">check_circle</mat-icon>
          <span>{{ savedMsg() }}</span>
        </div>
      }

      @if (loading()) {
        <div class="h-48 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
      } @else if (patient(); as p) {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <!-- Left: Record & Proxies & Documents -->
          <div class="lg:col-span-5 space-y-6">
            <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-3">
              <div class="flex items-center justify-between gap-2">
                <h2 class="text-lg font-bold text-[#212B32]">Patient Record</h2>
                <app-status-label
                  [label]="p.nhs_verification_status"
                  [tone]="p.nhs_verification_status.startsWith('Verified') ? 'success' : 'warning'"
                />
              </div>
              <dl class="text-sm space-y-2 pt-2 border-t border-[#E8EDEE]">
                <div class="flex justify-between gap-2">
                  <dt class="text-[#4C6272]">Full name</dt>
                  <dd class="font-semibold text-[#212B32]">{{ p.full_name }}</dd>
                </div>
                <div class="flex justify-between gap-2">
                  <dt class="text-[#4C6272]">Internal ID</dt>
                  <dd class="font-mono text-[#212B32]">{{ p.id }}</dd>
                </div>
                <div class="flex justify-between gap-2">
                  <dt class="text-[#4C6272]">Synthetic NHS No.</dt>
                  <dd class="font-mono tabular-nums text-[#212B32]">{{ p.nhs_number ?? 'Not supplied' }}</dd>
                </div>
                <div class="flex justify-between gap-2">
                  <dt class="text-[#4C6272]">Date of birth</dt>
                  <dd class="font-mono tabular-nums text-[#212B32]">{{ p.date_of_birth }}</dd>
                </div>
                <div class="flex justify-between gap-2">
                  <dt class="text-[#4C6272]">External refs</dt>
                  <dd class="font-mono text-xs text-[#4C6272]">{{ p.pas_ref }} · {{ p.epr_ref }}</dd>
                </div>
              </dl>
            </section>

            <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-3">
              <h2 class="text-lg font-bold text-[#212B32]">Verified Proxy Relationships</h2>
              @if (proxies().length === 0) {
                <p class="text-sm text-[#4C6272]">No verified proxy representatives linked to this record.</p>
              } @else {
                @for (prx of proxies(); track prx.id) {
                  <div class="p-3 bg-[#F8FAFC] border border-[#D8DDE0] rounded text-sm space-y-1">
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-semibold text-[#212B32]">{{ prx.proxy_name }}</span>
                      <app-status-label [label]="prx.verification_status" tone="success" />
                    </div>
                    <div class="text-xs text-[#4C6272]">
                      {{ prx.relationship }} · Scope: <strong class="font-mono">{{ prx.scope }}</strong>
                    </div>
                  </div>
                }
              }
            </section>

            <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-3">
              <h2 class="text-lg font-bold text-[#212B32]">Protected Referral Documents</h2>
              @if (documents().length === 0) {
                <p class="text-sm text-[#4C6272]">No supporting documents stored.</p>
              } @else {
                <div class="space-y-2">
                  @for (doc of documents(); track doc.id) {
                    <div class="flex items-center justify-between gap-2 p-2.5 border border-[#D8DDE0] rounded text-sm">
                      <div class="min-w-0">
                        <div class="font-medium text-[#212B32] truncate">{{ doc.title }}</div>
                        <div class="text-xs text-[#4C6272]">{{ doc.doc_type }}</div>
                      </div>
                      <button
                        type="button"
                        (click)="viewDoc(doc.id)"
                        class="px-3 py-1.5 bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#003087] text-xs font-semibold rounded shrink-0 cursor-pointer"
                      >
                        View
                      </button>
                    </div>
                  }
                </div>
              }
              @if (docPreview()) {
                <pre class="mt-3 p-3 bg-[#F8FAFC] border border-[#D8DDE0] rounded text-xs font-mono whitespace-pre-wrap text-[#212B32]">{{ docPreview() }}</pre>
              }
            </section>
          </div>

          <!-- Right: Communication & Accessibility Preferences -->
          <section class="lg:col-span-7 bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-5">
            <h2 class="text-lg font-bold text-[#212B32]">Communication &amp; Accessibility Preferences</h2>
            <form [formGroup]="form" (ngSubmit)="savePreferences()" class="space-y-4">
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label for="channel" class="block text-sm font-semibold text-[#212B32] mb-1.5">Preferred appointment channel</label>
                  <select id="channel" formControlName="preferred_contact_channel" class="w-full min-h-[44px] px-3 py-2 border border-[#768692] rounded bg-white text-sm">
                    <option value="SMS">SMS text message</option>
                    <option value="Email">Email</option>
                    <option value="Letter">Posted letter</option>
                    <option value="Telephone">Telephone call</option>
                    <option value="Portal">Portal inbox only</option>
                  </select>
                </div>
                <div>
                  <label for="modality" class="block text-sm font-semibold text-[#212B32] mb-1.5">Preferred clinic format</label>
                  <select id="modality" formControlName="preferred_modality" class="w-full min-h-[44px] px-3 py-2 border border-[#768692] rounded bg-white text-sm">
                    <option value="In-person">In-person at clinic</option>
                    <option value="Telephone">Telephone consultation</option>
                    <option value="Video">Video consultation</option>
                  </select>
                </div>
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label for="phone" class="block text-sm font-semibold text-[#212B32] mb-1.5">Telephone number</label>
                  <input id="phone" type="text" formControlName="phone" class="w-full min-h-[44px] px-3 py-2 border border-[#768692] rounded bg-white text-sm" />
                </div>
                <div>
                  <label for="email" class="block text-sm font-semibold text-[#212B32] mb-1.5">Email address</label>
                  <input id="email" type="email" formControlName="email" class="w-full min-h-[44px] px-3 py-2 border border-[#768692] rounded bg-white text-sm" />
                </div>
              </div>

              <div>
                <label for="acc" class="block text-sm font-semibold text-[#212B32] mb-1.5">Accessibility requirements</label>
                <input id="acc" type="text" formControlName="accessibility_requirements" class="w-full min-h-[44px] px-3 py-2 border border-[#768692] rounded bg-white text-sm" />
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                <label class="flex items-center gap-2.5 text-sm font-medium text-[#212B32] cursor-pointer">
                  <input type="checkbox" formControlName="interpreter_required" class="w-4 h-4" />
                  <span>Interpreter required for clinics</span>
                </label>
                <div>
                  <label for="lang" class="block text-xs font-semibold text-[#4C6272] mb-1">Interpreter language</label>
                  <input id="lang" type="text" formControlName="interpreter_language" placeholder="e.g. Urdu, British Sign Language" class="w-full min-h-[40px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm" />
                </div>
              </div>

              <!-- Marketing Consent Strictly Separate from Appointment Communications -->
              <div class="pt-4 border-t border-[#E8EDEE] space-y-3">
                <h3 class="text-sm font-bold text-[#212B32]">Consent Separation</h3>
                <label class="flex items-start gap-2.5 text-sm text-[#212B32] cursor-pointer">
                  <input type="checkbox" formControlName="appointment_comms_enabled" class="w-4 h-4 mt-0.5" />
                  <span>Receive essential appointment offers, confirmations, and reminders</span>
                </label>
                <label class="flex items-start gap-2.5 text-sm text-[#4C6272] cursor-pointer">
                  <input type="checkbox" formControlName="marketing_consent" class="w-4 h-4 mt-0.5" />
                  <span>Optional trust news &amp; patient engagement surveys (kept separate from care communications)</span>
                </label>
              </div>

              <button
                type="submit"
                [disabled]="saving()"
                class="min-h-[44px] px-5 py-2.5 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center gap-2 cursor-pointer"
              >
                <mat-icon aria-hidden="true">save</mat-icon>
                <span>{{ saving() ? 'Saving...' : 'Save preferences' }}</span>
              </button>
            </form>
          </section>
        </div>
      }
    </div>
  `,
})
export class PatientAccount implements OnInit {
  private readonly api = inject(ApiService);
  private readonly auth = inject(AuthService);

  readonly loading = signal(true);
  readonly saving = signal(false);
  readonly savedMsg = signal<string | null>(null);
  readonly patient = signal<PatientRecord | null>(null);
  readonly proxies = signal<ProxyRelationship[]>([]);
  readonly documents = signal<{id: string; title: string; doc_type: string}[]>([]);
  readonly docPreview = signal<string | null>(null);

  readonly form = new FormGroup({
    preferred_contact_channel: new FormControl('SMS', {nonNullable: true}),
    preferred_modality: new FormControl('In-person', {nonNullable: true}),
    phone: new FormControl('', {nonNullable: true}),
    email: new FormControl('', {nonNullable: true}),
    accessibility_requirements: new FormControl('', {nonNullable: true}),
    interpreter_required: new FormControl(false, {nonNullable: true}),
    interpreter_language: new FormControl('', {nonNullable: true}),
    appointment_comms_enabled: new FormControl(true, {nonNullable: true}),
    marketing_consent: new FormControl(false, {nonNullable: true}),
  });

  async ngOnInit(): Promise<void> {
    const pid = this.auth.activePatientId();
    if (!pid) {
      this.loading.set(false);
      return;
    }
    try {
      const detail = await this.api.getPatientDetail(pid);
      this.patient.set(detail.patient);
      this.proxies.set(detail.proxies);
      this.documents.set(detail.documents);
      this.form.setValue({
        preferred_contact_channel: detail.patient.preferred_contact_channel,
        preferred_modality: detail.patient.preferred_modality,
        phone: detail.patient.phone,
        email: detail.patient.email,
        accessibility_requirements: detail.patient.accessibility_requirements,
        interpreter_required: detail.patient.interpreter_required === 1,
        interpreter_language: detail.patient.interpreter_language ?? '',
        appointment_comms_enabled: detail.patient.appointment_comms_enabled === 1,
        marketing_consent: detail.patient.marketing_consent === 1,
      });
    } finally {
      this.loading.set(false);
    }
  }

  async savePreferences(): Promise<void> {
    const pid = this.auth.activePatientId();
    if (!pid) return;
    this.saving.set(true);
    this.savedMsg.set(null);
    try {
      const v = this.form.getRawValue();
      const res = await this.api.updatePatientPreferences(pid, {
        ...v,
        interpreter_language: v.interpreter_required ? v.interpreter_language || null : null,
      });
      this.patient.set(res.patient);
      this.savedMsg.set('Preferences updated.');
    } finally {
      this.saving.set(false);
    }
  }

  async viewDoc(docId: string): Promise<void> {
    const res = await this.api.downloadDocument(docId);
    this.docPreview.set(res.content);
  }
}
