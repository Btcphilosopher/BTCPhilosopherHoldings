import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';

@Component({
  selector: 'app-patient-help',
  imports: [ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold text-[#003087]">Help &amp; Booking Assistance</h1>
        <p class="text-sm text-[#4C6272]">
          Support for booking appointments, requesting an interpreter, or arranging telephone/letter booking without a smartphone.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <!-- Telephone & Accessibility Options -->
        <section class="lg:col-span-5 bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
          <h2 class="text-lg font-bold text-[#212B32]">Telephone &amp; In-Person Booking</h2>
          <p class="text-sm text-[#4C6272] leading-relaxed">
            You do not need a smartphone or internet access to manage your care at Pennine Outpatient Centre. Our booking clerks record telephone bookings directly into the same schedule.
          </p>
          <div class="bg-[#F8FAFC] border border-[#D8DDE0] rounded p-4 space-y-2 text-sm">
            <div><strong>Pennine General Booking Desk:</strong> <span class="font-mono">01282 550100</span></div>
            <div><strong>Calder Valley Annex Desk:</strong> <span class="font-mono">01422 550240</span></div>
            <div class="text-xs text-[#4C6272]">Monday to Friday, 08:00 – 18:00 (Europe/London)</div>
          </div>
          <div class="text-xs text-[#4C6272] space-y-1">
            <p class="font-semibold text-[#212B32]">Accessibility &amp; Interpreters</p>
            <p>Large print (18pt), British Sign Language (BSL), Urdu, Polish, and step-free clinic rooms can be requested below or in Account preferences.</p>
          </div>
        </section>

        <!-- Request Help Form -->
        <section class="lg:col-span-7 bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
          <h2 class="text-lg font-bold text-[#212B32]">Ask the Booking Team for Help</h2>

          @if (submittedTaskId()) {
            <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-start gap-2.5">
              <mat-icon aria-hidden="true">check_circle</mat-icon>
              <div>
                <strong>Request sent (Task {{ submittedTaskId() }}).</strong>
                Our booking team has received your request and will contact you using your preferred channel.
              </div>
            </div>
          }

          <form [formGroup]="form" (ngSubmit)="submitHelp()" class="space-y-4">
            <div>
              <label for="topic" class="block text-sm font-semibold text-[#212B32] mb-1.5">Topic</label>
              <select
                id="topic"
                formControlName="topic"
                class="w-full min-h-[44px] px-3 py-2 border border-[#768692] rounded bg-white text-sm"
              >
                <option value="Telephone booking callback">Request a telephone booking callback</option>
                <option value="Interpreter or accessibility support">Update interpreter or accessibility needs</option>
                <option value="Change or cancel appointment">Help changing or cancelling an appointment</option>
                <option value="Travel and parking enquiry">Directions, parking, or transport advice</option>
              </select>
            </div>

            <div>
              <label for="details" class="block text-sm font-semibold text-[#212B32] mb-1.5">Details</label>
              <textarea
                id="details"
                rows="4"
                formControlName="details"
                placeholder="Tell us the best times to call or any specific requirements..."
                class="w-full px-3.5 py-2.5 border border-[#768692] rounded bg-white text-sm"
              ></textarea>
            </div>

            <button
              type="submit"
              [disabled]="submitting() || form.invalid"
              class="min-h-[44px] px-5 py-2.5 bg-[#005EB8] hover:bg-[#003087] disabled:opacity-60 text-white text-sm font-semibold rounded inline-flex items-center gap-2 cursor-pointer"
            >
              <mat-icon aria-hidden="true">send</mat-icon>
              <span>{{ submitting() ? 'Sending...' : 'Send request to booking team' }}</span>
            </button>
          </form>
        </section>
      </div>
    </div>
  `,
})
export class PatientHelp {
  private readonly api = inject(ApiService);
  private readonly auth = inject(AuthService);

  readonly submitting = signal(false);
  readonly submittedTaskId = signal<string | null>(null);

  readonly form = new FormGroup({
    topic: new FormControl('Telephone booking callback', {nonNullable: true, validators: [Validators.required]}),
    details: new FormControl('', {nonNullable: true, validators: [Validators.required, Validators.minLength(5)]}),
  });

  async submitHelp(): Promise<void> {
    const pid = this.auth.activePatientId();
    if (!pid || this.form.invalid) return;
    this.submitting.set(true);
    try {
      const {topic, details} = this.form.getRawValue();
      const res = await this.api.requestHelp(pid, topic, details);
      this.submittedTaskId.set(res.task_id);
      this.form.reset({topic: 'Telephone booking callback', details: ''});
    } finally {
      this.submitting.set(false);
    }
  }
}
