import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import {Router, RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {AuthService} from '../core/auth.service';

@Component({
  selector: 'app-patient-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-[#F0F4F5] flex flex-col">
      <!-- Top Deep-Blue Civic Header (3-zone contract) -->
      <header class="bg-[#003087] text-white border-b border-[#00205B]">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          <a routerLink="/patient/home" class="font-display font-bold text-lg tracking-tight text-white whitespace-nowrap shrink-0">
            TERTIUSMEDICO
          </a>

          <nav aria-label="Patient navigation" class="hidden md:flex items-center gap-6 text-sm font-medium">
            <a
              routerLink="/patient/home"
              routerLinkActive="underline underline-offset-8 decoration-2 text-white"
              class="text-blue-100 hover:text-white whitespace-nowrap shrink-0"
            >Home</a>
            <a
              routerLink="/patient/appointments"
              routerLinkActive="underline underline-offset-8 decoration-2 text-white"
              class="text-blue-100 hover:text-white whitespace-nowrap shrink-0"
            >Appointments</a>
            <a
              routerLink="/patient/book"
              routerLinkActive="underline underline-offset-8 decoration-2 text-white"
              class="text-blue-100 hover:text-white whitespace-nowrap shrink-0"
            >Book or change</a>
            <a
              routerLink="/patient/messages"
              routerLinkActive="underline underline-offset-8 decoration-2 text-white"
              class="text-blue-100 hover:text-white whitespace-nowrap shrink-0"
            >Messages</a>
            <a
              routerLink="/patient/help"
              routerLinkActive="underline underline-offset-8 decoration-2 text-white"
              class="text-blue-100 hover:text-white whitespace-nowrap shrink-0"
            >Help</a>
            <a
              routerLink="/patient/account"
              routerLinkActive="underline underline-offset-8 decoration-2 text-white"
              class="text-blue-100 hover:text-white whitespace-nowrap shrink-0"
            >Account</a>
          </nav>

          <div class="flex items-center shrink-0">
            <button
              type="button"
              (click)="auth.logout()"
              class="px-3.5 py-2 text-xs font-semibold bg-white/10 hover:bg-white/20 text-white rounded border border-white/20 flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">logout</mat-icon>
              <span>Sign out</span>
            </button>
          </div>
        </div>
      </header>

      <!-- Context Banner (below header) -->
      <div class="bg-white border-b border-[#D8DDE0]">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-[#4C6272]">
          <div class="flex flex-wrap items-center gap-2">
            <span class="font-semibold text-[#212B32]">Pennine Outpatient Centre</span>
            <span aria-hidden="true">·</span>
            <span>Independent Prototype (Synthetic Records)</span>
            @if (auth.user(); as u) {
              <span aria-hidden="true">·</span>
              <span>Signed in as <strong class="text-[#212B32]">{{ u.display_name }}</strong></span>
            }
          </div>
          @if (auth.accessiblePatients().length > 0) {
            <div class="flex items-center gap-2">
              <span class="text-[#4C6272]">Patient record:</span>
              @for (p of auth.accessiblePatients(); track p.id) {
                <button
                  type="button"
                  (click)="auth.activePatientId.set(p.id)"
                  class="px-2 py-0.5 rounded border text-xs font-medium cursor-pointer whitespace-nowrap"
                  [class]="auth.activePatientId() === p.id ? 'bg-[#EFF6FF] border-[#005EB8] text-[#003087]' : 'bg-white border-[#D8DDE0] text-[#4C6272]'"
                >
                  {{ p.full_name }}
                </button>
              }
            </div>
          }
        </div>
      </div>

      <!-- Main Patient Workspace -->
      <main class="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-24 md:pb-10">
        <router-outlet />
      </main>

      <!-- Mobile Bottom Navigation (compact, <= 15% viewport height) -->
      <nav
        aria-label="Mobile patient navigation"
        class="md:hidden fixed bottom-0 inset-x-0 bg-[#003087] text-white border-t border-[#00205B] grid grid-cols-6 z-40"
      >
        <a routerLink="/patient/home" routerLinkActive="bg-[#005EB8]" class="py-2 flex flex-col items-center justify-center text-[11px] gap-0.5">
          <mat-icon class="!text-[20px] !w-[20px] !h-[20px]" aria-hidden="true">home</mat-icon>
          <span>Home</span>
        </a>
        <a routerLink="/patient/appointments" routerLinkActive="bg-[#005EB8]" class="py-2 flex flex-col items-center justify-center text-[11px] gap-0.5">
          <mat-icon class="!text-[20px] !w-[20px] !h-[20px]" aria-hidden="true">event</mat-icon>
          <span>Appts</span>
        </a>
        <a routerLink="/patient/book" routerLinkActive="bg-[#005EB8]" class="py-2 flex flex-col items-center justify-center text-[11px] gap-0.5">
          <mat-icon class="!text-[20px] !w-[20px] !h-[20px]" aria-hidden="true">edit_calendar</mat-icon>
          <span>Book</span>
        </a>
        <a routerLink="/patient/messages" routerLinkActive="bg-[#005EB8]" class="py-2 flex flex-col items-center justify-center text-[11px] gap-0.5">
          <mat-icon class="!text-[20px] !w-[20px] !h-[20px]" aria-hidden="true">mail</mat-icon>
          <span>Messages</span>
        </a>
        <a routerLink="/patient/help" routerLinkActive="bg-[#005EB8]" class="py-2 flex flex-col items-center justify-center text-[11px] gap-0.5">
          <mat-icon class="!text-[20px] !w-[20px] !h-[20px]" aria-hidden="true">help</mat-icon>
          <span>Help</span>
        </a>
        <a routerLink="/patient/account" routerLinkActive="bg-[#005EB8]" class="py-2 flex flex-col items-center justify-center text-[11px] gap-0.5">
          <mat-icon class="!text-[20px] !w-[20px] !h-[20px]" aria-hidden="true">person</mat-icon>
          <span>Account</span>
        </a>
      </nav>
    </div>
  `,
})
export class PatientShell {
  readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  constructor() {
    if (!this.auth.isAuthenticated()) {
      void this.router.navigate(['/login']);
    }
  }
}
