import {ChangeDetectionStrategy, Component, computed, inject, OnInit, signal} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import type {AppointmentRecord, NotificationRecord, WaitingListRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-patient-home',
  imports: [RouterLink, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-8">
      <!-- Welcome / Primary Focal Anchor -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 sm:p-8 shadow-sm">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 class="text-2xl sm:text-3xl font-bold text-[#003087]">Your Outpatient Care</h1>
            <p class="text-sm sm:text-base text-[#4C6272] mt-1">
              Manage your clinic appointments, choose offered times, and review preparation instructions at Pennine Outpatient Centre.
            </p>
          </div>
          <a
            routerLink="/patient/book"
            class="min-h-[46px] px-5 py-2.5 bg-[#005EB8] hover:bg-[#003087] text-white font-semibold rounded inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-colors"
          >
            <mat-icon aria-hidden="true">edit_calendar</mat-icon>
            <span>Book or change appointment</span>
          </a>
        </div>
      </section>

      @if (loading()) {
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="h-44 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
          <div class="h-44 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
        </div>
      } @else {
        <!-- Offers Ready to Book -->
        @if (activeOffers().length > 0) {
          <section class="bg-[#EFF6FF] border border-[#93C5FD] rounded-lg p-6">
            <div class="flex items-start gap-3 mb-4">
              <mat-icon class="text-[#003087] shrink-0 mt-0.5" aria-hidden="true">event_available</mat-icon>
              <div>
                <h2 class="text-lg font-bold text-[#003087]">Appointment offers ready for you to choose</h2>
                <p class="text-sm text-[#212B32]">
                  A clinician has reviewed your referral and approved compatible clinic times.
                </p>
              </div>
            </div>

            <div class="space-y-3">
              @for (offer of activeOffers(); track offer.id) {
                <div class="bg-white border border-[#BFDBFE] rounded p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div class="font-semibold text-[#212B32]">{{ offer.specialty }} · {{ offer.service_name }}</div>
                    <div class="text-xs text-[#4C6272] mt-1 tabular-nums">
                      Referral {{ offer.referral_id }} · Waiting list since {{ offer.original_joined_at.slice(0, 10) }}
                      · {{ offer.duration_minutes }} minutes
                      @if (offer.interpreter_required) {
                        · Interpreter: {{ offer.interpreter_language }}
                      }
                    </div>
                  </div>
                  <a
                    [routerLink]="['/patient/book']"
                    [queryParams]="{referralId: offer.referral_id}"
                    class="min-h-[42px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <mat-icon class="!text-[18px] !w-[18px] !h-[18px]" aria-hidden="true">schedule</mat-icon>
                    <span>Choose a time</span>
                  </a>
                </div>
              }
            </div>
          </section>
        }

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Upcoming Appointments -->
          <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm">
            <div class="flex items-center justify-between gap-4 mb-4">
              <h2 class="text-lg font-bold text-[#212B32]">Upcoming appointments</h2>
              <a routerLink="/patient/appointments" class="text-sm font-semibold text-[#005EB8] hover:underline whitespace-nowrap">
                View all
              </a>
            </div>

            @if (upcomingAppointments().length === 0) {
              <p class="text-sm text-[#4C6272] py-4">
                You do not have any booked appointments yet. Check your offers or waiting-list status below.
              </p>
            } @else {
              <div class="divide-y divide-[#E8EDEE]">
                @for (appt of upcomingAppointments(); track appt.id) {
                  <div class="py-4 first:pt-0 last:pb-0 space-y-2">
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-semibold text-[#212B32]">{{ appt.specialty }} · {{ appt.appointment_type }}</span>
                      <app-status-label [label]="appt.state" tone="info" />
                    </div>
                    <div class="text-sm text-[#212B32] font-mono tabular-nums">
                      {{ appt.local_date }} · {{ appt.local_start_time }}–{{ appt.local_end_time }} (Europe/London)
                    </div>
                    <div class="text-xs text-[#4C6272]">
                      {{ appt.site_name }} · {{ appt.room_name }} · {{ appt.clinician_name }}
                    </div>
                  </div>
                }
              </div>
            }
          </section>

          <!-- Waiting List & Recent Messages -->
          <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-6">
            <div>
              <h2 class="text-lg font-bold text-[#212B32] mb-3">Waiting list &amp; referrals</h2>
              @if (waitingLists().length === 0) {
                <p class="text-sm text-[#4C6272]">No active waiting-list entries.</p>
              } @else {
                <div class="divide-y divide-[#E8EDEE]">
                  @for (wl of waitingLists(); track wl.id) {
                    <div class="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-3">
                      <div class="min-w-0">
                        <div class="font-medium text-sm text-[#212B32] truncate">{{ wl.specialty }} · {{ wl.service_name }}</div>
                        <div class="text-xs text-[#4C6272] tabular-nums">
                          Joined {{ wl.original_joined_at.slice(0, 10) }} · Status: {{ wl.status }}
                        </div>
                      </div>
                      <app-status-label
                        [label]="wl.clinical_priority"
                        [tone]="wl.clinical_priority === 'Urgent' ? 'urgent' : wl.clinical_priority === 'Soon' ? 'warning' : 'neutral'"
                      />
                    </div>
                  }
                </div>
              }
            </div>

            <div class="pt-4 border-t border-[#E8EDEE]">
              <div class="flex items-center justify-between mb-2">
                <h3 class="text-base font-bold text-[#212B32]">Recent messages ({{ unreadCount() }} unread)</h3>
                <a routerLink="/patient/messages" class="text-sm font-semibold text-[#005EB8] hover:underline">Open inbox</a>
              </div>
              <p class="text-xs text-[#4C6272]">
                Portal messaging is for outpatient appointments only and is not an emergency service. Unread messages never cancel your booking.
              </p>
            </div>
          </section>
        </div>
      }
    </div>
  `,
})
export class PatientHome implements OnInit {
  private readonly api = inject(ApiService);
  private readonly auth = inject(AuthService);

  readonly loading = signal(true);
  readonly appointments = signal<AppointmentRecord[]>([]);
  readonly waitingLists = signal<WaitingListRecord[]>([]);
  readonly notifications = signal<NotificationRecord[]>([]);

  readonly activeOffers = computed(() =>
    this.waitingLists().filter((w) => w.status === 'Active' || w.status === 'Offer Pending'),
  );
  readonly upcomingAppointments = computed(() =>
    this.appointments().filter((a) => ['Booked', 'Confirmed', 'Arrived'].includes(a.state)),
  );
  readonly unreadCount = computed(
    () => this.notifications().filter((n) => !n.read_at).length,
  );

  async ngOnInit(): Promise<void> {
    const pid = this.auth.activePatientId();
    if (!pid) {
      this.loading.set(false);
      return;
    }
    try {
      const [appts, wls, notifs] = await Promise.all([
        this.api.getAppointments({patientId: pid}),
        this.api.getWaitingLists(pid),
        this.api.getNotifications(pid),
      ]);
      this.appointments.set(appts.appointments);
      this.waitingLists.set(wls.waiting_lists);
      this.notifications.set(notifs.notifications);
    } finally {
      this.loading.set(false);
    }
  }
}
