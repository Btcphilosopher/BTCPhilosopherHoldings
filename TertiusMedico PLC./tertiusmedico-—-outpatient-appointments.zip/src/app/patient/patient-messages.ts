import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import type {NotificationRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-patient-messages',
  imports: [MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold text-[#003087]">Messages &amp; Reminders</h1>
        <p class="text-sm text-[#4C6272]">Appointment confirmations, offers, and preparation notices.</p>
      </div>

      <!-- Urgent Non-Emergency Disclaimer -->
      <div class="bg-[#FEF2F2] border border-[#EF4444] rounded-lg p-4 flex items-start gap-3">
        <mat-icon class="text-[#991B1B] shrink-0 mt-0.5" aria-hidden="true">error</mat-icon>
        <div class="text-sm text-[#991B1B]">
          <strong>Urgent: Portal messaging is not an emergency service.</strong>
          If you have an urgent medical concern or chest pain, call <strong>999</strong> or <strong>NHS 111</strong> immediately.
          An unread reminder will never cancel your appointment.
        </div>
      </div>

      @if (loading()) {
        <div class="h-48 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
      } @else if (notifications().length === 0) {
        <div class="bg-white border border-[#D8DDE0] rounded-lg p-8 text-center text-[#4C6272]">
          No messages or notifications recorded.
        </div>
      } @else {
        <div class="space-y-3">
          @for (msg of notifications(); track msg.id) {
            <article class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm space-y-2.5">
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div class="flex flex-wrap items-center gap-2">
                  <span class="font-bold text-[#212B32]">{{ msg.subject }}</span>
                  <app-status-label [label]="msg.message_type" tone="info" />
                  <app-status-label
                    [label]="msg.status"
                    [tone]="msg.status === 'Failed' ? 'urgent' : 'success'"
                  />
                </div>
                <span class="text-xs font-mono tabular-nums text-[#4C6272]">
                  {{ msg.channel }} · {{ msg.created_at.slice(0, 16).replace('T', ' ') }}
                </span>
              </div>
              <p class="text-sm text-[#212B32] leading-relaxed">{{ msg.body_redacted }}</p>
              <div class="flex items-center justify-between pt-2 border-t border-[#E8EDEE] text-xs text-[#4C6272]">
                <span>{{ msg.read_at ? 'Read ' + msg.read_at.slice(0, 10) : 'Unread' }}</span>
                @if (!msg.read_at) {
                  <button
                    type="button"
                    (click)="markRead(msg.id)"
                    class="px-3 py-1.5 bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#003087] font-semibold rounded cursor-pointer"
                  >
                    Mark as read
                  </button>
                }
              </div>
            </article>
          }
        </div>
      }
    </div>
  `,
})
export class PatientMessages implements OnInit {
  private readonly api = inject(ApiService);
  private readonly auth = inject(AuthService);

  readonly loading = signal(true);
  readonly notifications = signal<NotificationRecord[]>([]);

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  async load(): Promise<void> {
    const pid = this.auth.activePatientId();
    if (!pid) {
      this.loading.set(false);
      return;
    }
    try {
      const res = await this.api.getNotifications(pid);
      this.notifications.set(res.notifications);
    } finally {
      this.loading.set(false);
    }
  }

  async markRead(id: string): Promise<void> {
    await this.api.markNotificationRead(id);
    await this.load();
  }
}
