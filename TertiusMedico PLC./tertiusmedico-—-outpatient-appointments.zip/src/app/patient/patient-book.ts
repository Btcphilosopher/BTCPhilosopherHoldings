import {ChangeDetectionStrategy, Component, inject, OnDestroy, OnInit, signal} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import type {ClinicSlot, ReferralRecord, Site, WaitingListRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-patient-book',
  imports: [MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold text-[#003087]">
          {{ rescheduleId() ? 'Change Your Appointment Time' : 'Book an Outpatient Appointment' }}
        </h1>
        <p class="text-sm text-[#4C6272] mt-1">
          Only times matching your clinician-reviewed requirements (specialty, duration, and equipment) are shown.
        </p>
      </div>

      @if (errorMsg()) {
        <div role="alert" class="bg-[#FEF2F2] border border-[#EF4444] rounded p-4 text-sm text-[#991B1B] flex items-start gap-2.5">
          <mat-icon class="shrink-0 mt-0.5" aria-hidden="true">error</mat-icon>
          <div>
            <strong>Booking notice:</strong> {{ errorMsg() }}
          </div>
        </div>
      }

      @if (successMsg()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-start gap-2.5">
          <mat-icon class="shrink-0 mt-0.5" aria-hidden="true">check_circle</mat-icon>
          <div>{{ successMsg() }}</div>
        </div>
      }

      @if (loading()) {
        <div class="h-48 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
      } @else {
        <!-- Step 1: Choose Referral / Waiting List Offer -->
        <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
          <h2 class="text-lg font-bold text-[#212B32]">1. Your Approved Referrals</h2>
          @if (eligibleReferrals().length === 0) {
            <div class="bg-[#FFFBEB] border border-[#F59E0B] rounded p-4 text-sm text-[#212B32]">
              <strong class="text-[#92400E]">Warning: No reviewed referrals ready for self-booking.</strong>
              If your GP recently referred you, a clinician is reviewing your referral. You can also call the booking team on <strong>01282 550100</strong>.
            </div>
          } @else {
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              @for (ref of eligibleReferrals(); track ref.id) {
                <button
                  type="button"
                  (click)="selectReferral(ref.id)"
                  class="text-left p-4 rounded border transition-colors cursor-pointer"
                  [class]="selectedReferralId() === ref.id ? 'bg-[#EFF6FF] border-[#005EB8]' : 'bg-white border-[#D8DDE0] hover:border-[#005EB8]'"
                >
                  <div class="flex items-center justify-between gap-2">
                    <span class="font-bold text-[#212B32]">{{ ref.specialty }}</span>
                    <app-status-label [label]="ref.clinical_priority ?? 'Reviewed'" tone="info" />
                  </div>
                  <div class="text-sm text-[#4C6272] mt-1">{{ ref.service_name }}</div>
                  <div class="text-xs text-[#4C6272] mt-2 tabular-nums">
                    {{ ref.appointment_type }} · {{ ref.duration_minutes }} min
                    @if (ref.required_equipment) {
                      · {{ ref.required_equipment }}
                    }
                  </div>
                </button>
              }
            </div>
          }
        </section>

        <!-- Step 2: Filter & Choose Slot -->
        @if (selectedReferral(); as ref) {
          <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-5">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 class="text-lg font-bold text-[#212B32]">2. Choose a Suitable Time</h2>
                <p class="text-xs text-[#4C6272]">
                  Showing {{ ref.specialty }} slots ({{ ref.duration_minutes }} minutes minimum) in Europe/London time.
                </p>
              </div>
              <div class="flex flex-wrap items-center gap-3">
                <select
                  aria-label="Filter by hospital site"
                  [value]="siteFilter()"
                  (change)="onSiteChange($event)"
                  class="min-h-[40px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm"
                >
                  <option value="">All hospital sites</option>
                  @for (s of sites(); track s.id) {
                    <option [value]="s.id">{{ s.name }}</option>
                  }
                </select>
                @if (selectedWaitingList(); as wl) {
                  <button
                    type="button"
                    (click)="toggleShortNotice(wl)"
                    class="min-h-[40px] px-3.5 py-1.5 rounded border text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    [class]="wl.short_notice_opt_in ? 'bg-[#ECFDF5] border-[#10B981] text-[#065F46]' : 'bg-white border-[#768692] text-[#212B32]'"
                  >
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">
                      {{ wl.short_notice_opt_in ? 'check_box' : 'check_box_outline_blank' }}
                    </mat-icon>
                    <span>Short-notice cancellation list</span>
                  </button>
                }
              </div>
            </div>

            <!-- Active Hold Banner -->
            @if (heldSlot(); as held) {
              <div class="bg-[#FFFBEB] border border-[#F59E0B] rounded-lg p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div class="flex items-start gap-3">
                  <mat-icon class="text-[#B45309] shrink-0 mt-0.5" aria-hidden="true">timer</mat-icon>
                  <div>
                    <div class="font-bold text-[#92400E]">
                      Slot held for you: {{ held.slot_date }} at {{ held.start_time }}–{{ held.end_time }}
                    </div>
                    <p class="text-xs text-[#212B32] mt-0.5">
                      {{ held.site_name }} · {{ held.room_name }} · {{ held.clinician_name }}.
                      Please confirm within <span class="font-mono font-bold tabular-nums">{{ countdownLabel() }}</span> before the temporary hold expires.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  [disabled]="confirming()"
                  (click)="confirmHeldBooking()"
                  class="min-h-[44px] px-5 py-2 bg-[#007F3B] hover:bg-[#00662F] text-white font-semibold rounded inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <mat-icon aria-hidden="true">check_circle</mat-icon>
                  <span>{{ confirming() ? 'Confirming...' : 'Confirm booking' }}</span>
                </button>
              </div>
            }

            @if (slots().length === 0) {
              <div class="bg-[#F8FAFC] border border-[#D8DDE0] rounded p-6 space-y-3">
                <p class="font-semibold text-[#212B32]">
                  No suitable times are currently available matching your referral requirements.
                </p>
                <p class="text-sm text-[#4C6272]">
                  Your place on the waiting list is preserved. Request assistance from our booking team and we will contact you by telephone or post.
                </p>
                <button
                  type="button"
                  (click)="requestStaffAssistance(ref.id)"
                  class="min-h-[44px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center gap-2 cursor-pointer"
                >
                  <mat-icon aria-hidden="true">support_agent</mat-icon>
                  <span>Request booking team assistance</span>
                </button>
              </div>
            } @else {
              <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                @for (slot of slots(); track slot.id) {
                  <div class="border border-[#D8DDE0] rounded p-4 flex flex-col justify-between gap-3 bg-white">
                    <div>
                      <div class="font-mono font-bold text-base text-[#003087] tabular-nums">
                        {{ slot.slot_date }} · {{ slot.start_time }}–{{ slot.end_time }}
                      </div>
                      <div class="text-sm font-medium text-[#212B32] mt-1">{{ slot.site_name }}</div>
                      <div class="text-xs text-[#4C6272] mt-0.5">
                        {{ slot.room_name }} · {{ slot.clinician_name }}
                      </div>
                      <div class="text-xs text-[#4C6272] mt-1">
                        {{ slot.modality }} · {{ slot.duration_minutes }} min
                      </div>
                    </div>
                    <button
                      type="button"
                      (click)="holdSlot(slot)"
                      [disabled]="heldSlot()?.id === slot.id"
                      class="w-full min-h-[42px] px-4 py-2 text-sm font-semibold rounded flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      [class]="heldSlot()?.id === slot.id ? 'bg-[#ECFDF5] text-[#065F46] border border-[#10B981]' : 'bg-[#005EB8] hover:bg-[#003087] text-white'"
                    >
                      <mat-icon class="!text-[18px] !w-[18px] !h-[18px]" aria-hidden="true">
                        {{ heldSlot()?.id === slot.id ? 'lock_clock' : 'touch_app' }}
                      </mat-icon>
                      <span>{{ heldSlot()?.id === slot.id ? 'Held by you' : 'Hold this time' }}</span>
                    </button>
                  </div>
                }
              </div>
            }
          </section>
        }
      }
    </div>
  `,
})
export class PatientBook implements OnInit, OnDestroy {
  private readonly api = inject(ApiService);
  private readonly auth = inject(AuthService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly confirming = signal(false);
  readonly referrals = signal<ReferralRecord[]>([]);
  readonly waitingLists = signal<WaitingListRecord[]>([]);
  readonly sites = signal<Site[]>([]);
  readonly slots = signal<ClinicSlot[]>([]);
  readonly selectedReferralId = signal<string | null>(null);
  readonly rescheduleId = signal<string | null>(null);
  readonly siteFilter = signal<string>('');
  readonly heldSlot = signal<ClinicSlot | null>(null);
  readonly holdExpiresAt = signal<string | null>(null);
  readonly countdownLabel = signal<string>('10:00');
  readonly errorMsg = signal<string | null>(null);
  readonly successMsg = signal<string | null>(null);

  private timerHandle: ReturnType<typeof setInterval> | null = null;

  readonly eligibleReferrals = () =>
    this.referrals().filter((r) => r.review_status === 'Accepted');

  readonly selectedReferral = () =>
    this.referrals().find((r) => r.id === this.selectedReferralId()) ?? null;

  readonly selectedWaitingList = () =>
    this.waitingLists().find((w) => w.referral_id === this.selectedReferralId()) ?? null;

  async ngOnInit(): Promise<void> {
    const pid = this.auth.activePatientId();
    const qp = this.route.snapshot.queryParamMap;
    this.rescheduleId.set(qp.get('rescheduleId'));
    const refParam = qp.get('referralId');

    if (!pid) {
      this.loading.set(false);
      return;
    }

    try {
      const [refRes, wlRes, sitesRes] = await Promise.all([
        this.api.getReferrals({patientId: pid}),
        this.api.getWaitingLists(pid),
        this.api.getSites(),
      ]);
      this.referrals.set(refRes.referrals);
      this.waitingLists.set(wlRes.waiting_lists);
      this.sites.set(sitesRes.sites);

      const accepted = refRes.referrals.filter((r) => r.review_status === 'Accepted');
      const initialRef = refParam ?? accepted[0]?.id ?? null;
      if (initialRef) {
        await this.selectReferral(initialRef);
      }
    } finally {
      this.loading.set(false);
    }

    this.timerHandle = setInterval(() => this.updateCountdown(), 1000);
  }

  ngOnDestroy(): void {
    if (this.timerHandle) clearInterval(this.timerHandle);
  }

  private updateCountdown(): void {
    const exp = this.holdExpiresAt();
    if (!exp) return;
    const diff = Math.max(0, Math.floor((new Date(exp).getTime() - Date.now()) / 1000));
    const mins = Math.floor(diff / 60);
    const secs = diff % 60;
    this.countdownLabel.set(`${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`);
    if (diff === 0) {
      this.heldSlot.set(null);
      this.holdExpiresAt.set(null);
      this.errorMsg.set('Your temporary slot hold expired. Please select another time.');
      if (this.selectedReferralId()) {
        void this.loadSlots(this.selectedReferralId()!);
      }
    }
  }

  async selectReferral(referralId: string): Promise<void> {
    this.selectedReferralId.set(referralId);
    this.heldSlot.set(null);
    this.holdExpiresAt.set(null);
    this.errorMsg.set(null);
    await this.loadSlots(referralId);
  }

  async onSiteChange(ev: Event): Promise<void> {
    const val = (ev.target as HTMLSelectElement).value;
    this.siteFilter.set(val);
    if (this.selectedReferralId()) {
      await this.loadSlots(this.selectedReferralId()!);
    }
  }

  private async loadSlots(referralId: string): Promise<void> {
    const res = await this.api.getEligibleSlots(referralId, undefined, this.siteFilter() || undefined);
    this.slots.set(res.slots);
  }

  async holdSlot(slot: ClinicSlot): Promise<void> {
    const pid = this.auth.activePatientId();
    const refId = this.selectedReferralId();
    if (!pid || !refId) return;
    this.errorMsg.set(null);
    this.successMsg.set(null);
    try {
      const res = await this.api.holdSlot(slot.id, pid, refId);
      this.heldSlot.set(slot);
      this.holdExpiresAt.set(res.holdExpiresAt);
      this.updateCountdown();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Could not hold this slot. Please choose another time.');
      await this.loadSlots(refId);
    }
  }

  async confirmHeldBooking(): Promise<void> {
    const held = this.heldSlot();
    const pid = this.auth.activePatientId();
    const refId = this.selectedReferralId();
    if (!held || !pid || !refId) return;

    this.confirming.set(true);
    this.errorMsg.set(null);
    try {
      if (this.rescheduleId()) {
        const res = await this.api.rescheduleAppointment(
          this.rescheduleId()!,
          held.id,
          'Patient selected new time via self-service portal',
        );
        this.successMsg.set(
          `Appointment rescheduled to ${res.new_appointment.local_date} at ${res.new_appointment.local_start_time} (Ref: ${res.new_appointment.id}).`,
        );
      } else {
        const res = await this.api.bookAppointment({
          slot_id: held.id,
          patient_id: pid,
          referral_id: refId,
        });
        this.successMsg.set(
          `Booking confirmed for ${res.appointment.local_date} at ${res.appointment.local_start_time} (Ref: ${res.appointment.id}). A confirmation notice has been sent.`,
        );
      }
      this.heldSlot.set(null);
      this.holdExpiresAt.set(null);
      setTimeout(() => {
        void this.router.navigate(['/patient/appointments']);
      }, 1400);
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Booking confirmation failed.');
      await this.loadSlots(refId);
    } finally {
      this.confirming.set(false);
    }
  }

  async toggleShortNotice(wl: WaitingListRecord): Promise<void> {
    const next = wl.short_notice_opt_in === 0;
    await this.api.toggleShortNotice(wl.id, next);
    const pid = this.auth.activePatientId();
    if (pid) {
      const res = await this.api.getWaitingLists(pid);
      this.waitingLists.set(res.waiting_lists);
    }
  }

  async requestStaffAssistance(referralId: string): Promise<void> {
    const pid = this.auth.activePatientId();
    if (!pid) return;
    await this.api.requestHelp(
      pid,
      'No suitable appointment slots',
      'Patient requested telephone callback from booking team.',
      referralId,
    );
    this.successMsg.set(
      'Your request has been sent to the booking team. Your waiting-list position remains preserved.',
    );
  }
}
