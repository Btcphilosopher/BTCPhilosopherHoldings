import {Routes} from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'login',
  },
  {
    path: 'login',
    loadComponent: () => import('./pages/login').then((m) => m.LoginPage),
  },
  {
    path: 'patient',
    loadComponent: () => import('./patient/patient-shell').then((m) => m.PatientShell),
    children: [
      {path: '', pathMatch: 'full', redirectTo: 'home'},
      {path: 'home', loadComponent: () => import('./patient/patient-home').then((m) => m.PatientHome)},
      {
        path: 'appointments',
        loadComponent: () => import('./patient/patient-appointments').then((m) => m.PatientAppointments),
      },
      {path: 'book', loadComponent: () => import('./patient/patient-book').then((m) => m.PatientBook)},
      {
        path: 'messages',
        loadComponent: () => import('./patient/patient-messages').then((m) => m.PatientMessages),
      },
      {path: 'help', loadComponent: () => import('./patient/patient-help').then((m) => m.PatientHelp)},
      {
        path: 'account',
        loadComponent: () => import('./patient/patient-account').then((m) => m.PatientAccount),
      },
    ],
  },
  {
    path: 'staff',
    loadComponent: () => import('./staff/staff-shell').then((m) => m.StaffShell),
    children: [
      {path: '', pathMatch: 'full', redirectTo: 'overview'},
      {
        path: 'overview',
        loadComponent: () => import('./staff/staff-overview').then((m) => m.StaffOverview),
      },
      {
        path: 'referrals',
        loadComponent: () => import('./staff/staff-referrals').then((m) => m.StaffReferrals),
      },
      {
        path: 'waiting-lists',
        loadComponent: () => import('./staff/staff-waiting-lists').then((m) => m.StaffWaitingLists),
      },
      {
        path: 'clinics',
        loadComponent: () => import('./staff/staff-clinics').then((m) => m.StaffClinics),
      },
      {
        path: 'appointments',
        loadComponent: () => import('./staff/staff-appointments').then((m) => m.StaffAppointments),
      },
      {
        path: 'patients',
        loadComponent: () => import('./staff/staff-patients').then((m) => m.StaffPatients),
      },
      {path: 'tasks', loadComponent: () => import('./staff/staff-tasks').then((m) => m.StaffTasks)},
      {
        path: 'reports',
        loadComponent: () => import('./staff/staff-reports').then((m) => m.StaffReports),
      },
      {path: 'admin', loadComponent: () => import('./staff/staff-admin').then((m) => m.StaffAdmin)},
    ],
  },
  {
    path: '**',
    redirectTo: 'login',
  },
];
