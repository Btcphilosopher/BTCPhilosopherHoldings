import {ChangeDetectionStrategy, Component, computed, input} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';

@Component({
  selector: 'app-status-label',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <span [class]="boxClass()">
      <mat-icon class="!text-[15px] !w-[15px] !h-[15px] leading-none shrink-0" aria-hidden="true">{{ icon() }}</mat-icon>
      <span class="whitespace-nowrap">{{ prefix() }}{{ label() }}</span>
    </span>
  `,
})
export class StatusLabel {
  readonly label = input.required<string>();
  readonly tone = input<'neutral' | 'info' | 'success' | 'warning' | 'urgent'>('neutral');
  readonly prefix = input<string>('');

  readonly icon = computed(() => {
    switch (this.tone()) {
      case 'urgent':
        return 'error';
      case 'warning':
        return 'warning';
      case 'success':
        return 'check_circle';
      case 'info':
        return 'info';
      default:
        return 'schedule';
    }
  });

  readonly boxClass = computed(() => {
    const base =
      'inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium border whitespace-nowrap shrink-0';
    switch (this.tone()) {
      case 'urgent':
        return `${base} bg-[#FEF2F2] text-[#991B1B] border-[#FCA5A5]`;
      case 'warning':
        return `${base} bg-[#FFFBEB] text-[#92400E] border-[#FCD34D]`;
      case 'success':
        return `${base} bg-[#ECFDF5] text-[#065F46] border-[#A7F3D0]`;
      case 'info':
        return `${base} bg-[#EFF6FF] text-[#003087] border-[#BFDBFE]`;
      default:
        return `${base} bg-[#F8FAFC] text-[#334155] border-[#CBD5E1]`;
    }
  });
}
