import {computed, inject, Injectable, signal} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router';
import {firstValueFrom} from 'rxjs';
import type {AccessiblePatientSummary, AuthUser} from './models';

@Injectable({providedIn: 'root'})
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  // Kept strictly in memory (never localStorage/sessionStorage) per security policy
  private readonly tokenSig = signal<string | null>(null);
  readonly user = signal<AuthUser | null>(null);
  readonly accessiblePatients = signal<AccessiblePatientSummary[]>([]);
  readonly activePatientId = signal<string | null>(null);

  readonly isAuthenticated = computed(() => this.tokenSig() !== null && this.user() !== null);
  readonly isPatientPortalUser = computed(() => {
    const r = this.user()?.role;
    return r === 'PATIENT' || r === 'PROXY';
  });
  readonly isClinician = computed(() => {
    const r = this.user()?.role;
    return r === 'CLINICIAN' || r === 'TRIAGE_NURSE' || r === 'CLINICAL_LEAD';
  });

  getToken(): string | null {
    return this.tokenSig();
  }

  async getPersonas(): Promise<AuthUser[]> {
    const res = await firstValueFrom(
      this.http.get<{personas: AuthUser[]}>('/api/auth/personas'),
    );
    return res.personas;
  }

  async login(username: string, password: string): Promise<AuthUser> {
    const res = await firstValueFrom(
      this.http.post<{token: string; user: AuthUser}>('/api/auth/login', {
        username,
        password,
      }),
    );
    this.tokenSig.set(res.token);
    this.user.set(res.user);

    const me = await firstValueFrom(
      this.http.get<{user: AuthUser; accessible_patients: AccessiblePatientSummary[]}>(
        '/api/auth/me',
        {headers: {Authorization: `Bearer ${res.token}`}},
      ),
    );
    this.accessiblePatients.set(me.accessible_patients ?? []);
    if (res.user.patient_id) {
      this.activePatientId.set(res.user.patient_id);
    } else if (me.accessible_patients?.length > 0) {
      this.activePatientId.set(me.accessible_patients[0].id);
    } else {
      this.activePatientId.set(null);
    }
    return res.user;
  }

  logout(): void {
    this.tokenSig.set(null);
    this.user.set(null);
    this.accessiblePatients.set([]);
    this.activePatientId.set(null);
    void this.router.navigate(['/login']);
  }
}
