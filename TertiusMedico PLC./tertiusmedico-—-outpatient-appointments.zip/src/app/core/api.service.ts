import {inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {firstValueFrom} from 'rxjs';
import {AuthService} from './auth.service';
import type {
  AffectedQueueItem,
  AppointmentRecord,
  Clinician,
  ClinicSession,
  ClinicSlot,
  ClinicTemplate,
  NotificationRecord,
  OperationalReport,
  PatientRecord,
  ProxyRelationship,
  ReferralRecord,
  Room,
  Site,
  StaffTaskRecord,
  WaitingListRecord,
} from './models';

@Injectable({providedIn: 'root'})
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);

  private headers(): HttpHeaders {
    const token = this.auth.getToken();
    return new HttpHeaders(token ? {Authorization: `Bearer ${token}`} : {});
  }

  getSites() {
    return firstValueFrom(
      this.http.get<{sites: Site[]; rooms: Room[]; clinicians: Clinician[]}>('/api/sites', {
        headers: this.headers(),
      }),
    );
  }

  getPatients(q = '') {
    const qs = q ? `?q=${encodeURIComponent(q)}` : '';
    return firstValueFrom(
      this.http.get<{patients: PatientRecord[]}>(`/api/patients${qs}`, {
        headers: this.headers(),
      }),
    );
  }

  getPatientDetail(patientId: string) {
    return firstValueFrom(
      this.http.get<{
        patient: PatientRecord;
        proxies: ProxyRelationship[];
        documents: {id: string; title: string; doc_type: string; referral_id: string | null; uploaded_by: string; created_at: string}[];
      }>(`/api/patients/${encodeURIComponent(patientId)}`, {headers: this.headers()}),
    );
  }

  updatePatientPreferences(patientId: string, payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.patch<{patient: PatientRecord}>(
        `/api/patients/${encodeURIComponent(patientId)}/preferences`,
        payload,
        {headers: this.headers()},
      ),
    );
  }

  downloadDocument(docId: string) {
    return firstValueFrom(
      this.http.get<{document: {title: string; doc_type: string}; content: string}>(
        `/api/documents/${encodeURIComponent(docId)}/download`,
        {headers: this.headers()},
      ),
    );
  }

  getReferrals(params: {patientId?: string; specialty?: string; reviewStatus?: string} = {}) {
    const q = new URLSearchParams();
    if (params.patientId) q.set('patient_id', params.patientId);
    if (params.specialty) q.set('specialty', params.specialty);
    if (params.reviewStatus) q.set('review_status', params.reviewStatus);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return firstValueFrom(
      this.http.get<{referrals: ReferralRecord[]}>(`/api/referrals${qs}`, {
        headers: this.headers(),
      }),
    );
  }

  createReferral(payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{id: string}>('/api/referrals', payload, {headers: this.headers()}),
    );
  }

  reviewReferral(referralId: string, payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{referral: ReferralRecord}>(
        `/api/referrals/${encodeURIComponent(referralId)}/review`,
        payload,
        {headers: this.headers()},
      ),
    );
  }

  getReferralHistory(referralId: string) {
    return firstValueFrom(
      this.http.get<{
        history: {id: string; actor_name: string; actor_role: string; action: string; previous_priority: string | null; new_priority: string | null; notes: string; created_at: string}[];
        documents: {id: string; title: string; doc_type: string; uploaded_by: string; created_at: string}[];
      }>(`/api/referrals/${encodeURIComponent(referralId)}/history`, {headers: this.headers()}),
    );
  }

  getWaitingLists(patientId?: string) {
    const qs = patientId ? `?patient_id=${encodeURIComponent(patientId)}` : '';
    return firstValueFrom(
      this.http.get<{waiting_lists: WaitingListRecord[]}>(`/api/waiting-lists${qs}`, {
        headers: this.headers(),
      }),
    );
  }

  sendOffer(waitingListId: string) {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        `/api/waiting-lists/${encodeURIComponent(waitingListId)}/send-offer`,
        {},
        {headers: this.headers()},
      ),
    );
  }

  toggleShortNotice(waitingListId: string, optIn: boolean) {
    return firstValueFrom(
      this.http.patch<{short_notice_opt_in: boolean}>(
        `/api/waiting-lists/${encodeURIComponent(waitingListId)}/short-notice`,
        {opt_in: optIn},
        {headers: this.headers()},
      ),
    );
  }

  getClinicTemplates() {
    return firstValueFrom(
      this.http.get<{templates: ClinicTemplate[]; versions: {id: string; template_id: string; version_number: number; effective_from: string; changed_by: string; change_reason: string}[]}>(
        '/api/clinic-templates',
        {headers: this.headers()},
      ),
    );
  }

  updateClinicTemplate(templateId: string, payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.patch<{version: number}>(
        `/api/clinic-templates/${encodeURIComponent(templateId)}`,
        payload,
        {headers: this.headers()},
      ),
    );
  }

  getClinicSessions() {
    return firstValueFrom(
      this.http.get<{
        sessions: ClinicSession[];
        absences: {id: string; clinician_id: string; clinician_name: string; specialty: string; start_date: string; end_date: string; reason: string}[];
        closures: {id: string; room_id: string; room_name: string; site_name: string; start_date: string; end_date: string; reason: string}[];
      }>('/api/clinic-sessions', {headers: this.headers()}),
    );
  }

  generateSession(payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{sessionId: string; slotsCreated: number}>(
        '/api/clinic-sessions/generate',
        payload,
        {headers: this.headers()},
      ),
    );
  }

  recordAbsence(payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{id: string; impacted_sessions: number; affected_bookings: number}>(
        '/api/absences',
        payload,
        {headers: this.headers()},
      ),
    );
  }

  recordRoomClosure(payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{id: string; impacted_sessions: number; affected_bookings: number}>(
        '/api/room-closures',
        payload,
        {headers: this.headers()},
      ),
    );
  }

  getAffectedQueue() {
    return firstValueFrom(
      this.http.get<{affected_queue: AffectedQueueItem[]}>('/api/affected-queue', {
        headers: this.headers(),
      }),
    );
  }

  getBulkPreview() {
    return firstValueFrom(
      this.http.get<{
        previews: {
          queue_id: string;
          appointment_id: string;
          patient_name: string;
          specialty: string;
          local_date: string;
          local_start_time: string;
          trigger_reason: string;
          candidate_slots: ClinicSlot[];
        }[];
      }>('/api/affected-queue/bulk-preview', {headers: this.headers()}),
    );
  }

  getEligibleSlots(referralId?: string, modality?: string, siteId?: string) {
    const q = new URLSearchParams();
    if (referralId) q.set('referral_id', referralId);
    if (modality) q.set('modality', modality);
    if (siteId) q.set('site_id', siteId);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return firstValueFrom(
      this.http.get<{slots: ClinicSlot[]; referral?: ReferralRecord; message?: string}>(
        `/api/slots/eligible${qs}`,
        {headers: this.headers()},
      ),
    );
  }

  holdSlot(slotId: string, patientId: string, referralId: string) {
    return firstValueFrom(
      this.http.post<{slotId: string; holdExpiresAt: string}>(
        `/api/slots/${encodeURIComponent(slotId)}/hold`,
        {patient_id: patientId, referral_id: referralId},
        {headers: this.headers()},
      ),
    );
  }

  checkConflicts(payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{hasConflict: boolean; reasons: string[]}>(
        '/api/appointments/check-conflicts',
        payload,
        {headers: this.headers()},
      ),
    );
  }

  bookAppointment(payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{appointment: AppointmentRecord}>('/api/appointments/book', payload, {
        headers: this.headers(),
      }),
    );
  }

  getAppointments(params: {patientId?: string; specialty?: string; date?: string} = {}) {
    const q = new URLSearchParams();
    if (params.patientId) q.set('patient_id', params.patientId);
    if (params.specialty) q.set('specialty', params.specialty);
    if (params.date) q.set('date', params.date);
    const qs = q.toString() ? `?${q.toString()}` : '';
    return firstValueFrom(
      this.http.get<{appointments: AppointmentRecord[]}>(`/api/appointments${qs}`, {
        headers: this.headers(),
      }),
    );
  }

  transitionAppointment(appointmentId: string, targetState: string, reason?: string) {
    return firstValueFrom(
      this.http.post<{previousState: string; newState: string; appointment: AppointmentRecord}>(
        `/api/appointments/${encodeURIComponent(appointmentId)}/transition`,
        {target_state: targetState, reason},
        {headers: this.headers()},
      ),
    );
  }

  rescheduleAppointment(appointmentId: string, newSlotId: string, reason: string) {
    return firstValueFrom(
      this.http.post<{new_appointment: AppointmentRecord; old_appointment_id: string}>(
        `/api/appointments/${encodeURIComponent(appointmentId)}/reschedule`,
        {new_slot_id: newSlotId, reason},
        {headers: this.headers()},
      ),
    );
  }

  recordOutcome(appointmentId: string, payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{appointment: AppointmentRecord; followup_referral_id: string | null}>(
        `/api/appointments/${encodeURIComponent(appointmentId)}/outcome`,
        payload,
        {headers: this.headers()},
      ),
    );
  }

  getAppointmentLetter(appointmentId: string) {
    return firstValueFrom(
      this.http.get<{letter: Record<string, unknown>}>(
        `/api/appointments/${encodeURIComponent(appointmentId)}/letter`,
        {headers: this.headers()},
      ),
    );
  }

  getNotifications(patientId?: string) {
    const qs = patientId ? `?patient_id=${encodeURIComponent(patientId)}` : '';
    return firstValueFrom(
      this.http.get<{notifications: NotificationRecord[]}>(`/api/notifications${qs}`, {
        headers: this.headers(),
      }),
    );
  }

  markNotificationRead(notifId: string) {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        `/api/notifications/${encodeURIComponent(notifId)}/read`,
        {},
        {headers: this.headers()},
      ),
    );
  }

  queueReminder(appointmentId: string, channel: string, simulateBounce: boolean) {
    return firstValueFrom(
      this.http.post<{notification: NotificationRecord; worker_result: Record<string, number>}>(
        '/api/notifications/queue-reminder',
        {appointment_id: appointmentId, channel, simulate_bounce: simulateBounce},
        {headers: this.headers()},
      ),
    );
  }

  requestHelp(patientId: string, topic: string, details: string, referralId?: string) {
    return firstValueFrom(
      this.http.post<{task_id: string}>(
        '/api/help-request',
        {patient_id: patientId, topic, details, referral_id: referralId},
        {headers: this.headers()},
      ),
    );
  }

  getTasks() {
    return firstValueFrom(
      this.http.get<{tasks: StaffTaskRecord[]}>('/api/tasks', {headers: this.headers()}),
    );
  }

  resolveTask(taskId: string, resolutionNotes: string) {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        `/api/tasks/${encodeURIComponent(taskId)}/resolve`,
        {resolution_notes: resolutionNotes},
        {headers: this.headers()},
      ),
    );
  }

  getOperationalReport() {
    return firstValueFrom(
      this.http.get<OperationalReport>('/api/reports/operational', {headers: this.headers()}),
    );
  }

  getAuditLogs() {
    return firstValueFrom(
      this.http.get<{
        audit_logs: {id: string; actor_name: string; actor_role: string; action: string; entity_type: string; entity_id: string; patient_id: string | null; detail_json: string; created_at: string}[];
      }>('/api/audit-logs', {headers: this.headers()}),
    );
  }

  getIntegrations() {
    return firstValueFrom(
      this.http.get<{
        adapters: {adapter: string; system_name: string; authoritative_fields: string[]; interoperability_profile: string; integration_status: string}[];
        events: {id: string; adapter_name: string; direction: string; idempotency_key: string; external_ref: string; payload_summary: string; status: string; retry_count: number; conflict_detail: string | null; created_at: string}[];
      }>('/api/integrations', {headers: this.headers()}),
    );
  }

  ingestIntegrationEvent(payload: Record<string, unknown>) {
    return firstValueFrom(
      this.http.post<{eventId: string; duplicate: boolean; status: string}>(
        '/api/integrations/ingest',
        payload,
        {headers: this.headers()},
      ),
    );
  }

  getHazardLog() {
    return firstValueFrom(
      this.http.get<{
        hazards: {id: string; category: string; hazard: string; clinical_consequence: string; initial_risk: string; mitigation_controls: string; residual_risk: string; verification_status: string}[];
      }>('/api/hazard-log', {headers: this.headers()}),
    );
  }

  runBackupSnapshot() {
    return firstValueFrom(
      this.http.get<{exported_at: string; counts: Record<string, number>}>('/api/admin/backup', {
        headers: this.headers(),
      }),
    );
  }

  verifyRestoration() {
    return firstValueFrom(
      this.http.post<{integrity_check: string; foreign_key_violations: number; verified_at: string}>(
        '/api/admin/restore-verify',
        {},
        {headers: this.headers()},
      ),
    );
  }

  runWorkerTick() {
    return firstValueFrom(
      this.http.post<{expiredHoldsReleased: number; queuedNotificationsProcessed: number; failedNotificationsRouted: number}>(
        '/api/admin/worker-tick',
        {},
        {headers: this.headers()},
      ),
    );
  }
}
