export type UserRole =
  | 'PATIENT'
  | 'PROXY'
  | 'RECEPTIONIST'
  | 'BOOKING_CLERK'
  | 'TRIAGE_NURSE'
  | 'CLINICIAN'
  | 'CLINICAL_LEAD'
  | 'ADMIN';

export interface AuthUser {
  id: string;
  username: string;
  display_name: string;
  role: UserRole;
  patient_id: string | null;
  clinician_id: string | null;
  specialty: string | null;
  site_id: string | null;
  identity_provider: string;
}

export interface AccessiblePatientSummary {
  id: string;
  full_name: string;
  nhs_number: string;
  nhs_verification_status: string;
  relationship?: string;
  scope?: string;
}

export interface Site {
  id: string;
  name: string;
  code: string;
  address: string;
  postcode: string;
  phone: string;
  accessibility_notes: string;
}

export interface Room {
  id: string;
  site_id: string;
  name: string;
  room_type: string;
  step_free: number;
  hearing_loop: number;
  equipment_list: string;
}

export interface Clinician {
  id: string;
  full_name: string;
  gmc_or_nmc: string;
  role_title: string;
  specialty: string;
  primary_site_id: string;
  staff_directory_ref: string;
}

export interface PatientRecord {
  id: string;
  nhs_number: string | null;
  nhs_verification_status: string;
  full_name: string;
  date_of_birth: string;
  phone: string;
  email: string;
  address: string;
  preferred_contact_channel: string;
  marketing_consent: number;
  appointment_comms_enabled: number;
  accessibility_requirements: string;
  interpreter_required: number;
  interpreter_language: string | null;
  preferred_modality: string;
  preferred_site_id: string | null;
  pas_ref: string;
  epr_ref: string;
  proxy_scope?: string;
  proxy_relationship?: string;
}

export interface ProxyRelationship {
  id: string;
  proxy_user_id: string;
  proxy_name: string;
  patient_id: string;
  relationship: string;
  scope: string;
  verification_status: string;
  verified_by: string | null;
  verified_at: string | null;
  expires_at: string | null;
}

export interface ReferralRecord {
  id: string;
  patient_id: string;
  patient_name?: string;
  nhs_number?: string;
  nhs_verification_status?: string;
  source: string;
  external_ubrn: string | null;
  received_date: string;
  specialty: string;
  service_name: string;
  reason_summary: string;
  clinical_priority: 'Urgent' | 'Soon' | 'Routine' | null;
  administrative_status: string;
  review_status: 'Pending Review' | 'Accepted' | 'Returned for Info' | 'Rejected';
  reviewed_by_name: string | null;
  reviewed_at: string | null;
  review_notes: string | null;
  appointment_type: string;
  duration_minutes: number;
  required_staff_role: string;
  required_room_type: string;
  required_equipment: string | null;
  requires_interpreter_booking: number;
  interpreter_required?: number;
  interpreter_language?: string | null;
  accessibility_requirements?: string;
  booking_window_start: string | null;
  booking_window_end: string | null;
  admin_due_date: string | null;
}

export interface WaitingListRecord {
  id: string;
  referral_id: string;
  patient_id: string;
  patient_name?: string;
  nhs_number?: string;
  specialty: string;
  service_name?: string;
  clinical_priority: 'Urgent' | 'Soon' | 'Routine';
  original_joined_at: string;
  status: string;
  short_notice_opt_in: number;
  preferred_site_id: string | null;
  preferred_modality: string;
  duration_minutes?: number;
  appointment_type?: string;
  required_equipment?: string | null;
  admin_due_date?: string | null;
  administrative_status?: string;
  interpreter_required?: number;
  interpreter_language?: string | null;
  preferred_contact_channel?: string;
  notes: string | null;
}

export interface ClinicTemplate {
  id: string;
  name: string;
  specialty: string;
  site_id: string;
  site_name: string;
  room_id: string;
  room_name: string;
  clinician_id: string;
  clinician_name: string;
  supporting_staff_role: string | null;
  modality: string;
  appointment_types_json: string;
  slot_length_minutes: number;
  buffer_minutes: number;
  break_start_time: string | null;
  break_end_time: string | null;
  required_equipment: string | null;
  protected_urgent_slots: number;
  current_version: number;
}

export interface ClinicSession {
  id: string;
  template_id: string;
  template_version: number;
  specialty: string;
  site_id: string;
  site_name: string;
  room_id: string;
  room_name: string;
  clinician_id: string;
  clinician_name: string;
  supporting_staff: string | null;
  session_date: string;
  start_time: string;
  end_time: string;
  modality: string;
  required_equipment: string | null;
  status: string;
  timezone: string;
  notes: string | null;
  total_slots: number;
  available_slots: number;
  booked_slots: number;
}

export interface ClinicSlot {
  id: string;
  session_id: string;
  specialty: string;
  site_id: string;
  site_name?: string;
  site_address?: string;
  accessibility_notes?: string;
  room_id: string;
  room_name?: string;
  clinician_id: string;
  clinician_name?: string;
  slot_date: string;
  start_time: string;
  end_time: string;
  duration_minutes: number;
  modality: string;
  appointment_type: string;
  required_equipment: string | null;
  is_protected_urgent: number;
  status: string;
  held_by_patient_id: string | null;
  hold_expires_at: string | null;
}

export interface AppointmentRecord {
  id: string;
  patient_id: string;
  patient_name?: string;
  nhs_number?: string;
  referral_id: string;
  waiting_list_id: string | null;
  slot_id: string;
  session_id: string;
  site_id: string;
  site_name?: string;
  site_address?: string;
  site_postcode?: string;
  accessibility_notes?: string;
  room_id: string;
  room_name?: string;
  clinician_id: string;
  clinician_name?: string;
  specialty: string;
  appointment_type: string;
  modality: string;
  local_date: string;
  local_start_time: string;
  local_end_time: string;
  state: string;
  interpreter_language: string | null;
  assistance_notes: string | null;
  accessibility_requirements?: string;
  preparation_instructions: string;
  arrival_time_utc: string | null;
  clinical_outcome: string | null;
  outcome_notes: string | null;
  outcome_recorded_by: string | null;
  outcome_recorded_at: string | null;
  followup_referral_id: string | null;
  rescheduled_from_id: string | null;
  rescheduled_to_id: string | null;
  reschedule_reason: string | null;
  booked_channel: string;
  clinical_priority?: string;
  admin_due_date?: string | null;
}

export interface NotificationRecord {
  id: string;
  patient_id: string;
  patient_name?: string;
  appointment_id: string | null;
  channel: string;
  message_type: string;
  recipient_address: string;
  subject: string;
  body_redacted: string;
  status: string;
  failure_reason: string | null;
  attempt_count: number;
  read_at: string | null;
  scheduled_for_utc: string;
  sent_at_utc: string | null;
  created_at: string;
}

export interface StaffTaskRecord {
  id: string;
  task_type: string;
  priority: string;
  patient_id: string | null;
  patient_name?: string;
  patient_phone?: string;
  preferred_contact_channel?: string;
  referral_id: string | null;
  appointment_id: string | null;
  notification_id: string | null;
  title: string;
  description: string;
  assigned_role: string;
  status: string;
  resolution_notes: string | null;
  resolved_by: string | null;
  resolved_at: string | null;
  created_at: string;
}

export interface AffectedQueueItem {
  id: string;
  appointment_id: string;
  session_id: string;
  patient_id: string;
  patient_name: string;
  local_date: string;
  local_start_time: string;
  specialty: string;
  appointment_state: string;
  clinician_name: string;
  site_name: string;
  room_name: string;
  preferred_contact_channel: string;
  accessibility_requirements: string;
  trigger_type: string;
  trigger_reason: string;
  status: string;
  resolution_notes: string | null;
}

export interface OperationalReport {
  disclaimer: string;
  metrics: {
    referrals_awaiting_review: number;
    unbooked_patients: number;
    available_slots: number;
    scheduled_capacity: number;
    booked_appointments: number;
    completed_activity: number;
    clinic_utilisation_pct: number;
    booking_lead_time_days: number;
    attendance_recorded: number;
    did_not_attend: number;
    patient_cancellations: number;
    provider_cancellations: number;
    reschedules: number;
    failed_communications: number;
    outstanding_outcomes: number;
  };
  by_specialty: {
    specialty: string;
    scheduled_slots: number;
    available_slots: number;
    booked_slots: number;
    completed_appointments: number;
  }[];
}
