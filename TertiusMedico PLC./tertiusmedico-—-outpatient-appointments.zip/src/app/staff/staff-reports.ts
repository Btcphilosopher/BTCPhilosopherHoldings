import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import type {OperationalReport} from '../core/models';

@Component({
  selector: 'app-staff-reports',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold text-[#003087]">Operational Reports</h1>
        <p class="text-sm text-[#4C6272]">
          Distinguishes scheduled clinic capacity, booked appointments, and completed clinical activity.
        </p>
      </div>

      @if (report(); as rep) {
        <div class="bg-[#FFFBEB] border border-[#F59E0B] rounded-lg p-4 text-sm text-[#212B32] flex items-start gap-2.5">
          <mat-icon class="text-[#B45309] shrink-0 mt-0.5" aria-hidden="true">warning</mat-icon>
          <div>
            <strong class="text-[#92400E]">Reporting Scope Notice:</strong> {{ rep.disclaimer }}
          </div>
        </div>

        <!-- Distinct Capacity vs Booked vs Completed Strip -->
        <section class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm">
            <div class="text-xs font-semibold text-[#4C6272]">Scheduled Capacity (Total Active Slots)</div>
            <div class="text-3xl font-bold font-mono tabular-nums text-[#212B32] mt-2">{{ rep.metrics.scheduled_capacity }}</div>
            <div class="text-xs text-[#4C6272] mt-1">{{ rep.metrics.available_slots }} slots currently available</div>
          </div>
          <div class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm">
            <div class="text-xs font-semibold text-[#4C6272]">Booked Appointments (Active Pipeline)</div>
            <div class="text-3xl font-bold font-mono tabular-nums text-[#003087] mt-2">{{ rep.metrics.booked_appointments }}</div>
            <div class="text-xs text-[#4C6272] mt-1">Clinic utilisation: {{ rep.metrics.clinic_utilisation_pct }}%</div>
          </div>
          <div class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm">
            <div class="text-xs font-semibold text-[#4C6272]">Completed Activity (Delivered Clinics)</div>
            <div class="text-3xl font-bold font-mono tabular-nums text-[#065F46] mt-2">{{ rep.metrics.completed_activity }}</div>
            <div class="text-xs text-[#4C6272] mt-1">Attendance recorded: {{ rep.metrics.attendance_recorded }}</div>
          </div>
        </section>

        <!-- Full 10 Operational Metrics Table -->
        <section class="bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
          <div class="p-4 border-b border-[#E8EDEE]">
            <h2 class="font-bold text-[#212B32]">Outpatient Operational Metrics</h2>
          </div>
          <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 divide-y sm:divide-y-0 sm:divide-x divide-[#E8EDEE] text-sm">
            <div class="p-4"><div class="text-xs text-[#4C6272]">Referrals awaiting review</div><div class="text-xl font-bold font-mono tabular-nums mt-1">{{ rep.metrics.referrals_awaiting_review }}</div></div>
            <div class="p-4"><div class="text-xs text-[#4C6272]">Unbooked waiting list</div><div class="text-xl font-bold font-mono tabular-nums mt-1">{{ rep.metrics.unbooked_patients }}</div></div>
            <div class="p-4"><div class="text-xs text-[#4C6272]">Avg booking lead time</div><div class="text-xl font-bold font-mono tabular-nums mt-1">{{ rep.metrics.booking_lead_time_days }} d</div></div>
            <div class="p-4"><div class="text-xs text-[#4C6272]">Patient / Provider cancels</div><div class="text-xl font-bold font-mono tabular-nums mt-1">{{ rep.metrics.patient_cancellations }} / {{ rep.metrics.provider_cancellations }}</div></div>
            <div class="p-4"><div class="text-xs text-[#4C6272]">Reschedules / DNA</div><div class="text-xl font-bold font-mono tabular-nums mt-1">{{ rep.metrics.reschedules }} / {{ rep.metrics.did_not_attend }}</div></div>
          </div>
          <div class="grid grid-cols-2 divide-x divide-[#E8EDEE] border-t border-[#E8EDEE] text-sm">
            <div class="p-4"><div class="text-xs text-[#4C6272]">Failed communications</div><div class="text-xl font-bold font-mono tabular-nums text-[#991B1B] mt-1">{{ rep.metrics.failed_communications }}</div></div>
            <div class="p-4"><div class="text-xs text-[#4C6272]">Outstanding clinical outcomes</div><div class="text-xl font-bold font-mono tabular-nums text-[#92400E] mt-1">{{ rep.metrics.outstanding_outcomes }}</div></div>
          </div>
        </section>

        <!-- Specialty Breakdown -->
        <section class="bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
          <div class="p-4 border-b border-[#E8EDEE]">
            <h2 class="font-bold text-[#212B32]">Capacity vs Booked vs Completed by Specialty</h2>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
                <tr>
                  <th class="py-2.5 px-4 font-semibold">Specialty</th>
                  <th class="py-2.5 px-3 font-semibold text-right">Scheduled Slots</th>
                  <th class="py-2.5 px-3 font-semibold text-right">Available Slots</th>
                  <th class="py-2.5 px-3 font-semibold text-right">Booked Slots</th>
                  <th class="py-2.5 px-4 font-semibold text-right">Completed Activity</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#E8EDEE]">
                @for (row of rep.by_specialty; track row.specialty) {
                  <tr>
                    <td class="py-3 px-4 font-semibold text-[#212B32]">{{ row.specialty }}</td>
                    <td class="py-3 px-3 text-right font-mono tabular-nums">{{ row.scheduled_slots }}</td>
                    <td class="py-3 px-3 text-right font-mono tabular-nums">{{ row.available_slots }}</td>
                    <td class="py-3 px-3 text-right font-mono tabular-nums">{{ row.booked_slots }}</td>
                    <td class="py-3 px-4 text-right font-mono tabular-nums">{{ row.completed_appointments }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      }
    </div>
  `,
})
export class StaffReports implements OnInit {
  private readonly api = inject(ApiService);
  readonly report = signal<OperationalReport | null>(null);

  async ngOnInit(): Promise<void> {
    const res = await this.api.getOperationalReport();
    this.report.set(res);
  }
}
