import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {Router} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import type {WaitingListRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-waiting-lists',
  imports: [MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-[#003087]">Waiting Lists &amp; Unbooked Worklist</h1>
          <p class="text-sm text-[#4C6272]">
            Clinical priority is displayed separately from administrative target dates. Original waiting-list dates are preserved across cancellations and reschedules.
          </p>
        </div>
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="filterMode.set('unbooked')"
            class="px-3.5 py-2 text-xs font-semibold rounded border cursor-pointer"
            [class]="filterMode() === 'unbooked' ? 'bg-[#005EB8] text-white border-[#005EB8]' : 'bg-white text-[#212B32] border-[#D8DDE0]'"
          >
            Unbooked only
          </button>
          <button
            type="button"
            (click)="filterMode.set('all')"
            class="px-3.5 py-2 text-xs font-semibold rounded border cursor-pointer"
            [class]="filterMode() === 'all' ? 'bg-[#005EB8] text-white border-[#005EB8]' : 'bg-white text-[#212B32] border-[#D8DDE0]'"
          >
            All entries
          </button>
        </div>
      </div>

      @if (feedback()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-center gap-2">
          <mat-icon aria-hidden="true">check_circle</mat-icon>
          <span>{{ feedback() }}</span>
        </div>
      }

      <section class="bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
              <tr>
                <th class="py-3 px-4 font-semibold">Patient &amp; Referral</th>
                <th class="py-3 px-3 font-semibold">Specialty &amp; Req</th>
                <th class="py-3 px-3 font-semibold">Clinical Priority</th>
                <th class="py-3 px-3 font-semibold">Original Joined Date</th>
                <th class="py-3 px-3 font-semibold">Admin Target</th>
                <th class="py-3 px-3 font-semibold">WL Status</th>
                <th class="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#E8EDEE]">
              @for (wl of visibleRows(); track wl.id) {
                <tr class="hover:bg-[#F8FAFC]">
                  <td class="py-3 px-4">
                    <div class="font-semibold text-[#212B32]">{{ wl.patient_name }}</div>
                    <div class="text-xs font-mono text-[#4C6272]">
                      {{ wl.referral_id }} · {{ wl.preferred_contact_channel }}
                      @if (wl.interpreter_required) {
                        · Interpreter: {{ wl.interpreter_language }}
                      }
                    </div>
                  </td>
                  <td class="py-3 px-3 text-xs">
                    <div class="font-medium text-[#212B32]">{{ wl.specialty }} ({{ wl.duration_minutes }}m)</div>
                    <div class="text-[#4C6272]">{{ wl.required_equipment ?? 'Standard room' }}</div>
                  </td>
                  <td class="py-3 px-3">
                    <app-status-label
                      [label]="wl.clinical_priority"
                      [tone]="wl.clinical_priority === 'Urgent' ? 'urgent' : wl.clinical_priority === 'Soon' ? 'warning' : 'neutral'"
                    />
                  </td>
                  <td class="py-3 px-3 font-mono text-xs tabular-nums text-[#212B32]">
                    {{ wl.original_joined_at.slice(0, 10) }}
                  </td>
                  <td class="py-3 px-3 font-mono text-xs tabular-nums text-[#4C6272]">
                    {{ wl.admin_due_date ?? '—' }}
                  </td>
                  <td class="py-3 px-3 text-xs">
                    <span class="font-medium text-[#212B32]">{{ wl.status }}</span>
                    @if (wl.short_notice_opt_in) {
                      <div class="text-[11px] text-[#065F46]">Short-notice opt-in</div>
                    }
                  </td>
                  <td class="py-3 px-4 text-right space-x-2 whitespace-nowrap">
                    @if (wl.status === 'Active' || wl.status === 'Offer Pending') {
                      <button
                        type="button"
                        (click)="sendOffer(wl.id)"
                        class="px-3 py-1.5 bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#003087] text-xs font-semibold rounded cursor-pointer"
                      >
                        Send Offer
                      </button>
                      <button
                        type="button"
                        (click)="goToBook(wl)"
                        class="px-3 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded cursor-pointer"
                      >
                        Book Slot
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class StaffWaitingLists implements OnInit {
  private readonly api = inject(ApiService);
  private readonly router = inject(Router);

  readonly rows = signal<WaitingListRecord[]>([]);
  readonly filterMode = signal<'unbooked' | 'all'>('unbooked');
  readonly feedback = signal<string | null>(null);

  readonly visibleRows = () =>
    this.filterMode() === 'unbooked'
      ? this.rows().filter((r) => r.status === 'Active' || r.status === 'Offer Pending')
      : this.rows();

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  async load(): Promise<void> {
    const res = await this.api.getWaitingLists();
    this.rows.set(res.waiting_lists);
  }

  async sendOffer(wlId: string): Promise<void> {
    await this.api.sendOffer(wlId);
    this.feedback.set(`Appointment offer sent to patient (Waiting List ${wlId}).`);
    await this.load();
  }

  goToBook(wl: WaitingListRecord): void {
    void this.router.navigate(['/staff/appointments'], {
      queryParams: {bookReferralId: wl.referral_id, patientId: wl.patient_id},
    });
  }
}
