import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import type {StaffTaskRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-tasks',
  imports: [MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold text-[#003087]">Patient-Contact &amp; Follow-up Tasks</h1>
        <p class="text-sm text-[#4C6272]">
          Failed reminders, telephone booking assistance requests, and clinic disruption follow-ups routed to booking staff.
        </p>
      </div>

      @if (feedback()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-center gap-2">
          <mat-icon aria-hidden="true">check_circle</mat-icon>
          <span>{{ feedback() }}</span>
        </div>
      }

      <div class="space-y-3">
        @for (t of tasks(); track t.id) {
          <article class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm space-y-3">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div class="flex flex-wrap items-center gap-2">
                <span class="font-bold text-[#212B32]">{{ t.title }}</span>
                <app-status-label
                  [label]="t.priority"
                  [tone]="t.priority === 'High' ? 'urgent' : 'warning'"
                  [prefix]="t.priority === 'High' ? 'Urgent: ' : ''"
                />
                <app-status-label
                  [label]="t.status"
                  [tone]="t.status === 'Open' ? 'info' : 'success'"
                />
              </div>
              <span class="text-xs font-mono text-[#4C6272]">{{ t.id }} · {{ t.task_type }}</span>
            </div>

            <p class="text-sm text-[#212B32]">{{ t.description }}</p>

            <div class="text-xs text-[#4C6272] flex flex-wrap gap-4">
              @if (t.patient_name) {
                <span>Patient: <strong>{{ t.patient_name }}</strong> ({{ t.patient_phone }} · Prefers {{ t.preferred_contact_channel }})</span>
              }
              @if (t.appointment_id) {
                <span class="font-mono">Appt: {{ t.appointment_id }}</span>
              }
            </div>

            @if (t.status === 'Open') {
              <div class="pt-3 border-t border-[#E8EDEE] flex flex-col sm:flex-row gap-2">
                <input
                  #noteInput
                  type="text"
                  placeholder="Record contact outcome (e.g. Confirmed by landline)..."
                  class="flex-1 min-h-[40px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm"
                />
                <button
                  type="button"
                  (click)="resolve(t.id, noteInput.value)"
                  class="min-h-[40px] px-4 py-2 bg-[#007F3B] hover:bg-[#00662F] text-white text-xs font-semibold rounded inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">done</mat-icon>
                  <span>Mark resolved</span>
                </button>
              </div>
            } @else {
              <div class="pt-2 border-t border-[#E8EDEE] text-xs text-[#065F46]">
                Resolved by {{ t.resolved_by }}: {{ t.resolution_notes }}
              </div>
            }
          </article>
        }
      </div>
    </div>
  `,
})
export class StaffTasks implements OnInit {
  private readonly api = inject(ApiService);

  readonly tasks = signal<StaffTaskRecord[]>([]);
  readonly feedback = signal<string | null>(null);

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  async load(): Promise<void> {
    const res = await this.api.getTasks();
    this.tasks.set(res.tasks);
  }

  async resolve(taskId: string, notes: string): Promise<void> {
    const text = notes.trim() || 'Patient contacted by telephone and details confirmed.';
    await this.api.resolveTask(taskId, text);
    this.feedback.set(`Task ${taskId} marked resolved and audited.`);
    await this.load();
  }
}
