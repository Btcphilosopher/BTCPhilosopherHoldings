import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import type {AffectedQueueItem, OperationalReport, StaffTaskRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-overview',
  imports: [RouterLink, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-[#003087]">Outpatient Operations Overview</h1>
          <p class="text-sm text-[#4C6272]">
            Pennine General Hospital &amp; Calder Valley Outpatient Annex · Europe/London
          </p>
        </div>
        <a
          routerLink="/staff/admin"
          class="min-h-[42px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <mat-icon aria-hidden="true">playlist_add_check</mat-icon>
          <span>12-Step Demo &amp; Governance</span>
        </a>
      </div>

      @if (loading()) {
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div class="h-28 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
          <div class="h-28 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
          <div class="h-28 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
          <div class="h-28 bg-white border border-[#D8DDE0] rounded-lg animate-pulse"></div>
        </div>
      } @else if (report(); as rep) {
        <!-- Operational KPIs (Tabular Numerals) -->
        <section class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <a routerLink="/staff/referrals" class="bg-white border border-[#D8DDE0] hover:border-[#005EB8] rounded-lg p-5 shadow-sm block">
            <div class="text-xs font-semibold text-[#4C6272]">Awaiting clinical review</div>
            <div class="text-3xl font-bold font-mono tabular-nums text-[#003087] mt-2">
              {{ rep.metrics.referrals_awaiting_review }}
            </div>
            <div class="text-xs text-[#4C6272] mt-1">Clinician triage required</div>
          </a>

          <a routerLink="/staff/waiting-lists" class="bg-white border border-[#D8DDE0] hover:border-[#005EB8] rounded-lg p-5 shadow-sm block">
            <div class="text-xs font-semibold text-[#4C6272]">Unbooked waiting list</div>
            <div class="text-3xl font-bold font-mono tabular-nums text-[#212B32] mt-2">
              {{ rep.metrics.unbooked_patients }}
            </div>
            <div class="text-xs text-[#4C6272] mt-1">{{ rep.metrics.available_slots }} compatible slots open</div>
          </a>

          <a routerLink="/staff/clinics" class="bg-white border border-[#D8DDE0] hover:border-[#005EB8] rounded-lg p-5 shadow-sm block">
            <div class="text-xs font-semibold text-[#4C6272]">Affected clinic queue</div>
            <div class="text-3xl font-bold font-mono tabular-nums text-[#92400E] mt-2">
              {{ pendingAffected().length }}
            </div>
            <div class="text-xs text-[#4C6272] mt-1">Absences / room closures</div>
          </a>

          <a routerLink="/staff/tasks" class="bg-white border border-[#D8DDE0] hover:border-[#005EB8] rounded-lg p-5 shadow-sm block">
            <div class="text-xs font-semibold text-[#4C6272]">Open contact tasks</div>
            <div class="text-3xl font-bold font-mono tabular-nums text-[#991B1B] mt-2">
              {{ openTasks().length }}
            </div>
            <div class="text-xs text-[#4C6272] mt-1">{{ rep.metrics.failed_communications }} failed reminders</div>
          </a>
        </section>

        <!-- Urgent & Warning Operational Alerts (text + icon, never color alone) -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
            <div class="flex items-center justify-between gap-2">
              <h2 class="text-lg font-bold text-[#212B32]">Affected Appointments Review Queue</h2>
              <a routerLink="/staff/clinics" class="text-sm font-semibold text-[#005EB8] hover:underline">Manage clinics</a>
            </div>
            @if (pendingAffected().length === 0) {
              <p class="text-sm text-[#4C6272]">All clinic disruption items have been resolved.</p>
            } @else {
              <div class="space-y-3">
                @for (item of pendingAffected(); track item.id) {
                  <div class="bg-[#FFFBEB] border border-[#F59E0B] rounded p-3.5 text-sm space-y-1">
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-bold text-[#92400E]">Warning: {{ item.trigger_type }} · {{ item.appointment_id }}</span>
                      <span class="font-mono text-xs text-[#212B32] tabular-nums">{{ item.local_date }} {{ item.local_start_time }}</span>
                    </div>
                    <div class="text-[#212B32]">{{ item.patient_name }} ({{ item.specialty }}) — {{ item.trigger_reason }}</div>
                  </div>
                }
              </div>
            }
          </section>

          <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
            <div class="flex items-center justify-between gap-2">
              <h2 class="text-lg font-bold text-[#212B32]">Open Staff Contact Tasks</h2>
              <a routerLink="/staff/tasks" class="text-sm font-semibold text-[#005EB8] hover:underline">Open worklist</a>
            </div>
            @if (openTasks().length === 0) {
              <p class="text-sm text-[#4C6272]">No open patient-contact tasks.</p>
            } @else {
              <div class="space-y-3">
                @for (t of openTasks(); track t.id) {
                  <div class="border border-[#D8DDE0] rounded p-3.5 text-sm space-y-1.5">
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-semibold text-[#212B32]">{{ t.title }}</span>
                      <app-status-label
                        [label]="t.priority"
                        [tone]="t.priority === 'High' ? 'urgent' : 'warning'"
                        [prefix]="t.priority === 'High' ? 'Urgent: ' : ''"
                      />
                    </div>
                    <p class="text-xs text-[#4C6272]">{{ t.description }}</p>
                  </div>
                }
              </div>
            }
          </section>
        </div>
      }
    </div>
  `,
})
export class StaffOverview implements OnInit {
  private readonly api = inject(ApiService);

  readonly loading = signal(true);
  readonly report = signal<OperationalReport | null>(null);
  readonly affected = signal<AffectedQueueItem[]>([]);
  readonly tasks = signal<StaffTaskRecord[]>([]);

  readonly pendingAffected = () =>
    this.affected().filter((a) => a.status === 'Pending Review');
  readonly openTasks = () =>
    this.tasks().filter((t) => t.status === 'Open');

  async ngOnInit(): Promise<void> {
    try {
      const [rep, aff, tsk] = await Promise.all([
        this.api.getOperationalReport(),
        this.api.getAffectedQueue(),
        this.api.getTasks(),
      ]);
      this.report.set(rep);
      this.affected.set(aff.affected_queue);
      this.tasks.set(tsk.tasks);
    } finally {
      this.loading.set(false);
    }
  }
}
