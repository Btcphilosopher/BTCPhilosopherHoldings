import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import type {
  AffectedQueueItem,
  Clinician,
  ClinicSession,
  ClinicSlot,
  ClinicTemplate,
  Room,
} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-clinics',
  imports: [ReactiveFormsModule, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="text-2xl font-bold text-[#003087]">Clinics, Templates &amp; Affected Queue</h1>
        <p class="text-sm text-[#4C6272]">
          Versioned clinic templates in Europe/London. Absences or room closures queue affected appointments for review rather than silently altering bookings.
        </p>
      </div>

      @if (feedback()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-center gap-2">
          <mat-icon aria-hidden="true">check_circle</mat-icon>
          <span>{{ feedback() }}</span>
        </div>
      }
      @if (errorMsg()) {
        <div role="alert" class="bg-[#FEF2F2] border border-[#EF4444] rounded p-4 text-sm text-[#991B1B] flex items-center gap-2">
          <mat-icon aria-hidden="true">error</mat-icon>
          <span>{{ errorMsg() }}</span>
        </div>
      }

      <!-- Affected Appointments Review Queue + Bulk Reschedule Preview -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 class="text-lg font-bold text-[#212B32]">Affected Appointments Review Queue</h2>
            <p class="text-xs text-[#4C6272]">Bookings impacted by clinician absence or room unavailability requiring patient contact and audited reschedule.</p>
          </div>
          <button
            type="button"
            (click)="loadBulkPreview()"
            class="min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">preview</mat-icon>
            <span>Preview bulk reschedules</span>
          </button>
        </div>

        @if (affectedQueue().length === 0) {
          <p class="text-sm text-[#4C6272]">No affected bookings awaiting review.</p>
        } @else {
          <div class="space-y-3">
            @for (item of affectedQueue(); track item.id) {
              <div class="p-4 rounded border" [class]="item.status === 'Pending Review' ? 'bg-[#FFFBEB] border-[#F59E0B]' : 'bg-[#F8FAFC] border-[#D8DDE0]'">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span class="font-bold text-sm text-[#212B32]">
                      {{ item.patient_name }} · {{ item.appointment_id }} ({{ item.specialty }})
                    </span>
                    <div class="text-xs text-[#4C6272] mt-0.5 tabular-nums">
                      Original: {{ item.local_date }} {{ item.local_start_time }} · {{ item.site_name }} · {{ item.room_name }}
                    </div>
                    <div class="text-xs text-[#92400E] mt-1 font-medium">
                      Trigger ({{ item.trigger_type }}): {{ item.trigger_reason }}
                    </div>
                  </div>
                  <app-status-label
                    [label]="item.status"
                    [tone]="item.status === 'Pending Review' ? 'warning' : 'success'"
                  />
                </div>
                @if (item.resolution_notes) {
                  <div class="text-xs text-[#065F46] mt-2 font-medium">Resolution: {{ item.resolution_notes }}</div>
                }
              </div>
            }
          </div>
        }

        @if (bulkPreviews().length > 0) {
          <div class="mt-4 pt-4 border-t border-[#E8EDEE] space-y-3">
            <h3 class="text-sm font-bold text-[#003087]">Bulk Reschedule Candidate Slots</h3>
            @for (prev of bulkPreviews(); track prev.queue_id) {
              <div class="p-4 border border-[#BFDBFE] bg-[#EFF6FF] rounded space-y-2">
                <div class="text-sm font-semibold text-[#212B32]">
                  {{ prev.patient_name }} ({{ prev.appointment_id }}) — currently {{ prev.local_date }} {{ prev.local_start_time }}
                </div>
                @if (prev.candidate_slots.length === 0) {
                  <p class="text-xs text-[#991B1B]">No compatible replacement slots found yet. Generate a new session below.</p>
                } @else {
                  <div class="flex flex-wrap gap-2">
                    @for (slot of prev.candidate_slots; track slot.id) {
                      <button
                        type="button"
                        (click)="executeAffectedReschedule(prev.appointment_id, slot.id, prev.trigger_reason)"
                        class="px-3 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded cursor-pointer"
                      >
                        Move to {{ slot.slot_date }} {{ slot.start_time }} ({{ slot.room_name }})
                      </button>
                    }
                  </div>
                }
              </div>
            }
          </div>
        }
      </section>

      <!-- Generate Session + Record Absence / Room Closure -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <section class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm space-y-3">
          <h2 class="text-base font-bold text-[#212B32]">Generate Session from Template</h2>
          <form [formGroup]="genForm" (ngSubmit)="generateSession()" class="space-y-3">
            <div>
              <label for="g-tpl" class="block text-xs font-semibold mb-1">Template</label>
              <select id="g-tpl" formControlName="template_id" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm">
                @for (t of templates(); track t.id) {
                  <option [value]="t.id">{{ t.name }} (v{{ t.current_version }})</option>
                }
              </select>
            </div>
            <div>
              <label for="g-date" class="block text-xs font-semibold mb-1">Session date (Europe/London)</label>
              <input id="g-date" type="date" formControlName="session_date" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label for="g-st" class="block text-xs font-semibold mb-1">Start</label>
                <input id="g-st" type="time" formControlName="start_time" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
              </div>
              <div>
                <label for="g-et" class="block text-xs font-semibold mb-1">End</label>
                <input id="g-et" type="time" formControlName="end_time" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
              </div>
            </div>
            <button type="submit" class="w-full min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded cursor-pointer">
              Generate bookable slots
            </button>
          </form>
        </section>

        <section class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm space-y-3">
          <h2 class="text-base font-bold text-[#212B32]">Record Clinician Absence</h2>
          <form [formGroup]="absForm" (ngSubmit)="submitAbsence()" class="space-y-3">
            <div>
              <label for="a-clin" class="block text-xs font-semibold mb-1">Clinician</label>
              <select id="a-clin" formControlName="clinician_id" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm">
                @for (c of clinicians(); track c.id) {
                  <option [value]="c.id">{{ c.full_name }} ({{ c.specialty }})</option>
                }
              </select>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label for="a-sd" class="block text-xs font-semibold mb-1">From</label>
                <input id="a-sd" type="date" formControlName="start_date" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
              </div>
              <div>
                <label for="a-ed" class="block text-xs font-semibold mb-1">To</label>
                <input id="a-ed" type="date" formControlName="end_date" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
              </div>
            </div>
            <div>
              <label for="a-rsn" class="block text-xs font-semibold mb-1">Reason</label>
              <input id="a-rsn" type="text" formControlName="reason" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
            </div>
            <button type="submit" class="w-full min-h-[40px] px-4 py-2 bg-[#B45309] hover:bg-[#92400E] text-white text-xs font-semibold rounded cursor-pointer">
              Record absence &amp; queue affected
            </button>
          </form>
        </section>

        <section class="bg-white border border-[#D8DDE0] rounded-lg p-5 shadow-sm space-y-3">
          <h2 class="text-base font-bold text-[#212B32]">Record Room Closure</h2>
          <form [formGroup]="roomForm" (ngSubmit)="submitRoomClosure()" class="space-y-3">
            <div>
              <label for="r-rm" class="block text-xs font-semibold mb-1">Room</label>
              <select id="r-rm" formControlName="room_id" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm">
                @for (r of rooms(); track r.id) {
                  <option [value]="r.id">{{ r.name }}</option>
                }
              </select>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label for="r-sd" class="block text-xs font-semibold mb-1">From</label>
                <input id="r-sd" type="date" formControlName="start_date" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
              </div>
              <div>
                <label for="r-ed" class="block text-xs font-semibold mb-1">To</label>
                <input id="r-ed" type="date" formControlName="end_date" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
              </div>
            </div>
            <div>
              <label for="r-rsn" class="block text-xs font-semibold mb-1">Reason</label>
              <input id="r-rsn" type="text" formControlName="reason" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
            </div>
            <button type="submit" class="w-full min-h-[40px] px-4 py-2 bg-[#B45309] hover:bg-[#92400E] text-white text-xs font-semibold rounded cursor-pointer">
              Close room &amp; queue affected
            </button>
          </form>
        </section>
      </div>

      <!-- Clinic Sessions Schedule -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
        <div class="p-4 border-b border-[#E8EDEE] flex items-center justify-between">
          <h2 class="font-bold text-[#212B32]">Scheduled Clinic Sessions ({{ sessions().length }})</h2>
          <span class="text-xs text-[#4C6272]">Timezone: Europe/London</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
              <tr>
                <th class="py-2.5 px-4 font-semibold">Date &amp; Hours</th>
                <th class="py-2.5 px-3 font-semibold">Specialty &amp; Clinician</th>
                <th class="py-2.5 px-3 font-semibold">Site &amp; Room</th>
                <th class="py-2.5 px-3 font-semibold">Template</th>
                <th class="py-2.5 px-3 font-semibold text-right">Slots (Avail / Booked)</th>
                <th class="py-2.5 px-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#E8EDEE]">
              @for (s of sessions(); track s.id) {
                <tr class="hover:bg-[#F8FAFC]">
                  <td class="py-3 px-4 font-mono text-xs tabular-nums">
                    <div class="font-semibold text-[#212B32]">{{ s.session_date }}</div>
                    <div class="text-[#4C6272]">{{ s.start_time }}–{{ s.end_time }}</div>
                  </td>
                  <td class="py-3 px-3 text-xs">
                    <div class="font-semibold text-[#212B32]">{{ s.specialty }}</div>
                    <div class="text-[#4C6272]">{{ s.clinician_name }}</div>
                  </td>
                  <td class="py-3 px-3 text-xs">
                    <div class="text-[#212B32]">{{ s.site_name }}</div>
                    <div class="text-[#4C6272]">{{ s.room_name }} · {{ s.modality }}</div>
                  </td>
                  <td class="py-3 px-3 font-mono text-xs text-[#4C6272]">
                    {{ s.template_id }} v{{ s.template_version }}
                  </td>
                  <td class="py-3 px-3 text-right font-mono text-xs tabular-nums">
                    {{ s.available_slots }} / {{ s.booked_slots }} ({{ s.total_slots }} total)
                  </td>
                  <td class="py-3 px-4">
                    <app-status-label
                      [label]="s.status"
                      [tone]="s.status === 'Active' ? 'success' : 'warning'"
                    />
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Versioned Templates -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
        <div class="p-4 border-b border-[#E8EDEE]">
          <h2 class="font-bold text-[#212B32]">Versioned Clinic Templates</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
              <tr>
                <th class="py-2.5 px-4 font-semibold">Template</th>
                <th class="py-2.5 px-3 font-semibold">Clinician &amp; Room</th>
                <th class="py-2.5 px-3 font-semibold">Length / Buffer / Break</th>
                <th class="py-2.5 px-3 font-semibold">Protected Urgent</th>
                <th class="py-2.5 px-4 font-semibold text-right">Version</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#E8EDEE]">
              @for (t of templates(); track t.id) {
                <tr>
                  <td class="py-3 px-4">
                    <div class="font-semibold text-[#212B32]">{{ t.name }}</div>
                    <div class="text-xs text-[#4C6272]">{{ t.specialty }} · {{ t.required_equipment }}</div>
                  </td>
                  <td class="py-3 px-3 text-xs">
                    <div>{{ t.clinician_name }}</div>
                    <div class="text-[#4C6272]">{{ t.site_name }} · {{ t.room_name }}</div>
                  </td>
                  <td class="py-3 px-3 font-mono text-xs tabular-nums">
                    {{ t.slot_length_minutes }}m / {{ t.buffer_minutes }}m ·
                    {{ t.break_start_time ? t.break_start_time + '–' + t.break_end_time : 'No break' }}
                  </td>
                  <td class="py-3 px-3 font-mono text-xs tabular-nums">{{ t.protected_urgent_slots }} slot(s)</td>
                  <td class="py-3 px-4 text-right font-mono text-xs">
                    v{{ t.current_version }}
                    <button
                      type="button"
                      (click)="bumpTemplateVersion(t)"
                      class="ml-2 px-2 py-1 bg-[#EFF6FF] text-[#003087] rounded font-sans font-semibold cursor-pointer"
                    >
                      New version
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class StaffClinics implements OnInit {
  private readonly api = inject(ApiService);

  readonly templates = signal<ClinicTemplate[]>([]);
  readonly sessions = signal<ClinicSession[]>([]);
  readonly clinicians = signal<Clinician[]>([]);
  readonly rooms = signal<Room[]>([]);
  readonly affectedQueue = signal<AffectedQueueItem[]>([]);
  readonly bulkPreviews = signal<
    {
      queue_id: string;
      appointment_id: string;
      patient_name: string;
      specialty: string;
      local_date: string;
      local_start_time: string;
      trigger_reason: string;
      candidate_slots: ClinicSlot[];
    }[]
  >([]);
  readonly feedback = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  private readonly defaultDate = new Date(Date.now() + 4 * 86400_000).toISOString().slice(0, 10);

  readonly genForm = new FormGroup({
    template_id: new FormControl('TPL-CARD-PGH', {nonNullable: true, validators: [Validators.required]}),
    session_date: new FormControl(this.defaultDate, {nonNullable: true, validators: [Validators.required]}),
    start_time: new FormControl('09:00', {nonNullable: true, validators: [Validators.required]}),
    end_time: new FormControl('12:30', {nonNullable: true, validators: [Validators.required]}),
  });

  readonly absForm = new FormGroup({
    clinician_id: new FormControl('CLIN-OWEN', {nonNullable: true, validators: [Validators.required]}),
    start_date: new FormControl(this.defaultDate, {nonNullable: true, validators: [Validators.required]}),
    end_date: new FormControl(this.defaultDate, {nonNullable: true, validators: [Validators.required]}),
    reason: new FormControl('Unplanned sick leave', {nonNullable: true, validators: [Validators.required]}),
  });

  readonly roomForm = new FormGroup({
    room_id: new FormControl('ROOM-PGH-OP2', {nonNullable: true, validators: [Validators.required]}),
    start_date: new FormControl(this.defaultDate, {nonNullable: true, validators: [Validators.required]}),
    end_date: new FormControl(this.defaultDate, {nonNullable: true, validators: [Validators.required]}),
    reason: new FormControl('Emergency estates maintenance', {nonNullable: true, validators: [Validators.required]}),
  });

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  async load(): Promise<void> {
    const [tpl, ses, ref, aff] = await Promise.all([
      this.api.getClinicTemplates(),
      this.api.getClinicSessions(),
      this.api.getSites(),
      this.api.getAffectedQueue(),
    ]);
    this.templates.set(tpl.templates);
    this.sessions.set(ses.sessions);
    this.clinicians.set(ref.clinicians);
    this.rooms.set(ref.rooms);
    this.affectedQueue.set(aff.affected_queue);
  }

  async generateSession(): Promise<void> {
    this.errorMsg.set(null);
    this.feedback.set(null);
    try {
      const res = await this.api.generateSession(this.genForm.getRawValue());
      this.feedback.set(`Generated clinic session ${res.sessionId} with ${res.slotsCreated} bookable slots.`);
      await this.load();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Could not generate session.');
    }
  }

  async submitAbsence(): Promise<void> {
    this.errorMsg.set(null);
    this.feedback.set(null);
    const res = await this.api.recordAbsence(this.absForm.getRawValue());
    this.feedback.set(
      `Absence recorded (${res.id}). ${res.impacted_sessions} session(s) marked impacted; ${res.affected_bookings} booking(s) queued for review.`,
    );
    await this.load();
  }

  async submitRoomClosure(): Promise<void> {
    this.errorMsg.set(null);
    this.feedback.set(null);
    const res = await this.api.recordRoomClosure(this.roomForm.getRawValue());
    this.feedback.set(
      `Room closure recorded (${res.id}). ${res.impacted_sessions} session(s) marked impacted; ${res.affected_bookings} booking(s) queued for review.`,
    );
    await this.load();
  }

  async loadBulkPreview(): Promise<void> {
    const res = await this.api.getBulkPreview();
    this.bulkPreviews.set(res.previews);
  }

  async executeAffectedReschedule(appointmentId: string, newSlotId: string, reason: string): Promise<void> {
    this.errorMsg.set(null);
    this.feedback.set(null);
    try {
      const res = await this.api.rescheduleAppointment(
        appointmentId,
        newSlotId,
        `Affected clinic reschedule: ${reason}`,
      );
      this.feedback.set(
        `Appointment ${appointmentId} rescheduled to ${res.new_appointment.id} (${res.new_appointment.local_date} ${res.new_appointment.local_start_time}). Notification sent.`,
      );
      await this.load();
      await this.loadBulkPreview();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Could not reschedule appointment.');
    }
  }

  async bumpTemplateVersion(t: ClinicTemplate): Promise<void> {
    const res = await this.api.updateClinicTemplate(t.id, {
      change_reason: 'Routine capacity review by outpatient operations',
    });
    this.feedback.set(`Template ${t.id} updated to version v${res.version}.`);
    await this.load();
  }
}
