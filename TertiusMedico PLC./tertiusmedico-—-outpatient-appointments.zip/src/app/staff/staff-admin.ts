import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {RouterLink} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-admin',
  imports: [RouterLink, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-[#003087]">Administration, Integrations &amp; Governance</h1>
          <p class="text-sm text-[#4C6272]">
            Audit trail, external adapter boundaries, prototype clinical safety hazard log, backup verification, and 12-step demonstration walkthrough.
          </p>
        </div>
        <div class="flex flex-wrap gap-2">
          <button
            type="button"
            (click)="runWorker()"
            class="min-h-[40px] px-3.5 py-2 bg-white border border-[#D8DDE0] hover:bg-[#F8FAFC] text-[#212B32] text-xs font-semibold rounded cursor-pointer"
          >
            Run Hold &amp; Reminder Worker
          </button>
          <button
            type="button"
            (click)="verifyBackup()"
            class="min-h-[40px] px-3.5 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded cursor-pointer"
          >
            Test Backup &amp; Integrity
          </button>
        </div>
      </div>

      @if (adminNotice()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46]">
          {{ adminNotice() }}
        </div>
      }

      <!-- 12-Step Reproducible Demonstration Guide -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
        <h2 class="text-lg font-bold text-[#003087]">12-Step Pennine Outpatient Centre Demonstration</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          @for (step of demoSteps; track step.num) {
            <div class="p-3.5 border border-[#D8DDE0] rounded bg-[#F8FAFC] flex flex-col justify-between gap-2">
              <div>
                <div class="font-bold text-[#212B32]">{{ step.num }}. {{ step.title }}</div>
                <p class="text-[#4C6272] mt-1">{{ step.detail }}</p>
              </div>
              <a [routerLink]="step.route" class="text-[#005EB8] font-semibold hover:underline">
                Open {{ step.area }} →
              </a>
            </div>
          }
        </div>
      </section>

      <!-- Prototype Clinical Safety Hazard Log -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
        <div class="p-4 border-b border-[#E8EDEE]">
          <h2 class="font-bold text-[#212B32]">Prototype Clinical Safety Hazard Log</h2>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-[#4C6272]">
              <tr>
                <th class="py-2.5 px-4 font-semibold">ID &amp; Category</th>
                <th class="py-2.5 px-3 font-semibold">Hazard &amp; Consequence</th>
                <th class="py-2.5 px-3 font-semibold">Mitigation Controls</th>
                <th class="py-2.5 px-4 font-semibold">Residual Risk</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#E8EDEE]">
              @for (h of hazards(); track h.id) {
                <tr>
                  <td class="py-3 px-4 align-top">
                    <div class="font-mono font-bold text-[#003087]">{{ h.id }}</div>
                    <div class="text-[#4C6272]">{{ h.category }}</div>
                  </td>
                  <td class="py-3 px-3 align-top">
                    <div class="font-semibold text-[#212B32]">{{ h.hazard }}</div>
                    <div class="text-[#4C6272] mt-0.5">{{ h.clinical_consequence }}</div>
                  </td>
                  <td class="py-3 px-3 align-top text-[#212B32]">{{ h.mitigation_controls }}</td>
                  <td class="py-3 px-4 align-top">
                    <app-status-label [label]="h.residual_risk + ' (' + h.verification_status + ')'" tone="success" />
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- External-System Integration Boundaries & Idempotency -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 class="text-lg font-bold text-[#212B32]">External Integration Adapters &amp; Field Ownership</h2>
            <p class="text-xs text-[#4C6272]">Mocked adapter boundaries with explicit authoritative fields and idempotent event handling.</p>
          </div>
          <button
            type="button"
            (click)="testIdempotency()"
            class="px-3.5 py-2 bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#003087] text-xs font-semibold rounded cursor-pointer"
          >
            Simulate Duplicate e-RS Event
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          @for (a of adapters(); track a.adapter) {
            <div class="p-3.5 border border-[#D8DDE0] rounded bg-[#F8FAFC] space-y-1">
              <div class="flex items-center justify-between gap-2">
                <span class="font-bold text-[#212B32]">{{ a.adapter }}</span>
                <span class="font-mono text-[#003087]">{{ a.integration_status }}</span>
              </div>
              <div class="text-[#4C6272]">Authoritative fields: <span class="font-mono">{{ a.authoritative_fields.join(', ') }}</span></div>
              <div class="text-[#4C6272]">Profile: {{ a.interoperability_profile }}</div>
            </div>
          }
        </div>

        <div class="overflow-x-auto pt-2">
          <table class="w-full text-left text-xs">
            <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-[#4C6272]">
              <tr>
                <th class="py-2 px-3">Event ID</th>
                <th class="py-2 px-3">Adapter</th>
                <th class="py-2 px-3">Idempotency Key</th>
                <th class="py-2 px-3">Summary</th>
                <th class="py-2 px-3">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#E8EDEE]">
              @for (ev of events(); track ev.id) {
                <tr>
                  <td class="py-2 px-3 font-mono">{{ ev.id }}</td>
                  <td class="py-2 px-3">{{ ev.adapter_name }}</td>
                  <td class="py-2 px-3 font-mono">{{ ev.idempotency_key }}</td>
                  <td class="py-2 px-3">{{ ev.payload_summary }}</td>
                  <td class="py-2 px-3 font-semibold">{{ ev.status }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Redacted Audit Trail -->
      <section class="bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
        <div class="p-4 border-b border-[#E8EDEE] flex items-center justify-between">
          <h2 class="font-bold text-[#212B32]">Immutable Audit Trail (Redacted Logs)</h2>
          <button type="button" (click)="load()" class="text-xs font-semibold text-[#005EB8] hover:underline cursor-pointer">Refresh</button>
        </div>
        <div class="overflow-x-auto max-h-96">
          <table class="w-full text-left text-xs">
            <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-[#4C6272]">
              <tr>
                <th class="py-2 px-4">Timestamp</th>
                <th class="py-2 px-3">Actor &amp; Role</th>
                <th class="py-2 px-3">Action</th>
                <th class="py-2 px-3">Entity</th>
                <th class="py-2 px-4">Redacted Detail</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#E8EDEE]">
              @for (log of auditLogs(); track log.id) {
                <tr>
                  <td class="py-2 px-4 font-mono tabular-nums whitespace-nowrap">{{ log.created_at.slice(0, 19).replace('T', ' ') }}</td>
                  <td class="py-2 px-3">{{ log.actor_name }} ({{ log.actor_role }})</td>
                  <td class="py-2 px-3 font-mono font-semibold text-[#003087]">{{ log.action }}</td>
                  <td class="py-2 px-3 font-mono">{{ log.entity_type }}:{{ log.entity_id }}</td>
                  <td class="py-2 px-4 font-mono text-[#4C6272]">{{ log.detail_json }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class StaffAdmin implements OnInit {
  private readonly api = inject(ApiService);

  readonly auditLogs = signal<
    {id: string; actor_name: string; actor_role: string; action: string; entity_type: string; entity_id: string; detail_json: string; created_at: string}[]
  >([]);
  readonly adapters = signal<
    {adapter: string; system_name: string; authoritative_fields: string[]; interoperability_profile: string; integration_status: string}[]
  >([]);
  readonly events = signal<
    {id: string; adapter_name: string; idempotency_key: string; payload_summary: string; status: string}[]
  >([]);
  readonly hazards = signal<
    {id: string; category: string; hazard: string; clinical_consequence: string; mitigation_controls: string; residual_risk: string; verification_status: string}[]
  >([]);
  readonly adminNotice = signal<string | null>(null);

  readonly demoSteps = [
    {num: 1, title: 'Receive a referral', detail: 'REF-2026-001 (Arthur Pendelton) is received via GP e-RS.', area: 'Referrals', route: '/staff/referrals'},
    {num: 2, title: 'Authorised clinical review', detail: 'Sign in as Dr. Priya Nair or Dr. Thorne to assign priority & ECG requirements.', area: 'Referrals', route: '/staff/referrals'},
    {num: 3, title: 'Waiting list entry', detail: 'Accepted referral adds patient to waiting list preserving original date.', area: 'Waiting Lists', route: '/staff/waiting-lists'},
    {num: 4, title: 'Generate eligible slots', detail: 'Send offer or generate Cardiology session from versioned template.', area: 'Clinics', route: '/staff/clinics'},
    {num: 5, title: 'Patient self-booking', detail: 'Sign in as Arthur Pendelton (or Proxy Margaret) to hold & confirm a slot.', area: 'Patient Login', route: '/login'},
    {num: 6, title: 'Prevent competing booking', detail: 'Atomic SQLite BEGIN IMMEDIATE holds block concurrent double-booking (409).', area: 'Clinics', route: '/staff/clinics'},
    {num: 7, title: 'Simulated confirmation', detail: 'Booking immediately emits a redacted confirmation notice.', area: 'Tasks & Comms', route: '/staff/tasks'},
    {num: 8, title: 'Reschedule affected clinic', detail: 'Suite 2 closure queues Eleanor Vance (APT-3003) for bulk preview.', area: 'Clinics', route: '/staff/clinics'},
    {num: 9, title: 'Arrival & completion', detail: 'Check in George Hargreaves (APT-3001) & mark completed as clinician.', area: 'Appointments', route: '/staff/appointments'},
    {num: 10, title: 'Create follow-up booking', detail: 'Record Follow-up required outcome to generate a new waiting-list referral.', area: 'Appointments', route: '/staff/appointments'},
    {num: 11, title: 'Inspect audit trail', detail: 'Every clinical, booking, isolation, and admin action is logged below.', area: 'Audit Trail', route: '/staff/admin'},
    {num: 12, title: 'Review operational reports', detail: 'Inspect capacity vs booked vs completed activity.', area: 'Reports', route: '/staff/reports'},
  ];

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  async load(): Promise<void> {
    const [aud, integ, haz] = await Promise.all([
      this.api.getAuditLogs(),
      this.api.getIntegrations(),
      this.api.getHazardLog(),
    ]);
    this.auditLogs.set(aud.audit_logs);
    this.adapters.set(integ.adapters);
    this.events.set(integ.events);
    this.hazards.set(haz.hazards);
  }

  async runWorker(): Promise<void> {
    const res = await this.api.runWorkerTick();
    this.adminNotice.set(
      `Background worker completed: ${res.expiredHoldsReleased} expired holds released, ${res.queuedNotificationsProcessed} queued notifications processed.`,
    );
    await this.load();
  }

  async verifyBackup(): Promise<void> {
    const [snap, check] = await Promise.all([
      this.api.runBackupSnapshot(),
      this.api.verifyRestoration(),
    ]);
    this.adminNotice.set(
      `Backup snapshot exported (${snap.counts['patients']} patients, ${snap.counts['appointments']} appointments). SQLite integrity check: ${check.integrity_check}, FK violations: ${check.foreign_key_violations}.`,
    );
    await this.load();
  }

  async testIdempotency(): Promise<void> {
    const res = await this.api.ingestIntegrationEvent({
      adapter_name: 'e-RS Referral Adapter',
      direction: 'Inbound',
      idempotency_key: 'ers-ubrn-4821-9011-v1',
      external_ref: 'UBRN-4821-9011',
      payload_summary: 'Duplicate e-RS referral webhook replay test',
    });
    this.adminNotice.set(
      res.duplicate
        ? `Duplicate event (${res.eventId}) safely ignored via idempotency key.`
        : `Ingested event ${res.eventId}.`,
    );
    await this.load();
  }
}
