import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import type {AppointmentRecord, ClinicSlot, ReferralRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-appointments',
  imports: [ReactiveFormsModule, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-[#003087]">Appointments, Check-In &amp; Outcomes</h1>
          <p class="text-sm text-[#4C6272]">
            Manage bookings, reception arrivals, public waiting-room queue, rescheduling conflict validation, and clinician outcomes.
          </p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
          <button
            type="button"
            (click)="publicDisplayMode.set(!publicDisplayMode())"
            class="min-h-[40px] px-3.5 py-2 rounded border text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            [class]="publicDisplayMode() ? 'bg-[#003087] text-white border-[#003087]' : 'bg-white text-[#212B32] border-[#D8DDE0]'"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">tv</mat-icon>
            <span>{{ publicDisplayMode() ? 'Exit Public Queue Display' : 'Public Queue Display' }}</span>
          </button>
        </div>
      </div>

      @if (feedback()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-center gap-2">
          <mat-icon aria-hidden="true">check_circle</mat-icon>
          <span>{{ feedback() }}</span>
        </div>
      }
      @if (errorMsg()) {
        <div role="alert" class="bg-[#FEF2F2] border border-[#EF4444] rounded p-4 text-sm text-[#991B1B] flex items-center gap-2">
          <mat-icon aria-hidden="true">error</mat-icon>
          <span>{{ errorMsg() }}</span>
        </div>
      }

      <!-- Public Waiting Room Display Mode (NO clinical information exposed!) -->
      @if (publicDisplayMode()) {
        <section class="bg-white border border-[#003087] rounded-lg p-6 shadow-sm space-y-4">
          <div class="flex items-center justify-between border-b border-[#E8EDEE] pb-3">
            <div>
              <h2 class="text-xl font-bold text-[#003087]">Pennine Outpatient Centre — Clinic Queue</h2>
              <p class="text-xs text-[#4C6272]">Public waiting-area view (clinical diagnoses and sensitive notes hidden)</p>
            </div>
            <span class="font-mono text-xs text-[#4C6272]">Europe/London</span>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
                <tr>
                  <th class="py-2.5 px-4 font-semibold">Scheduled Time</th>
                  <th class="py-2.5 px-3 font-semibold">Booking Ref</th>
                  <th class="py-2.5 px-3 font-semibold">Room &amp; Clinician</th>
                  <th class="py-2.5 px-3 font-semibold">Arrival Time</th>
                  <th class="py-2.5 px-3 font-semibold">Status</th>
                  <th class="py-2.5 px-4 font-semibold">Assistance / Access</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#E8EDEE]">
                @for (a of appointments(); track a.id) {
                  @if (['Booked', 'Confirmed', 'Arrived', 'In progress'].includes(a.state)) {
                    <tr>
                      <td class="py-3 px-4 font-mono font-semibold tabular-nums">{{ a.local_date }} {{ a.local_start_time }}</td>
                      <td class="py-3 px-3 font-mono text-xs">{{ a.id }}</td>
                      <td class="py-3 px-3 text-xs">{{ a.room_name }} · {{ a.clinician_name }}</td>
                      <td class="py-3 px-3 font-mono text-xs tabular-nums">
                        {{ a.arrival_time_utc ? a.arrival_time_utc.slice(11, 16) + ' UTC' : '—' }}
                      </td>
                      <td class="py-3 px-3">
                        <app-status-label [label]="a.state" [tone]="a.state === 'Arrived' || a.state === 'In progress' ? 'success' : 'info'" />
                      </td>
                      <td class="py-3 px-4 text-xs text-[#4C6272]">
                        {{ a.interpreter_language ? 'Interpreter: ' + a.interpreter_language : 'Standard' }}
                      </td>
                    </tr>
                  }
                }
              </tbody>
            </table>
          </div>
        </section>
      }

      <!-- Staff Telephone / Desk Booking Drawer (when triggered from Waiting Lists) -->
      @if (bookingReferral(); as br) {
        <section class="bg-[#EFF6FF] border border-[#93C5FD] rounded-lg p-6 space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <h2 class="text-lg font-bold text-[#003087]">Staff Telephone / Desk Booking for {{ br.patient_name }} ({{ br.id }})</h2>
              <p class="text-xs text-[#212B32]">{{ br.specialty }} · {{ br.duration_minutes }} min · {{ br.required_equipment ?? 'Standard room' }}</p>
            </div>
            <button type="button" (click)="bookingReferral.set(null)" class="text-xs font-semibold text-[#003087] underline cursor-pointer">Close</button>
          </div>
          @if (eligibleSlots().length === 0) {
            <p class="text-sm text-[#92400E]">No compatible slots available right now. Generate a clinic session first.</p>
          } @else {
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              @for (s of eligibleSlots(); track s.id) {
                <div class="bg-white border border-[#BFDBFE] rounded p-3.5 flex items-center justify-between gap-3">
                  <div class="text-xs">
                    <div class="font-mono font-bold text-[#003087]">{{ s.slot_date }} {{ s.start_time }}–{{ s.end_time }}</div>
                    <div class="text-[#4C6272]">{{ s.site_name }} · {{ s.room_name }}</div>
                  </div>
                  <button
                    type="button"
                    (click)="bookSlotForReferral(br, s.id)"
                    class="px-3 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded cursor-pointer shrink-0"
                  >
                    Book
                  </button>
                </div>
              }
            </div>
          }
        </section>
      }

      <!-- Main Appointments Worklist & Action Panel -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <section class="lg:col-span-7 bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
          <div class="p-4 border-b border-[#E8EDEE] flex flex-wrap items-center justify-between gap-3">
            <h2 class="font-bold text-[#212B32]">All Appointments ({{ appointments().length }})</h2>
            <select
              aria-label="Filter by specialty"
              [value]="specialtyFilter()"
              (change)="onFilterSpecialty($event)"
              class="min-h-[38px] px-3 py-1 border border-[#768692] rounded bg-white text-xs"
            >
              <option value="">All specialties</option>
              <option value="Cardiology">Cardiology</option>
              <option value="Dermatology">Dermatology</option>
              <option value="Orthopaedics">Orthopaedics</option>
              <option value="Ophthalmology">Ophthalmology</option>
            </select>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
                <tr>
                  <th class="py-2.5 px-4 font-semibold">Date &amp; Time</th>
                  <th class="py-2.5 px-3 font-semibold">Patient</th>
                  <th class="py-2.5 px-3 font-semibold">Clinic &amp; Site</th>
                  <th class="py-2.5 px-3 font-semibold">State</th>
                  <th class="py-2.5 px-4 font-semibold text-right">Manage</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#E8EDEE]">
                @for (a of appointments(); track a.id) {
                  <tr class="hover:bg-[#F8FAFC]" [class.bg-[#EFF6FF]]="selectedAppt()?.id === a.id">
                    <td class="py-3 px-4 font-mono text-xs tabular-nums">
                      <div class="font-semibold text-[#212B32]">{{ a.local_date }}</div>
                      <div class="text-[#4C6272]">{{ a.local_start_time }}–{{ a.local_end_time }}</div>
                    </td>
                    <td class="py-3 px-3 text-xs">
                      <div class="font-semibold text-[#212B32]">{{ a.patient_name }}</div>
                      <div class="font-mono text-[#4C6272]">{{ a.id }}</div>
                    </td>
                    <td class="py-3 px-3 text-xs">
                      <div class="font-medium text-[#212B32]">{{ a.specialty }}</div>
                      <div class="text-[#4C6272]">{{ a.clinician_name }} · {{ a.room_name }}</div>
                    </td>
                    <td class="py-3 px-3">
                      <app-status-label [label]="a.state" [tone]="apptTone(a.state)" />
                    </td>
                    <td class="py-3 px-4 text-right">
                      <button
                        type="button"
                        (click)="selectAppointment(a)"
                        class="px-3 py-1.5 bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#003087] text-xs font-semibold rounded cursor-pointer"
                      >
                        Open
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>

        <!-- Appointment Lifecycle, Rescheduling Conflict Check, Letter & Clinical Outcome -->
        <section class="lg:col-span-5 bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-5">
          @if (selectedAppt(); as sel) {
            <div class="border-b border-[#E8EDEE] pb-4 space-y-1.5">
              <div class="flex items-center justify-between gap-2">
                <h2 class="text-lg font-bold text-[#003087]">{{ sel.id }} — {{ sel.patient_name }}</h2>
                <app-status-label [label]="sel.state" [tone]="apptTone(sel.state)" />
              </div>
              <div class="text-xs font-mono tabular-nums text-[#212B32]">
                {{ sel.local_date }} {{ sel.local_start_time }}–{{ sel.local_end_time }} · {{ sel.site_name }} ({{ sel.room_name }})
              </div>
              <div class="text-xs text-[#4C6272]">
                Booked via: {{ sel.booked_channel }} · Priority: {{ sel.clinical_priority ?? 'Reviewed' }}
              </div>
              @if (sel.interpreter_language) {
                <div class="text-xs font-semibold text-[#92400E] bg-[#FFFBEB] border border-[#FCD34D] rounded px-2 py-1 inline-block">
                  Interpreter: {{ sel.interpreter_language }}
                </div>
              }
            </div>

            <!-- Attendance & 12-State Transitions -->
            <div class="space-y-2.5">
              <h3 class="text-sm font-bold text-[#212B32]">Attendance &amp; Administrative Status</h3>
              <div class="flex flex-wrap gap-2">
                @if (sel.state === 'Booked') {
                  <button type="button" (click)="transition(sel.id, 'Confirmed')" class="px-3 py-1.5 bg-[#005EB8] text-white text-xs font-semibold rounded cursor-pointer">Confirm</button>
                }
                @if (sel.state === 'Booked' || sel.state === 'Confirmed') {
                  <button type="button" (click)="transition(sel.id, 'Arrived')" class="px-3 py-1.5 bg-[#007F3B] text-white text-xs font-semibold rounded cursor-pointer">Record Arrival</button>
                  <button type="button" (click)="transition(sel.id, 'Did not attend')" class="px-3 py-1.5 bg-[#B45309] text-white text-xs font-semibold rounded cursor-pointer">Mark DNA</button>
                  <button type="button" (click)="transition(sel.id, 'Cancelled by provider')" class="px-3 py-1.5 bg-white border border-[#FCA5A5] text-[#991B1B] text-xs font-semibold rounded cursor-pointer">Cancel (Provider)</button>
                }
                @if (sel.state === 'Arrived') {
                  <button type="button" (click)="transition(sel.id, 'In progress')" class="px-3 py-1.5 bg-[#005EB8] text-white text-xs font-semibold rounded cursor-pointer">Start Consultation</button>
                }
                @if (sel.state === 'In progress') {
                  <button type="button" (click)="transition(sel.id, 'Completed')" class="px-3 py-1.5 bg-[#007F3B] text-white text-xs font-semibold rounded cursor-pointer">Mark Completed</button>
                  <button type="button" (click)="transition(sel.id, 'Unable to complete')" class="px-3 py-1.5 bg-[#B45309] text-white text-xs font-semibold rounded cursor-pointer">Unable to Complete</button>
                }
              </div>
              <div class="flex flex-wrap gap-2 pt-1">
                <button type="button" (click)="openLetter(sel.id)" class="px-3 py-1.5 bg-[#F8FAFC] border border-[#D8DDE0] text-[#212B32] text-xs font-semibold rounded inline-flex items-center gap-1 cursor-pointer">
                  <mat-icon class="!text-[15px] !w-[15px] !h-[15px]" aria-hidden="true">description</mat-icon>
                  <span>Appointment Letter</span>
                </button>
                <button type="button" (click)="sendSimulatedReminder(sel.id, false)" class="px-3 py-1.5 bg-[#F8FAFC] border border-[#D8DDE0] text-[#212B32] text-xs font-semibold rounded cursor-pointer">
                  Send Reminder
                </button>
                <button type="button" (click)="sendSimulatedReminder(sel.id, true)" class="px-3 py-1.5 bg-[#FFFBEB] border border-[#FCD34D] text-[#92400E] text-xs font-semibold rounded cursor-pointer">
                  Simulate Failed Reminder
                </button>
              </div>
            </div>

            <!-- Reschedule with Resource Conflict Validation -->
            @if (sel.state === 'Booked' || sel.state === 'Confirmed') {
              <div class="pt-4 border-t border-[#E8EDEE] space-y-2.5">
                <h3 class="text-sm font-bold text-[#212B32]">Propose Reschedule (Backend Conflict Checked)</h3>
                <select
                  aria-label="Choose candidate slot for reschedule"
                  [value]="rescheduleSlotId()"
                  (change)="onRescheduleSlotPick($event, sel)"
                  class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-xs"
                >
                  <option value="">Select a slot to validate conflicts...</option>
                  @for (sl of allSlots(); track sl.id) {
                    <option [value]="sl.id">
                      {{ sl.slot_date }} {{ sl.start_time }} · {{ sl.specialty }} ({{ sl.status }}) — {{ sl.room_name }}
                    </option>
                  }
                </select>
                @if (conflictCheck(); as cc) {
                  @if (cc.hasConflict) {
                    <div class="bg-[#FEF2F2] border border-[#EF4444] rounded p-3 text-xs text-[#991B1B]">
                      <strong>Resource conflict detected:</strong> {{ cc.reasons.join(' ') }}
                    </div>
                  } @else {
                    <div class="bg-[#ECFDF5] border border-[#10B981] rounded p-3 text-xs text-[#065F46] space-y-2">
                      <div><strong>Validated:</strong> No staff, room, equipment, or patient conflicts.</div>
                      <button
                        type="button"
                        (click)="executeReschedule(sel.id)"
                        class="px-3 py-1.5 bg-[#005EB8] text-white font-semibold rounded cursor-pointer"
                      >
                        Confirm audited reschedule
                      </button>
                    </div>
                  }
                }
              </div>
            }

            <!-- Authorised Clinical Outcome & Follow-up -->
            <div class="pt-4 border-t border-[#E8EDEE] space-y-3">
              <h3 class="text-sm font-bold text-[#212B32]">Clinical Outcome &amp; Follow-up</h3>
              @if (sel.clinical_outcome) {
                <div class="p-3 bg-[#F8FAFC] border border-[#D8DDE0] rounded text-xs space-y-1">
                  <div class="font-bold text-[#003087]">{{ sel.clinical_outcome }}</div>
                  <div class="text-[#212B32]">{{ sel.outcome_notes }}</div>
                  <div class="text-[#4C6272]">Recorded by {{ sel.outcome_recorded_by }}</div>
                  @if (sel.followup_referral_id) {
                    <div class="font-mono text-[#065F46] font-semibold">
                      Follow-up referral created: {{ sel.followup_referral_id }}
                    </div>
                  }
                </div>
              }
              @if (!auth.isClinician()) {
                <div class="bg-[#FFFBEB] border border-[#F59E0B] rounded p-3 text-xs text-[#92400E]">
                  <strong>Clinical Role Restriction:</strong> Administrative users cannot record clinical outcomes or follow-up decisions.
                </div>
              } @else {
                <form [formGroup]="outcomeForm" (ngSubmit)="submitOutcome(sel.id)" class="space-y-2.5">
                  <select formControlName="clinical_outcome" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-xs">
                    <option value="Follow-up required">Follow-up required</option>
                    <option value="Discharged from this service">Discharged from this service</option>
                    <option value="Further investigation requested">Further investigation requested</option>
                    <option value="Outcome awaiting completion">Outcome awaiting completion</option>
                  </select>
                  <div class="grid grid-cols-2 gap-2">
                    <div>
                      <label for="fu-win" class="block text-[11px] font-semibold text-[#4C6272]">Follow-up window (days)</label>
                      <input id="fu-win" type="number" formControlName="followup_window_days" class="w-full min-h-[38px] px-2.5 border border-[#768692] rounded bg-white text-xs" />
                    </div>
                    <div>
                      <label for="fu-dur" class="block text-[11px] font-semibold text-[#4C6272]">Duration (min)</label>
                      <input id="fu-dur" type="number" formControlName="followup_duration_minutes" class="w-full min-h-[38px] px-2.5 border border-[#768692] rounded bg-white text-xs" />
                    </div>
                  </div>
                  <textarea rows="2" formControlName="outcome_notes" placeholder="Clinical outcome & follow-up instructions..." class="w-full px-3 py-2 border border-[#768692] rounded bg-white text-xs"></textarea>
                  <button type="submit" class="w-full min-h-[40px] px-4 py-2 bg-[#003087] hover:bg-[#00205B] text-white text-xs font-semibold rounded cursor-pointer">
                    Record clinical outcome &amp; generate follow-up
                  </button>
                </form>
              }
            </div>

            @if (letterPreview(); as ltr) {
              <div class="pt-4 border-t border-[#E8EDEE] bg-[#F8FAFC] p-4 rounded border border-[#D8DDE0] text-xs space-y-1.5">
                <div class="flex justify-between font-bold text-[#003087]">
                  <span>APPOINTMENT LETTER PREVIEW</span>
                  <button type="button" (click)="letterPreview.set(null)" class="underline cursor-pointer">Close</button>
                </div>
                <div><strong>To:</strong> {{ ltr['patient_name'] }} ({{ ltr['patient_address'] }})</div>
                <div><strong>Clinic:</strong> {{ ltr['specialty'] }} with {{ ltr['clinician_name'] }}</div>
                <div><strong>When:</strong> {{ ltr['local_date'] }} at {{ ltr['local_start_time'] }}</div>
                <div><strong>Where:</strong> {{ ltr['site_name'] }}, {{ ltr['room_name'] }}</div>
                <div><strong>Instructions:</strong> {{ ltr['preparation_instructions'] }}</div>
              </div>
            }
          } @else {
            <p class="text-sm text-[#4C6272]">Select an appointment to record arrival, validate rescheduling conflicts, preview letters, or record clinical outcomes.</p>
          }
        </section>
      </div>
    </div>
  `,
})
export class StaffAppointments implements OnInit {
  private readonly api = inject(ApiService);
  readonly auth = inject(AuthService);
  private readonly route = inject(ActivatedRoute);

  readonly appointments = signal<AppointmentRecord[]>([]);
  readonly selectedAppt = signal<AppointmentRecord | null>(null);
  readonly allSlots = signal<ClinicSlot[]>([]);
  readonly bookingReferral = signal<ReferralRecord | null>(null);
  readonly eligibleSlots = signal<ClinicSlot[]>([]);
  readonly specialtyFilter = signal('');
  readonly publicDisplayMode = signal(false);
  readonly rescheduleSlotId = signal('');
  readonly conflictCheck = signal<{hasConflict: boolean; reasons: string[]} | null>(null);
  readonly letterPreview = signal<Record<string, unknown> | null>(null);
  readonly feedback = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  readonly outcomeForm = new FormGroup({
    clinical_outcome: new FormControl('Follow-up required', {nonNullable: true}),
    followup_window_days: new FormControl(14, {nonNullable: true}),
    followup_duration_minutes: new FormControl(30, {nonNullable: true}),
    outcome_notes: new FormControl('Review ECG & medication response in 2 weeks.', {
      nonNullable: true,
      validators: [Validators.required],
    }),
  });

  async ngOnInit(): Promise<void> {
    await this.load();
    const bookRefId = this.route.snapshot.queryParamMap.get('bookReferralId');
    if (bookRefId) {
      const slotsRes = await this.api.getEligibleSlots(bookRefId);
      if (slotsRes.referral) {
        this.bookingReferral.set(slotsRes.referral);
        this.eligibleSlots.set(slotsRes.slots);
      }
    }
  }

  async load(): Promise<void> {
    const [appts, slots] = await Promise.all([
      this.api.getAppointments({specialty: this.specialtyFilter() || undefined}),
      this.api.getEligibleSlots(),
    ]);
    this.appointments.set(appts.appointments);
    this.allSlots.set(slots.slots);
    const cur = this.selectedAppt();
    if (cur) {
      const refreshed = appts.appointments.find((a) => a.id === cur.id) ?? null;
      this.selectedAppt.set(refreshed);
    } else if (appts.appointments.length > 0) {
      this.selectedAppt.set(appts.appointments[0]);
    }
  }

  async onFilterSpecialty(ev: Event): Promise<void> {
    this.specialtyFilter.set((ev.target as HTMLSelectElement).value);
    await this.load();
  }

  selectAppointment(a: AppointmentRecord): void {
    this.selectedAppt.set(a);
    this.conflictCheck.set(null);
    this.rescheduleSlotId.set('');
    this.letterPreview.set(null);
  }

  apptTone(state: string): 'neutral' | 'info' | 'success' | 'warning' | 'urgent' {
    if (state === 'Completed' || state === 'Confirmed' || state === 'Arrived') return 'success';
    if (state === 'Booked' || state === 'In progress') return 'info';
    if (state.startsWith('Cancelled') || state === 'Did not attend' || state === 'Unable to complete') {
      return 'warning';
    }
    return 'neutral';
  }

  async transition(id: string, targetState: string): Promise<void> {
    this.errorMsg.set(null);
    this.feedback.set(null);
    try {
      await this.api.transitionAppointment(id, targetState, 'Staff workstation update');
      this.feedback.set(`Appointment ${id} updated to '${targetState}'.`);
      await this.load();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Could not transition appointment state.');
    }
  }

  async onRescheduleSlotPick(ev: Event, sel: AppointmentRecord): Promise<void> {
    const slotId = (ev.target as HTMLSelectElement).value;
    this.rescheduleSlotId.set(slotId);
    if (!slotId) {
      this.conflictCheck.set(null);
      return;
    }
    const res = await this.api.checkConflicts({
      slot_id: slotId,
      patient_id: sel.patient_id,
      exclude_appointment_id: sel.id,
    });
    this.conflictCheck.set(res);
  }

  async executeReschedule(oldApptId: string): Promise<void> {
    const newSlotId = this.rescheduleSlotId();
    if (!newSlotId) return;
    this.errorMsg.set(null);
    try {
      const res = await this.api.rescheduleAppointment(
        oldApptId,
        newSlotId,
        'Staff booking reschedule after conflict validation',
      );
      this.feedback.set(`Rescheduled ${oldApptId} → ${res.new_appointment.id}.`);
      this.rescheduleSlotId.set('');
      this.conflictCheck.set(null);
      await this.load();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Reschedule failed.');
    }
  }

  async bookSlotForReferral(ref: ReferralRecord, slotId: string): Promise<void> {
    this.errorMsg.set(null);
    try {
      const res = await this.api.bookAppointment({
        slot_id: slotId,
        patient_id: ref.patient_id,
        referral_id: ref.id,
        booked_channel: 'Staff Telephone Booking',
      });
      this.feedback.set(`Booked ${res.appointment.id} for ${ref.patient_name ?? ref.patient_id}.`);
      this.bookingReferral.set(null);
      await this.load();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Booking failed.');
    }
  }

  async submitOutcome(appointmentId: string): Promise<void> {
    if (this.outcomeForm.invalid) return;
    this.errorMsg.set(null);
    try {
      const v = this.outcomeForm.getRawValue();
      const res = await this.api.recordOutcome(appointmentId, {
        ...v,
        followup_window_days: Number(v.followup_window_days),
        followup_duration_minutes: Number(v.followup_duration_minutes),
        mark_completed: true,
      });
      this.feedback.set(
        res.followup_referral_id
          ? `Outcome recorded. Follow-up referral ${res.followup_referral_id} added to waiting list.`
          : `Clinical outcome recorded for ${appointmentId}.`,
      );
      await this.load();
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Could not record outcome.');
    }
  }

  async openLetter(appointmentId: string): Promise<void> {
    const res = await this.api.getAppointmentLetter(appointmentId);
    this.letterPreview.set(res.letter);
  }

  async sendSimulatedReminder(appointmentId: string, simulateBounce: boolean): Promise<void> {
    const res = await this.api.queueReminder(appointmentId, 'SMS', simulateBounce);
    this.feedback.set(
      simulateBounce
        ? `Simulated reminder bounce (${res.notification.id}). Staff follow-up task created automatically.`
        : `Simulated SMS reminder delivered (${res.notification.id}).`,
    );
  }
}
