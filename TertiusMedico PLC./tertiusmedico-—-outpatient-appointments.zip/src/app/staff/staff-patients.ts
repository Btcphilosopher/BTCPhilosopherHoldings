import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import type {PatientRecord, ProxyRelationship} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-patients',
  imports: [MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-[#003087]">Patient Records &amp; Proxy Verification</h1>
          <p class="text-sm text-[#4C6272]">Search synthetic Pennine patients, NHS number verification status, interpreter needs, and external PAS/EPR references.</p>
        </div>
        <div class="flex items-center gap-2">
          <input
            type="search"
            aria-label="Search patients by name, NHS number, or ID"
            placeholder="Search name, NHS no., ID..."
            (input)="onSearch($event)"
            class="min-h-[42px] px-3.5 py-2 border border-[#768692] rounded bg-white text-sm w-64"
          />
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <section class="lg:col-span-7 bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
          <table class="w-full text-left text-sm">
            <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
              <tr>
                <th class="py-2.5 px-4 font-semibold">Patient</th>
                <th class="py-2.5 px-3 font-semibold">Synthetic NHS No.</th>
                <th class="py-2.5 px-3 font-semibold">Verification</th>
                <th class="py-2.5 px-3 font-semibold">Comms &amp; Access</th>
                <th class="py-2.5 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#E8EDEE]">
              @for (p of patients(); track p.id) {
                <tr class="hover:bg-[#F8FAFC]" [class.bg-[#EFF6FF]]="selectedPatient()?.id === p.id">
                  <td class="py-3 px-4">
                    <div class="font-semibold text-[#212B32]">{{ p.full_name }}</div>
                    <div class="text-xs font-mono text-[#4C6272]">{{ p.id }} · DOB {{ p.date_of_birth }}</div>
                  </td>
                  <td class="py-3 px-3 font-mono text-xs tabular-nums">{{ p.nhs_number }}</td>
                  <td class="py-3 px-3">
                    <app-status-label
                      [label]="p.nhs_verification_status.startsWith('Verified') ? 'Verified' : 'Provisional'"
                      [tone]="p.nhs_verification_status.startsWith('Verified') ? 'success' : 'warning'"
                    />
                  </td>
                  <td class="py-3 px-3 text-xs text-[#4C6272]">
                    <div>{{ p.preferred_contact_channel }}</div>
                    @if (p.interpreter_required) {
                      <div class="font-semibold text-[#92400E]">{{ p.interpreter_language }}</div>
                    }
                  </td>
                  <td class="py-3 px-4 text-right">
                    <button
                      type="button"
                      (click)="inspectPatient(p.id)"
                      class="px-3 py-1.5 bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#003087] text-xs font-semibold rounded cursor-pointer"
                    >
                      View
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </section>

        <section class="lg:col-span-5 bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
          @if (selectedPatient(); as sel) {
            <h2 class="text-lg font-bold text-[#003087]">{{ sel.full_name }} ({{ sel.id }})</h2>
            <dl class="text-xs space-y-2 border-t border-[#E8EDEE] pt-3">
              <div class="flex justify-between gap-2"><dt class="text-[#4C6272]">NHS Verification</dt><dd class="font-semibold">{{ sel.nhs_verification_status }}</dd></div>
              <div class="flex justify-between gap-2"><dt class="text-[#4C6272]">Address</dt><dd class="text-right">{{ sel.address }}</dd></div>
              <div class="flex justify-between gap-2"><dt class="text-[#4C6272]">Phone / Email</dt><dd class="font-mono text-right">{{ sel.phone }} · {{ sel.email }}</dd></div>
              <div class="flex justify-between gap-2"><dt class="text-[#4C6272]">Accessibility</dt><dd class="text-right">{{ sel.accessibility_requirements }}</dd></div>
              <div class="flex justify-between gap-2"><dt class="text-[#4C6272]">External Refs</dt><dd class="font-mono">{{ sel.pas_ref }} · {{ sel.epr_ref }}</dd></div>
              <div class="flex justify-between gap-2"><dt class="text-[#4C6272]">Marketing Consent</dt><dd>{{ sel.marketing_consent ? 'Opted in' : 'Opted out (separate from care)' }}</dd></div>
            </dl>

            <div class="pt-3 border-t border-[#E8EDEE] space-y-2">
              <h3 class="text-sm font-bold text-[#212B32]">Verified Proxies ({{ proxies().length }})</h3>
              @for (prx of proxies(); track prx.id) {
                <div class="p-2.5 bg-[#F8FAFC] border border-[#D8DDE0] rounded text-xs">
                  <span class="font-semibold">{{ prx.proxy_name }}</span> · {{ prx.relationship }} ·
                  <span class="font-mono">{{ prx.scope }}</span> ({{ prx.verification_status }})
                </div>
              } @empty {
                <p class="text-xs text-[#4C6272]">No proxy relationships recorded.</p>
              }
            </div>
          } @else {
            <p class="text-sm text-[#4C6272]">Select a patient record to view full demographics, verification status, and proxy permissions.</p>
          }
        </section>
      </div>
    </div>
  `,
})
export class StaffPatients implements OnInit {
  private readonly api = inject(ApiService);

  readonly patients = signal<PatientRecord[]>([]);
  readonly selectedPatient = signal<PatientRecord | null>(null);
  readonly proxies = signal<ProxyRelationship[]>([]);

  async ngOnInit(): Promise<void> {
    const res = await this.api.getPatients();
    this.patients.set(res.patients);
    if (res.patients.length > 0) {
      await this.inspectPatient(res.patients[0].id);
    }
  }

  async onSearch(ev: Event): Promise<void> {
    const q = (ev.target as HTMLInputElement).value;
    const res = await this.api.getPatients(q);
    this.patients.set(res.patients);
  }

  async inspectPatient(id: string): Promise<void> {
    const detail = await this.api.getPatientDetail(id);
    this.selectedPatient.set(detail.patient);
    this.proxies.set(detail.proxies);
  }
}
