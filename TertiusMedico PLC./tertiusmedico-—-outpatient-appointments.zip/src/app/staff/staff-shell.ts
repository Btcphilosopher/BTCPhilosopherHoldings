import {ChangeDetectionStrategy, Component, inject, signal} from '@angular/core';
import {Router, RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {MatIconModule} from '@angular/material/icon';
import {AuthService} from '../core/auth.service';

@Component({
  selector: 'app-staff-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-[#F0F4F5] flex flex-col lg:flex-row">
      <!-- Deep-Blue Staff Sidebar -->
      <aside
        class="bg-[#003087] text-white lg:w-[248px] shrink-0 flex flex-col border-r border-[#00205B]"
      >
        <div class="h-16 px-5 flex items-center justify-between border-b border-white/15">
          <a routerLink="/staff/overview" class="font-display font-bold text-lg tracking-tight text-white whitespace-nowrap">
            TERTIUSMEDICO
          </a>
          <button
            type="button"
            (click)="mobileNavOpen.set(!mobileNavOpen())"
            aria-label="Toggle staff navigation"
            class="lg:hidden p-2 rounded hover:bg-white/10 text-white cursor-pointer"
          >
            <mat-icon aria-hidden="true">{{ mobileNavOpen() ? 'close' : 'menu' }}</mat-icon>
          </button>
        </div>

        <nav
          aria-label="Staff navigation"
          class="flex-1 p-3 space-y-1"
          [class.hidden]="!mobileNavOpen()"
          [class.lg:block]="true"
        >
          @for (item of navItems; track item.path) {
            <a
              [routerLink]="item.path"
              (click)="mobileNavOpen.set(false)"
              routerLinkActive="bg-[#005EB8] text-white font-semibold"
              class="flex items-center gap-3 px-3 py-2.5 rounded text-sm text-blue-100 hover:bg-white/10 hover:text-white transition-colors whitespace-nowrap"
            >
              <mat-icon class="!text-[19px] !w-[19px] !h-[19px] shrink-0" aria-hidden="true">{{ item.icon }}</mat-icon>
              <span>{{ item.label }}</span>
            </a>
          }
        </nav>

        @if (auth.user(); as u) {
          <div class="hidden lg:block p-4 border-t border-white/15 text-xs text-blue-100 space-y-1">
            <div class="font-semibold text-white truncate">{{ u.display_name }}</div>
            <div class="truncate">Role: {{ u.role }}</div>
            <div class="truncate text-blue-200">Pennine Outpatient Centre</div>
          </div>
        }
      </aside>

      <!-- Main Staff Content Frame -->
      <div class="flex-1 flex flex-col min-w-0">
        <!-- Top Bar (3-zone contract) -->
        <header class="bg-white border-b border-[#D8DDE0] h-16 px-4 sm:px-6 flex items-center justify-between gap-8">
          <div class="text-sm text-[#4C6272] truncate">
            <span class="font-semibold text-[#212B32]">Pennine Outpatient Centre</span>
            <span class="mx-2" aria-hidden="true">/</span>
            <span>Outpatient Scheduling &amp; Clinical Operations (Prototype)</span>
          </div>

          <div class="flex items-center gap-3 shrink-0">
            <button
              type="button"
              (click)="auth.logout()"
              class="min-h-[40px] px-3.5 py-2 bg-[#F0F4F5] hover:bg-[#E2E8F0] text-[#212B32] text-xs font-semibold rounded border border-[#D8DDE0] flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]" aria-hidden="true">logout</mat-icon>
              <span>Sign out</span>
            </button>
          </div>
        </header>

        <main class="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1400px] w-full mx-auto">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
})
export class StaffShell {
  readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  readonly mobileNavOpen = signal(false);

  readonly navItems = [
    {path: '/staff/overview', label: 'Overview', icon: 'dashboard'},
    {path: '/staff/referrals', label: 'Referrals', icon: 'assignment'},
    {path: '/staff/waiting-lists', label: 'Waiting Lists', icon: 'hourglass_top'},
    {path: '/staff/clinics', label: 'Clinics', icon: 'calendar_month'},
    {path: '/staff/appointments', label: 'Appointments', icon: 'event_note'},
    {path: '/staff/patients', label: 'Patients', icon: 'people'},
    {path: '/staff/tasks', label: 'Tasks', icon: 'task_alt'},
    {path: '/staff/reports', label: 'Reports', icon: 'bar_chart'},
    {path: '/staff/admin', label: 'Administration', icon: 'admin_panel_settings'},
  ];

  constructor() {
    if (!this.auth.isAuthenticated() || this.auth.isPatientPortalUser()) {
      void this.router.navigate(['/login']);
    }
  }
}
