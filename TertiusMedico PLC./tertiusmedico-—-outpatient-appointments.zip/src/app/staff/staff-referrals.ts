import {ChangeDetectionStrategy, Component, inject, OnInit, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ApiService} from '../core/api.service';
import {AuthService} from '../core/auth.service';
import type {PatientRecord, ReferralRecord} from '../core/models';
import {StatusLabel} from '../shared/status-label';

@Component({
  selector: 'app-staff-referrals',
  imports: [ReactiveFormsModule, MatIconModule, StatusLabel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-[#003087]">Referrals &amp; Clinical Review</h1>
          <p class="text-sm text-[#4C6272]">
            Clinical priority and booking requirements can only be set by authorised clinical roles.
          </p>
        </div>
        <button
          type="button"
          (click)="showCreateForm.set(!showCreateForm())"
          class="min-h-[42px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <mat-icon aria-hidden="true">{{ showCreateForm() ? 'close' : 'add' }}</mat-icon>
          <span>{{ showCreateForm() ? 'Close new referral' : 'Receive new referral' }}</span>
        </button>
      </div>

      @if (feedback()) {
        <div role="status" class="bg-[#ECFDF5] border border-[#10B981] rounded p-4 text-sm text-[#065F46] flex items-center gap-2">
          <mat-icon aria-hidden="true">check_circle</mat-icon>
          <span>{{ feedback() }}</span>
        </div>
      }
      @if (errorMsg()) {
        <div role="alert" class="bg-[#FEF2F2] border border-[#EF4444] rounded p-4 text-sm text-[#991B1B] flex items-center gap-2">
          <mat-icon aria-hidden="true">error</mat-icon>
          <span>{{ errorMsg() }}</span>
        </div>
      }

      @if (showCreateForm()) {
        <section class="bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-4">
          <h2 class="text-lg font-bold text-[#212B32]">Receive GP / Internal Referral</h2>
          <form [formGroup]="createForm" (ngSubmit)="submitCreate()" class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label for="c-pat" class="block text-xs font-semibold text-[#212B32] mb-1">Patient</label>
              <select id="c-pat" formControlName="patient_id" class="w-full min-h-[42px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm">
                @for (p of patients(); track p.id) {
                  <option [value]="p.id">{{ p.full_name }} ({{ p.nhs_number }})</option>
                }
              </select>
            </div>
            <div>
              <label for="c-spec" class="block text-xs font-semibold text-[#212B32] mb-1">Specialty</label>
              <select id="c-spec" formControlName="specialty" class="w-full min-h-[42px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm">
                <option value="Cardiology">Cardiology</option>
                <option value="Dermatology">Dermatology</option>
                <option value="Orthopaedics">Orthopaedics</option>
                <option value="Ophthalmology">Ophthalmology</option>
              </select>
            </div>
            <div>
              <label for="c-src" class="block text-xs font-semibold text-[#212B32] mb-1">Source</label>
              <select id="c-src" formControlName="source" class="w-full min-h-[42px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm">
                <option value="GP e-RS">GP e-RS</option>
                <option value="A&E Follow-up">A&amp;E Follow-up</option>
                <option value="Internal Consultant">Internal Consultant</option>
              </select>
            </div>
            <div class="md:col-span-2">
              <label for="c-svc" class="block text-xs font-semibold text-[#212B32] mb-1">Service name</label>
              <input id="c-svc" type="text" formControlName="service_name" class="w-full min-h-[42px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm" />
            </div>
            <div>
              <label for="c-due" class="block text-xs font-semibold text-[#212B32] mb-1">Admin target date (not clinical urgency)</label>
              <input id="c-due" type="date" formControlName="admin_due_date" class="w-full min-h-[42px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm" />
            </div>
            <div class="md:col-span-3">
              <label for="c-reason" class="block text-xs font-semibold text-[#212B32] mb-1">Referral summary</label>
              <input id="c-reason" type="text" formControlName="reason_summary" class="w-full min-h-[42px] px-3 py-1.5 border border-[#768692] rounded bg-white text-sm" />
            </div>
            <div class="md:col-span-3">
              <button type="submit" class="min-h-[42px] px-5 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center gap-2 cursor-pointer">
                <mat-icon aria-hidden="true">save</mat-icon>
                <span>Register referral (awaiting clinical review)</span>
              </button>
            </div>
          </form>
        </section>
      }

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <!-- Referrals Table -->
        <section class="lg:col-span-7 bg-white border border-[#D8DDE0] rounded-lg shadow-sm overflow-hidden">
          <div class="p-4 border-b border-[#E8EDEE] flex flex-wrap items-center justify-between gap-3">
            <h2 class="font-bold text-[#212B32]">Referral Queue ({{ referrals().length }})</h2>
            <select
              aria-label="Filter referrals by status"
              [value]="statusFilter()"
              (change)="onFilterStatus($event)"
              class="min-h-[38px] px-3 py-1 border border-[#768692] rounded bg-white text-xs"
            >
              <option value="">All review statuses</option>
              <option value="Pending Review">Pending Review</option>
              <option value="Accepted">Accepted</option>
            </select>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead class="bg-[#F8FAFC] border-b border-[#D8DDE0] text-xs text-[#4C6272]">
                <tr>
                  <th class="py-2.5 px-4 font-semibold">Referral / Patient</th>
                  <th class="py-2.5 px-3 font-semibold">Specialty</th>
                  <th class="py-2.5 px-3 font-semibold">Priority</th>
                  <th class="py-2.5 px-3 font-semibold">Admin Status</th>
                  <th class="py-2.5 px-4 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#E8EDEE]">
                @for (ref of referrals(); track ref.id) {
                  <tr
                    class="hover:bg-[#F8FAFC] transition-colors"
                    [class.bg-[#EFF6FF]]="selectedReferral()?.id === ref.id"
                  >
                    <td class="py-3 px-4">
                      <div class="font-semibold text-[#212B32]">{{ ref.patient_name }}</div>
                      <div class="text-xs font-mono text-[#4C6272]">{{ ref.id }} · {{ ref.received_date }}</div>
                    </td>
                    <td class="py-3 px-3 text-xs">
                      <div class="font-medium text-[#212B32]">{{ ref.specialty }}</div>
                      <div class="text-[#4C6272]">{{ ref.duration_minutes }}m · {{ ref.source }}</div>
                    </td>
                    <td class="py-3 px-3">
                      @if (ref.clinical_priority) {
                        <app-status-label
                          [label]="ref.clinical_priority"
                          [tone]="ref.clinical_priority === 'Urgent' ? 'urgent' : ref.clinical_priority === 'Soon' ? 'warning' : 'neutral'"
                        />
                      } @else {
                        <app-status-label label="Unreviewed" tone="warning" />
                      }
                    </td>
                    <td class="py-3 px-3 text-xs text-[#4C6272]">
                      {{ ref.administrative_status }}
                    </td>
                    <td class="py-3 px-4 text-right">
                      <button
                        type="button"
                        (click)="selectReferral(ref)"
                        class="px-3 py-1.5 bg-[#EFF6FF] hover:bg-[#DBEAFE] text-[#003087] text-xs font-semibold rounded cursor-pointer whitespace-nowrap"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>

        <!-- Clinical Review & History Panel -->
        <section class="lg:col-span-5 bg-white border border-[#D8DDE0] rounded-lg p-6 shadow-sm space-y-5">
          @if (selectedReferral(); as sel) {
            <div class="space-y-1 border-b border-[#E8EDEE] pb-4">
              <div class="flex items-center justify-between gap-2">
                <h2 class="text-lg font-bold text-[#003087]">{{ sel.id }} — {{ sel.patient_name }}</h2>
                <app-status-label [label]="sel.review_status" [tone]="sel.review_status === 'Accepted' ? 'success' : 'warning'" />
              </div>
              <p class="text-sm text-[#212B32]">{{ sel.reason_summary }}</p>
              <div class="text-xs text-[#4C6272] tabular-nums">
                NHS: {{ sel.nhs_number }} ({{ sel.nhs_verification_status }}) ·
                Admin target date: {{ sel.admin_due_date ?? 'None' }} (not clinical urgency)
              </div>
              @if (sel.interpreter_required) {
                <div class="text-xs font-semibold text-[#92400E] bg-[#FFFBEB] border border-[#FCD34D] rounded px-2.5 py-1 inline-block mt-1">
                  Interpreter required: {{ sel.interpreter_language }}
                </div>
              }
            </div>

            <!-- Authorised Clinical Review Form -->
            <div class="space-y-3">
              <h3 class="text-sm font-bold text-[#212B32]">Authorised Clinical Review &amp; Booking Requirements</h3>
              @if (!auth.isClinician()) {
                <div class="bg-[#FFFBEB] border border-[#F59E0B] rounded p-3.5 text-xs text-[#92400E]">
                  <strong>Clinical Role Restriction:</strong> You are signed in as <strong>{{ auth.user()?.role }}</strong>.
                  Only authorised clinical roles (Clinician, Triage Nurse, Clinical Lead) may assign clinical priority or modify clinical booking requirements.
                </div>
              } @else {
                <form [formGroup]="reviewForm" (ngSubmit)="submitReview()" class="space-y-3">
                  <div class="grid grid-cols-2 gap-3">
                    <div>
                      <label for="rev-stat" class="block text-xs font-semibold text-[#212B32] mb-1">Decision</label>
                      <select id="rev-stat" formControlName="review_status" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm">
                        <option value="Accepted">Accepted (Add to Waiting List)</option>
                        <option value="Returned for Info">Returned for Info</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                    <div>
                      <label for="rev-prio" class="block text-xs font-semibold text-[#212B32] mb-1">Clinician Priority</label>
                      <select id="rev-prio" formControlName="clinical_priority" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm">
                        <option value="Urgent">Urgent</option>
                        <option value="Soon">Soon</option>
                        <option value="Routine">Routine</option>
                      </select>
                    </div>
                  </div>

                  <div class="grid grid-cols-2 gap-3">
                    <div>
                      <label for="rev-type" class="block text-xs font-semibold text-[#212B32] mb-1">Appointment Type</label>
                      <select id="rev-type" formControlName="appointment_type" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm">
                        <option value="New Outpatient">New Outpatient</option>
                        <option value="Follow-up">Follow-up</option>
                        <option value="Diagnostic Review">Diagnostic Review</option>
                      </select>
                    </div>
                    <div>
                      <label for="rev-dur" class="block text-xs font-semibold text-[#212B32] mb-1">Slot Length (min)</label>
                      <select id="rev-dur" formControlName="duration_minutes" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm">
                        <option [value]="15">15 min</option>
                        <option [value]="20">20 min</option>
                        <option [value]="30">30 min</option>
                        <option [value]="45">45 min</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label for="rev-eq" class="block text-xs font-semibold text-[#212B32] mb-1">Required Equipment</label>
                    <input id="rev-eq" type="text" formControlName="required_equipment" placeholder="e.g. 12-Lead ECG Machine" class="w-full min-h-[40px] px-2.5 py-1.5 border border-[#768692] rounded bg-white text-sm" />
                  </div>

                  <div>
                    <label for="rev-notes" class="block text-xs font-semibold text-[#212B32] mb-1">Clinical Review Notes</label>
                    <textarea id="rev-notes" rows="2" formControlName="review_notes" class="w-full px-3 py-2 border border-[#768692] rounded bg-white text-sm"></textarea>
                  </div>

                  <button type="submit" class="w-full min-h-[42px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-sm font-semibold rounded inline-flex items-center justify-center gap-2 cursor-pointer">
                    <mat-icon aria-hidden="true">verified_user</mat-icon>
                    <span>Record clinical review &amp; add to waiting list</span>
                  </button>
                </form>
              }
            </div>

            <!-- Documents & History -->
            <div class="pt-4 border-t border-[#E8EDEE] space-y-3">
              <h3 class="text-sm font-bold text-[#212B32]">Supporting Documents ({{ documents().length }})</h3>
              @for (d of documents(); track d.id) {
                <div class="flex items-center justify-between gap-2 text-xs p-2 bg-[#F8FAFC] border border-[#D8DDE0] rounded">
                  <span class="truncate font-medium">{{ d.title }}</span>
                  <button type="button" (click)="viewDoc(d.id)" class="text-[#005EB8] font-semibold hover:underline cursor-pointer">Open</button>
                </div>
              }
              @if (docContent()) {
                <pre class="p-3 bg-[#F8FAFC] border border-[#D8DDE0] rounded text-xs font-mono whitespace-pre-wrap">{{ docContent() }}</pre>
              }

              <h3 class="text-sm font-bold text-[#212B32] pt-2">Review &amp; Decision History</h3>
              <div class="space-y-2 max-h-48 overflow-y-auto">
                @for (h of history(); track h.id) {
                  <div class="text-xs p-2.5 border border-[#E8EDEE] rounded bg-[#F8FAFC]">
                    <div class="font-semibold text-[#212B32]">{{ h.action }} · {{ h.actor_name }} ({{ h.actor_role }})</div>
                    <div class="text-[#4C6272] mt-0.5">{{ h.notes }}</div>
                    <div class="text-[11px] font-mono text-[#4C6272] mt-0.5">{{ h.created_at.slice(0, 16).replace('T', ' ') }}</div>
                  </div>
                }
              </div>
            </div>
          } @else {
            <p class="text-sm text-[#4C6272]">Select a referral from the table to inspect details, supporting documents, and review history.</p>
          }
        </section>
      </div>
    </div>
  `,
})
export class StaffReferrals implements OnInit {
  private readonly api = inject(ApiService);
  readonly auth = inject(AuthService);

  readonly referrals = signal<ReferralRecord[]>([]);
  readonly patients = signal<PatientRecord[]>([]);
  readonly selectedReferral = signal<ReferralRecord | null>(null);
  readonly history = signal<{id: string; actor_name: string; actor_role: string; action: string; notes: string; created_at: string}[]>([]);
  readonly documents = signal<{id: string; title: string}[]>([]);
  readonly docContent = signal<string | null>(null);
  readonly statusFilter = signal('');
  readonly showCreateForm = signal(false);
  readonly feedback = signal<string | null>(null);
  readonly errorMsg = signal<string | null>(null);

  readonly createForm = new FormGroup({
    patient_id: new FormControl('PAT-1001', {nonNullable: true, validators: [Validators.required]}),
    specialty: new FormControl('Cardiology', {nonNullable: true, validators: [Validators.required]}),
    source: new FormControl('GP e-RS', {nonNullable: true, validators: [Validators.required]}),
    service_name: new FormControl('General Cardiology Outpatient', {nonNullable: true, validators: [Validators.required]}),
    reason_summary: new FormControl('GP referral for outpatient assessment and ECG.', {nonNullable: true, validators: [Validators.required]}),
    admin_due_date: new FormControl('', {nonNullable: true}),
  });

  readonly reviewForm = new FormGroup({
    review_status: new FormControl('Accepted', {nonNullable: true}),
    clinical_priority: new FormControl('Soon', {nonNullable: true}),
    appointment_type: new FormControl('New Outpatient', {nonNullable: true}),
    duration_minutes: new FormControl(30, {nonNullable: true}),
    required_equipment: new FormControl('', {nonNullable: true}),
    review_notes: new FormControl('Clinically reviewed and approved for outpatient booking.', {nonNullable: true, validators: [Validators.required]}),
  });

  async ngOnInit(): Promise<void> {
    await this.load();
    const pats = await this.api.getPatients();
    this.patients.set(pats.patients);
  }

  async load(): Promise<void> {
    const res = await this.api.getReferrals({reviewStatus: this.statusFilter() || undefined});
    this.referrals.set(res.referrals);
    if (!this.selectedReferral() && res.referrals.length > 0) {
      await this.selectReferral(res.referrals[0]);
    }
  }

  async onFilterStatus(ev: Event): Promise<void> {
    this.statusFilter.set((ev.target as HTMLSelectElement).value);
    await this.load();
  }

  async selectReferral(ref: ReferralRecord): Promise<void> {
    this.selectedReferral.set(ref);
    this.docContent.set(null);
    this.reviewForm.patchValue({
      review_status: ref.review_status === 'Pending Review' ? 'Accepted' : ref.review_status,
      clinical_priority: ref.clinical_priority ?? 'Soon',
      appointment_type: ref.appointment_type,
      duration_minutes: ref.duration_minutes,
      required_equipment: ref.required_equipment ?? '',
      review_notes: ref.review_notes ?? 'Clinically reviewed and approved for outpatient booking.',
    });
    const histRes = await this.api.getReferralHistory(ref.id);
    this.history.set(histRes.history);
    this.documents.set(histRes.documents);
  }

  async submitCreate(): Promise<void> {
    if (this.createForm.invalid) return;
    this.errorMsg.set(null);
    this.feedback.set(null);
    const v = this.createForm.getRawValue();
    const res = await this.api.createReferral(v);
    this.feedback.set(`Referral ${res.id} received and queued for clinical review.`);
    this.showCreateForm.set(false);
    await this.load();
  }

  async submitReview(): Promise<void> {
    const sel = this.selectedReferral();
    if (!sel || this.reviewForm.invalid) return;
    this.errorMsg.set(null);
    this.feedback.set(null);
    try {
      const v = this.reviewForm.getRawValue();
      const res = await this.api.reviewReferral(sel.id, {
        ...v,
        duration_minutes: Number(v.duration_minutes),
        required_equipment: v.required_equipment || null,
      });
      this.feedback.set(`Clinical review saved for ${sel.id}. Waiting list entry updated.`);
      await this.load();
      await this.selectReferral(res.referral);
    } catch (err: unknown) {
      const e = err as {error?: {error?: string}};
      this.errorMsg.set(e?.error?.error ?? 'Unable to record clinical review.');
    }
  }

  async viewDoc(docId: string): Promise<void> {
    const res = await this.api.downloadDocument(docId);
    this.docContent.set(res.content);
  }
}
