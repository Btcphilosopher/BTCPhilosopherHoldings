import express, {type Router} from 'express';
import {randomBytes} from 'node:crypto';
import {readFileSync, writeFileSync, existsSync} from 'node:fs';
import {resolve, sep} from 'node:path';
import type {AppDatabase} from './db.js';
import {
  attachAuth,
  checkPatientAccess,
  issueSessionToken,
  recordAudit,
  requireRoles,
  verifyPassword,
  type AuthenticatedRequest,
} from './auth.js';
import {
  checkResourceConflicts,
  confirmBookingTransactional,
  flagSessionImpacted,
  generateSessionWithSlots,
  holdSlotTransactional,
  transitionAppointmentState,
} from './scheduling.js';
import {ADAPTER_AUTHORITY_MATRIX, ingestExternalEventIdempotent} from './adapters.js';
import {runBackgroundWorkerPass} from './worker.js';
import {PROTOTYPE_HAZARD_LOG} from './hazard-log.js';
import {
  CLINICAL_ROLES,
  STAFF_ROLES,
  type AppointmentState,
  type AuthUser,
  type ClinicalOutcomeType,
  type ClinicalPriority,
  type ProxyScope,
  type ReviewStatus,
} from './types.js';

function handleRouteError(res: express.Response, err: unknown): void {
  const e = err as Error & {statusCode?: number};
  const status = e.statusCode ?? 400;
  res.status(status).json({error: e.message || 'Operation failed'});
}

export function createApiRouter(appDb: AppDatabase): Router {
  const router = express.Router();
  router.use(express.json({limit: '2mb'}));

  // Health endpoint
  router.get('/health', (_req, res) => {
    res.json({
      status: 'ok',
      prototype: true,
      organisation: 'Pennine Outpatient Centre (Fictional Independent Prototype)',
      timezone: 'Europe/London',
    });
  });

  // Synthetic persona list for prototype login screen (excludes password hashes!)
  router.get('/auth/personas', (_req, res) => {
    const users = appDb.db
      .prepare(
        `SELECT id, username, display_name, role, patient_id, clinician_id, specialty, site_id, identity_provider
         FROM users WHERE active = 1 ORDER BY role, display_name`,
      )
      .all();
    res.json({personas: users});
  });

  // Synthetic sign-in (NHS number is NEVER accepted as a password or credential)
  router.post('/auth/login', (req, res) => {
    const {username, password} = req.body as {username?: string; password?: string};
    if (!username || !password) {
      res.status(400).json({error: 'Username and passcode are required. NHS numbers cannot be used as passwords.'});
      return;
    }

    // Explicitly reject attempts to log in using an NHS number as username
    if (/^\d{3}\s?\d{3}\s?\d{4}$/.test(username.trim())) {
      res.status(400).json({
        error: 'An NHS number is an identifier, not a credential. Please sign in with your portal username and passcode.',
      });
      return;
    }

    const row = appDb.db
      .prepare('SELECT * FROM users WHERE username = ? AND active = 1')
      .get(username.trim()) as (AuthUser & {password_hash: string; active: number}) | undefined;

    if (!row || !verifyPassword(password, row.password_hash)) {
      res.status(401).json({error: 'Invalid username or passcode.'});
      return;
    }

    const user: AuthUser = {
      id: row.id,
      username: row.username,
      display_name: row.display_name,
      role: row.role,
      patient_id: row.patient_id,
      clinician_id: row.clinician_id,
      specialty: row.specialty,
      site_id: row.site_id,
      identity_provider: row.identity_provider,
    };
    const token = issueSessionToken(user);
    recordAudit(appDb, user, 'USER_SIGNED_IN', 'User', user.id, user.patient_id, {
      identity_provider: user.identity_provider,
    });

    res.json({token, user});
  });

  // All routes below require valid Bearer token
  router.use(attachAuth(appDb));

  router.get('/auth/me', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    let accessiblePatients: unknown[] = [];
    if (user.role === 'PATIENT' && user.patient_id) {
      accessiblePatients = appDb.db
        .prepare('SELECT id, full_name, nhs_number, nhs_verification_status FROM patients WHERE id = ?')
        .all(user.patient_id);
    } else if (user.role === 'PROXY') {
      accessiblePatients = appDb.db
        .prepare(
          `SELECT p.id, p.full_name, p.nhs_number, p.nhs_verification_status, pr.relationship, pr.scope
           FROM proxy_relationships pr
           JOIN patients p ON p.id = pr.patient_id
           WHERE pr.proxy_user_id = ? AND pr.verification_status = 'Verified'`,
        )
        .all(user.id);
    }
    res.json({user, accessible_patients: accessiblePatients});
  });

  // Reference data (authenticated)
  router.get('/sites', (_req, res) => {
    const sites = appDb.db.prepare('SELECT * FROM sites ORDER BY name').all();
    const rooms = appDb.db.prepare('SELECT * FROM rooms ORDER BY site_id, name').all();
    const clinicians = appDb.db.prepare('SELECT * FROM clinicians ORDER BY specialty, full_name').all();
    res.json({sites, rooms, clinicians});
  });

  // Patients list (Staff only; patients/proxies only get their authorised records)
  router.get('/patients', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    if (user.role === 'PATIENT') {
      const rows = appDb.db.prepare('SELECT * FROM patients WHERE id = ?').all(user.patient_id);
      res.json({patients: rows});
      return;
    }
    if (user.role === 'PROXY') {
      const rows = appDb.db
        .prepare(
          `SELECT p.*, pr.scope as proxy_scope, pr.relationship as proxy_relationship
           FROM proxy_relationships pr
           JOIN patients p ON p.id = pr.patient_id
           WHERE pr.proxy_user_id = ? AND pr.verification_status = 'Verified'`,
        )
        .all(user.id);
      res.json({patients: rows});
      return;
    }

    const q = typeof req.query['q'] === 'string' ? req.query['q'].trim() : '';
    const rows = q
      ? appDb.db
          .prepare(
            `SELECT * FROM patients
             WHERE full_name LIKE ? OR nhs_number LIKE ? OR id LIKE ?
             ORDER BY full_name`,
          )
          .all(`%${q}%`, `%${q}%`, `%${q}%`)
      : appDb.db.prepare('SELECT * FROM patients ORDER BY full_name').all();
    res.json({patients: rows});
  });

  router.get('/patients/:id', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    const patientId = String(req.params['id']);
    const access = checkPatientAccess(appDb, user, patientId, 'VIEW_ONLY');
    if (!access.allowed) {
      recordAudit(appDb, user, 'PATIENT_ISOLATION_BLOCKED', 'Patient', patientId, patientId, {
        reason: access.reason,
      });
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }

    const patient = appDb.db.prepare('SELECT * FROM patients WHERE id = ?').get(patientId);
    if (!patient) {
      res.status(404).json({error: 'Patient not found.'});
      return;
    }

    const proxies = appDb.db
      .prepare('SELECT * FROM proxy_relationships WHERE patient_id = ?')
      .all(patientId);
    const documents = appDb.db
      .prepare('SELECT id, patient_id, referral_id, title, doc_type, mime_type, uploaded_by, created_at FROM documents WHERE patient_id = ?')
      .all(patientId);

    res.json({patient, proxies, documents});
  });

  router.patch('/patients/:id/preferences', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    const patientId = String(req.params['id']);
    const access = checkPatientAccess(appDb, user, patientId, 'VIEW_AND_BOOK');
    if (!access.allowed) {
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }

    const body = req.body as {
      preferred_contact_channel?: string;
      marketing_consent?: boolean;
      appointment_comms_enabled?: boolean;
      accessibility_requirements?: string;
      interpreter_required?: boolean;
      interpreter_language?: string | null;
      preferred_modality?: string;
      preferred_site_id?: string;
      phone?: string;
      email?: string;
    };

    const existing = appDb.db.prepare('SELECT * FROM patients WHERE id = ?').get(patientId) as
      | Record<string, unknown>
      | undefined;
    if (!existing) {
      res.status(404).json({error: 'Patient not found.'});
      return;
    }

    appDb.db
      .prepare(
        `UPDATE patients SET
          preferred_contact_channel = ?,
          marketing_consent = ?,
          appointment_comms_enabled = ?,
          accessibility_requirements = ?,
          interpreter_required = ?,
          interpreter_language = ?,
          preferred_modality = ?,
          preferred_site_id = ?,
          phone = ?,
          email = ?
         WHERE id = ?`,
      )
      .run(
        body.preferred_contact_channel ?? existing['preferred_contact_channel'],
        body.marketing_consent !== undefined ? (body.marketing_consent ? 1 : 0) : existing['marketing_consent'],
        body.appointment_comms_enabled !== undefined
          ? body.appointment_comms_enabled
            ? 1
            : 0
          : existing['appointment_comms_enabled'],
        body.accessibility_requirements ?? existing['accessibility_requirements'],
        body.interpreter_required !== undefined
          ? body.interpreter_required
            ? 1
            : 0
          : existing['interpreter_required'],
        body.interpreter_language !== undefined ? body.interpreter_language : existing['interpreter_language'],
        body.preferred_modality ?? existing['preferred_modality'],
        body.preferred_site_id ?? existing['preferred_site_id'],
        body.phone ?? existing['phone'],
        body.email ?? existing['email'],
        patientId,
      );

    recordAudit(appDb, user, 'PATIENT_PREFERENCES_UPDATED', 'Patient', patientId, patientId, {
      preferred_contact_channel: body.preferred_contact_channel,
      marketing_consent_updated: body.marketing_consent !== undefined,
    });

    const updated = appDb.db.prepare('SELECT * FROM patients WHERE id = ?').get(patientId);
    res.json({patient: updated});
  });

  router.post(
    '/patients/:id/proxies',
    requireRoles(appDb, STAFF_ROLES, 'Manage verified proxy relationships'),
    (req: AuthenticatedRequest, res) => {
      const patientId = String(req.params['id']);
      const {proxy_user_id, proxy_name, relationship, scope, verification_status} = req.body as {
        proxy_user_id?: string;
        proxy_name?: string;
        relationship?: string;
        scope?: ProxyScope;
        verification_status?: string;
      };
      if (!proxy_user_id || !proxy_name || !relationship || !scope) {
        res.status(400).json({error: 'proxy_user_id, proxy_name, relationship, and scope are required.'});
        return;
      }
      const id = `PRX-${Date.now().toString().slice(-5)}`;
      const nowIso = new Date().toISOString();
      appDb.db
        .prepare(
          `INSERT INTO proxy_relationships (id, proxy_user_id, proxy_name, patient_id, relationship, scope, verification_status, verified_by, verified_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .run(
          id,
          proxy_user_id,
          proxy_name,
          patientId,
          relationship,
          scope,
          verification_status ?? 'Verified',
          req.user!.display_name,
          nowIso,
        );
      recordAudit(appDb, req.user!, 'PROXY_RELATIONSHIP_CREATED', 'ProxyRelationship', id, patientId, {
        proxy_user_id,
        scope,
      });
      res.status(201).json({id});
    },
  );

  // Protected Document Download (with path traversal confinement + patient/proxy isolation)
  router.get('/documents/:docId/download', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    const docId = String(req.params['docId']);
    const doc = appDb.db.prepare('SELECT * FROM documents WHERE id = ?').get(docId) as
      | {
          id: string;
          patient_id: string;
          title: string;
          storage_key: string;
          mime_type: string;
        }
      | undefined;

    if (!doc) {
      res.status(404).json({error: 'Document not found.'});
      return;
    }

    const access = checkPatientAccess(appDb, user, doc.patient_id, 'VIEW_ONLY');
    if (!access.allowed) {
      recordAudit(appDb, user, 'DOCUMENT_ACCESS_DENIED', 'Document', docId, doc.patient_id, {
        reason: access.reason,
      });
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }

    const baseDir = resolve(appDb.storageDir);
    const resolvedPath = resolve(baseDir, doc.storage_key);
    if (!resolvedPath.startsWith(baseDir + sep) || !existsSync(resolvedPath)) {
      res.status(404).json({error: 'Protected document file unavailable.'});
      return;
    }

    const content = readFileSync(resolvedPath, 'utf8');
    recordAudit(appDb, user, 'DOCUMENT_ACCESSED', 'Document', docId, doc.patient_id, {
      title: doc.title,
    });
    res.json({document: doc, content});
  });

  // Referrals
  router.get('/referrals', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    const targetPatient = typeof req.query['patient_id'] === 'string' ? req.query['patient_id'] : null;

    if (user.role === 'PATIENT' || user.role === 'PROXY') {
      const patientId = targetPatient ?? user.patient_id;
      if (!patientId) {
        res.status(400).json({error: 'patient_id query parameter required for proxy account.'});
        return;
      }
      const access = checkPatientAccess(appDb, user, patientId, 'VIEW_ONLY');
      if (!access.allowed) {
        recordAudit(appDb, user, 'REFERRAL_ACCESS_DENIED', 'Referral', 'list', patientId, {
          reason: access.reason,
        });
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const rows = appDb.db
        .prepare(
          `SELECT r.*, p.full_name as patient_name, p.nhs_number, p.interpreter_required, p.interpreter_language
           FROM referrals r JOIN patients p ON p.id = r.patient_id
           WHERE r.patient_id = ? ORDER BY r.received_date DESC`,
        )
        .all(patientId);
      res.json({referrals: rows});
      return;
    }

    const specialty = typeof req.query['specialty'] === 'string' ? req.query['specialty'] : '';
    const reviewStatus = typeof req.query['review_status'] === 'string' ? req.query['review_status'] : '';

    let sql = `SELECT r.*, p.full_name as patient_name, p.nhs_number, p.nhs_verification_status,
                      p.interpreter_required, p.interpreter_language, p.accessibility_requirements
               FROM referrals r JOIN patients p ON p.id = r.patient_id WHERE 1=1`;
    const params: string[] = [];
    if (specialty) {
      sql += ' AND r.specialty = ?';
      params.push(specialty);
    }
    if (reviewStatus) {
      sql += ' AND r.review_status = ?';
      params.push(reviewStatus);
    }
    if (targetPatient) {
      sql += ' AND r.patient_id = ?';
      params.push(targetPatient);
    }
    sql += ' ORDER BY r.received_date DESC, r.created_at DESC';
    const rows = appDb.db.prepare(sql).all(...params);
    res.json({referrals: rows});
  });

  // Create new synthetic referral (Staff or inbound e-RS simulator)
  router.post(
    '/referrals',
    requireRoles(appDb, STAFF_ROLES, 'Create referral'),
    (req: AuthenticatedRequest, res) => {
      const body = req.body as {
        patient_id?: string;
        source?: string;
        specialty?: string;
        service_name?: string;
        reason_summary?: string;
        appointment_type?: string;
        duration_minutes?: number;
        required_equipment?: string | null;
        admin_due_date?: string;
      };
      if (!body.patient_id || !body.specialty || !body.service_name || !body.reason_summary) {
        res.status(400).json({error: 'patient_id, specialty, service_name, and reason_summary are required.'});
        return;
      }

      const id = `REF-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`;
      const nowIso = new Date().toISOString();
      const today = nowIso.slice(0, 10);

      appDb.runInTransaction(() => {
        appDb.db
          .prepare(
            `INSERT INTO referrals (
              id, patient_id, source, external_ubrn, received_date, specialty, service_name,
              reason_summary, clinical_priority, administrative_status, review_status,
              appointment_type, duration_minutes, required_staff_role, required_room_type,
              required_equipment, requires_interpreter_booking, admin_due_date, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, 'Awaiting Clinical Review', 'Pending Review', ?, ?, ?, 'Outpatient Consulting', ?, 0, ?, ?)`,
          )
          .run(
            id,
            body.patient_id!,
            body.source ?? 'GP e-RS',
            `UBRN-${Date.now().toString().slice(-8)}`,
            today,
            body.specialty!,
            body.service_name!,
            body.reason_summary!,
            body.appointment_type ?? 'New Outpatient',
            body.duration_minutes ?? 30,
            `Consultant (${body.specialty})`,
            body.required_equipment ?? null,
            body.admin_due_date ?? null,
            nowIso,
          );

        appDb.db
          .prepare(
            `INSERT INTO referral_history (id, referral_id, actor_user_id, actor_name, actor_role, action, notes, created_at)
             VALUES (?, ?, ?, ?, ?, 'Referral Received', ?, ?)`,
          )
          .run(
            `RH-${Date.now().toString().slice(-6)}`,
            id,
            req.user!.id,
            req.user!.display_name,
            req.user!.role,
            `Referral received from ${body.source ?? 'GP e-RS'}. Awaiting authorised clinical review.`,
            nowIso,
          );

        recordAudit(appDb, req.user!, 'REFERRAL_CREATED', 'Referral', id, body.patient_id!, {
          specialty: body.specialty,
        });
      });

      res.status(201).json({id});
    },
  );

  // Authorised Clinical Review & Priority Assignment (STRICTLY CLINICAL ROLES!)
  router.post(
    '/referrals/:id/review',
    requireRoles(appDb, CLINICAL_ROLES, 'Clinical review and priority assignment'),
    (req: AuthenticatedRequest, res) => {
      const referralId = String(req.params['id']);
      const body = req.body as {
        review_status?: ReviewStatus;
        clinical_priority?: ClinicalPriority;
        appointment_type?: string;
        duration_minutes?: number;
        required_equipment?: string | null;
        requires_interpreter_booking?: boolean;
        booking_window_start?: string;
        booking_window_end?: string;
        review_notes?: string;
      };

      if (!body.review_status || !body.clinical_priority || !body.review_notes) {
        res.status(400).json({error: 'review_status, clinical_priority, and review_notes are required.'});
        return;
      }

      const existing = appDb.db.prepare('SELECT * FROM referrals WHERE id = ?').get(referralId) as
        | {
            id: string;
            patient_id: string;
            specialty: string;
            clinical_priority: string | null;
            duration_minutes: number;
            appointment_type: string;
            required_equipment: string | null;
            requires_interpreter_booking: number;
          }
        | undefined;

      if (!existing) {
        res.status(404).json({error: 'Referral not found.'});
        return;
      }

      const nowIso = new Date().toISOString();
      const patient = appDb.db
        .prepare('SELECT preferred_site_id, preferred_modality, interpreter_required FROM patients WHERE id = ?')
        .get(existing.patient_id) as {
        preferred_site_id: string | null;
        preferred_modality: string;
        interpreter_required: number;
      };

      appDb.runInTransaction(() => {
        const newAdminStatus =
          body.review_status === 'Accepted' ? 'On Waiting List' : 'Returned / Cancelled';

        appDb.db
          .prepare(
            `UPDATE referrals SET
              review_status = ?,
              clinical_priority = ?,
              administrative_status = ?,
              reviewed_by_user_id = ?,
              reviewed_by_name = ?,
              reviewed_at = ?,
              review_notes = ?,
              appointment_type = ?,
              duration_minutes = ?,
              required_equipment = ?,
              requires_interpreter_booking = ?,
              booking_window_start = ?,
              booking_window_end = ?
             WHERE id = ?`,
          )
          .run(
            body.review_status!,
            body.clinical_priority!,
            newAdminStatus,
            req.user!.id,
            req.user!.display_name,
            nowIso,
            body.review_notes!,
            body.appointment_type ?? existing.appointment_type,
            body.duration_minutes ?? existing.duration_minutes,
            body.required_equipment !== undefined
              ? body.required_equipment
              : existing.required_equipment,
            body.requires_interpreter_booking !== undefined
              ? body.requires_interpreter_booking
                ? 1
                : 0
              : patient.interpreter_required,
            body.booking_window_start ?? nowIso.slice(0, 10),
            body.booking_window_end ?? null,
            referralId,
          );

        appDb.db
          .prepare(
            `INSERT INTO referral_history (id, referral_id, actor_user_id, actor_name, actor_role, action, previous_priority, new_priority, notes, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          )
          .run(
            `RH-${Date.now().toString().slice(-6)}-${randomBytes(1).toString('hex')}`,
            referralId,
            req.user!.id,
            req.user!.display_name,
            req.user!.role,
            `Clinical Review: ${body.review_status}`,
            existing.clinical_priority,
            body.clinical_priority!,
            body.review_notes!,
            nowIso,
          );

        // Add or update waiting list entry preserving original_joined_at
        if (body.review_status === 'Accepted') {
          const existingWl = appDb.db
            .prepare('SELECT id FROM waiting_list_entries WHERE referral_id = ?')
            .get(referralId) as {id: string} | undefined;
          if (!existingWl) {
            appDb.db
              .prepare(
                `INSERT INTO waiting_list_entries (id, referral_id, patient_id, specialty, clinical_priority, original_joined_at, status, short_notice_opt_in, preferred_site_id, preferred_modality, notes)
                 VALUES (?, ?, ?, ?, ?, ?, 'Active', 0, ?, ?, ?)`,
              )
              .run(
                `WL-${Date.now().toString().slice(-5)}`,
                referralId,
                existing.patient_id,
                existing.specialty,
                body.clinical_priority!,
                nowIso,
                patient.preferred_site_id,
                patient.preferred_modality,
                `Reviewed by ${req.user!.display_name}`,
              );
          } else {
            appDb.db
              .prepare('UPDATE waiting_list_entries SET clinical_priority = ? WHERE id = ?')
              .run(body.clinical_priority!, existingWl.id);
          }
        }

        recordAudit(appDb, req.user!, 'REFERRAL_CLINICALLY_REVIEWED', 'Referral', referralId, existing.patient_id, {
          review_status: body.review_status,
          previous_priority: existing.clinical_priority,
          clinical_priority: body.clinical_priority,
          duration_minutes: body.duration_minutes ?? existing.duration_minutes,
        });
      });

      const updated = appDb.db.prepare('SELECT * FROM referrals WHERE id = ?').get(referralId);
      res.json({referral: updated});
    },
  );

  router.get('/referrals/:id/history', (req: AuthenticatedRequest, res) => {
    const referralId = String(req.params['id']);
    const ref = appDb.db.prepare('SELECT patient_id FROM referrals WHERE id = ?').get(referralId) as
      | {patient_id: string}
      | undefined;
    if (!ref) {
      res.status(404).json({error: 'Referral not found.'});
      return;
    }
    const access = checkPatientAccess(appDb, req.user!, ref.patient_id, 'VIEW_ONLY');
    if (!access.allowed) {
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }
    const history = appDb.db
      .prepare('SELECT * FROM referral_history WHERE referral_id = ? ORDER BY created_at DESC')
      .all(referralId);
    const documents = appDb.db
      .prepare('SELECT id, patient_id, referral_id, title, doc_type, mime_type, uploaded_by, created_at FROM documents WHERE referral_id = ?')
      .all(referralId);
    res.json({history, documents});
  });

  // Upload/attach protected text document to a referral
  router.post(
    '/referrals/:id/documents',
    requireRoles(appDb, STAFF_ROLES, 'Attach referral supporting document'),
    (req: AuthenticatedRequest, res) => {
      const referralId = String(req.params['id']);
      const {title, doc_type, content} = req.body as {
        title?: string;
        doc_type?: string;
        content?: string;
      };
      if (!title || !content) {
        res.status(400).json({error: 'title and content are required.'});
        return;
      }
      const ref = appDb.db.prepare('SELECT patient_id FROM referrals WHERE id = ?').get(referralId) as
        | {patient_id: string}
        | undefined;
      if (!ref) {
        res.status(404).json({error: 'Referral not found.'});
        return;
      }

      const docId = `DOC-${Date.now().toString().slice(-6)}`;
      const storageKey = `${referralId.toLowerCase()}-${docId.toLowerCase()}.txt`;
      const baseDir = resolve(appDb.storageDir);
      const targetPath = resolve(baseDir, storageKey);
      if (!targetPath.startsWith(baseDir + sep)) {
        res.status(400).json({error: 'Invalid document key.'});
        return;
      }
      writeFileSync(targetPath, content, 'utf8');
      appDb.db
        .prepare(
          'INSERT INTO documents (id, patient_id, referral_id, title, doc_type, storage_key, mime_type, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          docId,
          ref.patient_id,
          referralId,
          title,
          doc_type ?? 'Clinical Supporting Note',
          storageKey,
          'text/plain',
          req.user!.display_name,
          new Date().toISOString(),
        );
      recordAudit(appDb, req.user!, 'DOCUMENT_UPLOADED', 'Document', docId, ref.patient_id, {
        referral_id: referralId,
        title,
      });
      res.status(201).json({id: docId});
    },
  );

  // Waiting Lists
  router.get('/waiting-lists', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    const patientIdParam = typeof req.query['patient_id'] === 'string' ? req.query['patient_id'] : null;

    if (user.role === 'PATIENT' || user.role === 'PROXY') {
      const pid = patientIdParam ?? user.patient_id;
      if (!pid) {
        res.status(400).json({error: 'patient_id required'});
        return;
      }
      const access = checkPatientAccess(appDb, user, pid, 'VIEW_ONLY');
      if (!access.allowed) {
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const rows = appDb.db
        .prepare(
          `SELECT wl.*, r.service_name, r.appointment_type, r.duration_minutes, r.required_equipment,
                  r.booking_window_start, r.booking_window_end, r.admin_due_date, r.administrative_status,
                  p.full_name as patient_name
           FROM waiting_list_entries wl
           JOIN referrals r ON r.id = wl.referral_id
           JOIN patients p ON p.id = wl.patient_id
           WHERE wl.patient_id = ?
           ORDER BY wl.original_joined_at ASC`,
        )
        .all(pid);
      res.json({waiting_lists: rows});
      return;
    }

    const rows = appDb.db
      .prepare(
        `SELECT wl.*, r.service_name, r.appointment_type, r.duration_minutes, r.required_equipment,
                r.booking_window_start, r.booking_window_end, r.admin_due_date, r.administrative_status,
                p.full_name as patient_name, p.nhs_number, p.interpreter_required, p.interpreter_language,
                p.preferred_contact_channel
         FROM waiting_list_entries wl
         JOIN referrals r ON r.id = wl.referral_id
         JOIN patients p ON p.id = wl.patient_id
         ORDER BY CASE wl.clinical_priority WHEN 'Urgent' THEN 1 WHEN 'Soon' THEN 2 ELSE 3 END, wl.original_joined_at ASC`,
      )
      .all();
    res.json({waiting_lists: rows});
  });

  // Send appointment offer to patient from waiting list
  router.post(
    '/waiting-lists/:id/send-offer',
    requireRoles(appDb, STAFF_ROLES, 'Send appointment offer'),
    (req: AuthenticatedRequest, res) => {
      const wlId = String(req.params['id']);
      const wl = appDb.db
        .prepare(
          `SELECT wl.*, p.full_name, p.preferred_contact_channel, p.phone, p.email
           FROM waiting_list_entries wl JOIN patients p ON p.id = wl.patient_id
           WHERE wl.id = ?`,
        )
        .get(wlId) as
        | {
            id: string;
            referral_id: string;
            patient_id: string;
            specialty: string;
            full_name: string;
            preferred_contact_channel: string;
            phone: string;
            email: string;
          }
        | undefined;
      if (!wl) {
        res.status(404).json({error: 'Waiting list entry not found.'});
        return;
      }
      const nowIso = new Date().toISOString();
      appDb.runInTransaction(() => {
        appDb.db
          .prepare(`UPDATE waiting_list_entries SET status = 'Offer Pending' WHERE id = ?`)
          .run(wl.id);
        appDb.db
          .prepare(`UPDATE referrals SET administrative_status = 'Offer Sent' WHERE id = ?`)
          .run(wl.referral_id);
        const notifId = `NTF-${Date.now().toString().slice(-6)}`;
        const recipient =
          wl.preferred_contact_channel === 'Email'
            ? wl.email
            : wl.preferred_contact_channel === 'SMS' || wl.preferred_contact_channel === 'Telephone'
              ? wl.phone
              : `Portal Account: ${wl.full_name}`;
        appDb.db
          .prepare(
            `INSERT INTO notifications (id, patient_id, channel, message_type, recipient_address, subject, body_redacted, status, attempt_count, scheduled_for_utc, sent_at_utc, created_at)
             VALUES (?, ?, ?, 'Offer', ?, ?, ?, 'Delivered', 1, ?, ?, ?)`,
          )
          .run(
            notifId,
            wl.patient_id,
            wl.preferred_contact_channel,
            recipient,
            `${wl.specialty} appointment slots available to book`,
            `Pennine Outpatient Centre invites you to choose an appointment slot for your ${wl.specialty} referral. Sign in to TERTIUSMEDICO or call 01282 550100. Portal messaging is not an emergency service.`,
            nowIso,
            nowIso,
            nowIso,
          );
        recordAudit(appDb, req.user!, 'APPOINTMENT_OFFER_SENT', 'WaitingListEntry', wl.id, wl.patient_id, {
          referral_id: wl.referral_id,
          channel: wl.preferred_contact_channel,
        });
      });
      res.json({ok: true});
    },
  );

  // Patient short-notice opt-in toggle
  router.patch('/waiting-lists/:id/short-notice', (req: AuthenticatedRequest, res) => {
    const wlId = String(req.params['id']);
    const {opt_in} = req.body as {opt_in?: boolean};
    const wl = appDb.db.prepare('SELECT id, patient_id FROM waiting_list_entries WHERE id = ?').get(wlId) as
      | {id: string; patient_id: string}
      | undefined;
    if (!wl) {
      res.status(404).json({error: 'Waiting list entry not found.'});
      return;
    }
    const access = checkPatientAccess(appDb, req.user!, wl.patient_id, 'VIEW_AND_BOOK');
    if (!access.allowed) {
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }
    appDb.db
      .prepare('UPDATE waiting_list_entries SET short_notice_opt_in = ? WHERE id = ?')
      .run(opt_in ? 1 : 0, wlId);
    recordAudit(appDb, req.user!, 'SHORT_NOTICE_LIST_UPDATED', 'WaitingListEntry', wlId, wl.patient_id, {
      short_notice_opt_in: !!opt_in,
    });
    res.json({short_notice_opt_in: !!opt_in});
  });

  // Clinic Templates & Sessions
  router.get('/clinic-templates', requireRoles(appDb, STAFF_ROLES, 'View clinic templates'), (_req, res) => {
    const templates = appDb.db
      .prepare(
        `SELECT ct.*, s.name as site_name, r.name as room_name, c.full_name as clinician_name
         FROM clinic_templates ct
         JOIN sites s ON s.id = ct.site_id
         JOIN rooms r ON r.id = ct.room_id
         JOIN clinicians c ON c.id = ct.clinician_id
         ORDER BY ct.specialty, ct.name`,
      )
      .all();
    const versions = appDb.db
      .prepare('SELECT * FROM clinic_template_versions ORDER BY created_at DESC')
      .all();
    res.json({templates, versions});
  });

  router.patch(
    '/clinic-templates/:id',
    requireRoles(appDb, STAFF_ROLES, 'Update versioned clinic template'),
    (req: AuthenticatedRequest, res) => {
      const templateId = String(req.params['id']);
      const {slot_length_minutes, buffer_minutes, protected_urgent_slots, change_reason} = req.body as {
        slot_length_minutes?: number;
        buffer_minutes?: number;
        protected_urgent_slots?: number;
        change_reason?: string;
      };
      const existing = appDb.db.prepare('SELECT * FROM clinic_templates WHERE id = ?').get(templateId) as
        | {
            id: string;
            slot_length_minutes: number;
            buffer_minutes: number;
            protected_urgent_slots: number;
            current_version: number;
          }
        | undefined;
      if (!existing) {
        res.status(404).json({error: 'Clinic template not found.'});
        return;
      }

      const nextVer = existing.current_version + 1;
      const nowIso = new Date().toISOString();
      appDb.runInTransaction(() => {
        appDb.db
          .prepare(
            `UPDATE clinic_templates SET slot_length_minutes = ?, buffer_minutes = ?, protected_urgent_slots = ?, current_version = ? WHERE id = ?`,
          )
          .run(
            slot_length_minutes ?? existing.slot_length_minutes,
            buffer_minutes ?? existing.buffer_minutes,
            protected_urgent_slots ?? existing.protected_urgent_slots,
            nextVer,
            templateId,
          );
        appDb.db
          .prepare(
            `INSERT INTO clinic_template_versions (id, template_id, version_number, effective_from, snapshot_json, changed_by, change_reason, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          )
          .run(
            `TV-${templateId}-${nextVer}`,
            templateId,
            nextVer,
            nowIso.slice(0, 10),
            JSON.stringify({
              slot_length_minutes: slot_length_minutes ?? existing.slot_length_minutes,
              buffer_minutes: buffer_minutes ?? existing.buffer_minutes,
              protected_urgent_slots: protected_urgent_slots ?? existing.protected_urgent_slots,
            }),
            req.user!.display_name,
            change_reason ?? 'Template capacity update',
            nowIso,
          );
        recordAudit(appDb, req.user!, 'CLINIC_TEMPLATE_VERSIONED', 'ClinicTemplate', templateId, null, {
          new_version: nextVer,
          change_reason: change_reason ?? 'Template capacity update',
        });
      });

      res.json({version: nextVer});
    },
  );

  router.get('/clinic-sessions', requireRoles(appDb, STAFF_ROLES, 'View clinic sessions'), (_req, res) => {
    const sessions = appDb.db
      .prepare(
        `SELECT cs.*, s.name as site_name, r.name as room_name, c.full_name as clinician_name,
                (SELECT COUNT(*) FROM clinic_slots sl WHERE sl.session_id = cs.id) as total_slots,
                (SELECT COUNT(*) FROM clinic_slots sl WHERE sl.session_id = cs.id AND sl.status = 'Available') as available_slots,
                (SELECT COUNT(*) FROM clinic_slots sl WHERE sl.session_id = cs.id AND sl.status = 'Booked') as booked_slots
         FROM clinic_sessions cs
         JOIN sites s ON s.id = cs.site_id
         JOIN rooms r ON r.id = cs.room_id
         JOIN clinicians c ON c.id = cs.clinician_id
         ORDER BY cs.session_date ASC, cs.start_time ASC`,
      )
      .all();
    const absences = appDb.db
      .prepare(
        `SELECT sa.*, c.full_name as clinician_name, c.specialty
         FROM staff_absences sa JOIN clinicians c ON c.id = sa.clinician_id ORDER BY sa.start_date ASC`,
      )
      .all();
    const closures = appDb.db
      .prepare(
        `SELECT rc.*, r.name as room_name, s.name as site_name
         FROM room_closures rc JOIN rooms r ON r.id = rc.room_id JOIN sites s ON s.id = r.site_id ORDER BY rc.start_date ASC`,
      )
      .all();
    res.json({sessions, absences, closures});
  });

  router.post(
    '/clinic-sessions/generate',
    requireRoles(appDb, STAFF_ROLES, 'Generate clinic session slots'),
    (req: AuthenticatedRequest, res) => {
      try {
        const {template_id, session_date, start_time, end_time, notes} = req.body as {
          template_id?: string;
          session_date?: string;
          start_time?: string;
          end_time?: string;
          notes?: string;
        };
        if (!template_id || !session_date || !start_time || !end_time) {
          res.status(400).json({error: 'template_id, session_date, start_time, and end_time are required.'});
          return;
        }
        const out = generateSessionWithSlots(appDb, req.user!, {
          templateId: template_id,
          sessionDate: session_date,
          startTime: start_time,
          endTime: end_time,
          notes,
        });
        res.status(201).json(out);
      } catch (err) {
        handleRouteError(res, err);
      }
    },
  );

  // Record clinician absence -> places impacted bookings in Affected Appointments Queue
  router.post(
    '/absences',
    requireRoles(appDb, STAFF_ROLES, 'Record clinician absence'),
    (req: AuthenticatedRequest, res) => {
      const {clinician_id, start_date, end_date, reason} = req.body as {
        clinician_id?: string;
        start_date?: string;
        end_date?: string;
        reason?: string;
      };
      if (!clinician_id || !start_date || !end_date || !reason) {
        res.status(400).json({error: 'clinician_id, start_date, end_date, and reason are required.'});
        return;
      }
      const absId = `ABS-${Date.now().toString().slice(-5)}`;
      appDb.db
        .prepare(
          'INSERT INTO staff_absences (id, clinician_id, start_date, end_date, reason, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        )
        .run(absId, clinician_id, start_date, end_date, reason, req.user!.display_name, new Date().toISOString());

      const impactedSessions = appDb.db
        .prepare(
          'SELECT id FROM clinic_sessions WHERE clinician_id = ? AND session_date >= ? AND session_date <= ?',
        )
        .all(clinician_id, start_date, end_date) as {id: string}[];

      let totalAffected = 0;
      for (const s of impactedSessions) {
        const resImpact = flagSessionImpacted(appDb, req.user!, s.id, 'Clinician Absent', reason);
        totalAffected += resImpact.affectedCount;
      }
      res.status(201).json({id: absId, impacted_sessions: impactedSessions.length, affected_bookings: totalAffected});
    },
  );

  // Record room closure -> places impacted bookings in Affected Appointments Queue
  router.post(
    '/room-closures',
    requireRoles(appDb, STAFF_ROLES, 'Record room closure'),
    (req: AuthenticatedRequest, res) => {
      const {room_id, start_date, end_date, reason} = req.body as {
        room_id?: string;
        start_date?: string;
        end_date?: string;
        reason?: string;
      };
      if (!room_id || !start_date || !end_date || !reason) {
        res.status(400).json({error: 'room_id, start_date, end_date, and reason are required.'});
        return;
      }
      const rclId = `RCL-${Date.now().toString().slice(-5)}`;
      appDb.db
        .prepare(
          'INSERT INTO room_closures (id, room_id, start_date, end_date, reason, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        )
        .run(rclId, room_id, start_date, end_date, reason, req.user!.display_name, new Date().toISOString());

      const impactedSessions = appDb.db
        .prepare(
          'SELECT id FROM clinic_sessions WHERE room_id = ? AND session_date >= ? AND session_date <= ?',
        )
        .all(room_id, start_date, end_date) as {id: string}[];

      let totalAffected = 0;
      for (const s of impactedSessions) {
        const resImpact = flagSessionImpacted(appDb, req.user!, s.id, 'Room Unavailable', reason);
        totalAffected += resImpact.affectedCount;
      }
      res.status(201).json({id: rclId, impacted_sessions: impactedSessions.length, affected_bookings: totalAffected});
    },
  );

  router.get(
    '/affected-queue',
    requireRoles(appDb, STAFF_ROLES, 'View affected appointments review queue'),
    (_req, res) => {
      const items = appDb.db
        .prepare(
          `SELECT aq.*, a.local_date, a.local_start_time, a.specialty, a.state as appointment_state,
                  p.full_name as patient_name, p.preferred_contact_channel, p.accessibility_requirements,
                  c.full_name as clinician_name, s.name as site_name, r.name as room_name
           FROM affected_appointments_queue aq
           JOIN appointments a ON a.id = aq.appointment_id
           JOIN patients p ON p.id = aq.patient_id
           JOIN clinicians c ON c.id = a.clinician_id
           JOIN sites s ON s.id = a.site_id
           JOIN rooms r ON r.id = a.room_id
           ORDER BY aq.status ASC, aq.created_at DESC`,
        )
        .all();
      res.json({affected_queue: items});
    },
  );

  // Bulk reschedule preview for an impacted session
  router.get(
    '/affected-queue/bulk-preview',
    requireRoles(appDb, STAFF_ROLES, 'Preview bulk clinic reschedule'),
    (req, res) => {
      const sessionId = typeof req.query['session_id'] === 'string' ? req.query['session_id'] : '';
      const pending = appDb.db
        .prepare(
          `SELECT aq.id as queue_id, aq.appointment_id, aq.trigger_reason, a.patient_id, a.referral_id, a.specialty,
                  a.local_date, a.local_start_time, p.full_name as patient_name, r.duration_minutes, r.required_equipment
           FROM affected_appointments_queue aq
           JOIN appointments a ON a.id = aq.appointment_id
           JOIN patients p ON p.id = aq.patient_id
           JOIN referrals r ON r.id = a.referral_id
           WHERE aq.status = 'Pending Review' ${sessionId ? 'AND aq.session_id = ?' : ''}`,
        )
        .all(...(sessionId ? [sessionId] : [])) as {
        queue_id: string;
        appointment_id: string;
        trigger_reason: string;
        patient_id: string;
        referral_id: string;
        specialty: string;
        local_date: string;
        local_start_time: string;
        patient_name: string;
        duration_minutes: number;
        required_equipment: string | null;
      }[];

      const previews = pending.map((item) => {
        const candidateSlots = appDb.db
          .prepare(
            `SELECT sl.*, s.name as site_name, r.name as room_name, c.full_name as clinician_name
             FROM clinic_slots sl
             JOIN clinic_sessions cs ON cs.id = sl.session_id
             JOIN sites s ON s.id = sl.site_id
             JOIN rooms r ON r.id = sl.room_id
             JOIN clinicians c ON c.id = sl.clinician_id
             WHERE sl.specialty = ? AND sl.status = 'Available' AND cs.status = 'Active'
               AND sl.duration_minutes >= ?
               AND (? IS NULL OR sl.required_equipment = ?)
             ORDER BY sl.slot_date ASC, sl.start_time ASC
             LIMIT 3`,
          )
          .all(item.specialty, item.duration_minutes, item.required_equipment, item.required_equipment);
        return {...item, candidate_slots: candidateSlots};
      });

      res.json({previews});
    },
  );

  // Eligible Slots for a Referral (Patient / Proxy / Staff)
  router.get('/slots/eligible', (req: AuthenticatedRequest, res) => {
    const referralId = typeof req.query['referral_id'] === 'string' ? req.query['referral_id'] : '';
    const modality = typeof req.query['modality'] === 'string' ? req.query['modality'] : '';
    const siteId = typeof req.query['site_id'] === 'string' ? req.query['site_id'] : '';

    if (!referralId) {
      // Staff can also query all upcoming slots
      if (req.user!.role === 'PATIENT' || req.user!.role === 'PROXY') {
        res.status(400).json({error: 'referral_id is required to view eligible appointment slots.'});
        return;
      }
      const allSlots = appDb.db
        .prepare(
          `SELECT sl.*, s.name as site_name, r.name as room_name, c.full_name as clinician_name, cs.status as session_status
           FROM clinic_slots sl
           JOIN clinic_sessions cs ON cs.id = sl.session_id
           JOIN sites s ON s.id = sl.site_id
           JOIN rooms r ON r.id = sl.room_id
           JOIN clinicians c ON c.id = sl.clinician_id
           ORDER BY sl.slot_date ASC, sl.start_time ASC`,
        )
        .all();
      res.json({slots: allSlots});
      return;
    }

    const referral = appDb.db.prepare('SELECT * FROM referrals WHERE id = ?').get(referralId) as
      | {
          id: string;
          patient_id: string;
          specialty: string;
          review_status: string;
          clinical_priority: string | null;
          duration_minutes: number;
          required_equipment: string | null;
          booking_window_start: string | null;
          booking_window_end: string | null;
        }
      | undefined;

    if (!referral) {
      res.status(404).json({error: 'Referral not found.'});
      return;
    }

    const access = checkPatientAccess(appDb, req.user!, referral.patient_id, 'VIEW_ONLY');
    if (!access.allowed) {
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }

    if (referral.review_status !== 'Accepted') {
      res.json({
        slots: [],
        referral,
        message: 'Referral is awaiting authorised clinical review before slots can be offered.',
      });
      return;
    }

    // Release any expired holds first
    appDb.db
      .prepare(
        `UPDATE clinic_slots SET status = 'Available', held_by_patient_id = NULL, held_by_referral_id = NULL, hold_expires_at = NULL
         WHERE status = 'Held' AND hold_expires_at < ?`,
      )
      .run(new Date().toISOString());

    const isPatientRole = req.user!.role === 'PATIENT' || req.user!.role === 'PROXY';
    let sql = `SELECT sl.*, s.name as site_name, s.address as site_address, s.accessibility_notes,
                      r.name as room_name, c.full_name as clinician_name, cs.status as session_status
               FROM clinic_slots sl
               JOIN clinic_sessions cs ON cs.id = sl.session_id
               JOIN sites s ON s.id = sl.site_id
               JOIN rooms r ON r.id = sl.room_id
               JOIN clinicians c ON c.id = sl.clinician_id
               WHERE sl.specialty = ?
                 AND cs.status = 'Active'
                 AND sl.duration_minutes >= ?
                 AND (sl.status = 'Available' OR (sl.status = 'Held' AND sl.held_by_patient_id = ?))`;
    const params: (string | number)[] = [
      referral.specialty,
      referral.duration_minutes,
      referral.patient_id,
    ];

    if (referral.required_equipment) {
      sql += ' AND sl.required_equipment = ?';
      params.push(referral.required_equipment);
    }
    if (referral.booking_window_start) {
      sql += ' AND sl.slot_date >= ?';
      params.push(referral.booking_window_start);
    }
    if (referral.booking_window_end) {
      sql += ' AND sl.slot_date <= ?';
      params.push(referral.booking_window_end);
    }
    if (isPatientRole && referral.clinical_priority !== 'Urgent') {
      sql += ' AND sl.is_protected_urgent = 0';
    }
    if (modality) {
      sql += ' AND sl.modality = ?';
      params.push(modality);
    }
    if (siteId) {
      sql += ' AND sl.site_id = ?';
      params.push(siteId);
    }
    sql += ' ORDER BY sl.slot_date ASC, sl.start_time ASC';

    const slots = appDb.db.prepare(sql).all(...params);
    res.json({slots, referral});
  });

  // Short-lived Slot Hold (atomic concurrency check)
  router.post('/slots/:slotId/hold', (req: AuthenticatedRequest, res) => {
    try {
      const slotId = String(req.params['slotId']);
      const {patient_id, referral_id} = req.body as {patient_id?: string; referral_id?: string};
      const pid = patient_id ?? req.user!.patient_id;
      if (!pid || !referral_id) {
        res.status(400).json({error: 'patient_id and referral_id are required.'});
        return;
      }
      const access = checkPatientAccess(appDb, req.user!, pid, 'VIEW_AND_BOOK');
      if (!access.allowed) {
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const out = holdSlotTransactional(appDb, req.user!, slotId, pid, referral_id);
      res.json(out);
    } catch (err) {
      handleRouteError(res, err);
    }
  });

  // Check resource conflicts before proposing a reschedule/drag-and-drop move
  router.post(
    '/appointments/check-conflicts',
    requireRoles(appDb, STAFF_ROLES, 'Validate appointment resource conflicts'),
    (req, res) => {
      const {slot_id, patient_id, exclude_appointment_id, required_equipment} = req.body as {
        slot_id?: string;
        patient_id?: string;
        exclude_appointment_id?: string;
        required_equipment?: string | null;
      };
      if (!slot_id) {
        res.status(400).json({error: 'slot_id is required.'});
        return;
      }
      const slot = appDb.db.prepare('SELECT * FROM clinic_slots WHERE id = ?').get(slot_id) as
        | {
            id: string;
            slot_date: string;
            start_utc: string;
            end_utc: string;
            clinician_id: string;
            room_id: string;
            status: string;
          }
        | undefined;
      if (!slot) {
        res.status(404).json({error: 'Slot not found.'});
        return;
      }
      const conflict = checkResourceConflicts(appDb, {
        startUtc: slot.start_utc,
        endUtc: slot.end_utc,
        slotDate: slot.slot_date,
        clinicianId: slot.clinician_id,
        roomId: slot.room_id,
        patientId: patient_id,
        requiredEquipment: required_equipment,
        excludeAppointmentId: exclude_appointment_id,
      });
      if (slot.status !== 'Available') {
        conflict.hasConflict = true;
        conflict.reasons.unshift(`Slot status is currently '${slot.status}'.`);
      }
      res.json(conflict);
    },
  );

  // Confirm Appointment Booking
  router.post('/appointments/book', (req: AuthenticatedRequest, res) => {
    try {
      const {slot_id, patient_id, referral_id, booked_channel, preparation_instructions} = req.body as {
        slot_id?: string;
        patient_id?: string;
        referral_id?: string;
        booked_channel?: string;
        preparation_instructions?: string;
      };
      const pid = patient_id ?? req.user!.patient_id;
      if (!slot_id || !pid || !referral_id) {
        res.status(400).json({error: 'slot_id, patient_id, and referral_id are required.'});
        return;
      }
      const access = checkPatientAccess(appDb, req.user!, pid, 'VIEW_AND_BOOK');
      if (!access.allowed) {
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const channel =
        booked_channel ??
        (req.user!.role === 'PATIENT'
          ? 'Patient Self-Booking Portal'
          : req.user!.role === 'PROXY'
            ? 'Verified Proxy Portal'
            : 'Staff Telephone / Desk Booking');
      const result = confirmBookingTransactional(appDb, req.user!, {
        slotId: slot_id,
        patientId: pid,
        referralId: referral_id,
        bookedChannel: channel,
        preparationInstructions: preparation_instructions,
      });
      const appt = appDb.db.prepare('SELECT * FROM appointments WHERE id = ?').get(result.appointmentId);
      res.status(201).json({appointment: appt});
    } catch (err) {
      handleRouteError(res, err);
    }
  });

  // List Appointments (strictly isolated for Patient/Proxy)
  router.get('/appointments', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    const patientIdParam = typeof req.query['patient_id'] === 'string' ? req.query['patient_id'] : null;

    if (user.role === 'PATIENT' || user.role === 'PROXY') {
      const pid = patientIdParam ?? user.patient_id;
      if (!pid) {
        res.status(400).json({error: 'patient_id query parameter required.'});
        return;
      }
      const access = checkPatientAccess(appDb, user, pid, 'VIEW_ONLY');
      if (!access.allowed) {
        recordAudit(appDb, user, 'APPOINTMENT_ISOLATION_BLOCKED', 'Appointment', 'list', pid, {
          reason: access.reason,
        });
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const appts = appDb.db
        .prepare(
          `SELECT a.*, s.name as site_name, s.address as site_address, s.postcode as site_postcode, s.accessibility_notes,
                  r.name as room_name, c.full_name as clinician_name, p.full_name as patient_name
           FROM appointments a
           JOIN sites s ON s.id = a.site_id
           JOIN rooms r ON r.id = a.room_id
           JOIN clinicians c ON c.id = a.clinician_id
           JOIN patients p ON p.id = a.patient_id
           WHERE a.patient_id = ?
           ORDER BY a.local_date DESC, a.local_start_time DESC`,
        )
        .all(pid);
      res.json({appointments: appts});
      return;
    }

    const specialty = typeof req.query['specialty'] === 'string' ? req.query['specialty'] : '';
    const date = typeof req.query['date'] === 'string' ? req.query['date'] : '';
    let sql = `SELECT a.*, s.name as site_name, s.address as site_address, s.postcode as site_postcode,
                      r.name as room_name, c.full_name as clinician_name, p.full_name as patient_name,
                      p.nhs_number, p.preferred_contact_channel, p.accessibility_requirements,
                      ref.clinical_priority, ref.admin_due_date
               FROM appointments a
               JOIN sites s ON s.id = a.site_id
               JOIN rooms r ON r.id = a.room_id
               JOIN clinicians c ON c.id = a.clinician_id
               JOIN patients p ON p.id = a.patient_id
               JOIN referrals ref ON ref.id = a.referral_id
               WHERE 1=1`;
    const params: string[] = [];
    if (specialty) {
      sql += ' AND a.specialty = ?';
      params.push(specialty);
    }
    if (date) {
      sql += ' AND a.local_date = ?';
      params.push(date);
    }
    if (patientIdParam) {
      sql += ' AND a.patient_id = ?';
      params.push(patientIdParam);
    }
    sql += ' ORDER BY a.local_date ASC, a.local_start_time ASC';
    const appts = appDb.db.prepare(sql).all(...params);
    res.json({appointments: appts});
  });

  // Transition Appointment State (12 explicit lifecycle states)
  router.post('/appointments/:id/transition', (req: AuthenticatedRequest, res) => {
    try {
      const appointmentId = String(req.params['id']);
      const {target_state, reason} = req.body as {target_state?: AppointmentState; reason?: string};
      if (!target_state) {
        res.status(400).json({error: 'target_state is required.'});
        return;
      }
      const appt = appDb.db.prepare('SELECT patient_id FROM appointments WHERE id = ?').get(appointmentId) as
        | {patient_id: string}
        | undefined;
      if (!appt) {
        res.status(404).json({error: 'Appointment not found.'});
        return;
      }
      const access = checkPatientAccess(appDb, req.user!, appt.patient_id, 'VIEW_AND_BOOK');
      if (!access.allowed) {
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const out = transitionAppointmentState(appDb, req.user!, appointmentId, target_state, reason);
      const updated = appDb.db.prepare('SELECT * FROM appointments WHERE id = ?').get(appointmentId);
      res.json({...out, appointment: updated});
    } catch (err) {
      handleRouteError(res, err);
    }
  });

  // Reschedule Appointment (links old <-> new, preserves reason & waiting-list)
  router.post('/appointments/:id/reschedule', (req: AuthenticatedRequest, res) => {
    try {
      const oldApptId = String(req.params['id']);
      const {new_slot_id, reason} = req.body as {new_slot_id?: string; reason?: string};
      if (!new_slot_id || !reason) {
        res.status(400).json({error: 'new_slot_id and reason are required.'});
        return;
      }
      const oldAppt = appDb.db.prepare('SELECT * FROM appointments WHERE id = ?').get(oldApptId) as
        | {id: string; patient_id: string; referral_id: string; state: AppointmentState}
        | undefined;
      if (!oldAppt) {
        res.status(404).json({error: 'Original appointment not found.'});
        return;
      }
      if (!['Booked', 'Confirmed'].includes(oldAppt.state)) {
        res.status(400).json({error: `Cannot reschedule appointment in state '${oldAppt.state}'.`});
        return;
      }
      const access = checkPatientAccess(appDb, req.user!, oldAppt.patient_id, 'VIEW_AND_BOOK');
      if (!access.allowed) {
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const result = confirmBookingTransactional(appDb, req.user!, {
        slotId: new_slot_id,
        patientId: oldAppt.patient_id,
        referralId: oldAppt.referral_id,
        bookedChannel:
          req.user!.role === 'PATIENT' || req.user!.role === 'PROXY'
            ? 'Patient Reschedule'
            : 'Staff Reschedule',
        rescheduleFromAppointmentId: oldApptId,
        rescheduleReason: reason,
      });
      const newAppt = appDb.db.prepare('SELECT * FROM appointments WHERE id = ?').get(result.appointmentId);
      res.status(201).json({new_appointment: newAppt, old_appointment_id: oldApptId});
    } catch (err) {
      handleRouteError(res, err);
    }
  });

  // Record Clinical Outcome & Optional Follow-Up Referral (STRICTLY CLINICAL ROLES!)
  router.post(
    '/appointments/:id/outcome',
    requireRoles(appDb, CLINICAL_ROLES, 'Record clinical outcome and follow-up'),
    (req: AuthenticatedRequest, res) => {
      const appointmentId = String(req.params['id']);
      const {
        clinical_outcome,
        outcome_notes,
        mark_completed,
        followup_window_days,
        followup_duration_minutes,
        followup_priority,
      } = req.body as {
        clinical_outcome?: ClinicalOutcomeType;
        outcome_notes?: string;
        mark_completed?: boolean;
        followup_window_days?: number;
        followup_duration_minutes?: number;
        followup_priority?: ClinicalPriority;
      };

      if (!clinical_outcome || !outcome_notes) {
        res.status(400).json({error: 'clinical_outcome and outcome_notes are required.'});
        return;
      }

      const appt = appDb.db.prepare('SELECT * FROM appointments WHERE id = ?').get(appointmentId) as
        | {
            id: string;
            patient_id: string;
            referral_id: string;
            specialty: string;
            state: AppointmentState;
          }
        | undefined;
      if (!appt) {
        res.status(404).json({error: 'Appointment not found.'});
        return;
      }

      const nowIso = new Date().toISOString();
      let followupReferralId: string | null = null;

      appDb.runInTransaction(() => {
        // Transition to Completed if currently Arrived or In progress and mark_completed requested
        let newState = appt.state;
        if (mark_completed !== false && (appt.state === 'Arrived' || appt.state === 'In progress')) {
          newState = 'Completed';
        }

        if (clinical_outcome === 'Follow-up required') {
          followupReferralId = `REF-FU-${Date.now().toString().slice(-4)}`;
          const due = new Date(Date.now() + (followup_window_days ?? 14) * 86400_000)
            .toISOString()
            .slice(0, 10);
          const priority = followup_priority ?? 'Routine';
          const dur = followup_duration_minutes ?? 30;

          appDb.db
            .prepare(
              `INSERT INTO referrals (
                id, patient_id, source, external_ubrn, received_date, specialty, service_name,
                reason_summary, clinical_priority, administrative_status, review_status,
                reviewed_by_user_id, reviewed_by_name, reviewed_at, review_notes,
                appointment_type, duration_minutes, required_staff_role, required_room_type,
                required_equipment, requires_interpreter_booking, booking_window_start,
                booking_window_end, admin_due_date, created_at
              ) VALUES (?, ?, 'Clinician Follow-up Order', ?, ?, ?, ?, ?, ?, 'On Waiting List', 'Accepted', ?, ?, ?, ?, 'Follow-up', ?, 'Consultant', 'Outpatient Consulting', ?, 0, ?, ?, ?, ?)`,
            )
            .run(
              followupReferralId,
              appt.patient_id,
              `FU-${appointmentId}`,
              nowIso.slice(0, 10),
              appt.specialty,
              `${appt.specialty} Follow-Up Clinic`,
              `Clinician-ordered follow-up from ${appointmentId}: ${outcome_notes}`,
              priority,
              req.user!.id,
              req.user!.display_name,
              nowIso,
              outcome_notes,
              dur,
              appt.specialty === 'Cardiology' ? '12-Lead ECG Machine' : null,
              nowIso.slice(0, 10),
              due,
              due,
              nowIso,
            );

          appDb.db
            .prepare(
              `INSERT INTO waiting_list_entries (id, referral_id, patient_id, specialty, clinical_priority, original_joined_at, status, short_notice_opt_in, preferred_modality, notes)
               VALUES (?, ?, ?, ?, ?, ?, 'Active', 0, 'In-person', ?)`,
            )
            .run(
              `WL-FU-${Date.now().toString().slice(-4)}`,
              followupReferralId,
              appt.patient_id,
              appt.specialty,
              priority,
              nowIso,
              `Follow-up generated after ${appointmentId}`,
            );
        }

        appDb.db
          .prepare(
            `UPDATE appointments SET
              state = ?,
              clinical_outcome = ?,
              outcome_notes = ?,
              outcome_recorded_by = ?,
              outcome_recorded_at = ?,
              followup_referral_id = ?,
              updated_at = ?
             WHERE id = ?`,
          )
          .run(
            newState,
            clinical_outcome,
            outcome_notes,
            req.user!.display_name,
            nowIso,
            followupReferralId,
            nowIso,
            appointmentId,
          );

        appDb.db
          .prepare('UPDATE referrals SET administrative_status = ? WHERE id = ?')
          .run(
            clinical_outcome === 'Discharged from this service'
              ? 'Closed / Discharged'
              : 'Outcome Recorded',
            appt.referral_id,
          );

        recordAudit(appDb, req.user!, 'CLINICAL_OUTCOME_RECORDED', 'Appointment', appointmentId, appt.patient_id, {
          clinical_outcome,
          followup_referral_id: followupReferralId,
          new_state: newState,
        });
      });

      const updated = appDb.db.prepare('SELECT * FROM appointments WHERE id = ?').get(appointmentId);
      res.json({appointment: updated, followup_referral_id: followupReferralId});
    },
  );

  // Appointment Letter view
  router.get('/appointments/:id/letter', (req: AuthenticatedRequest, res) => {
    const appointmentId = String(req.params['id']);
    const row = appDb.db
      .prepare(
        `SELECT a.*, p.full_name as patient_name, p.nhs_number, p.address as patient_address,
                p.accessibility_requirements, p.interpreter_required, p.interpreter_language,
                s.name as site_name, s.address as site_address, s.postcode as site_postcode, s.phone as site_phone,
                s.accessibility_notes, r.name as room_name, c.full_name as clinician_name
         FROM appointments a
         JOIN patients p ON p.id = a.patient_id
         JOIN sites s ON s.id = a.site_id
         JOIN rooms r ON r.id = a.room_id
         JOIN clinicians c ON c.id = a.clinician_id
         WHERE a.id = ?`,
      )
      .get(appointmentId) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({error: 'Appointment not found.'});
      return;
    }
    const access = checkPatientAccess(appDb, req.user!, String(row['patient_id']), 'VIEW_ONLY');
    if (!access.allowed) {
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }
    res.json({letter: row});
  });

  // Notifications & Messages
  router.get('/notifications', (req: AuthenticatedRequest, res) => {
    const user = req.user!;
    const patientIdParam = typeof req.query['patient_id'] === 'string' ? req.query['patient_id'] : null;

    if (user.role === 'PATIENT' || user.role === 'PROXY') {
      const pid = patientIdParam ?? user.patient_id;
      if (!pid) {
        res.status(400).json({error: 'patient_id required'});
        return;
      }
      const access = checkPatientAccess(appDb, user, pid, 'MESSAGES_ONLY');
      if (!access.allowed) {
        res.status(403).json({error: access.reason ?? 'Forbidden'});
        return;
      }
      const rows = appDb.db
        .prepare('SELECT * FROM notifications WHERE patient_id = ? ORDER BY created_at DESC')
        .all(pid);
      res.json({notifications: rows});
      return;
    }

    const rows = appDb.db
      .prepare(
        `SELECT n.*, p.full_name as patient_name
         FROM notifications n JOIN patients p ON p.id = n.patient_id
         ORDER BY n.created_at DESC`,
      )
      .all();
    res.json({notifications: rows});
  });

  router.post('/notifications/:id/read', (req: AuthenticatedRequest, res) => {
    const notifId = String(req.params['id']);
    const notif = appDb.db.prepare('SELECT id, patient_id FROM notifications WHERE id = ?').get(notifId) as
      | {id: string; patient_id: string}
      | undefined;
    if (!notif) {
      res.status(404).json({error: 'Message not found.'});
      return;
    }
    const access = checkPatientAccess(appDb, req.user!, notif.patient_id, 'MESSAGES_ONLY');
    if (!access.allowed) {
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }
    appDb.db
      .prepare('UPDATE notifications SET read_at = ? WHERE id = ?')
      .run(new Date().toISOString(), notifId);
    res.json({ok: true});
  });

  // Staff can queue simulated reminders (including failure test)
  router.post(
    '/notifications/queue-reminder',
    requireRoles(appDb, STAFF_ROLES, 'Queue appointment reminder'),
    (req: AuthenticatedRequest, res) => {
      const {appointment_id, channel, simulate_bounce} = req.body as {
        appointment_id?: string;
        channel?: string;
        simulate_bounce?: boolean;
      };
      if (!appointment_id) {
        res.status(400).json({error: 'appointment_id is required.'});
        return;
      }
      const appt = appDb.db
        .prepare(
          `SELECT a.*, p.phone, p.email, p.full_name, p.preferred_contact_channel
           FROM appointments a JOIN patients p ON p.id = a.patient_id WHERE a.id = ?`,
        )
        .get(appointment_id) as
        | {
            id: string;
            patient_id: string;
            specialty: string;
            local_date: string;
            local_start_time: string;
            phone: string;
            email: string;
            full_name: string;
            preferred_contact_channel: string;
          }
        | undefined;
      if (!appt) {
        res.status(404).json({error: 'Appointment not found.'});
        return;
      }
      const notifId = `NTF-${Date.now().toString().slice(-6)}`;
      const nowIso = new Date().toISOString();
      const ch = channel ?? appt.preferred_contact_channel;
      const recipient = simulate_bounce
        ? `${appt.phone} (bounce-test)`
        : ch === 'Email'
          ? appt.email
          : appt.phone;

      appDb.db
        .prepare(
          `INSERT INTO notifications (id, patient_id, appointment_id, channel, message_type, recipient_address, subject, body_redacted, status, attempt_count, scheduled_for_utc, created_at)
           VALUES (?, ?, ?, ?, 'Reminder', ?, ?, ?, 'Queued', 1, ?, ?)`,
        )
        .run(
          notifId,
          appt.patient_id,
          appt.id,
          ch,
          recipient,
          `Reminder: ${appt.specialty} Outpatient Appointment`,
          `Reminder for ${appt.local_date} at ${appt.local_start_time}. Please contact the booking team if you need to rearrange. Portal messaging is not an emergency service.`,
          nowIso,
          nowIso,
        );
      const workerResult = runBackgroundWorkerPass(appDb, nowIso);
      const created = appDb.db.prepare('SELECT * FROM notifications WHERE id = ?').get(notifId);
      res.status(201).json({notification: created, worker_result: workerResult});
    },
  );

  // Patient help / staff-assisted booking request
  router.post('/help-request', (req: AuthenticatedRequest, res) => {
    const {patient_id, referral_id, topic, details} = req.body as {
      patient_id?: string;
      referral_id?: string;
      topic?: string;
      details?: string;
    };
    const pid = patient_id ?? req.user!.patient_id;
    if (!pid || !topic || !details) {
      res.status(400).json({error: 'patient_id, topic, and details are required.'});
      return;
    }
    const access = checkPatientAccess(appDb, req.user!, pid, 'VIEW_ONLY');
    if (!access.allowed) {
      res.status(403).json({error: access.reason ?? 'Forbidden'});
      return;
    }

    const patient = appDb.db.prepare('SELECT full_name, phone FROM patients WHERE id = ?').get(pid) as {
      full_name: string;
      phone: string;
    };
    const taskId = `TSK-${Date.now().toString().slice(-5)}`;
    const nowIso = new Date().toISOString();
    appDb.db
      .prepare(
        `INSERT INTO staff_tasks (id, task_type, priority, patient_id, referral_id, title, description, assigned_role, status, created_at)
         VALUES (?, 'Patient Booking Assistance', 'Medium', ?, ?, ?, ?, 'BOOKING_CLERK', 'Open', ?)`,
      )
      .run(
        taskId,
        pid,
        referral_id ?? null,
        `${topic}: ${patient.full_name}`,
        `Requested via portal (${patient.phone}): ${details}`,
        nowIso,
      );
    recordAudit(appDb, req.user!, 'PATIENT_HELP_REQUESTED', 'StaffTask', taskId, pid, {topic});
    res.status(201).json({task_id: taskId});
  });

  // Staff Tasks
  router.get('/tasks', requireRoles(appDb, STAFF_ROLES, 'View staff tasks'), (_req, res) => {
    const tasks = appDb.db
      .prepare(
        `SELECT t.*, p.full_name as patient_name, p.phone as patient_phone, p.preferred_contact_channel
         FROM staff_tasks t LEFT JOIN patients p ON p.id = t.patient_id
         ORDER BY CASE t.status WHEN 'Open' THEN 1 ELSE 2 END, t.created_at DESC`,
      )
      .all();
    res.json({tasks});
  });

  router.post(
    '/tasks/:id/resolve',
    requireRoles(appDb, STAFF_ROLES, 'Resolve staff task'),
    (req: AuthenticatedRequest, res) => {
      const taskId = String(req.params['id']);
      const {resolution_notes} = req.body as {resolution_notes?: string};
      if (!resolution_notes) {
        res.status(400).json({error: 'resolution_notes are required.'});
        return;
      }
      const task = appDb.db.prepare('SELECT id, patient_id FROM staff_tasks WHERE id = ?').get(taskId) as
        | {id: string; patient_id: string | null}
        | undefined;
      if (!task) {
        res.status(404).json({error: 'Task not found.'});
        return;
      }
      appDb.db
        .prepare(
          `UPDATE staff_tasks SET status = 'Resolved', resolution_notes = ?, resolved_by = ?, resolved_at = ? WHERE id = ?`,
        )
        .run(resolution_notes, req.user!.display_name, new Date().toISOString(), taskId);
      recordAudit(appDb, req.user!, 'STAFF_TASK_RESOLVED', 'StaffTask', taskId, task.patient_id, {
        resolution_notes,
      });
      res.json({ok: true});
    },
  );

  // Operational Reports (distinguishing Scheduled Capacity, Booked, and Completed Activity)
  router.get('/reports/operational', requireRoles(appDb, STAFF_ROLES, 'View operational reports'), (_req, res) => {
    const referralsAwaitingReview = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM referrals WHERE review_status = 'Pending Review'`).get() as {c: number}
    ).c;
    const unbookedPatients = (
      appDb.db
        .prepare(`SELECT COUNT(*) as c FROM waiting_list_entries WHERE status IN ('Active', 'Offer Pending')`)
        .get() as {c: number}
    ).c;
    const availableSlots = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM clinic_slots WHERE status = 'Available'`).get() as {c: number}
    ).c;
    const scheduledCapacity = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM clinic_slots WHERE status NOT LIKE 'Unavailable%'`).get() as {c: number}
    ).c;
    const bookedAppointments = (
      appDb.db
        .prepare(`SELECT COUNT(*) as c FROM appointments WHERE state IN ('Booked', 'Confirmed', 'Arrived', 'In progress')`)
        .get() as {c: number}
    ).c;
    const completedActivity = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM appointments WHERE state = 'Completed'`).get() as {c: number}
    ).c;
    const attendedCount = (
      appDb.db
        .prepare(`SELECT COUNT(*) as c FROM appointments WHERE state IN ('Arrived', 'In progress', 'Completed')`)
        .get() as {c: number}
    ).c;
    const dnaCount = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM appointments WHERE state = 'Did not attend'`).get() as {c: number}
    ).c;
    const patientCancellations = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM appointments WHERE state = 'Cancelled by patient'`).get() as {c: number}
    ).c;
    const providerCancellations = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM appointments WHERE state = 'Cancelled by provider'`).get() as {c: number}
    ).c;
    const reschedulesCount = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM appointments WHERE state = 'Rescheduled'`).get() as {c: number}
    ).c;
    const failedCommunications = (
      appDb.db.prepare(`SELECT COUNT(*) as c FROM notifications WHERE status = 'Failed'`).get() as {c: number}
    ).c;
    const outstandingOutcomes = (
      appDb.db
        .prepare(
          `SELECT COUNT(*) as c FROM appointments
           WHERE state IN ('Arrived', 'In progress', 'Completed')
             AND (clinical_outcome IS NULL OR clinical_outcome = 'Outcome awaiting completion')`,
        )
        .get() as {c: number}
    ).c;

    const leadTimeRows = appDb.db
      .prepare(
        `SELECT AVG(julianday(a.local_date) - julianday(r.received_date)) as avg_days
         FROM appointments a JOIN referrals r ON r.id = a.referral_id
         WHERE a.state != 'Rescheduled'`,
      )
      .get() as {avg_days: number | null};

    const bySpecialty = appDb.db
      .prepare(
        `SELECT cs.specialty,
                COUNT(sl.id) as scheduled_slots,
                SUM(CASE WHEN sl.status = 'Available' THEN 1 ELSE 0 END) as available_slots,
                SUM(CASE WHEN sl.status = 'Booked' THEN 1 ELSE 0 END) as booked_slots,
                (SELECT COUNT(*) FROM appointments a WHERE a.specialty = cs.specialty AND a.state = 'Completed') as completed_appointments
         FROM clinic_sessions cs
         LEFT JOIN clinic_slots sl ON sl.session_id = cs.id
         GROUP BY cs.specialty
         ORDER BY cs.specialty`,
      )
      .all();

    res.json({
      disclaimer:
        'Prototype operational counts for Pennine Outpatient Centre. These metrics distinguish scheduled capacity, booked appointments, and completed activity, and are NOT validated official NHS RTT waiting-time submissions.',
      metrics: {
        referrals_awaiting_review: referralsAwaitingReview,
        unbooked_patients: unbookedPatients,
        available_slots: availableSlots,
        scheduled_capacity: scheduledCapacity,
        booked_appointments: bookedAppointments,
        completed_activity: completedActivity,
        clinic_utilisation_pct:
          scheduledCapacity > 0 ? Math.round((bookedAppointments / scheduledCapacity) * 100) : 0,
        booking_lead_time_days: leadTimeRows.avg_days ? Math.round(leadTimeRows.avg_days * 10) / 10 : 0,
        attendance_recorded: attendedCount,
        did_not_attend: dnaCount,
        patient_cancellations: patientCancellations,
        provider_cancellations: providerCancellations,
        reschedules: reschedulesCount,
        failed_communications: failedCommunications,
        outstanding_outcomes: outstandingOutcomes,
      },
      by_specialty: bySpecialty,
    });
  });

  // Audit Logs, Integrations, Hazard Log, Backup/Restore
  router.get('/audit-logs', requireRoles(appDb, STAFF_ROLES, 'View audit logs'), (_req, res) => {
    const logs = appDb.db
      .prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 200')
      .all();
    res.json({audit_logs: logs});
  });

  router.get('/integrations', requireRoles(appDb, STAFF_ROLES, 'View external adapter boundaries'), (_req, res) => {
    const events = appDb.db
      .prepare('SELECT * FROM integration_events ORDER BY created_at DESC LIMIT 100')
      .all();
    res.json({adapters: ADAPTER_AUTHORITY_MATRIX, events});
  });

  router.post(
    '/integrations/ingest',
    requireRoles(appDb, STAFF_ROLES, 'Simulate external adapter event ingestion'),
    (req: AuthenticatedRequest, res) => {
      const {adapter_name, direction, idempotency_key, external_ref, payload_summary, simulate_conflict} =
        req.body as {
          adapter_name?: string;
          direction?: 'Inbound' | 'Outbound' | 'Outbound/Sync';
          idempotency_key?: string;
          external_ref?: string;
          payload_summary?: string;
          simulate_conflict?: boolean;
        };
      if (!adapter_name || !idempotency_key || !external_ref || !payload_summary) {
        res.status(400).json({error: 'adapter_name, idempotency_key, external_ref, and payload_summary are required.'});
        return;
      }
      const out = ingestExternalEventIdempotent(appDb, req.user!, {
        adapterName: adapter_name,
        direction: direction ?? 'Inbound',
        idempotencyKey: idempotency_key,
        externalRef: external_ref,
        payloadSummary: payload_summary,
        simulateConflict: !!simulate_conflict,
      });
      res.json(out);
    },
  );

  router.get('/hazard-log', requireRoles(appDb, STAFF_ROLES, 'View clinical safety hazard log'), (_req, res) => {
    res.json({hazards: PROTOTYPE_HAZARD_LOG});
  });

  router.post('/admin/worker-tick', requireRoles(appDb, STAFF_ROLES, 'Trigger background worker pass'), (_req, res) => {
    const result = runBackgroundWorkerPass(appDb);
    res.json(result);
  });

  router.get(
    '/admin/backup',
    requireRoles(appDb, ['CLINICAL_LEAD', 'ADMIN'], 'Export verified database backup snapshot'),
    (req: AuthenticatedRequest, res) => {
      const snapshot = {
        exported_at: new Date().toISOString(),
        schema_version: 1,
        counts: {
          patients: (appDb.db.prepare('SELECT COUNT(*) as c FROM patients').get() as {c: number}).c,
          referrals: (appDb.db.prepare('SELECT COUNT(*) as c FROM referrals').get() as {c: number}).c,
          waiting_list: (appDb.db.prepare('SELECT COUNT(*) as c FROM waiting_list_entries').get() as {c: number}).c,
          appointments: (appDb.db.prepare('SELECT COUNT(*) as c FROM appointments').get() as {c: number}).c,
          audit_logs: (appDb.db.prepare('SELECT COUNT(*) as c FROM audit_logs').get() as {c: number}).c,
        },
        data: {
          sites: appDb.db.prepare('SELECT * FROM sites').all(),
          patients: appDb.db.prepare('SELECT * FROM patients').all(),
          referrals: appDb.db.prepare('SELECT * FROM referrals').all(),
          waiting_list_entries: appDb.db.prepare('SELECT * FROM waiting_list_entries').all(),
          appointments: appDb.db.prepare('SELECT * FROM appointments').all(),
        },
      };
      recordAudit(appDb, req.user!, 'BACKUP_SNAPSHOT_EXPORTED', 'Database', 'tertiusmedico.db', null, {
        counts: snapshot.counts,
      });
      res.json(snapshot);
    },
  );

  router.post(
    '/admin/restore-verify',
    requireRoles(appDb, ['CLINICAL_LEAD', 'ADMIN'], 'Run integrity & restoration verification'),
    (req: AuthenticatedRequest, res) => {
      const integrity = appDb.db.prepare('PRAGMA integrity_check;').get() as {integrity_check: string};
      const fk = appDb.db.prepare('PRAGMA foreign_key_check;').all();
      recordAudit(appDb, req.user!, 'BACKUP_RESTORATION_TESTED', 'Database', 'tertiusmedico.db', null, {
        integrity_check: integrity.integrity_check,
        foreign_key_violations: fk.length,
      });
      res.json({
        integrity_check: integrity.integrity_check,
        foreign_key_violations: fk.length,
        verified_at: new Date().toISOString(),
      });
    },
  );

  return router;
}
