import type {HazardLogEntry} from './types.js';

export const PROTOTYPE_HAZARD_LOG: readonly HazardLogEntry[] = [
  {
    id: 'HAZ-01',
    category: 'Identity & Access',
    hazard: 'Wrong-patient booking or document disclosure via shared household device or NHS number guessing',
    clinical_consequence: 'Confidential outpatient specialty or GP letter exposed to wrong person; wrong patient booked into clinic.',
    initial_risk: 'High',
    mitigation_controls:
      'NHS number is never accepted as a credential. Server-side patient isolation and verified proxy scope checks (VIEW_AND_BOOK / VIEW_ONLY / MESSAGES_ONLY) enforced on every API route and document download with audit logging on denial.',
    residual_risk: 'Low',
    verification_status: 'Verified by automated RBAC & patient-isolation tests',
  },
  {
    id: 'HAZ-02',
    category: 'Referral Continuity',
    hazard: 'Lost referral or silent waiting-list clock reset when an appointment is cancelled or rescheduled',
    clinical_consequence: 'Patient drops off outpatient follow-up or loses original waiting-list position undetected.',
    initial_risk: 'High',
    mitigation_controls:
      'Waiting-list entries are stored separately from appointments and preserve original_joined_at immutably. Cancelling an appointment transitions waiting-list status back to Active without deleting the referral.',
    residual_risk: 'Low',
    verification_status: 'Verified by automated waiting-list preservation test',
  },
  {
    id: 'HAZ-03',
    category: 'Clinical Guidance & Instructions',
    hazard: 'Incorrect preparation instructions, missing interpreter, or incompatible slot length',
    clinical_consequence: 'Patient attends fasting/unprepared, without required BSL/Urdu interpreter, or in a slot lacking ECG/Slit Lamp equipment, causing wasted attendance and delayed care.',
    initial_risk: 'High',
    mitigation_controls:
      'Slot eligibility filters strictly by reviewed referral specialty, minimum duration, and required equipment. Interpreter and accessibility requirements flow onto reception queue and appointment letters.',
    residual_risk: 'Low',
    verification_status: 'Verified in slot eligibility engine and seed fixtures',
  },
  {
    id: 'HAZ-04',
    category: 'Resource & Concurrency',
    hazard: 'Double-booking of clinician, room, equipment, or patient across simultaneous self-booking',
    clinical_consequence: 'Two patients arrive for the same consultant/room simultaneously; overbooking causes clinic overrun and unsafe delays.',
    initial_risk: 'High',
    mitigation_controls:
      'SQLite BEGIN IMMEDIATE transactions enforce atomic slot holds with 10-minute TTL and 409 Conflict responses. Backend resource conflict engine blocks overlapping clinician, room, equipment, and patient bookings; routine overbooking disabled.',
    residual_risk: 'Low',
    verification_status: 'Verified by concurrent hold/booking & conflict tests',
  },
  {
    id: 'HAZ-05',
    category: 'Communications',
    hazard: 'Missed communication or silent appointment cancellation after failed/unread reminder',
    clinical_consequence: 'Patient unaware of appointment date/location or clinic closure; unread reminder wrongly cancels vital care.',
    initial_risk: 'High',
    mitigation_controls:
      'Unread reminders never cancel bookings. Failed SMS/email deliveries automatically create high-priority Staff Contact Tasks and appear in Failed Communications operational reports.',
    residual_risk: 'Low',
    verification_status: 'Verified by worker failure routing test & seed fixture',
  },
  {
    id: 'HAZ-06',
    category: 'Interoperability',
    hazard: 'Failed synchronisation or duplicate inbound referral/PAS event causing conflicting demographics',
    clinical_consequence: 'Duplicate referral entries or corrupted patient contact details across e-RS, PAS, and scheduling store.',
    initial_risk: 'Medium',
    mitigation_controls:
      'Typed adapter boundaries enforce unique idempotency keys, field-level system-of-record ownership matrix, and quarantine conflicting demographic updates into a staff reconciliation queue.',
    residual_risk: 'Low',
    verification_status: 'Verified by idempotent event ingestion',
  },
  {
    id: 'HAZ-07',
    category: 'Clinical Governance',
    hazard: 'Administrative staff altering clinical priority or recording clinical outcomes',
    clinical_consequence: 'Urgent clinical assessment inappropriately downgraded or non-clinician discharges patient without clinical review.',
    initial_risk: 'High',
    mitigation_controls:
      'Clinical priority assignment, booking clinical requirements, and clinical outcome recording are strictly restricted to CLINICIAN, TRIAGE_NURSE, and CLINICAL_LEAD roles on the server.',
    residual_risk: 'Low',
    verification_status: 'Verified by automated clinical-role restriction tests',
  },
];
