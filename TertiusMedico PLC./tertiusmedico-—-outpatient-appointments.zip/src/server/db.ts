import {createRequire} from 'node:module';
import type {DatabaseSync as DatabaseSyncType} from 'node:sqlite';
import {mkdirSync, writeFileSync, existsSync} from 'node:fs';
import {join, resolve} from 'node:path';
import {scryptSync, randomBytes} from 'node:crypto';

const require = createRequire(import.meta.url);
const {DatabaseSync} = require('node:sqlite') as {DatabaseSync: typeof DatabaseSyncType};

const DEFAULT_DATA_DIR = resolve(process.cwd(), 'data');

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const derived = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export class AppDatabase {
  public readonly db: DatabaseSyncType;
  public readonly storageDir: string;

  constructor(dbPath?: string, storageDir?: string) {
    const resolvedDataDir = DEFAULT_DATA_DIR;
    if (!dbPath) {
      mkdirSync(resolvedDataDir, {recursive: true});
    }
    const finalDbPath = dbPath ?? join(resolvedDataDir, 'tertiusmedico.db');
    this.storageDir = storageDir ?? join(resolvedDataDir, 'storage');
    mkdirSync(this.storageDir, {recursive: true});

    this.db = new DatabaseSync(finalDbPath);
    this.db.exec('PRAGMA journal_mode = WAL;');
    this.db.exec('PRAGMA foreign_keys = ON;');
    this.db.exec('PRAGMA busy_timeout = 5000;');
    this.migrate();
  }

  public runInTransaction<T>(fn: () => T): T {
    this.db.exec('BEGIN IMMEDIATE;');
    try {
      const result = fn();
      this.db.exec('COMMIT;');
      return result;
    } catch (err) {
      try {
        this.db.exec('ROLLBACK;');
      } catch {
        // ignore rollback error
      }
      throw err;
    }
  }

  private migrate(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        applied_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sites (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT NOT NULL,
        address TEXT NOT NULL,
        postcode TEXT NOT NULL,
        phone TEXT NOT NULL,
        accessibility_notes TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS rooms (
        id TEXT PRIMARY KEY,
        site_id TEXT NOT NULL REFERENCES sites(id),
        name TEXT NOT NULL,
        room_type TEXT NOT NULL,
        step_free INTEGER NOT NULL DEFAULT 1,
        hearing_loop INTEGER NOT NULL DEFAULT 1,
        equipment_list TEXT NOT NULL DEFAULT '[]'
      );

      CREATE TABLE IF NOT EXISTS clinicians (
        id TEXT PRIMARY KEY,
        full_name TEXT NOT NULL,
        gmc_or_nmc TEXT NOT NULL,
        role_title TEXT NOT NULL,
        specialty TEXT NOT NULL,
        primary_site_id TEXT NOT NULL REFERENCES sites(id),
        staff_directory_ref TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        display_name TEXT NOT NULL,
        role TEXT NOT NULL,
        patient_id TEXT,
        clinician_id TEXT,
        specialty TEXT,
        site_id TEXT,
        identity_provider TEXT NOT NULL DEFAULT 'Prototype Synthetic Directory',
        active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS patients (
        id TEXT PRIMARY KEY,
        nhs_number TEXT,
        nhs_verification_status TEXT NOT NULL,
        full_name TEXT NOT NULL,
        date_of_birth TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT NOT NULL,
        address TEXT NOT NULL,
        preferred_contact_channel TEXT NOT NULL DEFAULT 'SMS',
        marketing_consent INTEGER NOT NULL DEFAULT 0,
        appointment_comms_enabled INTEGER NOT NULL DEFAULT 1,
        accessibility_requirements TEXT NOT NULL DEFAULT 'None',
        interpreter_required INTEGER NOT NULL DEFAULT 0,
        interpreter_language TEXT,
        preferred_modality TEXT NOT NULL DEFAULT 'In-person',
        preferred_site_id TEXT,
        pas_ref TEXT NOT NULL,
        epr_ref TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS proxy_relationships (
        id TEXT PRIMARY KEY,
        proxy_user_id TEXT NOT NULL REFERENCES users(id),
        proxy_name TEXT NOT NULL,
        patient_id TEXT NOT NULL REFERENCES patients(id),
        relationship TEXT NOT NULL,
        scope TEXT NOT NULL,
        verification_status TEXT NOT NULL,
        verified_by TEXT,
        verified_at TEXT,
        expires_at TEXT
      );

      CREATE TABLE IF NOT EXISTS referrals (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(id),
        source TEXT NOT NULL,
        external_ubrn TEXT,
        received_date TEXT NOT NULL,
        specialty TEXT NOT NULL,
        service_name TEXT NOT NULL,
        reason_summary TEXT NOT NULL,
        clinical_priority TEXT,
        administrative_status TEXT NOT NULL,
        review_status TEXT NOT NULL,
        reviewed_by_user_id TEXT,
        reviewed_by_name TEXT,
        reviewed_at TEXT,
        review_notes TEXT,
        appointment_type TEXT NOT NULL,
        duration_minutes INTEGER NOT NULL DEFAULT 20,
        required_staff_role TEXT NOT NULL,
        required_room_type TEXT NOT NULL,
        required_equipment TEXT,
        requires_interpreter_booking INTEGER NOT NULL DEFAULT 0,
        booking_window_start TEXT,
        booking_window_end TEXT,
        admin_due_date TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS referral_history (
        id TEXT PRIMARY KEY,
        referral_id TEXT NOT NULL REFERENCES referrals(id),
        actor_user_id TEXT NOT NULL,
        actor_name TEXT NOT NULL,
        actor_role TEXT NOT NULL,
        action TEXT NOT NULL,
        previous_priority TEXT,
        new_priority TEXT,
        notes TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS documents (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(id),
        referral_id TEXT REFERENCES referrals(id),
        title TEXT NOT NULL,
        doc_type TEXT NOT NULL,
        storage_key TEXT NOT NULL,
        mime_type TEXT NOT NULL,
        uploaded_by TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS waiting_list_entries (
        id TEXT PRIMARY KEY,
        referral_id TEXT NOT NULL UNIQUE REFERENCES referrals(id),
        patient_id TEXT NOT NULL REFERENCES patients(id),
        specialty TEXT NOT NULL,
        clinical_priority TEXT NOT NULL,
        original_joined_at TEXT NOT NULL,
        status TEXT NOT NULL,
        short_notice_opt_in INTEGER NOT NULL DEFAULT 0,
        preferred_site_id TEXT,
        preferred_modality TEXT NOT NULL DEFAULT 'In-person',
        notes TEXT
      );

      CREATE TABLE IF NOT EXISTS clinic_templates (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        specialty TEXT NOT NULL,
        site_id TEXT NOT NULL REFERENCES sites(id),
        room_id TEXT NOT NULL REFERENCES rooms(id),
        clinician_id TEXT NOT NULL REFERENCES clinicians(id),
        supporting_staff_role TEXT,
        modality TEXT NOT NULL,
        appointment_types_json TEXT NOT NULL,
        slot_length_minutes INTEGER NOT NULL,
        buffer_minutes INTEGER NOT NULL DEFAULT 5,
        break_start_time TEXT,
        break_end_time TEXT,
        required_equipment TEXT,
        protected_urgent_slots INTEGER NOT NULL DEFAULT 1,
        current_version INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS clinic_template_versions (
        id TEXT PRIMARY KEY,
        template_id TEXT NOT NULL REFERENCES clinic_templates(id),
        version_number INTEGER NOT NULL,
        effective_from TEXT NOT NULL,
        snapshot_json TEXT NOT NULL,
        changed_by TEXT NOT NULL,
        change_reason TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS clinic_sessions (
        id TEXT PRIMARY KEY,
        template_id TEXT NOT NULL REFERENCES clinic_templates(id),
        template_version INTEGER NOT NULL,
        specialty TEXT NOT NULL,
        site_id TEXT NOT NULL REFERENCES sites(id),
        room_id TEXT NOT NULL REFERENCES rooms(id),
        clinician_id TEXT NOT NULL REFERENCES clinicians(id),
        supporting_staff TEXT,
        session_date TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        modality TEXT NOT NULL,
        required_equipment TEXT,
        status TEXT NOT NULL DEFAULT 'Active',
        timezone TEXT NOT NULL DEFAULT 'Europe/London',
        notes TEXT
      );

      CREATE TABLE IF NOT EXISTS staff_absences (
        id TEXT PRIMARY KEY,
        clinician_id TEXT NOT NULL REFERENCES clinicians(id),
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        reason TEXT NOT NULL,
        recorded_by TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS room_closures (
        id TEXT PRIMARY KEY,
        room_id TEXT NOT NULL REFERENCES rooms(id),
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        reason TEXT NOT NULL,
        recorded_by TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS clinic_slots (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES clinic_sessions(id),
        specialty TEXT NOT NULL,
        site_id TEXT NOT NULL REFERENCES sites(id),
        room_id TEXT NOT NULL REFERENCES rooms(id),
        clinician_id TEXT NOT NULL REFERENCES clinicians(id),
        slot_date TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        start_utc TEXT NOT NULL,
        end_utc TEXT NOT NULL,
        duration_minutes INTEGER NOT NULL,
        modality TEXT NOT NULL,
        appointment_type TEXT NOT NULL,
        required_equipment TEXT,
        is_protected_urgent INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'Available',
        held_by_patient_id TEXT,
        held_by_referral_id TEXT,
        hold_expires_at TEXT
      );

      CREATE TABLE IF NOT EXISTS appointments (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(id),
        referral_id TEXT NOT NULL REFERENCES referrals(id),
        waiting_list_id TEXT REFERENCES waiting_list_entries(id),
        slot_id TEXT NOT NULL REFERENCES clinic_slots(id),
        session_id TEXT NOT NULL REFERENCES clinic_sessions(id),
        site_id TEXT NOT NULL REFERENCES sites(id),
        room_id TEXT NOT NULL REFERENCES rooms(id),
        clinician_id TEXT NOT NULL REFERENCES clinicians(id),
        specialty TEXT NOT NULL,
        appointment_type TEXT NOT NULL,
        modality TEXT NOT NULL,
        scheduled_start_utc TEXT NOT NULL,
        scheduled_end_utc TEXT NOT NULL,
        local_date TEXT NOT NULL,
        local_start_time TEXT NOT NULL,
        local_end_time TEXT NOT NULL,
        state TEXT NOT NULL,
        interpreter_language TEXT,
        assistance_notes TEXT,
        preparation_instructions TEXT NOT NULL,
        arrival_time_utc TEXT,
        clinical_outcome TEXT,
        outcome_notes TEXT,
        outcome_recorded_by TEXT,
        outcome_recorded_at TEXT,
        followup_referral_id TEXT,
        rescheduled_from_id TEXT,
        rescheduled_to_id TEXT,
        reschedule_reason TEXT,
        overbooked INTEGER NOT NULL DEFAULT 0,
        overbook_justification TEXT,
        booked_channel TEXT NOT NULL DEFAULT 'Patient Portal',
        booked_by_user_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS affected_appointments_queue (
        id TEXT PRIMARY KEY,
        appointment_id TEXT NOT NULL REFERENCES appointments(id),
        session_id TEXT NOT NULL REFERENCES clinic_sessions(id),
        patient_id TEXT NOT NULL REFERENCES patients(id),
        trigger_type TEXT NOT NULL,
        trigger_reason TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending Review',
        resolution_notes TEXT,
        resolved_by TEXT,
        resolved_at TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS notifications (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(id),
        appointment_id TEXT REFERENCES appointments(id),
        channel TEXT NOT NULL,
        message_type TEXT NOT NULL,
        recipient_address TEXT NOT NULL,
        subject TEXT NOT NULL,
        body_redacted TEXT NOT NULL,
        status TEXT NOT NULL,
        failure_reason TEXT,
        attempt_count INTEGER NOT NULL DEFAULT 1,
        read_at TEXT,
        scheduled_for_utc TEXT NOT NULL,
        sent_at_utc TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS staff_tasks (
        id TEXT PRIMARY KEY,
        task_type TEXT NOT NULL,
        priority TEXT NOT NULL,
        patient_id TEXT REFERENCES patients(id),
        referral_id TEXT REFERENCES referrals(id),
        appointment_id TEXT REFERENCES appointments(id),
        notification_id TEXT REFERENCES notifications(id),
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        assigned_role TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Open',
        resolution_notes TEXT,
        resolved_by TEXT,
        resolved_at TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS integration_events (
        id TEXT PRIMARY KEY,
        adapter_name TEXT NOT NULL,
        direction TEXT NOT NULL,
        idempotency_key TEXT NOT NULL UNIQUE,
        external_ref TEXT NOT NULL,
        payload_summary TEXT NOT NULL,
        status TEXT NOT NULL,
        retry_count INTEGER NOT NULL DEFAULT 0,
        conflict_detail TEXT,
        created_at TEXT NOT NULL,
        processed_at TEXT
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        actor_user_id TEXT NOT NULL,
        actor_name TEXT NOT NULL,
        actor_role TEXT NOT NULL,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        patient_id TEXT,
        detail_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    `);

    const mig = this.db
      .prepare('SELECT version FROM schema_migrations WHERE version = 1')
      .get();
    if (!mig) {
      this.db
        .prepare(
          'INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)',
        )
        .run(1, '001_initial_outpatient_schema', new Date().toISOString());
    }
  }

  public seedPennineDemoIfEmpty(): void {
    const existing = this.db
      .prepare('SELECT COUNT(*) as cnt FROM sites')
      .get() as {cnt: number};
    if (existing.cnt > 0) {
      return;
    }

    const now = new Date();
    const dayStr = (offsetDays: number): string => {
      const d = new Date(now.getTime() + offsetDays * 86400_000);
      return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Europe/London',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(d);
    };

    const today = dayStr(0);
    const tomorrow = dayStr(1);
    const day2 = dayStr(2);
    const day3 = dayStr(3);
    const day5 = dayStr(5);
    const day7 = dayStr(7);
    const yesterday = dayStr(-1);
    const twoWeeksAgo = dayStr(-14);
    const threeWeeksAgo = dayStr(-21);

    this.runInTransaction(() => {
      // 1. Two Fictional Sites
      const insertSite = this.db.prepare(
        'INSERT INTO sites (id, name, code, address, postcode, phone, accessibility_notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
      );
      insertSite.run(
        'SITE-PGH',
        'Pennine General Hospital — Outpatients Wing',
        'PGH',
        '42 Calder Way, Burnley, Lancashire',
        'BB10 2PQ',
        '01282 550100',
        'Step-free main entrance, Blue Badge parking Bays A-F, hearing loop at all reception desks, quiet waiting zone available.',
      );
      insertSite.run(
        'SITE-CVA',
        'Calder Valley Outpatient Annex',
        'CVA',
        '18 Todmorden Road, Hebden Bridge, West Yorkshire',
        'HX7 8ER',
        '01422 550240',
        'Ground-floor consulting rooms, bus stop 60m from entrance, assistance dog relief area.',
      );

      // 2. Rooms
      const insertRoom = this.db.prepare(
        'INSERT INTO rooms (id, site_id, name, room_type, step_free, hearing_loop, equipment_list) VALUES (?, ?, ?, ?, ?, ?, ?)',
      );
      insertRoom.run(
        'ROOM-PGH-C1',
        'SITE-PGH',
        'Cardiology Suite 1',
        'Diagnostic Consulting',
        1,
        1,
        JSON.stringify(['12-Lead ECG Machine', 'Blood Pressure Monitor']),
      );
      insertRoom.run(
        'ROOM-PGH-D1',
        'SITE-PGH',
        'Dermatology Room D1',
        'Clinical Examination',
        1,
        1,
        JSON.stringify(['Digital Dermoscope', 'Minor Procedures Light']),
      );
      insertRoom.run(
        'ROOM-PGH-O1',
        'SITE-PGH',
        'Orthopaedics Clinic Room 3',
        'Fracture & Mobility Suite',
        1,
        1,
        JSON.stringify(['X-Ray Viewing Workstation', 'Goniometer Kit']),
      );
      insertRoom.run(
        'ROOM-PGH-OP2',
        'SITE-PGH',
        'Ophthalmology Suite 2',
        'Ophthalmic Examination',
        1,
        1,
        JSON.stringify(['Slit Lamp Biomicroscope', 'OCT Scanner']),
      );
      insertRoom.run(
        'ROOM-CVA-C2',
        'SITE-CVA',
        'Calder Clinic Room 2',
        'General Outpatient',
        1,
        1,
        JSON.stringify(['12-Lead ECG Machine', 'Video Consultation Terminal']),
      );

      // 3. Synthetic Clinicians
      const insertClinician = this.db.prepare(
        'INSERT INTO clinicians (id, full_name, gmc_or_nmc, role_title, specialty, primary_site_id, staff_directory_ref) VALUES (?, ?, ?, ?, ?, ?, ?)',
      );
      insertClinician.run(
        'CLIN-NAIR',
        'Dr. Priya Nair',
        'GMC-9041128',
        'Consultant Cardiologist',
        'Cardiology',
        'SITE-PGH',
        'DIR-PEN-011',
      );
      insertClinician.run(
        'CLIN-OWEN',
        'Dr. Gareth Owen',
        'GMC-9053314',
        'Consultant Dermatologist',
        'Dermatology',
        'SITE-PGH',
        'DIR-PEN-024',
      );
      insertClinician.run(
        'CLIN-FINCH',
        'Mr. Alistair Finch',
        'GMC-9028810',
        'Consultant Orthopaedic Surgeon',
        'Orthopaedics',
        'SITE-PGH',
        'DIR-PEN-037',
      );
      insertClinician.run(
        'CLIN-REID',
        'Ms. Hannah Reid',
        'GMC-9064419',
        'Consultant Ophthalmologist',
        'Ophthalmology',
        'SITE-PGH',
        'DIR-PEN-042',
      );

      // 4. Synthetic Users (Patients, Proxy, Staff)
      const demoHash = hashPassword('PennineDemo2026!');
      const insertUser = this.db.prepare(
        'INSERT INTO users (id, username, password_hash, display_name, role, patient_id, clinician_id, specialty, site_id, identity_provider) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      );
      insertUser.run(
        'USR-PAT-ARTHUR',
        'arthur.pendelton',
        demoHash,
        'Arthur Pendelton',
        'PATIENT',
        'PAT-1001',
        null,
        null,
        null,
        'NHS Login Adapter (Synthetic)',
      );
      insertUser.run(
        'USR-PAT-NADIA',
        'nadia.begum',
        demoHash,
        'Nadia Begum',
        'PATIENT',
        'PAT-1002',
        null,
        null,
        null,
        'NHS Login Adapter (Synthetic)',
      );
      insertUser.run(
        'USR-PROXY-MARGARET',
        'margaret.pendelton',
        demoHash,
        'Margaret Pendelton (Verified Proxy)',
        'PROXY',
        null,
        null,
        null,
        null,
        'NHS Login Adapter (Synthetic)',
      );
      insertUser.run(
        'USR-CLIN-NAIR',
        'priya.nair',
        demoHash,
        'Dr. Priya Nair (Cardiology)',
        'CLINICIAN',
        null,
        'CLIN-NAIR',
        'Cardiology',
        'SITE-PGH',
        'NHS CIS2 Adapter (Synthetic)',
      );
      insertUser.run(
        'USR-NURSE-SHAW',
        'eleanor.shaw',
        demoHash,
        'Nurse Eleanor Shaw (Triage)',
        'TRIAGE_NURSE',
        null,
        null,
        'Cardiology',
        'SITE-PGH',
        'NHS CIS2 Adapter (Synthetic)',
      );
      insertUser.run(
        'USR-CLERK-JENKINS',
        'clara.jenkins',
        demoHash,
        'Clara Jenkins (Booking Clerk)',
        'BOOKING_CLERK',
        null,
        null,
        null,
        'SITE-PGH',
        'NHS CIS2 Adapter (Synthetic)',
      );
      insertUser.run(
        'USR-RECEP-PATEL',
        'david.patel',
        demoHash,
        'David Patel (Reception)',
        'RECEPTIONIST',
        null,
        null,
        null,
        'SITE-PGH',
        'NHS CIS2 Adapter (Synthetic)',
      );
      insertUser.run(
        'USR-LEAD-THORNE',
        'marcus.thorne',
        demoHash,
        'Dr. Marcus Thorne (Clinical Lead)',
        'CLINICAL_LEAD',
        null,
        'CLIN-NAIR',
        'All Specialties',
        'SITE-PGH',
        'NHS CIS2 Adapter (Synthetic)',
      );

      // 5. Synthetic Patients
      const insertPatient = this.db.prepare(
        `INSERT INTO patients (
          id, nhs_number, nhs_verification_status, full_name, date_of_birth,
          phone, email, address, preferred_contact_channel, marketing_consent,
          appointment_comms_enabled, accessibility_requirements, interpreter_required,
          interpreter_language, preferred_modality, preferred_site_id, pas_ref, epr_ref, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );

      insertPatient.run(
        'PAT-1001',
        '943 476 5919',
        'Verified via PDS Adapter',
        'Arthur Pendelton',
        '1954-04-12',
        '07700 900114',
        'arthur.pendelton@synthetic.pennine.nhs.example',
        '14 Stonebridge Terrace, Burnley, BB11 3AB',
        'SMS',
        0,
        1,
        'Hearing loop required; step-free ground-floor access',
        0,
        null,
        'In-person',
        'SITE-PGH',
        'PAS-991001',
        'EPR-441001',
        threeWeeksAgo + 'T09:00:00Z',
      );

      insertPatient.run(
        'PAT-1002',
        '943 512 8834',
        'Verified via PDS Adapter',
        'Nadia Begum',
        '1983-09-27',
        '07700 900245',
        'nadia.begum@synthetic.pennine.nhs.example',
        '78 Whalley Road, Accrington, BB5 1DE',
        'Portal',
        0,
        1,
        'Female clinician preferred where possible',
        1,
        'Urdu',
        'In-person',
        'SITE-PGH',
        'PAS-991002',
        'EPR-441002',
        twoWeeksAgo + 'T11:30:00Z',
      );

      insertPatient.run(
        'PAT-1003',
        '943 608 1122',
        'Unverified - Provisional Trace',
        'Samuel Whitaker',
        '1968-11-05',
        '07700 900399',
        'samuel.whitaker@synthetic.pennine.nhs.example',
        '3 Moorland View, Todmorden, OL14 7AA',
        'SMS',
        0,
        1,
        'Mobility scooter parking bay near entrance',
        0,
        null,
        'In-person',
        'SITE-PGH',
        'PAS-991003',
        'EPR-441003',
        twoWeeksAgo + 'T14:15:00Z',
      );

      insertPatient.run(
        'PAT-1004',
        '943 729 4401',
        'Verified via PDS Adapter',
        'Eleanor Vance',
        '1949-02-19',
        '07700 900488',
        'eleanor.vance@synthetic.pennine.nhs.example',
        '22 Riverside Croft, Hebden Bridge, HX7 6BB',
        'Letter',
        0,
        1,
        'Large print (18pt) correspondence',
        0,
        null,
        'In-person',
        'SITE-PGH',
        'PAS-991004',
        'EPR-441004',
        twoWeeksAgo + 'T16:00:00Z',
      );

      insertPatient.run(
        'PAT-1005',
        '943 815 3098',
        'Verified via PDS Adapter',
        'George Hargreaves',
        '1941-07-03',
        '01282 550912',
        'no-email@telephone-only.pennine.nhs.example',
        '9 Oakwood Close, Nelson, BB9 8XY',
        'Telephone',
        0,
        1,
        'No smartphone — telephone contact & posted letters only',
        1,
        'British Sign Language',
        'In-person',
        'SITE-CVA',
        'PAS-991005',
        'EPR-441005',
        threeWeeksAgo + 'T10:20:00Z',
      );

      // 6. Verified Proxy Relationships
      this.db
        .prepare(
          `INSERT INTO proxy_relationships (id, proxy_user_id, proxy_name, patient_id, relationship, scope, verification_status, verified_by, verified_at, expires_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .run(
          'PRX-001',
          'USR-PROXY-MARGARET',
          'Margaret Pendelton',
          'PAT-1001',
          'Spouse / Registered Carer',
          'VIEW_AND_BOOK',
          'Verified',
          'Clara Jenkins (Booking Clerk)',
          threeWeeksAgo + 'T12:00:00Z',
          dayStr(365) + 'T23:59:59Z',
        );

      // 7. Referrals (covering full pipeline: awaiting review, waiting list, booked, arrived/today, completed)
      const insertReferral = this.db.prepare(
        `INSERT INTO referrals (
          id, patient_id, source, external_ubrn, received_date, specialty, service_name,
          reason_summary, clinical_priority, administrative_status, review_status,
          reviewed_by_user_id, reviewed_by_name, reviewed_at, review_notes,
          appointment_type, duration_minutes, required_staff_role, required_room_type,
          required_equipment, requires_interpreter_booking, booking_window_start,
          booking_window_end, admin_due_date, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );

      // REF-2026-001: Arthur Pendelton — New GP Cardiology referral awaiting clinical review (Step 1-2 of demo!)
      insertReferral.run(
        'REF-2026-001',
        'PAT-1001',
        'GP e-RS',
        'UBRN-4821-9011',
        yesterday,
        'Cardiology',
        'General Cardiology & Arrhythmia Clinic',
        'Exertional palpitations and mild peripheral oedema; GP requests cardiology assessment and ECG.',
        null, // Not yet assigned by clinician!
        'Awaiting Clinical Review',
        'Pending Review',
        null,
        null,
        null,
        null,
        'New Outpatient',
        30,
        'Consultant Cardiologist',
        'Diagnostic Consulting',
        '12-Lead ECG Machine',
        0,
        today,
        dayStr(28),
        dayStr(21),
        yesterday + 'T08:40:00Z',
      );

      // REF-2026-002: Nadia Begum — Dermatology (Urdu Interpreter required, 30 min, clinician reviewed & on waiting list)
      insertReferral.run(
        'REF-2026-002',
        'PAT-1002',
        'GP e-RS',
        'UBRN-4821-9044',
        twoWeeksAgo,
        'Dermatology',
        'Pigmented Lesion & Dermoscopy Clinic',
        'Changing pigmented lesion on left forearm; dermoscopy requested.',
        'Urgent',
        'Offer Sent',
        'Accepted',
        'USR-LEAD-THORNE',
        'Dr. Marcus Thorne',
        twoWeeksAgo + 'T15:00:00Z',
        'Urgent dermoscopy assessment within 14 days; Urdu interpreter booked.',
        'New Outpatient',
        30,
        'Consultant Dermatologist',
        'Clinical Examination',
        'Digital Dermoscope',
        1,
        today,
        dayStr(14),
        dayStr(10),
        twoWeeksAgo + 'T11:30:00Z',
      );

      // REF-2026-003: Samuel Whitaker — Orthopaedics (45 min, Booked, failed SMS reminder!)
      insertReferral.run(
        'REF-2026-003',
        'PAT-1003',
        'A&E Follow-up',
        'INT-2026-089',
        twoWeeksAgo,
        'Orthopaedics',
        'Knee & Mobility Assessment Clinic',
        'Post-injury meniscal assessment and mobility plan.',
        'Soon',
        'Appointment Booked',
        'Accepted',
        'USR-LEAD-THORNE',
        'Dr. Marcus Thorne',
        twoWeeksAgo + 'T16:10:00Z',
        '45-minute orthopaedic assessment with X-ray review.',
        'New Outpatient',
        45,
        'Consultant Orthopaedic Surgeon',
        'Fracture & Mobility Suite',
        'X-Ray Viewing Workstation',
        0,
        today,
        dayStr(21),
        dayStr(14),
        twoWeeksAgo + 'T14:15:00Z',
      );

      // REF-2026-004: Eleanor Vance — Ophthalmology (20 min, Booked into Suite 2 which has a room closure!)
      insertReferral.run(
        'REF-2026-004',
        'PAT-1004',
        'GP e-RS',
        'UBRN-4821-9102',
        twoWeeksAgo,
        'Ophthalmology',
        'Retinal & Glaucoma Monitoring',
        'Elevated intraocular pressure noted by community optometrist.',
        'Soon',
        'Appointment Booked',
        'Accepted',
        'USR-LEAD-THORNE',
        'Dr. Marcus Thorne',
        twoWeeksAgo + 'T17:00:00Z',
        '20-minute slit lamp & OCT review.',
        'New Outpatient',
        20,
        'Consultant Ophthalmologist',
        'Ophthalmic Examination',
        'Slit Lamp Biomicroscope',
        0,
        today,
        dayStr(21),
        dayStr(18),
        twoWeeksAgo + 'T16:00:00Z',
      );

      // REF-2026-005: George Hargreaves — Cardiology today (Telephone preference / BSL interpreter, ready for Reception Check-in & Outcome!)
      insertReferral.run(
        'REF-2026-005',
        'PAT-1005',
        'Internal Consultant',
        'INT-2026-014',
        threeWeeksAgo,
        'Cardiology',
        'Heart Failure Medication Titration',
        'Follow-up review of ACE inhibitor tolerance and blood pressure.',
        'Routine',
        'Appointment Booked',
        'Accepted',
        'USR-CLIN-NAIR',
        'Dr. Priya Nair',
        threeWeeksAgo + 'T14:00:00Z',
        '20-minute follow-up at Calder Valley Annex; BSL interpreter arranged.',
        'Follow-up',
        20,
        'Consultant Cardiologist',
        'General Outpatient',
        '12-Lead ECG Machine',
        1,
        yesterday,
        dayStr(14),
        dayStr(14),
        threeWeeksAgo + 'T10:20:00Z',
      );

      // REF-2026-006: Arthur Pendelton — Second Cardiology referral ALREADY reviewed & on Waiting List (so patient portal has active offer ready too)
      insertReferral.run(
        'REF-2026-006',
        'PAT-1001',
        'Internal Consultant',
        'INT-2026-099',
        dayStr(-5),
        'Cardiology',
        'Pacemaker & Device Pre-Assessment',
        'Routine device check prior to elective consultation.',
        'Routine',
        'Offer Sent',
        'Accepted',
        'USR-CLIN-NAIR',
        'Dr. Priya Nair',
        dayStr(-4) + 'T10:00:00Z',
        '30-minute diagnostic check with ECG.',
        'Diagnostic Review',
        30,
        'Consultant Cardiologist',
        'Diagnostic Consulting',
        '12-Lead ECG Machine',
        0,
        today,
        dayStr(30),
        dayStr(28),
        dayStr(-5) + 'T09:30:00Z',
      );

      // 8. Protected Supporting Referral Documents (inserted after referrals for FK integrity)
      const refDoc1 = join(this.storageDir, 'ref-2026-001-gp-letter.txt');
      if (!existsSync(refDoc1)) {
        writeFileSync(
          refDoc1,
          [
            'SYNTHETIC PROTOTYPE REFERRAL DOCUMENT — PENNINE OUTPATIENT CENTRE',
            'UBRN: 0000 4821 9011',
            'Patient: Arthur Pendelton (DOB: 1954-04-12, Synthetic NHS: 943 476 5919)',
            'Referring Practice: Pendle Valley Medical Centre',
            'Clinical Summary: Intermittent exertional palpitations and mild ankle oedema over 6 weeks.',
            'Requested Service: General Cardiology Outpatient Assessment + 12-Lead ECG.',
            'Note: Fictional patient record for prototype demonstration only.',
          ].join('\n'),
          'utf8',
        );
      }
      const refDoc2 = join(this.storageDir, 'ref-2026-002-derm-letter.txt');
      if (!existsSync(refDoc2)) {
        writeFileSync(
          refDoc2,
          [
            'SYNTHETIC PROTOTYPE REFERRAL DOCUMENT — PENNINE OUTPATIENT CENTRE',
            'UBRN: 0000 4821 9044',
            'Patient: Nadia Begum (DOB: 1983-09-27, Synthetic NHS: 943 512 8834)',
            'Interpreter Requirement: Urdu language interpreter requested.',
            'Clinical Summary: Persistent pigmented lesion on left forearm requiring dermoscopic evaluation.',
            'Note: Fictional patient record for prototype demonstration only.',
          ].join('\n'),
          'utf8',
        );
      }

      this.db
        .prepare(
          'INSERT INTO documents (id, patient_id, referral_id, title, doc_type, storage_key, mime_type, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          'DOC-1001',
          'PAT-1001',
          'REF-2026-001',
          'GP Cardiology Referral Letter (Synthetic)',
          'Referral Letter',
          'ref-2026-001-gp-letter.txt',
          'text/plain',
          'e-RS Referral Adapter',
          yesterday + 'T08:45:00Z',
        );
      this.db
        .prepare(
          'INSERT INTO documents (id, patient_id, referral_id, title, doc_type, storage_key, mime_type, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          'DOC-1002',
          'PAT-1002',
          'REF-2026-002',
          'GP Dermatology Referral & Lesion History',
          'Referral Letter',
          'ref-2026-002-derm-letter.txt',
          'text/plain',
          'e-RS Referral Adapter',
          twoWeeksAgo + 'T11:35:00Z',
        );

      // Referral History
      const insertRefHist = this.db.prepare(
        'INSERT INTO referral_history (id, referral_id, actor_user_id, actor_name, actor_role, action, previous_priority, new_priority, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      );
      insertRefHist.run(
        'RH-001',
        'REF-2026-001',
        'SYSTEM',
        'e-RS Referral Adapter',
        'SYSTEM',
        'Referral Received',
        null,
        null,
        'Imported via e-RS adapter (UBRN-4821-9011). Awaiting authorised clinical review.',
        yesterday + 'T08:40:00Z',
      );
      insertRefHist.run(
        'RH-002',
        'REF-2026-002',
        'USR-LEAD-THORNE',
        'Dr. Marcus Thorne',
        'CLINICAL_LEAD',
        'Clinical Review Completed',
        null,
        'Urgent',
        'Accepted as Urgent; Urdu interpreter required; 30-minute Digital Dermoscope slot specified.',
        twoWeeksAgo + 'T15:00:00Z',
      );
      insertRefHist.run(
        'RH-003',
        'REF-2026-006',
        'USR-CLIN-NAIR',
        'Dr. Priya Nair',
        'CLINICIAN',
        'Clinical Review Completed',
        null,
        'Routine',
        'Accepted as Routine; 30-minute ECG slot required.',
        dayStr(-4) + 'T10:00:00Z',
      );

      // 9. Waiting List Entries
      const insertWait = this.db.prepare(
        `INSERT INTO waiting_list_entries (id, referral_id, patient_id, specialty, clinical_priority, original_joined_at, status, short_notice_opt_in, preferred_site_id, preferred_modality, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );
      insertWait.run(
        'WL-2002',
        'REF-2026-002',
        'PAT-1002',
        'Dermatology',
        'Urgent',
        twoWeeksAgo + 'T15:00:00Z',
        'Offer Pending',
        1,
        'SITE-PGH',
        'In-person',
        'Requires Urdu interpreter; patient opted into short-notice cancellations.',
      );
      insertWait.run(
        'WL-2003',
        'REF-2026-003',
        'PAT-1003',
        'Orthopaedics',
        'Soon',
        twoWeeksAgo + 'T16:10:00Z',
        'Booked',
        0,
        'SITE-PGH',
        'In-person',
        'Booked for 45 min slot.',
      );
      insertWait.run(
        'WL-2004',
        'REF-2026-004',
        'PAT-1004',
        'Ophthalmology',
        'Soon',
        twoWeeksAgo + 'T17:00:00Z',
        'Booked',
        0,
        'SITE-PGH',
        'In-person',
        'Large print instructions needed.',
      );
      insertWait.run(
        'WL-2005',
        'REF-2026-005',
        'PAT-1005',
        'Cardiology',
        'Routine',
        threeWeeksAgo + 'T14:00:00Z',
        'Booked',
        0,
        'SITE-CVA',
        'In-person',
        'BSL interpreter confirmed; telephone/letter comms only.',
      );
      insertWait.run(
        'WL-2006',
        'REF-2026-006',
        'PAT-1001',
        'Cardiology',
        'Routine',
        dayStr(-4) + 'T10:00:00Z',
        'Offer Pending',
        1,
        'SITE-PGH',
        'In-person',
        'Waiting list entry active with offer sent to patient portal.',
      );

      // 10. Versioned Clinic Templates
      const insertTpl = this.db.prepare(
        `INSERT INTO clinic_templates (
          id, name, specialty, site_id, room_id, clinician_id, supporting_staff_role,
          modality, appointment_types_json, slot_length_minutes, buffer_minutes,
          break_start_time, break_end_time, required_equipment, protected_urgent_slots,
          current_version, active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );
      insertTpl.run(
        'TPL-CARD-PGH',
        'Morning General Cardiology (PGH)',
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        'Cardiac HCA',
        'In-person',
        JSON.stringify(['New Outpatient', 'Diagnostic Review', 'Follow-up']),
        30,
        5,
        '10:30',
        '10:50',
        '12-Lead ECG Machine',
        1,
        1,
        1,
      );
      insertTpl.run(
        'TPL-CARD-CVA',
        'Calder Valley Cardiology Follow-Up',
        'Cardiology',
        'SITE-CVA',
        'ROOM-CVA-C2',
        'CLIN-NAIR',
        'Outpatient Nurse',
        'In-person',
        JSON.stringify(['Follow-up', 'Telephone Review']),
        20,
        5,
        '11:00',
        '11:15',
        '12-Lead ECG Machine',
        0,
        1,
        1,
      );
      insertTpl.run(
        'TPL-DERM-PGH',
        'Dermatology Urgent Lesion Clinic',
        'Dermatology',
        'SITE-PGH',
        'ROOM-PGH-D1',
        'CLIN-OWEN',
        'Dermatology Nurse',
        'In-person',
        JSON.stringify(['New Outpatient', 'Follow-up']),
        30,
        5,
        '10:45',
        '11:00',
        'Digital Dermoscope',
        1,
        1,
        1,
      );
      insertTpl.run(
        'TPL-ORTHO-PGH',
        'Orthopaedics Mobility & Fracture Clinic',
        'Orthopaedics',
        'SITE-PGH',
        'ROOM-PGH-O1',
        'CLIN-FINCH',
        'Orthopaedic Practitioner',
        'In-person',
        JSON.stringify(['New Outpatient', 'Follow-up']),
        45,
        5,
        null,
        null,
        'X-Ray Viewing Workstation',
        0,
        1,
        1,
      );
      insertTpl.run(
        'TPL-OPHTH-PGH',
        'Ophthalmology Retinal Suite 2',
        'Ophthalmology',
        'SITE-PGH',
        'ROOM-PGH-OP2',
        'CLIN-REID',
        'Ophthalmic Technician',
        'In-person',
        JSON.stringify(['New Outpatient', 'Follow-up']),
        20,
        5,
        '15:00',
        '15:15',
        'Slit Lamp Biomicroscope',
        0,
        1,
        1,
      );

      const insertTplVer = this.db.prepare(
        'INSERT INTO clinic_template_versions (id, template_id, version_number, effective_from, snapshot_json, changed_by, change_reason, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      );
      for (const tplId of [
        'TPL-CARD-PGH',
        'TPL-CARD-CVA',
        'TPL-DERM-PGH',
        'TPL-ORTHO-PGH',
        'TPL-OPHTH-PGH',
      ]) {
        insertTplVer.run(
          `TV-${tplId}-1`,
          tplId,
          1,
          threeWeeksAgo,
          JSON.stringify({template_id: tplId, version: 1, slot_policy: 'No routine overbooking'}),
          'Dr. Marcus Thorne',
          'Initial Pennine Outpatient Centre baseline schedule',
          threeWeeksAgo + 'T08:00:00Z',
        );
      }

      // 11. Clinic Sessions & Bookable Slots (in Europe/London)
      const insertSession = this.db.prepare(
        `INSERT INTO clinic_sessions (
          id, template_id, template_version, specialty, site_id, room_id, clinician_id,
          supporting_staff, session_date, start_time, end_time, modality, required_equipment, status, timezone, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );

      // Today's Cardiology session at Calder Valley Annex (for George Hargreaves arrival & outcome demo!)
      insertSession.run(
        'SES-CARD-TODAY-CVA',
        'TPL-CARD-CVA',
        1,
        'Cardiology',
        'SITE-CVA',
        'ROOM-CVA-C2',
        'CLIN-NAIR',
        'Nurse Eleanor Shaw',
        today,
        '09:00',
        '12:30',
        'In-person',
        '12-Lead ECG Machine',
        'Active',
        'Europe/London',
        'Today morning clinic at Calder Valley Annex',
      );

      // Tomorrow Cardiology session at Pennine General (for Arthur Pendelton self-booking & concurrency demo!)
      insertSession.run(
        'SES-CARD-TOMORROW-PGH',
        'TPL-CARD-PGH',
        1,
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        'Cardiac HCA',
        tomorrow,
        '09:00',
        '12:30',
        'In-person',
        '12-Lead ECG Machine',
        'Active',
        'Europe/London',
        'General Cardiology & ECG clinic',
      );

      // Day+3 Cardiology session at Pennine General (for follow-up booking & rescheduling!)
      insertSession.run(
        'SES-CARD-DAY3-PGH',
        'TPL-CARD-PGH',
        1,
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        'Cardiac HCA',
        day3,
        '09:00',
        '12:30',
        'In-person',
        '12-Lead ECG Machine',
        'Active',
        'Europe/London',
        'Follow-up & New Cardiology clinic',
      );

      // Day+2 Dermatology session (Dr. Gareth Owen — has an absence on Day+5, Day+2 is active for Nadia Begum!)
      insertSession.run(
        'SES-DERM-DAY2-PGH',
        'TPL-DERM-PGH',
        1,
        'Dermatology',
        'SITE-PGH',
        'ROOM-PGH-D1',
        'CLIN-OWEN',
        'Dermatology Nurse',
        day2,
        '09:00',
        '12:00',
        'In-person',
        'Digital Dermoscope',
        'Active',
        'Europe/London',
        'Urgent Dermoscopy session',
      );

      // Day+5 Dermatology session — Dr. Gareth Owen ABSENT!
      insertSession.run(
        'SES-DERM-DAY5-ABSENT',
        'TPL-DERM-PGH',
        1,
        'Dermatology',
        'SITE-PGH',
        'ROOM-PGH-D1',
        'CLIN-OWEN',
        'Dermatology Nurse',
        day5,
        '09:00',
        '12:00',
        'In-person',
        'Digital Dermoscope',
        'Impacted - Clinician Absent',
        'Europe/London',
        'Dr. Gareth Owen on annual leave — review required',
      );

      // Day+2 Orthopaedics session (Samuel Whitaker booked here with failed SMS reminder)
      insertSession.run(
        'SES-ORTHO-DAY2-PGH',
        'TPL-ORTHO-PGH',
        1,
        'Orthopaedics',
        'SITE-PGH',
        'ROOM-PGH-O1',
        'CLIN-FINCH',
        'Orthopaedic Practitioner',
        day2,
        '13:30',
        '16:30',
        'In-person',
        'X-Ray Viewing Workstation',
        'Active',
        'Europe/London',
        'Afternoon Orthopaedics',
      );

      // Day+3 Ophthalmology session — Suite 2 UNAVAILABLE (Equipment Calibration)!
      insertSession.run(
        'SES-OPHTH-DAY3-CLOSED',
        'TPL-OPHTH-PGH',
        1,
        'Ophthalmology',
        'SITE-PGH',
        'ROOM-PGH-OP2',
        'CLIN-REID',
        'Ophthalmic Technician',
        day3,
        '13:30',
        '16:30',
        'In-person',
        'Slit Lamp Biomicroscope',
        'Impacted - Room Unavailable',
        'Europe/London',
        'Ophthalmology Suite 2 closed for Slit Lamp & OCT calibration',
      );

      // Day+7 Ophthalmology replacement session (for rescheduling affected appointment!)
      insertSession.run(
        'SES-OPHTH-DAY7-PGH',
        'TPL-OPHTH-PGH',
        1,
        'Ophthalmology',
        'SITE-PGH',
        'ROOM-PGH-OP2',
        'CLIN-REID',
        'Ophthalmic Technician',
        day7,
        '13:30',
        '16:30',
        'In-person',
        'Slit Lamp Biomicroscope',
        'Active',
        'Europe/London',
        'Rescheduled Ophthalmology capacity',
      );

      // 12. One Clinician Absence & One Unavailable Room
      this.db
        .prepare(
          'INSERT INTO staff_absences (id, clinician_id, start_date, end_date, reason, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          'ABS-001',
          'CLIN-OWEN',
          day5,
          day5,
          'Consultant study & annual leave',
          'Clara Jenkins',
          yesterday + 'T11:00:00Z',
        );

      this.db
        .prepare(
          'INSERT INTO room_closures (id, room_id, start_date, end_date, reason, recorded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          'RCL-001',
          'ROOM-PGH-OP2',
          day3,
          day3,
          'Scheduled Slit Lamp & OCT laser calibration',
          'Dr. Marcus Thorne',
          yesterday + 'T13:15:00Z',
        );

      // 13. Slots across sessions
      const insertSlot = this.db.prepare(
        `INSERT INTO clinic_slots (
          id, session_id, specialty, site_id, room_id, clinician_id, slot_date,
          start_time, end_time, start_utc, end_utc, duration_minutes, modality,
          appointment_type, required_equipment, is_protected_urgent, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );

      // Today Calder Valley Cardiology slots
      insertSlot.run(
        'SLT-CVA-T1',
        'SES-CARD-TODAY-CVA',
        'Cardiology',
        'SITE-CVA',
        'ROOM-CVA-C2',
        'CLIN-NAIR',
        today,
        '09:00',
        '09:20',
        `${today}T09:00:00Z`,
        `${today}T09:20:00Z`,
        20,
        'In-person',
        'Follow-up',
        '12-Lead ECG Machine',
        0,
        'Booked',
      );
      insertSlot.run(
        'SLT-CVA-T2',
        'SES-CARD-TODAY-CVA',
        'Cardiology',
        'SITE-CVA',
        'ROOM-CVA-C2',
        'CLIN-NAIR',
        today,
        '09:30',
        '09:50',
        `${today}T09:30:00Z`,
        `${today}T09:50:00Z`,
        20,
        'In-person',
        'Follow-up',
        '12-Lead ECG Machine',
        0,
        'Available',
      );
      insertSlot.run(
        'SLT-CVA-T3',
        'SES-CARD-TODAY-CVA',
        'Cardiology',
        'SITE-CVA',
        'ROOM-CVA-C2',
        'CLIN-NAIR',
        today,
        '10:00',
        '10:20',
        `${today}T10:00:00Z`,
        `${today}T10:20:00Z`,
        20,
        'In-person',
        'Follow-up',
        '12-Lead ECG Machine',
        0,
        'Available',
      );

      // Tomorrow Pennine General Cardiology 30-min slots (for Arthur Pendelton booking & concurrency!)
      insertSlot.run(
        'SLT-PGH-C1',
        'SES-CARD-TOMORROW-PGH',
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        tomorrow,
        '09:00',
        '09:30',
        `${tomorrow}T09:00:00Z`,
        `${tomorrow}T09:30:00Z`,
        30,
        'In-person',
        'New Outpatient',
        '12-Lead ECG Machine',
        0,
        'Available',
      );
      insertSlot.run(
        'SLT-PGH-C2',
        'SES-CARD-TOMORROW-PGH',
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        tomorrow,
        '09:35',
        '10:05',
        `${tomorrow}T09:35:00Z`,
        `${tomorrow}T10:05:00Z`,
        30,
        'In-person',
        'Diagnostic Review',
        '12-Lead ECG Machine',
        0,
        'Available',
      );
      insertSlot.run(
        'SLT-PGH-C3',
        'SES-CARD-TOMORROW-PGH',
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        tomorrow,
        '10:55',
        '11:25',
        `${tomorrow}T10:55:00Z`,
        `${tomorrow}T11:25:00Z`,
        30,
        'In-person',
        'New Outpatient',
        '12-Lead ECG Machine',
        1,
        'Available',
      );
      insertSlot.run(
        'SLT-PGH-C4',
        'SES-CARD-TOMORROW-PGH',
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        tomorrow,
        '11:30',
        '12:00',
        `${tomorrow}T11:30:00Z`,
        `${tomorrow}T12:00:00Z`,
        30,
        'In-person',
        'Follow-up',
        '12-Lead ECG Machine',
        0,
        'Available',
      );

      // Day+3 Cardiology slots
      insertSlot.run(
        'SLT-PGH-C5',
        'SES-CARD-DAY3-PGH',
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        day3,
        '09:00',
        '09:30',
        `${day3}T09:00:00Z`,
        `${day3}T09:30:00Z`,
        30,
        'In-person',
        'Follow-up',
        '12-Lead ECG Machine',
        0,
        'Available',
      );
      insertSlot.run(
        'SLT-PGH-C6',
        'SES-CARD-DAY3-PGH',
        'Cardiology',
        'SITE-PGH',
        'ROOM-PGH-C1',
        'CLIN-NAIR',
        day3,
        '09:35',
        '10:05',
        `${day3}T09:35:00Z`,
        `${day3}T10:05:00Z`,
        30,
        'In-person',
        'New Outpatient',
        '12-Lead ECG Machine',
        0,
        'Available',
      );

      // Day+2 Dermatology slots (30 min, Digital Dermoscope)
      insertSlot.run(
        'SLT-PGH-D1',
        'SES-DERM-DAY2-PGH',
        'Dermatology',
        'SITE-PGH',
        'ROOM-PGH-D1',
        'CLIN-OWEN',
        day2,
        '09:00',
        '09:30',
        `${day2}T09:00:00Z`,
        `${day2}T09:30:00Z`,
        30,
        'In-person',
        'New Outpatient',
        'Digital Dermoscope',
        1,
        'Available',
      );
      insertSlot.run(
        'SLT-PGH-D2',
        'SES-DERM-DAY2-PGH',
        'Dermatology',
        'SITE-PGH',
        'ROOM-PGH-D1',
        'CLIN-OWEN',
        day2,
        '09:35',
        '10:05',
        `${day2}T09:35:00Z`,
        `${day2}T10:05:00Z`,
        30,
        'In-person',
        'New Outpatient',
        'Digital Dermoscope',
        0,
        'Available',
      );

      // Day+5 Dermatology slot (blocked due to clinician absence)
      insertSlot.run(
        'SLT-PGH-D3-ABS',
        'SES-DERM-DAY5-ABSENT',
        'Dermatology',
        'SITE-PGH',
        'ROOM-PGH-D1',
        'CLIN-OWEN',
        day5,
        '09:00',
        '09:30',
        `${day5}T09:00:00Z`,
        `${day5}T09:30:00Z`,
        30,
        'In-person',
        'New Outpatient',
        'Digital Dermoscope',
        0,
        'Unavailable - Clinician Absent',
      );

      // Day+2 Orthopaedics slots (45 min)
      insertSlot.run(
        'SLT-PGH-O1',
        'SES-ORTHO-DAY2-PGH',
        'Orthopaedics',
        'SITE-PGH',
        'ROOM-PGH-O1',
        'CLIN-FINCH',
        day2,
        '13:30',
        '14:15',
        `${day2}T13:30:00Z`,
        `${day2}T14:15:00Z`,
        45,
        'In-person',
        'New Outpatient',
        'X-Ray Viewing Workstation',
        0,
        'Booked',
      );
      insertSlot.run(
        'SLT-PGH-O2',
        'SES-ORTHO-DAY2-PGH',
        'Orthopaedics',
        'SITE-PGH',
        'ROOM-PGH-O1',
        'CLIN-FINCH',
        day2,
        '14:20',
        '15:05',
        `${day2}T14:20:00Z`,
        `${day2}T15:05:00Z`,
        45,
        'In-person',
        'New Outpatient',
        'X-Ray Viewing Workstation',
        0,
        'Available',
      );

      // Day+3 Ophthalmology slot (Booked by Eleanor Vance, impacted by Room Closure!)
      insertSlot.run(
        'SLT-PGH-OP1',
        'SES-OPHTH-DAY3-CLOSED',
        'Ophthalmology',
        'SITE-PGH',
        'ROOM-PGH-OP2',
        'CLIN-REID',
        day3,
        '13:30',
        '13:50',
        `${day3}T13:30:00Z`,
        `${day3}T13:50:00Z`,
        20,
        'In-person',
        'New Outpatient',
        'Slit Lamp Biomicroscope',
        0,
        'Booked',
      );

      // Day+7 Ophthalmology replacement slots
      insertSlot.run(
        'SLT-PGH-OP2',
        'SES-OPHTH-DAY7-PGH',
        'Ophthalmology',
        'SITE-PGH',
        'ROOM-PGH-OP2',
        'CLIN-REID',
        day7,
        '13:30',
        '13:50',
        `${day7}T13:30:00Z`,
        `${day7}T13:50:00Z`,
        20,
        'In-person',
        'New Outpatient',
        'Slit Lamp Biomicroscope',
        0,
        'Available',
      );
      insertSlot.run(
        'SLT-PGH-OP3',
        'SES-OPHTH-DAY7-PGH',
        'Ophthalmology',
        'SITE-PGH',
        'ROOM-PGH-OP2',
        'CLIN-REID',
        day7,
        '13:55',
        '14:15',
        `${day7}T13:55:00Z`,
        `${day7}T14:15:00Z`,
        20,
        'In-person',
        'Follow-up',
        'Slit Lamp Biomicroscope',
        0,
        'Available',
      );

      // 14. Existing Seeded Appointments
      const insertAppt = this.db.prepare(
        `INSERT INTO appointments (
          id, patient_id, referral_id, waiting_list_id, slot_id, session_id,
          site_id, room_id, clinician_id, specialty, appointment_type, modality,
          scheduled_start_utc, scheduled_end_utc, local_date, local_start_time, local_end_time,
          state, interpreter_language, assistance_notes, preparation_instructions,
          booked_channel, booked_by_user_id, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );

      // George Hargreaves today at Calder Valley (Confirmed — ready for Reception Check-in & Clinical Completion + Follow-up!)
      insertAppt.run(
        'APT-3001',
        'PAT-1005',
        'REF-2026-005',
        'WL-2005',
        'SLT-CVA-T1',
        'SES-CARD-TODAY-CVA',
        'SITE-CVA',
        'ROOM-CVA-C2',
        'CLIN-NAIR',
        'Cardiology',
        'Follow-up',
        'In-person',
        `${today}T09:00:00Z`,
        `${today}T09:20:00Z`,
        today,
        '09:00',
        '09:20',
        'Confirmed',
        'British Sign Language',
        'BSL interpreter confirmed; no smartphone — staff telephone booked.',
        'Please bring your current list of blood pressure medications.',
        'Staff Telephone Booking',
        'USR-CLERK-JENKINS',
        dayStr(-6) + 'T11:00:00Z',
        dayStr(-6) + 'T11:00:00Z',
      );

      // Samuel Whitaker Day+2 Orthopaedics (Booked — has a failed SMS reminder!)
      insertAppt.run(
        'APT-3002',
        'PAT-1003',
        'REF-2026-003',
        'WL-2003',
        'SLT-PGH-O1',
        'SES-ORTHO-DAY2-PGH',
        'SITE-PGH',
        'ROOM-PGH-O1',
        'CLIN-FINCH',
        'Orthopaedics',
        'New Outpatient',
        'In-person',
        `${day2}T13:30:00Z`,
        `${day2}T14:15:00Z`,
        day2,
        '13:30',
        '14:15',
        'Booked',
        null,
        'Mobility scooter parking bay reserved near Outpatients entrance.',
        'Wear loose trousers for knee examination. Bring previous A&E discharge summary if available.',
        'Staff Telephone Booking',
        'USR-CLERK-JENKINS',
        dayStr(-4) + 'T14:20:00Z',
        dayStr(-4) + 'T14:20:00Z',
      );

      // Eleanor Vance Day+3 Ophthalmology (Confirmed — in Affected Appointments Queue due to Suite 2 closure!)
      insertAppt.run(
        'APT-3003',
        'PAT-1004',
        'REF-2026-004',
        'WL-2004',
        'SLT-PGH-OP1',
        'SES-OPHTH-DAY3-CLOSED',
        'SITE-PGH',
        'ROOM-PGH-OP2',
        'CLIN-REID',
        'Ophthalmology',
        'New Outpatient',
        'In-person',
        `${day3}T13:30:00Z`,
        `${day3}T13:50:00Z`,
        day3,
        '13:30',
        '13:50',
        'Confirmed',
        null,
        'Large print (18pt) correspondence required.',
        'Do not drive to your appointment as dilating eye drops may be used.',
        'Staff Telephone Booking',
        'USR-CLERK-JENKINS',
        dayStr(-5) + 'T10:15:00Z',
        yesterday + 'T13:20:00Z',
      );

      // 15. Affected Appointments Review Queue
      this.db
        .prepare(
          'INSERT INTO affected_appointments_queue (id, appointment_id, session_id, patient_id, trigger_type, trigger_reason, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          'AFQ-001',
          'APT-3003',
          'SES-OPHTH-DAY3-CLOSED',
          'PAT-1004',
          'Room Closure',
          'Ophthalmology Suite 2 closed for scheduled Slit Lamp & OCT calibration',
          'Pending Review',
          yesterday + 'T13:20:00Z',
        );

      // 16. Notifications (including 1 Failed Reminder!)
      const insertNotif = this.db.prepare(
        `INSERT INTO notifications (
          id, patient_id, appointment_id, channel, message_type, recipient_address,
          subject, body_redacted, status, failure_reason, attempt_count, scheduled_for_utc, sent_at_utc, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );

      insertNotif.run(
        'NTF-4001',
        'PAT-1001',
        null,
        'Portal',
        'Offer',
        'Portal Account: Arthur Pendelton',
        'Cardiology appointment slots are ready to choose',
        'Pennine Outpatient Centre has slots available for your Cardiology review. Please sign in to choose a time. Note: Portal messaging is not an emergency service.',
        'Delivered',
        null,
        1,
        dayStr(-4) + 'T10:05:00Z',
        dayStr(-4) + 'T10:05:00Z',
        dayStr(-4) + 'T10:05:00Z',
      );

      insertNotif.run(
        'NTF-4002',
        'PAT-1002',
        null,
        'Portal',
        'Offer',
        'Portal Account: Nadia Begum',
        'Dermatology appointment offer (Urdu interpreter arranged)',
        'You have an urgent Dermatology clinic offer at Pennine General Hospital with an Urdu interpreter. Sign in to confirm your slot.',
        'Delivered',
        null,
        1,
        twoWeeksAgo + 'T15:10:00Z',
        twoWeeksAgo + 'T15:10:00Z',
        twoWeeksAgo + 'T15:10:00Z',
      );

      // Failed SMS reminder for Samuel Whitaker
      insertNotif.run(
        'NTF-4003',
        'PAT-1003',
        'APT-3002',
        'SMS',
        'Reminder',
        '07700 900***',
        'Appointment Reminder — Pennine Outpatient Centre',
        'Reminder: You have an Orthopaedics appointment at Pennine General Hospital on ' +
          day2 +
          ' at 13:30. Reply or call 01282 550100 if you need to change.',
        'Failed',
        'GOV.UK Notify Adapter: Permanent delivery failure (mobile handset unreachable / bounced)',
        2,
        yesterday + 'T09:00:00Z',
        null,
        yesterday + 'T09:00:00Z',
      );

      // 17. Staff Tasks (linked to failed reminder + affected room closure)
      const insertTask = this.db.prepare(
        `INSERT INTO staff_tasks (
          id, task_type, priority, patient_id, referral_id, appointment_id, notification_id,
          title, description, assigned_role, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );
      insertTask.run(
        'TSK-5001',
        'Failed Communication Follow-up',
        'High',
        'PAT-1003',
        'REF-2026-003',
        'APT-3002',
        'NTF-4003',
        'Call Samuel Whitaker — SMS reminder failed',
        'Automated 48h SMS reminder bounced. Contact patient by landline/letter to confirm attendance and send preparation instructions. Do not cancel appointment because reminder failed.',
        'BOOKING_CLERK',
        'Open',
        yesterday + 'T09:05:00Z',
      );
      insertTask.run(
        'TSK-5002',
        'Affected Clinic Reschedule',
        'High',
        'PAT-1004',
        'REF-2026-004',
        'APT-3003',
        null,
        'Reschedule Eleanor Vance — Ophthalmology Suite 2 closed',
        'Suite 2 closed for Slit Lamp calibration on ' +
          day3 +
          '. Offer replacement slot on ' +
          day7 +
          ' and post Large Print (18pt) confirmation letter.',
        'BOOKING_CLERK',
        'Open',
        yesterday + 'T13:22:00Z',
      );

      // 18. Integration Adapter Events
      const insertEvt = this.db.prepare(
        `INSERT INTO integration_events (
          id, adapter_name, direction, idempotency_key, external_ref,
          payload_summary, status, retry_count, conflict_detail, created_at, processed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );
      insertEvt.run(
        'EVT-001',
        'e-RS Referral Adapter',
        'Inbound',
        'ers-ubrn-4821-9011-v1',
        'UBRN-4821-9011',
        'New GP Cardiology referral received for synthetic NHS 943 *** 5919',
        'Processed',
        0,
        null,
        yesterday + 'T08:40:00Z',
        yesterday + 'T08:40:01Z',
      );
      insertEvt.run(
        'EVT-002',
        'PDS Identity & Demographics Adapter',
        'Outbound/Sync',
        'pds-trace-pat-1003-v1',
        'PAS-991003',
        'Provisional trace mismatch on postcode for PAT-1003; flagged Unverified pending reception check',
        'Conflict - Staff Review',
        1,
        'Local PAS address differs from GP trace; preserved local record as authoritative for mail until verified',
        twoWeeksAgo + 'T14:16:00Z',
        null,
      );
      insertEvt.run(
        'EVT-003',
        'GOV.UK Notify Messaging Adapter',
        'Outbound',
        'notify-rem-apt-3002-try2',
        'NTF-4003',
        'SMS reminder dispatch for APT-3002',
        'Failed - Routed to Staff',
        2,
        'Permanent bounce reported; staff contact task TSK-5001 created',
        yesterday + 'T09:00:00Z',
        yesterday + 'T09:04:00Z',
      );

      // 19. Initial Audit Trail
      this.db
        .prepare(
          'INSERT INTO audit_logs (id, actor_user_id, actor_name, actor_role, action, entity_type, entity_id, patient_id, detail_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        )
        .run(
          'AUD-0001',
          'SYSTEM',
          'Pennine Prototype Seeder',
          'ADMIN',
          'SEED_ENVIRONMENT_INITIALISED',
          'Site',
          'SITE-PGH',
          null,
          JSON.stringify({
            sites: 2,
            specialties: ['Cardiology', 'Dermatology', 'Orthopaedics', 'Ophthalmology'],
            note: 'Synthetic Pennine Outpatient Centre dataset initialised',
          }),
          now.toISOString(),
        );
    });
  }
}
