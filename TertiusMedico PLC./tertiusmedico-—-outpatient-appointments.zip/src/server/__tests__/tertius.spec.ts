import {describe, it, expect, beforeEach, afterEach} from 'vitest';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import express from 'express';
import {AppDatabase} from '../db.js';
import {createApiRouter} from '../routes.js';
import {
  holdSlotTransactional,
  confirmBookingTransactional,
  londonLocalToUtcIso,
  transitionAppointmentState,
  checkResourceConflicts,
} from '../scheduling.js';
import {runBackgroundWorkerPass} from '../worker.js';
import type {AuthUser} from '../types.js';

function createServer(appDb: AppDatabase) {
  const app = express();
  app.use('/api', createApiRouter(appDb));
  return new Promise<{baseUrl: string; close: () => Promise<void>}>((resolve) => {
    const srv = app.listen(0, '127.0.0.1', () => {
      const addr = srv.address() as {port: number};
      resolve({
        baseUrl: `http://127.0.0.1:${addr.port}/api`,
        close: () => new Promise((res) => srv.close(() => res())),
      });
    });
  });
}

async function loginAs(baseUrl: string, username: string): Promise<{token: string; user: AuthUser}> {
  const res = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({username, password: 'PennineDemo2026!'}),
  });
  expect(res.status).toBe(200);
  return (await res.json()) as {token: string; user: AuthUser};
}

describe('TERTIUSMEDICO Outpatient Governance & Scheduling Suite', () => {
  let tmpDir: string;
  let appDb: AppDatabase;
  let srv: {baseUrl: string; close: () => Promise<void>};

  beforeEach(async () => {
    tmpDir = mkdtempSync(join(tmpdir(), 'tertius-test-'));
    appDb = new AppDatabase(join(tmpDir, 'test.db'), join(tmpDir, 'storage'));
    appDb.seedPennineDemoIfEmpty();
    srv = await createServer(appDb);
  });

  afterEach(async () => {
    await srv.close();
    rmSync(tmpDir, {recursive: true, force: true});
  });

  it('rejects using an NHS number as a login credential', async () => {
    const res = await fetch(`${srv.baseUrl}/auth/login`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username: '943 476 5919', password: 'PennineDemo2026!'}),
    });
    expect(res.status).toBe(400);
    const body = (await res.json()) as {error: string};
    expect(body.error).toContain('NHS number is an identifier');
  });

  it('enforces patient isolation across records, appointments, and protected documents', async () => {
    const arthur = await loginAs(srv.baseUrl, 'arthur.pendelton');

    // Arthur trying to view Nadia's patient record, appointments, or referral document
    const patRes = await fetch(`${srv.baseUrl}/patients/PAT-1002`, {
      headers: {Authorization: `Bearer ${arthur.token}`},
    });
    expect(patRes.status).toBe(403);

    const apptRes = await fetch(`${srv.baseUrl}/appointments?patient_id=PAT-1002`, {
      headers: {Authorization: `Bearer ${arthur.token}`},
    });
    expect(apptRes.status).toBe(403);

    const docRes = await fetch(`${srv.baseUrl}/documents/DOC-1002/download`, {
      headers: {Authorization: `Bearer ${arthur.token}`},
    });
    expect(docRes.status).toBe(403);

    // Verify denial was audited
    const audit = appDb.db
      .prepare(`SELECT COUNT(*) as c FROM audit_logs WHERE action LIKE '%DENIED%' OR action LIKE '%BLOCKED%'`)
      .get() as {c: number};
    expect(audit.c).toBeGreaterThanOrEqual(3);
  });

  it('verifies proxy authority and scope boundaries', async () => {
    const margaret = await loginAs(srv.baseUrl, 'margaret.pendelton');

    // Permitted for Arthur (PAT-1001, VIEW_AND_BOOK)
    const allowedRes = await fetch(`${srv.baseUrl}/appointments?patient_id=PAT-1001`, {
      headers: {Authorization: `Bearer ${margaret.token}`},
    });
    expect(allowedRes.status).toBe(200);

    // Denied for Nadia (PAT-1002, no proxy relationship)
    const deniedRes = await fetch(`${srv.baseUrl}/appointments?patient_id=PAT-1002`, {
      headers: {Authorization: `Bearer ${margaret.token}`},
    });
    expect(deniedRes.status).toBe(403);

    // Downgrade proxy scope to VIEW_ONLY -> booking must fail 403
    appDb.db.prepare(`UPDATE proxy_relationships SET scope = 'VIEW_ONLY' WHERE id = 'PRX-001'`).run();
    const bookBlocked = await fetch(`${srv.baseUrl}/slots/SLT-PGH-C1/hold`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${margaret.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({patient_id: 'PAT-1001', referral_id: 'REF-2026-006'}),
    });
    expect(bookBlocked.status).toBe(403);
  });

  it('restricts clinical review and clinical outcomes strictly to authorised clinical roles', async () => {
    const clerk = await loginAs(srv.baseUrl, 'clara.jenkins');
    const clinician = await loginAs(srv.baseUrl, 'priya.nair');

    // Booking clerk attempts clinical review -> 403
    const clerkReview = await fetch(`${srv.baseUrl}/referrals/REF-2026-001/review`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${clerk.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        review_status: 'Accepted',
        clinical_priority: 'Urgent',
        review_notes: 'Unauthorised triage attempt',
      }),
    });
    expect(clerkReview.status).toBe(403);

    // Booking clerk attempts clinical outcome -> 403
    const clerkOutcome = await fetch(`${srv.baseUrl}/appointments/APT-3001/outcome`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${clerk.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        clinical_outcome: 'Discharged from this service',
        outcome_notes: 'Unauthorised discharge',
      }),
    });
    expect(clerkOutcome.status).toBe(403);

    // Clinician succeeds -> 200
    const clinReview = await fetch(`${srv.baseUrl}/referrals/REF-2026-001/review`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${clinician.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        review_status: 'Accepted',
        clinical_priority: 'Soon',
        duration_minutes: 30,
        required_equipment: '12-Lead ECG Machine',
        review_notes: 'Clinically reviewed by Dr. Nair',
      }),
    });
    expect(clinReview.status).toBe(200);
  });

  it('prevents concurrent double-booking of the same slot and expires elapsed holds', () => {
    const actorArthur: AuthUser = {
      id: 'USR-PAT-ARTHUR',
      username: 'arthur.pendelton',
      display_name: 'Arthur Pendelton',
      role: 'PATIENT',
      patient_id: 'PAT-1001',
      clinician_id: null,
      specialty: null,
      site_id: null,
      identity_provider: 'Test',
    };
    const actorClerk: AuthUser = {
      id: 'USR-CLERK-JENKINS',
      username: 'clara.jenkins',
      display_name: 'Clara Jenkins',
      role: 'BOOKING_CLERK',
      patient_id: null,
      clinician_id: null,
      specialty: null,
      site_id: 'SITE-PGH',
      identity_provider: 'Test',
    };

    // First hold succeeds
    const hold1 = holdSlotTransactional(appDb, actorArthur, 'SLT-PGH-C1', 'PAT-1001', 'REF-2026-006');
    expect(hold1.slotId).toBe('SLT-PGH-C1');

    // Second competing hold on same slot fails with 409
    expect(() =>
      holdSlotTransactional(appDb, actorClerk, 'SLT-PGH-C1', 'PAT-1005', 'REF-2026-005'),
    ).toThrow(/no longer available/i);

    // Force hold expiry in the past & run background worker -> slot returns to Available
    appDb.db
      .prepare(`UPDATE clinic_slots SET hold_expires_at = '2020-01-01T00:00:00Z' WHERE id = 'SLT-PGH-C1'`)
      .run();
    const workerRes = runBackgroundWorkerPass(appDb);
    expect(workerRes.expiredHoldsReleased).toBe(1);

    const slotAfter = appDb.db
      .prepare(`SELECT status FROM clinic_slots WHERE id = 'SLT-PGH-C1'`)
      .get() as {status: string};
    expect(slotAfter.status).toBe('Available');
  });

  it('detects resource conflicts and handles Europe/London DST transitions', () => {
    // Winter GMT: 2026-01-15 09:00 Europe/London === 09:00Z
    expect(londonLocalToUtcIso('2026-01-15', '09:00')).toBe('2026-01-15T09:00:00.000Z');
    // Summer BST (after last Sunday of March): 2026-06-15 09:00 Europe/London === 08:00Z
    expect(londonLocalToUtcIso('2026-06-15', '09:00')).toBe('2026-06-15T08:00:00.000Z');

    // Check conflict against Samuel Whitaker's existing Orthopaedics booking (SLT-PGH-O1)
    const slot = appDb.db
      .prepare(`SELECT slot_date, start_utc, end_utc, clinician_id, room_id FROM clinic_slots WHERE id = 'SLT-PGH-O1'`)
      .get() as {slot_date: string; start_utc: string; end_utc: string; clinician_id: string; room_id: string};
    const conflict = checkResourceConflicts(appDb, {
      startUtc: slot.start_utc,
      endUtc: slot.end_utc,
      slotDate: slot.slot_date,
      clinicianId: slot.clinician_id,
      roomId: slot.room_id,
      patientId: 'PAT-1003',
    });
    expect(conflict.hasConflict).toBe(true);
    expect(conflict.reasons.length).toBeGreaterThanOrEqual(3); // clinician, room, patient
  });

  it('preserves waiting-list original date on cancellation and links rescheduling history', () => {
    const clerk: AuthUser = {
      id: 'USR-CLERK-JENKINS',
      username: 'clara.jenkins',
      display_name: 'Clara Jenkins',
      role: 'BOOKING_CLERK',
      patient_id: null,
      clinician_id: null,
      specialty: null,
      site_id: 'SITE-PGH',
      identity_provider: 'Test',
    };

    const origWl = appDb.db
      .prepare(`SELECT original_joined_at FROM waiting_list_entries WHERE id = 'WL-2003'`)
      .get() as {original_joined_at: string};

    // Cancel APT-3002 -> waiting list must return to Active with identical original_joined_at
    transitionAppointmentState(appDb, clerk, 'APT-3002', 'Cancelled by patient', 'Patient unable to travel');
    const afterCancelWl = appDb.db
      .prepare(`SELECT status, original_joined_at FROM waiting_list_entries WHERE id = 'WL-2003'`)
      .get() as {status: string; original_joined_at: string};
    expect(afterCancelWl.status).toBe('Active');
    expect(afterCancelWl.original_joined_at).toBe(origWl.original_joined_at);

    // Reschedule Eleanor Vance's affected APT-3003 -> SLT-PGH-OP2
    const resched = confirmBookingTransactional(appDb, clerk, {
      slotId: 'SLT-PGH-OP2',
      patientId: 'PAT-1004',
      referralId: 'REF-2026-004',
      bookedChannel: 'Staff Reschedule',
      rescheduleFromAppointmentId: 'APT-3003',
      rescheduleReason: 'Suite 2 calibration closure',
    });

    const oldAppt = appDb.db
      .prepare('SELECT state, rescheduled_to_id, reschedule_reason FROM appointments WHERE id = ?')
      .get('APT-3003') as {state: string; rescheduled_to_id: string; reschedule_reason: string};
    const newAppt = appDb.db
      .prepare('SELECT state, rescheduled_from_id, reschedule_reason FROM appointments WHERE id = ?')
      .get(resched.appointmentId) as {state: string; rescheduled_from_id: string; reschedule_reason: string};

    expect(oldAppt.state).toBe('Rescheduled');
    expect(oldAppt.rescheduled_to_id).toBe(resched.appointmentId);
    expect(newAppt.rescheduled_from_id).toBe('APT-3003');
    expect(newAppt.reschedule_reason).toBe('Suite 2 calibration closure');
  });

  it('routes failed reminders to staff contact tasks without cancelling the appointment', async () => {
    const clerk = await loginAs(srv.baseUrl, 'clara.jenkins');

    const res = await fetch(`${srv.baseUrl}/notifications/queue-reminder`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${clerk.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        appointment_id: 'APT-3001',
        channel: 'SMS',
        simulate_bounce: true,
      }),
    });
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      notification: {id: string; status: string};
      worker_result: {failedNotificationsRouted: number};
    };
    expect(body.notification.status).toBe('Failed');
    expect(body.worker_result.failedNotificationsRouted).toBe(1);

    // Appointment APT-3001 remains Confirmed (never cancelled)
    const appt = appDb.db
      .prepare(`SELECT state FROM appointments WHERE id = 'APT-3001'`)
      .get() as {state: string};
    expect(appt.state).toBe('Confirmed');

    // Staff task created
    const task = appDb.db
      .prepare('SELECT status FROM staff_tasks WHERE notification_id = ?')
      .get(body.notification.id) as {status: string};
    expect(task.status).toBe('Open');
  });
});
