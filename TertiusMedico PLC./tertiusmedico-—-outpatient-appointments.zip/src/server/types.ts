export type UserRole =
  | 'PATIENT'
  | 'PROXY'
  | 'RECEPTIONIST'
  | 'BOOKING_CLERK'
  | 'TRIAGE_NURSE'
  | 'CLINICIAN'
  | 'CLINICAL_LEAD'
  | 'ADMIN';

export const CLINICAL_ROLES: readonly UserRole[] = [
  'TRIAGE_NURSE',
  'CLINICIAN',
  'CLINICAL_LEAD',
] as const;

export const STAFF_ROLES: readonly UserRole[] = [
  'RECEPTIONIST',
  'BOOKING_CLERK',
  'TRIAGE_NURSE',
  'CLINICIAN',
  'CLINICAL_LEAD',
  'ADMIN',
] as const;

export type ClinicalPriority = 'Urgent' | 'Soon' | 'Routine';

export type ReviewStatus =
  | 'Pending Review'
  | 'Accepted'
  | 'Returned for Info'
  | 'Rejected';

export type ReferralAdminStatus =
  | 'Awaiting Clinical Review'
  | 'On Waiting List'
  | 'Offer Sent'
  | 'Appointment Booked'
  | 'Attendance Recorded'
  | 'Outcome Recorded'
  | 'Closed / Discharged'
  | 'Returned / Cancelled';

export type AppointmentModality = 'In-person' | 'Telephone' | 'Video';

export type AppointmentState =
  | 'Offered'
  | 'Held'
  | 'Booked'
  | 'Confirmed'
  | 'Arrived'
  | 'In progress'
  | 'Completed'
  | 'Cancelled by patient'
  | 'Cancelled by provider'
  | 'Did not attend'
  | 'Unable to complete'
  | 'Rescheduled';

export type ClinicalOutcomeType =
  | 'Follow-up required'
  | 'Discharged from this service'
  | 'Further investigation requested'
  | 'Outcome awaiting completion';

export type ProxyScope = 'VIEW_AND_BOOK' | 'VIEW_ONLY' | 'MESSAGES_ONLY';

export interface AuthUser {
  id: string;
  username: string;
  display_name: string;
  role: UserRole;
  patient_id: string | null;
  clinician_id: string | null;
  specialty: string | null;
  site_id: string | null;
  identity_provider: string;
}

export interface SessionTokenPayload {
  sub: string;
  role: UserRole;
  patient_id: string | null;
  clinician_id: string | null;
  display_name: string;
  exp: number;
}

export const ALLOWED_TRANSITIONS: Record<AppointmentState, readonly AppointmentState[]> = {
  Offered: ['Held', 'Booked', 'Cancelled by patient', 'Cancelled by provider'],
  Held: ['Booked', 'Offered', 'Cancelled by patient', 'Cancelled by provider'],
  Booked: [
    'Confirmed',
    'Arrived',
    'Cancelled by patient',
    'Cancelled by provider',
    'Did not attend',
    'Rescheduled',
  ],
  Confirmed: [
    'Arrived',
    'Cancelled by patient',
    'Cancelled by provider',
    'Did not attend',
    'Rescheduled',
  ],
  Arrived: ['In progress', 'Cancelled by patient', 'Cancelled by provider', 'Unable to complete', 'Did not attend'],
  'In progress': ['Completed', 'Unable to complete'],
  Completed: [],
  'Cancelled by patient': [],
  'Cancelled by provider': [],
  'Did not attend': [],
  'Unable to complete': [],
  Rescheduled: [],
};

export const TRANSITION_ROLES: Record<AppointmentState, readonly UserRole[]> = {
  Offered: ['BOOKING_CLERK', 'TRIAGE_NURSE', 'CLINICIAN', 'CLINICAL_LEAD', 'ADMIN'],
  Held: ['PATIENT', 'PROXY', 'BOOKING_CLERK', 'CLINICAL_LEAD', 'ADMIN'],
  Booked: ['PATIENT', 'PROXY', 'BOOKING_CLERK', 'RECEPTIONIST', 'CLINICAL_LEAD', 'ADMIN'],
  Confirmed: ['PATIENT', 'PROXY', 'BOOKING_CLERK', 'RECEPTIONIST', 'CLINICAL_LEAD', 'ADMIN'],
  Arrived: ['RECEPTIONIST', 'BOOKING_CLERK', 'TRIAGE_NURSE', 'CLINICIAN', 'CLINICAL_LEAD', 'ADMIN'],
  'In progress': ['TRIAGE_NURSE', 'CLINICIAN', 'CLINICAL_LEAD'],
  Completed: ['TRIAGE_NURSE', 'CLINICIAN', 'CLINICAL_LEAD'],
  'Cancelled by patient': ['PATIENT', 'PROXY', 'BOOKING_CLERK', 'RECEPTIONIST', 'CLINICAL_LEAD', 'ADMIN'],
  'Cancelled by provider': ['BOOKING_CLERK', 'CLINICIAN', 'CLINICAL_LEAD', 'ADMIN'],
  'Did not attend': ['RECEPTIONIST', 'BOOKING_CLERK', 'TRIAGE_NURSE', 'CLINICIAN', 'CLINICAL_LEAD', 'ADMIN'],
  'Unable to complete': ['TRIAGE_NURSE', 'CLINICIAN', 'CLINICAL_LEAD'],
  Rescheduled: ['PATIENT', 'PROXY', 'BOOKING_CLERK', 'CLINICAL_LEAD', 'ADMIN'],
};

export interface HazardLogEntry {
  id: string;
  category: string;
  hazard: string;
  clinical_consequence: string;
  initial_risk: 'High' | 'Medium' | 'Low';
  mitigation_controls: string;
  residual_risk: 'Low' | 'Medium';
  verification_status: string;
}
