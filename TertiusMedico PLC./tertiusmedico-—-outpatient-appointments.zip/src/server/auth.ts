import {createHmac, randomBytes, scryptSync, timingSafeEqual} from 'node:crypto';
import type {Request, Response, NextFunction} from 'express';
import type {AppDatabase} from './db.js';
import type {AuthUser, ProxyScope, SessionTokenPayload, UserRole} from './types.js';

const SESSION_SECRET =
  process.env['SESSION_SECRET'] && process.env['SESSION_SECRET'].length >= 16
    ? process.env['SESSION_SECRET']
    : randomBytes(32).toString('hex');

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  if (!salt || !keyHex) return false;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derived = scryptSync(password, salt, 64);
  if (keyBuf.length !== derived.length) return false;
  return timingSafeEqual(keyBuf, derived);
}

export function issueSessionToken(user: AuthUser): string {
  const payload: SessionTokenPayload = {
    sub: user.id,
    role: user.role,
    patient_id: user.patient_id,
    clinician_id: user.clinician_id,
    display_name: user.display_name,
    exp: Date.now() + 8 * 3600_000, // 8-hour shift / portal session
  };
  const body = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

export function verifySessionToken(token: string): SessionTokenPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  if (!body || !sig) return null;
  const expectedSig = createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  const sigBuf = Buffer.from(sig, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (sigBuf.length !== expectedBuf.length) return null;
  if (!timingSafeEqual(sigBuf, expectedBuf)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as SessionTokenPayload;
    if (!parsed.sub || !parsed.exp || parsed.exp < Date.now()) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function redactSensitive(input: unknown): unknown {
  if (input === null || input === undefined) return input;
  if (typeof input === 'string') {
    return input
      .replace(/\b\d{3}\s?\d{3}\s?\d{4}\b/g, '[REDACTED_NHS_NO]')
      .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[REDACTED_EMAIL]');
  }
  if (Array.isArray(input)) {
    return input.map(redactSensitive);
  }
  if (typeof input === 'object') {
    const obj = input as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj)) {
      if (['password', 'password_hash', 'nhs_number', 'date_of_birth', 'token'].includes(k)) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = redactSensitive(v);
      }
    }
    return out;
  }
  return input;
}

export function recordAudit(
  appDb: AppDatabase,
  actor: {id: string; display_name: string; role: string},
  action: string,
  entityType: string,
  entityId: string,
  patientId: string | null,
  detail: Record<string, unknown>,
): void {
  const auditId = `AUD-${Date.now()}-${randomBytes(3).toString('hex')}`;
  appDb.db
    .prepare(
      `INSERT INTO audit_logs (id, actor_user_id, actor_name, actor_role, action, entity_type, entity_id, patient_id, detail_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      auditId,
      actor.id,
      actor.display_name,
      actor.role,
      action,
      entityType,
      entityId,
      patientId,
      JSON.stringify(redactSensitive(detail)),
      new Date().toISOString(),
    );
}

export function attachAuth(appDb: AppDatabase) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({error: 'Authentication required. Please sign in.'});
      return;
    }
    const token = authHeader.slice(7).trim();
    const payload = verifySessionToken(token);
    if (!payload) {
      res.status(401).json({error: 'Session invalid or expired. Please sign in again.'});
      return;
    }

    const row = appDb.db
      .prepare(
        'SELECT id, username, display_name, role, patient_id, clinician_id, specialty, site_id, identity_provider, active FROM users WHERE id = ?',
      )
      .get(payload.sub) as (AuthUser & {active: number}) | undefined;

    if (!row || row.active !== 1) {
      res.status(401).json({error: 'Account inactive or not found.'});
      return;
    }

    req.user = {
      id: row.id,
      username: row.username,
      display_name: row.display_name,
      role: row.role,
      patient_id: row.patient_id,
      clinician_id: row.clinician_id,
      specialty: row.specialty,
      site_id: row.site_id,
      identity_provider: row.identity_provider,
    };
    next();
  };
}

export function requireRoles(appDb: AppDatabase, allowedRoles: readonly UserRole[], actionLabel: string) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({error: 'Authentication required.'});
      return;
    }
    if (!allowedRoles.includes(req.user.role)) {
      recordAudit(
        appDb,
        req.user,
        'AUTHORISATION_DENIED',
        'Endpoint',
        req.path,
        null,
        {required_roles: allowedRoles, attempted_action: actionLabel},
      );
      res.status(403).json({
        error: `Access restricted: ${actionLabel} requires one of [${allowedRoles.join(', ')}].`,
      });
      return;
    }
    next();
  };
}

export function checkPatientAccess(
  appDb: AppDatabase,
  user: AuthUser,
  targetPatientId: string,
  requiredProxyScope: ProxyScope = 'VIEW_ONLY',
): {allowed: boolean; reason?: string; viaProxy?: boolean} {
  // Staff roles can access patient operational records
  if (user.role !== 'PATIENT' && user.role !== 'PROXY') {
    return {allowed: true, viaProxy: false};
  }

  // Patient accessing own record
  if (user.role === 'PATIENT' && user.patient_id === targetPatientId) {
    return {allowed: true, viaProxy: false};
  }

  // Proxy accessing linked patient record
  if (user.role === 'PROXY') {
    const proxy = appDb.db
      .prepare(
        `SELECT id, scope, verification_status, expires_at
         FROM proxy_relationships
         WHERE proxy_user_id = ? AND patient_id = ?`,
      )
      .get(user.id, targetPatientId) as
      | {id: string; scope: ProxyScope; verification_status: string; expires_at: string | null}
      | undefined;

    if (!proxy) {
      return {allowed: false, reason: 'No proxy relationship exists for this patient.'};
    }
    if (proxy.verification_status !== 'Verified') {
      return {allowed: false, reason: `Proxy authority is ${proxy.verification_status}.`};
    }
    if (proxy.expires_at && new Date(proxy.expires_at).getTime() < Date.now()) {
      return {allowed: false, reason: 'Proxy authority has expired.'};
    }
    if (requiredProxyScope === 'VIEW_AND_BOOK' && proxy.scope !== 'VIEW_AND_BOOK') {
      return {
        allowed: false,
        reason: `Proxy scope (${proxy.scope}) does not permit booking or changing appointments.`,
      };
    }
    if (
      requiredProxyScope === 'MESSAGES_ONLY' &&
      proxy.scope !== 'MESSAGES_ONLY' &&
      proxy.scope !== 'VIEW_AND_BOOK'
    ) {
      return {
        allowed: false,
        reason: `Proxy scope (${proxy.scope}) does not permit message access.`,
      };
    }
    return {allowed: true, viaProxy: true};
  }

  return {allowed: false, reason: 'Patients cannot access other patients’ records.'};
}
