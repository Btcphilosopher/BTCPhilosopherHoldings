import {randomBytes} from 'node:crypto';
import type {AppDatabase} from './db.js';

export interface WorkerTickResult {
  expiredHoldsReleased: number;
  queuedNotificationsProcessed: number;
  failedNotificationsRouted: number;
}

/**
 * Deterministic background worker pass:
 * 1. Releases expired Held slots back to Available.
 * 2. Processes Queued notifications (handling simulated bounces -> Staff Tasks without cancelling appointments).
 */
export function runBackgroundWorkerPass(appDb: AppDatabase, nowIso = new Date().toISOString()): WorkerTickResult {
  let expiredHoldsReleased = 0;
  let queuedNotificationsProcessed = 0;
  let failedNotificationsRouted = 0;

  appDb.runInTransaction(() => {
    const expired = appDb.db
      .prepare(
        `SELECT id, held_by_patient_id FROM clinic_slots
         WHERE status = 'Held' AND hold_expires_at IS NOT NULL AND hold_expires_at < ?`,
      )
      .all(nowIso) as {id: string; held_by_patient_id: string | null}[];

    if (expired.length > 0) {
      const releaseStmt = appDb.db.prepare(
        `UPDATE clinic_slots
         SET status = 'Available', held_by_patient_id = NULL, held_by_referral_id = NULL, hold_expires_at = NULL
         WHERE id = ?`,
      );
      const auditStmt = appDb.db.prepare(
        `INSERT INTO audit_logs (id, actor_user_id, actor_name, actor_role, action, entity_type, entity_id, patient_id, detail_json, created_at)
         VALUES (?, 'WORKER', 'Background Hold Expiry Worker', 'ADMIN', 'SLOT_HOLD_EXPIRED', 'ClinicSlot', ?, ?, ?, ?)`,
      );

      for (const s of expired) {
        releaseStmt.run(s.id);
        auditStmt.run(
          `AUD-${Date.now()}-${randomBytes(2).toString('hex')}`,
          s.id,
          s.held_by_patient_id,
          JSON.stringify({reason: 'Hold TTL elapsed without booking confirmation'}),
          nowIso,
        );
        expiredHoldsReleased++;
      }
    }

    const queued = appDb.db
      .prepare(
        `SELECT id, patient_id, appointment_id, channel, recipient_address, subject, attempt_count
         FROM notifications
         WHERE status = 'Queued' AND scheduled_for_utc <= ?`,
      )
      .all(nowIso) as {
      id: string;
      patient_id: string;
      appointment_id: string | null;
      channel: string;
      recipient_address: string;
      subject: string;
      attempt_count: number;
    }[];

    for (const n of queued) {
      queuedNotificationsProcessed++;
      const shouldFail =
        n.recipient_address.includes('bounce') ||
        n.recipient_address.includes('unreachable') ||
        n.recipient_address.includes('invalid');

      if (shouldFail) {
        const failReason = `Messaging Adapter: Simulated delivery failure to ${n.channel} endpoint`;
        appDb.db
          .prepare(
            `UPDATE notifications SET status = 'Failed', failure_reason = ?, attempt_count = ? WHERE id = ?`,
          )
          .run(failReason, n.attempt_count + 1, n.id);

        const existingTask = appDb.db
          .prepare(`SELECT id FROM staff_tasks WHERE notification_id = ? AND status = 'Open'`)
          .get(n.id);
        if (!existingTask) {
          appDb.db
            .prepare(
              `INSERT INTO staff_tasks (
                id, task_type, priority, patient_id, appointment_id, notification_id,
                title, description, assigned_role, status, created_at
              ) VALUES (?, 'Failed Communication Follow-up', 'High', ?, ?, ?, ?, ?, 'BOOKING_CLERK', 'Open', ?)`,
            )
            .run(
              `TSK-${Date.now().toString().slice(-5)}-${randomBytes(1).toString('hex')}`,
              n.patient_id,
              n.appointment_id,
              n.id,
              `Follow up failed ${n.channel} notification (${n.id})`,
              `${failReason}. Contact patient via alternative channel. Booking remains active.`,
              nowIso,
            );
        }
        failedNotificationsRouted++;
      } else {
        appDb.db
          .prepare(`UPDATE notifications SET status = 'Delivered', sent_at_utc = ? WHERE id = ?`)
          .run(nowIso, n.id);
      }
    }
  });

  return {expiredHoldsReleased, queuedNotificationsProcessed, failedNotificationsRouted};
}
