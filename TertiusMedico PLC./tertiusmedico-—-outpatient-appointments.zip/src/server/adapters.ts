import {randomBytes} from 'node:crypto';
import type {AppDatabase} from './db.js';
import {recordAudit} from './auth.js';
import type {AuthUser} from './types.js';

export interface AdapterFieldOwnership {
  adapter: string;
  system_name: string;
  authoritative_fields: string[];
  interoperability_profile: string;
  integration_status: 'Simulated Mock Adapter' | 'Boundary Ready';
}

export const ADAPTER_AUTHORITY_MATRIX: readonly AdapterFieldOwnership[] = [
  {
    adapter: 'PAS Adapter',
    system_name: 'Pennine Patient Administration System (Mock)',
    authoritative_fields: ['pas_ref', 'local_address', 'patient_merge_status'],
    interoperability_profile: 'HL7 v2 ADT / NHS Spine PDS Alignment (Prototype Boundary)',
    integration_status: 'Simulated Mock Adapter',
  },
  {
    adapter: 'EPR Adapter',
    system_name: 'Electronic Patient Record (Mock)',
    authoritative_fields: ['epr_ref', 'clinical_outcome_notes', 'investigation_orders'],
    interoperability_profile: 'UK Core FHIR R4 Outpatient Encounter (Unaccredited Prototype)',
    integration_status: 'Simulated Mock Adapter',
  },
  {
    adapter: 'e-RS Referral Adapter',
    system_name: 'NHS e-Referral Service Boundary (Mock)',
    authoritative_fields: ['external_ubrn', 'referral_source', 'received_date', 'gp_letter'],
    interoperability_profile: 'NHS e-RS FHIR API Profile (Mocked — requires NHS Digital onboarding)',
    integration_status: 'Simulated Mock Adapter',
  },
  {
    adapter: 'Identity Adapter',
    system_name: 'NHS Login / NHS CIS2 Boundary (Mock)',
    authoritative_fields: ['identity_assurance_level', 'staff_smartcard_role', 'patient_sub'],
    interoperability_profile: 'OIDC / NHS CIS2 & NHS Login (Prototype Synthetic Directory active)',
    integration_status: 'Simulated Mock Adapter',
  },
  {
    adapter: 'Staff Directory Adapter',
    system_name: 'ESR / Trust Roster Directory (Mock)',
    authoritative_fields: ['clinician_id', 'gmc_or_nmc', 'approved_leave_dates'],
    interoperability_profile: 'Internal Roster REST Boundary',
    integration_status: 'Simulated Mock Adapter',
  },
  {
    adapter: 'Messaging Adapter',
    system_name: 'GOV.UK Notify / NHS App Messaging (Mock)',
    authoritative_fields: ['delivery_receipt', 'bounce_reason', 'sms_template_id'],
    interoperability_profile: 'GOV.UK Notify v2 REST Client Boundary',
    integration_status: 'Simulated Mock Adapter',
  },
  {
    adapter: 'Video Consultation Adapter',
    system_name: 'Attend Anywhere / NHS Video Boundary (Mock)',
    authoritative_fields: ['waiting_area_url', 'session_room_token'],
    interoperability_profile: 'WebRTC Waiting Room Link Boundary',
    integration_status: 'Simulated Mock Adapter',
  },
];

export function ingestExternalEventIdempotent(
  appDb: AppDatabase,
  actor: AuthUser,
  params: {
    adapterName: string;
    direction: 'Inbound' | 'Outbound' | 'Outbound/Sync';
    idempotencyKey: string;
    externalRef: string;
    payloadSummary: string;
    simulateConflict?: boolean;
  },
): {eventId: string; duplicate: boolean; status: string} {
  const existing = appDb.db
    .prepare('SELECT id, status FROM integration_events WHERE idempotency_key = ?')
    .get(params.idempotencyKey) as {id: string; status: string} | undefined;

  if (existing) {
    recordAudit(appDb, actor, 'INTEGRATION_DUPLICATE_IGNORED', 'IntegrationEvent', existing.id, null, {
      adapter_name: params.adapterName,
      idempotency_key: params.idempotencyKey,
    });
    return {eventId: existing.id, duplicate: true, status: existing.status};
  }

  const eventId = `EVT-${Date.now().toString().slice(-5)}-${randomBytes(1).toString('hex').toUpperCase()}`;
  const status = params.simulateConflict ? 'Conflict - Staff Review' : 'Processed';
  const conflictDetail = params.simulateConflict
    ? 'Incoming demographic field differed from authoritative local PAS record; quarantined for staff reconciliation.'
    : null;

  appDb.db
    .prepare(
      `INSERT INTO integration_events (
        id, adapter_name, direction, idempotency_key, external_ref, payload_summary,
        status, retry_count, conflict_detail, created_at, processed_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      eventId,
      params.adapterName,
      params.direction,
      params.idempotencyKey,
      params.externalRef,
      params.payloadSummary,
      status,
      0,
      conflictDetail,
      new Date().toISOString(),
      params.simulateConflict ? null : new Date().toISOString(),
    );

  recordAudit(appDb, actor, 'INTEGRATION_EVENT_INGESTED', 'IntegrationEvent', eventId, null, {
    adapter_name: params.adapterName,
    idempotency_key: params.idempotencyKey,
    status,
  });

  return {eventId, duplicate: false, status};
}
