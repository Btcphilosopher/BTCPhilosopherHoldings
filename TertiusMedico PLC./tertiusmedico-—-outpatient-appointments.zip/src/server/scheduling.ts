import {randomBytes} from 'node:crypto';
import type {AppDatabase} from './db.js';
import {recordAudit} from './auth.js';
import {
  ALLOWED_TRANSITIONS,
  TRANSITION_ROLES,
  type AppointmentState,
  type AuthUser,
} from './types.js';

/**
 * Convert a wall-clock YYYY-MM-DD + HH:MM in Europe/London to an exact UTC ISO string,
 * handling GMT/BST daylight-saving transitions cleanly.
 */
export function londonLocalToUtcIso(dateStr: string, timeStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const [hh, mm] = timeStr.split(':').map(Number);
  const approxUtc = new Date(Date.UTC(y, m - 1, d, hh, mm, 0));

  const fmt = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });

  const parts = fmt.formatToParts(approxUtc);
  const get = (t: string): number => Number(parts.find((p) => p.type === t)?.value ?? '0');
  const londonYear = get('year');
  const londonMonth = get('month');
  const londonDay = get('day');
  const londonHour = get('hour') === 24 ? 0 : get('hour');
  const londonMin = get('minute');

  const renderedAsUtc = Date.UTC(londonYear, londonMonth - 1, londonDay, londonHour, londonMin, 0);
  const offsetMs = renderedAsUtc - approxUtc.getTime();
  return new Date(approxUtc.getTime() - offsetMs).toISOString();
}

export function addMinutesToTimeStr(timeStr: string, mins: number): string {
  const [hh, mm] = timeStr.split(':').map(Number);
  const total = hh * 60 + mm + mins;
  const nh = Math.floor(total / 60) % 24;
  const nm = total % 60;
  return `${String(nh).padStart(2, '0')}:${String(nm).padStart(2, '0')}`;
}

export function timeStrToMinutes(timeStr: string): number {
  const [hh, mm] = timeStr.split(':').map(Number);
  return hh * 60 + mm;
}

export interface ConflictCheckResult {
  hasConflict: boolean;
  reasons: string[];
}

export function checkResourceConflicts(
  appDb: AppDatabase,
  params: {
    startUtc: string;
    endUtc: string;
    slotDate: string;
    clinicianId: string;
    roomId: string;
    patientId?: string;
    requiredEquipment?: string | null;
    excludeAppointmentId?: string;
    excludeSlotId?: string;
  },
): ConflictCheckResult {
  const reasons: string[] = [];

  // 1. Clinician absence check
  const absence = appDb.db
    .prepare(
      `SELECT id, reason FROM staff_absences
       WHERE clinician_id = ? AND start_date <= ? AND end_date >= ?`,
    )
    .get(params.clinicianId, params.slotDate, params.slotDate) as
    | {id: string; reason: string}
    | undefined;
  if (absence) {
    reasons.push(`Clinician is recorded absent on ${params.slotDate} (${absence.reason}).`);
  }

  // 2. Room closure check
  const closure = appDb.db
    .prepare(
      `SELECT id, reason FROM room_closures
       WHERE room_id = ? AND start_date <= ? AND end_date >= ?`,
    )
    .get(params.roomId, params.slotDate, params.slotDate) as
    | {id: string; reason: string}
    | undefined;
  if (closure) {
    reasons.push(`Room is closed/unavailable on ${params.slotDate} (${closure.reason}).`);
  }

  // 3. Overlapping active appointments for Clinician
  const clinicianOverlap = appDb.db
    .prepare(
      `SELECT id, local_start_time, local_end_time FROM appointments
       WHERE clinician_id = ?
         AND state IN ('Booked', 'Confirmed', 'Arrived', 'In progress')
         AND id != ?
         AND scheduled_start_utc < ?
         AND scheduled_end_utc > ?`,
    )
    .get(
      params.clinicianId,
      params.excludeAppointmentId ?? '',
      params.endUtc,
      params.startUtc,
    ) as {id: string; local_start_time: string; local_end_time: string} | undefined;
  if (clinicianOverlap) {
    reasons.push(
      `Clinician already has appointment ${clinicianOverlap.id} (${clinicianOverlap.local_start_time}–${clinicianOverlap.local_end_time}).`,
    );
  }

  // 4. Overlapping active appointments for Room
  const roomOverlap = appDb.db
    .prepare(
      `SELECT id, local_start_time, local_end_time FROM appointments
       WHERE room_id = ?
         AND state IN ('Booked', 'Confirmed', 'Arrived', 'In progress')
         AND id != ?
         AND scheduled_start_utc < ?
         AND scheduled_end_utc > ?`,
    )
    .get(
      params.roomId,
      params.excludeAppointmentId ?? '',
      params.endUtc,
      params.startUtc,
    ) as {id: string; local_start_time: string; local_end_time: string} | undefined;
  if (roomOverlap) {
    reasons.push(
      `Room already occupied by appointment ${roomOverlap.id} (${roomOverlap.local_start_time}–${roomOverlap.local_end_time}).`,
    );
  }

  // 5. Overlapping active appointments for Patient
  if (params.patientId) {
    const patientOverlap = appDb.db
      .prepare(
        `SELECT id, specialty, local_start_time, local_end_time FROM appointments
         WHERE patient_id = ?
           AND state IN ('Booked', 'Confirmed', 'Arrived', 'In progress')
           AND id != ?
           AND scheduled_start_utc < ?
           AND scheduled_end_utc > ?`,
      )
      .get(
        params.patientId,
        params.excludeAppointmentId ?? '',
        params.endUtc,
        params.startUtc,
      ) as {id: string; specialty: string; local_start_time: string; local_end_time: string} | undefined;
    if (patientOverlap) {
      reasons.push(
        `Patient already has an overlapping ${patientOverlap.specialty} appointment (${patientOverlap.id} at ${patientOverlap.local_start_time}–${patientOverlap.local_end_time}).`,
      );
    }
  }

  // 6. Required Equipment availability in room
  if (params.requiredEquipment) {
    const room = appDb.db
      .prepare('SELECT name, equipment_list FROM rooms WHERE id = ?')
      .get(params.roomId) as {name: string; equipment_list: string} | undefined;
    if (room) {
      const equipList = JSON.parse(room.equipment_list) as string[];
      if (!equipList.includes(params.requiredEquipment)) {
        reasons.push(
          `Room ${room.name} does not have required equipment (${params.requiredEquipment}).`,
        );
      }
    }
  }

  return {hasConflict: reasons.length > 0, reasons};
}

export function generateSessionWithSlots(
  appDb: AppDatabase,
  actor: AuthUser,
  params: {
    templateId: string;
    sessionDate: string;
    startTime: string;
    endTime: string;
    notes?: string;
  },
): {sessionId: string; slotsCreated: number} {
  const tpl = appDb.db
    .prepare('SELECT * FROM clinic_templates WHERE id = ? AND active = 1')
    .get(params.templateId) as
    | {
        id: string;
        name: string;
        specialty: string;
        site_id: string;
        room_id: string;
        clinician_id: string;
        supporting_staff_role: string | null;
        modality: string;
        appointment_types_json: string;
        slot_length_minutes: number;
        buffer_minutes: number;
        break_start_time: string | null;
        break_end_time: string | null;
        required_equipment: string | null;
        protected_urgent_slots: number;
        current_version: number;
      }
    | undefined;

  if (!tpl) {
    throw new Error('Clinic template not found.');
  }

  // Verify no absence or closure blocks generation
  const absence = appDb.db
    .prepare(
      'SELECT reason FROM staff_absences WHERE clinician_id = ? AND start_date <= ? AND end_date >= ?',
    )
    .get(tpl.clinician_id, params.sessionDate, params.sessionDate) as {reason: string} | undefined;
  if (absence) {
    throw new Error(`Cannot generate bookable session: clinician absent (${absence.reason}).`);
  }

  const closure = appDb.db
    .prepare(
      'SELECT reason FROM room_closures WHERE room_id = ? AND start_date <= ? AND end_date >= ?',
    )
    .get(tpl.room_id, params.sessionDate, params.sessionDate) as {reason: string} | undefined;
  if (closure) {
    throw new Error(`Cannot generate bookable session: room closed (${closure.reason}).`);
  }

  const sessionId = `SES-${tpl.specialty.slice(0, 4).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
  const apptTypes = JSON.parse(tpl.appointment_types_json) as string[];
  const defaultType = apptTypes[0] ?? 'New Outpatient';

  let slotsCreated = 0;
  appDb.runInTransaction(() => {
    appDb.db
      .prepare(
        `INSERT INTO clinic_sessions (
          id, template_id, template_version, specialty, site_id, room_id, clinician_id,
          supporting_staff, session_date, start_time, end_time, modality, required_equipment, status, timezone, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        sessionId,
        tpl.id,
        tpl.current_version,
        tpl.specialty,
        tpl.site_id,
        tpl.room_id,
        tpl.clinician_id,
        tpl.supporting_staff_role,
        params.sessionDate,
        params.startTime,
        params.endTime,
        tpl.modality,
        tpl.required_equipment,
        'Active',
        'Europe/London',
        params.notes ?? `Generated from ${tpl.name} v${tpl.current_version}`,
      );

    let cursor = timeStrToMinutes(params.startTime);
    const endMins = timeStrToMinutes(params.endTime);
    const breakStart = tpl.break_start_time ? timeStrToMinutes(tpl.break_start_time) : null;
    const breakEnd = tpl.break_end_time ? timeStrToMinutes(tpl.break_end_time) : null;

    let idx = 0;
    const insertSlot = appDb.db.prepare(
      `INSERT INTO clinic_slots (
        id, session_id, specialty, site_id, room_id, clinician_id, slot_date,
        start_time, end_time, start_utc, end_utc, duration_minutes, modality,
        appointment_type, required_equipment, is_protected_urgent, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    );

    while (cursor + tpl.slot_length_minutes <= endMins) {
      const slotEnd = cursor + tpl.slot_length_minutes;
      if (breakStart !== null && breakEnd !== null && cursor < breakEnd && slotEnd > breakStart) {
        cursor = breakEnd;
        continue;
      }
      const st = `${String(Math.floor(cursor / 60)).padStart(2, '0')}:${String(cursor % 60).padStart(2, '0')}`;
      const et = `${String(Math.floor(slotEnd / 60)).padStart(2, '0')}:${String(slotEnd % 60).padStart(2, '0')}`;
      const startUtc = londonLocalToUtcIso(params.sessionDate, st);
      const endUtc = londonLocalToUtcIso(params.sessionDate, et);
      const isProtected = idx < tpl.protected_urgent_slots ? 1 : 0;

      insertSlot.run(
        `SLT-${sessionId.slice(-6)}-${idx + 1}`,
        sessionId,
        tpl.specialty,
        tpl.site_id,
        tpl.room_id,
        tpl.clinician_id,
        params.sessionDate,
        st,
        et,
        startUtc,
        endUtc,
        tpl.slot_length_minutes,
        tpl.modality,
        apptTypes[idx % apptTypes.length] ?? defaultType,
        tpl.required_equipment,
        isProtected,
        'Available',
      );
      slotsCreated++;
      idx++;
      cursor = slotEnd + tpl.buffer_minutes;
    }

    recordAudit(appDb, actor, 'CLINIC_SESSION_GENERATED', 'ClinicSession', sessionId, null, {
      template_id: tpl.id,
      template_version: tpl.current_version,
      session_date: params.sessionDate,
      slots_created: slotsCreated,
    });
  });

  return {sessionId, slotsCreated};
}

export function holdSlotTransactional(
  appDb: AppDatabase,
  actor: AuthUser,
  slotId: string,
  patientId: string,
  referralId: string,
): {slotId: string; holdExpiresAt: string} {
  const holdExpiresAt = new Date(Date.now() + 10 * 60_000).toISOString();

  return appDb.runInTransaction(() => {
    // Expire stale holds on this slot first
    appDb.db
      .prepare(
        `UPDATE clinic_slots
         SET status = 'Available', held_by_patient_id = NULL, held_by_referral_id = NULL, hold_expires_at = NULL
         WHERE id = ? AND status = 'Held' AND hold_expires_at < ?`,
      )
      .run(slotId, new Date().toISOString());

    const slot = appDb.db
      .prepare('SELECT * FROM clinic_slots WHERE id = ?')
      .get(slotId) as
      | {
          id: string;
          session_id: string;
          specialty: string;
          site_id: string;
          room_id: string;
          clinician_id: string;
          slot_date: string;
          start_time: string;
          end_time: string;
          start_utc: string;
          end_utc: string;
          duration_minutes: number;
          modality: string;
          appointment_type: string;
          required_equipment: string | null;
          is_protected_urgent: number;
          status: string;
          held_by_patient_id: string | null;
        }
      | undefined;

    if (!slot) {
      const err = new Error('Selected slot does not exist.') as Error & {statusCode?: number};
      err.statusCode = 404;
      throw err;
    }

    if (slot.status !== 'Available') {
      const err = new Error(
        `This slot (${slot.slot_date} at ${slot.start_time}) is no longer available (current status: ${slot.status}). Another patient or staff member selected it first.`,
      ) as Error & {statusCode?: number};
      err.statusCode = 409;
      throw err;
    }

    const referral = appDb.db
      .prepare('SELECT * FROM referrals WHERE id = ? AND patient_id = ?')
      .get(referralId, patientId) as
      | {
          id: string;
          specialty: string;
          review_status: string;
          clinical_priority: string | null;
          duration_minutes: number;
          required_equipment: string | null;
          booking_window_start: string | null;
          booking_window_end: string | null;
        }
      | undefined;

    if (!referral) {
      const err = new Error('Matching referral not found for patient.') as Error & {statusCode?: number};
      err.statusCode = 404;
      throw err;
    }
    if (referral.review_status !== 'Accepted') {
      const err = new Error(
        'Referral must complete authorised clinical review before slots can be held.',
      ) as Error & {statusCode?: number};
      err.statusCode = 400;
      throw err;
    }
    if (referral.specialty !== slot.specialty) {
      const err = new Error(
        `Slot specialty (${slot.specialty}) is incompatible with reviewed referral (${referral.specialty}).`,
      ) as Error & {statusCode?: number};
      err.statusCode = 400;
      throw err;
    }
    if (slot.duration_minutes < referral.duration_minutes) {
      const err = new Error(
        `Slot duration (${slot.duration_minutes} min) is shorter than clinical requirement (${referral.duration_minutes} min).`,
      ) as Error & {statusCode?: number};
      err.statusCode = 400;
      throw err;
    }
    if (
      referral.required_equipment &&
      slot.required_equipment !== referral.required_equipment
    ) {
      const err = new Error(
        `Slot does not include required equipment (${referral.required_equipment}).`,
      ) as Error & {statusCode?: number};
      err.statusCode = 400;
      throw err;
    }
    if (
      slot.is_protected_urgent === 1 &&
      referral.clinical_priority !== 'Urgent' &&
      actor.role === 'PATIENT'
    ) {
      const err = new Error(
        'This slot is protected capacity reserved for urgent referrals.',
      ) as Error & {statusCode?: number};
      err.statusCode = 403;
      throw err;
    }

    const conflict = checkResourceConflicts(appDb, {
      startUtc: slot.start_utc,
      endUtc: slot.end_utc,
      slotDate: slot.slot_date,
      clinicianId: slot.clinician_id,
      roomId: slot.room_id,
      patientId,
      requiredEquipment: referral.required_equipment,
    });
    if (conflict.hasConflict) {
      const err = new Error(conflict.reasons.join(' ')) as Error & {statusCode?: number};
      err.statusCode = 409;
      throw err;
    }

    const updated = appDb.db
      .prepare(
        `UPDATE clinic_slots
         SET status = 'Held', held_by_patient_id = ?, held_by_referral_id = ?, hold_expires_at = ?
         WHERE id = ? AND status = 'Available'`,
      )
      .run(patientId, referralId, holdExpiresAt, slotId);

    if (updated.changes !== 1) {
      const err = new Error('Slot was claimed concurrently by another user.') as Error & {statusCode?: number};
      err.statusCode = 409;
      throw err;
    }

    recordAudit(appDb, actor, 'SLOT_HELD', 'ClinicSlot', slotId, patientId, {
      referral_id: referralId,
      hold_expires_at: holdExpiresAt,
    });

    return {slotId, holdExpiresAt};
  });
}

export function confirmBookingTransactional(
  appDb: AppDatabase,
  actor: AuthUser,
  params: {
    slotId: string;
    patientId: string;
    referralId: string;
    bookedChannel: string;
    preparationInstructions?: string;
    rescheduleFromAppointmentId?: string;
    rescheduleReason?: string;
  },
): {appointmentId: string} {
  return appDb.runInTransaction(() => {
    const nowIso = new Date().toISOString();

    const slot = appDb.db
      .prepare('SELECT * FROM clinic_slots WHERE id = ?')
      .get(params.slotId) as
      | {
          id: string;
          session_id: string;
          specialty: string;
          site_id: string;
          room_id: string;
          clinician_id: string;
          slot_date: string;
          start_time: string;
          end_time: string;
          start_utc: string;
          end_utc: string;
          duration_minutes: number;
          modality: string;
          appointment_type: string;
          required_equipment: string | null;
          status: string;
          held_by_patient_id: string | null;
          hold_expires_at: string | null;
        }
      | undefined;

    if (!slot) {
      const err = new Error('Slot not found.') as Error & {statusCode?: number};
      err.statusCode = 404;
      throw err;
    }

    // Check hold validity or atomic available slot claim
    if (slot.status === 'Held') {
      if (slot.held_by_patient_id !== params.patientId) {
        const err = new Error('This slot is currently held by another patient.') as Error & {statusCode?: number};
        err.statusCode = 409;
        throw err;
      }
      if (slot.hold_expires_at && slot.hold_expires_at < nowIso) {
        appDb.db
          .prepare(
            `UPDATE clinic_slots SET status = 'Available', held_by_patient_id = NULL, held_by_referral_id = NULL, hold_expires_at = NULL WHERE id = ?`,
          )
          .run(slot.id);
        const err = new Error('Your slot hold expired before confirmation. Please select an available time.') as Error & {statusCode?: number};
        err.statusCode = 409;
        throw err;
      }
    } else if (slot.status !== 'Available') {
      const err = new Error(
        `Slot is already ${slot.status}. Overbooking is disabled.`,
      ) as Error & {statusCode?: number};
      err.statusCode = 409;
      throw err;
    }

    const referral = appDb.db
      .prepare('SELECT * FROM referrals WHERE id = ? AND patient_id = ?')
      .get(params.referralId, params.patientId) as
      | {
          id: string;
          specialty: string;
          review_status: string;
          appointment_type: string;
          duration_minutes: number;
          required_equipment: string | null;
        }
      | undefined;

    if (!referral || referral.review_status !== 'Accepted') {
      const err = new Error('Referral must be reviewed and accepted before booking.') as Error & {statusCode?: number};
      err.statusCode = 400;
      throw err;
    }
    if (referral.specialty !== slot.specialty || slot.duration_minutes < referral.duration_minutes) {
      const err = new Error('Slot does not match clinical referral requirements.') as Error & {statusCode?: number};
      err.statusCode = 400;
      throw err;
    }

    const patient = appDb.db
      .prepare(
        'SELECT id, full_name, phone, email, preferred_contact_channel, interpreter_required, interpreter_language, accessibility_requirements FROM patients WHERE id = ?',
      )
      .get(params.patientId) as {
      id: string;
      full_name: string;
      phone: string;
      email: string;
      preferred_contact_channel: string;
      interpreter_required: number;
      interpreter_language: string | null;
      accessibility_requirements: string;
    };

    const conflict = checkResourceConflicts(appDb, {
      startUtc: slot.start_utc,
      endUtc: slot.end_utc,
      slotDate: slot.slot_date,
      clinicianId: slot.clinician_id,
      roomId: slot.room_id,
      patientId: params.patientId,
      requiredEquipment: referral.required_equipment,
      excludeAppointmentId: params.rescheduleFromAppointmentId,
    });
    if (conflict.hasConflict) {
      const err = new Error(conflict.reasons.join(' ')) as Error & {statusCode?: number};
      err.statusCode = 409;
      throw err;
    }

    const waitingList = appDb.db
      .prepare('SELECT id FROM waiting_list_entries WHERE referral_id = ?')
      .get(params.referralId) as {id: string} | undefined;

    const appointmentId = `APT-${Date.now().toString().slice(-5)}${randomBytes(1).toString('hex').toUpperCase()}`;
    const defaultPrep =
      params.preparationInstructions ??
      (slot.specialty === 'Cardiology'
        ? 'Please bring a list of all current medications and arrive 10 minutes early for your ECG.'
        : slot.specialty === 'Ophthalmology'
          ? 'Do not drive to your appointment as dilating eye drops may be used.'
          : 'Please bring your appointment confirmation reference and any relevant medication list.');

    // Atomically mark slot booked
    const slotRes = appDb.db
      .prepare(
        `UPDATE clinic_slots
         SET status = 'Booked', held_by_patient_id = NULL, held_by_referral_id = NULL, hold_expires_at = NULL
         WHERE id = ? AND (status = 'Available' OR (status = 'Held' AND held_by_patient_id = ?))`,
      )
      .run(slot.id, params.patientId);

    if (slotRes.changes !== 1) {
      const err = new Error('Concurrent booking detected; slot is no longer free.') as Error & {statusCode?: number};
      err.statusCode = 409;
      throw err;
    }

    appDb.db
      .prepare(
        `INSERT INTO appointments (
          id, patient_id, referral_id, waiting_list_id, slot_id, session_id,
          site_id, room_id, clinician_id, specialty, appointment_type, modality,
          scheduled_start_utc, scheduled_end_utc, local_date, local_start_time, local_end_time,
          state, interpreter_language, assistance_notes, preparation_instructions,
          rescheduled_from_id, reschedule_reason, booked_channel, booked_by_user_id, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        appointmentId,
        params.patientId,
        params.referralId,
        waitingList?.id ?? null,
        slot.id,
        slot.session_id,
        slot.site_id,
        slot.room_id,
        slot.clinician_id,
        slot.specialty,
        referral.appointment_type,
        slot.modality,
        slot.start_utc,
        slot.end_utc,
        slot.slot_date,
        slot.start_time,
        slot.end_time,
        'Booked',
        patient.interpreter_required ? patient.interpreter_language : null,
        patient.accessibility_requirements,
        defaultPrep,
        params.rescheduleFromAppointmentId ?? null,
        params.rescheduleReason ?? null,
        params.bookedChannel,
        actor.id,
        nowIso,
        nowIso,
      );

    // If rescheduling from an old appointment, link and transition old appointment + release old slot
    if (params.rescheduleFromAppointmentId) {
      const oldAppt = appDb.db
        .prepare('SELECT id, slot_id FROM appointments WHERE id = ?')
        .get(params.rescheduleFromAppointmentId) as {id: string; slot_id: string} | undefined;
      if (oldAppt) {
        appDb.db
          .prepare(
            `UPDATE appointments SET state = 'Rescheduled', rescheduled_to_id = ?, reschedule_reason = ?, updated_at = ? WHERE id = ?`,
          )
          .run(
            appointmentId,
            params.rescheduleReason ?? 'Rescheduled',
            nowIso,
            oldAppt.id,
          );
        appDb.db
          .prepare(
            `UPDATE clinic_slots SET status = 'Available' WHERE id = ? AND status = 'Booked'`,
          )
          .run(oldAppt.slot_id);
        appDb.db
          .prepare(
            `UPDATE affected_appointments_queue SET status = 'Resolved', resolution_notes = ?, resolved_by = ?, resolved_at = ? WHERE appointment_id = ? AND status = 'Pending Review'`,
          )
          .run(
            `Rescheduled to ${appointmentId}`,
            actor.display_name,
            nowIso,
            oldAppt.id,
          );
      }
    }

    // Update referral & waiting list status (never changing original_joined_at)
    appDb.db
      .prepare(`UPDATE referrals SET administrative_status = 'Appointment Booked' WHERE id = ?`)
      .run(params.referralId);
    if (waitingList) {
      appDb.db
        .prepare(`UPDATE waiting_list_entries SET status = 'Booked' WHERE id = ?`)
        .run(waitingList.id);
    }

    // Queue confirmation notification (non-sensitive content!)
    const site = appDb.db
      .prepare('SELECT name FROM sites WHERE id = ?')
      .get(slot.site_id) as {name: string};
    const notifId = `NTF-${Date.now().toString().slice(-6)}-${randomBytes(1).toString('hex')}`;
    const channel = patient.preferred_contact_channel;
    const recipient =
      channel === 'SMS' || channel === 'Telephone'
        ? patient.phone
        : channel === 'Email'
          ? patient.email
          : `Portal Account: ${patient.full_name}`;

    appDb.db
      .prepare(
        `INSERT INTO notifications (
          id, patient_id, appointment_id, channel, message_type, recipient_address,
          subject, body_redacted, status, attempt_count, scheduled_for_utc, sent_at_utc, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        notifId,
        params.patientId,
        appointmentId,
        channel,
        params.rescheduleFromAppointmentId ? 'Rescheduling Notice' : 'Confirmation',
        recipient,
        params.rescheduleFromAppointmentId
          ? `Appointment Rescheduled (${appointmentId})`
          : `Appointment Confirmed (${appointmentId})`,
        `Your ${slot.specialty} outpatient appointment at ${site.name} is booked for ${slot.slot_date} at ${slot.start_time}. Preparation: ${defaultPrep} Note: Portal messaging is not an emergency service.`,
        'Delivered',
        1,
        nowIso,
        nowIso,
        nowIso,
      );

    recordAudit(
      appDb,
      actor,
      params.rescheduleFromAppointmentId ? 'APPOINTMENT_RESCHEDULED' : 'APPOINTMENT_BOOKED',
      'Appointment',
      appointmentId,
      params.patientId,
      {
        referral_id: params.referralId,
        slot_id: slot.id,
        local_date: slot.slot_date,
        local_start_time: slot.start_time,
        rescheduled_from_id: params.rescheduleFromAppointmentId ?? null,
        reschedule_reason: params.rescheduleReason ?? null,
      },
    );

    return {appointmentId};
  });
}

export function transitionAppointmentState(
  appDb: AppDatabase,
  actor: AuthUser,
  appointmentId: string,
  targetState: AppointmentState,
  reason?: string,
): {previousState: AppointmentState; newState: AppointmentState} {
  return appDb.runInTransaction(() => {
    const appt = appDb.db
      .prepare('SELECT * FROM appointments WHERE id = ?')
      .get(appointmentId) as
      | {
          id: string;
          patient_id: string;
          referral_id: string;
          waiting_list_id: string | null;
          slot_id: string;
          specialty: string;
          state: AppointmentState;
          local_date: string;
          local_start_time: string;
        }
      | undefined;

    if (!appt) {
      const err = new Error('Appointment not found.') as Error & {statusCode?: number};
      err.statusCode = 404;
      throw err;
    }

    const allowedNext = ALLOWED_TRANSITIONS[appt.state] ?? [];
    if (!allowedNext.includes(targetState)) {
      const err = new Error(
        `Invalid appointment state transition: cannot move from '${appt.state}' to '${targetState}'.`,
      ) as Error & {statusCode?: number};
      err.statusCode = 400;
      throw err;
    }

    const allowedRoles = TRANSITION_ROLES[targetState] ?? [];
    if (!allowedRoles.includes(actor.role)) {
      const err = new Error(
        `Role '${actor.role}' is not permitted to transition appointment to '${targetState}'.`,
      ) as Error & {statusCode?: number};
      err.statusCode = 403;
      throw err;
    }

    const nowIso = new Date().toISOString();
    const arrivalTime = targetState === 'Arrived' ? nowIso : undefined;

    if (arrivalTime) {
      appDb.db
        .prepare('UPDATE appointments SET state = ?, arrival_time_utc = ?, updated_at = ? WHERE id = ?')
        .run(targetState, arrivalTime, nowIso, appointmentId);
      appDb.db
        .prepare(`UPDATE referrals SET administrative_status = 'Attendance Recorded' WHERE id = ?`)
        .run(appt.referral_id);
    } else {
      appDb.db
        .prepare('UPDATE appointments SET state = ?, updated_at = ? WHERE id = ?')
        .run(targetState, nowIso, appointmentId);
    }

    // If cancelled, release slot AND preserve waiting list entry + original_joined_at!
    if (targetState === 'Cancelled by patient' || targetState === 'Cancelled by provider') {
      appDb.db
        .prepare(`UPDATE clinic_slots SET status = 'Available' WHERE id = ?`)
        .run(appt.slot_id);

      // Preserve waiting list entry & original_joined_at!
      if (appt.waiting_list_id) {
        appDb.db
          .prepare(
            `UPDATE waiting_list_entries
             SET status = 'Active', notes = COALESCE(notes, '') || ?
             WHERE id = ?`,
          )
          .run(
            ` | Preserved after ${targetState} (${nowIso.slice(0, 10)}${reason ? `: ${reason}` : ''})`,
            appt.waiting_list_id,
          );
      }
      appDb.db
        .prepare(`UPDATE referrals SET administrative_status = 'On Waiting List' WHERE id = ?`)
        .run(appt.referral_id);

      // Send cancellation notice
      const patient = appDb.db
        .prepare('SELECT full_name, preferred_contact_channel, phone, email FROM patients WHERE id = ?')
        .get(appt.patient_id) as {
        full_name: string;
        preferred_contact_channel: string;
        phone: string;
        email: string;
      };
      const notifId = `NTF-${Date.now().toString().slice(-6)}-${randomBytes(1).toString('hex')}`;
      appDb.db
        .prepare(
          `INSERT INTO notifications (
            id, patient_id, appointment_id, channel, message_type, recipient_address,
            subject, body_redacted, status, attempt_count, scheduled_for_utc, sent_at_utc, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .run(
          notifId,
          appt.patient_id,
          appointmentId,
          patient.preferred_contact_channel,
          'Cancellation Notice',
          patient.preferred_contact_channel === 'Email' ? patient.email : patient.phone,
          `Appointment Cancelled (${appointmentId})`,
          `Your ${appt.specialty} appointment on ${appt.local_date} at ${appt.local_start_time} has been cancelled (${targetState}). Your referral remains open on our waiting list.`,
          'Delivered',
          1,
          nowIso,
          nowIso,
          nowIso,
        );
    }

    recordAudit(appDb, actor, 'APPOINTMENT_STATE_CHANGED', 'Appointment', appointmentId, appt.patient_id, {
      previous_state: appt.state,
      new_state: targetState,
      reason: reason ?? null,
    });

    return {previousState: appt.state, newState: targetState};
  });
}

export function flagSessionImpacted(
  appDb: AppDatabase,
  actor: AuthUser,
  sessionId: string,
  triggerType: string,
  triggerReason: string,
): {affectedCount: number} {
  return appDb.runInTransaction(() => {
    const nowIso = new Date().toISOString();
    appDb.db
      .prepare('UPDATE clinic_sessions SET status = ?, notes = ? WHERE id = ?')
      .run(`Impacted - ${triggerType}`, triggerReason, sessionId);

    // Block unbooked slots in this session
    appDb.db
      .prepare(
        `UPDATE clinic_slots SET status = ? WHERE session_id = ? AND status IN ('Available', 'Held')`,
      )
      .run(`Unavailable - ${triggerType}`, sessionId);

    const booked = appDb.db
      .prepare(
        `SELECT id, patient_id, referral_id FROM appointments
         WHERE session_id = ? AND state IN ('Booked', 'Confirmed')`,
      )
      .all(sessionId) as {id: string; patient_id: string; referral_id: string}[];

    let affectedCount = 0;
    for (const appt of booked) {
      const existing = appDb.db
        .prepare(
          `SELECT id FROM affected_appointments_queue WHERE appointment_id = ? AND status = 'Pending Review'`,
        )
        .get(appt.id);
      if (!existing) {
        const afqId = `AFQ-${Date.now().toString().slice(-5)}-${randomBytes(1).toString('hex')}`;
        appDb.db
          .prepare(
            `INSERT INTO affected_appointments_queue (id, appointment_id, session_id, patient_id, trigger_type, trigger_reason, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, 'Pending Review', ?)`,
          )
          .run(afqId, appt.id, sessionId, appt.patient_id, triggerType, triggerReason, nowIso);

        const tskId = `TSK-${Date.now().toString().slice(-5)}-${randomBytes(1).toString('hex')}`;
        appDb.db
          .prepare(
            `INSERT INTO staff_tasks (
              id, task_type, priority, patient_id, referral_id, appointment_id,
              title, description, assigned_role, status, created_at
            ) VALUES (?, 'Affected Clinic Reschedule', 'High', ?, ?, ?, ?, ?, 'BOOKING_CLERK', 'Open', ?)`,
          )
          .run(
            tskId,
            appt.patient_id,
            appt.referral_id,
            appt.id,
            `Review affected booking ${appt.id} (${triggerType})`,
            triggerReason,
            nowIso,
          );
        affectedCount++;
      }
    }

    recordAudit(appDb, actor, 'CLINIC_SESSION_IMPACTED', 'ClinicSession', sessionId, null, {
      trigger_type: triggerType,
      trigger_reason: triggerReason,
      affected_bookings_queued: affectedCount,
    });

    return {affectedCount};
  });
}
