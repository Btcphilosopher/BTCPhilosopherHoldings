import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {AppDatabase} from './server/db.js';
import {createApiRouter} from './server/routes.js';
import {runBackgroundWorkerPass} from './server/worker.js';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

// Initialize persistent SQLite database and seed Pennine Outpatient Centre demo dataset
const appDb = new AppDatabase();
appDb.seedPennineDemoIfEmpty();

// Mount REST API under /api
app.use('/api', createApiRouter(appDb));

// Background worker for hold expiry & queued notifications (every 30s)
const globalState = globalThis as unknown as {__tertiusWorkerStarted?: boolean};
if (!globalState.__tertiusWorkerStarted) {
  globalState.__tertiusWorkerStarted = true;
  setInterval(() => {
    try {
      runBackgroundWorkerPass(appDb);
    } catch (err) {
      console.error('Background worker pass error:', err instanceof Error ? err.message : 'unknown');
    }
  }, 30_000).unref();
}

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`TERTIUSMEDICO Express SSR server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
