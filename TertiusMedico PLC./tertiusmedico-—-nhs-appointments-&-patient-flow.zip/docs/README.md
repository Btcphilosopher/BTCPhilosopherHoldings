# TERTIUSMEDICO — Pennine University Hospital Demonstrator

> **Important Prototype Notice:** TERTIUSMEDICO is an independent healthcare scheduling and patient flow prototype using synthetic patients, staff, and hospital sites. It carries **no NHS endorsement, clinical certification, or live integration** with NHS Spine, PDS, e-RS, PAS, EPR, or NHS Notify.

## 1. Implemented vs Simulated vs Adapter-Ready vs Deferred Capabilities

| Capability Area | Status | Notes |
|---|---|---|
| Relational scheduling & audit DB | **Implemented** | SQLite (`node:sqlite`, WAL mode) with versioned SQL migrations (`src/server/db/migrations.ts`) |
| Patient & Staff RBAC + Proxy Scoping | **Implemented** | Server-verified Bearer sessions, patient isolation, verified vs pending proxy scope checks, clinician-only priority triage |
| Deterministic Scheduling & Slot Concurrency | **Implemented** | Hard constraints vs preferences, conflict explanations, transactional `BEGIN IMMEDIATE` holds, background hold expiry worker |
| Appointment Lifecycle & Waiting List Separation | **Implemented** | Explicit state transitions, linked rescheduling, waiting-list preservation with immutable `original_rtt_clock_start` |
| Versioned Clinic Templates & Rota Absence Impact | **Implemented** | Controlled template versioning without silent booking changes; absence queues affected patients without silent cancellations |
| Inpatient Planned Admissions & Ward 4B Beds | **Implemented** | Source & freshness tracking, Maintenance Closed & Infection Control states, conflict detection & resolution |
| Real-time Operational Sync | **Implemented** | Server-Sent Events (`/api/events`) pushing live updates across connected browser sessions |
| Hash-Chained Audit Trail | **Implemented** | SHA-256 chained `audit_logs` with sensitive field redaction and chain integrity verification |
| External PAS / EPR / e-RS / Messaging / Video / Calendar | **Simulated** | Typed adapters (`src/server/services/adapters.ts`) with idempotency keys, lock-screen safe previews, and failure simulation |
| Live NHS Spine CIS2 / PDS / e-RS / Statutory RTT Returns | **Deferred** | Requires organisational onboarding, DCB0129/DCB0160 clinical safety sign-off, DSPT, and DTAC |

## 2. Running Locally

```bash
npm install
npm run dev      # Starts Angular 21 SSR + Express API on http://localhost:3000
npx vitest run   # Runs the 13-scenario scheduling, security, and workflow test suite
```

## 3. Reference Infrastructure Templates

See `docs/API.md`, `docs/HAZARD_LOG.md`, `docs/docker-compose.yml`, and `docs/postgres_reference_schema.sql` for API documentation, safety hazard analysis, and PostgreSQL/Docker reference configuration.
