# Prototype Clinical Safety & Information Governance Hazard Log

**Jurisdiction & Organisational Context (Pre-Deployment Scoping):**  
Before any real-world deployment in England, the deploying NHS Trust must appoint a qualified **Clinical Safety Officer (CSO)** to establish a DCB0129 / DCB0160 Safety Case, alongside **Caldicott Guardian**, **SIRO**, **Data Protection Officer (UK GDPR)**, **DTAC**, **DSPT**, and **Equality Act / Accessible Information Standard** sign-offs.

| ID | Hazard Description | Potential Clinical / Governance Impact | Prototype Mitigation | Required Organisational Review |
|---|---|---|---|---|
| **H-01** | Silent automatic merging of duplicate patient records with similar names/DOB | Wrong-patient appointment or clinical correspondence | Duplicate candidates are flagged only; automatic merging is prohibited | Caldicott Guardian & PAS Data Quality Lead |
| **H-02** | Unauthorised non-clinical staff altering referral clinical priority | Delayed urgent assessment or inappropriate prioritisation | Server RBAC enforces clinician-only priority assignment (`403` otherwise) | Clinical Safety Officer (DCB0160) |
| **H-03** | Concurrent booking race condition double-booking a clinic slot | Clinic overcrowding, double-booked patient arrival | SQLite `BEGIN IMMEDIATE` transactional slot holds + `409 Conflict` lock | Outpatient Service Manager & Technical Architect |
| **H-04** | Clinician sickness/leave silently cancelling patient appointments | Patient lost to follow-up without notification | Absence workflow preserves bookings and opens `Staff absence` + `Patient needing contact` queues | Outpatient Service Lead & CSO |
| **H-05** | Estimated inpatient discharge date treated as guaranteed bed availability | Elective surgical cancellation on day of admission | Estimated discharge shown advisory only; closed/IPC/occupied beds block auto-clearance | Chief Nurse & Bed Flow Operations Lead |
| **H-06** | Sensitive clinical text visible on lock-screen SMS/push notifications | Breach of patient confidentiality | Messaging adapter enforces separate redacted `lock_screen_safe_preview` | Data Protection Officer (UK GDPR) |
| **H-07** | Unverified family member accessing patient bookings or messages | Unauthorised disclosure of care details | Proxy relationships require staff verification and explicit scope (`403` if pending) | Information Governance / Caldicott Guardian |
