# TERTIUSMEDICO REST & SSE API Reference

All protected routes require `Authorization: Bearer <token>` obtained from `POST /api/auth/login`.

## Authentication & Session
- `GET /api/auth/personas` — Lists synthetic demonstrator personas (no patient PII).
- `POST /api/auth/login` — Authenticates user (`password` verified via `scrypt` or `demoQuickSignIn` for demonstrator personas) and returns a Bearer token.
- `POST /api/auth/mfa-verify` — Verifies 6-digit MFA code for clinical/staff sessions.
- `POST /api/auth/logout` — Invalidates current Bearer session.
- `GET /api/bootstrap` — Returns hospital sites, authenticated user context, and live 15-step demonstrator checklist state.
- `GET /api/events` — Server-Sent Events (SSE) stream broadcasting non-PII operational change events (`slot:held`, `slot:released`, `appointment:booked`, `rota:absence`, `bed:updated`, etc.).

## Patients, Proxies & Identity
- `GET /api/patients` — Scoped by role (staff see all; patients see self; verified proxies see scoped patients).
- `GET /api/patients/:id` — Returns demographics, accessibility needs, proxy relationships, and read-only EPR readiness summary.
- `PATCH /api/patients/:id` — Updates communication and accessibility preferences.
- `POST /api/patients/:id/verify-nhs` — Runs simulated PAS NHS number verification.
- `POST /api/patients/:id/flag-duplicate` — Logs manual duplicate review without automatically merging patient records.
- `PATCH /api/proxies/:id` — Staff verification/revocation and scope update for proxy relationships.

## Referrals & Waiting Lists
- `GET /api/referrals` / `POST /api/referrals` — List or intake referrals.
- `POST /api/referrals/:id/review` — **Clinician/Admin only (`403` for booking clerks/patients).** Sets review status, clinical priority, booking window, and creates waiting list entry preserving original `received_at`.
- `GET /api/waiting-list` — Lists active/booked waiting-list entries ordered by clinical priority and original RTT clock start.

## Clinics, Slots & Appointments
- `GET /api/clinic-templates` / `POST /api/clinic-templates/:id/amend` — Versioned clinic templates; amendments preserve existing bookings and queue `Clinic change` review tasks.
- `GET /api/slots/eligible?referralId=...` — Deterministic constraint & preference scheduler returning `eligible` slots and `ineligible` slots with conflict reasons.
- `POST /api/slots/:id/hold` / `POST /api/slots/:id/release` — Transactional (`BEGIN IMMEDIATE`) slot hold; returns `409 Conflict` on concurrent contention.
- `GET /api/appointments` / `POST /api/appointments` — Lists or confirms bookings from held/available slots.
- `POST /api/appointments/:id/transition` — Enforces allowed lifecycle transitions and clinical-role checks; cancellations preserve waiting-list entries.
- `POST /api/appointments/:id/reschedule` — Links previous and new appointments and preserves reason/history.
- `POST /api/appointments/:id/follow-up` — Clinician-authorised follow-up referral and waiting-list entry.
- `GET /api/appointments/:id/ics` — Downloads redacted `.ics` calendar entry.

## Rotas, Inpatients, Beds, Work Queues, Comms, Reports & Governance
- `GET /api/rotas`, `POST /api/rotas/:id/publish`, `POST /api/rotas/:id/absence`
- `GET /api/wards-beds`, `PATCH /api/beds/:id`
- `GET /api/admissions`, `POST /api/admissions`, `POST /api/admissions/:id/resolve-conflict`, `POST /api/admissions/:id/transition`
- `GET /api/work-tasks`, `PATCH /api/work-tasks/:id`, `POST /api/work-tasks/batch`
- `GET /api/communications`, `POST /api/communications`, `POST /api/communications/:id/retry`, `POST /api/communications/:id/read`
- `GET /api/reports`, `GET /api/audit`, `GET /api/integrations`, `POST /api/integrations/simulate-event`, `POST /api/demo/reset`
