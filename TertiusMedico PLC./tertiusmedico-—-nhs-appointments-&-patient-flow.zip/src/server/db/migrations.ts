import type {DatabaseSync} from 'node:sqlite';

export interface Migration {
  version: number;
  name: string;
  sql: string;
}

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: '001_initial_schema',
    sql: `
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        applied_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sites (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        short_name TEXT NOT NULL,
        city TEXT NOT NULL,
        postcode TEXT NOT NULL,
        description TEXT NOT NULL,
        image_url TEXT NOT NULL,
        timezone TEXT NOT NULL DEFAULT 'Europe/London'
      );

      CREATE TABLE IF NOT EXISTS staff_users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        display_name TEXT NOT NULL,
        role TEXT NOT NULL,
        specialty TEXT,
        competencies_json TEXT NOT NULL DEFAULT '[]',
        site_id TEXT REFERENCES sites(id),
        contracted_hours INTEGER NOT NULL DEFAULT 37,
        password_hash TEXT NOT NULL,
        mfa_enabled INTEGER NOT NULL DEFAULT 1,
        patient_id TEXT
      );

      CREATE TABLE IF NOT EXISTS patients (
        internal_id TEXT PRIMARY KEY,
        nhs_number TEXT,
        nhs_verification_status TEXT NOT NULL DEFAULT 'unverified',
        given_name TEXT NOT NULL,
        family_name TEXT NOT NULL,
        date_of_birth TEXT NOT NULL,
        gender TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT NOT NULL,
        address TEXT NOT NULL,
        preferred_channel TEXT NOT NULL DEFAULT 'Portal',
        preferred_language TEXT NOT NULL DEFAULT 'English',
        interpreter_required INTEGER NOT NULL DEFAULT 0,
        accessibility_needs_json TEXT NOT NULL DEFAULT '[]',
        source_system_ids_json TEXT NOT NULL DEFAULT '{}',
        duplicate_flag_patient_id TEXT,
        merged_into_id TEXT
      );

      CREATE TABLE IF NOT EXISTS proxy_relationships (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(internal_id),
        proxy_user_id TEXT NOT NULL REFERENCES staff_users(id),
        proxy_name TEXT NOT NULL,
        relationship_type TEXT NOT NULL,
        scope TEXT NOT NULL,
        verified_status TEXT NOT NULL DEFAULT 'pending',
        verified_by TEXT,
        verified_at TEXT
      );

      CREATE TABLE IF NOT EXISTS referrals (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(internal_id),
        specialty TEXT NOT NULL,
        service_name TEXT NOT NULL,
        referral_source TEXT NOT NULL,
        received_at TEXT NOT NULL,
        status TEXT NOT NULL,
        clinical_priority TEXT,
        priority_assigned_by TEXT,
        appointment_requirements TEXT NOT NULL,
        required_duration_mins INTEGER NOT NULL DEFAULT 20,
        required_format TEXT NOT NULL DEFAULT 'In-person',
        required_resources_json TEXT NOT NULL DEFAULT '[]',
        interpreter_language TEXT,
        supporting_docs_json TEXT NOT NULL DEFAULT '[]',
        review_notes TEXT,
        reviewed_at TEXT,
        reviewed_by TEXT,
        booking_window_days INTEGER NOT NULL DEFAULT 28,
        review_history_json TEXT NOT NULL DEFAULT '[]'
      );

      CREATE TABLE IF NOT EXISTS waiting_list_entries (
        id TEXT PRIMARY KEY,
        referral_id TEXT NOT NULL UNIQUE REFERENCES referrals(id),
        patient_id TEXT NOT NULL REFERENCES patients(internal_id),
        specialty TEXT NOT NULL,
        service_name TEXT NOT NULL,
        clinical_priority TEXT NOT NULL,
        original_rtt_clock_start TEXT NOT NULL,
        current_status TEXT NOT NULL DEFAULT 'Active',
        removal_reason TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS clinic_templates (
        id TEXT PRIMARY KEY,
        version INTEGER NOT NULL DEFAULT 1,
        name TEXT NOT NULL,
        specialty TEXT NOT NULL,
        clinic_type TEXT NOT NULL,
        site_id TEXT NOT NULL REFERENCES sites(id),
        room_name TEXT NOT NULL,
        format TEXT NOT NULL,
        clinician_id TEXT NOT NULL REFERENCES staff_users(id),
        support_staff_role TEXT,
        required_equipment_json TEXT NOT NULL DEFAULT '[]',
        default_duration_mins INTEGER NOT NULL DEFAULT 20,
        buffer_mins INTEGER NOT NULL DEFAULT 5,
        break_start TEXT,
        break_end TEXT,
        protected_capacity_count INTEGER NOT NULL DEFAULT 1,
        group_session_enabled INTEGER NOT NULL DEFAULT 0,
        overbooking_enabled INTEGER NOT NULL DEFAULT 0,
        preparation_instructions TEXT NOT NULL DEFAULT '',
        booking_window_days INTEGER NOT NULL DEFAULT 28,
        active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS clinic_sessions (
        id TEXT PRIMARY KEY,
        template_id TEXT NOT NULL REFERENCES clinic_templates(id),
        template_version INTEGER NOT NULL,
        site_id TEXT NOT NULL REFERENCES sites(id),
        room_name TEXT NOT NULL,
        clinician_id TEXT NOT NULL REFERENCES staff_users(id),
        session_date TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Scheduled',
        amendment_note TEXT
      );

      CREATE TABLE IF NOT EXISTS appointment_slots (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL REFERENCES clinic_sessions(id),
        start_iso TEXT NOT NULL,
        end_iso TEXT NOT NULL,
        duration_mins INTEGER NOT NULL,
        format TEXT NOT NULL,
        slot_status TEXT NOT NULL DEFAULT 'Available',
        held_by_user_id TEXT,
        held_until_iso TEXT,
        protected_for_priority INTEGER NOT NULL DEFAULT 0,
        version INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS appointments (
        id TEXT PRIMARY KEY,
        slot_id TEXT REFERENCES appointment_slots(id),
        referral_id TEXT REFERENCES referrals(id),
        waiting_list_id TEXT REFERENCES waiting_list_entries(id),
        patient_id TEXT NOT NULL REFERENCES patients(internal_id),
        specialty TEXT NOT NULL,
        appointment_type TEXT NOT NULL,
        format TEXT NOT NULL,
        site_id TEXT NOT NULL REFERENCES sites(id),
        room_name TEXT NOT NULL,
        clinician_id TEXT NOT NULL REFERENCES staff_users(id),
        start_iso TEXT NOT NULL,
        end_iso TEXT NOT NULL,
        status TEXT NOT NULL,
        cancellation_reason TEXT,
        clinical_outcome TEXT,
        attendance_recorded_at TEXT,
        linked_previous_appointment_id TEXT,
        short_notice_opt_in INTEGER NOT NULL DEFAULT 0,
        interpreter_booked TEXT,
        preparation_instructions TEXT,
        video_join_url TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS staff_rotas (
        id TEXT PRIMARY KEY,
        staff_id TEXT NOT NULL REFERENCES staff_users(id),
        site_id TEXT NOT NULL REFERENCES sites(id),
        rota_date TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        assignment_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Draft',
        travel_buffer_mins INTEGER NOT NULL DEFAULT 0,
        swap_requested_with_staff_id TEXT,
        note TEXT
      );

      CREATE TABLE IF NOT EXISTS wards (
        id TEXT PRIMARY KEY,
        site_id TEXT NOT NULL REFERENCES sites(id),
        name TEXT NOT NULL,
        specialty TEXT NOT NULL,
        total_beds INTEGER NOT NULL,
        capabilities_json TEXT NOT NULL DEFAULT '[]',
        source_system TEXT NOT NULL,
        last_synced_iso TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS beds (
        id TEXT PRIMARY KEY,
        ward_id TEXT NOT NULL REFERENCES wards(id),
        bed_label TEXT NOT NULL,
        capabilities_json TEXT NOT NULL DEFAULT '[]',
        occupancy_status TEXT NOT NULL DEFAULT 'Available',
        current_admission_id TEXT,
        restriction_note TEXT,
        updated_by TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS planned_admissions (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(internal_id),
        referral_id TEXT REFERENCES referrals(id),
        specialty TEXT NOT NULL,
        site_id TEXT NOT NULL REFERENCES sites(id),
        requested_ward_id TEXT NOT NULL REFERENCES wards(id),
        allocated_bed_id TEXT REFERENCES beds(id),
        expected_admission_date TEXT NOT NULL,
        estimated_los_days INTEGER NOT NULL DEFAULT 2,
        estimated_discharge_date TEXT NOT NULL,
        prerequisites_json TEXT NOT NULL DEFAULT '[]',
        pre_admission_appt_id TEXT REFERENCES appointments(id),
        state TEXT NOT NULL DEFAULT 'Planned admission',
        conflict_status TEXT NOT NULL DEFAULT 'Clear',
        conflict_reason TEXT,
        created_by TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS work_tasks (
        id TEXT PRIMARY KEY,
        queue_type TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        patient_id TEXT REFERENCES patients(internal_id),
        owner_staff_id TEXT REFERENCES staff_users(id),
        priority_source TEXT NOT NULL,
        due_iso TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Open',
        resolution_note TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS communications (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(internal_id),
        channel TEXT NOT NULL,
        message_type TEXT NOT NULL,
        subject TEXT NOT NULL,
        body TEXT NOT NULL,
        lock_screen_safe_preview TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Queued',
        failure_reason TEXT,
        accessible_format TEXT NOT NULL DEFAULT 'Standard',
        language TEXT NOT NULL DEFAULT 'English',
        emergency_disclaimer_shown INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        sequence_num INTEGER NOT NULL,
        actor_user_id TEXT NOT NULL,
        actor_role TEXT NOT NULL,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        patient_id TEXT,
        details_json TEXT NOT NULL,
        prev_hash TEXT NOT NULL,
        entry_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS integration_events (
        id TEXT PRIMARY KEY,
        adapter_name TEXT NOT NULL,
        external_event_id TEXT NOT NULL,
        idempotency_key TEXT UNIQUE NOT NULL,
        direction TEXT NOT NULL,
        authoritative_source TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        sync_status TEXT NOT NULL,
        conflict_detail TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES staff_users(id),
        role TEXT NOT NULL,
        patient_id TEXT,
        acting_for_patient_id TEXT,
        proxy_scope TEXT,
        mfa_verified INTEGER NOT NULL DEFAULT 0,
        expires_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS short_notice_list (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL REFERENCES patients(internal_id),
        referral_id TEXT REFERENCES referrals(id),
        specialty TEXT NOT NULL,
        preferred_sites_json TEXT NOT NULL DEFAULT '[]',
        notes TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_slots_session ON appointment_slots(session_id);
      CREATE INDEX IF NOT EXISTS idx_slots_status ON appointment_slots(slot_status);
      CREATE INDEX IF NOT EXISTS idx_appts_patient ON appointments(patient_id);
      CREATE INDEX IF NOT EXISTS idx_appts_clinician ON appointments(clinician_id);
      CREATE INDEX IF NOT EXISTS idx_tasks_status ON work_tasks(status);
      CREATE INDEX IF NOT EXISTS idx_audit_seq ON audit_logs(sequence_num);
    `,
  },
];

export function runMigrations(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const appliedRows = db.prepare('SELECT version FROM schema_migrations').all();
  const applied = new Set(appliedRows.map((r) => Number(r['version'])));

  for (const m of MIGRATIONS) {
    if (!applied.has(m.version)) {
      db.exec('BEGIN IMMEDIATE;');
      try {
        db.exec(m.sql);
        db.prepare(
          'INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)',
        ).run(m.version, m.name, new Date().toISOString());
        db.exec('COMMIT;');
      } catch (err) {
        db.exec('ROLLBACK;');
        throw err;
      }
    }
  }
}
