declare module 'node:sqlite' {
  export interface StatementResultingChanges {
    changes: number | bigint;
    lastInsertRowid: number | bigint;
  }

  export type SqlParam = string | number | bigint | Uint8Array | null;

  export interface StatementSync {
    run(...params: SqlParam[]): StatementResultingChanges;
    get(...params: SqlParam[]): Record<string, unknown> | undefined;
    all(...params: SqlParam[]): Record<string, unknown>[];
  }

  export class DatabaseSync {
    constructor(path: string, options?: {open?: boolean; readOnly?: boolean});
    exec(sql: string): void;
    prepare(sql: string): StatementSync;
    close(): void;
  }
}
