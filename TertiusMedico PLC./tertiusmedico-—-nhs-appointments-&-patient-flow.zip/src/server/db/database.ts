import {createRequire} from 'node:module';
import type {DatabaseSync as DatabaseSyncType} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {dirname, join} from 'node:path';
import {runMigrations} from './migrations';

const require = createRequire(import.meta.url);
const {DatabaseSync} = require('node:sqlite') as {
  DatabaseSync: new (path: string, options?: {open?: boolean; readOnly?: boolean}) => DatabaseSyncType;
};

let singletonDb: DatabaseSyncType | null = null;

export function createDatabase(dbPath: string): DatabaseSyncType {
  if (dbPath !== ':memory:') {
    mkdirSync(dirname(dbPath), {recursive: true});
  }
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');
  runMigrations(db);
  return db;
}

export function getDatabase(): DatabaseSyncType {
  if (!singletonDb) {
    const dbPath =
      process.env['TERTIUS_DB_PATH'] || join(process.cwd(), 'data', 'tertiusmedico.db');
    singletonDb = createDatabase(dbPath);
  }
  return singletonDb;
}
