import {scryptSync, randomBytes} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import {londonLocalToUtcIso} from '../services/scheduler';
import {recordAudit} from '../services/audit';

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const derived = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function addDaysIsoDate(offsetDays: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

export function seedDemonstratorDatabase(db: DatabaseSync, forceReset = false): void {
  const existingSite = db.prepare('SELECT id FROM sites LIMIT 1').get();
  if (existingSite && !forceReset) {
    return;
  }

  if (forceReset) {
    db.exec('PRAGMA foreign_keys = OFF;');
    const tables = [
      'short_notice_list',
      'sessions',
      'integration_events',
      'audit_logs',
      'communications',
      'work_tasks',
      'planned_admissions',
      'beds',
      'wards',
      'staff_rotas',
      'appointments',
      'appointment_slots',
      'clinic_sessions',
      'clinic_templates',
      'waiting_list_entries',
      'referrals',
      'proxy_relationships',
      'patients',
      'staff_users',
      'sites',
    ];
    for (const t of tables) {
      db.exec(`DELETE FROM ${t};`);
    }
    db.exec('PRAGMA foreign_keys = ON;');
  }

  const now = new Date().toISOString();
  const demoPassHash = hashPassword('PennineDemo2026!');

  // 1. Sites
  const insertSite = db.prepare(
    `INSERT INTO sites (id, name, short_name, city, postcode, description, image_url, timezone)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertSite.run(
    'SITE-STA',
    "St Aidan's General Hospital",
    "St Aidan's",
    'Bradford',
    'BD9 6RJ',
    'Regional teaching hospital housing specialist Cardiology, Respiratory Medicine, and acute surgical wards.',
    '/src/assets/images/site_st_aidans_hospital_1795696570679.jpg',
    'Europe/London',
  );
  insertSite.run(
    'SITE-CVI',
    'Calder Valley Royal Infirmary',
    'Calder Valley',
    'Halifax',
    'HX3 0PW',
    'Planned outpatient diagnostics, Orthopaedic clinics, and day-case pre-assessment suites.',
    '/src/assets/images/site_calder_valley_infirmary_1795696570335.jpg',
    'Europe/London',
  );

  // 2. Staff & Portal Users
  const insertUser = db.prepare(
    `INSERT INTO staff_users (id, username, display_name, role, specialty, competencies_json, site_id, contracted_hours, password_hash, mfa_enabled, patient_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertUser.run('USR-PATEL', 'h.patel', 'Dr. Hannah Patel', 'clinician', 'Cardiology', '["ECG Review","Echocardiography","Outpatient Triage"]', 'SITE-STA', 40, demoPassHash, 1, null);
  insertUser.run('USR-FINCH', 'a.finch', 'Mr. Alistair Finch', 'clinician', 'Orthopaedics', '["Joint Assessment","Pre-op Clearance","Elective Surgery"]', 'SITE-CVI', 40, demoPassHash, 1, null);
  insertUser.run('USR-OKAFOR', 'm.okafor', 'Dr. Miriam Okafor', 'clinician', 'Respiratory Medicine', '["Spirometry","Asthma Clinic","COPD Review"]', 'SITE-STA', 37, demoPassHash, 1, null);
  insertUser.run('USR-JENKINS', 's.jenkins', 'Sarah Jenkins', 'booking_clerk', null, '["Patient Scheduling","Interpreter Booking","Waiting List Validation"]', 'SITE-STA', 37, demoPassHash, 1, null);
  insertUser.run('USR-BED', 'd.thornton', 'David Thornton', 'bed_manager', null, '["Bed Allocation","Discharge Flow","Infection Control Escalation"]', 'SITE-STA', 37, demoPassHash, 1, null);
  insertUser.run('USR-ROTA', 'c.whitaker', 'Claire Whitaker', 'service_manager', null, '["Rota Approval","Clinic Templates","Capacity Planning"]', 'SITE-STA', 37, demoPassHash, 1, null);
  insertUser.run('USR-ADMIN', 't.vance', 'Tom Vance', 'admin', null, '["Information Governance","Audit Verification","Adapter Administration"]', 'SITE-STA', 37, demoPassHash, 1, null);

  insertUser.run('USR-PATIENT-ARTHUR', 'arthur.pendelton', 'Arthur Pendelton', 'patient', null, '[]', null, 0, demoPassHash, 0, 'PAT-001');
  insertUser.run('USR-PATIENT-FATIMA', 'fatima.begum', 'Fatima Begum', 'patient', null, '[]', null, 0, demoPassHash, 0, 'PAT-002');
  insertUser.run('USR-PROXY-TARIQ', 'tariq.begum', 'Tariq Begum (Verified Proxy)', 'proxy', null, '[]', null, 0, demoPassHash, 0, 'PAT-002');
  insertUser.run('USR-PROXY-NADIA', 'nadia.begum', 'Nadia Begum (Pending Proxy)', 'proxy', null, '[]', null, 0, demoPassHash, 0, 'PAT-002');

  // 3. Synthetic Patients
  const insertPatient = db.prepare(
    `INSERT INTO patients (
      internal_id, nhs_number, nhs_verification_status, given_name, family_name,
      date_of_birth, gender, phone, email, address, preferred_channel,
      preferred_language, interpreter_required, accessibility_needs_json,
      source_system_ids_json, duplicate_flag_patient_id, merged_into_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertPatient.run(
    'PAT-001',
    '943 476 5919',
    'verified',
    'Arthur',
    'Pendelton',
    '1954-06-14',
    'Male',
    '07700 900142',
    'arthur.pendelton@synthetic.example',
    '18 Wharfedale Terrace, Shipley, BD18 2PL',
    'Portal',
    'English',
    0,
    '["Large print letters (18pt)","Step-free ground floor room"]',
    '{"PAS":"PAS-88412","EPR":"EPR-44019"}',
    null,
    null,
  );
  insertPatient.run(
    'PAT-002',
    '943 582 1104',
    'verified',
    'Fatima',
    'Begum',
    '1968-11-03',
    'Female',
    '07700 900285',
    'fatima.begum@synthetic.example',
    '42 Manningham Lane, Bradford, BD8 7ER',
    'SMS',
    'Sylheti',
    1,
    '["Sylheti interpreter required","Female clinician preferred where possible"]',
    '{"PAS":"PAS-89104","EPR":"EPR-44521"}',
    null,
    null,
  );
  insertPatient.run(
    'PAT-003',
    '943 619 3328',
    'verified',
    'Eleanor',
    'Rigby-Smythe',
    '1949-03-22',
    'Female',
    '07700 900391',
    'eleanor.smythe@synthetic.example',
    '7 Savile Park Road, Halifax, HX1 2EN',
    'Email',
    'English',
    0,
    '["Hearing loop"]',
    '{"PAS":"PAS-90211","EPR":"EPR-45102"}',
    'PAT-003-DUP',
    null,
  );
  insertPatient.run(
    'PAT-003-DUP',
    '943 619 3328',
    'mismatch',
    'Eleanor',
    'Smythe',
    '1949-03-23',
    'Female',
    '07700 900391',
    'e.smythe.old@synthetic.example',
    '7 Savile Pk Rd, Halifax, HX1 2EN',
    'Letter',
    'English',
    0,
    '[]',
    '{"GP_EXTRACT":"GP-7721"}',
    'PAT-003',
    null,
  );
  insertPatient.run(
    'PAT-004',
    '943 704 8812',
    'verified',
    'Marcus',
    'Holloway',
    '1979-08-19',
    'Male',
    '07700 900419',
    'marcus.holloway@synthetic.example',
    '104 Keighley Road, Hebden Bridge, HX7 8AT',
    'SMS',
    'English',
    0,
    '[]',
    '{"PAS":"PAS-91005","EPR":"EPR-46088"}',
    null,
    null,
  );
  insertPatient.run(
    'PAT-005',
    '943 812 4401',
    'unverified',
    'Sanjay',
    'Kulkarni',
    '1985-01-29',
    'Male',
    '07700 900577',
    'sanjay.kulkarni@synthetic.example',
    '9 Aire Street, Leeds, LS1 4HT',
    'Email',
    'English',
    0,
    '[]',
    '{"E_REFERRAL":"ERS-99301"}',
    null,
    null,
  );

  // 4. Proxy Relationships
  const insertProxy = db.prepare(
    `INSERT INTO proxy_relationships (id, patient_id, proxy_user_id, proxy_name, relationship_type, scope, verified_status, verified_by, verified_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertProxy.run(
    'PRX-001',
    'PAT-002',
    'USR-PROXY-TARIQ',
    'Tariq Begum',
    'Son / Nominated Carer',
    'manage_bookings',
    'verified',
    'USR-JENKINS',
    addDaysIsoDate(-14) + 'T10:15:00.000Z',
  );
  insertProxy.run(
    'PRX-002',
    'PAT-002',
    'USR-PROXY-NADIA',
    'Nadia Begum',
    'Daughter (Unverified ID)',
    'view_appointments',
    'pending',
    null,
    null,
  );

  // 5. Referrals
  const insertReferral = db.prepare(
    `INSERT INTO referrals (
      id, patient_id, specialty, service_name, referral_source, received_at,
      status, clinical_priority, priority_assigned_by, appointment_requirements,
      required_duration_mins, required_format, required_resources_json,
      interpreter_language, supporting_docs_json, review_notes, reviewed_at,
      reviewed_by, booking_window_days, review_history_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  const twoDaysAgo = addDaysIsoDate(-2) + 'T09:15:00.000Z';
  const fiveDaysAgo = addDaysIsoDate(-5) + 'T14:20:00.000Z';
  const sevenDaysAgo = addDaysIsoDate(-7) + 'T11:00:00.000Z';

  // Arthur Pendelton: Awaiting review (Step 1-2 demonstrator)
  insertReferral.run(
    'REF-CARD-01',
    'PAT-001',
    'Cardiology',
    'Rapid Access Chest Pain & Arrhythmia Clinic',
    'GP Practice — Shipley Medical Centre (e-RS)',
    twoDaysAgo,
    'Awaiting review',
    null,
    null,
    'New outpatient consultation with 12-lead ECG availability.',
    20,
    'In-person',
    '["12-lead ECG"]',
    null,
    '[{"id":"DOC-101","title":"GP Referral Letter & Recent Bloods","source":"Simulated e-RS","uploaded_at":"' + twoDaysAgo + '"}]',
    null,
    null,
    null,
    28,
    JSON.stringify([
      {
        timestamp: twoDaysAgo,
        actor: 'e-RS Adapter',
        role: 'system',
        action: 'Referral received',
        note: 'Imported from Shipley Medical Centre',
      },
    ]),
  );

  // Fatima Begum: Accepted Respiratory referral requiring Sylheti interpreter
  insertReferral.run(
    'REF-RESP-01',
    'PAT-002',
    'Respiratory Medicine',
    'General Respiratory & Spirometry Outpatients',
    'GP Practice — Manningham Health Centre',
    fiveDaysAgo,
    'Accepted',
    'Soon',
    'USR-OKAFOR',
    'Outpatient assessment with spirometry and Sylheti interpreter.',
    30,
    'In-person',
    '["Spirometry"]',
    'Sylheti',
    '[{"id":"DOC-102","title":"Peak Flow Diary & GP Summary","source":"Simulated e-RS","uploaded_at":"' + fiveDaysAgo + '"}]',
    'Accepted for Soon outpatient clinic with spirometry and Sylheti interpreter.',
    addDaysIsoDate(-3) + 'T15:10:00.000Z',
    'USR-OKAFOR',
    21,
    JSON.stringify([
      {
        timestamp: fiveDaysAgo,
        actor: 'e-RS Adapter',
        role: 'system',
        action: 'Referral received',
        note: 'Requires Sylheti interpreter',
      },
      {
        timestamp: addDaysIsoDate(-3) + 'T15:10:00.000Z',
        actor: 'Dr. Miriam Okafor',
        role: 'clinician',
        action: 'Accepted (Soon)',
        note: 'Book 30-min spirometry-capable clinic slot with interpreter.',
      },
    ]),
  );

  // Marcus Holloway: Accepted & Booked Cardiology
  insertReferral.run(
    'REF-CARD-02',
    'PAT-004',
    'Cardiology',
    'General Cardiology Outpatients',
    'A&E Follow-up Pathway',
    sevenDaysAgo,
    'Accepted',
    'Urgent',
    'USR-PATEL',
    'Urgent post-discharge palpitation review.',
    20,
    'In-person',
    '["12-lead ECG"]',
    null,
    '[{"id":"DOC-103","title":"ED Discharge Summary","source":"Trust EPR","uploaded_at":"' + sevenDaysAgo + '"}]',
    'Urgent review within 14 days.',
    addDaysIsoDate(-6) + 'T10:00:00.000Z',
    'USR-PATEL',
    14,
    JSON.stringify([
      {
        timestamp: addDaysIsoDate(-6) + 'T10:00:00.000Z',
        actor: 'Dr. Hannah Patel',
        role: 'clinician',
        action: 'Accepted (Urgent)',
        note: 'Priority review required',
      },
    ]),
  );

  // Eleanor Rigby-Smythe: Orthopaedics surgical pathway
  insertReferral.run(
    'REF-ORTH-01',
    'PAT-003',
    'Orthopaedics',
    'Elective Hip & Knee Arthroplasty',
    'MSK Triage Service',
    addDaysIsoDate(-20) + 'T11:30:00.000Z',
    'Accepted',
    'Soon',
    'USR-FINCH',
    'Listed for elective right total knee replacement following pre-op assessment.',
    30,
    'In-person',
    '["Pre-op Assessment Suite"]',
    null,
    '[{"id":"DOC-104","title":"Knee X-Ray & MSK Outcome","source":"Trust EPR","uploaded_at":"' + addDaysIsoDate(-20) + 'T11:30:00.000Z"}]',
    'Decision to admit recorded by Mr. Finch.',
    addDaysIsoDate(-18) + 'T16:00:00.000Z',
    'USR-FINCH',
    42,
    JSON.stringify([]),
  );

  // Sanjay Kulkarni: Incomplete referral (missing docs / unverified NHS number)
  insertReferral.run(
    'REF-CARD-03',
    'PAT-005',
    'Cardiology',
    'Cardiology Telephone Assessment',
    'Out-of-area GP Referral',
    addDaysIsoDate(-1) + 'T08:40:00.000Z',
    'Received',
    null,
    null,
    'Hypertension assessment (NHS number unverified; awaiting baseline ECG).',
    20,
    'Telephone',
    '[]',
    null,
    '[]',
    null,
    null,
    null,
    28,
    JSON.stringify([]),
  );

  // 6. Waiting List Entries (Separate from bookings!)
  const insertWl = db.prepare(
    `INSERT INTO waiting_list_entries (
      id, referral_id, patient_id, specialty, service_name,
      clinical_priority, original_rtt_clock_start, current_status, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertWl.run('WL-RESP-01', 'REF-RESP-01', 'PAT-002', 'Respiratory Medicine', 'General Respiratory & Spirometry Outpatients', 'Soon', fiveDaysAgo, 'Active', addDaysIsoDate(-3) + 'T15:10:00.000Z');
  insertWl.run('WL-CARD-02', 'REF-CARD-02', 'PAT-004', 'Cardiology', 'General Cardiology Outpatients', 'Urgent', sevenDaysAgo, 'Booked', addDaysIsoDate(-6) + 'T10:00:00.000Z');
  insertWl.run('WL-ORTH-01', 'REF-ORTH-01', 'PAT-003', 'Orthopaedics', 'Elective Hip & Knee Arthroplasty', 'Soon', addDaysIsoDate(-20) + 'T11:30:00.000Z', 'Active', addDaysIsoDate(-18) + 'T16:00:00.000Z');

  // 7. Clinic Templates (Versioned)
  const insertTemplate = db.prepare(
    `INSERT INTO clinic_templates (
      id, version, name, specialty, clinic_type, site_id, room_name, format,
      clinician_id, support_staff_role, required_equipment_json,
      default_duration_mins, buffer_mins, break_start, break_end,
      protected_capacity_count, group_session_enabled, overbooking_enabled,
      preparation_instructions, booking_window_days, active
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertTemplate.run(
    'TPL-CARD-STA',
    2,
    "St Aidan's Morning Cardiology Outpatients",
    'Cardiology',
    'New Outpatient Consultation',
    'SITE-STA',
    'Outpatient Suite B · Room 4',
    'In-person',
    'USR-PATEL',
    'Cardiac Physiologist (ECG)',
    '["12-lead ECG","Step-free access"]',
    20,
    5,
    '10:30',
    '10:45',
    1,
    0,
    0,
    'Please bring a current list of all medications and avoid caffeine for 2 hours prior to ECG.',
    28,
    1,
  );
  insertTemplate.run(
    'TPL-CARD-TEL',
    1,
    'Cardiology Telephone Follow-up Clinic',
    'Cardiology',
    'Telephone Review',
    'SITE-CVI',
    'Virtual Consultation Hub 2',
    'Telephone',
    'USR-PATEL',
    null,
    '[]',
    20,
    5,
    null,
    null,
    0,
    0,
    0,
    'Ensure your phone can accept withheld or hospital switchboard calls within 30 minutes of your slot.',
    28,
    1,
  );
  insertTemplate.run(
    'TPL-RESP-STA',
    1,
    "St Aidan's Respiratory & Spirometry Clinic",
    'Respiratory Medicine',
    'Specialist Respiratory Assessment',
    'SITE-STA',
    'Respiratory Hub · Room 2',
    'In-person',
    'USR-OKAFOR',
    'Respiratory Nurse Specialist',
    '["Spirometry","Step-free access"]',
    30,
    5,
    '11:00',
    '11:15',
    1,
    0,
    0,
    'Do not use short-acting reliever inhalers for 4 hours before spirometry unless clinically needed.',
    28,
    1,
  );
  insertTemplate.run(
    'TPL-ORTH-CVI',
    1,
    'Calder Valley Pre-operative & Orthopaedic Clinic',
    'Orthopaedics',
    'Orthopaedic Pre-Admission Clinic',
    'SITE-CVI',
    'Surgical Outpatients · Room 1',
    'In-person',
    'USR-FINCH',
    'Pre-op Assessment Nurse',
    '["Pre-op Assessment Suite","Step-free access"]',
    30,
    10,
    null,
    null,
    1,
    0,
    0,
    'Bring reading glasses and details of previous anaesthetics.',
    42,
    1,
  );

  // 8. Generate Clinic Sessions & Slots for next 7 days
  const insertSession = db.prepare(
    `INSERT INTO clinic_sessions (
      id, template_id, template_version, site_id, room_name, clinician_id,
      session_date, start_time, end_time, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  const insertSlot = db.prepare(
    `INSERT INTO appointment_slots (
      id, session_id, start_iso, end_iso, duration_mins, format,
      slot_status, protected_for_priority
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  const day1 = addDaysIsoDate(1);
  const day2 = addDaysIsoDate(2);
  const day3 = addDaysIsoDate(3);
  const day4 = addDaysIsoDate(4);
  const day5 = addDaysIsoDate(5);

  const sessionConfigs = [
    {
      id: 'SES-CARD-D1',
      tplId: 'TPL-CARD-STA',
      ver: 2,
      siteId: 'SITE-STA',
      room: 'Outpatient Suite B · Room 4',
      clinician: 'USR-PATEL',
      date: day1,
      start: '09:00',
      end: '12:00',
      format: 'In-person',
      dur: 20,
      slots: ['09:00', '09:25', '09:50', '10:50', '11:15'],
      protectedFirst: true,
    },
    {
      id: 'SES-CARD-D3',
      tplId: 'TPL-CARD-STA',
      ver: 2,
      siteId: 'SITE-STA',
      room: 'Outpatient Suite B · Room 4',
      clinician: 'USR-PATEL',
      date: day3,
      start: '09:00',
      end: '12:00',
      format: 'In-person',
      dur: 20,
      slots: ['09:00', '09:25', '09:50', '10:50', '11:15'],
      protectedFirst: false,
    },
    {
      id: 'SES-CARD-TEL-D4',
      tplId: 'TPL-CARD-TEL',
      ver: 1,
      siteId: 'SITE-CVI',
      room: 'Virtual Consultation Hub 2',
      clinician: 'USR-PATEL',
      date: day4,
      start: '14:00',
      end: '16:00',
      format: 'Telephone',
      dur: 20,
      slots: ['14:00', '14:25', '14:50', '15:15'],
      protectedFirst: false,
    },
    {
      id: 'SES-RESP-D2',
      tplId: 'TPL-RESP-STA',
      ver: 1,
      siteId: 'SITE-STA',
      room: 'Respiratory Hub · Room 2',
      clinician: 'USR-OKAFOR',
      date: day2,
      start: '09:00',
      end: '12:30',
      format: 'In-person',
      dur: 30,
      slots: ['09:00', '09:35', '10:10', '11:20'],
      protectedFirst: true,
    },
    {
      id: 'SES-RESP-D5',
      tplId: 'TPL-RESP-STA',
      ver: 1,
      siteId: 'SITE-STA',
      room: 'Respiratory Hub · Room 2',
      clinician: 'USR-OKAFOR',
      date: day5,
      start: '09:00',
      end: '12:00',
      format: 'In-person',
      dur: 30,
      slots: ['09:00', '09:35', '10:10'],
      protectedFirst: false,
    },
    {
      id: 'SES-ORTH-D2',
      tplId: 'TPL-ORTH-CVI',
      ver: 1,
      siteId: 'SITE-CVI',
      room: 'Surgical Outpatients · Room 1',
      clinician: 'USR-FINCH',
      date: day2,
      start: '13:30',
      end: '16:30',
      format: 'In-person',
      dur: 30,
      slots: ['13:30', '14:10', '14:50'],
      protectedFirst: false,
    },
  ];

  let bookedSlotForMarcus = '';
  let bookedSlotStartMarcus = '';
  let bookedSlotEndMarcus = '';

  let bookedSlotForOkaforDemo = '';
  let bookedSlotStartOkafor = '';
  let bookedSlotEndOkafor = '';

  for (const sc of sessionConfigs) {
    insertSession.run(
      sc.id,
      sc.tplId,
      sc.ver,
      sc.siteId,
      sc.room,
      sc.clinician,
      sc.date,
      sc.start,
      sc.end,
      'Scheduled',
    );
    sc.slots.forEach((timeStr, idx) => {
      const slotId = `SLT-${sc.id}-${idx + 1}`;
      const startIso = londonLocalToUtcIso(sc.date, timeStr);
      const endIso = new Date(new Date(startIso).getTime() + sc.dur * 60 * 1000).toISOString();
      const isMarcusSlot = sc.id === 'SES-CARD-D1' && idx === 0;
      const isOkaforSlot = sc.id === 'SES-RESP-D5' && idx === 0;
      if (isMarcusSlot) {
        bookedSlotForMarcus = slotId;
        bookedSlotStartMarcus = startIso;
        bookedSlotEndMarcus = endIso;
      }
      if (isOkaforSlot) {
        bookedSlotForOkaforDemo = slotId;
        bookedSlotStartOkafor = startIso;
        bookedSlotEndOkafor = endIso;
      }
      insertSlot.run(
        slotId,
        sc.id,
        startIso,
        endIso,
        sc.dur,
        sc.format,
        isMarcusSlot || isOkaforSlot ? 'Booked' : 'Available',
        sc.protectedFirst && idx === 0 ? 1 : 0,
      );
    });
  }

  // 9. Existing Appointments
  const insertAppt = db.prepare(
    `INSERT INTO appointments (
      id, slot_id, referral_id, waiting_list_id, patient_id, specialty,
      appointment_type, format, site_id, room_name, clinician_id, start_iso, end_iso,
      status, preparation_instructions, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  // Marcus Holloway's Cardiology appointment (with failed SMS reminder!)
  insertAppt.run(
    'APT-MARCUS-01',
    bookedSlotForMarcus,
    'REF-CARD-02',
    'WL-CARD-02',
    'PAT-004',
    'Cardiology',
    'New Outpatient Consultation',
    'In-person',
    'SITE-STA',
    'Outpatient Suite B · Room 4',
    'USR-PATEL',
    bookedSlotStartMarcus,
    bookedSlotEndMarcus,
    'Booked',
    'Please bring a current list of all medications and avoid caffeine for 2 hours prior to ECG.',
    addDaysIsoDate(-2) + 'T10:00:00.000Z',
    addDaysIsoDate(-2) + 'T10:00:00.000Z',
  );

  // Fatima Begum already has an upcoming Day-5 appointment so clinician absence on Day-5 affects a real patient
  insertAppt.run(
    'APT-FATIMA-00',
    bookedSlotForOkaforDemo,
    'REF-RESP-01',
    'WL-RESP-01',
    'PAT-002',
    'Respiratory Medicine',
    'Specialist Respiratory Assessment',
    'In-person',
    'SITE-STA',
    'Respiratory Hub · Room 2',
    'USR-OKAFOR',
    bookedSlotStartOkafor,
    bookedSlotEndOkafor,
    'Confirmed',
    'Do not use short-acting reliever inhalers for 4 hours before spirometry unless clinically needed.',
    addDaysIsoDate(-1) + 'T11:20:00.000Z',
    addDaysIsoDate(-1) + 'T11:20:00.000Z',
  );

  // 10. Staff Rotas (Draft & Published)
  const insertRota = db.prepare(
    `INSERT INTO staff_rotas (
      id, staff_id, site_id, rota_date, start_time, end_time,
      assignment_type, status, travel_buffer_mins, note
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertRota.run('ROT-001', 'USR-PATEL', 'SITE-STA', day1, '08:30', '13:00', 'Clinic', 'Published', 0, "St Aidan's Cardiology Clinic");
  insertRota.run('ROT-002', 'USR-PATEL', 'SITE-STA', day3, '08:30', '13:00', 'Clinic', 'Published', 0, "St Aidan's Cardiology Clinic");
  insertRota.run('ROT-003', 'USR-PATEL', 'SITE-CVI', day4, '13:30', '17:00', 'Clinic', 'Draft', 35, 'Cross-site travel buffer 35m from St Aidan’s');
  insertRota.run('ROT-004', 'USR-OKAFOR', 'SITE-STA', day2, '08:30', '13:00', 'Clinic', 'Published', 0, 'Respiratory & Spirometry Session');
  insertRota.run('ROT-005', 'USR-OKAFOR', 'SITE-STA', day5, '08:30', '13:00', 'Clinic', 'Published', 0, 'Published clinic — test absence impact here');
  insertRota.run('ROT-006', 'USR-FINCH', 'SITE-CVI', day2, '13:00', '17:00', 'Clinic', 'Published', 0, 'Orthopaedic Pre-Admission Clinic');
  insertRota.run('ROT-007', 'USR-FINCH', 'SITE-STA', day4, '08:00', '18:00', 'On-call', 'Published', 0, 'Acute Orthopaedic On-call');

  // 11. Small Inpatient Ward & Beds (Ward 4B — 8 beds, including closed bed & infection control bed)
  db.prepare(
    `INSERT INTO wards (id, site_id, name, specialty, total_beds, capabilities_json, source_system, last_synced_iso)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'WRD-4B',
    'SITE-STA',
    'Airedale Surgical & Cardiac Ward (Ward 4B)',
    'Orthopaedics & Cardiology',
    8,
    '["Telemetry","Oxygen","Step-free en-suite","Isolation bay"]',
    'Trust PAS Bed Board (Simulated)',
    now,
  );

  const insertBed = db.prepare(
    `INSERT INTO beds (id, ward_id, bed_label, capabilities_json, occupancy_status, current_admission_id, restriction_note, updated_by, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertBed.run('BED-4B-01', 'WRD-4B', '4B-01', '["Telemetry","Oxygen"]', 'Occupied', null, 'Inpatient admitted via ED (est. discharge in 2 days — not guaranteed)', 'USR-BED', now);
  insertBed.run('BED-4B-02', 'WRD-4B', '4B-02', '["Telemetry","Oxygen"]', 'Occupied', null, 'Post-PCI monitoring', 'USR-BED', now);
  insertBed.run('BED-4B-03', 'WRD-4B', '4B-03', '["Oxygen"]', 'Occupied', null, 'Elective hip recovery', 'USR-BED', now);
  insertBed.run('BED-4B-04', 'WRD-4B', '4B-04', '["Oxygen"]', 'Cleaning', null, 'Deep clean turnaround in progress (~45m)', 'USR-BED', now);
  insertBed.run('BED-4B-05', 'WRD-4B', '4B-05', '["Isolation bay","Oxygen"]', 'Infection Control', null, 'IPC barrier precaution — restricted by Infection Prevention Team', 'USR-BED', now);
  insertBed.run('BED-4B-06', 'WRD-4B', '4B-06', '["Telemetry","Oxygen","Step-free en-suite"]', 'Maintenance Closed', null, 'Med-gas outlet valve repair — closed by Estates until signed off', 'USR-BED', now);
  insertBed.run('BED-4B-07', 'WRD-4B', '4B-07', '["Telemetry","Oxygen"]', 'Available', null, null, 'USR-BED', now);
  insertBed.run('BED-4B-08', 'WRD-4B', '4B-08', '["Oxygen","Step-free en-suite"]', 'Available', null, null, 'USR-BED', now);

  // 12. Planned Admission with Conflict (allocated to closed Bed 4B-06!)
  db.prepare(
    `INSERT INTO planned_admissions (
      id, patient_id, referral_id, specialty, site_id, requested_ward_id,
      allocated_bed_id, expected_admission_date, estimated_los_days,
      estimated_discharge_date, prerequisites_json, state,
      conflict_status, conflict_reason, created_by
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'ADM-001',
    'PAT-003',
    'REF-ORTH-01',
    'Orthopaedics',
    'SITE-STA',
    'WRD-4B',
    'BED-4B-06',
    day3,
    4,
    addDaysIsoDate(7),
    JSON.stringify([
      {label: 'Pre-operative anaesthetic assessment', completed: true},
      {label: 'MRSA & VTE screening', completed: true},
      {label: 'Blood group & save', completed: false},
    ]),
    'Confirmed booking',
    'Conflict Detected',
    'Allocated bed 4B-06 is restricted (Maintenance Closed: Med-gas outlet valve repair — closed by Estates until signed off) | Incomplete prerequisites: Blood group & save.',
    'USR-FINCH',
  );

  // 13. Work Queues
  const insertTask = db.prepare(
    `INSERT INTO work_tasks (
      id, queue_type, title, description, entity_type, entity_id,
      patient_id, owner_staff_id, priority_source, due_iso, status, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  insertTask.run(
    'TSK-001',
    'Awaiting clinical review',
    'Cardiology referral triage: Arthur Pendelton',
    'GP e-RS referral REF-CARD-01 requires clinician acceptance and priority assignment.',
    'referral',
    'REF-CARD-01',
    'PAT-001',
    'USR-PATEL',
    'Clinical triage SLA (48h)',
    addDaysIsoDate(1) + 'T17:00:00.000Z',
    'Open',
    twoDaysAgo,
  );
  insertTask.run(
    'TSK-002',
    'Failed communication',
    'Failed SMS reminder for Marcus Holloway',
    'Automated 48h reminder SMS failed (Carrier code 4801 — handset unreachable). Contact patient via Email or telephone.',
    'communication',
    'COM-FAIL-01',
    'PAT-004',
    'USR-JENKINS',
    'Communication safety rule',
    day1 + 'T08:00:00.000Z',
    'Open',
    now,
  );
  insertTask.run(
    'TSK-003',
    'Identity issue',
    'Potential duplicate patient record: Eleanor Rigby-Smythe',
    'GP extract record PAT-003-DUP shares NHS number 943 619 3328 with PAT-003 but differs by 1 day in DOB. Manual review required; do not auto-merge.',
    'patient',
    'PAT-003',
    'PAT-003',
    'USR-ADMIN',
    'Patient identity governance',
    addDaysIsoDate(2) + 'T12:00:00.000Z',
    'Open',
    now,
  );
  insertTask.run(
    'TSK-004',
    'Identity issue',
    'Unverified NHS number: Sanjay Kulkarni',
    'Inbound referral REF-CARD-03 has unverified NHS number 943 812 4401. Verify via PAS before clinical booking.',
    'patient',
    'PAT-005',
    'PAT-005',
    'USR-JENKINS',
    'PAS identity verification',
    addDaysIsoDate(2) + 'T17:00:00.000Z',
    'Open',
    now,
  );
  insertTask.run(
    'TSK-005',
    'Admission prerequisite',
    'Admission bed & prerequisite conflict: Eleanor Rigby-Smythe',
    'Planned admission ADM-001 is assigned to Maintenance Closed bed 4B-06 and awaits Blood group & save.',
    'planned_admission',
    'ADM-001',
    'PAT-003',
    'USR-BED',
    'Elective admission readiness',
    day2 + 'T16:00:00.000Z',
    'Open',
    now,
  );
  insertTask.run(
    'TSK-006',
    'Interpreter booking',
    'Confirm Sylheti interpreter for Fatima Begum',
    'Confirmed appointment APT-FATIMA-00 requires verified Sylheti interpreter attendance.',
    'appointment',
    'APT-FATIMA-00',
    'PAT-002',
    'USR-JENKINS',
    'Accessible Information Standard',
    day5 + 'T08:00:00.000Z',
    'Open',
    now,
  );

  // 14. Communications (including Failed SMS reminder!)
  const insertComm = db.prepare(
    `INSERT INTO communications (
      id, patient_id, channel, message_type, subject, body,
      lock_screen_safe_preview, status, failure_reason, accessible_format,
      language, emergency_disclaimer_shown, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
  );
  insertComm.run(
    'COM-FAIL-01',
    'PAT-004',
    'SMS',
    'Reminder',
    'Appointment Reminder',
    "Reminder: Your appointment at St Aidan's General Hospital is scheduled for tomorrow morning. Call 01274 000 100 if you need help.",
    'Pennine University Hospital: You have a hospital appointment reminder. Sign in to view details.',
    'Failed',
    'Simulated SMS carrier error 4801: Subscriber handset unreachable',
    'Standard',
    'English',
    addDaysIsoDate(-1) + 'T18:00:00.000Z',
    now,
  );
  insertComm.run(
    'COM-PORTAL-01',
    'PAT-001',
    'Portal',
    'General',
    'Referral received by Cardiology service',
    "Your GP referral has been received at St Aidan's General Hospital and is currently awaiting clinical review. You will be notified as soon as booking slots are released.",
    'Pennine University Hospital: Update regarding your referral.',
    'Delivered',
    null,
    'Large print letters (18pt)',
    'English',
    twoDaysAgo,
    twoDaysAgo,
  );
  insertComm.run(
    'COM-PORTAL-02',
    'PAT-002',
    'Portal',
    'Offer',
    'Respiratory Medicine appointment offer available',
    'Your Respiratory Medicine referral has been clinically reviewed. You may now select an eligible clinic slot online or request telephone booking support.',
    'Pennine University Hospital: You have an appointment offer ready to view.',
    'Delivered',
    null,
    'Standard',
    'Sylheti',
    addDaysIsoDate(-3) + 'T15:15:00.000Z',
    addDaysIsoDate(-3) + 'T15:15:00.000Z',
  );

  // 15. Initial Integration Event & Audit Log
  db.prepare(
    `INSERT INTO integration_events (
      id, adapter_name, external_event_id, idempotency_key, direction,
      authoritative_source, payload_json, sync_status, conflict_detail, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    'INT-SEED-01',
    'Simulated NHS e-RS Adapter',
    'UBRN-0009-4421-8810',
    'ers-ubrn-0009-4421-8810-v1',
    'Inbound',
    'External e-RS (Simulated)',
    JSON.stringify({patientId: 'PAT-001', specialty: 'Cardiology', referralId: 'REF-CARD-01'}),
    'Synced',
    null,
    twoDaysAgo,
  );

  recordAudit(db, {
    actorUserId: 'SYSTEM_SEED',
    actorRole: 'system',
    action: 'DEMONSTRATOR_INITIALISED',
    entityType: 'system',
    entityId: 'PENNINE-DEMO',
    details: {sites: 2, patients: 6, clinics: 4, beds: 8},
  });
}
