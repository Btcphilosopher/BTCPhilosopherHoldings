import {createHash, randomUUID} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import type {AuditEntry} from '../../shared/types';

const REDACTED_KEYS = new Set(['password', 'password_hash', 'token', 'secret', 'passcode']);

function redactObject(obj: Record<string, unknown>): Record<string, unknown> {
  const clean: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (REDACTED_KEYS.has(k.toLowerCase())) {
      clean[k] = '[REDACTED]';
    } else if (v && typeof v === 'object' && !Array.isArray(v)) {
      clean[k] = redactObject(v as Record<string, unknown>);
    } else {
      clean[k] = v;
    }
  }
  return clean;
}

export function recordAudit(
  db: DatabaseSync,
  params: {
    actorUserId: string;
    actorRole: string;
    action: string;
    entityType: string;
    entityId: string;
    patientId?: string | null;
    details?: Record<string, unknown>;
  },
): AuditEntry {
  const lastRow = db
    .prepare('SELECT sequence_num, entry_hash FROM audit_logs ORDER BY sequence_num DESC LIMIT 1')
    .get();

  const sequenceNum = lastRow ? Number(lastRow['sequence_num']) + 1 : 1;
  const prevHash = lastRow ? String(lastRow['entry_hash']) : 'GENESIS_HASH_TERTIUSMEDICO';
  const id = `AUD-${randomUUID().slice(0, 8).toUpperCase()}`;
  const createdAt = new Date().toISOString();
  const safeDetails = redactObject(params.details ?? {});
  const detailsJson = JSON.stringify(safeDetails);

  const hashPayload = `${sequenceNum}|${prevHash}|${params.actorUserId}|${params.actorRole}|${params.action}|${params.entityType}|${params.entityId}|${params.patientId ?? ''}|${detailsJson}|${createdAt}`;
  const entryHash = createHash('sha256').update(hashPayload).digest('hex');

  db.prepare(
    `INSERT INTO audit_logs (
      id, sequence_num, actor_user_id, actor_role, action, entity_type, entity_id,
      patient_id, details_json, prev_hash, entry_hash, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    id,
    sequenceNum,
    params.actorUserId,
    params.actorRole,
    params.action,
    params.entityType,
    params.entityId,
    params.patientId ?? null,
    detailsJson,
    prevHash,
    entryHash,
    createdAt,
  );

  return {
    id,
    sequence_num: sequenceNum,
    actor_user_id: params.actorUserId,
    actor_role: params.actorRole,
    action: params.action,
    entity_type: params.entityType,
    entity_id: params.entityId,
    patient_id: params.patientId ?? null,
    details: safeDetails,
    prev_hash: prevHash,
    entry_hash: entryHash,
    created_at: createdAt,
  };
}

export function verifyAuditChain(db: DatabaseSync): {valid: boolean; total: number; brokenAt?: number} {
  const rows = db.prepare('SELECT * FROM audit_logs ORDER BY sequence_num ASC').all();
  let expectedPrev = 'GENESIS_HASH_TERTIUSMEDICO';

  for (const row of rows) {
    const seq = Number(row['sequence_num']);
    if (String(row['prev_hash']) !== expectedPrev) {
      return {valid: false, total: rows.length, brokenAt: seq};
    }
    const payload = `${seq}|${String(row['prev_hash'])}|${String(row['actor_user_id'])}|${String(row['actor_role'])}|${String(row['action'])}|${String(row['entity_type'])}|${String(row['entity_id'])}|${row['patient_id'] ? String(row['patient_id']) : ''}|${String(row['details_json'])}|${String(row['created_at'])}`;
    const computed = createHash('sha256').update(payload).digest('hex');
    if (computed !== String(row['entry_hash'])) {
      return {valid: false, total: rows.length, brokenAt: seq};
    }
    expectedPrev = computed;
  }

  return {valid: true, total: rows.length};
}
