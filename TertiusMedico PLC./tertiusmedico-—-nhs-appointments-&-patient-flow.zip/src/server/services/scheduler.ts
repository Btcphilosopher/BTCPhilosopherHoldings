import {randomUUID} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import type {
  Appointment,
  AppointmentSlot,
  AppointmentStatus,
  ClinicalPriority,
  ClinicFormat,
} from '../../shared/types';
import {recordAudit} from './audit';
import {mockMessagingAdapter, mockVideoAdapter} from './adapters';
import {realtimeBus} from './realtime';

/**
 * Converts a local date (YYYY-MM-DD) and local time (HH:mm) in Europe/London
 * to an accurate UTC ISO-8601 string, respecting GMT/BST offsets.
 */
export function londonLocalToUtcIso(dateStr: string, timeStr: string): string {
  const [year, month, day] = dateStr.split('-').map(Number);
  const [hour, minute] = timeStr.split(':').map(Number);

  // Start with UTC guess
  const utcGuess = new Date(Date.UTC(year, month - 1, day, hour, minute, 0));
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(utcGuess);

  const getPart = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  const londonAsUtc = Date.UTC(
    getPart('year'),
    getPart('month') - 1,
    getPart('day'),
    getPart('hour') === 24 ? 0 : getPart('hour'),
    getPart('minute'),
    0,
  );
  const offsetMs = londonAsUtc - utcGuess.getTime();
  return new Date(utcGuess.getTime() - offsetMs).toISOString();
}

export function formatUtcInLondon(isoString: string): string {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(isoString));
}

export const ALLOWED_APPOINTMENT_TRANSITIONS: Record<AppointmentStatus, AppointmentStatus[]> = {
  Proposed: ['Offered', 'Held', 'Booked', 'Cancelled by provider'],
  Offered: ['Held', 'Booked', 'Cancelled by patient', 'Cancelled by provider'],
  Held: ['Booked', 'Confirmed', 'Cancelled by patient', 'Cancelled by provider'],
  Booked: [
    'Confirmed',
    'Arrived',
    'Cancelled by patient',
    'Cancelled by provider',
    'Did not attend',
    'Rescheduled',
  ],
  Confirmed: [
    'Arrived',
    'Cancelled by patient',
    'Cancelled by provider',
    'Did not attend',
    'Rescheduled',
  ],
  Arrived: ['In progress', 'Unable to complete', 'Cancelled by provider'],
  'In progress': ['Completed', 'Unable to complete'],
  Completed: [],
  'Cancelled by patient': [],
  'Cancelled by provider': [],
  'Did not attend': [],
  'Unable to complete': [],
  Rescheduled: [],
};

export function releaseExpiredHolds(db: DatabaseSync, nowIso = new Date().toISOString()): number {
  const expiredRows = db
    .prepare(
      `SELECT id, held_by_user_id FROM appointment_slots
       WHERE slot_status = 'Held' AND held_until_iso IS NOT NULL AND held_until_iso <= ?`,
    )
    .all(nowIso);

  if (expiredRows.length === 0) return 0;

  db.exec('BEGIN IMMEDIATE;');
  try {
    for (const row of expiredRows) {
      const slotId = String(row['id']);
      db.prepare(
        `UPDATE appointment_slots
         SET slot_status = 'Available', held_by_user_id = NULL, held_until_iso = NULL, version = version + 1
         WHERE id = ? AND slot_status = 'Held'`,
      ).run(slotId);

      recordAudit(db, {
        actorUserId: 'SYSTEM_WORKER',
        actorRole: 'system',
        action: 'SLOT_HOLD_EXPIRED',
        entityType: 'appointment_slot',
        entityId: slotId,
        details: {previousHolder: row['held_by_user_id'], releasedAt: nowIso},
      });

      realtimeBus.broadcast('slot:released', {slotId, reason: 'hold_expired'});
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }

  return expiredRows.length;
}

export function getEligibleSlotsForReferral(
  db: DatabaseSync,
  params: {
    referralId: string;
    actingUserId: string;
    preferredSiteId?: string | null;
    timeOfDayPreference?: 'morning' | 'afternoon' | null;
    nowIso?: string;
  },
): {eligible: AppointmentSlot[]; ineligible: AppointmentSlot[]} {
  const nowIso = params.nowIso ?? new Date().toISOString();
  releaseExpiredHolds(db, nowIso);

  const ref = db.prepare('SELECT * FROM referrals WHERE id = ?').get(params.referralId);
  if (!ref) {
    throw new Error('Referral not found');
  }

  const reqResources: string[] = JSON.parse(String(ref['required_resources_json'] || '[]'));
  const reqDuration = Number(ref['required_duration_mins']);
  const reqFormat = String(ref['required_format']) as ClinicFormat;
  const refPriority = ref['clinical_priority'] ? (String(ref['clinical_priority']) as ClinicalPriority) : null;
  const bookingWindowDays = Number(ref['booking_window_days'] || 28);
  const windowCutoffMs = new Date(nowIso).getTime() + bookingWindowDays * 24 * 3600 * 1000;
  const patientId = String(ref['patient_id']);

  const patientAppts = db
    .prepare(
      `SELECT start_iso, end_iso FROM appointments
       WHERE patient_id = ? AND status IN ('Booked', 'Confirmed', 'Arrived', 'In progress')`,
    )
    .all(patientId);

  const absences = db
    .prepare(
      `SELECT staff_id, rota_date, start_time, end_time, assignment_type
       FROM staff_rotas
       WHERE assignment_type IN ('Leave', 'Sickness Absence')`,
    )
    .all();

  const rows = db
    .prepare(
      `SELECT
         s.id, s.session_id, s.start_iso, s.end_iso, s.duration_mins, s.format,
         s.slot_status, s.held_by_user_id, s.held_until_iso, s.protected_for_priority,
         cs.site_id, cs.room_name, cs.clinician_id, cs.session_date, cs.status AS session_status,
         st.name AS site_name,
         ct.specialty, ct.clinic_type, ct.preparation_instructions, ct.required_equipment_json,
         u.display_name AS clinician_name
       FROM appointment_slots s
       JOIN clinic_sessions cs ON cs.id = s.session_id
       JOIN sites st ON st.id = cs.site_id
       JOIN clinic_templates ct ON ct.id = cs.template_id
       JOIN staff_users u ON u.id = cs.clinician_id
       WHERE s.start_iso >= ?
       ORDER BY s.start_iso ASC`,
    )
    .all(nowIso);

  const eligible: AppointmentSlot[] = [];
  const ineligible: AppointmentSlot[] = [];

  for (const r of rows) {
    const conflicts: string[] = [];
    const slotSpecialty = String(r['specialty']);
    const slotDuration = Number(r['duration_mins']);
    const slotFormat = String(r['format']) as ClinicFormat;
    const slotStatus = String(r['slot_status']) as AppointmentSlot['slot_status'];
    const heldBy = r['held_by_user_id'] ? String(r['held_by_user_id']) : null;
    const protectedSlot = Boolean(r['protected_for_priority']);
    const equipment: string[] = JSON.parse(String(r['required_equipment_json'] || '[]'));
    const startIso = String(r['start_iso']);
    const endIso = String(r['end_iso']);
    const sessionStatus = String(r['session_status']);
    const clinicianId = String(r['clinician_id']);
    const sessionDate = String(r['session_date']);

    if (String(ref['status']) !== 'Accepted') {
      conflicts.push(`Referral status is "${String(ref['status'])}" (must be Accepted by clinician)`);
    }
    if (!refPriority) {
      conflicts.push('Clinical priority has not yet been assigned');
    }
    if (slotSpecialty !== String(ref['specialty'])) {
      conflicts.push(`Specialty mismatch (${slotSpecialty} vs ${String(ref['specialty'])})`);
    }
    if (sessionStatus === 'Cancelled') {
      conflicts.push('Clinic session is cancelled');
    }
    if (slotDuration < reqDuration) {
      conflicts.push(`Slot duration (${slotDuration}m) shorter than required (${reqDuration}m)`);
    }
    if (slotFormat !== reqFormat) {
      conflicts.push(`Format mismatch (${slotFormat} vs required ${reqFormat})`);
    }
    for (const reqRes of reqResources) {
      if (!equipment.includes(reqRes)) {
        conflicts.push(`Missing required room/equipment resource: ${reqRes}`);
      }
    }
    if (new Date(startIso).getTime() > windowCutoffMs) {
      conflicts.push(`Outside clinically defined ${bookingWindowDays}-day booking window`);
    }
    if (protectedSlot && refPriority !== 'Urgent') {
      conflicts.push('Protected Urgent-only capacity');
    }

    const isAvailableOrOwnHold =
      slotStatus === 'Available' ||
      (slotStatus === 'Held' && heldBy === params.actingUserId);

    if (!isAvailableOrOwnHold) {
      conflicts.push(
        slotStatus === 'Held'
          ? 'Temporarily held by another user'
          : `Slot status is ${slotStatus}`,
      );
    }

    // Check clinician absence conflict
    const slotStartMs = new Date(startIso).getTime();
    const slotEndMs = new Date(endIso).getTime();
    for (const abs of absences) {
      if (String(abs['staff_id']) === clinicianId && String(abs['rota_date']) === sessionDate) {
        const absStart = new Date(londonLocalToUtcIso(sessionDate, String(abs['start_time']))).getTime();
        const absEnd = new Date(londonLocalToUtcIso(sessionDate, String(abs['end_time']))).getTime();
        if (slotStartMs < absEnd && slotEndMs > absStart) {
          conflicts.push(`Clinician marked as ${String(abs['assignment_type'])} on ${sessionDate}`);
        }
      }
    }

    // Check patient double booking
    for (const pa of patientAppts) {
      const paStart = new Date(String(pa['start_iso'])).getTime();
      const paEnd = new Date(String(pa['end_iso'])).getTime();
      if (slotStartMs < paEnd && slotEndMs > paStart) {
        conflicts.push('Patient already has an overlapping appointment');
      }
    }

    // Preference score (separate from hard constraints!)
    let prefScore = 50;
    if (params.preferredSiteId && String(r['site_id']) === params.preferredSiteId) {
      prefScore += 30;
    }
    const londonHour = Number(
      new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Europe/London',
        hour: '2-digit',
        hour12: false,
      }).format(new Date(startIso)),
    );
    if (params.timeOfDayPreference === 'morning' && londonHour < 12) prefScore += 20;
    if (params.timeOfDayPreference === 'afternoon' && londonHour >= 12) prefScore += 20;

    const slotObj: AppointmentSlot = {
      id: String(r['id']),
      session_id: String(r['session_id']),
      site_id: String(r['site_id']),
      site_name: String(r['site_name']),
      room_name: String(r['room_name']),
      specialty: slotSpecialty,
      clinic_type: String(r['clinic_type']),
      clinician_id: clinicianId,
      clinician_name: String(r['clinician_name']),
      start_iso: startIso,
      end_iso: endIso,
      duration_mins: slotDuration,
      format: slotFormat,
      slot_status: slotStatus,
      held_by_user_id: heldBy,
      held_until_iso: r['held_until_iso'] ? String(r['held_until_iso']) : null,
      protected_for_priority: protectedSlot,
      preparation_instructions: String(r['preparation_instructions'] || ''),
      required_equipment: equipment,
      eligible: conflicts.length === 0,
      preference_score: prefScore,
      conflict_reasons: conflicts,
    };

    if (conflicts.length === 0) {
      eligible.push(slotObj);
    } else if (slotSpecialty === String(ref['specialty'])) {
      ineligible.push(slotObj);
    }
  }

  eligible.sort((a, b) => {
    const scoreDiff = (b.preference_score ?? 0) - (a.preference_score ?? 0);
    if (scoreDiff !== 0) return scoreDiff;
    return a.start_iso.localeCompare(b.start_iso);
  });

  return {eligible, ineligible};
}

export function holdSlot(
  db: DatabaseSync,
  params: {
    slotId: string;
    userId: string;
    userRole: string;
    ttlSeconds?: number;
    nowIso?: string;
  },
): {slotId: string; heldUntilIso: string} {
  const nowIso = params.nowIso ?? new Date().toISOString();
  const ttl = params.ttlSeconds ?? 300;
  const heldUntilIso = new Date(new Date(nowIso).getTime() + ttl * 1000).toISOString();

  releaseExpiredHolds(db, nowIso);

  db.exec('BEGIN IMMEDIATE;');
  try {
    const slot = db.prepare('SELECT * FROM appointment_slots WHERE id = ?').get(params.slotId);
    if (!slot) {
      db.exec('ROLLBACK;');
      const err = new Error('Appointment slot not found');
      (err as Error & {statusCode?: number}).statusCode = 404;
      throw err;
    }

    const status = String(slot['slot_status']);
    const heldBy = slot['held_by_user_id'] ? String(slot['held_by_user_id']) : null;

    if (status === 'Booked' || status === 'Blocked') {
      db.exec('ROLLBACK;');
      const err = new Error(`Slot is already ${status.toLowerCase()} and cannot be held.`);
      (err as Error & {statusCode?: number}).statusCode = 409;
      throw err;
    }

    if (status === 'Held' && heldBy !== params.userId) {
      db.exec('ROLLBACK;');
      const err = new Error(
        `Slot is currently held by another user until ${formatUtcInLondon(String(slot['held_until_iso']))}.`,
      );
      (err as Error & {statusCode?: number}).statusCode = 409;
      throw err;
    }

    db.prepare(
      `UPDATE appointment_slots
       SET slot_status = 'Held', held_by_user_id = ?, held_until_iso = ?, version = version + 1
       WHERE id = ?`,
    ).run(params.userId, heldUntilIso, params.slotId);

    recordAudit(db, {
      actorUserId: params.userId,
      actorRole: params.userRole,
      action: 'SLOT_HELD',
      entityType: 'appointment_slot',
      entityId: params.slotId,
      details: {heldUntilIso},
    });

    db.exec('COMMIT;');
    realtimeBus.broadcast('slot:held', {slotId: params.slotId, heldUntilIso});
    return {slotId: params.slotId, heldUntilIso};
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // already rolled back
    }
    throw err;
  }
}

export function bookSlotForReferral(
  db: DatabaseSync,
  params: {
    slotId: string;
    referralId: string;
    actorUserId: string;
    actorRole: string;
    shortNoticeOptIn?: boolean;
    linkedPreviousAppointmentId?: string | null;
    nowIso?: string;
  },
): Appointment {
  const nowIso = params.nowIso ?? new Date().toISOString();
  releaseExpiredHolds(db, nowIso);

  db.exec('BEGIN IMMEDIATE;');
  try {
    const slotRow = db
      .prepare(
        `SELECT s.*, cs.site_id, cs.room_name, cs.clinician_id, cs.session_date,
                ct.specialty, ct.clinic_type, ct.preparation_instructions,
                st.name AS site_name, u.display_name AS clinician_name
         FROM appointment_slots s
         JOIN clinic_sessions cs ON cs.id = s.session_id
         JOIN clinic_templates ct ON ct.id = cs.template_id
         JOIN sites st ON st.id = cs.site_id
         JOIN staff_users u ON u.id = cs.clinician_id
         WHERE s.id = ?`,
      )
      .get(params.slotId);

    if (!slotRow) {
      const err = new Error('Slot not found');
      (err as Error & {statusCode?: number}).statusCode = 404;
      throw err;
    }

    const slotStatus = String(slotRow['slot_status']);
    const heldBy = slotRow['held_by_user_id'] ? String(slotRow['held_by_user_id']) : null;

    if (slotStatus === 'Booked' || slotStatus === 'Blocked') {
      const err = new Error(`Slot is ${slotStatus} and no longer available.`);
      (err as Error & {statusCode?: number}).statusCode = 409;
      throw err;
    }
    if (slotStatus === 'Held' && heldBy !== params.actorUserId) {
      const err = new Error('Slot is held by another user. Please choose an alternative slot.');
      (err as Error & {statusCode?: number}).statusCode = 409;
      throw err;
    }

    const refRow = db.prepare('SELECT * FROM referrals WHERE id = ?').get(params.referralId);
    if (!refRow) {
      const err = new Error('Referral not found');
      (err as Error & {statusCode?: number}).statusCode = 404;
      throw err;
    }
    if (String(refRow['status']) !== 'Accepted') {
      const err = new Error('Referral must be clinically Accepted before booking.');
      (err as Error & {statusCode?: number}).statusCode = 400;
      throw err;
    }

    const patientId = String(refRow['patient_id']);
    const clinicianId = String(slotRow['clinician_id']);
    const roomName = String(slotRow['room_name']);
    const siteId = String(slotRow['site_id']);
    const startIso = String(slotRow['start_iso']);
    const endIso = String(slotRow['end_iso']);

    // Enforce zero simultaneous room or clinician conflict
    const overlap = db
      .prepare(
        `SELECT id, clinician_id, room_name FROM appointments
         WHERE status IN ('Booked', 'Confirmed', 'Arrived', 'In progress')
           AND start_iso < ? AND end_iso > ?
           AND (clinician_id = ? OR (site_id = ? AND room_name = ?))`,
      )
      .get(endIso, startIso, clinicianId, siteId, roomName);

    if (overlap) {
      const err = new Error('Simultaneous clinician or room conflict detected at confirmation.');
      (err as Error & {statusCode?: number}).statusCode = 409;
      throw err;
    }

    // Find or ensure waiting list entry
    let wl = db.prepare('SELECT * FROM waiting_list_entries WHERE referral_id = ?').get(params.referralId);
    if (!wl) {
      const wlId = `WL-${randomUUID().slice(0, 8).toUpperCase()}`;
      db.prepare(
        `INSERT INTO waiting_list_entries (
          id, referral_id, patient_id, specialty, service_name,
          clinical_priority, original_rtt_clock_start, current_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Booked', ?)`,
      ).run(
        wlId,
        params.referralId,
        patientId,
        String(refRow['specialty']),
        String(refRow['service_name']),
        String(refRow['clinical_priority'] || 'Routine'),
        String(refRow['received_at']),
        nowIso,
      );
      wl = db.prepare('SELECT * FROM waiting_list_entries WHERE id = ?').get(wlId);
    } else {
      db.prepare(`UPDATE waiting_list_entries SET current_status = 'Booked' WHERE id = ?`).run(
        String(wl['id']),
      );
    }

    const apptId = `APT-${randomUUID().slice(0, 8).toUpperCase()}`;
    const format = String(slotRow['format']) as ClinicFormat;
    const videoUrl = format === 'Video' ? mockVideoAdapter.generateSessionLink(apptId) : null;
    const interpreterLang = refRow['interpreter_language'] ? String(refRow['interpreter_language']) : null;
    const prep = String(slotRow['preparation_instructions'] || '');

    db.prepare(
      `UPDATE appointment_slots
       SET slot_status = 'Booked', held_by_user_id = NULL, held_until_iso = NULL, version = version + 1
       WHERE id = ?`,
    ).run(params.slotId);

    db.prepare(
      `INSERT INTO appointments (
        id, slot_id, referral_id, waiting_list_id, patient_id, specialty,
        appointment_type, format, site_id, room_name, clinician_id, start_iso, end_iso,
        status, linked_previous_appointment_id, short_notice_opt_in,
        interpreter_booked, preparation_instructions, video_join_url, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Booked', ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      apptId,
      params.slotId,
      params.referralId,
      wl ? String(wl['id']) : null,
      patientId,
      String(slotRow['specialty']),
      String(slotRow['clinic_type']),
      format,
      siteId,
      roomName,
      clinicianId,
      startIso,
      endIso,
      params.linkedPreviousAppointmentId ?? null,
      params.shortNoticeOptIn ? 1 : 0,
      interpreterLang,
      prep,
      videoUrl,
      nowIso,
      nowIso,
    );

    if (params.shortNoticeOptIn) {
      db.prepare(
        `INSERT INTO short_notice_list (id, patient_id, referral_id, specialty, preferred_sites_json, active, created_at)
         VALUES (?, ?, ?, ?, ?, 1, ?)`,
      ).run(
        `SN-${randomUUID().slice(0, 8).toUpperCase()}`,
        patientId,
        params.referralId,
        String(slotRow['specialty']),
        JSON.stringify([siteId]),
        nowIso,
      );
    }

    if (interpreterLang) {
      db.prepare(
        `INSERT INTO work_tasks (
          id, queue_type, title, description, entity_type, entity_id,
          patient_id, owner_staff_id, priority_source, due_iso, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?)`,
      ).run(
        `TSK-${randomUUID().slice(0, 8).toUpperCase()}`,
        'Interpreter booking',
        `Confirm ${interpreterLang} interpreter for ${apptId}`,
        `Patient requires ${interpreterLang} interpreter for ${format} appointment on ${formatUtcInLondon(startIso)} at ${String(slotRow['site_name'])}.`,
        'appointment',
        apptId,
        patientId,
        'USR-JENKINS',
        'Accessible Information Standard',
        startIso,
        nowIso,
      );
    }

    const patientRow = db.prepare('SELECT * FROM patients WHERE internal_id = ?').get(patientId);
    const prefChannel = (patientRow ? String(patientRow['preferred_channel']) : 'Portal') as
      | 'Portal'
      | 'Email'
      | 'SMS'
      | 'Letter';
    const prefLang = patientRow ? String(patientRow['preferred_language']) : 'English';
    const accNeeds: string[] = patientRow
      ? JSON.parse(String(patientRow['accessibility_needs_json'] || '[]'))
      : [];

    mockMessagingAdapter.dispatch(
      db,
      {
        patientId,
        channel: prefChannel,
        messageType: 'Confirmation',
        subject: `Appointment booked: ${String(slotRow['specialty'])} at ${String(slotRow['site_name'])}`,
        body: `Your ${String(slotRow['specialty'])} (${format}) appointment is booked for ${formatUtcInLondon(startIso)} at ${String(slotRow['site_name'])}, ${roomName} with ${String(slotRow['clinician_name'])}. Preparation: ${prep || 'None required.'}`,
        lockScreenSafePreview:
          'Pennine University Hospital: Your appointment booking is confirmed. Sign in to the patient portal to view date and site details.',
        accessibleFormat: accNeeds.includes('Large print') ? 'Large print' : 'Standard',
        language: prefLang,
      },
      params.actorUserId,
      params.actorRole,
    );

    recordAudit(db, {
      actorUserId: params.actorUserId,
      actorRole: params.actorRole,
      action: 'APPOINTMENT_BOOKED',
      entityType: 'appointment',
      entityId: apptId,
      patientId,
      details: {
        slotId: params.slotId,
        referralId: params.referralId,
        startIso,
        siteId,
      },
    });

    db.exec('COMMIT;');

    realtimeBus.broadcast('appointment:booked', {
      appointmentId: apptId,
      slotId: params.slotId,
      patientId,
    });

    return {
      id: apptId,
      slot_id: params.slotId,
      referral_id: params.referralId,
      waiting_list_id: wl ? String(wl['id']) : null,
      patient_id: patientId,
      patient_name: patientRow ? `${String(patientRow['given_name'])} ${String(patientRow['family_name'])}` : undefined,
      specialty: String(slotRow['specialty']),
      appointment_type: String(slotRow['clinic_type']),
      format,
      site_id: siteId,
      site_name: String(slotRow['site_name']),
      room_name: roomName,
      clinician_id: clinicianId,
      clinician_name: String(slotRow['clinician_name']),
      start_iso: startIso,
      end_iso: endIso,
      status: 'Booked',
      cancellation_reason: null,
      clinical_outcome: null,
      attendance_recorded_at: null,
      linked_previous_appointment_id: params.linkedPreviousAppointmentId ?? null,
      short_notice_opt_in: Boolean(params.shortNoticeOptIn),
      interpreter_booked: interpreterLang,
      preparation_instructions: prep,
      video_join_url: videoUrl,
      created_at: nowIso,
      updated_at: nowIso,
    };
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // already rolled back
    }
    throw err;
  }
}

export function transitionAppointment(
  db: DatabaseSync,
  params: {
    appointmentId: string;
    targetStatus: AppointmentStatus;
    actorUserId: string;
    actorRole: string;
    reason?: string;
    clinicalOutcome?: string;
  },
): Appointment {
  const nowIso = new Date().toISOString();

  db.exec('BEGIN IMMEDIATE;');
  try {
    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(params.appointmentId);
    if (!appt) {
      const err = new Error('Appointment not found');
      (err as Error & {statusCode?: number}).statusCode = 404;
      throw err;
    }

    const currentStatus = String(appt['status']) as AppointmentStatus;
    const allowed = ALLOWED_APPOINTMENT_TRANSITIONS[currentStatus] || [];
    if (!allowed.includes(params.targetStatus)) {
      const err = new Error(
        `Invalid appointment transition from "${currentStatus}" to "${params.targetStatus}".`,
      );
      (err as Error & {statusCode?: number}).statusCode = 400;
      throw err;
    }

    // Clinical outcome / completion / in-progress restricted to clinician or authorised staff
    if (
      (params.targetStatus === 'In progress' ||
        params.targetStatus === 'Completed' ||
        params.targetStatus === 'Unable to complete') &&
      params.actorRole !== 'clinician' &&
      params.actorRole !== 'admin'
    ) {
      const err = new Error('Only authorised clinical staff can record consultation progress or clinical outcome.');
      (err as Error & {statusCode?: number}).statusCode = 403;
      throw err;
    }

    const attendanceTimestamp =
      params.targetStatus === 'Arrived' ? nowIso : appt['attendance_recorded_at'] ? String(appt['attendance_recorded_at']) : null;

    db.prepare(
      `UPDATE appointments
       SET status = ?,
           cancellation_reason = COALESCE(?, cancellation_reason),
           clinical_outcome = COALESCE(?, clinical_outcome),
           attendance_recorded_at = ?,
           updated_at = ?
       WHERE id = ?`,
    ).run(
      params.targetStatus,
      params.reason ?? null,
      params.clinicalOutcome ?? null,
      attendanceTimestamp,
      nowIso,
      params.appointmentId,
    );

    // IMPORTANT: Cancellation NEVER silently removes the patient from the waiting list or resets original_rtt_clock_start!
    if (
      params.targetStatus === 'Cancelled by patient' ||
      params.targetStatus === 'Cancelled by provider'
    ) {
      if (appt['slot_id']) {
        db.prepare(
          `UPDATE appointment_slots SET slot_status = 'Available', held_by_user_id = NULL, held_until_iso = NULL WHERE id = ?`,
        ).run(String(appt['slot_id']));
      }
      if (appt['waiting_list_id']) {
        db.prepare(
          `UPDATE waiting_list_entries SET current_status = 'Active' WHERE id = ?`,
        ).run(String(appt['waiting_list_id']));
      }
    }

    if (params.targetStatus === 'Completed' && appt['waiting_list_id']) {
      db.prepare(
        `UPDATE waiting_list_entries SET current_status = 'Discharged' WHERE id = ?`,
      ).run(String(appt['waiting_list_id']));
    }

    recordAudit(db, {
      actorUserId: params.actorUserId,
      actorRole: params.actorRole,
      action: `APPOINTMENT_${params.targetStatus.toUpperCase().replace(/\s+/g, '_')}`,
      entityType: 'appointment',
      entityId: params.appointmentId,
      patientId: String(appt['patient_id']),
      details: {
        fromStatus: currentStatus,
        toStatus: params.targetStatus,
        reason: params.reason ?? null,
        clinicalOutcome: params.clinicalOutcome ?? null,
        waitingListPreserved: true,
      },
    });

    db.exec('COMMIT;');
    realtimeBus.broadcast('appointment:updated', {
      appointmentId: params.appointmentId,
      status: params.targetStatus,
    });

    const updated = db
      .prepare(
        `SELECT a.*, st.name AS site_name, u.display_name AS clinician_name,
                p.given_name || ' ' || p.family_name AS patient_name
         FROM appointments a
         JOIN sites st ON st.id = a.site_id
         JOIN staff_users u ON u.id = a.clinician_id
         JOIN patients p ON p.internal_id = a.patient_id
         WHERE a.id = ?`,
      )
      .get(params.appointmentId)!;

    return {
      ...(updated as unknown as Appointment),
      short_notice_opt_in: Boolean(updated['short_notice_opt_in']),
    };
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // ignore
    }
    throw err;
  }
}

export function rescheduleAppointment(
  db: DatabaseSync,
  params: {
    appointmentId: string;
    newSlotId: string;
    reason: string;
    actorUserId: string;
    actorRole: string;
  },
): {previousAppointmentId: string; newAppointment: Appointment} {
  const nowIso = new Date().toISOString();
  const prevAppt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(params.appointmentId);
  if (!prevAppt) {
    const err = new Error('Original appointment not found');
    (err as Error & {statusCode?: number}).statusCode = 404;
    throw err;
  }

  const referralId = prevAppt['referral_id'] ? String(prevAppt['referral_id']) : null;
  if (!referralId) {
    const err = new Error('Cannot reschedule appointment without linked referral');
    (err as Error & {statusCode?: number}).statusCode = 400;
    throw err;
  }

  // Mark old appointment Rescheduled and free old slot before booking new slot
  db.exec('BEGIN IMMEDIATE;');
  try {
    db.prepare(
      `UPDATE appointments SET status = 'Rescheduled', cancellation_reason = ?, updated_at = ? WHERE id = ?`,
    ).run(params.reason, nowIso, params.appointmentId);

    if (prevAppt['slot_id']) {
      db.prepare(
        `UPDATE appointment_slots SET slot_status = 'Available', held_by_user_id = NULL, held_until_iso = NULL WHERE id = ?`,
      ).run(String(prevAppt['slot_id']));
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }

  const newAppointment = bookSlotForReferral(db, {
    slotId: params.newSlotId,
    referralId,
    actorUserId: params.actorUserId,
    actorRole: params.actorRole,
    linkedPreviousAppointmentId: params.appointmentId,
    nowIso,
  });

  recordAudit(db, {
    actorUserId: params.actorUserId,
    actorRole: params.actorRole,
    action: 'APPOINTMENT_RESCHEDULED',
    entityType: 'appointment',
    entityId: newAppointment.id,
    patientId: String(prevAppt['patient_id']),
    details: {
      previousAppointmentId: params.appointmentId,
      newAppointmentId: newAppointment.id,
      reason: params.reason,
      waitingListClockPreserved: true,
    },
  });

  return {previousAppointmentId: params.appointmentId, newAppointment};
}

export function evaluateAdmissionConflicts(db: DatabaseSync, admissionId: string): {
  conflictStatus: 'Clear' | 'Conflict Detected';
  conflictReason: string | null;
} {
  const adm = db.prepare('SELECT * FROM planned_admissions WHERE id = ?').get(admissionId);
  if (!adm) throw new Error('Planned admission not found');

  const reasons: string[] = [];
  const wardId = String(adm['requested_ward_id']);
  const allocatedBedId = adm['allocated_bed_id'] ? String(adm['allocated_bed_id']) : null;
  const expectedDate = String(adm['expected_admission_date']);
  const specialty = String(adm['specialty']);
  const prereqs: {label: string; completed: boolean}[] = JSON.parse(
    String(adm['prerequisites_json'] || '[]'),
  );

  const wardBeds = db.prepare('SELECT * FROM beds WHERE ward_id = ?').all(wardId);
  if (allocatedBedId) {
    const bed = wardBeds.find((b) => String(b['id']) === allocatedBedId);
    if (!bed) {
      reasons.push('Allocated bed no longer exists on requested ward.');
    } else if (
      String(bed['occupancy_status']) === 'Maintenance Closed' ||
      String(bed['occupancy_status']) === 'Infection Control'
    ) {
      reasons.push(
        `Allocated bed ${String(bed['bed_label'])} is restricted (${String(bed['occupancy_status'])}${bed['restriction_note'] ? ': ' + String(bed['restriction_note']) : ''}).`,
      );
    } else if (
      String(bed['occupancy_status']) === 'Occupied' &&
      String(bed['current_admission_id'] || '') !== admissionId
    ) {
      reasons.push(
        `Allocated bed ${String(bed['bed_label'])} is currently occupied. Estimated discharges are not treated as guaranteed availability.`,
      );
    }
  } else {
    const availableCount = wardBeds.filter(
      (b) => String(b['occupancy_status']) === 'Available',
    ).length;
    if (availableCount === 0) {
      reasons.push('Zero currently available beds on requested ward (closed/occupied beds block auto-allocation).');
    }
  }

  // Check if specialty clinicians have Leave/Sickness Absence on expected admission date
  const clinicianAbsences = db
    .prepare(
      `SELECT u.display_name, r.assignment_type
       FROM staff_rotas r
       JOIN staff_users u ON u.id = r.staff_id
       WHERE r.rota_date = ? AND u.specialty = ? AND r.assignment_type IN ('Leave', 'Sickness Absence')`,
    )
    .all(expectedDate, specialty);

  if (clinicianAbsences.length > 0) {
    reasons.push(
      `Staffing conflict on ${expectedDate}: ${clinicianAbsences.map((a) => `${String(a['display_name'])} (${String(a['assignment_type'])})`).join(', ')}.`,
    );
  }

  const incompletePrereqs = prereqs.filter((p) => !p.completed);
  if (incompletePrereqs.length > 0 && String(adm['state']) === 'Confirmed booking') {
    reasons.push(
      `Incomplete prerequisites: ${incompletePrereqs.map((p) => p.label).join(', ')}.`,
    );
  }

  const conflictStatus = reasons.length > 0 ? 'Conflict Detected' : 'Clear';
  const conflictReason = reasons.length > 0 ? reasons.join(' | ') : null;

  db.prepare(
    `UPDATE planned_admissions SET conflict_status = ?, conflict_reason = ? WHERE id = ?`,
  ).run(conflictStatus, conflictReason, admissionId);

  return {conflictStatus, conflictReason};
}
