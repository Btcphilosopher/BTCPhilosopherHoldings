import {randomUUID} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import type {CommChannel, CommunicationRecord, IntegrationEvent} from '../../shared/types';
import {recordAudit} from './audit';

export interface PasDemographicsAdapter {
  readonly adapterName: string;
  readonly authoritativeFor: string[];
  verifyNhsNumber(nhsNumber: string | null): {
    status: 'verified' | 'unverified' | 'mismatch';
    sourceRef: string;
    checkedAt: string;
  };
}

export interface EprClinicalSummaryAdapter {
  readonly adapterName: string;
  readonly authoritativeFor: string[];
  fetchPreAdmissionReadiness(patientId: string): {
    authoritativeSource: string;
    clinicalClearanceAvailable: boolean;
    summaryNote: string;
  };
}

export interface ErsReferralAdapter {
  readonly adapterName: string;
  readonly authoritativeFor: string[];
  ingestReferralEvent(
    db: DatabaseSync,
    event: {
      externalEventId: string;
      idempotencyKey: string;
      patientId: string;
      specialty: string;
      serviceName: string;
      referralSource: string;
      appointmentRequirements: string;
      requiredDurationMins: number;
      requiredFormat: 'In-person' | 'Telephone' | 'Video';
      requiredResources?: string[];
      interpreterLanguage?: string | null;
      simulateConflict?: boolean;
    },
    actorUserId: string,
    actorRole: string,
  ): {status: 'Synced' | 'Duplicate Ignored' | 'Conflict'; event: IntegrationEvent; referralId?: string};
}

export interface MessagingAdapter {
  readonly adapterName: string;
  dispatch(
    db: DatabaseSync,
    params: {
      patientId: string;
      channel: CommChannel;
      messageType: CommunicationRecord['message_type'];
      subject: string;
      body: string;
      lockScreenSafePreview: string;
      accessibleFormat?: string;
      language?: string;
      simulateFailure?: boolean;
      failureReason?: string;
    },
    actorUserId: string,
    actorRole: string,
  ): CommunicationRecord;
}

export interface VideoConsultationAdapter {
  readonly adapterName: string;
  generateSessionLink(appointmentId: string): string;
}

export interface CalendarExportAdapter {
  readonly adapterName: string;
  generateIcs(appointment: {
    id: string;
    specialty: string;
    siteName: string;
    roomName: string;
    startIso: string;
    endIso: string;
    format: string;
  }): string;
}

export const mockPasAdapter: PasDemographicsAdapter = {
  adapterName: 'Simulated PAS / Spine PDS Adapter',
  authoritativeFor: ['nhs_number', 'nhs_verification_status', 'legal_name', 'date_of_birth'],
  verifyNhsNumber(nhsNumber: string | null) {
    const cleaned = (nhsNumber ?? '').replace(/\s+/g, '');
    if (cleaned.length === 10 && /^\d{10}$/.test(cleaned) && !cleaned.startsWith('943812')) {
      return {
        status: 'verified',
        sourceRef: `PDS-MOCK-${cleaned.slice(-4)}`,
        checkedAt: new Date().toISOString(),
      };
    }
    if (cleaned.startsWith('943812')) {
      return {
        status: 'unverified',
        sourceRef: 'PDS-MOCK-PENDING',
        checkedAt: new Date().toISOString(),
      };
    }
    return {
      status: 'mismatch',
      sourceRef: 'PDS-MOCK-MISMATCH',
      checkedAt: new Date().toISOString(),
    };
  },
};

export const mockEprAdapter: EprClinicalSummaryAdapter = {
  adapterName: 'Simulated Trust EPR Adapter',
  authoritativeFor: ['clinical_diagnosis', 'allergies', 'clinical_discharge_readiness'],
  fetchPreAdmissionReadiness(patientId: string) {
    return {
      authoritativeSource: 'Simulated Trust EPR (Read-only summary)',
      clinicalClearanceAvailable: true,
      summaryNote: `Simulated EPR link active for ${patientId}. Clinical diagnosis and medication records remain in Trust EPR.`,
    };
  },
};

export const mockErsAdapter: ErsReferralAdapter = {
  adapterName: 'Simulated NHS e-RS Adapter',
  authoritativeFor: ['external_ubrn', 'referral_source', 'received_timestamp'],
  ingestReferralEvent(db, ev, actorUserId, actorRole) {
    const existing = db
      .prepare('SELECT * FROM integration_events WHERE idempotency_key = ?')
      .get(ev.idempotencyKey);

    const now = new Date().toISOString();

    if (existing) {
      const dupId = `INT-${randomUUID().slice(0, 8).toUpperCase()}`;
      const dupKey = `${ev.idempotencyKey}-DUP-${Date.now()}`;
      db.prepare(
        `INSERT INTO integration_events (
          id, adapter_name, external_event_id, idempotency_key, direction,
          authoritative_source, payload_json, sync_status, conflict_detail, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        dupId,
        this.adapterName,
        ev.externalEventId,
        dupKey,
        'Inbound',
        'External e-RS (Simulated)',
        JSON.stringify(ev),
        'Duplicate Ignored',
        `Idempotency key ${ev.idempotencyKey} already processed at ${String(existing['created_at'])}.`,
        now,
      );

      recordAudit(db, {
        actorUserId,
        actorRole,
        action: 'INTEGRATION_DUPLICATE_IGNORED',
        entityType: 'integration_event',
        entityId: dupId,
        patientId: ev.patientId,
        details: {idempotencyKey: ev.idempotencyKey, externalEventId: ev.externalEventId},
      });

      return {
        status: 'Duplicate Ignored',
        event: {
          id: dupId,
          adapter_name: this.adapterName,
          external_event_id: ev.externalEventId,
          idempotency_key: dupKey,
          direction: 'Inbound',
          authoritative_source: 'External e-RS (Simulated)',
          payload: ev,
          sync_status: 'Duplicate Ignored',
          conflict_detail: `Idempotency key ${ev.idempotencyKey} already processed.`,
          created_at: now,
        },
      };
    }

    if (ev.simulateConflict) {
      const conflictId = `INT-${randomUUID().slice(0, 8).toUpperCase()}`;
      const conflictDetail =
        'Demographic mismatch between inbound e-RS referral payload and authoritative PAS DOB. Queued for manual identity review.';
      db.prepare(
        `INSERT INTO integration_events (
          id, adapter_name, external_event_id, idempotency_key, direction,
          authoritative_source, payload_json, sync_status, conflict_detail, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        conflictId,
        this.adapterName,
        ev.externalEventId,
        ev.idempotencyKey,
        'Inbound',
        'External e-RS (Simulated)',
        JSON.stringify(ev),
        'Conflict',
        conflictDetail,
        now,
      );

      const taskId = `TSK-${randomUUID().slice(0, 8).toUpperCase()}`;
      db.prepare(
        `INSERT INTO work_tasks (
          id, queue_type, title, description, entity_type, entity_id,
          patient_id, owner_staff_id, priority_source, due_iso, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        taskId,
        'Identity issue',
        `e-RS demographic conflict (${ev.externalEventId})`,
        conflictDetail,
        'integration_event',
        conflictId,
        ev.patientId,
        'USR-ADMIN',
        'Integration adapter check',
        new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
        'Open',
        now,
      );

      recordAudit(db, {
        actorUserId,
        actorRole,
        action: 'INTEGRATION_CONFLICT_DETECTED',
        entityType: 'integration_event',
        entityId: conflictId,
        patientId: ev.patientId,
        details: {conflictDetail},
      });

      return {
        status: 'Conflict',
        event: {
          id: conflictId,
          adapter_name: this.adapterName,
          external_event_id: ev.externalEventId,
          idempotency_key: ev.idempotencyKey,
          direction: 'Inbound',
          authoritative_source: 'External e-RS (Simulated)',
          payload: ev,
          sync_status: 'Conflict',
          conflict_detail: conflictDetail,
          created_at: now,
        },
      };
    }

    const refId = `REF-${randomUUID().slice(0, 8).toUpperCase()}`;
    const eventId = `INT-${randomUUID().slice(0, 8).toUpperCase()}`;

    db.exec('BEGIN IMMEDIATE;');
    try {
      db.prepare(
        `INSERT INTO referrals (
          id, patient_id, specialty, service_name, referral_source, received_at,
          status, clinical_priority, priority_assigned_by, appointment_requirements,
          required_duration_mins, required_format, required_resources_json,
          interpreter_language, supporting_docs_json, review_history_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        refId,
        ev.patientId,
        ev.specialty,
        ev.serviceName,
        ev.referralSource,
        now,
        'Awaiting review',
        null,
        null,
        ev.appointmentRequirements,
        ev.requiredDurationMins,
        ev.requiredFormat,
        JSON.stringify(ev.requiredResources ?? []),
        ev.interpreterLanguage ?? null,
        JSON.stringify([
          {
            id: `DOC-${randomUUID().slice(0, 6).toUpperCase()}`,
            title: `e-RS Referral Summary (${ev.externalEventId})`,
            source: 'Simulated e-RS',
            uploaded_at: now,
          },
        ]),
        JSON.stringify([
          {
            timestamp: now,
            actor: actorUserId,
            role: actorRole,
            action: 'Referral received via e-RS adapter',
            note: `External UBRN ${ev.externalEventId}`,
          },
        ]),
      );

      db.prepare(
        `INSERT INTO integration_events (
          id, adapter_name, external_event_id, idempotency_key, direction,
          authoritative_source, payload_json, sync_status, conflict_detail, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        eventId,
        this.adapterName,
        ev.externalEventId,
        ev.idempotencyKey,
        'Inbound',
        'External e-RS (Simulated)',
        JSON.stringify(ev),
        'Synced',
        null,
        now,
      );

      const taskId = `TSK-${randomUUID().slice(0, 8).toUpperCase()}`;
      db.prepare(
        `INSERT INTO work_tasks (
          id, queue_type, title, description, entity_type, entity_id,
          patient_id, owner_staff_id, priority_source, due_iso, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        taskId,
        'Awaiting clinical review',
        `Clinical triage required: ${ev.specialty} referral (${refId})`,
        `Inbound referral from ${ev.referralSource} requires authorised clinician review and priority assignment.`,
        'referral',
        refId,
        ev.patientId,
        'USR-PATEL',
        'Referral triage SLA (48h)',
        new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
        'Open',
        now,
      );

      recordAudit(db, {
        actorUserId,
        actorRole,
        action: 'REFERRAL_INGESTED_VIA_ADAPTER',
        entityType: 'referral',
        entityId: refId,
        patientId: ev.patientId,
        details: {externalEventId: ev.externalEventId, specialty: ev.specialty},
      });

      db.exec('COMMIT;');
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }

    return {
      status: 'Synced',
      referralId: refId,
      event: {
        id: eventId,
        adapter_name: this.adapterName,
        external_event_id: ev.externalEventId,
        idempotency_key: ev.idempotencyKey,
        direction: 'Inbound',
        authoritative_source: 'External e-RS (Simulated)',
        payload: ev,
        sync_status: 'Synced',
        conflict_detail: null,
        created_at: now,
      },
    };
  },
};

export const mockMessagingAdapter: MessagingAdapter = {
  adapterName: 'Simulated NHS Notify / Trust Comms Adapter',
  dispatch(db, params, actorUserId, actorRole) {
    const id = `COM-${randomUUID().slice(0, 8).toUpperCase()}`;
    const now = new Date().toISOString();
    const status: CommunicationRecord['status'] = params.simulateFailure
      ? 'Failed'
      : params.channel === 'Portal'
        ? 'Delivered'
        : 'Sent';

    const safePreview =
      params.lockScreenSafePreview.trim() ||
      'Pennine University Hospital: You have a hospital appointment update. Sign in to view details.';

    db.prepare(
      `INSERT INTO communications (
        id, patient_id, channel, message_type, subject, body,
        lock_screen_safe_preview, status, failure_reason, accessible_format,
        language, emergency_disclaimer_shown, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
    ).run(
      id,
      params.patientId,
      params.channel,
      params.messageType,
      params.subject,
      params.body,
      safePreview,
      status,
      params.simulateFailure ? params.failureReason || 'Simulated carrier delivery timeout (4801)' : null,
      params.accessibleFormat || 'Standard',
      params.language || 'English',
      now,
      now,
    );

    if (status === 'Failed') {
      const taskId = `TSK-${randomUUID().slice(0, 8).toUpperCase()}`;
      db.prepare(
        `INSERT INTO work_tasks (
          id, queue_type, title, description, entity_type, entity_id,
          patient_id, owner_staff_id, priority_source, due_iso, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        taskId,
        'Failed communication',
        `Failed ${params.channel} ${params.messageType.toLowerCase()} delivery`,
        `Delivery failed (${params.failureReason || 'carrier timeout'}). Contact patient via fallback channel without cancelling appointment.`,
        'communication',
        id,
        params.patientId,
        'USR-JENKINS',
        'Patient safety & access check',
        new Date(Date.now() + 12 * 3600 * 1000).toISOString(),
        'Open',
        now,
      );
    }

    recordAudit(db, {
      actorUserId,
      actorRole,
      action: status === 'Failed' ? 'COMMUNICATION_FAILED' : 'COMMUNICATION_SENT',
      entityType: 'communication',
      entityId: id,
      patientId: params.patientId,
      details: {channel: params.channel, messageType: params.messageType, status},
    });

    return {
      id,
      patient_id: params.patientId,
      channel: params.channel,
      message_type: params.messageType,
      subject: params.subject,
      body: params.body,
      lock_screen_safe_preview: safePreview,
      status,
      failure_reason: params.simulateFailure
        ? params.failureReason || 'Simulated carrier delivery timeout (4801)'
        : null,
      accessible_format: params.accessibleFormat || 'Standard',
      language: params.language || 'English',
      emergency_disclaimer_shown: true,
      created_at: now,
      updated_at: now,
    };
  },
};

export const mockVideoAdapter: VideoConsultationAdapter = {
  adapterName: 'Simulated Video Consultation Adapter',
  generateSessionLink(appointmentId: string): string {
    return `https://video-demo.pennine-hospital.example/waiting-room/${appointmentId}`;
  },
};

export const mockCalendarAdapter: CalendarExportAdapter = {
  adapterName: 'Approved Calendar Export (.ics, redacted)',
  generateIcs(appt): string {
    const dtStart = appt.startIso.replace(/[-:]/g, '').split('.')[0] + 'Z';
    const dtEnd = appt.endIso.replace(/[-:]/g, '').split('.')[0] + 'Z';
    return [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//TertiusMedico Prototype//Pennine University Hospital//EN',
      'BEGIN:VEVENT',
      `UID:${appt.id}@tertiusmedico.prototype`,
      `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z`,
      `DTSTART:${dtStart}`,
      `DTEND:${dtEnd}`,
      `SUMMARY:Hospital Appointment (${appt.format})`,
      `LOCATION:${appt.siteName} - ${appt.roomName}`,
      'DESCRIPTION:Hospital appointment reminder. Clinical details are withheld from calendar export for privacy.',
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');
  },
};
