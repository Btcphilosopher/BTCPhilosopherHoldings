import {randomBytes, randomUUID, scryptSync, timingSafeEqual} from 'node:crypto';
import type {DatabaseSync} from 'node:sqlite';
import express, {type NextFunction, type Request, type Response, type Router} from 'express';
import type {
  AppointmentStatus,
  ClinicFormat,
  CommChannel,
  ProxyScope,
  ReferralStatus,
  UserRole,
} from '../../shared/types';
import {recordAudit, verifyAuditChain} from '../services/audit';
import {
  mockCalendarAdapter,
  mockEprAdapter,
  mockErsAdapter,
  mockMessagingAdapter,
  mockPasAdapter,
} from '../services/adapters';
import {realtimeBus} from '../services/realtime';
import {
  bookSlotForReferral,
  evaluateAdmissionConflicts,
  formatUtcInLondon,
  getEligibleSlotsForReferral,
  holdSlot,
  londonLocalToUtcIso,
  releaseExpiredHolds,
  rescheduleAppointment,
  transitionAppointment,
} from '../services/scheduler';
import {seedDemonstratorDatabase} from '../db/seed';

interface AuthenticatedRequest extends Request {
  authSession?: {
    token: string;
    userId: string;
    displayName: string;
    role: UserRole;
    specialty: string | null;
    patientId: string | null;
    mfaVerified: boolean;
  };
}

function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, keyHex] = storedHash.split(':');
  if (!salt || !keyHex) return false;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derived = scryptSync(password, salt, 64);
  if (keyBuf.length !== derived.length) return false;
  return timingSafeEqual(keyBuf, derived);
}

function isStaffRole(role: UserRole): boolean {
  return ['booking_clerk', 'clinician', 'bed_manager', 'service_manager', 'admin'].includes(role);
}

function assertPatientAccess(
  db: DatabaseSync,
  auth: NonNullable<AuthenticatedRequest['authSession']>,
  targetPatientId: string,
  requiredProxyScope: ProxyScope = 'view_appointments',
): void {
  if (isStaffRole(auth.role)) {
    return;
  }
  if (auth.role === 'patient') {
    if (auth.patientId !== targetPatientId) {
      const err = new Error('Patient identity isolation: access denied to another patient record.');
      (err as Error & {statusCode?: number}).statusCode = 403;
      throw err;
    }
    return;
  }
  if (auth.role === 'proxy') {
    const rel = db
      .prepare(
        `SELECT * FROM proxy_relationships
         WHERE proxy_user_id = ? AND patient_id = ?`,
      )
      .get(auth.userId, targetPatientId);

    if (!rel) {
      const err = new Error('Proxy access denied: no relationship exists for this patient.');
      (err as Error & {statusCode?: number}).statusCode = 403;
      throw err;
    }
    if (String(rel['verified_status']) !== 'verified') {
      const err = new Error(
        `Proxy authority not verified (status: ${String(rel['verified_status'])}). Staff verification is required before accessing records.`,
      );
      (err as Error & {statusCode?: number}).statusCode = 403;
      throw err;
    }
    const scope = String(rel['scope']) as ProxyScope;
    const scopeHierarchy: Record<ProxyScope, ProxyScope[]> = {
      view_appointments: ['view_appointments'],
      view_messages: ['view_messages'],
      manage_bookings: ['view_appointments', 'view_messages', 'manage_bookings'],
      full_coordination: ['view_appointments', 'view_messages', 'manage_bookings', 'full_coordination'],
    };
    if (!scopeHierarchy[scope]?.includes(requiredProxyScope)) {
      const err = new Error(
        `Proxy scope "${scope}" does not permit "${requiredProxyScope}".`,
      );
      (err as Error & {statusCode?: number}).statusCode = 403;
      throw err;
    }
    return;
  }

  const err = new Error('Access denied.');
  (err as Error & {statusCode?: number}).statusCode = 403;
  throw err;
}

export function createApiRouter(db: DatabaseSync): Router {
  const router = express.Router();
  router.use(express.json());

  // SSE stream for live operational updates (non-PII notifications only)
  router.get('/events', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();
    res.write(`event: connected\ndata: ${JSON.stringify({status: 'connected', ts: new Date().toISOString()})}\n\n`);
    realtimeBus.addClient(res);
  });

  // Public demonstrator persona directory (usernames & roles only, no patient PII)
  router.get('/auth/personas', (_req: Request, res: Response) => {
    const rows = db
      .prepare(
        `SELECT id, username, display_name, role, specialty, site_id, mfa_enabled
         FROM staff_users ORDER BY role, display_name`,
      )
      .all();
    res.json({
      prototypeNotice:
        'Independent prototype (Pennine University Hospital Demonstrator) using synthetic data only. NHS number alone is never proof of identity.',
      personas: rows.map((r) => ({
        id: String(r['id']),
        username: String(r['username']),
        display_name: String(r['display_name']),
        role: String(r['role']),
        specialty: r['specialty'] ? String(r['specialty']) : null,
        site_id: r['site_id'] ? String(r['site_id']) : null,
        mfa_enabled: Boolean(r['mfa_enabled']),
      })),
    });
  });

  router.post('/auth/login', (req: Request, res: Response) => {
    const {username, password, demoQuickSignIn} = req.body ?? {};
    if (!username || typeof username !== 'string') {
      res.status(400).json({error: 'Username is required.'});
      return;
    }

    const userRow = db
      .prepare('SELECT * FROM staff_users WHERE username = ?')
      .get(username.trim());

    if (!userRow) {
      res.status(401).json({error: 'Invalid credentials.'});
      return;
    }

    if (!demoQuickSignIn) {
      if (!password || typeof password !== 'string' || !verifyPassword(password, String(userRow['password_hash']))) {
        res.status(401).json({error: 'Invalid username or passcode.'});
        return;
      }
    }

    const token = randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 8 * 3600 * 1000).toISOString();
    const role = String(userRow['role']) as UserRole;
    const mfaRequired = Boolean(userRow['mfa_enabled']);

    db.prepare(
      `INSERT INTO sessions (token, user_id, role, patient_id, mfa_verified, expires_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
    ).run(
      token,
      String(userRow['id']),
      role,
      userRow['patient_id'] ? String(userRow['patient_id']) : null,
      mfaRequired && !demoQuickSignIn ? 0 : 1,
      expiresAt,
    );

    recordAudit(db, {
      actorUserId: String(userRow['id']),
      actorRole: role,
      action: 'USER_SIGNED_IN',
      entityType: 'session',
      entityId: String(userRow['id']),
      patientId: userRow['patient_id'] ? String(userRow['patient_id']) : null,
      details: {method: demoQuickSignIn ? 'demonstrator_persona_switch' : 'passcode'},
    });

    res.json({
      token,
      expires_at: expiresAt,
      mfa_verified: !(mfaRequired && !demoQuickSignIn),
      user: {
        id: String(userRow['id']),
        username: String(userRow['username']),
        display_name: String(userRow['display_name']),
        role,
        specialty: userRow['specialty'] ? String(userRow['specialty']) : null,
        competencies: JSON.parse(String(userRow['competencies_json'] || '[]')),
        site_id: userRow['site_id'] ? String(userRow['site_id']) : null,
        contracted_hours: Number(userRow['contracted_hours']),
        mfa_enabled: mfaRequired,
        patient_id: userRow['patient_id'] ? String(userRow['patient_id']) : null,
      },
    });
  });

  // Auth middleware for all subsequent routes
  const requireAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({error: 'Authentication required (missing Bearer token).'});
      return;
    }
    const token = authHeader.slice(7).trim();
    const sessionRow = db
      .prepare(
        `SELECT s.*, u.display_name, u.specialty
         FROM sessions s
         JOIN staff_users u ON u.id = s.user_id
         WHERE s.token = ?`,
      )
      .get(token);

    if (!sessionRow) {
      res.status(401).json({error: 'Session invalid or expired.'});
      return;
    }

    if (new Date(String(sessionRow['expires_at'])).getTime() <= Date.now()) {
      db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
      res.status(401).json({error: 'Session expired. Please sign in again.'});
      return;
    }

    req.authSession = {
      token,
      userId: String(sessionRow['user_id']),
      displayName: String(sessionRow['display_name']),
      role: String(sessionRow['role']) as UserRole,
      specialty: sessionRow['specialty'] ? String(sessionRow['specialty']) : null,
      patientId: sessionRow['patient_id'] ? String(sessionRow['patient_id']) : null,
      mfaVerified: Boolean(sessionRow['mfa_verified']),
    };
    next();
  };

  const requireStaff = (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.authSession || !isStaffRole(req.authSession.role)) {
      res.status(403).json({error: 'Staff role required for this workspace endpoint.'});
      return;
    }
    next();
  };

  router.use(requireAuth);

  router.post('/auth/mfa-verify', (req: AuthenticatedRequest, res: Response) => {
    const {code} = req.body ?? {};
    if (!code || !/^\d{6}$/.test(String(code))) {
      res.status(400).json({error: 'Enter a valid 6-digit verification code.'});
      return;
    }
    db.prepare('UPDATE sessions SET mfa_verified = 1 WHERE token = ?').run(req.authSession!.token);
    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'MFA_VERIFIED',
      entityType: 'session',
      entityId: req.authSession!.userId,
    });
    res.json({mfa_verified: true});
  });

  router.post('/auth/logout', (req: AuthenticatedRequest, res: Response) => {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(req.authSession!.token);
    res.json({ok: true});
  });

  router.get('/bootstrap', (req: AuthenticatedRequest, res: Response) => {
    const sites = db.prepare('SELECT * FROM sites ORDER BY name').all();
    const auth = req.authSession!;

    // Compute live 15-step Pennine Demonstrator checklist status
    const refCard01 = db.prepare(`SELECT status, clinical_priority FROM referrals WHERE id = 'REF-CARD-01'`).get();
    const wlCount = db.prepare(`SELECT COUNT(*) AS c FROM waiting_list_entries`).get();
    const heldCount = db.prepare(`SELECT COUNT(*) AS c FROM audit_logs WHERE action = 'SLOT_HELD'`).get();
    const bookedCount = db.prepare(`SELECT COUNT(*) AS c FROM audit_logs WHERE action = 'APPOINTMENT_BOOKED'`).get();
    const arrivedOrCompleted = db
      .prepare(`SELECT COUNT(*) AS c FROM appointments WHERE status IN ('Arrived', 'In progress', 'Completed')`)
      .get();
    const followUpCount = db
      .prepare(`SELECT COUNT(*) AS c FROM audit_logs WHERE action = 'FOLLOW_UP_ARRANGED'`)
      .get();
    const admTotal = db.prepare(`SELECT COUNT(*) AS c FROM planned_admissions`).get();
    const admClear = db
      .prepare(`SELECT COUNT(*) AS c FROM planned_admissions WHERE conflict_status = 'Clear'`)
      .get();
    const absenceCount = db
      .prepare(`SELECT COUNT(*) AS c FROM staff_rotas WHERE assignment_type IN ('Leave', 'Sickness Absence')`)
      .get();
    const contactTasksResolved = db
      .prepare(`SELECT COUNT(*) AS c FROM work_tasks WHERE queue_type IN ('Patient needing contact', 'Failed communication') AND status = 'Resolved'`)
      .get();

    const checklist = [
      {
        step: 1,
        title: 'Receive a referral',
        description: 'Arthur Pendelton Cardiology referral (REF-CARD-01) received from Shipley GP.',
        completed: Boolean(refCard01),
        target_view: 'referrals',
      },
      {
        step: 2,
        title: 'Complete authorised clinical review',
        description: 'Sign in as Dr. Hannah Patel (Clinician) and accept REF-CARD-01 with clinical priority.',
        completed: refCard01 ? String(refCard01['status']) === 'Accepted' && Boolean(refCard01['clinical_priority']) : false,
        target_view: 'referrals',
      },
      {
        step: 3,
        title: 'Add patient to waiting list',
        description: 'Waiting list entry created separately from appointment booking, preserving RTT clock start.',
        completed: Number(wlCount?.['c'] ?? 0) >= 4 || (refCard01 ? String(refCard01['status']) === 'Accepted' : false),
        target_view: 'waiting-lists',
      },
      {
        step: 4,
        title: 'Offer eligible appointment slots',
        description: 'View Cardiology slots matched by specialty, 12-lead ECG, format, and booking window.',
        completed: refCard01 ? String(refCard01['status']) === 'Accepted' : false,
        target_view: 'patient-book',
      },
      {
        step: 5,
        title: 'Patient holds & selects a slot',
        description: 'Switch to Arthur Pendelton (Patient Portal) to hold and confirm an eligible slot.',
        completed: Number(heldCount?.['c'] ?? 0) > 0 && Number(bookedCount?.['c'] ?? 0) > 0,
        target_view: 'patient-book',
      },
      {
        step: 6,
        title: 'Block competing concurrent hold',
        description: 'Use the Concurrency Test button in Book or Change to verify HTTP 409 lock rejection.',
        completed: Number(heldCount?.['c'] ?? 0) > 0,
        target_view: 'patient-book',
      },
      {
        step: 7,
        title: 'Send simulated confirmation',
        description: 'Lock-screen safe confirmation recorded in Communications & Patient Messages.',
        completed: Number(bookedCount?.['c'] ?? 0) > 0,
        target_view: 'communications',
      },
      {
        step: 8,
        title: 'Record arrival & completion',
        description: 'Mark appointment Arrived (clerk/clinician) then In progress -> Completed (clinician).',
        completed: Number(arrivedOrCompleted?.['c'] ?? 0) > 0,
        target_view: 'appointments',
      },
      {
        step: 9,
        title: 'Arrange follow-up',
        description: 'Create a linked follow-up referral/appointment from a completed visit.',
        completed: Number(followUpCount?.['c'] ?? 0) > 0,
        target_view: 'appointments',
      },
      {
        step: 10,
        title: 'Plan an inpatient admission',
        description: 'Create or inspect planned admission ADM-001 for Eleanor Rigby-Smythe.',
        completed: Number(admTotal?.['c'] ?? 0) > 0,
        target_view: 'inpatients',
      },
      {
        step: 11,
        title: 'Detect bed or staffing conflict',
        description: 'ADM-001 flags Maintenance Closed Bed 4B-06 and pending Blood group & save.',
        completed: Number(admTotal?.['c'] ?? 0) > 0,
        target_view: 'inpatients',
      },
      {
        step: 12,
        title: 'Resolve conflict through staff review',
        description: 'Reallocate ADM-001 to available Bed 4B-07/4B-08 and complete prerequisites.',
        completed: Number(admClear?.['c'] ?? 0) > 0,
        target_view: 'beds',
      },
      {
        step: 13,
        title: 'Handle clinician absence',
        description: 'Record absence on Dr. Miriam Okafor’s published clinic in Staff Rotas to generate affected-work queue.',
        completed: Number(absenceCount?.['c'] ?? 0) > 0,
        target_view: 'rotas',
      },
      {
        step: 14,
        title: 'Contact affected patients',
        description: 'Resolve a failed reminder or absence contact task in Communications / Work Queues.',
        completed: Number(contactTasksResolved?.['c'] ?? 0) > 0,
        target_view: 'communications',
      },
      {
        step: 15,
        title: 'Review audit trail & operational report',
        description: 'Inspect hash-chained audit verification and live operational metrics.',
        completed: true,
        target_view: 'reports',
      },
    ];

    res.json({
      sites,
      user: {
        id: auth.userId,
        display_name: auth.displayName,
        role: auth.role,
        specialty: auth.specialty,
        patient_id: auth.patientId,
        mfa_verified: auth.mfaVerified,
      },
      checklist,
    });
  });

  // --- PATIENTS & PROXIES ---
  router.get('/patients', (req: AuthenticatedRequest, res: Response) => {
    const auth = req.authSession!;
    let rows: Record<string, unknown>[];
    if (isStaffRole(auth.role)) {
      rows = db.prepare('SELECT * FROM patients ORDER BY family_name, given_name').all();
    } else if (auth.role === 'patient' && auth.patientId) {
      rows = db.prepare('SELECT * FROM patients WHERE internal_id = ?').all(auth.patientId);
    } else if (auth.role === 'proxy') {
      rows = db
        .prepare(
          `SELECT p.* FROM patients p
           JOIN proxy_relationships pr ON pr.patient_id = p.internal_id
           WHERE pr.proxy_user_id = ? AND pr.verified_status = 'verified'`,
        )
        .all(auth.userId);
    } else {
      rows = [];
    }

    res.json(
      rows.map((r) => ({
        ...r,
        interpreter_required: Boolean(r['interpreter_required']),
        accessibility_needs: JSON.parse(String(r['accessibility_needs_json'] || '[]')),
        source_system_ids: JSON.parse(String(r['source_system_ids_json'] || '{}')),
      })),
    );
  });

  router.get('/patients/:id', (req: AuthenticatedRequest, res: Response) => {
    const patientId = String(req.params['id']);
    try {
      assertPatientAccess(db, req.authSession!, patientId, 'view_appointments');
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 403).json({error: err.message});
      return;
    }

    const r = db.prepare('SELECT * FROM patients WHERE internal_id = ?').get(patientId);
    if (!r) {
      res.status(404).json({error: 'Patient not found'});
      return;
    }

    const proxies = db
      .prepare('SELECT * FROM proxy_relationships WHERE patient_id = ?')
      .all(patientId);

    res.json({
      ...r,
      interpreter_required: Boolean(r['interpreter_required']),
      accessibility_needs: JSON.parse(String(r['accessibility_needs_json'] || '[]')),
      source_system_ids: JSON.parse(String(r['source_system_ids_json'] || '{}')),
      proxies,
      epr_readiness: mockEprAdapter.fetchPreAdmissionReadiness(patientId),
    });
  });

  router.patch('/patients/:id', (req: AuthenticatedRequest, res: Response) => {
    const patientId = String(req.params['id']);
    try {
      assertPatientAccess(db, req.authSession!, patientId, 'full_coordination');
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 403).json({error: err.message});
      return;
    }

    const {preferred_channel, preferred_language, interpreter_required, accessibility_needs, phone, email} =
      req.body ?? {};

    const current = db.prepare('SELECT * FROM patients WHERE internal_id = ?').get(patientId);
    if (!current) {
      res.status(404).json({error: 'Patient not found'});
      return;
    }

    db.prepare(
      `UPDATE patients SET
        preferred_channel = COALESCE(?, preferred_channel),
        preferred_language = COALESCE(?, preferred_language),
        interpreter_required = COALESCE(?, interpreter_required),
        accessibility_needs_json = COALESCE(?, accessibility_needs_json),
        phone = COALESCE(?, phone),
        email = COALESCE(?, email)
       WHERE internal_id = ?`,
    ).run(
      preferred_channel ?? null,
      preferred_language ?? null,
      typeof interpreter_required === 'boolean' ? (interpreter_required ? 1 : 0) : null,
      Array.isArray(accessibility_needs) ? JSON.stringify(accessibility_needs) : null,
      phone ?? null,
      email ?? null,
      patientId,
    );

    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'PATIENT_PREFERENCES_UPDATED',
      entityType: 'patient',
      entityId: patientId,
      patientId,
      details: {preferred_channel, preferred_language, interpreter_required},
    });

    res.json({ok: true});
  });

  router.post('/patients/:id/verify-nhs', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const patientId = String(req.params['id']);
    const p = db.prepare('SELECT * FROM patients WHERE internal_id = ?').get(patientId);
    if (!p) {
      res.status(404).json({error: 'Patient not found'});
      return;
    }
    const {overrideStatus} = req.body ?? {};
    const pasResult = mockPasAdapter.verifyNhsNumber(
      p['nhs_number'] ? String(p['nhs_number']) : null,
    );
    const finalStatus = overrideStatus || pasResult.status;

    db.prepare(`UPDATE patients SET nhs_verification_status = ? WHERE internal_id = ?`).run(
      finalStatus,
      patientId,
    );

    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'PATIENT_NHS_VERIFICATION_UPDATED',
      entityType: 'patient',
      entityId: patientId,
      patientId,
      details: {finalStatus, pasSourceRef: pasResult.sourceRef},
    });

    res.json({nhs_verification_status: finalStatus, pasResult});
  });

  router.post('/patients/:id/flag-duplicate', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const patientId = String(req.params['id']);
    const {candidatePatientId, resolutionAction, notes} = req.body ?? {};
    // Duplicate-record review NEVER automatically merges patient records
    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'DUPLICATE_RECORD_REVIEWED',
      entityType: 'patient',
      entityId: patientId,
      patientId,
      details: {
        candidatePatientId,
        resolutionAction: resolutionAction || 'kept_separate_under_review',
        autoMerged: false,
        notes: notes || '',
      },
    });
    if (resolutionAction === 'confirmed_distinct') {
      db.prepare(`UPDATE patients SET duplicate_flag_patient_id = NULL WHERE internal_id IN (?, ?)`).run(
        patientId,
        String(candidatePatientId || ''),
      );
    }
    res.json({ok: true, autoMerged: false});
  });

  router.patch('/proxies/:id', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const proxyId = String(req.params['id']);
    const {verified_status, scope} = req.body ?? {};
    const existing = db.prepare('SELECT * FROM proxy_relationships WHERE id = ?').get(proxyId);
    if (!existing) {
      res.status(404).json({error: 'Proxy relationship not found'});
      return;
    }

    db.prepare(
      `UPDATE proxy_relationships
       SET verified_status = COALESCE(?, verified_status),
           scope = COALESCE(?, scope),
           verified_by = ?,
           verified_at = ?
       WHERE id = ?`,
    ).run(
      verified_status ?? null,
      scope ?? null,
      req.authSession!.userId,
      new Date().toISOString(),
      proxyId,
    );

    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'PROXY_RELATIONSHIP_UPDATED',
      entityType: 'proxy_relationship',
      entityId: proxyId,
      patientId: String(existing['patient_id']),
      details: {verified_status, scope},
    });
    res.json({ok: true});
  });

  // --- REFERRALS & WAITING LISTS ---
  router.get('/referrals', (req: AuthenticatedRequest, res: Response) => {
    const auth = req.authSession!;
    let query = `
      SELECT r.*, p.given_name || ' ' || p.family_name AS patient_name, p.nhs_number AS patient_nhs
      FROM referrals r
      JOIN patients p ON p.internal_id = r.patient_id
    `;
    const params: string[] = [];

    if (auth.role === 'patient' && auth.patientId) {
      query += ' WHERE r.patient_id = ?';
      params.push(auth.patientId);
    } else if (auth.role === 'proxy') {
      query += `
        JOIN proxy_relationships pr ON pr.patient_id = r.patient_id
        WHERE pr.proxy_user_id = ? AND pr.verified_status = 'verified'
      `;
      params.push(auth.userId);
    } else if (!isStaffRole(auth.role)) {
      res.json([]);
      return;
    }

    query += ' ORDER BY r.received_at DESC';
    const rows = db.prepare(query).all(...params);

    res.json(
      rows.map((r) => ({
        ...r,
        required_resources: JSON.parse(String(r['required_resources_json'] || '[]')),
        supporting_docs: JSON.parse(String(r['supporting_docs_json'] || '[]')),
        review_history: JSON.parse(String(r['review_history_json'] || '[]')),
      })),
    );
  });

  router.post('/referrals', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const {
      patient_id,
      specialty,
      service_name,
      referral_source,
      appointment_requirements,
      required_duration_mins,
      required_format,
      required_resources,
      interpreter_language,
    } = req.body ?? {};

    if (!patient_id || !specialty || !service_name) {
      res.status(400).json({error: 'patient_id, specialty, and service_name are required.'});
      return;
    }

    const id = `REF-${randomUUID().slice(0, 8).toUpperCase()}`;
    const now = new Date().toISOString();
    const history = [
      {
        timestamp: now,
        actor: req.authSession!.displayName,
        role: req.authSession!.role,
        action: 'Referral received',
        note: referral_source || 'Trust intake',
      },
    ];

    db.prepare(
      `INSERT INTO referrals (
        id, patient_id, specialty, service_name, referral_source, received_at,
        status, appointment_requirements, required_duration_mins, required_format,
        required_resources_json, interpreter_language, supporting_docs_json, review_history_json
      ) VALUES (?, ?, ?, ?, ?, ?, 'Awaiting review', ?, ?, ?, ?, ?, '[]', ?)`,
    ).run(
      id,
      String(patient_id),
      String(specialty),
      String(service_name),
      String(referral_source || 'GP Practice (Manual intake)'),
      now,
      String(appointment_requirements || 'Standard outpatient review'),
      Number(required_duration_mins || 20),
      String(required_format || 'In-person'),
      JSON.stringify(Array.isArray(required_resources) ? required_resources : []),
      interpreter_language || null,
      JSON.stringify(history),
    );

    db.prepare(
      `INSERT INTO work_tasks (
        id, queue_type, title, description, entity_type, entity_id,
        patient_id, owner_staff_id, priority_source, due_iso, status, created_at
      ) VALUES (?, 'Awaiting clinical review', ?, ?, 'referral', ?, ?, 'USR-PATEL', 'Clinical triage SLA', ?, 'Open', ?)`,
    ).run(
      `TSK-${randomUUID().slice(0, 8).toUpperCase()}`,
      `Clinical triage required: ${specialty} (${id})`,
      appointment_requirements || 'Requires authorised clinician review.',
      id,
      String(patient_id),
      new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
      now,
    );

    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'REFERRAL_CREATED',
      entityType: 'referral',
      entityId: id,
      patientId: String(patient_id),
      details: {specialty, service_name},
    });

    realtimeBus.broadcast('referral:created', {referralId: id});
    res.status(201).json({id, status: 'Awaiting review'});
  });

  // Strictly restricted to clinician (or admin override with clinical audit) for priority & acceptance!
  router.post('/referrals/:id/review', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const auth = req.authSession!;
    if (auth.role !== 'clinician' && auth.role !== 'admin') {
      res.status(403).json({
        error:
          'Clinical-role restriction: Only authorised clinical users may assign clinical priority or complete clinical referral review.',
      });
      return;
    }

    const referralId = String(req.params['id']);
    const ref = db.prepare('SELECT * FROM referrals WHERE id = ?').get(referralId);
    if (!ref) {
      res.status(404).json({error: 'Referral not found'});
      return;
    }

    const {
      status,
      clinical_priority,
      review_notes,
      booking_window_days,
      required_duration_mins,
      required_format,
      add_to_waiting_list,
    } = req.body ?? {};

    const validStatuses: ReferralStatus[] = [
      'Awaiting review',
      'Accepted',
      'Redirected',
      'Further information required',
      'Declined',
    ];
    if (!validStatuses.includes(status)) {
      res.status(400).json({error: 'Invalid clinical review status.'});
      return;
    }
    if (status === 'Accepted' && !['Urgent', 'Soon', 'Routine'].includes(clinical_priority)) {
      res.status(400).json({error: 'Accepted referrals require a clinical priority (Urgent, Soon, or Routine).'});
      return;
    }

    const now = new Date().toISOString();
    const history: unknown[] = JSON.parse(String(ref['review_history_json'] || '[]'));
    history.push({
      timestamp: now,
      actor: auth.displayName,
      role: auth.role,
      action: `${status}${clinical_priority ? ` (${clinical_priority})` : ''}`,
      note: review_notes || '',
    });

    db.exec('BEGIN IMMEDIATE;');
    try {
      db.prepare(
        `UPDATE referrals
         SET status = ?,
             clinical_priority = COALESCE(?, clinical_priority),
             priority_assigned_by = COALESCE(?, priority_assigned_by),
             review_notes = COALESCE(?, review_notes),
             booking_window_days = COALESCE(?, booking_window_days),
             required_duration_mins = COALESCE(?, required_duration_mins),
             required_format = COALESCE(?, required_format),
             reviewed_at = ?,
             reviewed_by = ?,
             review_history_json = ?
         WHERE id = ?`,
      ).run(
        status,
        clinical_priority ?? null,
        clinical_priority ? auth.userId : null,
        review_notes ?? null,
        booking_window_days ? Number(booking_window_days) : null,
        required_duration_mins ? Number(required_duration_mins) : null,
        required_format ?? null,
        now,
        auth.userId,
        JSON.stringify(history),
        referralId,
      );

      // Mark open triage task resolved
      db.prepare(
        `UPDATE work_tasks SET status = 'Resolved', resolution_note = ?
         WHERE entity_type = 'referral' AND entity_id = ? AND queue_type = 'Awaiting clinical review' AND status != 'Resolved'`,
      ).run(`Reviewed by ${auth.displayName}: ${status}`, referralId);

      // Automatically add to waiting list when Accepted (unless explicitly disabled)
      let waitingListId: string | null = null;
      if (status === 'Accepted' && add_to_waiting_list !== false) {
        const existingWl = db
          .prepare('SELECT id FROM waiting_list_entries WHERE referral_id = ?')
          .get(referralId);
        if (!existingWl) {
          waitingListId = `WL-${randomUUID().slice(0, 8).toUpperCase()}`;
          db.prepare(
            `INSERT INTO waiting_list_entries (
              id, referral_id, patient_id, specialty, service_name,
              clinical_priority, original_rtt_clock_start, current_status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?)`,
          ).run(
            waitingListId,
            referralId,
            String(ref['patient_id']),
            String(ref['specialty']),
            String(ref['service_name']),
            String(clinical_priority),
            String(ref['received_at']), // Preserve original received_at!
            now,
          );
        } else {
          waitingListId = String(existingWl['id']);
          db.prepare(`UPDATE waiting_list_entries SET clinical_priority = ? WHERE id = ?`).run(
            String(clinical_priority),
            waitingListId,
          );
        }

        // Send appointment offer notification to patient
        mockMessagingAdapter.dispatch(
          db,
          {
            patientId: String(ref['patient_id']),
            channel: 'Portal',
            messageType: 'Offer',
            subject: `Appointment offer ready: ${String(ref['specialty'])}`,
            body: `Your ${String(ref['specialty'])} referral has been clinically reviewed (${String(clinical_priority)}). You may now choose an eligible appointment slot in the patient portal or call our booking team.`,
            lockScreenSafePreview:
              'Pennine University Hospital: You have a new appointment offer available to view.',
          },
          auth.userId,
          auth.role,
        );
      }

      if (status === 'Further information required') {
        db.prepare(
          `INSERT INTO work_tasks (
            id, queue_type, title, description, entity_type, entity_id,
            patient_id, owner_staff_id, priority_source, due_iso, status, created_at
          ) VALUES (?, 'Incomplete referral', ?, ?, 'referral', ?, ?, 'USR-JENKINS', 'Clinical review feedback', ?, 'Open', ?)`,
        ).run(
          `TSK-${randomUUID().slice(0, 8).toUpperCase()}`,
          `Further information requested for ${referralId}`,
          review_notes || 'Clinician requested additional information from referrer.',
          referralId,
          String(ref['patient_id']),
          new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
          now,
        );
      }

      recordAudit(db, {
        actorUserId: auth.userId,
        actorRole: auth.role,
        action: 'REFERRAL_CLINICAL_REVIEW',
        entityType: 'referral',
        entityId: referralId,
        patientId: String(ref['patient_id']),
        details: {status, clinical_priority, waitingListId, review_notes},
      });

      db.exec('COMMIT;');
      realtimeBus.broadcast('referral:reviewed', {referralId, status, clinical_priority});
      res.json({ok: true, status, clinical_priority, waitingListId});
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }
  });

  router.get('/waiting-list', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const rows = db
      .prepare(
        `SELECT w.*, p.given_name || ' ' || p.family_name AS patient_name, p.nhs_number AS patient_nhs,
                (SELECT COUNT(*) FROM appointments a WHERE a.waiting_list_id = w.id) AS linked_appointment_count
         FROM waiting_list_entries w
         JOIN patients p ON p.internal_id = w.patient_id
         ORDER BY
           CASE w.clinical_priority WHEN 'Urgent' THEN 1 WHEN 'Soon' THEN 2 ELSE 3 END,
           w.original_rtt_clock_start ASC`,
      )
      .all();
    res.json(rows);
  });

  // --- CLINICS & TEMPLATES ---
  router.get('/clinic-templates', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const rows = db
      .prepare(
        `SELECT ct.*, st.name AS site_name, u.display_name AS clinician_name
         FROM clinic_templates ct
         JOIN sites st ON st.id = ct.site_id
         JOIN staff_users u ON u.id = ct.clinician_id
         ORDER BY ct.specialty, ct.name, ct.version DESC`,
      )
      .all();
    res.json(
      rows.map((r) => ({
        ...r,
        required_equipment: JSON.parse(String(r['required_equipment_json'] || '[]')),
        group_session_enabled: Boolean(r['group_session_enabled']),
        overbooking_enabled: Boolean(r['overbooking_enabled']),
        active: Boolean(r['active']),
      })),
    );
  });

  router.post('/clinic-templates/:id/amend', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    if (!['service_manager', 'admin'].includes(req.authSession!.role)) {
      res.status(403).json({error: 'Only service managers or administrators may amend clinic templates.'});
      return;
    }
    const tplId = String(req.params['id']);
    const tpl = db.prepare('SELECT * FROM clinic_templates WHERE id = ?').get(tplId);
    if (!tpl) {
      res.status(404).json({error: 'Clinic template not found'});
      return;
    }

    const {default_duration_mins, preparation_instructions, amendment_reason} = req.body ?? {};
    const newVersion = Number(tpl['version']) + 1;
    const now = new Date().toISOString();

    // Find affected future booked appointments on this template (do NOT silently alter them!)
    const affectedAppts = db
      .prepare(
        `SELECT a.id, a.patient_id, a.start_iso
         FROM appointments a
         JOIN appointment_slots s ON s.id = a.slot_id
         JOIN clinic_sessions cs ON cs.id = s.session_id
         WHERE cs.template_id = ? AND a.status IN ('Booked', 'Confirmed') AND a.start_iso >= ?`,
      )
      .all(tplId, now);

    db.exec('BEGIN IMMEDIATE;');
    try {
      db.prepare(
        `UPDATE clinic_templates
         SET version = ?,
             default_duration_mins = COALESCE(?, default_duration_mins),
             preparation_instructions = COALESCE(?, preparation_instructions)
         WHERE id = ?`,
      ).run(
        newVersion,
        default_duration_mins ? Number(default_duration_mins) : null,
        preparation_instructions ?? null,
        tplId,
      );

      for (const appt of affectedAppts) {
        db.prepare(
          `INSERT INTO work_tasks (
            id, queue_type, title, description, entity_type, entity_id,
            patient_id, owner_staff_id, priority_source, due_iso, status, created_at
          ) VALUES (?, 'Clinic change', ?, ?, 'appointment', ?, ?, 'USR-JENKINS', 'Template amendment governance', ?, 'Open', ?)`,
        ).run(
          `TSK-${randomUUID().slice(0, 8).toUpperCase()}`,
          `Review booking ${String(appt['id'])} after template v${newVersion} change`,
          `Template ${String(tpl['name'])} amended (${amendment_reason || 'operational change'}). Existing booking preserved; confirm impact with patient.`,
          String(appt['id']),
          String(appt['patient_id']),
          String(appt['start_iso']),
          now,
        );
      }

      recordAudit(db, {
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
        action: 'CLINIC_TEMPLATE_AMENDED',
        entityType: 'clinic_template',
        entityId: tplId,
        details: {newVersion, affectedBookingsCount: affectedAppts.length, amendment_reason},
      });
      db.exec('COMMIT;');
      res.json({
        ok: true,
        newVersion,
        affectedBookingsCount: affectedAppts.length,
        affectedAppointmentIds: affectedAppts.map((a) => String(a['id'])),
      });
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }
  });

  router.get('/clinic-sessions', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const rows = db
      .prepare(
        `SELECT cs.*, ct.name AS template_name, ct.specialty, st.name AS site_name,
                u.display_name AS clinician_name,
                (SELECT COUNT(*) FROM appointment_slots s WHERE s.session_id = cs.id AND s.slot_status = 'Booked') AS booked_count,
                (SELECT COUNT(*) FROM appointment_slots s WHERE s.session_id = cs.id AND s.slot_status = 'Available') AS available_count
         FROM clinic_sessions cs
         JOIN clinic_templates ct ON ct.id = cs.template_id
         JOIN sites st ON st.id = cs.site_id
         JOIN staff_users u ON u.id = cs.clinician_id
         ORDER BY cs.session_date, cs.start_time`,
      )
      .all();
    res.json(rows);
  });

  // --- SLOTS & SCHEDULING ---
  router.get('/slots/eligible', (req: AuthenticatedRequest, res: Response) => {
    const referralId = String(req.query['referralId'] || '');
    if (!referralId) {
      res.status(400).json({error: 'referralId query parameter is required.'});
      return;
    }
    const ref = db.prepare('SELECT patient_id FROM referrals WHERE id = ?').get(referralId);
    if (!ref) {
      res.status(404).json({error: 'Referral not found'});
      return;
    }
    try {
      assertPatientAccess(db, req.authSession!, String(ref['patient_id']), 'manage_bookings');
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 403).json({error: err.message});
      return;
    }

    const preferredSiteId = req.query['preferredSiteId'] ? String(req.query['preferredSiteId']) : null;
    const timePref = req.query['timeOfDay'] ? (String(req.query['timeOfDay']) as 'morning' | 'afternoon') : null;

    const result = getEligibleSlotsForReferral(db, {
      referralId,
      actingUserId: req.authSession!.userId,
      preferredSiteId,
      timeOfDayPreference: timePref,
    });
    res.json(result);
  });

  router.post('/slots/:id/hold', (req: AuthenticatedRequest, res: Response) => {
    const slotId = String(req.params['id']);
    const {ttlSeconds, simulateCompetingUserId} = req.body ?? {};
    const actingUserId =
      simulateCompetingUserId && typeof simulateCompetingUserId === 'string'
        ? simulateCompetingUserId
        : req.authSession!.userId;

    try {
      const held = holdSlot(db, {
        slotId,
        userId: actingUserId,
        userRole: req.authSession!.role,
        ttlSeconds: ttlSeconds ? Number(ttlSeconds) : 300,
      });
      res.json(held);
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 409).json({error: err.message});
    }
  });

  router.post('/slots/:id/release', (req: AuthenticatedRequest, res: Response) => {
    const slotId = String(req.params['id']);
    db.prepare(
      `UPDATE appointment_slots
       SET slot_status = 'Available', held_by_user_id = NULL, held_until_iso = NULL
       WHERE id = ? AND slot_status = 'Held' AND (held_by_user_id = ? OR ? IN ('booking_clerk', 'admin'))`,
    ).run(slotId, req.authSession!.userId, req.authSession!.role);
    realtimeBus.broadcast('slot:released', {slotId});
    res.json({ok: true});
  });

  // --- APPOINTMENTS ---
  router.get('/appointments', (req: AuthenticatedRequest, res: Response) => {
    const auth = req.authSession!;
    let query = `
      SELECT a.*, st.name AS site_name, u.display_name AS clinician_name,
             p.given_name || ' ' || p.family_name AS patient_name, p.nhs_number AS patient_nhs
      FROM appointments a
      JOIN sites st ON st.id = a.site_id
      JOIN staff_users u ON u.id = a.clinician_id
      JOIN patients p ON p.internal_id = a.patient_id
    `;
    const params: string[] = [];

    if (auth.role === 'patient' && auth.patientId) {
      query += ' WHERE a.patient_id = ?';
      params.push(auth.patientId);
    } else if (auth.role === 'proxy') {
      query += `
        JOIN proxy_relationships pr ON pr.patient_id = a.patient_id
        WHERE pr.proxy_user_id = ? AND pr.verified_status = 'verified'
      `;
      params.push(auth.userId);
    } else if (!isStaffRole(auth.role)) {
      res.json([]);
      return;
    }

    query += ' ORDER BY a.start_iso ASC';
    const rows = db.prepare(query).all(...params);
    res.json(
      rows.map((r) => ({
        ...r,
        short_notice_opt_in: Boolean(r['short_notice_opt_in']),
      })),
    );
  });

  router.post('/appointments', (req: AuthenticatedRequest, res: Response) => {
    const {slot_id, referral_id, short_notice_opt_in} = req.body ?? {};
    if (!slot_id || !referral_id) {
      res.status(400).json({error: 'slot_id and referral_id are required.'});
      return;
    }

    const ref = db.prepare('SELECT patient_id FROM referrals WHERE id = ?').get(String(referral_id));
    if (!ref) {
      res.status(404).json({error: 'Referral not found'});
      return;
    }

    try {
      assertPatientAccess(db, req.authSession!, String(ref['patient_id']), 'manage_bookings');
      const appt = bookSlotForReferral(db, {
        slotId: String(slot_id),
        referralId: String(referral_id),
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
        shortNoticeOptIn: Boolean(short_notice_opt_in),
      });
      res.status(201).json(appt);
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 400).json({error: err.message});
    }
  });

  router.post('/appointments/:id/transition', (req: AuthenticatedRequest, res: Response) => {
    const apptId = String(req.params['id']);
    const appt = db.prepare('SELECT patient_id FROM appointments WHERE id = ?').get(apptId);
    if (!appt) {
      res.status(404).json({error: 'Appointment not found'});
      return;
    }

    const {targetStatus, reason, clinicalOutcome} = req.body ?? {};
    const isPatientAllowedAction =
      targetStatus === 'Confirmed' || targetStatus === 'Cancelled by patient';

    try {
      if (!isStaffRole(req.authSession!.role)) {
        if (!isPatientAllowedAction) {
          res.status(403).json({error: 'Patients and proxies cannot perform staff/clinical lifecycle transitions.'});
          return;
        }
        assertPatientAccess(db, req.authSession!, String(appt['patient_id']), 'manage_bookings');
      }

      const updated = transitionAppointment(db, {
        appointmentId: apptId,
        targetStatus: targetStatus as AppointmentStatus,
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
        reason,
        clinicalOutcome,
      });
      res.json(updated);
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 400).json({error: err.message});
    }
  });

  router.post('/appointments/:id/reschedule', (req: AuthenticatedRequest, res: Response) => {
    const apptId = String(req.params['id']);
    const appt = db.prepare('SELECT patient_id FROM appointments WHERE id = ?').get(apptId);
    if (!appt) {
      res.status(404).json({error: 'Appointment not found'});
      return;
    }
    const {newSlotId, reason} = req.body ?? {};
    if (!newSlotId || !reason) {
      res.status(400).json({error: 'newSlotId and reason are required.'});
      return;
    }

    try {
      assertPatientAccess(db, req.authSession!, String(appt['patient_id']), 'manage_bookings');
      const result = rescheduleAppointment(db, {
        appointmentId: apptId,
        newSlotId: String(newSlotId),
        reason: String(reason),
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
      });
      res.json(result);
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 400).json({error: err.message});
    }
  });

  router.post('/appointments/:id/follow-up', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    if (req.authSession!.role !== 'clinician' && req.authSession!.role !== 'admin') {
      res.status(403).json({error: 'Only clinicians may authorise a clinical follow-up pathway.'});
      return;
    }
    const apptId = String(req.params['id']);
    const appt = db.prepare('SELECT * FROM appointments WHERE id = ?').get(apptId);
    if (!appt) {
      res.status(404).json({error: 'Appointment not found'});
      return;
    }

    const {clinical_priority, format, booking_window_days, notes} = req.body ?? {};
    const followUpRefId = `REF-FU-${randomUUID().slice(0, 6).toUpperCase()}`;
    const wlId = `WL-FU-${randomUUID().slice(0, 6).toUpperCase()}`;
    const now = new Date().toISOString();

    db.exec('BEGIN IMMEDIATE;');
    try {
      db.prepare(
        `INSERT INTO referrals (
          id, patient_id, specialty, service_name, referral_source, received_at,
          status, clinical_priority, priority_assigned_by, appointment_requirements,
          required_duration_mins, required_format, required_resources_json,
          review_notes, reviewed_at, reviewed_by, booking_window_days, review_history_json
        ) VALUES (?, ?, ?, ?, ?, ?, 'Accepted', ?, ?, ?, 20, ?, '[]', ?, ?, ?, ?, ?)`,
      ).run(
        followUpRefId,
        String(appt['patient_id']),
        String(appt['specialty']),
        `${String(appt['specialty'])} Follow-up Clinic`,
        `Clinician Follow-up from ${apptId}`,
        now,
        String(clinical_priority || 'Routine'),
        req.authSession!.userId,
        notes || 'Follow-up review following attended outpatient consultation.',
        String(format || 'Telephone'),
        notes || 'Follow-up arranged',
        now,
        req.authSession!.userId,
        Number(booking_window_days || 28),
        JSON.stringify([
          {
            timestamp: now,
            actor: req.authSession!.displayName,
            role: req.authSession!.role,
            action: 'Follow-up authorised',
            note: notes || '',
          },
        ]),
      );

      db.prepare(
        `INSERT INTO waiting_list_entries (
          id, referral_id, patient_id, specialty, service_name,
          clinical_priority, original_rtt_clock_start, current_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?)`,
      ).run(
        wlId,
        followUpRefId,
        String(appt['patient_id']),
        String(appt['specialty']),
        `${String(appt['specialty'])} Follow-up Clinic`,
        String(clinical_priority || 'Routine'),
        now,
        now,
      );

      recordAudit(db, {
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
        action: 'FOLLOW_UP_ARRANGED',
        entityType: 'referral',
        entityId: followUpRefId,
        patientId: String(appt['patient_id']),
        details: {sourceAppointmentId: apptId, format: format || 'Telephone', clinical_priority},
      });

      db.exec('COMMIT;');
      realtimeBus.broadcast('referral:created', {referralId: followUpRefId});
      res.status(201).json({followUpReferralId: followUpRefId, waitingListId: wlId});
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }
  });

  router.get('/appointments/:id/ics', (req: AuthenticatedRequest, res: Response) => {
    const apptId = String(req.params['id']);
    const row = db
      .prepare(
        `SELECT a.*, st.name AS site_name FROM appointments a
         JOIN sites st ON st.id = a.site_id
         WHERE a.id = ?`,
      )
      .get(apptId);
    if (!row) {
      res.status(404).json({error: 'Appointment not found'});
      return;
    }
    try {
      assertPatientAccess(db, req.authSession!, String(row['patient_id']), 'view_appointments');
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 403).json({error: err.message});
      return;
    }
    const ics = mockCalendarAdapter.generateIcs({
      id: apptId,
      specialty: String(row['specialty']),
      siteName: String(row['site_name']),
      roomName: String(row['room_name']),
      startIso: String(row['start_iso']),
      endIso: String(row['end_iso']),
      format: String(row['format']),
    });
    res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${apptId}.ics"`);
    res.send(ics);
  });

  // --- STAFF ROTAS & ABSENCE IMPACT ---
  router.get('/rotas', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const rows = db
      .prepare(
        `SELECT r.*, u.display_name AS staff_name, u.role AS staff_role, st.name AS site_name
         FROM staff_rotas r
         JOIN staff_users u ON u.id = r.staff_id
         JOIN sites st ON st.id = r.site_id
         ORDER BY r.rota_date ASC, r.start_time ASC`,
      )
      .all();
    res.json(rows);
  });

  router.post('/rotas/:id/publish', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    if (!['service_manager', 'admin'].includes(req.authSession!.role)) {
      res.status(403).json({error: 'Only service managers or administrators can publish rotas.'});
      return;
    }
    const rotaId = String(req.params['id']);
    db.prepare(`UPDATE staff_rotas SET status = 'Published' WHERE id = ?`).run(rotaId);
    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'ROTA_PUBLISHED',
      entityType: 'staff_rota',
      entityId: rotaId,
    });
    realtimeBus.broadcast('rota:updated', {rotaId});
    res.json({ok: true});
  });

  // Record staff absence WITHOUT silently cancelling appointments; generates affected-work queue
  router.post('/rotas/:id/absence', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const rotaId = String(req.params['id']);
    const rota = db
      .prepare(
        `SELECT r.*, u.display_name AS staff_name
         FROM staff_rotas r JOIN staff_users u ON u.id = r.staff_id
         WHERE r.id = ?`,
      )
      .get(rotaId);

    if (!rota) {
      res.status(404).json({error: 'Rota entry not found'});
      return;
    }

    const {absenceType, note} = req.body ?? {};
    const type = absenceType === 'Leave' ? 'Leave' : 'Sickness Absence';
    const now = new Date().toISOString();
    const rotaDate = String(rota['rota_date']);
    const staffId = String(rota['staff_id']);

    const winStart = londonLocalToUtcIso(rotaDate, String(rota['start_time']));
    const winEnd = londonLocalToUtcIso(rotaDate, String(rota['end_time']));

    // Find affected booked/confirmed appointments
    const affectedAppts = db
      .prepare(
        `SELECT a.id, a.patient_id, a.start_iso, p.given_name || ' ' || p.family_name AS patient_name
         FROM appointments a
         JOIN patients p ON p.internal_id = a.patient_id
         WHERE a.clinician_id = ?
           AND a.status IN ('Booked', 'Confirmed')
           AND a.start_iso >= ? AND a.start_iso < ?`,
      )
      .all(staffId, winStart, winEnd);

    db.exec('BEGIN IMMEDIATE;');
    try {
      db.prepare(`UPDATE staff_rotas SET assignment_type = ?, note = ? WHERE id = ?`).run(
        type,
        note || `Absence recorded by ${req.authSession!.displayName}`,
        rotaId,
      );

      db.prepare(
        `INSERT INTO work_tasks (
          id, queue_type, title, description, entity_type, entity_id,
          owner_staff_id, priority_source, due_iso, status, created_at
        ) VALUES (?, 'Staff absence', ?, ?, 'staff_rota', ?, 'USR-ROTA', 'Published clinic disruption', ?, 'Open', ?)`,
      ).run(
        `TSK-${randomUUID().slice(0, 8).toUpperCase()}`,
        `${type}: ${String(rota['staff_name'])} on ${rotaDate}`,
        `${affectedAppts.length} booked appointment(s) impacted. Arrange clinical cover or reschedule; appointments were NOT silently cancelled.`,
        rotaId,
        winStart,
        now,
      );

      for (const appt of affectedAppts) {
        db.prepare(
          `INSERT INTO work_tasks (
            id, queue_type, title, description, entity_type, entity_id,
            patient_id, owner_staff_id, priority_source, due_iso, status, created_at
          ) VALUES (?, 'Patient needing contact', ?, ?, 'appointment', ?, ?, 'USR-JENKINS', 'Clinician absence cover/contact', ?, 'Open', ?)`,
        ).run(
          `TSK-${randomUUID().slice(0, 8).toUpperCase()}`,
          `Contact ${String(appt['patient_name'])} regarding ${String(rota['staff_name'])} absence`,
          `Appointment ${String(appt['id'])} on ${formatUtcInLondon(String(appt['start_iso']))} is affected by clinician ${type}. Confirm cover or offer alternative slot.`,
          String(appt['id']),
          String(appt['patient_id']),
          String(appt['start_iso']),
          now,
        );
      }

      recordAudit(db, {
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
        action: 'STAFF_ABSENCE_RECORDED',
        entityType: 'staff_rota',
        entityId: rotaId,
        details: {
          staffId,
          absenceType: type,
          affectedAppointments: affectedAppts.map((a) => String(a['id'])),
          appointmentsSilentlyCancelled: false,
        },
      });

      db.exec('COMMIT;');
      realtimeBus.broadcast('rota:absence', {rotaId, affectedCount: affectedAppts.length});
      res.json({
        ok: true,
        affectedAppointments: affectedAppts,
        appointmentsSilentlyCancelled: false,
      });
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }
  });

  // --- INPATIENTS & BEDS ---
  router.get('/wards-beds', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const wards = db
      .prepare(
        `SELECT w.*, st.name AS site_name
         FROM wards w JOIN sites st ON st.id = w.site_id`,
      )
      .all();
    const beds = db
      .prepare(
        `SELECT b.*, w.name AS ward_name, st.name AS site_name,
                pa.patient_id, p.given_name || ' ' || p.family_name AS current_patient_name
         FROM beds b
         JOIN wards w ON w.id = b.ward_id
         JOIN sites st ON st.id = w.site_id
         LEFT JOIN planned_admissions pa ON pa.id = b.current_admission_id
         LEFT JOIN patients p ON p.internal_id = pa.patient_id
         ORDER BY b.bed_label ASC`,
      )
      .all();

    res.json({
      wards: wards.map((w) => ({
        ...w,
        capabilities: JSON.parse(String(w['capabilities_json'] || '[]')),
      })),
      beds: beds.map((b) => ({
        ...b,
        capabilities: JSON.parse(String(b['capabilities_json'] || '[]')),
      })),
    });
  });

  router.patch('/beds/:id', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    if (!['bed_manager', 'clinician', 'admin'].includes(req.authSession!.role)) {
      res.status(403).json({error: 'Only authorised bed managers or clinicians may change bed state or infection-control restrictions.'});
      return;
    }
    const bedId = String(req.params['id']);
    const {occupancy_status, restriction_note} = req.body ?? {};
    const now = new Date().toISOString();

    db.prepare(
      `UPDATE beds SET occupancy_status = COALESCE(?, occupancy_status),
                       restriction_note = ?,
                       updated_by = ?,
                       updated_at = ?
       WHERE id = ?`,
    ).run(occupancy_status ?? null, restriction_note ?? null, req.authSession!.userId, now, bedId);

    db.prepare(`UPDATE wards SET last_synced_iso = ? WHERE id = (SELECT ward_id FROM beds WHERE id = ?)`).run(
      now,
      bedId,
    );

    // Re-evaluate planned admissions linked to this ward
    const impactedAdmissions = db
      .prepare(`SELECT id FROM planned_admissions WHERE requested_ward_id = (SELECT ward_id FROM beds WHERE id = ?)`)
      .all(bedId);
    for (const adm of impactedAdmissions) {
      evaluateAdmissionConflicts(db, String(adm['id']));
    }

    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'BED_STATUS_UPDATED',
      entityType: 'bed',
      entityId: bedId,
      details: {occupancy_status, restriction_note},
    });
    realtimeBus.broadcast('bed:updated', {bedId, occupancy_status});
    res.json({ok: true});
  });

  router.get('/admissions', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const rows = db
      .prepare(
        `SELECT pa.*, p.given_name || ' ' || p.family_name AS patient_name, p.nhs_number AS patient_nhs,
                st.name AS site_name, w.name AS requested_ward_name, b.bed_label AS allocated_bed_label
         FROM planned_admissions pa
         JOIN patients p ON p.internal_id = pa.patient_id
         JOIN sites st ON st.id = pa.site_id
         JOIN wards w ON w.id = pa.requested_ward_id
         LEFT JOIN beds b ON b.id = pa.allocated_bed_id
         ORDER BY pa.expected_admission_date ASC`,
      )
      .all();
    res.json(
      rows.map((r) => ({
        ...r,
        prerequisites: JSON.parse(String(r['prerequisites_json'] || '[]')),
      })),
    );
  });

  router.post('/admissions', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const {patient_id, specialty, site_id, requested_ward_id, allocated_bed_id, expected_admission_date, estimated_los_days} =
      req.body ?? {};
    if (!patient_id || !specialty || !site_id || !requested_ward_id || !expected_admission_date) {
      res.status(400).json({error: 'Missing required planned admission fields.'});
      return;
    }

    const id = `ADM-${randomUUID().slice(0, 8).toUpperCase()}`;
    const los = Number(estimated_los_days || 2);
    const estDischarge = new Date(
      new Date(String(expected_admission_date)).getTime() + los * 24 * 3600 * 1000,
    )
      .toISOString()
      .slice(0, 10);

    db.prepare(
      `INSERT INTO planned_admissions (
        id, patient_id, specialty, site_id, requested_ward_id, allocated_bed_id,
        expected_admission_date, estimated_los_days, estimated_discharge_date,
        prerequisites_json, state, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Planned admission', ?)`,
    ).run(
      id,
      String(patient_id),
      String(specialty),
      String(site_id),
      String(requested_ward_id),
      allocated_bed_id ? String(allocated_bed_id) : null,
      String(expected_admission_date),
      los,
      estDischarge,
      JSON.stringify([
        {label: 'Pre-operative assessment', completed: false},
        {label: 'MRSA screening', completed: false},
      ]),
      req.authSession!.userId,
    );

    const conflict = evaluateAdmissionConflicts(db, id);
    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'PLANNED_ADMISSION_CREATED',
      entityType: 'planned_admission',
      entityId: id,
      patientId: String(patient_id),
      details: {allocated_bed_id, conflict},
    });
    realtimeBus.broadcast('admission:updated', {admissionId: id});
    res.status(201).json({id, ...conflict});
  });

  router.post('/admissions/:id/resolve-conflict', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    if (!['bed_manager', 'clinician', 'admin'].includes(req.authSession!.role)) {
      res.status(403).json({error: 'Only authorised bed managers or clinicians may resolve inpatient placement conflicts.'});
      return;
    }
    const admissionId = String(req.params['id']);
    const adm = db.prepare('SELECT * FROM planned_admissions WHERE id = ?').get(admissionId);
    if (!adm) {
      res.status(404).json({error: 'Planned admission not found'});
      return;
    }

    const {newBedId, completeAllPrerequisites, resolutionNotes} = req.body ?? {};
    const prereqs: {label: string; completed: boolean}[] = JSON.parse(
      String(adm['prerequisites_json'] || '[]'),
    );
    const updatedPrereqs = completeAllPrerequisites
      ? prereqs.map((p) => ({...p, completed: true}))
      : prereqs;

    db.prepare(
      `UPDATE planned_admissions
       SET allocated_bed_id = COALESCE(?, allocated_bed_id),
           prerequisites_json = ?
       WHERE id = ?`,
    ).run(newBedId ?? null, JSON.stringify(updatedPrereqs), admissionId);

    const conflict = evaluateAdmissionConflicts(db, admissionId);

    if (conflict.conflictStatus === 'Clear') {
      db.prepare(
        `UPDATE work_tasks SET status = 'Resolved', resolution_note = ?
         WHERE entity_type = 'planned_admission' AND entity_id = ? AND status != 'Resolved'`,
      ).run(resolutionNotes || 'Resolved by bed management review', admissionId);
    }

    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'ADMISSION_CONFLICT_REVIEWED',
      entityType: 'planned_admission',
      entityId: admissionId,
      patientId: String(adm['patient_id']),
      details: {newBedId, completeAllPrerequisites, conflict, resolutionNotes},
    });

    realtimeBus.broadcast('admission:updated', {admissionId});
    res.json({ok: true, ...conflict});
  });

  router.post('/admissions/:id/transition', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const admissionId = String(req.params['id']);
    const {targetState} = req.body ?? {};
    const adm = db.prepare('SELECT * FROM planned_admissions WHERE id = ?').get(admissionId);
    if (!adm) {
      res.status(404).json({error: 'Planned admission not found'});
      return;
    }

    if (targetState === 'Ready for discharge' && req.authSession!.role !== 'clinician' && req.authSession!.role !== 'admin') {
      res.status(403).json({error: 'Clinical readiness for discharge must be recorded by an authorised clinician.'});
      return;
    }

    const now = new Date().toISOString();
    db.exec('BEGIN IMMEDIATE;');
    try {
      db.prepare(`UPDATE planned_admissions SET state = ? WHERE id = ?`).run(
        String(targetState),
        admissionId,
      );

      if (targetState === 'Actual admission' && adm['allocated_bed_id']) {
        db.prepare(
          `UPDATE beds SET occupancy_status = 'Occupied', current_admission_id = ?, updated_by = ?, updated_at = ? WHERE id = ?`,
        ).run(admissionId, req.authSession!.userId, now, String(adm['allocated_bed_id']));
      }

      if (targetState === 'Administrative discharge' && adm['allocated_bed_id']) {
        db.prepare(
          `UPDATE beds SET occupancy_status = 'Cleaning', current_admission_id = NULL, restriction_note = 'Post-discharge turnaround clean', updated_by = ?, updated_at = ? WHERE id = ?`,
        ).run(req.authSession!.userId, now, String(adm['allocated_bed_id']));
      }

      recordAudit(db, {
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
        action: 'ADMISSION_STATE_CHANGED',
        entityType: 'planned_admission',
        entityId: admissionId,
        patientId: String(adm['patient_id']),
        details: {targetState},
      });
      db.exec('COMMIT;');
      realtimeBus.broadcast('admission:updated', {admissionId, targetState});
      res.json({ok: true, state: targetState});
    } catch (err) {
      db.exec('ROLLBACK;');
      throw err;
    }
  });

  // --- WORK QUEUES ---
  router.get('/work-tasks', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const rows = db
      .prepare(
        `SELECT wt.*, p.given_name || ' ' || p.family_name AS patient_name,
                u.display_name AS owner_name
         FROM work_tasks wt
         LEFT JOIN patients p ON p.internal_id = wt.patient_id
         LEFT JOIN staff_users u ON u.id = wt.owner_staff_id
         ORDER BY CASE wt.status WHEN 'Open' THEN 1 WHEN 'Acknowledged' THEN 2 ELSE 3 END, wt.due_iso ASC`,
      )
      .all();
    res.json(rows);
  });

  router.patch('/work-tasks/:id', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const taskId = String(req.params['id']);
    const {status, resolution_note, owner_staff_id} = req.body ?? {};
    const existing = db.prepare('SELECT * FROM work_tasks WHERE id = ?').get(taskId);
    if (!existing) {
      res.status(404).json({error: 'Task not found'});
      return;
    }

    db.prepare(
      `UPDATE work_tasks
       SET status = COALESCE(?, status),
           resolution_note = COALESCE(?, resolution_note),
           owner_staff_id = COALESCE(?, owner_staff_id)
       WHERE id = ?`,
    ).run(status ?? null, resolution_note ?? null, owner_staff_id ?? null, taskId);

    recordAudit(db, {
      actorUserId: req.authSession!.userId,
      actorRole: req.authSession!.role,
      action: 'WORK_TASK_UPDATED',
      entityType: 'work_task',
      entityId: taskId,
      patientId: existing['patient_id'] ? String(existing['patient_id']) : null,
      details: {status, resolution_note, owner_staff_id},
    });
    realtimeBus.broadcast('task:updated', {taskId, status});
    res.json({ok: true});
  });

  router.post('/work-tasks/batch', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const {taskIds, action, preview, resolutionNote} = req.body ?? {};
    if (!Array.isArray(taskIds) || taskIds.length === 0) {
      res.status(400).json({error: 'taskIds array is required.'});
      return;
    }
    const targetStatus = action === 'resolve' ? 'Resolved' : 'Acknowledged';
    const results: {id: string; eligible: boolean; outcome: string}[] = [];

    for (const tid of taskIds) {
      const task = db.prepare('SELECT * FROM work_tasks WHERE id = ?').get(String(tid));
      if (!task) {
        results.push({id: String(tid), eligible: false, outcome: 'Not found'});
        continue;
      }
      if (String(task['queue_type']) === 'Awaiting clinical review' && targetStatus === 'Resolved' && req.authSession!.role !== 'clinician') {
        results.push({id: String(tid), eligible: false, outcome: 'Denied: clinical review requires clinician role'});
        continue;
      }
      if (!preview) {
        db.prepare(`UPDATE work_tasks SET status = ?, resolution_note = COALESCE(?, resolution_note) WHERE id = ?`).run(
          targetStatus,
          resolutionNote ?? null,
          String(tid),
        );
      }
      results.push({
        id: String(tid),
        eligible: true,
        outcome: preview ? `Would mark ${targetStatus}` : `Marked ${targetStatus}`,
      });
    }

    if (!preview) {
      recordAudit(db, {
        actorUserId: req.authSession!.userId,
        actorRole: req.authSession!.role,
        action: 'WORK_TASKS_BATCH_ACTION',
        entityType: 'work_task',
        entityId: 'BATCH',
        details: {targetStatus, count: results.filter((r) => r.eligible).length},
      });
    }
    res.json({preview: Boolean(preview), results});
  });

  // --- COMMUNICATIONS ---
  router.get('/communications', (req: AuthenticatedRequest, res: Response) => {
    const auth = req.authSession!;
    let query = `
      SELECT c.*, p.given_name || ' ' || p.family_name AS patient_name
      FROM communications c
      JOIN patients p ON p.internal_id = c.patient_id
    `;
    const params: string[] = [];
    if (auth.role === 'patient' && auth.patientId) {
      query += ' WHERE c.patient_id = ?';
      params.push(auth.patientId);
    } else if (auth.role === 'proxy') {
      query += `
        JOIN proxy_relationships pr ON pr.patient_id = c.patient_id
        WHERE pr.proxy_user_id = ? AND pr.verified_status = 'verified'
      `;
      params.push(auth.userId);
    } else if (!isStaffRole(auth.role)) {
      res.json([]);
      return;
    }
    query += ' ORDER BY c.created_at DESC';
    res.json(db.prepare(query).all(...params));
  });

  router.post('/communications', (req: AuthenticatedRequest, res: Response) => {
    const {patient_id, channel, message_type, subject, body, lock_screen_safe_preview, simulateFailure} =
      req.body ?? {};
    if (!patient_id || !subject || !body) {
      res.status(400).json({error: 'patient_id, subject, and body are required.'});
      return;
    }
    try {
      assertPatientAccess(db, req.authSession!, String(patient_id), 'view_messages');
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 403).json({error: err.message});
      return;
    }

    const comm = mockMessagingAdapter.dispatch(
      db,
      {
        patientId: String(patient_id),
        channel: (channel || 'Portal') as CommChannel,
        messageType: message_type || 'General',
        subject: String(subject),
        body: String(body),
        lockScreenSafePreview:
          lock_screen_safe_preview ||
          'Pennine University Hospital: You have a message in your patient portal.',
        simulateFailure: Boolean(simulateFailure),
      },
      req.authSession!.userId,
      req.authSession!.role,
    );
    realtimeBus.broadcast('communication:created', {id: comm.id, status: comm.status});
    res.status(201).json(comm);
  });

  router.post('/communications/:id/retry', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const commId = String(req.params['id']);
    const existing = db.prepare('SELECT * FROM communications WHERE id = ?').get(commId);
    if (!existing) {
      res.status(404).json({error: 'Communication record not found'});
      return;
    }
    const {fallbackChannel} = req.body ?? {};
    const newComm = mockMessagingAdapter.dispatch(
      db,
      {
        patientId: String(existing['patient_id']),
        channel: (fallbackChannel || 'Email') as CommChannel,
        messageType: String(existing['message_type']) as 'Reminder',
        subject: String(existing['subject']),
        body: String(existing['body']),
        lockScreenSafePreview: String(existing['lock_screen_safe_preview']),
        accessibleFormat: String(existing['accessible_format']),
        language: String(existing['language']),
      },
      req.authSession!.userId,
      req.authSession!.role,
    );

    // Resolve related failed communication work task
    db.prepare(
      `UPDATE work_tasks SET status = 'Resolved', resolution_note = ?
       WHERE entity_type = 'communication' AND entity_id = ? AND status != 'Resolved'`,
    ).run(`Fallback ${newComm.channel} dispatched (${newComm.id})`, commId);

    realtimeBus.broadcast('communication:created', {id: newComm.id, status: newComm.status});
    res.json({ok: true, fallbackCommunication: newComm});
  });

  router.post('/communications/:id/read', (req: AuthenticatedRequest, res: Response) => {
    const commId = String(req.params['id']);
    const existing = db.prepare('SELECT patient_id FROM communications WHERE id = ?').get(commId);
    if (!existing) {
      res.status(404).json({error: 'Message not found'});
      return;
    }
    try {
      assertPatientAccess(db, req.authSession!, String(existing['patient_id']), 'view_messages');
    } catch (e) {
      const err = e as Error & {statusCode?: number};
      res.status(err.statusCode || 403).json({error: err.message});
      return;
    }
    db.prepare(`UPDATE communications SET status = 'Read', updated_at = ? WHERE id = ?`).run(
      new Date().toISOString(),
      commId,
    );
    res.json({ok: true});
  });

  // --- REPORTING, AUDIT, INTEGRATIONS & DEMO RESET ---
  router.get('/reports', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    releaseExpiredHolds(db);

    const refStats = db
      .prepare(
        `SELECT
           COUNT(*) AS total,
           SUM(CASE WHEN status IN ('Received', 'Awaiting review', 'Further information required') THEN 1 ELSE 0 END) AS pending,
           SUM(CASE WHEN status = 'Accepted' THEN 1 ELSE 0 END) AS accepted,
           SUM(CASE WHEN status IN ('Declined', 'Redirected') THEN 1 ELSE 0 END) AS declined_redirected
         FROM referrals`,
      )
      .get()!;

    const wlStats = db
      .prepare(
        `SELECT
           SUM(CASE WHEN current_status IN ('Active', 'Booked') THEN 1 ELSE 0 END) AS active_count,
           SUM(CASE WHEN current_status IN ('Active', 'Booked') AND clinical_priority = 'Urgent' THEN 1 ELSE 0 END) AS urgent_count,
           SUM(CASE WHEN current_status IN ('Active', 'Booked') AND clinical_priority = 'Soon' THEN 1 ELSE 0 END) AS soon_count,
           SUM(CASE WHEN current_status IN ('Active', 'Booked') AND clinical_priority = 'Routine' THEN 1 ELSE 0 END) AS routine_count
         FROM waiting_list_entries`,
      )
      .get()!;

    const apptStats = db
      .prepare(
        `SELECT
           SUM(CASE WHEN status IN ('Booked', 'Confirmed') THEN 1 ELSE 0 END) AS booked_capacity,
           SUM(CASE WHEN status IN ('Arrived', 'In progress', 'Completed') THEN 1 ELSE 0 END) AS attended,
           SUM(CASE WHEN status = 'Did not attend' THEN 1 ELSE 0 END) AS dna,
           SUM(CASE WHEN status = 'Cancelled by patient' THEN 1 ELSE 0 END) AS cancelled_patient,
           SUM(CASE WHEN status = 'Cancelled by provider' THEN 1 ELSE 0 END) AS cancelled_provider
         FROM appointments`,
      )
      .get()!;

    const slotStats = db
      .prepare(
        `SELECT
           COUNT(*) AS total_slots,
           SUM(CASE WHEN slot_status = 'Booked' THEN 1 ELSE 0 END) AS booked_slots,
           SUM(CASE WHEN slot_status = 'Held' THEN 1 ELSE 0 END) AS held_slots,
           SUM(CASE WHEN slot_status = 'Available' THEN 1 ELSE 0 END) AS available_slots
         FROM appointment_slots`,
      )
      .get()!;

    const rotaStats = db
      .prepare(
        `SELECT
           SUM(CASE WHEN status = 'Published' THEN 1 ELSE 0 END) AS published,
           SUM(CASE WHEN status = 'Draft' THEN 1 ELSE 0 END) AS draft,
           SUM(CASE WHEN assignment_type IN ('Leave', 'Sickness Absence') THEN 1 ELSE 0 END) AS absences
         FROM staff_rotas`,
      )
      .get()!;

    const admStats = db
      .prepare(
        `SELECT
           SUM(CASE WHEN state = 'Planned admission' THEN 1 ELSE 0 END) AS planned,
           SUM(CASE WHEN state = 'Confirmed booking' THEN 1 ELSE 0 END) AS confirmed,
           SUM(CASE WHEN state IN ('Actual admission', 'Ready for discharge') THEN 1 ELSE 0 END) AS actual
         FROM planned_admissions`,
      )
      .get()!;

    const bedStats = db
      .prepare(
        `SELECT
           COUNT(*) AS total_beds,
           SUM(CASE WHEN occupancy_status = 'Occupied' THEN 1 ELSE 0 END) AS occupied,
           SUM(CASE WHEN occupancy_status IN ('Maintenance Closed', 'Infection Control') THEN 1 ELSE 0 END) AS closed,
           SUM(CASE WHEN occupancy_status = 'Available' THEN 1 ELSE 0 END) AS available
         FROM beds`,
      )
      .get()!;

    const commStats = db
      .prepare(
        `SELECT
           SUM(CASE WHEN status IN ('Sent', 'Delivered', 'Read') THEN 1 ELSE 0 END) AS sent_delivered,
           SUM(CASE WHEN status = 'Failed' THEN 1 ELSE 0 END) AS failed,
           SUM(CASE WHEN status = 'Read' THEN 1 ELSE 0 END) AS read_count
         FROM communications`,
      )
      .get()!;

    const openTasks = db
      .prepare(`SELECT COUNT(*) AS c FROM work_tasks WHERE status != 'Resolved'`)
      .get()!;

    const totalSlots = Number(slotStats['total_slots'] ?? 0);
    const bookedSlots = Number(slotStats['booked_slots'] ?? 0);
    const totalBeds = Number(bedStats['total_beds'] ?? 0);
    const occupiedBeds = Number(bedStats['occupied'] ?? 0);

    res.json({
      generated_at: new Date().toISOString(),
      prototype_disclaimer:
        'Prototype operational management metrics only. Not an official NHS RTT statutory return or validated clinical outcome report.',
      referral_workload: {
        total: Number(refStats['total'] ?? 0),
        received_or_awaiting: Number(refStats['pending'] ?? 0),
        accepted: Number(refStats['accepted'] ?? 0),
        declined_or_redirected: Number(refStats['declined_redirected'] ?? 0),
      },
      waiting_list: {
        active_count: Number(wlStats['active_count'] ?? 0),
        urgent_count: Number(wlStats['urgent_count'] ?? 0),
        soon_count: Number(wlStats['soon_count'] ?? 0),
        routine_count: Number(wlStats['routine_count'] ?? 0),
      },
      appointments: {
        booked_or_confirmed_capacity: Number(apptStats['booked_capacity'] ?? 0),
        attended_activity: Number(apptStats['attended'] ?? 0),
        dna_count: Number(apptStats['dna'] ?? 0),
        cancelled_by_patient: Number(apptStats['cancelled_patient'] ?? 0),
        cancelled_by_provider: Number(apptStats['cancelled_provider'] ?? 0),
        average_booking_lead_days: 3.4,
      },
      clinics: {
        total_slots: totalSlots,
        booked_slots: bookedSlots,
        held_slots: Number(slotStats['held_slots'] ?? 0),
        unfilled_available_slots: Number(slotStats['available_slots'] ?? 0),
        utilisation_pct: totalSlots > 0 ? Math.round((bookedSlots / totalSlots) * 100) : 0,
      },
      rotas: {
        published_sessions: Number(rotaStats['published'] ?? 0),
        draft_sessions: Number(rotaStats['draft'] ?? 0),
        active_absences: Number(rotaStats['absences'] ?? 0),
      },
      inpatients_and_beds: {
        planned_admissions: Number(admStats['planned'] ?? 0),
        confirmed_admissions: Number(admStats['confirmed'] ?? 0),
        actual_inpatient_admissions: Number(admStats['actual'] ?? 0),
        total_beds: totalBeds,
        occupied_beds: occupiedBeds,
        closed_or_restricted_beds: Number(bedStats['closed'] ?? 0),
        available_beds: Number(bedStats['available'] ?? 0),
        bed_occupancy_pct: totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0,
      },
      communications: {
        total_sent_or_delivered: Number(commStats['sent_delivered'] ?? 0),
        failed_count: Number(commStats['failed'] ?? 0),
        read_count: Number(commStats['read_count'] ?? 0),
      },
      open_work_tasks: Number(openTasks['c'] ?? 0),
    });
  });

  router.get('/audit', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const chainCheck = verifyAuditChain(db);
    const rows = db
      .prepare('SELECT * FROM audit_logs ORDER BY sequence_num DESC LIMIT 100')
      .all();
    res.json({
      chainIntegrity: chainCheck,
      entries: rows.map((r) => ({
        ...r,
        details: JSON.parse(String(r['details_json'] || '{}')),
      })),
    });
  });

  router.get('/integrations', requireStaff, (_req: AuthenticatedRequest, res: Response) => {
    const rows = db
      .prepare('SELECT * FROM integration_events ORDER BY created_at DESC LIMIT 50')
      .all();
    res.json({
      adapters: [
        {name: mockPasAdapter.adapterName, authoritativeFor: mockPasAdapter.authoritativeFor, mode: 'Simulated'},
        {name: mockEprAdapter.adapterName, authoritativeFor: mockEprAdapter.authoritativeFor, mode: 'Simulated'},
        {name: mockErsAdapter.adapterName, authoritativeFor: mockErsAdapter.authoritativeFor, mode: 'Simulated'},
        {name: mockMessagingAdapter.adapterName, authoritativeFor: ['delivery_receipts'], mode: 'Simulated'},
      ],
      events: rows.map((r) => ({
        ...r,
        payload: JSON.parse(String(r['payload_json'] || '{}')),
      })),
    });
  });

  router.post('/integrations/simulate-event', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    const {externalEventId, idempotencyKey, patientId, specialty, simulateConflict} = req.body ?? {};
    const result = mockErsAdapter.ingestReferralEvent(
      db,
      {
        externalEventId: String(externalEventId || `UBRN-${Date.now().toString().slice(-6)}`),
        idempotencyKey: String(idempotencyKey || 'ers-demo-idempotency-key'),
        patientId: String(patientId || 'PAT-001'),
        specialty: String(specialty || 'Cardiology'),
        serviceName: 'Rapid Access Chest Pain & Arrhythmia Clinic',
        referralSource: 'GP Practice (Simulated e-RS)',
        appointmentRequirements: 'Simulated inbound e-RS referral',
        requiredDurationMins: 20,
        requiredFormat: 'In-person' as ClinicFormat,
        simulateConflict: Boolean(simulateConflict),
      },
      req.authSession!.userId,
      req.authSession!.role,
    );
    realtimeBus.broadcast('integration:event', {status: result.status});
    res.json(result);
  });

  router.post('/demo/reset', requireStaff, (req: AuthenticatedRequest, res: Response) => {
    seedDemonstratorDatabase(db, true);
    realtimeBus.broadcast('demo:reset', {by: req.authSession!.userId});
    res.json({ok: true});
  });

  return router;
}
