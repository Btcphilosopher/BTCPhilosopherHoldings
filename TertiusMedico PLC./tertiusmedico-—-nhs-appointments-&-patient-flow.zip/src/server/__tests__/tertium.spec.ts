import {describe, it, expect} from 'vitest';
import express from 'express';
import type {AddressInfo} from 'node:net';
import {createDatabase} from '../db/database';
import {seedDemonstratorDatabase} from '../db/seed';
import {createApiRouter} from '../routes/api';
import {
  bookSlotForReferral,
  londonLocalToUtcIso,
  releaseExpiredHolds,
} from '../services/scheduler';
import {verifyAuditChain} from '../services/audit';
import {mockErsAdapter, mockMessagingAdapter} from '../services/adapters';

function setupTestApp() {
  const db = createDatabase(':memory:');
  seedDemonstratorDatabase(db, false);
  const app = express();
  app.use('/api', createApiRouter(db));
  return {db, app};
}

async function withServer(
  app: express.Express,
  fn: (baseUrl: string) => Promise<void>,
): Promise<void> {
  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, () => resolve(s));
  });
  try {
    const port = (server.address() as AddressInfo).port;
    await fn(`http://127.0.0.1:${port}/api`);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
}

async function signIn(baseUrl: string, username: string): Promise<string> {
  const res = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({username, demoQuickSignIn: true}),
  });
  const data = (await res.json()) as {token: string};
  return data.token;
}

describe('TertiusMedico Core Scheduling, Security & Flow Tests', () => {
  it('1. Enforces patient identity isolation across records', async () => {
    const {app} = setupTestApp();
    await withServer(app, async (baseUrl) => {
      const arthurToken = await signIn(baseUrl, 'arthur.pendelton');
      const ownRes = await fetch(`${baseUrl}/patients/PAT-001`, {
        headers: {Authorization: `Bearer ${arthurToken}`},
      });
      expect(ownRes.status).toBe(200);

      const otherRes = await fetch(`${baseUrl}/patients/PAT-002`, {
        headers: {Authorization: `Bearer ${arthurToken}`},
      });
      expect(otherRes.status).toBe(403);
    });
  });

  it('2. Enforces verified proxy permissions and blocks unverified proxies', async () => {
    const {app} = setupTestApp();
    await withServer(app, async (baseUrl) => {
      const nadiaToken = await signIn(baseUrl, 'nadia.begum');
      const blocked = await fetch(`${baseUrl}/patients/PAT-002`, {
        headers: {Authorization: `Bearer ${nadiaToken}`},
      });
      expect(blocked.status).toBe(403);

      const tariqToken = await signIn(baseUrl, 'tariq.begum');
      const allowed = await fetch(`${baseUrl}/patients/PAT-002`, {
        headers: {Authorization: `Bearer ${tariqToken}`},
      });
      expect(allowed.status).toBe(200);
    });
  });

  it('3. Enforces clinical-role restrictions on referral priority & clinical review', async () => {
    const {app} = setupTestApp();
    await withServer(app, async (baseUrl) => {
      const clerkToken = await signIn(baseUrl, 's.jenkins');
      const clerkAttempt = await fetch(`${baseUrl}/referrals/REF-CARD-01/review`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${clerkToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({status: 'Accepted', clinical_priority: 'Urgent'}),
      });
      expect(clerkAttempt.status).toBe(403);

      const clinicianToken = await signIn(baseUrl, 'h.patel');
      const clinicianAttempt = await fetch(`${baseUrl}/referrals/REF-CARD-01/review`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${clinicianToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          status: 'Accepted',
          clinical_priority: 'Soon',
          booking_window_days: 28,
        }),
      });
      expect(clinicianAttempt.status).toBe(200);
    });
  });

  it('4. Prevents competing users from taking a held slot (slot concurrency)', async () => {
    const {app} = setupTestApp();
    await withServer(app, async (baseUrl) => {
      const clinicianToken = await signIn(baseUrl, 'h.patel');
      await fetch(`${baseUrl}/referrals/REF-CARD-01/review`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${clinicianToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({status: 'Accepted', clinical_priority: 'Soon'}),
      });

      const arthurToken = await signIn(baseUrl, 'arthur.pendelton');
      const slotsRes = await fetch(`${baseUrl}/slots/eligible?referralId=REF-CARD-01`, {
        headers: {Authorization: `Bearer ${arthurToken}`},
      });
      const {eligible} = (await slotsRes.json()) as {eligible: {id: string}[]};
      expect(eligible.length).toBeGreaterThan(0);

      const targetSlotId = eligible[0].id;
      const hold1 = await fetch(`${baseUrl}/slots/${targetSlotId}/hold`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${arthurToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ttlSeconds: 300}),
      });
      expect(hold1.status).toBe(200);

      // Competing user attempt
      const hold2 = await fetch(`${baseUrl}/slots/${targetSlotId}/hold`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${arthurToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({simulateCompetingUserId: 'USR-COMPETING'}),
      });
      expect(hold2.status).toBe(409);
    });
  });

  it('5. Releases expired slot holds automatically', () => {
    const {db} = setupTestApp();
    const slot = db
      .prepare(`SELECT id FROM appointment_slots WHERE slot_status = 'Available' LIMIT 1`)
      .get()!;
    const slotId = String(slot['id']);
    const pastExpiry = new Date(Date.now() - 60_000).toISOString();

    db.prepare(
      `UPDATE appointment_slots SET slot_status = 'Held', held_by_user_id = 'USR-PATIENT-ARTHUR', held_until_iso = ? WHERE id = ?`,
    ).run(pastExpiry, slotId);

    const released = releaseExpiredHolds(db, new Date().toISOString());
    expect(released).toBe(1);

    const updated = db.prepare(`SELECT slot_status FROM appointment_slots WHERE id = ?`).get(slotId)!;
    expect(updated['slot_status']).toBe('Available');
  });

  it('6. Blocks simultaneous clinician/room conflicts and flags staff absences without silent cancellation', async () => {
    const {db, app} = setupTestApp();
    // Direct booking conflict check when clinician/room already occupied at same time
    const slot = db
      .prepare(`SELECT * FROM appointment_slots WHERE slot_status = 'Available' LIMIT 1`)
      .get()!;
    const refId = 'REF-CARD-02';
    // Force an overlapping appointment for same clinician at exact start/end
    db.prepare(
      `INSERT INTO appointments (
        id, referral_id, patient_id, specialty, appointment_type, format,
        site_id, room_name, clinician_id, start_iso, end_iso, status, created_at, updated_at
      ) VALUES ('APT-CONFLICT-TEST', 'REF-CARD-02', 'PAT-004', 'Cardiology', 'Test', 'In-person',
        'SITE-STA', 'Outpatient Suite B · Room 4', 'USR-PATEL', ?, ?, 'Booked', ?, ?)`,
    ).run(
      String(slot['start_iso']),
      String(slot['end_iso']),
      new Date().toISOString(),
      new Date().toISOString(),
    );

    expect(() =>
      bookSlotForReferral(db, {
        slotId: String(slot['id']),
        referralId: refId,
        actorUserId: 'USR-JENKINS',
        actorRole: 'booking_clerk',
      }),
    ).toThrow(/conflict/i);

    // Staff absence generates work queues without cancelling booked appointment APT-FATIMA-00
    await withServer(app, async (baseUrl) => {
      const rotaToken = await signIn(baseUrl, 'c.whitaker');
      const absRes = await fetch(`${baseUrl}/rotas/ROT-005/absence`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${rotaToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({absenceType: 'Sickness Absence', note: 'Test absence'}),
      });
      const absData = (await absRes.json()) as {
        appointmentsSilentlyCancelled: boolean;
        affectedAppointments: {id: string}[];
      };
      expect(absRes.status).toBe(200);
      expect(absData.appointmentsSilentlyCancelled).toBe(false);
      expect(absData.affectedAppointments.some((a) => a.id === 'APT-FATIMA-00')).toBe(true);
    });
  });

  it('7. Handles Europe/London GMT vs BST timezone conversion accurately', () => {
    const winterUtc = londonLocalToUtcIso('2026-01-15', '09:30');
    const summerUtc = londonLocalToUtcIso('2026-07-15', '09:30');
    expect(winterUtc).toBe('2026-01-15T09:30:00.000Z'); // GMT +0
    expect(summerUtc).toBe('2026-07-15T08:30:00.000Z'); // BST +1
  });

  it('8 & 9. Preserves rescheduling history and waiting-list RTT clock start on cancellation', async () => {
    const {db, app} = setupTestApp();
    const origWl = db
      .prepare(`SELECT original_rtt_clock_start FROM waiting_list_entries WHERE id = 'WL-CARD-02'`)
      .get()!;

    await withServer(app, async (baseUrl) => {
      const clerkToken = await signIn(baseUrl, 's.jenkins');

      // Reschedule APT-MARCUS-01 to another eligible Cardiology slot
      const slotsRes = await fetch(`${baseUrl}/slots/eligible?referralId=REF-CARD-02`, {
        headers: {Authorization: `Bearer ${clerkToken}`},
      });
      const {eligible} = (await slotsRes.json()) as {eligible: {id: string}[]};
      const reschedRes = await fetch(`${baseUrl}/appointments/APT-MARCUS-01/reschedule`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${clerkToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({newSlotId: eligible[0].id, reason: 'Patient travel conflict'}),
      });
      expect(reschedRes.status).toBe(200);
      const reschedData = (await reschedRes.json()) as {
        previousAppointmentId: string;
        newAppointment: {id: string; linked_previous_appointment_id: string};
      };
      expect(reschedData.newAppointment.linked_previous_appointment_id).toBe('APT-MARCUS-01');

      // Now cancel new appointment and confirm waiting list stays Active with unchanged original_rtt_clock_start
      const cancelRes = await fetch(
        `${baseUrl}/appointments/${reschedData.newAppointment.id}/transition`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${clerkToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({targetStatus: 'Cancelled by patient', reason: 'Unwell'}),
        },
      );
      expect(cancelRes.status).toBe(200);
    });

    const afterWl = db
      .prepare(`SELECT current_status, original_rtt_clock_start FROM waiting_list_entries WHERE id = 'WL-CARD-02'`)
      .get()!;
    expect(afterWl['current_status']).toBe('Active');
    expect(afterWl['original_rtt_clock_start']).toBe(origWl['original_rtt_clock_start']);
  });

  it('10. Deduplicates repeated inbound integration events by idempotency key', () => {
    const {db} = setupTestApp();
    const first = mockErsAdapter.ingestReferralEvent(
      db,
      {
        externalEventId: 'UBRN-TEST-99',
        idempotencyKey: 'idem-key-99',
        patientId: 'PAT-001',
        specialty: 'Cardiology',
        serviceName: 'Cardiology Outpatients',
        referralSource: 'GP',
        appointmentRequirements: 'Test',
        requiredDurationMins: 20,
        requiredFormat: 'In-person',
      },
      'SYSTEM',
      'system',
    );
    expect(first.status).toBe('Synced');

    const second = mockErsAdapter.ingestReferralEvent(
      db,
      {
        externalEventId: 'UBRN-TEST-99',
        idempotencyKey: 'idem-key-99',
        patientId: 'PAT-001',
        specialty: 'Cardiology',
        serviceName: 'Cardiology Outpatients',
        referralSource: 'GP',
        appointmentRequirements: 'Test',
        requiredDurationMins: 20,
        requiredFormat: 'In-person',
      },
      'SYSTEM',
      'system',
    );
    expect(second.status).toBe('Duplicate Ignored');
  });

  it('11. Records failed notifications and opens a fallback task without cancelling appointments', () => {
    const {db} = setupTestApp();
    const comm = mockMessagingAdapter.dispatch(
      db,
      {
        patientId: 'PAT-004',
        channel: 'SMS',
        messageType: 'Reminder',
        subject: 'Reminder',
        body: 'Test reminder',
        lockScreenSafePreview: 'Hospital reminder',
        simulateFailure: true,
        failureReason: 'Carrier unreachable',
      },
      'SYSTEM',
      'system',
    );
    expect(comm.status).toBe('Failed');
    const task = db
      .prepare(`SELECT * FROM work_tasks WHERE entity_type = 'communication' AND entity_id = ?`)
      .get(comm.id);
    expect(task).toBeDefined();
    expect(task?.['queue_type']).toBe('Failed communication');
  });

  it('12. Detects and resolves inpatient bed & prerequisite conflicts', async () => {
    const {app} = setupTestApp();
    await withServer(app, async (baseUrl) => {
      const bedToken = await signIn(baseUrl, 'd.thornton');
      const beforeRes = await fetch(`${baseUrl}/admissions`, {
        headers: {Authorization: `Bearer ${bedToken}`},
      });
      const beforeList = (await beforeRes.json()) as {id: string; conflict_status: string}[];
      const adm001 = beforeList.find((a) => a.id === 'ADM-001');
      expect(adm001?.conflict_status).toBe('Conflict Detected');

      const resolveRes = await fetch(`${baseUrl}/admissions/ADM-001/resolve-conflict`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${bedToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          newBedId: 'BED-4B-07',
          completeAllPrerequisites: true,
          resolutionNotes: 'Moved to available bed 4B-07',
        }),
      });
      const resolved = (await resolveRes.json()) as {conflictStatus: string};
      expect(resolveRes.status).toBe(200);
      expect(resolved.conflictStatus).toBe('Clear');
    });
  });

  it('13. Maintains a complete, tamper-evident hash-chained audit trail', () => {
    const {db} = setupTestApp();
    const chain = verifyAuditChain(db);
    expect(chain.valid).toBe(true);
    expect(chain.total).toBeGreaterThan(0);
  });
});
