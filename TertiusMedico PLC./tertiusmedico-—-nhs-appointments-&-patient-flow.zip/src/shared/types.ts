export type UserRole =
  | 'patient'
  | 'proxy'
  | 'booking_clerk'
  | 'clinician'
  | 'bed_manager'
  | 'service_manager'
  | 'admin';

export type NhsVerificationStatus = 'verified' | 'unverified' | 'mismatch';

export type ProxyScope =
  | 'view_appointments'
  | 'manage_bookings'
  | 'view_messages'
  | 'full_coordination';

export type ProxyVerifiedStatus = 'verified' | 'pending' | 'revoked';

export type ReferralStatus =
  | 'Received'
  | 'Awaiting review'
  | 'Accepted'
  | 'Redirected'
  | 'Further information required'
  | 'Declined';

export type ClinicalPriority = 'Urgent' | 'Soon' | 'Routine';

export type WaitingListStatus =
  | 'Active'
  | 'Booked'
  | 'Suspended'
  | 'Discharged'
  | 'Removed';

export type ClinicFormat = 'In-person' | 'Telephone' | 'Video';

export type SlotStatus = 'Available' | 'Held' | 'Booked' | 'Blocked';

export type AppointmentStatus =
  | 'Proposed'
  | 'Offered'
  | 'Held'
  | 'Booked'
  | 'Confirmed'
  | 'Arrived'
  | 'In progress'
  | 'Completed'
  | 'Cancelled by patient'
  | 'Cancelled by provider'
  | 'Did not attend'
  | 'Unable to complete'
  | 'Rescheduled';

export type RotaAssignmentType =
  | 'Clinic'
  | 'On-call'
  | 'Training'
  | 'Leave'
  | 'Sickness Absence'
  | 'Admin';

export type RotaStatus = 'Draft' | 'Published';

export type BedOccupancyStatus =
  | 'Available'
  | 'Occupied'
  | 'Cleaning'
  | 'Maintenance Closed'
  | 'Infection Control';

export type AdmissionState =
  | 'Planned admission'
  | 'Confirmed booking'
  | 'Actual admission'
  | 'Ready for discharge'
  | 'Administrative discharge';

export type WorkQueueType =
  | 'Incomplete referral'
  | 'Awaiting clinical review'
  | 'Patient needing contact'
  | 'Unaccepted offer'
  | 'Clinic change'
  | 'Staff absence'
  | 'Cancelled session'
  | 'Missing prep'
  | 'Interpreter booking'
  | 'Admission prerequisite'
  | 'Identity issue'
  | 'Failed communication';

export type WorkTaskStatus = 'Open' | 'Acknowledged' | 'Resolved';

export type CommChannel = 'Portal' | 'Email' | 'SMS' | 'Letter';

export type CommStatus = 'Queued' | 'Sent' | 'Delivered' | 'Failed' | 'Read';

export interface Site {
  id: string;
  name: string;
  short_name: string;
  city: string;
  postcode: string;
  description: string;
  image_url: string;
  timezone: string;
}

export interface StaffUser {
  id: string;
  username: string;
  display_name: string;
  role: UserRole;
  specialty: string | null;
  competencies: string[];
  site_id: string | null;
  contracted_hours: number;
  mfa_enabled: boolean;
  patient_id?: string | null;
}

export interface AuthSession {
  token: string;
  user: StaffUser;
  mfa_verified: boolean;
  expires_at: string;
  acting_for_patient_id?: string | null;
  proxy_scope?: ProxyScope | null;
}

export interface PatientRecord {
  internal_id: string;
  nhs_number: string | null;
  nhs_verification_status: NhsVerificationStatus;
  given_name: string;
  family_name: string;
  date_of_birth: string;
  gender: string;
  phone: string;
  email: string;
  address: string;
  preferred_channel: CommChannel;
  preferred_language: string;
  interpreter_required: boolean;
  accessibility_needs: string[];
  source_system_ids: Record<string, string>;
  duplicate_flag_patient_id: string | null;
  merged_into_id: string | null;
}

export interface ProxyRelationship {
  id: string;
  patient_id: string;
  proxy_user_id: string;
  proxy_name: string;
  relationship_type: string;
  scope: ProxyScope;
  verified_status: ProxyVerifiedStatus;
  verified_by: string | null;
  verified_at: string | null;
}

export interface Referral {
  id: string;
  patient_id: string;
  patient_name?: string;
  patient_nhs?: string | null;
  specialty: string;
  service_name: string;
  referral_source: string;
  received_at: string;
  status: ReferralStatus;
  clinical_priority: ClinicalPriority | null;
  priority_assigned_by: string | null;
  appointment_requirements: string;
  required_duration_mins: number;
  required_format: ClinicFormat;
  required_resources: string[];
  interpreter_language: string | null;
  supporting_docs: { id: string; title: string; source: string; uploaded_at: string }[];
  review_notes: string | null;
  reviewed_at: string | null;
  reviewed_by: string | null;
  booking_window_days: number;
  review_history: { timestamp: string; actor: string; role: string; action: string; note: string }[];
}

export interface WaitingListEntry {
  id: string;
  referral_id: string;
  patient_id: string;
  patient_name?: string;
  patient_nhs?: string | null;
  specialty: string;
  service_name: string;
  clinical_priority: ClinicalPriority;
  original_rtt_clock_start: string;
  current_status: WaitingListStatus;
  removal_reason: string | null;
  created_at: string;
  linked_appointment_count?: number;
}

export interface ClinicTemplate {
  id: string;
  version: number;
  name: string;
  specialty: string;
  clinic_type: string;
  site_id: string;
  site_name?: string;
  room_name: string;
  format: ClinicFormat;
  clinician_id: string;
  clinician_name?: string;
  support_staff_role: string | null;
  required_equipment: string[];
  default_duration_mins: number;
  buffer_mins: number;
  break_start: string | null;
  break_end: string | null;
  protected_capacity_count: number;
  group_session_enabled: boolean;
  overbooking_enabled: boolean;
  preparation_instructions: string;
  booking_window_days: number;
  active: boolean;
}

export interface ClinicSession {
  id: string;
  template_id: string;
  template_version: number;
  template_name?: string;
  specialty?: string;
  site_id: string;
  site_name?: string;
  room_name: string;
  clinician_id: string;
  clinician_name?: string;
  session_date: string;
  start_time: string;
  end_time: string;
  status: 'Scheduled' | 'Amended' | 'Cancelled';
  amendment_note: string | null;
  booked_count?: number;
  available_count?: number;
}

export interface AppointmentSlot {
  id: string;
  session_id: string;
  site_id: string;
  site_name: string;
  room_name: string;
  specialty: string;
  clinic_type: string;
  clinician_id: string;
  clinician_name: string;
  start_iso: string;
  end_iso: string;
  duration_mins: number;
  format: ClinicFormat;
  slot_status: SlotStatus;
  held_by_user_id: string | null;
  held_until_iso: string | null;
  protected_for_priority: boolean;
  preparation_instructions: string;
  required_equipment: string[];
  eligible?: boolean;
  preference_score?: number;
  conflict_reasons?: string[];
}

export interface Appointment {
  id: string;
  slot_id: string | null;
  referral_id: string | null;
  waiting_list_id: string | null;
  patient_id: string;
  patient_name?: string;
  patient_nhs?: string | null;
  specialty: string;
  appointment_type: string;
  format: ClinicFormat;
  site_id: string;
  site_name?: string;
  room_name: string;
  clinician_id: string;
  clinician_name?: string;
  start_iso: string;
  end_iso: string;
  status: AppointmentStatus;
  cancellation_reason: string | null;
  clinical_outcome: string | null;
  attendance_recorded_at: string | null;
  linked_previous_appointment_id: string | null;
  short_notice_opt_in: boolean;
  interpreter_booked: string | null;
  preparation_instructions: string | null;
  video_join_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface StaffRotaEntry {
  id: string;
  staff_id: string;
  staff_name?: string;
  staff_role?: string;
  site_id: string;
  site_name?: string;
  rota_date: string;
  start_time: string;
  end_time: string;
  assignment_type: RotaAssignmentType;
  status: RotaStatus;
  travel_buffer_mins: number;
  swap_requested_with_staff_id: string | null;
  note: string | null;
}

export interface Ward {
  id: string;
  site_id: string;
  site_name?: string;
  name: string;
  specialty: string;
  total_beds: number;
  capabilities: string[];
  source_system: string;
  last_synced_iso: string;
}

export interface Bed {
  id: string;
  ward_id: string;
  ward_name?: string;
  site_name?: string;
  bed_label: string;
  capabilities: string[];
  occupancy_status: BedOccupancyStatus;
  current_admission_id: string | null;
  current_patient_name?: string | null;
  restriction_note: string | null;
  updated_by: string;
  updated_at: string;
}

export interface PlannedAdmission {
  id: string;
  patient_id: string;
  patient_name?: string;
  patient_nhs?: string | null;
  referral_id: string | null;
  specialty: string;
  site_id: string;
  site_name?: string;
  requested_ward_id: string;
  requested_ward_name?: string;
  allocated_bed_id: string | null;
  allocated_bed_label?: string | null;
  expected_admission_date: string;
  estimated_los_days: number;
  estimated_discharge_date: string;
  prerequisites: { label: string; completed: boolean }[];
  pre_admission_appt_id: string | null;
  state: AdmissionState;
  conflict_status: 'Clear' | 'Conflict Detected';
  conflict_reason: string | null;
  created_by: string;
}

export interface WorkTask {
  id: string;
  queue_type: WorkQueueType;
  title: string;
  description: string;
  entity_type: string;
  entity_id: string;
  patient_id: string | null;
  patient_name?: string | null;
  owner_staff_id: string | null;
  owner_name?: string | null;
  priority_source: string;
  due_iso: string;
  status: WorkTaskStatus;
  resolution_note: string | null;
  created_at: string;
}

export interface CommunicationRecord {
  id: string;
  patient_id: string;
  patient_name?: string;
  channel: CommChannel;
  message_type: 'Offer' | 'Confirmation' | 'Reminder' | 'Preparation' | 'Change' | 'Admission' | 'General';
  subject: string;
  body: string;
  lock_screen_safe_preview: string;
  status: CommStatus;
  failure_reason: string | null;
  accessible_format: string;
  language: string;
  emergency_disclaimer_shown: boolean;
  created_at: string;
  updated_at: string;
}

export interface AuditEntry {
  id: string;
  sequence_num: number;
  actor_user_id: string;
  actor_role: string;
  action: string;
  entity_type: string;
  entity_id: string;
  patient_id: string | null;
  details: Record<string, unknown>;
  prev_hash: string;
  entry_hash: string;
  created_at: string;
}

export interface IntegrationEvent {
  id: string;
  adapter_name: string;
  external_event_id: string;
  idempotency_key: string;
  direction: 'Inbound' | 'Outbound';
  authoritative_source: string;
  payload: Record<string, unknown>;
  sync_status: 'Synced' | 'Duplicate Ignored' | 'Conflict' | 'Failed';
  conflict_detail: string | null;
  created_at: string;
}

export interface OperationalReport {
  generated_at: string;
  prototype_disclaimer: string;
  referral_workload: {
    total: number;
    received_or_awaiting: number;
    accepted: number;
    declined_or_redirected: number;
  };
  waiting_list: {
    active_count: number;
    urgent_count: number;
    soon_count: number;
    routine_count: number;
  };
  appointments: {
    booked_or_confirmed_capacity: number;
    attended_activity: number;
    dna_count: number;
    cancelled_by_patient: number;
    cancelled_by_provider: number;
    average_booking_lead_days: number;
  };
  clinics: {
    total_slots: number;
    booked_slots: number;
    held_slots: number;
    unfilled_available_slots: number;
    utilisation_pct: number;
  };
  rotas: {
    published_sessions: number;
    draft_sessions: number;
    active_absences: number;
  };
  inpatients_and_beds: {
    planned_admissions: number;
    confirmed_admissions: number;
    actual_inpatient_admissions: number;
    total_beds: number;
    occupied_beds: number;
    closed_or_restricted_beds: number;
    available_beds: number;
    bed_occupancy_pct: number;
  };
  communications: {
    total_sent_or_delivered: number;
    failed_count: number;
    read_count: number;
  };
  open_work_tasks: number;
}

export interface DemonstratorChecklistItem {
  step: number;
  title: string;
  description: string;
  completed: boolean;
  target_view: string;
}
