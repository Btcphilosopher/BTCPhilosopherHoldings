import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {getDatabase} from './server/db/database';
import {seedDemonstratorDatabase} from './server/db/seed';
import {createApiRouter} from './server/routes/api';
import {releaseExpiredHolds} from './server/services/scheduler';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

// Initialize SQLite database, run migrations, and seed Pennine University Hospital Demonstrator
const db = getDatabase();
seedDemonstratorDatabase(db, false);

// Background worker: release expired slot holds every 10 seconds
const holdWorkerTimer = setInterval(() => {
  try {
    releaseExpiredHolds(db);
  } catch (err) {
    console.error('Background hold release error:', err);
  }
}, 10_000);
holdWorkerTimer.unref();

// Mount TertiusMedico API & SSE routes
app.use('/api', createApiRouter(db));

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`TertiusMedico server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
