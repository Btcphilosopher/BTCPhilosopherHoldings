export function formatLondonDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(iso));
}

export function formatLondonDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date(iso));
}

export function formatLondonTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(iso));
}

export function daysSince(iso: string | null | undefined): number {
  if (!iso) return 0;
  const diff = Date.now() - new Date(iso).getTime();
  return Math.max(0, Math.floor(diff / (24 * 3600 * 1000)));
}

export function statusToneClass(status: string | null | undefined): string {
  const s = (status || '').toLowerCase();
  if (
    s.includes('urgent') ||
    s.includes('fail') ||
    s.includes('closed') ||
    s.includes('conflict') ||
    s.includes('infection') ||
    s.includes('declined') ||
    s.includes('did not attend') ||
    s.includes('sickness') ||
    s.includes('mismatch')
  ) {
    return 'bg-[#FEF2F2] text-[#B91C1C] border-[#FECACA]';
  }
  if (
    s.includes('awaiting') ||
    s.includes('pending') ||
    s.includes('held') ||
    s.includes('soon') ||
    s.includes('clean') ||
    s.includes('draft') ||
    s.includes('leave') ||
    s.includes('further') ||
    s.includes('unverified') ||
    s.includes('acknowledged')
  ) {
    return 'bg-[#FFFBEB] text-[#B45309] border-[#FDE68A]';
  }
  if (
    s.includes('accept') ||
    s.includes('confirm') ||
    s.includes('complet') ||
    s.includes('avail') ||
    s.includes('clear') ||
    s.includes('publish') ||
    s.includes('verif') ||
    s.includes('deliv') ||
    s.includes('read') ||
    s.includes('resolv') ||
    s.includes('arrived') ||
    s.includes('synced')
  ) {
    return 'bg-[#ECFDF5] text-[#007F3B] border-[#A7F3D0]';
  }
  return 'bg-[#E8F1FA] text-[#003087] border-[#BFDBFE]';
}

export function extractErrorMessage(err: unknown): string {
  if (err && typeof err === 'object') {
    const e = err as {error?: {error?: string; message?: string}; message?: string};
    if (e.error?.error) return e.error.error;
    if (e.error?.message) return e.error.message;
    if (e.message) return e.message;
  }
  return 'An unexpected error occurred.';
}
