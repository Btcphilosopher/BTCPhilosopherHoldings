import {Injectable, inject, signal, PLATFORM_ID, OnDestroy} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {firstValueFrom} from 'rxjs';
import type {
  Appointment,
  AppointmentSlot,
  AuditEntry,
  AuthSession,
  Bed,
  ClinicSession,
  ClinicTemplate,
  CommunicationRecord,
  DemonstratorChecklistItem,
  IntegrationEvent,
  OperationalReport,
  PatientRecord,
  PlannedAdmission,
  Referral,
  Site,
  StaffRotaEntry,
  WaitingListEntry,
  Ward,
  WorkTask,
} from '../../shared/types';

export interface PersonaOption {
  id: string;
  username: string;
  display_name: string;
  role: string;
  specialty: string | null;
  site_id: string | null;
  mfa_enabled: boolean;
}

@Injectable({providedIn: 'root'})
export class ApiService implements OnDestroy {
  private http = inject(HttpClient);
  private platformId = inject(PLATFORM_ID);

  // Security rule: Bearer token kept strictly in JS memory, never in localStorage/sessionStorage
  readonly session = signal<AuthSession | null>(null);
  readonly sites = signal<Site[]>([]);
  readonly checklist = signal<DemonstratorChecklistItem[]>([]);
  readonly lastLiveEvent = signal<{type: string; timestamp: string} | null>(null);

  private eventSource: EventSource | null = null;
  private listeners = new Set<() => void>();

  private get headers(): HttpHeaders {
    const token = this.session()?.token;
    return token
      ? new HttpHeaders({Authorization: `Bearer ${token}`})
      : new HttpHeaders();
  }

  onLiveUpdate(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  connectSse(): void {
    if (!isPlatformBrowser(this.platformId) || this.eventSource) {
      return;
    }
    const es = new EventSource('/api/events');
    const eventTypes = [
      'slot:held',
      'slot:released',
      'appointment:booked',
      'appointment:updated',
      'referral:created',
      'referral:reviewed',
      'rota:updated',
      'rota:absence',
      'bed:updated',
      'admission:updated',
      'task:updated',
      'communication:created',
      'integration:event',
      'demo:reset',
    ];
    for (const t of eventTypes) {
      es.addEventListener(t, (ev: MessageEvent) => {
        try {
          const parsed = JSON.parse(String(ev.data)) as {type: string; timestamp: string};
          this.lastLiveEvent.set({type: parsed.type, timestamp: parsed.timestamp});
        } catch {
          this.lastLiveEvent.set({type: t, timestamp: new Date().toISOString()});
        }
        for (const cb of this.listeners) {
          cb();
        }
      });
    }
    this.eventSource = es;
  }

  ngOnDestroy(): void {
    this.eventSource?.close();
    this.eventSource = null;
  }

  async getPersonas(): Promise<{prototypeNotice: string; personas: PersonaOption[]}> {
    return firstValueFrom(
      this.http.get<{prototypeNotice: string; personas: PersonaOption[]}>('/api/auth/personas'),
    );
  }

  async login(username: string, options?: {password?: string; demoQuickSignIn?: boolean}): Promise<AuthSession> {
    const res = await firstValueFrom(
      this.http.post<AuthSession>('/api/auth/login', {
        username,
        password: options?.password,
        demoQuickSignIn: options?.demoQuickSignIn ?? false,
      }),
    );
    this.session.set(res);
    this.connectSse();
    await this.loadBootstrap();
    return res;
  }

  async verifyMfa(code: string): Promise<{mfa_verified: boolean}> {
    const res = await firstValueFrom(
      this.http.post<{mfa_verified: boolean}>('/api/auth/mfa-verify', {code}, {headers: this.headers}),
    );
    const cur = this.session();
    if (cur && res.mfa_verified) {
      this.session.set({...cur, mfa_verified: true});
    }
    return res;
  }

  async logout(): Promise<void> {
    if (this.session()) {
      try {
        await firstValueFrom(this.http.post('/api/auth/logout', {}, {headers: this.headers}));
      } catch {
        // ignore network errors on logout
      }
    }
    this.session.set(null);
    this.checklist.set([]);
  }

  async loadBootstrap(): Promise<void> {
    const data = await firstValueFrom(
      this.http.get<{
        sites: Site[];
        checklist: DemonstratorChecklistItem[];
      }>('/api/bootstrap', {headers: this.headers}),
    );
    this.sites.set(data.sites);
    this.checklist.set(data.checklist);
  }

  getPatients(): Promise<PatientRecord[]> {
    return firstValueFrom(this.http.get<PatientRecord[]>('/api/patients', {headers: this.headers}));
  }

  getPatientDetail(patientId: string): Promise<
    PatientRecord & {
      proxies: {
        id: string;
        patient_id: string;
        proxy_user_id: string;
        proxy_name: string;
        relationship_type: string;
        scope: string;
        verified_status: string;
      }[];
      epr_readiness: {authoritativeSource: string; clinicalClearanceAvailable: boolean; summaryNote: string};
    }
  > {
    return firstValueFrom(this.http.get<never>(`/api/patients/${patientId}`, {headers: this.headers}));
  }

  updatePatientPreferences(patientId: string, body: Record<string, unknown>): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.patch<{ok: boolean}>(`/api/patients/${patientId}`, body, {headers: this.headers}),
    );
  }

  verifyPatientNhs(patientId: string, overrideStatus?: string): Promise<{nhs_verification_status: string}> {
    return firstValueFrom(
      this.http.post<{nhs_verification_status: string}>(
        `/api/patients/${patientId}/verify-nhs`,
        {overrideStatus},
        {headers: this.headers},
      ),
    );
  }

  flagDuplicateReviewed(
    patientId: string,
    candidatePatientId: string,
    resolutionAction: string,
    notes: string,
  ): Promise<{ok: boolean; autoMerged: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean; autoMerged: boolean}>(
        `/api/patients/${patientId}/flag-duplicate`,
        {candidatePatientId, resolutionAction, notes},
        {headers: this.headers},
      ),
    );
  }

  updateProxy(proxyId: string, body: {verified_status?: string; scope?: string}): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.patch<{ok: boolean}>(`/api/proxies/${proxyId}`, body, {headers: this.headers}),
    );
  }

  getReferrals(): Promise<Referral[]> {
    return firstValueFrom(this.http.get<Referral[]>('/api/referrals', {headers: this.headers}));
  }

  createReferral(body: Record<string, unknown>): Promise<{id: string; status: string}> {
    return firstValueFrom(
      this.http.post<{id: string; status: string}>('/api/referrals', body, {headers: this.headers}),
    );
  }

  reviewReferral(
    referralId: string,
    body: Record<string, unknown>,
  ): Promise<{ok: boolean; status: string; clinical_priority: string; waitingListId: string | null}> {
    return firstValueFrom(
      this.http.post<never>(`/api/referrals/${referralId}/review`, body, {headers: this.headers}),
    );
  }

  getWaitingList(): Promise<WaitingListEntry[]> {
    return firstValueFrom(this.http.get<WaitingListEntry[]>('/api/waiting-list', {headers: this.headers}));
  }

  getClinicTemplates(): Promise<ClinicTemplate[]> {
    return firstValueFrom(this.http.get<ClinicTemplate[]>('/api/clinic-templates', {headers: this.headers}));
  }

  amendClinicTemplate(
    templateId: string,
    body: {default_duration_mins?: number; preparation_instructions?: string; amendment_reason: string},
  ): Promise<{ok: boolean; newVersion: number; affectedBookingsCount: number}> {
    return firstValueFrom(
      this.http.post<never>(`/api/clinic-templates/${templateId}/amend`, body, {headers: this.headers}),
    );
  }

  getClinicSessions(): Promise<ClinicSession[]> {
    return firstValueFrom(this.http.get<ClinicSession[]>('/api/clinic-sessions', {headers: this.headers}));
  }

  getEligibleSlots(
    referralId: string,
    preferredSiteId?: string | null,
    timeOfDay?: string | null,
  ): Promise<{eligible: AppointmentSlot[]; ineligible: AppointmentSlot[]}> {
    const params = new URLSearchParams({referralId});
    if (preferredSiteId) params.set('preferredSiteId', preferredSiteId);
    if (timeOfDay) params.set('timeOfDay', timeOfDay);
    return firstValueFrom(
      this.http.get<{eligible: AppointmentSlot[]; ineligible: AppointmentSlot[]}>(
        `/api/slots/eligible?${params.toString()}`,
        {headers: this.headers},
      ),
    );
  }

  holdSlot(
    slotId: string,
    options?: {ttlSeconds?: number; simulateCompetingUserId?: string},
  ): Promise<{slotId: string; heldUntilIso: string}> {
    return firstValueFrom(
      this.http.post<{slotId: string; heldUntilIso: string}>(
        `/api/slots/${slotId}/hold`,
        options ?? {},
        {headers: this.headers},
      ),
    );
  }

  releaseSlot(slotId: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(`/api/slots/${slotId}/release`, {}, {headers: this.headers}),
    );
  }

  getAppointments(): Promise<Appointment[]> {
    return firstValueFrom(this.http.get<Appointment[]>('/api/appointments', {headers: this.headers}));
  }

  bookAppointment(body: {
    slot_id: string;
    referral_id: string;
    short_notice_opt_in?: boolean;
  }): Promise<Appointment> {
    return firstValueFrom(
      this.http.post<Appointment>('/api/appointments', body, {headers: this.headers}),
    );
  }

  transitionAppointment(
    appointmentId: string,
    body: {targetStatus: string; reason?: string; clinicalOutcome?: string},
  ): Promise<Appointment> {
    return firstValueFrom(
      this.http.post<Appointment>(`/api/appointments/${appointmentId}/transition`, body, {
        headers: this.headers,
      }),
    );
  }

  rescheduleAppointment(
    appointmentId: string,
    body: {newSlotId: string; reason: string},
  ): Promise<{previousAppointmentId: string; newAppointment: Appointment}> {
    return firstValueFrom(
      this.http.post<never>(`/api/appointments/${appointmentId}/reschedule`, body, {
        headers: this.headers,
      }),
    );
  }

  arrangeFollowUp(
    appointmentId: string,
    body: {clinical_priority: string; format: string; booking_window_days: number; notes: string},
  ): Promise<{followUpReferralId: string; waitingListId: string}> {
    return firstValueFrom(
      this.http.post<never>(`/api/appointments/${appointmentId}/follow-up`, body, {
        headers: this.headers,
      }),
    );
  }

  async downloadIcs(appointmentId: string): Promise<void> {
    const icsText = await firstValueFrom(
      this.http.get(`/api/appointments/${appointmentId}/ics`, {
        headers: this.headers,
        responseType: 'text',
      }),
    );
    const blob = new Blob([icsText], {type: 'text/calendar;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${appointmentId}.ics`;
    a.click();
    URL.revokeObjectURL(url);
  }

  getRotas(): Promise<StaffRotaEntry[]> {
    return firstValueFrom(this.http.get<StaffRotaEntry[]>('/api/rotas', {headers: this.headers}));
  }

  publishRota(rotaId: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(`/api/rotas/${rotaId}/publish`, {}, {headers: this.headers}),
    );
  }

  recordStaffAbsence(
    rotaId: string,
    absenceType: 'Leave' | 'Sickness Absence',
    note: string,
  ): Promise<{ok: boolean; affectedAppointments: {id: string; patient_name: string}[]}> {
    return firstValueFrom(
      this.http.post<never>(`/api/rotas/${rotaId}/absence`, {absenceType, note}, {headers: this.headers}),
    );
  }

  getWardsAndBeds(): Promise<{wards: Ward[]; beds: Bed[]}> {
    return firstValueFrom(
      this.http.get<{wards: Ward[]; beds: Bed[]}>('/api/wards-beds', {headers: this.headers}),
    );
  }

  updateBed(bedId: string, body: {occupancy_status: string; restriction_note: string | null}): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.patch<{ok: boolean}>(`/api/beds/${bedId}`, body, {headers: this.headers}),
    );
  }

  getAdmissions(): Promise<PlannedAdmission[]> {
    return firstValueFrom(this.http.get<PlannedAdmission[]>('/api/admissions', {headers: this.headers}));
  }

  createAdmission(body: Record<string, unknown>): Promise<{id: string; conflictStatus: string}> {
    return firstValueFrom(
      this.http.post<never>('/api/admissions', body, {headers: this.headers}),
    );
  }

  resolveAdmissionConflict(
    admissionId: string,
    body: {newBedId?: string; completeAllPrerequisites?: boolean; resolutionNotes?: string},
  ): Promise<{ok: boolean; conflictStatus: string; conflictReason: string | null}> {
    return firstValueFrom(
      this.http.post<never>(`/api/admissions/${admissionId}/resolve-conflict`, body, {
        headers: this.headers,
      }),
    );
  }

  transitionAdmission(admissionId: string, targetState: string): Promise<{ok: boolean; state: string}> {
    return firstValueFrom(
      this.http.post<never>(`/api/admissions/${admissionId}/transition`, {targetState}, {
        headers: this.headers,
      }),
    );
  }

  getWorkTasks(): Promise<WorkTask[]> {
    return firstValueFrom(this.http.get<WorkTask[]>('/api/work-tasks', {headers: this.headers}));
  }

  updateWorkTask(taskId: string, body: {status?: string; resolution_note?: string}): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.patch<{ok: boolean}>(`/api/work-tasks/${taskId}`, body, {headers: this.headers}),
    );
  }

  batchWorkTasks(body: {
    taskIds: string[];
    action: 'acknowledge' | 'resolve';
    preview: boolean;
    resolutionNote?: string;
  }): Promise<{preview: boolean; results: {id: string; eligible: boolean; outcome: string}[]}> {
    return firstValueFrom(
      this.http.post<never>('/api/work-tasks/batch', body, {headers: this.headers}),
    );
  }

  getCommunications(): Promise<CommunicationRecord[]> {
    return firstValueFrom(
      this.http.get<CommunicationRecord[]>('/api/communications', {headers: this.headers}),
    );
  }

  sendCommunication(body: Record<string, unknown>): Promise<CommunicationRecord> {
    return firstValueFrom(
      this.http.post<CommunicationRecord>('/api/communications', body, {headers: this.headers}),
    );
  }

  retryCommunication(commId: string, fallbackChannel: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(
        `/api/communications/${commId}/retry`,
        {fallbackChannel},
        {headers: this.headers},
      ),
    );
  }

  markCommunicationRead(commId: string): Promise<{ok: boolean}> {
    return firstValueFrom(
      this.http.post<{ok: boolean}>(`/api/communications/${commId}/read`, {}, {headers: this.headers}),
    );
  }

  getReports(): Promise<OperationalReport> {
    return firstValueFrom(this.http.get<OperationalReport>('/api/reports', {headers: this.headers}));
  }

  getAudit(): Promise<{chainIntegrity: {valid: boolean; total: number}; entries: AuditEntry[]}> {
    return firstValueFrom(this.http.get<never>('/api/audit', {headers: this.headers}));
  }

  getIntegrations(): Promise<{
    adapters: {name: string; authoritativeFor: string[]; mode: string}[];
    events: IntegrationEvent[];
  }> {
    return firstValueFrom(this.http.get<never>('/api/integrations', {headers: this.headers}));
  }

  simulateIntegrationEvent(body: Record<string, unknown>): Promise<{status: string; event: IntegrationEvent}> {
    return firstValueFrom(
      this.http.post<never>('/api/integrations/simulate-event', body, {headers: this.headers}),
    );
  }

  resetDemonstrator(): Promise<{ok: boolean}> {
    return firstValueFrom(this.http.post<{ok: boolean}>('/api/demo/reset', {}, {headers: this.headers}));
  }
}
