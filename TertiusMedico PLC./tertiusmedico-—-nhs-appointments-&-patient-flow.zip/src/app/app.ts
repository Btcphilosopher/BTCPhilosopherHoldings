import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  PLATFORM_ID,
  computed,
  inject,
  signal,
} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {ApiService, type PersonaOption} from './services/api';
import {extractErrorMessage} from './services/format';
import {PatientPortal, type PatientTab} from './portals/patient-portal';
import {StaffWorkspace, type StaffSection} from './portals/staff-workspace';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [ReactiveFormsModule, MatIconModule, PatientPortal, StaffWorkspace],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  readonly api = inject(ApiService);
  private platformId = inject(PLATFORM_ID);
  private fb = inject(FormBuilder);

  readonly patientTab = signal<PatientTab>('appointments');
  readonly staffSection = signal<StaffSection>('overview');
  readonly showPersonaModal = signal(false);
  readonly personas = signal<PersonaOption[]>([]);
  readonly authError = signal<string | null>(null);

  readonly patientTabs: {id: PatientTab; label: string}[] = [
    {id: 'appointments', label: 'Appointments'},
    {id: 'book', label: 'Book or change'},
    {id: 'messages', label: 'Messages'},
    {id: 'admission', label: 'Admission info'},
    {id: 'accessibility', label: 'Accessibility'},
    {id: 'account', label: 'Account'},
  ];

  readonly staffTopLinks: {id: StaffSection; label: string}[] = [
    {id: 'overview', label: 'Overview'},
    {id: 'referrals', label: 'Referrals'},
    {id: 'waiting-lists', label: 'Waiting lists'},
    {id: 'inpatients', label: 'Inpatients'},
    {id: 'reports', label: 'Reports'},
  ];

  readonly isPatientExperience = computed(() => {
    const role = this.api.session()?.user.role;
    return role === 'patient' || role === 'proxy';
  });

  readonly patientPersonas = computed(() =>
    this.personas().filter((p) => p.role === 'patient' || p.role === 'proxy'),
  );

  readonly staffPersonas = computed(() =>
    this.personas().filter((p) => p.role !== 'patient' && p.role !== 'proxy'),
  );

  readonly loginForm = this.fb.group({
    username: ['h.patel', Validators.required],
    password: ['PennineDemo2026!', Validators.required],
  });

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      void this.initBrowserSession();
    }
  }

  private async initBrowserSession(): Promise<void> {
    try {
      const dir = await this.api.getPersonas();
      this.personas.set(dir.personas);
      // Start demonstrator as Consultant Cardiologist Dr. Hannah Patel
      if (!this.api.session()) {
        await this.api.login('h.patel', {demoQuickSignIn: true});
      }
    } catch {
      // Allow manual persona modal opening if backend is still booting
    }
  }

  async openPersonaModal(): Promise<void> {
    this.authError.set(null);
    if (this.personas().length === 0) {
      try {
        const dir = await this.api.getPersonas();
        this.personas.set(dir.personas);
      } catch {
        // ignore
      }
    }
    this.showPersonaModal.set(true);
  }

  async quickSignIn(username: string): Promise<void> {
    this.authError.set(null);
    try {
      const session = await this.api.login(username, {demoQuickSignIn: true});
      this.showPersonaModal.set(false);
      if (session.user.role === 'patient' || session.user.role === 'proxy') {
        this.patientTab.set('appointments');
      } else {
        this.staffSection.set('overview');
      }
    } catch (err) {
      this.authError.set(extractErrorMessage(err));
    }
  }

  async submitPasscodeLogin(): Promise<void> {
    if (this.loginForm.invalid) return;
    this.authError.set(null);
    try {
      const {username, password} = this.loginForm.value;
      const session = await this.api.login(username!, {
        password: password!,
        demoQuickSignIn: false,
      });
      if (!session.mfa_verified) {
        await this.api.verifyMfa('123456');
      }
      this.showPersonaModal.set(false);
    } catch (err) {
      this.authError.set(extractErrorMessage(err));
    }
  }

  resetToHome(): void {
    if (this.isPatientExperience()) {
      this.patientTab.set('appointments');
    } else {
      this.staffSection.set('overview');
    }
  }
}
