import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {
  Appointment,
  AppointmentSlot,
  CommunicationRecord,
  PatientRecord,
  Referral,
} from '../../shared/types';
import {ApiService} from '../services/api';
import {
  extractErrorMessage,
  formatLondonDate,
  formatLondonDateTime,
  formatLondonTime,
  statusToneClass,
} from '../services/format';

export type PatientTab =
  | 'appointments'
  | 'book'
  | 'messages'
  | 'admission'
  | 'accessibility'
  | 'account';

@Component({
  selector: 'app-patient-portal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="mx-auto max-w-[1200px] px-4 py-6 sm:px-6 lg:px-8">
      <!-- Feedback Banner -->
      @if (feedback()) {
        <div
          class="mb-6 flex items-start justify-between gap-4 rounded-lg border p-4"
          [class]="
            feedback()!.tone === 'error'
              ? 'border-[#FECACA] bg-[#FEF2F2] text-[#991B1B]'
              : feedback()!.tone === 'warning'
                ? 'border-[#FDE68A] bg-[#FFFBEB] text-[#92400E]'
                : 'border-[#A7F3D0] bg-[#ECFDF5] text-[#065F46]'
          "
          role="status"
        >
          <div class="flex items-start gap-3">
            <mat-icon class="mt-0.5 shrink-0 text-[20px]">
              {{
                feedback()!.tone === 'error'
                  ? 'error_outline'
                  : feedback()!.tone === 'warning'
                    ? 'warning_amber'
                    : 'check_circle'
              }}
            </mat-icon>
            <div>
              <p class="text-sm font-semibold">{{ feedback()!.title }}</p>
              <p class="mt-0.5 text-sm">{{ feedback()!.detail }}</p>
            </div>
          </div>
          <button
            type="button"
            (click)="feedback.set(null)"
            class="shrink-0 rounded p-1 hover:bg-black/5"
            aria-label="Dismiss notification"
          >
            <mat-icon class="text-[18px]">close</mat-icon>
          </button>
        </div>
      }

      <!-- Access Denied State (e.g., Unverified Proxy Nadia Begum) -->
      @if (accessBlockedError()) {
        <section class="rounded-lg border border-[#FECACA] bg-white p-8">
          <div class="flex items-start gap-4">
            <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-[#FEF2F2] text-[#D5281B]">
              <mat-icon>gpp_bad</mat-icon>
            </div>
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Proxy verification required</h1>
              <p class="mt-2 max-w-2xl text-base text-[#4C6272]">
                {{ accessBlockedError() }}
              </p>
              <p class="mt-3 text-sm text-[#4C6272]">
                Under TertiusMedico governance rules, a family relationship does not automatically grant access to clinical schedules or messages. A booking coordinator must verify identity and proxy scope first.
              </p>
              <button
                type="button"
                (click)="requestSwitchPersona.emit()"
                class="mt-5 inline-flex items-center gap-2 rounded bg-[#005EB8] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#003087]"
              >
                <mat-icon class="text-[18px]">swap_horiz</mat-icon>
                Switch persona to verify proxy or view as Tariq / Fatima
              </button>
            </div>
          </div>
        </section>
      } @else {
        <!-- Portal Header Summary -->
        @if (patient(); as p) {
          <div class="mb-6 flex flex-col justify-between gap-4 border-b border-[#D8DDE0] pb-5 md:flex-row md:items-end">
            <div>
              <p class="text-xs font-medium text-[#4C6272]">
                Patient Portal · Pennine University Hospital Demonstrator
              </p>
              <h1 class="mt-1 text-2xl font-bold tracking-tight text-[#212B32] sm:text-3xl">
                Welcome, {{ p.given_name }} {{ p.family_name }}
              </h1>
              <p class="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-[#4C6272]">
                <span>NHS No: <strong class="font-mono tabular-nums text-[#212B32]">{{ p.nhs_number || 'Not supplied' }}</strong></span>
                <span aria-hidden="true">·</span>
                <span>DOB: <span class="tabular-nums">{{ formatDate(p.date_of_birth) }}</span></span>
                <span aria-hidden="true">·</span>
                <span>Preferred channel: {{ p.preferred_channel }}</span>
                @if (p.interpreter_required) {
                  <span aria-hidden="true">·</span>
                  <span class="font-medium text-[#005EB8]">{{ p.preferred_language }} interpreter flagged</span>
                }
              </p>
            </div>

            <div class="flex flex-wrap items-center gap-2">
              <button
                type="button"
                (click)="tabChange.emit('book')"
                class="inline-flex items-center gap-2 rounded bg-[#005EB8] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#003087] whitespace-nowrap shrink-0"
              >
                <mat-icon class="text-[18px]">event_available</mat-icon>
                Book or change appointment
              </button>
            </div>
          </div>
        }

        <!-- TAB 1: APPOINTMENTS -->
        @if (activeTab() === 'appointments') {
          <div class="space-y-6">
            <div class="flex items-center justify-between">
              <h2 class="text-xl font-semibold text-[#212B32]">Your hospital appointments</h2>
              <span class="text-sm text-[#4C6272] tabular-nums">{{ appointments().length }} record(s)</span>
            </div>

            @if (loading()) {
              <div class="space-y-3">
                <div class="h-28 animate-pulse rounded-lg border border-[#D8DDE0] bg-white"></div>
                <div class="h-28 animate-pulse rounded-lg border border-[#D8DDE0] bg-white"></div>
              </div>
            } @else if (appointments().length === 0) {
              <div class="rounded-lg border border-[#D8DDE0] bg-white p-8 text-center">
                <mat-icon class="text-[36px] text-[#4C6272]">calendar_today</mat-icon>
                <h3 class="mt-2 text-lg font-semibold text-[#212B32]">No appointments booked yet</h3>
                <p class="mx-auto mt-1 max-w-md text-sm text-[#4C6272]">
                  If your referral has been accepted by a clinician, you can choose an eligible clinic slot in Book or change.
                </p>
                <button
                  type="button"
                  (click)="tabChange.emit('book')"
                  class="mt-4 inline-flex items-center gap-2 rounded bg-[#005EB8] px-4 py-2 text-sm font-semibold text-white hover:bg-[#003087]"
                >
                  <mat-icon class="text-[18px]">search</mat-icon>
                  View eligible slots
                </button>
              </div>
            } @else {
              <div class="space-y-4">
                @for (appt of appointments(); track appt.id) {
                  <article class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                    <div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
                      <div class="space-y-2">
                        <div class="flex flex-wrap items-center gap-2">
                          <span
                            class="inline-flex items-center gap-1 rounded border px-2 py-0.5 text-xs font-semibold"
                            [class]="toneClass(appt.status)"
                          >
                            {{ appt.status }}
                          </span>
                          <span class="text-xs text-[#4C6272] font-mono tabular-nums">{{ appt.id }}</span>
                          <span aria-hidden="true" class="text-[#4C6272]">·</span>
                          <span class="text-xs text-[#4C6272]">{{ appt.format }}</span>
                        </div>

                        <h3 class="text-lg font-semibold text-[#212B32]">
                          {{ appt.specialty }} — {{ appt.appointment_type }}
                        </h3>

                        <p class="text-sm font-medium text-[#212B32] tabular-nums">
                          {{ formatDateTime(appt.start_iso) }} – {{ formatTime(appt.end_iso) }} (UK time)
                        </p>

                        <p class="text-sm text-[#4C6272]">
                          {{ appt.site_name }} · {{ appt.room_name }} · {{ appt.clinician_name }}
                        </p>

                        @if (appt.interpreter_booked) {
                          <p class="text-sm font-medium text-[#005EB8]">
                            Interpreter requested: {{ appt.interpreter_booked }}
                          </p>
                        }

                        @if (appt.preparation_instructions) {
                          <div class="mt-2 rounded border border-[#D8DDE0] bg-[#F8FAFB] p-3 text-sm text-[#212B32]">
                            <strong class="font-semibold">Preparation instructions:</strong>
                            {{ appt.preparation_instructions }}
                          </div>
                        }

                        @if (appt.video_join_url && (appt.status === 'Booked' || appt.status === 'Confirmed')) {
                          <p class="text-sm text-[#005EB8]">
                            Simulated video waiting room: <span class="font-mono text-xs">{{ appt.video_join_url }}</span>
                          </p>
                        }

                        @if (appt.linked_previous_appointment_id) {
                          <p class="text-xs text-[#4C6272]">
                            Rescheduled from previous booking {{ appt.linked_previous_appointment_id }}
                          </p>
                        }
                      </div>

                      <div class="flex flex-wrap gap-2 lg:flex-col lg:items-end">
                        @if (appt.status === 'Booked') {
                          <button
                            type="button"
                            (click)="confirmAttendance(appt.id)"
                            class="inline-flex items-center gap-1.5 rounded bg-[#007F3B] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#00662F] whitespace-nowrap shrink-0"
                          >
                            <mat-icon class="text-[16px]">check</mat-icon>
                            Confirm attendance
                          </button>
                        }

                        @if (appt.status === 'Booked' || appt.status === 'Confirmed') {
                          <button
                            type="button"
                            (click)="startReschedule(appt)"
                            class="inline-flex items-center gap-1.5 rounded border border-[#005EB8] bg-white px-3.5 py-2 text-xs font-semibold text-[#005EB8] hover:bg-[#E8F1FA] whitespace-nowrap shrink-0"
                          >
                            <mat-icon class="text-[16px]">edit_calendar</mat-icon>
                            Change appointment
                          </button>
                          <button
                            type="button"
                            (click)="api.downloadIcs(appt.id)"
                            class="inline-flex items-center gap-1.5 rounded border border-[#D8DDE0] bg-white px-3.5 py-2 text-xs font-medium text-[#212B32] hover:bg-[#F0F4F5] whitespace-nowrap shrink-0"
                          >
                            <mat-icon class="text-[16px]">download</mat-icon>
                            Add to calendar (.ics)
                          </button>
                          <button
                            type="button"
                            (click)="cancelAppointment(appt.id)"
                            class="inline-flex items-center gap-1.5 rounded border border-[#FECACA] bg-white px-3.5 py-2 text-xs font-medium text-[#B91C1C] hover:bg-[#FEF2F2] whitespace-nowrap shrink-0"
                          >
                            <mat-icon class="text-[16px]">cancel</mat-icon>
                            Cancel booking
                          </button>
                        }
                      </div>
                    </div>
                  </article>
                }
              </div>
            }

            <!-- Referral Status Overview -->
            <div class="mt-8 rounded-lg border border-[#D8DDE0] bg-white p-5">
              <h3 class="text-base font-semibold text-[#212B32]">Your active referrals</h3>
              <div class="mt-3 divide-y divide-[#E5E7EB]">
                @for (ref of referrals(); track ref.id) {
                  <div class="flex flex-col justify-between gap-2 py-3 sm:flex-row sm:items-center">
                    <div>
                      <p class="text-sm font-semibold text-[#212B32]">
                        {{ ref.specialty }} · {{ ref.service_name }}
                      </p>
                      <p class="text-xs text-[#4C6272]">
                        Received {{ formatDate(ref.received_at) }} · {{ ref.required_format }} ({{ ref.required_duration_mins }}m)
                      </p>
                    </div>
                    <div class="flex items-center gap-2">
                      <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(ref.status)">
                        {{ ref.status }}
                      </span>
                      @if (ref.status === 'Accepted') {
                        <button
                          type="button"
                          (click)="selectReferralAndBook(ref.id)"
                          class="inline-flex items-center gap-1 rounded bg-[#005EB8] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#003087] whitespace-nowrap shrink-0"
                        >
                          <mat-icon class="text-[15px]">calendar_month</mat-icon>
                          Select slot
                        </button>
                      }
                    </div>
                  </div>
                } @empty {
                  <p class="py-3 text-sm text-[#4C6272]">No referrals recorded for this account.</p>
                }
              </div>
            </div>
          </div>
        }

        <!-- TAB 2: BOOK OR CHANGE -->
        @if (activeTab() === 'book') {
          <div class="grid grid-cols-1 gap-6 lg:grid-cols-12">
            <div class="space-y-5 lg:col-span-8">
              <div class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                <h2 class="text-xl font-semibold text-[#212B32]">
                  {{ reschedulingAppt() ? 'Reschedule appointment ' + reschedulingAppt()!.id : 'Book an eligible appointment slot' }}
                </h2>
                <p class="mt-1 text-sm text-[#4C6272]">
                  Only slots matching your clinical review requirements, duration, clinic format, and booking window are offered.
                </p>

                @if (reschedulingAppt()) {
                  <div class="mt-4 rounded border border-[#FDE68A] bg-[#FFFBEB] p-3 text-sm text-[#92400E]">
                    Changing booking for <strong>{{ reschedulingAppt()!.specialty }}</strong> (currently {{ formatDateTime(reschedulingAppt()!.start_iso) }}). Your original waiting-list start date is preserved.
                    <button
                      type="button"
                      (click)="reschedulingAppt.set(null)"
                      class="ml-2 font-semibold underline"
                    >
                      Cancel reschedule mode
                    </button>
                  </div>
                }

                <form [formGroup]="slotFilterForm" class="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label for="pt-ref-select" class="block text-xs font-semibold text-[#212B32]">Accepted referral</label>
                    <select
                      id="pt-ref-select"
                      formControlName="referralId"
                      (change)="loadEligibleSlots()"
                      class="mt-1 w-full rounded border border-[#D8DDE0] bg-white px-3 py-2 text-sm text-[#212B32]"
                    >
                      @for (ref of acceptedReferrals(); track ref.id) {
                        <option [value]="ref.id">{{ ref.specialty }} ({{ ref.id }})</option>
                      }
                    </select>
                  </div>

                  <div>
                    <label for="pt-site-select" class="block text-xs font-semibold text-[#212B32]">Preferred hospital site</label>
                    <select
                      id="pt-site-select"
                      formControlName="preferredSiteId"
                      (change)="loadEligibleSlots()"
                      class="mt-1 w-full rounded border border-[#D8DDE0] bg-white px-3 py-2 text-sm text-[#212B32]"
                    >
                      <option value="">Any hospital site</option>
                      @for (s of api.sites(); track s.id) {
                        <option [value]="s.id">{{ s.name }}</option>
                      }
                    </select>
                  </div>

                  <div>
                    <label for="pt-tod-select" class="block text-xs font-semibold text-[#212B32]">Time of day preference</label>
                    <select
                      id="pt-tod-select"
                      formControlName="timeOfDay"
                      (change)="loadEligibleSlots()"
                      class="mt-1 w-full rounded border border-[#D8DDE0] bg-white px-3 py-2 text-sm text-[#212B32]"
                    >
                      <option value="">Any time</option>
                      <option value="morning">Morning (before 12:00)</option>
                      <option value="afternoon">Afternoon (12:00 onwards)</option>
                    </select>
                  </div>
                </form>

                @if (acceptedReferrals().length === 0) {
                  <div class="mt-5 rounded border border-[#D8DDE0] bg-[#F8FAFB] p-4 text-sm text-[#4C6272]">
                    You have no referrals currently awaiting booking. Referrals in "Awaiting review" must first be clinically accepted by a consultant before slots can be offered.
                  </div>
                } @else if (eligibleSlots().length === 0) {
                  <div class="mt-5 rounded border border-[#FDE68A] bg-[#FFFBEB] p-4 text-sm text-[#92400E]">
                    <p class="font-semibold">No suitable slots currently available online</p>
                    <p class="mt-1">
                      Your referral remains safely active on the waiting list. Please contact the booking team below so staff can arrange an appointment or add you to the short-notice cancellation list.
                    </p>
                  </div>
                } @else {
                  <div class="mt-5 space-y-3">
                    @for (slot of eligibleSlots(); track slot.id) {
                      <div
                        class="flex flex-col justify-between gap-4 rounded-lg border p-4 transition-colors sm:flex-row sm:items-center"
                        [class]="
                          heldSlot()?.slotId === slot.id
                            ? 'border-[#005EB8] bg-[#E8F1FA]/40'
                            : 'border-[#D8DDE0] bg-white'
                        "
                      >
                        <div>
                          <div class="flex flex-wrap items-center gap-2 text-xs text-[#4C6272]">
                            <span class="font-semibold text-[#003087]">{{ slot.site_name }}</span>
                            <span aria-hidden="true">·</span>
                            <span>{{ slot.format }}</span>
                            <span aria-hidden="true">·</span>
                            <span class="tabular-nums">{{ slot.duration_mins }} mins</span>
                            @if (slot.protected_for_priority) {
                              <span aria-hidden="true">·</span>
                              <span class="font-semibold text-[#B45309]">Urgent protected slot</span>
                            }
                          </div>
                          <p class="mt-1 text-base font-semibold text-[#212B32] tabular-nums">
                            {{ formatDateTime(slot.start_iso) }} – {{ formatTime(slot.end_iso) }}
                          </p>
                          <p class="text-xs text-[#4C6272]">
                            {{ slot.clinician_name }} · {{ slot.room_name }}
                          </p>
                        </div>

                        <div class="flex flex-wrap items-center gap-2 shrink-0">
                          @if (heldSlot()?.slotId === slot.id) {
                            <button
                              type="button"
                              (click)="testCompetingHold(slot.id)"
                              class="inline-flex items-center gap-1.5 rounded border border-[#D97706] bg-[#FFFBEB] px-3 py-2 text-xs font-semibold text-[#B45309] hover:bg-[#FEF3C7] whitespace-nowrap"
                            >
                              <mat-icon class="text-[16px]">lock</mat-icon>
                              Test competing user
                            </button>
                            <button
                              type="button"
                              (click)="confirmHeldSlot(slot)"
                              class="inline-flex items-center gap-1.5 rounded bg-[#007F3B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#00662F] whitespace-nowrap"
                            >
                              <mat-icon class="text-[16px]">check_circle</mat-icon>
                              {{ reschedulingAppt() ? 'Confirm reschedule' : 'Confirm booking' }}
                            </button>
                          } @else {
                            <button
                              type="button"
                              (click)="holdSlotForSelection(slot.id)"
                              class="inline-flex items-center gap-1.5 rounded bg-[#005EB8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#003087] whitespace-nowrap"
                            >
                              <mat-icon class="text-[16px]">schedule</mat-icon>
                              Select &amp; hold (5 min)
                            </button>
                          }
                        </div>
                      </div>
                    }
                  </div>
                }

                @if (heldSlot()) {
                  <div class="mt-4 rounded border border-[#BFDBFE] bg-[#E8F1FA] p-4 text-sm text-[#003087]">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <strong>Transactional hold active:</strong> Slot {{ heldSlot()!.slotId }} is reserved for you until
                        <span class="font-mono tabular-nums">{{ formatTime(heldSlot()!.heldUntilIso) }}</span>.
                      </div>
                      <label class="inline-flex items-center gap-2 text-xs font-medium">
                        <input
                          type="checkbox"
                          [checked]="shortNoticeOptIn()"
                          (change)="shortNoticeOptIn.set($any($event.target).checked)"
                          class="h-4 w-4 rounded border-[#005EB8]"
                        />
                        Also join short-notice cancellation list
                      </label>
                    </div>
                  </div>
                }

                @if (ineligibleSlots().length > 0) {
                  <details class="mt-5 rounded border border-[#D8DDE0] bg-[#F8FAFB] p-3 text-xs text-[#4C6272]">
                    <summary class="cursor-pointer font-semibold text-[#212B32]">
                      Why {{ ineligibleSlots().length }} other {{ acceptedReferrals()[0]?.specialty }} slot(s) are excluded
                    </summary>
                    <ul class="mt-2 space-y-1.5 pl-4 list-disc">
                      @for (bad of ineligibleSlots().slice(0, 6); track bad.id) {
                        <li>
                          <span class="font-mono">{{ formatDateTime(bad.start_iso) }}</span> ({{ bad.site_name }}):
                          {{ bad.conflict_reasons?.join('; ') }}
                        </li>
                      }
                    </ul>
                  </details>
                }
              </div>
            </div>

            <!-- Right Column: Staff-assisted booking & site info -->
            <div class="space-y-5 lg:col-span-4">
              <div class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                <div class="flex items-center gap-2 text-[#005EB8]">
                  <mat-icon>support_agent</mat-icon>
                  <h3 class="text-base font-semibold text-[#212B32]">Need help booking?</h3>
                </div>
                <p class="mt-2 text-sm text-[#4C6272]">
                  If you cannot use the online booking service or need an interpreter / accessible room confirmed, our booking coordinators can help over the telephone.
                </p>
                <p class="mt-3 text-sm font-semibold text-[#212B32] tabular-nums">
                  Booking Desk: 01274 000 100 (Mon–Fri, 08:00–18:00)
                </p>
                <button
                  type="button"
                  (click)="requestStaffBookingHelp()"
                  class="mt-4 inline-flex w-full items-center justify-center gap-2 rounded border border-[#005EB8] bg-white px-4 py-2 text-sm font-semibold text-[#005EB8] hover:bg-[#E8F1FA]"
                >
                  <mat-icon class="text-[18px]">phone_callback</mat-icon>
                  Request booking-team call back
                </button>
              </div>

              @for (site of api.sites(); track site.id) {
                <div class="overflow-hidden rounded-lg border border-[#D8DDE0] bg-white">
                  <img
                    [src]="site.image_url"
                    [alt]="site.name + ' entrance'"
                    referrerpolicy="no-referrer"
                    class="h-36 w-full object-cover"
                  />
                  <div class="p-4">
                    <h4 class="text-sm font-semibold text-[#212B32]">{{ site.name }}</h4>
                    <p class="mt-0.5 text-xs text-[#4C6272]">{{ site.city }} · {{ site.postcode }}</p>
                    <p class="mt-2 text-xs text-[#4C6272]">{{ site.description }}</p>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 3: MESSAGES -->
        @if (activeTab() === 'messages') {
          <div class="space-y-4">
            <div class="rounded-lg border border-[#FDE68A] bg-[#FFFBEB] p-4 text-sm text-[#92400E]">
              <div class="flex items-start gap-3">
                <mat-icon class="mt-0.5 shrink-0">emergency</mat-icon>
                <p>
                  <strong>Important:</strong> Portal messages are not monitored as an emergency service. For life-threatening emergencies call <strong>999</strong>. For urgent medical advice call <strong>NHS 111</strong>.
                </p>
              </div>
            </div>

            <div class="rounded-lg border border-[#D8DDE0] bg-white divide-y divide-[#E5E7EB]">
              @for (msg of messages(); track msg.id) {
                <div class="p-5">
                  <div class="flex flex-wrap items-center justify-between gap-2">
                    <div class="flex flex-wrap items-center gap-2">
                      <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(msg.status)">
                        {{ msg.status }}
                      </span>
                      <span class="text-xs text-[#4C6272]">{{ msg.channel }} · {{ msg.message_type }}</span>
                      <span aria-hidden="true" class="text-[#4C6272]">·</span>
                      <span class="text-xs text-[#4C6272] tabular-nums">{{ formatDateTime(msg.created_at) }}</span>
                    </div>
                    @if (msg.status !== 'Read' && msg.status !== 'Failed') {
                      <button
                        type="button"
                        (click)="markRead(msg.id)"
                        class="text-xs font-semibold text-[#005EB8] hover:underline"
                      >
                        Mark as read
                      </button>
                    }
                  </div>
                  <h3 class="mt-2 text-base font-semibold text-[#212B32]">{{ msg.subject }}</h3>
                  <p class="mt-1 text-sm text-[#212B32]">{{ msg.body }}</p>
                  <p class="mt-2 text-xs text-[#4C6272]">
                    Lock-screen safe preview: <em>"{{ msg.lock_screen_safe_preview }}"</em>
                  </p>
                </div>
              } @empty {
                <div class="p-8 text-center text-sm text-[#4C6272]">No portal messages found.</div>
              }
            </div>
          </div>
        }

        <!-- TAB 4: ADMISSION INFO -->
        @if (activeTab() === 'admission') {
          <div class="space-y-4">
            <h2 class="text-xl font-semibold text-[#212B32]">Inpatient admission information</h2>
            <div class="rounded-lg border border-[#D8DDE0] bg-white p-6">
              <p class="text-sm text-[#4C6272]">
                Elective inpatient admissions require clinical pre-assessment clearance and confirmed ward capacity before your admission date is finalised. Emergency admissions are managed separately through Acute Assessment Units and are never self-booked online.
              </p>
              <div class="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
                @for (site of api.sites(); track site.id) {
                  <div class="overflow-hidden rounded-lg border border-[#D8DDE0]">
                    <img
                      [src]="site.image_url"
                      [alt]="site.name"
                      referrerpolicy="no-referrer"
                      class="h-44 w-full object-cover"
                    />
                    <div class="p-4">
                      <h3 class="text-base font-semibold text-[#212B32]">{{ site.name }}</h3>
                      <p class="text-xs text-[#4C6272]">{{ site.city }} · {{ site.postcode }}</p>
                      <p class="mt-2 text-sm text-[#4C6272]">{{ site.description }}</p>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>
        }

        <!-- TAB 5: ACCESSIBILITY NEEDS -->
        @if (activeTab() === 'accessibility') {
          <div class="max-w-2xl rounded-lg border border-[#D8DDE0] bg-white p-6">
            <h2 class="text-xl font-semibold text-[#212B32]">Communication &amp; accessibility needs</h2>
            <p class="mt-1 text-sm text-[#4C6272]">
              Tell us how we should contact you and what support you require when attending hospital clinics.
            </p>

            <form [formGroup]="prefsForm" (ngSubmit)="savePreferences()" class="mt-5 space-y-4">
              <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label for="pt-pref-channel" class="block text-xs font-semibold text-[#212B32]">Preferred contact method</label>
                  <select
                    id="pt-pref-channel"
                    formControlName="preferred_channel"
                    class="mt-1 w-full rounded border border-[#D8DDE0] bg-white px-3 py-2 text-sm"
                  >
                    <option value="Portal">Patient Portal</option>
                    <option value="Email">Email</option>
                    <option value="SMS">SMS text message</option>
                    <option value="Letter">Posted letter</option>
                  </select>
                </div>

                <div>
                  <label for="pt-pref-lang" class="block text-xs font-semibold text-[#212B32]">Preferred language</label>
                  <select
                    id="pt-pref-lang"
                    formControlName="preferred_language"
                    class="mt-1 w-full rounded border border-[#D8DDE0] bg-white px-3 py-2 text-sm"
                  >
                    <option value="English">English</option>
                    <option value="Sylheti">Sylheti</option>
                    <option value="Urdu">Urdu</option>
                    <option value="Polish">Polish</option>
                    <option value="British Sign Language">British Sign Language (BSL)</option>
                  </select>
                </div>
              </div>

              <label class="flex items-center gap-2 text-sm text-[#212B32]">
                <input type="checkbox" formControlName="interpreter_required" class="h-4 w-4 rounded" />
                I require an interpreter for appointments and clinical discussions
              </label>

              <div>
                <p class="text-xs font-semibold text-[#212B32]">Additional adjustments</p>
                <div class="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  @for (opt of accessibilityOptions; track opt) {
                    <label class="flex items-center gap-2 rounded border border-[#D8DDE0] p-2.5 text-sm">
                      <input
                        type="checkbox"
                        [checked]="selectedAccessibility().includes(opt)"
                        (change)="toggleAccessibilityOption(opt, $any($event.target).checked)"
                        class="h-4 w-4 rounded"
                      />
                      <span>{{ opt }}</span>
                    </label>
                  }
                </div>
              </div>

              <button
                type="submit"
                class="inline-flex items-center gap-2 rounded bg-[#005EB8] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#003087]"
              >
                <mat-icon class="text-[18px]">save</mat-icon>
                Save communication preferences
              </button>
            </form>
          </div>
        }

        <!-- TAB 6: ACCOUNT & PROXY -->
        @if (activeTab() === 'account' && patient(); as p) {
          <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div class="rounded-lg border border-[#D8DDE0] bg-white p-6">
              <h2 class="text-xl font-semibold text-[#212B32]">Identity &amp; contact record</h2>
              <p class="mt-1 text-xs text-[#4C6272]">
                Authoritative demographics originate from the Trust Patient Administration System (PAS). An NHS number alone is never used as authentication.
              </p>

              <dl class="mt-4 divide-y divide-[#E5E7EB] text-sm">
                <div class="flex justify-between py-2.5">
                  <dt class="text-[#4C6272]">Full name</dt>
                  <dd class="font-semibold text-[#212B32]">{{ p.given_name }} {{ p.family_name }}</dd>
                </div>
                <div class="flex justify-between py-2.5">
                  <dt class="text-[#4C6272]">Internal patient ID</dt>
                  <dd class="font-mono text-[#212B32]">{{ p.internal_id }}</dd>
                </div>
                <div class="flex justify-between py-2.5">
                  <dt class="text-[#4C6272]">NHS number</dt>
                  <dd class="flex items-center gap-2 font-mono text-[#212B32]">
                    {{ p.nhs_number || 'Not recorded' }}
                    <span class="rounded border px-1.5 py-0.5 font-sans text-xs font-semibold" [class]="toneClass(p.nhs_verification_status)">
                      {{ p.nhs_verification_status }}
                    </span>
                  </dd>
                </div>
                <div class="flex justify-between py-2.5">
                  <dt class="text-[#4C6272]">Date of birth</dt>
                  <dd class="tabular-nums">{{ formatDate(p.date_of_birth) }}</dd>
                </div>
                <div class="flex justify-between py-2.5">
                  <dt class="text-[#4C6272]">Telephone</dt>
                  <dd class="tabular-nums">{{ p.phone }}</dd>
                </div>
                <div class="flex justify-between py-2.5">
                  <dt class="text-[#4C6272]">Address</dt>
                  <dd class="text-right">{{ p.address }}</dd>
                </div>
              </dl>
            </div>

            <div class="rounded-lg border border-[#D8DDE0] bg-white p-6">
              <h2 class="text-xl font-semibold text-[#212B32]">Nominated proxy relationships</h2>
              <p class="mt-1 text-xs text-[#4C6272]">
                Proxies can only act within their verified scope after identity confirmation by hospital staff.
              </p>

              <div class="mt-4 divide-y divide-[#E5E7EB]">
                @for (prx of proxies(); track prx.id) {
                  <div class="flex items-center justify-between py-3">
                    <div>
                      <p class="text-sm font-semibold text-[#212B32]">{{ prx.proxy_name }}</p>
                      <p class="text-xs text-[#4C6272]">{{ prx.relationship_type }} · Scope: {{ prx.scope }}</p>
                    </div>
                    <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(prx.verified_status)">
                      {{ prx.verified_status }}
                    </span>
                  </div>
                } @empty {
                  <p class="py-3 text-sm text-[#4C6272]">No proxy relationships recorded.</p>
                }
              </div>
            </div>
          </div>
        }
      }
    </div>
  `,
})
export class PatientPortal implements OnInit, OnDestroy {
  readonly api = inject(ApiService);
  private fb = inject(FormBuilder);

  readonly activeTab = input<PatientTab>('appointments');
  readonly tabChange = output<PatientTab>();
  readonly requestSwitchPersona = output<void>();

  readonly loading = signal(true);
  readonly accessBlockedError = signal<string | null>(null);
  readonly patient = signal<PatientRecord | null>(null);
  readonly proxies = signal<{id: string; proxy_name: string; relationship_type: string; scope: string; verified_status: string}[]>([]);
  readonly appointments = signal<Appointment[]>([]);
  readonly referrals = signal<Referral[]>([]);
  readonly messages = signal<CommunicationRecord[]>([]);
  readonly eligibleSlots = signal<AppointmentSlot[]>([]);
  readonly ineligibleSlots = signal<AppointmentSlot[]>([]);
  readonly heldSlot = signal<{slotId: string; heldUntilIso: string} | null>(null);
  readonly shortNoticeOptIn = signal(false);
  readonly reschedulingAppt = signal<Appointment | null>(null);
  readonly selectedAccessibility = signal<string[]>([]);
  readonly feedback = signal<{tone: 'success' | 'warning' | 'error'; title: string; detail: string} | null>(null);

  readonly accessibilityOptions = [
    'Large print letters (18pt)',
    'Step-free ground floor room',
    'Hearing loop',
    'Easy read format',
  ];

  readonly acceptedReferrals = computed(() =>
    this.referrals().filter((r) => r.status === 'Accepted'),
  );

  readonly slotFilterForm = this.fb.group({
    referralId: [''],
    preferredSiteId: [''],
    timeOfDay: [''],
  });

  readonly prefsForm = this.fb.group({
    preferred_channel: ['Portal', Validators.required],
    preferred_language: ['English', Validators.required],
    interpreter_required: [false],
  });

  private unsubSse: (() => void) | null = null;

  ngOnInit(): void {
    void this.refreshAll();
    this.unsubSse = this.api.onLiveUpdate(() => {
      void this.refreshAll(true);
    });
  }

  ngOnDestroy(): void {
    this.unsubSse?.();
  }

  async refreshAll(silent = false): Promise<void> {
    if (!silent) this.loading.set(true);
    this.accessBlockedError.set(null);
    try {
      const targetPatientId = this.api.session()?.user.patient_id;
      if (!targetPatientId) {
        this.accessBlockedError.set('No linked patient record found for this portal account.');
        return;
      }

      const [detail, appts, refs, comms] = await Promise.all([
        this.api.getPatientDetail(targetPatientId),
        this.api.getAppointments(),
        this.api.getReferrals(),
        this.api.getCommunications(),
      ]);

      this.patient.set(detail);
      this.proxies.set(detail.proxies);
      this.appointments.set(appts);
      this.referrals.set(refs);
      this.messages.set(comms);
      this.selectedAccessibility.set(detail.accessibility_needs);
      this.prefsForm.patchValue({
        preferred_channel: detail.preferred_channel,
        preferred_language: detail.preferred_language,
        interpreter_required: detail.interpreter_required,
      });

      const firstAccepted = refs.find((r) => r.status === 'Accepted');
      if (firstAccepted && !this.slotFilterForm.value.referralId) {
        this.slotFilterForm.patchValue({referralId: firstAccepted.id});
      }
      if (this.slotFilterForm.value.referralId) {
        await this.loadEligibleSlots();
      }
    } catch (err) {
      this.accessBlockedError.set(extractErrorMessage(err));
    } finally {
      this.loading.set(false);
    }
  }

  async loadEligibleSlots(): Promise<void> {
    const refId = this.slotFilterForm.value.referralId;
    if (!refId) {
      this.eligibleSlots.set([]);
      this.ineligibleSlots.set([]);
      return;
    }
    try {
      const res = await this.api.getEligibleSlots(
        refId,
        this.slotFilterForm.value.preferredSiteId || null,
        this.slotFilterForm.value.timeOfDay || null,
      );
      this.eligibleSlots.set(res.eligible);
      this.ineligibleSlots.set(res.ineligible);
    } catch (err) {
      this.feedback.set({
        tone: 'error',
        title: 'Unable to load slots',
        detail: extractErrorMessage(err),
      });
    }
  }

  selectReferralAndBook(referralId: string): void {
    this.slotFilterForm.patchValue({referralId});
    this.tabChange.emit('book');
    void this.loadEligibleSlots();
  }

  startReschedule(appt: Appointment): void {
    this.reschedulingAppt.set(appt);
    if (appt.referral_id) {
      this.slotFilterForm.patchValue({referralId: appt.referral_id});
    }
    this.tabChange.emit('book');
    void this.loadEligibleSlots();
  }

  async holdSlotForSelection(slotId: string): Promise<void> {
    try {
      const res = await this.api.holdSlot(slotId, {ttlSeconds: 300});
      this.heldSlot.set(res);
      this.feedback.set({
        tone: 'success',
        title: 'Slot held for 5 minutes',
        detail: `Slot ${slotId} is locked for your session. Click Confirm booking to complete reservation.`,
      });
      await this.loadEligibleSlots();
    } catch (err) {
      this.feedback.set({
        tone: 'error',
        title: 'Could not hold slot',
        detail: extractErrorMessage(err),
      });
    }
  }

  async testCompetingHold(slotId: string): Promise<void> {
    try {
      await this.api.holdSlot(slotId, {simulateCompetingUserId: 'USR-COMPETING-PATIENT'});
      this.feedback.set({
        tone: 'warning',
        title: 'Competing hold unexpectedly succeeded',
        detail: 'Check slot lock status.',
      });
    } catch (err) {
      this.feedback.set({
        tone: 'success',
        title: 'Concurrency lock verified (HTTP 409 Conflict)',
        detail: `Competing user blocked cleanly: ${extractErrorMessage(err)}`,
      });
    }
  }

  async confirmHeldSlot(slot: AppointmentSlot): Promise<void> {
    const refId = this.slotFilterForm.value.referralId;
    if (!refId) return;
    try {
      if (this.reschedulingAppt()) {
        await this.api.rescheduleAppointment(this.reschedulingAppt()!.id, {
          newSlotId: slot.id,
          reason: 'Patient requested alternative date/time via portal',
        });
        this.reschedulingAppt.set(null);
        this.feedback.set({
          tone: 'success',
          title: 'Appointment rescheduled',
          detail: 'Your new booking is confirmed and linked to the previous appointment history.',
        });
      } else {
        await this.api.bookAppointment({
          slot_id: slot.id,
          referral_id: refId,
          short_notice_opt_in: this.shortNoticeOptIn(),
        });
        this.feedback.set({
          tone: 'success',
          title: 'Appointment confirmed',
          detail: `Booked for ${this.formatDateTime(slot.start_iso)} at ${slot.site_name}. Confirmation message sent.`,
        });
      }
      this.heldSlot.set(null);
      await this.refreshAll();
      await this.api.loadBootstrap();
      this.tabChange.emit('appointments');
    } catch (err) {
      this.feedback.set({
        tone: 'error',
        title: 'Booking failed',
        detail: extractErrorMessage(err),
      });
    }
  }

  async confirmAttendance(apptId: string): Promise<void> {
    try {
      await this.api.transitionAppointment(apptId, {targetStatus: 'Confirmed'});
      this.feedback.set({
        tone: 'success',
        title: 'Attendance confirmed',
        detail: 'Thank you for confirming your attendance.',
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Action failed', detail: extractErrorMessage(err)});
    }
  }

  async cancelAppointment(apptId: string): Promise<void> {
    try {
      await this.api.transitionAppointment(apptId, {
        targetStatus: 'Cancelled by patient',
        reason: 'Patient cancelled via self-service portal',
      });
      this.feedback.set({
        tone: 'warning',
        title: 'Appointment cancelled',
        detail: 'Your booking is cancelled, and your referral remains active on the waiting list with your original start date preserved.',
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Cancel failed', detail: extractErrorMessage(err)});
    }
  }

  async requestStaffBookingHelp(): Promise<void> {
    const p = this.patient();
    if (!p) return;
    try {
      await this.api.sendCommunication({
        patient_id: p.internal_id,
        channel: 'Portal',
        message_type: 'General',
        subject: 'Staff-assisted telephone booking requested',
        body: `${p.given_name} ${p.family_name} requested telephone assistance from the booking team to arrange an appointment.`,
        lock_screen_safe_preview: 'Pennine University Hospital: Callback request logged.',
      });
      this.feedback.set({
        tone: 'success',
        title: 'Booking team callback requested',
        detail: 'Our booking coordinators have received your request and will telephone you on ' + p.phone + '.',
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Request failed', detail: extractErrorMessage(err)});
    }
  }

  async markRead(msgId: string): Promise<void> {
    await this.api.markCommunicationRead(msgId);
    await this.refreshAll(true);
  }

  toggleAccessibilityOption(option: string, checked: boolean): void {
    this.selectedAccessibility.update((list) =>
      checked ? [...new Set([...list, option])] : list.filter((x) => x !== option),
    );
  }

  async savePreferences(): Promise<void> {
    const p = this.patient();
    if (!p) return;
    try {
      await this.api.updatePatientPreferences(p.internal_id, {
        ...this.prefsForm.value,
        accessibility_needs: this.selectedAccessibility(),
      });
      this.feedback.set({
        tone: 'success',
        title: 'Preferences saved',
        detail: 'Your communication and accessibility requirements have been updated.',
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Save failed', detail: extractErrorMessage(err)});
    }
  }

  formatDateTime = formatLondonDateTime;
  formatDate = formatLondonDate;
  formatTime = formatLondonTime;
  toneClass = statusToneClass;
}
