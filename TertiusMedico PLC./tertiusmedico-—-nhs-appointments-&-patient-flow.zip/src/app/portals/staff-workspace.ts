import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {
  Appointment,
  AuditEntry,
  Bed,
  ClinicSession,
  ClinicTemplate,
  CommunicationRecord,
  IntegrationEvent,
  OperationalReport,
  PatientRecord,
  PlannedAdmission,
  Referral,
  StaffRotaEntry,
  WaitingListEntry,
  Ward,
  WorkTask,
} from '../../shared/types';
import {ApiService} from '../services/api';
import {
  daysSince,
  extractErrorMessage,
  formatLondonDate,
  formatLondonDateTime,
  formatLondonTime,
  statusToneClass,
} from '../services/format';

export type StaffSection =
  | 'overview'
  | 'referrals'
  | 'waiting-lists'
  | 'appointments'
  | 'clinics'
  | 'inpatients'
  | 'beds'
  | 'rotas'
  | 'communications'
  | 'reports'
  | 'administration';

@Component({
  selector: 'app-staff-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="mx-auto flex min-h-[calc(100vh-110px)] max-w-[1440px]">
      <!-- Left Sidebar Navigation (260px) -->
      <aside class="hidden w-[250px] shrink-0 border-r border-[#D8DDE0] bg-white p-4 lg:block">
        <p class="px-3 text-xs font-semibold text-[#4C6272]">Staff Workspace</p>
        <nav class="mt-3 space-y-1" aria-label="Staff workspace sections">
          @for (item of navItems; track item.id) {
            <button
              type="button"
              (click)="selectSection(item.id)"
              class="flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-left text-sm font-medium transition-colors whitespace-nowrap"
              [class]="
                activeSection() === item.id
                  ? 'bg-[#E8F1FA] text-[#003087] font-semibold'
                  : 'text-[#212B32] hover:bg-[#F0F4F5]'
              "
            >
              <mat-icon class="text-[18px] shrink-0">{{ item.icon }}</mat-icon>
              <span class="truncate">{{ item.label }}</span>
            </button>
          }
        </nav>
      </aside>

      <!-- Main Staff Viewport -->
      <main class="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">
        <!-- Mobile Section Selector -->
        <div class="mb-4 lg:hidden">
          <label for="staff-mobile-section" class="block text-xs font-semibold text-[#4C6272]">Workspace section</label>
          <select
            id="staff-mobile-section"
            [value]="activeSection()"
            (change)="selectSection($any($event.target).value)"
            class="mt-1 w-full rounded border border-[#D8DDE0] bg-white px-3 py-2 text-sm font-medium"
          >
            @for (item of navItems; track item.id) {
              <option [value]="item.id">{{ item.label }}</option>
            }
          </select>
        </div>

        <!-- Prominent Selected Patient Identity Banner -->
        @if (selectedPatient(); as sp) {
          <div class="mb-5 flex flex-col justify-between gap-3 rounded-lg border border-[#005EB8] bg-[#E8F1FA] px-4 py-3 sm:flex-row sm:items-center">
            <div class="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
              <span class="font-semibold text-[#003087]">Active Patient Record:</span>
              <strong class="text-[#212B32]">{{ sp.given_name }} {{ sp.family_name }}</strong>
              <span aria-hidden="true" class="text-[#4C6272]">·</span>
              <span class="font-mono text-xs text-[#212B32] tabular-nums">
                NHS: {{ sp.nhs_number || 'Not supplied' }} ({{ sp.nhs_verification_status }})
              </span>
              <span aria-hidden="true" class="text-[#4C6272]">·</span>
              <span class="text-xs text-[#212B32] tabular-nums">DOB: {{ formatDate(sp.date_of_birth) }}</span>
              <span aria-hidden="true" class="text-[#4C6272]">·</span>
              <span class="font-mono text-xs text-[#4C6272]">ID: {{ sp.internal_id }}</span>
              @if (sp.interpreter_required) {
                <span class="rounded border border-[#FDE68A] bg-[#FFFBEB] px-2 py-0.5 text-xs font-semibold text-[#B45309]">
                  {{ sp.preferred_language }} interpreter
                </span>
              }
            </div>
            <button
              type="button"
              (click)="clearSelectedPatient()"
              class="shrink-0 text-xs font-semibold text-[#003087] underline"
            >
              Clear selection
            </button>
          </div>
        }

        <!-- Consequential Record Switch Guard -->
        @if (pendingPatientSwitch()) {
          <div class="mb-5 rounded-lg border border-[#FDE68A] bg-[#FFFBEB] p-4 text-sm text-[#92400E]">
            <p class="font-semibold">Confirm patient record change before proceeding</p>
            <p class="mt-1">
              You have an active action open for <strong>{{ selectedPatient()?.given_name }} {{ selectedPatient()?.family_name }}</strong>. Switch active patient context to
              <strong>{{ pendingPatientSwitch()!.given_name }} {{ pendingPatientSwitch()!.family_name }}</strong> (NHS {{ pendingPatientSwitch()!.nhs_number }})?
            </p>
            <div class="mt-3 flex gap-2">
              <button
                type="button"
                (click)="confirmPatientSwitch()"
                class="rounded bg-[#B45309] px-3 py-1.5 text-xs font-semibold text-white"
              >
                Confirm switch patient
              </button>
              <button
                type="button"
                (click)="pendingPatientSwitch.set(null)"
                class="rounded border border-[#D8DDE0] bg-white px-3 py-1.5 text-xs font-semibold text-[#212B32]"
              >
                Keep current patient
              </button>
            </div>
          </div>
        }

        <!-- Feedback Banner -->
        @if (feedback()) {
          <div
            class="mb-5 flex items-start justify-between gap-4 rounded-lg border p-4"
            [class]="
              feedback()!.tone === 'error'
                ? 'border-[#FECACA] bg-[#FEF2F2] text-[#991B1B]'
                : feedback()!.tone === 'warning'
                  ? 'border-[#FDE68A] bg-[#FFFBEB] text-[#92400E]'
                  : 'border-[#A7F3D0] bg-[#ECFDF5] text-[#065F46]'
            "
            role="status"
          >
            <div class="flex items-start gap-3">
              <mat-icon class="mt-0.5 shrink-0 text-[20px]">
                {{
                  feedback()!.tone === 'error'
                    ? 'error_outline'
                    : feedback()!.tone === 'warning'
                      ? 'warning_amber'
                      : 'check_circle'
                }}
              </mat-icon>
              <div>
                <p class="text-sm font-semibold">{{ feedback()!.title }}</p>
                <p class="mt-0.5 text-sm">{{ feedback()!.detail }}</p>
              </div>
            </div>
            <button type="button" (click)="feedback.set(null)" class="rounded p-1 hover:bg-black/5">
              <mat-icon class="text-[18px]">close</mat-icon>
            </button>
          </div>
        }

        <!-- 1. OVERVIEW -->
        @if (activeSection() === 'overview') {
          <div class="space-y-6">
            <div class="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
              <div>
                <h1 class="text-2xl font-bold text-[#212B32]">Operational overview</h1>
                <p class="mt-1 text-sm text-[#4C6272]">
                  Pennine University Hospital Demonstrator · St Aidan's General Hospital &amp; Calder Valley Royal Infirmary
                </p>
              </div>
              <button
                type="button"
                (click)="refreshAll()"
                class="inline-flex items-center gap-1.5 rounded border border-[#D8DDE0] bg-white px-3 py-2 text-xs font-semibold text-[#212B32] hover:bg-[#F0F4F5] whitespace-nowrap shrink-0"
              >
                <mat-icon class="text-[16px]">refresh</mat-icon>
                Refresh operational state
              </button>
            </div>

            <!-- KPI Strip -->
            @if (report(); as rep) {
              <div class="grid grid-cols-2 gap-4 md:grid-cols-4">
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-4">
                  <p class="text-xs font-medium text-[#4C6272]">Referrals awaiting review</p>
                  <p class="mt-1 text-2xl font-bold text-[#212B32] tabular-nums">{{ rep.referral_workload.received_or_awaiting }}</p>
                  <p class="mt-1 text-xs text-[#4C6272] tabular-nums">{{ rep.referral_workload.accepted }} accepted</p>
                </div>
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-4">
                  <p class="text-xs font-medium text-[#4C6272]">Active waiting list</p>
                  <p class="mt-1 text-2xl font-bold text-[#212B32] tabular-nums">{{ rep.waiting_list.active_count }}</p>
                  <p class="mt-1 text-xs text-[#4C6272] tabular-nums">{{ rep.waiting_list.urgent_count }} urgent · {{ rep.waiting_list.soon_count }} soon</p>
                </div>
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-4">
                  <p class="text-xs font-medium text-[#4C6272]">Ward 4B bed occupancy</p>
                  <p class="mt-1 text-2xl font-bold text-[#212B32] tabular-nums">{{ rep.inpatients_and_beds.bed_occupancy_pct }}%</p>
                  <p class="mt-1 text-xs text-[#B91C1C] tabular-nums">{{ rep.inpatients_and_beds.closed_or_restricted_beds }} closed/IPC · {{ rep.inpatients_and_beds.available_beds }} free</p>
                </div>
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-4">
                  <p class="text-xs font-medium text-[#4C6272]">Open back-office tasks</p>
                  <p class="mt-1 text-2xl font-bold text-[#212B32] tabular-nums">{{ rep.open_work_tasks }}</p>
                  <p class="mt-1 text-xs text-[#B91C1C] tabular-nums">{{ rep.communications.failed_count }} failed comms</p>
                </div>
              </div>
            }

            <!-- 15-Step Pennine Demonstrator Checklist + Work Queues -->
            <div class="grid grid-cols-1 gap-6 xl:grid-cols-12">
              <!-- Work Queues (with Batch preview/execute) -->
              <section class="rounded-lg border border-[#D8DDE0] bg-white p-5 xl:col-span-7">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 class="text-lg font-semibold text-[#212B32]">Back-office work queues</h2>
                    <p class="text-xs text-[#4C6272]">
                      Acknowledging a task is tracked separately from resolving the underlying issue.
                    </p>
                  </div>
                  @if (selectedTaskIds().length > 0) {
                    <div class="flex items-center gap-2">
                      <button
                        type="button"
                        (click)="runBatchTasks(true)"
                        class="rounded border border-[#D8DDE0] bg-white px-2.5 py-1.5 text-xs font-semibold text-[#212B32] hover:bg-[#F0F4F5]"
                      >
                        Preview batch ({{ selectedTaskIds().length }})
                      </button>
                      <button
                        type="button"
                        (click)="runBatchTasks(false)"
                        class="rounded bg-[#005EB8] px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-[#003087]"
                      >
                        Acknowledge selected
                      </button>
                    </div>
                  }
                </div>

                @if (batchPreviewResults()) {
                  <div class="mt-3 rounded border border-[#BFDBFE] bg-[#E8F1FA] p-3 text-xs text-[#003087]">
                    <strong>Batch preview:</strong>
                    @for (r of batchPreviewResults()!; track r.id) {
                      <span class="mr-2 font-mono">{{ r.id }}: {{ r.outcome }};</span>
                    }
                  </div>
                }

                <div class="mt-4 divide-y divide-[#E5E7EB]">
                  @for (task of workTasks(); track task.id) {
                    <div class="flex items-start justify-between gap-3 py-3">
                      <div class="flex items-start gap-2.5">
                        <input
                          type="checkbox"
                          [checked]="selectedTaskIds().includes(task.id)"
                          (change)="toggleTaskSelection(task.id, $any($event.target).checked)"
                          class="mt-1 h-4 w-4 rounded"
                          [attr.aria-label]="'Select task ' + task.title"
                        />
                        <div>
                          <div class="flex flex-wrap items-center gap-2">
                            <span class="rounded border px-1.5 py-0.5 text-[11px] font-semibold" [class]="toneClass(task.status)">
                              {{ task.status }}
                            </span>
                            <span class="text-xs font-semibold text-[#003087]">{{ task.queue_type }}</span>
                            <span aria-hidden="true" class="text-[#4C6272]">·</span>
                            <span class="text-xs text-[#4C6272]">{{ task.priority_source }}</span>
                          </div>
                          <p class="mt-1 text-sm font-semibold text-[#212B32]">{{ task.title }}</p>
                          <p class="text-xs text-[#4C6272]">{{ task.description }}</p>
                          @if (task.resolution_note) {
                            <p class="mt-1 text-xs font-medium text-[#007F3B]">Resolution: {{ task.resolution_note }}</p>
                          }
                        </div>
                      </div>

                      <div class="flex shrink-0 gap-1.5">
                        @if (task.status === 'Open') {
                          <button
                            type="button"
                            (click)="updateTaskStatus(task.id, 'Acknowledged')"
                            class="rounded border border-[#D8DDE0] bg-white px-2.5 py-1 text-xs font-medium hover:bg-[#F0F4F5] whitespace-nowrap"
                          >
                            Acknowledge
                          </button>
                        }
                        @if (task.status !== 'Resolved') {
                          <button
                            type="button"
                            (click)="updateTaskStatus(task.id, 'Resolved')"
                            class="rounded border border-[#A7F3D0] bg-[#ECFDF5] px-2.5 py-1 text-xs font-semibold text-[#007F3B] hover:bg-[#D1FAE5] whitespace-nowrap"
                          >
                            Resolve
                          </button>
                        }
                      </div>
                    </div>
                  }
                </div>
              </section>

              <!-- 15-Step Demonstrator Walkthrough -->
              <section class="rounded-lg border border-[#D8DDE0] bg-white p-5 xl:col-span-5">
                <h2 class="text-lg font-semibold text-[#212B32]">15-step demonstrator workflow</h2>
                <p class="text-xs text-[#4C6272]">
                  Live database state across Pennine University Hospital workflows.
                </p>

                <ol class="mt-4 space-y-2">
                  @for (item of api.checklist(); track item.step) {
                    <li class="flex items-start justify-between gap-2 rounded border border-[#E5E7EB] p-2.5 text-xs">
                      <div class="flex items-start gap-2">
                        <mat-icon
                          class="text-[16px] shrink-0 mt-0.5"
                          [class]="item.completed ? 'text-[#007F3B]' : 'text-[#4C6272]'"
                        >
                          {{ item.completed ? 'check_circle' : 'radio_button_unchecked' }}
                        </mat-icon>
                        <div>
                          <p class="font-semibold text-[#212B32]">{{ item.step }}. {{ item.title }}</p>
                          <p class="text-[#4C6272]">{{ item.description }}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        (click)="jumpToChecklistTarget(item.target_view)"
                        class="shrink-0 font-semibold text-[#005EB8] hover:underline"
                      >
                        Open
                      </button>
                    </li>
                  }
                </ol>
              </section>
            </div>
          </div>
        }

        <!-- 2. REFERRALS -->
        @if (activeSection() === 'referrals') {
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h1 class="text-2xl font-bold text-[#212B32]">Referrals &amp; clinical triage</h1>
                <p class="mt-1 text-sm text-[#4C6272]">
                  Only authorised clinicians may assign clinical priority or complete clinical review.
                </p>
              </div>
              <button
                type="button"
                (click)="showNewReferralForm.set(!showNewReferralForm())"
                class="inline-flex items-center gap-1.5 rounded bg-[#005EB8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#003087]"
              >
                <mat-icon class="text-[16px]">add</mat-icon>
                Record new referral
              </button>
            </div>

            @if (showNewReferralForm()) {
              <form
                [formGroup]="newReferralForm"
                (ngSubmit)="submitNewReferral()"
                class="rounded-lg border border-[#D8DDE0] bg-white p-5 space-y-4"
              >
                <h2 class="text-base font-semibold text-[#212B32]">New synthetic referral intake</h2>
                <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label for="nr-patient" class="block text-xs font-semibold">Patient</label>
                    <select id="nr-patient" formControlName="patient_id" class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm">
                      @for (p of patients(); track p.internal_id) {
                        <option [value]="p.internal_id">{{ p.given_name }} {{ p.family_name }} ({{ p.internal_id }})</option>
                      }
                    </select>
                  </div>
                  <div>
                    <label for="nr-specialty" class="block text-xs font-semibold">Specialty</label>
                    <select id="nr-specialty" formControlName="specialty" class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm">
                      <option value="Cardiology">Cardiology</option>
                      <option value="Respiratory Medicine">Respiratory Medicine</option>
                      <option value="Orthopaedics">Orthopaedics</option>
                    </select>
                  </div>
                  <div>
                    <label for="nr-format" class="block text-xs font-semibold">Required format</label>
                    <select id="nr-format" formControlName="required_format" class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm">
                      <option value="In-person">In-person</option>
                      <option value="Telephone">Telephone</option>
                      <option value="Video">Video</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label for="nr-reqs" class="block text-xs font-semibold">Clinical appointment requirements</label>
                  <input
                    id="nr-reqs"
                    type="text"
                    formControlName="appointment_requirements"
                    class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm"
                  />
                </div>
                <div class="flex gap-2">
                  <button type="submit" class="rounded bg-[#005EB8] px-4 py-2 text-xs font-semibold text-white">
                    Create referral
                  </button>
                  <button type="button" (click)="showNewReferralForm.set(false)" class="rounded border border-[#D8DDE0] px-4 py-2 text-xs">
                    Cancel
                  </button>
                </div>
              </form>
            }

            <div class="overflow-x-auto rounded-lg border border-[#D8DDE0] bg-white">
              <table class="w-full text-left text-sm">
                <thead class="border-b border-[#D8DDE0] bg-[#F8FAFB] text-xs font-semibold text-[#4C6272]">
                  <tr>
                    <th class="px-4 py-3">Referral &amp; Patient</th>
                    <th class="px-4 py-3">Specialty &amp; Source</th>
                    <th class="px-4 py-3">Received</th>
                    <th class="px-4 py-3">Review Status &amp; Priority</th>
                    <th class="px-4 py-3">Requirements</th>
                    <th class="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#E5E7EB]">
                  @for (ref of referrals(); track ref.id) {
                    <tr class="hover:bg-[#F8FAFB]">
                      <td class="px-4 py-3">
                        <button
                          type="button"
                          (click)="selectPatientById(ref.patient_id)"
                          class="font-semibold text-[#005EB8] hover:underline text-left"
                        >
                          {{ ref.patient_name }}
                        </button>
                        <p class="font-mono text-xs text-[#4C6272]">{{ ref.id }} · {{ ref.patient_nhs }}</p>
                      </td>
                      <td class="px-4 py-3">
                        <p class="font-medium text-[#212B32]">{{ ref.specialty }}</p>
                        <p class="text-xs text-[#4C6272]">{{ ref.referral_source }}</p>
                      </td>
                      <td class="px-4 py-3 text-xs text-[#4C6272] tabular-nums">
                        {{ formatDate(ref.received_at) }}
                      </td>
                      <td class="px-4 py-3">
                        <div class="flex flex-wrap items-center gap-1.5">
                          <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(ref.status)">
                            {{ ref.status }}
                          </span>
                          @if (ref.clinical_priority) {
                            <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(ref.clinical_priority)">
                              {{ ref.clinical_priority }}
                            </span>
                          }
                        </div>
                      </td>
                      <td class="px-4 py-3 text-xs text-[#4C6272]">
                        {{ ref.required_format }} · {{ ref.required_duration_mins }}m
                        @if (ref.interpreter_language) {
                          <span class="block font-medium text-[#B45309]">Interpreter: {{ ref.interpreter_language }}</span>
                        }
                      </td>
                      <td class="px-4 py-3 text-right">
                        <button
                          type="button"
                          (click)="openReviewModal(ref)"
                          class="inline-flex items-center gap-1 rounded border border-[#005EB8] bg-white px-3 py-1.5 text-xs font-semibold text-[#005EB8] hover:bg-[#E8F1FA] whitespace-nowrap"
                        >
                          <mat-icon class="text-[15px]">rate_review</mat-icon>
                          Review
                        </button>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>

            <!-- Clinical Review Drawer -->
            @if (reviewingReferral(); as rr) {
              <div class="rounded-lg border border-[#005EB8] bg-white p-6">
                <div class="flex items-start justify-between">
                  <div>
                    <h2 class="text-lg font-semibold text-[#212B32]">
                      Clinical review: {{ rr.patient_name }} ({{ rr.id }})
                    </h2>
                    <p class="text-xs text-[#4C6272]">
                      {{ rr.specialty }} — {{ rr.appointment_requirements }}
                    </p>
                  </div>
                  <button type="button" (click)="reviewingReferral.set(null)" class="text-xs underline">Close</button>
                </div>

                <form [formGroup]="reviewForm" (ngSubmit)="submitClinicalReview()" class="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label for="rv-status" class="block text-xs font-semibold">Review decision</label>
                    <select id="rv-status" formControlName="status" class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm">
                      <option value="Accepted">Accepted (add to waiting list)</option>
                      <option value="Further information required">Further information required</option>
                      <option value="Redirected">Redirected</option>
                      <option value="Declined">Declined</option>
                    </select>
                  </div>
                  <div>
                    <label for="rv-priority" class="block text-xs font-semibold">Clinical priority (clinician only)</label>
                    <select id="rv-priority" formControlName="clinical_priority" class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm">
                      <option value="Urgent">Urgent</option>
                      <option value="Soon">Soon</option>
                      <option value="Routine">Routine</option>
                    </select>
                  </div>
                  <div>
                    <label for="rv-window" class="block text-xs font-semibold">Booking window (days)</label>
                    <input id="rv-window" type="number" formControlName="booking_window_days" class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm tabular-nums" />
                  </div>
                  <div class="sm:col-span-3">
                    <label for="rv-notes" class="block text-xs font-semibold">Clinical review notes</label>
                    <input id="rv-notes" type="text" formControlName="review_notes" class="mt-1 w-full rounded border border-[#D8DDE0] px-3 py-2 text-sm" />
                  </div>
                  <div class="sm:col-span-3 flex items-center gap-3">
                    <button
                      type="submit"
                      class="inline-flex items-center gap-1.5 rounded bg-[#005EB8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#003087]"
                    >
                      <mat-icon class="text-[16px]">verified_user</mat-icon>
                      Save clinical review
                    </button>
                    <span class="text-xs text-[#4C6272]">
                      Signed in role: <strong>{{ api.session()?.user?.role }}</strong> (non-clinicians are blocked by server RBAC)
                    </span>
                  </div>
                </form>
              </div>
            }
          </div>
        }

        <!-- 3. WAITING LISTS -->
        @if (activeSection() === 'waiting-lists') {
          <div class="space-y-5">
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Waiting lists</h1>
              <p class="mt-1 text-sm text-[#4C6272]">
                Maintained separately from appointment bookings. Cancelling or rescheduling an appointment never deletes a waiting-list entry or resets the original referral date.
              </p>
            </div>

            <div class="overflow-x-auto rounded-lg border border-[#D8DDE0] bg-white">
              <table class="w-full text-left text-sm">
                <thead class="border-b border-[#D8DDE0] bg-[#F8FAFB] text-xs font-semibold text-[#4C6272]">
                  <tr>
                    <th class="px-4 py-3">Patient</th>
                    <th class="px-4 py-3">Specialty &amp; Service</th>
                    <th class="px-4 py-3">Priority</th>
                    <th class="px-4 py-3">Original Clock Start</th>
                    <th class="px-4 py-3 text-right">Days Waiting</th>
                    <th class="px-4 py-3">List Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#E5E7EB]">
                  @for (wl of waitingList(); track wl.id) {
                    <tr>
                      <td class="px-4 py-3">
                        <button type="button" (click)="selectPatientById(wl.patient_id)" class="font-semibold text-[#005EB8] hover:underline">
                          {{ wl.patient_name }}
                        </button>
                        <p class="font-mono text-xs text-[#4C6272]">{{ wl.id }} · Ref {{ wl.referral_id }}</p>
                      </td>
                      <td class="px-4 py-3">
                        <p class="font-medium">{{ wl.specialty }}</p>
                        <p class="text-xs text-[#4C6272]">{{ wl.service_name }}</p>
                      </td>
                      <td class="px-4 py-3">
                        <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(wl.clinical_priority)">
                          {{ wl.clinical_priority }}
                        </span>
                      </td>
                      <td class="px-4 py-3 text-xs tabular-nums">{{ formatDate(wl.original_rtt_clock_start) }}</td>
                      <td class="px-4 py-3 text-right font-mono font-semibold tabular-nums">{{ waitDays(wl.original_rtt_clock_start) }}d</td>
                      <td class="px-4 py-3">
                        <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(wl.current_status)">
                          {{ wl.current_status }}
                        </span>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }

        <!-- 4. APPOINTMENTS (Staff Worklist + Attendance + Follow-up) -->
        @if (activeSection() === 'appointments') {
          <div class="space-y-6">
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Outpatient appointments &amp; clinic flow</h1>
              <p class="mt-1 text-sm text-[#4C6272]">
                Confirmation, arrival, consultation progress, clinical outcome, and follow-up pathways are tracked distinctly.
              </p>
            </div>

            <div class="space-y-3">
              @for (appt of appointments(); track appt.id) {
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-4">
                  <div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
                    <div>
                      <div class="flex flex-wrap items-center gap-2">
                        <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(appt.status)">
                          {{ appt.status }}
                        </span>
                        <button type="button" (click)="selectPatientById(appt.patient_id)" class="font-semibold text-[#005EB8] hover:underline">
                          {{ appt.patient_name }}
                        </button>
                        <span class="font-mono text-xs text-[#4C6272]">{{ appt.id }}</span>
                      </div>
                      <p class="mt-1 text-sm font-medium text-[#212B32] tabular-nums">
                        {{ formatDateTime(appt.start_iso) }} – {{ formatTime(appt.end_iso) }} · {{ appt.specialty }} ({{ appt.format }})
                      </p>
                      <p class="text-xs text-[#4C6272]">
                        {{ appt.site_name }} · {{ appt.room_name }} · {{ appt.clinician_name }}
                      </p>
                      @if (appt.clinical_outcome) {
                        <p class="mt-1 text-xs font-medium text-[#007F3B]">Outcome: {{ appt.clinical_outcome }}</p>
                      }
                    </div>

                    <div class="flex flex-wrap gap-2">
                      @if (appt.status === 'Booked' || appt.status === 'Confirmed') {
                        <button
                          type="button"
                          (click)="transitionAppt(appt.id, 'Arrived')"
                          class="rounded bg-[#005EB8] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#003087] whitespace-nowrap"
                        >
                          Record arrival
                        </button>
                        <button
                          type="button"
                          (click)="transitionAppt(appt.id, 'Did not attend', 'Patient did not attend')"
                          class="rounded border border-[#FECACA] bg-white px-3 py-1.5 text-xs font-medium text-[#B91C1C] hover:bg-[#FEF2F2] whitespace-nowrap"
                        >
                          Mark DNA
                        </button>
                      }
                      @if (appt.status === 'Arrived') {
                        <button
                          type="button"
                          (click)="transitionAppt(appt.id, 'In progress')"
                          class="rounded bg-[#005EB8] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#003087] whitespace-nowrap"
                        >
                          Start consultation
                        </button>
                      }
                      @if (appt.status === 'In progress') {
                        <button
                          type="button"
                          (click)="transitionAppt(appt.id, 'Completed', undefined, 'Outpatient consultation completed; follow-up advised')"
                          class="rounded bg-[#007F3B] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#00662F] whitespace-nowrap"
                        >
                          Complete with outcome
                        </button>
                      }
                      @if (appt.status === 'Completed') {
                        <button
                          type="button"
                          (click)="createFollowUp(appt)"
                          class="inline-flex items-center gap-1 rounded border border-[#005EB8] bg-white px-3 py-1.5 text-xs font-semibold text-[#005EB8] hover:bg-[#E8F1FA] whitespace-nowrap"
                        >
                          <mat-icon class="text-[15px]">replay</mat-icon>
                          Arrange follow-up
                        </button>
                      }
                    </div>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- 5. CLINICS -->
        @if (activeSection() === 'clinics') {
          <div class="space-y-6">
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Versioned clinic templates &amp; sessions</h1>
              <p class="mt-1 text-sm text-[#4C6272]">
                Template amendments create a new version without silently altering existing bookings. Affected appointments are queued for staff review.
              </p>
            </div>

            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
              @for (tpl of clinicTemplates(); track tpl.id) {
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                  <div class="flex items-start justify-between gap-2">
                    <div>
                      <p class="text-xs font-semibold text-[#005EB8]">{{ tpl.specialty }} · Version {{ tpl.version }}</p>
                      <h2 class="text-base font-semibold text-[#212B32]">{{ tpl.name }}</h2>
                      <p class="text-xs text-[#4C6272]">{{ tpl.site_name }} · {{ tpl.room_name }} · {{ tpl.clinician_name }}</p>
                    </div>
                    <button
                      type="button"
                      (click)="amendTemplate(tpl)"
                      class="rounded border border-[#D8DDE0] bg-white px-2.5 py-1.5 text-xs font-semibold hover:bg-[#F0F4F5] whitespace-nowrap"
                    >
                      Amend template
                    </button>
                  </div>
                  <div class="mt-3 grid grid-cols-2 gap-2 text-xs text-[#4C6272]">
                    <span>Format: <strong class="text-[#212B32]">{{ tpl.format }}</strong></span>
                    <span class="tabular-nums">Slot / buffer: <strong class="text-[#212B32]">{{ tpl.default_duration_mins }}m / {{ tpl.buffer_mins }}m</strong></span>
                    <span>Protected Urgent: <strong class="text-[#212B32]">{{ tpl.protected_capacity_count }}</strong></span>
                    <span>Group / Overbook: <strong class="text-[#212B32]">{{ tpl.group_session_enabled ? 'On' : 'Disabled' }} / {{ tpl.overbooking_enabled ? 'On' : 'Disabled' }}</strong></span>
                  </div>
                </div>
              }
            </div>

            <div class="overflow-x-auto rounded-lg border border-[#D8DDE0] bg-white">
              <table class="w-full text-left text-sm">
                <thead class="border-b border-[#D8DDE0] bg-[#F8FAFB] text-xs font-semibold text-[#4C6272]">
                  <tr>
                    <th class="px-4 py-3">Date &amp; Time</th>
                    <th class="px-4 py-3">Clinic &amp; Site</th>
                    <th class="px-4 py-3">Clinician</th>
                    <th class="px-4 py-3 text-right">Booked / Free</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#E5E7EB]">
                  @for (s of clinicSessions(); track s.id) {
                    <tr>
                      <td class="px-4 py-3 font-mono text-xs tabular-nums">{{ s.session_date }} · {{ s.start_time }}–{{ s.end_time }}</td>
                      <td class="px-4 py-3">
                        <p class="font-medium">{{ s.template_name }} (v{{ s.template_version }})</p>
                        <p class="text-xs text-[#4C6272]">{{ s.site_name }} · {{ s.room_name }}</p>
                      </td>
                      <td class="px-4 py-3 text-sm">{{ s.clinician_name }}</td>
                      <td class="px-4 py-3 text-right font-mono text-xs tabular-nums">{{ s.booked_count }} booked · {{ s.available_count }} free</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }

        <!-- 6. INPATIENTS -->
        @if (activeSection() === 'inpatients') {
          <div class="space-y-6">
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Inpatient planned admissions</h1>
              <p class="mt-1 text-sm text-[#4C6272]">
                Distinguishes planned admission, confirmed booking, actual admission, clinical readiness for discharge, and administrative discharge.
              </p>
            </div>

            @for (adm of admissions(); track adm.id) {
              <div class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                <div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-start">
                  <div class="space-y-2">
                    <div class="flex flex-wrap items-center gap-2">
                      <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(adm.state)">
                        {{ adm.state }}
                      </span>
                      <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(adm.conflict_status)">
                        {{ adm.conflict_status }}
                      </span>
                      <span class="font-mono text-xs text-[#4C6272]">{{ adm.id }}</span>
                    </div>

                    <h2 class="text-lg font-semibold text-[#212B32]">
                      <button type="button" (click)="selectPatientById(adm.patient_id)" class="text-[#005EB8] hover:underline">
                        {{ adm.patient_name }}
                      </button>
                      — {{ adm.specialty }}
                    </h2>

                    <p class="text-sm text-[#4C6272] tabular-nums">
                      Expected admission: <strong class="text-[#212B32]">{{ adm.expected_admission_date }}</strong> · Est. LOS {{ adm.estimated_los_days }} days (Est. discharge {{ adm.estimated_discharge_date }} — estimate only)
                    </p>
                    <p class="text-xs text-[#4C6272]">
                      {{ adm.site_name }} · {{ adm.requested_ward_name }} · Allocated bed: <strong>{{ adm.allocated_bed_label || 'Unassigned' }}</strong>
                    </p>

                    @if (adm.conflict_reason) {
                      <div class="rounded border border-[#FECACA] bg-[#FEF2F2] p-3 text-xs text-[#991B1B]">
                        <strong>Resource / Prerequisite Conflict:</strong> {{ adm.conflict_reason }}
                      </div>
                    }

                    <div class="flex flex-wrap gap-2 pt-1">
                      @for (pr of adm.prerequisites; track pr.label) {
                        <span class="rounded border px-2 py-0.5 text-xs" [class]="pr.completed ? 'border-[#A7F3D0] bg-[#ECFDF5] text-[#007F3B]' : 'border-[#FDE68A] bg-[#FFFBEB] text-[#B45309]'">
                          {{ pr.completed ? 'Done' : 'Pending' }}: {{ pr.label }}
                        </span>
                      }
                    </div>
                  </div>

                  <div class="flex flex-wrap gap-2 shrink-0">
                    @if (adm.conflict_status === 'Conflict Detected') {
                      <button
                        type="button"
                        (click)="resolveAdmissionConflict(adm)"
                        class="inline-flex items-center gap-1.5 rounded bg-[#005EB8] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#003087] whitespace-nowrap"
                      >
                        <mat-icon class="text-[16px]">build</mat-icon>
                        Resolve conflict (assign Bed 4B-07 &amp; clear prereqs)
                      </button>
                    }
                    @if (adm.state === 'Confirmed booking' && adm.conflict_status === 'Clear') {
                      <button
                        type="button"
                        (click)="transitionAdm(adm.id, 'Actual admission')"
                        class="rounded bg-[#007F3B] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#00662F] whitespace-nowrap"
                      >
                        Admit to ward
                      </button>
                    }
                    @if (adm.state === 'Actual admission') {
                      <button
                        type="button"
                        (click)="transitionAdm(adm.id, 'Ready for discharge')"
                        class="rounded border border-[#005EB8] bg-white px-3.5 py-2 text-xs font-semibold text-[#005EB8] whitespace-nowrap"
                      >
                        Mark clinically ready for discharge
                      </button>
                    }
                    @if (adm.state === 'Ready for discharge') {
                      <button
                        type="button"
                        (click)="transitionAdm(adm.id, 'Administrative discharge')"
                        class="rounded bg-[#005EB8] px-3.5 py-2 text-xs font-semibold text-white whitespace-nowrap"
                      >
                        Complete administrative discharge
                      </button>
                    }
                  </div>
                </div>
              </div>
            }
          </div>
        }

        <!-- 7. BEDS -->
        @if (activeSection() === 'beds') {
          <div class="space-y-6">
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Hospital beds &amp; ward coordination</h1>
              @for (w of wards(); track w.id) {
                <p class="mt-1 text-sm text-[#4C6272]">
                  {{ w.name }} ({{ w.site_name }}) · Source: <strong>{{ w.source_system }}</strong> · Last synced: <span class="tabular-nums">{{ formatDateTime(w.last_synced_iso) }}</span>
                </p>
              }
            </div>

            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              @for (bed of beds(); track bed.id) {
                <div class="flex flex-col justify-between rounded-lg border border-[#D8DDE0] bg-white p-4">
                  <div>
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-mono text-base font-bold text-[#212B32]">Bed {{ bed.bed_label }}</span>
                      <span class="rounded border px-2 py-0.5 text-[11px] font-semibold" [class]="toneClass(bed.occupancy_status)">
                        {{ bed.occupancy_status }}
                      </span>
                    </div>
                    <p class="mt-2 text-xs text-[#4C6272]">
                      Capabilities: {{ bed.capabilities.join(', ') }}
                    </p>
                    @if (bed.current_patient_name) {
                      <p class="mt-2 text-xs font-semibold text-[#003087]">Patient: {{ bed.current_patient_name }}</p>
                    }
                    @if (bed.restriction_note) {
                      <p class="mt-2 text-xs text-[#B45309]">{{ bed.restriction_note }}</p>
                    }
                  </div>

                  <div class="mt-4 flex gap-2 border-t border-[#E5E7EB] pt-3">
                    @if (bed.occupancy_status === 'Maintenance Closed' || bed.occupancy_status === 'Cleaning') {
                      <button
                        type="button"
                        (click)="setBedStatus(bed.id, 'Available', null)"
                        class="w-full rounded border border-[#A7F3D0] bg-[#ECFDF5] px-2.5 py-1.5 text-xs font-semibold text-[#007F3B]"
                      >
                        Mark Available
                      </button>
                    } @else if (bed.occupancy_status === 'Available') {
                      <button
                        type="button"
                        (click)="setBedStatus(bed.id, 'Maintenance Closed', 'Estates check in progress')"
                        class="w-full rounded border border-[#FECACA] bg-white px-2.5 py-1.5 text-xs font-medium text-[#B91C1C]"
                      >
                        Close for maintenance
                      </button>
                    }
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- 8. STAFF ROTAS -->
        @if (activeSection() === 'rotas') {
          <div class="space-y-5">
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Clinician &amp; staff rotas</h1>
              <p class="mt-1 text-sm text-[#4C6272]">
                Draft and published rotas are separated. Recording a staff absence creates an affected-work queue for cover or patient contact without silently cancelling appointments.
              </p>
            </div>

            <div class="overflow-x-auto rounded-lg border border-[#D8DDE0] bg-white">
              <table class="w-full text-left text-sm">
                <thead class="border-b border-[#D8DDE0] bg-[#F8FAFB] text-xs font-semibold text-[#4C6272]">
                  <tr>
                    <th class="px-4 py-3">Date &amp; Hours</th>
                    <th class="px-4 py-3">Staff Member</th>
                    <th class="px-4 py-3">Site &amp; Assignment</th>
                    <th class="px-4 py-3">Rota Status</th>
                    <th class="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#E5E7EB]">
                  @for (r of rotas(); track r.id) {
                    <tr>
                      <td class="px-4 py-3 font-mono text-xs tabular-nums">
                        {{ r.rota_date }} · {{ r.start_time }}–{{ r.end_time }}
                        @if (r.travel_buffer_mins > 0) {
                          <span class="block text-[#B45309]">Cross-site travel buffer: {{ r.travel_buffer_mins }}m</span>
                        }
                      </td>
                      <td class="px-4 py-3 font-medium">{{ r.staff_name }}</td>
                      <td class="px-4 py-3">
                        <p>{{ r.site_name }} · <strong>{{ r.assignment_type }}</strong></p>
                        @if (r.note) {
                          <p class="text-xs text-[#4C6272]">{{ r.note }}</p>
                        }
                      </td>
                      <td class="px-4 py-3">
                        <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(r.status)">
                          {{ r.status }}
                        </span>
                      </td>
                      <td class="px-4 py-3 text-right space-x-2 whitespace-nowrap">
                        @if (r.status === 'Draft') {
                          <button
                            type="button"
                            (click)="publishRota(r.id)"
                            class="rounded bg-[#005EB8] px-3 py-1.5 text-xs font-semibold text-white"
                          >
                            Publish
                          </button>
                        }
                        @if (r.assignment_type === 'Clinic') {
                          <button
                            type="button"
                            (click)="recordAbsence(r.id)"
                            class="rounded border border-[#FDE68A] bg-[#FFFBEB] px-3 py-1.5 text-xs font-semibold text-[#B45309] hover:bg-[#FEF3C7]"
                          >
                            Record absence
                          </button>
                        }
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }

        <!-- 9. COMMUNICATIONS -->
        @if (activeSection() === 'communications') {
          <div class="space-y-6">
            <div>
              <h1 class="text-2xl font-bold text-[#212B32]">Patient communications &amp; delivery log</h1>
              <p class="mt-1 text-sm text-[#4C6272]">
                Lock-screen previews omit sensitive clinical detail. Failed deliveries automatically generate follow-up tasks without cancelling bookings.
              </p>
            </div>

            <div class="divide-y divide-[#E5E7EB] rounded-lg border border-[#D8DDE0] bg-white">
              @for (c of communications(); track c.id) {
                <div class="flex flex-col justify-between gap-3 p-4 sm:flex-row sm:items-center">
                  <div>
                    <div class="flex flex-wrap items-center gap-2">
                      <span class="rounded border px-2 py-0.5 text-xs font-semibold" [class]="toneClass(c.status)">
                        {{ c.status }}
                      </span>
                      <span class="font-semibold text-[#212B32]">{{ c.patient_name }}</span>
                      <span class="text-xs text-[#4C6272]">{{ c.channel }} · {{ c.message_type }} · {{ c.language }} ({{ c.accessible_format }})</span>
                    </div>
                    <p class="mt-1 text-sm font-medium text-[#212B32]">{{ c.subject }}</p>
                    <p class="text-xs text-[#4C6272]">{{ c.body }}</p>
                    @if (c.failure_reason) {
                      <p class="mt-1 text-xs font-semibold text-[#B91C1C]">Failure: {{ c.failure_reason }}</p>
                    }
                  </div>
                  @if (c.status === 'Failed') {
                    <button
                      type="button"
                      (click)="retryFailedComm(c.id)"
                      class="shrink-0 rounded bg-[#005EB8] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#003087] whitespace-nowrap"
                    >
                      Retry via Email fallback
                    </button>
                  }
                </div>
              }
            </div>
          </div>
        }

        <!-- 10. REPORTS & AUDIT TRAIL -->
        @if (activeSection() === 'reports') {
          <div class="space-y-6">
            <div class="rounded-lg border border-[#FDE68A] bg-[#FFFBEB] p-4 text-xs text-[#92400E]">
              <strong>Prototype Reporting Notice:</strong> {{ report()?.prototype_disclaimer }} Booked capacity is reported separately from attended activity, and planned admissions are reported separately from actual bed occupancy.
            </div>

            @if (report(); as rep) {
              <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                  <h2 class="text-sm font-semibold text-[#212B32]">Outpatient activity vs booked capacity</h2>
                  <dl class="mt-3 space-y-2 text-sm">
                    <div class="flex justify-between"><dt class="text-[#4C6272]">Booked / Confirmed</dt><dd class="font-mono font-semibold tabular-nums">{{ rep.appointments.booked_or_confirmed_capacity }}</dd></div>
                    <div class="flex justify-between"><dt class="text-[#4C6272]">Attended / Completed</dt><dd class="font-mono font-semibold tabular-nums text-[#007F3B]">{{ rep.appointments.attended_activity }}</dd></div>
                    <div class="flex justify-between"><dt class="text-[#4C6272]">Clinic utilisation</dt><dd class="font-mono font-semibold tabular-nums">{{ rep.clinics.utilisation_pct }}% ({{ rep.clinics.unfilled_available_slots }} unfilled)</dd></div>
                  </dl>
                </div>
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                  <h2 class="text-sm font-semibold text-[#212B32]">Inpatient flow vs actual occupancy</h2>
                  <dl class="mt-3 space-y-2 text-sm">
                    <div class="flex justify-between"><dt class="text-[#4C6272]">Planned / Confirmed admissions</dt><dd class="font-mono font-semibold tabular-nums">{{ rep.inpatients_and_beds.planned_admissions + rep.inpatients_and_beds.confirmed_admissions }}</dd></div>
                    <div class="flex justify-between"><dt class="text-[#4C6272]">Actual inpatients occupying beds</dt><dd class="font-mono font-semibold tabular-nums">{{ rep.inpatients_and_beds.occupied_beds }} / {{ rep.inpatients_and_beds.total_beds }}</dd></div>
                    <div class="flex justify-between"><dt class="text-[#4C6272]">Closed / Infection control</dt><dd class="font-mono font-semibold tabular-nums text-[#B91C1C]">{{ rep.inpatients_and_beds.closed_or_restricted_beds }}</dd></div>
                  </dl>
                </div>
                <div class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                  <h2 class="text-sm font-semibold text-[#212B32]">Audit chain integrity</h2>
                  <p class="mt-2 text-sm">
                    SHA-256 hash chain status:
                    <strong [class]="auditChainValid() ? 'text-[#007F3B]' : 'text-[#B91C1C]'">
                      {{ auditChainValid() ? 'Verified intact' : 'Broken' }}
                    </strong>
                  </p>
                  <p class="mt-1 text-xs text-[#4C6272] tabular-nums">{{ auditEntries().length }} recent audit entries shown</p>
                </div>
              </div>
            }

            <div class="overflow-x-auto rounded-lg border border-[#D8DDE0] bg-white">
              <table class="w-full text-left text-xs">
                <thead class="border-b border-[#D8DDE0] bg-[#F8FAFB] font-semibold text-[#4C6272]">
                  <tr>
                    <th class="px-3 py-2.5">Seq</th>
                    <th class="px-3 py-2.5">Timestamp (UK)</th>
                    <th class="px-3 py-2.5">Actor (Role)</th>
                    <th class="px-3 py-2.5">Action</th>
                    <th class="px-3 py-2.5">Entity</th>
                    <th class="px-3 py-2.5">Hash</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#E5E7EB]">
                  @for (a of auditEntries().slice(0, 20); track a.id) {
                    <tr>
                      <td class="px-3 py-2 font-mono tabular-nums">#{{ a.sequence_num }}</td>
                      <td class="px-3 py-2 tabular-nums">{{ formatDateTime(a.created_at) }}</td>
                      <td class="px-3 py-2">{{ a.actor_user_id }} ({{ a.actor_role }})</td>
                      <td class="px-3 py-2 font-mono font-semibold">{{ a.action }}</td>
                      <td class="px-3 py-2 font-mono">{{ a.entity_type }}:{{ a.entity_id }}</td>
                      <td class="px-3 py-2 font-mono text-[#4C6272]">{{ a.entry_hash.slice(0, 12) }}…</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        }

        <!-- 11. ADMINISTRATION & GOVERNANCE -->
        @if (activeSection() === 'administration') {
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h1 class="text-2xl font-bold text-[#212B32]">Administration, identity governance &amp; safety log</h1>
                <p class="mt-1 text-sm text-[#4C6272]">
                  Duplicate review without auto-merge, external adapter boundary, prototype hazard log, and demonstrator controls.
                </p>
              </div>
              <button
                type="button"
                (click)="resetDemo()"
                class="rounded border border-[#FECACA] bg-white px-3.5 py-2 text-xs font-semibold text-[#B91C1C] hover:bg-[#FEF2F2]"
              >
                Reset demonstrator dataset
              </button>
            </div>

            <!-- Duplicate Review + Unverified NHS -->
            <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <section class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                <h2 class="text-base font-semibold text-[#212B32]">Duplicate-record &amp; NHS verification review</h2>
                <p class="mt-1 text-xs text-[#4C6272]">
                  Potential duplicates are never automatically merged.
                </p>
                <div class="mt-3 divide-y divide-[#E5E7EB]">
                  @for (p of patients(); track p.internal_id) {
                    <div class="flex items-center justify-between py-2.5 text-sm">
                      <div>
                        <p class="font-semibold text-[#212B32]">{{ p.given_name }} {{ p.family_name }} <span class="font-mono text-xs text-[#4C6272]">({{ p.internal_id }})</span></p>
                        <p class="text-xs text-[#4C6272] tabular-nums">
                          NHS: {{ p.nhs_number }} · {{ p.nhs_verification_status }} · DOB {{ p.date_of_birth }}
                        </p>
                        @if (p.duplicate_flag_patient_id) {
                          <p class="text-xs font-semibold text-[#B45309]">Flagged duplicate candidate: {{ p.duplicate_flag_patient_id }} (unmerged)</p>
                        }
                      </div>
                      @if (p.nhs_verification_status === 'unverified') {
                        <button
                          type="button"
                          (click)="verifyNhs(p.internal_id)"
                          class="rounded bg-[#005EB8] px-2.5 py-1 text-xs font-semibold text-white"
                        >
                          Verify via PAS
                        </button>
                      }
                    </div>
                  }
                </div>
              </section>

              <!-- External Adapters & Duplicate Event Test -->
              <section class="rounded-lg border border-[#D8DDE0] bg-white p-5">
                <h2 class="text-base font-semibold text-[#212B32]">External system adapters (Simulated)</h2>
                <div class="mt-3 space-y-2">
                  @for (ad of adapters(); track ad.name) {
                    <div class="rounded border border-[#E5E7EB] p-2.5 text-xs">
                      <p class="font-semibold text-[#212B32]">{{ ad.name }} · {{ ad.mode }}</p>
                      <p class="text-[#4C6272]">Authoritative for: {{ ad.authoritativeFor.join(', ') }}</p>
                    </div>
                  }
                </div>
                <div class="mt-4 flex flex-wrap gap-2">
                  <button
                    type="button"
                    (click)="simulateErsEvent(false)"
                    class="rounded bg-[#005EB8] px-3 py-1.5 text-xs font-semibold text-white"
                  >
                    Simulate inbound e-RS event (idempotent)
                  </button>
                  <button
                    type="button"
                    (click)="simulateErsEvent(true)"
                    class="rounded border border-[#FDE68A] bg-[#FFFBEB] px-3 py-1.5 text-xs font-semibold text-[#B45309]"
                  >
                    Simulate demographic conflict
                  </button>
                </div>
              </section>
            </div>

            <!-- Prototype Hazard Log -->
            <section class="rounded-lg border border-[#D8DDE0] bg-white p-5">
              <h2 class="text-base font-semibold text-[#212B32]">Prototype clinical safety &amp; governance hazard log (UK / England context)</h2>
              <p class="mt-1 text-xs text-[#4C6272]">
                Before any live NHS deployment, organisational scoping, DCB0129/DCB0160 clinical safety sign-off by a qualified Clinical Safety Officer (CSO), DSPT, DTAC, and Caldicott Guardian review are mandatory.
              </p>
              <div class="mt-3 overflow-x-auto">
                <table class="w-full text-left text-xs">
                  <thead class="border-b border-[#D8DDE0] bg-[#F8FAFB] font-semibold text-[#4C6272]">
                    <tr>
                      <th class="px-3 py-2">Hazard ID</th>
                      <th class="px-3 py-2">Clinical / Operational Hazard</th>
                      <th class="px-3 py-2">Prototype Mitigation</th>
                      <th class="px-3 py-2">Qualified Sign-off Required</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-[#E5E7EB]">
                    <tr><td class="px-3 py-2 font-mono font-semibold">H-01</td><td class="px-3 py-2">Silent merge of distinct patients sharing similar demographics</td><td class="px-3 py-2">Manual duplicate review queue; automatic merging disabled</td><td class="px-3 py-2">Caldicott Guardian / PAS Lead</td></tr>
                    <tr><td class="px-3 py-2 font-mono font-semibold">H-02</td><td class="px-3 py-2">Unauthorised triage priority downgrade delaying urgent care</td><td class="px-3 py-2">Server RBAC restricts priority assignment strictly to clinician role</td><td class="px-3 py-2">Clinical Safety Officer (DCB0160)</td></tr>
                    <tr><td class="px-3 py-2 font-mono font-semibold">H-03</td><td class="px-3 py-2">Staff absence cancelling bookings silently without patient contact</td><td class="px-3 py-2">Absence creates Staff absence + Patient needing contact work queues</td><td class="px-3 py-2">Outpatient Service Manager &amp; CSO</td></tr>
                    <tr><td class="px-3 py-2 font-mono font-semibold">H-04</td><td class="px-3 py-2">Estimated inpatient discharge treated as guaranteed bed availability</td><td class="px-3 py-2">Estimated discharge displayed advisory only; closed beds block allocation</td><td class="px-3 py-2">Chief Nurse / Bed Flow Lead</td></tr>
                    <tr><td class="px-3 py-2 font-mono font-semibold">H-05</td><td class="px-3 py-2">Clinical diagnosis exposed on SMS/push lock-screen notification</td><td class="px-3 py-2">Separate lock-screen-safe preview omits specialty and clinical text</td><td class="px-3 py-2">Data Protection Officer (UK GDPR)</td></tr>
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        }
      </main>
    </div>
  `,
})
export class StaffWorkspace implements OnInit, OnDestroy {
  readonly api = inject(ApiService);
  private fb = inject(FormBuilder);

  readonly activeSection = input<StaffSection>('overview');
  readonly sectionChange = output<StaffSection>();

  readonly navItems: {id: StaffSection; label: string; icon: string}[] = [
    {id: 'overview', label: 'Overview', icon: 'dashboard'},
    {id: 'referrals', label: 'Referrals', icon: 'assignment_ind'},
    {id: 'waiting-lists', label: 'Waiting lists', icon: 'hourglass_top'},
    {id: 'appointments', label: 'Appointments', icon: 'event_note'},
    {id: 'clinics', label: 'Clinics', icon: 'medical_services'},
    {id: 'inpatients', label: 'Inpatients', icon: 'local_hospital'},
    {id: 'beds', label: 'Beds', icon: 'bed'},
    {id: 'rotas', label: 'Staff rotas', icon: 'badge'},
    {id: 'communications', label: 'Communications', icon: 'mail'},
    {id: 'reports', label: 'Reports', icon: 'assessment'},
    {id: 'administration', label: 'Administration', icon: 'admin_panel_settings'},
  ];

  readonly patients = signal<PatientRecord[]>([]);
  readonly referrals = signal<Referral[]>([]);
  readonly waitingList = signal<WaitingListEntry[]>([]);
  readonly appointments = signal<Appointment[]>([]);
  readonly clinicTemplates = signal<ClinicTemplate[]>([]);
  readonly clinicSessions = signal<ClinicSession[]>([]);
  readonly rotas = signal<StaffRotaEntry[]>([]);
  readonly wards = signal<Ward[]>([]);
  readonly beds = signal<Bed[]>([]);
  readonly admissions = signal<PlannedAdmission[]>([]);
  readonly workTasks = signal<WorkTask[]>([]);
  readonly communications = signal<CommunicationRecord[]>([]);
  readonly report = signal<OperationalReport | null>(null);
  readonly auditEntries = signal<AuditEntry[]>([]);
  readonly auditChainValid = signal(true);
  readonly adapters = signal<{name: string; authoritativeFor: string[]; mode: string}[]>([]);
  readonly integrationEvents = signal<IntegrationEvent[]>([]);

  readonly selectedPatient = signal<PatientRecord | null>(null);
  readonly pendingPatientSwitch = signal<PatientRecord | null>(null);
  readonly reviewingReferral = signal<Referral | null>(null);
  readonly showNewReferralForm = signal(false);
  readonly selectedTaskIds = signal<string[]>([]);
  readonly batchPreviewResults = signal<{id: string; eligible: boolean; outcome: string}[] | null>(null);
  readonly feedback = signal<{tone: 'success' | 'warning' | 'error'; title: string; detail: string} | null>(null);

  readonly newReferralForm = this.fb.group({
    patient_id: ['PAT-001', Validators.required],
    specialty: ['Cardiology', Validators.required],
    required_format: ['In-person', Validators.required],
    appointment_requirements: ['Outpatient cardiology review with 12-lead ECG', Validators.required],
  });

  readonly reviewForm = this.fb.group({
    status: ['Accepted', Validators.required],
    clinical_priority: ['Soon', Validators.required],
    booking_window_days: [28, Validators.required],
    review_notes: ['Accepted for outpatient assessment; add to waiting list.'],
  });

  private unsubSse: (() => void) | null = null;

  ngOnInit(): void {
    void this.refreshAll();
    this.unsubSse = this.api.onLiveUpdate(() => {
      void this.refreshAll();
    });
  }

  ngOnDestroy(): void {
    this.unsubSse?.();
  }

  selectSection(section: StaffSection): void {
    this.sectionChange.emit(section);
  }

  jumpToChecklistTarget(target: string): void {
    const map: Record<string, StaffSection> = {
      referrals: 'referrals',
      'waiting-lists': 'waiting-lists',
      'patient-book': 'appointments',
      communications: 'communications',
      appointments: 'appointments',
      inpatients: 'inpatients',
      beds: 'beds',
      rotas: 'rotas',
      reports: 'reports',
    };
    this.selectSection(map[target] || 'overview');
  }

  selectPatientById(patientId: string): void {
    const found = this.patients().find((p) => p.internal_id === patientId);
    if (!found) return;
    if (this.reviewingReferral() && this.selectedPatient() && this.selectedPatient()!.internal_id !== patientId) {
      this.pendingPatientSwitch.set(found);
      return;
    }
    this.selectedPatient.set(found);
  }

  confirmPatientSwitch(): void {
    if (this.pendingPatientSwitch()) {
      this.selectedPatient.set(this.pendingPatientSwitch());
      this.reviewingReferral.set(null);
      this.pendingPatientSwitch.set(null);
    }
  }

  clearSelectedPatient(): void {
    this.selectedPatient.set(null);
  }

  async refreshAll(): Promise<void> {
    try {
      const [
        patients,
        referrals,
        waitingList,
        appointments,
        clinicTemplates,
        clinicSessions,
        rotas,
        wardsBeds,
        admissions,
        workTasks,
        communications,
        report,
        audit,
        integrations,
      ] = await Promise.all([
        this.api.getPatients(),
        this.api.getReferrals(),
        this.api.getWaitingList(),
        this.api.getAppointments(),
        this.api.getClinicTemplates(),
        this.api.getClinicSessions(),
        this.api.getRotas(),
        this.api.getWardsAndBeds(),
        this.api.getAdmissions(),
        this.api.getWorkTasks(),
        this.api.getCommunications(),
        this.api.getReports(),
        this.api.getAudit(),
        this.api.getIntegrations(),
        this.api.loadBootstrap(),
      ]);

      this.patients.set(patients);
      this.referrals.set(referrals);
      this.waitingList.set(waitingList);
      this.appointments.set(appointments);
      this.clinicTemplates.set(clinicTemplates);
      this.clinicSessions.set(clinicSessions);
      this.rotas.set(rotas);
      this.wards.set(wardsBeds.wards);
      this.beds.set(wardsBeds.beds);
      this.admissions.set(admissions);
      this.workTasks.set(workTasks);
      this.communications.set(communications);
      this.report.set(report);
      this.auditEntries.set(audit.entries);
      this.auditChainValid.set(audit.chainIntegrity.valid);
      this.adapters.set(integrations.adapters);
      this.integrationEvents.set(integrations.events);
    } catch (err) {
      this.feedback.set({
        tone: 'error',
        title: 'Failed to load workspace data',
        detail: extractErrorMessage(err),
      });
    }
  }

  openReviewModal(ref: Referral): void {
    this.selectPatientById(ref.patient_id);
    this.reviewingReferral.set(ref);
    this.reviewForm.patchValue({
      status: ref.status === 'Awaiting review' || ref.status === 'Received' ? 'Accepted' : ref.status,
      clinical_priority: ref.clinical_priority || 'Soon',
      booking_window_days: ref.booking_window_days || 28,
      review_notes: ref.review_notes || 'Accepted for outpatient review; add to waiting list.',
    });
  }

  async submitClinicalReview(): Promise<void> {
    const rr = this.reviewingReferral();
    if (!rr) return;
    try {
      await this.api.reviewReferral(rr.id, this.reviewForm.value);
      this.feedback.set({
        tone: 'success',
        title: 'Clinical review saved',
        detail: `Referral ${rr.id} updated to ${this.reviewForm.value.status} (${this.reviewForm.value.clinical_priority}).`,
      });
      this.reviewingReferral.set(null);
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({
        tone: 'error',
        title: 'Clinical review blocked',
        detail: extractErrorMessage(err),
      });
    }
  }

  async submitNewReferral(): Promise<void> {
    try {
      const val = this.newReferralForm.value;
      await this.api.createReferral({
        ...val,
        service_name: `${val.specialty} Outpatients`,
        required_resources: val.specialty === 'Cardiology' ? ['12-lead ECG'] : [],
      });
      this.showNewReferralForm.set(false);
      this.feedback.set({
        tone: 'success',
        title: 'Referral recorded',
        detail: 'Added to Awaiting clinical review queue.',
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Error', detail: extractErrorMessage(err)});
    }
  }

  async transitionAppt(id: string, targetStatus: string, reason?: string, clinicalOutcome?: string): Promise<void> {
    try {
      await this.api.transitionAppointment(id, {targetStatus, reason, clinicalOutcome});
      this.feedback.set({
        tone: 'success',
        title: `Appointment marked ${targetStatus}`,
        detail: `Appointment ${id} updated.`,
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({
        tone: 'error',
        title: 'Transition blocked',
        detail: extractErrorMessage(err),
      });
    }
  }

  async createFollowUp(appt: Appointment): Promise<void> {
    try {
      const res = await this.api.arrangeFollowUp(appt.id, {
        clinical_priority: 'Routine',
        format: 'Telephone',
        booking_window_days: 28,
        notes: `Follow-up telephone clinic after attended appointment ${appt.id}`,
      });
      this.feedback.set({
        tone: 'success',
        title: 'Follow-up arranged',
        detail: `Created follow-up referral ${res.followUpReferralId} and waiting list entry ${res.waitingListId}.`,
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Follow-up failed', detail: extractErrorMessage(err)});
    }
  }

  async amendTemplate(tpl: ClinicTemplate): Promise<void> {
    try {
      const res = await this.api.amendClinicTemplate(tpl.id, {
        default_duration_mins: tpl.default_duration_mins + 5,
        amendment_reason: 'Extended consultation buffer by 5 mins for future sessions',
      });
      this.feedback.set({
        tone: 'success',
        title: `Template ${tpl.id} updated to v${res.newVersion}`,
        detail: `Existing bookings preserved; ${res.affectedBookingsCount} review task(s) created in Clinic change queue.`,
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Amendment blocked', detail: extractErrorMessage(err)});
    }
  }

  async resolveAdmissionConflict(adm: PlannedAdmission): Promise<void> {
    try {
      const res = await this.api.resolveAdmissionConflict(adm.id, {
        newBedId: 'BED-4B-07',
        completeAllPrerequisites: true,
        resolutionNotes: 'Reallocated from Maintenance Closed 4B-06 to available telemetry bed 4B-07 and confirmed Blood group & save.',
      });
      this.feedback.set({
        tone: res.conflictStatus === 'Clear' ? 'success' : 'warning',
        title: `Admission ${adm.id}: ${res.conflictStatus}`,
        detail: res.conflictReason || 'All bed and prerequisite conflicts resolved.',
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Resolution blocked', detail: extractErrorMessage(err)});
    }
  }

  async transitionAdm(id: string, targetState: string): Promise<void> {
    try {
      await this.api.transitionAdmission(id, targetState);
      this.feedback.set({tone: 'success', title: `Admission updated to ${targetState}`, detail: `Record ${id} updated.`});
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Blocked', detail: extractErrorMessage(err)});
    }
  }

  async setBedStatus(bedId: string, occupancy_status: string, restriction_note: string | null): Promise<void> {
    try {
      await this.api.updateBed(bedId, {occupancy_status, restriction_note});
      this.feedback.set({tone: 'success', title: `Bed updated to ${occupancy_status}`, detail: 'Planned admissions re-evaluated.'});
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Update blocked', detail: extractErrorMessage(err)});
    }
  }

  async publishRota(rotaId: string): Promise<void> {
    try {
      await this.api.publishRota(rotaId);
      this.feedback.set({tone: 'success', title: 'Rota published', detail: `Rota ${rotaId} is now published.`});
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Blocked', detail: extractErrorMessage(err)});
    }
  }

  async recordAbsence(rotaId: string): Promise<void> {
    try {
      const res = await this.api.recordStaffAbsence(rotaId, 'Sickness Absence', 'Unexpected clinician sickness absence');
      this.feedback.set({
        tone: 'warning',
        title: 'Clinician absence recorded (appointments preserved)',
        detail: `${res.affectedAppointments.length} booked appointment(s) flagged in Staff absence & Patient needing contact queues without silent cancellation.`,
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Failed', detail: extractErrorMessage(err)});
    }
  }

  async retryFailedComm(commId: string): Promise<void> {
    try {
      await this.api.retryCommunication(commId, 'Email');
      this.feedback.set({
        tone: 'success',
        title: 'Fallback Email dispatched',
        detail: 'Reminder resent via Email and corresponding failed communication task resolved.',
      });
      await this.refreshAll();
    } catch (err) {
      this.feedback.set({tone: 'error', title: 'Retry failed', detail: extractErrorMessage(err)});
    }
  }

  toggleTaskSelection(id: string, checked: boolean): void {
    this.selectedTaskIds.update((list) =>
      checked ? [...new Set([...list, id])] : list.filter((x) => x !== id),
    );
  }

  async updateTaskStatus(taskId: string, status: string): Promise<void> {
    await this.api.updateWorkTask(taskId, {
      status,
      resolution_note: status === 'Resolved' ? `Resolved by ${this.api.session()?.user.display_name}` : undefined,
    });
    await this.refreshAll();
  }

  async runBatchTasks(preview: boolean): Promise<void> {
    const res = await this.api.batchWorkTasks({
      taskIds: this.selectedTaskIds(),
      action: 'acknowledge',
      preview,
    });
    if (preview) {
      this.batchPreviewResults.set(res.results);
    } else {
      this.batchPreviewResults.set(null);
      this.selectedTaskIds.set([]);
      this.feedback.set({
        tone: 'success',
        title: 'Batch update completed',
        detail: `${res.results.filter((r) => r.eligible).length} task(s) acknowledged.`,
      });
      await this.refreshAll();
    }
  }

  async verifyNhs(patientId: string): Promise<void> {
    const res = await this.api.verifyPatientNhs(patientId, 'verified');
    this.feedback.set({
      tone: 'success',
      title: 'NHS number verified via simulated PAS',
      detail: `Patient ${patientId} status: ${res.nhs_verification_status}.`,
    });
    await this.refreshAll();
  }

  async simulateErsEvent(simulateConflict: boolean): Promise<void> {
    const res = await this.api.simulateIntegrationEvent({
      externalEventId: 'UBRN-DEMO-7712',
      idempotencyKey: simulateConflict ? `conflict-${Date.now()}` : 'ers-demo-stable-key',
      patientId: 'PAT-001',
      specialty: 'Cardiology',
      simulateConflict,
    });
    this.feedback.set({
      tone: res.status === 'Synced' ? 'success' : 'warning',
      title: `e-RS Event: ${res.status}`,
      detail: res.event.conflict_detail || `Event ${res.event.id} processed cleanly.`,
    });
    await this.refreshAll();
  }

  async resetDemo(): Promise<void> {
    await this.api.resetDemonstrator();
    this.feedback.set({
      tone: 'success',
      title: 'Demonstrator dataset reset',
      detail: 'Pennine University Hospital baseline data restored.',
    });
    await this.refreshAll();
  }

  formatDateTime = formatLondonDateTime;
  formatDate = formatLondonDate;
  formatTime = formatLondonTime;
  waitDays = daysSince;
  toneClass = statusToneClass;
}
