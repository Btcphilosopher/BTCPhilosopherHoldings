package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.userPrefsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "patient_connect_non_sensitive_prefs"
)

data class AppPreferences(
    val reducedMotion: Boolean = false,
    val highContrast: Boolean = false,
    val largeText: Boolean = false,
    val biometricUnlockEnabled: Boolean = false,
    val useLiveBackend: Boolean = false,
    val serverBaseUrl: String = "http://10.0.2.2:8000",
    val simulateOffline: Boolean = false,
    val simulateInterruptedConnection: Boolean = false,
)

class UserPreferencesRepository(private val context: Context) {
    private object Keys {
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val HIGH_CONTRAST = booleanPreferencesKey("high_contrast")
        val LARGE_TEXT = booleanPreferencesKey("large_text")
        val BIOMETRIC_UNLOCK = booleanPreferencesKey("biometric_unlock")
        val USE_LIVE_BACKEND = booleanPreferencesKey("use_live_backend")
        val SERVER_BASE_URL = stringPreferencesKey("server_base_url")
        val SIMULATE_OFFLINE = booleanPreferencesKey("simulate_offline")
        val SIMULATE_INTERRUPTED = booleanPreferencesKey("simulate_interrupted")
    }

    val preferences: Flow<AppPreferences> = context.userPrefsDataStore.data.map { prefs ->
        AppPreferences(
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            highContrast = prefs[Keys.HIGH_CONTRAST] ?: false,
            largeText = prefs[Keys.LARGE_TEXT] ?: false,
            biometricUnlockEnabled = prefs[Keys.BIOMETRIC_UNLOCK] ?: false,
            useLiveBackend = prefs[Keys.USE_LIVE_BACKEND] ?: false,
            serverBaseUrl = prefs[Keys.SERVER_BASE_URL] ?: "http://10.0.2.2:8000",
            simulateOffline = prefs[Keys.SIMULATE_OFFLINE] ?: false,
            simulateInterruptedConnection = prefs[Keys.SIMULATE_INTERRUPTED] ?: false,
        )
    }

    suspend fun setReducedMotion(enabled: Boolean) {
        context.userPrefsDataStore.edit { it[Keys.REDUCED_MOTION] = enabled }
    }

    suspend fun setHighContrast(enabled: Boolean) {
        context.userPrefsDataStore.edit { it[Keys.HIGH_CONTRAST] = enabled }
    }

    suspend fun setLargeText(enabled: Boolean) {
        context.userPrefsDataStore.edit { it[Keys.LARGE_TEXT] = enabled }
    }

    suspend fun setBiometricUnlockEnabled(enabled: Boolean) {
        context.userPrefsDataStore.edit { it[Keys.BIOMETRIC_UNLOCK] = enabled }
    }

    suspend fun setBackendConfig(useLive: Boolean, baseUrl: String) {
        context.userPrefsDataStore.edit {
            it[Keys.USE_LIVE_BACKEND] = useLive
            it[Keys.SERVER_BASE_URL] = baseUrl.trim().ifEmpty { "http://10.0.2.2:8000" }
        }
    }

    suspend fun setSimulateOffline(offline: Boolean) {
        context.userPrefsDataStore.edit { it[Keys.SIMULATE_OFFLINE] = offline }
    }

    suspend fun setSimulateInterruptedConnection(interrupted: Boolean) {
        context.userPrefsDataStore.edit { it[Keys.SIMULATE_INTERRUPTED] = interrupted }
    }
}
