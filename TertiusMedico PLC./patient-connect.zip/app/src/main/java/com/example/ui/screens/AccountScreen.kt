package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.AppPreferences
import com.example.data.model.HomeSummaryDto
import com.example.data.model.NotificationDispatchDto
import com.example.data.model.ProxyGrantDto
import com.example.data.model.TrustedDeviceDto
import com.example.ui.components.BluePageHeader
import com.example.ui.components.ProxyAccountBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.util.LondonTimeFormatter

@Composable
fun AccountScreen(
    summary: HomeSummaryDto?,
    proxies: List<ProxyGrantDto>,
    devices: List<TrustedDeviceDto>,
    notifications: List<NotificationDispatchDto>,
    preferences: AppPreferences,
    isProxyMode: Boolean,
    onSwitchPatient: (String?) -> Unit,
    onUpdatePreferences: (comm: String, interpreter: String, format: String) -> Unit,
    onSetReducedMotion: (Boolean) -> Unit,
    onSetHighContrast: (Boolean) -> Unit,
    onSetLargeText: (Boolean) -> Unit,
    onSetBiometricUnlock: (Boolean) -> Unit,
    onLockSession: () -> Unit,
    onRevokeDevice: (String) -> Unit,
    onSetSimulateOffline: (Boolean) -> Unit,
    onSetSimulateInterrupted: (Boolean) -> Unit,
    onSetBackendConfig: (Boolean, String) -> Unit,
    onSimulateExpiry: () -> Unit,
    onSandboxConfirmBooking: () -> Unit,
    onSandboxAdvanceMedicine: (Boolean) -> Unit,
    onSandboxFailedNotification: () -> Unit,
    onSendPrivacyTestNotification: () -> Unit,
    onSignOutAndClearCache: () -> Unit,
) {
    val profile = summary?.activePatient
    var commPref by remember(profile?.id) { mutableStateOf(profile?.commPreference ?: "In-app message") }
    var interpreter by remember(profile?.id) { mutableStateOf(profile?.interpreterLanguage ?: "Not required (English)") }
    var accessibleFmt by remember(profile?.id) { mutableStateOf(profile?.accessibleFormat ?: "Large print") }
    var serverUrl by remember(preferences.serverBaseUrl) { mutableStateOf(preferences.serverBaseUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        BluePageHeader(
            title = "Account & Access",
            subtitle = "Proxy accounts, accessibility preferences, device security, and offline controls.",
        )

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (summary?.activeProxyGrant != null) {
                ProxyAccountBanner(
                    patientName = summary.activePatient.fullName,
                    restrictions = summary.activeProxyGrant.restrictionsSummary,
                    onSwitchBack = { onSwitchPatient(null) },
                )
            }

            // 1. Account & Proxy Switching
            SectionHeader("Switch patient / proxy account")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Eleanor Vance (Own account)", style = MaterialTheme.typography.titleMedium)
                    Text("Full personal access · Synthetic ID TM-904-812-3310", style = MaterialTheme.typography.bodyMedium)
                    Button(
                        onClick = { onSwitchPatient(null) },
                        enabled = isProxyMode,
                        modifier = Modifier.testTag("switch_to_own_account"),
                    ) {
                        Text(if (!isProxyMode) "Currently active" else "Switch to my own account")
                    }
                }
            }

            proxies.forEach { grant ->
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("proxy_card_${grant.patientId}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusPill(grant.verificationStatus)
                        Text("${grant.patientName} (${grant.relationshipLabel})", style = MaterialTheme.typography.titleMedium)
                        Text("Verification: ${grant.verificationReference}", style = MaterialTheme.typography.labelMedium)
                        Text("Effective: ${grant.effectiveFrom} to ${grant.effectiveUntil}", style = MaterialTheme.typography.labelMedium)
                        Text(
                            "Permissions: ${if (grant.permissions.isEmpty()) "None" else grant.permissions.joinToString(", ")}",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Text("Restrictions: ${grant.restrictionsSummary}", style = MaterialTheme.typography.bodyMedium)
                        Button(
                            onClick = { onSwitchPatient(grant.patientId) },
                            enabled = !grant.revoked,
                            modifier = Modifier.testTag("switch_proxy_${grant.patientId}"),
                        ) {
                            Text(
                                if (grant.verificationStatus == "VERIFIED") {
                                    "Switch to ${grant.patientName}"
                                } else {
                                    "Attempt access (policy-blocked demo)"
                                }
                            )
                        }
                    }
                }
            }

            // 2. Communication & Accessibility Preferences
            SectionHeader("Communication & accessibility preferences")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = commPref,
                        onValueChange = { commPref = it },
                        label = { Text("Preferred contact method") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = interpreter,
                        onValueChange = { interpreter = it },
                        label = { Text("Interpreter / language support") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = accessibleFmt,
                        onValueChange = { accessibleFmt = it },
                        label = { Text("Accessible format needs") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = { onUpdatePreferences(commPref, interpreter, accessibleFmt) },
                        enabled = !preferences.simulateOffline && summary?.activeProxyGrant?.permissions?.contains("profile:write") != false,
                    ) {
                        Text("Save provider preferences")
                    }

                    Spacer(Modifier.height(4.dp))
                    ToggleRow("High-contrast display", "Stronger borders and pure black text", preferences.highContrast, onSetHighContrast)
                    ToggleRow("Large text boost", "Increases typography scale across screens", preferences.largeText, onSetLargeText)
                    ToggleRow("Reduced motion", "Minimises UI transitions and animations", preferences.reducedMotion, onSetReducedMotion)
                }
            }

            // 3. Security, Biometrics & Devices
            SectionHeader("Session security & trusted devices")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToggleRow(
                        title = "Local biometric session unlock",
                        subtitle = "Unlocks this device's saved session only — does not verify clinical identity.",
                        checked = preferences.biometricUnlockEnabled,
                        onCheckedChange = onSetBiometricUnlock,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (preferences.biometricUnlockEnabled) {
                            OutlinedButton(onClick = onLockSession) { Text("Lock session now") }
                        }
                        OutlinedButton(onClick = onSimulateExpiry) { Text("Test session expiry") }
                    }

                    devices.forEach { dev ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${dev.deviceName}${if (dev.isCurrent) " (This device)" else ""}",
                                        style = MaterialTheme.typography.titleMedium,
                                    )
                                    Text(
                                        if (dev.revoked) "REVOKED" else "Active · ${LondonTimeFormatter.formatShortTimestamp(dev.lastSeenAt)}",
                                        style = MaterialTheme.typography.labelMedium,
                                    )
                                }
                                if (!dev.revoked) {
                                    OutlinedButton(onClick = { onRevokeDevice(dev.id) }) {
                                        Text("Revoke")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Privacy-Preserving Notifications Log
            SectionHeader("Notification delivery log")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Notifications never show health details or patient names on the lock screen.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedButton(onClick = onSendPrivacyTestNotification) {
                        Text("Trigger privacy-preserving Android alert")
                    }
                    notifications.forEach { n ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            StatusPill(n.deliveryStatus)
                            Text("Preview: \"${n.genericPreviewText}\"", style = MaterialTheme.typography.bodyMedium)
                            n.failureReason?.let { Text(it, style = MaterialTheme.typography.labelMedium) }
                        }
                    }
                }
            }

            // 5. Offline, Interrupted Connection & Prototype Staff Simulator
            SectionHeader("Offline, interruption & staff simulation")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToggleRow(
                        title = "Simulate offline mode",
                        subtitle = "Displays cached appointments & contacts with timestamps; blocks authoritative mutations.",
                        checked = preferences.simulateOffline,
                        onCheckedChange = onSetSimulateOffline,
                        tag = "toggle_simulate_offline",
                    )
                    ToggleRow(
                        title = "Simulate interrupted connection (next medicine request)",
                        subtitle = "Demonstrates idempotent status recovery without duplicate resubmission.",
                        checked = preferences.simulateInterruptedConnection,
                        onCheckedChange = onSetSimulateInterrupted,
                        tag = "toggle_simulate_interrupted",
                    )
                    ToggleRow(
                        title = "Connect to Live FastAPI Server",
                        subtitle = "Off = On-device deterministic sandbox; On = HTTP Ktor client.",
                        checked = preferences.useLiveBackend,
                        onCheckedChange = { onSetBackendConfig(it, serverUrl) },
                    )
                    if (preferences.useLiveBackend) {
                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = { serverUrl = it },
                            label = { Text("FastAPI URL") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Button(onClick = { onSetBackendConfig(true, serverUrl) }) { Text("Apply URL") }
                    } else {
                        Text("On-Device Sandbox Staff Actions:", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onSandboxConfirmBooking, modifier = Modifier.weight(1f)) {
                                Text("Confirm booking")
                            }
                            OutlinedButton(onClick = { onSandboxAdvanceMedicine(true) }, modifier = Modifier.weight(1f)) {
                                Text("Advance medicine")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onSandboxAdvanceMedicine(false) }, modifier = Modifier.weight(1f)) {
                                Text("Decline medicine")
                            }
                            OutlinedButton(onClick = onSandboxFailedNotification, modifier = Modifier.weight(1f)) {
                                Text("Fail notification")
                            }
                        }
                    }
                }
            }

            // 6. Explicit Sign Out & Cache Wipe
            Button(
                onClick = onSignOutAndClearCache,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signout_clear_cache_button"),
            ) {
                Text("Sign out & clear local cache")
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String? = null,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = if (tag != null) Modifier.testTag(tag) else Modifier,
        )
    }
}
