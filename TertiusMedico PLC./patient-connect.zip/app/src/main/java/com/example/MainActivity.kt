package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.Medication
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.notifications.PrivacyNotificationHelper
import com.example.security.BiometricUnlockHelper
import com.example.ui.MainUiState
import com.example.ui.MainViewModel
import com.example.ui.SubScreen
import com.example.ui.TopTab
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.PrototypeNoticeStrip
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AppointmentsScreen
import com.example.ui.screens.BiometricLocalLockScreen
import com.example.ui.screens.CareTasksScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MedicinesScreen
import com.example.ui.screens.MessagesScreen
import com.example.ui.screens.RecordsScreen
import com.example.ui.screens.SignInScreen
import com.example.ui.theme.AccessibilityThemeConfig
import com.example.ui.theme.PatientConnectTheme

class MainActivity : FragmentActivity() {
    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as PatientConnectApplication

        setContent {
            val viewModel: MainViewModel = viewModel(
                factory = MainViewModel.Factory(app.repository, app.preferencesRepository)
            )
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val windowSizeClass = calculateWindowSizeClass(this)
            val useRail = windowSizeClass.widthSizeClass != WindowWidthSizeClass.Compact

            val notificationLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                if (granted) {
                    PrivacyNotificationHelper.showGenericUpdateNotification(this)
                }
            }

            // Request POST_NOTIFICATIONS politely only after signing in on Android 13+
            LaunchedEffect(uiState.session?.userId) {
                if (uiState.session != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val already = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS,
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!already) {
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            PatientConnectTheme(
                accessibilityConfig = AccessibilityThemeConfig(
                    highContrast = uiState.preferences.highContrast,
                    reducedMotion = uiState.preferences.reducedMotion,
                    largeText = uiState.preferences.largeText,
                )
            ) {
                PatientConnectRoot(
                    uiState = uiState,
                    useNavigationRail = useRail,
                    viewModel = viewModel,
                    onPromptBiometricUnlock = {
                        BiometricUnlockHelper.promptLocalSessionUnlock(
                            activity = this@MainActivity,
                            onSuccess = { viewModel.unlockLocalSession() },
                            onFallbackOrError = { _ -> viewModel.unlockLocalSession() },
                        )
                    },
                    onTriggerTestNotification = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.POST_NOTIFICATIONS,
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            PrivacyNotificationHelper.showGenericUpdateNotification(this@MainActivity)
                        }
                    },
                )
            }
        }
    }
}

private data class NavTabItem(
    val tab: TopTab,
    val labelRes: Int,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector,
    val tag: String,
)

private val NAV_ITEMS = listOf(
    NavTabItem(TopTab.HOME, R.string.nav_home, Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    NavTabItem(TopTab.APPOINTMENTS, R.string.nav_appointments, Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_appointments"),
    NavTabItem(TopTab.MEDICINES, R.string.nav_medicines, Icons.Filled.Medication, Icons.Outlined.Medication, "nav_medicines"),
    NavTabItem(TopTab.MESSAGES, R.string.nav_messages, Icons.Filled.Mail, Icons.Outlined.Mail, "nav_messages"),
    NavTabItem(TopTab.ACCOUNT, R.string.nav_account, Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle, "nav_account"),
)

@Composable
private fun PatientConnectRoot(
    uiState: MainUiState,
    useNavigationRail: Boolean,
    viewModel: MainViewModel,
    onPromptBiometricUnlock: () -> Unit,
    onTriggerTestNotification: () -> Unit,
) {
    val session = uiState.session
    if (session == null) {
        Scaffold(contentWindowInsets = WindowInsets.safeDrawing) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                SignInScreen(
                    isLoading = uiState.isLoading,
                    errorMessage = uiState.errorMessage,
                    bannerMessage = uiState.bannerMessage,
                    preferences = uiState.preferences,
                    recoveryGuidance = uiState.recoveryGuidance,
                    onSignIn = viewModel::signIn,
                    onBackendConfigChange = viewModel::setBackendConfig,
                    onDismissMessage = viewModel::clearNotices,
                )
            }
        }
        return
    }

    if (uiState.sessionLockedByBiometricGate) {
        Scaffold(contentWindowInsets = WindowInsets.safeDrawing) { innerPadding ->
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                BiometricLocalLockScreen(
                    displayName = session.displayName,
                    onUnlockWithBiometric = onPromptBiometricUnlock,
                    onSignOut = viewModel::signOutAndClearCache,
                )
            }
        }
        return
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (!useNavigationRail && uiState.subScreen == SubScreen.NONE) {
                NavigationBar {
                    NAV_ITEMS.forEach { item ->
                        val selected = uiState.selectedTab == item.tab
                        val label = stringResource(item.labelRes)
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.selectTab(item.tab) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.activeIcon else item.inactiveIcon,
                                    contentDescription = label,
                                )
                            },
                            label = { Text(label, maxLines = 1) },
                            modifier = Modifier.testTag(item.tag),
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (useNavigationRail && uiState.subScreen == SubScreen.NONE) {
                NavigationRail {
                    NAV_ITEMS.forEach { item ->
                        val selected = uiState.selectedTab == item.tab
                        val label = stringResource(item.labelRes)
                        NavigationRailItem(
                            selected = selected,
                            onClick = { viewModel.selectTab(item.tab) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.activeIcon else item.inactiveIcon,
                                    contentDescription = label,
                                )
                            },
                            label = { Text(label) },
                            modifier = Modifier.testTag(item.tag),
                        )
                    }
                }
            }

            Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                PrototypeNoticeStrip()
                if (uiState.isLoading) {
                    LinearProgressIndicator(modifier = Modifier.padding(0.dp))
                }
                FeedbackBanner(
                    message = uiState.errorMessage ?: uiState.bannerMessage,
                    isError = uiState.errorMessage != null,
                    onDismiss = viewModel::clearNotices,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                )

                when (uiState.subScreen) {
                    SubScreen.RECORDS -> RecordsScreen(
                        summary = uiState.homeSummary,
                        records = uiState.records,
                        corrections = uiState.corrections,
                        selectedDocument = uiState.selectedDocument,
                        isOffline = uiState.preferences.simulateOffline,
                        onBack = viewModel::closeSubScreen,
                        onOpenDocument = viewModel::openRecordDocument,
                        onCloseDocument = viewModel::closeRecordDocument,
                        onSubmitCorrection = viewModel::submitCorrection,
                        onSwitchBackToSelf = { viewModel.switchPatientContext(null) },
                    )

                    SubScreen.CARE_TASKS -> CareTasksScreen(
                        summary = uiState.homeSummary,
                        tasks = uiState.careTasks,
                        isOffline = uiState.preferences.simulateOffline,
                        onBack = viewModel::closeSubScreen,
                        onCompleteTask = viewModel::completeCareTask,
                        onSwitchBackToSelf = { viewModel.switchPatientContext(null) },
                    )

                    SubScreen.NONE -> when (uiState.selectedTab) {
                        TopTab.HOME -> HomeScreen(
                            summary = uiState.homeSummary,
                            cachedSummary = uiState.cachedSummary,
                            cachedAppointments = uiState.cachedAppointments,
                            isOffline = uiState.preferences.simulateOffline,
                            onRefresh = viewModel::refreshAllData,
                            onNavigateTab = viewModel::selectTab,
                            onOpenSubScreen = viewModel::openSubScreen,
                            onSwitchBackToSelf = { viewModel.switchPatientContext(null) },
                        )

                        TopTab.APPOINTMENTS -> AppointmentsScreen(
                            summary = uiState.homeSummary,
                            appointments = uiState.appointments,
                            offers = uiState.offers,
                            cachedAppointments = uiState.cachedAppointments,
                            isOffline = uiState.preferences.simulateOffline,
                            onHoldOffer = viewModel::holdOffer,
                            onConfirmOffer = viewModel::confirmOffer,
                            onNoSuitableSlots = viewModel::submitNoSuitableSlots,
                            onReschedule = viewModel::rescheduleAppointment,
                            onCancel = viewModel::cancelAppointment,
                            onSwitchBackToSelf = { viewModel.switchPatientContext(null) },
                        )

                        TopTab.MEDICINES -> MedicinesScreen(
                            summary = uiState.homeSummary,
                            medicines = uiState.medicines,
                            repeatRequests = uiState.repeatRequests,
                            pendingOutbox = uiState.pendingOutbox,
                            isOffline = uiState.preferences.simulateOffline,
                            onRequestRepeat = viewModel::submitRepeatMedicine,
                            onCheckInterruptedItem = viewModel::checkInterruptedOutboxItem,
                            onContactPractice = { viewModel.selectTab(TopTab.MESSAGES) },
                            onSwitchBackToSelf = { viewModel.switchPatientContext(null) },
                        )

                        TopTab.MESSAGES -> MessagesScreen(
                            summary = uiState.homeSummary,
                            threads = uiState.threads,
                            isOffline = uiState.preferences.simulateOffline,
                            onCreateThread = viewModel::createMessageThread,
                            onReplyThread = viewModel::replyToThread,
                            onMarkRead = viewModel::markThreadRead,
                            onSwitchBackToSelf = { viewModel.switchPatientContext(null) },
                        )

                        TopTab.ACCOUNT -> AccountScreen(
                            summary = uiState.homeSummary,
                            proxies = uiState.proxies,
                            devices = uiState.devices,
                            notifications = uiState.notifications,
                            preferences = uiState.preferences,
                            isProxyMode = uiState.activePatientId != null,
                            onSwitchPatient = viewModel::switchPatientContext,
                            onUpdatePreferences = viewModel::updateCommunicationPreferences,
                            onSetReducedMotion = viewModel::setReducedMotion,
                            onSetHighContrast = viewModel::setHighContrast,
                            onSetLargeText = viewModel::setLargeText,
                            onSetBiometricUnlock = viewModel::setBiometricUnlock,
                            onLockSession = viewModel::lockLocalSession,
                            onRevokeDevice = viewModel::revokeDevice,
                            onSetSimulateOffline = viewModel::setSimulateOffline,
                            onSetSimulateInterrupted = viewModel::setSimulateInterrupted,
                            onSetBackendConfig = viewModel::setBackendConfig,
                            onSimulateExpiry = viewModel::simulateSessionExpiry,
                            onSandboxConfirmBooking = viewModel::triggerSandboxConfirmBooking,
                            onSandboxAdvanceMedicine = viewModel::triggerSandboxAdvanceMedicine,
                            onSandboxFailedNotification = viewModel::triggerSandboxFailedNotification,
                            onSendPrivacyTestNotification = onTriggerTestNotification,
                            onSignOutAndClearCache = viewModel::signOutAndClearCache,
                        )
                    }
                }
            }
        }
    }
}
