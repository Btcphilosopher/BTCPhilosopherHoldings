package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.AppPreferences
import com.example.data.model.RecoveryGuidance
import com.example.ui.components.BluePageHeader
import com.example.ui.components.FeedbackBanner
import com.example.ui.components.PrototypeNoticeStrip

@Composable
fun SignInScreen(
    isLoading: Boolean,
    errorMessage: String?,
    bannerMessage: String?,
    preferences: AppPreferences,
    recoveryGuidance: RecoveryGuidance?,
    onSignIn: (email: String, passphrase: String, code: String) -> Unit,
    onBackendConfigChange: (useLive: Boolean, url: String) -> Unit,
    onDismissMessage: () -> Unit,
) {
    var email by remember { mutableStateOf("") }
    var passphrase by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var showRecoveryDialog by remember { mutableStateOf(false) }
    var showBackendOptions by remember { mutableStateOf(false) }
    var serverUrl by remember(preferences.serverBaseUrl) { mutableStateOf(preferences.serverBaseUrl) }
    var useLive by remember(preferences.useLiveBackend) { mutableStateOf(preferences.useLiveBackend) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PrototypeNoticeStrip()
        BluePageHeader(
            title = "TERTIUSMEDICO",
            subtitle = "Patient Connect — Independent Healthcare Prototype",
        )

        Column(
            modifier = Modifier
                .widthIn(max = 580.dp)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            FeedbackBanner(message = errorMessage, isError = true, onDismiss = onDismissMessage)
            FeedbackBanner(message = bannerMessage, isError = false, onDismiss = onDismissMessage)

            // Explicitly display NO sensitive health details on Sign-In screen
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Column(modifier = Modifier.padding(start = 10.dp)) {
                        Text(
                            text = "Synthetic Identity Verification",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "This prototype uses a replaceable identity adapter and synthetic accounts. " +
                                "It does not imitate NHS login or connect to live NHS services. " +
                                "A health ID, surname, or date of birth alone cannot grant access.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text("Sign in to your account", style = MaterialTheme.typography.titleLarge)

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Registered email") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("signin_email_input"),
                    )

                    OutlinedTextField(
                        value = passphrase,
                        onValueChange = { passphrase = it },
                        label = { Text("Account passphrase") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("signin_passphrase_input"),
                    )

                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text("6-digit verification code") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("signin_code_input"),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(
                            onClick = {
                                email = "eleanor.vance@example.org"
                                passphrase = "CareConnect!2026"
                                code = "246810"
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("fill_demo_credentials_button"),
                        ) {
                            Text("Fill demo patient")
                        }
                        Button(
                            onClick = { onSignIn(email, passphrase, code) },
                            enabled = !isLoading && email.isNotBlank() && passphrase.isNotBlank() && code.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("signin_submit_button"),
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp,
                                )
                            } else {
                                Text("Sign in")
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        TextButton(onClick = { showRecoveryDialog = true }) {
                            Text("Account recovery process")
                        }
                        TextButton(onClick = { showBackendOptions = !showBackendOptions }) {
                            Text(if (showBackendOptions) "Hide connection mode" else "Backend mode")
                        }
                    }
                }
            }

            if (showBackendOptions) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("Backend Connection Mode", style = MaterialTheme.typography.titleMedium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Use Live FastAPI Server", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    "Off = On-device deterministic sandbox; On = HTTP Ktor client to FastAPI + PostgreSQL.",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                            Switch(
                                checked = useLive,
                                onCheckedChange = {
                                    useLive = it
                                    onBackendConfigChange(it, serverUrl)
                                },
                            )
                        }
                        if (useLive) {
                            OutlinedTextField(
                                value = serverUrl,
                                onValueChange = { serverUrl = it },
                                label = { Text("FastAPI Base URL") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Button(onClick = { onBackendConfigChange(useLive, serverUrl) }) {
                                Text("Save Server URL")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showRecoveryDialog) {
        AlertDialog(
            onDismissRequest = { showRecoveryDialog = false },
            title = { Text("Documented Account Recovery") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    (recoveryGuidance?.steps ?: listOf(
                        "1. Verify email and secondary recovery factor.",
                        "2. Contact Oakbridge Practice reception with photo ID for supervised reset.",
                        "3. Revoke lost devices once signed back in.",
                    )).forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text(
                        text = recoveryGuidance?.supportContact ?: "Oakbridge Reception: 0113 496 0410",
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showRecoveryDialog = false }) { Text("Close") }
            },
        )
    }
}

@Composable
fun BiometricLocalLockScreen(
    displayName: String,
    onUnlockWithBiometric: () -> Unit,
    onSignOut: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        PrototypeNoticeStrip()
        BluePageHeader(
            title = "Local Session Locked",
            subtitle = "No sensitive health details are displayed while locked.",
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = "Session locked",
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Signed in locally as $displayName",
                style = MaterialTheme.typography.titleLarge,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Device biometrics or PIN unlock this device's saved session only. They do not verify clinical identity.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onUnlockWithBiometric,
                modifier = Modifier.fillMaxWidth().widthIn(max = 360.dp),
            ) {
                Icon(Icons.Filled.Fingerprint, contentDescription = null)
                Text(" Unlock local session", modifier = Modifier.padding(start = 8.dp))
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier.fillMaxWidth().widthIn(max = 360.dp),
            ) {
                Text("Sign out & clear cache")
            }
        }
    }
}
