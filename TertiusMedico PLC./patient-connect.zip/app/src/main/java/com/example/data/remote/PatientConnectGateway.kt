package com.example.data.remote

import com.example.data.model.AppointmentDto
import com.example.data.model.AppointmentOfferDto
import com.example.data.model.AuthSession
import com.example.data.model.CareTaskDto
import com.example.data.model.ClinicalRecordDto
import com.example.data.model.CompleteTaskBody
import com.example.data.model.CorrectionRequestDto
import com.example.data.model.CreateCorrectionBody
import com.example.data.model.CreateMedicineRequestBody
import com.example.data.model.CreateThreadBody
import com.example.data.model.HoldOrConfirmBody
import com.example.data.model.HomeSummaryDto
import com.example.data.model.LoginRequest
import com.example.data.model.MedicineRecordDto
import com.example.data.model.MessageThreadDto
import com.example.data.model.NoSlotAssistBody
import com.example.data.model.NotificationDispatchDto
import com.example.data.model.PatientProfileDto
import com.example.data.model.PreferencesUpdateBody
import com.example.data.model.ProxyGrantDto
import com.example.data.model.RecordDocumentDto
import com.example.data.model.RecoveryGuidance
import com.example.data.model.RepeatMedicineRequestDto
import com.example.data.model.ReplyThreadBody
import com.example.data.model.RescheduleBody
import com.example.data.model.TrustedDeviceDto

class ApiException(val statusCode: Int, override val message: String) : Exception(message)

interface PatientConnectGateway {
    // Identity & Session
    suspend fun login(request: LoginRequest): AuthSession
    suspend fun logout(token: String)
    suspend fun getDevices(token: String): List<TrustedDeviceDto>
    suspend fun revokeDevice(token: String, deviceId: String)
    suspend fun getRecoveryGuidance(): RecoveryGuidance

    // Home, Profile & Proxy
    suspend fun getHomeSummary(token: String, patientId: String?): HomeSummaryDto
    suspend fun getProxies(token: String): List<ProxyGrantDto>
    suspend fun updatePreferences(token: String, patientId: String?, body: PreferencesUpdateBody): PatientProfileDto
    suspend fun getNotifications(token: String, patientId: String?): List<NotificationDispatchDto>

    // Appointments
    suspend fun getAppointments(token: String, patientId: String?): List<AppointmentDto>
    suspend fun getOffers(token: String, patientId: String?): List<AppointmentOfferDto>
    suspend fun holdOffer(token: String, patientId: String?, offerId: String, body: HoldOrConfirmBody): AppointmentOfferDto
    suspend fun confirmOffer(token: String, patientId: String?, offerId: String, body: HoldOrConfirmBody): AppointmentDto
    suspend fun requestNoSuitableSlots(token: String, patientId: String?, body: NoSlotAssistBody)
    suspend fun rescheduleAppointment(token: String, patientId: String?, appointmentId: String, body: RescheduleBody): AppointmentDto
    suspend fun cancelAppointment(token: String, patientId: String?, appointmentId: String): AppointmentDto

    // Medicines
    suspend fun getMedicines(token: String, patientId: String?): List<MedicineRecordDto>
    suspend fun getRepeatRequests(token: String, patientId: String?): List<RepeatMedicineRequestDto>
    suspend fun getRepeatRequestByKey(token: String, patientId: String?, idempotencyKey: String): RepeatMedicineRequestDto?
    suspend fun submitRepeatRequest(token: String, patientId: String?, body: CreateMedicineRequestBody): RepeatMedicineRequestDto

    // Health Records
    suspend fun getReleasedRecords(token: String, patientId: String?): List<ClinicalRecordDto>
    suspend fun getRecordDocument(token: String, patientId: String?, recordId: String): RecordDocumentDto
    suspend fun getCorrections(token: String, patientId: String?): List<CorrectionRequestDto>
    suspend fun submitCorrection(token: String, patientId: String?, body: CreateCorrectionBody): CorrectionRequestDto

    // Messages & Care Tasks
    suspend fun getMessageThreads(token: String, patientId: String?): List<MessageThreadDto>
    suspend fun createThread(token: String, patientId: String?, body: CreateThreadBody): MessageThreadDto
    suspend fun replyThread(token: String, patientId: String?, threadId: String, body: ReplyThreadBody): MessageThreadDto
    suspend fun markThreadRead(token: String, patientId: String?, threadId: String): MessageThreadDto
    suspend fun getCareTasks(token: String, patientId: String?): List<CareTaskDto>
    suspend fun completeCareTask(token: String, patientId: String?, taskId: String, body: CompleteTaskBody): CareTaskDto

    // Sandbox-only Staff Demonstration Helpers (no-op in live server mode since Staff Console is separate)
    suspend fun simulateStaffConfirmNextBooking(patientId: String?): String?
    suspend fun simulateStaffAdvanceLatestMedicine(patientId: String?, approve: Boolean): String?
    suspend fun simulateStaffFailedNotification(patientId: String?): String?
}
