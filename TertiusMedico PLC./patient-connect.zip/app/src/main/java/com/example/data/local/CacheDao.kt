package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CacheDao {
    @Query("SELECT * FROM cached_summaries WHERE patientId = :patientId LIMIT 1")
    fun observeSummary(patientId: String): Flow<CachedSummaryEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSummary(summary: CachedSummaryEntity)

    @Query("SELECT * FROM cached_appointments WHERE patientId = :patientId ORDER BY startsAtLondon ASC")
    fun observeAppointments(patientId: String): Flow<List<CachedAppointmentEntity>>

    @Query("DELETE FROM cached_appointments WHERE patientId = :patientId")
    suspend fun deleteAppointmentsForPatient(patientId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppointments(items: List<CachedAppointmentEntity>)

    @Query("SELECT * FROM pending_outbox_actions WHERE patientId = :patientId ORDER BY createdAtIso DESC")
    fun observeOutboxActions(patientId: String): Flow<List<PendingOutboxActionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOutboxAction(action: PendingOutboxActionEntity)

    @Query("DELETE FROM pending_outbox_actions WHERE idempotencyKey = :key")
    suspend fun deleteOutboxAction(key: String)

    @Query("DELETE FROM cached_summaries")
    suspend fun clearSummaries()

    @Query("DELETE FROM cached_appointments")
    suspend fun clearAppointments()

    @Query("DELETE FROM pending_outbox_actions")
    suspend fun clearOutbox()
}
