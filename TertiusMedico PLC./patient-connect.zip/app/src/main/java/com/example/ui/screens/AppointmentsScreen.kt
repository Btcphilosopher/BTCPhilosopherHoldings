package com.example.ui.screens

import android.content.Intent
import android.provider.CalendarContract
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.CachedAppointmentEntity
import com.example.data.model.AppointmentDto
import com.example.data.model.AppointmentOfferDto
import com.example.data.model.HomeSummaryDto
import com.example.ui.components.BluePageHeader
import com.example.ui.components.OfflineCacheBanner
import com.example.ui.components.ProxyAccountBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.util.LondonTimeFormatter

@Composable
fun AppointmentsScreen(
    summary: HomeSummaryDto?,
    appointments: List<AppointmentDto>,
    offers: List<AppointmentOfferDto>,
    cachedAppointments: List<CachedAppointmentEntity>,
    isOffline: Boolean,
    onHoldOffer: (String) -> Unit,
    onConfirmOffer: (String) -> Unit,
    onNoSuitableSlots: (preferredDays: String, reason: String) -> Unit,
    onReschedule: (appointmentId: String, window: String, reason: String) -> Unit,
    onCancel: (String) -> Unit,
    onSwitchBackToSelf: () -> Unit,
) {
    val context = LocalContext.current
    var showNoSlotDialog by remember { mutableStateOf(false) }
    var rescheduleTarget by remember { mutableStateOf<AppointmentDto?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        BluePageHeader(
            title = "Appointments",
            subtitle = "Times shown in Europe/London (GMT/BST). Booking requests await provider confirmation.",
        )

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (summary?.activeProxyGrant != null) {
                ProxyAccountBanner(
                    patientName = summary.activePatient.fullName,
                    restrictions = summary.activeProxyGrant.restrictionsSummary,
                    onSwitchBack = onSwitchBackToSelf,
                )
            }

            if (isOffline) {
                OfflineCacheBanner(
                    cachedAtLabel = LondonTimeFormatter.formatShortTimestamp(
                        cachedAppointments.firstOrNull()?.cachedAtIso ?: summary?.lastSyncedAt.orEmpty()
                    )
                )
            }

            if (!isOffline) {
                SectionHeader("Eligible booking offers")
                if (offers.isEmpty()) {
                    Text("No eligible booking offers are open right now.")
                } else {
                    offers.forEach { offer ->
                        OfferCard(
                            offer = offer,
                            onHold = { onHoldOffer(offer.id) },
                            onConfirm = { onConfirmOffer(offer.id) },
                            onContactBookingTeam = { showNoSlotDialog = true },
                        )
                    }
                }

                OutlinedButton(
                    onClick = { showNoSlotDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("no_suitable_slots_button"),
                ) {
                    Text("None of these slots suit me — ask the booking team")
                }
            }

            SectionHeader("Upcoming & past appointments")
            val displayAppointments = if (isOffline && cachedAppointments.isNotEmpty()) {
                cachedAppointments.map {
                    AppointmentDto(
                        id = it.id,
                        patientId = it.patientId,
                        orgId = "",
                        orgName = it.orgName,
                        orgPhone = it.orgPhone,
                        serviceName = it.serviceName,
                        clinicianName = it.clinicianName,
                        location = it.location,
                        format = it.format,
                        startsAtLondon = it.startsAtLondon,
                        endsAtLondon = it.endsAtLondon,
                        preparationInstructions = it.preparationInstructions,
                        status = it.status,
                        canCancel = false,
                        sourceSystem = it.orgName,
                        updatedAt = it.cachedAtIso,
                    )
                }
            } else {
                appointments
            }

            displayAppointments.forEach { appt ->
                AppointmentCard(
                    appointment = appt,
                    isOffline = isOffline,
                    onAddToCalendar = {
                        val intent = Intent(Intent.ACTION_INSERT).apply {
                            data = CalendarContract.Events.CONTENT_URI
                            putExtra(CalendarContract.Events.TITLE, "${appt.serviceName} (${appt.clinicianName})")
                            putExtra(CalendarContract.Events.EVENT_LOCATION, appt.location)
                            putExtra(CalendarContract.Events.DESCRIPTION, appt.preparationInstructions)
                            putExtra(
                                CalendarContract.EXTRA_EVENT_BEGIN_TIME,
                                LondonTimeFormatter.toEpochMillis(appt.startsAtLondon),
                            )
                            putExtra(
                                CalendarContract.EXTRA_EVENT_END_TIME,
                                LondonTimeFormatter.toEpochMillis(appt.endsAtLondon),
                            )
                        }
                        runCatching { context.startActivity(intent) }
                    },
                    onReschedule = { rescheduleTarget = appt },
                    onCancel = { onCancel(appt.id) },
                )
            }
        }
    }

    if (showNoSlotDialog) {
        var days by remember { mutableStateOf("Weekday mornings after 09:30") }
        var reason by remember { mutableStateOf("Work or carer transport commitments") }
        AlertDialog(
            onDismissRequest = { showNoSlotDialog = false },
            title = { Text("Request staff-assisted booking") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Your referral request stays preserved while our booking team arranges an alternative time.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedTextField(
                        value = days,
                        onValueChange = { days = it },
                        label = { Text("Preferred days or times") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Notes for booking team") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onNoSuitableSlots(days, reason)
                        showNoSlotDialog = false
                    }
                ) {
                    Text("Send request")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showNoSlotDialog = false }) { Text("Cancel") }
            },
        )
    }

    rescheduleTarget?.let { target ->
        var window by remember { mutableStateOf("Next available morning") }
        var reason by remember { mutableStateOf("Need an alternative date") }
        AlertDialog(
            onDismissRequest = { rescheduleTarget = null },
            title = { Text("Request rescheduling") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(target.serviceName, style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = window,
                        onValueChange = { window = it },
                        label = { Text("Preferred window") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Reason") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onReschedule(target.id, window, reason)
                    rescheduleTarget = null
                }) {
                    Text("Submit request")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { rescheduleTarget = null }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun OfferCard(
    offer: AppointmentOfferDto,
    onHold: () -> Unit,
    onConfirm: () -> Unit,
    onContactBookingTeam: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("offer_card_${offer.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            StatusPill(offer.status)
            Text(offer.serviceName, style = MaterialTheme.typography.titleLarge)
            Text(
                LondonTimeFormatter.formatLondonDateTime(offer.startsAtLondon),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            Text("${offer.clinicianName} · ${offer.format.replace('_', ' ')}")
            Text(offer.location, style = MaterialTheme.typography.bodyMedium)
            Text("Rule match: ${offer.referralRuleNote}", style = MaterialTheme.typography.labelMedium)
            Text("Preparation: ${offer.preparationInstructions}", style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (offer.status == "OFFER_AVAILABLE") {
                    OutlinedButton(
                        onClick = onHold,
                        modifier = Modifier.testTag("hold_offer_${offer.id}"),
                    ) {
                        Text("Hold slot (5m)")
                    }
                    Button(
                        onClick = onConfirm,
                        modifier = Modifier.testTag("confirm_offer_${offer.id}"),
                    ) {
                        Text("Request slot")
                    }
                } else if (offer.status == "SLOT_HELD") {
                    Button(
                        onClick = onConfirm,
                        modifier = Modifier.testTag("confirm_offer_${offer.id}"),
                    ) {
                        Text("Confirm held slot")
                    }
                } else if (offer.status == "UNAVAILABLE") {
                    OutlinedButton(
                        onClick = onConfirm,
                        modifier = Modifier.testTag("test_unavailable_offer_${offer.id}"),
                    ) {
                        Text("Try slot (conflict demo)")
                    }
                    OutlinedButton(onClick = onContactBookingTeam) {
                        Text("Contact team")
                    }
                }
            }
        }
    }
}

@Composable
private fun AppointmentCard(
    appointment: AppointmentDto,
    isOffline: Boolean,
    onAddToCalendar: () -> Unit,
    onReschedule: () -> Unit,
    onCancel: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("appointment_card_${appointment.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            StatusPill(appointment.status)
            Text(appointment.serviceName, style = MaterialTheme.typography.titleLarge)
            Text(
                LondonTimeFormatter.formatLondonDateTime(appointment.startsAtLondon),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            Text("${appointment.clinicianName} · ${appointment.format.replace('_', ' ')}")
            Text(appointment.location, style = MaterialTheme.typography.bodyMedium)
            Text("Preparation: ${appointment.preparationInstructions}", style = MaterialTheme.typography.bodyMedium)
            Text("Source: ${appointment.sourceSystem}", style = MaterialTheme.typography.labelMedium)

            if (appointment.orgPhone.isNotBlank()) {
                Row {
                    Icon(Icons.Filled.Phone, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Booking team: ${appointment.orgPhone}", style = MaterialTheme.typography.bodyMedium)
                }
            }

            appointment.rescheduleNote?.let {
                Text("Note: $it", style = MaterialTheme.typography.bodyMedium)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (appointment.status == "BOOKING_CONFIRMED") {
                    Button(
                        onClick = onAddToCalendar,
                        modifier = Modifier.testTag("add_to_calendar_${appointment.id}"),
                    ) {
                        Icon(Icons.Filled.EventAvailable, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add to calendar")
                    }
                }
                if (!isOffline && appointment.status in listOf("BOOKING_CONFIRMED", "BOOKING_REQUESTED")) {
                    OutlinedButton(onClick = onReschedule) {
                        Icon(Icons.Filled.CalendarToday, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Reschedule")
                    }
                    if (appointment.canCancel) {
                        OutlinedButton(onClick = onCancel) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }
    }
}
