package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.local.CachedAppointmentEntity
import com.example.data.local.CachedSummaryEntity
import com.example.data.local.PendingOutboxActionEntity
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.AppointmentDto
import com.example.data.model.AppointmentOfferDto
import com.example.data.model.AuthSession
import com.example.data.model.CareTaskDto
import com.example.data.model.ClinicalRecordDto
import com.example.data.model.CompleteTaskBody
import com.example.data.model.CorrectionRequestDto
import com.example.data.model.CreateCorrectionBody
import com.example.data.model.CreateThreadBody
import com.example.data.model.HoldOrConfirmBody
import com.example.data.model.HomeSummaryDto
import com.example.data.model.LoginRequest
import com.example.data.model.MedicineRecordDto
import com.example.data.model.MessageThreadDto
import com.example.data.model.NoSlotAssistBody
import com.example.data.model.NotificationDispatchDto
import com.example.data.model.PreferencesUpdateBody
import com.example.data.model.ProxyGrantDto
import com.example.data.model.RecordDocumentDto
import com.example.data.model.RecoveryGuidance
import com.example.data.model.RepeatMedicineRequestDto
import com.example.data.model.ReplyThreadBody
import com.example.data.model.RescheduleBody
import com.example.data.model.TrustedDeviceDto
import com.example.data.remote.ApiException
import com.example.data.repository.InterruptedConnectionException
import com.example.data.repository.OfflineBlockedException
import com.example.data.repository.PatientConnectRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class TopTab {
    HOME,
    APPOINTMENTS,
    MEDICINES,
    MESSAGES,
    ACCOUNT,
}

enum class SubScreen {
    NONE,
    RECORDS,
    CARE_TASKS,
}

data class MainUiState(
    val session: AuthSession? = null,
    val sessionLockedByBiometricGate: Boolean = false,
    val activePatientId: String? = null, // null = own account; non-null = verified proxy patient
    val selectedTab: TopTab = TopTab.HOME,
    val subScreen: SubScreen = SubScreen.NONE,
    val isLoading: Boolean = false,
    val bannerMessage: String? = null,
    val errorMessage: String? = null,
    val preferences: AppPreferences = AppPreferences(),
    val recoveryGuidance: RecoveryGuidance? = null,
    val homeSummary: HomeSummaryDto? = null,
    val proxies: List<ProxyGrantDto> = emptyList(),
    val appointments: List<AppointmentDto> = emptyList(),
    val offers: List<AppointmentOfferDto> = emptyList(),
    val medicines: List<MedicineRecordDto> = emptyList(),
    val repeatRequests: List<RepeatMedicineRequestDto> = emptyList(),
    val records: List<ClinicalRecordDto> = emptyList(),
    val selectedDocument: RecordDocumentDto? = null,
    val corrections: List<CorrectionRequestDto> = emptyList(),
    val threads: List<MessageThreadDto> = emptyList(),
    val careTasks: List<CareTaskDto> = emptyList(),
    val devices: List<TrustedDeviceDto> = emptyList(),
    val notifications: List<NotificationDispatchDto> = emptyList(),
    val cachedSummary: CachedSummaryEntity? = null,
    val cachedAppointments: List<CachedAppointmentEntity> = emptyList(),
    val pendingOutbox: List<PendingOutboxActionEntity> = emptyList(),
)

class MainViewModel(
    private val repository: PatientConnectRepository,
    private val prefsRepo: UserPreferencesRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.preferences.collectLatest { prefs ->
                _uiState.update { it.copy(preferences = prefs) }
            }
        }
        observeCacheForPatient("pat_eleanor_01")
        loadRecoveryGuidance()
    }

    private fun observeCacheForPatient(patientId: String) {
        viewModelScope.launch {
            repository.observeCachedSummary(patientId).collectLatest { summary ->
                _uiState.update { it.copy(cachedSummary = summary) }
            }
        }
        viewModelScope.launch {
            repository.observeCachedAppointments(patientId).collectLatest { appts ->
                _uiState.update { it.copy(cachedAppointments = appts) }
            }
        }
        viewModelScope.launch {
            repository.observePendingOutbox(patientId).collectLatest { outbox ->
                _uiState.update { it.copy(pendingOutbox = outbox) }
            }
        }
    }

    private fun loadRecoveryGuidance() {
        viewModelScope.launch {
            runCatching { repository.currentGateway().getRecoveryGuidance() }
                .onSuccess { g -> _uiState.update { it.copy(recoveryGuidance = g) } }
        }
    }

    fun clearNotices() {
        _uiState.update { it.copy(bannerMessage = null, errorMessage = null) }
    }

    fun selectTab(tab: TopTab) {
        _uiState.update { it.copy(selectedTab = tab, subScreen = SubScreen.NONE) }
    }

    fun openSubScreen(screen: SubScreen) {
        _uiState.update { it.copy(subScreen = screen) }
    }

    fun closeSubScreen() {
        _uiState.update { it.copy(subScreen = SubScreen.NONE) }
    }

    fun signIn(email: String, passphrase: String, code: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
            try {
                repository.requireOnline("sign in")
                val session = repository.currentGateway().login(
                    LoginRequest(
                        email = email.trim(),
                        passphrase = passphrase,
                        verificationCode = code.trim(),
                    )
                )
                _uiState.update {
                    it.copy(
                        session = session,
                        sessionLockedByBiometricGate = false,
                        activePatientId = null,
                        selectedTab = TopTab.HOME,
                        subScreen = SubScreen.NONE,
                    )
                }
                refreshAllData()
            } catch (e: Exception) {
                handleException(e)
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun lockLocalSession() {
        if (_uiState.value.session != null && _uiState.value.preferences.biometricUnlockEnabled) {
            _uiState.update {
                it.copy(
                    sessionLockedByBiometricGate = true,
                    bannerMessage = "Local session locked. Use device biometric/PIN to unlock this device session.",
                )
            }
        }
    }

    fun unlockLocalSession() {
        _uiState.update {
            it.copy(
                sessionLockedByBiometricGate = false,
                bannerMessage = "Local device session unlocked (note: device biometrics do not re-verify clinical identity).",
            )
        }
    }

    fun simulateSessionExpiry() {
        viewModelScope.launch {
            repository.clearSensitiveCache()
            _uiState.update {
                MainUiState(
                    preferences = it.preferences,
                    recoveryGuidance = it.recoveryGuidance,
                    errorMessage = "Your session expired after inactivity for your safety. Local cache cleared. Please sign in again.",
                )
            }
        }
    }

    fun signOutAndClearCache() {
        viewModelScope.launch {
            val token = _uiState.value.session?.accessToken
            if (token != null) {
                runCatching { repository.currentGateway().logout(token) }
            }
            repository.clearSensitiveCache()
            _uiState.update {
                MainUiState(
                    preferences = it.preferences,
                    recoveryGuidance = it.recoveryGuidance,
                    bannerMessage = "Signed out and cleared sensitive local cache.",
                )
            }
        }
    }

    fun switchPatientContext(patientId: String?) {
        viewModelScope.launch {
            val token = _uiState.value.session?.accessToken ?: return@launch
            _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
            try {
                repository.requireOnline("switch patient account")
                // Verify target access before switching state
                val summary = repository.currentGateway().getHomeSummary(token, patientId)
                _uiState.update {
                    it.copy(
                        activePatientId = patientId,
                        homeSummary = summary,
                        records = emptyList(),
                        corrections = emptyList(),
                        bannerMessage = if (patientId != null) {
                            "Switched to proxy view for ${summary.activePatient.fullName}. Restrictions apply."
                        } else {
                            "Returned to your own account (${summary.activePatient.fullName})."
                        },
                    )
                }
                observeCacheForPatient(summary.activePatient.id)
                refreshAllData()
            } catch (e: Exception) {
                handleException(e)
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun refreshAllData() {
        viewModelScope.launch {
            val token = _uiState.value.session?.accessToken ?: return@launch
            val patientId = _uiState.value.activePatientId
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                if (_uiState.value.preferences.simulateOffline) {
                    _uiState.update {
                        it.copy(
                            bannerMessage = "Offline mode active — showing explicitly cached appointments and contacts with timestamps.",
                        )
                    }
                    return@launch
                }
                val gw = repository.currentGateway()
                val home = gw.getHomeSummary(token, patientId)
                val proxies = gw.getProxies(token)
                val appts = gw.getAppointments(token, patientId)
                val offers = gw.getOffers(token, patientId)
                val meds = gw.getMedicines(token, patientId)
                val medReqs = gw.getRepeatRequests(token, patientId)
                val threads = gw.getMessageThreads(token, patientId)
                val tasks = runCatching { gw.getCareTasks(token, patientId) }.getOrDefault(emptyList())
                val records = runCatching { gw.getReleasedRecords(token, patientId) }.getOrDefault(emptyList())
                val corrections = runCatching { gw.getCorrections(token, patientId) }.getOrDefault(emptyList())
                val devices = gw.getDevices(token)
                val notifs = gw.getNotifications(token, patientId)

                repository.cacheMinimalHomeAndAppointments(home, appts)

                _uiState.update {
                    it.copy(
                        homeSummary = home,
                        proxies = proxies,
                        appointments = appts,
                        offers = offers,
                        medicines = meds,
                        repeatRequests = medReqs,
                        threads = threads,
                        careTasks = tasks,
                        records = records,
                        corrections = corrections,
                        devices = devices,
                        notifications = notifs,
                    )
                }
            } catch (e: Exception) {
                handleException(e)
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun holdOffer(offerId: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("hold appointment slot") {
                val held = repository.currentGateway().holdOffer(
                    token, pid, offerId, HoldOrConfirmBody(UUID.randomUUID().toString())
                )
                refreshAllData()
                _uiState.update {
                    it.copy(bannerMessage = "Slot held for 5 minutes (${held.serviceName}). Confirm before the hold expires.")
                }
            }
        }
    }

    fun confirmOffer(offerId: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("confirm appointment booking") {
                val appt = repository.currentGateway().confirmOffer(
                    token, pid, offerId, HoldOrConfirmBody(UUID.randomUUID().toString())
                )
                refreshAllData()
                _uiState.update {
                    it.copy(bannerMessage = "Booking request sent (${appt.status}). Confirmation from the booking team will appear once processed.")
                }
            }
        }
    }

    fun submitNoSuitableSlots(preferredDays: String, reason: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("send booking assistance request") {
                repository.currentGateway().requestNoSuitableSlots(
                    token, pid, NoSlotAssistBody(UUID.randomUUID().toString(), preferredDays, reason)
                )
                refreshAllData()
                _uiState.update {
                    it.copy(bannerMessage = "Your request has been preserved and sent to the booking team. Check Messages for updates.")
                }
            }
        }
    }

    fun rescheduleAppointment(appointmentId: String, window: String, reason: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("request rescheduling") {
                repository.currentGateway().rescheduleAppointment(
                    token, pid, appointmentId, RescheduleBody(reason, window)
                )
                refreshAllData()
                _uiState.update { it.copy(bannerMessage = "Reschedule request submitted (CHANGE_REQUESTED).") }
            }
        }
    }

    fun cancelAppointment(appointmentId: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("cancel appointment") {
                repository.currentGateway().cancelAppointment(token, pid, appointmentId)
                refreshAllData()
                _uiState.update { it.copy(bannerMessage = "Appointment cancelled.") }
            }
        }
    }

    fun submitRepeatMedicine(medicine: MedicineRecordDto, pharmacyName: String, note: String?) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
            try {
                val created = repository.submitRepeatMedicineWithIdempotency(
                    token = token,
                    patientId = pid,
                    medicineId = medicine.id,
                    medicineName = medicine.nameFormulation,
                    preferredPharmacy = pharmacyName,
                    patientNote = note?.takeIf { it.isNotBlank() },
                )
                refreshAllData()
                _uiState.update {
                    it.copy(
                        bannerMessage = "Request received for ${created.medicineName} (Stage: ${created.stage}). This is awaiting practice review and is not yet a signed prescription.",
                    )
                }
            } catch (e: Exception) {
                handleException(e)
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun checkInterruptedOutboxItem(item: PendingOutboxActionEntity) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("verify interrupted request status") {
                val found = repository.verifyInterruptedMedicineAction(token, pid, item)
                refreshAllData()
                _uiState.update {
                    it.copy(
                        bannerMessage = if (found != null) {
                            "Recovered status safely (no duplicate created): ${found.medicineName} is ${found.stage}."
                        } else {
                            "Request was not received by the practice. You can safely submit it again now."
                        }
                    )
                }
            }
        }
    }

    fun openRecordDocument(recordId: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("view released document") {
                val doc = repository.currentGateway().getRecordDocument(token, pid, recordId)
                _uiState.update { it.copy(selectedDocument = doc) }
            }
        }
    }

    fun closeRecordDocument() {
        _uiState.update { it.copy(selectedDocument = null) }
    }

    fun submitCorrection(recordId: String, requestedChange: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("submit correction request") {
                repository.currentGateway().submitCorrection(
                    token, pid, CreateCorrectionBody(recordId, requestedChange)
                )
                refreshAllData()
                _uiState.update {
                    it.copy(bannerMessage = "Correction request sent to your care provider for clinical review.")
                }
            }
        }
    }

    fun createMessageThread(orgId: String, category: String, subject: String, body: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("send structured message") {
                repository.currentGateway().createThread(
                    token, pid, CreateThreadBody(orgId, category, subject, body, UUID.randomUUID().toString())
                )
                refreshAllData()
                _uiState.update {
                    it.copy(bannerMessage = "Message delivered to the service. Delivery does not mean a clinician has reviewed it yet.")
                }
            }
        }
    }

    fun replyToThread(threadId: String, body: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("send reply") {
                repository.currentGateway().replyThread(token, pid, threadId, ReplyThreadBody(body))
                refreshAllData()
                _uiState.update { it.copy(bannerMessage = "Reply delivered to care team.") }
            }
        }
    }

    fun markThreadRead(threadId: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runCatching {
                repository.requireOnline("mark message as read")
                repository.currentGateway().markThreadRead(token, pid, threadId)
                refreshAllData()
            }
        }
    }

    fun completeCareTask(taskId: String, summary: String, measurement: String?) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("submit care task") {
                repository.currentGateway().completeCareTask(
                    token, pid, taskId, CompleteTaskBody(summary, measurement?.takeIf { it.isNotBlank() })
                )
                refreshAllData()
                _uiState.update {
                    it.copy(bannerMessage = "Task submitted with source tagged as 'Patient-entered (unverified)'.")
                }
            }
        }
    }

    fun updateCommunicationPreferences(commPref: String, interpreter: String, accessibleFmt: String) {
        val token = _uiState.value.session?.accessToken ?: return
        val pid = _uiState.value.activePatientId
        viewModelScope.launch {
            runAction("update communication preferences") {
                repository.currentGateway().updatePreferences(
                    token, pid, PreferencesUpdateBody(commPref, interpreter, accessibleFmt)
                )
                refreshAllData()
                _uiState.update { it.copy(bannerMessage = "Communication and accessibility preferences saved.") }
            }
        }
    }

    fun revokeDevice(deviceId: String) {
        val token = _uiState.value.session?.accessToken ?: return
        viewModelScope.launch {
            runAction("revoke device") {
                repository.currentGateway().revokeDevice(token, deviceId)
                if (deviceId == _uiState.value.session?.deviceId) {
                    signOutAndClearCache()
                } else {
                    refreshAllData()
                    _uiState.update { it.copy(bannerMessage = "Device revoked.") }
                }
            }
        }
    }

    // DataStore accessibility & simulation toggles
    fun setReducedMotion(enabled: Boolean) = viewModelScope.launch { prefsRepo.setReducedMotion(enabled) }
    fun setHighContrast(enabled: Boolean) = viewModelScope.launch { prefsRepo.setHighContrast(enabled) }
    fun setLargeText(enabled: Boolean) = viewModelScope.launch { prefsRepo.setLargeText(enabled) }
    fun setBiometricUnlock(enabled: Boolean) = viewModelScope.launch { prefsRepo.setBiometricUnlockEnabled(enabled) }
    fun setBackendConfig(useLive: Boolean, url: String) = viewModelScope.launch {
        prefsRepo.setBackendConfig(useLive, url)
    }
    fun setSimulateOffline(offline: Boolean) = viewModelScope.launch {
        prefsRepo.setSimulateOffline(offline)
        if (!offline && _uiState.value.session != null) {
            refreshAllData()
        }
    }
    fun setSimulateInterrupted(interrupted: Boolean) = viewModelScope.launch {
        prefsRepo.setSimulateInterruptedConnection(interrupted)
    }

    // Sandbox Staff Demonstration Helpers
    fun triggerSandboxConfirmBooking() = viewModelScope.launch {
        val msg = repository.currentGateway().simulateStaffConfirmNextBooking(_uiState.value.activePatientId)
        refreshAllData()
        _uiState.update { it.copy(bannerMessage = msg) }
    }

    fun triggerSandboxAdvanceMedicine(approve: Boolean) = viewModelScope.launch {
        val msg = repository.currentGateway().simulateStaffAdvanceLatestMedicine(_uiState.value.activePatientId, approve)
        refreshAllData()
        _uiState.update { it.copy(bannerMessage = msg) }
    }

    fun triggerSandboxFailedNotification() = viewModelScope.launch {
        val msg = repository.currentGateway().simulateStaffFailedNotification(_uiState.value.activePatientId)
        refreshAllData()
        _uiState.update { it.copy(bannerMessage = msg) }
    }

    private suspend fun runAction(label: String, block: suspend () -> Unit) {
        _uiState.update { it.copy(isLoading = true, errorMessage = null, bannerMessage = null) }
        try {
            repository.requireOnline(label)
            block()
        } catch (e: Exception) {
            handleException(e)
        } finally {
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    private fun handleException(e: Exception) {
        when (e) {
            is OfflineBlockedException -> _uiState.update { it.copy(errorMessage = e.message) }
            is InterruptedConnectionException -> _uiState.update { it.copy(errorMessage = e.message) }
            is ApiException -> {
                if (e.statusCode == 401 && _uiState.value.session != null) {
                    simulateSessionExpiry()
                } else {
                    _uiState.update { it.copy(errorMessage = e.message) }
                }
            }
            else -> _uiState.update {
                it.copy(errorMessage = e.message ?: "Unable to connect. Check your connection or backend settings.")
            }
        }
    }

    class Factory(
        private val repository: PatientConnectRepository,
        private val prefsRepo: UserPreferencesRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository, prefsRepo) as T
        }
    }
}
