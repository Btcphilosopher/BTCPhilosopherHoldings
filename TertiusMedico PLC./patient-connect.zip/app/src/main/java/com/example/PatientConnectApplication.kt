package com.example

import android.app.Application
import androidx.work.Configuration
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferencesRepository
import com.example.data.repository.PatientConnectRepository
import com.example.notifications.PrivacyNotificationHelper
import com.example.worker.SyncWorker

class PatientConnectApplication : Application(), Configuration.Provider {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val preferencesRepository: UserPreferencesRepository by lazy { UserPreferencesRepository(this) }
    val repository: PatientConnectRepository by lazy {
        PatientConnectRepository(database, preferencesRepository)
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().build()

    override fun onCreate() {
        super.onCreate()
        PrivacyNotificationHelper.ensureChannel(this)
        runCatching { SyncWorker.schedule(this) }
    }
}
