package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ClinicalRecordDto
import com.example.data.model.CorrectionRequestDto
import com.example.data.model.HomeSummaryDto
import com.example.data.model.RecordDocumentDto
import com.example.ui.components.BluePageHeader
import com.example.ui.components.ProxyAccountBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.StatusPendingBg
import com.example.ui.theme.StatusPendingFg
import com.example.util.LondonTimeFormatter

@Composable
fun RecordsScreen(
    summary: HomeSummaryDto?,
    records: List<ClinicalRecordDto>,
    corrections: List<CorrectionRequestDto>,
    selectedDocument: RecordDocumentDto?,
    isOffline: Boolean,
    onBack: () -> Unit,
    onOpenDocument: (String) -> Unit,
    onCloseDocument: () -> Unit,
    onSubmitCorrection: (recordId: String, requestedChange: String) -> Unit,
    onSwitchBackToSelf: () -> Unit,
) {
    BackHandler(onBack = onBack)

    var filterCategory by remember { mutableStateOf("ALL") }
    var correctionTarget by remember { mutableStateOf<ClinicalRecordDto?>(null) }
    val proxyBlocked = summary?.activeProxyGrant?.permissions?.contains("records:read") == false
    val categories = listOf("ALL", "CONSULTATION", "ALLERGY", "DIAGNOSIS", "IMMUNISATION", "LETTER", "RESULT")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        BluePageHeader(
            title = "Health Records",
            subtitle = "Only clinician-released records appear here. Patients cannot overwrite clinical entries.",
        )

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("records_back_button"),
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Home")
                }
                Text("Back to Home", style = MaterialTheme.typography.titleMedium)
            }

            if (summary?.activeProxyGrant != null) {
                ProxyAccountBanner(
                    patientName = summary.activePatient.fullName,
                    restrictions = summary.activeProxyGrant.restrictionsSummary,
                    onSwitchBack = onSwitchBackToSelf,
                )
            }

            // Explicit allergy non-confirmation safeguard
            val allergyState = summary?.activePatient?.allergyConfirmationState
            if (allergyState == "NOT_CONFIRMED") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
                    border = BorderStroke(1.5.dp, StatusPendingFg),
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Filled.Warning, contentDescription = "Allergy confirmation notice", tint = StatusPendingFg)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Allergies: Information not yet confirmed on record. Missing allergy entries do NOT mean 'no known allergies'.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StatusPendingFg,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }

            if (proxyBlocked) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
                    border = BorderStroke(1.dp, StatusPendingFg),
                ) {
                    Text(
                        "Full clinical records, letters, and results are restricted in this proxy view (${summary?.activeProxyGrant?.restrictionsSummary}).",
                        style = MaterialTheme.typography.bodyLarge,
                        color = StatusPendingFg,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            } else if (isOffline) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
                    border = BorderStroke(1.dp, StatusPendingFg),
                ) {
                    Text(
                        "Complete health records are not cached offline by default for your privacy. Reconnect to read released records.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = StatusPendingFg,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            } else {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = filterCategory == cat,
                            onClick = { filterCategory = cat },
                            label = { Text(if (cat == "ALL") "All" else cat.lowercase().replaceFirstChar { it.uppercase() }) },
                        )
                    }
                }

                val filtered = if (filterCategory == "ALL") records else records.filter { it.category == filterCategory }
                filtered.forEach { rec ->
                    RecordEntryCard(
                        record = rec,
                        onViewDocument = { onOpenDocument(rec.id) },
                        onRequestCorrection = { correctionTarget = rec },
                    )
                }

                if (corrections.isNotEmpty()) {
                    SectionHeader("Record correction requests")
                    corrections.forEach { corr ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                StatusPill(corr.status)
                                Text(corr.recordTitle, style = MaterialTheme.typography.titleMedium)
                                Text("Requested: ${corr.requestedChange}", style = MaterialTheme.typography.bodyMedium)
                                corr.staffResponse?.let { Text("Response: $it", style = MaterialTheme.typography.bodyMedium) }
                            }
                        }
                    }
                }
            }
        }
    }

    selectedDocument?.let { doc ->
        AlertDialog(
            onDismissRequest = onCloseDocument,
            title = { Text(doc.title) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(doc.content, style = MaterialTheme.typography.bodyMedium, fontFamily = MonoFontFamily)
                }
            },
            confirmButton = { Button(onClick = onCloseDocument) { Text("Close") } },
        )
    }

    correctionTarget?.let { rec ->
        var requestedChange by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { correctionTarget = null },
            title = { Text("Request a record correction") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(rec.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "You cannot edit clinical records directly. Your request will be reviewed by the responsible care organisation.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedTextField(
                        value = requestedChange,
                        onValueChange = { requestedChange = it },
                        label = { Text("Describe what appears inaccurate") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSubmitCorrection(rec.id, requestedChange)
                        correctionTarget = null
                    },
                    enabled = requestedChange.length >= 5,
                ) { Text("Submit request") }
            },
            dismissButton = {
                OutlinedButton(onClick = { correctionTarget = null }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun RecordEntryCard(
    record: ClinicalRecordDto,
    onViewDocument: () -> Unit,
    onRequestCorrection: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("record_card_${record.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill(record.certaintyStatus)
                StatusPill(record.releaseStatus)
            }
            Text(record.title, style = MaterialTheme.typography.titleLarge)
            Text(
                "${record.sourceOrg} · ${LondonTimeFormatter.formatDateLabel(record.recordedDate)}",
                style = MaterialTheme.typography.labelMedium,
            )

            if (record.isStale && !record.staleNotice.isNullOrBlank()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
                    border = BorderStroke(1.dp, StatusPendingFg),
                ) {
                    Text(
                        text = record.staleNotice,
                        style = MaterialTheme.typography.bodyMedium,
                        color = StatusPendingFg,
                        modifier = Modifier.padding(10.dp),
                    )
                }
            }

            Text(record.summary, style = MaterialTheme.typography.bodyLarge)

            if (record.resultValue != null) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Result: ${record.resultValue} ${record.resultUnit.orEmpty()}",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = MonoFontFamily,
                        )
                        record.referenceRange?.let {
                            Text("Lab reference range: $it", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text(
                            "Speak with your care team about what this result means for you — this app does not interpret results.",
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                }
            }

            record.clinicianComment?.let {
                Text("Clinician comment: $it", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (record.hasDocument) {
                    Button(onClick = onViewDocument) {
                        Icon(Icons.Filled.Description, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Read letter")
                    }
                }
                OutlinedButton(onClick = onRequestCorrection) {
                    Text("Request correction")
                }
            }
        }
    }
}
