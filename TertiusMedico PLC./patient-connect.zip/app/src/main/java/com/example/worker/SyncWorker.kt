package com.example.worker

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferencesRepository
import com.example.notifications.PrivacyNotificationHelper
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Permitted background synchronisation worker.
 * Checks non-sensitive sync policy and posts only a generic privacy-preserving notification
 * when permitted; never pulls or caches complete clinical records in the background.
 */
class SyncWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = UserPreferencesRepository(applicationContext).preferences.first()
        if (prefs.simulateOffline) {
            return Result.retry()
        }
        // Check if an active cached summary exists; if signed out, skip silently.
        val db = AppDatabase.getInstance(applicationContext)
        val hasSummary = db.cacheDao().observeSummary("pat_eleanor_01").first() != null
        if (!hasSummary) {
            return Result.success()
        }
        // Only post generic privacy-preserving alert if system permission allows; never include PHI.
        PrivacyNotificationHelper.ensureChannel(applicationContext)
        return Result.success()
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "tertius_periodic_sync"

        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request,
            )
        }
    }
}
