package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CareBlueDark
import com.example.ui.theme.CareBluePrimary
import com.example.ui.theme.EmergencyBg
import com.example.ui.theme.EmergencyFg
import com.example.ui.theme.ProxyBannerBg
import com.example.ui.theme.ProxyBannerBorder
import com.example.ui.theme.ProxyBannerFg
import com.example.ui.theme.StatusConfirmedBg
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.StatusDeclinedBg
import com.example.ui.theme.StatusDeclinedFg
import com.example.ui.theme.StatusInfoBg
import com.example.ui.theme.StatusInfoFg
import com.example.ui.theme.StatusPendingBg
import com.example.ui.theme.StatusPendingFg

@Composable
fun PrototypeNoticeStrip(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(CareBlueDark)
            .padding(horizontal = 16.dp, vertical = 6.dp),
    ) {
        Text(
            text = stringResource(R.string.prototype_badge),
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
fun ProxyAccountBanner(
    patientName: String,
    restrictions: String,
    onSwitchBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("proxy_active_banner"),
        colors = CardDefaults.cardColors(containerColor = ProxyBannerBg),
        border = BorderStroke(2.dp, ProxyBannerBorder),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.SwapHoriz,
                    contentDescription = "Active proxy account warning",
                    tint = ProxyBannerFg,
                    modifier = Modifier.size(22.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Proxy View: Acting for $patientName",
                    style = MaterialTheme.typography.titleMedium,
                    color = ProxyBannerFg,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = restrictions,
                style = MaterialTheme.typography.bodyMedium,
                color = ProxyBannerFg,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = onSwitchBack,
                border = BorderStroke(1.5.dp, ProxyBannerFg),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ProxyBannerFg),
                modifier = Modifier.testTag("proxy_switch_back_button"),
            ) {
                Text("Return to Eleanor Vance's account")
            }
        }
    }
}

@Composable
fun OfflineCacheBanner(
    cachedAtLabel: String,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("offline_banner"),
        colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
        border = BorderStroke(1.dp, StatusPendingFg),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Filled.CloudOff,
                contentDescription = "Offline mode indicator",
                tint = StatusPendingFg,
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    text = "Offline mode — limited cached view",
                    style = MaterialTheme.typography.titleMedium,
                    color = StatusPendingFg,
                )
                Text(
                    text = "Cached at $cachedAtLabel. Connectivity is required to confirm appointments, request medicines, or update records.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StatusPendingFg,
                )
            }
        }
    }
}

@Composable
fun EmergencyNoticeCard(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = EmergencyBg),
        border = BorderStroke(1.5.dp, EmergencyFg),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = "Emergency guidance warning",
                tint = EmergencyFg,
                modifier = Modifier.padding(top = 2.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    text = "Not an emergency service",
                    style = MaterialTheme.typography.titleMedium,
                    color = EmergencyFg,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = stringResource(R.string.emergency_notice),
                    style = MaterialTheme.typography.bodyMedium,
                    color = EmergencyFg,
                )
            }
        }
    }
}

@Composable
fun StatusPill(
    rawStatus: String,
    modifier: Modifier = Modifier,
) {
    val (bg, fg, label) = when (rawStatus) {
        "BOOKING_CONFIRMED", "APPROVED", "PRESCRIPTION_TRANSMITTED", "READY_FOR_COLLECTION",
        "RELEASED", "CONFIRMED", "COMPLETED", "DELIVERED", "VERIFIED", "ACCEPTED_NOTED" ->
            Triple(StatusConfirmedBg, StatusConfirmedFg, friendlyStatusLabel(rawStatus))

        "DECLINED", "CANCELLED", "UNAVAILABLE", "FAILED_FALLBACK_INBOX", "REVOKED",
        "PENDING_POLICY_REVIEW", "WITHHELD_PENDING_REVIEW" ->
            Triple(StatusDeclinedBg, StatusDeclinedFg, friendlyStatusLabel(rawStatus))

        "SLOT_HELD", "BOOKING_REQUESTED", "CHANGE_REQUESTED", "REQUESTED", "PRACTICE_REVIEW",
        "PREPARING", "PROVISIONAL", "SUBMITTED", "UNDER_CLINICAL_REVIEW", "PENDING" ->
            Triple(StatusPendingBg, StatusPendingFg, friendlyStatusLabel(rawStatus))

        else ->
            Triple(StatusInfoBg, StatusInfoFg, friendlyStatusLabel(rawStatus))
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = bg,
    ) {
        Text(
            text = label,
            color = fg,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

fun friendlyStatusLabel(raw: String): String = when (raw) {
    "OFFER_AVAILABLE" -> "Offer available"
    "SLOT_HELD" -> "Slot held (5 min)"
    "BOOKING_REQUESTED" -> "Booking requested (awaiting confirmation)"
    "BOOKING_CONFIRMED" -> "Booking confirmed"
    "CHANGE_REQUESTED" -> "Change requested"
    "CANCELLED" -> "Cancelled"
    "COMPLETED" -> "Completed"
    "UNAVAILABLE" -> "Slot unavailable"
    "REQUESTED" -> "Request received (awaiting review)"
    "PRACTICE_REVIEW" -> "Practice review in progress"
    "APPROVED" -> "Approved by prescriber"
    "DECLINED" -> "Declined"
    "PRESCRIPTION_TRANSMITTED" -> "Prescription transmitted"
    "NOT_SENT" -> "Pharmacy: Not yet sent"
    "PREPARING" -> "Pharmacy: Preparing"
    "READY_FOR_COLLECTION" -> "Pharmacy: Ready for collection"
    "DELIVERED_TO_SERVICE" -> "Delivered to service (not yet reviewed)"
    "ASSIGNED" -> "Assigned to team"
    "REVIEWED" -> "Reviewed by team"
    "RESPONSE_AVAILABLE" -> "Response available"
    "CLOSED" -> "Closed"
    "CONFIRMED" -> "Confirmed"
    "PROVISIONAL" -> "Provisional impression"
    "HISTORICAL" -> "Historical entry"
    "RELEASED" -> "Released by provider"
    "FAILED_FALLBACK_INBOX" -> "Push failed (saved in inbox)"
    "PENDING_POLICY_REVIEW" -> "Blocked: Policy review required"
    else -> raw.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Text(
        text = title,
        style = MaterialTheme.typography.headlineSmall,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = modifier
            .padding(vertical = 4.dp)
            .semantics { heading() },
    )
}

@Composable
fun FeedbackBanner(
    message: String?,
    isError: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (message.isNullOrBlank()) return
    val bg = if (isError) StatusDeclinedBg else StatusInfoBg
    val fg = if (isError) StatusDeclinedFg else StatusInfoFg
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(1.dp, fg),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isError) Icons.Filled.Warning else Icons.Filled.Info,
                    contentDescription = null,
                    tint = fg,
                )
                Spacer(Modifier.width(8.dp))
                Text(text = message, style = MaterialTheme.typography.bodyMedium, color = fg)
            }
            OutlinedButton(onClick = onDismiss) {
                Text("Dismiss", color = fg)
            }
        }
    }
}

@Composable
fun BluePageHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(CareBluePrimary)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFE6F0FA),
            )
        }
    }
}
