package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class AccessibilityThemeConfig(
    val highContrast: Boolean = false,
    val reducedMotion: Boolean = false,
    val largeText: Boolean = false,
)

val LocalAccessibilityConfig = staticCompositionLocalOf { AccessibilityThemeConfig() }

private val StandardHealthcareColorScheme = lightColorScheme(
    primary = CareBluePrimary,
    onPrimary = Color.White,
    primaryContainer = CareBlueSoft,
    onPrimaryContainer = CareBlueDark,
    secondary = CareAqua,
    onSecondary = Color.White,
    secondaryContainer = CareAquaSoft,
    onSecondaryContainer = Color(0xFF003734),
    background = CanvasWhite,
    onBackground = InkPrimary,
    surface = CanvasWhite,
    onSurface = InkPrimary,
    surfaceVariant = CanvasMist,
    onSurfaceVariant = InkSecondary,
    outline = BorderSlate,
    error = StatusDeclinedFg,
    onError = Color.White,
    errorContainer = StatusDeclinedBg,
    onErrorContainer = StatusDeclinedFg,
)

private val HighContrastHealthcareColorScheme = lightColorScheme(
    primary = CareBlueDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E6FA),
    onPrimaryContainer = Color.Black,
    secondary = Color(0xFF004D48),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCDEEEB),
    onSecondaryContainer = Color.Black,
    background = Color.White,
    onBackground = Color.Black,
    surface = Color.White,
    onSurface = Color.Black,
    surfaceVariant = Color(0xFFF0F4F8),
    onSurfaceVariant = Color.Black,
    outline = Color.Black,
    error = Color(0xFF7A0014),
    onError = Color.White,
    errorContainer = Color(0xFFFDDCE2),
    onErrorContainer = Color.Black,
)

private val HealthcareShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
)

@Composable
fun PatientConnectTheme(
    accessibilityConfig: AccessibilityThemeConfig = AccessibilityThemeConfig(),
    content: @Composable () -> Unit,
) {
    val colors = if (accessibilityConfig.highContrast) {
        HighContrastHealthcareColorScheme
    } else {
        StandardHealthcareColorScheme
    }
    CompositionLocalProvider(LocalAccessibilityConfig provides accessibilityConfig) {
        MaterialTheme(
            colorScheme = colors,
            typography = buildHealthcareTypography(accessibilityConfig.largeText),
            shapes = HealthcareShapes,
            content = content,
        )
    }
}
