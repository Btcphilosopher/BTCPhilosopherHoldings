package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.CachedAppointmentEntity
import com.example.data.local.CachedSummaryEntity
import com.example.data.model.HomeSummaryDto
import com.example.data.model.OrganisationDto
import com.example.ui.SubScreen
import com.example.ui.TopTab
import com.example.ui.components.BluePageHeader
import com.example.ui.components.OfflineCacheBanner
import com.example.ui.components.ProxyAccountBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoFontFamily
import com.example.util.LondonTimeFormatter
import kotlinx.serialization.json.Json

@Composable
fun HomeScreen(
    summary: HomeSummaryDto?,
    cachedSummary: CachedSummaryEntity?,
    cachedAppointments: List<CachedAppointmentEntity>,
    isOffline: Boolean,
    onRefresh: () -> Unit,
    onNavigateTab: (TopTab) -> Unit,
    onOpenSubScreen: (SubScreen) -> Unit,
    onSwitchBackToSelf: () -> Unit,
) {
    val activeName = summary?.activePatient?.fullName
        ?: cachedSummary?.patientName
        ?: "Patient"
    val syntheticId = summary?.activePatient?.syntheticHealthId
        ?: cachedSummary?.syntheticHealthId
        ?: ""
    val isProxy = summary?.isProxyMode ?: cachedSummary?.isProxyMode ?: false
    val lastSync = summary?.lastSyncedAt ?: cachedSummary?.lastSyncedIso ?: ""

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        BluePageHeader(
            title = "Hello, $activeName",
            subtitle = buildString {
                append("Account: ${if (isProxy) "Proxy view" else "Personal account"}")
                if (syntheticId.isNotEmpty()) append(" · Synthetic ID $syntheticId")
            },
        )

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (summary?.activeProxyGrant != null) {
                ProxyAccountBanner(
                    patientName = summary.activePatient.fullName,
                    restrictions = summary.activeProxyGrant.restrictionsSummary,
                    onSwitchBack = onSwitchBackToSelf,
                )
            }

            if (isOffline) {
                OfflineCacheBanner(
                    cachedAtLabel = LondonTimeFormatter.formatShortTimestamp(
                        cachedSummary?.cachedAtIso ?: lastSync
                    )
                )
            }

            // Sync status bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = if (lastSync.isNotBlank()) {
                        "Last synced: ${LondonTimeFormatter.formatShortTimestamp(lastSync)}"
                    } else {
                        "Synchronising..."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("home_last_sync"),
                )
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Refresh patient summary",
                    )
                }
            }

            // Welcoming non-branded clinical artwork banner
            Image(
                painter = painterResource(id = R.drawable.img_care_banner),
                contentDescription = "Calm healthcare community illustration",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(MaterialTheme.shapes.medium),
            )

            // 4 Core Shortcuts + Prominent Health Records & Care Tasks shortcuts
            SectionHeader("Quick actions")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ShortcutTile(
                    icon = Icons.Filled.CalendarMonth,
                    label = stringResource(R.string.shortcut_book_appointment),
                    onClick = { onNavigateTab(TopTab.APPOINTMENTS) },
                    modifier = Modifier.weight(1f).testTag("shortcut_book_appointment"),
                )
                ShortcutTile(
                    icon = Icons.Filled.Medication,
                    label = stringResource(R.string.shortcut_request_medicines),
                    onClick = { onNavigateTab(TopTab.MEDICINES) },
                    modifier = Modifier.weight(1f).testTag("shortcut_request_medicines"),
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ShortcutTile(
                    icon = Icons.Filled.FolderShared,
                    label = stringResource(R.string.shortcut_view_records),
                    onClick = { onOpenSubScreen(SubScreen.RECORDS) },
                    modifier = Modifier.weight(1f).testTag("shortcut_view_records"),
                )
                ShortcutTile(
                    icon = Icons.Filled.Mail,
                    label = stringResource(R.string.shortcut_contact_practice),
                    onClick = { onNavigateTab(TopTab.MESSAGES) },
                    modifier = Modifier.weight(1f).testTag("shortcut_contact_practice"),
                )
            }
            ShortcutTile(
                icon = Icons.AutoMirrored.Filled.Assignment,
                label = "${stringResource(R.string.shortcut_care_tasks)} (${summary?.pendingTasksCount ?: 0} due)",
                onClick = { onOpenSubScreen(SubScreen.CARE_TASKS) },
                modifier = Modifier.fillMaxWidth().testTag("shortcut_care_tasks"),
            )

            // Next appointment card (uses live summary or explicitly cached appointment when offline)
            SectionHeader("Next appointment")
            val nextAppt = summary?.nextAppointment
            val offlineAppt = cachedAppointments.firstOrNull()
            if (nextAppt != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("home_next_appointment"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusPill(nextAppt.status)
                        Text(nextAppt.serviceName, style = MaterialTheme.typography.titleLarge)
                        Text(
                            LondonTimeFormatter.formatLondonDateTime(nextAppt.startsAtLondon),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text("${nextAppt.clinicianName} · ${nextAppt.location}")
                        OutlinedButton(onClick = { onNavigateTab(TopTab.APPOINTMENTS) }) {
                            Text("Manage appointments")
                        }
                    }
                }
            } else if (isOffline && offlineAppt != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusPill(offlineAppt.status)
                        Text(offlineAppt.serviceName, style = MaterialTheme.typography.titleLarge)
                        Text(LondonTimeFormatter.formatLondonDateTime(offlineAppt.startsAtLondon))
                        Text(
                            "Cached at ${LondonTimeFormatter.formatShortTimestamp(offlineAppt.cachedAtIso)}",
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                }
            } else {
                Text("No upcoming confirmed appointments shown.", style = MaterialTheme.typography.bodyMedium)
            }

            // At-a-glance status summary
            if (summary != null) {
                SectionHeader("Updates & requests")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    MetricCard(
                        title = "Awaiting action",
                        count = "${summary.requestsAwaitingActionCount}",
                        subtitle = "${summary.pendingOffersCount} booking offers",
                        icon = Icons.Filled.TaskAlt,
                        onClick = { onOpenSubScreen(SubScreen.CARE_TASKS) },
                        modifier = Modifier.weight(1f),
                    )
                    MetricCard(
                        title = "Unread messages",
                        count = "${summary.unreadMessagesCount}",
                        subtitle = if (summary.failedNotificationsCount > 0) {
                            "${summary.failedNotificationsCount} push alert fallback"
                        } else {
                            "Inbox up to date"
                        },
                        icon = Icons.Filled.Mail,
                        onClick = { onNavigateTab(TopTab.MESSAGES) },
                        modifier = Modifier.weight(1f),
                    )
                }

                // Latest medicine request status
                summary.latestMedicineRequest?.let { req ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onNavigateTab(TopTab.MEDICINES) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Latest medicine request", style = MaterialTheme.typography.labelLarge)
                            Text(req.medicineName, style = MaterialTheme.typography.titleMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StatusPill(req.stage)
                                StatusPill(req.pharmacyStatus)
                            }
                            req.decisionReason?.let {
                                Text(it, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            // Care-provider contacts (also readable from minimal cache when offline!)
            SectionHeader("Your care-provider contacts")
            val orgs: List<OrganisationDto> = summary?.careOrganisations ?: runCatching {
                cachedSummary?.contactsSummaryJson?.let {
                    Json.decodeFromString<List<OrganisationDto>>(it)
                } ?: emptyList()
            }.getOrDefault(emptyList())

            orgs.forEach { org ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.LocalHospital,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(org.name, style = MaterialTheme.typography.titleMedium)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "${org.phone} · ${org.hours}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = MonoFontFamily,
                            )
                        }
                        Text(org.address, style = MaterialTheme.typography.bodyMedium)
                        Text(org.responseSla, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun ShortcutTile(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(24.dp),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    count: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                Text(title, style = MaterialTheme.typography.labelLarge)
            }
            Text(count, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
