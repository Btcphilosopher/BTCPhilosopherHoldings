package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Accessible British Healthcare Palette (NHS-inspired blue & crisp white, high contrast)
val CareBluePrimary = Color(0xFF005EB8)
val CareBlueDark = Color(0xFF003087)
val CareBlueSoft = Color(0xFFE6F0FA)
val CareAqua = Color(0xFF007F78)
val CareAquaSoft = Color(0xFFE0F4F2)

val CanvasWhite = Color(0xFFFFFFFF)
val CanvasMist = Color(0xFFF4F7FA)
val BorderSlate = Color(0xFFD0DCE8)

val InkPrimary = Color(0xFF0B1220)
val InkSecondary = Color(0xFF3A4A62)

// Semantic Status Colours (Accessible AA+ contrast pairs)
val StatusConfirmedBg = Color(0xFFDDF3E4)
val StatusConfirmedFg = Color(0xFF005A30)

val StatusPendingBg = Color(0xFFFFF4D6)
val StatusPendingFg = Color(0xFF7A4100)

val StatusDeclinedBg = Color(0xFFFDE8EC)
val StatusDeclinedFg = Color(0xFF9E001C)

val StatusInfoBg = Color(0xFFE3EFFB)
val StatusInfoFg = Color(0xFF003087)

val ProxyBannerBg = Color(0xFFFFF1CC)
val ProxyBannerBorder = Color(0xFFB45309)
val ProxyBannerFg = Color(0xFF5C2800)

val EmergencyBg = Color(0xFFFEE2E2)
val EmergencyFg = Color(0xFF8C001A)
