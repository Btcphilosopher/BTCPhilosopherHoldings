package com.example.data.remote

import com.example.data.model.AppointmentDto
import com.example.data.model.AppointmentOfferDto
import com.example.data.model.AuthSession
import com.example.data.model.CareTaskDto
import com.example.data.model.ClinicalRecordDto
import com.example.data.model.CompleteTaskBody
import com.example.data.model.CorrectionRequestDto
import com.example.data.model.CreateCorrectionBody
import com.example.data.model.CreateMedicineRequestBody
import com.example.data.model.CreateThreadBody
import com.example.data.model.HoldOrConfirmBody
import com.example.data.model.HomeSummaryDto
import com.example.data.model.LoginRequest
import com.example.data.model.MedicineRecordDto
import com.example.data.model.MessageThreadDto
import com.example.data.model.NoSlotAssistBody
import com.example.data.model.NotificationDispatchDto
import com.example.data.model.OrganisationDto
import com.example.data.model.PatientProfileDto
import com.example.data.model.PreferencesUpdateBody
import com.example.data.model.ProxyGrantDto
import com.example.data.model.RecordDocumentDto
import com.example.data.model.RecoveryGuidance
import com.example.data.model.RepeatMedicineRequestDto
import com.example.data.model.ReplyThreadBody
import com.example.data.model.RescheduleBody
import com.example.data.model.ThreadMessageDto
import com.example.data.model.TrustedDeviceDto
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID

/**
 * On-device deterministic sandbox mirroring the FastAPI backend contract, fixtures,
 * proxy permission gates, optimistic slot concurrency, and idempotency guarantees.
 */
class DeterministicSandboxGateway : PatientConnectGateway {
    private val mutex = Mutex()

    private val gpOrg = OrganisationDto(
        id = "org_oakbridge_gp",
        name = "Oakbridge Community Medical Practice",
        orgType = "GP_PRACTICE",
        phone = "0113 496 0410",
        address = "14 Oakbridge Lane, Northborough, NB2 4QA",
        hours = "Mon–Fri 08:00–18:30 (Europe/London)",
        responseSla = "Practice team aims to respond within 2 working days (non-urgent).",
        syntheticOdsCode = "SYN-GP-104",
    )
    private val hospOrg = OrganisationDto(
        id = "org_westgate_hosp",
        name = "Westgate General Infirmary (Fictional Trust)",
        orgType = "HOSPITAL_TRUST",
        phone = "0113 496 0822",
        address = "Westgate Hill, Northborough, NB4 8TR",
        hours = "Outpatients Mon–Fri 08:30–17:00",
        responseSla = "Outpatient booking desk responds within 3 working days.",
        syntheticOdsCode = "SYN-HT-209",
    )
    private val pharmOrg = OrganisationDto(
        id = "org_meadowbank_pharm",
        name = "Meadowbank Dispensing Chemist",
        orgType = "PHARMACY",
        phone = "0113 496 0299",
        address = "42 High Street, Northborough, NB1 1AA",
        hours = "Mon–Sat 08:30–18:00",
        responseSla = "Dispensing updates shown only after confirmed transmission.",
        syntheticOdsCode = "SYN-PH-312",
    )

    private var activeToken: String? = null
    private var tokenExpiresAt: Instant = Instant.EPOCH

    private val profiles = mutableMapOf(
        "pat_eleanor_01" to PatientProfileDto(
            id = "pat_eleanor_01",
            syntheticHealthId = "TM-904-812-3310",
            fullName = "Eleanor Vance",
            dateOfBirth = "1978-05-14",
            preferredPhone = "07700 900412",
            email = "eleanor.vance@example.org",
            commPreference = "In-app message & SMS reminder",
            interpreterLanguage = "Not required (English)",
            accessibleFormat = "Large print & high-contrast digital",
            allergyConfirmationState = "CONFIRMED_PRESENT",
            lastSyncedAt = Instant.now().toString(),
        ),
        "pat_arthur_02" to PatientProfileDto(
            id = "pat_arthur_02",
            syntheticHealthId = "TM-611-204-8891",
            fullName = "Arthur Vance",
            dateOfBirth = "1944-11-03",
            preferredPhone = "07700 900188",
            email = "arthur.vance@example.org",
            commPreference = "Telephone call (morning)",
            interpreterLanguage = "Not required (English)",
            accessibleFormat = "Extra-large print (18pt)",
            allergyConfirmationState = "NOT_CONFIRMED",
            lastSyncedAt = Instant.now().minus(2, ChronoUnit.HOURS).toString(),
        ),
    )

    private val proxies = mutableListOf(
        ProxyGrantDto(
            id = "prx_arthur",
            patientId = "pat_arthur_02",
            patientName = "Arthur Vance",
            syntheticHealthId = "TM-611-204-8891",
            relationshipLabel = "Adult daughter acting for father (Arthur Vance)",
            verificationStatus = "VERIFIED",
            verificationReference = "Practice ID & Signed Consent Ref: PRX-2026-019",
            permissions = listOf("profile:read", "appointments:read", "appointments:book", "medicines:read", "messages:read"),
            restrictionsSummary = "Read-only for medicines and messages. Cannot request repeat medicines, view clinical letters/results, or submit record corrections.",
            effectiveFrom = "2026-01-15",
            effectiveUntil = "2027-06-30",
            revoked = false,
            requiresCapacityOrChildPolicy = false,
        ),
        ProxyGrantDto(
            id = "prx_maya_blocked",
            patientId = "pat_maya_03",
            patientName = "Maya Vance (Age 11)",
            syntheticHealthId = "TM-819-440-1025",
            relationshipLabel = "Parent / Child record",
            verificationStatus = "PENDING_POLICY_REVIEW",
            verificationReference = "Safeguarding & Gillick competence review required (PRX-CHILD-04)",
            permissions = emptyList(),
            restrictionsSummary = "Blocked until safeguarding & capacity policy verification is completed by Oakbridge Practice.",
            effectiveFrom = "2026-11-01",
            effectiveUntil = "2027-11-01",
            revoked = false,
            requiresCapacityOrChildPolicy = true,
        ),
    )

    private val devices = mutableListOf(
        TrustedDeviceDto(
            id = "dev_eleanor_tablet",
            deviceName = "Home Pixel Tablet (Previous Session)",
            platform = "ANDROID",
            biometricSessionUnlock = true,
            revoked = false,
            isCurrent = false,
            lastSeenAt = Instant.now().minus(2, ChronoUnit.DAYS).toString(),
        ),
        TrustedDeviceDto(
            id = "dev_current_android",
            deviceName = "This Android Device",
            platform = "ANDROID",
            biometricSessionUnlock = false,
            revoked = false,
            isCurrent = true,
            lastSeenAt = Instant.now().toString(),
        ),
    )

    private val offers = mutableListOf(
        AppointmentOfferDto(
            id = "off_cardio_01",
            patientId = "pat_eleanor_01",
            orgId = hospOrg.id,
            orgName = hospOrg.name,
            serviceName = "Cardiology Outpatient Follow-up",
            clinicianName = "Dr Priya Nair",
            location = "Westgate General Infirmary — Outpatients Wing B, Room 12",
            format = "IN_PERSON",
            startsAtLondon = "2026-12-08T09:30:00+00:00",
            endsAtLondon = "2026-12-08T10:00:00+00:00",
            preparationInstructions = "Bring your current medicines list and home blood-pressure readings from the last 7 days. Arrive 15 minutes early.",
            referralRuleNote = "Matches reviewed Cardiology Follow-up Referral #WGI-4412 (6-week review window).",
            status = "OFFER_AVAILABLE",
        ),
        AppointmentOfferDto(
            id = "off_cardio_02_bst",
            patientId = "pat_eleanor_01",
            orgId = hospOrg.id,
            orgName = hospOrg.name,
            serviceName = "Cardiology Nurse Telephone Review",
            clinicianName = "Senior Cardiac Nurse T. Okafor",
            location = "Telephone consultation (Westgate Cardiology Desk)",
            format = "TELEPHONE",
            startsAtLondon = "2027-04-14T14:15:00+01:00",
            endsAtLondon = "2027-04-14T14:35:00+01:00",
            preparationInstructions = "Keep your phone available from 14:05 BST. Withheld numbers may appear.",
            referralRuleNote = "Matches Cardiology Nurse Triage Protocol (BST daylight-saving schedule).",
            status = "OFFER_AVAILABLE",
        ),
        AppointmentOfferDto(
            id = "off_unavailable_conflict",
            patientId = "pat_eleanor_01",
            orgId = gpOrg.id,
            orgName = gpOrg.name,
            serviceName = "GP Medication & Blood Pressure Review",
            clinicianName = "Dr Malik Rahman",
            location = "Oakbridge Community Medical Practice — Room 3",
            format = "IN_PERSON",
            startsAtLondon = "2026-12-04T11:00:00+00:00",
            endsAtLondon = "2026-12-04T11:15:00+00:00",
            preparationInstructions = "Standard 15-minute GP review.",
            referralRuleNote = "Slot recently taken / unavailable — demonstrates conflict handling.",
            status = "UNAVAILABLE",
        ),
        AppointmentOfferDto(
            id = "off_arthur_01",
            patientId = "pat_arthur_02",
            orgId = gpOrg.id,
            orgName = gpOrg.name,
            serviceName = "Routine Blood Pressure Check",
            clinicianName = "Practice Nurse S. Hughes",
            location = "Oakbridge Community Medical Practice — Nurse Suite 1",
            format = "IN_PERSON",
            startsAtLondon = "2026-12-11T10:20:00+00:00",
            endsAtLondon = "2026-12-11T10:35:00+00:00",
            preparationInstructions = "Wear a loose sleeve for arm cuff reading.",
            referralRuleNote = "Eligible for verified proxy booking.",
            status = "OFFER_AVAILABLE",
        ),
    )

    private val appointments = mutableListOf(
        AppointmentDto(
            id = "apt_eleanor_upcoming",
            patientId = "pat_eleanor_01",
            orgId = gpOrg.id,
            orgName = gpOrg.name,
            orgPhone = gpOrg.phone,
            serviceName = "Phlebotomy (Fasting Blood Test)",
            clinicianName = "HCA Marcus Bell",
            location = "Oakbridge Community Medical Practice — Treatment Room 2",
            format = "IN_PERSON",
            startsAtLondon = "2026-12-02T08:40:00+00:00",
            endsAtLondon = "2026-12-02T08:55:00+00:00",
            preparationInstructions = "Fast from midnight (plain water only). Take morning blood-pressure tablet as normal unless told otherwise by your clinician.",
            status = "BOOKING_CONFIRMED",
            canCancel = true,
            sourceSystem = "Oakbridge GP Appointments",
            updatedAt = Instant.now().minus(1, ChronoUnit.DAYS).toString(),
        ),
        AppointmentDto(
            id = "apt_eleanor_past",
            patientId = "pat_eleanor_01",
            orgId = hospOrg.id,
            orgName = hospOrg.name,
            orgPhone = hospOrg.phone,
            serviceName = "12-Lead ECG & Echocardiogram",
            clinicianName = "Cardiology Diagnostics Team",
            location = "Westgate General Infirmary — Cardiac Diagnostics",
            format = "IN_PERSON",
            startsAtLondon = "2026-10-19T10:00:00+01:00",
            endsAtLondon = "2026-10-19T10:45:00+01:00",
            preparationInstructions = "Completed diagnostic appointment.",
            status = "COMPLETED",
            canCancel = false,
            sourceSystem = "Westgate PAS",
            updatedAt = Instant.now().minus(38, ChronoUnit.DAYS).toString(),
        ),
        AppointmentDto(
            id = "apt_arthur_upcoming",
            patientId = "pat_arthur_02",
            orgId = gpOrg.id,
            orgName = gpOrg.name,
            orgPhone = gpOrg.phone,
            serviceName = "Annual Respiratory Check",
            clinicianName = "Dr Malik Rahman",
            location = "Oakbridge Community Medical Practice — Room 1",
            format = "IN_PERSON",
            startsAtLondon = "2026-12-15T11:30:00+00:00",
            endsAtLondon = "2026-12-15T11:50:00+00:00",
            preparationInstructions = "Bring all inhalers and spacer device.",
            status = "BOOKING_CONFIRMED",
            canCancel = true,
            sourceSystem = "Oakbridge GP Appointments",
            updatedAt = Instant.now().minus(3, ChronoUnit.DAYS).toString(),
        ),
    )

    private val medicines = listOf(
        MedicineRecordDto(
            id = "med_eleanor_ramipril",
            patientId = "pat_eleanor_01",
            nameFormulation = "Ramipril capsules",
            strength = "5 mg",
            directions = "Take ONE capsule once daily in the morning.",
            sourceOrg = "Oakbridge Community Medical Practice (GP Repeat)",
            lastUpdatedAt = Instant.now().minus(5, ChronoUnit.DAYS).toString(),
            repeatEligible = true,
        ),
        MedicineRecordDto(
            id = "med_eleanor_atorva",
            patientId = "pat_eleanor_01",
            nameFormulation = "Atorvastatin tablets",
            strength = "20 mg",
            directions = "Take ONE tablet once daily at night.",
            sourceOrg = "Oakbridge Community Medical Practice (GP Repeat)",
            lastUpdatedAt = Instant.now().minus(14, ChronoUnit.DAYS).toString(),
            repeatEligible = true,
            conflictWarning = "Hospital letter (Oct 2026) mentions reviewing lipid dose after repeat blood test; GP record currently shows 20 mg. Confirm with your practice if unsure.",
        ),
        MedicineRecordDto(
            id = "med_eleanor_acute",
            patientId = "pat_eleanor_01",
            nameFormulation = "Naproxen gastro-resistant tablets",
            strength = "250 mg",
            directions = "Previously issued as a short acute course — do not continue without GP review.",
            sourceOrg = "Oakbridge Community Medical Practice (Acute issue)",
            lastUpdatedAt = Instant.now().minus(45, ChronoUnit.DAYS).toString(),
            repeatEligible = false,
            ineligibilityReason = "Acute prescription only — requires clinician review before any further issue.",
        ),
        MedicineRecordDto(
            id = "med_arthur_salbutamol",
            patientId = "pat_arthur_02",
            nameFormulation = "Salbutamol 100 micrograms/dose pressurised inhalation",
            strength = "100 mcg",
            directions = "Inhale ONE or TWO puffs when required for shortness of breath.",
            sourceOrg = "Oakbridge Community Medical Practice (GP Repeat)",
            lastUpdatedAt = Instant.now().minus(9, ChronoUnit.DAYS).toString(),
            repeatEligible = true,
        ),
    )

    private val medicineRequests = mutableListOf(
        RepeatMedicineRequestDto(
            id = "req_med_declined_01",
            patientId = "pat_eleanor_01",
            medicineId = "med_eleanor_acute",
            medicineName = "Naproxen gastro-resistant tablets",
            preferredPharmacyName = pharmOrg.name,
            patientNote = "Requested extra pack for occasional knee ache.",
            stage = "DECLINED",
            pharmacyStatus = "NOT_SENT",
            reviewerRole = "GP Prescriber (Dr Malik Rahman)",
            decisionReason = "Declined for automatic repeat: NSAIDs require blood-pressure and kidney-function check alongside Ramipril. Please book a GP review or message the practice.",
            createdAt = Instant.now().minus(6, ChronoUnit.DAYS).toString(),
            updatedAt = Instant.now().minus(5, ChronoUnit.DAYS).toString(),
        )
    )
    private val medIdempotency = mutableMapOf<String, RepeatMedicineRequestDto>()
    private val offerIdempotency = mutableMapOf<String, AppointmentDto>()

    private val records = listOf(
        ClinicalRecordDto(
            id = "rec_consult_01",
            patientId = "pat_eleanor_01",
            category = "CONSULTATION",
            title = "GP Consultation Summary — Blood Pressure & Lipids Plan",
            summary = "Reviewed home blood pressure diary (average 132/82 mmHg). Arranged fasting blood tests before December cardiology follow-up. Advised to continue Ramipril 5 mg.",
            certaintyStatus = "CONFIRMED",
            releaseStatus = "RELEASED",
            sourceOrg = "Oakbridge Community Medical Practice",
            recordedDate = "2026-11-12",
            clinicianComment = "Released to patient by Dr Malik Rahman.",
        ),
        ClinicalRecordDto(
            id = "rec_allergy_01",
            patientId = "pat_eleanor_01",
            category = "ALLERGY",
            title = "Penicillin V (Phenoxymethylpenicillin) — Adverse Reaction",
            summary = "Widespread urticarial rash reported in 2018. Avoid penicillin-class antibiotics.",
            certaintyStatus = "CONFIRMED",
            releaseStatus = "RELEASED",
            sourceOrg = "Oakbridge Community Medical Practice",
            recordedDate = "2018-09-04",
            clinicianComment = "Verified allergy record.",
        ),
        ClinicalRecordDto(
            id = "rec_diagnosis_confirmed",
            patientId = "pat_eleanor_01",
            category = "DIAGNOSIS",
            title = "Essential (primary) hypertension",
            summary = "Long-term condition managed in primary care with lifestyle support and ACE inhibitor therapy.",
            certaintyStatus = "CONFIRMED",
            releaseStatus = "RELEASED",
            sourceOrg = "Oakbridge Community Medical Practice",
            recordedDate = "2022-04-18",
        ),
        ClinicalRecordDto(
            id = "rec_diagnosis_provisional",
            patientId = "pat_eleanor_01",
            category = "DIAGNOSIS",
            title = "Suspected white-coat blood pressure variability",
            summary = "Provisional impression pending ambulatory / 7-day home blood pressure readings.",
            certaintyStatus = "PROVISIONAL",
            releaseStatus = "RELEASED",
            sourceOrg = "Westgate General Infirmary",
            recordedDate = "2026-10-19",
        ),
        ClinicalRecordDto(
            id = "rec_diagnosis_historical",
            patientId = "pat_eleanor_01",
            category = "DIAGNOSIS",
            title = "Resolved iron-deficiency anaemia (2019)",
            summary = "Historical entry; resolved following oral supplementation in 2019.",
            certaintyStatus = "HISTORICAL",
            releaseStatus = "RELEASED",
            sourceOrg = "Oakbridge Community Medical Practice",
            recordedDate = "2019-11-10",
        ),
        ClinicalRecordDto(
            id = "rec_immunisation_01",
            patientId = "pat_eleanor_01",
            category = "IMMUNISATION",
            title = "Seasonal Influenza Vaccine (2026/27)",
            summary = "Administered in left deltoid at Oakbridge Practice clinic. Batch SYN-FLU-26B.",
            certaintyStatus = "RECORDED",
            releaseStatus = "RELEASED",
            sourceOrg = "Oakbridge Community Medical Practice",
            recordedDate = "2026-10-08",
        ),
        ClinicalRecordDto(
            id = "rec_letter_01",
            patientId = "pat_eleanor_01",
            category = "LETTER",
            title = "Cardiology Outpatient Clinic Letter (Oct 2026)",
            summary = "Echocardiogram summary and plan for fasting lipid/renal blood test prior to follow-up.",
            certaintyStatus = "CONFIRMED",
            releaseStatus = "RELEASED",
            sourceOrg = "Westgate General Infirmary",
            recordedDate = "2026-10-19",
            clinicianComment = "Copy sent to GP and released to patient.",
            hasDocument = true,
        ),
        ClinicalRecordDto(
            id = "rec_result_creatinine",
            patientId = "pat_eleanor_01",
            category = "RESULT",
            title = "Serum Creatinine & eGFR (Renal Profile)",
            summary = "Routine renal monitoring prior to repeat Ramipril review.",
            certaintyStatus = "CONFIRMED",
            releaseStatus = "RELEASED",
            sourceOrg = "Westgate Pathology Lab (via Oakbridge GP)",
            recordedDate = "2026-11-05",
            resultValue = "74",
            resultUnit = "umol/L",
            referenceRange = "45 - 84 umol/L (Adult Female Lab Range)",
            clinicianComment = "Within laboratory reference range; satisfactory for continuing current monitoring schedule. Repeat fasting bloods due Dec 2026.",
        ),
        ClinicalRecordDto(
            id = "rec_result_stale",
            patientId = "pat_eleanor_01",
            category = "RESULT",
            title = "Serum Potassium (Previous Archive Result)",
            summary = "Older archived electrolyte result — newer test pending.",
            certaintyStatus = "HISTORICAL",
            releaseStatus = "RELEASED",
            sourceOrg = "Westgate Pathology Lab",
            recordedDate = "2025-11-02",
            resultValue = "4.3",
            resultUnit = "mmol/L",
            referenceRange = "3.5 - 5.3 mmol/L",
            clinicianComment = "Archive result from over 12 months ago. Do not rely on this for current treatment decisions.",
            isStale = true,
            staleNotice = "Stale record (>12 months old). Upcoming fasting blood test on 2 Dec 2026 will provide updated values.",
        ),
    )

    private val corrections = mutableListOf(
        CorrectionRequestDto(
            id = "corr_seed_01",
            recordId = "rec_allergy_01",
            recordTitle = "Penicillin V (Phenoxymethylpenicillin) — Adverse Reaction",
            requestedChange = "Please clarify that reaction occurred in September 2018 after 2 doses (no breathing difficulty).",
            status = "UNDER_CLINICAL_REVIEW",
            staffResponse = "Received by Oakbridge Practice coding team; awaiting GP confirmation.",
            createdAt = Instant.now().minus(2, ChronoUnit.DAYS).toString(),
        )
    )

    private val threads = mutableListOf(
        MessageThreadDto(
            id = "thr_eleanor_01",
            patientId = "pat_eleanor_01",
            orgId = hospOrg.id,
            orgName = hospOrg.name,
            category = "Appointment queries",
            subject = "Preparation for your December Cardiology review",
            workflowStatus = "RESPONSE_AVAILABLE",
            expectedResponseWindow = hospOrg.responseSla,
            unreadByPatient = true,
            updatedAt = Instant.now().minus(4, ChronoUnit.HOURS).toString(),
            messages = listOf(
                ThreadMessageDto(
                    id = "msg_01",
                    senderType = "STAFF",
                    senderLabel = "Westgate Cardiology Booking Team",
                    body = "Hello Eleanor, we have released eligible follow-up appointment slots for December. Please also complete the 7-day Blood Pressure Log task before attending. If none of the times suit you, reply here.",
                    sentAt = Instant.now().minus(4, ChronoUnit.HOURS).toString(),
                )
            ),
        ),
        MessageThreadDto(
            id = "thr_eleanor_02",
            patientId = "pat_eleanor_01",
            orgId = gpOrg.id,
            orgName = gpOrg.name,
            category = "Administrative help",
            subject = "Fasting blood test form confirmation",
            workflowStatus = "DELIVERED_TO_SERVICE",
            expectedResponseWindow = gpOrg.responseSla,
            unreadByPatient = false,
            updatedAt = Instant.now().minus(1, ChronoUnit.DAYS).toString(),
            messages = listOf(
                ThreadMessageDto(
                    id = "msg_02",
                    senderType = "PATIENT",
                    senderLabel = "Eleanor Vance",
                    body = "Could you confirm whether my paper blood form is already with the treatment room for 2 December?",
                    sentAt = Instant.now().minus(1, ChronoUnit.DAYS).toString(),
                )
            ),
        ),
        MessageThreadDto(
            id = "thr_arthur_01",
            patientId = "pat_arthur_02",
            orgId = gpOrg.id,
            orgName = gpOrg.name,
            category = "Appointment queries",
            subject = "Respiratory clinic preparation for Arthur",
            workflowStatus = "RESPONSE_AVAILABLE",
            expectedResponseWindow = gpOrg.responseSla,
            unreadByPatient = false,
            updatedAt = Instant.now().minus(2, ChronoUnit.DAYS).toString(),
            messages = listOf(
                ThreadMessageDto(
                    id = "msg_arthur_01",
                    senderType = "STAFF",
                    senderLabel = "Oakbridge Reception",
                    body = "Please remind Arthur to bring his reliever inhaler and spacer to Room 1.",
                    sentAt = Instant.now().minus(2, ChronoUnit.DAYS).toString(),
                )
            ),
        ),
    )

    private val tasks = mutableListOf(
        CareTaskDto(
            id = "tsk_bp_questionnaire",
            patientId = "pat_eleanor_01",
            issuingOrgName = "Westgate General Infirmary — Cardiology",
            contactDetails = "Cardiology Desk: 0113 496 0822",
            taskType = "QUESTIONNAIRE",
            title = "Pre-Clinic Home Blood Pressure & Symptom Check",
            purpose = "Helps your cardiology team review recent home readings alongside your clinic assessment. Readings you enter are recorded as patient-entered observations.",
            dueDate = "2026-12-06",
            status = "PENDING",
        ),
        CareTaskDto(
            id = "tsk_prep_read",
            patientId = "pat_eleanor_01",
            issuingOrgName = "Oakbridge Community Medical Practice",
            contactDetails = "Reception: 0113 496 0410",
            taskType = "PREPARATION",
            title = "Read fasting instructions for 2 Dec blood test",
            purpose = "Confirm you have read the fasting guidance (water only from midnight).",
            dueDate = "2026-12-01",
            status = "PENDING",
        ),
    )

    private val notifications = mutableListOf(
        NotificationDispatchDto(
            id = "not_01",
            patientId = "pat_eleanor_01",
            genericPreviewText = "You have a new message from your care team.",
            deliveryStatus = "DELIVERED",
            createdAt = Instant.now().minus(4, ChronoUnit.HOURS).toString(),
        ),
        NotificationDispatchDto(
            id = "not_02_failed",
            patientId = "pat_eleanor_01",
            genericPreviewText = "You have a new message from your care team.",
            deliveryStatus = "FAILED_FALLBACK_INBOX",
            failureReason = "Simulated push delivery failure — alert preserved inside app without exposing sensitive data.",
            createdAt = Instant.now().minus(1, ChronoUnit.HOURS).toString(),
        ),
    )

    private fun requireValidSession(token: String) {
        if (activeToken == null || token != activeToken) {
            throw ApiException(401, "Session is invalid or signed out.")
        }
        if (Instant.now().isAfter(tokenExpiresAt)) {
            throw ApiException(401, "Your session has expired for your protection. Please sign in again.")
        }
    }

    private fun resolvePatient(patientId: String?, permission: String): Pair<PatientProfileDto, ProxyGrantDto?> {
        val targetId = patientId ?: "pat_eleanor_01"
        if (targetId == "pat_eleanor_01") {
            return profiles["pat_eleanor_01"]!! to null
        }
        val grant = proxies.firstOrNull { it.patientId == targetId }
            ?: throw ApiException(403, "You are not authorised to access this patient's account.")
        if (grant.revoked || grant.verificationStatus != "VERIFIED") {
            throw ApiException(403, "Proxy access is pending policy review or has been revoked.")
        }
        if (!grant.permissions.contains(permission)) {
            throw ApiException(403, "Your proxy permissions do not allow this action ($permission).")
        }
        val profile = profiles[targetId]
            ?: throw ApiException(403, "Patient profile unavailable.")
        return profile to grant
    }

    override suspend fun login(request: LoginRequest): AuthSession = mutex.withLock {
        if (request.email.trim().lowercase() != "eleanor.vance@example.org" ||
            request.passphrase != "CareConnect!2026"
        ) {
            throw ApiException(
                401,
                "Invalid email or passphrase. Note: name, date of birth, or ID number alone cannot grant access.",
            )
        }
        if (request.verificationCode.trim() != "246810") {
            throw ApiException(401, "Two-step verification code is incorrect (use 246810 in demo).")
        }
        val token = "sandbox_${UUID.randomUUID()}"
        activeToken = token
        tokenExpiresAt = Instant.now().plus(30, ChronoUnit.MINUTES)
        AuthSession(
            accessToken = token,
            expiresAt = tokenExpiresAt.toString(),
            userId = "usr_eleanor",
            displayName = "Eleanor Vance",
            role = "PATIENT",
            deviceId = "dev_current_android",
            identityNotice = "Verified via DeterministicPatientIdentityAdapter (Prototype). Not connected to NHS login.",
            biometricNotice = "Optional device biometric unlock only unlocks this device's saved session and does not verify clinical identity.",
        )
    }

    override suspend fun logout(token: String) = mutex.withLock {
        activeToken = null
    }

    override suspend fun getDevices(token: String): List<TrustedDeviceDto> = mutex.withLock {
        requireValidSession(token)
        devices.toList()
    }

    override suspend fun revokeDevice(token: String, deviceId: String) = mutex.withLock {
        requireValidSession(token)
        val idx = devices.indexOfFirst { it.id == deviceId }
        if (idx >= 0) {
            devices[idx] = devices[idx].copy(revoked = true)
            if (devices[idx].isCurrent) {
                activeToken = null
            }
        }
    }

    override suspend fun getRecoveryGuidance(): RecoveryGuidance = RecoveryGuidance(
        steps = listOf(
            "1. Verify identity with your registered email and secondary recovery factor — name, date of birth, or synthetic ID alone never grants access.",
            "2. If you have lost your authenticator or device, contact Oakbridge Community Medical Practice reception with photo ID for a supervised reset.",
            "3. Revoke lost devices from Account -> Trusted Devices once signed back in.",
        ),
        supportContact = "Oakbridge Practice Identity Desk: 0113 496 0410 (Mon–Fri 08:00–18:30)",
        securityRule = "Independent prototype recovery process — does not use NHS login.",
    )

    override suspend fun getHomeSummary(token: String, patientId: String?): HomeSummaryDto = mutex.withLock {
        requireValidSession(token)
        val (profile, grant) = resolvePatient(patientId, "profile:read")
        val updatedProfile = profile.copy(lastSyncedAt = Instant.now().toString())
        profiles[profile.id] = updatedProfile

        val patientAppts = appointments.filter {
            it.patientId == profile.id && it.status in listOf("BOOKING_CONFIRMED", "BOOKING_REQUESTED", "CHANGE_REQUESTED")
        }.sortedBy { it.startsAtLondon }

        val pendingOffers = offers.count { it.patientId == profile.id && it.status == "OFFER_AVAILABLE" }
        val pendingTasks = tasks.count { it.patientId == profile.id && it.status == "PENDING" }
        val unreadMsgs = threads.count { it.patientId == profile.id && it.unreadByPatient }
        val patientMedReqs = medicineRequests.filter { it.patientId == profile.id }.sortedByDescending { it.updatedAt }
        val awaiting = medicineRequests.count {
            it.patientId == profile.id && it.stage in listOf("REQUESTED", "PRACTICE_REVIEW")
        } + pendingTasks

        HomeSummaryDto(
            prototypeNotice = "Independent prototype using synthetic records. Not affiliated with or endorsed by the NHS.",
            activePatient = updatedProfile,
            isProxyMode = grant != null,
            activeProxyGrant = grant,
            nextAppointment = patientAppts.firstOrNull(),
            pendingOffersCount = pendingOffers,
            requestsAwaitingActionCount = awaiting,
            unreadMessagesCount = unreadMsgs,
            latestMedicineRequest = patientMedReqs.firstOrNull(),
            pendingTasksCount = pendingTasks,
            careOrganisations = listOf(gpOrg, hospOrg, pharmOrg),
            lastSyncedAt = updatedProfile.lastSyncedAt,
            failedNotificationsCount = notifications.count { it.patientId == profile.id && it.deliveryStatus != "DELIVERED" },
        )
    }

    override suspend fun getProxies(token: String): List<ProxyGrantDto> = mutex.withLock {
        requireValidSession(token)
        proxies.toList()
    }

    override suspend fun updatePreferences(
        token: String,
        patientId: String?,
        body: PreferencesUpdateBody,
    ): PatientProfileDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "profile:write")
        val updated = profile.copy(
            commPreference = body.commPreference,
            interpreterLanguage = body.interpreterLanguage,
            accessibleFormat = body.accessibleFormat,
            preferredPhone = body.preferredPhone ?: profile.preferredPhone,
        )
        profiles[profile.id] = updated
        updated
    }

    override suspend fun getNotifications(token: String, patientId: String?): List<NotificationDispatchDto> =
        mutex.withLock {
            requireValidSession(token)
            val (profile, _) = resolvePatient(patientId, "profile:read")
            notifications.filter { it.patientId == profile.id }.sortedByDescending { it.createdAt }
        }

    override suspend fun getAppointments(token: String, patientId: String?): List<AppointmentDto> = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "appointments:read")
        appointments.filter { it.patientId == profile.id }.sortedByDescending { it.startsAtLondon }
    }

    override suspend fun getOffers(token: String, patientId: String?): List<AppointmentOfferDto> = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "appointments:read")
        offers.filter { it.patientId == profile.id }.sortedBy { it.startsAtLondon }
    }

    override suspend fun holdOffer(
        token: String,
        patientId: String?,
        offerId: String,
        body: HoldOrConfirmBody,
    ): AppointmentOfferDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "appointments:book")
        val idx = offers.indexOfFirst { it.id == offerId && it.patientId == profile.id }
        if (idx < 0) throw ApiException(404, "Appointment offer not found.")
        val offer = offers[idx]
        if (offer.status == "SLOT_HELD") return offer
        if (offer.status != "OFFER_AVAILABLE") {
            throw ApiException(409, "This slot is no longer available. Choose another slot or contact the booking team.")
        }
        val held = offer.copy(
            status = "SLOT_HELD",
            holdExpiresAt = Instant.now().plus(5, ChronoUnit.MINUTES).toString(),
        )
        offers[idx] = held
        held
    }

    override suspend fun confirmOffer(
        token: String,
        patientId: String?,
        offerId: String,
        body: HoldOrConfirmBody,
    ): AppointmentDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "appointments:book")
        offerIdempotency["$offerId:${body.idempotencyKey}"]?.let { return it }

        val idx = offers.indexOfFirst { it.id == offerId && it.patientId == profile.id }
        if (idx < 0) throw ApiException(404, "Appointment offer not found.")
        val offer = offers[idx]
        if (offer.status == "UNAVAILABLE") {
            throw ApiException(
                409,
                "This appointment slot is unavailable. Your request has been preserved; please contact the booking team or select another slot.",
            )
        }
        if (offer.status == "BOOKED") {
            throw ApiException(409, "This slot has already been booked.")
        }
        offers[idx] = offer.copy(status = "BOOKED")
        val org = if (offer.orgId == hospOrg.id) hospOrg else gpOrg
        val created = AppointmentDto(
            id = "apt_${UUID.randomUUID().toString().take(8)}",
            patientId = profile.id,
            orgId = offer.orgId,
            orgName = offer.orgName,
            orgPhone = org.phone,
            offerId = offer.id,
            serviceName = offer.serviceName,
            clinicianName = offer.clinicianName,
            location = offer.location,
            format = offer.format,
            startsAtLondon = offer.startsAtLondon,
            endsAtLondon = offer.endsAtLondon,
            preparationInstructions = offer.preparationInstructions,
            status = "BOOKING_REQUESTED",
            canCancel = true,
            rescheduleNote = body.patientNote,
            sourceSystem = offer.orgName,
            updatedAt = Instant.now().toString(),
        )
        appointments.add(0, created)
        offerIdempotency["$offerId:${body.idempotencyKey}"] = created
        created
    }

    override suspend fun requestNoSuitableSlots(
        token: String,
        patientId: String?,
        body: NoSlotAssistBody,
    ) {
        mutex.withLock {
            requireValidSession(token)
            val (profile, _) = resolvePatient(patientId, "appointments:book")
            val now = Instant.now().toString()
            threads.add(
                0,
                MessageThreadDto(
                    id = "thr_${UUID.randomUUID().toString().take(8)}",
                    patientId = profile.id,
                    orgId = hospOrg.id,
                    orgName = hospOrg.name,
                    category = "Appointment queries",
                    subject = "Staff-assisted appointment booking request (no suitable slots)",
                    workflowStatus = "DELIVERED_TO_SERVICE",
                    expectedResponseWindow = hospOrg.responseSla,
                    unreadByPatient = false,
                    updatedAt = now,
                    messages = listOf(
                        ThreadMessageDto(
                            id = "msg_${UUID.randomUUID().toString().take(8)}",
                            senderType = "PATIENT",
                            senderLabel = profile.fullName,
                            body = "No offered slot fits. Preferred days/times: ${body.preferredDays}. Notes: ${body.reason}",
                            sentAt = now,
                        )
                    ),
                ),
            )
        }
    }

    override suspend fun rescheduleAppointment(
        token: String,
        patientId: String?,
        appointmentId: String,
        body: RescheduleBody,
    ): AppointmentDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "appointments:book")
        val idx = appointments.indexOfFirst { it.id == appointmentId && it.patientId == profile.id }
        if (idx < 0) throw ApiException(404, "Appointment not found.")
        val updated = appointments[idx].copy(
            status = "CHANGE_REQUESTED",
            rescheduleNote = "Preferred: ${body.preferredWindow}. Reason: ${body.reason}",
            updatedAt = Instant.now().toString(),
        )
        appointments[idx] = updated
        updated
    }

    override suspend fun cancelAppointment(
        token: String,
        patientId: String?,
        appointmentId: String,
    ): AppointmentDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "appointments:book")
        val idx = appointments.indexOfFirst { it.id == appointmentId && it.patientId == profile.id }
        if (idx < 0) throw ApiException(404, "Appointment not found.")
        val current = appointments[idx]
        if (!current.canCancel || current.status == "COMPLETED") {
            throw ApiException(400, "This appointment cannot be cancelled online. Please phone the booking team.")
        }
        val updated = current.copy(
            status = "CANCELLED",
            canCancel = false,
            updatedAt = Instant.now().toString(),
        )
        appointments[idx] = updated
        updated
    }

    override suspend fun getMedicines(token: String, patientId: String?): List<MedicineRecordDto> = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "medicines:read")
        medicines.filter { it.patientId == profile.id }
    }

    override suspend fun getRepeatRequests(token: String, patientId: String?): List<RepeatMedicineRequestDto> =
        mutex.withLock {
            requireValidSession(token)
            val (profile, _) = resolvePatient(patientId, "medicines:read")
            medicineRequests.filter { it.patientId == profile.id }.sortedByDescending { it.updatedAt }
        }

    override suspend fun getRepeatRequestByKey(
        token: String,
        patientId: String?,
        idempotencyKey: String,
    ): RepeatMedicineRequestDto? = mutex.withLock {
        requireValidSession(token)
        resolvePatient(patientId, "medicines:read")
        medIdempotency[idempotencyKey]
    }

    override suspend fun submitRepeatRequest(
        token: String,
        patientId: String?,
        body: CreateMedicineRequestBody,
    ): RepeatMedicineRequestDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "medicines:request")
        medIdempotency[body.idempotencyKey]?.let { return it }

        val med = medicines.firstOrNull { it.id == body.medicineId && it.patientId == profile.id }
            ?: throw ApiException(404, "Medicine record not found.")
        if (!med.repeatEligible) {
            throw ApiException(400, med.ineligibilityReason ?: "Not eligible for repeat requests.")
        }
        val now = Instant.now().toString()
        val created = RepeatMedicineRequestDto(
            id = "mreq_${UUID.randomUUID().toString().take(8)}",
            patientId = profile.id,
            medicineId = med.id,
            medicineName = med.nameFormulation,
            preferredPharmacyName = body.preferredPharmacyName,
            patientNote = body.patientNote,
            stage = "REQUESTED",
            pharmacyStatus = "NOT_SENT",
            decisionReason = "Request received — awaiting practice review. This is not yet a signed prescription.",
            createdAt = now,
            updatedAt = now,
        )
        medicineRequests.add(0, created)
        medIdempotency[body.idempotencyKey] = created
        created
    }

    override suspend fun getReleasedRecords(token: String, patientId: String?): List<ClinicalRecordDto> =
        mutex.withLock {
            requireValidSession(token)
            val (profile, _) = resolvePatient(patientId, "records:read")
            records.filter { it.patientId == profile.id && it.releaseStatus == "RELEASED" }
        }

    override suspend fun getRecordDocument(token: String, patientId: String?, recordId: String): RecordDocumentDto =
        mutex.withLock {
            requireValidSession(token)
            val (profile, _) = resolvePatient(patientId, "records:read")
            val entry = records.firstOrNull { it.id == recordId && it.patientId == profile.id }
                ?: throw ApiException(404, "Released document not found.")
            RecordDocumentDto(
                recordId = entry.id,
                title = entry.title,
                content = "WESTGATE GENERAL INFIRMARY — CARDIOLOGY OUTPATIENTS (SYNTHETIC PROTOTYPE)\n" +
                    "Patient: Eleanor Vance (Synthetic ID: TM-904-812-3310)\n" +
                    "Date: 19 October 2026\n\n" +
                    "Summary: Echocardiogram showed preserved left ventricular systolic function. " +
                    "Continue current GP-prescribed Ramipril 5 mg daily and complete fasting lipid & renal profile prior to December review.\n" +
                    "Author: Dr Priya Nair, Consultant Cardiologist (Fictional).",
            )
        }

    override suspend fun getCorrections(token: String, patientId: String?): List<CorrectionRequestDto> =
        mutex.withLock {
            requireValidSession(token)
            resolvePatient(patientId, "records:read")
            corrections.toList()
        }

    override suspend fun submitCorrection(
        token: String,
        patientId: String?,
        body: CreateCorrectionBody,
    ): CorrectionRequestDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "records:correct")
        val rec = records.firstOrNull { it.id == body.recordId && it.patientId == profile.id }
            ?: throw ApiException(404, "Clinical record not found.")
        val created = CorrectionRequestDto(
            id = "corr_${UUID.randomUUID().toString().take(8)}",
            recordId = rec.id,
            recordTitle = rec.title,
            requestedChange = body.requestedChange,
            status = "SUBMITTED",
            staffResponse = "Correction request received. Clinical records can only be amended after review by your care organisation.",
            createdAt = Instant.now().toString(),
        )
        corrections.add(0, created)
        created
    }

    override suspend fun getMessageThreads(token: String, patientId: String?): List<MessageThreadDto> =
        mutex.withLock {
            requireValidSession(token)
            val (profile, _) = resolvePatient(patientId, "messages:read")
            threads.filter { it.patientId == profile.id }.sortedByDescending { it.updatedAt }
        }

    override suspend fun createThread(
        token: String,
        patientId: String?,
        body: CreateThreadBody,
    ): MessageThreadDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "messages:write")
        val org = if (body.orgId == hospOrg.id) hospOrg else gpOrg
        val now = Instant.now().toString()
        val created = MessageThreadDto(
            id = "thr_${UUID.randomUUID().toString().take(8)}",
            patientId = profile.id,
            orgId = org.id,
            orgName = org.name,
            category = body.category,
            subject = body.subject,
            workflowStatus = "DELIVERED_TO_SERVICE",
            expectedResponseWindow = org.responseSla,
            unreadByPatient = false,
            updatedAt = now,
            messages = listOf(
                ThreadMessageDto(
                    id = "msg_${UUID.randomUUID().toString().take(8)}",
                    senderType = "PATIENT",
                    senderLabel = profile.fullName,
                    body = body.body,
                    sentAt = now,
                )
            ),
        )
        threads.add(0, created)
        created
    }

    override suspend fun replyThread(
        token: String,
        patientId: String?,
        threadId: String,
        body: ReplyThreadBody,
    ): MessageThreadDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "messages:write")
        val idx = threads.indexOfFirst { it.id == threadId && it.patientId == profile.id }
        if (idx < 0) throw ApiException(404, "Thread not found.")
        val current = threads[idx]
        val now = Instant.now().toString()
        val updated = current.copy(
            workflowStatus = "DELIVERED_TO_SERVICE",
            unreadByPatient = false,
            updatedAt = now,
            messages = current.messages + ThreadMessageDto(
                id = "msg_${UUID.randomUUID().toString().take(8)}",
                senderType = "PATIENT",
                senderLabel = profile.fullName,
                body = body.body,
                sentAt = now,
            ),
        )
        threads[idx] = updated
        updated
    }

    override suspend fun markThreadRead(
        token: String,
        patientId: String?,
        threadId: String,
    ): MessageThreadDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "messages:read")
        val idx = threads.indexOfFirst { it.id == threadId && it.patientId == profile.id }
        if (idx < 0) throw ApiException(404, "Thread not found.")
        val updated = threads[idx].copy(unreadByPatient = false)
        threads[idx] = updated
        updated
    }

    override suspend fun getCareTasks(token: String, patientId: String?): List<CareTaskDto> = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "tasks:read")
        tasks.filter { it.patientId == profile.id }
    }

    override suspend fun completeCareTask(
        token: String,
        patientId: String?,
        taskId: String,
        body: CompleteTaskBody,
    ): CareTaskDto = mutex.withLock {
        requireValidSession(token)
        val (profile, _) = resolvePatient(patientId, "tasks:write")
        val idx = tasks.indexOfFirst { it.id == taskId && it.patientId == profile.id }
        if (idx < 0) throw ApiException(404, "Care task not found.")
        val now = Instant.now().toString()
        val updated = tasks[idx].copy(
            status = "COMPLETED",
            responseJson = "{\"response_summary\":\"${body.responseSummary.replace("\"", "'")}\"," +
                "\"patient_entered_measurement\":\"${(body.patientEnteredMeasurement ?: "").replace("\"", "'")}\"," +
                "\"recorded_at_utc\":\"$now\",\"source\":\"Patient-entered (unverified)\"}",
            measurementSource = "Patient-entered (unverified)",
            submittedAt = now,
        )
        tasks[idx] = updated
        updated
    }

    override suspend fun simulateStaffConfirmNextBooking(patientId: String?): String? = mutex.withLock {
        val targetId = patientId ?: "pat_eleanor_01"
        val idx = appointments.indexOfFirst {
            it.patientId == targetId && (it.status == "BOOKING_REQUESTED" || it.status == "CHANGE_REQUESTED")
        }
        if (idx < 0) return "No pending booking requests to confirm for this patient."
        appointments[idx] = appointments[idx].copy(
            status = "BOOKING_CONFIRMED",
            updatedAt = Instant.now().toString(),
        )
        "Simulated Staff Console: confirmed booking for ${appointments[idx].serviceName}."
    }

    override suspend fun simulateStaffAdvanceLatestMedicine(patientId: String?, approve: Boolean): String? =
        mutex.withLock {
            val targetId = patientId ?: "pat_eleanor_01"
            val idx = medicineRequests.indexOfFirst {
                it.patientId == targetId && it.stage in listOf("REQUESTED", "PRACTICE_REVIEW", "APPROVED")
            }
            if (idx < 0) return "No open repeat medicine request to review."
            val current = medicineRequests[idx]
            val next = if (!approve) {
                current.copy(
                    stage = "DECLINED",
                    pharmacyStatus = "NOT_SENT",
                    reviewerRole = "GP Prescriber (Dr Malik Rahman)",
                    decisionReason = "Declined in simulated staff review: medication review required before re-issue.",
                    updatedAt = Instant.now().toString(),
                )
            } else if (current.stage == "REQUESTED") {
                current.copy(
                    stage = "PRACTICE_REVIEW",
                    pharmacyStatus = "NOT_SENT",
                    reviewerRole = "GP Prescriber (Dr Malik Rahman)",
                    decisionReason = "Under clinical review by Oakbridge GP prescribing team.",
                    updatedAt = Instant.now().toString(),
                )
            } else {
                current.copy(
                    stage = "PRESCRIPTION_TRANSMITTED",
                    pharmacyStatus = "READY_FOR_COLLECTION",
                    reviewerRole = "GP Prescriber (Dr Malik Rahman)",
                    decisionReason = "Approved, signed, and transmitted to Meadowbank Dispensing Chemist.",
                    updatedAt = Instant.now().toString(),
                )
            }
            medicineRequests[idx] = next
            "Simulated Staff Console: ${next.medicineName} moved to ${next.stage} (${next.pharmacyStatus})."
        }

    override suspend fun simulateStaffFailedNotification(patientId: String?): String? = mutex.withLock {
        val targetId = patientId ?: "pat_eleanor_01"
        val now = Instant.now().toString()
        notifications.add(
            0,
            NotificationDispatchDto(
                id = "not_${UUID.randomUUID().toString().take(8)}",
                patientId = targetId,
                genericPreviewText = "You have a new message from your care team.",
                deliveryStatus = "FAILED_FALLBACK_INBOX",
                failureReason = "Simulated push gateway timeout — content never exposed on lock screen; safely held in inbox.",
                createdAt = now,
            ),
        )
        "Simulated failed push notification logged with privacy-preserving fallback."
    }
}
