package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.local.CachedAppointmentEntity
import com.example.data.local.CachedSummaryEntity
import com.example.data.local.PendingOutboxActionEntity
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.AppointmentDto
import com.example.data.model.CreateMedicineRequestBody
import com.example.data.model.HomeSummaryDto
import com.example.data.model.RepeatMedicineRequestDto
import com.example.data.remote.ApiException
import com.example.data.remote.DeterministicSandboxGateway
import com.example.data.remote.KtorPatientConnectGateway
import com.example.data.remote.PatientConnectGateway
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.time.Instant
import java.util.UUID

class OfflineBlockedException(message: String) : Exception(message)
class InterruptedConnectionException(val idempotencyKey: String, message: String) : Exception(message)

class PatientConnectRepository(
    private val db: AppDatabase,
    private val prefsRepo: UserPreferencesRepository,
    private val sandboxGateway: PatientConnectGateway = DeterministicSandboxGateway(),
    private var liveGateway: PatientConnectGateway? = null,
) {
    private val json = Json { ignoreUnknownKeys = true }

    val preferences: Flow<AppPreferences> = prefsRepo.preferences

    suspend fun currentGateway(): PatientConnectGateway {
        val prefs = prefsRepo.preferences.first()
        if (!prefs.useLiveBackend) return sandboxGateway
        if (liveGateway == null) {
            liveGateway = KtorPatientConnectGateway(baseUrlProvider = { prefs.serverBaseUrl })
        }
        return liveGateway!!
    }

    suspend fun requireOnline(actionLabel: String) {
        val prefs = prefsRepo.preferences.first()
        if (prefs.simulateOffline) {
            throw OfflineBlockedException(
                "You are currently offline. Connectivity is required to $actionLabel. Previously cached summaries remain readable with timestamps.",
            )
        }
    }

    fun observeCachedSummary(patientId: String): Flow<CachedSummaryEntity?> =
        db.cacheDao().observeSummary(patientId)

    fun observeCachedAppointments(patientId: String): Flow<List<CachedAppointmentEntity>> =
        db.cacheDao().observeAppointments(patientId)

    fun observePendingOutbox(patientId: String): Flow<List<PendingOutboxActionEntity>> =
        db.cacheDao().observeOutboxActions(patientId)

    suspend fun cacheMinimalHomeAndAppointments(
        summary: HomeSummaryDto,
        appointments: List<AppointmentDto>,
    ) {
        val cachedAt = Instant.now().toString()
        val patient = summary.activePatient
        val allergyNotice = if (patient.allergyConfirmationState == "CONFIRMED_PRESENT") {
            "Confirmed allergies recorded — view Records for full details."
        } else {
            "Allergies: Information not yet confirmed on record (do not assume no allergies)."
        }

        db.cacheDao().upsertSummary(
            CachedSummaryEntity(
                patientId = patient.id,
                patientName = patient.fullName,
                syntheticHealthId = patient.syntheticHealthId,
                isProxyMode = summary.isProxyMode,
                lastSyncedIso = summary.lastSyncedAt,
                cachedAtIso = cachedAt,
                contactsSummaryJson = json.encodeToString(summary.careOrganisations),
                allergyConfirmationNotice = allergyNotice,
            )
        )

        // Minimal offline cache: store upcoming appointments & contacts only (never complete clinical records)
        val upcoming = appointments
            .filter { it.status in listOf("BOOKING_CONFIRMED", "BOOKING_REQUESTED", "CHANGE_REQUESTED") }
            .map {
                CachedAppointmentEntity(
                    id = it.id,
                    patientId = it.patientId,
                    orgName = it.orgName,
                    orgPhone = it.orgPhone,
                    serviceName = it.serviceName,
                    clinicianName = it.clinicianName,
                    location = it.location,
                    format = it.format,
                    startsAtLondon = it.startsAtLondon,
                    endsAtLondon = it.endsAtLondon,
                    preparationInstructions = it.preparationInstructions,
                    status = it.status,
                    cachedAtIso = cachedAt,
                )
            }
        db.cacheDao().deleteAppointmentsForPatient(patient.id)
        db.cacheDao().insertAppointments(upcoming)
    }

    /**
     * Submits a repeat-medicine request with idempotency tracking.
     * If `simulateInterruptedConnection` is active, records the request on the server/sandbox
     * OR drops the response before returning, storing the pending idempotency key in Room
     * so the user can safely verify existing status after reconnection without double-submitting.
     */
    suspend fun submitRepeatMedicineWithIdempotency(
        token: String,
        patientId: String?,
        medicineId: String,
        medicineName: String,
        preferredPharmacy: String,
        patientNote: String?,
    ): RepeatMedicineRequestDto {
        requireOnline("submit a repeat medicine request")
        val prefs = prefsRepo.preferences.first()
        val key = "med_${UUID.randomUUID()}"
        val effectivePatientId = patientId ?: "pat_eleanor_01"
        val gw = currentGateway()

        val body = CreateMedicineRequestBody(
            medicineId = medicineId,
            preferredPharmacyName = preferredPharmacy,
            patientNote = patientNote,
            idempotencyKey = key,
        )

        if (prefs.simulateInterruptedConnection) {
            // Simulate: server received request, but connection dropped before client got the response!
            try {
                gw.submitRepeatRequest(token, patientId, body)
            } catch (e: ApiException) {
                throw e
            } catch (_: IOException) {
                // ignore network error
            }
            db.cacheDao().upsertOutboxAction(
                PendingOutboxActionEntity(
                    idempotencyKey = key,
                    patientId = effectivePatientId,
                    actionType = "REPEAT_MEDICINE",
                    targetId = medicineId,
                    description = "Repeat request: $medicineName",
                    state = "INTERRUPTED_NEEDS_STATUS_CHECK",
                    createdAtIso = Instant.now().toString(),
                )
            )
            // Automatically disable the simulation toggle after triggering once so recovery works immediately on retry
            prefsRepo.setSimulateInterruptedConnection(false)
            throw InterruptedConnectionException(
                key,
                "Connection interrupted while waiting for confirmation. Your request will NOT be auto-resubmitted blindly — tap 'Check Status' to verify whether it reached the practice.",
            )
        }

        return gw.submitRepeatRequest(token, patientId, body)
    }

    suspend fun verifyInterruptedMedicineAction(
        token: String,
        patientId: String?,
        outboxItem: PendingOutboxActionEntity,
    ): RepeatMedicineRequestDto? {
        requireOnline("check request status")
        val gw = currentGateway()
        val found = gw.getRepeatRequestByKey(token, patientId, outboxItem.idempotencyKey)
        if (found != null) {
            db.cacheDao().deleteOutboxAction(outboxItem.idempotencyKey)
        } else {
            db.cacheDao().upsertOutboxAction(outboxItem.copy(state = "NOT_FOUND_ON_SERVER"))
        }
        return found
    }

    suspend fun clearSensitiveCache() {
        db.clearAllSensitiveCache()
    }
}
