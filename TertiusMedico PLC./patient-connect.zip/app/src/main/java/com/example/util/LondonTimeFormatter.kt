package com.example.util

import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object LondonTimeFormatter {
    private val londonZone: ZoneId = ZoneId.of("Europe/London")
    private val displayFormatter: DateTimeFormatter =
        DateTimeFormatter.ofPattern("EEE d MMM yyyy, HH:mm z", Locale.UK)
    private val dateOnlyFormatter: DateTimeFormatter =
        DateTimeFormatter.ofPattern("d MMM yyyy", Locale.UK)

    fun formatLondonDateTime(isoString: String): String {
        return runCatching {
            val odt = OffsetDateTime.parse(isoString)
            val zoned = odt.atZoneSameInstant(londonZone)
            displayFormatter.format(zoned)
        }.getOrElse {
            runCatching {
                val inst = Instant.parse(isoString)
                displayFormatter.format(inst.atZone(londonZone))
            }.getOrDefault(isoString)
        }
    }

    fun toEpochMillis(isoString: String): Long {
        return runCatching { OffsetDateTime.parse(isoString).toInstant().toEpochMilli() }
            .getOrElse {
                runCatching { Instant.parse(isoString).toEpochMilli() }.getOrDefault(System.currentTimeMillis())
            }
    }

    fun formatShortTimestamp(isoString: String): String {
        return runCatching {
            val odt = OffsetDateTime.parse(isoString)
            val zoned = odt.atZoneSameInstant(londonZone)
            DateTimeFormatter.ofPattern("d MMM, HH:mm z", Locale.UK).format(zoned)
        }.getOrElse {
            runCatching {
                val inst = Instant.parse(isoString)
                DateTimeFormatter.ofPattern("d MMM, HH:mm z", Locale.UK).format(inst.atZone(londonZone))
            }.getOrDefault(isoString)
        }
    }

    fun formatDateLabel(isoDate: String): String {
        return runCatching {
            val localDate = java.time.LocalDate.parse(isoDate)
            dateOnlyFormatter.format(localDate)
        }.getOrDefault(isoDate)
    }
}
