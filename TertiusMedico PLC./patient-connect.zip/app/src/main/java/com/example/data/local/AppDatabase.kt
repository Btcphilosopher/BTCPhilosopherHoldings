package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CachedSummaryEntity::class,
        CachedAppointmentEntity::class,
        PendingOutboxActionEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cacheDao(): CacheDao

    suspend fun clearAllSensitiveCache() {
        val dao = cacheDao()
        dao.clearSummaries()
        dao.clearAppointments()
        dao.clearOutbox()
    }

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "patient_connect_minimal_cache.db",
                ).build().also { instance = it }
            }
        }
    }
}
