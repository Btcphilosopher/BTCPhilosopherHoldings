package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Minimal explicitly cached offline summary.
 * Complete clinical records are NEVER cached by default, and all rows are wiped on logout/expiry.
 */
@Entity(tableName = "cached_summaries")
data class CachedSummaryEntity(
    @PrimaryKey val patientId: String,
    val patientName: String,
    val syntheticHealthId: String,
    val isProxyMode: Boolean,
    val lastSyncedIso: String,
    val cachedAtIso: String,
    val contactsSummaryJson: String,
    val allergyConfirmationNotice: String,
)

@Entity(tableName = "cached_appointments")
data class CachedAppointmentEntity(
    @PrimaryKey val id: String,
    val patientId: String,
    val orgName: String,
    val orgPhone: String,
    val serviceName: String,
    val clinicianName: String,
    val location: String,
    val format: String,
    val startsAtLondon: String,
    val endsAtLondon: String,
    val preparationInstructions: String,
    val status: String,
    val cachedAtIso: String,
)

@Entity(tableName = "pending_outbox_actions")
data class PendingOutboxActionEntity(
    @PrimaryKey val idempotencyKey: String,
    val patientId: String,
    val actionType: String, // REPEAT_MEDICINE | CONFIRM_OFFER | CREATE_THREAD
    val targetId: String,
    val description: String,
    val state: String, // INTERRUPTED_NEEDS_STATUS_CHECK | VERIFIED_COMPLETE | NOT_FOUND_ON_SERVER
    val createdAtIso: String,
)
