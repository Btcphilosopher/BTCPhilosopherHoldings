package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.SyncProblem
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.PendingOutboxActionEntity
import com.example.data.model.HomeSummaryDto
import com.example.data.model.MedicineRecordDto
import com.example.data.model.RepeatMedicineRequestDto
import com.example.ui.components.BluePageHeader
import com.example.ui.components.OfflineCacheBanner
import com.example.ui.components.ProxyAccountBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.StatusDeclinedBg
import com.example.ui.theme.StatusDeclinedFg
import com.example.ui.theme.StatusPendingBg
import com.example.ui.theme.StatusPendingFg
import com.example.util.LondonTimeFormatter

@Composable
fun MedicinesScreen(
    summary: HomeSummaryDto?,
    medicines: List<MedicineRecordDto>,
    repeatRequests: List<RepeatMedicineRequestDto>,
    pendingOutbox: List<PendingOutboxActionEntity>,
    isOffline: Boolean,
    onRequestRepeat: (MedicineRecordDto, pharmacyName: String, note: String?) -> Unit,
    onCheckInterruptedItem: (PendingOutboxActionEntity) -> Unit,
    onContactPractice: () -> Unit,
    onSwitchBackToSelf: () -> Unit,
) {
    var selectedMedicine by remember { mutableStateOf<MedicineRecordDto?>(null) }
    val proxyReadOnly = summary?.activeProxyGrant?.permissions?.contains("medicines:request") == false

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        BluePageHeader(
            title = "Medicines",
            subtitle = "A repeat request is not a prescription until approved and transmitted by your practice.",
        )

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (summary?.activeProxyGrant != null) {
                ProxyAccountBanner(
                    patientName = summary.activePatient.fullName,
                    restrictions = summary.activeProxyGrant.restrictionsSummary,
                    onSwitchBack = onSwitchBackToSelf,
                )
            }

            if (isOffline) {
                OfflineCacheBanner(
                    cachedAtLabel = LondonTimeFormatter.formatShortTimestamp(summary?.lastSyncedAt.orEmpty())
                )
            }

            // Interrupted connection recovery cards (idempotency check before resubmit)
            if (pendingOutbox.isNotEmpty()) {
                SectionHeader("Interrupted requests — verify status first")
                pendingOutbox.forEach { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("interrupted_outbox_card"),
                        colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
                        border = BorderStroke(1.5.dp, StatusPendingFg),
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.SyncProblem, contentDescription = null, tint = StatusPendingFg)
                                Spacer(Modifier.width(8.dp))
                                Text(item.description, style = MaterialTheme.typography.titleMedium, color = StatusPendingFg)
                            }
                            Text(
                                "State: ${item.state}. To avoid duplicate prescriptions, check whether the practice already received this request before submitting again.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = StatusPendingFg,
                            )
                            Button(
                                onClick = { onCheckInterruptedItem(item) },
                                enabled = !isOffline,
                                modifier = Modifier.testTag("check_interrupted_status_button"),
                            ) {
                                Text("Check existing status")
                            }
                        }
                    }
                }
            }

            // Pipeline tracker
            SectionHeader("Repeat request status")
            if (repeatRequests.isEmpty()) {
                Text("No repeat medicine requests recorded.", style = MaterialTheme.typography.bodyMedium)
            } else {
                repeatRequests.forEach { req ->
                    RepeatRequestCard(req)
                }
            }

            // Recorded medicines
            SectionHeader("Recorded medicines")
            medicines.forEach { med ->
                MedicineCard(
                    medicine = med,
                    canRequest = !isOffline && med.repeatEligible && !proxyReadOnly,
                    proxyBlocked = proxyReadOnly,
                    onRequestClick = { selectedMedicine = med },
                    onContactPractice = onContactPractice,
                )
            }
        }
    }

    selectedMedicine?.let { med ->
        val defaultPharmacy = summary?.careOrganisations
            ?.firstOrNull { it.orgType == "PHARMACY" }?.name
            ?: "Meadowbank Dispensing Chemist"
        var pharmacy by remember { mutableStateOf(defaultPharmacy) }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { selectedMedicine = null },
            title = { Text("Request repeat medicine") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${med.nameFormulation} (${med.strength})", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Submitting sends a request to Oakbridge Practice for clinician review. " +
                            "Do not assume your prescription is ready until transmitted and confirmed.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedTextField(
                        value = pharmacy,
                        onValueChange = { pharmacy = it },
                        label = { Text("Preferred pharmacy") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Optional note for practice") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRequestRepeat(med, pharmacy, note)
                        selectedMedicine = null
                    },
                    modifier = Modifier.testTag("confirm_repeat_medicine_button"),
                ) {
                    Text("Submit request")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { selectedMedicine = null }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun RepeatRequestCard(req: RepeatMedicineRequestDto) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("repeat_request_card_${req.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(req.medicineName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill(req.stage)
                StatusPill(req.pharmacyStatus)
            }
            Text("Preferred pharmacy: ${req.preferredPharmacyName}", style = MaterialTheme.typography.bodyMedium)
            req.reviewerRole?.let { Text("Reviewer: $it", style = MaterialTheme.typography.labelMedium) }
            req.decisionReason?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Text(
                "Updated: ${LondonTimeFormatter.formatShortTimestamp(req.updatedAt)}",
                style = MaterialTheme.typography.labelMedium,
            )
        }
    }
}

@Composable
private fun MedicineCard(
    medicine: MedicineRecordDto,
    canRequest: Boolean,
    proxyBlocked: Boolean,
    onRequestClick: () -> Unit,
    onContactPractice: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("medicine_card_${medicine.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Medication, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("${medicine.nameFormulation} · ${medicine.strength}", style = MaterialTheme.typography.titleMedium)
                    Text(medicine.sourceOrg, style = MaterialTheme.typography.labelMedium)
                }
            }
            Text("Recorded directions: ${medicine.directions}", style = MaterialTheme.typography.bodyLarge)
            Text(
                "Last updated: ${LondonTimeFormatter.formatShortTimestamp(medicine.lastUpdatedAt)}",
                style = MaterialTheme.typography.labelMedium,
            )

            medicine.conflictWarning?.let { warning ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusPendingBg),
                    border = BorderStroke(1.dp, StatusPendingFg),
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Filled.Warning, contentDescription = "Information discrepancy", tint = StatusPendingFg)
                        Spacer(Modifier.width(8.dp))
                        Text(warning, style = MaterialTheme.typography.bodyMedium, color = StatusPendingFg)
                    }
                }
            }

            if (!medicine.repeatEligible) {
                Card(colors = CardDefaults.cardColors(containerColor = StatusDeclinedBg)) {
                    Text(
                        text = medicine.ineligibilityReason ?: "Not eligible for repeat request.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StatusDeclinedFg,
                        modifier = Modifier.padding(10.dp),
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onRequestClick,
                    enabled = canRequest,
                    modifier = Modifier.testTag("request_repeat_${medicine.id}"),
                ) {
                    Text(
                        when {
                            proxyBlocked -> "Blocked in proxy view"
                            !medicine.repeatEligible -> "Not eligible"
                            else -> "Request repeat"
                        }
                    )
                }
                OutlinedButton(onClick = onContactPractice) {
                    Text("Contact practice")
                }
            }
        }
    }
}
