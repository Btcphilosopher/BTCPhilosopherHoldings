package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.HomeSummaryDto
import com.example.data.model.MessageThreadDto
import com.example.ui.components.BluePageHeader
import com.example.ui.components.EmergencyNoticeCard
import com.example.ui.components.ProxyAccountBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.util.LondonTimeFormatter

private val REQUEST_CATEGORIES = listOf(
    "Administrative help",
    "Appointment queries",
    "Document requests",
    "Existing-care questions",
    "Contact-detail changes",
)

@Composable
fun MessagesScreen(
    summary: HomeSummaryDto?,
    threads: List<MessageThreadDto>,
    isOffline: Boolean,
    onCreateThread: (orgId: String, category: String, subject: String, body: String) -> Unit,
    onReplyThread: (threadId: String, body: String) -> Unit,
    onMarkRead: (threadId: String) -> Unit,
    onSwitchBackToSelf: () -> Unit,
) {
    var selectedThreadId by remember { mutableStateOf<String?>(null) }
    var showNewRequestDialog by remember { mutableStateOf(false) }
    val proxyReadOnly = summary?.activeProxyGrant?.permissions?.contains("messages:write") == false
    val selectedThread = threads.firstOrNull { it.id == selectedThreadId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        BluePageHeader(
            title = "Messages & Requests",
            subtitle = "Delivery to the service does not mean a clinician has reviewed your message yet.",
        )

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (summary?.activeProxyGrant != null) {
                ProxyAccountBanner(
                    patientName = summary.activePatient.fullName,
                    restrictions = summary.activeProxyGrant.restrictionsSummary,
                    onSwitchBack = onSwitchBackToSelf,
                )
            }

            EmergencyNoticeCard()

            Button(
                onClick = { showNewRequestDialog = true },
                enabled = !isOffline && !proxyReadOnly,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("new_message_button"),
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text(
                    if (proxyReadOnly) " Messaging is read-only in proxy view" else " New structured request",
                    modifier = Modifier.padding(start = 6.dp),
                )
            }

            if (selectedThread != null) {
                ThreadDetailPanel(
                    thread = selectedThread,
                    canReply = !isOffline && !proxyReadOnly,
                    onBack = { selectedThreadId = null },
                    onReply = { body -> onReplyThread(selectedThread.id, body) },
                )
            } else {
                SectionHeader("Your conversations")
                if (threads.isEmpty()) {
                    Text("No messages available.")
                } else {
                    threads.forEach { thread ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedThreadId = thread.id
                                    if (thread.unreadByPatient) onMarkRead(thread.id)
                                }
                                .testTag("thread_card_${thread.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StatusPill(thread.workflowStatus)
                                    if (thread.unreadByPatient) {
                                        StatusPill("UNREAD")
                                    }
                                }
                                Text(thread.subject, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("${thread.orgName} · ${thread.category}", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "Response arrangement: ${thread.expectedResponseWindow}",
                                    style = MaterialTheme.typography.labelMedium,
                                )
                                Text(
                                    "Updated: ${LondonTimeFormatter.formatShortTimestamp(thread.updatedAt)}",
                                    style = MaterialTheme.typography.labelMedium,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewRequestDialog) {
        val orgs = summary?.careOrganisations?.filter { it.orgType != "PHARMACY" }.orEmpty()
        var selectedOrgId by remember { mutableStateOf(orgs.firstOrNull()?.id ?: "org_oakbridge_gp") }
        var selectedCategory by remember { mutableStateOf(REQUEST_CATEGORIES.first()) }
        var subject by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNewRequestDialog = false },
            title = { Text("New structured request") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Choose care provider:", style = MaterialTheme.typography.labelLarge)
                    orgs.forEach { org ->
                        FilterChip(
                            selected = selectedOrgId == org.id,
                            onClick = { selectedOrgId = org.id },
                            label = { Text(org.name) },
                        )
                    }
                    Text("Request type:", style = MaterialTheme.typography.labelLarge)
                    REQUEST_CATEGORIES.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) },
                        )
                    }
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = body,
                        onValueChange = { body = it },
                        label = { Text("Your message (non-urgent only)") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateThread(selectedOrgId, selectedCategory, subject, body)
                        showNewRequestDialog = false
                    },
                    enabled = subject.isNotBlank() && body.isNotBlank(),
                ) {
                    Text("Send")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showNewRequestDialog = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun ThreadDetailPanel(
    thread: MessageThreadDto,
    canReply: Boolean,
    onBack: () -> Unit,
    onReply: (String) -> Unit,
) {
    var replyText by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onBack) { Text("Back to all conversations") }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusPill(thread.workflowStatus)
                Text(thread.subject, style = MaterialTheme.typography.titleLarge)
                Text("${thread.orgName} · ${thread.category}", style = MaterialTheme.typography.bodyMedium)
                Text(thread.expectedResponseWindow, style = MaterialTheme.typography.labelMedium)
            }
        }

        thread.messages.forEach { msg ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (msg.senderType == "PATIENT") {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(msg.senderLabel, style = MaterialTheme.typography.labelLarge)
                    Text(msg.body, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        LondonTimeFormatter.formatShortTimestamp(msg.sentAt),
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
            }
        }

        if (canReply) {
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = replyText,
                onValueChange = { replyText = it },
                label = { Text("Reply to care team") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth().testTag("thread_reply_input"),
            )
            Button(
                onClick = {
                    onReply(replyText)
                    replyText = ""
                },
                enabled = replyText.isNotBlank(),
                modifier = Modifier.testTag("thread_reply_send"),
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                Text(" Send reply", modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}
