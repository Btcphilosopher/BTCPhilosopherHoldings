package com.example.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class LoginRequest(
    val email: String,
    val passphrase: String,
    @SerialName("verification_code") val verificationCode: String,
    @SerialName("device_name") val deviceName: String = "Android Device",
    val platform: String = "ANDROID",
)

@Serializable
data class AuthSession(
    @SerialName("access_token") val accessToken: String,
    @SerialName("expires_at") val expiresAt: String,
    @SerialName("user_id") val userId: String,
    @SerialName("display_name") val displayName: String,
    val role: String,
    @SerialName("device_id") val deviceId: String,
    @SerialName("identity_notice") val identityNotice: String,
    @SerialName("biometric_notice") val biometricNotice: String,
)

@Serializable
data class RecoveryGuidance(
    val steps: List<String>,
    @SerialName("support_contact") val supportContact: String,
    @SerialName("security_rule") val securityRule: String,
)

@Serializable
data class TrustedDeviceDto(
    val id: String,
    @SerialName("device_name") val deviceName: String,
    val platform: String,
    @SerialName("biometric_session_unlock") val biometricSessionUnlock: Boolean,
    val revoked: Boolean,
    @SerialName("is_current") val isCurrent: Boolean,
    @SerialName("last_seen_at") val lastSeenAt: String,
)

@Serializable
data class OrganisationDto(
    val id: String,
    val name: String,
    @SerialName("org_type") val orgType: String,
    val phone: String,
    val address: String,
    val hours: String,
    @SerialName("response_sla") val responseSla: String,
    @SerialName("synthetic_ods_code") val syntheticOdsCode: String,
)

@Serializable
data class PatientProfileDto(
    val id: String,
    @SerialName("synthetic_health_id") val syntheticHealthId: String,
    @SerialName("full_name") val fullName: String,
    @SerialName("date_of_birth") val dateOfBirth: String,
    @SerialName("preferred_phone") val preferredPhone: String,
    val email: String,
    @SerialName("comm_preference") val commPreference: String,
    @SerialName("interpreter_language") val interpreterLanguage: String,
    @SerialName("accessible_format") val accessibleFormat: String,
    @SerialName("allergy_confirmation_state") val allergyConfirmationState: String,
    @SerialName("last_synced_at") val lastSyncedAt: String,
)

@Serializable
data class PreferencesUpdateBody(
    @SerialName("comm_preference") val commPreference: String,
    @SerialName("interpreter_language") val interpreterLanguage: String,
    @SerialName("accessible_format") val accessibleFormat: String,
    @SerialName("preferred_phone") val preferredPhone: String? = null,
)

@Serializable
data class ProxyGrantDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("patient_name") val patientName: String,
    @SerialName("synthetic_health_id") val syntheticHealthId: String,
    @SerialName("relationship_label") val relationshipLabel: String,
    @SerialName("verification_status") val verificationStatus: String,
    @SerialName("verification_reference") val verificationReference: String,
    val permissions: List<String>,
    @SerialName("restrictions_summary") val restrictionsSummary: String,
    @SerialName("effective_from") val effectiveFrom: String,
    @SerialName("effective_until") val effectiveUntil: String,
    val revoked: Boolean,
    @SerialName("requires_capacity_or_child_policy") val requiresCapacityOrChildPolicy: Boolean,
)

@Serializable
data class AppointmentOfferDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("org_id") val orgId: String,
    @SerialName("org_name") val orgName: String,
    @SerialName("service_name") val serviceName: String,
    @SerialName("clinician_name") val clinicianName: String,
    val location: String,
    val format: String,
    @SerialName("starts_at_london") val startsAtLondon: String,
    @SerialName("ends_at_london") val endsAtLondon: String,
    @SerialName("preparation_instructions") val preparationInstructions: String,
    @SerialName("referral_rule_note") val referralRuleNote: String,
    val status: String,
    @SerialName("hold_expires_at") val holdExpiresAt: String? = null,
)

@Serializable
data class AppointmentDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("org_id") val orgId: String,
    @SerialName("org_name") val orgName: String,
    @SerialName("org_phone") val orgPhone: String,
    @SerialName("offer_id") val offerId: String? = null,
    @SerialName("service_name") val serviceName: String,
    @SerialName("clinician_name") val clinicianName: String,
    val location: String,
    val format: String,
    @SerialName("starts_at_london") val startsAtLondon: String,
    @SerialName("ends_at_london") val endsAtLondon: String,
    @SerialName("preparation_instructions") val preparationInstructions: String,
    val status: String,
    @SerialName("can_cancel") val canCancel: Boolean,
    @SerialName("reschedule_note") val rescheduleNote: String? = null,
    @SerialName("source_system") val sourceSystem: String,
    @SerialName("updated_at") val updatedAt: String,
)

@Serializable
data class HoldOrConfirmBody(
    @SerialName("idempotency_key") val idempotencyKey: String,
    @SerialName("patient_note") val patientNote: String? = null,
)

@Serializable
data class NoSlotAssistBody(
    @SerialName("idempotency_key") val idempotencyKey: String,
    @SerialName("preferred_days") val preferredDays: String,
    val reason: String,
)

@Serializable
data class RescheduleBody(
    val reason: String,
    @SerialName("preferred_window") val preferredWindow: String,
)

@Serializable
data class MedicineRecordDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("name_formulation") val nameFormulation: String,
    val strength: String,
    val directions: String,
    @SerialName("source_org") val sourceOrg: String,
    @SerialName("last_updated_at") val lastUpdatedAt: String,
    @SerialName("repeat_eligible") val repeatEligible: Boolean,
    @SerialName("ineligibility_reason") val ineligibilityReason: String? = null,
    @SerialName("conflict_warning") val conflictWarning: String? = null,
)

@Serializable
data class RepeatMedicineRequestDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("medicine_id") val medicineId: String,
    @SerialName("medicine_name") val medicineName: String,
    @SerialName("preferred_pharmacy_name") val preferredPharmacyName: String,
    @SerialName("patient_note") val patientNote: String? = null,
    val stage: String,
    @SerialName("pharmacy_status") val pharmacyStatus: String,
    @SerialName("reviewer_role") val reviewerRole: String? = null,
    @SerialName("decision_reason") val decisionReason: String? = null,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
)

@Serializable
data class CreateMedicineRequestBody(
    @SerialName("medicine_id") val medicineId: String,
    @SerialName("preferred_pharmacy_name") val preferredPharmacyName: String,
    @SerialName("patient_note") val patientNote: String? = null,
    @SerialName("idempotency_key") val idempotencyKey: String,
)

@Serializable
data class ClinicalRecordDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    val category: String,
    val title: String,
    val summary: String,
    @SerialName("certainty_status") val certaintyStatus: String,
    @SerialName("release_status") val releaseStatus: String,
    @SerialName("source_org") val sourceOrg: String,
    @SerialName("recorded_date") val recordedDate: String,
    @SerialName("result_value") val resultValue: String? = null,
    @SerialName("result_unit") val resultUnit: String? = null,
    @SerialName("reference_range") val referenceRange: String? = null,
    @SerialName("clinician_comment") val clinicianComment: String? = null,
    @SerialName("has_document") val hasDocument: Boolean = false,
    @SerialName("is_stale") val isStale: Boolean = false,
    @SerialName("stale_notice") val staleNotice: String? = null,
)

@Serializable
data class RecordDocumentDto(
    @SerialName("record_id") val recordId: String,
    val title: String,
    val content: String,
)

@Serializable
data class CorrectionRequestDto(
    val id: String,
    @SerialName("record_id") val recordId: String,
    @SerialName("record_title") val recordTitle: String,
    @SerialName("requested_change") val requestedChange: String,
    val status: String,
    @SerialName("staff_response") val staffResponse: String? = null,
    @SerialName("created_at") val createdAt: String,
)

@Serializable
data class CreateCorrectionBody(
    @SerialName("record_id") val recordId: String,
    @SerialName("requested_change") val requestedChange: String,
)

@Serializable
data class ThreadMessageDto(
    val id: String,
    @SerialName("sender_type") val senderType: String,
    @SerialName("sender_label") val senderLabel: String,
    val body: String,
    @SerialName("sent_at") val sentAt: String,
)

@Serializable
data class MessageThreadDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("org_id") val orgId: String,
    @SerialName("org_name") val orgName: String,
    val category: String,
    val subject: String,
    @SerialName("workflow_status") val workflowStatus: String,
    @SerialName("expected_response_window") val expectedResponseWindow: String,
    @SerialName("unread_by_patient") val unreadByPatient: Boolean,
    @SerialName("updated_at") val updatedAt: String,
    val messages: List<ThreadMessageDto>,
)

@Serializable
data class CreateThreadBody(
    @SerialName("org_id") val orgId: String,
    val category: String,
    val subject: String,
    val body: String,
    @SerialName("idempotency_key") val idempotencyKey: String,
)

@Serializable
data class ReplyThreadBody(
    val body: String,
)

@Serializable
data class CareTaskDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("issuing_org_name") val issuingOrgName: String,
    @SerialName("contact_details") val contactDetails: String,
    @SerialName("task_type") val taskType: String,
    val title: String,
    val purpose: String,
    @SerialName("due_date") val dueDate: String,
    val status: String,
    @SerialName("response_json") val responseJson: String? = null,
    @SerialName("measurement_source") val measurementSource: String? = null,
    @SerialName("submitted_at") val submittedAt: String? = null,
)

@Serializable
data class CompleteTaskBody(
    @SerialName("response_summary") val responseSummary: String,
    @SerialName("patient_entered_measurement") val patientEnteredMeasurement: String? = null,
)

@Serializable
data class NotificationDispatchDto(
    val id: String,
    @SerialName("patient_id") val patientId: String,
    @SerialName("generic_preview_text") val genericPreviewText: String,
    @SerialName("delivery_status") val deliveryStatus: String,
    @SerialName("failure_reason") val failureReason: String? = null,
    @SerialName("created_at") val createdAt: String,
)

@Serializable
data class HomeSummaryDto(
    @SerialName("prototype_notice") val prototypeNotice: String,
    @SerialName("active_patient") val activePatient: PatientProfileDto,
    @SerialName("is_proxy_mode") val isProxyMode: Boolean,
    @SerialName("active_proxy_grant") val activeProxyGrant: ProxyGrantDto? = null,
    @SerialName("next_appointment") val nextAppointment: AppointmentDto? = null,
    @SerialName("pending_offers_count") val pendingOffersCount: Int,
    @SerialName("requests_awaiting_action_count") val requestsAwaitingActionCount: Int,
    @SerialName("unread_messages_count") val unreadMessagesCount: Int,
    @SerialName("latest_medicine_request") val latestMedicineRequest: RepeatMedicineRequestDto? = null,
    @SerialName("pending_tasks_count") val pendingTasksCount: Int,
    @SerialName("care_organisations") val careOrganisations: List<OrganisationDto>,
    @SerialName("last_synced_at") val lastSyncedAt: String,
    @SerialName("failed_notifications_count") val failedNotificationsCount: Int = 0,
)
