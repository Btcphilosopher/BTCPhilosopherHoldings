package com.example.data.remote

import com.example.data.model.AppointmentDto
import com.example.data.model.AppointmentOfferDto
import com.example.data.model.AuthSession
import com.example.data.model.CareTaskDto
import com.example.data.model.ClinicalRecordDto
import com.example.data.model.CompleteTaskBody
import com.example.data.model.CorrectionRequestDto
import com.example.data.model.CreateCorrectionBody
import com.example.data.model.CreateMedicineRequestBody
import com.example.data.model.CreateThreadBody
import com.example.data.model.HoldOrConfirmBody
import com.example.data.model.HomeSummaryDto
import com.example.data.model.LoginRequest
import com.example.data.model.MedicineRecordDto
import com.example.data.model.MessageThreadDto
import com.example.data.model.NoSlotAssistBody
import com.example.data.model.NotificationDispatchDto
import com.example.data.model.PatientProfileDto
import com.example.data.model.PreferencesUpdateBody
import com.example.data.model.ProxyGrantDto
import com.example.data.model.RecordDocumentDto
import com.example.data.model.RecoveryGuidance
import com.example.data.model.RepeatMedicineRequestDto
import com.example.data.model.ReplyThreadBody
import com.example.data.model.RescheduleBody
import com.example.data.model.TrustedDeviceDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.put
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
private data class ErrorDetailResponse(val detail: String? = null)

class KtorPatientConnectGateway(
    private val baseUrlProvider: () -> String,
    engine: HttpClientEngine = OkHttp.create(),
) : PatientConnectGateway {

    private val jsonConfig = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private val client = HttpClient(engine) {
        install(ContentNegotiation) {
            json(jsonConfig)
        }
        install(HttpTimeout) {
            requestTimeoutMillis = 12_000
            connectTimeoutMillis = 8_000
        }
    }

    private fun url(path: String): String = "${baseUrlProvider().trimEnd('/')}$path"

    private fun HttpRequestBuilder.authAndPatient(token: String, patientId: String?) {
        header(HttpHeaders.Authorization, "Bearer $token")
        if (!patientId.isNullOrBlank()) {
            parameter("patient_id", patientId)
        }
    }

    private suspend inline fun <reified T> unwrap(response: HttpResponse): T {
        if (!response.status.isSuccess()) {
            val raw = response.bodyAsText()
            val detail = runCatching { jsonConfig.decodeFromString<ErrorDetailResponse>(raw).detail }.getOrNull()
            throw ApiException(response.status.value, detail ?: "Server returned ${response.status.value}")
        }
        return response.body()
    }

    override suspend fun login(request: LoginRequest): AuthSession =
        unwrap(client.post(url("/api/v1/auth/login")) {
            contentType(ContentType.Application.Json)
            setBody(request)
        })

    override suspend fun logout(token: String) {
        client.post(url("/api/v1/auth/logout")) {
            header(HttpHeaders.Authorization, "Bearer $token")
        }
    }

    override suspend fun getDevices(token: String): List<TrustedDeviceDto> =
        unwrap(client.get(url("/api/v1/auth/devices")) {
            header(HttpHeaders.Authorization, "Bearer $token")
        })

    override suspend fun revokeDevice(token: String, deviceId: String) {
        unwrap<Unit>(client.post(url("/api/v1/auth/devices/$deviceId/revoke")) {
            header(HttpHeaders.Authorization, "Bearer $token")
        })
    }

    override suspend fun getRecoveryGuidance(): RecoveryGuidance =
        unwrap(client.get(url("/api/v1/auth/recovery")))

    override suspend fun getHomeSummary(token: String, patientId: String?): HomeSummaryDto =
        unwrap(client.get(url("/api/v1/patient/home")) { authAndPatient(token, patientId) })

    override suspend fun getProxies(token: String): List<ProxyGrantDto> =
        unwrap(client.get(url("/api/v1/patient/proxies")) {
            header(HttpHeaders.Authorization, "Bearer $token")
        })

    override suspend fun updatePreferences(
        token: String,
        patientId: String?,
        body: PreferencesUpdateBody,
    ): PatientProfileDto =
        unwrap(client.put(url("/api/v1/patient/preferences")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun getNotifications(token: String, patientId: String?): List<NotificationDispatchDto> =
        unwrap(client.get(url("/api/v1/patient/notifications")) { authAndPatient(token, patientId) })

    override suspend fun getAppointments(token: String, patientId: String?): List<AppointmentDto> =
        unwrap(client.get(url("/api/v1/appointments")) { authAndPatient(token, patientId) })

    override suspend fun getOffers(token: String, patientId: String?): List<AppointmentOfferDto> =
        unwrap(client.get(url("/api/v1/appointments/offers")) { authAndPatient(token, patientId) })

    override suspend fun holdOffer(
        token: String,
        patientId: String?,
        offerId: String,
        body: HoldOrConfirmBody,
    ): AppointmentOfferDto =
        unwrap(client.post(url("/api/v1/appointments/offers/$offerId/hold")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun confirmOffer(
        token: String,
        patientId: String?,
        offerId: String,
        body: HoldOrConfirmBody,
    ): AppointmentDto =
        unwrap(client.post(url("/api/v1/appointments/offers/$offerId/confirm")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun requestNoSuitableSlots(
        token: String,
        patientId: String?,
        body: NoSlotAssistBody,
    ) {
        unwrap<Map<String, String>>(client.post(url("/api/v1/appointments/no-suitable-slots")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })
    }

    override suspend fun rescheduleAppointment(
        token: String,
        patientId: String?,
        appointmentId: String,
        body: RescheduleBody,
    ): AppointmentDto =
        unwrap(client.post(url("/api/v1/appointments/$appointmentId/reschedule")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun cancelAppointment(
        token: String,
        patientId: String?,
        appointmentId: String,
    ): AppointmentDto =
        unwrap(client.post(url("/api/v1/appointments/$appointmentId/cancel")) {
            authAndPatient(token, patientId)
        })

    override suspend fun getMedicines(token: String, patientId: String?): List<MedicineRecordDto> =
        unwrap(client.get(url("/api/v1/medicines")) { authAndPatient(token, patientId) })

    override suspend fun getRepeatRequests(token: String, patientId: String?): List<RepeatMedicineRequestDto> =
        unwrap(client.get(url("/api/v1/medicines/requests")) { authAndPatient(token, patientId) })

    override suspend fun getRepeatRequestByKey(
        token: String,
        patientId: String?,
        idempotencyKey: String,
    ): RepeatMedicineRequestDto? =
        unwrap(client.get(url("/api/v1/medicines/requests/by-key/$idempotencyKey")) {
            authAndPatient(token, patientId)
        })

    override suspend fun submitRepeatRequest(
        token: String,
        patientId: String?,
        body: CreateMedicineRequestBody,
    ): RepeatMedicineRequestDto =
        unwrap(client.post(url("/api/v1/medicines/requests")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun getReleasedRecords(token: String, patientId: String?): List<ClinicalRecordDto> =
        unwrap(client.get(url("/api/v1/records")) { authAndPatient(token, patientId) })

    override suspend fun getRecordDocument(token: String, patientId: String?, recordId: String): RecordDocumentDto =
        unwrap(client.get(url("/api/v1/records/$recordId/document")) { authAndPatient(token, patientId) })

    override suspend fun getCorrections(token: String, patientId: String?): List<CorrectionRequestDto> =
        unwrap(client.get(url("/api/v1/records/corrections")) { authAndPatient(token, patientId) })

    override suspend fun submitCorrection(
        token: String,
        patientId: String?,
        body: CreateCorrectionBody,
    ): CorrectionRequestDto =
        unwrap(client.post(url("/api/v1/records/corrections")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun getMessageThreads(token: String, patientId: String?): List<MessageThreadDto> =
        unwrap(client.get(url("/api/v1/messages/threads")) { authAndPatient(token, patientId) })

    override suspend fun createThread(
        token: String,
        patientId: String?,
        body: CreateThreadBody,
    ): MessageThreadDto =
        unwrap(client.post(url("/api/v1/messages/threads")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun replyThread(
        token: String,
        patientId: String?,
        threadId: String,
        body: ReplyThreadBody,
    ): MessageThreadDto =
        unwrap(client.post(url("/api/v1/messages/threads/$threadId/reply")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun markThreadRead(
        token: String,
        patientId: String?,
        threadId: String,
    ): MessageThreadDto =
        unwrap(client.post(url("/api/v1/messages/threads/$threadId/mark-read")) {
            authAndPatient(token, patientId)
        })

    override suspend fun getCareTasks(token: String, patientId: String?): List<CareTaskDto> =
        unwrap(client.get(url("/api/v1/tasks")) { authAndPatient(token, patientId) })

    override suspend fun completeCareTask(
        token: String,
        patientId: String?,
        taskId: String,
        body: CompleteTaskBody,
    ): CareTaskDto =
        unwrap(client.post(url("/api/v1/tasks/$taskId/complete")) {
            authAndPatient(token, patientId)
            contentType(ContentType.Application.Json)
            setBody(body)
        })

    override suspend fun simulateStaffConfirmNextBooking(patientId: String?): String =
        "Connected to Live FastAPI Server — use the React Staff Console (port 5173) to confirm bookings."

    override suspend fun simulateStaffAdvanceLatestMedicine(patientId: String?, approve: Boolean): String =
        "Connected to Live FastAPI Server — use the React Staff Console (port 5173) to review medicine requests."

    override suspend fun simulateStaffFailedNotification(patientId: String?): String =
        "Connected to Live FastAPI Server — use the React Staff Console (port 5173) to send messages."
}
