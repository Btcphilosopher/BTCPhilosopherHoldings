package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.CareTaskDto
import com.example.data.model.HomeSummaryDto
import com.example.ui.components.BluePageHeader
import com.example.ui.components.ProxyAccountBanner
import com.example.ui.components.StatusPill
import com.example.util.LondonTimeFormatter

@Composable
fun CareTasksScreen(
    summary: HomeSummaryDto?,
    tasks: List<CareTaskDto>,
    isOffline: Boolean,
    onBack: () -> Unit,
    onCompleteTask: (taskId: String, summary: String, measurement: String?) -> Unit,
    onSwitchBackToSelf: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var activeTask by remember { mutableStateOf<CareTaskDto?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        BluePageHeader(
            title = "Care Tasks & Forms",
            subtitle = "Patient-entered readings retain their source and time and are never treated as clinician-verified observations.",
        )

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("tasks_back_button"),
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Home")
                }
                Text("Back to Home", style = MaterialTheme.typography.titleMedium)
            }

            if (summary?.activeProxyGrant != null) {
                ProxyAccountBanner(
                    patientName = summary.activePatient.fullName,
                    restrictions = summary.activeProxyGrant.restrictionsSummary,
                    onSwitchBack = onSwitchBackToSelf,
                )
            }

            if (tasks.isEmpty()) {
                Text("No clinician-issued care tasks currently open.", style = MaterialTheme.typography.bodyLarge)
            } else {
                tasks.forEach { task ->
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("task_card_${task.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusPill(task.status)
                            Text(task.title, style = MaterialTheme.typography.titleLarge)
                            Text("Issued by: ${task.issuingOrgName}", style = MaterialTheme.typography.labelLarge)
                            Text("Due: ${LondonTimeFormatter.formatDateLabel(task.dueDate)}", style = MaterialTheme.typography.labelMedium)
                            Text(task.purpose, style = MaterialTheme.typography.bodyMedium)
                            Text("Contact: ${task.contactDetails}", style = MaterialTheme.typography.labelMedium)

                            task.measurementSource?.let { src ->
                                Text("Source: $src", style = MaterialTheme.typography.labelMedium)
                            }
                            task.submittedAt?.let { ts ->
                                Text(
                                    "Submitted: ${LondonTimeFormatter.formatShortTimestamp(ts)}",
                                    style = MaterialTheme.typography.labelMedium,
                                )
                            }

                            if (task.status == "PENDING") {
                                Button(
                                    onClick = { activeTask = task },
                                    enabled = !isOffline,
                                    modifier = Modifier.testTag("open_task_${task.id}"),
                                ) {
                                    Text(if (task.taskType == "QUESTIONNAIRE") "Complete questionnaire" else "Mark completed")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    activeTask?.let { task ->
        var responseSummary by remember {
            mutableStateOf(
                if (task.taskType == "QUESTIONNAIRE") {
                    "No chest pain or dizziness over the past 7 days; taking morning Ramipril regularly."
                } else {
                    "Read and understood preparation instructions."
                }
            )
        }
        var bpReading by remember {
            mutableStateOf(if (task.taskType == "QUESTIONNAIRE") "130/80 mmHg (home monitor)" else "")
        }

        AlertDialog(
            onDismissRequest = { activeTask = null },
            title = { Text(task.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Questionnaires do not diagnose conditions or change treatment automatically. Your care team reviews submissions.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedTextField(
                        value = responseSummary,
                        onValueChange = { responseSummary = it },
                        label = { Text("Your response") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("task_response_input"),
                    )
                    if (task.taskType == "QUESTIONNAIRE") {
                        OutlinedTextField(
                            value = bpReading,
                            onValueChange = { bpReading = it },
                            label = { Text("Optional home reading (tagged as patient-entered)") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCompleteTask(task.id, responseSummary, bpReading.takeIf { it.isNotBlank() })
                        activeTask = null
                    },
                    enabled = responseSummary.isNotBlank(),
                    modifier = Modifier.testTag("submit_task_button"),
                ) {
                    Text("Submit")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { activeTask = null }) { Text("Cancel") }
            },
        )
    }
}
