package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.LondonTimeFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name and privacy notification copy`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Patient Connect", context.getString(R.string.app_name))
        val notifText = context.getString(R.string.notification_privacy_text)
        assertTrue(notifText.contains("care team"))
    }

    @Test
    fun `europe london timezone handles GMT and BST cleanly`() {
        val winter = LondonTimeFormatter.formatLondonDateTime("2026-12-08T09:30:00+00:00")
        val summer = LondonTimeFormatter.formatLondonDateTime("2027-04-14T14:15:00+01:00")
        assertTrue(winter.contains("09:30") && winter.contains("GMT"))
        assertTrue(summer.contains("14:15") && summer.contains("BST"))
    }
}
