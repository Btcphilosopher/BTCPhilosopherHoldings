package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.CreateMedicineRequestBody
import com.example.data.model.HoldOrConfirmBody
import com.example.data.model.LoginRequest
import com.example.data.remote.ApiException
import com.example.data.remote.DeterministicSandboxGateway
import com.example.data.repository.InterruptedConnectionException
import com.example.data.repository.OfflineBlockedException
import com.example.data.repository.PatientConnectRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PatientConnectSafetyTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var prefs: UserPreferencesRepository
    private lateinit var gateway: DeterministicSandboxGateway
    private lateinit var repo: PatientConnectRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        prefs = UserPreferencesRepository(context)
        gateway = DeterministicSandboxGateway()
        repo = PatientConnectRepository(db, prefs, sandboxGateway = gateway)
    }

    @After
    fun tearDown() {
        db.close()
    }

    private suspend fun signInDemo(): String {
        val session = gateway.login(
            LoginRequest(
                email = "eleanor.vance@example.org",
                passphrase = "CareConnect!2026",
                verificationCode = "246810",
            )
        )
        return session.accessToken
    }

    @Test
    fun `proxy scope blocks medicine requests and clinical records on restricted father account and blocks child account`() = runTest {
        val token = signInDemo()

        val arthurAppts = gateway.getAppointments(token, "pat_arthur_02")
        assertTrue(arthurAppts.isNotEmpty())

        try {
            gateway.submitRepeatRequest(
                token,
                "pat_arthur_02",
                CreateMedicineRequestBody("med_arthur_salbutamol", "Meadowbank Dispensing Chemist", idempotencyKey = "p1"),
            )
            fail("Expected 403 for restricted proxy medicine request")
        } catch (e: ApiException) {
            assertEquals(403, e.statusCode)
        }

        try {
            gateway.getReleasedRecords(token, "pat_arthur_02")
            fail("Expected 403 for restricted proxy records read")
        } catch (e: ApiException) {
            assertEquals(403, e.statusCode)
        }

        try {
            gateway.getHomeSummary(token, "pat_maya_03")
            fail("Expected 403 for unverified child proxy")
        } catch (e: ApiException) {
            assertEquals(403, e.statusCode)
        }
    }

    @Test
    fun `slot concurrency blocks unavailable and double-booked offers`() = runTest {
        val token = signInDemo()

        try {
            gateway.confirmOffer(token, null, "off_unavailable_conflict", HoldOrConfirmBody("k_unavail"))
            fail("Expected 409 for unavailable offer")
        } catch (e: ApiException) {
            assertEquals(409, e.statusCode)
        }

        val held = gateway.holdOffer(token, null, "off_cardio_01", HoldOrConfirmBody("k_hold"))
        assertEquals("SLOT_HELD", held.status)

        val booked = gateway.confirmOffer(token, null, "off_cardio_01", HoldOrConfirmBody("k_confirm_1"))
        assertEquals("BOOKING_REQUESTED", booked.status)

        try {
            gateway.confirmOffer(token, null, "off_cardio_01", HoldOrConfirmBody("k_confirm_2"))
            fail("Expected 409 for already booked slot")
        } catch (e: ApiException) {
            assertEquals(409, e.statusCode)
        }
    }

    @Test
    fun `interrupted connection uses idempotency status check rather than duplicate submit`() = runTest {
        val token = signInDemo()
        prefs.setSimulateInterruptedConnection(true)

        var capturedKey: String? = null
        try {
            repo.submitRepeatMedicineWithIdempotency(
                token = token,
                patientId = null,
                medicineId = "med_eleanor_ramipril",
                medicineName = "Ramipril capsules",
                preferredPharmacy = "Meadowbank Dispensing Chemist",
                patientNote = null,
            )
            fail("Expected InterruptedConnectionException")
        } catch (e: InterruptedConnectionException) {
            capturedKey = e.idempotencyKey
        }

        assertNotNull(capturedKey)
        val outbox = db.cacheDao().observeOutboxActions("pat_eleanor_01").first()
        assertEquals(1, outbox.size)

        val verified = repo.verifyInterruptedMedicineAction(token, null, outbox.first())
        assertNotNull(verified)
        assertEquals("REQUESTED", verified!!.stage)

        val outboxAfter = db.cacheDao().observeOutboxActions("pat_eleanor_01").first()
        assertTrue(outboxAfter.isEmpty())
    }

    @Test
    fun `offline mode blocks consequential mutations and logout clears Room cache`() = runTest {
        val token = signInDemo()
        val home = gateway.getHomeSummary(token, null)
        val appts = gateway.getAppointments(token, null)
        repo.cacheMinimalHomeAndAppointments(home, appts)

        assertNotNull(db.cacheDao().observeSummary("pat_eleanor_01").first())
        assertTrue(db.cacheDao().observeAppointments("pat_eleanor_01").first().isNotEmpty())

        prefs.setSimulateOffline(true)
        try {
            repo.requireOnline("confirm appointment")
            fail("Expected OfflineBlockedException")
        } catch (_: OfflineBlockedException) {
            // expected
        }
        prefs.setSimulateOffline(false)

        repo.clearSensitiveCache()
        assertNull(db.cacheDao().observeSummary("pat_eleanor_01").first())
        assertTrue(db.cacheDao().observeAppointments("pat_eleanor_01").first().isEmpty())
    }
}
