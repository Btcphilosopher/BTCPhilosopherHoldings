import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.auth import get_current_session, record_audit, resolve_patient_context
from app.config import settings
from app.database import get_db
from app.models import (
    Appointment,
    AppointmentOffer,
    CareOrganisation,
    IdempotencyRecord,
    MessageThread,
    ThreadMessage,
    UserAccount,
    UserSession,
)
from app.schemas import (
    AppointmentDto,
    AppointmentOfferDto,
    ConfirmOfferRequest,
    HoldOfferRequest,
    NoSlotAssistRequest,
    RescheduleRequest,
)

router = APIRouter(prefix="/api/v1/appointments", tags=["appointments"])


def _release_expired_holds(db: Session, patient_id: str) -> None:
    now = datetime.now(timezone.utc)
    held_offers = (
        db.query(AppointmentOffer)
        .filter(AppointmentOffer.patient_id == patient_id, AppointmentOffer.status == "SLOT_HELD")
        .all()
    )
    for offer in held_offers:
        exp = offer.hold_expires_at
        if exp is not None:
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp <= now:
                offer.status = "OFFER_AVAILABLE"
                offer.held_by_user_id = None
                offer.hold_expires_at = None
                offer.version += 1


def _to_offer_dto(o: AppointmentOffer, org_name: str) -> AppointmentOfferDto:
    return AppointmentOfferDto(
        id=o.id,
        patient_id=o.patient_id,
        org_id=o.org_id,
        org_name=org_name,
        service_name=o.service_name,
        clinician_name=o.clinician_name,
        location=o.location,
        format=o.format,
        starts_at_london=o.starts_at_london,
        ends_at_london=o.ends_at_london,
        preparation_instructions=o.preparation_instructions,
        referral_rule_note=o.referral_rule_note,
        status=o.status,
        hold_expires_at=o.hold_expires_at,
    )


def _to_appt_dto(a: Appointment, org: Optional[CareOrganisation]) -> AppointmentDto:
    return AppointmentDto(
        id=a.id,
        patient_id=a.patient_id,
        org_id=a.org_id,
        org_name=org.name if org else a.source_system,
        org_phone=org.phone if org else "",
        offer_id=a.offer_id,
        service_name=a.service_name,
        clinician_name=a.clinician_name,
        location=a.location,
        format=a.format,
        starts_at_london=a.starts_at_london,
        ends_at_london=a.ends_at_london,
        preparation_instructions=a.preparation_instructions,
        status=a.status,
        can_cancel=a.can_cancel,
        reschedule_note=a.reschedule_note,
        source_system=a.source_system,
        updated_at=a.updated_at,
    )


@router.get("", response_model=list[AppointmentDto])
def list_appointments(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "appointments:read")
    appts = (
        db.query(Appointment)
        .filter(Appointment.patient_id == patient.id)
        .order_by(Appointment.starts_at_london.desc())
        .all()
    )
    orgs = {o.id: o for o in db.query(CareOrganisation).all()}
    return [_to_appt_dto(a, orgs.get(a.org_id)) for a in appts]


@router.get("/offers", response_model=list[AppointmentOfferDto])
def list_offers(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "appointments:read")
    _release_expired_holds(db, patient.id)
    db.commit()
    offers = (
        db.query(AppointmentOffer)
        .filter(AppointmentOffer.patient_id == patient.id)
        .order_by(AppointmentOffer.starts_at_london.asc())
        .all()
    )
    orgs = {o.id: o.name for o in db.query(CareOrganisation).all()}
    return [_to_offer_dto(o, orgs.get(o.org_id, "Healthcare Service")) for o in offers]


@router.post("/offers/{offer_id}/hold", response_model=AppointmentOfferDto)
def hold_offer(
    offer_id: str,
    body: HoldOfferRequest,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "appointments:book")
    _release_expired_holds(db, patient.id)

    offer = (
        db.query(AppointmentOffer)
        .filter(AppointmentOffer.id == offer_id, AppointmentOffer.patient_id == patient.id)
        .first()
    )
    if offer is None:
        raise HTTPException(status_code=404, detail="Appointment offer not found.")

    now = datetime.now(timezone.utc)
    if offer.status == "SLOT_HELD" and offer.held_by_user_id == user.id:
        org = db.query(CareOrganisation).filter(CareOrganisation.id == offer.org_id).first()
        return _to_offer_dto(offer, org.name if org else "Healthcare Service")

    if offer.status != "OFFER_AVAILABLE":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This slot is no longer available. Choose another slot or contact the booking team.",
        )

    expected_version = offer.version
    expires = now + timedelta(minutes=settings.slot_hold_minutes)
    updated = (
        db.query(AppointmentOffer)
        .filter(
            AppointmentOffer.id == offer.id,
            AppointmentOffer.version == expected_version,
            AppointmentOffer.status == "OFFER_AVAILABLE",
        )
        .update(
            {
                "status": "SLOT_HELD",
                "held_by_user_id": user.id,
                "hold_expires_at": expires,
                "version": expected_version + 1,
            }
        )
    )
    if updated != 1:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Slot was just taken by another booking attempt. Please pick another time.",
        )
    record_audit(
        db, user.id, user.role, patient.id, "APPOINTMENT_SLOT_HELD", "SUCCESS",
        f"Held offer {offer.id} until {expires.isoformat()}",
    )
    db.commit()
    db.refresh(offer)
    org = db.query(CareOrganisation).filter(CareOrganisation.id == offer.org_id).first()
    return _to_offer_dto(offer, org.name if org else "Healthcare Service")


@router.post("/offers/{offer_id}/confirm", response_model=AppointmentDto)
def confirm_offer(
    offer_id: str,
    body: ConfirmOfferRequest,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "appointments:book")

    existing_idem = (
        db.query(IdempotencyRecord)
        .filter(
            IdempotencyRecord.user_id == user.id,
            IdempotencyRecord.endpoint == f"confirm_offer:{offer_id}",
            IdempotencyRecord.idempotency_key == body.idempotency_key,
        )
        .first()
    )
    if existing_idem is not None:
        return AppointmentDto(**json.loads(existing_idem.response_json))

    _release_expired_holds(db, patient.id)
    offer = (
        db.query(AppointmentOffer)
        .filter(AppointmentOffer.id == offer_id, AppointmentOffer.patient_id == patient.id)
        .first()
    )
    if offer is None:
        raise HTTPException(status_code=404, detail="Appointment offer not found.")

    if offer.status == "UNAVAILABLE":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This appointment slot is unavailable. Your request has been preserved; please contact the booking team or select another slot.",
        )
    if offer.status == "BOOKED":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This slot has already been booked.",
        )
    if offer.status == "SLOT_HELD" and offer.held_by_user_id != user.id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This slot is currently held by another user.",
        )

    expected_version = offer.version
    updated = (
        db.query(AppointmentOffer)
        .filter(
            AppointmentOffer.id == offer.id,
            AppointmentOffer.version == expected_version,
            AppointmentOffer.status.in_(["OFFER_AVAILABLE", "SLOT_HELD"]),
        )
        .update({"status": "BOOKED", "version": expected_version + 1})
    )
    if updated != 1:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Slot conflict during confirmation.")

    org = db.query(CareOrganisation).filter(CareOrganisation.id == offer.org_id).first()
    now = datetime.now(timezone.utc)
    appt = Appointment(
        id=f"apt_{uuid.uuid4().hex[:12]}",
        patient_id=patient.id,
        org_id=offer.org_id,
        offer_id=offer.id,
        service_name=offer.service_name,
        clinician_name=offer.clinician_name,
        location=offer.location,
        format=offer.format,
        starts_at_london=offer.starts_at_london,
        ends_at_london=offer.ends_at_london,
        preparation_instructions=offer.preparation_instructions,
        status="BOOKING_REQUESTED",
        can_cancel=True,
        reschedule_note=body.patient_note,
        source_system=org.name if org else "Hospital PAS",
        updated_at=now,
    )
    db.add(appt)
    dto = _to_appt_dto(appt, org)
    db.add(
        IdempotencyRecord(
            id=f"idm_{uuid.uuid4().hex[:14]}",
            user_id=user.id,
            endpoint=f"confirm_offer:{offer_id}",
            idempotency_key=body.idempotency_key,
            status_code=200,
            response_json=dto.model_dump_json(),
            created_at=now,
        )
    )
    record_audit(
        db, user.id, user.role, patient.id, "APPOINTMENT_BOOKING_REQUESTED", "SUCCESS",
        f"Booked offer {offer.id} -> appointment {appt.id} (status=BOOKING_REQUESTED)",
    )
    db.commit()
    return dto


@router.post("/no-suitable-slots")
def request_staff_booking_assistance(
    body: NoSlotAssistRequest,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "appointments:book")
    now = datetime.now(timezone.utc)
    org = db.query(CareOrganisation).filter(CareOrganisation.id == patient.hospital_org_id).first()

    thread = MessageThread(
        id=f"thr_{uuid.uuid4().hex[:12]}",
        patient_id=patient.id,
        org_id=patient.hospital_org_id,
        category="Appointment queries",
        subject="Staff-assisted appointment booking request (no suitable slots)",
        workflow_status="DELIVERED_TO_SERVICE",
        expected_response_window=org.response_sla if org else "Within 3 working days",
        unread_by_patient=False,
        updated_at=now,
    )
    db.add(thread)
    db.add(
        ThreadMessage(
            id=f"msg_{uuid.uuid4().hex[:12]}",
            thread_id=thread.id,
            sender_type="PATIENT",
            sender_label=user.display_name,
            body=f"No offered slot fits. Preferred days/times: {body.preferred_days}. Notes: {body.reason}",
            sent_at=now,
        )
    )
    record_audit(
        db, user.id, user.role, patient.id, "NO_SLOT_ASSISTANCE_REQUESTED", "SUCCESS",
        f"Preserved no-slot request in thread {thread.id}",
    )
    db.commit()
    return {"status": "REQUEST_PRESERVED", "thread_id": thread.id}


@router.post("/{appointment_id}/reschedule", response_model=AppointmentDto)
def request_reschedule(
    appointment_id: str,
    body: RescheduleRequest,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "appointments:book")
    appt = (
        db.query(Appointment)
        .filter(Appointment.id == appointment_id, Appointment.patient_id == patient.id)
        .first()
    )
    if appt is None:
        raise HTTPException(status_code=404, detail="Appointment not found.")
    if appt.status in {"CANCELLED", "COMPLETED"}:
        raise HTTPException(status_code=400, detail="Cannot reschedule a cancelled or completed appointment.")
    appt.status = "CHANGE_REQUESTED"
    appt.reschedule_note = f"Preferred: {body.preferred_window}. Reason: {body.reason}"
    appt.updated_at = datetime.now(timezone.utc)
    record_audit(
        db, user.id, user.role, patient.id, "APPOINTMENT_CHANGE_REQUESTED", "SUCCESS",
        f"Change requested for appointment {appt.id}",
    )
    db.commit()
    org = db.query(CareOrganisation).filter(CareOrganisation.id == appt.org_id).first()
    return _to_appt_dto(appt, org)


@router.post("/{appointment_id}/cancel", response_model=AppointmentDto)
def cancel_appointment(
    appointment_id: str,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "appointments:book")
    appt = (
        db.query(Appointment)
        .filter(Appointment.id == appointment_id, Appointment.patient_id == patient.id)
        .first()
    )
    if appt is None:
        raise HTTPException(status_code=404, detail="Appointment not found.")
    if not appt.can_cancel or appt.status == "COMPLETED":
        raise HTTPException(status_code=400, detail="This appointment cannot be cancelled online. Please phone the booking team.")
    appt.status = "CANCELLED"
    appt.can_cancel = False
    appt.updated_at = datetime.now(timezone.utc)
    record_audit(
        db, user.id, user.role, patient.id, "APPOINTMENT_CANCELLED", "SUCCESS",
        f"Cancelled appointment {appt.id}",
    )
    db.commit()
    org = db.query(CareOrganisation).filter(CareOrganisation.id == appt.org_id).first()
    return _to_appt_dto(appt, org)
