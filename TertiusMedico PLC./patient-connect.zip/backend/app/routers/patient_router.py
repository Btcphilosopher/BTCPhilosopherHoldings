import json
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.adapters import INTEGRATION_METADATA
from app.auth import get_current_session, record_audit, resolve_patient_context
from app.database import get_db
from app.models import (
    Appointment,
    AppointmentOffer,
    CareOrganisation,
    CareTask,
    MessageThread,
    NotificationDispatch,
    PatientProfile,
    ProxyGrant,
    RepeatMedicineRequest,
    MedicineRecord,
    UserAccount,
    UserSession,
)
from app.schemas import (
    AppointmentDto,
    HomeSummaryDto,
    NotificationDispatchDto,
    OrganisationDto,
    PatientProfileDto,
    PreferencesUpdateRequest,
    ProxyGrantDto,
    RepeatMedicineRequestDto,
)

router = APIRouter(prefix="/api/v1/patient", tags=["patient"])


def _to_org_dto(org: CareOrganisation) -> OrganisationDto:
    return OrganisationDto(
        id=org.id,
        name=org.name,
        org_type=org.org_type,
        phone=org.phone,
        address=org.address,
        hours=org.hours,
        response_sla=org.response_sla,
        synthetic_ods_code=org.synthetic_ods_code,
    )


def _to_profile_dto(p: PatientProfile) -> PatientProfileDto:
    return PatientProfileDto(
        id=p.id,
        synthetic_health_id=p.synthetic_health_id,
        full_name=p.full_name,
        date_of_birth=p.date_of_birth,
        preferred_phone=p.preferred_phone,
        email=p.email,
        comm_preference=p.comm_preference,
        interpreter_language=p.interpreter_language,
        accessible_format=p.accessible_format,
        allergy_confirmation_state=p.allergy_confirmation_state,
        last_synced_at=p.last_synced_at,
    )


def _to_proxy_dto(grant: ProxyGrant, db: Session) -> ProxyGrantDto:
    patient = db.query(PatientProfile).filter(PatientProfile.id == grant.patient_id).first()
    return ProxyGrantDto(
        id=grant.id,
        patient_id=grant.patient_id,
        patient_name=patient.full_name if patient else "Unknown",
        synthetic_health_id=patient.synthetic_health_id if patient else "",
        relationship_label=grant.relationship_label,
        verification_status=grant.verification_status,
        verification_reference=grant.verification_reference,
        permissions=json.loads(grant.permissions_json),
        restrictions_summary=grant.restrictions_summary,
        effective_from=grant.effective_from,
        effective_until=grant.effective_until,
        revoked=grant.revoked_at is not None or grant.verification_status == "REVOKED",
        requires_capacity_or_child_policy=grant.requires_capacity_or_child_policy,
    )


@router.get("/home", response_model=HomeSummaryDto)
def get_home_summary(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, is_proxy, grant = resolve_patient_context(db, user, patient_id, "profile:read")
    now = datetime.now(timezone.utc)
    patient.last_synced_at = now
    db.commit()

    orgs = (
        db.query(CareOrganisation)
        .filter(CareOrganisation.id.in_([patient.gp_org_id, patient.hospital_org_id, patient.pharmacy_org_id]))
        .all()
    )
    org_map = {o.id: o for o in orgs}

    upcoming_appts = (
        db.query(Appointment)
        .filter(
            Appointment.patient_id == patient.id,
            Appointment.status.in_(["BOOKING_CONFIRMED", "BOOKING_REQUESTED", "CHANGE_REQUESTED"]),
        )
        .order_by(Appointment.starts_at_london.asc())
        .all()
    )
    next_appt_dto = None
    if upcoming_appts:
        a = upcoming_appts[0]
        org = org_map.get(a.org_id) or db.query(CareOrganisation).filter(CareOrganisation.id == a.org_id).first()
        next_appt_dto = AppointmentDto(
            id=a.id,
            patient_id=a.patient_id,
            org_id=a.org_id,
            org_name=org.name if org else a.source_system,
            org_phone=org.phone if org else "",
            offer_id=a.offer_id,
            service_name=a.service_name,
            clinician_name=a.clinician_name,
            location=a.location,
            format=a.format,
            starts_at_london=a.starts_at_london,
            ends_at_london=a.ends_at_london,
            preparation_instructions=a.preparation_instructions,
            status=a.status,
            can_cancel=a.can_cancel,
            reschedule_note=a.reschedule_note,
            source_system=a.source_system,
            updated_at=a.updated_at,
        )

    pending_offers_count = (
        db.query(AppointmentOffer)
        .filter(AppointmentOffer.patient_id == patient.id, AppointmentOffer.status == "OFFER_AVAILABLE")
        .count()
    )
    pending_tasks_count = (
        db.query(CareTask)
        .filter(CareTask.patient_id == patient.id, CareTask.status == "PENDING")
        .count()
    )
    unread_messages_count = (
        db.query(MessageThread)
        .filter(MessageThread.patient_id == patient.id, MessageThread.unread_by_patient == True)
        .count()
    )
    latest_med_req = (
        db.query(RepeatMedicineRequest)
        .filter(RepeatMedicineRequest.patient_id == patient.id)
        .order_by(RepeatMedicineRequest.updated_at.desc())
        .first()
    )
    latest_med_dto = None
    if latest_med_req is not None:
        med = db.query(MedicineRecord).filter(MedicineRecord.id == latest_med_req.medicine_id).first()
        latest_med_dto = RepeatMedicineRequestDto(
            id=latest_med_req.id,
            patient_id=latest_med_req.patient_id,
            medicine_id=latest_med_req.medicine_id,
            medicine_name=med.name_formulation if med else "Medicine",
            preferred_pharmacy_name=latest_med_req.preferred_pharmacy_name,
            patient_note=latest_med_req.patient_note,
            stage=latest_med_req.stage,
            pharmacy_status=latest_med_req.pharmacy_status,
            reviewer_role=latest_med_req.reviewer_role,
            decision_reason=latest_med_req.decision_reason,
            created_at=latest_med_req.created_at,
            updated_at=latest_med_req.updated_at,
        )

    awaiting_requests = (
        db.query(RepeatMedicineRequest)
        .filter(
            RepeatMedicineRequest.patient_id == patient.id,
            RepeatMedicineRequest.stage.in_(["REQUESTED", "PRACTICE_REVIEW"]),
        )
        .count()
    ) + pending_tasks_count

    failed_notifications_count = (
        db.query(NotificationDispatch)
        .filter(
            NotificationDispatch.patient_id == patient.id,
            NotificationDispatch.delivery_status != "DELIVERED",
        )
        .count()
    )

    return HomeSummaryDto(
        prototype_notice="Independent prototype using synthetic records. Not affiliated with or endorsed by the NHS.",
        active_patient=_to_profile_dto(patient),
        is_proxy_mode=is_proxy,
        active_proxy_grant=_to_proxy_dto(grant, db) if grant else None,
        next_appointment=next_appt_dto,
        pending_offers_count=pending_offers_count,
        requests_awaiting_action_count=awaiting_requests,
        unread_messages_count=unread_messages_count,
        latest_medicine_request=latest_med_dto,
        pending_tasks_count=pending_tasks_count,
        care_organisations=[_to_org_dto(o) for o in orgs],
        last_synced_at=patient.last_synced_at,
        failed_notifications_count=failed_notifications_count,
    )


@router.get("/proxies", response_model=list[ProxyGrantDto])
def list_proxy_grants(
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    grants = (
        db.query(ProxyGrant)
        .filter(ProxyGrant.representative_user_id == user.id)
        .all()
    )
    return [_to_proxy_dto(g, db) for g in grants]


@router.put("/preferences", response_model=PatientProfileDto)
def update_preferences(
    body: PreferencesUpdateRequest,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, is_proxy, _ = resolve_patient_context(db, user, patient_id, "profile:write")
    patient.comm_preference = body.comm_preference
    patient.interpreter_language = body.interpreter_language
    patient.accessible_format = body.accessible_format
    if body.preferred_phone:
        patient.preferred_phone = body.preferred_phone
    record_audit(
        db,
        user.id,
        user.role,
        patient.id,
        "PREFERENCES_UPDATED",
        "SUCCESS",
        f"Updated communication & accessibility preferences (proxy={is_proxy}).",
    )
    db.commit()
    db.refresh(patient)
    return _to_profile_dto(patient)


@router.get("/notifications", response_model=list[NotificationDispatchDto])
def list_notifications(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "profile:read")
    items = (
        db.query(NotificationDispatch)
        .filter(NotificationDispatch.patient_id == patient.id)
        .order_by(NotificationDispatch.created_at.desc())
        .all()
    )
    return [
        NotificationDispatchDto(
            id=n.id,
            patient_id=n.patient_id,
            generic_preview_text=n.generic_preview_text,
            delivery_status=n.delivery_status,
            failure_reason=n.failure_reason,
            created_at=n.created_at,
        )
        for n in items
    ]


@router.get("/integrations")
def list_integration_metadata(
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
):
    return [
        {
            "domain": m.domain,
            "authoritative_source": m.authoritative_source,
            "freshness_policy": m.freshness_policy,
            "required_permission": m.required_permission,
            "reconciliation_behaviour": m.reconciliation_behaviour,
        }
        for m in INTEGRATION_METADATA
    ]
