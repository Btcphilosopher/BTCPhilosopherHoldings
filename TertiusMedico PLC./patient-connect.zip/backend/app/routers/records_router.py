import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.auth import get_current_session, record_audit, resolve_patient_context
from app.database import get_db
from app.models import (
    ClinicalRecordEntry,
    RecordCorrectionRequest,
    UserAccount,
    UserSession,
)
from app.schemas import (
    ClinicalRecordDto,
    CorrectionRequestDto,
    CreateCorrectionBody,
)
from app.storage import object_storage

router = APIRouter(prefix="/api/v1/records", tags=["records"])


def _to_record_dto(r: ClinicalRecordEntry) -> ClinicalRecordDto:
    return ClinicalRecordDto(
        id=r.id,
        patient_id=r.patient_id,
        category=r.category,
        title=r.title,
        summary=r.summary,
        certainty_status=r.certainty_status,
        release_status=r.release_status,
        source_org=r.source_org,
        recorded_date=r.recorded_date,
        result_value=r.result_value,
        result_unit=r.result_unit,
        reference_range=r.reference_range,
        clinician_comment=r.clinician_comment,
        has_document=r.object_key is not None,
        is_stale=r.is_stale,
        stale_notice=r.stale_notice,
    )


@router.get("", response_model=list[ClinicalRecordDto])
def list_released_records(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "records:read")
    entries = (
        db.query(ClinicalRecordEntry)
        .filter(
            ClinicalRecordEntry.patient_id == patient.id,
            ClinicalRecordEntry.release_status == "RELEASED",
            ClinicalRecordEntry.contains_internal_notes == False,
        )
        .order_by(ClinicalRecordEntry.recorded_date.desc())
        .all()
    )
    return [_to_record_dto(e) for e in entries]


@router.get("/{record_id}/document")
def get_record_document(
    record_id: str,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "records:read")
    entry = (
        db.query(ClinicalRecordEntry)
        .filter(
            ClinicalRecordEntry.id == record_id,
            ClinicalRecordEntry.patient_id == patient.id,
            ClinicalRecordEntry.release_status == "RELEASED",
            ClinicalRecordEntry.contains_internal_notes == False,
        )
        .first()
    )
    if entry is None or not entry.object_key:
        raise HTTPException(status_code=404, detail="Released document not found.")
    text = object_storage.get_text_document(entry.object_key)
    record_audit(
        db, user.id, user.role, patient.id, "RECORD_DOCUMENT_READ", "SUCCESS",
        f"Accessed released document for record {entry.id}",
    )
    db.commit()
    return {"record_id": entry.id, "title": entry.title, "content": text}


@router.get("/corrections", response_model=list[CorrectionRequestDto])
def list_correction_requests(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "records:read")
    reqs = (
        db.query(RecordCorrectionRequest)
        .filter(RecordCorrectionRequest.patient_id == patient.id)
        .order_by(RecordCorrectionRequest.created_at.desc())
        .all()
    )
    recs = {r.id: r.title for r in db.query(ClinicalRecordEntry).filter(ClinicalRecordEntry.patient_id == patient.id).all()}
    return [
        CorrectionRequestDto(
            id=c.id,
            record_id=c.record_id,
            record_title=recs.get(c.record_id, "Clinical record"),
            requested_change=c.requested_change,
            status=c.status,
            staff_response=c.staff_response,
            created_at=c.created_at,
        )
        for c in reqs
    ]


@router.post("/corrections", response_model=CorrectionRequestDto)
def submit_correction_request(
    body: CreateCorrectionBody,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "records:correct")
    entry = (
        db.query(ClinicalRecordEntry)
        .filter(
            ClinicalRecordEntry.id == body.record_id,
            ClinicalRecordEntry.patient_id == patient.id,
            ClinicalRecordEntry.release_status == "RELEASED",
        )
        .first()
    )
    if entry is None:
        raise HTTPException(status_code=404, detail="Clinical record not found.")

    corr = RecordCorrectionRequest(
        id=f"corr_{uuid.uuid4().hex[:12]}",
        patient_id=patient.id,
        record_id=entry.id,
        requested_change=body.requested_change,
        status="SUBMITTED",
        staff_response="Correction request received. Clinical records can only be amended after review by your care organisation.",
        created_at=datetime.now(timezone.utc),
    )
    db.add(corr)
    record_audit(
        db, user.id, user.role, patient.id, "RECORD_CORRECTION_SUBMITTED", "SUCCESS",
        f"Submitted correction request {corr.id} for record {entry.id}",
    )
    db.commit()
    return CorrectionRequestDto(
        id=corr.id,
        record_id=corr.record_id,
        record_title=entry.title,
        requested_change=corr.requested_change,
        status=corr.status,
        staff_response=corr.staff_response,
        created_at=corr.created_at,
    )
