import json
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.adapters import DeterministicNotificationsAdapter
from app.auth import record_audit, require_staff_role
from app.database import get_db
from app.models import (
    Appointment,
    AppointmentOffer,
    AuditLog,
    CareOrganisation,
    CareTask,
    ClinicalRecordEntry,
    MedicineRecord,
    MessageThread,
    NotificationDispatch,
    PatientProfile,
    ProxyGrant,
    RecordCorrectionRequest,
    RepeatMedicineRequest,
    ThreadMessage,
    UserAccount,
)
from app.schemas import (
    StaffAssignTaskBody,
    StaffCreateOfferBody,
    StaffReleaseRecordBody,
    StaffReviewCorrectionBody,
    StaffReviewMedicineBody,
    StaffSendMessageBody,
    StaffUpdateProxyBody,
)

router = APIRouter(prefix="/api/v1/staff", tags=["staff"])
notifier = DeterministicNotificationsAdapter()

STAFF_ALL = {"RECEPTION_ADMIN", "PRESCRIBER", "CLINICIAN", "GOVERNANCE_ADMIN"}
STAFF_BOOKING = {"RECEPTION_ADMIN", "CLINICIAN", "GOVERNANCE_ADMIN"}
STAFF_CLINICAL_DECISION = {"PRESCRIBER", "CLINICIAN"}
STAFF_RECORDS_RELEASE = {"CLINICIAN"}
STAFF_PROXY_GOV = {"GOVERNANCE_ADMIN", "CLINICIAN"}


@router.get("/overview")
def staff_overview(
    staff: UserAccount = Depends(require_staff_role(STAFF_ALL)),
    db: Session = Depends(get_db),
):
    patients = db.query(PatientProfile).all()
    orgs = db.query(CareOrganisation).all()
    offers = db.query(AppointmentOffer).order_by(AppointmentOffer.starts_at_london.asc()).all()
    appointments = db.query(Appointment).order_by(Appointment.starts_at_london.desc()).all()
    med_requests = db.query(RepeatMedicineRequest).order_by(RepeatMedicineRequest.updated_at.desc()).all()
    meds_map = {m.id: m.name_formulation for m in db.query(MedicineRecord).all()}
    records = db.query(ClinicalRecordEntry).order_by(ClinicalRecordEntry.recorded_date.desc()).all()
    corrections = db.query(RecordCorrectionRequest).order_by(RecordCorrectionRequest.created_at.desc()).all()
    threads = db.query(MessageThread).order_by(MessageThread.updated_at.desc()).all()
    tasks = db.query(CareTask).order_by(CareTask.due_date.asc()).all()
    proxies = db.query(ProxyGrant).all()
    audits = db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(60).all()

    return {
        "staff_user": {"id": staff.id, "display_name": staff.display_name, "role": staff.role},
        "patients": [
            {
                "id": p.id,
                "full_name": p.full_name,
                "synthetic_health_id": p.synthetic_health_id,
                "date_of_birth": p.date_of_birth,
            }
            for p in patients
        ],
        "organisations": [{"id": o.id, "name": o.name, "org_type": o.org_type} for o in orgs],
        "offers": [
            {
                "id": o.id,
                "patient_id": o.patient_id,
                "service_name": o.service_name,
                "clinician_name": o.clinician_name,
                "starts_at_london": o.starts_at_london,
                "format": o.format,
                "status": o.status,
            }
            for o in offers
        ],
        "appointments": [
            {
                "id": a.id,
                "patient_id": a.patient_id,
                "service_name": a.service_name,
                "clinician_name": a.clinician_name,
                "starts_at_london": a.starts_at_london,
                "status": a.status,
                "reschedule_note": a.reschedule_note,
            }
            for a in appointments
        ],
        "medicine_requests": [
            {
                "id": r.id,
                "patient_id": r.patient_id,
                "medicine_name": meds_map.get(r.medicine_id, "Medicine"),
                "preferred_pharmacy_name": r.preferred_pharmacy_name,
                "stage": r.stage,
                "pharmacy_status": r.pharmacy_status,
                "decision_reason": r.decision_reason,
                "updated_at": r.updated_at,
            }
            for r in med_requests
        ],
        "records": [
            {
                "id": rec.id,
                "patient_id": rec.patient_id,
                "category": rec.category,
                "title": rec.title,
                "certainty_status": rec.certainty_status,
                "release_status": rec.release_status,
                "contains_internal_notes": rec.contains_internal_notes,
                "clinician_comment": rec.clinician_comment,
                "recorded_date": rec.recorded_date,
            }
            for rec in records
        ],
        "corrections": [
            {
                "id": c.id,
                "patient_id": c.patient_id,
                "record_id": c.record_id,
                "requested_change": c.requested_change,
                "status": c.status,
                "staff_response": c.staff_response,
            }
            for c in corrections
        ],
        "threads": [
            {
                "id": t.id,
                "patient_id": t.patient_id,
                "subject": t.subject,
                "category": t.category,
                "workflow_status": t.workflow_status,
                "updated_at": t.updated_at,
            }
            for t in threads
        ],
        "tasks": [
            {
                "id": tk.id,
                "patient_id": tk.patient_id,
                "title": tk.title,
                "task_type": tk.task_type,
                "due_date": tk.due_date,
                "status": tk.status,
                "measurement_source": tk.measurement_source,
            }
            for tk in tasks
        ],
        "proxies": [
            {
                "id": pr.id,
                "patient_id": pr.patient_id,
                "relationship_label": pr.relationship_label,
                "verification_status": pr.verification_status,
                "permissions": json.loads(pr.permissions_json),
                "restrictions_summary": pr.restrictions_summary,
                "effective_until": pr.effective_until,
                "requires_capacity_or_child_policy": pr.requires_capacity_or_child_policy,
            }
            for pr in proxies
        ],
        "audit_logs": [
            {
                "id": au.id,
                "actor_role": au.actor_role,
                "patient_id": au.patient_id,
                "action": au.action,
                "outcome": au.outcome,
                "redacted_summary": au.redacted_summary,
                "created_at": au.created_at,
            }
            for au in audits
        ],
    }


@router.post("/offers")
def create_offer(
    body: StaffCreateOfferBody,
    staff: UserAccount = Depends(require_staff_role(STAFF_BOOKING)),
    db: Session = Depends(get_db),
):
    offer = AppointmentOffer(
        id=f"off_{uuid.uuid4().hex[:10]}",
        patient_id=body.patient_id,
        org_id=body.org_id,
        service_name=body.service_name,
        clinician_name=body.clinician_name,
        location=body.location,
        format=body.format,
        starts_at_london=body.starts_at_london,
        ends_at_london=body.ends_at_london,
        preparation_instructions=body.preparation_instructions,
        referral_rule_note=body.referral_rule_note,
        status="OFFER_AVAILABLE",
        version=1,
    )
    db.add(offer)
    record_audit(db, staff.id, staff.role, body.patient_id, "STAFF_OFFER_CREATED", "SUCCESS", f"Created offer {offer.id}")
    db.commit()
    return {"id": offer.id, "status": offer.status}


@router.post("/appointments/{appointment_id}/confirm")
def confirm_appointment_booking(
    appointment_id: str,
    staff: UserAccount = Depends(require_staff_role(STAFF_BOOKING)),
    db: Session = Depends(get_db),
):
    appt = db.query(Appointment).filter(Appointment.id == appointment_id).first()
    if appt is None:
        raise HTTPException(status_code=404, detail="Appointment not found.")
    appt.status = "BOOKING_CONFIRMED"
    appt.updated_at = datetime.now(timezone.utc)
    record_audit(
        db, staff.id, staff.role, appt.patient_id, "STAFF_APPOINTMENT_CONFIRMED", "SUCCESS",
        f"Confirmed booking for appointment {appt.id}",
    )
    db.commit()
    return {"id": appt.id, "status": appt.status}


@router.post("/medicines/requests/{request_id}/review")
def review_medicine_request(
    request_id: str,
    body: StaffReviewMedicineBody,
    staff: UserAccount = Depends(require_staff_role(STAFF_CLINICAL_DECISION)),
    db: Session = Depends(get_db),
):
    req = db.query(RepeatMedicineRequest).filter(RepeatMedicineRequest.id == request_id).first()
    if req is None:
        raise HTTPException(status_code=404, detail="Medicine request not found.")
    if body.decision not in {"PRACTICE_REVIEW", "APPROVED", "DECLINED", "PRESCRIPTION_TRANSMITTED"}:
        raise HTTPException(status_code=400, detail="Invalid review decision.")
    if body.decision != "PRESCRIPTION_TRANSMITTED" and body.pharmacy_status in {"PREPARING", "READY_FOR_COLLECTION"}:
        raise HTTPException(
            status_code=400,
            detail="Pharmacy dispensing status cannot be active before prescription transmission is confirmed.",
        )

    req.stage = body.decision
    req.pharmacy_status = body.pharmacy_status
    req.reviewer_role = f"{staff.role} ({staff.display_name})"
    req.decision_reason = body.decision_reason
    req.updated_at = datetime.now(timezone.utc)
    record_audit(
        db, staff.id, staff.role, req.patient_id, "STAFF_MEDICINE_REVIEWED", "SUCCESS",
        f"Reviewed medicine request {req.id} -> stage={req.stage}, pharmacy={req.pharmacy_status}",
    )
    db.commit()
    return {"id": req.id, "stage": req.stage, "pharmacy_status": req.pharmacy_status}


@router.post("/records/{record_id}/release")
def update_record_release(
    record_id: str,
    body: StaffReleaseRecordBody,
    staff: UserAccount = Depends(require_staff_role(STAFF_RECORDS_RELEASE)),
    db: Session = Depends(get_db),
):
    rec = db.query(ClinicalRecordEntry).filter(ClinicalRecordEntry.id == record_id).first()
    if rec is None:
        raise HTTPException(status_code=404, detail="Clinical record not found.")
    if rec.contains_internal_notes and body.release_status == "RELEASED":
        raise HTTPException(
            status_code=400,
            detail="Records marked with internal staff notes or unreviewed third-party drafts cannot be auto-released directly.",
        )
    rec.release_status = body.release_status
    if body.clinician_comment is not None:
        rec.clinician_comment = body.clinician_comment
    record_audit(
        db, staff.id, staff.role, rec.patient_id, "STAFF_RECORD_RELEASE_UPDATED", "SUCCESS",
        f"Updated record {rec.id} release_status={rec.release_status}",
    )
    db.commit()
    return {"id": rec.id, "release_status": rec.release_status}


@router.post("/messages")
def staff_send_message(
    body: StaffSendMessageBody,
    staff: UserAccount = Depends(require_staff_role(STAFF_ALL)),
    db: Session = Depends(get_db),
):
    org = db.query(CareOrganisation).filter(CareOrganisation.id == body.org_id).first()
    if org is None:
        raise HTTPException(status_code=404, detail="Organisation not found.")
    now = datetime.now(timezone.utc)
    thread = MessageThread(
        id=f"thr_{uuid.uuid4().hex[:12]}",
        patient_id=body.patient_id,
        org_id=org.id,
        category=body.category,
        subject=body.subject,
        workflow_status="RESPONSE_AVAILABLE",
        expected_response_window=org.response_sla,
        unread_by_patient=True,
        updated_at=now,
    )
    db.add(thread)
    db.add(
        ThreadMessage(
            id=f"msg_{uuid.uuid4().hex[:12]}",
            thread_id=thread.id,
            sender_type="STAFF",
            sender_label=staff.display_name,
            body=body.body,
            sent_at=now,
        )
    )
    delivery_status, failure_reason = notifier.dispatch(body.patient_id, body.simulate_notification_failure)
    db.add(
        NotificationDispatch(
            id=f"not_{uuid.uuid4().hex[:12]}",
            patient_id=body.patient_id,
            generic_preview_text=notifier.build_privacy_preserving_preview(),
            delivery_status=delivery_status,
            failure_reason=failure_reason,
            created_at=now,
        )
    )
    record_audit(
        db, staff.id, staff.role, body.patient_id, "STAFF_MESSAGE_SENT", "SUCCESS",
        f"Sent thread {thread.id}; notification_status={delivery_status}",
    )
    db.commit()
    return {"thread_id": thread.id, "notification_status": delivery_status}


@router.post("/tasks")
def staff_assign_task(
    body: StaffAssignTaskBody,
    staff: UserAccount = Depends(require_staff_role(STAFF_CLINICAL_DECISION)),
    db: Session = Depends(get_db),
):
    task = CareTask(
        id=f"tsk_{uuid.uuid4().hex[:10]}",
        patient_id=body.patient_id,
        issuing_org_name=body.issuing_org_name,
        contact_details=body.contact_details,
        task_type=body.task_type,
        title=body.title,
        purpose=body.purpose,
        due_date=body.due_date,
        status="PENDING",
    )
    db.add(task)
    record_audit(db, staff.id, staff.role, body.patient_id, "STAFF_TASK_ASSIGNED", "SUCCESS", f"Assigned task {task.id}")
    db.commit()
    return {"id": task.id, "status": task.status}


@router.post("/corrections/{correction_id}/review")
def review_correction(
    correction_id: str,
    body: StaffReviewCorrectionBody,
    staff: UserAccount = Depends(require_staff_role(STAFF_CLINICAL_DECISION)),
    db: Session = Depends(get_db),
):
    corr = db.query(RecordCorrectionRequest).filter(RecordCorrectionRequest.id == correction_id).first()
    if corr is None:
        raise HTTPException(status_code=404, detail="Correction request not found.")
    corr.status = body.status
    corr.staff_response = body.staff_response
    record_audit(
        db, staff.id, staff.role, corr.patient_id, "STAFF_CORRECTION_REVIEWED", "SUCCESS",
        f"Reviewed correction {corr.id} -> status={corr.status}",
    )
    db.commit()
    return {"id": corr.id, "status": corr.status}


@router.put("/proxies/{proxy_id}")
def update_proxy_grant(
    proxy_id: str,
    body: StaffUpdateProxyBody,
    staff: UserAccount = Depends(require_staff_role(STAFF_PROXY_GOV)),
    db: Session = Depends(get_db),
):
    grant = db.query(ProxyGrant).filter(ProxyGrant.id == proxy_id).first()
    if grant is None:
        raise HTTPException(status_code=404, detail="Proxy grant not found.")
    if grant.requires_capacity_or_child_policy and body.verification_status == "VERIFIED" and staff.role != "GOVERNANCE_ADMIN":
        raise HTTPException(
            status_code=403,
            detail="Child/capacity proxy grants require GOVERNANCE_ADMIN sign-off.",
        )
    grant.verification_status = body.verification_status
    grant.permissions_json = json.dumps(body.permissions)
    grant.restrictions_summary = body.restrictions_summary
    grant.effective_until = body.effective_until
    grant.revoked_at = datetime.now(timezone.utc) if body.verification_status == "REVOKED" else None
    record_audit(
        db, staff.id, staff.role, grant.patient_id, "STAFF_PROXY_UPDATED", "SUCCESS",
        f"Updated proxy {grant.id} -> status={grant.verification_status}",
    )
    db.commit()
    return {"id": grant.id, "verification_status": grant.verification_status}


@router.get("/backup-verify")
def verify_backup_snapshot(
    staff: UserAccount = Depends(require_staff_role({"GOVERNANCE_ADMIN"})),
    db: Session = Depends(get_db),
):
    return {
        "verified_at": datetime.now(timezone.utc),
        "patients_count": db.query(PatientProfile).count(),
        "appointments_count": db.query(Appointment).count(),
        "audit_logs_count": db.query(AuditLog).count(),
        "note": "Redacted structural integrity verification for prototype backup check.",
    }
