import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.adapters import DeterministicPatientIdentityAdapter
from app.auth import (
    get_current_session,
    hash_token,
    rate_limiter,
    record_audit,
    verify_password,
)
from app.config import settings
from app.database import get_db
from app.models import TrustedDevice, UserAccount, UserSession
from app.schemas import AuthSessionResponse, LoginRequest, RecoveryGuidanceResponse

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])
identity_adapter = DeterministicPatientIdentityAdapter()


@router.post("/login", response_model=AuthSessionResponse)
def login(body: LoginRequest, request: Request, db: Session = Depends(get_db)):
    rate_limiter.check(f"login:{request.client.host if request.client else 'unknown'}", 20)
    user = db.query(UserAccount).filter(UserAccount.email == body.email.strip().lower()).first()
    if user is None or not user.is_active or not verify_password(body.passphrase, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or passphrase. Note: name, date of birth, or ID number alone cannot grant access.",
        )

    if body.verification_code.strip() != user.totp_demo_code:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Two-step verification code is incorrect.",
        )

    id_result = identity_adapter.verify_credentials(user.email, "***", body.verification_code)
    now = datetime.now(timezone.utc)

    device = (
        db.query(TrustedDevice)
        .filter(
            TrustedDevice.user_id == user.id,
            TrustedDevice.device_name == body.device_name,
            TrustedDevice.revoked == False,
        )
        .first()
    )
    if device is None:
        device = TrustedDevice(
            id=f"dev_{uuid.uuid4().hex[:12]}",
            user_id=user.id,
            device_name=body.device_name,
            platform=body.platform,
            biometric_session_unlock=False,
            revoked=False,
            last_seen_at=now,
        )
        db.add(device)
    else:
        device.last_seen_at = now

    raw_token = secrets.token_urlsafe(36)
    expires_at = now + timedelta(minutes=settings.session_ttl_minutes)
    session = UserSession(
        id=f"ses_{uuid.uuid4().hex[:14]}",
        user_id=user.id,
        device_id=device.id,
        token_hash=hash_token(raw_token),
        expires_at=expires_at,
        revoked=False,
        created_at=now,
    )
    db.add(session)
    record_audit(
        db,
        user.id,
        user.role,
        user.primary_patient_id,
        "AUTH_LOGIN",
        "SUCCESS",
        f"Signed in via {id_result.adapter_name} on device {device.id}",
    )
    db.commit()

    return AuthSessionResponse(
        access_token=raw_token,
        expires_at=expires_at,
        user_id=user.id,
        display_name=user.display_name,
        role=user.role,
        device_id=device.id,
        identity_notice=id_result.message,
        biometric_notice="Optional device biometric unlock only unlocks this device's saved session and does not verify clinical identity.",
    )


@router.post("/logout")
def logout(
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, session = auth_ctx
    session.revoked = True
    record_audit(
        db,
        user.id,
        user.role,
        user.primary_patient_id,
        "AUTH_LOGOUT",
        "SUCCESS",
        f"Explicit logout revoked session {session.id}; client instructed to clear sensitive cache.",
    )
    db.commit()
    return {"status": "logged_out", "clear_local_cache": True}


@router.get("/devices")
def list_devices(
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, session = auth_ctx
    devices = (
        db.query(TrustedDevice)
        .filter(TrustedDevice.user_id == user.id)
        .order_by(TrustedDevice.last_seen_at.desc())
        .all()
    )
    return [
        {
            "id": d.id,
            "device_name": d.device_name,
            "platform": d.platform,
            "biometric_session_unlock": d.biometric_session_unlock,
            "revoked": d.revoked,
            "is_current": d.id == session.device_id,
            "last_seen_at": d.last_seen_at,
        }
        for d in devices
    ]


@router.post("/devices/{device_id}/revoke")
def revoke_device(
    device_id: str,
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    device = (
        db.query(TrustedDevice)
        .filter(TrustedDevice.id == device_id, TrustedDevice.user_id == user.id)
        .first()
    )
    if device is None:
        raise HTTPException(status_code=404, detail="Device not found.")
    device.revoked = True
    db.query(UserSession).filter(UserSession.device_id == device.id).update({"revoked": True})
    record_audit(
        db,
        user.id,
        user.role,
        user.primary_patient_id,
        "DEVICE_REVOKED",
        "SUCCESS",
        f"Revoked device {device.id} and associated active sessions.",
    )
    db.commit()
    return {"status": "revoked", "device_id": device.id}


@router.get("/recovery", response_model=RecoveryGuidanceResponse)
def get_recovery_guidance():
    return RecoveryGuidanceResponse(
        steps=[
            "1. Verify identity with your registered email and secondary recovery factor — name, date of birth, or synthetic health ID alone never grants access.",
            "2. If you have lost your authenticator or device, contact Oakbridge Community Medical Practice reception with photo ID for a supervised account reset.",
            "3. Revoke lost devices from Account -> Trusted Devices once signed back in.",
        ],
        support_contact="Oakbridge Practice Identity Desk: 0113 496 0410 (Mon-Fri 08:00-18:30)",
        security_rule="Independent prototype recovery process — does not use NHS login.",
    )
