import json
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.auth import get_current_session, record_audit, resolve_patient_context
from app.database import get_db
from app.models import (
    CareOrganisation,
    CareTask,
    IdempotencyRecord,
    MessageThread,
    ThreadMessage,
    UserAccount,
    UserSession,
)
from app.schemas import (
    CareTaskDto,
    CompleteTaskBody,
    CreateThreadBody,
    MessageThreadDto,
    ReplyThreadBody,
    ThreadMessageDto,
)

router = APIRouter(prefix="/api/v1", tags=["messages_and_tasks"])


def _to_thread_dto(t: MessageThread, db: Session) -> MessageThreadDto:
    org = db.query(CareOrganisation).filter(CareOrganisation.id == t.org_id).first()
    msgs = (
        db.query(ThreadMessage)
        .filter(ThreadMessage.thread_id == t.id)
        .order_by(ThreadMessage.sent_at.asc())
        .all()
    )
    return MessageThreadDto(
        id=t.id,
        patient_id=t.patient_id,
        org_id=t.org_id,
        org_name=org.name if org else "Care Provider",
        category=t.category,
        subject=t.subject,
        workflow_status=t.workflow_status,
        expected_response_window=t.expected_response_window,
        unread_by_patient=t.unread_by_patient,
        updated_at=t.updated_at,
        messages=[
            ThreadMessageDto(
                id=m.id,
                sender_type=m.sender_type,
                sender_label=m.sender_label,
                body=m.body,
                sent_at=m.sent_at,
            )
            for m in msgs
        ],
    )


@router.get("/messages/threads", response_model=list[MessageThreadDto])
def list_threads(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "messages:read")
    threads = (
        db.query(MessageThread)
        .filter(MessageThread.patient_id == patient.id)
        .order_by(MessageThread.updated_at.desc())
        .all()
    )
    return [_to_thread_dto(t, db) for t in threads]


@router.post("/messages/threads", response_model=MessageThreadDto)
def create_thread(
    body: CreateThreadBody,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "messages:write")

    existing_idem = (
        db.query(IdempotencyRecord)
        .filter(
            IdempotencyRecord.user_id == user.id,
            IdempotencyRecord.endpoint == "create_thread",
            IdempotencyRecord.idempotency_key == body.idempotency_key,
        )
        .first()
    )
    if existing_idem is not None:
        return MessageThreadDto(**json.loads(existing_idem.response_json))

    org = db.query(CareOrganisation).filter(CareOrganisation.id == body.org_id).first()
    if org is None:
        raise HTTPException(status_code=404, detail="Care organisation not found.")
    now = datetime.now(timezone.utc)
    thread = MessageThread(
        id=f"thr_{uuid.uuid4().hex[:12]}",
        patient_id=patient.id,
        org_id=org.id,
        category=body.category,
        subject=body.subject,
        workflow_status="DELIVERED_TO_SERVICE",
        expected_response_window=org.response_sla,
        unread_by_patient=False,
        updated_at=now,
    )
    db.add(thread)
    db.add(
        ThreadMessage(
            id=f"msg_{uuid.uuid4().hex[:12]}",
            thread_id=thread.id,
            sender_type="PATIENT",
            sender_label=user.display_name,
            body=body.body,
            sent_at=now,
        )
    )
    db.flush()
    dto = _to_thread_dto(thread, db)
    db.add(
        IdempotencyRecord(
            id=f"idm_{uuid.uuid4().hex[:14]}",
            user_id=user.id,
            endpoint="create_thread",
            idempotency_key=body.idempotency_key,
            status_code=200,
            response_json=dto.model_dump_json(),
            created_at=now,
        )
    )
    record_audit(
        db, user.id, user.role, patient.id, "MESSAGE_THREAD_CREATED", "SUCCESS",
        f"Created thread {thread.id} (status=DELIVERED_TO_SERVICE)",
    )
    db.commit()
    return dto


@router.post("/messages/threads/{thread_id}/reply", response_model=MessageThreadDto)
def reply_thread(
    thread_id: str,
    body: ReplyThreadBody,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "messages:write")
    thread = (
        db.query(MessageThread)
        .filter(MessageThread.id == thread_id, MessageThread.patient_id == patient.id)
        .first()
    )
    if thread is None:
        raise HTTPException(status_code=404, detail="Thread not found.")
    now = datetime.now(timezone.utc)
    db.add(
        ThreadMessage(
            id=f"msg_{uuid.uuid4().hex[:12]}",
            thread_id=thread.id,
            sender_type="PATIENT",
            sender_label=user.display_name,
            body=body.body,
            sent_at=now,
        )
    )
    thread.workflow_status = "DELIVERED_TO_SERVICE"
    thread.unread_by_patient = False
    thread.updated_at = now
    record_audit(
        db, user.id, user.role, patient.id, "MESSAGE_REPLIED", "SUCCESS",
        f"Patient replied to thread {thread.id}",
    )
    db.commit()
    return _to_thread_dto(thread, db)


@router.post("/messages/threads/{thread_id}/mark-read", response_model=MessageThreadDto)
def mark_thread_read(
    thread_id: str,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "messages:read")
    thread = (
        db.query(MessageThread)
        .filter(MessageThread.id == thread_id, MessageThread.patient_id == patient.id)
        .first()
    )
    if thread is None:
        raise HTTPException(status_code=404, detail="Thread not found.")
    thread.unread_by_patient = False
    db.commit()
    return _to_thread_dto(thread, db)


@router.get("/tasks", response_model=list[CareTaskDto])
def list_care_tasks(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "tasks:read")
    tasks = (
        db.query(CareTask)
        .filter(CareTask.patient_id == patient.id)
        .order_by(CareTask.due_date.asc())
        .all()
    )
    return [
        CareTaskDto(
            id=t.id,
            patient_id=t.patient_id,
            issuing_org_name=t.issuing_org_name,
            contact_details=t.contact_details,
            task_type=t.task_type,
            title=t.title,
            purpose=t.purpose,
            due_date=t.due_date,
            status=t.status,
            response_json=t.response_json,
            measurement_source=t.measurement_source,
            submitted_at=t.submitted_at,
        )
        for t in tasks
    ]


@router.post("/tasks/{task_id}/complete", response_model=CareTaskDto)
def complete_care_task(
    task_id: str,
    body: CompleteTaskBody,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "tasks:write")
    task = (
        db.query(CareTask)
        .filter(CareTask.id == task_id, CareTask.patient_id == patient.id)
        .first()
    )
    if task is None:
        raise HTTPException(status_code=404, detail="Care task not found.")

    now = datetime.now(timezone.utc)
    payload = {
        "response_summary": body.response_summary,
        "patient_entered_measurement": body.patient_entered_measurement,
        "recorded_at_utc": now.isoformat(),
        "source": "Patient-entered (not clinician-verified)",
        "disclaimer": "Questionnaire responses are forwarded to the issuing care team and do not diagnose or alter treatment automatically.",
    }
    task.status = "COMPLETED"
    task.response_json = json.dumps(payload)
    task.measurement_source = "Patient-entered (unverified)"
    task.submitted_at = now
    record_audit(
        db, user.id, user.role, patient.id, "CARE_TASK_COMPLETED", "SUCCESS",
        f"Completed care task {task.id} with patient-entered source tag.",
    )
    db.commit()
    return CareTaskDto(
        id=task.id,
        patient_id=task.patient_id,
        issuing_org_name=task.issuing_org_name,
        contact_details=task.contact_details,
        task_type=task.task_type,
        title=task.title,
        purpose=task.purpose,
        due_date=task.due_date,
        status=task.status,
        response_json=task.response_json,
        measurement_source=task.measurement_source,
        submitted_at=task.submitted_at,
    )
