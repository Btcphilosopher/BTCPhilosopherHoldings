import json
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.auth import get_current_session, record_audit, resolve_patient_context
from app.database import get_db
from app.models import (
    IdempotencyRecord,
    MedicineRecord,
    RepeatMedicineRequest,
    UserAccount,
    UserSession,
)
from app.schemas import (
    CreateMedicineRequestBody,
    MedicineRecordDto,
    RepeatMedicineRequestDto,
)

router = APIRouter(prefix="/api/v1/medicines", tags=["medicines"])


def _to_med_dto(m: MedicineRecord) -> MedicineRecordDto:
    return MedicineRecordDto(
        id=m.id,
        patient_id=m.patient_id,
        name_formulation=m.name_formulation,
        strength=m.strength,
        directions=m.directions,
        source_org=m.source_org,
        last_updated_at=m.last_updated_at,
        repeat_eligible=m.repeat_eligible,
        ineligibility_reason=m.ineligibility_reason,
        conflict_warning=m.conflict_warning,
    )


def _to_req_dto(r: RepeatMedicineRequest, med_name: str) -> RepeatMedicineRequestDto:
    return RepeatMedicineRequestDto(
        id=r.id,
        patient_id=r.patient_id,
        medicine_id=r.medicine_id,
        medicine_name=med_name,
        preferred_pharmacy_name=r.preferred_pharmacy_name,
        patient_note=r.patient_note,
        stage=r.stage,
        pharmacy_status=r.pharmacy_status,
        reviewer_role=r.reviewer_role,
        decision_reason=r.decision_reason,
        created_at=r.created_at,
        updated_at=r.updated_at,
    )


@router.get("", response_model=list[MedicineRecordDto])
def list_medicines(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "medicines:read")
    meds = (
        db.query(MedicineRecord)
        .filter(MedicineRecord.patient_id == patient.id)
        .order_by(MedicineRecord.name_formulation.asc())
        .all()
    )
    return [_to_med_dto(m) for m in meds]


@router.get("/requests", response_model=list[RepeatMedicineRequestDto])
def list_repeat_requests(
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "medicines:read")
    reqs = (
        db.query(RepeatMedicineRequest)
        .filter(RepeatMedicineRequest.patient_id == patient.id)
        .order_by(RepeatMedicineRequest.updated_at.desc())
        .all()
    )
    meds = {m.id: m.name_formulation for m in db.query(MedicineRecord).filter(MedicineRecord.patient_id == patient.id).all()}
    return [_to_req_dto(r, meds.get(r.medicine_id, "Medicine")) for r in reqs]


@router.get("/requests/by-key/{idempotency_key}", response_model=Optional[RepeatMedicineRequestDto])
def get_request_by_idempotency_key(
    idempotency_key: str,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "medicines:read")
    req = (
        db.query(RepeatMedicineRequest)
        .filter(
            RepeatMedicineRequest.patient_id == patient.id,
            RepeatMedicineRequest.idempotency_key == idempotency_key,
        )
        .first()
    )
    if req is None:
        return None
    med = db.query(MedicineRecord).filter(MedicineRecord.id == req.medicine_id).first()
    return _to_req_dto(req, med.name_formulation if med else "Medicine")


@router.post("/requests", response_model=RepeatMedicineRequestDto)
def create_repeat_request(
    body: CreateMedicineRequestBody,
    patient_id: Optional[str] = Query(default=None),
    auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session),
    db: Session = Depends(get_db),
):
    user, _ = auth_ctx
    patient, _, _ = resolve_patient_context(db, user, patient_id, "medicines:request")

    existing_idem = (
        db.query(IdempotencyRecord)
        .filter(
            IdempotencyRecord.user_id == user.id,
            IdempotencyRecord.endpoint == "create_repeat_request",
            IdempotencyRecord.idempotency_key == body.idempotency_key,
        )
        .first()
    )
    if existing_idem is not None:
        return RepeatMedicineRequestDto(**json.loads(existing_idem.response_json))

    med = (
        db.query(MedicineRecord)
        .filter(MedicineRecord.id == body.medicine_id, MedicineRecord.patient_id == patient.id)
        .first()
    )
    if med is None:
        raise HTTPException(status_code=404, detail="Medicine record not found.")
    if not med.repeat_eligible:
        raise HTTPException(
            status_code=400,
            detail=med.ineligibility_reason or "This medicine is not eligible for online repeat requests.",
        )

    now = datetime.now(timezone.utc)
    req = RepeatMedicineRequest(
        id=f"mreq_{uuid.uuid4().hex[:12]}",
        patient_id=patient.id,
        medicine_id=med.id,
        preferred_pharmacy_name=body.preferred_pharmacy_name,
        patient_note=body.patient_note,
        stage="REQUESTED",
        pharmacy_status="NOT_SENT",
        reviewer_role=None,
        decision_reason="Request received — awaiting practice review. This is not yet a signed prescription.",
        idempotency_key=body.idempotency_key,
        created_at=now,
        updated_at=now,
    )
    db.add(req)
    dto = _to_req_dto(req, med.name_formulation)
    db.add(
        IdempotencyRecord(
            id=f"idm_{uuid.uuid4().hex[:14]}",
            user_id=user.id,
            endpoint="create_repeat_request",
            idempotency_key=body.idempotency_key,
            status_code=200,
            response_json=dto.model_dump_json(),
            created_at=now,
        )
    )
    record_audit(
        db, user.id, user.role, patient.id, "MEDICINE_REPEAT_REQUESTED", "SUCCESS",
        f"Created repeat request {req.id} for medicine {med.id} (stage=REQUESTED)",
    )
    db.commit()
    return dto
