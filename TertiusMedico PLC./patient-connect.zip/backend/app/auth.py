import hashlib
import hmac
import json
import secrets
import time
import uuid
from collections import defaultdict, deque
from datetime import date, datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.models import (
    AuditLog,
    PatientProfile,
    ProxyGrant,
    TrustedDevice,
    UserAccount,
    UserSession,
)


def hash_password(password: str, salt: Optional[str] = None) -> str:
    actual_salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        actual_salt.encode("utf-8"),
        120_000,
    ).hex()
    return f"pbkdf2_sha256${actual_salt}${digest}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        scheme, salt, expected = stored_hash.split("$", 2)
        if scheme != "pbkdf2_sha256":
            return False
        actual = hash_password(password, salt).split("$", 2)[2]
        return hmac.compare_digest(actual, expected)
    except ValueError:
        return False


def hash_token(raw_token: str) -> str:
    return hmac.new(
        settings.jwt_signing_secret.encode("utf-8"),
        raw_token.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


class SimpleRateLimiter:
    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def check(self, key: str, limit: int) -> None:
        now = time.monotonic()
        bucket = self._hits[key]
        while bucket and now - bucket[0] > 60.0:
            bucket.popleft()
        if len(bucket) >= limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many requests. Please wait a moment and try again.",
            )
        bucket.append(now)


rate_limiter = SimpleRateLimiter()


def record_audit(
    db: Session,
    actor_user_id: str,
    actor_role: str,
    patient_id: Optional[str],
    action: str,
    outcome: str,
    redacted_summary: str,
) -> None:
    entry = AuditLog(
        id=f"aud_{uuid.uuid4().hex[:16]}",
        actor_user_id=actor_user_id,
        actor_role=actor_role,
        patient_id=patient_id,
        action=action,
        outcome=outcome,
        redacted_summary=redacted_summary[:250],
        created_at=datetime.now(timezone.utc),
    )
    db.add(entry)


def get_current_session(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
) -> tuple[UserAccount, UserSession]:
    rate_limiter.check(request.client.host if request.client else "unknown", settings.rate_limit_per_minute)
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Sign in to view patient information.",
        )
    raw_token = authorization.removeprefix("Bearer ").strip()
    token_digest = hash_token(raw_token)
    session = (
        db.query(UserSession)
        .filter(UserSession.token_hash == token_digest)
        .first()
    )
    if session is None or session.revoked:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session is invalid or signed out.",
        )
    now = datetime.now(timezone.utc)
    expires_at = session.expires_at
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at <= now:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Your session has expired for your protection. Please sign in again.",
        )
    device = db.query(TrustedDevice).filter(TrustedDevice.id == session.device_id).first()
    if device is None or device.revoked:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="This device has been revoked. Please sign in again.",
        )
    user = db.query(UserAccount).filter(UserAccount.id == session.user_id, UserAccount.is_active == True).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Account unavailable.")
    return user, session


def require_staff_role(allowed_roles: set[str]):
    def _dep(auth_ctx: tuple[UserAccount, UserSession] = Depends(get_current_session)) -> UserAccount:
        user, _ = auth_ctx
        if user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{user.role}' is not authorised for this clinical or administrative action.",
            )
        return user

    return _dep


def resolve_patient_context(
    db: Session,
    user: UserAccount,
    requested_patient_id: Optional[str],
    required_permission: str,
) -> tuple[PatientProfile, bool, Optional[ProxyGrant]]:
    """
    Enforces account isolation and proxy scope.
    - If user is accessing their own primary_patient_id, full patient access applies.
    - If accessing another patient, a VERIFIED, non-revoked, in-date ProxyGrant
      containing `required_permission` is mandatory.
    - Unverified child/capacity grants or missing permissions return 403.
    """
    target_id = requested_patient_id or user.primary_patient_id
    if not target_id:
        raise HTTPException(status_code=403, detail="No patient profile linked to this account.")

    patient = db.query(PatientProfile).filter(PatientProfile.id == target_id).first()
    if patient is None:
        raise HTTPException(status_code=404, detail="Patient profile not found.")

    if user.primary_patient_id == target_id:
        return patient, False, None

    grant = (
        db.query(ProxyGrant)
        .filter(
            ProxyGrant.representative_user_id == user.id,
            ProxyGrant.patient_id == target_id,
        )
        .first()
    )
    if grant is None:
        record_audit(
            db, user.id, user.role, target_id, "ACCOUNT_ACCESS", "DENIED",
            f"Blocked cross-account access without proxy grant for permission {required_permission}",
        )
        db.commit()
        raise HTTPException(status_code=403, detail="You are not authorised to access this patient's account.")

    if grant.revoked_at is not None or grant.verification_status != "VERIFIED":
        raise HTTPException(
            status_code=403,
            detail="Proxy access is pending policy review or has been revoked.",
        )

    today = date.today().isoformat()
    if not (grant.effective_from <= today <= grant.effective_until):
        raise HTTPException(status_code=403, detail="Proxy grant is outside its effective dates.")

    permissions = json.loads(grant.permissions_json)
    if required_permission not in permissions:
        record_audit(
            db, user.id, user.role, target_id, "PROXY_SCOPE_CHECK", "DENIED",
            f"Proxy grant {grant.id} lacks permission {required_permission}",
        )
        db.commit()
        raise HTTPException(
            status_code=403,
            detail=f"Your proxy permissions do not allow this action ({required_permission}).",
        )

    return patient, True, grant
