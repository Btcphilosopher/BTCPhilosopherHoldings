import os
import secrets
from dataclasses import dataclass, field
from zoneinfo import ZoneInfo


LONDON_TZ = ZoneInfo("Europe/London")


def _load_jwt_secret() -> str:
    env_val = os.getenv("JWT_SIGNING_SECRET", "").strip()
    if env_val:
        return env_val
    return secrets.token_hex(32)


@dataclass(frozen=True)
class Settings:
    app_env: str = field(default_factory=lambda: os.getenv("APP_ENV", "prototype"))
    database_url: str = field(
        default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///./patient_connect_dev.db")
    )
    jwt_signing_secret: str = field(default_factory=_load_jwt_secret)
    session_ttl_minutes: int = field(
        default_factory=lambda: int(os.getenv("SESSION_TTL_MINUTES", "30"))
    )
    slot_hold_minutes: int = field(
        default_factory=lambda: int(os.getenv("SLOT_HOLD_MINUTES", "5"))
    )
    cors_allowed_origins: list[str] = field(
        default_factory=lambda: [
            o.strip()
            for o in os.getenv(
                "CORS_ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
            ).split(",")
            if o.strip()
        ]
    )
    object_storage_mode: str = field(
        default_factory=lambda: os.getenv("OBJECT_STORAGE_MODE", "local")
    )
    object_storage_local_dir: str = field(
        default_factory=lambda: os.getenv("OBJECT_STORAGE_LOCAL_DIR", "./object_store")
    )
    s3_endpoint_url: str = field(
        default_factory=lambda: os.getenv("S3_ENDPOINT_URL", "http://minio:9000")
    )
    s3_bucket_name: str = field(
        default_factory=lambda: os.getenv("S3_BUCKET_NAME", "tertius-protected-docs")
    )
    s3_access_key: str = field(default_factory=lambda: os.getenv("S3_ACCESS_KEY", ""))
    s3_secret_key: str = field(default_factory=lambda: os.getenv("S3_SECRET_KEY", ""))
    rate_limit_per_minute: int = field(
        default_factory=lambda: int(os.getenv("RATE_LIMIT_PER_MINUTE", "120"))
    )


settings = Settings()
