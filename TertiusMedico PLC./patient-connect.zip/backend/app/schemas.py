from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    email: str = Field(..., min_length=3, max_length=180)
    passphrase: str = Field(..., min_length=6, max_length=120)
    verification_code: str = Field(..., min_length=6, max_length=12)
    device_name: str = Field(default="Android Device", max_length=120)
    platform: str = Field(default="ANDROID", max_length=40)


class AuthSessionResponse(BaseModel):
    access_token: str
    expires_at: datetime
    user_id: str
    display_name: str
    role: str
    device_id: str
    identity_notice: str
    biometric_notice: str


class RecoveryGuidanceResponse(BaseModel):
    steps: list[str]
    support_contact: str
    security_rule: str


class OrganisationDto(BaseModel):
    id: str
    name: str
    org_type: str
    phone: str
    address: str
    hours: str
    response_sla: str
    synthetic_ods_code: str


class PatientProfileDto(BaseModel):
    id: str
    synthetic_health_id: str
    full_name: str
    date_of_birth: str
    preferred_phone: str
    email: str
    comm_preference: str
    interpreter_language: str
    accessible_format: str
    allergy_confirmation_state: str
    last_synced_at: datetime


class PreferencesUpdateRequest(BaseModel):
    comm_preference: str = Field(..., max_length=60)
    interpreter_language: str = Field(..., max_length=80)
    accessible_format: str = Field(..., max_length=80)
    preferred_phone: Optional[str] = Field(default=None, max_length=40)


class ProxyGrantDto(BaseModel):
    id: str
    patient_id: str
    patient_name: str
    synthetic_health_id: str
    relationship_label: str
    verification_status: str
    verification_reference: str
    permissions: list[str]
    restrictions_summary: str
    effective_from: str
    effective_until: str
    revoked: bool
    requires_capacity_or_child_policy: bool


class AppointmentOfferDto(BaseModel):
    id: str
    patient_id: str
    org_id: str
    org_name: str
    service_name: str
    clinician_name: str
    location: str
    format: str
    starts_at_london: str
    ends_at_london: str
    preparation_instructions: str
    referral_rule_note: str
    status: str
    hold_expires_at: Optional[datetime] = None


class AppointmentDto(BaseModel):
    id: str
    patient_id: str
    org_id: str
    org_name: str
    org_phone: str
    offer_id: Optional[str] = None
    service_name: str
    clinician_name: str
    location: str
    format: str
    starts_at_london: str
    ends_at_london: str
    preparation_instructions: str
    status: str
    can_cancel: bool
    reschedule_note: Optional[str] = None
    source_system: str
    updated_at: datetime


class HoldOfferRequest(BaseModel):
    idempotency_key: str = Field(..., min_length=4, max_length=120)


class ConfirmOfferRequest(BaseModel):
    idempotency_key: str = Field(..., min_length=4, max_length=120)
    patient_note: Optional[str] = Field(default=None, max_length=300)


class NoSlotAssistRequest(BaseModel):
    idempotency_key: str = Field(..., min_length=4, max_length=120)
    preferred_days: str = Field(..., min_length=2, max_length=200)
    reason: str = Field(..., min_length=3, max_length=400)


class RescheduleRequest(BaseModel):
    reason: str = Field(..., min_length=3, max_length=300)
    preferred_window: str = Field(..., min_length=3, max_length=140)


class MedicineRecordDto(BaseModel):
    id: str
    patient_id: str
    name_formulation: str
    strength: str
    directions: str
    source_org: str
    last_updated_at: datetime
    repeat_eligible: bool
    ineligibility_reason: Optional[str] = None
    conflict_warning: Optional[str] = None


class RepeatMedicineRequestDto(BaseModel):
    id: str
    patient_id: str
    medicine_id: str
    medicine_name: str
    preferred_pharmacy_name: str
    patient_note: Optional[str] = None
    stage: str
    pharmacy_status: str
    reviewer_role: Optional[str] = None
    decision_reason: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class CreateMedicineRequestBody(BaseModel):
    medicine_id: str
    preferred_pharmacy_name: str = Field(..., min_length=2, max_length=140)
    patient_note: Optional[str] = Field(default=None, max_length=300)
    idempotency_key: str = Field(..., min_length=4, max_length=120)


class ClinicalRecordDto(BaseModel):
    id: str
    patient_id: str
    category: str
    title: str
    summary: str
    certainty_status: str
    release_status: str
    source_org: str
    recorded_date: str
    result_value: Optional[str] = None
    result_unit: Optional[str] = None
    reference_range: Optional[str] = None
    clinician_comment: Optional[str] = None
    has_document: bool = False
    is_stale: bool = False
    stale_notice: Optional[str] = None


class CorrectionRequestDto(BaseModel):
    id: str
    record_id: str
    record_title: str
    requested_change: str
    status: str
    staff_response: Optional[str] = None
    created_at: datetime


class CreateCorrectionBody(BaseModel):
    record_id: str
    requested_change: str = Field(..., min_length=5, max_length=500)


class ThreadMessageDto(BaseModel):
    id: str
    sender_type: str
    sender_label: str
    body: str
    sent_at: datetime


class MessageThreadDto(BaseModel):
    id: str
    patient_id: str
    org_id: str
    org_name: str
    category: str
    subject: str
    workflow_status: str
    expected_response_window: str
    unread_by_patient: bool
    updated_at: datetime
    messages: list[ThreadMessageDto]


class CreateThreadBody(BaseModel):
    org_id: str
    category: str = Field(..., max_length=60)
    subject: str = Field(..., min_length=3, max_length=180)
    body: str = Field(..., min_length=3, max_length=2000)
    idempotency_key: str = Field(..., min_length=4, max_length=120)


class ReplyThreadBody(BaseModel):
    body: str = Field(..., min_length=1, max_length=2000)


class CareTaskDto(BaseModel):
    id: str
    patient_id: str
    issuing_org_name: str
    contact_details: str
    task_type: str
    title: str
    purpose: str
    due_date: str
    status: str
    response_json: Optional[str] = None
    measurement_source: Optional[str] = None
    submitted_at: Optional[datetime] = None


class CompleteTaskBody(BaseModel):
    response_summary: str = Field(..., min_length=2, max_length=1200)
    patient_entered_measurement: Optional[str] = Field(default=None, max_length=200)


class NotificationDispatchDto(BaseModel):
    id: str
    patient_id: str
    generic_preview_text: str
    delivery_status: str
    failure_reason: Optional[str] = None
    created_at: datetime


class HomeSummaryDto(BaseModel):
    prototype_notice: str
    active_patient: PatientProfileDto
    is_proxy_mode: bool
    active_proxy_grant: Optional[ProxyGrantDto] = None
    next_appointment: Optional[AppointmentDto] = None
    pending_offers_count: int
    requests_awaiting_action_count: int
    unread_messages_count: int
    latest_medicine_request: Optional[RepeatMedicineRequestDto] = None
    pending_tasks_count: int
    care_organisations: list[OrganisationDto]
    last_synced_at: datetime
    failed_notifications_count: int


# Staff Console Schemas
class StaffCreateOfferBody(BaseModel):
    patient_id: str
    org_id: str
    service_name: str
    clinician_name: str
    location: str
    format: str
    starts_at_london: str
    ends_at_london: str
    preparation_instructions: str
    referral_rule_note: str


class StaffReviewMedicineBody(BaseModel):
    decision: str  # PRACTICE_REVIEW | APPROVED | DECLINED | PRESCRIPTION_TRANSMITTED
    pharmacy_status: str  # NOT_SENT | PREPARING | READY_FOR_COLLECTION | UNAVAILABLE
    decision_reason: str


class StaffReleaseRecordBody(BaseModel):
    release_status: str  # RELEASED | WITHHELD_PENDING_REVIEW
    clinician_comment: Optional[str] = None


class StaffSendMessageBody(BaseModel):
    patient_id: str
    org_id: str
    category: str
    subject: str
    body: str
    simulate_notification_failure: bool = False


class StaffAssignTaskBody(BaseModel):
    patient_id: str
    issuing_org_name: str
    contact_details: str
    task_type: str
    title: str
    purpose: str
    due_date: str


class StaffReviewCorrectionBody(BaseModel):
    status: str  # UNDER_CLINICAL_REVIEW | ACCEPTED_NOTED | DECLINED
    staff_response: str


class StaffUpdateProxyBody(BaseModel):
    verification_status: str  # VERIFIED | PENDING_POLICY_REVIEW | REVOKED
    permissions: list[str]
    restrictions_summary: str
    effective_until: str
