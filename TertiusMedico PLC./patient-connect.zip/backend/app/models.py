from datetime import datetime, timezone
from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from app.database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class CareOrganisation(Base):
    __tablename__ = "care_organisations"

    id = Column(String(64), primary_key=True)
    name = Column(String(160), nullable=False)
    org_type = Column(String(40), nullable=False)  # GP_PRACTICE | HOSPITAL_TRUST | PHARMACY
    phone = Column(String(40), nullable=False)
    address = Column(String(255), nullable=False)
    hours = Column(String(160), nullable=False)
    response_sla = Column(String(200), nullable=False)
    synthetic_ods_code = Column(String(32), nullable=False)


class UserAccount(Base):
    __tablename__ = "user_accounts"

    id = Column(String(64), primary_key=True)
    email = Column(String(180), nullable=False, unique=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(40), nullable=False)  # PATIENT | RECEPTION_ADMIN | PRESCRIBER | CLINICIAN | GOVERNANCE_ADMIN
    display_name = Column(String(120), nullable=False)
    totp_demo_code = Column(String(16), nullable=False)
    primary_patient_id = Column(String(64), nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class PatientProfile(Base):
    __tablename__ = "patient_profiles"

    id = Column(String(64), primary_key=True)
    synthetic_health_id = Column(String(40), nullable=False, unique=True)
    full_name = Column(String(120), nullable=False)
    date_of_birth = Column(String(20), nullable=False)
    preferred_phone = Column(String(40), nullable=False)
    email = Column(String(180), nullable=False)
    gp_org_id = Column(String(64), ForeignKey("care_organisations.id"), nullable=False)
    hospital_org_id = Column(String(64), ForeignKey("care_organisations.id"), nullable=False)
    pharmacy_org_id = Column(String(64), ForeignKey("care_organisations.id"), nullable=False)
    comm_preference = Column(String(60), nullable=False)
    interpreter_language = Column(String(80), nullable=False)
    accessible_format = Column(String(80), nullable=False)
    allergy_confirmation_state = Column(String(40), nullable=False)  # CONFIRMED_PRESENT | NOT_CONFIRMED
    last_synced_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class TrustedDevice(Base):
    __tablename__ = "trusted_devices"

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("user_accounts.id"), nullable=False)
    device_name = Column(String(120), nullable=False)
    platform = Column(String(40), nullable=False)
    biometric_session_unlock = Column(Boolean, nullable=False, default=False)
    revoked = Column(Boolean, nullable=False, default=False)
    last_seen_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class UserSession(Base):
    __tablename__ = "user_sessions"

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("user_accounts.id"), nullable=False)
    device_id = Column(String(64), ForeignKey("trusted_devices.id"), nullable=False)
    token_hash = Column(String(128), nullable=False, unique=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    revoked = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class ProxyGrant(Base):
    __tablename__ = "proxy_grants"

    id = Column(String(64), primary_key=True)
    representative_user_id = Column(String(64), ForeignKey("user_accounts.id"), nullable=False)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    relationship_label = Column(String(60), nullable=False)
    verification_status = Column(String(40), nullable=False)  # VERIFIED | PENDING_POLICY_REVIEW | REVOKED
    verification_reference = Column(String(120), nullable=False)
    permissions_json = Column(Text, nullable=False)
    restrictions_summary = Column(Text, nullable=False)
    effective_from = Column(String(20), nullable=False)
    effective_until = Column(String(20), nullable=False)
    revoked_at = Column(DateTime(timezone=True), nullable=True)
    requires_capacity_or_child_policy = Column(Boolean, nullable=False, default=False)


class AppointmentOffer(Base):
    __tablename__ = "appointment_offers"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    org_id = Column(String(64), ForeignKey("care_organisations.id"), nullable=False)
    service_name = Column(String(120), nullable=False)
    clinician_name = Column(String(120), nullable=False)
    location = Column(String(160), nullable=False)
    format = Column(String(40), nullable=False)  # IN_PERSON | VIDEO | TELEPHONE
    starts_at_london = Column(String(40), nullable=False)
    ends_at_london = Column(String(40), nullable=False)
    preparation_instructions = Column(Text, nullable=False)
    referral_rule_note = Column(String(200), nullable=False)
    status = Column(String(40), nullable=False)  # OFFER_AVAILABLE | SLOT_HELD | BOOKED | UNAVAILABLE
    held_by_user_id = Column(String(64), nullable=True)
    hold_expires_at = Column(DateTime(timezone=True), nullable=True)
    version = Column(Integer, nullable=False, default=1)


class Appointment(Base):
    __tablename__ = "appointments"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    org_id = Column(String(64), ForeignKey("care_organisations.id"), nullable=False)
    offer_id = Column(String(64), nullable=True)
    service_name = Column(String(120), nullable=False)
    clinician_name = Column(String(120), nullable=False)
    location = Column(String(160), nullable=False)
    format = Column(String(40), nullable=False)
    starts_at_london = Column(String(40), nullable=False)
    ends_at_london = Column(String(40), nullable=False)
    preparation_instructions = Column(Text, nullable=False)
    status = Column(String(40), nullable=False)  # BOOKING_REQUESTED | BOOKING_CONFIRMED | CHANGE_REQUESTED | CANCELLED | COMPLETED
    can_cancel = Column(Boolean, nullable=False, default=True)
    reschedule_note = Column(Text, nullable=True)
    source_system = Column(String(80), nullable=False)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class MedicineRecord(Base):
    __tablename__ = "medicine_records"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    name_formulation = Column(String(160), nullable=False)
    strength = Column(String(60), nullable=False)
    directions = Column(Text, nullable=False)
    source_org = Column(String(120), nullable=False)
    last_updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    repeat_eligible = Column(Boolean, nullable=False, default=True)
    ineligibility_reason = Column(String(200), nullable=True)
    conflict_warning = Column(Text, nullable=True)


class RepeatMedicineRequest(Base):
    __tablename__ = "repeat_medicine_requests"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    medicine_id = Column(String(64), ForeignKey("medicine_records.id"), nullable=False)
    preferred_pharmacy_name = Column(String(140), nullable=False)
    patient_note = Column(Text, nullable=True)
    stage = Column(String(40), nullable=False)  # REQUESTED | PRACTICE_REVIEW | APPROVED | DECLINED | PRESCRIPTION_TRANSMITTED
    pharmacy_status = Column(String(60), nullable=False)  # NOT_SENT | PREPARING | READY_FOR_COLLECTION | UNAVAILABLE
    reviewer_role = Column(String(80), nullable=True)
    decision_reason = Column(Text, nullable=True)
    idempotency_key = Column(String(120), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class ClinicalRecordEntry(Base):
    __tablename__ = "clinical_record_entries"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    category = Column(String(40), nullable=False)  # CONSULTATION | ALLERGY | IMMUNISATION | DIAGNOSIS | LETTER | RESULT
    title = Column(String(180), nullable=False)
    summary = Column(Text, nullable=False)
    certainty_status = Column(String(40), nullable=False)  # CONFIRMED | PROVISIONAL | HISTORICAL | RECORDED
    release_status = Column(String(40), nullable=False)  # RELEASED | WITHHELD_PENDING_REVIEW
    source_org = Column(String(120), nullable=False)
    recorded_date = Column(String(30), nullable=False)
    result_value = Column(String(60), nullable=True)
    result_unit = Column(String(40), nullable=True)
    reference_range = Column(String(80), nullable=True)
    clinician_comment = Column(Text, nullable=True)
    object_key = Column(String(200), nullable=True)
    is_stale = Column(Boolean, nullable=False, default=False)
    stale_notice = Column(String(200), nullable=True)
    contains_internal_notes = Column(Boolean, nullable=False, default=False)


class RecordCorrectionRequest(Base):
    __tablename__ = "record_correction_requests"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    record_id = Column(String(64), ForeignKey("clinical_record_entries.id"), nullable=False)
    requested_change = Column(Text, nullable=False)
    status = Column(String(40), nullable=False)  # SUBMITTED | UNDER_CLINICAL_REVIEW | ACCEPTED_NOTED | DECLINED
    staff_response = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class MessageThread(Base):
    __tablename__ = "message_threads"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    org_id = Column(String(64), ForeignKey("care_organisations.id"), nullable=False)
    category = Column(String(60), nullable=False)
    subject = Column(String(180), nullable=False)
    workflow_status = Column(String(40), nullable=False)  # SUBMITTED | DELIVERED_TO_SERVICE | ASSIGNED | REVIEWED | RESPONSE_AVAILABLE | CLOSED
    expected_response_window = Column(String(180), nullable=False)
    unread_by_patient = Column(Boolean, nullable=False, default=False)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class ThreadMessage(Base):
    __tablename__ = "thread_messages"

    id = Column(String(64), primary_key=True)
    thread_id = Column(String(64), ForeignKey("message_threads.id"), nullable=False)
    sender_type = Column(String(40), nullable=False)  # PATIENT | STAFF | SYSTEM_NOTICE
    sender_label = Column(String(120), nullable=False)
    body = Column(Text, nullable=False)
    sent_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class CareTask(Base):
    __tablename__ = "care_tasks"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    issuing_org_name = Column(String(140), nullable=False)
    contact_details = Column(String(160), nullable=False)
    task_type = Column(String(40), nullable=False)  # QUESTIONNAIRE | PREPARATION | CONFIRM_ATTENDANCE | SUBMIT_INFO | FOLLOW_UP
    title = Column(String(180), nullable=False)
    purpose = Column(Text, nullable=False)
    due_date = Column(String(30), nullable=False)
    status = Column(String(40), nullable=False)  # PENDING | COMPLETED
    response_json = Column(Text, nullable=True)
    measurement_source = Column(String(80), nullable=True)
    submitted_at = Column(DateTime(timezone=True), nullable=True)


class NotificationDispatch(Base):
    __tablename__ = "notification_dispatches"

    id = Column(String(64), primary_key=True)
    patient_id = Column(String(64), ForeignKey("patient_profiles.id"), nullable=False)
    generic_preview_text = Column(String(180), nullable=False)
    delivery_status = Column(String(40), nullable=False)  # DELIVERED | FAILED_FALLBACK_INBOX
    failure_reason = Column(String(200), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)


class IdempotencyRecord(Base):
    __tablename__ = "idempotency_records"

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), nullable=False)
    endpoint = Column(String(120), nullable=False)
    idempotency_key = Column(String(120), nullable=False)
    status_code = Column(Integer, nullable=False)
    response_json = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)

    __table_args__ = (
        UniqueConstraint("user_id", "endpoint", "idempotency_key", name="uq_idempotency_user_ep_key"),
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(64), primary_key=True)
    actor_user_id = Column(String(64), nullable=False)
    actor_role = Column(String(40), nullable=False)
    patient_id = Column(String(64), nullable=True)
    action = Column(String(100), nullable=False)
    outcome = Column(String(40), nullable=False)
    redacted_summary = Column(String(255), nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
