from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class FieldSourceMetadata:
    domain: str
    authoritative_source: str
    freshness_policy: str
    required_permission: str
    reconciliation_behaviour: str


@dataclass(frozen=True)
class IdentityVerificationResult:
    verified: bool
    assurance_level: str
    adapter_name: str
    message: str


class PatientIdentityAdapter(Protocol):
    def verify_credentials(self, email: str, passphrase: str, verification_code: str) -> IdentityVerificationResult: ...


class GpSystemAdapter(Protocol):
    def describe_integration(self) -> FieldSourceMetadata: ...


class HospitalAppointmentsAdapter(Protocol):
    def describe_integration(self) -> FieldSourceMetadata: ...


class MedicinesPrescriptionAdapter(Protocol):
    def describe_integration(self) -> FieldSourceMetadata: ...


class PharmacyStatusAdapter(Protocol):
    def describe_integration(self) -> FieldSourceMetadata: ...


class ReleasedClinicalRecordsAdapter(Protocol):
    def describe_integration(self) -> FieldSourceMetadata: ...


class SecureMessagingAdapter(Protocol):
    def describe_integration(self) -> FieldSourceMetadata: ...


class NotificationsAdapter(Protocol):
    def build_privacy_preserving_preview(self) -> str: ...
    def dispatch(self, patient_id: str, simulate_failure: bool = False) -> tuple[str, str | None]: ...


class DeterministicPatientIdentityAdapter:
    """Replaceable synthetic identity-verification adapter (not NHS login)."""

    def verify_credentials(self, email: str, passphrase: str, verification_code: str) -> IdentityVerificationResult:
        return IdentityVerificationResult(
            verified=True,
            assurance_level="SYNTHETIC_2FA_PROTOTYPE",
            adapter_name="DeterministicPatientIdentityAdapter",
            message="Verified via synthetic prototype identity adapter. Not connected to live NHS login.",
        )


class DeterministicGpSystemAdapter:
    def describe_integration(self) -> FieldSourceMetadata:
        return FieldSourceMetadata(
            domain="GP Systems (Oakbridge Community Medical Practice)",
            authoritative_source="Practice Clinical System (Deterministic Mock)",
            freshness_policy="Synchronised on sign-in and WorkManager schedule; stale flagged > 7 days",
            required_permission="profile:read",
            reconciliation_behaviour="GP system is authoritative for registered practice demographics and primary-care medications.",
        )


class DeterministicHospitalAppointmentsAdapter:
    def describe_integration(self) -> FieldSourceMetadata:
        return FieldSourceMetadata(
            domain="Hospital Appointments (Westgate General Infirmary)",
            authoritative_source="Trust PAS / Booking Engine (Deterministic Mock)",
            freshness_policy="Real-time transactional slot holds (5 min TTL) and confirmation",
            required_permission="appointments:book",
            reconciliation_behaviour="Optimistic version locking prevents double-booking; expired holds automatically release.",
        )


class DeterministicMedicinesPrescriptionAdapter:
    def describe_integration(self) -> FieldSourceMetadata:
        return FieldSourceMetadata(
            domain="Medicines & Repeat Requests",
            authoritative_source="Prescribing Decision Queue (Deterministic Mock)",
            freshness_policy="Status updated on staff review; never inferred from submission",
            required_permission="medicines:request",
            reconciliation_behaviour="Idempotency keys prevent duplicate repeat requests after connection drops.",
        )


class DeterministicPharmacyStatusAdapter:
    def describe_integration(self) -> FieldSourceMetadata:
        return FieldSourceMetadata(
            domain="Pharmacy Dispensing Status (Meadowbank Dispensing Chemist)",
            authoritative_source="Community Pharmacy Feed (Deterministic Mock)",
            freshness_policy="Best-effort status; shows UNAVAILABLE when feed has not confirmed",
            required_permission="medicines:read",
            reconciliation_behaviour="Only updated after prescription transmission is confirmed.",
        )


class DeterministicReleasedClinicalRecordsAdapter:
    def describe_integration(self) -> FieldSourceMetadata:
        return FieldSourceMetadata(
            domain="Released Clinical Records",
            authoritative_source="Hospital & GP Record Release Gate (Deterministic Mock)",
            freshness_policy="Clinician-released entries only; internal notes and unreviewed results strictly withheld",
            required_permission="records:read",
            reconciliation_behaviour="Patients submit structured correction requests; original entries remain immutable by patients.",
        )


class DeterministicSecureMessagingAdapter:
    def describe_integration(self) -> FieldSourceMetadata:
        return FieldSourceMetadata(
            domain="Secure Messaging",
            authoritative_source="Practice & Outpatient Admin Inbox (Deterministic Mock)",
            freshness_policy="Tracks Submitted -> Delivered -> Assigned -> Reviewed -> Response Available -> Closed separately",
            required_permission="messages:read",
            reconciliation_behaviour="Delivery does not imply clinical review.",
        )


class DeterministicNotificationsAdapter:
    def build_privacy_preserving_preview(self) -> str:
        return "You have a new message from your care team."

    def dispatch(self, patient_id: str, simulate_failure: bool = False) -> tuple[str, str | None]:
        if simulate_failure:
            return (
                "FAILED_FALLBACK_INBOX",
                "Push gateway unreachable (simulated). Message remains safely in your in-app inbox.",
            )
        return ("DELIVERED", None)


INTEGRATION_METADATA: list[FieldSourceMetadata] = [
    DeterministicGpSystemAdapter().describe_integration(),
    DeterministicHospitalAppointmentsAdapter().describe_integration(),
    DeterministicMedicinesPrescriptionAdapter().describe_integration(),
    DeterministicPharmacyStatusAdapter().describe_integration(),
    DeterministicReleasedClinicalRecordsAdapter().describe_integration(),
    DeterministicSecureMessagingAdapter().describe_integration(),
]
