import json
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session

from app.auth import hash_password
from app.models import (
    Appointment,
    AppointmentOffer,
    AuditLog,
    CareOrganisation,
    CareTask,
    ClinicalRecordEntry,
    MedicineRecord,
    MessageThread,
    NotificationDispatch,
    PatientProfile,
    ProxyGrant,
    RecordCorrectionRequest,
    RepeatMedicineRequest,
    ThreadMessage,
    TrustedDevice,
    UserAccount,
)
from app.storage import object_storage


def seed_synthetic_data(db: Session) -> None:
    if db.query(CareOrganisation).count() > 0:
        return

    now = datetime.now(timezone.utc)

    # 1. Fictional Healthcare Organisations
    gp = CareOrganisation(
        id="org_oakbridge_gp",
        name="Oakbridge Community Medical Practice",
        org_type="GP_PRACTICE",
        phone="0113 496 0410",
        address="14 Oakbridge Lane, Northborough, NB2 4QA",
        hours="Mon-Fri 08:00-18:30 (Europe/London)",
        response_sla="Practice team aims to respond within 2 working days (non-urgent).",
        synthetic_ods_code="SYN-GP-104",
    )
    hosp = CareOrganisation(
        id="org_westgate_hosp",
        name="Westgate General Infirmary (Fictional Trust)",
        org_type="HOSPITAL_TRUST",
        phone="0113 496 0822",
        address="Westgate Hill, Northborough, NB4 8TR",
        hours="Outpatients Mon-Fri 08:30-17:00",
        response_sla="Outpatient booking desk responds within 3 working days.",
        synthetic_ods_code="SYN-HT-209",
    )
    pharm = CareOrganisation(
        id="org_meadowbank_pharm",
        name="Meadowbank Dispensing Chemist",
        org_type="PHARMACY",
        phone="0113 496 0299",
        address="42 High Street, Northborough, NB1 1AA",
        hours="Mon-Sat 08:30-18:00",
        response_sla="Dispensing updates shown only after confirmed transmission.",
        synthetic_ods_code="SYN-PH-312",
    )
    db.add_all([gp, hosp, pharm])

    # 2. Synthetic Patients
    eleanor = PatientProfile(
        id="pat_eleanor_01",
        synthetic_health_id="TM-904-812-3310",
        full_name="Eleanor Vance",
        date_of_birth="1978-05-14",
        preferred_phone="07700 900412",
        email="eleanor.vance@example.org",
        gp_org_id=gp.id,
        hospital_org_id=hosp.id,
        pharmacy_org_id=pharm.id,
        comm_preference="In-app message & SMS reminder",
        interpreter_language="Not required (English)",
        accessible_format="Large print & high-contrast digital",
        allergy_confirmation_state="CONFIRMED_PRESENT",
        last_synced_at=now - timedelta(minutes=12),
    )
    arthur = PatientProfile(
        id="pat_arthur_02",
        synthetic_health_id="TM-611-204-8891",
        full_name="Arthur Vance",
        date_of_birth="1944-11-03",
        preferred_phone="07700 900188",
        email="arthur.vance@example.org",
        gp_org_id=gp.id,
        hospital_org_id=hosp.id,
        pharmacy_org_id=pharm.id,
        comm_preference="Telephone call (morning)",
        interpreter_language="Not required (English)",
        accessible_format="Extra-large print (18pt)",
        allergy_confirmation_state="NOT_CONFIRMED",  # Demonstrates: never equate missing allergy info with 'no known allergies'
        last_synced_at=now - timedelta(hours=3),
    )
    maya = PatientProfile(
        id="pat_maya_03",
        synthetic_health_id="TM-819-440-1025",
        full_name="Maya Vance",
        date_of_birth="2015-03-22",
        preferred_phone="07700 900412",
        email="parent.contact@example.org",
        gp_org_id=gp.id,
        hospital_org_id=hosp.id,
        pharmacy_org_id=pharm.id,
        comm_preference="Parent/guardian contact pending verification",
        interpreter_language="Not required",
        accessible_format="Standard",
        allergy_confirmation_state="NOT_CONFIRMED",
        last_synced_at=now - timedelta(days=2),
    )
    db.add_all([eleanor, arthur, maya])

    # 3. User Accounts (Patient + Second Isolated Patient + Role-Scoped Staff)
    u_eleanor = UserAccount(
        id="usr_eleanor",
        email="eleanor.vance@example.org",
        password_hash=hash_password("CareConnect!2026"),
        role="PATIENT",
        display_name="Eleanor Vance",
        totp_demo_code="246810",
        primary_patient_id=eleanor.id,
    )
    u_other = UserAccount(
        id="usr_isolated_other",
        email="sam.patel@example.org",
        password_hash=hash_password("PatientTwo!2026"),
        role="PATIENT",
        display_name="Sam Patel",
        totp_demo_code="112233",
        primary_patient_id=arthur.id,  # Separate user for isolation testing
    )
    u_reception = UserAccount(
        id="usr_staff_reception",
        email="reception@oakbridge-demo.org",
        password_hash=hash_password("StaffReception!2026"),
        role="RECEPTION_ADMIN",
        display_name="Hannah Brooks (Booking & Reception)",
        totp_demo_code="654321",
        primary_patient_id=None,
    )
    u_prescriber = UserAccount(
        id="usr_staff_prescriber",
        email="prescriber@oakbridge-demo.org",
        password_hash=hash_password("StaffPrescribe!2026"),
        role="PRESCRIBER",
        display_name="Dr Malik Rahman (GP Prescriber)",
        totp_demo_code="654321",
        primary_patient_id=None,
    )
    u_clinician = UserAccount(
        id="usr_staff_clinician",
        email="clinician@westgate-demo.org",
        password_hash=hash_password("StaffClinician!2026"),
        role="CLINICIAN",
        display_name="Dr Priya Nair (Cardiology Consultant)",
        totp_demo_code="654321",
        primary_patient_id=None,
    )
    u_governance = UserAccount(
        id="usr_staff_governance",
        email="governance@tertius-demo.org",
        password_hash=hash_password("StaffGovernance!2026"),
        role="GOVERNANCE_ADMIN",
        display_name="Claire Davies (Caldicott & Proxy Officer)",
        totp_demo_code="654321",
        primary_patient_id=None,
    )
    db.add_all([u_eleanor, u_other, u_reception, u_prescriber, u_clinician, u_governance])

    # Pre-seed a trusted device for device management demonstration
    db.add(
        TrustedDevice(
            id="dev_eleanor_tablet",
            user_id=u_eleanor.id,
            device_name="Home Pixel Tablet (Previous Session)",
            platform="ANDROID",
            biometric_session_unlock=True,
            revoked=False,
            last_seen_at=now - timedelta(days=2),
        )
    )

    # 4. Proxy Grants
    db.add_all([
        ProxyGrant(
            id="prx_arthur",
            representative_user_id=u_eleanor.id,
            patient_id=arthur.id,
            relationship_label="Adult daughter acting for father (Arthur Vance)",
            verification_status="VERIFIED",
            verification_reference="Practice ID & Signed Consent Ref: PRX-2026-019",
            permissions_json=json.dumps(["profile:read", "appointments:read", "appointments:book", "medicines:read", "messages:read"]),
            restrictions_summary="Read-only for medicines and messages. Cannot submit repeat medicine requests, view full clinical letters/results, or request record corrections.",
            effective_from="2026-01-15",
            effective_until="2027-06-30",
            requires_capacity_or_child_policy=False,
        ),
        ProxyGrant(
            id="prx_maya_blocked",
            representative_user_id=u_eleanor.id,
            patient_id=maya.id,
            relationship_label="Parent / Child record (Maya Vance, age 11)",
            verification_status="PENDING_POLICY_REVIEW",
            verification_reference="Safeguarding & Gillick competence review required (PRX-CHILD-04)",
            permissions_json=json.dumps([]),
            restrictions_summary="Blocked until safeguarding & capacity policy verification is completed by the practice.",
            effective_from="2026-11-01",
            effective_until="2027-11-01",
            requires_capacity_or_child_policy=True,
        ),
    ])

    # 5. Appointments & Eligible Offers (Europe/London)
    # Note: Includes GMT (Nov/Dec) and BST (April) dates to exercise Europe/London DST handling
    db.add_all([
        AppointmentOffer(
            id="off_cardio_01",
            patient_id=eleanor.id,
            org_id=hosp.id,
            service_name="Cardiology Outpatient Follow-up",
            clinician_name="Dr Priya Nair",
            location="Westgate General Infirmary — Outpatients Wing B, Room 12",
            format="IN_PERSON",
            starts_at_london="2026-12-08T09:30:00+00:00",
            ends_at_london="2026-12-08T10:00:00+00:00",
            preparation_instructions="Bring your current medicines list and home blood-pressure readings from the last 7 days. Arrive 15 minutes early.",
            referral_rule_note="Matches reviewed Cardiology Follow-up Referral #WGI-4412 (6-week review window).",
            status="OFFER_AVAILABLE",
            version=1,
        ),
        AppointmentOffer(
            id="off_cardio_02_bst",
            patient_id=eleanor.id,
            org_id=hosp.id,
            service_name="Cardiology Nurse Telephone Review",
            clinician_name="Senior Cardiac Nurse T. Okafor",
            location="Telephone consultation (Westgate Cardiology Desk)",
            format="TELEPHONE",
            starts_at_london="2027-04-14T14:15:00+01:00",  # BST (+01:00)
            ends_at_london="2027-04-14T14:35:00+01:00",
            preparation_instructions="Keep your phone available from 14:05 BST. Withheld numbers may appear.",
            referral_rule_note="Matches Cardiology Nurse Triage Protocol (BST schedule).",
            status="OFFER_AVAILABLE",
            version=1,
        ),
        AppointmentOffer(
            id="off_unavailable_conflict",
            patient_id=eleanor.id,
            org_id=gp.id,
            service_name="GP Medication & Blood Pressure Review",
            clinician_name="Dr Malik Rahman",
            location="Oakbridge Community Medical Practice — Room 3",
            format="IN_PERSON",
            starts_at_london="2026-12-04T11:00:00+00:00",
            ends_at_london="2026-12-04T11:15:00+00:00",
            preparation_instructions="Standard 15-minute GP review.",
            referral_rule_note="Slot recently taken / unavailable — demonstrates conflict handling.",
            status="UNAVAILABLE",
            version=2,
        ),
        AppointmentOffer(
            id="off_arthur_01",
            patient_id=arthur.id,
            org_id=gp.id,
            service_name="Routine Blood Pressure Check",
            clinician_name="Practice Nurse S. Hughes",
            location="Oakbridge Community Medical Practice — Nurse Suite 1",
            format="IN_PERSON",
            starts_at_london="2026-12-11T10:20:00+00:00",
            ends_at_london="2026-12-11T10:35:00+00:00",
            preparation_instructions="Wear a loose sleeve for arm cuff reading.",
            referral_rule_note="Eligible for verified proxy booking.",
            status="OFFER_AVAILABLE",
            version=1,
        ),
    ])

    db.add_all([
        Appointment(
            id="apt_eleanor_upcoming",
            patient_id=eleanor.id,
            org_id=gp.id,
            offer_id=None,
            service_name="Phlebotomy (Fasting Blood Test)",
            clinician_name="HCA Marcus Bell",
            location="Oakbridge Community Medical Practice — Treatment Room 2",
            format="IN_PERSON",
            starts_at_london="2026-12-02T08:40:00+00:00",
            ends_at_london="2026-12-02T08:55:00+00:00",
            preparation_instructions="Fast from midnight (plain water only). Take morning blood-pressure tablet as normal unless told otherwise by your clinician.",
            status="BOOKING_CONFIRMED",
            can_cancel=True,
            source_system="Oakbridge GP Appointments",
            updated_at=now - timedelta(days=1),
        ),
        Appointment(
            id="apt_eleanor_past",
            patient_id=eleanor.id,
            org_id=hosp.id,
            offer_id=None,
            service_name="12-Lead ECG & Echocardiogram",
            clinician_name="Cardiology Diagnostics Team",
            location="Westgate General Infirmary — Cardiac Diagnostics",
            format="IN_PERSON",
            starts_at_london="2026-10-19T10:00:00+01:00",
            ends_at_london="2026-10-19T10:45:00+01:00",
            preparation_instructions="Completed diagnostic appointment.",
            status="COMPLETED",
            can_cancel=False,
            source_system="Westgate PAS",
            updated_at=now - timedelta(days=38),
        ),
        Appointment(
            id="apt_arthur_upcoming",
            patient_id=arthur.id,
            org_id=gp.id,
            offer_id=None,
            service_name="Annual Respiratory Check",
            clinician_name="Dr Malik Rahman",
            location="Oakbridge Community Medical Practice — Room 1",
            format="IN_PERSON",
            starts_at_london="2026-12-15T11:30:00+00:00",
            ends_at_london="2026-12-15T11:50:00+00:00",
            preparation_instructions="Bring all inhalers and spacer device.",
            status="BOOKING_CONFIRMED",
            can_cancel=True,
            source_system="Oakbridge GP Appointments",
            updated_at=now - timedelta(days=3),
        ),
    ])

    # 6. Medicines & Repeat Requests
    med_ramipril = MedicineRecord(
        id="med_eleanor_ramipril",
        patient_id=eleanor.id,
        name_formulation="Ramipril capsules",
        strength="5 mg",
        directions="Take ONE capsule once daily in the morning.",
        source_org="Oakbridge Community Medical Practice (GP Repeat)",
        last_updated_at=now - timedelta(days=5),
        repeat_eligible=True,
        ineligibility_reason=None,
        conflict_warning=None,
    )
    med_atorvastatin = MedicineRecord(
        id="med_eleanor_atorva",
        patient_id=eleanor.id,
        name_formulation="Atorvastatin tablets",
        strength="20 mg",
        directions="Take ONE tablet once daily at night.",
        source_org="Oakbridge Community Medical Practice (GP Repeat)",
        last_updated_at=now - timedelta(days=14),
        repeat_eligible=True,
        ineligibility_reason=None,
        conflict_warning="Hospital letter (Oct 2026) mentions reviewing lipid dose after repeat blood test; GP record currently shows 20 mg. Confirm with your practice if unsure.",
    )
    med_co_codamol = MedicineRecord(
        id="med_eleanor_acute",
        patient_id=eleanor.id,
        name_formulation="Naproxen gastro-resistant tablets",
        strength="250 mg",
        directions="Previously issued as a short acute course — do not continue without GP review.",
        source_org="Oakbridge Community Medical Practice (Acute issue)",
        last_updated_at=now - timedelta(days=45),
        repeat_eligible=False,
        ineligibility_reason="Acute prescription only — requires clinician review before any further issue.",
        conflict_warning=None,
    )
    med_arthur_salbutamol = MedicineRecord(
        id="med_arthur_salbutamol",
        patient_id=arthur.id,
        name_formulation="Salbutamol 100 micrograms/dose pressurised inhalation",
        strength="100 mcg",
        directions="Inhale ONE or TWO puffs when required for shortness of breath.",
        source_org="Oakbridge Community Medical Practice (GP Repeat)",
        last_updated_at=now - timedelta(days=9),
        repeat_eligible=True,
        ineligibility_reason=None,
        conflict_warning=None,
    )
    db.add_all([med_ramipril, med_atorvastatin, med_co_codamol, med_arthur_salbutamol])

    # Seed one declined request to demonstrate transparent refusal & rationale
    db.add(
        RepeatMedicineRequest(
            id="req_med_declined_01",
            patient_id=eleanor.id,
            medicine_id=med_co_codamol.id,
            preferred_pharmacy_name=pharm.name,
            patient_note="Requested extra pack for occasional knee ache.",
            stage="DECLINED",
            pharmacy_status="NOT_SENT",
            reviewer_role="GP Prescriber (Dr Malik Rahman)",
            decision_reason="Declined for automatic repeat: NSAIDs require blood-pressure and kidney-function check alongside Ramipril. Please book a GP review or message the practice.",
            idempotency_key="seed_declined_01",
            created_at=now - timedelta(days=6),
            updated_at=now - timedelta(days=5),
        )
    )

    # 7. Clinical Records (Released vs Withheld + Stale + Letter Object + Unconfirmed Allergy on Arthur)
    letter_text = (
        "WESTGATE GENERAL INFIRMARY — CARDIOLOGY OUTPATIENTS (SYNTHETIC PROTOTYPE)\n"
        "Patient: Eleanor Vance (Synthetic ID: TM-904-812-3310)\n"
        "Date: 19 October 2026\n\n"
        "Summary: Echocardiogram showed preserved left ventricular systolic function. "
        "Continue current GP-prescribed Ramipril 5 mg daily and complete fasting lipid & renal profile prior to December review.\n"
        "Author: Dr Priya Nair, Consultant Cardiologist (Fictional)."
    )
    object_storage.put_text_document("records/pat_eleanor_01/cardiology_letter_oct2026.txt", letter_text)

    db.add_all([
        ClinicalRecordEntry(
            id="rec_consult_01",
            patient_id=eleanor.id,
            category="CONSULTATION",
            title="GP Consultation Summary — Blood Pressure & Lipids Plan",
            summary="Reviewed home blood pressure diary (average 132/82 mmHg). Arranged fasting blood tests before December cardiology follow-up. Advised to continue Ramipril 5 mg.",
            certainty_status="CONFIRMED",
            release_status="RELEASED",
            source_org="Oakbridge Community Medical Practice",
            recorded_date="2026-11-12",
            clinician_comment="Released to patient by Dr Malik Rahman.",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_allergy_01",
            patient_id=eleanor.id,
            category="ALLERGY",
            title="Penicillin V (Phenoxymethylpenicillin) — Adverse Reaction",
            summary="Widespread urticarial rash reported in 2018. Avoid penicillin-class antibiotics.",
            certainty_status="CONFIRMED",
            release_status="RELEASED",
            source_org="Oakbridge Community Medical Practice",
            recorded_date="2018-09-04",
            clinician_comment="Verified allergy record.",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_diagnosis_confirmed",
            patient_id=eleanor.id,
            category="DIAGNOSIS",
            title="Essential (primary) hypertension",
            summary="Long-term condition managed in primary care with lifestyle support and ACE inhibitor therapy.",
            certainty_status="CONFIRMED",
            release_status="RELEASED",
            source_org="Oakbridge Community Medical Practice",
            recorded_date="2022-04-18",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_diagnosis_provisional",
            patient_id=eleanor.id,
            category="DIAGNOSIS",
            title="Suspected white-coat blood pressure variability",
            summary="Provisional impression pending ambulatory / 7-day home blood pressure readings.",
            certainty_status="PROVISIONAL",
            release_status="RELEASED",
            source_org="Westgate General Infirmary",
            recorded_date="2026-10-19",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_diagnosis_historical",
            patient_id=eleanor.id,
            category="DIAGNOSIS",
            title="Resolved iron-deficiency anaemia (2019)",
            summary="Historical entry; resolved following oral supplementation in 2019.",
            certainty_status="HISTORICAL",
            release_status="RELEASED",
            source_org="Oakbridge Community Medical Practice",
            recorded_date="2019-11-10",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_immunisation_01",
            patient_id=eleanor.id,
            category="IMMUNISATION",
            title="Seasonal Influenza Vaccine (2026/27)",
            summary="Administered in left deltoid at Oakbridge Practice clinic. Batch SYN-FLU-26B.",
            certainty_status="RECORDED",
            release_status="RELEASED",
            source_org="Oakbridge Community Medical Practice",
            recorded_date="2026-10-08",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_letter_01",
            patient_id=eleanor.id,
            category="LETTER",
            title="Cardiology Outpatient Clinic Letter (Oct 2026)",
            summary="Echocardiogram summary and plan for fasting lipid/renal blood test prior to follow-up.",
            certainty_status="CONFIRMED",
            release_status="RELEASED",
            source_org="Westgate General Infirmary",
            recorded_date="2026-10-19",
            object_key="records/pat_eleanor_01/cardiology_letter_oct2026.txt",
            clinician_comment="Copy sent to GP and released to patient.",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_result_creatinine",
            patient_id=eleanor.id,
            category="RESULT",
            title="Serum Creatinine & eGFR (Renal Profile)",
            summary="Routine renal monitoring prior to repeat Ramipril review.",
            certainty_status="CONFIRMED",
            release_status="RELEASED",
            source_org="Westgate Pathology Lab (via Oakbridge GP)",
            recorded_date="2026-11-05",
            result_value="74",
            result_unit="umol/L",
            reference_range="45 - 84 umol/L (Adult Female Lab Range)",
            clinician_comment="Within laboratory reference range; satisfactory for continuing current monitoring schedule. Repeat fasting bloods due Dec 2026.",
            is_stale=False,
        ),
        ClinicalRecordEntry(
            id="rec_result_stale",
            patient_id=eleanor.id,
            category="RESULT",
            title="Serum Potassium (Previous Archive Result)",
            summary="Older archived electrolyte result — newer test pending.",
            certainty_status="HISTORICAL",
            release_status="RELEASED",
            source_org="Westgate Pathology Lab",
            recorded_date="2025-11-02",
            result_value="4.3",
            result_unit="mmol/L",
            reference_range="3.5 - 5.3 mmol/L",
            clinician_comment="Archive result from over 12 months ago. Do not rely on this for current treatment decisions.",
            is_stale=True,
            stale_notice="Stale record (>12 months old). Upcoming fasting blood test on 2 Dec 2026 will provide updated values.",
        ),
        # Withheld internal / unreviewed result (MUST NEVER BE RETURNED TO PATIENT!)
        ClinicalRecordEntry(
            id="rec_withheld_internal",
            patient_id=eleanor.id,
            category="RESULT",
            title="24-Hour Holter Tape Preliminary Technician Trace",
            summary="INTERNAL STAFF DRAFT — Unreviewed automated rhythm flags; third-party colleague handover note.",
            certainty_status="PROVISIONAL",
            release_status="WITHHELD_PENDING_REVIEW",
            source_org="Westgate General Infirmary",
            recorded_date="2026-11-24",
            result_value="Pending",
            result_unit="bpm",
            reference_range="Consultant review required",
            clinician_comment="Do not release until Dr Nair reviews full trace.",
            is_stale=False,
            contains_internal_notes=True,
        ),
    ])

    db.add(
        RecordCorrectionRequest(
            id="corr_seed_01",
            patient_id=eleanor.id,
            record_id="rec_allergy_01",
            requested_change="Please clarify that reaction occurred in September 2018 after 2 doses (no breathing difficulty).",
            status="UNDER_CLINICAL_REVIEW",
            staff_response="Received by Oakbridge Practice coding team; awaiting GP confirmation.",
            created_at=now - timedelta(days=2),
        )
    )

    # 8. Messages & Threads
    thr_1 = MessageThread(
        id="thr_eleanor_01",
        patient_id=eleanor.id,
        org_id=hosp.id,
        category="Appointment queries",
        subject="Preparation for your December Cardiology review",
        workflow_status="RESPONSE_AVAILABLE",
        expected_response_window=hosp.response_sla,
        unread_by_patient=True,
        updated_at=now - timedelta(hours=4),
    )
    db.add(thr_1)
    db.add_all([
        ThreadMessage(
            id="msg_01",
            thread_id=thr_1.id,
            sender_type="STAFF",
            sender_label="Westgate Cardiology Booking Team",
            body="Hello Eleanor, we have released eligible follow-up appointment slots for December. Please also complete the 7-day Blood Pressure Log task before attending. If none of the times suit you, reply here.",
            sent_at=now - timedelta(hours=4),
        ),
    ])

    thr_2 = MessageThread(
        id="thr_eleanor_02",
        patient_id=eleanor.id,
        org_id=gp.id,
        category="Administrative help",
        subject="Fasting blood test form confirmation",
        workflow_status="DELIVERED_TO_SERVICE",
        expected_response_window=gp.response_sla,
        unread_by_patient=False,
        updated_at=now - timedelta(days=1),
    )
    db.add(thr_2)
    db.add(
        ThreadMessage(
            id="msg_02",
            thread_id=thr_2.id,
            sender_type="PATIENT",
            sender_label="Eleanor Vance",
            body="Could you confirm whether my paper blood form is already with the treatment room for 2 December?",
            sent_at=now - timedelta(days=1),
        )
    )

    # 9. Care Tasks & Forms
    db.add_all([
        CareTask(
            id="tsk_bp_questionnaire",
            patient_id=eleanor.id,
            issuing_org_name="Westgate General Infirmary — Cardiology",
            contact_details="Cardiology Desk: 0113 496 0822",
            task_type="QUESTIONNAIRE",
            title="Pre-Clinic Home Blood Pressure & Symptom Check",
            purpose="Helps your cardiology team review recent home readings alongside your clinic assessment. Readings you enter are recorded as patient-entered observations.",
            due_date="2026-12-06",
            status="PENDING",
        ),
        CareTask(
            id="tsk_prep_read",
            patient_id=eleanor.id,
            issuing_org_name="Oakbridge Community Medical Practice",
            contact_details="Reception: 0113 496 0410",
            task_type="PREPARATION",
            title="Read fasting instructions for 2 Dec blood test",
            purpose="Confirm you have read the fasting guidance (water only from midnight).",
            due_date="2026-12-01",
            status="PENDING",
        ),
    ])

    # 10. Notifications (1 delivered privacy-preserving, 1 simulated failure)
    db.add_all([
        NotificationDispatch(
            id="not_01",
            patient_id=eleanor.id,
            generic_preview_text="You have a new message from your care team.",
            delivery_status="DELIVERED",
            failure_reason=None,
            created_at=now - timedelta(hours=4),
        ),
        NotificationDispatch(
            id="not_02_failed",
            patient_id=eleanor.id,
            generic_preview_text="You have a new message from your care team.",
            delivery_status="FAILED_FALLBACK_INBOX",
            failure_reason="Simulated push delivery failure — alert preserved inside app without exposing sensitive data.",
            created_at=now - timedelta(hours=1),
        ),
    ])

    db.add(
        AuditLog(
            id="aud_seed_01",
            actor_user_id="system_seed",
            actor_role="SYSTEM",
            patient_id=eleanor.id,
            action="SYNTHETIC_SEED",
            outcome="SUCCESS",
            redacted_summary="Initialised fictional organisations and synthetic patient fixtures.",
            created_at=now,
        )
    )
    db.commit()
