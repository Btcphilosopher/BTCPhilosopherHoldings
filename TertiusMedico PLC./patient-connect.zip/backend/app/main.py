from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, SessionLocal, engine
from app.fixtures import seed_synthetic_data
from app.routers import (
    appointments_router,
    auth_router,
    medicines_router,
    messages_tasks_router,
    patient_router,
    records_router,
    staff_router,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_synthetic_data(db)
    finally:
        db.close()
    yield


app = FastAPI(
    title="TERTIUSMEDICO — Patient Connect Prototype API",
    version="0.1.0",
    description="Independent healthcare prototype backend using fictional organisations and synthetic patient records. Not affiliated with or endorsed by the NHS.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

app.include_router(auth_router.router)
app.include_router(patient_router.router)
app.include_router(appointments_router.router)
app.include_router(medicines_router.router)
app.include_router(records_router.router)
app.include_router(messages_tasks_router.router)
app.include_router(staff_router.router)


@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "service": "tertiusmedico-patient-connect-backend",
        "timezone": "Europe/London",
        "prototype_notice": "Independent prototype with synthetic data. Not NHS.",
    }
