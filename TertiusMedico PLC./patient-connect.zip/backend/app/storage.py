import os
from pathlib import Path
from app.config import settings


class ProtectedObjectStorage:
    """
    Protected object storage abstraction.
    Uses local confined directory with path traversal guards by default,
    and supports S3-compatible storage (MinIO) when OBJECT_STORAGE_MODE=s3.
    """

    def __init__(self) -> None:
        self.base_dir = Path(settings.object_storage_local_dir).resolve()
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _safe_local_path(self, object_key: str) -> Path:
        clean_key = object_key.lstrip("/")
        resolved = (self.base_dir / clean_key).resolve()
        base_str = str(self.base_dir)
        if not str(resolved).startswith(base_str + os.sep):
            raise ValueError("Invalid object key path")
        resolved.parent.mkdir(parents=True, exist_ok=True)
        return resolved

    def put_text_document(self, object_key: str, content: str) -> None:
        if settings.object_storage_mode == "s3" and settings.s3_access_key and settings.s3_secret_key:
            import boto3

            client = boto3.client(
                "s3",
                endpoint_url=settings.s3_endpoint_url,
                aws_access_key_id=settings.s3_access_key,
                aws_secret_access_key=settings.s3_secret_key,
            )
            client.put_object(
                Bucket=settings.s3_bucket_name,
                Key=object_key,
                Body=content.encode("utf-8"),
                ContentType="text/plain; charset=utf-8",
            )
            return

        path = self._safe_local_path(object_key)
        path.write_text(content, encoding="utf-8")

    def get_text_document(self, object_key: str) -> str:
        if settings.object_storage_mode == "s3" and settings.s3_access_key and settings.s3_secret_key:
            import boto3

            client = boto3.client(
                "s3",
                endpoint_url=settings.s3_endpoint_url,
                aws_access_key_id=settings.s3_access_key,
                aws_secret_access_key=settings.s3_secret_key,
            )
            resp = client.get_object(Bucket=settings.s3_bucket_name, Key=object_key)
            return resp["Body"].read().decode("utf-8")

        path = self._safe_local_path(object_key)
        if not path.exists():
            return "Document unavailable in storage."
        return path.read_text(encoding="utf-8")


object_storage = ProtectedObjectStorage()
