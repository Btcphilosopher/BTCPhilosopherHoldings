import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ["OBJECT_STORAGE_LOCAL_DIR"] = tempfile.mkdtemp(prefix="tm_stdlib_obj_")

from app.storage import ProtectedObjectStorage  # noqa: E402


class StdlibSecurityTests(unittest.TestCase):
    def test_storage_blocks_path_traversal(self):
        storage = ProtectedObjectStorage()
        with self.assertRaises(ValueError):
            storage._safe_local_path("../../etc/passwd")

    def test_storage_round_trip(self):
        storage = ProtectedObjectStorage()
        storage.put_text_document("records/test_pat/note.txt", "Synthetic summary")
        self.assertEqual(storage.get_text_document("records/test_pat/note.txt"), "Synthetic summary")


if __name__ == "__main__":
    unittest.main()
