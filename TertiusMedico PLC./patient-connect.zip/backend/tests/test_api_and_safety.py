import os
import tempfile
import uuid

import pytest
from fastapi.testclient import TestClient

os.environ["DATABASE_URL"] = "sqlite:///./test_patient_connect.db"
os.environ["OBJECT_STORAGE_LOCAL_DIR"] = tempfile.mkdtemp(prefix="tm_obj_")

from app.database import Base, SessionLocal, engine  # noqa: E402
from app.fixtures import seed_synthetic_data  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(autouse=True)
def reset_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_synthetic_data(db)
    finally:
        db.close()
    yield


def _login(client: TestClient, email: str, passphrase: str, code: str) -> str:
    res = client.post(
        "/api/v1/auth/login",
        json={
            "email": email,
            "passphrase": passphrase,
            "verification_code": code,
            "device_name": "Pytest Device",
            "platform": "TEST",
        },
    )
    assert res.status_code == 200, res.text
    return res.json()["access_token"]


def test_account_isolation_blocks_unauthorised_patient_access():
    with TestClient(app) as client:
        sam_token = _login(client, "sam.patel@example.org", "PatientTwo!2026", "112233")
        # Sam Patel tries to access Eleanor Vance's records without a proxy grant
        res = client.get(
            "/api/v1/records?patient_id=pat_eleanor_01",
            headers={"Authorization": f"Bearer {sam_token}"},
        )
        assert res.status_code == 403


def test_proxy_scope_and_child_policy_gate():
    with TestClient(app) as client:
        token = _login(client, "eleanor.vance@example.org", "CareConnect!2026", "246810")
        headers = {"Authorization": f"Bearer {token}"}

        # Allowed: read Arthur's appointments via verified proxy grant
        ok_res = client.get("/api/v1/appointments?patient_id=pat_arthur_02", headers=headers)
        assert ok_res.status_code == 200

        # Denied: request repeat medicine on Arthur's restricted proxy account
        denied_med = client.post(
            "/api/v1/medicines/requests?patient_id=pat_arthur_02",
            headers=headers,
            json={
                "medicine_id": "med_arthur_salbutamol",
                "preferred_pharmacy_name": "Meadowbank Dispensing Chemist",
                "idempotency_key": f"k_{uuid.uuid4().hex}",
            },
        )
        assert denied_med.status_code == 403

        # Denied: read clinical records on Arthur's restricted proxy account
        denied_rec = client.get("/api/v1/records?patient_id=pat_arthur_02", headers=headers)
        assert denied_rec.status_code == 403

        # Denied: switch to unverified child account (Maya Vance)
        denied_child = client.get("/api/v1/patient/home?patient_id=pat_maya_03", headers=headers)
        assert denied_child.status_code == 403


def test_slot_concurrency_and_unavailable_offer():
    with TestClient(app) as client:
        token = _login(client, "eleanor.vance@example.org", "CareConnect!2026", "246810")
        headers = {"Authorization": f"Bearer {token}"}

        # Unavailable slot returns 409 Conflict
        res_unavail = client.post(
            "/api/v1/appointments/offers/off_unavailable_conflict/confirm",
            headers=headers,
            json={"idempotency_key": "idem_unavail_1"},
        )
        assert res_unavail.status_code == 409

        # Valid slot hold + confirm
        hold_res = client.post(
            "/api/v1/appointments/offers/off_cardio_01/hold",
            headers=headers,
            json={"idempotency_key": "idem_hold_1"},
        )
        assert hold_res.status_code == 200
        assert hold_res.json()["status"] == "SLOT_HELD"

        confirm_res = client.post(
            "/api/v1/appointments/offers/off_cardio_01/confirm",
            headers=headers,
            json={"idempotency_key": "idem_confirm_1"},
        )
        assert confirm_res.status_code == 200
        assert confirm_res.json()["status"] == "BOOKING_REQUESTED"

        # Second distinct confirm attempt on already booked slot returns 409
        second_res = client.post(
            "/api/v1/appointments/offers/off_cardio_01/confirm",
            headers=headers,
            json={"idempotency_key": "idem_confirm_2"},
        )
        assert second_res.status_code == 409


def test_request_idempotency_after_interruption():
    with TestClient(app) as client:
        token = _login(client, "eleanor.vance@example.org", "CareConnect!2026", "246810")
        headers = {"Authorization": f"Bearer {token}"}
        idem_key = "retry_key_ramipril_001"

        r1 = client.post(
            "/api/v1/medicines/requests",
            headers=headers,
            json={
                "medicine_id": "med_eleanor_ramipril",
                "preferred_pharmacy_name": "Meadowbank Dispensing Chemist",
                "idempotency_key": idem_key,
            },
        )
        assert r1.status_code == 200
        r2 = client.post(
            "/api/v1/medicines/requests",
            headers=headers,
            json={
                "medicine_id": "med_eleanor_ramipril",
                "preferred_pharmacy_name": "Meadowbank Dispensing Chemist",
                "idempotency_key": idem_key,
            },
        )
        assert r2.status_code == 200
        assert r1.json()["id"] == r2.json()["id"]


def test_record_release_permissions_and_role_restrictions():
    with TestClient(app) as client:
        patient_token = _login(client, "eleanor.vance@example.org", "CareConnect!2026", "246810")
        records = client.get("/api/v1/records", headers={"Authorization": f"Bearer {patient_token}"}).json()
        ids = {r["id"] for r in records}
        # Withheld internal draft MUST never appear in patient records
        assert "rec_withheld_internal" not in ids

        # Reception admin cannot approve medicine requests or release clinical records
        rec_token = _login(client, "reception@oakbridge-demo.org", "StaffReception!2026", "654321")
        forbidden_med = client.post(
            "/api/v1/staff/medicines/requests/req_med_declined_01/review",
            headers={"Authorization": f"Bearer {rec_token}"},
            json={
                "decision": "APPROVED",
                "pharmacy_status": "NOT_SENT",
                "decision_reason": "Attempting unauthorised clinical override",
            },
        )
        assert forbidden_med.status_code == 403

        # Clinician cannot auto-release a record flagged with internal notes
        clin_token = _login(client, "clinician@westgate-demo.org", "StaffClinician!2026", "654321")
        blocked_release = client.post(
            "/api/v1/staff/records/rec_withheld_internal/release",
            headers={"Authorization": f"Bearer {clin_token}"},
            json={"release_status": "RELEASED"},
        )
        assert blocked_release.status_code == 400
