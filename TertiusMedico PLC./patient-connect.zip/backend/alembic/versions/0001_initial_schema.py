"""Initial schema for TERTIUSMEDICO Patient Connect."""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "0001_initial_schema"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "care_organisations",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("name", sa.String(160), nullable=False),
        sa.Column("org_type", sa.String(40), nullable=False),
        sa.Column("phone", sa.String(40), nullable=False),
        sa.Column("address", sa.String(255), nullable=False),
        sa.Column("hours", sa.String(160), nullable=False),
        sa.Column("response_sla", sa.String(200), nullable=False),
        sa.Column("synthetic_ods_code", sa.String(32), nullable=False),
    )

    op.create_table(
        "user_accounts",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("email", sa.String(180), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("role", sa.String(40), nullable=False),
        sa.Column("display_name", sa.String(120), nullable=False),
        sa.Column("totp_demo_code", sa.String(16), nullable=False),
        sa.Column("primary_patient_id", sa.String(64), nullable=True),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "patient_profiles",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("synthetic_health_id", sa.String(40), nullable=False, unique=True),
        sa.Column("full_name", sa.String(120), nullable=False),
        sa.Column("date_of_birth", sa.String(20), nullable=False),
        sa.Column("preferred_phone", sa.String(40), nullable=False),
        sa.Column("email", sa.String(180), nullable=False),
        sa.Column("gp_org_id", sa.String(64), sa.ForeignKey("care_organisations.id"), nullable=False),
        sa.Column("hospital_org_id", sa.String(64), sa.ForeignKey("care_organisations.id"), nullable=False),
        sa.Column("pharmacy_org_id", sa.String(64), sa.ForeignKey("care_organisations.id"), nullable=False),
        sa.Column("comm_preference", sa.String(60), nullable=False),
        sa.Column("interpreter_language", sa.String(80), nullable=False),
        sa.Column("accessible_format", sa.String(80), nullable=False),
        sa.Column("allergy_confirmation_state", sa.String(40), nullable=False),
        sa.Column("last_synced_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "trusted_devices",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.String(64), sa.ForeignKey("user_accounts.id"), nullable=False),
        sa.Column("device_name", sa.String(120), nullable=False),
        sa.Column("platform", sa.String(40), nullable=False),
        sa.Column("biometric_session_unlock", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("revoked", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "user_sessions",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.String(64), sa.ForeignKey("user_accounts.id"), nullable=False),
        sa.Column("device_id", sa.String(64), sa.ForeignKey("trusted_devices.id"), nullable=False),
        sa.Column("token_hash", sa.String(128), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "proxy_grants",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("representative_user_id", sa.String(64), sa.ForeignKey("user_accounts.id"), nullable=False),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("relationship_label", sa.String(60), nullable=False),
        sa.Column("verification_status", sa.String(40), nullable=False),
        sa.Column("verification_reference", sa.String(120), nullable=False),
        sa.Column("permissions_json", sa.Text, nullable=False),
        sa.Column("restrictions_summary", sa.Text, nullable=False),
        sa.Column("effective_from", sa.String(20), nullable=False),
        sa.Column("effective_until", sa.String(20), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("requires_capacity_or_child_policy", sa.Boolean, nullable=False, server_default=sa.false()),
    )

    op.create_table(
        "appointment_offers",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("org_id", sa.String(64), sa.ForeignKey("care_organisations.id"), nullable=False),
        sa.Column("service_name", sa.String(120), nullable=False),
        sa.Column("clinician_name", sa.String(120), nullable=False),
        sa.Column("location", sa.String(160), nullable=False),
        sa.Column("format", sa.String(40), nullable=False),
        sa.Column("starts_at_london", sa.String(40), nullable=False),
        sa.Column("ends_at_london", sa.String(40), nullable=False),
        sa.Column("preparation_instructions", sa.Text, nullable=False),
        sa.Column("referral_rule_note", sa.String(200), nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("held_by_user_id", sa.String(64), nullable=True),
        sa.Column("hold_expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("version", sa.Integer, nullable=False, server_default="1"),
    )

    op.create_table(
        "appointments",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("org_id", sa.String(64), sa.ForeignKey("care_organisations.id"), nullable=False),
        sa.Column("offer_id", sa.String(64), nullable=True),
        sa.Column("service_name", sa.String(120), nullable=False),
        sa.Column("clinician_name", sa.String(120), nullable=False),
        sa.Column("location", sa.String(160), nullable=False),
        sa.Column("format", sa.String(40), nullable=False),
        sa.Column("starts_at_london", sa.String(40), nullable=False),
        sa.Column("ends_at_london", sa.String(40), nullable=False),
        sa.Column("preparation_instructions", sa.Text, nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("can_cancel", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("reschedule_note", sa.Text, nullable=True),
        sa.Column("source_system", sa.String(80), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "medicine_records",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("name_formulation", sa.String(160), nullable=False),
        sa.Column("strength", sa.String(60), nullable=False),
        sa.Column("directions", sa.Text, nullable=False),
        sa.Column("source_org", sa.String(120), nullable=False),
        sa.Column("last_updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("repeat_eligible", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("ineligibility_reason", sa.String(200), nullable=True),
        sa.Column("conflict_warning", sa.Text, nullable=True),
    )

    op.create_table(
        "repeat_medicine_requests",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("medicine_id", sa.String(64), sa.ForeignKey("medicine_records.id"), nullable=False),
        sa.Column("preferred_pharmacy_name", sa.String(140), nullable=False),
        sa.Column("patient_note", sa.Text, nullable=True),
        sa.Column("stage", sa.String(40), nullable=False),
        sa.Column("pharmacy_status", sa.String(60), nullable=False),
        sa.Column("reviewer_role", sa.String(80), nullable=True),
        sa.Column("decision_reason", sa.Text, nullable=True),
        sa.Column("idempotency_key", sa.String(120), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "clinical_record_entries",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("category", sa.String(40), nullable=False),
        sa.Column("title", sa.String(180), nullable=False),
        sa.Column("summary", sa.Text, nullable=False),
        sa.Column("certainty_status", sa.String(40), nullable=False),
        sa.Column("release_status", sa.String(40), nullable=False),
        sa.Column("source_org", sa.String(120), nullable=False),
        sa.Column("recorded_date", sa.String(30), nullable=False),
        sa.Column("result_value", sa.String(60), nullable=True),
        sa.Column("result_unit", sa.String(40), nullable=True),
        sa.Column("reference_range", sa.String(80), nullable=True),
        sa.Column("clinician_comment", sa.Text, nullable=True),
        sa.Column("object_key", sa.String(200), nullable=True),
        sa.Column("is_stale", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("stale_notice", sa.String(200), nullable=True),
        sa.Column("contains_internal_notes", sa.Boolean, nullable=False, server_default=sa.false()),
    )

    op.create_table(
        "record_correction_requests",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("record_id", sa.String(64), sa.ForeignKey("clinical_record_entries.id"), nullable=False),
        sa.Column("requested_change", sa.Text, nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("staff_response", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "message_threads",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("org_id", sa.String(64), sa.ForeignKey("care_organisations.id"), nullable=False),
        sa.Column("category", sa.String(60), nullable=False),
        sa.Column("subject", sa.String(180), nullable=False),
        sa.Column("workflow_status", sa.String(40), nullable=False),
        sa.Column("expected_response_window", sa.String(180), nullable=False),
        sa.Column("unread_by_patient", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "thread_messages",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("thread_id", sa.String(64), sa.ForeignKey("message_threads.id"), nullable=False),
        sa.Column("sender_type", sa.String(40), nullable=False),
        sa.Column("sender_label", sa.String(120), nullable=False),
        sa.Column("body", sa.Text, nullable=False),
        sa.Column("sent_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "care_tasks",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("issuing_org_name", sa.String(140), nullable=False),
        sa.Column("contact_details", sa.String(160), nullable=False),
        sa.Column("task_type", sa.String(40), nullable=False),
        sa.Column("title", sa.String(180), nullable=False),
        sa.Column("purpose", sa.Text, nullable=False),
        sa.Column("due_date", sa.String(30), nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("response_json", sa.Text, nullable=True),
        sa.Column("measurement_source", sa.String(80), nullable=True),
        sa.Column("submitted_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "notification_dispatches",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("patient_id", sa.String(64), sa.ForeignKey("patient_profiles.id"), nullable=False),
        sa.Column("generic_preview_text", sa.String(180), nullable=False),
        sa.Column("delivery_status", sa.String(40), nullable=False),
        sa.Column("failure_reason", sa.String(200), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "idempotency_records",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.String(64), nullable=False),
        sa.Column("endpoint", sa.String(120), nullable=False),
        sa.Column("idempotency_key", sa.String(120), nullable=False),
        sa.Column("status_code", sa.Integer, nullable=False),
        sa.Column("response_json", sa.Text, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("user_id", "endpoint", "idempotency_key", name="uq_idempotency_user_ep_key"),
    )

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("actor_user_id", sa.String(64), nullable=False),
        sa.Column("actor_role", sa.String(40), nullable=False),
        sa.Column("patient_id", sa.String(64), nullable=True),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("outcome", sa.String(40), nullable=False),
        sa.Column("redacted_summary", sa.String(255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )


def downgrade() -> None:
    for table in [
        "audit_logs",
        "idempotency_records",
        "notification_dispatches",
        "care_tasks",
        "thread_messages",
        "message_threads",
        "record_correction_requests",
        "clinical_record_entries",
        "repeat_medicine_requests",
        "medicine_records",
        "appointments",
        "appointment_offers",
        "proxy_grants",
        "user_sessions",
        "trusted_devices",
        "patient_profiles",
        "user_accounts",
        "care_organisations",
    ]:
        op.drop_table(table)
