# TERTIUSMEDICO — Patient Connect API & Data Provenance

> **Prototype Disclaimer:** Independent prototype using fictional organisations and synthetic patient records. Generic FHIR or REST terminology does **not** represent live NHS integration or NHS endorsement.

## Base URL
- Docker / Host: `http://localhost:8000`
- Android Emulator: `http://10.0.2.2:8000`

## Authentication & Session Endpoints
| Method | Path | Purpose | Auth |
|---|---|---|---|
| `POST` | `/api/v1/auth/login` | Synthetic 2FA login (email + passphrase + verification code) | Public |
| `POST` | `/api/v1/auth/logout` | Revokes active session & signals client cache wipe | Bearer |
| `GET` | `/api/v1/auth/devices` | Lists trusted devices for account | Bearer |
| `POST` | `/api/v1/auth/devices/{id}/revoke` | Revokes device & all device sessions | Bearer |
| `GET` | `/api/v1/auth/recovery` | Documented supervised recovery steps | Public |

## Patient & Proxy Endpoints (Optional `?patient_id=...` for verified proxy context)
| Method | Path | Permission Scope |
|---|---|---|
| `GET` | `/api/v1/patient/home` | `profile:read` |
| `GET` | `/api/v1/patient/proxies` | Authenticated user's grants |
| `PUT` | `/api/v1/patient/preferences` | `profile:write` |
| `GET` | `/api/v1/patient/notifications` | `profile:read` |
| `GET` | `/api/v1/patient/integrations` | Authenticated |
| `GET` | `/api/v1/appointments` | `appointments:read` |
| `GET` | `/api/v1/appointments/offers` | `appointments:read` |
| `POST` | `/api/v1/appointments/offers/{id}/hold` | `appointments:book` |
| `POST` | `/api/v1/appointments/offers/{id}/confirm` | `appointments:book` (idempotent) |
| `POST` | `/api/v1/appointments/no-suitable-slots` | `appointments:book` |
| `POST` | `/api/v1/appointments/{id}/reschedule` | `appointments:book` |
| `POST` | `/api/v1/appointments/{id}/cancel` | `appointments:book` |
| `GET` | `/api/v1/medicines` | `medicines:read` |
| `GET` | `/api/v1/medicines/requests` | `medicines:read` |
| `GET` | `/api/v1/medicines/requests/by-key/{key}` | `medicines:read` |
| `POST` | `/api/v1/medicines/requests` | `medicines:request` (idempotent) |
| `GET` | `/api/v1/records` | `records:read` |
| `GET` | `/api/v1/records/{id}/document` | `records:read` |
| `GET` | `/api/v1/records/corrections` | `records:read` |
| `POST` | `/api/v1/records/corrections` | `records:correct` |
| `GET` | `/api/v1/messages/threads` | `messages:read` |
| `POST` | `/api/v1/messages/threads` | `messages:write` (idempotent) |
| `POST` | `/api/v1/messages/threads/{id}/reply` | `messages:write` |
| `GET` | `/api/v1/tasks` | `tasks:read` |
| `POST` | `/api/v1/tasks/{id}/complete` | `tasks:write` |

## Field Provenance, Freshness & Reconciliation Matrix

| Domain / Field | Authoritative Source | Freshness | Permissions | Reconciliation Behaviour |
|---|---|---|---|---|
| `PatientProfile` & Contact/Accessibility | Practice Clinical System (`DeterministicGpSystemAdapter`) | Synced on login + WorkManager; timestamp shown | `profile:read` / `profile:write` | Practice demographics authoritative; patient preferences synced back |
| `AppointmentOffer` & `Appointment` | Trust PAS / Practice Booking (`DeterministicHospitalAppointmentsAdapter`) | Real-time hold (5 min TTL) & Europe/London DST-aware ISO timestamps | `appointments:read` / `appointments:book` | Optimistic version column prevents double-booking (`409 Conflict`) |
| `MedicineRecord` | GP Repeat Prescribing System (`DeterministicMedicinesPrescriptionAdapter`) | Timestamped per medicine; conflict warnings surfaced | `medicines:read` | Hospital vs GP discrepancies flagged with contact prompt |
| `RepeatMedicineRequest.stage` | Prescribing Review Queue | Updated only on clinician/prescriber action | `medicines:request` (proxy restricted) | Idempotency keys prevent duplicate submits on network drop |
| `RepeatMedicineRequest.pharmacy_status` | Community Pharmacy Feed (`DeterministicPharmacyStatusAdapter`) | Best-effort; `NOT_SENT` or `UNAVAILABLE` if unconfirmed | `medicines:read` | Never marked ready without confirmed transmission |
| `ClinicalRecordEntry` | Care Organisation Release Gate (`DeterministicReleasedClinicalRecordsAdapter`) | Clinician-released only; `is_stale` flagged >12 months | `records:read` | Internal notes & unreviewed items withheld; corrections go via addendum queue |
| `MessageThread.workflow_status` | Care Team Admin Inbox (`DeterministicSecureMessagingAdapter`) | Distinct `SUBMITTED` -> `DELIVERED_TO_SERVICE` -> `ASSIGNED` -> `REVIEWED` -> `RESPONSE_AVAILABLE` -> `CLOSED` | `messages:read` / `messages:write` | Delivery never implies clinical review |
| `CareTask` & Patient Measurements | Issuing Clinic / Patient (`response_json`) | Recorded UTC timestamp + `Patient-entered (unverified)` tag | `tasks:read` / `tasks:write` | Never treated as clinician-verified observations |
| `NotificationDispatch` | Push Gateway (`DeterministicNotificationsAdapter`) | Logged per dispatch (`DELIVERED` / `FAILED_FALLBACK_INBOX`) | `profile:read` | Generic preview text only; never exposes PHI |
