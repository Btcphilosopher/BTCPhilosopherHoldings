# TERTIUSMEDICO — Build, Docker Compose & 12-Step Demonstration Guide

## 1. Running the Full Backend + PostgreSQL + Object Storage + Staff Console
From the repository root:
```bash
docker compose up --build
```
Services started:
- **PostgreSQL 16**: `localhost:5432` (database `patient_connect`, Alembic migration `0001_initial_schema` runs automatically on backend startup)
- **MinIO Object Storage**: `http://localhost:9000` (Console `http://localhost:9001`)
- **FastAPI Backend**: `http://localhost:8000` (Swagger UI at `http://localhost:8000/docs`)
- **React + TypeScript Staff Console**: `http://localhost:5173`

To run backend automated tests locally (with Python virtual env + `backend/requirements.txt`):
```bash
cd backend
pytest -v
```

## 2. Building the Android APK & Running Robolectric Tests
```bash
# Debug APK
gradle :app:assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Release APK (requires signing env vars in CI/AI Studio)
gradle :app:assembleRelease

# JVM + Robolectric Automated Tests
gradle :app:testDebugUnitTest
```
> **Connecting Android App to Backend:**
> - Inside the Android Emulator, select **Live FastAPI Server** in Sign-In / Account Settings (`http://10.0.2.2:8000`).
> - When running standalone in the Streaming Emulator without Docker running locally, keep **On-Device Deterministic Sandbox** active — it uses the exact same typed adapter contracts, concurrency rules, idempotency store, and synthetic fixtures so all 12 demonstration scenarios work immediately.

## 3. Synthetic Demo Credentials
- **Patient (Eleanor Vance):** `eleanor.vance@example.org` / `CareConnect!2026` / 2FA code: `246810`
- **Staff — Reception/Booking:** `reception@oakbridge-demo.org` / `StaffReception!2026` / 2FA: `654321`
- **Staff — GP Prescriber:** `prescriber@oakbridge-demo.org` / `StaffPrescribe!2026` / 2FA: `654321`
- **Staff — Cardiology Consultant:** `clinician@westgate-demo.org` / `StaffClinician!2026` / 2FA: `654321`
- **Staff — Caldicott/Governance:** `governance@tertius-demo.org` / `StaffGovernance!2026` / 2FA: `654321`

## 4. 12-Step Working Demonstration & Edge-Case Script
1. **Sign in:** Launch Patient Connect, inspect non-NHS prototype notice, verify email + passphrase + 2FA code (`246810`). Observe recovery & biometric disclosures.
2. **Personalised Home Screen:** Inspect patient name, active account pill, next confirmed appointment (`Phlebotomy`), requests awaiting action, unread message count, latest medicine request status, care provider contacts, and last sync timestamp.
3. **Select Eligible Appointment & Unavailable Slot:** Open *Appointments* -> test the unavailable GP slot (`off_unavailable_conflict`) to observe conflict handling and preserved booking-team contact option -> hold and confirm the eligible Cardiology slot (`off_cardio_01`) -> shows `BOOKING_REQUESTED`.
4. **Confirmed Booking via Staff Console:** In Staff Console (`reception@oakbridge-demo.org`), click **Confirm booking** -> refresh Patient App -> status updates to `BOOKING_CONFIRMED` and *Add to calendar* button becomes enabled.
5. **Submit Repeat Medicine Request:** Open *Medicines* -> inspect Ramipril, Atorvastatin (with GP/Hospital conflict warning), and ineligible Naproxen -> submit repeat request for Ramipril (`REQUESTED`).
6. **Track Simulated Review (plus Declined Request):** Inspect pre-seeded declined Naproxen request (`DECLINED` with prescriber rationale). In Staff Console (`prescriber@oakbridge-demo.org`), mark Ramipril as `PRACTICE_REVIEW`, then `PRESCRIPTION_TRANSMITTED` + `READY_FOR_COLLECTION` -> refresh Patient App.
7. **Read Released Consultation Summary:** Open *View records* from Home -> read *GP Consultation Summary* (`CONFIRMED`, `RELEASED`, source + date). Note that *Holter Tape Draft* (`WITHHELD_PENDING_REVIEW`) is strictly absent from patient view.
8. **View Investigation Result with Provider Comments & Stale Record:** Inspect *Serum Creatinine & eGFR* (`74 umol/L`, lab range `45 - 84 umol/L`, clinician comment) and *Serum Potassium Archive* (marked `STALE >12 months old`), plus submit a *Request correction* on Penicillin allergy.
9. **Receive & Answer Care-Team Message + Failed Notification:** Open *Messages* -> view emergency banner (`999`/`111`), separate `RESPONSE_AVAILABLE` status, reply to Cardiology Booking Team -> check *Account -> Notification Delivery Log* showing the privacy-preserving preview and simulated `FAILED_FALLBACK_INBOX` entry.
10. **Complete Questionnaire (Care Tasks):** Open *Care tasks & forms* from Home -> complete *Pre-Clinic Home Blood Pressure & Symptom Check* -> observe tag `Patient-entered (unverified)` + timestamp.
11. **Switch to Restricted Proxy Account:** Open *Account* or top account switcher -> switch to **Arthur Vance** (verified father proxy) -> observe prominent proxy banner, missing-allergy warning (*Information not yet confirmed on record*), and blocked repeat-medicine/records actions. Notice **Maya Vance** (child) is blocked under `PENDING_POLICY_REVIEW`.
12. **Offline Cache & Interrupted Connection Recovery:** Toggle *Simulate Offline Mode* in Account -> confirm cached upcoming appointment & contacts appear with visible `Cached at` timestamp, while booking/medicine mutations are blocked. Test *Simulate Interrupted Connection* to see idempotent status recovery via `/by-key/{idempotency_key}` without duplicate submission.
