import type { StaffOverview } from "./types";

const DEFAULT_BASE_URL =
  (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_API_BASE_URL ??
  "http://localhost:8000";

export class StaffApiClient {
  private token: string | null = null;
  private baseUrl: string = DEFAULT_BASE_URL;

  setBaseUrl(url: string) {
    this.baseUrl = url.replace(/\/+$/, "");
  }

  setToken(token: string | null) {
    this.token = token;
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...(init.headers as Record<string, string> | undefined),
    };
    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`;
    }
    const res = await fetch(`${this.baseUrl}${path}`, { ...init, headers });
    if (!res.ok) {
      let detail = `Request failed (${res.status})`;
      try {
        const json = await res.json();
        if (json.detail) detail = json.detail;
      } catch {
        // ignore parse failure
      }
      throw new Error(detail);
    }
    return (await res.json()) as T;
  }

  async login(email: string, passphrase: string, verificationCode: string) {
    const data = await this.request<{
      access_token: string;
      display_name: string;
      role: string;
    }>("/api/v1/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email,
        passphrase,
        verification_code: verificationCode,
        device_name: "Staff Web Console",
        platform: "WEB",
      }),
    });
    this.token = data.access_token;
    return data;
  }

  async logout() {
    try {
      await this.request("/api/v1/auth/logout", { method: "POST" });
    } finally {
      this.token = null;
    }
  }

  getOverview(): Promise<StaffOverview> {
    return this.request<StaffOverview>("/api/v1/staff/overview");
  }

  createOffer(body: Record<string, string>) {
    return this.request("/api/v1/staff/offers", { method: "POST", body: JSON.stringify(body) });
  }

  confirmAppointment(appointmentId: string) {
    return this.request(`/api/v1/staff/appointments/${appointmentId}/confirm`, { method: "POST" });
  }

  reviewMedicine(requestId: string, body: { decision: string; pharmacy_status: string; decision_reason: string }) {
    return this.request(`/api/v1/staff/medicines/requests/${requestId}/review`, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  releaseRecord(recordId: string, body: { release_status: string; clinician_comment?: string }) {
    return this.request(`/api/v1/staff/records/${recordId}/release`, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  sendMessage(body: {
    patient_id: string;
    org_id: string;
    category: string;
    subject: string;
    body: string;
    simulate_notification_failure: boolean;
  }) {
    return this.request("/api/v1/staff/messages", { method: "POST", body: JSON.stringify(body) });
  }

  assignTask(body: Record<string, string>) {
    return this.request("/api/v1/staff/tasks", { method: "POST", body: JSON.stringify(body) });
  }

  reviewCorrection(correctionId: string, body: { status: string; staff_response: string }) {
    return this.request(`/api/v1/staff/corrections/${correctionId}/review`, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  updateProxy(
    proxyId: string,
    body: {
      verification_status: string;
      permissions: string[];
      restrictions_summary: string;
      effective_until: string;
    }
  ) {
    return this.request(`/api/v1/staff/proxies/${proxyId}`, {
      method: "PUT",
      body: JSON.stringify(body),
    });
  }
}

export const staffApi = new StaffApiClient();
