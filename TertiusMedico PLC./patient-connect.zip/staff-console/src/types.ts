export interface StaffOverview {
  staff_user: {
    id: string;
    display_name: string;
    role: string;
  };
  patients: Array<{
    id: string;
    full_name: string;
    synthetic_health_id: string;
    date_of_birth: string;
  }>;
  organisations: Array<{
    id: string;
    name: string;
    org_type: string;
  }>;
  offers: Array<{
    id: string;
    patient_id: string;
    service_name: string;
    clinician_name: string;
    starts_at_london: string;
    format: string;
    status: string;
  }>;
  appointments: Array<{
    id: string;
    patient_id: string;
    service_name: string;
    clinician_name: string;
    starts_at_london: string;
    status: string;
    reschedule_note: string | null;
  }>;
  medicine_requests: Array<{
    id: string;
    patient_id: string;
    medicine_name: string;
    preferred_pharmacy_name: string;
    stage: string;
    pharmacy_status: string;
    decision_reason: string | null;
    updated_at: string;
  }>;
  records: Array<{
    id: string;
    patient_id: string;
    category: string;
    title: string;
    certainty_status: string;
    release_status: string;
    contains_internal_notes: boolean;
    clinician_comment: string | null;
    recorded_date: string;
  }>;
  corrections: Array<{
    id: string;
    patient_id: string;
    record_id: string;
    requested_change: string;
    status: string;
    staff_response: string | null;
  }>;
  threads: Array<{
    id: string;
    patient_id: string;
    subject: string;
    category: string;
    workflow_status: string;
    updated_at: string;
  }>;
  tasks: Array<{
    id: string;
    patient_id: string;
    title: string;
    task_type: string;
    due_date: string;
    status: string;
    measurement_source: string | null;
  }>;
  proxies: Array<{
    id: string;
    patient_id: string;
    relationship_label: string;
    verification_status: string;
    permissions: string[];
    restrictions_summary: string;
    effective_until: string;
    requires_capacity_or_child_policy: boolean;
  }>;
  audit_logs: Array<{
    id: string;
    actor_role: string;
    patient_id: string | null;
    action: string;
    outcome: string;
    redacted_summary: string;
    created_at: string;
  }>;
}
