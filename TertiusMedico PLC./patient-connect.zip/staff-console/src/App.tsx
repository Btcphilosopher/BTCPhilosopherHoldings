import React, { useState } from "react";
import { staffApi } from "./api";
import type { StaffOverview } from "./types";

type TabId =
  | "appointments"
  | "medicines"
  | "messages"
  | "records"
  | "tasks"
  | "proxies"
  | "audit";

const DEMO_ROLES = [
  { label: "Reception & Booking Admin", email: "reception@oakbridge-demo.org", pass: "StaffReception!2026" },
  { label: "GP Prescriber (Dr Rahman)", email: "prescriber@oakbridge-demo.org", pass: "StaffPrescribe!2026" },
  { label: "Cardiology Consultant (Dr Nair)", email: "clinician@westgate-demo.org", pass: "StaffClinician!2026" },
  { label: "Caldicott & Proxy Officer", email: "governance@tertius-demo.org", pass: "StaffGovernance!2026" },
];

export default function App() {
  const [apiUrl, setApiUrl] = useState("http://localhost:8000");
  const [email, setEmail] = useState(DEMO_ROLES[0].email);
  const [passphrase, setPassphrase] = useState(DEMO_ROLES[0].pass);
  const [code, setCode] = useState("654321");
  const [overview, setOverview] = useState<StaffOverview | null>(null);
  const [tab, setTab] = useState<TabId>("appointments");
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Offer creation form
  const [offerService, setOfferService] = useState("Cardiology Nurse Follow-up");
  const [offerStart, setOfferStart] = useState("2026-12-16T10:30:00+00:00");
  const [offerEnd, setOfferEnd] = useState("2026-12-16T11:00:00+00:00");

  // Message form
  const [msgSubject, setMsgSubject] = useState("Updated blood-test preparation reminder");
  const [msgBody, setMsgBody] = useState("Please bring your home blood pressure readings to your upcoming clinic appointment.");
  const [simNotifFail, setSimNotifFail] = useState(false);

  // Task form
  const [taskTitle, setTaskTitle] = useState("Confirm appointment attendance");
  const [taskPurpose, setTaskPurpose] = useState("Confirm you can still attend your outpatient slot.");
  const [taskDue, setTaskDue] = useState("2026-12-05");

  async function refresh() {
    const data = await staffApi.getOverview();
    setOverview(data);
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setNotice(null);
    try {
      staffApi.setBaseUrl(apiUrl);
      await staffApi.login(email, passphrase, code);
      await refresh();
      setNotice("Signed in to Staff Demonstration Console.");
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function handleAction(fn: () => Promise<unknown>, successMsg: string) {
    setError(null);
    setNotice(null);
    try {
      await fn();
      await refresh();
      setNotice(successMsg);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  const role = overview?.staff_user.role ?? "";
  const isClinical = role === "CLINICIAN" || role === "PRESCRIBER";
  const isClinicianOnly = role === "CLINICIAN";
  const isBookingAllowed = role === "RECEPTION_ADMIN" || role === "CLINICIAN" || role === "GOVERNANCE_ADMIN";
  const isProxyGov = role === "GOVERNANCE_ADMIN" || role === "CLINICIAN";

  return (
    <>
      <div className="banner-proto">
        TERTIUSMEDICO — STAFF DEMONSTRATION CONSOLE • INDEPENDENT PROTOTYPE • SYNTHETIC RECORDS ONLY • NOT NHS
      </div>
      <header className="topbar">
        <div>
          <h1>TERTIUSMEDICO Staff Console</h1>
          <div>Fictional organisations: Oakbridge GP · Westgate Infirmary · Meadowbank Chemist</div>
        </div>
        {overview && (
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
            <span className="badge">{overview.staff_user.display_name} ({overview.staff_user.role})</span>
            <button
              className="btn secondary"
              onClick={async () => {
                await staffApi.logout();
                setOverview(null);
              }}
            >
              Sign out
            </button>
          </div>
        )}
      </header>

      <main className="container">
        {notice && <div className="alert">{notice}</div>}
        {error && <div className="alert error">{error}</div>}

        {!overview ? (
          <section className="card" style={{ maxWidth: 640, margin: "2rem auto" }}>
            <h2>Role-Scoped Staff Sign-In</h2>
            <p>
              Select a synthetic staff role to test strict separation between administrative,
              prescribing, clinical release, and governance duties.
            </p>
            <div className="tabs">
              {DEMO_ROLES.map((r) => (
                <button
                  key={r.email}
                  type="button"
                  className={`tab-btn ${email === r.email ? "active" : ""}`}
                  onClick={() => {
                    setEmail(r.email);
                    setPassphrase(r.pass);
                    setCode("654321");
                  }}
                >
                  {r.label}
                </button>
              ))}
            </div>
            <form onSubmit={handleLogin}>
              <label>Backend API URL</label>
              <input value={apiUrl} onChange={(e) => setApiUrl(e.target.value)} />
              <label>Staff Email</label>
              <input value={email} onChange={(e) => setEmail(e.target.value)} />
              <label>Passphrase</label>
              <input type="password" value={passphrase} onChange={(e) => setPassphrase(e.target.value)} />
              <label>2FA Code</label>
              <input value={code} onChange={(e) => setCode(e.target.value)} />
              <button className="btn" type="submit">Sign in to Staff Console</button>
            </form>
          </section>
        ) : (
          <>
            <nav className="tabs" aria-label="Staff workspace sections">
              {(
                [
                  ["appointments", "Appointments & Offers"],
                  ["medicines", "Medicines Review"],
                  ["messages", "Messages & Alerts"],
                  ["records", "Records & Corrections"],
                  ["tasks", "Care Tasks"],
                  ["proxies", "Proxy Governance"],
                  ["audit", "Redacted Audit Log"],
                ] as Array<[TabId, string]>
              ).map(([id, label]) => (
                <button
                  key={id}
                  className={`tab-btn ${tab === id ? "active" : ""}`}
                  onClick={() => setTab(id)}
                >
                  {label}
                </button>
              ))}
            </nav>

            {tab === "appointments" && (
              <div className="grid-2">
                <section className="card">
                  <h3>Confirm / Track Patient Bookings</h3>
                  <table>
                    <thead>
                      <tr>
                        <th>Service</th>
                        <th>When (London)</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {overview.appointments.map((a) => (
                        <tr key={a.id}>
                          <td>
                            <strong>{a.service_name}</strong>
                            <div>{a.clinician_name}</div>
                            {a.reschedule_note && <small>{a.reschedule_note}</small>}
                          </td>
                          <td>{a.starts_at_london}</td>
                          <td><span className="badge">{a.status}</span></td>
                          <td>
                            {a.status === "BOOKING_REQUESTED" || a.status === "CHANGE_REQUESTED" ? (
                              <button
                                className="btn"
                                disabled={!isBookingAllowed}
                                onClick={() =>
                                  handleAction(
                                    () => staffApi.confirmAppointment(a.id),
                                    `Confirmed booking ${a.id}. Patient app will now show BOOKING_CONFIRMED.`
                                  )
                                }
                              >
                                Confirm booking
                              </button>
                            ) : (
                              <span>—</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </section>

                <section className="card">
                  <h3>Create Eligible Appointment Offer</h3>
                  <label>Service Name</label>
                  <input value={offerService} onChange={(e) => setOfferService(e.target.value)} />
                  <label>Start (Europe/London ISO)</label>
                  <input value={offerStart} onChange={(e) => setOfferStart(e.target.value)} />
                  <label>End (Europe/London ISO)</label>
                  <input value={offerEnd} onChange={(e) => setOfferEnd(e.target.value)} />
                  <button
                    className="btn"
                    disabled={!isBookingAllowed}
                    onClick={() =>
                      handleAction(
                        () =>
                          staffApi.createOffer({
                            patient_id: "pat_eleanor_01",
                            org_id: "org_westgate_hosp",
                            service_name: offerService,
                            clinician_name: "Dr Priya Nair",
                            location: "Westgate General Infirmary — Wing B",
                            format: "IN_PERSON",
                            starts_at_london: offerStart,
                            ends_at_london: offerEnd,
                            preparation_instructions: "Bring your latest medicines list.",
                            referral_rule_note: "Released via Staff Demonstration Console.",
                          }),
                        "Created new eligible appointment offer for Eleanor Vance."
                      )
                    }
                  >
                    Publish eligible offer
                  </button>
                </section>
              </div>
            )}

            {tab === "medicines" && (
              <section className="card">
                <h3>Repeat Medicine Requests (Prescriber / Clinician Only)</h3>
                {!isClinical && (
                  <div className="alert error">
                    Your role ({role}) cannot make clinical prescribing decisions. Sign in as GP Prescriber or Clinician to approve or decline requests.
                  </div>
                )}
                <table>
                  <thead>
                    <tr>
                      <th>Medicine &amp; Pharmacy</th>
                      <th>Current Stage</th>
                      <th>Pharmacy Status</th>
                      <th>Clinical Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {overview.medicine_requests.map((r) => (
                      <tr key={r.id}>
                        <td>
                          <strong>{r.medicine_name}</strong>
                          <div>{r.preferred_pharmacy_name}</div>
                          {r.decision_reason && <small>{r.decision_reason}</small>}
                        </td>
                        <td><span className="badge warn">{r.stage}</span></td>
                        <td><span className="badge">{r.pharmacy_status}</span></td>
                        <td style={{ display: "flex", gap: "0.4rem", flexWrap: "wrap" }}>
                          <button
                            className="btn secondary"
                            disabled={!isClinical}
                            onClick={() =>
                              handleAction(
                                () =>
                                  staffApi.reviewMedicine(r.id, {
                                    decision: "PRACTICE_REVIEW",
                                    pharmacy_status: "NOT_SENT",
                                    decision_reason: "Under clinical review by GP prescribing team.",
                                  }),
                                `Moved ${r.id} to PRACTICE_REVIEW.`
                              )
                            }
                          >
                            Mark In Review
                          </button>
                          <button
                            className="btn"
                            disabled={!isClinical}
                            onClick={() =>
                              handleAction(
                                () =>
                                  staffApi.reviewMedicine(r.id, {
                                    decision: "PRESCRIPTION_TRANSMITTED",
                                    pharmacy_status: "READY_FOR_COLLECTION",
                                    decision_reason: "Approved & signed by prescriber; transmitted to Meadowbank Chemist.",
                                  }),
                                `Approved & transmitted prescription ${r.id}.`
                              )
                            }
                          >
                            Approve &amp; Transmit
                          </button>
                          <button
                            className="btn danger"
                            disabled={!isClinical}
                            onClick={() =>
                              handleAction(
                                () =>
                                  staffApi.reviewMedicine(r.id, {
                                    decision: "DECLINED",
                                    pharmacy_status: "NOT_SENT",
                                    decision_reason: "Declined: medication review blood test required before further supply.",
                                  }),
                                `Declined medicine request ${r.id}.`
                              )
                            }
                          >
                            Decline
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </section>
            )}

            {tab === "messages" && (
              <div className="grid-2">
                <section className="card">
                  <h3>Send Patient Message &amp; Notification</h3>
                  <label>Subject</label>
                  <input value={msgSubject} onChange={(e) => setMsgSubject(e.target.value)} />
                  <label>Message Body</label>
                  <textarea rows={4} value={msgBody} onChange={(e) => setMsgBody(e.target.value)} />
                  <label style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                    <input
                      type="checkbox"
                      style={{ width: "auto", margin: 0 }}
                      checked={simNotifFail}
                      onChange={(e) => setSimNotifFail(e.target.checked)}
                    />
                    Simulate push notification delivery failure (fallback to in-app inbox)
                  </label>
                  <button
                    className="btn"
                    style={{ marginTop: "0.75rem" }}
                    onClick={() =>
                      handleAction(
                        () =>
                          staffApi.sendMessage({
                            patient_id: "pat_eleanor_01",
                            org_id: "org_oakbridge_gp",
                            category: "Existing-care questions",
                            subject: msgSubject,
                            body: msgBody,
                            simulate_notification_failure: simNotifFail,
                          }),
                        "Message delivered to patient thread with privacy-preserving notification log."
                      )
                    }
                  >
                    Send message
                  </button>
                </section>
                <section className="card">
                  <h3>Active Threads</h3>
                  <ul>
                    {overview.threads.map((t) => (
                      <li key={t.id} style={{ marginBottom: "0.6rem" }}>
                        <strong>{t.subject}</strong> — <span className="badge">{t.workflow_status}</span>
                      </li>
                    ))}
                  </ul>
                </section>
              </div>
            )}

            {tab === "records" && (
              <div className="grid-2">
                <section className="card">
                  <h3>Synthetic Clinical Records Release (Clinician Only)</h3>
                  {!isClinicianOnly && (
                    <div className="alert error">
                      Only CLINICIAN accounts can release clinical records. Internal notes cannot be auto-released.
                    </div>
                  )}
                  <table>
                    <thead>
                      <tr>
                        <th>Entry</th>
                        <th>Release Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {overview.records.map((rec) => (
                        <tr key={rec.id}>
                          <td>
                            <strong>{rec.title}</strong>
                            <div>{rec.category} · {rec.certainty_status} · {rec.recorded_date}</div>
                            {rec.contains_internal_notes && (
                              <span className="badge danger">Contains internal/unreviewed notes (Blocked)</span>
                            )}
                          </td>
                          <td><span className="badge">{rec.release_status}</span></td>
                          <td>
                            <button
                              className="btn secondary"
                              disabled={!isClinicianOnly || rec.contains_internal_notes}
                              onClick={() =>
                                handleAction(
                                  () =>
                                    staffApi.releaseRecord(rec.id, {
                                      release_status:
                                        rec.release_status === "RELEASED"
                                          ? "WITHHELD_PENDING_REVIEW"
                                          : "RELEASED",
                                      clinician_comment: rec.clinician_comment ?? "Reviewed by consultant.",
                                    }),
                                  `Updated release state for ${rec.title}.`
                                )
                              }
                            >
                              {rec.release_status === "RELEASED" ? "Withhold" : "Release"}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </section>

                <section className="card">
                  <h3>Patient Record Correction Requests</h3>
                  {overview.corrections.map((c) => (
                    <div key={c.id} className="card">
                      <strong>{c.record_id}</strong> · <span className="badge">{c.status}</span>
                      <p>{c.requested_change}</p>
                      <button
                        className="btn"
                        disabled={!isClinical}
                        onClick={() =>
                          handleAction(
                            () =>
                              staffApi.reviewCorrection(c.id, {
                                status: "ACCEPTED_NOTED",
                                staff_response: "Clarification added as a verified patient addendum by clinician.",
                              }),
                            `Accepted addendum for correction ${c.id}.`
                          )
                        }
                      >
                        Accept &amp; Record Addendum
                      </button>
                    </div>
                  ))}
                </section>
              </div>
            )}

            {tab === "tasks" && (
              <div className="grid-2">
                <section className="card">
                  <h3>Assign Care Task</h3>
                  <label>Task Title</label>
                  <input value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} />
                  <label>Purpose</label>
                  <textarea rows={3} value={taskPurpose} onChange={(e) => setTaskPurpose(e.target.value)} />
                  <label>Due Date</label>
                  <input value={taskDue} onChange={(e) => setTaskDue(e.target.value)} />
                  <button
                    className="btn"
                    disabled={!isClinical}
                    onClick={() =>
                      handleAction(
                        () =>
                          staffApi.assignTask({
                            patient_id: "pat_eleanor_01",
                            issuing_org_name: "Westgate General Infirmary",
                            contact_details: "0113 496 0822",
                            task_type: "CONFIRM_ATTENDANCE",
                            title: taskTitle,
                            purpose: taskPurpose,
                            due_date: taskDue,
                          }),
                        "Assigned new care task to Eleanor Vance."
                      )
                    }
                  >
                    Assign Care Task
                  </button>
                </section>
                <section className="card">
                  <h3>Assigned Tasks</h3>
                  <ul>
                    {overview.tasks.map((t) => (
                      <li key={t.id} style={{ marginBottom: "0.5rem" }}>
                        <strong>{t.title}</strong> ({t.due_date}) — <span className="badge">{t.status}</span>
                        {t.measurement_source && <div><small>Source: {t.measurement_source}</small></div>}
                      </li>
                    ))}
                  </ul>
                </section>
              </div>
            )}

            {tab === "proxies" && (
              <section className="card">
                <h3>Approved Proxy Access Governance</h3>
                {!isProxyGov && (
                  <div className="alert error">
                    Proxy grants can only be verified or revoked by GOVERNANCE_ADMIN or CLINICIAN.
                  </div>
                )}
                {overview.proxies.map((p) => (
                  <div key={p.id} className="card">
                    <strong>{p.relationship_label}</strong> · Patient: {p.patient_id} ·{" "}
                    <span className="badge">{p.verification_status}</span>
                    <p>{p.restrictions_summary}</p>
                    <small>Permissions: {p.permissions.join(", ") || "None"} · Valid until {p.effective_until}</small>
                    <div style={{ marginTop: "0.75rem", display: "flex", gap: "0.5rem" }}>
                      <button
                        className="btn danger"
                        disabled={!isProxyGov}
                        onClick={() =>
                          handleAction(
                            () =>
                              staffApi.updateProxy(p.id, {
                                verification_status: "REVOKED",
                                permissions: [],
                                restrictions_summary: "Revoked via Staff Console.",
                                effective_until: p.effective_until,
                              }),
                            `Revoked proxy grant ${p.id}.`
                          )
                        }
                      >
                        Revoke Proxy
                      </button>
                      <button
                        className="btn secondary"
                        disabled={!isProxyGov}
                        onClick={() =>
                          handleAction(
                            () =>
                              staffApi.updateProxy(p.id, {
                                verification_status: "VERIFIED",
                                permissions: ["profile:read", "appointments:read", "appointments:book", "medicines:read", "messages:read"],
                                restrictions_summary: "Verified restricted proxy access.",
                                effective_until: p.effective_until,
                              }),
                            `Verified proxy grant ${p.id}.`
                          )
                        }
                      >
                        Verify / Restore
                      </button>
                    </div>
                  </div>
                ))}
              </section>
            )}

            {tab === "audit" && (
              <section className="card">
                <h3>Redacted Audit History</h3>
                <p>Clinical payloads, passphrases, and access tokens are never stored in audit logs.</p>
                <table>
                  <thead>
                    <tr>
                      <th>Time (UTC)</th>
                      <th>Actor Role</th>
                      <th>Action</th>
                      <th>Outcome</th>
                      <th>Summary</th>
                    </tr>
                  </thead>
                  <tbody>
                    {overview.audit_logs.map((a) => (
                      <tr key={a.id}>
                        <td>{a.created_at}</td>
                        <td><span className="badge">{a.actor_role}</span></td>
                        <td>{a.action}</td>
                        <td><span className={`badge ${a.outcome === "DENIED" ? "danger" : "ok"}`}>{a.outcome}</span></td>
                        <td>{a.redacted_summary}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </section>
            )}
          </>
        )}
      </main>
    </>
  );
}
