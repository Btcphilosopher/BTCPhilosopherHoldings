import express from 'express';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {GoogleGenAI, ThinkingLevel, Type} from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT ?? 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

interface HandlerRequestBody {
  mode?: 'briefing' | 'hint' | 'banter' | 'debrief';
  hintTier?: 1 | 2 | 3;
  missionTitle?: string;
  corporationName?: string;
  nodeLabel?: string;
  puzzleType?: string;
  puzzleSummary?: string;
  tracePercent?: number;
  playerChoice?: string;
}

const SYSTEM_INSTRUCTION = `You are "Giles", the impeccably polite British cyber-operations handler for Duke Satoshi — an aristocratic white-hat security auditor in an Anglo-futurist cyber-noir London.
Tone: Dry British humour, composed, intellectually confident, crisp and concise (2-4 sentences max so text stays effortless to read in XR).
Strict Safety & Game Rules:
- Everything is 100% fictional cyberspace puzzle mechanics (Signal Routing, Identity Reconstruction, Archive Decoding).
- NEVER provide real-world hacking commands, exploit payloads, malware, vulnerability exploitation, or real cryptocurrency/financial advice.
- NEVER invent completed objectives or grant currency (Cipher Credits).
- For hints:
  - Tier 1 (nudge): gentle thematic nudge pointing out what clue or rule to inspect.
  - Tier 2 (explanation): clear explanation of the puzzle mechanic and constraint logic.
  - Tier 3 (solution): explicit step-by-step guidance using the provided fictional puzzle summary.`;

let cachedClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  if (!cachedClient) {
    cachedClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedClient;
}

async function startServer() {
  const app = express();
  app.use(express.json({limit: '256kb'}));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      aiConfigured: Boolean(process.env.GEMINI_API_KEY?.trim()),
    });
  });

  app.post('/api/handler', async (req, res) => {
    const body = (req.body ?? {}) as HandlerRequestBody;
    const ai = getGeminiClient();
    if (!ai) {
      res.status(200).json({
        ok: false,
        fallback: true,
        reason: 'NO_API_KEY',
      });
      return;
    }

    const mode = body.mode ?? 'banter';
    const tierLabel =
      body.hintTier === 3
        ? 'Tier 3 (Direct Solution Assistance)'
        : body.hintTier === 2
          ? 'Tier 2 (Mechanic Explanation)'
          : 'Tier 1 (Subtle Nudge)';

    const userPrompt = [
      `Mode: ${mode}`,
      body.missionTitle ? `Contract: ${body.missionTitle}` : '',
      body.corporationName ? `Corporation: ${body.corporationName}` : '',
      body.nodeLabel ? `Active Node: ${body.nodeLabel}` : '',
      body.puzzleType ? `Puzzle Type: ${body.puzzleType}` : '',
      mode === 'hint' ? `Hint Tier: ${tierLabel}` : '',
      body.puzzleSummary ? `Fictional Puzzle Context: ${body.puzzleSummary}` : '',
      typeof body.tracePercent === 'number'
        ? `Current Trace Pressure: ${Math.round(body.tracePercent)}%`
        : '',
      body.playerChoice ? `Duke's Decision: ${body.playerChoice}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: userPrompt,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          thinkingConfig: {thinkingLevel: ThinkingLevel.LOW},
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            required: ['speaker', 'line'],
            properties: {
              speaker: {type: Type.STRING},
              line: {type: Type.STRING},
              quip: {type: Type.STRING},
            },
          },
        },
      });

      const raw = (response.text ?? '').trim();
      const parsed = JSON.parse(raw) as {
        speaker?: string;
        line?: string;
        quip?: string;
      };
      if (!parsed.line) {
        throw new Error('Empty handler line');
      }

      res.json({
        ok: true,
        fallback: false,
        speaker: parsed.speaker || 'Giles (Handler)',
        line: parsed.line,
        quip: parsed.quip || '',
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : 'Upstream handler error';
      res.status(200).json({
        ok: false,
        fallback: true,
        reason: message,
      });
    }
  });

  if (!IS_PROD) {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.use((_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(
      `Duke Satoshi server running on http://0.0.0.0:${PORT} (${IS_PROD ? 'prod' : 'dev'})`
    );
  });
}

void startServer();
