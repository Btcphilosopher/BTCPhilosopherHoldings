import * as xb from 'xrblocks';
import {DukeSatoshiApp} from './xr/DukeSatoshiApp.ts';

function start() {
  const options = new xb.Options();
  options.setAppTitle('Duke Satoshi of Cyberspace: White Hat');
  options.setAppDescription(
    'An Anglo-futurist cyber-noir spatial heist from Duke Satoshi’s London study.'
  );
  options.enableReticles();
  options.enableHandRays();
  options.xrButton.showEnterSimulatorButton = true;

  xb.add(new DukeSatoshiApp());
  void xb.init(options);
}

document.addEventListener('DOMContentLoaded', start);
