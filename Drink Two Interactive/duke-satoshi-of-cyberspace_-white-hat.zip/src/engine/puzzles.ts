import {createSeededRng, pickRandom, shuffleWithRng} from './rng.ts';
import type {
  ArchiveDecodingPuzzle,
  ArchiveOp,
  IdentityReconstructionPuzzle,
  IdentitySlotClue,
  SignalChannelPair,
  SignalRoutingPuzzle,
} from './types.ts';

function keyOf(r: number, c: number): string {
  return `${r},${c}`;
}

function sameCoord(a: [number, number], b: [number, number]): boolean {
  return a[0] === b[0] && a[1] === b[1];
}

// ============================================================================
// 1. SIGNAL ROUTING PUZZLE
// ============================================================================

interface RoutingTemplate {
  channels: Array<{
    id: string;
    colorName: 'Cyan' | 'Gold' | 'Violet';
    colorHex: string;
    path: Array<[number, number]>;
  }>;
  freeCells: Array<[number, number]>;
}

const ROUTING_TEMPLATES_2CH: RoutingTemplate[] = [
  {
    channels: [
      {
        id: 'ch_cyan',
        colorName: 'Cyan',
        colorHex: '#38bdf8',
        path: [
          [0, 0],
          [1, 0],
          [2, 0],
          [2, 1],
          [2, 2],
          [3, 2],
        ],
      },
      {
        id: 'ch_gold',
        colorName: 'Gold',
        colorHex: '#eab308',
        path: [
          [0, 2],
          [0, 3],
          [1, 3],
          [2, 3],
          [3, 3],
        ],
      },
    ],
    freeCells: [
      [0, 1],
      [1, 1],
      [1, 2],
      [3, 0],
      [3, 1],
    ],
  },
  {
    channels: [
      {
        id: 'ch_cyan',
        colorName: 'Cyan',
        colorHex: '#38bdf8',
        path: [
          [0, 1],
          [0, 0],
          [1, 0],
          [1, 1],
          [1, 2],
          [2, 2],
        ],
      },
      {
        id: 'ch_gold',
        colorName: 'Gold',
        colorHex: '#eab308',
        path: [
          [3, 0],
          [3, 1],
          [3, 2],
          [3, 3],
          [2, 3],
        ],
      },
    ],
    freeCells: [
      [0, 2],
      [0, 3],
      [1, 3],
      [2, 0],
      [2, 1],
    ],
  },
];

const ROUTING_TEMPLATES_3CH: RoutingTemplate[] = [
  {
    channels: [
      {
        id: 'ch_cyan',
        colorName: 'Cyan',
        colorHex: '#38bdf8',
        path: [
          [0, 0],
          [1, 0],
          [2, 0],
          [2, 1],
        ],
      },
      {
        id: 'ch_gold',
        colorName: 'Gold',
        colorHex: '#eab308',
        path: [
          [0, 2],
          [0, 3],
          [1, 3],
          [2, 3],
          [3, 3],
        ],
      },
      {
        id: 'ch_violet',
        colorName: 'Violet',
        colorHex: '#a78bfa',
        path: [
          [3, 0],
          [3, 1],
          [3, 2],
          [2, 2],
        ],
      },
    ],
    freeCells: [
      [0, 1],
      [1, 1],
      [1, 2],
    ],
  },
];

function transformCoord(
  [r, c]: [number, number],
  size: number,
  rotation: number,
  flipX: boolean
): [number, number] {
  let nr = r;
  let nc = flipX ? size - 1 - c : c;
  for (let i = 0; i < rotation; i++) {
    const tmp = nr;
    nr = nc;
    nc = size - 1 - tmp;
  }
  return [nr, nc];
}

function directionLabel([dr, dc]: [number, number]): string {
  if (dr === -1 && dc === 0) return 'UP';
  if (dr === 1 && dc === 0) return 'DOWN';
  if (dr === 0 && dc === -1) return 'LEFT';
  return 'RIGHT';
}

export function generateSignalRoutingPuzzle(
  seed: number,
  channelCount: 2 | 3 = 2
): SignalRoutingPuzzle {
  const rng = createSeededRng(seed);
  const gridSize = 4;
  const templates =
    channelCount === 3 ? ROUTING_TEMPLATES_3CH : ROUTING_TEMPLATES_2CH;
  const template = pickRandom(rng, templates);
  const rotation = Math.floor(rng() * 4);
  const flipX = rng() > 0.5;

  const channels: SignalChannelPair[] = template.channels.map((ch) => {
    const transformed = ch.path.map((p) =>
      transformCoord(p, gridSize, rotation, flipX)
    );
    return {
      id: ch.id,
      colorName: ch.colorName,
      colorHex: ch.colorHex,
      start: transformed[0],
      end: transformed[transformed.length - 1],
      solutionPath: transformed,
    };
  });

  const freeTransformed = template.freeCells.map((p) =>
    transformCoord(p, gridSize, rotation, flipX)
  );
  const shuffledFree = shuffleWithRng(rng, freeTransformed);
  const blockedCells = shuffledFree.slice(0, channelCount === 3 ? 2 : 3);

  // Place one directional diode on the first channel's interior step
  const firstPath = channels[0].solutionPath;
  const diodeIdx = Math.min(2, firstPath.length - 2);
  const pos = firstPath[diodeIdx];
  const next = firstPath[diodeIdx + 1];
  const dir: [number, number] = [next[0] - pos[0], next[1] - pos[1]];

  const playerPaths: Record<string, Array<[number, number]>> = {};
  for (const ch of channels) {
    playerPaths[ch.id] = [ch.start];
  }

  const puzzle: SignalRoutingPuzzle = {
    kind: 'signal_routing',
    seed,
    gridSize,
    channels,
    blockedCells,
    directionalGates: [
      {
        pos,
        dir,
        label: directionLabel(dir),
      },
    ],
    playerPaths,
    solved: false,
  };

  return puzzle;
}

export function validateSignalRouting(puzzle: SignalRoutingPuzzle): {
  valid: boolean;
  reason?: string;
} {
  const blockedSet = new Set(puzzle.blockedCells.map(([r, c]) => keyOf(r, c)));
  const occupied = new Map<string, string>();

  for (const ch of puzzle.channels) {
    const path = puzzle.playerPaths[ch.id] ?? [];
    if (path.length < 2) {
      return {
        valid: false,
        reason: `${ch.colorName} channel is incomplete.`,
      };
    }
    if (!sameCoord(path[0], ch.start) || !sameCoord(path[path.length - 1], ch.end)) {
      return {
        valid: false,
        reason: `${ch.colorName} channel must connect Start to Sink.`,
      };
    }

    const seenInChannel = new Set<string>();
    for (let i = 0; i < path.length; i++) {
      const [r, c] = path[i];
      if (r < 0 || r >= puzzle.gridSize || c < 0 || c >= puzzle.gridSize) {
        return {valid: false, reason: 'Path exits grid bounds.'};
      }
      const k = keyOf(r, c);
      if (blockedSet.has(k)) {
        return {
          valid: false,
          reason: `${ch.colorName} channel hits interference barrier at (${r},${c}).`,
        };
      }
      if (seenInChannel.has(k)) {
        return {
          valid: false,
          reason: `${ch.colorName} channel loops onto itself.`,
        };
      }
      seenInChannel.add(k);

      const prevOwner = occupied.get(k);
      if (prevOwner && prevOwner !== ch.id) {
        return {
          valid: false,
          reason: `Signal collision at (${r},${c}) between channels.`,
        };
      }
      occupied.set(k, ch.id);

      if (i > 0) {
        const [pr, pc] = path[i - 1];
        const manhattan = Math.abs(r - pr) + Math.abs(c - pc);
        if (manhattan !== 1) {
          return {
            valid: false,
            reason: `${ch.colorName} channel must step orthogonally.`,
          };
        }
      }

      // Check directional diode constraint when leaving this cell
      if (i < path.length - 1) {
        const gate = puzzle.directionalGates.find((g) => sameCoord(g.pos, [r, c]));
        if (gate) {
          const [nr, nc] = path[i + 1];
          const stepDr = nr - r;
          const stepDc = nc - c;
          if (stepDr !== gate.dir[0] || stepDc !== gate.dir[1]) {
            return {
              valid: false,
              reason: `Directional diode at (${r},${c}) requires exiting ${gate.label}.`,
            };
          }
        }
      }
    }
  }

  return {valid: true};
}

export function stepSignalChannel(
  puzzle: SignalRoutingPuzzle,
  channelId: string,
  cell: [number, number]
): {updated: boolean; message: string} {
  const ch = puzzle.channels.find((c) => c.id === channelId);
  if (!ch) return {updated: false, message: 'Unknown channel.'};

  const blocked = puzzle.blockedCells.some((b) => sameCoord(b, cell));
  if (blocked) {
    return {
      updated: false,
      message: 'Cell is shielded by interference.',
    };
  }

  const current = puzzle.playerPaths[channelId] ?? [ch.start];

  // Clicking an earlier cell trims back to it
  const existingIdx = current.findIndex((p) => sameCoord(p, cell));
  if (existingIdx !== -1) {
    puzzle.playerPaths[channelId] = current.slice(0, existingIdx + 1);
    puzzle.solved = validateSignalRouting(puzzle).valid;
    return {updated: true, message: `${ch.colorName} path trimmed.`};
  }

  // Must be orthogonal to tail
  const tail = current[current.length - 1];
  const dist = Math.abs(tail[0] - cell[0]) + Math.abs(tail[1] - cell[1]);
  if (dist !== 1) {
    return {
      updated: false,
      message: `Select a tile adjacent to the ${ch.colorName} tip (${tail[0]},${tail[1]}).`,
    };
  }

  // Enforce directional diode when leaving tail
  const gate = puzzle.directionalGates.find((g) => sameCoord(g.pos, tail));
  if (gate) {
    const dr = cell[0] - tail[0];
    const dc = cell[1] - tail[1];
    if (dr !== gate.dir[0] || dc !== gate.dir[1]) {
      return {
        updated: false,
        message: `Diode enforces ${gate.label} exit from (${tail[0]},${tail[1]}).`,
      };
    }
  }

  // Prevent crossing another channel's current path
  for (const other of puzzle.channels) {
    if (other.id === channelId) continue;
    const otherPath = puzzle.playerPaths[other.id] ?? [];
    if (otherPath.some((p) => sameCoord(p, cell))) {
      return {
        updated: false,
        message: `Tile occupied by ${other.colorName} channel.`,
      };
    }
  }

  puzzle.playerPaths[channelId] = [...current, cell];
  puzzle.solved = validateSignalRouting(puzzle).valid;
  return {
    updated: true,
    message: puzzle.solved
      ? 'All signal channels synchronized.'
      : `${ch.colorName} routed to (${cell[0]},${cell[1]}).`,
  };
}

// ============================================================================
// 2. IDENTITY RECONSTRUCTION PUZZLE
// ============================================================================

interface IdentityTemplate {
  subjectName: string;
  slots: Array<{
    slotName: string;
    options: string[];
    clueTemplate: (answer: string) => string;
  }>;
}

const IDENTITY_TEMPLATES: IdentityTemplate[] = [
  {
    subjectName: 'Crownline Port Authority — Night Manifest Auditor',
    slots: [
      {
        slotName: 'Division Crest',
        options: ['Thames-East Rail', 'Orbital Dock 4', 'Bonded Cold-Vault'],
        clueTemplate: (ans) =>
          `Freight beacon logs route altered crates exclusively through ${ans}.`,
      },
      {
        slotName: 'Shift Window',
        options: ['01:40 GMT', '03:15 GMT', '05:50 GMT'],
        clueTemplate: (ans) =>
          `Thames fog-gate telemetry recorded the signature stamp at ${ans}.`,
      },
      {
        slotName: 'Clearance Sigil',
        options: ['Amber-Sextant', 'Ivory-Anchor', 'Cobalt-Ledger'],
        clueTemplate: (ans) =>
          `Only stewards carrying the ${ans} seal may override berth weights.`,
      },
      {
        slotName: 'Ledger Checksum',
        options: ['SIG-409-B', 'SIG-772-K', 'SIG-918-M'],
        clueTemplate: (ans) =>
          `Checksum footer ends with the token ${ans} on authentic audit slips.`,
      },
    ],
  },
  {
    subjectName: 'Helix Meridian — Clinical Registry Custodian',
    slots: [
      {
        slotName: 'Lab Wing',
        options: ['Cryo-Block C', 'Gene-Synth North', 'Trial Ward IX'],
        clueTemplate: (ans) =>
          `Biometric badge pings originate from ${ans} before archive lock.`,
      },
      {
        slotName: 'Protocol Cohort',
        options: ['Cohort Vesper', 'Cohort Albion', 'Cohort Halcyon'],
        clueTemplate: (ans) =>
          `Suppressed patient appendix is filed under ${ans}.`,
      },
      {
        slotName: 'Director Sigil',
        options: ['Silver-Caduceus', 'Obsidian-Helix', 'Jade-Pipette'],
        clueTemplate: (ans) =>
          `Board ethics override requires the ${ans} signet imprint.`,
      },
      {
        slotName: 'Audit Epoch',
        options: ['EP-14-DELTA', 'EP-22-SIGMA', 'EP-31-OMEGA'],
        clueTemplate: (ans) =>
          `Frozen snapshot header stamps the epoch ${ans}.`,
      },
    ],
  },
  {
    subjectName: 'Vesper Capital — Sovereign Clearing Steward',
    slots: [
      {
        slotName: 'Vault Desk',
        options: ['Guildhall Desk', 'Threadneedle Core', 'Bishopsgate Annex'],
        clueTemplate: (ans) =>
          `Settlement orders clear only when countersigned at ${ans}.`,
      },
      {
        slotName: 'Cycle Window',
        options: ['Closing Bell', 'Overnight Repo', 'Dawn Settlement'],
        clueTemplate: (ans) =>
          `Synthetic bond entries appear strictly during ${ans}.`,
      },
      {
        slotName: 'Steward Seal',
        options: ['Gold-Florin', 'Bronze-Keystone', 'Azure-Crown'],
        clueTemplate: (ans) =>
          `Fictional bearer tokens bear the ${ans} watermark.`,
      },
      {
        slotName: 'Ledger Parity',
        options: ['PAR-88-EVEN', 'PAR-43-ODD', 'PAR-19-PRIME'],
        clueTemplate: (ans) =>
          `Clearinghouse parity tag reads ${ans} on dual-signed slips.`,
      },
    ],
  },
];

export function generateIdentityPuzzle(
  seed: number,
  templateIndex = 0
): IdentityReconstructionPuzzle {
  const rng = createSeededRng(seed);
  const tmpl =
    IDENTITY_TEMPLATES[Math.abs(templateIndex) % IDENTITY_TEMPLATES.length];

  const slots: IdentitySlotClue[] = tmpl.slots.map((slot, idx) => {
    const shuffled = shuffleWithRng(rng, slot.options);
    const correctOption = pickRandom(rng, shuffled);
    return {
      slotIndex: idx,
      slotName: slot.slotName,
      options: shuffled,
      correctOption,
      clueText: slot.clueTemplate(correctOption),
      revealedByDefault: idx < 2,
    };
  });

  return {
    kind: 'identity_reconstruction',
    seed,
    subjectName: tmpl.subjectName,
    slots,
    selectedOptions: slots.map((s) => s.options[0]),
    solved: false,
  };
}

export function validateIdentityPuzzle(
  puzzle: IdentityReconstructionPuzzle
): boolean {
  return puzzle.slots.every(
    (slot, idx) => puzzle.selectedOptions[idx] === slot.correctOption
  );
}

// ============================================================================
// 3. ARCHIVE DECODING PUZZLE
// ============================================================================

export function applyArchiveOp(ring: number[], op: ArchiveOp): number[] {
  const [a, b, c, d] = ring;
  switch (op) {
    case 'ROTATE_CW':
      return [d, a, b, c];
    case 'FLIP_POLARITY':
      return [b, a, d, c];
    case 'SHIFT_RING':
      return [c, b, a, d];
  }
}

function findShortestArchiveSolution(
  start: number[],
  target: number[]
): ArchiveOp[] {
  const ops: ArchiveOp[] = ['ROTATE_CW', 'FLIP_POLARITY', 'SHIFT_RING'];
  const targetKey = target.join(',');
  const startKey = start.join(',');
  if (startKey === targetKey) return [];

  const queue: Array<{state: number[]; path: ArchiveOp[]}> = [
    {state: start, path: []},
  ];
  const visited = new Set<string>([startKey]);

  while (queue.length > 0) {
    const current = queue.shift()!;
    for (const op of ops) {
      const next = applyArchiveOp(current.state, op);
      const nextKey = next.join(',');
      if (visited.has(nextKey)) continue;
      const nextPath = [...current.path, op];
      if (nextKey === targetKey) return nextPath;
      visited.add(nextKey);
      queue.push({state: next, path: nextPath});
    }
  }
  return [];
}

export function generateArchivePuzzle(seed: number): ArchiveDecodingPuzzle {
  const rng = createSeededRng(seed);
  const targetRing = [0, 1, 2, 3];
  const ops: ArchiveOp[] = ['ROTATE_CW', 'FLIP_POLARITY', 'SHIFT_RING'];

  let scrambled = [...targetRing];
  const scrambleCount = 4 + Math.floor(rng() * 3);
  for (let i = 0; i < scrambleCount; i++) {
    scrambled = applyArchiveOp(scrambled, pickRandom(rng, ops));
  }
  if (scrambled.join(',') === targetRing.join(',')) {
    scrambled = applyArchiveOp(scrambled, 'ROTATE_CW');
    scrambled = applyArchiveOp(scrambled, 'FLIP_POLARITY');
  }

  const solutionOps = findShortestArchiveSolution(scrambled, targetRing);

  return {
    kind: 'archive_decoding',
    seed,
    glyphLabels: ['A-CROWN', 'B-CYAN', 'C-GOLD', 'D-SEAL'],
    initialRing: [...scrambled],
    targetRing,
    currentRing: [...scrambled],
    solutionOps,
    movesTaken: 0,
    parMoves: Math.max(1, solutionOps.length),
    solved: false,
  };
}

export function stepArchivePuzzle(
  puzzle: ArchiveDecodingPuzzle,
  op: ArchiveOp
): boolean {
  puzzle.currentRing = applyArchiveOp(puzzle.currentRing, op);
  puzzle.movesTaken += 1;
  puzzle.solved = puzzle.currentRing.join(',') === puzzle.targetRing.join(',');
  return puzzle.solved;
}

export function validateArchivePuzzle(puzzle: ArchiveDecodingPuzzle): boolean {
  return puzzle.currentRing.join(',') === puzzle.targetRing.join(',');
}

export function getNextOptimalArchiveOp(
  puzzle: ArchiveDecodingPuzzle
): ArchiveOp | null {
  if (puzzle.solved) return null;
  const remaining = findShortestArchiveSolution(
    puzzle.currentRing,
    puzzle.targetRing
  );
  return remaining[0] ?? null;
}
