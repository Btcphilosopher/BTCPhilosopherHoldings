export type CorporationId =
  | 'helix_meridian'
  | 'crownline_logistics'
  | 'argent_cloud'
  | 'northstar_consumer'
  | 'vesper_capital';

export type NodeType =
  | 'entry_gateway'
  | 'routing_junction'
  | 'identity_puzzle'
  | 'encrypted_archive'
  | 'monitoring_node'
  | 'decoy'
  | 'evidence_cache'
  | 'extraction_point';

export type PuzzleKind =
  | 'signal_routing'
  | 'identity_reconstruction'
  | 'archive_decoding';

export type ToolId =
  | 'spectral_lens'
  | 'cipher_loom'
  | 'ghost_thread'
  | 'mirror_key'
  | 'cold_storage';

export type GamePhase =
  | 'STUDY_BRIEFING'
  | 'LOADOUT_PREP'
  | 'NETWORK_INFILTRATION'
  | 'EXTRACTION'
  | 'MISSION_DEBRIEF'
  | 'UPGRADE_WORKSHOP';

export type HintTier = 1 | 2 | 3;

export interface CorporationDef {
  id: CorporationId;
  name: string;
  sector: string;
  accentHex: string;
  secondaryHex: string;
  politics: string;
  puzzleStyle: string;
  motto: string;
}

export interface ToolDef {
  id: ToolId;
  name: string;
  shortLabel: string;
  tagline: string;
  computeCost: number;
  baseCharges: number;
  traceDelta: number;
  tradeoff: string;
  upgradeCost: number;
  upgradeDescription: string;
}

export interface SignalChannelPair {
  id: string;
  colorName: 'Cyan' | 'Gold' | 'Violet';
  colorHex: string;
  start: [number, number];
  end: [number, number];
  solutionPath: Array<[number, number]>;
}

export interface SignalRoutingPuzzle {
  kind: 'signal_routing';
  seed: number;
  gridSize: number;
  channels: SignalChannelPair[];
  /** Blocked cells `[row, col]` acting as interference barriers */
  blockedCells: Array<[number, number]>;
  /** Directional diode cells enforcing step direction `[dr, dc]` */
  directionalGates: Array<{
    pos: [number, number];
    dir: [number, number];
    label: string;
  }>;
  /** Player-drawn paths keyed by channel id */
  playerPaths: Record<string, Array<[number, number]>>;
  solved: boolean;
}

export interface IdentitySlotClue {
  slotIndex: number;
  slotName: string;
  options: string[];
  correctOption: string;
  clueText: string;
  revealedByDefault: boolean;
}

export interface IdentityReconstructionPuzzle {
  kind: 'identity_reconstruction';
  seed: number;
  subjectName: string;
  slots: IdentitySlotClue[];
  selectedOptions: string[];
  solved: boolean;
}

export type ArchiveOp = 'ROTATE_CW' | 'FLIP_POLARITY' | 'SHIFT_RING';

export interface ArchiveDecodingPuzzle {
  kind: 'archive_decoding';
  seed: number;
  glyphLabels: string[];
  initialRing: number[];
  targetRing: number[];
  currentRing: number[];
  solutionOps: ArchiveOp[];
  movesTaken: number;
  parMoves: number;
  solved: boolean;
}

export type PuzzleState =
  | SignalRoutingPuzzle
  | IdentityReconstructionPuzzle
  | ArchiveDecodingPuzzle;

export interface ClueFragment {
  id: string;
  title: string;
  summary: string;
  forPuzzleNodeId?: string;
  revealed: boolean;
}

export interface EvidenceItem {
  id: string;
  title: string;
  quality: 'Primary' | 'Corroborating' | 'Rare Asset';
  creditValue: number;
  storageCost: number;
  summary: string;
  collected: boolean;
}

export interface NetworkNodeDef {
  id: string;
  label: string;
  shortCode: string;
  type: NodeType;
  routeTag: 'entry' | 'silent_ledger' | 'dispatch_core' | 'shared_vault';
  position: [number, number, number];
  connections: string[];
  requiresUnlocked?: string[];
  /** Optional hidden shortcut revealed by Spectral Lens or investigating clues */
  hiddenConnectionTo?: string;
  hiddenRevealed?: boolean;
  computeCost: number;
  baseTraceGain: number;
  description: string;
  puzzleKind?: PuzzleKind;
  clueIds?: string[];
  evidenceId?: string;
  isDecoyTrap?: boolean;
  mirrorKeyCompatible?: boolean;
}

export interface NetworkNodeRuntime extends NetworkNodeDef {
  discovered: boolean;
  unlocked: boolean;
  completed: boolean;
  lockedOut: boolean;
  concealed: boolean;
  inspected: boolean;
  puzzle?: PuzzleState;
}

export interface TrustChoiceOption {
  id: string;
  label: string;
  faction: string;
  summary: string;
  creditMultiplier: number;
  flatBonus: number;
  reputationDelta: Partial<Record<CorporationId, number>>;
  narrativeTag: string;
  dukeQuip: string;
}

export interface ContractDef {
  id: string;
  codeName: string;
  title: string;
  corporationId: CorporationId;
  difficulty: 'Introductory' | 'Standard' | 'High-Stakes';
  seed: number;
  baseReward: number;
  computeBudget: number;
  extractionCapacity: number;
  briefingLead: string;
  briefingDetail: string;
  requiredNodeId: string;
  extractionNodeId: string;
  minReputation?: Partial<Record<CorporationId, number>>;
  prerequisiteMissionId?: string;
  nodes: NetworkNodeDef[];
  clues: ClueFragment[];
  evidence: EvidenceItem[];
  trustChoices: TrustChoiceOption[];
}

export interface TraceConsequenceEvent {
  id: string;
  threshold: number;
  title: string;
  effectType:
    | 'warning'
    | 'route_lockdown'
    | 'tool_disabled'
    | 'reward_cut'
    | 'forced_extraction';
  description: string;
  triggered: boolean;
}

export interface EconomyBreakdown {
  baseContract: number;
  optionalEvidence: number;
  efficiencyBonus: number;
  assetRecovery: number;
  choiceAdjustment: number;
  tracePenalty: number;
  equipmentUpkeep: number;
  netCredits: number;
  claimId: string;
}

export interface MissionRunState {
  contractId: string;
  seed: number;
  selectedTools: ToolId[];
  toolCharges: Record<ToolId, number>;
  disabledTools: ToolId[];
  computeRemaining: number;
  computeMax: number;
  tracePressure: number;
  traceMax: number;
  extractionCapacity: number;
  carriedEvidenceIds: string[];
  preservedEvidenceIds: string[];
  activeNodeId: string;
  nodes: Record<string, NetworkNodeRuntime>;
  clues: Record<string, ClueFragment>;
  evidence: Record<string, EvidenceItem>;
  consequences: TraceConsequenceEvent[];
  selectedTrustChoiceId: string | null;
  actionLog: string[];
  turnsElapsed: number;
  forcedExtraction: boolean;
  extracted: boolean;
  rewardClaimed: boolean;
  debrief: EconomyBreakdown | null;
}

export interface AccessibilitySettings {
  postureMode: 'seated' | 'standing';
  uiDistance: number;
  fontScale: number;
  highContrast: boolean;
  pauseTimersOnMenu: boolean;
  arPassthrough: boolean;
  audioMuted: boolean;
}

export interface SaveFileV1 {
  version: 1;
  savedAt: string;
  checksum: string;
  cipherCredits: number;
  reputation: Record<CorporationId, number>;
  toolUpgrades: Record<ToolId, number>;
  equipmentCondition: Record<ToolId, number>;
  completedContracts: Record<
    string,
    {
      timesCompleted: number;
      bestCredits: number;
      lastChoiceId: string;
    }
  >;
  narrativeFlags: string[];
  accessibility: AccessibilitySettings;
}

export interface HandlerDialoguePayload {
  speaker: string;
  line: string;
  quip?: string;
  source: 'gemini-4.0' | 'scripted';
}
