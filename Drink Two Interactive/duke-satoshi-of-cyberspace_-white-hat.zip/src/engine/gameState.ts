import {CORPORATIONS} from './corporations.ts';
import {CONTRACTS, getContractById} from './missions.ts';
import {
  generateArchivePuzzle,
  generateIdentityPuzzle,
  generateSignalRoutingPuzzle,
  getNextOptimalArchiveOp,
  stepArchivePuzzle,
  stepSignalChannel,
  validateIdentityPuzzle,
  validateSignalRouting,
} from './puzzles.ts';
import {SaveManager} from './saveSystem.ts';
import {TOOLS} from './tools.ts';
import type {
  AccessibilitySettings,
  ContractDef,
  CorporationId,
  EconomyBreakdown,
  GamePhase,
  MissionRunState,
  NetworkNodeRuntime,
  PuzzleState,
  SaveFileV1,
  ToolId,
  TraceConsequenceEvent,
} from './types.ts';

export type EngineListener = () => void;

export class GameEngine {
  private saveManager: SaveManager;
  private saveState: SaveFileV1;
  private listeners = new Set<EngineListener>();

  public phase: GamePhase = 'STUDY_BRIEFING';
  public selectedContractId = 'meridian_ledger';
  public draftLoadout: ToolId[] = ['spectral_lens', 'ghost_thread', 'cipher_loom'];
  public activeRun: MissionRunState | null = null;
  public activeChannelId = 'ch_cyan';
  public activeHintTier: 0 | 1 | 2 | 3 = 0;
  public timersPaused = false;
  public recoveredFromBackup = false;
  public lastFeedback =
    'Good evening, Your Grace. Crownline Logistics’ berth telemetry awaits inspection.';

  constructor(saveManager?: SaveManager) {
    this.saveManager = saveManager ?? new SaveManager();
    const loaded = this.saveManager.load();
    this.saveState = loaded.save;
    this.recoveredFromBackup = loaded.recoveredFromBackup;
  }

  subscribe(listener: EngineListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit() {
    for (const listener of this.listeners) listener();
  }

  getSave(): Readonly<SaveFileV1> {
    return this.saveState;
  }

  getAccessibility(): AccessibilitySettings {
    return this.saveState.accessibility;
  }

  updateAccessibility(partial: Partial<AccessibilitySettings>) {
    this.saveState = this.saveManager.save({
      ...this.saveState,
      accessibility: {
        ...this.saveState.accessibility,
        ...partial,
      },
    });
    this.emit();
  }

  setTimersPaused(paused: boolean) {
    this.timersPaused = paused;
    this.emit();
  }

  getAvailableContracts(): Array<{
    contract: ContractDef;
    unlocked: boolean;
    lockReason?: string;
    completedCount: number;
  }> {
    return CONTRACTS.map((contract) => {
      const completedCount =
        this.saveState.completedContracts[contract.id]?.timesCompleted ?? 0;
      if (
        contract.prerequisiteMissionId &&
        !this.saveState.completedContracts[contract.prerequisiteMissionId]
      ) {
        const prereq = getContractById(contract.prerequisiteMissionId);
        return {
          contract,
          unlocked: false,
          lockReason: `Complete "${prereq.title}" first.`,
          completedCount,
        };
      }
      return {contract, unlocked: true, completedCount};
    });
  }

  selectContract(contractId: string) {
    const info = this.getAvailableContracts().find(
      (c) => c.contract.id === contractId
    );
    if (!info || !info.unlocked) {
      this.lastFeedback = info?.lockReason ?? 'Contract unavailable.';
      this.emit();
      return false;
    }
    this.selectedContractId = contractId;
    this.phase = 'STUDY_BRIEFING';
    this.lastFeedback = `Dossier opened: ${info.contract.title} (${CORPORATIONS[info.contract.corporationId].name}).`;
    this.emit();
    return true;
  }

  goToLoadout() {
    this.phase = 'LOADOUT_PREP';
    this.lastFeedback =
      'Select up to three tools from the cabinet. Each brings a clear operational tradeoff.';
    this.emit();
  }

  goToBriefing() {
    this.phase = 'STUDY_BRIEFING';
    this.emit();
  }

  goToWorkshop() {
    this.phase = 'UPGRADE_WORKSHOP';
    this.lastFeedback =
      'Equipment Workshop: upgrade capacity or refurbish worn modules using Cipher Credits.';
    this.emit();
  }

  toggleDraftTool(toolId: ToolId): boolean {
    const idx = this.draftLoadout.indexOf(toolId);
    if (idx !== -1) {
      if (this.draftLoadout.length <= 1) {
        this.lastFeedback = 'Duke Satoshi never enters a grid empty-handed.';
        this.emit();
        return false;
      }
      this.draftLoadout = this.draftLoadout.filter((id) => id !== toolId);
      this.emit();
      return true;
    }
    if (this.draftLoadout.length >= 3) {
      this.lastFeedback =
        'Loadout holds at most 3 tools. Deselect one before adding another.';
      this.emit();
      return false;
    }
    this.draftLoadout = [...this.draftLoadout, toolId];
    this.emit();
    return true;
  }

  upgradeTool(toolId: ToolId): boolean {
    const def = TOOLS[toolId];
    const currentLv = this.saveState.toolUpgrades[toolId] ?? 1;
    if (currentLv >= 3) {
      this.lastFeedback = `${def.name} is already at Masterwork Lv.3.`;
      this.emit();
      return false;
    }
    const cost = def.upgradeCost * currentLv;
    if (this.saveState.cipherCredits < cost) {
      this.lastFeedback = `Requires ${cost} Cipher Credits to upgrade ${def.name}.`;
      this.emit();
      return false;
    }
    this.saveState = this.saveManager.save({
      ...this.saveState,
      cipherCredits: this.saveState.cipherCredits - cost,
      toolUpgrades: {
        ...this.saveState.toolUpgrades,
        [toolId]: currentLv + 1,
      },
    });
    this.lastFeedback = `${def.name} upgraded to Lv.${currentLv + 1}.`;
    this.emit();
    return true;
  }

  repairTool(toolId: ToolId): boolean {
    const cond = this.saveState.equipmentCondition[toolId] ?? 100;
    if (cond >= 100) {
      this.lastFeedback = `${TOOLS[toolId].name} is already in pristine condition.`;
      this.emit();
      return false;
    }
    const cost = Math.max(20, Math.round((100 - cond) * 1.2));
    if (this.saveState.cipherCredits < cost) {
      this.lastFeedback = `Requires ${cost} Cipher Credits to refurbish ${TOOLS[toolId].name}.`;
      this.emit();
      return false;
    }
    this.saveState = this.saveManager.save({
      ...this.saveState,
      cipherCredits: this.saveState.cipherCredits - cost,
      equipmentCondition: {
        ...this.saveState.equipmentCondition,
        [toolId]: 100,
      },
    });
    this.lastFeedback = `${TOOLS[toolId].name} restored to 100% condition.`;
    this.emit();
    return true;
  }

  startMission(seedOverride?: number): MissionRunState {
    const contract = getContractById(this.selectedContractId);
    const seed = seedOverride ?? contract.seed;

    const toolCharges = {
      spectral_lens: 0,
      cipher_loom: 0,
      ghost_thread: 0,
      mirror_key: 0,
      cold_storage: 0,
    } as Record<ToolId, number>;

    for (const toolId of this.draftLoadout) {
      const lv = this.saveState.toolUpgrades[toolId] ?? 1;
      const cond = this.saveState.equipmentCondition[toolId] ?? 100;
      const base = TOOLS[toolId].baseCharges;
      const upgradeBonus =
        (toolId === 'spectral_lens' ||
          toolId === 'cipher_loom' ||
          toolId === 'mirror_key') &&
        lv >= 2
          ? 1
          : 0;
      const wearPenalty = cond < 40 ? -1 : 0;
      toolCharges[toolId] = Math.max(1, base + upgradeBonus + wearPenalty);
    }

    const coldLv = this.saveState.toolUpgrades.cold_storage ?? 1;
    const extraCap =
      this.draftLoadout.includes('cold_storage') && coldLv >= 2 ? 1 : 0;

    const nodes: Record<string, NetworkNodeRuntime> = {};
    let puzzleOffset = 1;
    for (const n of contract.nodes) {
      let puzzle: PuzzleState | undefined;
      if (n.puzzleKind === 'signal_routing') {
        const channels: 2 | 3 = contract.id === 'meridian_ledger' ? 2 : 3;
        puzzle = generateSignalRoutingPuzzle(seed + puzzleOffset * 97, channels);
      } else if (n.puzzleKind === 'identity_reconstruction') {
        const tmplIdx =
          contract.id === 'meridian_ledger'
            ? 0
            : contract.id === 'helix_protocol'
              ? 1
              : 2;
        puzzle = generateIdentityPuzzle(seed + puzzleOffset * 131, tmplIdx);
      } else if (n.puzzleKind === 'archive_decoding') {
        puzzle = generateArchivePuzzle(seed + puzzleOffset * 173);
      }
      puzzleOffset++;

      const isEntry = n.type === 'entry_gateway';
      nodes[n.id] = {
        ...n,
        discovered: isEntry || n.connections.includes(contract.nodes[0].id),
        unlocked: isEntry,
        completed: isEntry,
        lockedOut: false,
        concealed: false,
        inspected: isEntry,
        puzzle,
      };
    }

    const clues: MissionRunState['clues'] = {};
    for (const c of contract.clues) {
      clues[c.id] = {...c};
    }

    const evidence: MissionRunState['evidence'] = {};
    for (const e of contract.evidence) {
      evidence[e.id] = {...e, collected: false};
    }

    const consequences: TraceConsequenceEvent[] = [
      {
        id: 'warn_50',
        threshold: 50,
        title: 'Security Caution (50%)',
        effectType: 'warning',
        description:
          'Automated sweeps have noticed irregular traffic. Consider Ghost Thread or quieter nodes.',
        triggered: false,
      },
      {
        id: 'lock_75',
        threshold: 75,
        title: 'Containment Response (75%)',
        effectType: 'route_lockdown',
        description:
          'Security seals one auxiliary node and disrupts one module charge.',
        triggered: false,
      },
      {
        id: 'cut_90',
        threshold: 90,
        title: 'Audit Scrubbing Fee (90%)',
        effectType: 'reward_cut',
        description:
          'Emergency signal laundering reduces final Cipher Credit payout by 15%.',
        triggered: false,
      },
      {
        id: 'force_100',
        threshold: 100,
        title: 'Forced Extraction (100%)',
        effectType: 'forced_extraction',
        description:
          'Link severed safely back to the Study. Cold Storage preserves protected evidence.',
        triggered: false,
      },
    ];

    const entryNode = contract.nodes[0];
    this.activeRun = {
      contractId: contract.id,
      seed,
      selectedTools: [...this.draftLoadout],
      toolCharges,
      disabledTools: [],
      computeRemaining: contract.computeBudget,
      computeMax: contract.computeBudget,
      tracePressure: entryNode.baseTraceGain,
      traceMax: 100,
      extractionCapacity: contract.extractionCapacity + extraCap,
      carriedEvidenceIds: [],
      preservedEvidenceIds: [],
      activeNodeId: entryNode.id,
      nodes,
      clues,
      evidence,
      consequences,
      selectedTrustChoiceId: null,
      actionLog: [
        `Entered ${CORPORATIONS[contract.corporationId].name} network via ${entryNode.label}.`,
      ],
      turnsElapsed: 0,
      forcedExtraction: false,
      extracted: false,
      rewardClaimed: false,
      debrief: null,
    };

    // Reveal initial gateway clues
    this.revealNodeClues(entryNode.id);
    this.activeChannelId = 'ch_cyan';
    this.activeHintTier = 0;
    this.phase = 'NETWORK_INFILTRATION';
    this.lastFeedback = `Linked to ${entryNode.label}. Choose a route: Silent Ledger (left) or Dispatch Core (right).`;
    this.emit();
    return this.activeRun;
  }

  private revealNodeClues(nodeId: string) {
    if (!this.activeRun) return;
    const node = this.activeRun.nodes[nodeId];
    if (!node?.clueIds) return;
    for (const cid of node.clueIds) {
      if (this.activeRun.clues[cid]) {
        this.activeRun.clues[cid].revealed = true;
      }
    }
    // Sync revealed clues to any identity puzzle slots
    for (const n of Object.values(this.activeRun.nodes)) {
      if (n.puzzle?.kind === 'identity_reconstruction') {
        const revealedCount = Object.values(this.activeRun.clues).filter(
          (c) => c.revealed && c.forPuzzleNodeId === n.id
        ).length;
        n.puzzle.slots.forEach((slot, idx) => {
          if (idx < revealedCount) slot.revealedByDefault = true;
        });
      }
    }
  }

  canAccessNode(nodeId: string): {ok: boolean; reason?: string} {
    const run = this.activeRun;
    if (!run) return {ok: false, reason: 'No active mission.'};
    const node = run.nodes[nodeId];
    if (!node) return {ok: false, reason: 'Unknown node.'};
    if (node.lockedOut) {
      return {ok: false, reason: 'Locked out by corporate containment.'};
    }

    // Either connected to current node OR unlocked/discovered adjacent to any completed node
    const completedNodes = Object.values(run.nodes).filter((n) => n.completed);
    const reachable =
      nodeId === run.activeNodeId ||
      completedNodes.some(
        (c) =>
          c.connections.includes(nodeId) ||
          (c.hiddenRevealed && c.hiddenConnectionTo === nodeId)
      );

    if (!reachable) {
      return {
        ok: false,
        reason: 'Unlock an adjacent connected node first.',
      };
    }

    if (node.requiresUnlocked && node.requiresUnlocked.length > 0) {
      const anyReqMet =
        node.requiresUnlocked.some((reqId) => run.nodes[reqId]?.completed) ||
        completedNodes.some(
          (c) => c.hiddenRevealed && c.hiddenConnectionTo === nodeId
        );
      if (!anyReqMet) {
        const names = node.requiresUnlocked
          .map((id) => run.nodes[id]?.label ?? id)
          .join(' or ');
        return {ok: false, reason: `Requires ${names}.`};
      }
    }

    return {ok: true};
  }

  moveToNode(nodeId: string): boolean {
    const run = this.activeRun;
    if (!run || run.extracted) return false;
    const access = this.canAccessNode(nodeId);
    if (!access.ok) {
      this.lastFeedback = access.reason ?? 'Route blocked.';
      this.emit();
      return false;
    }

    const node = run.nodes[nodeId];
    if (run.activeNodeId === nodeId) {
      this.lastFeedback = `Inspecting ${node.label}.`;
      this.emit();
      return true;
    }

    // Pay entry cost only on first unlock
    if (!node.unlocked) {
      if (run.computeRemaining < node.computeCost) {
        this.lastFeedback = `Insufficient Compute (${run.computeRemaining}/${node.computeCost} needed).`;
        this.emit();
        return false;
      }
      run.computeRemaining -= node.computeCost;
      node.unlocked = true;
      node.discovered = true;

      // Discover neighbours
      for (const connId of node.connections) {
        if (run.nodes[connId]) run.nodes[connId].discovered = true;
      }

      // Apply trace unless concealed or node already quiet
      const traceGain = node.concealed
        ? Math.max(0, Math.floor(node.baseTraceGain * 0.25))
        : node.baseTraceGain;
      if (traceGain > 0) {
        this.applyTrace(
          traceGain,
          node.isDecoyTrap
            ? `Decoy trap triggered at ${node.label}`
            : `Entered ${node.label}`
        );
      }

      if (node.isDecoyTrap) {
        node.completed = true;
        run.actionLog.push(
          `Decoy triggered at ${node.label}: wasted ${node.computeCost} Compute.`
        );
      } else if (!node.puzzle) {
        // Non-puzzle node (monitoring, evidence cache, extraction)
        node.completed = true;
        this.revealNodeClues(node.id);
        if (node.evidenceId) {
          this.collectEvidence(node.evidenceId);
        }
      }
    }

    run.activeNodeId = nodeId;
    run.turnsElapsed += 1;
    this.activeHintTier = 0;

    if (node.type === 'extraction_point' && node.unlocked) {
      this.phase = 'EXTRACTION';
    }

    this.lastFeedback = node.description;
    this.emit();
    return true;
  }

  /** Step signal routing tile on active node */
  stepActiveSignalCell(row: number, col: number): boolean {
    const run = this.activeRun;
    if (!run) return false;
    const node = run.nodes[run.activeNodeId];
    if (!node?.puzzle || node.puzzle.kind !== 'signal_routing') return false;
    if (node.completed) return true;

    const res = stepSignalChannel(node.puzzle, this.activeChannelId, [row, col]);
    this.lastFeedback = res.message;
    if (res.updated && validateSignalRouting(node.puzzle).valid) {
      node.puzzle.solved = true;
      this.completeNodePuzzle(node);
    }
    this.emit();
    return res.updated;
  }

  resetActiveSignalChannel(channelId?: string) {
    const run = this.activeRun;
    if (!run) return;
    const node = run.nodes[run.activeNodeId];
    if (!node?.puzzle || node.puzzle.kind !== 'signal_routing' || node.completed)
      return;
    const id = channelId ?? this.activeChannelId;
    const ch = node.puzzle.channels.find((c) => c.id === id);
    if (!ch) return;
    node.puzzle.playerPaths[id] = [ch.start];
    node.puzzle.solved = false;
    this.lastFeedback = `${ch.colorName} channel reset.`;
    this.emit();
  }

  selectIdentityOption(slotIndex: number, option: string): boolean {
    const run = this.activeRun;
    if (!run) return false;
    const node = run.nodes[run.activeNodeId];
    if (!node?.puzzle || node.puzzle.kind !== 'identity_reconstruction')
      return false;
    if (node.completed) return true;

    node.puzzle.selectedOptions[slotIndex] = option;
    if (validateIdentityPuzzle(node.puzzle)) {
      node.puzzle.solved = true;
      this.completeNodePuzzle(node);
    } else {
      this.lastFeedback = `Slot ${slotIndex + 1} set to ${option}.`;
    }
    this.emit();
    return true;
  }

  applyActiveArchiveOp(op: 'ROTATE_CW' | 'FLIP_POLARITY' | 'SHIFT_RING'): boolean {
    const run = this.activeRun;
    if (!run) return false;
    const node = run.nodes[run.activeNodeId];
    if (!node?.puzzle || node.puzzle.kind !== 'archive_decoding') return false;
    if (node.completed) return true;

    const solved = stepArchivePuzzle(node.puzzle, op);
    if (solved) {
      this.completeNodePuzzle(node);
    } else {
      this.lastFeedback = `Applied ${op.replace('_', ' ')} (Move ${node.puzzle.movesTaken}).`;
    }
    this.emit();
    return true;
  }

  resetActiveArchivePuzzle() {
    const run = this.activeRun;
    if (!run) return;
    const node = run.nodes[run.activeNodeId];
    if (!node?.puzzle || node.puzzle.kind !== 'archive_decoding' || node.completed)
      return;
    node.puzzle.currentRing = [...node.puzzle.initialRing];
    node.puzzle.movesTaken = 0;
    this.lastFeedback = 'Archive cipher ring reset to initial state.';
    this.emit();
  }

  private completeNodePuzzle(node: NetworkNodeRuntime) {
    if (!this.activeRun || node.completed) return;
    node.completed = true;
    this.revealNodeClues(node.id);
    for (const connId of node.connections) {
      if (this.activeRun.nodes[connId]) {
        this.activeRun.nodes[connId].discovered = true;
      }
    }
    this.activeRun.actionLog.push(`Solved ${node.label} (${node.shortCode}).`);
    this.lastFeedback = `${node.label} unlocked! Adjacent connections are now open.`;

    if (node.evidenceId) {
      this.collectEvidence(node.evidenceId);
    }
  }

  collectEvidence(evidenceId: string): boolean {
    const run = this.activeRun;
    if (!run) return false;
    const ev = run.evidence[evidenceId];
    if (!ev || ev.collected) return false;

    const currentUsed = run.carriedEvidenceIds.reduce(
      (sum, id) => sum + (run.evidence[id]?.storageCost ?? 0),
      0
    );
    if (currentUsed + ev.storageCost > run.extractionCapacity) {
      this.lastFeedback = `Extraction buffer full (${currentUsed}/${run.extractionCapacity}). Cold Storage upgrades expand capacity.`;
      this.emit();
      return false;
    }

    ev.collected = true;
    run.carriedEvidenceIds.push(evidenceId);
    run.actionLog.push(`Secured evidence: ${ev.title}.`);
    this.lastFeedback = `Secured "${ev.title}" (+${ev.creditValue} CC potential).`;
    this.emit();
    return true;
  }

  useTool(toolId: ToolId): boolean {
    const run = this.activeRun;
    if (!run || run.extracted) return false;

    if (!run.selectedTools.includes(toolId)) {
      this.lastFeedback = `${TOOLS[toolId].name} is not in your current loadout.`;
      this.emit();
      return false;
    }
    if (run.disabledTools.includes(toolId)) {
      this.lastFeedback = `${TOOLS[toolId].name} was scrambled by security.`;
      this.emit();
      return false;
    }
    if ((run.toolCharges[toolId] ?? 0) <= 0) {
      this.lastFeedback = `${TOOLS[toolId].name} has no charges remaining.`;
      this.emit();
      return false;
    }

    const lv = this.saveState.toolUpgrades[toolId] ?? 1;
    let cost = TOOLS[toolId].computeCost;
    if ((toolId === 'cipher_loom' || toolId === 'mirror_key') && lv >= 2) {
      cost = Math.max(1, cost - 1);
    }

    if (run.computeRemaining < cost) {
      this.lastFeedback = `Need ${cost} Compute to activate ${TOOLS[toolId].name}.`;
      this.emit();
      return false;
    }

    const node = run.nodes[run.activeNodeId];

    if (toolId === 'spectral_lens') {
      run.computeRemaining -= cost;
      run.toolCharges[toolId] -= 1;
      // Reveal hidden connections, decoy traps on neighbours, and 1 hidden clue
      let revealedSomething = false;
      for (const n of Object.values(run.nodes)) {
        if (n.hiddenConnectionTo && !n.hiddenRevealed) {
          n.hiddenRevealed = true;
          if (run.nodes[n.hiddenConnectionTo]) {
            run.nodes[n.hiddenConnectionTo].discovered = true;
          }
          revealedSomething = true;
        }
        if (node.connections.includes(n.id) && n.isDecoyTrap) {
          n.inspected = true;
          n.discovered = true;
          revealedSomething = true;
        }
      }
      const unrevealedClue = Object.values(run.clues).find((c) => !c.revealed);
      if (unrevealedClue) {
        unrevealedClue.revealed = true;
        revealedSomething = true;
      }
      const trace = lv >= 2 ? 2 : TOOLS.spectral_lens.traceDelta;
      this.applyTrace(trace, 'Spectral Lens pulse');
      this.lastFeedback = revealedSomething
        ? 'Spectral Lens revealed hidden shortcuts, decoy warnings, and an identity clue.'
        : 'Spectral Lens scan complete: no hidden anomalies remain nearby.';
      this.emit();
      return true;
    }

    if (toolId === 'ghost_thread') {
      run.computeRemaining -= cost;
      run.toolCharges[toolId] -= 1;
      for (const connId of node.connections) {
        if (run.nodes[connId]) run.nodes[connId].concealed = true;
      }
      const reduction = lv >= 2 ? -20 : TOOLS.ghost_thread.traceDelta;
      this.applyTrace(reduction, 'Ghost Thread route concealment');
      this.lastFeedback = `Ghost Thread veiled adjacent routes and scrubbed ${Math.abs(reduction)}% Trace Pressure.`;
      this.emit();
      return true;
    }

    if (toolId === 'cipher_loom') {
      if (!node.puzzle || node.completed) {
        this.lastFeedback =
          'Select an active puzzle node before weaving Cipher Loom.';
        this.emit();
        return false;
      }
      run.computeRemaining -= cost;
      run.toolCharges[toolId] -= 1;
      this.applyTrace(TOOLS.cipher_loom.traceDelta, 'Cipher Loom weave');

      if (node.puzzle.kind === 'signal_routing') {
        // Complete one unsolved channel automatically
        const unsolvedCh = node.puzzle.channels.find((ch) => {
          const path = node.puzzle!.kind === 'signal_routing'
            ? node.puzzle!.playerPaths[ch.id] ?? []
            : [];
          return (
            path.length < ch.solutionPath.length ||
            !validateSignalRouting({
              ...node.puzzle as Extract<PuzzleState, {kind: 'signal_routing'}>,
              channels: [ch],
              playerPaths: {[ch.id]: path},
            }).valid
          );
        });
        if (unsolvedCh) {
          node.puzzle.playerPaths[unsolvedCh.id] = [...unsolvedCh.solutionPath];
          if (validateSignalRouting(node.puzzle).valid) {
            node.puzzle.solved = true;
            this.completeNodePuzzle(node);
          } else {
            this.lastFeedback = `Cipher Loom routed the ${unsolvedCh.colorName} channel.`;
          }
        }
      } else if (node.puzzle.kind === 'identity_reconstruction') {
        const wrongIdx = node.puzzle.slots.findIndex(
          (s, i) => node.puzzle!.kind === 'identity_reconstruction' &&
            node.puzzle!.selectedOptions[i] !== s.correctOption
        );
        if (wrongIdx !== -1) {
          node.puzzle.slots[wrongIdx].revealedByDefault = true;
          node.puzzle.selectedOptions[wrongIdx] =
            node.puzzle.slots[wrongIdx].correctOption;
          if (validateIdentityPuzzle(node.puzzle)) {
            node.puzzle.solved = true;
            this.completeNodePuzzle(node);
          } else {
            this.lastFeedback = `Cipher Loom reconstructed ${node.puzzle.slots[wrongIdx].slotName}.`;
          }
        }
      } else if (node.puzzle.kind === 'archive_decoding') {
        const nextOp = getNextOptimalArchiveOp(node.puzzle);
        if (nextOp) {
          const solved = stepArchivePuzzle(node.puzzle, nextOp);
          if (solved) {
            this.completeNodePuzzle(node);
          } else {
            this.lastFeedback = `Cipher Loom executed optimal step: ${nextOp.replace('_', ' ')}.`;
          }
        }
      }
      this.emit();
      return true;
    }

    if (toolId === 'mirror_key') {
      if (!node.mirrorKeyCompatible || node.completed) {
        this.lastFeedback =
          'Mirror Key only unlocks compatible Identity or Core Vault locks.';
        this.emit();
        return false;
      }
      run.computeRemaining -= cost;
      run.toolCharges[toolId] -= 1;
      if (node.puzzle) node.puzzle.solved = true;
      this.completeNodePuzzle(node);
      this.applyTrace(TOOLS.mirror_key.traceDelta, 'Mirror Key lock bypass');
      this.lastFeedback = `Mirror Key cleanly bypassed ${node.label}.`;
      this.emit();
      return true;
    }

    if (toolId === 'cold_storage') {
      const targetEv = run.carriedEvidenceIds.find(
        (id) => !run.preservedEvidenceIds.includes(id)
      );
      if (!targetEv) {
        this.lastFeedback =
          'Carry an evidence packet first before sealing it in Cold Storage.';
        this.emit();
        return false;
      }
      run.computeRemaining -= cost;
      run.toolCharges[toolId] -= 1;
      run.preservedEvidenceIds.push(targetEv);
      this.applyTrace(TOOLS.cold_storage.traceDelta, 'Cold Storage seal');
      this.lastFeedback = `Cold Storage shielded "${run.evidence[targetEv].title}" from forced extraction.`;
      this.emit();
      return true;
    }

    return false;
  }

  private applyTrace(delta: number, reason: string) {
    const run = this.activeRun;
    if (!run) return;
    run.tracePressure = Math.max(0, Math.min(100, run.tracePressure + delta));
    run.actionLog.push(
      `${reason} (${delta >= 0 ? `+${delta}` : delta}% Trace -> ${run.tracePressure}%).`
    );

    for (const c of run.consequences) {
      if (!c.triggered && run.tracePressure >= c.threshold) {
        c.triggered = true;
        this.handleTraceConsequence(c);
      }
    }
  }

  private handleTraceConsequence(event: TraceConsequenceEvent) {
    const run = this.activeRun;
    if (!run) return;

    if (event.effectType === 'route_lockdown') {
      // Lock out one uncompleted auxiliary node if available (recoverable: alternate route still works!)
      const candidate = Object.values(run.nodes).find(
        (n) =>
          !n.completed &&
          n.id !== run.activeNodeId &&
          (n.type === 'monitoring_node' || n.type === 'decoy')
      );
      if (candidate) {
        candidate.lockedOut = true;
        run.actionLog.push(`Containment locked out ${candidate.label}.`);
      }
      // Scramble one tool with charges left (not Cold Storage)
      const toolToDisable = run.selectedTools.find(
        (t) =>
          t !== 'cold_storage' &&
          !run.disabledTools.includes(t) &&
          run.toolCharges[t] > 0
      );
      if (toolToDisable) {
        run.disabledTools.push(toolToDisable);
        run.actionLog.push(
          `Security interference temporarily disabled ${TOOLS[toolToDisable].name}.`
        );
      }
    } else if (event.effectType === 'forced_extraction') {
      run.forcedExtraction = true;
      // If Cold Storage wasn't used, drop non-preserved secondary evidence on forced disconnect
      if (run.carriedEvidenceIds.length > 1) {
        const preserved = new Set(run.preservedEvidenceIds);
        const contract = getContractById(run.contractId);
        const primaryEvId = run.nodes[contract.requiredNodeId]?.evidenceId;
        run.carriedEvidenceIds = run.carriedEvidenceIds.filter(
          (id) => preserved.has(id) || id === primaryEvId
        );
      }
      this.extractMission(true);
    }
  }

  selectTrustChoice(choiceId: string): boolean {
    const run = this.activeRun;
    if (!run) return false;
    const contract = getContractById(run.contractId);
    const choice = contract.trustChoices.find((c) => c.id === choiceId);
    if (!choice) return false;
    run.selectedTrustChoiceId = choiceId;
    run.actionLog.push(`Custodian choice: ${choice.label}.`);
    this.lastFeedback = choice.dukeQuip;
    this.emit();
    return true;
  }

  extractMission(forced = false): EconomyBreakdown | null {
    const run = this.activeRun;
    if (!run) return null;
    if (run.extracted && run.debrief) {
      // Idempotent guard: never duplicate rewards!
      return run.debrief;
    }

    const contract = getContractById(run.contractId);
    const primaryComplete = Boolean(run.nodes[contract.requiredNodeId]?.completed);

    const choice =
      contract.trustChoices.find((c) => c.id === run.selectedTrustChoiceId) ??
      contract.trustChoices[0];

    if (!run.selectedTrustChoiceId && primaryComplete) {
      run.selectedTrustChoiceId = choice.id;
    }

    const baseContract = primaryComplete
      ? contract.baseReward
      : Math.round(contract.baseReward * 0.25);

    let optionalEvidence = 0;
    let assetRecovery = 0;
    for (const evId of run.carriedEvidenceIds) {
      const ev = run.evidence[evId];
      if (!ev) continue;
      if (ev.quality === 'Rare Asset') assetRecovery += ev.creditValue;
      else optionalEvidence += ev.creditValue;
    }

    const efficiencyBonus =
      primaryComplete && !forced && run.tracePressure < 60
        ? 120 + run.computeRemaining * 15
        : 0;

    const choiceAdjustment = primaryComplete
      ? Math.round(baseContract * (choice.creditMultiplier - 1)) + choice.flatBonus
      : 0;

    const traceCutTriggered =
      run.tracePressure >= 90 ||
      run.consequences.some((c) => c.id === 'cut_90' && c.triggered);
    const tracePenalty =
      forced
        ? Math.round((baseContract + optionalEvidence) * 0.25)
        : traceCutTriggered
          ? Math.round((baseContract + optionalEvidence) * 0.15)
          : 0;

    const equipmentUpkeep = run.selectedTools.length * 25;

    const netCredits = Math.max(
      75,
      baseContract +
        optionalEvidence +
        efficiencyBonus +
        assetRecovery +
        choiceAdjustment -
        tracePenalty -
        equipmentUpkeep
    );

    const breakdown: EconomyBreakdown = {
      baseContract,
      optionalEvidence,
      efficiencyBonus,
      assetRecovery,
      choiceAdjustment,
      tracePenalty,
      equipmentUpkeep,
      netCredits,
      claimId: `${contract.id}_${run.seed}_${run.turnsElapsed}`,
    };

    run.extracted = true;
    run.forcedExtraction = forced;
    run.debrief = breakdown;

    // Apply persistent reward once only
    if (!run.rewardClaimed) {
      run.rewardClaimed = true;

      const updatedRep: Record<CorporationId, number> = {
        ...this.saveState.reputation,
      };
      if (primaryComplete) {
        for (const [corpId, delta] of Object.entries(choice.reputationDelta)) {
          const k = corpId as CorporationId;
          updatedRep[k] = Math.max(-100, Math.min(100, (updatedRep[k] ?? 0) + (delta ?? 0)));
        }
      }

      const updatedCondition: Record<ToolId, number> = {
        ...this.saveState.equipmentCondition,
      };
      for (const toolId of run.selectedTools) {
        const wear = forced ? 18 : 8;
        updatedCondition[toolId] = Math.max(
          15,
          (updatedCondition[toolId] ?? 100) - wear
        );
      }

      const prevRecord = this.saveState.completedContracts[contract.id];
      const nextCompleted = {...this.saveState.completedContracts};
      if (primaryComplete) {
        nextCompleted[contract.id] = {
          timesCompleted: (prevRecord?.timesCompleted ?? 0) + 1,
          bestCredits: Math.max(prevRecord?.bestCredits ?? 0, netCredits),
          lastChoiceId: choice.id,
        };
      }

      const nextFlags = new Set(this.saveState.narrativeFlags);
      if (primaryComplete) nextFlags.add(choice.narrativeTag);

      this.saveState = this.saveManager.save({
        ...this.saveState,
        cipherCredits: this.saveState.cipherCredits + netCredits,
        reputation: updatedRep,
        equipmentCondition: updatedCondition,
        completedContracts: nextCompleted,
        narrativeFlags: [...nextFlags],
      });
    }

    this.phase = 'MISSION_DEBRIEF';
    this.lastFeedback = forced
      ? `Emergency extraction completed. Net: +${netCredits} Cipher Credits.`
      : `Clean extraction! Net payout: +${netCredits} Cipher Credits.`;
    this.emit();
    return breakdown;
  }

  returnToStudyFromDebrief() {
    this.activeRun = null;
    this.phase = 'STUDY_BRIEFING';
    this.lastFeedback =
      'Back in the London Study. Review Reputation, Upgrade tools, or take a new contract.';
    this.emit();
  }

  resetProgress() {
    this.saveState = this.saveManager.reset();
    this.activeRun = null;
    this.selectedContractId = 'meridian_ledger';
    this.phase = 'STUDY_BRIEFING';
    this.lastFeedback = 'Campaign ledger reset to fresh Study state.';
    this.emit();
  }
}
