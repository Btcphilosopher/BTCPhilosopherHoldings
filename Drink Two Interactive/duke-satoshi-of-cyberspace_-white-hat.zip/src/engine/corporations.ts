import type {CorporationDef, CorporationId} from './types.ts';

export const CORPORATIONS: Record<CorporationId, CorporationDef> = {
  crownline_logistics: {
    id: 'crownline_logistics',
    name: 'Crownline Logistics',
    sector: 'Automated Freight & Thames Orbital Warehousing',
    accentHex: '#38bdf8',
    secondaryHex: '#d4af37',
    politics:
      'Old-guard maritime barons clashing with an automated ledger board eager to bury customs discrepancies.',
    puzzleStyle: 'Signal Routing & Freight Manifest Reconstruction',
    motto: 'Precision in Every Tonne.',
  },
  helix_meridian: {
    id: 'helix_meridian',
    name: 'Helix Meridian',
    sector: 'Biotechnology & Clinical Telemetry',
    accentHex: '#2dd4bf',
    secondaryHex: '#f4f1ea',
    politics:
      'Nobel-pedigree researchers fighting patent counsel over suppressed adverse-reaction registries.',
    puzzleStyle: 'Symbolic Genome Archives & Clinical Sigil Locks',
    motto: 'Life, Sequenced Responsibly.',
  },
  argent_cloud: {
    id: 'argent_cloud',
    name: 'Argent Cloud',
    sector: 'Sovereign Enterprise Computing',
    accentHex: '#818cf8',
    secondaryHex: '#38bdf8',
    politics:
      'Neutral Swiss-London custodianship masking quiet intelligence leasing to preferred conglomerates.',
    puzzleStyle: 'Multi-Layer Routing Diodes & Zero-Trust Identity Grids',
    motto: 'Silent Architecture, Absolute Continuity.',
  },
  northstar_consumer: {
    id: 'northstar_consumer',
    name: 'Northstar Consumer Group',
    sector: 'Global Retail & Dynamic Pricing',
    accentHex: '#fbbf24',
    secondaryHex: '#fb7185',
    politics:
      'Brand evangelists and supply-chain cost cutters hiding algorithmic price-gouging behind cheerful telemetry.',
    puzzleStyle: 'Decoy-Heavy Catalogues & Rapid Trace Thresholds',
    motto: 'Every Household, Every Morning.',
  },
  vesper_capital: {
    id: 'vesper_capital',
    name: 'Vesper Capital',
    sector: 'Fictional Clearinghouse & Bond Infrastructure',
    accentHex: '#e2b95b',
    secondaryHex: '#60a5fa',
    politics:
      'City of London clearing dynasties guarding synthetic liquidity ledgers from parliamentary auditors.',
    puzzleStyle: 'High-Precision Archive Transformations & Audit Seals',
    motto: 'Credit Endures Beyond Empires.',
  },
};

export const CORPORATION_LIST: CorporationDef[] = Object.values(CORPORATIONS);
