import {hashStringSeed} from './rng.ts';
import type {
  AccessibilitySettings,
  CorporationId,
  SaveFileV1,
  ToolId,
} from './types.ts';

export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

const PRIMARY_KEY = 'duke_satoshi_save_v1';
const BACKUP_KEY = 'duke_satoshi_save_v1_backup';

export const DEFAULT_ACCESSIBILITY: AccessibilitySettings = {
  postureMode: 'seated',
  uiDistance: 1.05,
  fontScale: 1.0,
  highContrast: false,
  pauseTimersOnMenu: true,
  arPassthrough: false,
  audioMuted: false,
};

export function createDefaultSave(): SaveFileV1 {
  const base: Omit<SaveFileV1, 'checksum'> = {
    version: 1,
    savedAt: new Date().toISOString(),
    cipherCredits: 450,
    reputation: {
      crownline_logistics: 0,
      helix_meridian: 0,
      argent_cloud: 0,
      northstar_consumer: 0,
      vesper_capital: 0,
    },
    toolUpgrades: {
      spectral_lens: 1,
      cipher_loom: 1,
      ghost_thread: 1,
      mirror_key: 1,
      cold_storage: 1,
    },
    equipmentCondition: {
      spectral_lens: 100,
      cipher_loom: 100,
      ghost_thread: 100,
      mirror_key: 100,
      cold_storage: 100,
    },
    completedContracts: {},
    narrativeFlags: [],
    accessibility: {...DEFAULT_ACCESSIBILITY},
  };
  return {
    ...base,
    checksum: computeSaveChecksum(base),
  };
}

export function computeSaveChecksum(
  data: Omit<SaveFileV1, 'checksum'>
): string {
  const canonical = JSON.stringify({
    version: data.version,
    cipherCredits: data.cipherCredits,
    reputation: data.reputation,
    toolUpgrades: data.toolUpgrades,
    equipmentCondition: data.equipmentCondition,
    completedContracts: data.completedContracts,
    narrativeFlags: [...data.narrativeFlags].sort(),
    accessibility: data.accessibility,
  });
  return hashStringSeed(canonical).toString(16).padStart(8, '0');
}

export function isValidSave(raw: unknown): raw is SaveFileV1 {
  if (!raw || typeof raw !== 'object') return false;
  const candidate = raw as Partial<SaveFileV1>;
  if (candidate.version !== 1) return false;
  if (typeof candidate.cipherCredits !== 'number') return false;
  if (typeof candidate.checksum !== 'string') return false;
  if (!candidate.reputation || !candidate.toolUpgrades) return false;
  const {checksum, ...rest} = candidate as SaveFileV1;
  return computeSaveChecksum(rest) === checksum;
}

function getDefaultStorage(): StorageLike | null {
  if (typeof globalThis !== 'undefined' && 'localStorage' in globalThis) {
    try {
      return globalThis.localStorage;
    } catch {
      return null;
    }
  }
  return null;
}

export class SaveManager {
  private storage: StorageLike | null;

  constructor(storage?: StorageLike | null) {
    this.storage = storage === undefined ? getDefaultStorage() : storage;
  }

  save(state: Omit<SaveFileV1, 'checksum' | 'savedAt'>): SaveFileV1 {
    const payloadWithoutChecksum: Omit<SaveFileV1, 'checksum'> = {
      ...state,
      version: 1,
      savedAt: new Date().toISOString(),
    };
    const full: SaveFileV1 = {
      ...payloadWithoutChecksum,
      checksum: computeSaveChecksum(payloadWithoutChecksum),
    };
    if (this.storage) {
      const existingPrimary = this.storage.getItem(PRIMARY_KEY);
      if (existingPrimary) {
        try {
          const parsed = JSON.parse(existingPrimary);
          if (isValidSave(parsed)) {
            this.storage.setItem(BACKUP_KEY, existingPrimary);
          }
        } catch {
          // Ignore corrupt primary when rotating backup
        }
      }
      this.storage.setItem(PRIMARY_KEY, JSON.stringify(full));
    }
    return full;
  }

  load(): {save: SaveFileV1; recoveredFromBackup: boolean} {
    if (!this.storage) {
      return {save: createDefaultSave(), recoveredFromBackup: false};
    }

    const primaryRaw = this.storage.getItem(PRIMARY_KEY);
    if (primaryRaw) {
      try {
        const parsed = JSON.parse(primaryRaw);
        if (isValidSave(parsed)) {
          return {
            save: this.normalizeSave(parsed),
            recoveredFromBackup: false,
          };
        }
      } catch {
        // Fall through to backup recovery
      }
    }

    const backupRaw = this.storage.getItem(BACKUP_KEY);
    if (backupRaw) {
      try {
        const parsed = JSON.parse(backupRaw);
        if (isValidSave(parsed)) {
          const normalized = this.normalizeSave(parsed);
          this.storage.setItem(PRIMARY_KEY, JSON.stringify(normalized));
          return {save: normalized, recoveredFromBackup: true};
        }
      } catch {
        // Fall through to clean default
      }
    }

    const fresh = createDefaultSave();
    this.storage.setItem(PRIMARY_KEY, JSON.stringify(fresh));
    return {save: fresh, recoveredFromBackup: false};
  }

  reset(): SaveFileV1 {
    const fresh = createDefaultSave();
    if (this.storage) {
      this.storage.removeItem(PRIMARY_KEY);
      this.storage.removeItem(BACKUP_KEY);
      this.storage.setItem(PRIMARY_KEY, JSON.stringify(fresh));
    }
    return fresh;
  }

  private normalizeSave(save: SaveFileV1): SaveFileV1 {
    const defaults = createDefaultSave();
    const reputation: Record<CorporationId, number> = {
      ...defaults.reputation,
      ...save.reputation,
    };
    const toolUpgrades: Record<ToolId, number> = {
      ...defaults.toolUpgrades,
      ...save.toolUpgrades,
    };
    const equipmentCondition: Record<ToolId, number> = {
      ...defaults.equipmentCondition,
      ...save.equipmentCondition,
    };
    const accessibility: AccessibilitySettings = {
      ...defaults.accessibility,
      ...save.accessibility,
    };
    return {
      ...save,
      reputation,
      toolUpgrades,
      equipmentCondition,
      accessibility,
    };
  }
}
