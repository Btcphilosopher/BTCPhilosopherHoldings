import {CORPORATIONS} from './corporations.ts';
import {getContractById} from './missions.ts';
import {getNextOptimalArchiveOp} from './puzzles.ts';
import type {
  HandlerDialoguePayload,
  HintTier,
  MissionRunState,
  NetworkNodeRuntime,
  PuzzleState,
} from './types.ts';

function buildPuzzleSummary(node: NetworkNodeRuntime): string {
  const puzzle: PuzzleState | undefined = node.puzzle;
  if (!puzzle) return node.description;

  if (puzzle.kind === 'signal_routing') {
    const chSummary = puzzle.channels
      .map(
        (c) =>
          `${c.colorName}: start (${c.start[0]},${c.start[1]}) -> sink (${c.end[0]},${c.end[1]}), solution ${c.solutionPath.map((p) => `(${p[0]},${p[1]})`).join('->')}`
      )
      .join(' | ');
    const gate = puzzle.directionalGates[0];
    return `Signal Routing ${puzzle.gridSize}x${puzzle.gridSize}. ${chSummary}. Diode at (${gate.pos[0]},${gate.pos[1]}) must exit ${gate.label}.`;
  }

  if (puzzle.kind === 'identity_reconstruction') {
    const slots = puzzle.slots
      .map(
        (s) =>
          `${s.slotName}: correct="${s.correctOption}" (${s.revealedByDefault ? 'clue found' : 'clue hidden'})`
      )
      .join(' | ');
    return `Identity Reconstruction for ${puzzle.subjectName}. ${slots}`;
  }

  const nextOp = getNextOptimalArchiveOp(puzzle);
  return `Archive Decoding ring [${puzzle.currentRing.map((i) => puzzle.glyphLabels[i]).join(', ')}] aiming for [A-CROWN, B-CYAN, C-GOLD, D-SEAL]. Next optimal op: ${nextOp ?? 'solved'}.`;
}

export function getScriptedBriefing(
  contractId: string,
  narrativeFlags: string[]
): HandlerDialoguePayload {
  const contract = getContractById(contractId);
  const corp = CORPORATIONS[contract.corporationId];

  let continuityNote = '';
  if (narrativeFlags.includes('meridian_exposed_public')) {
    continuityNote =
      ' Parliament is still citing your Meridian disclosure—expect tighter audit sweeps.';
  } else if (narrativeFlags.includes('meridian_internal_audit')) {
    continuityNote =
      ' Your quiet handling of the Meridian board earned discreet City referrals.';
  } else if (narrativeFlags.includes('meridian_brokered_quietly')) {
    continuityNote =
      ' Word of your Cold Vault auction reached Threadneedle; fees are high, trust is brisk.';
  }

  return {
    speaker: 'Giles (Handler)',
    line: `${contract.title} — ${corp.name}. ${contract.briefingLead}${continuityNote}`,
    quip: 'Tea is steeping, Your Grace. Choose your three modules with taste.',
    source: 'scripted',
  };
}

export function getScriptedHint(
  run: MissionRunState,
  tier: HintTier
): HandlerDialoguePayload {
  const node = run.nodes[run.activeNodeId];
  const puzzle = node?.puzzle;

  if (!puzzle) {
    if (node.type === 'monitoring_node') {
      return {
        speaker: 'Giles (Handler)',
        line:
          tier === 1
            ? 'Monitoring sentinels log loud traversals. Consider concealing your next route.'
            : 'Use Ghost Thread before stepping onward, or proceed directly to the adjacent Identity Seal.',
        quip: 'Silence is the sharpest tailoring in cyberspace.',
        source: 'scripted',
      };
    }
    return {
      speaker: 'Giles (Handler)',
      line:
        tier === 1
          ? 'Inspect adjacent glowing nodes on the spatial table to advance.'
          : 'Select an adjacent unlocked node (Silent Ledger left, Dispatch Core right) to progress toward the primary vault.',
      source: 'scripted',
    };
  }

  if (puzzle.kind === 'signal_routing') {
    const gate = puzzle.directionalGates[0];
    if (tier === 1) {
      return {
        speaker: 'Giles (Handler)',
        line: 'Nudge: Notice the directional diode tile and avoid blocked amber barriers.',
        quip: 'Channels never share a square—good manners in freight routing.',
        source: 'scripted',
      };
    }
    if (tier === 2) {
      return {
        speaker: 'Giles (Handler)',
        line: `Explanation: Route each coloured channel orthogonally from Start to Sink without crossing. The diode at (${gate.pos[0]},${gate.pos[1]}) forces an exit ${gate.label}.`,
        source: 'scripted',
      };
    }
    const sol = puzzle.channels
      .map(
        (c) =>
          `${c.colorName}: ${c.solutionPath.map((p) => `${p[0]},${p[1]}`).join(' → ')}`
      )
      .join(' | ');
    return {
      speaker: 'Giles (Handler)',
      line: `Solution Assist: ${sol}.`,
      quip: 'Or weave Cipher Loom to lock one channel instantly.',
      source: 'scripted',
    };
  }

  if (puzzle.kind === 'identity_reconstruction') {
    if (tier === 1) {
      return {
        speaker: 'Giles (Handler)',
        line: 'Nudge: Check your collected Evidence & Clues panel—two slots are logged at Gateway, two deeper on the grid.',
        source: 'scripted',
      };
    }
    if (tier === 2) {
      return {
        speaker: 'Giles (Handler)',
        line: 'Explanation: Match each slot to its verified berth/audit clue. Spectral Lens reveals missing clues remotely if you skipped the sentinel.',
        source: 'scripted',
      };
    }
    const answers = puzzle.slots
      .map((s) => `${s.slotName}: ${s.correctOption}`)
      .join(' · ');
    return {
      speaker: 'Giles (Handler)',
      line: `Solution Assist: ${answers}.`,
      source: 'scripted',
    };
  }

  // Archive decoding
  const nextOp = getNextOptimalArchiveOp(puzzle);
  if (tier === 1) {
    return {
      speaker: 'Giles (Handler)',
      line: 'Nudge: Align A-CROWN first, then use Flip Polarity or Shift Ring to pair B-CYAN and C-GOLD.',
      source: 'scripted',
    };
  }
  if (tier === 2) {
    return {
      speaker: 'Giles (Handler)',
      line: `Explanation: Target order is [A-CROWN, B-CYAN, C-GOLD, D-SEAL]. Rotate shifts right by 1; Flip swaps adjacent pairs; Shift swaps indices 0 & 2. Par is ${puzzle.parMoves} moves.`,
      source: 'scripted',
    };
  }
  return {
    speaker: 'Giles (Handler)',
    line: `Solution Assist: Recommended next operation is ${nextOp ? nextOp.replace('_', ' ') : 'already aligned'}.`,
    source: 'scripted',
  };
}

export class HandlerDialogueService {
  private fetchImpl: typeof fetch | null;

  constructor(fetchImpl?: typeof fetch | null) {
    this.fetchImpl =
      fetchImpl !== undefined
        ? fetchImpl
        : typeof globalThis.fetch === 'function'
          ? globalThis.fetch.bind(globalThis)
          : null;
  }

  async fetchBriefing(
    contractId: string,
    narrativeFlags: string[]
  ): Promise<HandlerDialoguePayload> {
    const scripted = getScriptedBriefing(contractId, narrativeFlags);
    if (!this.fetchImpl) return scripted;

    const contract = getContractById(contractId);
    const corp = CORPORATIONS[contract.corporationId];

    try {
      const res = await this.fetchImpl('/api/handler', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          mode: 'briefing',
          missionTitle: contract.title,
          corporationName: corp.name,
          puzzleSummary: `${contract.briefingLead} ${narrativeFlags.join(', ')}`,
        }),
      });
      if (!res.ok) return scripted;
      const data = (await res.json()) as {
        ok?: boolean;
        fallback?: boolean;
        speaker?: string;
        line?: string;
        quip?: string;
      };
      if (data.ok && !data.fallback && data.line) {
        return {
          speaker: data.speaker || 'Giles (Handler)',
          line: data.line,
          quip: data.quip || scripted.quip,
          source: 'gemini-4.0',
        };
      }
    } catch {
      // Seamless offline fallback
    }
    return scripted;
  }

  async fetchHint(
    run: MissionRunState,
    tier: HintTier
  ): Promise<HandlerDialoguePayload> {
    const scripted = getScriptedHint(run, tier);
    if (!this.fetchImpl) return scripted;

    const contract = getContractById(run.contractId);
    const corp = CORPORATIONS[contract.corporationId];
    const node = run.nodes[run.activeNodeId];

    try {
      const res = await this.fetchImpl('/api/handler', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          mode: 'hint',
          hintTier: tier,
          missionTitle: contract.title,
          corporationName: corp.name,
          nodeLabel: node.label,
          puzzleType: node.puzzle?.kind ?? node.type,
          puzzleSummary: buildPuzzleSummary(node),
          tracePercent: run.tracePressure,
        }),
      });
      if (!res.ok) return scripted;
      const data = (await res.json()) as {
        ok?: boolean;
        fallback?: boolean;
        speaker?: string;
        line?: string;
        quip?: string;
      };
      if (data.ok && !data.fallback && data.line) {
        return {
          speaker: data.speaker || 'Giles (Handler)',
          line: data.line,
          quip: data.quip || scripted.quip,
          source: 'gemini-4.0',
        };
      }
    } catch {
      // Seamless offline fallback
    }
    return scripted;
  }
}
