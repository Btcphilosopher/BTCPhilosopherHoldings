import type {ToolDef, ToolId} from './types.ts';

export const TOOLS: Record<ToolId, ToolDef> = {
  spectral_lens: {
    id: 'spectral_lens',
    name: 'Spectral Lens',
    shortLabel: 'Spectral Lens',
    tagline:
      'Reveals hidden node shortcuts, decoy signatures, and obscured identity clues.',
    computeCost: 1,
    baseCharges: 2,
    traceDelta: 4,
    tradeoff:
      'Zero combat utility; modest compute + trace ping, but exposes safer routes and traps.',
    upgradeCost: 220,
    upgradeDescription:
      '+1 charge and cuts inspection trace noise in half at Lv.2+.',
  },
  cipher_loom: {
    id: 'cipher_loom',
    name: 'Cipher Loom',
    shortLabel: 'Cipher Loom',
    tagline:
      'Applies one guaranteed symbolic step or reveals one hidden identity slot.',
    computeCost: 2,
    baseCharges: 2,
    traceDelta: 6,
    tradeoff:
      'Consumes 2 Compute per weave; saves precious turns on complex archives.',
    upgradeCost: 260,
    upgradeDescription: '+1 charge and reduces Compute cost by 1 at Lv.2+.',
  },
  ghost_thread: {
    id: 'ghost_thread',
    name: 'Ghost Thread',
    shortLabel: 'Ghost Thread',
    tagline:
      'Conceals the current node route, scrubbing 14% Trace Pressure and masking next entry.',
    computeCost: 2,
    baseCharges: 2,
    traceDelta: -14,
    tradeoff:
      'Must be budgeted carefully; occupies a loadout slot instead of decoding power.',
    upgradeCost: 240,
    upgradeDescription:
      'Scrubs an additional 6% Trace Pressure per weave at Lv.2+.',
  },
  mirror_key: {
    id: 'mirror_key',
    name: 'Mirror Key',
    shortLabel: 'Mirror Key',
    tagline:
      'Bypasses compatible fictional identity or routing locks cleanly without solving.',
    computeCost: 3,
    baseCharges: 1,
    traceDelta: 9,
    tradeoff:
      'Only 1 base charge and high Compute cost; leaves a slight forensic shimmer (+9% trace).',
    upgradeCost: 300,
    upgradeDescription: '+1 charge and lowers Compute cost from 3 to 2 at Lv.2+.',
  },
  cold_storage: {
    id: 'cold_storage',
    name: 'Cold Storage',
    shortLabel: 'Cold Storage',
    tagline:
      'Shields one carried evidence packet from forced-extraction loss and adds +1 capacity.',
    computeCost: 1,
    baseCharges: 2,
    traceDelta: 2,
    tradeoff:
      'Passive insurance; contributes nothing to unlocking vaults or suppressing trace.',
    upgradeCost: 200,
    upgradeDescription:
      '+1 extraction capacity passively while equipped in loadout at Lv.2+.',
  },
};

export const TOOL_LIST: ToolDef[] = Object.values(TOOLS);
