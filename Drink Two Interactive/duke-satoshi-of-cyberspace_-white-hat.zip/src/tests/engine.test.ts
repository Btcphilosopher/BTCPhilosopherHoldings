import {describe, expect, it} from 'vitest';
import {
  HandlerDialogueService,
  getScriptedBriefing,
  getScriptedHint,
} from '../engine/aiHandler.ts';
import {CORPORATION_LIST} from '../engine/corporations.ts';
import {GameEngine} from '../engine/gameState.ts';
import {
  generateArchivePuzzle,
  generateIdentityPuzzle,
  generateSignalRoutingPuzzle,
  stepArchivePuzzle,
  stepSignalChannel,
  validateArchivePuzzle,
  validateIdentityPuzzle,
  validateSignalRouting,
} from '../engine/puzzles.ts';
import {SaveManager, type StorageLike} from '../engine/saveSystem.ts';

function createMemoryStorage(): StorageLike {
  const map = new Map<string, string>();
  return {
    getItem: (key) => map.get(key) ?? null,
    setItem: (key, value) => {
      map.set(key, value);
    },
    removeItem: (key) => {
      map.delete(key);
    },
  };
}

describe('Duke Satoshi of Cyberspace — Puzzle Generators & Validators', () => {
  it('generates and validates 2-channel and 3-channel Signal Routing puzzles across seeds', () => {
    for (const channels of [2, 3] as const) {
      for (let seed = 1000; seed < 1015; seed++) {
        const puzzle = generateSignalRoutingPuzzle(seed, channels);
        expect(puzzle.channels).toHaveLength(channels);
        expect(validateSignalRouting(puzzle).valid).toBe(false);

        for (const ch of puzzle.channels) {
          for (let i = 1; i < ch.solutionPath.length; i++) {
            const [r, c] = ch.solutionPath[i];
            const res = stepSignalChannel(puzzle, ch.id, [r, c]);
            expect(res.updated).toBe(true);
          }
        }
        expect(validateSignalRouting(puzzle).valid).toBe(true);
        expect(puzzle.solved).toBe(true);
      }
    }
  });

  it('enforces interference barriers and directional diode constraints on Signal Routing', () => {
    const puzzle = generateSignalRoutingPuzzle(4242, 2);
    const blocked = puzzle.blockedCells[0];
    const blockedRes = stepSignalChannel(puzzle, puzzle.channels[0].id, blocked);
    expect(blockedRes.updated).toBe(false);

    // Route up to the directional gate and try exiting sideways
    const gate = puzzle.directionalGates[0];
    const ch0 = puzzle.channels[0];
    const gateIdx = ch0.solutionPath.findIndex(
      ([r, c]) => r === gate.pos[0] && c === gate.pos[1]
    );
    for (let i = 1; i <= gateIdx; i++) {
      stepSignalChannel(puzzle, ch0.id, ch0.solutionPath[i]);
    }
    const wrongR = gate.pos[0] + (gate.dir[0] === 0 ? 1 : 0);
    const wrongC = gate.pos[1] + (gate.dir[1] === 0 ? 1 : 0);
    if (wrongR >= 0 && wrongR < 4 && wrongC >= 0 && wrongC < 4) {
      const wrongStep = stepSignalChannel(puzzle, ch0.id, [wrongR, wrongC]);
      // Either wrong diode direction or blocked/occupied -> must not advance validly past diode
      if (
        wrongStep.updated &&
        !puzzle.blockedCells.some(([r, c]) => r === wrongR && c === wrongC)
      ) {
        expect(validateSignalRouting(puzzle).valid).toBe(false);
      }
    }
  });

  it('generates and validates Identity Reconstruction puzzles across all corporations', () => {
    for (let tmpl = 0; tmpl < 3; tmpl++) {
      const puzzle = generateIdentityPuzzle(5050 + tmpl, tmpl);
      expect(puzzle.slots).toHaveLength(4);
      puzzle.slots.forEach((slot, idx) => {
        puzzle.selectedOptions[idx] = slot.correctOption;
      });
      expect(validateIdentityPuzzle(puzzle)).toBe(true);
    }
  });

  it('generates solvable Archive Decoding puzzles with BFS shortest solution', () => {
    for (let seed = 200; seed < 220; seed++) {
      const puzzle = generateArchivePuzzle(seed);
      expect(puzzle.solutionOps.length).toBeGreaterThan(0);
      expect(validateArchivePuzzle(puzzle)).toBe(false);
      for (const op of puzzle.solutionOps) {
        stepArchivePuzzle(puzzle, op);
      }
      expect(validateArchivePuzzle(puzzle)).toBe(true);
      expect(puzzle.solved).toBe(true);
    }
  });

  it('defines all five original fictional corporations', () => {
    expect(CORPORATION_LIST.map((c) => c.id)).toEqual([
      'crownline_logistics',
      'helix_meridian',
      'argent_cloud',
      'northstar_consumer',
      'vesper_capital',
    ]);
  });
});

describe('The Meridian Ledger — Full Mission Progression, Tools, Trace & Economy', () => {
  it('completes Silent Ledger route end-to-end with evidence, trust choice, and idempotent reward', () => {
    const storage = createMemoryStorage();
    const engine = new GameEngine(new SaveManager(storage));
    const startingCredits = engine.getSave().cipherCredits;

    engine.selectContract('meridian_ledger');
    engine.goToLoadout();
    const run = engine.startMission(104729);
    expect(run.activeNodeId).toBe('gw_thames');

    // Spectral Lens reveals hidden shortcut + decoy + clue
    expect(engine.useTool('spectral_lens')).toBe(true);
    expect(run.nodes.junc_berth.hiddenRevealed).toBe(true);
    expect(run.nodes.decoy_manifest.inspected).toBe(true);

    // Move to Silent Ledger Junction & solve Signal Routing
    expect(engine.moveToNode('junc_berth')).toBe(true);
    const sigPuzzle = run.nodes.junc_berth.puzzle!;
    expect(sigPuzzle.kind).toBe('signal_routing');
    if (sigPuzzle.kind === 'signal_routing') {
      for (const ch of sigPuzzle.channels) {
        engine.activeChannelId = ch.id;
        for (let i = 1; i < ch.solutionPath.length; i++) {
          engine.stepActiveSignalCell(ch.solutionPath[i][0], ch.solutionPath[i][1]);
        }
      }
    }
    expect(run.nodes.junc_berth.completed).toBe(true);

    // Use Ghost Thread before entering Identity Seal & collect hidden evidence shortcut
    expect(engine.useTool('ghost_thread')).toBe(true);
    expect(engine.moveToNode('cache_evidence')).toBe(true);
    expect(run.carriedEvidenceIds).toContain('ev_weighbridge');

    expect(engine.moveToNode('id_steward')).toBe(true);
    const idPuzzle = run.nodes.id_steward.puzzle!;
    if (idPuzzle.kind === 'identity_reconstruction') {
      idPuzzle.slots.forEach((slot, idx) => {
        engine.selectIdentityOption(idx, slot.correctOption);
      });
    }
    expect(run.nodes.id_steward.completed).toBe(true);

    // Enter primary vault and decode Archive ring
    expect(engine.moveToNode('vault_meridian')).toBe(true);
    const vaultPuzzle = run.nodes.vault_meridian.puzzle!;
    if (vaultPuzzle.kind === 'archive_decoding') {
      for (const op of vaultPuzzle.solutionOps) {
        engine.applyActiveArchiveOp(op);
      }
    }
    expect(run.nodes.vault_meridian.completed).toBe(true);
    expect(run.carriedEvidenceIds).toContain('ev_meridian_master');

    // Select Trust Choice and extract
    expect(engine.selectTrustChoice('whistleblower_clara')).toBe(true);
    expect(engine.moveToNode('extract_beacon')).toBe(true);
    const debrief1 = engine.extractMission(false);
    expect(debrief1).not.toBeNull();
    const afterFirstCredits = engine.getSave().cipherCredits;
    expect(afterFirstCredits).toBe(startingCredits + debrief1!.netCredits);

    // Idempotency: calling extractMission a second time must never duplicate credits
    const debrief2 = engine.extractMission(false);
    expect(debrief2).toEqual(debrief1);
    expect(engine.getSave().cipherCredits).toBe(afterFirstCredits);

    // Follow-up contracts unlock after Meridian Ledger completion
    const available = engine.getAvailableContracts();
    expect(available.every((c) => c.unlocked)).toBe(true);
  });

  it('supports Dispatch Core alternative route + Mirror Key bypass + Cold Storage preservation', () => {
    const engine = new GameEngine(new SaveManager(createMemoryStorage()));
    engine.draftLoadout = ['mirror_key', 'cipher_loom', 'cold_storage'];
    const run = engine.startMission(104729);

    expect(engine.moveToNode('arch_dispatch')).toBe(true);
    const archPuzzle = run.nodes.arch_dispatch.puzzle!;
    if (archPuzzle.kind === 'archive_decoding') {
      for (const op of archPuzzle.solutionOps) {
        engine.applyActiveArchiveOp(op);
      }
    }
    expect(run.nodes.arch_dispatch.completed).toBe(true);

    // Grab optional cache and seal in Cold Storage
    expect(engine.moveToNode('cache_evidence')).toBe(true);
    expect(engine.useTool('cold_storage')).toBe(true);
    expect(run.preservedEvidenceIds).toContain('ev_weighbridge');

    // Use Mirror Key to bypass Meridian Ledger Core directly
    expect(engine.moveToNode('vault_meridian')).toBe(true);
    expect(engine.useTool('mirror_key')).toBe(true);
    expect(run.nodes.vault_meridian.completed).toBe(true);
  });

  it('triggers recoverable Trace consequences at thresholds and respects Cold Storage on forced extraction', () => {
    const engine = new GameEngine(new SaveManager(createMemoryStorage()));
    engine.draftLoadout = ['cipher_loom', 'ghost_thread', 'cold_storage'];
    const run = engine.startMission(104729);

    // Solve Dispatch Core so we can collect optional evidence and seal it in Cold Storage
    engine.moveToNode('arch_dispatch');
    const arch = run.nodes.arch_dispatch.puzzle!;
    if (arch.kind === 'archive_decoding') {
      arch.solutionOps.forEach((op) => engine.applyActiveArchiveOp(op));
    }
    engine.moveToNode('cache_evidence');
    engine.useTool('cold_storage');

    // Trigger decoy trap + repeated noisy actions to reach Trace consequences
    engine.moveToNode('decoy_manifest');
    expect(run.tracePressure).toBeGreaterThanOrEqual(35);

    // Push past 75% and then 100% via repeated tool activations on an active puzzle
    engine.moveToNode('junc_berth');
    while (!run.extracted && run.toolCharges.cipher_loom > 0) {
      engine.useTool('cipher_loom');
    }
    // Check at least warning or forced extraction logic functions cleanly
    if (!run.extracted) {
      // Trigger remaining trace by inspecting monitoring node
      engine.moveToNode('mon_customs');
    }

    // Even if forced extraction occurs at 100%, debrief is produced safely and Cold Storage item stays carried
    if (run.extracted) {
      expect(run.forcedExtraction).toBe(true);
      expect(run.debrief?.tracePenalty).toBeGreaterThan(0);
      expect(run.carriedEvidenceIds).toContain('ev_weighbridge');
    } else {
      // Otherwise verify clean extraction works
      const debrief = engine.extractMission(false);
      expect(debrief).not.toBeNull();
    }
  });

  it('tracks reputation differences across endings and workshop upgrades/repairs', () => {
    const engine = new GameEngine(new SaveManager(createMemoryStorage()));
    engine.startMission(104729);
    engine.moveToNode('arch_dispatch');
    const arch = engine.activeRun!.nodes.arch_dispatch.puzzle!;
    if (arch.kind === 'archive_decoding') {
      arch.solutionOps.forEach((op) => engine.applyActiveArchiveOp(op));
    }
    engine.moveToNode('vault_meridian');
    const vault = engine.activeRun!.nodes.vault_meridian.puzzle!;
    if (vault.kind === 'archive_decoding') {
      vault.solutionOps.forEach((op) => engine.applyActiveArchiveOp(op));
    }
    engine.selectTrustChoice('private_broker');
    engine.extractMission(false);

    expect(engine.getSave().reputation.vesper_capital).toBe(20);
    expect(engine.getSave().reputation.crownline_logistics).toBe(-25);

    // Upgrade a tool and repair worn equipment
    const creditsBeforeUpgrade = engine.getSave().cipherCredits;
    expect(engine.upgradeTool('spectral_lens')).toBe(true);
    expect(engine.getSave().toolUpgrades.spectral_lens).toBe(2);
    expect(engine.getSave().cipherCredits).toBeLessThan(creditsBeforeUpgrade);

    expect(engine.repairTool('spectral_lens')).toBe(true);
    expect(engine.getSave().equipmentCondition.spectral_lens).toBe(100);
  });
});

describe('Save Persistence, Backup Recovery, Accessibility & Offline AI Handler Fallback', () => {
  it('recovers automatically from backup when primary save is corrupted', () => {
    const storage = createMemoryStorage();
    const mgr1 = new SaveManager(storage);
    const initial = mgr1.load().save;
    mgr1.save({...initial, cipherCredits: 1200});
    mgr1.save({...initial, cipherCredits: 1850});

    // Corrupt primary save JSON
    storage.setItem('duke_satoshi_save_v1', '{CORRUPTED_JSON');

    const mgr2 = new SaveManager(storage);
    const recovered = mgr2.load();
    expect(recovered.recoveredFromBackup).toBe(true);
    expect(recovered.save.cipherCredits).toBe(1200);
  });

  it('persists accessibility settings across reloads', () => {
    const storage = createMemoryStorage();
    const engine1 = new GameEngine(new SaveManager(storage));
    engine1.updateAccessibility({
      postureMode: 'standing',
      uiDistance: 1.35,
      fontScale: 1.2,
      highContrast: true,
      arPassthrough: true,
      audioMuted: true,
    });

    const engine2 = new GameEngine(new SaveManager(storage));
    expect(engine2.getAccessibility()).toEqual({
      postureMode: 'standing',
      uiDistance: 1.35,
      fontScale: 1.2,
      highContrast: true,
      pauseTimersOnMenu: true,
      arPassthrough: true,
      audioMuted: true,
    });
  });

  it('falls back seamlessly to dry-wit scripted briefings and 3-tier hints offline', async () => {
    const failingFetch = (async () => {
      throw new Error('Network offline');
    }) as unknown as typeof fetch;

    const handler = new HandlerDialogueService(failingFetch);
    const briefing = await handler.fetchBriefing('meridian_ledger', [
      'meridian_exposed_public',
    ]);
    expect(briefing.source).toBe('scripted');
    expect(briefing.line.length).toBeGreaterThan(20);

    const engine = new GameEngine(new SaveManager(createMemoryStorage()));
    const run = engine.startMission(104729);
    engine.moveToNode('junc_berth');

    const h1 = await handler.fetchHint(run, 1);
    const h2 = await handler.fetchHint(run, 2);
    const h3 = await handler.fetchHint(run, 3);

    expect(h1.source).toBe('scripted');
    expect(h2.line).toContain('Explanation');
    expect(h3.line).toContain('Solution Assist');
    expect(getScriptedBriefing('meridian_ledger', []).speaker).toContain('Giles');
    expect(getScriptedHint(run, 1).line.length).toBeGreaterThan(10);
  });
});
