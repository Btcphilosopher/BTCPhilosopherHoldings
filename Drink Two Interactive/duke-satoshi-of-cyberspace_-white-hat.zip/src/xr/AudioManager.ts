/**
 * Procedural Web Audio synthesizer for Duke Satoshi's Anglo-futurist soundscape:
 * subtle London rain texture, understated electronic-orchestral pad, and tactile UI chimes.
 */
export class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private rainNode: AudioBufferSourceNode | null = null;
  private padOsc1: OscillatorNode | null = null;
  private padOsc2: OscillatorNode | null = null;
  private muted = false;
  private started = false;

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        muted ? 0 : 0.25,
        this.ctx.currentTime,
        0.08
      );
    }
  }

  unlockAndStart() {
    if (this.started || typeof window === 'undefined') return;
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as {webkitAudioContext?: typeof AudioContext})
        .webkitAudioContext;
    if (!AudioCtx) return;

    try {
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : 0.25;
      this.masterGain.connect(this.ctx.destination);

      // Subtle filtered rain noise outside the study window
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(
        1,
        bufferSize,
        this.ctx.sampleRate
      );
      const data = noiseBuffer.getChannelData(0);
      let lastOut = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        data[i] = (lastOut + 0.03 * white) / 1.03;
        lastOut = data[i];
      }
      const rainSource = this.ctx.createBufferSource();
      rainSource.buffer = noiseBuffer;
      rainSource.loop = true;

      const rainFilter = this.ctx.createBiquadFilter();
      rainFilter.type = 'bandpass';
      rainFilter.frequency.value = 900;
      rainFilter.Q.value = 0.7;

      const rainGain = this.ctx.createGain();
      rainGain.gain.value = 0.14;
      rainSource.connect(rainFilter);
      rainFilter.connect(rainGain);
      rainGain.connect(this.masterGain);
      rainSource.start();
      this.rainNode = rainSource;

      // Understated D-minor cyber-noir drone pad
      const padGain = this.ctx.createGain();
      padGain.gain.value = 0.045;
      const padFilter = this.ctx.createBiquadFilter();
      padFilter.type = 'lowpass';
      padFilter.frequency.value = 320;
      padFilter.connect(padGain);
      padGain.connect(this.masterGain);

      const osc1 = this.ctx.createOscillator();
      osc1.type = 'triangle';
      osc1.frequency.value = 73.42; // D2
      osc1.connect(padFilter);
      osc1.start();
      this.padOsc1 = osc1;

      const osc2 = this.ctx.createOscillator();
      osc2.type = 'sine';
      osc2.frequency.value = 110.0; // A2
      osc2.connect(padFilter);
      osc2.start();
      this.padOsc2 = osc2;

      this.started = true;
    } catch {
      // AudioContext blocked or unavailable
    }
  }

  playClick() {
    this.playTone(620, 0.045, 'triangle', 0.12);
  }

  playNodeEnter() {
    this.playTone(440, 0.09, 'sine', 0.14);
    setTimeout(() => this.playTone(659.25, 0.12, 'triangle', 0.12), 55);
  }

  playPuzzleSolved() {
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
      setTimeout(() => this.playTone(freq, 0.18, 'sine', 0.14), idx * 70);
    });
  }

  playTraceAlert() {
    this.playTone(233.08, 0.16, 'sawtooth', 0.08);
    setTimeout(() => this.playTone(196.0, 0.2, 'sawtooth', 0.08), 140);
  }

  private playTone(
    freq: number,
    durationSec: number,
    type: OscillatorType,
    volume: number
  ) {
    if (this.muted || !this.ctx || !this.masterGain) return;
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + durationSec + 0.02);
  }

  dispose() {
    try {
      this.rainNode?.stop();
      this.padOsc1?.stop();
      this.padOsc2?.stop();
      void this.ctx?.close();
    } catch {
      // ignore
    }
    this.started = false;
  }
}
