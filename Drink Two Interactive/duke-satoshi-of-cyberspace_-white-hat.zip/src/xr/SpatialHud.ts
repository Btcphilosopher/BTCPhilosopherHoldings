import * as xb from 'xrblocks';
import {CORPORATIONS} from '../engine/corporations.ts';
import type {GameEngine} from '../engine/gameState.ts';
import {getContractById} from '../engine/missions.ts';
import {TOOL_LIST, TOOLS} from '../engine/tools.ts';
import type {
  AccessibilitySettings,
  HandlerDialoguePayload,
  HintTier,
  ToolId,
} from '../engine/types.ts';

export type StudyStation = 'table' | 'desk' | 'evidence' | 'cabinet';

export interface SpatialHudCallbacks {
  onSelectContract: (id: string) => void;
  onGoToLoadout: () => void;
  onGoToBriefing: () => void;
  onGoToWorkshop: () => void;
  onToggleTool: (id: ToolId) => void;
  onStartMission: () => void;
  onUseTool: (id: ToolId) => void;
  onSelectTrustChoice: (choiceId: string) => void;
  onExtract: () => void;
  onReturnToStudy: () => void;
  onUpgradeTool: (id: ToolId) => void;
  onRepairTool: (id: ToolId) => void;
  onRequestHint: (tier: HintTier) => void;
  onTeleportStation: (station: StudyStation) => void;
  onUpdateAccessibility: (partial: Partial<AccessibilitySettings>) => void;
  onResetSave: () => void;
  onToggleComfortMenu: (open: boolean) => void;
}

/**
 * Manages the legible world-space UICards (Operations Console + Handler & Evidence Console)
 * and the view-space Comfort & Navigation UIOverlay.
 */
export class SpatialHud extends xb.Script {
  private engine: GameEngine;
  private callbacks: SpatialHudCallbacks;

  private opsCard: xb.UICard;
  private opsTitle: xb.UIText;
  private opsHeaderMeta: xb.UIText;
  private opsBody: xb.UIPanel;
  private opsStatus: xb.UIText;

  private handlerCard: xb.UICard;
  private handlerSpeaker: xb.UIText;
  private handlerLine: xb.UIText;
  private handlerQuip: xb.UIText;
  private cluesBody: xb.UIPanel;
  private hintRow: xb.UIPanel;

  private comfortOverlay: xb.UIOverlay;
  private comfortDrawer: xb.UIPanel;
  private comfortToggleBtn: xb.UIButton;
  private comfortOpen = false;
  private confirmReset = false;

  private lastOpsKey = '';
  private lastHandlerKey = '';
  private lastComfortKey = '';
  private currentDialogue: HandlerDialoguePayload = {
    speaker: 'Giles (Handler)',
    line: 'Good evening, Your Grace. Crownline Logistics’ berth telemetry awaits inspection.',
    quip: 'Tea is steeping in the study.',
    source: 'scripted',
  };

  constructor(engine: GameEngine, callbacks: SpatialHudCallbacks) {
    super();
    this.engine = engine;
    this.callbacks = callbacks;

    // 1. Left Operations Card (Briefing / Loadout / Active Node / Debrief / Workshop)
    this.opsTitle = new xb.UIText({
      text: 'DUKE SATOSHI // WHITE HAT',
      style: {fontSize: 22, fontWeight: 'bold', color: '#f8fafc'},
    });
    this.opsHeaderMeta = new xb.UIText({
      text: 'Cipher Credits: 450 CC',
      style: {fontSize: 15, fontWeight: 'bold', color: '#eab308'},
    });
    this.opsBody = new xb.UIPanel({
      style: {width: '100%', flexDirection: 'column', gap: 8},
    });
    this.opsStatus = new xb.UIText({
      text: '',
      style: {fontSize: 14, lineHeight: 1.3, color: '#7dd3fc'},
    });

    this.opsCard = new xb.UICard({
      size: {width: 0.62, height: 'auto'},
      manipulation: true,
      edge: true,
      style: {
        flexDirection: 'column',
        gap: 10,
        padding: 18,
        backgroundColor: 'rgba(10, 17, 31, 0.93)',
        borderColor: 'rgba(56, 189, 248, 0.45)',
        borderWidth: 1.5,
      },
      children: [
        this.opsTitle,
        this.opsHeaderMeta,
        this.opsBody,
        this.opsStatus,
      ],
    });
    this.opsCard.position.set(-1.06, 1.38, -1.0);
    this.opsCard.rotation.y = 0.48;
    this.add(this.opsCard);

    // 2. Right Handler & Clues Card
    this.handlerSpeaker = new xb.UIText({
      text: 'GILES (HANDLER · SCRIPTED)',
      style: {fontSize: 18, fontWeight: 'bold', color: '#eab308'},
    });
    this.handlerLine = new xb.UIText({
      text: this.currentDialogue.line,
      style: {
        fontSize: 15,
        lineHeight: 1.35,
        color: '#f1f5f9',
        whiteSpace: 'pre-line',
      },
    });
    this.handlerQuip = new xb.UIText({
      text: this.currentDialogue.quip ?? '',
      style: {fontSize: 13, color: '#94a3b8'},
    });
    this.hintRow = new xb.UIPanel({
      style: {width: '100%', flexDirection: 'row', gap: 6},
      children: [
        new xb.UIButton({
          label: 'Hint 1: Nudge',
          style: {flexGrow: 1, height: 34, fontSize: 13},
          onClick: () => this.callbacks.onRequestHint(1),
        }),
        new xb.UIButton({
          label: 'Hint 2: Rule',
          style: {flexGrow: 1, height: 34, fontSize: 13},
          onClick: () => this.callbacks.onRequestHint(2),
        }),
        new xb.UIButton({
          label: 'Hint 3: Assist',
          style: {flexGrow: 1, height: 34, fontSize: 13},
          onClick: () => this.callbacks.onRequestHint(3),
        }),
      ],
    });
    this.cluesBody = new xb.UIPanel({
      style: {width: '100%', flexDirection: 'column', gap: 6},
    });

    this.handlerCard = new xb.UICard({
      size: {width: 0.56, height: 'auto'},
      manipulation: true,
      edge: true,
      style: {
        flexDirection: 'column',
        gap: 10,
        padding: 18,
        backgroundColor: 'rgba(10, 17, 31, 0.93)',
        borderColor: 'rgba(212, 175, 55, 0.45)',
        borderWidth: 1.5,
      },
      children: [
        this.handlerSpeaker,
        this.handlerLine,
        this.handlerQuip,
        this.hintRow,
        new xb.UIText({
          text: 'INTEL, CLUES & EVIDENCE BUFFER',
          style: {fontSize: 14, fontWeight: 'bold', color: '#38bdf8'},
        }),
        this.cluesBody,
      ],
    });
    this.handlerCard.position.set(1.06, 1.38, -1.0);
    this.handlerCard.rotation.y = -0.48;
    this.add(this.handlerCard);

    // 3. View-Space Bottom Dock & Comfort Overlay (never occludes center viewport)
    this.comfortDrawer = new xb.UIPanel({
      visible: false,
      style: {
        width: '100%',
        flexDirection: 'column',
        gap: 8,
        padding: 12,
        backgroundColor: 'rgba(9, 15, 29, 0.95)',
        borderColor: 'rgba(56, 189, 248, 0.45)',
        borderWidth: 1.5,
        borderRadius: 16,
      },
    });
    this.comfortToggleBtn = new xb.UIButton({
      label: 'Comfort & XR Settings',
      icon: 'tune',
      style: {height: 36, fontSize: 13},
      onClick: () => {
        this.comfortOpen = !this.comfortOpen;
        this.confirmReset = false;
        this.callbacks.onToggleComfortMenu(this.comfortOpen);
        this.refreshComfortDrawer();
      },
    });

    const navBar = new xb.UIPanel({
      style: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'center',
        gap: 8,
        padding: 8,
        backgroundColor: 'rgba(9, 15, 29, 0.88)',
        borderRadius: 16,
        borderColor: 'rgba(255, 255, 255, 0.16)',
        borderWidth: 1,
      },
      children: [
        new xb.UIExitButton(),
        new xb.UIButton({
          label: 'Table',
          style: {height: 36, fontSize: 13},
          onClick: () => this.callbacks.onTeleportStation('table'),
        }),
        new xb.UIButton({
          label: 'Desk',
          style: {height: 36, fontSize: 13},
          onClick: () => this.callbacks.onTeleportStation('desk'),
        }),
        new xb.UIButton({
          label: 'Evidence',
          style: {height: 36, fontSize: 13},
          onClick: () => this.callbacks.onTeleportStation('evidence'),
        }),
        new xb.UIButton({
          label: 'Cabinet',
          style: {height: 36, fontSize: 13},
          onClick: () => this.callbacks.onTeleportStation('cabinet'),
        }),
        this.comfortToggleBtn,
      ],
    });

    this.comfortOverlay = new xb.UIOverlay({
      appearance: 'none',
      style: {
        width: 780,
        position: 'absolute',
        left: '50%',
        bottom: 18,
        transform: {translateX: '-50%'},
        flexDirection: 'column',
        gap: 8,
      },
      children: [this.comfortDrawer, navBar],
    });
    this.comfortOverlay.name = 'Duke Satoshi Navigation & Comfort';
    this.add(this.comfortOverlay);
  }

  setDialogue(payload: HandlerDialoguePayload) {
    this.currentDialogue = payload;
    this.lastHandlerKey = '';
    this.sync();
  }

  applyAccessibilityLayout(settings: AccessibilitySettings) {
    const baseY = settings.postureMode === 'seated' ? 1.24 : 1.44;
    const distScale = settings.uiDistance / 1.05;
    this.opsCard.position.set(-1.06 * distScale, baseY, -1.0 * distScale);
    this.handlerCard.position.set(1.06 * distScale, baseY, -1.0 * distScale);

    const fontScale = settings.fontScale;
    this.opsCard.scale.setScalar(fontScale);
    this.handlerCard.scale.setScalar(fontScale);

    xb.ui.theme = settings.highContrast ? 'highContrast' : 'grayGlass';
  }

  sync() {
    const save = this.engine.getSave();
    const run = this.engine.activeRun;
    const acc = this.engine.getAccessibility();
    this.applyAccessibilityLayout(acc);

    const opsKey = JSON.stringify({
      phase: this.engine.phase,
      contractId: this.engine.selectedContractId,
      credits: save.cipherCredits,
      draft: this.engine.draftLoadout,
      upgrades: save.toolUpgrades,
      cond: save.equipmentCondition,
      feedback: this.engine.lastFeedback,
      runState: run
        ? {
            node: run.activeNodeId,
            comp: run.computeRemaining,
            trace: run.tracePressure,
            charges: run.toolCharges,
            disabled: run.disabledTools,
            choice: run.selectedTrustChoiceId,
            extracted: run.extracted,
            completedCount: Object.values(run.nodes).filter((n) => n.completed)
              .length,
          }
        : null,
    });

    if (opsKey !== this.lastOpsKey) {
      this.lastOpsKey = opsKey;
      this.rebuildOpsCard();
    }

    const handlerKey = JSON.stringify({
      d: this.currentDialogue,
      phase: this.engine.phase,
      clues: run ? Object.values(run.clues) : null,
      ev: run ? Object.values(run.evidence) : null,
      preserved: run?.preservedEvidenceIds ?? [],
      rep: save.reputation,
    });

    if (handlerKey !== this.lastHandlerKey) {
      this.lastHandlerKey = handlerKey;
      this.rebuildHandlerCard();
    }

    const comfortKey = JSON.stringify({
      open: this.comfortOpen,
      confirmReset: this.confirmReset,
      acc,
      paused: this.engine.timersPaused,
    });
    if (comfortKey !== this.lastComfortKey) {
      this.lastComfortKey = comfortKey;
      this.refreshComfortDrawer();
    }
  }

  private clearPanel(panel: xb.UIPanel) {
    while (panel.children.length > 0) {
      panel.remove(panel.children[0]);
    }
  }

  private rebuildOpsCard() {
    this.clearPanel(this.opsBody);
    const save = this.engine.getSave();
    const phase = this.engine.phase;
    const run = this.engine.activeRun;

    this.opsHeaderMeta.text = `Cipher Credits: ${save.cipherCredits} CC${
      run
        ? `  |  Compute: ${run.computeRemaining}/${run.computeMax}  |  Trace: ${run.tracePressure}%`
        : ''
    }`;
    this.opsStatus.text = this.engine.lastFeedback;

    if (phase === 'STUDY_BRIEFING') {
      const contracts = this.engine.getAvailableContracts();
      const activeContract = getContractById(this.engine.selectedContractId);
      const corp = CORPORATIONS[activeContract.corporationId];
      this.opsTitle.text = 'LONDON STUDY // CONTRACT DOSSIER';

      // Contract selection row
      const row = new xb.UIPanel({
        style: {width: '100%', flexDirection: 'row', gap: 6},
        children: contracts.map(({contract, unlocked, completedCount}) => {
          const isSel = contract.id === this.engine.selectedContractId;
          return new xb.UIButton({
            label: `${contract.title.replace('The ', '')}${completedCount > 0 ? ' ✓' : ''}`,
            disabled: !unlocked,
            style: {
              flexGrow: 1,
              height: 36,
              fontSize: 12,
              backgroundColor: isSel
                ? 'rgba(56, 189, 248, 0.32)'
                : 'rgba(255, 255, 255, 0.08)',
              borderColor: isSel ? '#38bdf8' : 'rgba(255,255,255,0.18)',
              borderWidth: isSel ? 2 : 1,
            },
            onClick: () => this.callbacks.onSelectContract(contract.id),
          });
        }),
      });

      const detail = new xb.UIText({
        text: `${activeContract.codeName} (${activeContract.difficulty})\nClient/Target: ${corp.name} — ${corp.sector}\nBase Fee: ${activeContract.baseReward} CC · Compute: ${activeContract.computeBudget} · Capacity: ${activeContract.extractionCapacity}\n${activeContract.briefingDetail}`,
        style: {
          fontSize: 14,
          lineHeight: 1.35,
          color: '#e2e8f0',
          whiteSpace: 'pre-line',
        },
      });

      const actions = new xb.UIPanel({
        style: {width: '100%', flexDirection: 'row', gap: 8},
        children: [
          new xb.UIButton({
            label: 'Prepare Loadout',
            icon: 'work',
            style: {flexGrow: 1, height: 42, fontSize: 15},
            onClick: () => this.callbacks.onGoToLoadout(),
          }),
          new xb.UIButton({
            label: 'Workshop & Upgrades',
            icon: 'build',
            style: {flexGrow: 1, height: 42, fontSize: 15},
            onClick: () => this.callbacks.onGoToWorkshop(),
          }),
        ],
      });

      this.opsBody.add(row, detail, actions);
      return;
    }

    if (phase === 'LOADOUT_PREP') {
      const contract = getContractById(this.engine.selectedContractId);
      this.opsTitle.text = `LOADOUT // ${contract.title.toUpperCase()}`;

      this.opsBody.add(
        new xb.UIText({
          text: `Select 3 tools (${this.engine.draftLoadout.length}/3 equipped):`,
          style: {fontSize: 14, color: '#cbd5e1'},
        })
      );

      for (const tool of TOOL_LIST) {
        const equipped = this.engine.draftLoadout.includes(tool.id);
        const lv = save.toolUpgrades[tool.id] ?? 1;
        const cond = save.equipmentCondition[tool.id] ?? 100;
        const btn = new xb.UIButton({
          label: `${equipped ? '[EQUIPPED] ' : ''}${tool.name} (Lv.${lv} · ${cond}% · ${tool.computeCost}C)`,
          style: {
            width: '100%',
            height: 36,
            fontSize: 13,
            backgroundColor: equipped
              ? 'rgba(34, 197, 94, 0.25)'
              : 'rgba(255, 255, 255, 0.06)',
            borderColor: equipped ? '#4ade80' : 'rgba(255,255,255,0.16)',
            borderWidth: equipped ? 2 : 1,
          },
          onClick: () => this.callbacks.onToggleTool(tool.id),
        });
        const desc = new xb.UIText({
          text: `${tool.tagline} Tradeoff: ${tool.tradeoff}`,
          style: {fontSize: 12, color: '#94a3b8'},
        });
        this.opsBody.add(btn, desc);
      }

      const actions = new xb.UIPanel({
        style: {width: '100%', flexDirection: 'row', gap: 8},
        children: [
          new xb.UIButton({
            label: 'Back to Study',
            style: {flexGrow: 1, height: 40, fontSize: 14},
            onClick: () => this.callbacks.onGoToBriefing(),
          }),
          new xb.UIButton({
            label: 'Enter Corporate Grid',
            icon: 'login',
            style: {
              flexGrow: 2,
              height: 40,
              fontSize: 15,
              backgroundColor: 'rgba(56, 189, 248, 0.28)',
              borderColor: '#38bdf8',
              borderWidth: 2,
            },
            onClick: () => this.callbacks.onStartMission(),
          }),
        ],
      });
      this.opsBody.add(actions);
      return;
    }

    if (phase === 'UPGRADE_WORKSHOP') {
      this.opsTitle.text = 'EQUIPMENT CABINET // UPGRADES & REPAIR';
      for (const tool of TOOL_LIST) {
        const lv = save.toolUpgrades[tool.id] ?? 1;
        const cond = save.equipmentCondition[tool.id] ?? 100;
        const upgCost = tool.upgradeCost * lv;
        const repCost = Math.max(20, Math.round((100 - cond) * 1.2));

        const row = new xb.UIPanel({
          style: {
            width: '100%',
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            padding: 6,
            backgroundColor: 'rgba(255,255,255,0.05)',
            borderRadius: 10,
          },
          children: [
            new xb.UIText({
              text: `${tool.name} Lv.${lv} (${cond}%)\n${tool.upgradeDescription}`,
              style: {flexGrow: 1, fontSize: 12, whiteSpace: 'pre-line'},
            }),
            new xb.UIButton({
              label: lv >= 3 ? 'MAX' : `Up ${upgCost}CC`,
              disabled: lv >= 3 || save.cipherCredits < upgCost,
              style: {height: 34, fontSize: 12},
              onClick: () => this.callbacks.onUpgradeTool(tool.id),
            }),
            new xb.UIButton({
              label: cond >= 100 ? '100%' : `Fix ${repCost}CC`,
              disabled: cond >= 100 || save.cipherCredits < repCost,
              style: {height: 34, fontSize: 12},
              onClick: () => this.callbacks.onRepairTool(tool.id),
            }),
          ],
        });
        this.opsBody.add(row);
      }
      this.opsBody.add(
        new xb.UIButton({
          label: 'Return to Mission Desk',
          style: {width: '100%', height: 40, fontSize: 14},
          onClick: () => this.callbacks.onGoToBriefing(),
        })
      );
      return;
    }

    if (
      (phase === 'NETWORK_INFILTRATION' || phase === 'EXTRACTION') &&
      run
    ) {
      const contract = getContractById(run.contractId);
      const node = run.nodes[run.activeNodeId];
      const primaryDone = Boolean(run.nodes[contract.requiredNodeId]?.completed);

      this.opsTitle.text = `${node.shortCode} // ${node.label.toUpperCase()}`;
      this.opsBody.add(
        new xb.UIText({
          text: `${node.description}\nStatus: ${
            node.completed ? 'UNLOCKED / COMPLETE' : 'ACTIVE LOCK'
          } · Trace Risk on Entry: +${node.baseTraceGain}%`,
          style: {
            fontSize: 14,
            lineHeight: 1.35,
            color: '#e2e8f0',
            whiteSpace: 'pre-line',
          },
        })
      );

      // Tools row
      const toolRow = new xb.UIPanel({
        style: {width: '100%', flexDirection: 'row', gap: 6},
        children: run.selectedTools.map((toolId) => {
          const charges = run.toolCharges[toolId] ?? 0;
          const disabled =
            run.disabledTools.includes(toolId) || charges <= 0;
          return new xb.UIButton({
            label: `${TOOLS[toolId].shortLabel} (${charges})`,
            disabled,
            style: {flexGrow: 1, height: 36, fontSize: 12},
            onClick: () => this.callbacks.onUseTool(toolId),
          });
        }),
      });
      this.opsBody.add(toolRow);

      // Trust choice once primary vault is completed
      if (primaryDone) {
        this.opsBody.add(
          new xb.UIText({
            text: 'CUSTODIAN DECISION — WHOM DO YOU TRUST?',
            style: {fontSize: 14, fontWeight: 'bold', color: '#eab308'},
          })
        );
        for (const ch of contract.trustChoices) {
          const picked = run.selectedTrustChoiceId === ch.id;
          this.opsBody.add(
            new xb.UIButton({
              label: `${picked ? '[SELECTED] ' : ''}${ch.label} (${ch.faction})`,
              style: {
                width: '100%',
                height: 36,
                fontSize: 12,
                backgroundColor: picked
                  ? 'rgba(234, 179, 8, 0.25)'
                  : 'rgba(255,255,255,0.07)',
                borderColor: picked ? '#eab308' : 'rgba(255,255,255,0.18)',
                borderWidth: picked ? 2 : 1,
              },
              onClick: () => this.callbacks.onSelectTrustChoice(ch.id),
            })
          );
        }
      }

      // Extract button
      this.opsBody.add(
        new xb.UIButton({
          label: primaryDone
            ? 'Extract to London Study'
            : 'Emergency Abort & Extract',
          icon: 'logout',
          style: {
            width: '100%',
            height: 40,
            fontSize: 14,
            backgroundColor: primaryDone
              ? 'rgba(34, 197, 94, 0.28)'
              : 'rgba(239, 68, 68, 0.2)',
            borderColor: primaryDone ? '#4ade80' : '#f87171',
            borderWidth: 2,
          },
          onClick: () => this.callbacks.onExtract(),
        })
      );
      return;
    }

    if (phase === 'MISSION_DEBRIEF' && run?.debrief) {
      const d = run.debrief;
      const contract = getContractById(run.contractId);
      const choice = contract.trustChoices.find(
        (c) => c.id === run.selectedTrustChoiceId
      );
      this.opsTitle.text = run.forcedExtraction
        ? 'DEBRIEF // FORCED EXTRACTION'
        : 'DEBRIEF // CONTRACT SETTLED';

      const breakdownText = [
        `Base Contract Fee: +${d.baseContract} CC`,
        `Optional Evidence: +${d.optionalEvidence} CC`,
        `Efficiency Bonus: +${d.efficiencyBonus} CC`,
        `Asset Recovery: +${d.assetRecovery} CC`,
        `Custodian Adjustment: +${d.choiceAdjustment} CC`,
        `Trace Scrubbing Penalty: -${d.tracePenalty} CC`,
        `Equipment Upkeep: -${d.equipmentUpkeep} CC`,
        `------------------------------`,
        `NET PAYOUT: +${d.netCredits} CIPHER CREDITS`,
        choice ? `Outcome: ${choice.label} — "${choice.dukeQuip}"` : '',
      ]
        .filter(Boolean)
        .join('\n');

      this.opsBody.add(
        new xb.UIText({
          text: breakdownText,
          style: {
            fontSize: 14,
            lineHeight: 1.38,
            color: '#f8fafc',
            whiteSpace: 'pre-line',
          },
        }),
        new xb.UIButton({
          label: 'Return to London Study',
          icon: 'home',
          style: {width: '100%', height: 42, fontSize: 15},
          onClick: () => this.callbacks.onReturnToStudy(),
        })
      );
    }
  }

  private rebuildHandlerCard() {
    this.handlerSpeaker.text = `${this.currentDialogue.speaker.toUpperCase()} (${
      this.currentDialogue.source === 'gemini-4.0'
        ? 'GEMINI 4.0'
        : 'SCRIPTED ARCHIVE'
    })`;
    this.handlerLine.text = this.currentDialogue.line;
    this.handlerQuip.text = this.currentDialogue.quip ?? '';
    this.hintRow.visible = this.engine.phase === 'NETWORK_INFILTRATION';

    this.clearPanel(this.cluesBody);
    const run = this.engine.activeRun;
    if (!run) {
      const rep = this.engine.getSave().reputation;
      const lines = Object.entries(rep)
        .map(
          ([corpId, score]) =>
            `${CORPORATIONS[corpId as keyof typeof CORPORATIONS].name}: ${score >= 0 ? `+${score}` : score}`
        )
        .join('\n');
      this.cluesBody.add(
        new xb.UIText({
          text: `Corporate Reputation Standing:\n${lines}`,
          style: {
            fontSize: 13,
            lineHeight: 1.35,
            color: '#cbd5e1',
            whiteSpace: 'pre-line',
          },
        })
      );
      return;
    }

    const revealedClues = Object.values(run.clues).filter((c) => c.revealed);
    const clueLines =
      revealedClues.length > 0
        ? revealedClues.map((c) => `• ${c.title}: ${c.summary}`).join('\n')
        : 'No clues logged yet.';

    const evList = Object.values(run.evidence)
      .map((e) => {
        const tag = run.preservedEvidenceIds.includes(e.id)
          ? '[COLD STORAGE]'
          : e.collected
            ? '[CARRIED]'
            : '[IN VAULT]';
        return `${tag} ${e.title} (${e.creditValue} CC)`;
      })
      .join('\n');

    this.cluesBody.add(
      new xb.UIText({
        text: `Buffer: ${run.carriedEvidenceIds.length}/${run.extractionCapacity} slots\n${evList}\n\nClues:\n${clueLines}`,
        style: {
          fontSize: 13,
          lineHeight: 1.35,
          color: '#e2e8f0',
          whiteSpace: 'pre-line',
        },
      })
    );
  }

  private refreshComfortDrawer() {
    this.comfortDrawer.visible = this.comfortOpen;
    this.comfortToggleBtn.label = this.comfortOpen
      ? 'Close Comfort (Timers Paused)'
      : 'Comfort & XR Settings';

    if (!this.comfortOpen) return;
    this.clearPanel(this.comfortDrawer);

    const acc = this.engine.getAccessibility();
    const row1 = new xb.UIPanel({
      style: {width: '100%', flexDirection: 'row', gap: 8},
      children: [
        new xb.UIButton({
          label: `Posture: ${acc.postureMode.toUpperCase()}`,
          style: {flexGrow: 1, height: 34, fontSize: 12},
          onClick: () =>
            this.callbacks.onUpdateAccessibility({
              postureMode: acc.postureMode === 'seated' ? 'standing' : 'seated',
            }),
        }),
        new xb.UIButton({
          label: `Contrast: ${acc.highContrast ? 'HIGH' : 'NOIR'}`,
          style: {flexGrow: 1, height: 34, fontSize: 12},
          onClick: () =>
            this.callbacks.onUpdateAccessibility({
              highContrast: !acc.highContrast,
            }),
        }),
        new xb.UIButton({
          label: `AR Room: ${acc.arPassthrough ? 'ON' : 'STUDY'}`,
          style: {flexGrow: 1, height: 34, fontSize: 12},
          onClick: () =>
            this.callbacks.onUpdateAccessibility({
              arPassthrough: !acc.arPassthrough,
            }),
        }),
        new xb.UIButton({
          label: `Audio: ${acc.audioMuted ? 'MUTED' : 'ON'}`,
          style: {flexGrow: 1, height: 34, fontSize: 12},
          onClick: () =>
            this.callbacks.onUpdateAccessibility({
              audioMuted: !acc.audioMuted,
            }),
        }),
      ],
    });

    const distSlider = new xb.UISlider({
      ariaLabel: 'UI Distance in meters',
      min: 0.85,
      max: 1.45,
      step: 0.05,
      value: acc.uiDistance,
      style: {flexGrow: 1, height: 32},
      onInput: (value) =>
        this.callbacks.onUpdateAccessibility({uiDistance: value}),
    });

    const fontSlider = new xb.UISlider({
      ariaLabel: 'UI Scale',
      min: 0.85,
      max: 1.25,
      step: 0.05,
      value: acc.fontScale,
      style: {flexGrow: 1, height: 32},
      onInput: (value) =>
        this.callbacks.onUpdateAccessibility({fontScale: value}),
    });

    const row2 = new xb.UIPanel({
      style: {
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
      },
      children: [
        new xb.UIText({
          text: `Reach ${acc.uiDistance.toFixed(2)}m`,
          style: {fontSize: 12},
        }),
        distSlider,
        new xb.UIText({
          text: `Scale ${acc.fontScale.toFixed(2)}x`,
          style: {fontSize: 12},
        }),
        fontSlider,
        new xb.UIButton({
          label: this.confirmReset ? 'Confirm Reset!' : 'Reset Save',
          style: {
            height: 32,
            fontSize: 12,
            backgroundColor: this.confirmReset
              ? 'rgba(239, 68, 68, 0.45)'
              : 'rgba(255,255,255,0.08)',
          },
          onClick: () => {
            if (!this.confirmReset) {
              this.confirmReset = true;
              this.refreshComfortDrawer();
            } else {
              this.confirmReset = false;
              this.callbacks.onResetSave();
            }
          },
        }),
      ],
    });

    this.comfortDrawer.add(row1, row2);
  }
}
