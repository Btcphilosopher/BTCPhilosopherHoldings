import * as THREE from 'three';
import * as xb from 'xrblocks';
import type {EvidenceItem} from '../../engine/types.ts';

/**
 * Reusable grabbable XR Block representing a recovered fictional evidence dossier card.
 * Displays along the Study Evidence Wall or hovers beside the Network Table when collected.
 */
export class EvidenceCardBlock extends xb.UICard {
  private titleText: xb.UIText;
  private metaText: xb.UIText;
  private statusBadge: xb.UIText;

  constructor(item: EvidenceItem) {
    const titleText = new xb.UIText({
      text: item.title,
      pointerEvents: 'none',
      style: {fontSize: 18, fontWeight: 'bold', color: '#f8fafc'},
    });
    const metaText = new xb.UIText({
      text: `${item.quality} · ${item.creditValue} CC`,
      pointerEvents: 'none',
      style: {fontSize: 14, color: '#fde68a'},
    });
    const statusBadge = new xb.UIText({
      text: item.collected ? 'SECURED' : 'IN VAULT',
      pointerEvents: 'none',
      style: {fontSize: 13, fontWeight: 'bold', color: '#38bdf8'},
    });

    super({
      size: {width: 0.34, height: 'auto'},
      manipulation: true,
      edge: true,
      style: {
        flexDirection: 'column',
        gap: 6,
        padding: 12,
        backgroundColor: 'rgba(11, 21, 40, 0.9)',
        borderColor: 'rgba(212, 175, 55, 0.45)',
        borderWidth: 1.5,
        borderRadius: 14,
      },
      children: [titleText, metaText, statusBadge],
    });

    this.titleText = titleText;
    this.metaText = metaText;
    this.statusBadge = statusBadge;
    this.name = `Evidence: ${item.title}`;
  }

  sync(item: EvidenceItem, preserved: boolean) {
    this.titleText.text = item.title;
    this.metaText.text = `${item.quality} · ${item.creditValue} CC · ${item.summary}`;
    if (preserved) {
      this.statusBadge.text = 'COLD STORAGE LOCKED';
      this.statusBadge.style.color = '#2dd4bf';
    } else if (item.collected) {
      this.statusBadge.text = 'SECURED IN BUFFER';
      this.statusBadge.style.color = '#4ade80';
    } else {
      this.statusBadge.text = 'UNRECOVERED';
      this.statusBadge.style.color = '#94a3b8';
    }
  }
}

/**
 * Reusable Snap Connector beam linking two 3D NetworkNodeBlocks on the Spatial Table.
 */
export class SnapConnectorBeam extends THREE.Line {
  private mat: THREE.LineBasicMaterial;

  constructor(
    from: THREE.Vector3,
    to: THREE.Vector3,
    isHiddenShortcut = false
  ) {
    const geom = new THREE.BufferGeometry().setFromPoints([from, to]);
    const mat = new THREE.LineBasicMaterial({
      color: isHiddenShortcut ? 0x2dd4bf : 0x38bdf8,
      transparent: true,
      opacity: isHiddenShortcut ? 0.85 : 0.42,
    });
    super(geom, mat);
    this.mat = mat;
    this.xb = {pointerEvents: 'none'};
  }

  setState(active: boolean, concealed: boolean) {
    if (concealed) {
      this.mat.color.setHex(0xa78bfa);
      this.mat.opacity = 0.85;
    } else if (active) {
      this.mat.color.setHex(0xfacc15);
      this.mat.opacity = 0.92;
    } else {
      this.mat.color.setHex(0x38bdf8);
      this.mat.opacity = 0.4;
    }
  }

  dispose() {
    this.geometry.dispose();
    this.mat.dispose();
  }
}
