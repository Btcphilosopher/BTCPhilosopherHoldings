import * as THREE from 'three';
import * as xb from 'xrblocks';
import type {
  ArchiveDecodingPuzzle,
  ArchiveOp,
  IdentityReconstructionPuzzle,
  NetworkNodeRuntime,
  SignalRoutingPuzzle,
} from '../../engine/types.ts';

class SignalTileButton extends xb.MeshScript<
  THREE.BoxGeometry,
  THREE.MeshStandardMaterial
> {
  constructor(
    public readonly row: number,
    public readonly col: number,
    private onPress: (row: number, col: number) => void
  ) {
    super(
      new THREE.BoxGeometry(0.068, 0.018, 0.068),
      new THREE.MeshStandardMaterial({
        color: 0x162238,
        roughness: 0.35,
        metalness: 0.4,
      })
    );
    this.name = `Signal tile ${row},${col}`;
  }

  onObjectSelectStart(event: xb.SelectEvent) {
    this.onPress(this.row, this.col);
    event.stopPropagation();
  }

  onObjectTouchStart(event: xb.ObjectTouchStartEvent) {
    this.onPress(this.row, this.col);
    event.stopPropagation();
  }

  onHoverEnter(event: xb.HoverEvent) {
    this.scale.set(1.08, 1.25, 1.08);
    event.stopPropagation();
  }

  onHoverExit(event: xb.HoverEvent) {
    this.scale.set(1, 1, 1);
    event.stopPropagation();
  }

  dispose() {
    this.geometry.dispose();
    this.material.dispose();
    super.dispose();
  }
}

export interface PuzzleSocketCallbacks {
  onSignalTile: (row: number, col: number) => void;
  onSelectChannel: (channelId: string) => void;
  onResetChannel: () => void;
  onSelectIdentityOption: (slotIndex: number, option: string) => void;
  onArchiveOp: (op: ArchiveOp) => void;
  onArchiveReset: () => void;
}

const ARCHIVE_GLYPH_COLORS = [0x38bdf8, 0x2dd4bf, 0xeab308, 0xf4f1ea];

/**
 * Reusable spatial PuzzleSocketBlock rendering 3D interactive sockets for:
 * - Signal Routing (4x4 physical tile matrix + channel selector card)
 * - Identity Reconstruction (4-slot holographic badge card + crystal pedestal)
 * - Archive Decoding (4 orbiting symbolic cipher prisms + operation deck)
 */
export class PuzzleSocketBlock extends xb.Script {
  private callbacks: PuzzleSocketCallbacks;

  // 3D Signal Routing board
  private signalGroup = new THREE.Group();
  private signalTiles: SignalTileButton[][] = [];
  private signalMarkersGroup = new THREE.Group();

  // 3D Archive Decoding Ring
  private archiveGroup = new THREE.Group();
  private archivePrisms: THREE.Mesh<
    THREE.BufferGeometry,
    THREE.MeshStandardMaterial
  >[] = [];

  // 3D Identity Pedestal
  private identityGroup = new THREE.Group();
  private identityBeacons: THREE.Mesh<
    THREE.OctahedronGeometry,
    THREE.MeshStandardMaterial
  >[] = [];

  // Shared control card attached cleanly beside the 3D socket
  private controlCard: xb.UICard;
  private titleText: xb.UIText;
  private subtitleText: xb.UIText;
  private dynamicContainer: xb.UIPanel;
  private lastUiKey = '';

  constructor(callbacks: PuzzleSocketCallbacks) {
    super();
    this.callbacks = callbacks;

    this.buildSignalBoard();
    this.buildArchiveRing();
    this.buildIdentityPedestal();

    this.titleText = new xb.UIText({
      text: 'Puzzle Socket',
      style: {fontSize: 22, fontWeight: 'bold', color: '#f8fafc'},
    });
    this.subtitleText = new xb.UIText({
      text: 'Select a puzzle node on the table.',
      style: {fontSize: 15, lineHeight: 1.3, color: '#cbd5e1'},
    });
    this.dynamicContainer = new xb.UIPanel({
      style: {
        width: '100%',
        flexDirection: 'column',
        gap: 8,
      },
    });

    this.controlCard = new xb.UICard({
      size: {width: 0.5, height: 'auto'},
      manipulation: true,
      edge: true,
      style: {
        flexDirection: 'column',
        gap: 10,
        padding: 16,
        backgroundColor: 'rgba(10, 17, 32, 0.92)',
        borderColor: 'rgba(212, 175, 55, 0.5)',
        borderWidth: 1.5,
      },
      children: [this.titleText, this.subtitleText, this.dynamicContainer],
    });
    this.controlCard.position.set(0.46, 0.14, 0.04);
    this.controlCard.rotation.y = -0.35;
    this.add(this.controlCard);
  }

  private buildSignalBoard() {
    this.signalGroup.position.set(-0.02, 0.04, 0.02);
    this.signalGroup.rotation.x = 0.52;

    const frameGeo = new THREE.BoxGeometry(0.35, 0.02, 0.35);
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.4,
      metalness: 0.7,
    });
    const frame = new THREE.Mesh(frameGeo, frameMat);
    frame.position.y = -0.015;
    frame.xb = {pointerEvents: 'none'};
    this.signalGroup.add(frame, this.signalMarkersGroup);

    for (let r = 0; r < 4; r++) {
      const rowTiles: SignalTileButton[] = [];
      for (let c = 0; c < 4; c++) {
        const tile = new SignalTileButton(r, c, (rr, cc) =>
          this.callbacks.onSignalTile(rr, cc)
        );
        tile.position.set((c - 1.5) * 0.078, 0.005, (r - 1.5) * 0.078);
        this.signalGroup.add(tile);
        rowTiles.push(tile);
      }
      this.signalTiles.push(rowTiles);
    }

    this.signalGroup.visible = false;
    this.add(this.signalGroup);
  }

  private buildArchiveRing() {
    this.archiveGroup.position.set(0, 0.14, 0);
    const ringGeo = new THREE.TorusGeometry(0.14, 0.008, 10, 32);
    const ringMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      metalness: 0.85,
      roughness: 0.25,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.xb = {pointerEvents: 'none'};
    this.archiveGroup.add(ring);

    const geoms = [
      new THREE.OctahedronGeometry(0.036, 0),
      new THREE.BoxGeometry(0.052, 0.052, 0.052),
      new THREE.ConeGeometry(0.036, 0.068, 4),
      new THREE.DodecahedronGeometry(0.034, 0),
    ];

    const slotCoords: Array<[number, number, number]> = [
      [0, 0, -0.14],
      [0.14, 0, 0],
      [0, 0, 0.14],
      [-0.14, 0, 0],
    ];

    for (let i = 0; i < 4; i++) {
      const mat = new THREE.MeshStandardMaterial({
        color: ARCHIVE_GLYPH_COLORS[i],
        emissive: ARCHIVE_GLYPH_COLORS[i],
        emissiveIntensity: 0.35,
        roughness: 0.25,
        metalness: 0.5,
      });
      const mesh = new THREE.Mesh(geoms[i], mat);
      mesh.position.set(...slotCoords[i]);
      mesh.xb = {pointerEvents: 'none'};
      this.archivePrisms.push(mesh);
      this.archiveGroup.add(mesh);
    }

    this.archiveGroup.visible = false;
    this.add(this.archiveGroup);
  }

  private buildIdentityPedestal() {
    this.identityGroup.position.set(0, 0.12, 0);
    for (let i = 0; i < 4; i++) {
      const geo = new THREE.OctahedronGeometry(0.032, 0);
      const mat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        emissive: 0x38bdf8,
        emissiveIntensity: 0.15,
        roughness: 0.3,
        metalness: 0.6,
      });
      const gem = new THREE.Mesh(geo, mat);
      gem.position.set((i - 1.5) * 0.09, 0, 0);
      gem.xb = {pointerEvents: 'none'};
      this.identityBeacons.push(gem);
      this.identityGroup.add(gem);
    }
    this.identityGroup.visible = false;
    this.add(this.identityGroup);
  }

  syncNode(
    node: NetworkNodeRuntime | null,
    activeChannelId: string,
    extraVersion: string
  ) {
    if (!node || !node.puzzle) {
      this.visible = false;
      return;
    }
    this.visible = true;

    const puzzle = node.puzzle;
    this.signalGroup.visible = puzzle.kind === 'signal_routing';
    this.archiveGroup.visible = puzzle.kind === 'archive_decoding';
    this.identityGroup.visible = puzzle.kind === 'identity_reconstruction';

    if (puzzle.kind === 'signal_routing') {
      this.syncSignalBoard(puzzle);
      const uiKey = `sig:${node.id}:${activeChannelId}:${puzzle.solved}:${JSON.stringify(puzzle.playerPaths)}:${extraVersion}`;
      if (uiKey !== this.lastUiKey) {
        this.lastUiKey = uiKey;
        this.rebuildSignalCard(node, puzzle, activeChannelId);
      }
    } else if (puzzle.kind === 'identity_reconstruction') {
      this.syncIdentityPedestal(puzzle);
      const uiKey = `id:${node.id}:${puzzle.solved}:${puzzle.selectedOptions.join('|')}:${puzzle.slots.map((s) => s.revealedByDefault).join(',')}:${extraVersion}`;
      if (uiKey !== this.lastUiKey) {
        this.lastUiKey = uiKey;
        this.rebuildIdentityCard(node, puzzle);
      }
    } else if (puzzle.kind === 'archive_decoding') {
      this.syncArchiveRing(puzzle);
      const uiKey = `arch:${node.id}:${puzzle.solved}:${puzzle.currentRing.join(',')}:${puzzle.movesTaken}:${extraVersion}`;
      if (uiKey !== this.lastUiKey) {
        this.lastUiKey = uiKey;
        this.rebuildArchiveCard(node, puzzle);
      }
    }
  }

  private syncSignalBoard(puzzle: SignalRoutingPuzzle) {
    // Clear old diode/endpoint markers
    while (this.signalMarkersGroup.children.length > 0) {
      const child = this.signalMarkersGroup.children[0] as THREE.Mesh;
      this.signalMarkersGroup.remove(child);
      child.geometry?.dispose();
    }

    const blockedSet = new Set(
      puzzle.blockedCells.map(([r, c]) => `${r},${c}`)
    );

    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        const tile = this.signalTiles[r][c];
        const key = `${r},${c}`;
        if (blockedSet.has(key)) {
          tile.material.color.setHex(0x451a03);
          tile.material.emissive.setHex(0xd97706);
          tile.material.emissiveIntensity = 0.25;
        } else {
          tile.material.color.setHex(0x162238);
          tile.material.emissive.setHex(0x000000);
          tile.material.emissiveIntensity = 0;
        }
      }
    }

    for (const ch of puzzle.channels) {
      const col = new THREE.Color(ch.colorHex);
      const path = puzzle.playerPaths[ch.id] ?? [ch.start];
      for (const [r, c] of path) {
        const tile = this.signalTiles[r]?.[c];
        if (tile) {
          tile.material.color.copy(col);
          tile.material.emissive.copy(col);
          tile.material.emissiveIntensity = 0.35;
        }
      }

      // Highlight Start & Sink pillars above their tiles
      [ch.start, ch.end].forEach(([r, c], idx) => {
        const markerGeo =
          idx === 0
            ? new THREE.CylinderGeometry(0.015, 0.018, 0.032, 12)
            : new THREE.OctahedronGeometry(0.018, 0);
        const markerMat = new THREE.MeshStandardMaterial({
          color: col,
          emissive: col,
          emissiveIntensity: 0.65,
        });
        const marker = new THREE.Mesh(markerGeo, markerMat);
        marker.position.set((c - 1.5) * 0.078, 0.032, (r - 1.5) * 0.078);
        marker.xb = {pointerEvents: 'none'};
        this.signalMarkersGroup.add(marker);
      });
    }

    // Highlight directional diodes
    for (const gate of puzzle.directionalGates) {
      const [r, c] = gate.pos;
      const diodeGeo = new THREE.ConeGeometry(0.014, 0.032, 4);
      const diodeMat = new THREE.MeshBasicMaterial({color: 0xffffff});
      const diode = new THREE.Mesh(diodeGeo, diodeMat);
      diode.position.set((c - 1.5) * 0.078, 0.025, (r - 1.5) * 0.078);
      if (gate.dir[0] === -1) diode.rotation.x = -Math.PI / 2;
      else if (gate.dir[0] === 1) diode.rotation.x = Math.PI / 2;
      else if (gate.dir[1] === -1) diode.rotation.z = Math.PI / 2;
      else if (gate.dir[1] === 1) diode.rotation.z = -Math.PI / 2;
      diode.xb = {pointerEvents: 'none'};
      this.signalMarkersGroup.add(diode);
    }
  }

  private syncArchiveRing(puzzle: ArchiveDecodingPuzzle) {
    const slotCoords: Array<[number, number, number]> = [
      [0, 0, -0.14],
      [0.14, 0, 0],
      [0, 0, 0.14],
      [-0.14, 0, 0],
    ];
    puzzle.currentRing.forEach((glyphIdx, slotIdx) => {
      const prism = this.archivePrisms[glyphIdx];
      if (prism) {
        prism.position.set(...slotCoords[slotIdx]);
        prism.material.emissiveIntensity =
          glyphIdx === slotIdx ? 0.75 : 0.25;
      }
    });
  }

  private syncIdentityPedestal(puzzle: IdentityReconstructionPuzzle) {
    puzzle.slots.forEach((slot, idx) => {
      const gem = this.identityBeacons[idx];
      if (!gem) return;
      const matched = puzzle.selectedOptions[idx] === slot.correctOption;
      if (puzzle.solved && matched) {
        gem.material.color.setHex(0x22c55e);
        gem.material.emissive.setHex(0x22c55e);
        gem.material.emissiveIntensity = 0.65;
      } else if (slot.revealedByDefault) {
        gem.material.color.setHex(0xeab308);
        gem.material.emissive.setHex(0xeab308);
        gem.material.emissiveIntensity = 0.4;
      } else {
        gem.material.color.setHex(0x475569);
        gem.material.emissive.setHex(0x38bdf8);
        gem.material.emissiveIntensity = 0.15;
      }
    });
  }

  private clearDynamic() {
    while (this.dynamicContainer.children.length > 0) {
      const child = this.dynamicContainer.children[0];
      this.dynamicContainer.remove(child);
    }
  }

  private rebuildSignalCard(
    node: NetworkNodeRuntime,
    puzzle: SignalRoutingPuzzle,
    activeChannelId: string
  ) {
    this.clearDynamic();
    const gate = puzzle.directionalGates[0];
    this.titleText.text = `${node.label} — Signal Routing`;
    this.subtitleText.text = puzzle.solved
      ? 'SOLVED: All freight telemetry channels synchronized.'
      : `Click/touch adjacent 3D tiles on the board to route each channel from Start (pillar) to Sink (crystal). Diode at (${gate.pos[0]},${gate.pos[1]}) exits ${gate.label}.`;

    const chRow = new xb.UIPanel({
      style: {width: '100%', flexDirection: 'row', gap: 8},
      children: puzzle.channels.map(
        (ch) =>
          new xb.UIButton({
            label:
              ch.id === activeChannelId
                ? `[${ch.colorName}]`
                : ch.colorName,
            disabled: puzzle.solved,
            style: {
              flexGrow: 1,
              height: 38,
              backgroundColor:
                ch.id === activeChannelId
                  ? 'rgba(56, 189, 248, 0.32)'
                  : 'rgba(255, 255, 255, 0.08)',
              borderColor: ch.colorHex,
              borderWidth: 2,
              fontSize: 14,
            },
            onClick: () => this.callbacks.onSelectChannel(ch.id),
          })
      ),
    });

    const resetBtn = new xb.UIButton({
      label: 'Reset Active Channel',
      icon: 'restart_alt',
      disabled: puzzle.solved,
      style: {width: '100%', height: 38, fontSize: 14},
      onClick: () => this.callbacks.onResetChannel(),
    });

    this.dynamicContainer.add(chRow, resetBtn);
  }

  private rebuildIdentityCard(
    node: NetworkNodeRuntime,
    puzzle: IdentityReconstructionPuzzle
  ) {
    this.clearDynamic();
    this.titleText.text = `${node.label} — Identity Badge`;
    this.subtitleText.text = puzzle.solved
      ? `VERIFIED: ${puzzle.subjectName}`
      : `Reconstruct ${puzzle.subjectName} from mission clues.`;

    for (const slot of puzzle.slots) {
      const current = puzzle.selectedOptions[slot.slotIndex];
      const nextIdx =
        (slot.options.indexOf(current) + 1) % slot.options.length;
      const clueBadge = slot.revealedByDefault
        ? slot.clueText
        : 'Clue locked: inspect Sentinel or pulse Spectral Lens.';

      const row = new xb.UIPanel({
        style: {
          width: '100%',
          flexDirection: 'column',
          gap: 4,
          padding: 8,
          backgroundColor: 'rgba(255, 255, 255, 0.05)',
          borderRadius: 10,
        },
        children: [
          new xb.UIButton({
            label: `${slot.slotName}: ${current}`,
            disabled: puzzle.solved,
            style: {width: '100%', height: 36, fontSize: 14},
            onClick: () =>
              this.callbacks.onSelectIdentityOption(
                slot.slotIndex,
                slot.options[nextIdx]
              ),
          }),
          new xb.UIText({
            text: clueBadge,
            style: {fontSize: 12, color: slot.revealedByDefault ? '#fde68a' : '#94a3b8'},
          }),
        ],
      });
      this.dynamicContainer.add(row);
    }
  }

  private rebuildArchiveCard(
    node: NetworkNodeRuntime,
    puzzle: ArchiveDecodingPuzzle
  ) {
    this.clearDynamic();
    this.titleText.text = `${node.label} — Archive Ring`;
    const ringOrder = puzzle.currentRing
      .map((i) => puzzle.glyphLabels[i])
      .join('  ·  ');
    this.subtitleText.text = puzzle.solved
      ? `DECODED in ${puzzle.movesTaken} moves (Par ${puzzle.parMoves}).`
      : `Align to [A-CROWN · B-CYAN · C-GOLD · D-SEAL].\nCurrent: [${ringOrder}] (Moves: ${puzzle.movesTaken}/${puzzle.parMoves})`;

    const opsRow = new xb.UIPanel({
      style: {width: '100%', flexDirection: 'row', gap: 6},
      children: [
        new xb.UIButton({
          label: 'Rotate CW',
          disabled: puzzle.solved,
          style: {flexGrow: 1, height: 38, fontSize: 13},
          onClick: () => this.callbacks.onArchiveOp('ROTATE_CW'),
        }),
        new xb.UIButton({
          label: 'Flip Pairs',
          disabled: puzzle.solved,
          style: {flexGrow: 1, height: 38, fontSize: 13},
          onClick: () => this.callbacks.onArchiveOp('FLIP_POLARITY'),
        }),
        new xb.UIButton({
          label: 'Shift Outer',
          disabled: puzzle.solved,
          style: {flexGrow: 1, height: 38, fontSize: 13},
          onClick: () => this.callbacks.onArchiveOp('SHIFT_RING'),
        }),
      ],
    });

    const resetBtn = new xb.UIButton({
      label: 'Reset Cipher Ring',
      icon: 'restart_alt',
      disabled: puzzle.solved,
      style: {width: '100%', height: 36, fontSize: 13},
      onClick: () => this.callbacks.onArchiveReset(),
    });

    this.dynamicContainer.add(opsRow, resetBtn);
  }

  update() {
    const dt = xb.getDeltaTime();
    if (this.archiveGroup.visible) {
      this.archivePrisms.forEach((p, idx) => {
        p.rotation.y += dt * (0.6 + idx * 0.12);
      });
    }
    if (this.identityGroup.visible) {
      this.identityBeacons.forEach((g, idx) => {
        g.rotation.y += dt * (0.8 + idx * 0.15);
      });
    }
  }

  dispose() {
    this.archivePrisms.forEach((m) => {
      m.geometry.dispose();
      m.material.dispose();
    });
    this.identityBeacons.forEach((m) => {
      m.geometry.dispose();
      m.material.dispose();
    });
    super.dispose();
  }
}
