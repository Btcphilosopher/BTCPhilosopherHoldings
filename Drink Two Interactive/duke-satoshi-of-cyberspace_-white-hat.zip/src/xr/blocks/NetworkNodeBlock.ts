import * as THREE from 'three';
import * as xb from 'xrblocks';
import type {NetworkNodeRuntime, NodeType} from '../../engine/types.ts';

const NODE_COLORS: Record<NodeType, number> = {
  entry_gateway: 0x38bdf8,
  routing_junction: 0x0ea5e9,
  identity_puzzle: 0xeab308,
  encrypted_archive: 0xd4af37,
  monitoring_node: 0xf97316,
  decoy: 0xa855f7,
  evidence_cache: 0x2dd4bf,
  extraction_point: 0x22c55e,
};

function createNodeGeometry(type: NodeType): THREE.BufferGeometry {
  switch (type) {
    case 'entry_gateway':
      return new THREE.CylinderGeometry(0.042, 0.048, 0.055, 8);
    case 'routing_junction':
      return new THREE.CylinderGeometry(0.038, 0.038, 0.05, 6);
    case 'identity_puzzle':
      return new THREE.OctahedronGeometry(0.042, 0);
    case 'encrypted_archive':
      return new THREE.BoxGeometry(0.068, 0.068, 0.068);
    case 'monitoring_node':
      return new THREE.ConeGeometry(0.038, 0.075, 6);
    case 'decoy':
      return new THREE.TetrahedronGeometry(0.045, 0);
    case 'evidence_cache':
      return new THREE.CapsuleGeometry(0.026, 0.032, 6, 12);
    case 'extraction_point':
      return new THREE.CylinderGeometry(0.015, 0.045, 0.09, 8);
  }
}

/**
 * Reusable XR Block representing a navigable corporate network node on the spatial table.
 * Combines colour, distinct 3D geometry, status ring, and a crisp readable label.
 */
export class NetworkNodeBlock extends xb.Script {
  public readonly nodeId: string;
  private onSelectNode: (nodeId: string) => void;
  private bodyMesh: THREE.Mesh<THREE.BufferGeometry, THREE.MeshStandardMaterial>;
  private ringMesh: THREE.Mesh<THREE.RingGeometry, THREE.MeshBasicMaterial>;
  private labelCard: xb.UICard;
  private labelText: xb.UIText;
  private hovered = false;
  private baseLocalY = 0;
  private bobPhase = Math.random() * Math.PI * 2;
  private lastStateSignature = '';

  constructor(
    node: NetworkNodeRuntime,
    onSelectNode: (nodeId: string) => void
  ) {
    super();
    this.nodeId = node.id;
    this.name = `Node ${node.shortCode}`;
    this.onSelectNode = onSelectNode;
    this.baseLocalY = node.position[1];
    this.position.set(node.position[0], node.position[1], node.position[2]);

    const geom = createNodeGeometry(node.type);
    const mat = new THREE.MeshStandardMaterial({
      color: NODE_COLORS[node.type],
      emissive: NODE_COLORS[node.type],
      emissiveIntensity: 0.25,
      roughness: 0.28,
      metalness: 0.55,
    });
    this.bodyMesh = new THREE.Mesh(geom, mat);
    this.bodyMesh.castShadow = true;
    this.add(this.bodyMesh);

    const ringGeo = new THREE.RingGeometry(0.052, 0.064, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.8,
    });
    this.ringMesh = new THREE.Mesh(ringGeo, ringMat);
    this.ringMesh.rotation.x = -Math.PI / 2;
    this.ringMesh.position.y = -0.04;
    this.ringMesh.xb = {pointerEvents: 'none'};
    this.add(this.ringMesh);

    this.labelText = new xb.UIText({
      text: `${node.shortCode} ${node.label}`,
      pointerEvents: 'none',
      style: {
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'center',
        color: '#f8fafc',
      },
    });
    this.labelCard = new xb.UICard({
      size: {width: 0.22, height: 'auto'},
      pointerEvents: 'none',
      style: {
        padding: 6,
        borderRadius: 10,
        backgroundColor: 'rgba(9, 15, 29, 0.88)',
        borderColor: 'rgba(56, 189, 248, 0.45)',
        borderWidth: 1.5,
      },
      children: [this.labelText],
    });
    this.labelCard.position.set(0, 0.088, 0);
    this.labelCard.add(new xb.FaceCamera({mode: 'spherical', smoothing: 0.25}));
    this.add(this.labelCard);
  }

  syncState(node: NetworkNodeRuntime, isActive: boolean, accessible: boolean) {
    const sig = `${node.discovered}|${node.unlocked}|${node.completed}|${node.lockedOut}|${node.inspected}|${node.concealed}|${isActive}|${accessible}`;
    if (sig === this.lastStateSignature) return;
    this.lastStateSignature = sig;

    this.visible = node.discovered;
    if (!node.discovered) return;

    const baseColor =
      node.isDecoyTrap && node.inspected ? 0xef4444 : NODE_COLORS[node.type];
    this.bodyMesh.material.color.setHex(
      node.lockedOut ? 0x475569 : baseColor
    );

    if (isActive) {
      this.bodyMesh.material.emissive.setHex(0xffffff);
      this.bodyMesh.material.emissiveIntensity = 0.45;
      this.ringMesh.material.color.setHex(0xfacc15);
      this.ringMesh.material.opacity = 1.0;
    } else if (node.completed) {
      this.bodyMesh.material.emissive.setHex(0x22c55e);
      this.bodyMesh.material.emissiveIntensity = 0.35;
      this.ringMesh.material.color.setHex(0x22c55e);
      this.ringMesh.material.opacity = 0.9;
    } else if (node.lockedOut) {
      this.bodyMesh.material.emissive.setHex(0xef4444);
      this.bodyMesh.material.emissiveIntensity = 0.15;
      this.ringMesh.material.color.setHex(0xef4444);
      this.ringMesh.material.opacity = 0.45;
    } else if (accessible) {
      this.bodyMesh.material.emissive.setHex(baseColor);
      this.bodyMesh.material.emissiveIntensity = 0.35;
      this.ringMesh.material.color.setHex(0x38bdf8);
      this.ringMesh.material.opacity = 0.85;
    } else {
      this.bodyMesh.material.emissive.setHex(0x1e293b);
      this.bodyMesh.material.emissiveIntensity = 0.1;
      this.ringMesh.material.color.setHex(0x64748b);
      this.ringMesh.material.opacity = 0.35;
    }

    const prefix = node.isDecoyTrap && node.inspected ? '[TRAP] ' : '';
    const suffix = node.completed
      ? ' [OK]'
      : node.lockedOut
        ? ' [SEALED]'
        : node.computeCost > 0 && !node.unlocked
          ? ` (${node.computeCost}C)`
          : '';
    this.labelText.text = `${prefix}${node.label}${suffix}`;
  }

  onHoverEnter(event: xb.HoverEvent) {
    this.hovered = true;
    event.stopPropagation();
  }

  onHoverExit(event: xb.HoverEvent) {
    this.hovered = false;
    event.stopPropagation();
  }

  onObjectSelectStart(event: xb.SelectEvent) {
    this.onSelectNode(this.nodeId);
    event.stopPropagation();
  }

  onObjectTouchStart(event: xb.ObjectTouchStartEvent) {
    this.onSelectNode(this.nodeId);
    event.stopPropagation();
  }

  update() {
    const dt = xb.getDeltaTime();
    this.bobPhase += dt * 1.8;
    const targetScale = this.hovered ? 1.22 : 1.0;
    const s = THREE.MathUtils.lerp(this.bodyMesh.scale.x, targetScale, 0.2);
    this.bodyMesh.scale.setScalar(s);
    this.bodyMesh.rotation.y += dt * (this.hovered ? 1.4 : 0.45);
    this.position.y = this.baseLocalY + Math.sin(this.bobPhase) * 0.008;
  }

  dispose() {
    this.bodyMesh.geometry.dispose();
    this.bodyMesh.material.dispose();
    this.ringMesh.geometry.dispose();
    this.ringMesh.material.dispose();
    super.dispose();
  }
}
