import * as THREE from 'three';
import * as xb from 'xrblocks';
import {HandlerDialogueService, getScriptedBriefing} from '../engine/aiHandler.ts';
import {GameEngine} from '../engine/gameState.ts';
import type {ArchiveOp, HintTier} from '../engine/types.ts';
import {AudioManager} from './AudioManager.ts';
import {SpatialHud, type StudyStation} from './SpatialHud.ts';
import {StudyEnvironment} from './StudyEnvironment.ts';
import {EvidenceCardBlock, SnapConnectorBeam} from './blocks/EvidenceCardBlock.ts';
import {NetworkNodeBlock} from './blocks/NetworkNodeBlock.ts';
import {PuzzleSocketBlock} from './blocks/PuzzleSocketBlock.ts';

interface BeamRecord {
  fromId: string;
  toId: string;
  isHidden: boolean;
  beam: SnapConnectorBeam;
}

const STATION_DESK_VIEWS: Record<
  StudyStation,
  {pos: [number, number, number]; lookAt: [number, number, number]}
> = {
  table: {pos: [0, 1.56, 0.25], lookAt: [0, 1.12, -1.15]},
  desk: {pos: [-0.65, 1.5, -0.05], lookAt: [-1.45, 0.92, -1.05]},
  evidence: {pos: [-1.45, 1.52, -1.35], lookAt: [-2.95, 1.48, -1.35]},
  cabinet: {pos: [0.65, 1.5, -0.08], lookAt: [1.55, 1.0, -1.15]},
};

const STATION_XR_OFFSETS: Record<StudyStation, [number, number, number]> = {
  table: [0, 0, 0],
  desk: [-0.75, 0, 0.1],
  evidence: [-1.45, 0, -0.45],
  cabinet: [0.75, 0, 0.1],
};

/**
 * Top-level XR Blocks application script for DUKE SATOSHI OF CYBERSPACE: WHITE HAT.
 * Orchestrates the London Study environment, Spatial Network Table graph,
 * modular puzzle sockets, evidence blocks, spatial HUD, audio, and GameEngine.
 */
export class DukeSatoshiApp extends xb.Script {
  public readonly engine = new GameEngine();
  private handlerAI = new HandlerDialogueService();
  private audio = new AudioManager();

  private studyEnv = new StudyEnvironment();
  private hud!: SpatialHud;
  private puzzleSocket!: PuzzleSocketBlock;

  private networkGroup = new THREE.Group();
  private nodeBlocks = new Map<string, NetworkNodeBlock>();
  private beamRecords: BeamRecord[] = [];
  private evidenceBlocks = new Map<string, EvidenceCardBlock>();
  private evidenceGroup = new THREE.Group();

  private builtGraphKey = '';
  private lastTraceThresholdCount = 0;
  private unsubscribeEngine: (() => void) | null = null;

  // Desktop camera smooth station transition (never touches camera when XR is presenting)
  private camLerpActive = false;
  private camTargetPos = new THREE.Vector3();
  private camTargetLook = new THREE.Vector3();
  private camLerpTimer = 0;

  private boundKeyDown = (e: KeyboardEvent) => this.handleKeyDown(e);
  private boundUnlockAudio = () => {
    this.audio.unlockAndStart();
    this.camLerpActive = false;
  };

  init() {
    this.add(this.studyEnv);

    this.networkGroup.position.copy(this.studyEnv.tableCenter);
    this.add(this.networkGroup);

    this.evidenceGroup.position.set(0, 1.04, -1.55);
    this.add(this.evidenceGroup);

    this.puzzleSocket = new PuzzleSocketBlock({
      onSignalTile: (row, col) => {
        this.audio.unlockAndStart();
        const prevDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        const ok = this.engine.stepActiveSignalCell(row, col);
        const nowDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        if (!prevDone && nowDone) this.audio.playPuzzleSolved();
        else if (ok) this.audio.playClick();
      },
      onSelectChannel: (channelId) => {
        this.audio.playClick();
        this.engine.activeChannelId = channelId;
        this.syncScene();
      },
      onResetChannel: () => {
        this.audio.playClick();
        this.engine.resetActiveSignalChannel();
      },
      onSelectIdentityOption: (slotIndex, option) => {
        this.audio.unlockAndStart();
        const prevDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        this.engine.selectIdentityOption(slotIndex, option);
        const nowDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        if (!prevDone && nowDone) this.audio.playPuzzleSolved();
        else this.audio.playClick();
      },
      onArchiveOp: (op: ArchiveOp) => {
        this.audio.unlockAndStart();
        const prevDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        this.engine.applyActiveArchiveOp(op);
        const nowDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        if (!prevDone && nowDone) this.audio.playPuzzleSolved();
        else this.audio.playClick();
      },
      onArchiveReset: () => {
        this.audio.playClick();
        this.engine.resetActiveArchivePuzzle();
      },
    });
    this.puzzleSocket.position.set(-0.1, 1.22, -1.12);
    this.puzzleSocket.visible = false;
    this.add(this.puzzleSocket);

    this.hud = new SpatialHud(this.engine, {
      onSelectContract: (id) => {
        this.audio.playClick();
        if (this.engine.selectContract(id)) {
          void this.refreshBriefingDialogue();
        }
      },
      onGoToLoadout: () => {
        this.audio.playClick();
        this.engine.goToLoadout();
      },
      onGoToBriefing: () => {
        this.audio.playClick();
        this.engine.goToBriefing();
      },
      onGoToWorkshop: () => {
        this.audio.playClick();
        this.engine.goToWorkshop();
      },
      onToggleTool: (toolId) => {
        this.audio.playClick();
        this.engine.toggleDraftTool(toolId);
      },
      onStartMission: () => {
        this.audio.unlockAndStart();
        this.audio.playNodeEnter();
        this.lastTraceThresholdCount = 0;
        this.engine.startMission();
        void this.refreshBriefingDialogue();
      },
      onUseTool: (toolId) => {
        this.audio.playClick();
        const prevDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        const ok = this.engine.useTool(toolId);
        const nowDone =
          this.engine.activeRun?.nodes[this.engine.activeRun.activeNodeId]
            ?.completed ?? false;
        if (ok && !prevDone && nowDone) this.audio.playPuzzleSolved();
      },
      onSelectTrustChoice: (choiceId) => {
        this.audio.playClick();
        this.engine.selectTrustChoice(choiceId);
      },
      onExtract: () => {
        this.audio.playPuzzleSolved();
        this.engine.extractMission(false);
      },
      onReturnToStudy: () => {
        this.audio.playClick();
        this.engine.returnToStudyFromDebrief();
        void this.refreshBriefingDialogue();
      },
      onUpgradeTool: (toolId) => {
        this.audio.playPuzzleSolved();
        this.engine.upgradeTool(toolId);
      },
      onRepairTool: (toolId) => {
        this.audio.playClick();
        this.engine.repairTool(toolId);
      },
      onRequestHint: (tier: HintTier) => {
        this.audio.playClick();
        void this.requestHintDialogue(tier);
      },
      onTeleportStation: (station) => {
        this.audio.playClick();
        this.teleportToStation(station);
      },
      onUpdateAccessibility: (partial) => {
        this.audio.playClick();
        this.engine.updateAccessibility(partial);
        const acc = this.engine.getAccessibility();
        this.audio.setMuted(acc.audioMuted);
        this.studyEnv.setPassthroughMode(acc.arPassthrough);
        if (partial.postureMode) {
          this.applyPostureHeight(acc.postureMode);
        }
      },
      onResetSave: () => {
        this.audio.playClick();
        this.engine.resetProgress();
        void this.refreshBriefingDialogue();
      },
      onToggleComfortMenu: (open) => {
        this.audio.playClick();
        this.engine.setTimersPaused(open);
      },
    });
    this.add(this.hud);

    // Apply initial saved accessibility state
    const initialAcc = this.engine.getAccessibility();
    this.audio.setMuted(initialAcc.audioMuted);
    this.studyEnv.setPassthroughMode(initialAcc.arPassthrough);
    this.applyPostureHeight(initialAcc.postureMode);

    this.unsubscribeEngine = this.engine.subscribe(() => this.syncScene());
    this.syncScene();

    // Load initial handler briefing (Gemini 4.0 when configured, scripted archive fallback offline)
    const initialBrief = getScriptedBriefing(
      this.engine.selectedContractId,
      this.engine.getSave().narrativeFlags
    );
    this.hud.setDialogue(initialBrief);
    void this.refreshBriefingDialogue();

    if (typeof window !== 'undefined') {
      window.addEventListener('keydown', this.boundKeyDown);
      window.addEventListener('pointerdown', this.boundUnlockAudio, {
        passive: true,
      });
    }
  }

  onSelectStart() {
    this.audio.unlockAndStart();
  }

  onSimulatorStarted() {
    this.applyPostureHeight(this.engine.getAccessibility().postureMode);
    this.teleportToStation('table');
  }

  onXRSessionStarted() {
    const acc = this.engine.getAccessibility();
    this.studyEnv.setPassthroughMode(acc.arPassthrough);
    this.applyPostureHeight(acc.postureMode);
  }

  private applyPostureHeight(posture: 'seated' | 'standing') {
    if (!xb.core.renderer?.xr?.isPresenting && xb.core.camera) {
      xb.core.camera.position.y = posture === 'seated' ? 1.32 : 1.56;
    } else if (xb.core.user) {
      xb.core.user.position.y = posture === 'seated' ? -0.22 : 0;
    }
  }

  private teleportToStation(station: StudyStation) {
    const posture = this.engine.getAccessibility().postureMode;
    if (xb.core.renderer?.xr?.isPresenting) {
      // In active WebXR, teleport user rig without forcing camera rotation
      const [x, , z] = STATION_XR_OFFSETS[station];
      const yOffset = posture === 'seated' ? -0.22 : 0;
      xb.core.user.position.set(x, yOffset, z);
      return;
    }

    const view = STATION_DESK_VIEWS[station];
    const yHeight =
      posture === 'seated' ? view.pos[1] - 0.22 : view.pos[1];
    this.camTargetPos.set(view.pos[0], yHeight, view.pos[2]);
    this.camTargetLook.set(view.lookAt[0], view.lookAt[1], view.lookAt[2]);
    this.camLerpActive = true;
    this.camLerpTimer = 0.65;
  }

  private async refreshBriefingDialogue() {
    const payload = await this.handlerAI.fetchBriefing(
      this.engine.selectedContractId,
      this.engine.getSave().narrativeFlags
    );
    this.hud.setDialogue(payload);
  }

  private async requestHintDialogue(tier: HintTier) {
    if (!this.engine.activeRun) return;
    this.engine.activeHintTier = tier;
    const payload = await this.handlerAI.fetchHint(this.engine.activeRun, tier);
    this.hud.setDialogue(payload);
  }

  private handleKeyDown(e: KeyboardEvent) {
    this.audio.unlockAndStart();
    if (
      e.target instanceof HTMLInputElement ||
      e.target instanceof HTMLTextAreaElement
    ) {
      return;
    }
    const k = e.key.toLowerCase();
    if (k === '1') this.teleportToStation('table');
    else if (k === '2') this.teleportToStation('desk');
    else if (k === '3') this.teleportToStation('evidence');
    else if (k === '4') this.teleportToStation('cabinet');
    else if (k === 'm') {
      const muted = !this.engine.getAccessibility().audioMuted;
      this.engine.updateAccessibility({audioMuted: muted});
      this.audio.setMuted(muted);
    } else if (k === 'h' && this.engine.activeRun) {
      const nextTier = (((this.engine.activeHintTier % 3) + 1) as HintTier);
      void this.requestHintDialogue(nextTier);
    } else if (k === 'r' && this.engine.activeRun) {
      const node = this.engine.activeRun.nodes[this.engine.activeRun.activeNodeId];
      if (node?.puzzle?.kind === 'signal_routing') {
        this.engine.resetActiveSignalChannel();
      } else if (node?.puzzle?.kind === 'archive_decoding') {
        this.engine.resetActiveArchivePuzzle();
      }
    } else if (
      k === 'e' &&
      this.engine.activeRun &&
      (this.engine.phase === 'NETWORK_INFILTRATION' ||
        this.engine.phase === 'EXTRACTION')
    ) {
      this.engine.extractMission(false);
    }
  }

  private clearNetworkGraph() {
    for (const block of this.nodeBlocks.values()) {
      block.removeFromParent();
      block.dispose();
    }
    this.nodeBlocks.clear();

    for (const rec of this.beamRecords) {
      rec.beam.removeFromParent();
      rec.beam.dispose();
    }
    this.beamRecords = [];

    for (const evBlock of this.evidenceBlocks.values()) {
      evBlock.removeFromParent();
    }
    this.evidenceBlocks.clear();

    this.builtGraphKey = '';
  }

  private rebuildNetworkGraph() {
    this.clearNetworkGraph();
    const run = this.engine.activeRun;
    if (!run) return;

    this.builtGraphKey = `${run.contractId}:${run.seed}`;

    // 1. Instantiate reusable NetworkNodeBlocks
    for (const node of Object.values(run.nodes)) {
      const block = new NetworkNodeBlock(node, (nodeId) => {
        this.audio.unlockAndStart();
        const moved = this.engine.moveToNode(nodeId);
        if (moved) this.audio.playNodeEnter();
      });
      this.nodeBlocks.set(node.id, block);
      this.networkGroup.add(block);
    }

    // 2. Instantiate SnapConnectorBeams for edges + hidden shortcut edges
    const seenEdges = new Set<string>();
    for (const node of Object.values(run.nodes)) {
      const pA = new THREE.Vector3(...node.position);
      for (const targetId of node.connections) {
        const edgeKey = [node.id, targetId].sort().join('->');
        if (seenEdges.has(edgeKey)) continue;
        seenEdges.add(edgeKey);
        const target = run.nodes[targetId];
        if (!target) continue;
        const pB = new THREE.Vector3(...target.position);
        const beam = new SnapConnectorBeam(pA, pB, false);
        this.beamRecords.push({
          fromId: node.id,
          toId: targetId,
          isHidden: false,
          beam,
        });
        this.networkGroup.add(beam);
      }

      if (node.hiddenConnectionTo && run.nodes[node.hiddenConnectionTo]) {
        const target = run.nodes[node.hiddenConnectionTo];
        const pB = new THREE.Vector3(...target.position);
        const beam = new SnapConnectorBeam(pA, pB, true);
        beam.visible = Boolean(node.hiddenRevealed);
        this.beamRecords.push({
          fromId: node.id,
          toId: target.id,
          isHidden: true,
          beam,
        });
        this.networkGroup.add(beam);
      }
    }

    // 3. Instantiate grabbable EvidenceCardBlocks behind the network table
    const evList = Object.values(run.evidence);
    evList.forEach((ev, idx) => {
      const card = new EvidenceCardBlock(ev);
      card.position.set((idx - (evList.length - 1) / 2) * 0.44, 0, 0);
      this.evidenceBlocks.set(ev.id, card);
      this.evidenceGroup.add(card);
    });
  }

  private syncScene() {
    const run = this.engine.activeRun;
    const isInNetwork =
      Boolean(run) &&
      (this.engine.phase === 'NETWORK_INFILTRATION' ||
        this.engine.phase === 'EXTRACTION');

    this.networkGroup.visible = isInNetwork;
    this.evidenceGroup.visible = isInNetwork;

    if (!run || !isInNetwork) {
      if (this.builtGraphKey) this.clearNetworkGraph();
      this.puzzleSocket.visible = false;
      this.hud.sync();
      return;
    }

    const graphKey = `${run.contractId}:${run.seed}`;
    if (this.builtGraphKey !== graphKey) {
      this.rebuildNetworkGraph();
    }

    // Check trace threshold sound cue
    const triggeredCount = run.consequences.filter((c) => c.triggered).length;
    if (triggeredCount > this.lastTraceThresholdCount) {
      this.lastTraceThresholdCount = triggeredCount;
      this.audio.playTraceAlert();
    }

    // Sync nodes
    for (const [id, block] of this.nodeBlocks.entries()) {
      const node = run.nodes[id];
      if (!node) continue;
      const access = this.engine.canAccessNode(id);
      block.syncState(node, run.activeNodeId === id, access.ok);
    }

    // Sync beams
    for (const rec of this.beamRecords) {
      const a = run.nodes[rec.fromId];
      const b = run.nodes[rec.toId];
      if (!a || !b) continue;
      if (rec.isHidden) {
        rec.beam.visible = Boolean(a.hiddenRevealed);
      } else {
        rec.beam.visible = a.discovered && b.discovered;
      }
      const isActive =
        run.activeNodeId === rec.fromId || run.activeNodeId === rec.toId;
      const isConcealed = a.concealed || b.concealed;
      rec.beam.setState(isActive, isConcealed);
    }

    // Sync evidence blocks
    for (const [evId, card] of this.evidenceBlocks.entries()) {
      const ev = run.evidence[evId];
      if (ev) {
        card.sync(ev, run.preservedEvidenceIds.includes(evId));
      }
    }

    // Sync active puzzle socket
    const activeNode = run.nodes[run.activeNodeId] ?? null;
    this.puzzleSocket.syncNode(
      activeNode,
      this.engine.activeChannelId,
      `${run.turnsElapsed}:${this.engine.lastFeedback}`
    );

    this.hud.sync();
  }

  update() {
    if (
      this.camLerpActive &&
      !xb.core.renderer?.xr?.isPresenting &&
      xb.core.camera
    ) {
      const dt = xb.getDeltaTime();
      this.camLerpTimer -= dt;
      xb.core.camera.position.lerp(this.camTargetPos, Math.min(1, dt * 8));
      xb.core.camera.lookAt(this.camTargetLook);
      if (
        this.camLerpTimer <= 0 ||
        xb.core.camera.position.distanceTo(this.camTargetPos) < 0.015
      ) {
        this.camLerpActive = false;
      }
    }
  }

  dispose() {
    this.unsubscribeEngine?.();
    this.clearNetworkGraph();
    this.audio.dispose();
    if (typeof window !== 'undefined') {
      window.removeEventListener('keydown', this.boundKeyDown);
      window.removeEventListener('pointerdown', this.boundUnlockAudio);
    }
    super.dispose();
  }
}
