import * as THREE from 'three';
import * as xb from 'xrblocks';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';

/**
 * Renders Duke Satoshi's Anglo-futurist London study:
 * London stone walls, oak floorboards, bronze trim, arched cyber-noir windows
 * overlooking a rainy City skyline, Mission Desk (with White Fedora, midnight-blue
 * tailoring bust, and Bitcoin-inspired signet ring), Evidence Wall, Equipment Cabinet,
 * and the central Spatial Network Table.
 */
export class StudyEnvironment extends xb.Script {
  private roomEnclosure = new THREE.Group();
  private skylineGroup = new THREE.Group();
  private furnitureGroup = new THREE.Group();
  private rainLines: THREE.LineSegments | null = null;
  private rainPositions: Float32Array | null = null;
  private networkRingMesh: THREE.Mesh | null = null;
  private envTexture: THREE.Texture | null = null;
  private disposables: Array<{dispose(): void}> = [];

  public readonly tableTopY = 0.78;
  public readonly tableCenter = new THREE.Vector3(0, 0.78, -1.15);

  init() {
    this.setupEnvironmentMap();
    this.setupLighting();
    this.buildRoomShell();
    this.buildLondonSkylineAndRain();
    this.buildSpatialNetworkTable();
    this.buildMissionDeskAndDukeAttire();
    this.buildEvidenceWall();
    this.buildEquipmentCabinet();

    this.add(this.roomEnclosure, this.skylineGroup, this.furnitureGroup);
  }

  setPassthroughMode(arPassthrough: boolean) {
    this.roomEnclosure.visible = !arPassthrough;
    this.skylineGroup.visible = !arPassthrough;
  }

  private setupEnvironmentMap() {
    const renderer = xb.core.renderer as unknown as THREE.WebGLRenderer;
    if (renderer && typeof THREE.PMREMGenerator === 'function') {
      try {
        const pmrem = new THREE.PMREMGenerator(renderer);
        const rt = pmrem.fromScene(new RoomEnvironment(), 0.04);
        this.envTexture = rt.texture;
        xb.core.scene.environment = this.envTexture;
        pmrem.dispose();
      } catch {
        // Fallback if WebGPU/serializer renderer
      }
    }
    xb.core.scene.fog = new THREE.FogExp2(0x070b14, 0.045);
  }

  private setupLighting() {
    // Cool rainy London skylight balanced with warm study interior
    const hemi = new THREE.HemisphereLight(0x88b4e6, 0x2a1f16, 1.45);
    this.add(hemi);

    // Warm desk/study key light
    const key = new THREE.DirectionalLight(0xffe0b2, 1.8);
    key.position.set(1.8, 3.2, 1.4);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.bias = -0.0005;
    this.add(key);

    // Cyan network hologram rim light
    const tableGlow = new THREE.PointLight(0x38bdf8, 1.8, 4.5, 1.6);
    tableGlow.position.set(0, 1.35, -1.15);
    this.add(tableGlow);

    // Warm brass banker's lamp accent at Mission Desk
    const deskLamp = new THREE.PointLight(0xfbbf24, 1.4, 3.0, 1.8);
    deskLamp.position.set(-1.35, 1.15, -0.95);
    this.add(deskLamp);
  }

  private createOakTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#2c1e16';
    ctx.fillRect(0, 0, 256, 256);
    for (let y = 0; y < 256; y += 32) {
      ctx.fillStyle = y % 64 === 0 ? '#35251b' : '#261912';
      ctx.fillRect(0, y, 256, 30);
      ctx.fillStyle = '#18100b';
      ctx.fillRect(0, y + 30, 256, 2);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(6, 6);
    this.disposables.push(tex);
    return tex;
  }

  private createStoneTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#1b2230';
    ctx.fillRect(0, 0, 256, 256);
    for (let row = 0; row < 8; row++) {
      const y = row * 32;
      const offset = (row % 2) * 32;
      for (let col = -1; col < 5; col++) {
        ctx.fillStyle =
          (row + col) % 2 === 0 ? '#202838' : '#19202d';
        ctx.fillRect(col * 64 + offset + 1, y + 1, 62, 30);
      }
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(4, 2);
    this.disposables.push(tex);
    return tex;
  }

  private buildRoomShell() {
    this.roomEnclosure.xb = {pointerEvents: 'none'};

    const oakMat = new THREE.MeshStandardMaterial({
      map: this.createOakTexture(),
      roughness: 0.72,
      metalness: 0.08,
    });
    const stoneMat = new THREE.MeshStandardMaterial({
      map: this.createStoneTexture(),
      roughness: 0.88,
      metalness: 0.05,
    });
    const midnightWallMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.8,
      metalness: 0.1,
    });
    const bronzeMat = new THREE.MeshStandardMaterial({
      color: 0xb08d57,
      roughness: 0.28,
      metalness: 0.85,
    });
    this.disposables.push(oakMat, stoneMat, midnightWallMat, bronzeMat);

    // Oak floor
    const floorGeo = new THREE.PlaneGeometry(8.5, 8.5);
    const floor = new THREE.Mesh(floorGeo, oakMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.disposables.push(floorGeo);
    this.roomEnclosure.add(floor);

    // Midnight-blue woven rug under the Spatial Network Table
    const rugGeo = new THREE.BoxGeometry(2.8, 0.015, 2.2);
    const rugMat = new THREE.MeshStandardMaterial({
      color: 0x111f3b,
      roughness: 0.94,
    });
    const rug = new THREE.Mesh(rugGeo, rugMat);
    rug.position.set(0, 0.008, -1.15);
    rug.receiveShadow = true;
    this.disposables.push(rugGeo, rugMat);
    this.roomEnclosure.add(rug);

    // Ceiling
    const ceilGeo = new THREE.PlaneGeometry(8.5, 8.5);
    const ceil = new THREE.Mesh(ceilGeo, midnightWallMat);
    ceil.position.y = 3.6;
    ceil.rotation.x = Math.PI / 2;
    this.disposables.push(ceilGeo);
    this.roomEnclosure.add(ceil);

    // Left & Right Stone Walls + Back wall behind user
    const sideWallGeo = new THREE.BoxGeometry(0.18, 3.6, 8.5);
    const leftWall = new THREE.Mesh(sideWallGeo, stoneMat);
    leftWall.position.set(-3.2, 1.8, -0.5);
    const rightWall = new THREE.Mesh(sideWallGeo, stoneMat);
    rightWall.position.set(3.2, 1.8, -0.5);

    const backWallGeo = new THREE.BoxGeometry(6.6, 3.6, 0.18);
    const backWall = new THREE.Mesh(backWallGeo, stoneMat);
    backWall.position.set(0, 1.8, 3.4);
    this.disposables.push(sideWallGeo, backWallGeo);
    this.roomEnclosure.add(leftWall, rightWall, backWall);

    // Front Window Wall (z = -3.4) with wide cyber-noir London view opening
    const lowerWallGeo = new THREE.BoxGeometry(6.6, 0.75, 0.22);
    const lowerFront = new THREE.Mesh(lowerWallGeo, stoneMat);
    lowerFront.position.set(0, 0.375, -3.4);

    const headerWallGeo = new THREE.BoxGeometry(6.6, 0.65, 0.22);
    const headerFront = new THREE.Mesh(headerWallGeo, stoneMat);
    headerFront.position.set(0, 3.275, -3.4);

    const pillarGeo = new THREE.BoxGeometry(0.55, 2.2, 0.24);
    const leftPillar = new THREE.Mesh(pillarGeo, stoneMat);
    leftPillar.position.set(-2.9, 1.85, -3.4);
    const midLeftPillar = new THREE.Mesh(pillarGeo, bronzeMat);
    midLeftPillar.scale.set(0.18, 1, 1);
    midLeftPillar.position.set(-1.1, 1.85, -3.4);
    const midRightPillar = new THREE.Mesh(pillarGeo, bronzeMat);
    midRightPillar.scale.set(0.18, 1, 1);
    midRightPillar.position.set(1.1, 1.85, -3.4);
    const rightPillar = new THREE.Mesh(pillarGeo, stoneMat);
    rightPillar.position.set(2.9, 1.85, -3.4);

    // Subtle rain-tinted glass pane
    const glassGeo = new THREE.PlaneGeometry(5.3, 2.2);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x7dd3fc,
      transparent: true,
      opacity: 0.08,
      roughness: 0.15,
      metalness: 0.1,
      depthWrite: false,
    });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(0, 1.85, -3.4);

    this.disposables.push(
      lowerWallGeo,
      headerWallGeo,
      pillarGeo,
      glassGeo,
      glassMat
    );
    this.roomEnclosure.add(
      lowerFront,
      headerFront,
      leftPillar,
      midLeftPillar,
      midRightPillar,
      rightPillar,
      glass
    );
  }

  private buildLondonSkylineAndRain() {
    this.skylineGroup.xb = {pointerEvents: 'none'};

    // Night sky dome behind window
    const skyGeo = new THREE.SphereGeometry(28, 24, 16);
    const skyMat = new THREE.MeshBasicMaterial({
      color: 0x050811,
      side: THREE.BackSide,
    });
    const sky = new THREE.Mesh(skyGeo, skyMat);
    this.disposables.push(skyGeo, skyMat);
    this.skylineGroup.add(sky);

    // Futuristic London skyline silhouettes (Gherkin/Shard-inspired geometric spires)
    const towerMat = new THREE.MeshStandardMaterial({
      color: 0x0b1220,
      roughness: 0.55,
      metalness: 0.4,
    });
    const cyanBeaconMat = new THREE.MeshBasicMaterial({color: 0x38bdf8});
    const goldBeaconMat = new THREE.MeshBasicMaterial({color: 0xeab308});
    this.disposables.push(towerMat, cyanBeaconMat, goldBeaconMat);

    const towerSpecs = [
      {x: -7.5, z: -13, w: 1.8, h: 9.5, beacon: 'cyan'},
      {x: -4.2, z: -11, w: 1.4, h: 12.2, beacon: 'gold'},
      {x: -1.4, z: -15, w: 2.1, h: 14.8, beacon: 'cyan'},
      {x: 1.6, z: -12, w: 1.5, h: 11.0, beacon: 'gold'},
      {x: 4.5, z: -14, w: 2.0, h: 13.4, beacon: 'cyan'},
      {x: 7.8, z: -12, w: 1.6, h: 8.8, beacon: 'gold'},
    ];

    const boxGeo = new THREE.BoxGeometry(1, 1, 1);
    const spireGeo = new THREE.ConeGeometry(0.28, 2.2, 4);
    const stripGeo = new THREE.BoxGeometry(0.08, 0.65, 0.08);
    this.disposables.push(boxGeo, spireGeo, stripGeo);

    for (const spec of towerSpecs) {
      const tower = new THREE.Group();
      tower.position.set(spec.x, -2.5, spec.z);

      const body = new THREE.Mesh(boxGeo, towerMat);
      body.scale.set(spec.w, spec.h, spec.w);
      body.position.y = spec.h / 2;
      tower.add(body);

      const spire = new THREE.Mesh(spireGeo, towerMat);
      spire.position.y = spec.h + 1.1;
      tower.add(spire);

      const beacon = new THREE.Mesh(
        stripGeo,
        spec.beacon === 'cyan' ? cyanBeaconMat : goldBeaconMat
      );
      beacon.position.set(0, spec.h + 2.3, 0);
      tower.add(beacon);

      this.skylineGroup.add(tower);
    }

    // Animated rain outside the study window
    const dropCount = 160;
    const positions = new Float32Array(dropCount * 6);
    for (let i = 0; i < dropCount; i++) {
      const x = (Math.random() - 0.5) * 9;
      const y = Math.random() * 6;
      const z = -4.2 - Math.random() * 3.5;
      positions[i * 6] = x;
      positions[i * 6 + 1] = y;
      positions[i * 6 + 2] = z;
      positions[i * 6 + 3] = x - 0.02;
      positions[i * 6 + 4] = y - 0.28;
      positions[i * 6 + 5] = z;
    }
    this.rainPositions = positions;
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const rainMat = new THREE.LineBasicMaterial({
      color: 0x7dd3fc,
      transparent: true,
      opacity: 0.36,
    });
    this.rainLines = new THREE.LineSegments(rainGeo, rainMat);
    this.disposables.push(rainGeo, rainMat);
    this.skylineGroup.add(this.rainLines);
  }

  private buildSpatialNetworkTable() {
    const table = new THREE.Group();
    table.position.set(0, 0, -1.15);
    table.xb = {pointerEvents: 'none'};

    const oakMat = new THREE.MeshStandardMaterial({
      color: 0x261a14,
      roughness: 0.45,
      metalness: 0.15,
    });
    const bronzeMat = new THREE.MeshStandardMaterial({
      color: 0xc49a45,
      roughness: 0.25,
      metalness: 0.88,
    });
    const topGlassMat = new THREE.MeshStandardMaterial({
      color: 0x071426,
      roughness: 0.18,
      metalness: 0.35,
    });
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.65,
    });
    this.disposables.push(oakMat, bronzeMat, topGlassMat, ringMat);

    // Pedestal base
    const baseGeo = new THREE.CylinderGeometry(0.42, 0.52, 0.08, 8);
    const base = new THREE.Mesh(baseGeo, bronzeMat);
    base.position.y = 0.04;

    // Column
    const colGeo = new THREE.CylinderGeometry(0.18, 0.24, 0.64, 8);
    const col = new THREE.Mesh(colGeo, oakMat);
    col.position.y = 0.4;

    // Octagonal oak table housing
    const slabGeo = new THREE.CylinderGeometry(0.76, 0.72, 0.07, 8);
    const slab = new THREE.Mesh(slabGeo, oakMat);
    slab.position.y = 0.745;

    // Brass rim bezel
    const rimGeo = new THREE.TorusGeometry(0.75, 0.018, 10, 8);
    const rim = new THREE.Mesh(rimGeo, bronzeMat);
    rim.rotation.x = Math.PI / 2;
    rim.rotation.z = Math.PI / 8;
    rim.position.y = 0.78;

    // Recessed cyan holo-slate surface
    const slateGeo = new THREE.CylinderGeometry(0.68, 0.68, 0.012, 8);
    const slate = new THREE.Mesh(slateGeo, topGlassMat);
    slate.position.y = 0.782;

    // Glowing compass ring
    const holoRingGeo = new THREE.RingGeometry(0.48, 0.5, 48);
    const holoRing = new THREE.Mesh(holoRingGeo, ringMat);
    holoRing.rotation.x = -Math.PI / 2;
    holoRing.position.y = 0.79;
    this.networkRingMesh = holoRing;

    this.disposables.push(
      baseGeo,
      colGeo,
      slabGeo,
      rimGeo,
      slateGeo,
      holoRingGeo
    );
    table.add(base, col, slab, rim, slate, holoRing);
    this.furnitureGroup.add(table);
  }

  private buildMissionDeskAndDukeAttire() {
    const deskGroup = new THREE.Group();
    deskGroup.position.set(-1.45, 0, -1.05);
    deskGroup.rotation.y = 0.42;
    deskGroup.xb = {pointerEvents: 'none'};

    const oakMat = new THREE.MeshStandardMaterial({
      color: 0x322017,
      roughness: 0.52,
      metalness: 0.1,
    });
    const brassMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      roughness: 0.22,
      metalness: 0.9,
    });
    const ivoryMat = new THREE.MeshStandardMaterial({
      color: 0xf4f1ea,
      roughness: 0.68,
      metalness: 0.05,
    });
    const midnightCoatMat = new THREE.MeshStandardMaterial({
      color: 0x101c36,
      roughness: 0.85,
      metalness: 0.05,
    });
    this.disposables.push(oakMat, brassMat, ivoryMat, midnightCoatMat);

    // Desk top + twin pedestals
    const topGeo = new THREE.BoxGeometry(1.1, 0.05, 0.58);
    const top = new THREE.Mesh(topGeo, oakMat);
    top.position.y = 0.76;

    const legGeo = new THREE.BoxGeometry(0.28, 0.74, 0.5);
    const leftPed = new THREE.Mesh(legGeo, oakMat);
    leftPed.position.set(-0.38, 0.37, 0);
    const rightPed = new THREE.Mesh(legGeo, oakMat);
    rightPed.position.set(0.38, 0.37, 0);

    // Duke Satoshi's signature White Fedora resting on the desk corner
    const fedora = new THREE.Group();
    fedora.position.set(-0.28, 0.79, 0.08);
    const brimGeo = new THREE.CylinderGeometry(0.15, 0.16, 0.012, 24);
    const brim = new THREE.Mesh(brimGeo, ivoryMat);
    const crownGeo = new THREE.CylinderGeometry(0.075, 0.092, 0.1, 20);
    const crown = new THREE.Mesh(crownGeo, ivoryMat);
    crown.position.y = 0.052;
    const bandGeo = new THREE.CylinderGeometry(0.094, 0.095, 0.022, 20);
    const band = new THREE.Mesh(bandGeo, midnightCoatMat);
    band.position.y = 0.018;
    fedora.add(brim, crown, band);

    // Bitcoin-inspired Gold Signet Ring beside the folio
    const ringBandGeo = new THREE.TorusGeometry(0.022, 0.005, 10, 24);
    const ringBand = new THREE.Mesh(ringBandGeo, brassMat);
    ringBand.position.set(-0.04, 0.792, 0.14);
    ringBand.rotation.x = Math.PI / 2;
    const signetFaceGeo = new THREE.CylinderGeometry(0.014, 0.014, 0.006, 6);
    const signetFace = new THREE.Mesh(signetFaceGeo, brassMat);
    signetFace.position.set(-0.04, 0.798, 0.12);

    // Warm Banker's Lamp
    const lampBaseGeo = new THREE.CylinderGeometry(0.07, 0.08, 0.025, 16);
    const lampBase = new THREE.Mesh(lampBaseGeo, brassMat);
    lampBase.position.set(0.32, 0.795, -0.14);
    const stemGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.26, 12);
    const stem = new THREE.Mesh(stemGeo, brassMat);
    stem.position.set(0.32, 0.92, -0.14);
    const shadeGeo = new THREE.CylinderGeometry(0.08, 0.11, 0.08, 12);
    const shadeMat = new THREE.MeshStandardMaterial({
      color: 0x0f766e,
      emissive: 0x115e59,
      emissiveIntensity: 0.65,
      roughness: 0.35,
    });
    const shade = new THREE.Mesh(shadeGeo, shadeMat);
    shade.position.set(0.32, 1.05, -0.1);
    shade.rotation.x = 0.35;

    // Midnight-blue tailored coat stand behind the desk
    const standPoleGeo = new THREE.CylinderGeometry(0.02, 0.03, 1.55, 12);
    const standPole = new THREE.Mesh(standPoleGeo, brassMat);
    standPole.position.set(-0.68, 0.775, -0.25);
    const coatShoulderGeo = new THREE.CylinderGeometry(0.14, 0.19, 0.55, 12);
    const coatShoulder = new THREE.Mesh(coatShoulderGeo, midnightCoatMat);
    coatShoulder.position.set(-0.68, 1.25, -0.25);
    const lapelGeo = new THREE.BoxGeometry(0.06, 0.34, 0.39);
    const lapel = new THREE.Mesh(lapelGeo, brassMat);
    lapel.position.set(-0.68, 1.32, -0.25);

    this.disposables.push(
      topGeo,
      legGeo,
      brimGeo,
      crownGeo,
      bandGeo,
      ringBandGeo,
      signetFaceGeo,
      lampBaseGeo,
      stemGeo,
      shadeGeo,
      shadeMat,
      standPoleGeo,
      coatShoulderGeo,
      lapelGeo
    );

    deskGroup.add(
      top,
      leftPed,
      rightPed,
      fedora,
      ringBand,
      signetFace,
      lampBase,
      stem,
      shade,
      standPole,
      coatShoulder,
      lapel
    );
    this.furnitureGroup.add(deskGroup);
  }

  private buildEvidenceWall() {
    const wallBoard = new THREE.Group();
    wallBoard.position.set(-2.95, 1.48, -1.35);
    wallBoard.rotation.y = Math.PI / 2;
    wallBoard.xb = {pointerEvents: 'none'};

    const frameGeo = new THREE.BoxGeometry(1.7, 1.05, 0.05);
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x8b6c39,
      metalness: 0.75,
      roughness: 0.32,
    });
    const backingGeo = new THREE.BoxGeometry(1.58, 0.94, 0.06);
    const backingMat = new THREE.MeshStandardMaterial({
      color: 0x0b1528,
      roughness: 0.85,
    });

    const frame = new THREE.Mesh(frameGeo, frameMat);
    const backing = new THREE.Mesh(backingGeo, backingMat);
    this.disposables.push(frameGeo, frameMat, backingGeo, backingMat);
    wallBoard.add(frame, backing);

    // Decorative dossier pins & glowing thread lines
    const cardGeo = new THREE.BoxGeometry(0.28, 0.2, 0.02);
    const cardMat = new THREE.MeshStandardMaterial({
      color: 0xf4f1ea,
      roughness: 0.65,
    });
    const pinGeo = new THREE.SphereGeometry(0.015, 10, 10);
    const pinMat = new THREE.MeshBasicMaterial({color: 0x38bdf8});
    this.disposables.push(cardGeo, cardMat, pinGeo, pinMat);

    const offsets = [
      [-0.45, 0.18],
      [0.0, 0.22],
      [0.46, 0.14],
      [-0.22, -0.2],
      [0.28, -0.18],
    ];
    for (const [ox, oy] of offsets) {
      const c = new THREE.Mesh(cardGeo, cardMat);
      c.position.set(ox, oy, 0.04);
      const p = new THREE.Mesh(pinGeo, pinMat);
      p.position.set(ox, oy + 0.08, 0.055);
      wallBoard.add(c, p);
    }

    this.furnitureGroup.add(wallBoard);
  }

  private buildEquipmentCabinet() {
    const cabinet = new THREE.Group();
    cabinet.position.set(1.55, 0, -1.15);
    cabinet.rotation.y = -0.45;
    cabinet.xb = {pointerEvents: 'none'};

    const woodMat = new THREE.MeshStandardMaterial({
      color: 0x241711,
      roughness: 0.5,
      metalness: 0.15,
    });
    const brassMat = new THREE.MeshStandardMaterial({
      color: 0xc49a45,
      roughness: 0.25,
      metalness: 0.88,
    });
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xbae6fd,
      transparent: true,
      opacity: 0.14,
      roughness: 0.1,
      depthWrite: false,
    });

    const baseGeo = new THREE.BoxGeometry(0.95, 0.72, 0.44);
    const base = new THREE.Mesh(baseGeo, woodMat);
    base.position.y = 0.36;

    const vitrineGeo = new THREE.BoxGeometry(0.9, 0.64, 0.4);
    const vitrine = new THREE.Mesh(vitrineGeo, glassMat);
    vitrine.position.y = 1.04;

    const capGeo = new THREE.BoxGeometry(0.98, 0.05, 0.46);
    const cap = new THREE.Mesh(capGeo, brassMat);
    cap.position.y = 1.38;

    // Physicalized miniature tool relics inside vitrine
    const relicGeo = new THREE.OctahedronGeometry(0.055, 0);
    const relicColors = [0x38bdf8, 0xeab308, 0xa78bfa, 0x2dd4bf, 0xfb7185];
    this.disposables.push(
      woodMat,
      brassMat,
      glassMat,
      baseGeo,
      vitrineGeo,
      capGeo,
      relicGeo
    );

    relicColors.forEach((hex, idx) => {
      const mat = new THREE.MeshStandardMaterial({
        color: hex,
        emissive: hex,
        emissiveIntensity: 0.35,
        roughness: 0.25,
        metalness: 0.6,
      });
      this.disposables.push(mat);
      const relic = new THREE.Mesh(relicGeo, mat);
      relic.position.set(-0.32 + idx * 0.16, 0.92, 0);
      cabinet.add(relic);
    });

    cabinet.add(base, vitrine, cap);
    this.furnitureGroup.add(cabinet);
  }

  update() {
    const dt = xb.getDeltaTime();
    if (this.networkRingMesh) {
      this.networkRingMesh.rotation.z += dt * 0.22;
    }
    if (this.rainPositions && this.rainLines && this.skylineGroup.visible) {
      const pos = this.rainPositions;
      for (let i = 0; i < pos.length; i += 6) {
        const dropSpeed = dt * 6.5;
        pos[i + 1] -= dropSpeed;
        pos[i + 4] -= dropSpeed;
        if (pos[i + 1] < 0) {
          const resetY = 5.5 + Math.random() * 0.8;
          pos[i + 1] = resetY;
          pos[i + 4] = resetY - 0.28;
        }
      }
      this.rainLines.geometry.attributes.position.needsUpdate = true;
    }
  }

  dispose() {
    for (const d of this.disposables) d.dispose();
    this.envTexture?.dispose();
    super.dispose();
  }
}
