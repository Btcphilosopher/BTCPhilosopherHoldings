package com.example.psos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.PsosCosmicBlue
import com.example.ui.theme.PsosDeepNavy
import com.example.ui.theme.PsosVoidBlack

@Composable
fun AtmosphericBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PsosVoidBlack)
    ) {
        // Deep radial gradients mimicking the Atmospheric / Immersive Media theme
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Top cosmic glow (radial gradient at 50% width, 25% height)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        PsosCosmicBlue.copy(alpha = 0.55f),
                        PsosCosmicBlue.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = Offset(canvasWidth * 0.5f, canvasHeight * 0.22f),
                    radius = canvasWidth * 0.85f
                )
            )

            // Secondary deep navy nebula at bottom left
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        PsosDeepNavy.copy(alpha = 0.60f),
                        Color.Transparent
                    ),
                    center = Offset(canvasWidth * 0.15f, canvasHeight * 0.78f),
                    radius = canvasWidth * 0.75f
                )
            )

            // Subtle cybernetic architectural coordinates
            val lineAlpha = 0.04f
            drawLine(
                color = Color.White.copy(alpha = lineAlpha),
                start = Offset(0f, canvasHeight * 0.45f),
                end = Offset(canvasWidth, canvasHeight * 0.45f),
                strokeWidth = 1f
            )
            drawLine(
                color = Color.White.copy(alpha = lineAlpha),
                start = Offset(canvasWidth * 0.75f, 0f),
                end = Offset(canvasWidth * 0.75f, canvasHeight),
                strokeWidth = 1f
            )
        }

        content()
    }
}
