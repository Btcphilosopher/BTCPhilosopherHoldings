package com.example.psos.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.psos.model.SystemTab
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosTextSecondary

@Composable
fun PsosHeader(
    state: PlayStationState,
    onTabSelected: (SystemTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        // Status Bar Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Kernel Status
            Column {
                Text(
                    text = "PSOS-X KERNEL",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = PsosTextDim
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .shadow(8.dp, CircleShape, spotColor = PsosElectricCyan)
                            .clip(CircleShape)
                            .background(PsosElectricCyan.copy(alpha = glowAlpha))
                    )
                    Text(
                        text = "SYSTEM STABLE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 0.5.sp,
                        color = PsosTextSecondary
                    )
                }
            }

            // Right: Real-time Telemetry & Dynamic Clock
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${state.telemetry.pingMs}ms",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = PsosTextSecondary
                    )
                    Text(
                        text = "PING",
                        fontSize = 8.sp,
                        letterSpacing = 1.sp,
                        color = PsosTextDim
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${state.telemetry.controllerBattery}%",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = PsosTextSecondary
                    )
                    Text(
                        text = "BATTERY",
                        fontSize = 8.sp,
                        letterSpacing = 1.sp,
                        color = PsosTextDim
                    )
                }

                Text(
                    text = state.liveClockString,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Light,
                    fontFamily = FontFamily.Monospace,
                    color = PsosTextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // System Category Navigation Tabs (Scrollable bar)
        val tabs = listOf(
            SystemTab.HOME to "HOME",
            SystemTab.WORLD to "GAME WORLD",
            SystemTab.ACTIVITIES to "ACTIVITIES",
            SystemTab.TELEMETRY to "DIGITAL TWIN",
            SystemTab.TROPHIES to "TROPHIES",
            SystemTab.CONTINUITY to "CONTINUITY"
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            tabs.forEach { (tab, label) ->
                val isSelected = state.activeTab == tab
                val bgColor by animateColorAsState(
                    targetValue = if (isSelected) PsosElectricCyan.copy(alpha = 0.12f) else Color.Transparent,
                    label = "tabBg"
                )
                val borderColor by animateColorAsState(
                    targetValue = if (isSelected) PsosElectricCyan.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.07f),
                    label = "tabBorder"
                )
                val textColor by animateColorAsState(
                    targetValue = if (isSelected) PsosElectricCyan else PsosTextMuted,
                    label = "tabText"
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(bgColor)
                        .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        letterSpacing = 1.sp,
                        color = textColor
                    )
                }
            }
        }
    }
}
