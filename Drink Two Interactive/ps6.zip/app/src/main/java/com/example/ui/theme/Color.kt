package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// PSOS-X Atmospheric / Immersive Media Color Palette
val PsosVoidBlack = Color(0xFF040508)
val PsosDeepNavy = Color(0xFF0D1117)
val PsosCosmicBlue = Color(0xFF1A2B5F)
val PsosElectricCyan = Color(0xFF00F0FF)
val PsosCyanGlow = Color(0x6600F0FF)
val PsosCyanSubtle = Color(0x1A00F0FF)
val PsosTrophyGold = Color(0xFFFFD700)
val PsosTrophySilver = Color(0xFFC0C0C0)
val PsosTrophyBronze = Color(0xFFCD7F32)
val PsosTrophyPlatinum = Color(0xFF4EE2EC)

val PsosTextPrimary = Color(0xFFFFFFFF)
val PsosTextSecondary = Color(0xFFE0E0E0)
val PsosTextMuted = Color(0xFF9CA3AF)
val PsosTextDim = Color(0xFF6A7280)

val PsosCardBg = Color(0x12FFFFFF)
val PsosCardBorder = Color(0x1FFFFFFF)
val PsosCardActive = Color(0x24FFFFFF)
val PsosOverlayBg = Color(0xE6080C14)
val PsosSuccess = Color(0xFF10B981)
val PsosWarning = Color(0xFFF59E0B)
val PsosDanger = Color(0xFFEF4444)
