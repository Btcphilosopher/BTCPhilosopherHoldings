package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val PsosColorScheme = darkColorScheme(
    primary = PsosElectricCyan,
    onPrimary = PsosVoidBlack,
    primaryContainer = PsosCosmicBlue,
    onPrimaryContainer = PsosElectricCyan,
    secondary = PsosTextSecondary,
    onSecondary = PsosVoidBlack,
    background = PsosVoidBlack,
    onBackground = PsosTextPrimary,
    surface = PsosDeepNavy,
    onSurface = PsosTextPrimary,
    surfaceVariant = PsosCardBg,
    onSurfaceVariant = PsosTextMuted,
    outline = PsosCardBorder,
    error = PsosDanger,
    onError = PsosTextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PsosColorScheme,
        typography = Typography,
        content = content
    )
}

