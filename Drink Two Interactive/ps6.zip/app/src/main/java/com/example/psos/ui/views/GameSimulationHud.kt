package com.example.psos.ui.views

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosOverlayBg
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosVoidBlack

@Composable
fun GameSimulationHud(
    state: PlayStationState,
    onDismiss: () -> Unit,
    onSuspend: () -> Unit,
    onCapture: () -> Unit,
    onUnlockTrophy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGame = state.games.find { it.gameId == state.activeGameId }
    val activeActivity = activeGame?.activities?.find { it.id == state.activeActivityId } ?: activeGame?.activities?.firstOrNull()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF030509))
    ) {
        // Sci-Fi Reticle & Viewport Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f

            // Crosshair
            drawCircle(
                color = PsosElectricCyan.copy(alpha = 0.25f),
                radius = 28.dp.toPx(),
                center = Offset(cx, cy),
                style = Stroke(width = 1.dp.toPx())
            )
            drawLine(
                color = PsosElectricCyan.copy(alpha = 0.4f),
                start = Offset(cx - 36.dp.toPx(), cy),
                end = Offset(cx - 12.dp.toPx(), cy),
                strokeWidth = 1.5.dp.toPx()
            )
            drawLine(
                color = PsosElectricCyan.copy(alpha = 0.4f),
                start = Offset(cx + 12.dp.toPx(), cy),
                end = Offset(cx + 36.dp.toPx(), cy),
                strokeWidth = 1.5.dp.toPx()
            )
            drawLine(
                color = PsosElectricCyan.copy(alpha = 0.4f),
                start = Offset(cx, cy - 36.dp.toPx()),
                end = Offset(cx, cy - 12.dp.toPx()),
                strokeWidth = 1.5.dp.toPx()
            )
            drawLine(
                color = PsosElectricCyan.copy(alpha = 0.4f),
                start = Offset(cx, cy + 12.dp.toPx()),
                end = Offset(cx, cy + 36.dp.toPx()),
                strokeWidth = 1.5.dp.toPx()
            )

            // Dynamic boundary indicators
            drawCircle(
                color = Color.White.copy(alpha = 0.05f),
                radius = size.width * 0.45f,
                center = Offset(cx, cy),
                style = Stroke(width = 1f)
            )
        }

        // Top In-Game Telemetry & Overlay bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Red))
                    Text(
                        text = "DIRECT APU EXECUTION • 4K 120Hz PSSR",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = activeGame?.title ?: "ASTRAL FRONTIER",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraLight,
                    letterSpacing = 1.sp,
                    color = PsosTextPrimary
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = onCapture,
                    modifier = Modifier.size(36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f))
                ) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = "Capture", tint = Color.White, modifier = Modifier.size(16.dp))
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f))
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Exit HUD", tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }

        // Active Mission Objective Tracker (Top Left Floating)
        Box(
            modifier = Modifier
                .padding(start = 20.dp, top = 90.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = 0.65f))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Column {
                Text(
                    text = "ACTIVE OBJECTIVE",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = PsosElectricCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = activeActivity?.title ?: "Station Zero Infiltration",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = PsosTextPrimary
                )
                Text(
                    text = activeActivity?.location ?: "Sector 7 Outer Rim",
                    fontSize = 10.sp,
                    color = PsosTextDim
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LinearProgressIndicator(
                        progress = { 0.72f },
                        modifier = Modifier.width(100.dp).height(3.dp).clip(CircleShape),
                        color = PsosElectricCyan,
                        trackColor = Color.White.copy(alpha = 0.15f)
                    )
                    Text("72%", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = PsosTextPrimary)
                }
            }
        }

        // Squad Presence (Top Right Floating)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 20.dp, top = 90.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = 0.65f))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(text = "SQUAD VOIP", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = PsosTextDim)
                SquadMemberRow(name = "Tom_Ahyx", status = "SHIELD 100%")
                SquadMemberRow(name = "James_Valkyrie", status = "SHIELD 85%")
            }
        }

        // Bottom HUD Bar (Health, Plasma Ammo & OS Return CTA)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                // Shield & HP bars
                Column {
                    Text("KINETIC SHIELD", fontSize = 8.sp, letterSpacing = 1.sp, color = PsosElectricCyan)
                    Box(modifier = Modifier.width(130.dp).height(6.dp).clip(CircleShape).background(PsosElectricCyan))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("HULL INTEGRITY", fontSize = 8.sp, letterSpacing = 1.sp, color = Color.White.copy(alpha = 0.6f))
                    Box(modifier = Modifier.width(130.dp).height(6.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.8f)))
                }

                // Plasma rounds
                Column(horizontalAlignment = Alignment.End) {
                    Text("PLASMA BATTERY", fontSize = 8.sp, letterSpacing = 1.sp, color = PsosTextDim)
                    Text("184 / 400", fontSize = 22.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Light, color = PsosTextPrimary)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // OS Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onSuspend,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f), contentColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Icon(imageVector = Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SUSPEND TO OS", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = PsosElectricCyan, contentColor = PsosVoidBlack),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Text("PRESS PS BUTTON", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }
    }
}

@Composable
private fun SquadMemberRow(name: String, status: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(PsosElectricCyan))
        Column {
            Text(text = name, fontSize = 10.sp, color = PsosTextPrimary)
            Text(text = status, fontSize = 8.sp, color = PsosElectricCyan)
        }
    }
}
