package com.example.psos.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.psos.model.ActivityItem
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosCyanSubtle
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosTrophyGold
import com.example.ui.theme.PsosVoidBlack

@Composable
fun ActivitiesView(
    state: PlayStationState,
    onLaunchActivity: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGame = state.games.find { it.gameId == state.activeGameId } ?: state.games.first()
    val allActivities = activeGame.activities

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Text(
            text = "PLAYSTATION ACTIVITIES ENGINE",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = PsosElectricCyan
        )
        Text(
            text = "Instant Ingress Cards",
            fontSize = 24.sp,
            fontWeight = FontWeight.Light,
            color = PsosTextPrimary
        )
        Text(
            text = "Jump directly into game objectives, boss encounters, and co-op raids without wading through title screens.",
            fontSize = 12.sp,
            color = PsosTextMuted,
            modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
        )

        allActivities.forEach { activity ->
            val isCurrentActive = state.activeActivityId == activity.id

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isCurrentActive) PsosCyanSubtle else PsosCardBg)
                    .border(
                        1.dp,
                        if (isCurrentActive) PsosElectricCyan.copy(alpha = 0.6f) else PsosCardBorder,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.White.copy(alpha = 0.08f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${activity.difficulty.uppercase()} DIFFICULTY",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = if (activity.difficulty == "Legendary") PsosTrophyGold else PsosElectricCyan
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = PsosTextDim,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "~${activity.estimatedMinutes} MIN",
                                fontSize = 10.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color = PsosTextDim
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = activity.title,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = PsosTextPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = activity.description,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = PsosTextMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Location & Rewards metadata
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "LOCATION",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = PsosTextDim
                            )
                            Text(
                                text = activity.location,
                                fontSize = 11.sp,
                                color = PsosTextPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "REWARD",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = PsosTextDim
                            )
                            Text(
                                text = activity.reward,
                                fontSize = 11.sp,
                                color = PsosElectricCyan
                            )
                        }
                    }

                    if (activity.friendsInSquad > 0) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = PsosElectricCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${activity.friendsInSquad} squad members waiting in this activity",
                                fontSize = 10.sp,
                                color = PsosElectricCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Direct "PLAY NOW" Button
                    Button(
                        onClick = { onLaunchActivity(activeGame.gameId, activity.id) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCurrentActive) Color.White else PsosElectricCyan,
                            contentColor = PsosVoidBlack
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isCurrentActive) "CONTINUE THIS ACTIVITY" else "PLAY NOW",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
