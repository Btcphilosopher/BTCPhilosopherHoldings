package com.example.psos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.GameSessionStatus
import com.example.psos.kernel.PlayStationState
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosCyanSubtle
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosOverlayBg
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosVoidBlack

@Composable
fun QuickControlCentre(
    state: PlayStationState,
    onClose: () -> Unit,
    onResumeGame: () -> Unit,
    onSuspendGame: () -> Unit,
    onCaptureScreenshot: () -> Unit,
    onToggleMic: () -> Unit,
    onSetAudioBalance: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGame = state.games.find { it.gameId == state.activeGameId }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable(onClick = onClose),
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(PsosOverlayBg)
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clickable(enabled = false) { }
                .padding(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(PsosElectricCyan))
                        Text(
                            text = "CONTROL CENTRE",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = PsosTextPrimary
                        )
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(32.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f))
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = PsosTextPrimary, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Active Game State
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(PsosCyanSubtle)
                        .border(1.dp, PsosElectricCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeGame?.title ?: "ASTRAL FRONTIER",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = PsosTextPrimary
                            )
                            Text(
                                text = if (state.sessionStatus == GameSessionStatus.PLAYING) "Session Active • 34 min elapsed" else "Preserved in NVMe Memory",
                                fontSize = 11.sp,
                                color = PsosElectricCyan
                            )
                        }

                        if (state.sessionStatus == GameSessionStatus.PLAYING) {
                            Button(
                                onClick = onSuspendGame,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f), contentColor = PsosTextPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("SUSPEND", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Button(
                                onClick = onResumeGame,
                                colors = ButtonDefaults.buttonColors(containerColor = PsosElectricCyan, contentColor = PsosVoidBlack),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("RESUME", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Action Strip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Screenshot CTA
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.CameraAlt,
                        label = "INSTANT 4K",
                        sub = "Capture Media",
                        onClick = onCaptureScreenshot
                    )

                    // Mic Mute CTA
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        icon = if (state.isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        label = if (state.isMicMuted) "MIC MUTED" else "MIC OPEN",
                        sub = "Tempest 3D",
                        iconColor = if (state.isMicMuted) Color.Red else PsosElectricCyan,
                        onClick = onToggleMic
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Real-time Mini Telemetry Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(PsosCardBg)
                        .border(1.dp, PsosCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("FRAME RATE", fontSize = 8.sp, color = PsosTextDim)
                        Text("${state.telemetry.fps} FPS", fontSize = 13.sp, fontFamily = FontFamily.Monospace, color = PsosTextPrimary)
                    }
                    Column {
                        Text("LATENCY", fontSize = 8.sp, color = PsosTextDim)
                        Text("${state.telemetry.pingMs} ms", fontSize = 13.sp, fontFamily = FontFamily.Monospace, color = PsosTextPrimary)
                    }
                    Column {
                        Text("TEMPERATURE", fontSize = 8.sp, color = PsosTextDim)
                        Text("${state.telemetry.tempCelsius}°C", fontSize = 13.sp, fontFamily = FontFamily.Monospace, color = PsosTextPrimary)
                    }
                    Column {
                        Text("DUALSENSE", fontSize = 8.sp, color = PsosTextDim)
                        Text("${state.telemetry.controllerBattery}%", fontSize = 13.sp, fontFamily = FontFamily.Monospace, color = PsosElectricCyan)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionCard(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    sub: String,
    iconColor: Color = PsosElectricCyan,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(PsosCardBg)
            .border(1.dp, PsosCardBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
            Column {
                Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PsosTextPrimary)
                Text(text = sub, fontSize = 9.sp, color = PsosTextDim)
            }
        }
    }
}
