package com.example.psos.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationKernel
import com.example.psos.model.BottomNavSlot
import com.example.psos.model.SystemTab
import com.example.psos.ui.components.AtmosphericBackground
import com.example.psos.ui.components.PsosBottomNav
import com.example.psos.ui.components.PsosHeader
import com.example.psos.ui.components.QuickControlCentre
import com.example.psos.ui.views.ActivitiesView
import com.example.psos.ui.views.BottomNavModalOverlay
import com.example.psos.ui.views.ContinuityView
import com.example.psos.ui.views.GameSimulationHud
import com.example.psos.ui.views.HomeView
import com.example.psos.ui.views.TelemetryView
import com.example.psos.ui.views.TrophiesView
import com.example.psos.ui.views.WorldMapView
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosOverlayBg
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextPrimary
import kotlinx.coroutines.delay

@Composable
fun PlayStationOsScreen(
    kernel: PlayStationKernel = remember { PlayStationKernel() },
    modifier: Modifier = Modifier
) {
    val state by kernel.state.collectAsState()

    // Auto dismiss notification toast after 4s
    LaunchedEffect(state.latestToast) {
        if (state.latestToast != null) {
            delay(4000)
            kernel.clearToast()
        }
    }

    AtmosphericBackground(modifier = modifier) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                PsosHeader(
                    state = state,
                    onTabSelected = { kernel.setActiveTab(it) },
                    modifier = Modifier.statusBarsPadding()
                )
            },
            bottomBar = {
                PsosBottomNav(
                    activeModal = state.activeNavModal,
                    isControlCentreOpen = state.isControlCentreOpen,
                    onSlotClicked = { kernel.openBottomNavModal(it) }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Crossfade between top tabs
                Crossfade(targetState = state.activeTab, label = "tabContent") { tab ->
                    when (tab) {
                        SystemTab.HOME -> HomeView(
                            state = state,
                            onResumeActivity = { kernel.resumeActiveGame() },
                            onViewWorld = { kernel.setActiveTab(SystemTab.WORLD) },
                            onLaunchActivity = { gId, aId -> kernel.launchActivity(gId, aId) }
                        )
                        SystemTab.WORLD -> WorldMapView(
                            state = state,
                            onLaunchActivity = { gId, aId -> kernel.launchActivity(gId, aId) }
                        )
                        SystemTab.ACTIVITIES -> ActivitiesView(
                            state = state,
                            onLaunchActivity = { gId, aId -> kernel.launchActivity(gId, aId) }
                        )
                        SystemTab.TELEMETRY -> TelemetryView(
                            state = state,
                            onApplyScenario = { kernel.applyChaosScenario(it) }
                        )
                        SystemTab.TROPHIES -> TrophiesView(
                            state = state,
                            onUnlockTrophy = { kernel.unlockDemoTrophy() }
                        )
                        SystemTab.CONTINUITY -> ContinuityView(
                            state = state,
                            onHandoff = { kernel.triggerCloudHandoff(it) }
                        )
                    }
                }

                // Notification Toast Floating Banner
                AnimatedVisibility(
                    visible = state.latestToast != null,
                    enter = slideInVertically { -it } + fadeIn(),
                    exit = slideOutVertically { -it } + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 24.dp, vertical = 8.dp)
                ) {
                    state.latestToast?.let { toastText ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(12.dp, RoundedCornerShape(12.dp), spotColor = PsosElectricCyan)
                                .clip(RoundedCornerShape(12.dp))
                                .background(PsosOverlayBg)
                                .border(1.dp, PsosElectricCyan.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                .clickable { kernel.clearToast() }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(PsosElectricCyan)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = toastText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = PsosTextPrimary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Navigation Modals (Square, Cross, Circle, Triangle)
        state.activeNavModal?.let { modal ->
            BottomNavModalOverlay(
                slot = modal,
                state = state,
                onClose = { kernel.closeNavModal() },
                onSelectGame = { gameId ->
                    kernel.launchActivity(gameId, "act_station_zero")
                    kernel.closeNavModal()
                },
                onStartDownload = { kernel.startDownload(it) },
                onToggleMic = { kernel.toggleMic() },
                onSetAudioBalance = { kernel.setAudioBalance(it) },
                onSendAiPrompt = { kernel.sendAiPrompt(it) }
            )
        }

        // Quick Control Centre (Center PS Button)
        if (state.isControlCentreOpen) {
            QuickControlCentre(
                state = state,
                onClose = { kernel.toggleControlCentre() },
                onResumeGame = { kernel.resumeActiveGame() },
                onSuspendGame = { kernel.suspendActiveGame() },
                onCaptureScreenshot = { kernel.triggerInstantScreenshot() },
                onToggleMic = { kernel.toggleMic() },
                onSetAudioBalance = { kernel.setAudioBalance(it) }
            )
        }

        // Game Simulation HUD (Triggered when actively playing an activity)
        if (state.isGameSimulationHudVisible) {
            GameSimulationHud(
                state = state,
                onDismiss = { kernel.dismissGameHud() },
                onSuspend = { kernel.suspendActiveGame() },
                onCapture = { kernel.triggerInstantScreenshot() },
                onUnlockTrophy = { kernel.unlockDemoTrophy() }
            )
        }
    }
}
