package com.example.psos.kernel

import com.example.psos.model.ActivityItem
import com.example.psos.model.AiMessage
import com.example.psos.model.BottomNavSlot
import com.example.psos.model.CaptureMedia
import com.example.psos.model.DigitalTwinTelemetry
import com.example.psos.model.DownloadItem
import com.example.psos.model.FriendProfile
import com.example.psos.model.GameObject
import com.example.psos.model.SystemNotification
import com.example.psos.model.SystemTab
import com.example.psos.model.TrophyItem
import com.example.psos.model.WorldRegion
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed class PlayStationEvent {
    data class GameLaunched(val gameId: String, val activityId: String?) : PlayStationEvent()
    data class GameSuspended(val gameId: String) : PlayStationEvent()
    data class GameResumed(val gameId: String) : PlayStationEvent()
    data class TrophyUnlocked(val title: String, val rarity: String, val xp: Int) : PlayStationEvent()
    data class DownloadUpdated(val gameId: String, val progress: Int) : PlayStationEvent()
    data class PartyUpdated(val inParty: Boolean) : PlayStationEvent()
    data class ScreenshotCaptured(val fileName: String) : PlayStationEvent()
    data class CloudHandoffTriggered(val targetDevice: String) : PlayStationEvent()
    data class ChaosScenarioApplied(val scenarioName: String) : PlayStationEvent()
}

enum class GameSessionStatus {
    IDLE,
    LAUNCHING,
    PLAYING,
    SUSPENDED,
    STREAMING
}

data class PlayStationState(
    val activeTab: SystemTab = SystemTab.HOME,
    val activeNavModal: BottomNavSlot? = null,
    val isControlCentreOpen: Boolean = false,
    val isGameSimulationHudVisible: Boolean = false,
    val sessionStatus: GameSessionStatus = GameSessionStatus.PLAYING,
    val sessionPlayTimeMinutes: Int = 34,
    val activeGameId: String = "astral_frontier",
    val activeActivityId: String = "act_station_zero",
    val games: List<GameObject> = emptyList(),
    val downloads: List<DownloadItem> = emptyList(),
    val friends: List<FriendProfile> = emptyList(),
    val trophies: List<TrophyItem> = emptyList(),
    val captures: List<CaptureMedia> = emptyList(),
    val notifications: List<SystemNotification> = emptyList(),
    val aiMessages: List<AiMessage> = emptyList(),
    val telemetry: DigitalTwinTelemetry = DigitalTwinTelemetry(),
    val isPartyActive: Boolean = true,
    val isMicMuted: Boolean = false,
    val gameChatAudioBalance: Float = 0.65f, // 65% game, 35% chat
    val activeDevice: String = "PS5 Pro Console",
    val isCloudStreamActive: Boolean = false,
    val liveClockString: String = "22:42",
    val latestToast: String? = null
)

class PlayStationKernel(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main + Job())
) {
    private val _events = MutableSharedFlow<PlayStationEvent>(extraBufferCapacity = 64)
    val events = _events.asSharedFlow()

    private val _state = MutableStateFlow(createInitialState())
    val state = _state.asStateFlow()

    init {
        startKernelClockAndSimulation()
    }

    private fun startKernelClockAndSimulation() {
        scope.launch {
            val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
            while (isActive) {
                val nowStr = formatter.format(Date())
                _state.update { current ->
                    // live clock and slight natural telemetry fluctuations for realism
                    val currentTel = current.telemetry
                    val jitteredFps = if (current.sessionStatus == GameSessionStatus.PLAYING) {
                        59.4f + (Math.random().toFloat() * 0.8f)
                    } else 60.0f
                    val jitteredPing = 17 + (Math.random() * 3).toInt()

                    current.copy(
                        liveClockString = nowStr,
                        telemetry = currentTel.copy(
                            fps = (jitteredFps * 10).toInt() / 10f,
                            pingMs = jitteredPing
                        )
                    )
                }

                // download progress simulation
                progressDownloads()
                delay(2000)
            }
        }
    }

    private fun progressDownloads() {
        _state.update { current ->
            val updatedDownloads = current.downloads.map { dl ->
                if (dl.status == "Downloading" && dl.progressPercent < 100) {
                    val next = (dl.progressPercent + 3).coerceAtMost(100)
                    val status = if (next >= 100) "Completed" else "Downloading"
                    if (next >= 100) {
                        emitNotification("Download Complete", "${dl.title} is ready to play", "Download")
                    }
                    dl.copy(
                        progressPercent = next,
                        downloadedGb = (dl.totalGb * next / 100.0 * 10).toInt() / 10.0,
                        status = status
                    )
                } else dl
            }
            current.copy(downloads = updatedDownloads)
        }
    }

    // --- State mutations & Actions ---

    fun setActiveTab(tab: SystemTab) {
        _state.update { it.copy(activeTab = tab, activeNavModal = null) }
    }

    fun openBottomNavModal(slot: BottomNavSlot) {
        if (slot == BottomNavSlot.CONTROL) {
            toggleControlCentre()
        } else {
            _state.update { current ->
                if (current.activeNavModal == slot) current.copy(activeNavModal = null)
                else current.copy(activeNavModal = slot)
            }
        }
    }

    fun closeNavModal() {
        _state.update { it.copy(activeNavModal = null) }
    }

    fun toggleControlCentre() {
        _state.update { it.copy(isControlCentreOpen = !it.isControlCentreOpen) }
    }

    fun launchActivity(gameId: String, activityId: String) {
        _state.update {
            it.copy(
                activeGameId = gameId,
                activeActivityId = activityId,
                sessionStatus = GameSessionStatus.PLAYING,
                isGameSimulationHudVisible = true,
                isControlCentreOpen = false,
                activeNavModal = null
            )
        }
        scope.launch {
            _events.emit(PlayStationEvent.GameLaunched(gameId, activityId))
            val game = _state.value.games.find { it.gameId == gameId }
            val activity = game?.activities?.find { it.id == activityId }
            emitNotification(
                "Game Session Initialized",
                "Launched ${game?.title ?: "Game"}: ${activity?.title ?: "Main Story"}",
                "System"
            )
        }
    }

    fun suspendActiveGame() {
        _state.update {
            it.copy(
                sessionStatus = GameSessionStatus.SUSPENDED,
                isGameSimulationHudVisible = false
            )
        }
        scope.launch {
            _events.emit(PlayStationEvent.GameSuspended(_state.value.activeGameId))
            emitNotification("Game Suspended", "Active state preserved in NVMe high-speed cache", "System")
        }
    }

    fun resumeActiveGame() {
        _state.update {
            it.copy(
                sessionStatus = GameSessionStatus.PLAYING,
                isGameSimulationHudVisible = true,
                isControlCentreOpen = false
            )
        }
        scope.launch {
            _events.emit(PlayStationEvent.GameResumed(_state.value.activeGameId))
        }
    }

    fun dismissGameHud() {
        _state.update { it.copy(isGameSimulationHudVisible = false) }
    }

    fun toggleMic() {
        _state.update { it.copy(isMicMuted = !it.isMicMuted) }
    }

    fun setAudioBalance(balance: Float) {
        _state.update { it.copy(gameChatAudioBalance = balance) }
    }

    fun triggerInstantScreenshot() {
        val fileName = "CAPTURE_PSOS_${System.currentTimeMillis() % 10000}.PNG"
        val activeGame = _state.value.games.find { it.gameId == _state.value.activeGameId }?.title ?: "Astral Frontier"
        val newCapture = CaptureMedia(
            id = UUID.randomUUID().toString(),
            title = "$activeGame - Station Zero Infiltration",
            type = "Screenshot",
            timestamp = "Just Now",
            sizeMb = "14.2 MB",
            gameTitle = activeGame
        )
        _state.update {
            it.copy(captures = listOf(newCapture) + it.captures)
        }
        scope.launch {
            _events.emit(PlayStationEvent.ScreenshotCaptured(fileName))
            emitNotification("Screenshot Captured", "Saved to Media Gallery (3840x2160 HDR)", "System")
        }
    }

    fun unlockDemoTrophy() {
        val trophyTitle = "Void Walker"
        val trophyRarity = "Gold"
        _state.update { current ->
            val updatedTrophies = current.trophies.map {
                if (it.title == trophyTitle) it.copy(isUnlocked = true, unlockedDate = "Just now") else it
            }
            current.copy(trophies = updatedTrophies)
        }
        scope.launch {
            _events.emit(PlayStationEvent.TrophyUnlocked(trophyTitle, trophyRarity, 300))
            emitNotification("Trophy Unlocked! \uD83C\uDFC6", "$trophyTitle ($trophyRarity)", "Trophy")
        }
    }

    fun triggerCloudHandoff(device: String) {
        _state.update {
            it.copy(
                activeDevice = device,
                isCloudStreamActive = device != "PS5 Pro Console"
            )
        }
        scope.launch {
            _events.emit(PlayStationEvent.CloudHandoffTriggered(device))
            emitNotification(
                "Continuity Handoff Complete",
                "Seamless stream transferred to $device with 0ms save delta",
                "Cloud"
            )
        }
    }

    fun startDownload(game: GameObject) {
        val already = _state.value.downloads.find { it.gameId == game.gameId }
        if (already != null) {
            emitNotification("Download Status", "${game.title} is already in the download queue", "Download")
            return
        }
        val newItem = DownloadItem(
            id = UUID.randomUUID().toString(),
            gameId = game.gameId,
            title = game.title,
            progressPercent = 4,
            speedMbps = 642,
            totalGb = game.installSizeGb.toDouble(),
            downloadedGb = (game.installSizeGb * 0.04 * 10).toInt() / 10.0,
            status = "Downloading"
        )
        _state.update {
            it.copy(downloads = listOf(newItem) + it.downloads)
        }
        emitNotification("Download Started", "Prioritizing high-speed NVMe decompression", "Download")
    }

    fun applyChaosScenario(scenario: String) {
        _state.update { current ->
            when (scenario) {
                "Heavy Gaming 4K" -> current.copy(
                    telemetry = current.telemetry.copy(
                        gpuLoad = 96,
                        cpuLoad = 82,
                        tempCelsius = 68,
                        fps = 59.9f
                    )
                )
                "Network Congestion" -> current.copy(
                    telemetry = current.telemetry.copy(
                        pingMs = 94,
                        downloadSpeedMbps = 42,
                        packetLossPercent = 4
                    )
                )
                "Controller Low Battery" -> current.copy(
                    telemetry = current.telemetry.copy(
                        controllerBattery = 14
                    )
                )
                "Thermal Load" -> current.copy(
                    telemetry = current.telemetry.copy(
                        tempCelsius = 79,
                        gpuLoad = 98
                    )
                )
                else -> current.copy(
                    telemetry = DigitalTwinTelemetry()
                )
            }
        }
        scope.launch {
            _events.emit(PlayStationEvent.ChaosScenarioApplied(scenario))
            emitNotification("Digital Twin Scenario", "Applied simulation profile: $scenario", "System")
        }
    }

    fun sendAiPrompt(promptText: String) {
        val userMsg = AiMessage(
            id = UUID.randomUUID().toString(),
            isUser = true,
            message = promptText,
            timestamp = "Just Now"
        )
        _state.update { it.copy(aiMessages = it.aiMessages + userMsg) }

        scope.launch {
            delay(500)
            val replyText = generateAiAnswer(promptText)
            val aiReply = AiMessage(
                id = UUID.randomUUID().toString(),
                isUser = false,
                message = replyText.first,
                timestamp = "Just Now",
                suggestedAction = replyText.second
            )
            _state.update { it.copy(aiMessages = it.aiMessages + aiReply) }
        }
    }

    private fun generateAiAnswer(query: String): Pair<String, String?> {
        val q = query.lowercase()
        return when {
            "continue" in q || "resume" in q -> {
                Pair(
                    "You were playing Astral Frontier 34 minutes ago in the Outer Rim. Station Zero infiltration is 72% complete with squad members Tom and James waiting.",
                    "Resume Astral Frontier"
                )
            }
            "tonight" in q || "recommend" in q || "play" in q -> {
                Pair(
                    "Based on your 140 hrs in Astral Frontier and preference for high-framerate sci-fi action, I recommend Neon District (Ray-Tracing 60FPS) or joining James in Co-op Raid: Orbital Elevator.",
                    "Launch Neon District"
                )
            }
            "trophy" in q || "platinum" in q -> {
                Pair(
                    "You have 42 of 68 trophies in Astral Frontier (61% completion). Your next closest milestone is 'Void Walker' (Gold) by reaching the outer boundary of Sector 4.",
                    "View Trophy Journey"
                )
            }
            "storage" in q || "space" in q || "ssd" in q -> {
                Pair(
                    "Ultra-High Speed SSD has 189 GB free (82% used). 612 GB is allocated to active games, 91 GB to DLC, and 48 GB to 4K HDR captures. Space is optimal.",
                    "Manage SSD"
                )
            }
            "network" in q || "ping" in q || "download" in q -> {
                Pair(
                    "PSN Connection is healthy: 18ms latency to Frankfurt server, 642 Mbps download bandwidth, NAT Type 1 Open, zero packet loss.",
                    "Run Network Diagnostic"
                )
            }
            else -> {
                Pair(
                    "PSOS-X Neural Guide: I've indexed your games, saves, active party, and controller telemetry. I can optimize graphics profiles, guide you to next objectives, or orchestrate cloud handoffs.",
                    null
                )
            }
        }
    }

    private fun emitNotification(title: String, subtitle: String, category: String) {
        val notif = SystemNotification(
            id = UUID.randomUUID().toString(),
            title = title,
            subtitle = subtitle,
            category = category,
            timestamp = "Just Now"
        )
        _state.update {
            it.copy(
                notifications = listOf(notif) + it.notifications.take(9),
                latestToast = "$title: $subtitle"
            )
        }
    }

    fun clearToast() {
        _state.update { it.copy(latestToast = null) }
    }

    private fun createInitialState(): PlayStationState {
        val astralActivities = listOf(
            ActivityItem(
                id = "act_station_zero",
                gameId = "astral_frontier",
                title = "Station Zero: Outer Rim Infiltration",
                description = "Breach the primary docking hub and bypass the orbital mainframe security grid.",
                location = "Outer Rim - Sector 7",
                completionPercent = 72,
                difficulty = "High",
                estimatedMinutes = 25,
                reward = "Exotic Plasma Core",
                friendsInSquad = 2,
                isReady = true
            ),
            ActivityItem(
                id = "act_frozen_rift",
                gameId = "astral_frontier",
                title = "The Frozen Rift Boss Encounter",
                description = "Defeat the Void Weaver deep within the cryo-geothermal canyon.",
                location = "Glacial Trench",
                completionPercent = 0,
                difficulty = "Epic",
                estimatedMinutes = 15,
                reward = "Cryo Stalker Chassis",
                friendsInSquad = 0,
                isReady = true
            ),
            ActivityItem(
                id = "act_orbital_elevator",
                gameId = "astral_frontier",
                title = "Co-op Raid: Orbital Elevator",
                description = "4-Player assault against the vanguard flagship ascending the atmosphere.",
                location = "Geostationary Ring",
                completionPercent = 40,
                difficulty = "Legendary",
                estimatedMinutes = 40,
                reward = "Ascendant Catalyst",
                friendsInSquad = 3,
                isReady = true
            )
        )

        val astralRegions = listOf(
            WorldRegion(
                id = "reg_outer_rim",
                name = "Sector 7: Outer Rim",
                explorationPercent = 72,
                missionsCount = 8,
                bossesCount = 2,
                collectiblesCount = 14,
                activeThreatLevel = "Severe",
                squadPresent = true
            ),
            WorldRegion(
                id = "reg_station_zero",
                name = "Station Zero Core",
                explorationPercent = 88,
                missionsCount = 5,
                bossesCount = 1,
                collectiblesCount = 9,
                activeThreatLevel = "Moderate",
                squadPresent = true
            ),
            WorldRegion(
                id = "reg_glacial_trench",
                name = "Glacial Trench Deep",
                explorationPercent = 34,
                missionsCount = 6,
                bossesCount = 3,
                collectiblesCount = 18,
                activeThreatLevel = "Critical",
                squadPresent = false
            )
        )

        val gameAstral = GameObject(
            gameId = "astral_frontier",
            title = "ASTRAL FRONTIER",
            studio = "ECHO STUDIOS",
            genre = "Sci-Fi Action RPG",
            installSizeGb = 114,
            progressPercent = 72,
            trophiesUnlocked = 42,
            totalTrophies = 68,
            isInstalled = true,
            worldName = "The Outer Rim Continuum",
            worldSummary = "An expansive spatial sector scarred by derelict megastructures and void anomalies.",
            regions = astralRegions,
            activities = astralActivities
        )

        val gameNeon = GameObject(
            gameId = "neon_district",
            title = "NEON DISTRICT",
            studio = "KUROGANE LABS",
            genre = "Cyberpunk Stealth",
            installSizeGb = 86,
            progressPercent = 35,
            trophiesUnlocked = 24,
            totalTrophies = 50,
            isInstalled = true,
            worldName = "Neo-Shibuya 2099",
            worldSummary = "Vertiginous skyscraper canyons bathed in photonic rain and corporate intrigue.",
            regions = emptyList(),
            activities = listOf(
                ActivityItem(
                    id = "neon_heist",
                    gameId = "neon_district",
                    title = "Syndicate Vault Heist",
                    description = "Infiltrate the 80th floor vault without raising security alarms.",
                    location = "Kurogane Tower",
                    completionPercent = 20,
                    difficulty = "High",
                    estimatedMinutes = 18,
                    reward = "Monoblade Katana",
                    friendsInSquad = 1
                )
            )
        )

        val gameHorizon = GameObject(
            gameId = "last_horizon",
            title = "THE LAST HORIZON",
            studio = "SOLARIS GAMES",
            genre = "Deep Space Odyssey",
            installSizeGb = 64,
            progressPercent = 100,
            trophiesUnlocked = 58,
            totalTrophies = 58,
            isInstalled = true,
            worldName = "Andromeda Gateway",
            worldSummary = "The edge of known reality where ancient celestial gates still pulse with gravity.",
            regions = emptyList(),
            activities = emptyList()
        )

        val gameTokyo = GameObject(
            gameId = "tokyo_after_dark",
            title = "TOKYO AFTER DARK",
            studio = "SHIBUYA WORKS",
            genre = "Supernatural Mystery",
            installSizeGb = 42,
            progressPercent = 18,
            trophiesUnlocked = 12,
            totalTrophies = 44,
            isInstalled = false,
            worldName = "Midnight Alleyways",
            worldSummary = "A parallel realm hiding behind the vending machines and rain-soaked alleyways.",
            regions = emptyList(),
            activities = emptyList()
        )

        val gameMars = GameObject(
            gameId = "echoes_of_mars",
            title = "ECHOES OF MARS",
            studio = "AERO DYNAMICS",
            genre = "Atmospheric Survival Sim",
            installSizeGb = 78,
            progressPercent = 58,
            trophiesUnlocked = 30,
            totalTrophies = 55,
            isInstalled = false,
            worldName = "Valles Marineris Basin",
            worldSummary = "Harsh rust-colored canyons hiding forgotten terraforming monoliths.",
            regions = emptyList(),
            activities = emptyList()
        )

        val initialFriends = listOf(
            FriendProfile(
                id = "f_tom",
                gamertag = "Tom_Ahyx",
                statusSummary = "In Squad • Sector 7",
                activeGame = "Astral Frontier",
                activeActivity = "Station Zero: Outer Rim Infiltration",
                isInParty = true,
                isOnline = true,
                avatarColorHex = 0xFF00F0FF
            ),
            FriendProfile(
                id = "f_james",
                gamertag = "James_Valkyrie",
                statusSummary = "In Squad • Sector 7",
                activeGame = "Astral Frontier",
                activeActivity = "Station Zero: Outer Rim Infiltration",
                isInParty = true,
                isOnline = true,
                avatarColorHex = 0xFF3B82F6
            ),
            FriendProfile(
                id = "f_alex",
                gamertag = "Alex_Cyber",
                statusSummary = "Mission: Vault Heist",
                activeGame = "Neon District",
                activeActivity = null,
                isInParty = false,
                isOnline = true,
                avatarColorHex = 0xFFA855F7
            ),
            FriendProfile(
                id = "f_sarah",
                gamertag = "Sarah_Drift",
                statusSummary = "Rest Mode",
                activeGame = null,
                activeActivity = null,
                isInParty = false,
                isOnline = false,
                avatarColorHex = 0xFF6B7280
            )
        )

        val initialTrophies = listOf(
            TrophyItem(
                id = "tr_0",
                gameId = "astral_frontier",
                title = "Starbound Pioneer",
                description = "Complete the planetary departure protocol.",
                rarity = "Bronze",
                isUnlocked = true,
                unlockedDate = "Yesterday 18:22",
                progressPercent = 100
            ),
            TrophyItem(
                id = "tr_1",
                gameId = "astral_frontier",
                title = "Overclocked Kinetic",
                description = "Deal 100,000 thermal damage with rail technology.",
                rarity = "Silver",
                isUnlocked = true,
                unlockedDate = "Yesterday 21:05",
                progressPercent = 100
            ),
            TrophyItem(
                id = "tr_2",
                gameId = "astral_frontier",
                title = "Void Walker",
                description = "Reach the extreme outer boundary of Sector 7.",
                rarity = "Gold",
                isUnlocked = false,
                progressPercent = 75
            ),
            TrophyItem(
                id = "tr_3",
                gameId = "astral_frontier",
                title = "Master of the Void",
                description = "Unlock all trophies in Astral Frontier.",
                rarity = "Platinum",
                isUnlocked = false,
                progressPercent = 61
            )
        )

        val initialCaptures = listOf(
            CaptureMedia(
                id = "cap_1",
                title = "Orbital Dawn over Outer Rim",
                type = "Screenshot",
                timestamp = "Yesterday 21:40",
                sizeMb = "15.4 MB",
                gameTitle = "Astral Frontier"
            ),
            CaptureMedia(
                id = "cap_2",
                title = "Station Zero Boss Stagger",
                type = "4K Clip",
                timestamp = "Yesterday 20:15",
                sizeMb = "184 MB",
                gameTitle = "Astral Frontier"
            )
        )

        val initialAiMessages = listOf(
            AiMessage(
                id = "m1",
                isUser = false,
                message = "PSOS-X Neural Gaming Guide active. System telemetry stable at 59.8 FPS. Ready to assist with activities, trophy navigation, or performance tuning.",
                timestamp = "22:40"
            )
        )

        return PlayStationState(
            games = listOf(gameAstral, gameNeon, gameHorizon, gameTokyo, gameMars),
            friends = initialFriends,
            trophies = initialTrophies,
            captures = initialCaptures,
            aiMessages = initialAiMessages
        )
    }
}
