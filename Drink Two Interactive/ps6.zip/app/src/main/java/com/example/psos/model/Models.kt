package com.example.psos.model

enum class SystemTab {
    HOME,
    WORLD,
    ACTIVITIES,
    TELEMETRY,
    TROPHIES,
    CONTINUITY
}

enum class BottomNavSlot {
    LIBRARY, // Square
    STORE,   // Cross
    CONTROL, // Center glowing PS button
    SOCIAL,  // Circle
    AI       // Triangle
}

data class WorldRegion(
    val id: String,
    val name: String,
    val explorationPercent: Int,
    val missionsCount: Int,
    val bossesCount: Int,
    val collectiblesCount: Int,
    val activeThreatLevel: String,
    val squadPresent: Boolean
)

data class ActivityItem(
    val id: String,
    val gameId: String,
    val title: String,
    val description: String,
    val location: String,
    val completionPercent: Int,
    val difficulty: String,
    val estimatedMinutes: Int,
    val reward: String,
    val friendsInSquad: Int,
    val isReady: Boolean = true
)

data class TrophyItem(
    val id: String,
    val gameId: String,
    val title: String,
    val description: String,
    val rarity: String, // "Platinum", "Gold", "Silver", "Bronze"
    val isUnlocked: Boolean,
    val unlockedDate: String? = null,
    val progressPercent: Int = 0
)

data class GameObject(
    val gameId: String,
    val title: String,
    val studio: String,
    val genre: String,
    val installSizeGb: Int,
    val progressPercent: Int,
    val trophiesUnlocked: Int,
    val totalTrophies: Int,
    val isInstalled: Boolean,
    val worldName: String,
    val worldSummary: String,
    val regions: List<WorldRegion>,
    val activities: List<ActivityItem>,
    val pssrSupported: Boolean = true,
    val rayTracingSupported: Boolean = true
)

data class FriendProfile(
    val id: String,
    val gamertag: String,
    val statusSummary: String,
    val activeGame: String?,
    val activeActivity: String?,
    val isInParty: Boolean = false,
    val isOnline: Boolean = true,
    val avatarColorHex: Long = 0xFF00F0FF
)

data class DownloadItem(
    val id: String,
    val gameId: String,
    val title: String,
    val progressPercent: Int,
    val speedMbps: Int,
    val totalGb: Double,
    val downloadedGb: Double,
    val status: String // "Downloading", "Queued", "Paused", "Installing", "Completed"
)

data class DigitalTwinTelemetry(
    val fps: Float = 59.8f,
    val frameTimeMs: Float = 16.7f,
    val gpuLoad: Int = 84,
    val cpuLoad: Int = 61,
    val tempCelsius: Int = 44,
    val pingMs: Int = 18,
    val downloadSpeedMbps: Int = 642,
    val uploadSpeedMbps: Int = 78,
    val packetLossPercent: Int = 0,
    val natType: String = "Type 1 (Open)",
    val controllerBattery: Int = 84,
    val controllerConnected: Boolean = true,
    val controllerHaptics: Boolean = true,
    val controllerAdaptiveTriggers: Boolean = true,
    val ssdTotalGb: Int = 1000,
    val ssdUsedGb: Int = 811,
    val gamesGb: Int = 612,
    val dlcGb: Int = 91,
    val capturesGb: Int = 48,
    val systemGb: Int = 38,
    val cacheGb: Int = 22,
    val displayMode: String = "3840x2160 @ 120Hz VRR",
    val audioMode: String = "Tempest 3D Audio (HRTF Profile 3)",
    val pssrSuperRes: Boolean = true
)

data class CaptureMedia(
    val id: String,
    val title: String,
    val type: String, // "Screenshot" or "4K Clip"
    val timestamp: String,
    val sizeMb: String,
    val gameTitle: String
)

data class AiMessage(
    val id: String,
    val isUser: Boolean,
    val message: String,
    val timestamp: String,
    val suggestedAction: String? = null
)

data class SystemNotification(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String, // "Trophy", "Party", "Download", "System", "Cloud"
    val timestamp: String
)
