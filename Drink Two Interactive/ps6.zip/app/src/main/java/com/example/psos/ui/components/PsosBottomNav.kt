package com.example.psos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.psos.model.BottomNavSlot
import com.example.ui.theme.PsosElectricCyan

@Composable
fun PsosBottomNav(
    activeModal: BottomNavSlot?,
    isControlCentreOpen: Boolean,
    onSlotClicked: (BottomNavSlot) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.75f))
            .border(
                width = 1.dp,
                color = Color.White.copy(alpha = 0.08f)
            )
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Square - Library / Collection
            NavIconButton(
                isActive = activeModal == BottomNavSlot.LIBRARY,
                onClick = { onSlotClicked(BottomNavSlot.LIBRARY) }
            ) { color ->
                Canvas(modifier = Modifier.size(20.dp)) {
                    drawRect(
                        color = color,
                        topLeft = Offset(1f, 1f),
                        size = Size(size.width - 2f, size.height - 2f),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }

            // 2. Cross - PlayStation Store
            NavIconButton(
                isActive = activeModal == BottomNavSlot.STORE,
                onClick = { onSlotClicked(BottomNavSlot.STORE) }
            ) { color ->
                Canvas(modifier = Modifier.size(20.dp)) {
                    val stroke = 2.dp.toPx()
                    drawLine(
                        color = color,
                        start = Offset(2f, 2f),
                        end = Offset(size.width - 2f, size.height - 2f),
                        strokeWidth = stroke
                    )
                    drawLine(
                        color = color,
                        start = Offset(size.width - 2f, 2f),
                        end = Offset(2f, size.height - 2f),
                        strokeWidth = stroke
                    )
                }
            }

            // 3. Center Glowing PS Button - Quick Control Centre
            val psScale by animateFloatAsState(
                targetValue = if (isControlCentreOpen) 0.92f else 1f,
                label = "psScale"
            )
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .scale(psScale)
                    .shadow(16.dp, CircleShape, spotColor = PsosElectricCyan)
                    .clip(CircleShape)
                    .background(PsosElectricCyan.copy(alpha = 0.12f))
                    .border(1.5.dp, PsosElectricCyan.copy(alpha = 0.6f), CircleShape)
                    .clickable { onSlotClicked(BottomNavSlot.CONTROL) }
                    .minimumInteractiveComponentSize(),
                contentAlignment = Alignment.Center
            ) {
                // Outer ring
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, PsosElectricCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Core Dot
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(PsosElectricCyan)
                    )
                }
            }

            // 4. Circle - Social & Party
            NavIconButton(
                isActive = activeModal == BottomNavSlot.SOCIAL,
                onClick = { onSlotClicked(BottomNavSlot.SOCIAL) }
            ) { color ->
                Canvas(modifier = Modifier.size(20.dp)) {
                    drawCircle(
                        color = color,
                        radius = (size.width - 2f) / 2,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }

            // 5. Triangle - PlayStation AI Assistant
            NavIconButton(
                isActive = activeModal == BottomNavSlot.AI,
                onClick = { onSlotClicked(BottomNavSlot.AI) }
            ) { color ->
                Canvas(modifier = Modifier.size(20.dp)) {
                    val path = Path().apply {
                        moveTo(size.width / 2f, 2f)
                        lineTo(size.width - 2f, size.height - 2f)
                        lineTo(2f, size.height - 2f)
                        close()
                    }
                    drawPath(
                        path = path,
                        color = color,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }
        }
    }
}

@Composable
private fun NavIconButton(
    isActive: Boolean,
    onClick: () -> Unit,
    content: @Composable (Color) -> Unit
) {
    val color = if (isActive) PsosElectricCyan else Color.White.copy(alpha = 0.45f)
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize(),
        contentAlignment = Alignment.Center
    ) {
        content(color)
    }
}
