package com.example.psos.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.psos.model.TrophyItem
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosTrophyBronze
import com.example.ui.theme.PsosTrophyGold
import com.example.ui.theme.PsosTrophyPlatinum
import com.example.ui.theme.PsosTrophySilver
import com.example.ui.theme.PsosVoidBlack

@Composable
fun TrophiesView(
    state: PlayStationState,
    onUnlockTrophy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGame = state.games.find { it.gameId == state.activeGameId } ?: state.games.first()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Text(
            text = "TROPHY ARCHITECTURE",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = PsosElectricCyan
        )
        Text(
            text = "Trophy Journey & Milestones",
            fontSize = 24.sp,
            fontWeight = FontWeight.Light,
            color = PsosTextPrimary
        )
        Text(
            text = "Connected player identity tracking achievements and journey towards Platinum.",
            fontSize = 12.sp,
            color = PsosTextMuted,
            modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
        )

        // Player Level & Trophies Counter Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(PsosCardBg)
                .border(1.dp, PsosCardBorder, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PLAYSTATION LEVEL",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = PsosTextDim
                        )
                        Text(
                            text = "382",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Light,
                            fontFamily = FontFamily.Monospace,
                            color = PsosTextPrimary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        TrophyCountBadge(count = "18", color = PsosTrophyPlatinum, label = "PLATINUM")
                        TrophyCountBadge(count = "84", color = PsosTrophyGold, label = "GOLD")
                        TrophyCountBadge(count = "312", color = PsosTrophySilver, label = "SILVER")
                        TrophyCountBadge(count = "3,706", color = PsosTrophyBronze, label = "BRONZE")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onUnlockTrophy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PsosTrophyGold,
                        contentColor = PsosVoidBlack
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(40.dp)
                ) {
                    Text(
                        text = "TEST UNLOCK: VOID WALKER (GOLD) 🏆",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Game Specific Trophies
        Text(
            text = "${activeGame.title.uppercase()} TROPHY LIST",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        state.trophies.forEach { trophy ->
            val rarityColor = when (trophy.rarity) {
                "Platinum" -> PsosTrophyPlatinum
                "Gold" -> PsosTrophyGold
                "Silver" -> PsosTrophySilver
                else -> PsosTrophyBronze
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(PsosCardBg)
                    .border(1.dp, PsosCardBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(rarityColor)
                        )
                        Column {
                            Text(
                                text = trophy.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = PsosTextPrimary
                            )
                            Text(
                                text = trophy.description,
                                fontSize = 11.sp,
                                color = PsosTextMuted
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (trophy.isUnlocked) Color.White.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.04f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (trophy.isUnlocked) "UNLOCKED" else "${trophy.progressPercent}%",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (trophy.isUnlocked) PsosElectricCyan else PsosTextDim
                            )
                        }
                        if (trophy.unlockedDate != null) {
                            Text(
                                text = trophy.unlockedDate,
                                fontSize = 8.sp,
                                color = PsosTextDim,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrophyCountBadge(count: String, color: Color, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = count,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = PsosTextPrimary
        )
        Text(
            text = label,
            fontSize = 7.sp,
            letterSpacing = 0.5.sp,
            color = PsosTextDim
        )
    }
}
