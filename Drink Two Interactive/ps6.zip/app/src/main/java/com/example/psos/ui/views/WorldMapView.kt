package com.example.psos.ui.views

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.psos.model.WorldRegion
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosCyanSubtle
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosTextSecondary

@Composable
fun WorldMapView(
    state: PlayStationState,
    onLaunchActivity: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGame = state.games.find { it.gameId == state.activeGameId } ?: state.games.first()
    var selectedRegionId by remember { mutableStateOf(activeGame.regions.firstOrNull()?.id ?: "") }
    val selectedRegion = activeGame.regions.find { it.id == selectedRegionId } ?: activeGame.regions.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Text(
            text = "SPATIAL GAME WORLD",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = PsosElectricCyan
        )
        Text(
            text = activeGame.worldName,
            fontSize = 24.sp,
            fontWeight = FontWeight.Light,
            color = PsosTextPrimary
        )
        Text(
            text = activeGame.worldSummary,
            fontSize = 12.sp,
            color = PsosTextMuted,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        // Spatial Radar / Coordinate Visualizer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.03f))
                .border(1.dp, PsosCardBorder, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f

                // Concentric orbital grid lines
                drawCircle(color = PsosElectricCyan.copy(alpha = 0.1f), radius = cy * 0.85f)
                drawCircle(color = PsosElectricCyan.copy(alpha = 0.15f), radius = cy * 0.55f)
                drawCircle(color = PsosElectricCyan.copy(alpha = 0.25f), radius = cy * 0.25f)

                drawLine(
                    color = Color.White.copy(alpha = 0.08f),
                    start = Offset(0f, cy),
                    end = Offset(size.width, cy)
                )
                drawLine(
                    color = Color.White.copy(alpha = 0.08f),
                    start = Offset(cx, 0f),
                    end = Offset(cx, size.height)
                )

                // Region nodes
                drawCircle(color = PsosElectricCyan, radius = 6.dp.toPx(), center = Offset(cx - 60.dp.toPx(), cy - 20.dp.toPx()))
                drawCircle(color = Color.White, radius = 5.dp.toPx(), center = Offset(cx + 40.dp.toPx(), cy - 30.dp.toPx()))
                drawCircle(color = PsosElectricCyan.copy(alpha = 0.5f), radius = 5.dp.toPx(), center = Offset(cx + 70.dp.toPx(), cy + 35.dp.toPx()))
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(PsosElectricCyan))
                Text(
                    text = "SECTOR MAPPING ACTIVE • 3 ZONES RESOLVED",
                    fontSize = 9.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    color = PsosElectricCyan
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Region Selector Cards
        Text(
            text = "EXPLORATION REGIONS",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        activeGame.regions.forEach { region ->
            val isSelected = region.id == selectedRegionId
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) PsosCyanSubtle else PsosCardBg)
                    .border(
                        1.dp,
                        if (isSelected) PsosElectricCyan.copy(alpha = 0.6f) else PsosCardBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { selectedRegionId = region.id }
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = region.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) PsosElectricCyan else PsosTextPrimary
                            )
                            if (region.squadPresent) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.White.copy(alpha = 0.1f))
                                        .padding(horizontal = 6.dp, vertical = 1.dp)
                                ) {
                                    Text("SQUAD ACTIVE", fontSize = 8.sp, color = PsosElectricCyan, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${region.explorationPercent}% Explored • Threat: ${region.activeThreatLevel} • ${region.missionsCount} Missions",
                            fontSize = 11.sp,
                            color = PsosTextMuted
                        )
                    }

                    Text(
                        text = "${region.explorationPercent}%",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Light,
                        color = PsosTextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Region Detail & Instant Ingress
        selectedRegion?.let { reg ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(1.dp, PsosCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "REGION TELEMETRY: ${reg.name.uppercase()}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = PsosTextDim
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Missions", fontSize = 10.sp, color = PsosTextDim)
                            Text("${reg.missionsCount} Active", fontSize = 13.sp, color = PsosTextPrimary, fontWeight = FontWeight.Medium)
                        }
                        Column {
                            Text("Bosses", fontSize = 10.sp, color = PsosTextDim)
                            Text("${reg.bossesCount} Encounters", fontSize = 13.sp, color = PsosTextPrimary, fontWeight = FontWeight.Medium)
                        }
                        Column {
                            Text("Collectibles", fontSize = 10.sp, color = PsosTextDim)
                            Text("${reg.collectiblesCount} Found", fontSize = 13.sp, color = PsosTextPrimary, fontWeight = FontWeight.Medium)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val activity = activeGame.activities.firstOrNull()
                            onLaunchActivity(activeGame.gameId, activity?.id ?: "act_station_zero")
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PsosElectricCyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp)
                    ) {
                        Text(
                            text = "DROP INTO REGION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }
}
