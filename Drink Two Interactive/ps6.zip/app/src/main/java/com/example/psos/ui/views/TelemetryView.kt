package com.example.psos.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosDanger
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosSuccess
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosWarning

@Composable
fun TelemetryView(
    state: PlayStationState,
    onApplyScenario: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val t = state.telemetry

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Text(
            text = "HARDWARE DIGITAL TWIN",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = PsosElectricCyan
        )
        Text(
            text = "Performance & Silicon Telemetry",
            fontSize = 24.sp,
            fontWeight = FontWeight.Light,
            color = PsosTextPrimary
        )
        Text(
            text = "Direct hardware abstraction telemetry monitoring compute units, thermal margins, and storage pipelines.",
            fontSize = 12.sp,
            color = PsosTextMuted,
            modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
        )

        // 4 Core Real-Time Metric Tiles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricTile(
                modifier = Modifier.weight(1f),
                label = "FRAME RATE",
                value = "${t.fps} FPS",
                sub = "${t.frameTimeMs} ms"
            )
            MetricTile(
                modifier = Modifier.weight(1f),
                label = "GPU LOAD",
                value = "${t.gpuLoad}%",
                sub = "PSSR 2.0 Active"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricTile(
                modifier = Modifier.weight(1f),
                label = "CPU LOAD",
                value = "${t.cpuLoad}%",
                sub = "8 Core / 16 Thr"
            )
            val tempColor = if (t.tempCelsius > 75) PsosDanger else if (t.tempCelsius > 65) PsosWarning else PsosSuccess
            MetricTile(
                modifier = Modifier.weight(1f),
                label = "THERMALS",
                value = "${t.tempCelsius}°C",
                sub = if (t.tempCelsius > 75) "Thermal Load" else "Optimal Vapour",
                valueColor = tempColor
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // NVMe SSD Storage Visualizer
        Text(
            text = "CUSTOM NVME SSD ARCHITECTURE (8.2 GB/S RAW)",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(PsosCardBg)
                .border(1.dp, PsosCardBorder, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "811 GB Used of 1,000 GB",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = PsosTextPrimary
                    )
                    Text(
                        text = "189 GB Free",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        color = PsosElectricCyan
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Segmented Storage Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                ) {
                    // Games (612 GB)
                    Box(modifier = Modifier.weight(0.612f).height(10.dp).background(PsosElectricCyan))
                    // DLC (91 GB)
                    Box(modifier = Modifier.weight(0.091f).height(10.dp).background(Color(0xFF818CF8)))
                    // Captures (48 GB)
                    Box(modifier = Modifier.weight(0.048f).height(10.dp).background(Color(0xFFF472B6)))
                    // System (38 GB)
                    Box(modifier = Modifier.weight(0.038f).height(10.dp).background(Color(0xFFE2E8F0)))
                    // Free (189 GB)
                    Box(modifier = Modifier.weight(0.189f).height(10.dp).background(Color.Transparent))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StorageLegendItem(label = "Games", value = "612 GB", color = PsosElectricCyan)
                    StorageLegendItem(label = "DLC", value = "91 GB", color = Color(0xFF818CF8))
                    StorageLegendItem(label = "Media", value = "48 GB", color = Color(0xFFF472B6))
                    StorageLegendItem(label = "System", value = "38 GB", color = Color(0xFFE2E8F0))
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // DualSense & Peripherals
        Text(
            text = "HMI & CONTROLLER DIAGNOSTICS",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(PsosCardBg)
                .border(1.dp, PsosCardBorder, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DiagnosticsRow(label = "DUALSENSE PRO", value = "Connected (Ultra-Low Latency Wireless)")
                DiagnosticsRow(label = "BATTERY STATUS", value = "${t.controllerBattery}% Remaining")
                DiagnosticsRow(label = "HAPTIC ACTUATORS", value = "Active (Dual Voice-Coil Resonance)")
                DiagnosticsRow(label = "ADAPTIVE TRIGGERS", value = "Dynamic Force Resistance Profile")
                DiagnosticsRow(label = "DISPLAY SINK", value = t.displayMode)
                DiagnosticsRow(label = "SPATIAL AUDIO", value = t.audioMode)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Chaos Simulation Scenarios (Required by prompt)
        Text(
            text = "CHAOS HARDWARE SIMULATION ENGINE",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        val scenarios = listOf(
            "Normal Optimal",
            "Heavy Gaming 4K",
            "Network Congestion",
            "Controller Low Battery",
            "Thermal Load"
        )

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            scenarios.forEach { scenario ->
                Button(
                    onClick = { onApplyScenario(scenario) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.05f),
                        contentColor = PsosTextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(38.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = scenario, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Text(text = "SIMULATE", fontSize = 9.sp, color = PsosElectricCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTile(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    sub: String,
    valueColor: Color = PsosTextPrimary
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(PsosCardBg)
            .border(1.dp, PsosCardBorder, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = PsosTextDim
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Light,
                fontFamily = FontFamily.Monospace,
                color = valueColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = sub,
                fontSize = 10.sp,
                color = PsosTextMuted
            )
        }
    }
}

@Composable
private fun StorageLegendItem(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
        Text(text = "$label: $value", fontSize = 9.sp, color = PsosTextMuted)
    }
}

@Composable
private fun DiagnosticsRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 9.sp, letterSpacing = 1.sp, color = PsosTextDim)
        Text(text = value, fontSize = 10.sp, color = PsosTextPrimary, fontWeight = FontWeight.Medium)
    }
}
