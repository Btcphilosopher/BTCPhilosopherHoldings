package com.example.psos.ui.views

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.GameSessionStatus
import com.example.psos.kernel.PlayStationState
import com.example.psos.model.GameObject
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosCyanSubtle
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosTextSecondary
import com.example.ui.theme.PsosTrophyGold
import com.example.ui.theme.PsosVoidBlack

@Composable
fun HomeView(
    state: PlayStationState,
    onResumeActivity: () -> Unit,
    onViewWorld: () -> Unit,
    onLaunchActivity: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGame = state.games.find { it.gameId == state.activeGameId } ?: state.games.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.Bottom
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Session Tag & Studio
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(PsosCyanSubtle)
                    .border(1.dp, PsosElectricCyan.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (state.sessionStatus == GameSessionStatus.PLAYING) "ACTIVE SESSION" else "SUSPENDED IN MEMORY",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = PsosElectricCyan
                )
            }

            Text(
                text = activeGame?.studio ?: "ECHO STUDIOS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp,
                color = PsosTextDim
            )
        }

        // Monumental Game Title
        Text(
            text = activeGame?.title ?: "ASTRAL FRONTIER",
            fontSize = 44.sp,
            fontWeight = FontWeight.ExtraLight,
            letterSpacing = (-1.5).sp,
            lineHeight = 44.sp,
            color = PsosTextPrimary,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        // Narrative Context
        Text(
            text = "Continue exploring the Outer Rim. Squad members Tom and James are waiting at Station Zero.",
            fontSize = 14.sp,
            fontWeight = FontWeight.Light,
            lineHeight = 20.sp,
            color = PsosTextMuted,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(bottom = 20.dp)
        )

        // Live Metric Cards (World Progress & Trophy Rank)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card 1: World Progress
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(PsosCardBg)
                    .border(1.dp, PsosCardBorder, RoundedCornerShape(16.dp))
                    .clickable { onViewWorld() }
                    .padding(14.dp)
            ) {
                Column {
                    Text(
                        text = "WORLD PROGRESS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = PsosTextDim
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${activeGame?.progressPercent ?: 72}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Light,
                            color = PsosTextPrimary
                        )
                        Text(
                            text = "%",
                            fontSize = 13.sp,
                            color = PsosTextMuted,
                            modifier = Modifier.padding(bottom = 3.dp, start = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.1f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth((activeGame?.progressPercent ?: 72) / 100f)
                                .height(4.dp)
                                .clip(CircleShape)
                                .background(PsosElectricCyan)
                                .shadow(8.dp, CircleShape, spotColor = PsosElectricCyan)
                        )
                    }
                }
            }

            // Card 2: Trophy Rank
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(PsosCardBg)
                    .border(1.dp, PsosCardBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text(
                        text = "TROPHY RANK",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = PsosTextDim
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${activeGame?.trophiesUnlocked ?: 42}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Light,
                            color = PsosTextPrimary
                        )
                        Text(
                            text = " / ${activeGame?.totalTrophies ?: 68}",
                            fontSize = 13.sp,
                            color = PsosTextMuted,
                            modifier = Modifier.padding(bottom = 3.dp, start = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(PsosTrophyGold)
                                .padding(bottom = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Next: Void Walker (Gold)",
                        fontSize = 9.sp,
                        color = PsosElectricCyan
                    )
                }
            }
        }

        // High-Fidelity White Pill CTA: "RESUME ACTIVITY"
        Button(
            onClick = onResumeActivity,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = PsosVoidBlack
            ),
            shape = CircleShape,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .shadow(16.dp, CircleShape, spotColor = Color.White.copy(alpha = 0.2f))
                .testTag("resume_activity_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = PsosVoidBlack,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RESUME ACTIVITY",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Quick Activities Strip
        Text(
            text = "FAST-TRAVEL ACTIVITIES",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        activeGame?.activities?.forEach { activity ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.04f))
                    .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
                    .clickable { onLaunchActivity(activeGame.gameId, activity.id) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activity.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = PsosTextPrimary
                    )
                    Text(
                        text = "${activity.location} • ${activity.estimatedMinutes} min • ${activity.reward}",
                        fontSize = 10.sp,
                        color = PsosTextDim
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(PsosElectricCyan.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "PLAY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = PsosElectricCyan
                    )
                }
            }
        }
    }
}
