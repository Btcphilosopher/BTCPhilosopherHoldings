package com.example.psos.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosCyanSubtle
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosVoidBlack

@Composable
fun ContinuityView(
    state: PlayStationState,
    onHandoff: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Text(
            text = "PLAYSTATION CONTINUITY",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color = PsosElectricCyan
        )
        Text(
            text = "Cross-Device Execution Mesh",
            fontSize = 24.sp,
            fontWeight = FontWeight.Light,
            color = PsosTextPrimary
        )
        Text(
            text = "Seamless session handoff and zero-latency stream continuity across consoles, handhelds, and cloud nodes.",
            fontSize = 12.sp,
            color = PsosTextMuted,
            modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
        )

        // Current Active Node
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(PsosCyanSubtle)
                .border(1.dp, PsosElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE COMPUTATIONAL NODE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = PsosElectricCyan
                    )
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(PsosElectricCyan)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.activeDevice,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = PsosTextPrimary
                )
                Text(
                    text = if (state.isCloudStreamActive) "Cloud Streaming Relay • Low-Latency NVMe Remote Cache" else "Local Native APU Execution • 4K 120Hz HDR Direct Output",
                    fontSize = 11.sp,
                    color = PsosTextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "NEARBY CONTINUITY TARGETS",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        val devices = listOf(
            Triple("PlayStation Portal", "1080p 60fps • 4ms Wi-Fi 7 Remote Link • Ready", Icons.Default.SportsEsports),
            Triple("PS5 Pro Console", "Native 4K 120Hz HDR • Local Master Node", Icons.Default.Tv),
            Triple("Cloud Edge Stream", "Instant Stream • No SSD Storage required", Icons.Default.Cast),
            Triple("Xperia Companion Tablet", "DualSense Direct Connect • In Range", Icons.Default.PhoneAndroid)
        )

        devices.forEach { (name, details, icon) ->
            val isActive = state.activeDevice == name

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isActive) Color.White.copy(alpha = 0.08f) else PsosCardBg)
                    .border(
                        1.dp,
                        if (isActive) PsosElectricCyan else PsosCardBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { onHandoff(name) }
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isActive) PsosElectricCyan else PsosTextMuted,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = PsosTextPrimary
                            )
                            Text(
                                text = details,
                                fontSize = 10.sp,
                                color = PsosTextDim
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isActive) PsosElectricCyan else Color.White.copy(alpha = 0.05f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isActive) "ACTIVE" else "HANDOFF",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = if (isActive) PsosVoidBlack else PsosTextPrimary
                        )
                    }
                }
            }
        }
    }
}
