package com.example.psos.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.psos.kernel.PlayStationState
import com.example.psos.model.BottomNavSlot
import com.example.psos.model.GameObject
import com.example.ui.theme.PsosCardBg
import com.example.ui.theme.PsosCardBorder
import com.example.ui.theme.PsosCyanSubtle
import com.example.ui.theme.PsosElectricCyan
import com.example.ui.theme.PsosOverlayBg
import com.example.ui.theme.PsosTextDim
import com.example.ui.theme.PsosTextMuted
import com.example.ui.theme.PsosTextPrimary
import com.example.ui.theme.PsosTextSecondary
import com.example.ui.theme.PsosVoidBlack

@Composable
fun BottomNavModalOverlay(
    slot: BottomNavSlot,
    state: PlayStationState,
    onClose: () -> Unit,
    onSelectGame: (String) -> Unit,
    onStartDownload: (GameObject) -> Unit,
    onToggleMic: () -> Unit,
    onSetAudioBalance: (Float) -> Unit,
    onSendAiPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable(onClick = onClose),
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(PsosOverlayBg)
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clickable(enabled = false) { }
                .padding(20.dp)
        ) {
            when (slot) {
                BottomNavSlot.LIBRARY -> LibraryModalContent(state, onClose, onSelectGame)
                BottomNavSlot.STORE -> StoreModalContent(state, onClose, onStartDownload)
                BottomNavSlot.SOCIAL -> SocialModalContent(state, onClose, onToggleMic, onSetAudioBalance)
                BottomNavSlot.AI -> AiModalContent(state, onClose, onSendAiPrompt)
                BottomNavSlot.CONTROL -> {}
            }
        }
    }
}

// 1. Library Modal (Square)
@Composable
private fun LibraryModalContent(
    state: PlayStationState,
    onClose: () -> Unit,
    onSelectGame: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        ModalHeader(title = "DIGITAL COLLECTION", subtitle = "${state.games.size} TITLES REGISTERED", onClose = onClose)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.games) { game ->
                val isActive = game.gameId == state.activeGameId
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isActive) PsosCyanSubtle else PsosCardBg)
                        .border(1.dp, if (isActive) PsosElectricCyan else PsosCardBorder, RoundedCornerShape(12.dp))
                        .clickable { onSelectGame(game.gameId) }
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(text = game.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = PsosTextPrimary)
                                if (isActive) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(PsosElectricCyan)
                                            .padding(horizontal = 6.dp, vertical = 1.dp)
                                    ) {
                                        Text("ACTIVE", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = PsosVoidBlack)
                                    }
                                }
                            }
                            Text(text = "${game.studio} • ${game.genre} • ${game.installSizeGb} GB", fontSize = 11.sp, color = PsosTextDim)
                        }

                        Text(
                            text = "${game.progressPercent}%",
                            fontSize = 15.sp,
                            fontFamily = FontFamily.Monospace,
                            color = PsosElectricCyan
                        )
                    }
                }
            }
        }
    }
}

// 2. Store Modal (Cross)
@Composable
private fun StoreModalContent(
    state: PlayStationState,
    onClose: () -> Unit,
    onStartDownload: (GameObject) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        ModalHeader(title = "PLAYSTATION STORE & QUEUE", subtitle = "ULTRA-HIGH SPEED NVME PIPELINE", onClose = onClose)

        if (state.downloads.isNotEmpty()) {
            Text(
                text = "ACTIVE DOWNLOAD QUEUE",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                color = PsosElectricCyan,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            state.downloads.forEach { dl ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PsosCardBg)
                        .border(1.dp, PsosCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = dl.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = PsosTextPrimary)
                            Text(text = "${dl.progressPercent}% • ${dl.speedMbps} Mbps", fontSize = 11.sp, color = PsosElectricCyan)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { dl.progressPercent / 100f },
                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                            color = PsosElectricCyan,
                            trackColor = Color.White.copy(alpha = 0.1f)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        Text(
            text = "STORE CATALOGUE HIGHLIGHTS",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = PsosTextDim,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.games) { game ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(PsosCardBg)
                        .border(1.dp, PsosCardBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = game.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = PsosTextPrimary)
                            Text(text = "${game.genre} • ${game.installSizeGb} GB • PSSR Enhanced", fontSize = 11.sp, color = PsosTextDim)
                        }

                        Button(
                            onClick = { onStartDownload(game) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (game.isInstalled) Color.White.copy(alpha = 0.08f) else PsosElectricCyan,
                                contentColor = if (game.isInstalled) PsosTextPrimary else PsosVoidBlack
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = if (game.isInstalled) "INSTALLED" else "DOWNLOAD",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// 3. Social Modal (Circle)
@Composable
private fun SocialModalContent(
    state: PlayStationState,
    onClose: () -> Unit,
    onToggleMic: () -> Unit,
    onSetAudioBalance: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        ModalHeader(title = "PLAYSTATION SOCIAL", subtitle = "VOICE PARTY & SQUAD PRESENCE", onClose = onClose)

        // Active Party Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(PsosCyanSubtle)
                .border(1.dp, PsosElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "ACTIVE PARTY: OUTER RIM SQUAD", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PsosTextPrimary)
                        Text(text = "Tempest 3D Voice Channel Active (4 Connected)", fontSize = 10.sp, color = PsosElectricCyan)
                    }
                    IconButton(
                        onClick = onToggleMic,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (state.isMicMuted) Color.Red.copy(alpha = 0.2f) else PsosElectricCyan.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = if (state.isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mic Toggle",
                            tint = if (state.isMicMuted) Color.Red else PsosElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "VOICE / GAME AUDIO MIXER", fontSize = 9.sp, letterSpacing = 1.sp, color = PsosTextDim)
                Slider(
                    value = state.gameChatAudioBalance,
                    onValueChange = onSetAudioBalance,
                    colors = SliderDefaults.colors(
                        thumbColor = PsosElectricCyan,
                        activeTrackColor = PsosElectricCyan,
                        inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                    )
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("More Game", fontSize = 9.sp, color = PsosTextDim)
                    Text("More Voice", fontSize = 9.sp, color = PsosTextDim)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "FRIENDS ONLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, color = PsosTextDim)
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.friends) { friend ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(PsosCardBg)
                        .border(1.dp, PsosCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(friend.avatarColorHex).copy(alpha = 0.2f))
                                    .border(1.dp, Color(friend.avatarColorHex), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = friend.gamertag.take(1),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(friend.avatarColorHex)
                                )
                            }
                            Column {
                                Text(text = friend.gamertag, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = PsosTextPrimary)
                                Text(text = "${friend.activeGame ?: "Online"} • ${friend.statusSummary}", fontSize = 10.sp, color = PsosTextDim)
                            }
                        }

                        if (friend.isInParty) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(PsosElectricCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("IN PARTY", fontSize = 8.sp, color = PsosElectricCyan, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. AI Modal (Triangle)
@Composable
private fun AiModalContent(
    state: PlayStationState,
    onClose: () -> Unit,
    onSendPrompt: (String) -> Unit
) {
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        ModalHeader(title = "PLAYSTATION AI GUIDE", subtitle = "PERMISSION-AWARE NEURAL GAMING AGENT", onClose = onClose)

        // Suggestion Chips
        val suggestions = listOf(
            "Continue my campaign",
            "What should I play tonight?",
            "How close to Platinum?",
            "Run Network Diagnostic"
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            suggestions.take(2).forEach { sug ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                        .clickable { onSendPrompt(sug) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(text = sug, fontSize = 10.sp, color = PsosElectricCyan, maxLines = 1)
                }
            }
        }

        // Chat Log
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.aiMessages) { msg ->
                val isUser = msg.isUser
                Box(
                    modifier = Modifier
                        .fillMaxWidth(),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isUser) PsosElectricCyan.copy(alpha = 0.18f) else PsosCardBg)
                            .border(1.dp, if (isUser) PsosElectricCyan.copy(alpha = 0.4f) else PsosCardBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = if (isUser) "YOU" else "PSOS-X GUIDE",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = if (isUser) PsosElectricCyan else PsosTextDim
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = msg.message,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                color = PsosTextPrimary
                            )
                            if (msg.suggestedAction != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(PsosElectricCyan)
                                        .clickable { onSendPrompt(msg.suggestedAction) }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = msg.suggestedAction,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PsosVoidBlack
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Input Field
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask PlayStation AI...", fontSize = 12.sp, color = PsosTextDim) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White.copy(alpha = 0.06f),
                    unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = PsosTextPrimary,
                    unfocusedTextColor = PsosTextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).height(48.dp)
            )

            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onSendPrompt(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(PsosElectricCyan)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = PsosVoidBlack,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun ModalHeader(title: String, subtitle: String, onClose: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = PsosTextPrimary
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = PsosTextDim
            )
        }

        IconButton(
            onClick = onClose,
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.08f))
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = PsosTextPrimary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
