import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'WHITE-SHOE.OS | Ashcombe, Stone & Thorne',
  description: 'Enterprise operating system for elite professional services partnerships.',
  openGraph: {
    title: 'WHITE-SHOE.OS | Ashcombe, Stone & Thorne',
    description: 'Enterprise operating system for elite professional services partnerships.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'WHITE-SHOE.OS | Ashcombe, Stone & Thorne',
    description: 'Enterprise operating system for elite professional services partnerships.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600;700;800&family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-[#0b0f17] text-[#e2e8f0] antialiased selection:bg-[#991b1b] selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
