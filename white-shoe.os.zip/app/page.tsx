'use client';

import React, { useState } from 'react';
import { Navbar, ActiveTab } from '@/components/Navbar';
import { ExecutiveTerminal } from '@/components/ExecutiveTerminal';
import { ClientDirectory } from '@/components/ClientDirectory';
import { MatterEngineView } from '@/components/MatterEngineView';
import { TimeAndBillingView } from '@/components/TimeAndBillingView';
import { ConflictsEngineView } from '@/components/ConflictsEngineView';
import { KnowledgeMindView } from '@/components/KnowledgeMindView';
import { FirmGraphInteractive } from '@/components/FirmGraphInteractive';
import { ClientPortalView } from '@/components/ClientPortalView';
import { PartnerTerminalView } from '@/components/PartnerTerminalView';
import { AskTheFirmModal } from '@/components/AskTheFirmModal';
import { NewClientModal } from '@/components/NewClientModal';
import { NewMatterModal } from '@/components/NewMatterModal';
import { NewTimeEntryModal } from '@/components/NewTimeEntryModal';

import { 
  INITIAL_CLIENTS, 
  INITIAL_MATTERS, 
  INITIAL_PEOPLE, 
  INITIAL_TIME_ENTRIES, 
  INITIAL_INVOICES, 
  INITIAL_CONFLICTS, 
  INITIAL_KNOWLEDGE, 
  INITIAL_PARTNER_ECONOMICS,
  INITIAL_RELATIONSHIPS
} from '@/lib/data';
import { Client, Matter, TimeEntry, ConflictCheckRequest } from '@/lib/types';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('EXECUTIVE');
  const [currentRole, setCurrentRole] = useState<string>('Senior Partner');

  // Application State Engine
  const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS);
  const [matters, setMatters] = useState<Matter[]>(INITIAL_MATTERS);
  const [people, setPeople] = useState(INITIAL_PEOPLE);
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>(INITIAL_TIME_ENTRIES);
  const [invoices, setInvoices] = useState(INITIAL_INVOICES);
  const [conflicts, setConflicts] = useState<ConflictCheckRequest[]>(INITIAL_CONFLICTS);
  const [knowledge, setKnowledge] = useState(INITIAL_KNOWLEDGE);

  // Modals state
  const [isAskFirmOpen, setIsAskFirmOpen] = useState(false);
  const [askFirmInitialQuery, setAskFirmInitialQuery] = useState('');
  
  const [isNewClientOpen, setIsNewClientOpen] = useState(false);
  const [isNewMatterOpen, setIsNewMatterOpen] = useState(false);
  const [isNewTimeOpen, setIsNewTimeOpen] = useState(false);

  // Handlers for creating new records
  const handleOpenAskFirm = (query?: string) => {
    setAskFirmInitialQuery(query || '');
    setIsAskFirmOpen(true);
  };

  const handleSaveClient = (newClient: Client) => {
    setClients((prev) => [newClient, ...prev]);
  };

  const handleSaveMatter = (newMatter: Matter) => {
    setMatters((prev) => [newMatter, ...prev]);
  };

  const handleSaveTimeEntry = (newEntry: TimeEntry) => {
    setTimeEntries((prev) => [newEntry, ...prev]);
    // Dynamically update matter WIP amount
    setMatters((prev) =>
      prev.map((m) => {
        if (m.id === newEntry.matterId) {
          return {
            ...m,
            wipAmount: m.wipAmount + newEntry.hours * newEntry.hourlyRate
          };
        }
        return m;
      })
    );
  };

  const handleSaveConflictCheck = (newCheck: ConflictCheckRequest) => {
    setConflicts((prev) => [newCheck, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#05080e] text-[#f1f5f9] font-sans-ui flex flex-col selection:bg-[#c5a059] selection:text-black">
      
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSearch={() => handleOpenAskFirm('Search global firm records')}
        onOpenAskFirm={() => handleOpenAskFirm()}
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
      />

      {/* Main Operating System View Content */}
      <main className="flex-1 pb-16">
        {activeTab === 'EXECUTIVE' && (
          <ExecutiveTerminal
            setActiveTab={setActiveTab}
            onOpenAskFirm={handleOpenAskFirm}
          />
        )}

        {activeTab === 'CLIENTS' && (
          <ClientDirectory
            clients={clients}
            people={people}
            relationships={INITIAL_RELATIONSHIPS}
            onOpenNewClientModal={() => setIsNewClientOpen(true)}
            onSelectClient={() => {}}
          />
        )}

        {activeTab === 'MATTERS' && (
          <MatterEngineView
            matters={matters}
            people={people}
            clients={clients}
            onOpenNewMatterModal={() => setIsNewMatterOpen(true)}
            onSelectMatter={() => {}}
          />
        )}

        {activeTab === 'BILLING' && (
          <TimeAndBillingView
            timeEntries={timeEntries}
            invoices={invoices}
            people={people}
            matters={matters}
            clients={clients}
            onOpenTimeModal={() => setIsNewTimeOpen(true)}
          />
        )}

        {activeTab === 'CONFLICTS' && (
          <ConflictsEngineView
            conflicts={conflicts}
            clients={clients}
            matters={matters}
            onOpenNewCheck={handleSaveConflictCheck}
          />
        )}

        {activeTab === 'KNOWLEDGE' && (
          <KnowledgeMindView
            knowledge={knowledge}
            people={people}
          />
        )}

        {activeTab === 'GRAPH' && (
          <FirmGraphInteractive
            clients={clients}
            matters={matters}
            people={people}
            knowledge={knowledge}
          />
        )}

        {activeTab === 'PORTAL' && (
          <ClientPortalView
            clients={clients}
            matters={matters}
            invoices={invoices}
          />
        )}

        {activeTab === 'ECONOMICS' && (
          <PartnerTerminalView
            people={people}
            economics={INITIAL_PARTNER_ECONOMICS}
          />
        )}
      </main>

      {/* Global Modals */}
      <AskTheFirmModal
        isOpen={isAskFirmOpen}
        onClose={() => setIsAskFirmOpen(false)}
        initialQuery={askFirmInitialQuery}
        onNavigateToTab={(tab) => setActiveTab(tab as ActiveTab)}
      />

      <NewClientModal
        isOpen={isNewClientOpen}
        onClose={() => setIsNewClientOpen(false)}
        onSave={handleSaveClient}
      />

      <NewMatterModal
        isOpen={isNewMatterOpen}
        onClose={() => setIsNewMatterOpen(false)}
        clients={clients}
        onSave={handleSaveMatter}
      />

      <NewTimeEntryModal
        isOpen={isNewTimeOpen}
        onClose={() => setIsNewTimeOpen(false)}
        matters={matters}
        people={people}
        onSave={handleSaveTimeEntry}
      />

      {/* Subtle Restrained Partnership Footer */}
      <footer className="border-t border-[#141d2e] py-4 bg-[#030509] text-center text-[10px] text-[#64748b] font-mono tracking-widest uppercase">
        <span>Ashcombe, Stone & Thorne OS v3.6 · Enterprise Partnership Intelligence</span>
        <span className="mx-2">·</span>
        <span>London · New York · Paris · Zurich · Singapore · Dubai</span>
      </footer>

    </div>
  );
}
