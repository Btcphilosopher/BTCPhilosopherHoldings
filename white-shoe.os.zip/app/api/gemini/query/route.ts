import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';
import { FIRM_DETAILS, INITIAL_CLIENTS, INITIAL_MATTERS, INITIAL_PEOPLE, INITIAL_KNOWLEDGE, INITIAL_CONFLICTS, INITIAL_PARTNER_ECONOMICS } from '@/lib/data';

export async function POST(req: NextRequest) {
  try {
    const { prompt, userRole = 'Partner' } = await req.json();

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        text: `**SYSTEM ASSISTANT RESPONSE**:

The firm's AI Intelligence Layer is operational. (Note: Set \`GEMINI_API_KEY\` in Settings > Secrets for live dynamic LLM queries).

**Query:** "${prompt}"

**Authoritative System Output:**
- **Firm Revenue (YTD):** £842.7m across London, New York, Zurich, Paris, Singapore, and Dubai.
- **Unbilled WIP:** £214.3m across 6,902 active matters.
- **Top Active Matter:** Project Sovereign (£2.4bn M&A takeover for Aurelia Industries PLC, Lead Partner: Lord Henry Ashcombe KC).
- **Conflict Status:** 1 active conflict alert pending review (Project Aegis vs Aurelia Industries).
- **Intellectual Capital:** 3 primary precedents indexed including UK NSIA Defense Clearance & Pillar 2 Swiss Wealth Structuring.`,
        citations: [
          { label: 'Firm Ledger YTD', source: 'Financials - AR/WIP Database', recordId: 'LEDGER-2026' },
          { label: 'Project Sovereign (M-501)', source: 'Matter Engine', recordId: 'm-501' }
        ]
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Provide context about Ashcombe, Stone & Thorne
    const systemContext = `You are the executive AI Intelligence Layer for WHITE-SHOE.OS, the operating system of ASHCOMBE, STONE & THORNE, an elite multinational professional services partnership (Offices: London, New York, Paris, Zurich, Singapore, Dubai).
You answer natural language queries from Partners and Managing Partners with absolute authority, precision, and executive composure.

FIRM METRICS:
- YTD Revenue: £842.7m
- WIP (Unbilled): £214.3m
- Realisation Rate: 94.2%
- Collection Rate: 91.7%
- Active Clients: 2,481
- Active Matters: 6,902
- Partners: 318
- Total Professionals: 2,740

KEY PARTNERS:
${INITIAL_PEOPLE.map(p => `- ${p.name} (${p.grade}, ${p.office}, ${p.practice}) - Origination YTD: £${(p.originationYTD / 1e6).toFixed(1)}m, Working Billings: £${(p.workingBillingsYTD / 1e6).toFixed(1)}m, Realisation: ${p.realisationRate}%`).join('\n')}

KEY CLIENTS:
${INITIAL_CLIENTS.map(c => `- ${c.name} (${c.category}, ${c.jurisdiction}) - Billed YTD: £${(c.annualRevenueBilled / 1e6).toFixed(1)}m, WIP: £${(c.unbilledWip / 1e6).toFixed(1)}m, Lead Partner: ${c.relationshipPartnerId}`).join('\n')}

KEY ACTIVE MATTERS:
${INITIAL_MATTERS.map(m => `- ${m.code}: ${m.title} (Client: ${m.clientId}, Lead Partner: ${m.leadPartnerId}, WIP: £${m.wipAmount.toLocaleString()}, Status: ${m.status})`).join('\n')}

PENDING CONFLICTS:
${INITIAL_CONFLICTS.map(conf => `- ${conf.id}: ${conf.matterTitle} (Status: ${conf.status}, Proposed Client: ${conf.proposedClientName})`).join('\n')}

INSTRUCTIONS:
1. Speak in the tone of a discreet, authoritative chief of staff at an elite London/NY partnership.
2. Provide concise, direct facts with exact numbers (£/$/€), names, matters, and dates.
3. Include an explicit "Citations" list at the bottom formatted as JSON array or clear references so the UI can construct clickable source traces.
4. Always state clearly that AI suggestions are reviewable and do not supersede partner authority.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: systemContext,
        temperature: 0.2,
      },
    });

    const responseText = response.text || 'No response text received from intelligence layer.';

    return NextResponse.json({
      text: responseText,
      citations: [
        { label: 'Ashcombe Master Database', source: 'Authoritative Core System', recordId: 'SYS-DB-01' },
        { label: 'Partnership Economics & WIP Ledger', source: 'Financial Control Subsystem', recordId: 'FIN-WIP-2026' }
      ]
    });
  } catch (error: any) {
    console.error('Gemini query error:', error);
    return NextResponse.json(
      { error: error?.message || 'Error processing query via Gemini AI Intelligence Layer' },
      { status: 500 }
    );
  }
}
