import { 
  Person, 
  Client, 
  Matter, 
  TimeEntry, 
  Invoice, 
  ConflictCheckRequest, 
  KnowledgeItem, 
  RelationshipEdge, 
  ClientPortalRequest,
  PartnerEconomics
} from './types';

export const FIRM_DETAILS = {
  name: 'ASHCOMBE, STONE & THORNE',
  subtitle: 'INTERNATIONAL PROFESSIONAL PARTNERSHIP',
  established: 1894,
  headquarters: 'London (1 Chancery Lane)',
  offices: ['LONDON', 'NEW YORK', 'PARIS', 'ZURICH', 'SINGAPORE', 'DUBAI'],
  metrics: {
    revenueYtdGBP: 842700000,
    wipUnbilledGBP: 214300000,
    realisationRatePercent: 94.2,
    collectionRatePercent: 91.7,
    activeClientsCount: 2481,
    activeMattersCount: 6902,
    partnersCount: 318,
    totalProfessionalsCount: 2740,
  },
  todaySummary: {
    mattersRequiringAttention: 17,
    deadlinesThisWeek: 8,
    conflictReviewsPending: 3,
    clientRequestsPending: 12,
    partnerDecisionsPending: 6,
    newOpportunitiesCount: 4,
  }
};

export const INITIAL_PEOPLE: Person[] = [
  {
    id: 'p-101',
    name: 'Lord Henry Ashcombe KC',
    grade: 'Senior Partner',
    title: 'Senior Partner & Chair of Partnership Board',
    office: 'London',
    practice: 'CORPORATE',
    email: 'h.ashcombe@ashcombestone.com',
    rateHourly: 1450,
    isPartner: true,
    originationYTD: 28400000,
    workingBillingsYTD: 8900000,
    realisationRate: 98.1,
    utilisationRate: 82.4,
    capitalAccountBalance: 6200000,
    profitShareUnits: 100,
    skills: ['Cross-Border M&A', 'Board Advisory', 'Sovereign Wealth', 'Public Takeovers'],
    bio: 'Lead adviser on top-tier UK/US cross-border public acquisitions and sovereign advisory matters.',
    avatarUrl: 'https://picsum.photos/seed/ashcombe1/150/150'
  },
  {
    id: 'p-102',
    name: 'Sir Charles Thorne',
    grade: 'Managing Partner',
    title: 'Global Managing Partner',
    office: 'London',
    practice: 'M&A',
    email: 'c.thorne@ashcombestone.com',
    rateHourly: 1380,
    isPartner: true,
    originationYTD: 24100000,
    workingBillingsYTD: 7600000,
    realisationRate: 96.5,
    utilisationRate: 85.0,
    capitalAccountBalance: 5800000,
    profitShareUnits: 95,
    skills: ['M&A Strategy', 'Partnership Governance', 'Institutional Clients'],
    bio: 'Directs global operations and strategy across London, New York, Zurich and Singapore offices.',
    avatarUrl: 'https://picsum.photos/seed/thorne1/150/150'
  },
  {
    id: 'p-103',
    name: 'Eleanor Vance-Roth',
    grade: 'Equity Partner',
    title: 'Head of International Tax & Structuring',
    office: 'Zurich',
    practice: 'TAX',
    email: 'e.vance-roth@ashcombestone.com',
    rateHourly: 1250,
    isPartner: true,
    originationYTD: 19800000,
    workingBillingsYTD: 9200000,
    realisationRate: 95.8,
    utilisationRate: 91.2,
    capitalAccountBalance: 4500000,
    profitShareUnits: 85,
    skills: ['Transfer Pricing', 'Swiss Foundation Tax', 'Cross-Border Wealth', 'BEPS 2.0 Compliance'],
    bio: 'Specialist in multi-jurisdictional family office structures and corporate tax minimization frameworks.',
    avatarUrl: 'https://picsum.photos/seed/vance1/150/150'
  },
  {
    id: 'p-104',
    name: 'Marcus Sterling PC',
    grade: 'Equity Partner',
    title: 'Head of Complex Litigation & Arbitration',
    office: 'London',
    practice: 'LITIGATION',
    email: 'm.sterling@ashcombestone.com',
    rateHourly: 1300,
    isPartner: true,
    originationYTD: 16500000,
    workingBillingsYTD: 8100000,
    realisationRate: 93.4,
    utilisationRate: 89.5,
    capitalAccountBalance: 4100000,
    profitShareUnits: 80,
    skills: ['Commercial Court Litigation', 'LCIA Arbitration', 'Sovereign Immunity', 'Fraud Recovery'],
    bio: 'Appears before the UK Supreme Court, Privy Council and International Arbitral Tribunals.',
    avatarUrl: 'https://picsum.photos/seed/sterling1/150/150'
  },
  {
    id: 'p-105',
    name: 'Dr. Evelyn Chen',
    grade: 'Partner',
    title: 'Head of APAC Strategy & Corporate Advisory',
    office: 'Singapore',
    practice: 'STRATEGY',
    email: 'e.chen@ashcombestone.com',
    rateHourly: 1150,
    isPartner: true,
    originationYTD: 14200000,
    workingBillingsYTD: 6800000,
    realisationRate: 94.0,
    utilisationRate: 87.6,
    capitalAccountBalance: 3200000,
    profitShareUnits: 70,
    skills: ['ASEAN Expansion', 'Supply Chain Restructuring', 'Growth Equity'],
    bio: 'Advises Fortune 500 CEOs and Asian tech conglomerates on strategic transformation and market entry.',
    avatarUrl: 'https://picsum.photos/seed/chen1/150/150'
  },
  {
    id: 'p-106',
    name: 'Julian Montgomery',
    grade: 'Equity Partner',
    title: 'Head of Private Equity & M&A (US)',
    office: 'New York',
    practice: 'PRIVATE EQUITY',
    email: 'j.montgomery@ashcombestone.com',
    rateHourly: 1320,
    isPartner: true,
    originationYTD: 22100000,
    workingBillingsYTD: 7900000,
    realisationRate: 95.1,
    utilisationRate: 90.1,
    capitalAccountBalance: 4900000,
    profitShareUnits: 88,
    skills: ['LBOs', 'Carve-outs', 'Secondary Buyouts', 'Growth Capital'],
    bio: 'Represents tier-1 private equity sponsors in trillion-dollar asset class acquisitions.',
    avatarUrl: 'https://picsum.photos/seed/julian1/150/150'
  },
  {
    id: 'p-107',
    name: 'Tariq Al-Mansoor',
    grade: 'Partner',
    title: 'Head of Middle East Corporate & Banking',
    office: 'Dubai',
    practice: 'BANKING & FINANCE',
    email: 't.almansoor@ashcombestone.com',
    rateHourly: 1200,
    isPartner: true,
    originationYTD: 15800000,
    workingBillingsYTD: 6400000,
    realisationRate: 92.8,
    utilisationRate: 86.4,
    capitalAccountBalance: 3100000,
    profitShareUnits: 68,
    skills: ['Islamic Finance', 'Sovereign Bonds', 'Project Finance', 'GCC Regulatory'],
    bio: 'Advises GCC ministries, sovereign funds and regional banking syndicates.',
    avatarUrl: 'https://picsum.photos/seed/tariq1/150/150'
  },
  {
    id: 'p-108',
    name: 'Beatrix von Oldenburg',
    grade: 'Counsel',
    title: 'Senior Specialist Counsel - Private Client',
    office: 'Zurich',
    practice: 'PRIVATE CAPITAL',
    email: 'b.oldenburg@ashcombestone.com',
    rateHourly: 920,
    isPartner: false,
    originationYTD: 4200000,
    workingBillingsYTD: 4100000,
    realisationRate: 97.0,
    utilisationRate: 92.5,
    skills: ['Trust Law', 'Dynastic Succession', 'Art & Collectibles', 'Art Governance'],
    bio: 'Trusted adviser to multi-generational European industrialist families.',
    avatarUrl: 'https://picsum.photos/seed/beatrix1/150/150'
  },
  {
    id: 'p-109',
    name: 'Alistair Finch-Hatton',
    grade: 'Senior Associate',
    title: 'Managing Senior Associate - Corporate & M&A',
    office: 'London',
    practice: 'CORPORATE',
    email: 'a.finch@ashcombestone.com',
    rateHourly: 780,
    isPartner: false,
    originationYTD: 850000,
    workingBillingsYTD: 3400000,
    realisationRate: 93.8,
    utilisationRate: 94.2,
    skills: ['Share Purchase Agreements', 'Due Diligence Lead', 'Joint Ventures'],
    bio: 'Key deal manager for major FTSE 100 takeover transactions and joint ventures.',
    avatarUrl: 'https://picsum.photos/seed/finch1/150/150'
  },
  {
    id: 'p-110',
    name: 'Camille De La Tour',
    grade: 'Director',
    title: 'Audit & Forensic Accounting Director',
    office: 'Paris',
    practice: 'AUDIT & ACCOUNTANCY',
    email: 'c.delatour@ashcombestone.com',
    rateHourly: 880,
    isPartner: false,
    originationYTD: 2100000,
    workingBillingsYTD: 4800000,
    realisationRate: 96.2,
    utilisationRate: 89.0,
    skills: ['Forensic Audit', 'IFRS Standards', 'Fraud Investigation', 'Valuations'],
    bio: 'Leads complex financial investigations and expert witness accounting evaluations.',
    avatarUrl: 'https://picsum.photos/seed/camille1/150/150'
  }
];

export const INITIAL_CLIENTS: Client[] = [
  {
    id: 'c-301',
    code: 'AUR-001',
    name: 'Aurelia Industries PLC',
    category: 'MULTINATIONAL GROUP',
    jurisdiction: 'UK (London)',
    industry: 'Advanced Aerospace & Defence',
    relationshipPartnerId: 'p-101',
    secondaryPartnerIds: ['p-103', 'p-104'],
    relationshipTier: 'TIER_1_INSTITUTIONAL',
    riskRating: 'LOW',
    kycAmlStatus: 'VERIFIED',
    annualRevenueBilled: 14200000,
    unbilledWip: 2850000,
    agedDebt: 120000,
    marginPercentage: 42.5,
    onboardedDate: '2008-03-15',
    summaryNote: 'FTSE 50 defence industrial defense group. Longstanding Ashcombe client across Corporate, Tax and Litigation.',
    contacts: [
      { id: 'cc-1', name: 'Lord Marcus Aurelius', role: 'Group Chairman', email: 'chairman@aurelia.com', phone: '+44 20 7946 0100', isPrimary: false },
      { id: 'cc-2', name: 'Victoria Croft KC', role: 'General Counsel & Board Secretary', email: 'v.croft@aurelia.com', phone: '+44 20 7946 0102', isPrimary: true }
    ]
  },
  {
    id: 'c-302',
    code: 'RVF-002',
    name: 'Rothschild-Vane Family Office',
    category: 'FAMILY OFFICE / PRIVATE CLIENT',
    jurisdiction: 'EU (Paris/Zurich)',
    industry: 'Private Equity & Real Estate',
    relationshipPartnerId: 'p-103',
    secondaryPartnerIds: ['p-108'],
    relationshipTier: 'TIER_1_INSTITUTIONAL',
    riskRating: 'LOW',
    kycAmlStatus: 'VERIFIED',
    annualRevenueBilled: 8900000,
    unbilledWip: 1420000,
    agedDebt: 0,
    marginPercentage: 51.0,
    onboardedDate: '1998-11-20',
    summaryNote: 'Multi-generational European industrial family with £4.2bn AUM in real estate, private equity and vineyards.',
    contacts: [
      { id: 'cc-3', name: 'Baroness Helena Rothschild-Vane', role: 'Principal Trustee', email: 'baroness@rothschildvane.com', phone: '+41 44 211 8800', isPrimary: true }
    ]
  },
  {
    id: 'c-303',
    code: 'MCP-003',
    name: 'Meridian Capital Partners VIII',
    category: 'PRIVATE EQUITY SPONSOR',
    jurisdiction: 'US (New York)',
    industry: 'Global Technology & Healthcare PE',
    relationshipPartnerId: 'p-106',
    secondaryPartnerIds: ['p-101'],
    relationshipTier: 'TIER_1_INSTITUTIONAL',
    riskRating: 'LOW',
    kycAmlStatus: 'VERIFIED',
    annualRevenueBilled: 18500000,
    unbilledWip: 4100000,
    agedDebt: 450000,
    marginPercentage: 46.8,
    onboardedDate: '2015-06-10',
    summaryNote: '$28bn NY buyout fund. Ashcombe handles transatlantic acquisitions, debt financing and tax structuring.',
    contacts: [
      { id: 'cc-4', name: 'Jason Vance', role: 'Managing Director & Head of Deals', email: 'j.vance@meridiancap.com', phone: '+1 212 555 0199', isPrimary: true }
    ]
  },
  {
    id: 'c-304',
    code: 'SIF-004',
    name: 'Sovereign Infrastructure Fund',
    category: 'SOVEREIGN FUND',
    jurisdiction: 'ME (Dubai)',
    industry: 'Infrastructure, Energy & Ports',
    relationshipPartnerId: 'p-107',
    secondaryPartnerIds: ['p-101', 'p-105'],
    relationshipTier: 'TIER_1_INSTITUTIONAL',
    riskRating: 'LOW',
    kycAmlStatus: 'VERIFIED',
    annualRevenueBilled: 12100000,
    unbilledWip: 3200000,
    agedDebt: 0,
    marginPercentage: 48.2,
    onboardedDate: '2019-01-12',
    summaryNote: '$65bn state-backed infrastructure fund investing in European & Asian port and green energy assets.',
    contacts: [
      { id: 'cc-5', name: 'H.E. Ahmed Al-Maktoum', role: 'Chief Investment Officer', email: 'cio@sovereigninfra.ae', phone: '+971 4 312 9000', isPrimary: true }
    ]
  },
  {
    id: 'c-305',
    code: 'HEX-005',
    name: 'Hexagon Pharma AG',
    category: 'CORPORATION',
    jurisdiction: 'EU (Paris/Zurich)',
    industry: 'Pharmaceuticals & Biotechnology',
    relationshipPartnerId: 'p-103',
    secondaryPartnerIds: ['p-104'],
    relationshipTier: 'TIER_2_KEY_CLIENT',
    riskRating: 'MEDIUM',
    kycAmlStatus: 'VERIFIED',
    annualRevenueBilled: 6400000,
    unbilledWip: 980000,
    agedDebt: 85000,
    marginPercentage: 39.5,
    onboardedDate: '2021-09-04',
    summaryNote: 'Basel-headquartered Swiss bio-pharma firm with global IP litigation and cross-border research joint ventures.',
    contacts: [
      { id: 'cc-6', name: 'Dr. Klaus von Berg', role: 'VP Legal & IP Counsel', email: 'k.vonberg@hexagonpharma.ch', phone: '+41 61 322 4410', isPrimary: true }
    ]
  }
];

export const INITIAL_MATTERS: Matter[] = [
  {
    id: 'm-501',
    code: 'AUR-2026-01',
    title: 'Project Sovereign: £2.4bn Acquisition of Skynet Systems Defence',
    clientId: 'c-301',
    practice: 'M&A',
    moduleType: 'LEGAL',
    leadPartnerId: 'p-101',
    relationshipPartnerId: 'p-101',
    teamMemberIds: ['p-101', 'p-103', 'p-109'],
    jurisdiction: 'UK (London)',
    status: 'ACTIVE',
    feeModel: 'BLENDED_RATE',
    agreedBudget: 3200000,
    wipAmount: 1850000,
    billedYtd: 1100000,
    openingDate: '2026-01-10',
    targetClosingDate: '2026-05-30',
    riskRating: 'HIGH',
    confidentialityLevel: 'RESTRICTED_BARRIER',
    description: 'Public-to-private takeover of UK defense technology provider under UK Takeover Code & National Security and Investment Act.',
    tasks: [
      { id: 't-1', title: 'Finalize Scheme of Arrangement document', assigneeId: 'p-109', dueDate: '2026-03-25', status: 'IN_PROGRESS', priority: 'CRITICAL' },
      { id: 't-2', title: 'Submit NSIA Regulatory Clearance Filing to Cabinet Office', assigneeId: 'p-101', dueDate: '2026-03-28', status: 'PENDING', priority: 'HIGH' }
    ],
    deadlines: [
      { id: 'd-1', title: 'FCA Takeover Panel Rule 2.7 Announcement', date: '2026-04-02', type: 'REGULATORY', responsiblePersonId: 'p-101', isMandatory: true },
      { id: 'd-2', title: 'High Court Scheme Sanction Hearing', date: '2026-05-15', type: 'COURT', responsiblePersonId: 'p-104', isMandatory: true }
    ],
    legalMeta: {
      courtCaseNo: 'CR-2026-00912',
      forum: 'High Court of Justice (Chancery Division - Companies Court)',
      counterparty: 'Skynet Systems Group PLC',
      opposingCounsel: 'Slaughter and May',
      judgeOrArbitrator: 'Mr Justice Hildyard'
    }
  },
  {
    id: 'm-502',
    code: 'RVF-2025-09',
    title: 'Global Estate Tax & Swiss Trust Restructuring',
    clientId: 'c-302',
    practice: 'TAX',
    moduleType: 'TAX',
    leadPartnerId: 'p-103',
    relationshipPartnerId: 'p-103',
    teamMemberIds: ['p-103', 'p-108'],
    jurisdiction: 'EU (Paris/Zurich)',
    status: 'ACTIVE',
    feeModel: 'FIXED_FEE',
    agreedBudget: 1100000,
    wipAmount: 620000,
    billedYtd: 480000,
    openingDate: '2025-09-01',
    targetClosingDate: '2026-06-30',
    riskRating: 'LOW',
    confidentialityLevel: 'PARTNER_ONLY',
    description: 'Multi-jurisdictional trust restructuring for third-generation heirs under OECD Pillar 2 and Swiss federal tax harmonisation.',
    tasks: [
      { id: 't-3', title: 'Draft Zurich Canton Tax Ruling Memorandum', assigneeId: 'p-108', dueDate: '2026-03-20', status: 'IN_PROGRESS', priority: 'HIGH' }
    ],
    deadlines: [
      { id: 'd-3', title: 'Swiss Cantonal Tax Ruling Filing Deadline', date: '2026-03-31', type: 'TAX_FILING', responsiblePersonId: 'p-103', isMandatory: true }
    ],
    taxMeta: {
      taxYear: '2025/2026',
      taxAuthority: 'Swiss Federal Tax Administration (ESTV)',
      ruleVersion: 'v2026.1 (Pillar 2 / Swiss StG)',
      taxStructureType: 'Family Holding Trust & Foundation'
    }
  },
  {
    id: 'm-503',
    code: 'MCP-2026-04',
    title: '$1.8bn Acquisition of CloudNexus Systems (LBO)',
    clientId: 'c-303',
    practice: 'PRIVATE EQUITY',
    moduleType: 'CONSULTING',
    leadPartnerId: 'p-106',
    relationshipPartnerId: 'p-106',
    teamMemberIds: ['p-106', 'p-105', 'p-110'],
    jurisdiction: 'US (New York)',
    status: 'ACTIVE',
    feeModel: 'HOURLY_RATE',
    agreedBudget: 2800000,
    wipAmount: 1250000,
    billedYtd: 1550000,
    openingDate: '2026-02-01',
    targetClosingDate: '2026-06-15',
    riskRating: 'MEDIUM',
    confidentialityLevel: 'STANDARD',
    description: 'Leveraged buyout of SaaS enterprise platform with debt syndicate financing and 100-day operational transformation plan.',
    tasks: [
      { id: 't-4', title: 'Complete Quality of Earnings (QofE) Forensic Report', assigneeId: 'p-110', dueDate: '2026-03-22', status: 'IN_PROGRESS', priority: 'CRITICAL' }
    ],
    deadlines: [
      { id: 'd-4', title: 'Debt Commitment Letter Binding Execution', date: '2026-04-10', type: 'CLOSING_DATE', responsiblePersonId: 'p-106', isMandatory: true }
    ],
    consultingMeta: {
      workstreamCount: 4,
      deliverables: ['100-Day Operating Plan', 'Tech Stack Valuation Report', 'Vendor Due Diligence'],
      operatingModelPhase: 'Phase 2: Commercial & Financial Due Diligence'
    }
  },
  {
    id: 'm-504',
    code: 'SIF-2026-02',
    title: 'North Sea Wind Port Concession Agreement (£950m)',
    clientId: 'c-304',
    practice: 'BANKING & FINANCE',
    moduleType: 'LEGAL',
    leadPartnerId: 'p-107',
    relationshipPartnerId: 'p-107',
    teamMemberIds: ['p-107', 'p-101'],
    jurisdiction: 'UK (London)',
    status: 'ACTIVE',
    feeModel: 'CAPPED_FEE',
    agreedBudget: 1500000,
    wipAmount: 890000,
    billedYtd: 610000,
    openingDate: '2026-01-18',
    targetClosingDate: '2026-07-01',
    riskRating: 'LOW',
    confidentialityLevel: 'STANDARD',
    description: '30-year public-private port infrastructure concession for offshore wind terminal expansion.',
    tasks: [
      { id: 't-5', title: 'Draft Crown Estate Lease & Concession Deed', assigneeId: 'p-107', dueDate: '2026-04-01', status: 'PENDING', priority: 'STANDARD' }
    ],
    deadlines: [
      { id: 'd-5', title: 'Department for Energy Security Approval', date: '2026-04-20', type: 'REGULATORY', responsiblePersonId: 'p-107', isMandatory: false }
    ]
  }
];

export const INITIAL_RELATIONSHIPS: RelationshipEdge[] = [
  { id: 'r-1', sourceId: 'p-101', sourceType: 'PERSON', targetId: 'c-301', targetType: 'CLIENT', relationship: 'OWNS', strength: 'PRIMARY', notes: 'Lead Relationship Partner since 2008.' },
  { id: 'r-2', sourceId: 'p-103', sourceType: 'PERSON', targetId: 'c-302', targetType: 'CLIENT', relationship: 'ADVISES', strength: 'PRIMARY', notes: 'Trusted tax counsel for 20 years.' },
  { id: 'r-3', sourceId: 'p-106', sourceType: 'PERSON', targetId: 'c-303', targetType: 'CLIENT', relationship: 'OWNS', strength: 'PRIMARY', notes: 'Brought fund on board during 2015 NY expansion.' },
  { id: 'r-4', sourceId: 'c-301', sourceType: 'CLIENT', targetId: 'c-304', targetType: 'CLIENT', relationship: 'PARTNERS_WITH', strength: 'STRONG', notes: 'Joint venture partners in green port logistics.' },
  { id: 'r-5', sourceId: 'p-107', sourceType: 'PERSON', targetId: 'c-304', targetType: 'CLIENT', relationship: 'INTRODUCED', strength: 'PRIMARY', notes: 'Introduced by Dubai Government Board.' }
];

export const INITIAL_TIME_ENTRIES: TimeEntry[] = [
  {
    id: 't-101',
    date: '2026-03-08',
    personId: 'p-101',
    matterId: 'm-501',
    clientId: 'c-301',
    activityDescription: 'Attendance on Takeover Panel Rule 2.7 announcement and Board advisory meeting with General Counsel.',
    category: 'BILLABLE',
    hours: 4.5,
    hourlyRate: 1450,
    isApproved: true,
    billedStatus: 'UNBILLED'
  },
  {
    id: 't-102',
    date: '2026-03-09',
    personId: 'p-109',
    matterId: 'm-501',
    clientId: 'c-301',
    activityDescription: 'Drafting Scheme of Arrangement explanatory statement and NSIA filing schedule.',
    category: 'BILLABLE',
    hours: 6.0,
    hourlyRate: 780,
    isApproved: true,
    billedStatus: 'UNBILLED'
  },
  {
    id: 't-103',
    date: '2026-03-09',
    personId: 'p-103',
    matterId: 'm-502',
    clientId: 'c-302',
    activityDescription: 'Review of OECD Pillar 2 GloBE rules and Swiss federal tax ruling draft.',
    category: 'BILLABLE',
    hours: 3.8,
    hourlyRate: 1250,
    isApproved: true,
    billedStatus: 'UNBILLED'
  }
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-901',
    invoiceNumber: 'INV-2026-0042',
    matterId: 'm-501',
    clientId: 'c-301',
    leadPartnerId: 'p-101',
    issueDate: '2026-02-28',
    dueDate: '2026-03-30',
    netAmount: 850000,
    vatTaxAmount: 170000,
    grossAmount: 1020000,
    status: 'SENT_TO_CLIENT',
    paidAmount: 0,
    timeEntryIds: ['t-101', 't-102']
  },
  {
    id: 'inv-902',
    invoiceNumber: 'INV-2026-0038',
    matterId: 'm-502',
    clientId: 'c-302',
    leadPartnerId: 'p-103',
    issueDate: '2026-02-15',
    dueDate: '2026-03-15',
    netAmount: 320000,
    vatTaxAmount: 0,
    grossAmount: 320000,
    status: 'PAID',
    paidAmount: 320000,
    timeEntryIds: ['t-103']
  }
];

export const INITIAL_KNOWLEDGE: KnowledgeItem[] = [
  {
    id: 'k-701',
    title: 'Precedent: UK National Security & Investment Act (NSIA) Defense Sector Approval Memorandum',
    category: 'PRECEDENT',
    practice: 'M&A',
    jurisdiction: 'UK (London)',
    authorPersonId: 'p-101',
    clientId: 'c-301',
    matterId: 'm-501',
    createdDate: '2025-11-14',
    summary: 'Comprehensive analysis of Cabinet Office ISU approval conditions for sensitive UK defense acquisitions, including mandatory monitoring trustee terms.',
    keyTopics: ['NSIA', 'Defense Acquisition', 'Foreign Investment Screening', 'Cabinet Office'],
    documentUrl: '/docs/nsia_precedent_2025.pdf',
    fileSize: '4.2 MB'
  },
  {
    id: 'k-702',
    title: 'Tax Memorandum: Pillar 2 Minimum Tax Structuring for Swiss Family Holding Companies',
    category: 'TAX_ANALYSIS',
    practice: 'TAX',
    jurisdiction: 'EU (Paris/Zurich)',
    authorPersonId: 'p-103',
    clientId: 'c-302',
    matterId: 'm-502',
    createdDate: '2026-01-22',
    summary: 'Analysis of GloBE rules application to non-corporate family wealth vehicles under Swiss federal implementation guidelines.',
    keyTopics: ['Pillar 2', 'Swiss Tax', 'Family Office', 'GloBE Rules', 'Transfer Pricing'],
    documentUrl: '/docs/pillar2_swiss_wealth.pdf',
    fileSize: '2.8 MB'
  },
  {
    id: 'k-703',
    title: 'Model Agreement: Transatlantic Leveraged Buyout Senior Credit Facility Framework',
    category: 'TRANSACTION_MODEL',
    practice: 'PRIVATE EQUITY',
    jurisdiction: 'US (New York)',
    authorPersonId: 'p-106',
    createdDate: '2025-12-05',
    summary: 'Standardized LMA/LSTA hybrid debt documentation for US sponsors acquiring European tech targets with cross-border collateral.',
    keyTopics: ['LBO', 'Credit Agreement', 'LSTA', 'Cross-Border Security', 'Debt Syndication'],
    documentUrl: '/docs/lbo_hybrid_facility_2025.docx',
    fileSize: '1.9 MB'
  }
];

export const INITIAL_CONFLICTS: ConflictCheckRequest[] = [
  {
    id: 'conf-101',
    matterTitle: 'Project Aegis: Proposed Representation of BAE Systems Supplier Bidding Against Aurelia',
    proposedClientId: 'c-99',
    proposedClientName: 'Apex Defense Technologies Inc.',
    counterparties: ['Aurelia Industries PLC', 'Ministry of Defence'],
    directorsOrShareholders: ['Sir John Finch', 'Gen. Arthur Pendelton'],
    requestedByPersonId: 'p-109',
    checkDate: '2026-03-08',
    status: 'CONFIRMED_CONFLICT',
    riskAnalysis: 'Direct commercial conflict with Aurelia Industries PLC (Tier 1 institutional client). Active matter AUR-2026-01 involves identical defense bidding domain. Cannot represent target counterparty without explicit client waiver and strict Information Barrier.',
    matchedRecords: [
      { type: 'EXISTING_CLIENT', name: 'Aurelia Industries PLC', details: 'Client Code AUR-001 (Tier 1)' },
      { type: 'ACTIVE_MATTER', name: 'Project Sovereign', details: 'Matter M-501 (Lead: Lord Ashcombe KC)' }
    ]
  },
  {
    id: 'conf-102',
    matterTitle: 'Tax Advisory for Swiss Reinsurance Subsidiary Restructuring',
    proposedClientId: 'c-305',
    proposedClientName: 'Hexagon Pharma AG',
    counterparties: ['Novartis AG', 'Swiss Federal Tax Authority'],
    directorsOrShareholders: ['Dr. Klaus von Berg'],
    requestedByPersonId: 'p-103',
    checkDate: '2026-03-09',
    status: 'CLEAR',
    riskAnalysis: 'No active or historical adversary relationships. Cleared across all 6 global office databases.',
    matchedRecords: []
  }
];

export const INITIAL_PORTAL_REQUESTS: ClientPortalRequest[] = [
  {
    id: 'req-801',
    clientId: 'c-301',
    matterId: 'm-501',
    title: 'Execute Section 172 Director Statements & Board Resolution',
    requestedBy: 'Victoria Croft KC (General Counsel)',
    assignedToPersonId: 'p-109',
    dueDate: '2026-03-15',
    status: 'PENDING_CLIENT_UPLOAD',
    description: 'Please review and execute the attached board resolution authorizing the Takeover Announcement.',
    attachedDocumentName: 'Aurelia_Board_Res_Rule27.pdf'
  },
  {
    id: 'req-802',
    clientId: 'c-302',
    matterId: 'm-502',
    title: 'Provide 2025 Audited Balance Sheets for Liechtenstein Foundation',
    requestedBy: 'Baroness Helena Rothschild-Vane',
    assignedToPersonId: 'p-108',
    dueDate: '2026-03-25',
    status: 'UNDER_PARTNER_REVIEW',
    description: 'Financial records uploaded for Swiss cantonal tax ruling verification.',
    attachedDocumentName: 'Stiftung_Financials_2025.pdf'
  }
];

export const INITIAL_PARTNER_ECONOMICS: PartnerEconomics[] = [
  { personId: 'p-101', name: 'Lord Henry Ashcombe KC', equityTier: 'Senior Equity (100 Points)', capitalAccount: 6200000, targetDrawAnnual: 2400000, ytdDrawTaken: 1600000, originationBonusEligible: 852000, workingAttorneyRevenue: 8900000, clientOriginationRevenue: 28400000, profitShareAllocated: 3450000 },
  { personId: 'p-102', name: 'Sir Charles Thorne', equityTier: 'Managing Equity (95 Points)', capitalAccount: 5800000, targetDrawAnnual: 2280000, ytdDrawTaken: 1520000, originationBonusEligible: 723000, workingAttorneyRevenue: 7600000, clientOriginationRevenue: 24100000, profitShareAllocated: 3180000 },
  { personId: 'p-103', name: 'Eleanor Vance-Roth', equityTier: 'Senior Equity (85 Points)', capitalAccount: 4500000, targetDrawAnnual: 2040000, ytdDrawTaken: 1360000, originationBonusEligible: 594000, workingAttorneyRevenue: 9200000, clientOriginationRevenue: 19800000, profitShareAllocated: 2820000 },
  { personId: 'p-104', name: 'Marcus Sterling PC', equityTier: 'Equity Partner (80 Points)', capitalAccount: 4100000, targetDrawAnnual: 1920000, ytdDrawTaken: 1280000, originationBonusEligible: 495000, workingAttorneyRevenue: 8100000, clientOriginationRevenue: 16500000, profitShareAllocated: 2580000 },
  { personId: 'p-106', name: 'Julian Montgomery', equityTier: 'Equity Partner (88 Points)', capitalAccount: 4900000, targetDrawAnnual: 2110000, ytdDrawTaken: 1400000, originationBonusEligible: 663000, workingAttorneyRevenue: 7900000, clientOriginationRevenue: 22100000, profitShareAllocated: 2950000 }
];
