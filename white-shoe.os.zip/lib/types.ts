export type Jurisdiction = 'UK (London)' | 'US (New York)' | 'EU (Paris/Zurich)' | 'APAC (Singapore)' | 'ME (Dubai)';

export type PracticeGroup = 
  | 'CORPORATE' 
  | 'M&A' 
  | 'PRIVATE EQUITY' 
  | 'LITIGATION' 
  | 'TAX' 
  | 'REAL ESTATE' 
  | 'EMPLOYMENT' 
  | 'BANKING & FINANCE' 
  | 'RESTRUCTURING' 
  | 'REGULATORY' 
  | 'AUDIT & ACCOUNTANCY' 
  | 'STRATEGY' 
  | 'OPERATIONS' 
  | 'PRIVATE CAPITAL';

export type ProfessionalGrade = 
  | 'Senior Partner'
  | 'Managing Partner'
  | 'Equity Partner'
  | 'Partner'
  | 'Counsel'
  | 'Managing Associate'
  | 'Senior Associate'
  | 'Associate'
  | 'Director'
  | 'Senior Manager'
  | 'Manager'
  | 'Senior Consultant'
  | 'Consultant'
  | 'Senior Accountant'
  | 'Analyst'
  | 'Researcher';

export interface Person {
  id: string;
  name: string;
  grade: ProfessionalGrade;
  title: string;
  office: string;
  practice: PracticeGroup;
  email: string;
  rateHourly: number; // in GBP
  isPartner: boolean;
  originationYTD: number;
  workingBillingsYTD: number;
  realisationRate: number; // percentage e.g. 94.5
  utilisationRate: number; // percentage e.g. 88.2
  capitalAccountBalance?: number;
  profitShareUnits?: number;
  skills: string[];
  bio: string;
  avatarUrl?: string;
}

export type ClientCategory = 
  | 'CORPORATION'
  | 'MULTINATIONAL GROUP'
  | 'PRIVATE EQUITY SPONSOR'
  | 'FAMILY OFFICE / PRIVATE CLIENT'
  | 'TRUST'
  | 'FOUNDATION'
  | 'SOVEREIGN FUND'
  | 'GOVERNMENT'
  | 'BANK & INSTITUTION'
  | 'CHARITY / UNIVERSITY';

export interface ClientContact {
  id: string;
  name: string;
  role: string;
  email: string;
  phone: string;
  isPrimary: boolean;
}

export type RelationshipTier = 'TIER_1_INSTITUTIONAL' | 'TIER_2_KEY_CLIENT' | 'TIER_3_REGULAR' | 'PROSPECT';

export interface Client {
  id: string;
  code: string;
  name: string;
  category: ClientCategory;
  jurisdiction: Jurisdiction;
  industry: string;
  relationshipPartnerId: string;
  secondaryPartnerIds: string[];
  relationshipTier: RelationshipTier;
  riskRating: 'LOW' | 'MEDIUM' | 'ELEVATED' | 'REQUIRES_PARTNER_APPROVAL';
  kycAmlStatus: 'VERIFIED' | 'PENDING_REVIEW' | 'RE_CERTIFICATION_DUE';
  annualRevenueBilled: number;
  unbilledWip: number;
  agedDebt: number;
  marginPercentage: number;
  contacts: ClientContact[];
  onboardedDate: string;
  summaryNote: string;
}

export type RelationshipType = 
  | 'KNOWS' 
  | 'ADVISES' 
  | 'INTRODUCED' 
  | 'OWNS' 
  | 'CONTROLS' 
  | 'DIRECTS' 
  | 'REPRESENTS' 
  | 'AUDITS' 
  | 'CONSULTS' 
  | 'INVESTS' 
  | 'PARTNERS_WITH';

export interface RelationshipEdge {
  id: string;
  sourceId: string; // Person or Client ID
  sourceType: 'PERSON' | 'CLIENT' | 'ENTITY';
  targetId: string; // Person or Client ID
  targetType: 'PERSON' | 'CLIENT' | 'ENTITY';
  relationship: RelationshipType;
  strength: 'PRIMARY' | 'STRONG' | 'HISTORIC' | 'INFORMAL';
  notes: string;
}

export type ModuleType = 'LEGAL' | 'TAX' | 'ACCOUNTANCY' | 'CONSULTING' | 'ADVISORY';

export type FeeModel = 'HOURLY_RATE' | 'FIXED_FEE' | 'CAPPED_FEE' | 'RETAINER' | 'SUCCESS_FEE' | 'BLENDED_RATE';

export type MatterStatus = 'PRE_ENGAGEMENT' | 'CONFLICT_CHECK' | 'ACTIVE' | 'PENDING_REVIEW' | 'BILLING' | 'CLOSED' | 'ARCHIVED';

export interface MatterTask {
  id: string;
  title: string;
  assigneeId: string;
  dueDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'BLOCKED';
  priority: 'HIGH' | 'CRITICAL' | 'STANDARD';
}

export interface MatterDeadline {
  id: string;
  title: string;
  date: string;
  type: 'COURT' | 'TAX_FILING' | 'REGULATORY' | 'CLOSING_DATE' | 'CLIENT_MILESTONE';
  responsiblePersonId: string;
  isMandatory: boolean;
}

export interface Matter {
  id: string;
  code: string;
  title: string;
  clientId: string;
  practice: PracticeGroup;
  moduleType: 'LEGAL' | 'TAX' | 'ACCOUNTANCY' | 'CONSULTING' | 'ADVISORY';
  leadPartnerId: string;
  relationshipPartnerId: string;
  teamMemberIds: string[];
  jurisdiction: Jurisdiction;
  status: MatterStatus;
  feeModel: FeeModel;
  agreedBudget: number;
  wipAmount: number;
  billedYtd: number;
  openingDate: string;
  targetClosingDate: string;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  confidentialityLevel: 'STANDARD' | 'RESTRICTED_BARRIER' | 'PARTNER_ONLY';
  description: string;
  tasks: MatterTask[];
  deadlines: MatterDeadline[];
  
  // Practice-specific metadata
  legalMeta?: {
    courtCaseNo?: string;
    forum?: string;
    counterparty?: string;
    opposingCounsel?: string;
    judgeOrArbitrator?: string;
  };
  taxMeta?: {
    taxYear?: string;
    taxAuthority?: string;
    ruleVersion?: string;
    taxStructureType?: string;
  };
  accountancyMeta?: {
    auditPeriod?: string;
    financialFramework?: string;
    ledgerStatus?: string;
    partnerSignOffDate?: string;
  };
  consultingMeta?: {
    workstreamCount?: number;
    deliverables?: string[];
    operatingModelPhase?: string;
  };
}

export interface TimeEntry {
  id: string;
  personId: string;
  matterId: string;
  clientId: string;
  date: string;
  hours: number;
  hourlyRate: number;
  category: 'BILLABLE' | 'NON_BILLABLE' | 'BUSINESS_DEVELOPMENT' | 'KNOWLEDGE' | 'MANAGEMENT' | 'PRO_BONO';
  activityDescription: string;
  isApproved: boolean;
  billedStatus: 'UNBILLED' | 'DRAFT_BILL' | 'INVOICED' | 'WRITTEN_OFF';
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  matterId: string;
  leadPartnerId: string;
  issueDate: string;
  dueDate: string;
  grossAmount: number;
  vatTaxAmount: number;
  netAmount: number;
  status: 'DRAFT' | 'PARTNER_APPROVED' | 'SENT_TO_CLIENT' | 'PAID' | 'OVERDUE' | 'PARTIALLY_PAID';
  paidAmount: number;
  timeEntryIds: string[];
}

export interface ConflictCheckRequest {
  id: string;
  matterTitle: string;
  proposedClientId: string;
  proposedClientName: string;
  counterparties: string[];
  directorsOrShareholders: string[];
  requestedByPersonId: string;
  checkDate: string;
  status: 'CLEAR' | 'POTENTIAL_CONFLICT' | 'CONFIRMED_CONFLICT' | 'REQUIRES_PARTNER_REVIEW';
  riskAnalysis: string;
  matchedRecords: Array<{
    type: 'EXISTING_CLIENT' | 'FORMER_CLIENT' | 'ACTIVE_MATTER' | 'COUNTERPARTY' | 'BARRIER';
    name: string;
    details: string;
  }>;
}

export interface KnowledgeItem {
  id: string;
  title: string;
  category: 'PRECEDENT' | 'RESEARCH_MEMO' | 'TAX_ANALYSIS' | 'TRANSACTION_MODEL' | 'OPINION_LETTER' | 'DEAL_STUDY';
  practice: PracticeGroup;
  jurisdiction: Jurisdiction;
  authorPersonId: string;
  clientId?: string;
  matterId?: string;
  createdDate: string;
  summary: string;
  keyTopics: string[];
  documentUrl?: string;
  fileSize?: string;
}

export interface ClientPortalRequest {
  id: string;
  clientId: string;
  matterId: string;
  title: string;
  requestedBy: string;
  assignedToPersonId: string;
  dueDate: string;
  status: 'PENDING_CLIENT_UPLOAD' | 'UNDER_PARTNER_REVIEW' | 'APPROVED' | 'COMPLETED';
  description: string;
  attachedDocumentName?: string;
}

export interface PartnerEconomics {
  personId: string;
  name: string;
  equityTier: string;
  capitalAccount: number;
  targetDrawAnnual: number;
  ytdDrawTaken: number;
  originationBonusEligible: number;
  workingAttorneyRevenue: number;
  clientOriginationRevenue: number;
  profitShareAllocated: number;
}
