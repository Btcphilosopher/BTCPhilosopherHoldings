'use client';

import React, { useState } from 'react';
import { 
  Lock, 
  FileText, 
  Clock, 
  ShieldCheck, 
  Upload, 
  CheckCircle2, 
  Send, 
  DollarSign, 
  Download,
  AlertCircle
} from 'lucide-react';
import { Client, Matter, Invoice } from '@/lib/types';

interface ClientPortalViewProps {
  clients: Client[];
  matters: Matter[];
  invoices: Invoice[];
}

export const ClientPortalView: React.FC<ClientPortalViewProps> = ({
  clients,
  matters,
  invoices
}) => {
  // Simulate active logged-in client as Aurelia Industries PLC
  const client = clients[0];
  const clientMatters = matters.filter((m) => m.clientId === client?.id || m.clientId === 'c-101');
  const [requestText, setRequestText] = useState('');
  const [submittedRequest, setSubmittedRequest] = useState(false);

  const handleSendRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestText.trim()) return;
    setSubmittedRequest(true);
    setTimeout(() => {
      setRequestText('');
    }, 1500);
  };

  return (
    <div className="max-w-[1500px] mx-auto px-4 py-8 space-y-8">
      {/* Client Portal Header */}
      <div className="bg-[#080c14] border border-[#c5a059]/40 rounded-lg p-6 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1e293b] pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded border border-[#c5a059] bg-[#0f172a] flex items-center justify-center font-serif-title text-[#c5a059] font-bold text-sm">
              AST
            </div>
            <div>
              <span className="text-[10px] font-mono text-[#c5a059] uppercase tracking-widest">
                PRIVATE CLIENT PORTAL · CONFIDENTIAL & ENCRYPTED
              </span>
              <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9]">
                {client ? client.name : 'Aurelia Industries PLC'}
              </h1>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono text-[#10b981] bg-[#064e3b]/30 border border-[#047857] px-3 py-1.5 rounded">
            <ShieldCheck className="w-4 h-4" />
            <span>256-bit Encrypted Vault Connection Active</span>
          </div>
        </div>

        <p className="text-xs text-[#94a3b8] font-serif-body">
          Welcome to Ashcombe, Stone & Thorne&apos;s client interface. Review real-time matter progress, fee burn rates, pending approvals, and secure document vault transfers.
        </p>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Active Matters & Budget Burn */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4 shadow-xl">
            <div className="border-b border-[#141d2e] pb-3 flex justify-between items-center">
              <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
                YOUR INSTRUCTED MATTERS & ENGAGEMENTS
              </h2>
              <span className="text-[10px] font-mono text-[#64748b]">{clientMatters.length} Active Instructions</span>
            </div>

            <div className="space-y-4">
              {clientMatters.map((matter) => (
                <div key={matter.id} className="p-4 rounded bg-[#090d16] border border-[#1e293b] space-y-3">
                  <div className="flex justify-between items-start border-b border-[#1a2333] pb-2">
                    <div>
                      <span className="text-[10px] font-mono text-[#c5a059]">{matter.code}</span>
                      <h3 className="font-serif-title font-bold text-sm text-[#f1f5f9]">{matter.title}</h3>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#064e3b] text-[#a7f3d0]">
                      {matter.status}
                    </span>
                  </div>

                  <p className="text-xs text-[#94a3b8] font-serif-body">{matter.description}</p>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs font-mono">
                    <div className="bg-[#0b0f17] p-2 rounded">
                      <p className="text-[9px] text-[#64748b]">AGREED FEE BUDGET</p>
                      <p className="text-[#f1f5f9] font-bold">£{matter.agreedBudget.toLocaleString()}</p>
                    </div>
                    <div className="bg-[#0b0f17] p-2 rounded">
                      <p className="text-[9px] text-[#64748b]">CURRENT FEE BURN</p>
                      <p className="text-[#dfb76c] font-bold">£{matter.wipAmount.toLocaleString()}</p>
                    </div>
                    <div className="bg-[#0b0f17] p-2 rounded">
                      <p className="text-[9px] text-[#64748b]">TARGET CLOSING</p>
                      <p className="text-[#10b981] font-bold">{matter.targetClosingDate}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* DOCUMENT VAULT & E-SIGNATURES */}
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4 shadow-xl">
            <div className="border-b border-[#141d2e] pb-3 flex justify-between items-center">
              <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
                CONFIDENTIAL DOCUMENT VAULT & PENDING APPROVALS
              </h2>
              <span className="text-[10px] font-mono text-[#c5a059]">2 Documents Awaiting Signature</span>
            </div>

            <div className="space-y-3">
              <div className="p-3.5 rounded bg-[#090d16] border border-[#1e293b] flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3">
                  <FileText className="w-5 h-5 text-[#c5a059]" />
                  <div>
                    <p className="font-serif-title font-bold text-[#f1f5f9]">UK NSIA Regulatory Clearance Filing Notice.pdf</p>
                    <p className="text-[10px] text-[#64748b] font-mono">Requires Board Signature · Uploaded 09 Sep 2026</p>
                  </div>
                </div>
                <button className="px-3 py-1.5 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-bold text-xs cursor-pointer">
                  Review & Sign
                </button>
              </div>

              <div className="p-3.5 rounded bg-[#090d16] border border-[#1e293b] flex items-center justify-between text-xs">
                <div className="flex items-center space-x-3">
                  <FileText className="w-5 h-5 text-[#c5a059]" />
                  <div>
                    <p className="font-serif-title font-bold text-[#f1f5f9]">Draft M&A Share Purchase Agreement (v4.2).pdf</p>
                    <p className="text-[10px] text-[#64748b] font-mono">For Client Executive Review · Uploaded 08 Sep 2026</p>
                  </div>
                </div>
                <button className="px-3 py-1.5 rounded bg-[#1e293b] hover:bg-[#334155] text-[#f1f5f9] text-xs flex items-center space-x-1 cursor-pointer">
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Direct Partner Request Engine & Secure Upload */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-5 space-y-4 shadow-xl">
            <div className="border-b border-[#141d2e] pb-3">
              <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
                SUBMIT DIRECT INSTRUCTION OR ADVISORY REQUEST
              </h2>
            </div>

            <form onSubmit={handleSendRequest} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#94a3b8] mb-1 font-medium">Message for Lead Partner (Lord Henry Ashcombe KC):</label>
                <textarea
                  rows={4}
                  value={requestText}
                  onChange={(e) => setRequestText(e.target.value)}
                  placeholder="Inquire regarding matter strategy, urgent filings or new transaction instructions..."
                  className="w-full bg-[#090d16] border border-[#334155] rounded p-3 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-bold text-xs uppercase transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Transmit Secure Request</span>
              </button>
            </form>

            {submittedRequest && (
              <div className="p-3 rounded bg-[#064e3b]/30 border border-[#047857] text-xs text-[#a7f3d0] font-mono flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
                <span>Request transmitted to Lead Partner&apos;s terminal.</span>
              </div>
            )}
          </div>

          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-5 space-y-4 shadow-xl text-center">
            <Upload className="w-8 h-8 text-[#c5a059] mx-auto" />
            <h3 className="font-serif-title text-xs font-bold text-[#f1f5f9] uppercase">
              SECURE DOCUMENT UPLOAD VAULT
            </h3>
            <p className="text-[11px] text-[#94a3b8]">
              Drag & drop confidential corporate contracts, financial statements, or regulatory filings here.
            </p>
            <button className="px-4 py-2 rounded bg-[#1e293b] hover:bg-[#334155] text-xs text-[#f1f5f9] cursor-pointer">
              Select Confidential Files
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
