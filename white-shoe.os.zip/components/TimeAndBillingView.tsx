'use client';

import React, { useState } from 'react';
import { 
  Clock, 
  Plus, 
  CheckCircle2, 
  FileCheck, 
  TrendingUp, 
  DollarSign, 
  Send, 
  AlertCircle, 
  Filter, 
  Receipt, 
  CheckSquare, 
  ChevronRight,
  PieChart
} from 'lucide-react';
import { TimeEntry, Invoice, Person, Matter, Client } from '@/lib/types';

interface TimeAndBillingViewProps {
  timeEntries: TimeEntry[];
  invoices: Invoice[];
  people: Person[];
  matters: Matter[];
  clients: Client[];
  onOpenTimeModal: () => void;
}

export const TimeAndBillingView: React.FC<TimeAndBillingViewProps> = ({
  timeEntries,
  invoices,
  people,
  matters,
  clients,
  onOpenTimeModal
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'TIME' | 'DRAFT_BILLS' | 'PROFITABILITY'>('TIME');

  const getPersonName = (personId: string) => {
    const p = people.find((item) => item.id === personId);
    return p ? `${p.name} (${p.grade})` : personId;
  };

  const getMatterTitle = (matterId: string) => {
    const m = matters.find((item) => item.id === matterId);
    return m ? m.title : matterId;
  };

  const totalUnbilledWip = timeEntries
    .filter((t) => t.billedStatus === 'UNBILLED')
    .reduce((acc, t) => acc + t.hours * t.hourlyRate, 0);

  const totalApprovedTimeHours = timeEntries
    .filter((t) => t.isApproved)
    .reduce((acc, t) => acc + t.hours, 0);

  return (
    <div className="max-w-[1700px] mx-auto px-4 py-8 space-y-8">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1e293b] pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-[#c5a059]" />
            <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9] tracking-wider uppercase">
              Time Recording, Billing & Profitability Control
            </h1>
          </div>
          <p className="text-xs text-[#94a3b8] font-serif-body pt-1">
            Professional Time Engine · Rate Cards · Draft Pre-Bills · Realisation & Margin Intelligence
          </p>
        </div>

        <button
          onClick={onOpenTimeModal}
          className="flex items-center space-x-2 px-4 py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-semibold text-xs transition-all gold-border-glow cursor-pointer"
          id="record-time-btn"
        >
          <Plus className="w-4 h-4" />
          <span>RECORD TIME ENTRY</span>
        </button>
      </div>

      {/* Financial Metrics Overview Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">TOTAL UNBILLED WIP</p>
          <p className="text-2xl font-serif-title font-bold text-[#dfb76c]">
            £{totalUnbilledWip.toLocaleString()}
          </p>
          <p className="text-[10px] text-[#94a3b8] font-mono">Ready for Partner Pre-Bill Review</p>
        </div>

        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">APPROVED TIME (HOURS)</p>
          <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">
            {totalApprovedTimeHours} hrs
          </p>
          <p className="text-[10px] text-[#10b981] font-mono">100% Partner Verified</p>
        </div>

        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">AVERAGE REALISATION</p>
          <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">
            94.2%
          </p>
          <p className="text-[10px] text-[#10b981] font-mono">Target ≥92.0%</p>
        </div>

        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">AVERAGE MARGIN</p>
          <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">
            46.5%
          </p>
          <p className="text-[10px] text-[#94a3b8] font-mono">Post-Overhead Profit</p>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex space-x-2 border-b border-[#1e293b]">
        {[
          { id: 'TIME', label: 'Time Entries & Approvals', icon: <Clock className="w-3.5 h-3.5" /> },
          { id: 'DRAFT_BILLS', label: 'Billing Workflow & Invoices', icon: <Receipt className="w-3.5 h-3.5" /> },
          { id: 'PROFITABILITY', label: 'Profitability & Margins', icon: <PieChart className="w-3.5 h-3.5" /> },
        ].map((subTab) => (
          <button
            key={subTab.id}
            onClick={() => setActiveSubTab(subTab.id as any)}
            className={`flex items-center space-x-2 px-4 py-2.5 text-xs font-mono transition-all cursor-pointer border-b-2 ${
              activeSubTab === subTab.id
                ? 'border-[#c5a059] text-[#c5a059] font-bold bg-[#0f172a]'
                : 'border-transparent text-[#94a3b8] hover:text-white'
            }`}
          >
            {subTab.icon}
            <span>{subTab.label}</span>
          </button>
        ))}
      </div>

      {/* Sub-tab 1: Time Entries */}
      {activeSubTab === 'TIME' && (
        <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-[#141d2e] pb-3">
            <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
              PROFESSIONAL TIME RECORDING LEDGER
            </h2>
            <span className="text-[10px] font-mono text-[#64748b]">Passive Capture Reviewable</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-sans-ui">
              <thead className="bg-[#090d16] text-[#64748b] font-mono text-[10px] uppercase border-b border-[#1e293b]">
                <tr>
                  <th className="py-3 px-3">Date</th>
                  <th className="py-3 px-3">Professional</th>
                  <th className="py-3 px-3">Matter / Client</th>
                  <th className="py-3 px-3">Activity Description</th>
                  <th className="py-3 px-3 text-right">Hours</th>
                  <th className="py-3 px-3 text-right">Rate (£)</th>
                  <th className="py-3 px-3 text-right">Amount (£)</th>
                  <th className="py-3 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#141d2e]">
                {timeEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-[#0f172a]/50 transition-colors">
                    <td className="py-3 px-3 font-mono text-[#cbd5e1]">{entry.date}</td>
                    <td className="py-3 px-3 font-medium text-[#f1f5f9]">{getPersonName(entry.personId)}</td>
                    <td className="py-3 px-3 text-[#c5a059]">{getMatterTitle(entry.matterId)}</td>
                    <td className="py-3 px-3 text-[#94a3b8] max-w-xs truncate">{entry.activityDescription}</td>
                    <td className="py-3 px-3 text-right font-mono text-[#f1f5f9] font-bold">{entry.hours} hrs</td>
                    <td className="py-3 px-3 text-right font-mono text-[#cbd5e1]">£{entry.hourlyRate}</td>
                    <td className="py-3 px-3 text-right font-mono text-[#dfb76c] font-bold">
                      £{(entry.hours * entry.hourlyRate).toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[9px] font-mono bg-[#064e3b]/40 text-[#a7f3d0] border border-[#047857]">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        APPROVED
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-tab 2: Billing & Draft Bills */}
      {activeSubTab === 'DRAFT_BILLS' && (
        <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-6 shadow-xl">
          <div className="border-b border-[#141d2e] pb-3">
            <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
              BILLING WORKFLOW & INVOICES
            </h2>
            <p className="text-xs text-[#64748b] font-mono pt-1">
              TIME → DRAFT BILL → PARTNER REVIEW → PRE-BILL → CLIENT REVIEW → FINAL BILL → PAYMENT
            </p>
          </div>

          <div className="space-y-4">
            {invoices.map((inv) => (
              <div key={inv.id} className="p-4 rounded bg-[#090d16] border border-[#1e293b] flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#1e293b] text-[#c5a059]">
                      {inv.invoiceNumber}
                    </span>
                    <span className="text-xs font-serif-title font-bold text-[#f1f5f9]">
                      {getMatterTitle(inv.matterId)}
                    </span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Issue Date: {inv.issueDate} · Payment Due: {inv.dueDate}
                  </p>
                </div>

                <div className="flex items-center space-x-6 text-right">
                  <div>
                    <p className="text-[9px] font-mono text-[#64748b]">NET AMOUNT</p>
                    <p className="text-xs font-mono font-bold text-[#f1f5f9]">
                      £{inv.netAmount.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-[9px] font-mono text-[#64748b]">GROSS + VAT</p>
                    <p className="text-xs font-mono font-bold text-[#dfb76c]">
                      £{inv.grossAmount.toLocaleString()}
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded text-[10px] font-mono bg-[#10b981]/20 text-[#a7f3d0] border border-[#047857]">
                    {inv.status.replace('_', ' ')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sub-tab 3: Profitability Engine */}
      {activeSubTab === 'PROFITABILITY' && (
        <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-6 shadow-xl">
          <div className="border-b border-[#141d2e] pb-3">
            <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
              MATTER & PRACTICE PROFITABILITY INTELLIGENCE
            </h2>
            <p className="text-xs text-[#64748b]">
              Calculating Gross Margin, Partner Contribution & Post-Overhead Net Return per Matter
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {matters.map((m) => (
              <div key={m.id} className="p-4 rounded bg-[#090d16] border border-[#1e293b] space-y-3">
                <div className="flex justify-between items-start border-b border-[#1a2333] pb-2">
                  <div>
                    <p className="text-[10px] font-mono text-[#c5a059]">{m.code}</p>
                    <h3 className="font-serif-title font-bold text-[#f1f5f9] text-xs">{m.title}</h3>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#10b981]">
                    48.2% Gross Margin
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                  <div className="bg-[#0b0f17] p-2 rounded">
                    <p className="text-[9px] text-[#64748b]">REVENUE</p>
                    <p className="text-[#f1f5f9]">£{m.agreedBudget.toLocaleString()}</p>
                  </div>
                  <div className="bg-[#0b0f17] p-2 rounded">
                    <p className="text-[9px] text-[#64748b]">WIP COST</p>
                    <p className="text-[#dfb76c]">£{m.wipAmount.toLocaleString()}</p>
                  </div>
                  <div className="bg-[#0b0f17] p-2 rounded">
                    <p className="text-[9px] text-[#64748b]">NET PROFIT</p>
                    <p className="text-[#10b981]">£{(m.agreedBudget - m.wipAmount).toLocaleString()}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
