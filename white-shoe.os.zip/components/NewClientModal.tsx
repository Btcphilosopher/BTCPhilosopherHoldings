'use client';

import React, { useState } from 'react';
import { X, Building2, ShieldCheck, User } from 'lucide-react';
import { Client, ClientCategory, RelationshipTier, Jurisdiction } from '@/lib/types';

interface NewClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (client: Client) => void;
}

export const NewClientModal: React.FC<NewClientModalProps> = ({ isOpen, onClose, onSave }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ClientCategory>('MULTINATIONAL GROUP');
  const [tier, setTier] = useState<RelationshipTier>('TIER_1_INSTITUTIONAL');
  const [jurisdiction, setJurisdiction] = useState<Jurisdiction>('UK (London)');
  const [industry, setIndustry] = useState('Defense & Aerospace');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [summaryNote, setSummaryNote] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    const newClient: Client = {
      id: `c-${Date.now()}`,
      code: `CL-${Math.floor(100 + Math.random() * 900)}`,
      name,
      category,
      relationshipTier: tier,
      jurisdiction,
      industry,
      relationshipPartnerId: 'p-101', // Default Senior Partner
      secondaryPartnerIds: ['p-102'],
      contacts: [
        {
          id: `con-${Date.now()}`,
          name: contactName || 'Chief Legal Officer',
          email: contactEmail || 'clo@client.com',
          phone: '+44 20 7946 0912',
          role: 'General Counsel',
          isPrimary: true
        }
      ],
      kycAmlStatus: 'VERIFIED',
      riskRating: 'LOW',
      annualRevenueBilled: 0,
      unbilledWip: 0,
      agedDebt: 0,
      marginPercentage: 48.5,
      onboardedDate: new Date().toISOString().split('T')[0],
      summaryNote: summaryNote || 'Newly onboarded institutional client relationship.'
    };

    onSave(newClient);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg w-full max-w-xl p-6 space-y-6 shadow-2xl relative gold-border-glow">
        <div className="flex justify-between items-center border-b border-[#1e293b] pb-3">
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif-title text-sm tracking-widest text-[#f1f5f9] font-bold uppercase">
              ONBOARD NEW INSTITUTIONAL CLIENT
            </h2>
          </div>
          <button onClick={onClose} className="text-[#94a3b8] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-sans-ui">
          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Full Client Legal Name:</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Sovereign Wealth Fund of Singapore"
              className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Client Classification:</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              >
                <option value="MULTINATIONAL GROUP">Multinational Group</option>
                <option value="PRIVATE EQUITY SPONSOR">Private Equity Sponsor</option>
                <option value="FAMILY OFFICE / PRIVATE CLIENT">Family Office / Private Client</option>
                <option value="SOVEREIGN FUND">Sovereign Fund</option>
                <option value="CORPORATION">Corporation</option>
              </select>
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Relationship Tier:</label>
              <select
                value={tier}
                onChange={(e) => setTier(e.target.value as any)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              >
                <option value="TIER_1_INSTITUTIONAL">Tier 1 Institutional</option>
                <option value="TIER_2_KEY_CLIENT">Tier 2 Key Client</option>
                <option value="TIER_3_REGULAR">Tier 3 Regular</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Primary Jurisdiction:</label>
              <select
                value={jurisdiction}
                onChange={(e) => setJurisdiction(e.target.value as Jurisdiction)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              >
                <option value="UK (London)">UK (London)</option>
                <option value="US (New York)">US (New York)</option>
                <option value="EU (Paris/Zurich)">EU (Paris/Zurich)</option>
                <option value="APAC (Singapore)">APAC (Singapore)</option>
                <option value="ME (Dubai)">ME (Dubai)</option>
              </select>
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Industry Sector:</label>
              <input
                type="text"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Primary Contact Name:</label>
              <input
                type="text"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                placeholder="e.g. Dr. Arthur Vance"
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Contact Email:</label>
              <input
                type="email"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                placeholder="e.g. a.vance@client.com"
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Relationship Notes / Mandate Summary:</label>
            <textarea
              rows={3}
              value={summaryNote}
              onChange={(e) => setSummaryNote(e.target.value)}
              placeholder="Key facts regarding relationship origination..."
              className="w-full bg-[#090d16] border border-[#334155] rounded p-2.5 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            />
          </div>

          <div className="pt-2 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-[#1e293b] hover:bg-[#334155] text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-bold"
            >
              Complete Onboarding
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
