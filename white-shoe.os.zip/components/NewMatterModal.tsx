'use client';

import React, { useState } from 'react';
import { X, Briefcase } from 'lucide-react';
import { Matter, Client, ModuleType, FeeModel, PracticeGroup } from '@/lib/types';

interface NewMatterModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: Client[];
  onSave: (matter: Matter) => void;
}

export const NewMatterModal: React.FC<NewMatterModalProps> = ({ isOpen, onClose, clients, onSave }) => {
  const [title, setTitle] = useState('');
  const [clientId, setClientId] = useState(clients[0]?.id || 'c-101');
  const [moduleType, setModuleType] = useState<ModuleType>('LEGAL');
  const [practice, setPractice] = useState<PracticeGroup>('CORPORATE');
  const [feeModel, setFeeModel] = useState<FeeModel>('HOURLY_RATE');
  const [agreedBudget, setAgreedBudget] = useState('500000');
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    const newMatter: Matter = {
      id: `m-${Date.now()}`,
      code: `M-${Math.floor(500 + Math.random() * 500)}`,
      clientId,
      moduleType,
      practice,
      title,
      description: description || 'New professional engagement.',
      jurisdiction: 'UK (London)',
      status: 'ACTIVE',
      leadPartnerId: 'p-101',
      relationshipPartnerId: 'p-101',
      teamMemberIds: ['p-101', 'p-103'],
      feeModel,
      agreedBudget: parseFloat(agreedBudget) || 500000,
      wipAmount: 0,
      billedYtd: 0,
      openingDate: new Date().toISOString().split('T')[0],
      targetClosingDate: '2026-12-15',
      riskRating: 'MEDIUM',
      confidentialityLevel: 'STANDARD',
      tasks: [
        {
          id: `t-${Date.now()}`,
          title: 'Initial Partner Engagement & Strategy Memo',
          assigneeId: 'p-101',
          dueDate: '2026-09-20',
          status: 'PENDING',
          priority: 'HIGH'
        }
      ],
      deadlines: []
    };

    onSave(newMatter);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg w-full max-w-xl p-6 space-y-6 shadow-2xl relative gold-border-glow">
        <div className="flex justify-between items-center border-b border-[#1e293b] pb-3">
          <div className="flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif-title text-sm tracking-widest text-[#f1f5f9] font-bold uppercase">
              OPEN NEW MATTER OR ENGAGEMENT
            </h2>
          </div>
          <button onClick={onClose} className="text-[#94a3b8] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-sans-ui">
          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Matter Title / Instruction Name:</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Defense Advisory on Transatlantic Merger"
              className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Instructing Client:</label>
              <select
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              >
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>{c.name} ({c.code})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Practice Module:</label>
              <select
                value={moduleType}
                onChange={(e) => setModuleType(e.target.value as any)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              >
                <option value="LEGAL">Legal Takeovers & Disputes</option>
                <option value="TAX">Tax Structuring</option>
                <option value="ACCOUNTANCY">Audit & Ledger</option>
                <option value="CONSULTING">Strategy & Consulting</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Fee Model:</label>
              <select
                value={feeModel}
                onChange={(e) => setFeeModel(e.target.value as any)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              >
                <option value="HOURLY_RATE">Standard Hourly Rate</option>
                <option value="FIXED_FEE">Fixed Fee Mandate</option>
                <option value="CAPPED_FEE">Capped Fee Structure</option>
                <option value="SUCCESS_PREMIUM">Success Premium / Contingency</option>
              </select>
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Agreed Budget Fee (£):</label>
              <input
                type="number"
                value={agreedBudget}
                onChange={(e) => setAgreedBudget(e.target.value)}
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Scope & Strategy Description:</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Outline instruction scope..."
              className="w-full bg-[#090d16] border border-[#334155] rounded p-2.5 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            />
          </div>

          <div className="pt-2 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-[#1e293b] hover:bg-[#334155] text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-bold"
            >
              Open Matter
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
