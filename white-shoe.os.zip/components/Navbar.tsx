'use client';

import React from 'react';
import { 
  Building2, 
  Users, 
  Briefcase, 
  ShieldAlert, 
  Clock, 
  BookOpen, 
  Share2, 
  Lock, 
  TrendingUp, 
  Search, 
  Sparkles,
  ChevronDown
} from 'lucide-react';

export type ActiveTab = 
  | 'EXECUTIVE'
  | 'CLIENTS'
  | 'MATTERS'
  | 'PARTNERS'
  | 'BILLING'
  | 'CONFLICTS'
  | 'KNOWLEDGE'
  | 'GRAPH'
  | 'PORTAL'
  | 'ECONOMICS';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenSearch: () => void;
  onOpenAskFirm: () => void;
  currentRole: string;
  setCurrentRole: (role: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenSearch,
  onOpenAskFirm,
  currentRole,
  setCurrentRole
}) => {
  return (
    <header className="bg-[#080c14] border-b border-[#1e293b] sticky top-0 z-40 select-none">
      {/* Top Firm Branding Bar */}
      <div className="max-w-[1700px] mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between border-b border-[#141d2e] gap-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded border border-[#c5a059]/40 bg-[#0f172a] flex items-center justify-center font-serif-title text-[#c5a059] text-xs font-bold tracking-widest shadow-inner">
              AST
            </div>
            <div>
              <h1 className="font-serif-title text-base tracking-[0.15em] text-[#f1f5f9] font-bold uppercase leading-tight">
                Ashcombe, Stone & Thorne
              </h1>
              <p className="text-[10px] text-[#94a3b8] font-sans-ui tracking-wider uppercase">
                London · New York · Paris · Zurich · Singapore · Dubai
              </p>
            </div>
          </div>
        </div>

        {/* Executive Action Trigger & Time Clocks */}
        <div className="flex items-center space-x-4 text-xs">
          <div className="hidden lg:flex items-center space-x-3 text-[11px] text-[#64748b] border-r border-[#1e293b] pr-4 font-mono">
            <span>LDN 16:33</span>
            <span>·</span>
            <span>NYC 11:33</span>
            <span>·</span>
            <span>ZRH 17:33</span>
            <span>·</span>
            <span>SIN 23:33</span>
          </div>

          {/* Ask the Firm AI Command Trigger */}
          <button
            onClick={onOpenAskFirm}
            className="flex items-center space-x-2 px-3 py-1.5 rounded bg-[#111827] hover:bg-[#1f293d] border border-[#c5a059]/40 text-[#dfb76c] hover:text-white transition-all gold-border-glow text-xs font-sans-ui font-medium cursor-pointer"
            id="ask-firm-nav-btn"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#c5a059] animate-pulse" />
            <span>ASK THE FIRM</span>
            <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[9px] font-mono bg-[#090d16] text-[#94a3b8] rounded border border-[#334155]">
              ⌘K
            </kbd>
          </button>

          {/* Search Trigger */}
          <button
            onClick={onOpenSearch}
            className="p-1.5 rounded text-[#94a3b8] hover:text-white hover:bg-[#1e293b] transition-colors cursor-pointer"
            title="Global Search"
            id="global-search-btn"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Role Selector */}
          <div className="relative group">
            <div className="flex items-center space-x-1.5 bg-[#0f172a] border border-[#334155] rounded px-2.5 py-1 text-[11px] text-[#cbd5e1] cursor-pointer">
              <span className="w-1.5 h-1.5 rounded-full bg-[#10b981]"></span>
              <span>{currentRole}</span>
              <ChevronDown className="w-3 h-3 text-[#64748b]" />
            </div>
            <div className="absolute right-0 mt-1 w-48 bg-[#0f172a] border border-[#334155] rounded shadow-xl py-1 hidden group-hover:block z-50 text-[11px]">
              {['Senior Partner', 'Managing Partner', 'Partner', 'Associate', 'Client Portal Mode'].map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    setCurrentRole(r);
                    if (r === 'Client Portal Mode') setActiveTab('PORTAL');
                  }}
                  className={`w-full text-left px-3 py-1.5 hover:bg-[#1e293b] transition-colors ${currentRole === r ? 'text-[#c5a059] font-medium' : 'text-[#94a3b8]'}`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main OS Module Navigation Bar */}
      <div className="max-w-[1700px] mx-auto px-4 overflow-x-auto no-scrollbar">
        <nav className="flex space-x-1 py-1 text-xs font-sans-ui uppercase tracking-wider">
          <NavButton
            active={activeTab === 'EXECUTIVE'}
            onClick={() => setActiveTab('EXECUTIVE')}
            icon={<Building2 className="w-3.5 h-3.5" />}
            label="Executive OS"
            id="tab-executive"
          />
          <NavButton
            active={activeTab === 'CLIENTS'}
            onClick={() => setActiveTab('CLIENTS')}
            icon={<Users className="w-3.5 h-3.5" />}
            label="Clients & Graph"
            id="tab-clients"
          />
          <NavButton
            active={activeTab === 'MATTERS'}
            onClick={() => setActiveTab('MATTERS')}
            icon={<Briefcase className="w-3.5 h-3.5" />}
            label="Matters & Engagements"
            id="tab-matters"
          />
          <NavButton
            active={activeTab === 'BILLING'}
            onClick={() => setActiveTab('BILLING')}
            icon={<Clock className="w-3.5 h-3.5" />}
            label="Time & Billing"
            id="tab-billing"
          />
          <NavButton
            active={activeTab === 'CONFLICTS'}
            onClick={() => setActiveTab('CONFLICTS')}
            icon={<ShieldAlert className="w-3.5 h-3.5" />}
            label="Conflicts & Risk"
            badge="1 Alert"
            id="tab-conflicts"
          />
          <NavButton
            active={activeTab === 'KNOWLEDGE'}
            onClick={() => setActiveTab('KNOWLEDGE')}
            icon={<BookOpen className="w-3.5 h-3.5" />}
            label="Knowledge Mind"
            id="tab-knowledge"
          />
          <NavButton
            active={activeTab === 'GRAPH'}
            onClick={() => setActiveTab('GRAPH')}
            icon={<Share2 className="w-3.5 h-3.5" />}
            label="Firm Graph"
            id="tab-graph"
          />
          <NavButton
            active={activeTab === 'PORTAL'}
            onClick={() => setActiveTab('PORTAL')}
            icon={<Lock className="w-3.5 h-3.5" />}
            label="Client Portal"
            id="tab-portal"
          />
          <NavButton
            active={activeTab === 'ECONOMICS'}
            onClick={() => setActiveTab('ECONOMICS')}
            icon={<TrendingUp className="w-3.5 h-3.5" />}
            label="Partner Economics"
            id="tab-economics"
          />
        </nav>
      </div>
    </header>
  );
};

interface NavButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  badge?: string;
  id?: string;
}

const NavButton: React.FC<NavButtonProps> = ({ active, onClick, icon, label, badge, id }) => (
  <button
    onClick={onClick}
    id={id}
    className={`flex items-center space-x-2 px-3 py-2 rounded text-[11px] font-medium transition-all whitespace-nowrap cursor-pointer ${
      active
        ? 'bg-[#1e293b] text-[#f1f5f9] border-b-2 border-[#c5a059]'
        : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#111827]'
    }`}
  >
    <span className={active ? 'text-[#c5a059]' : 'text-[#64748b]'}>{icon}</span>
    <span>{label}</span>
    {badge && (
      <span className="ml-1 px-1.5 py-0.2 rounded-full text-[9px] bg-[#7f1d1d] text-[#fecca3] font-mono border border-[#991b1b]">
        {badge}
      </span>
    )}
  </button>
);
