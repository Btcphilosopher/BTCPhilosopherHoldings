'use client';

import React, { useState } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Search, 
  Lock, 
  FileCheck, 
  UserCheck, 
  XCircle,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { ConflictCheckRequest, Client, Matter } from '@/lib/types';

interface ConflictsEngineViewProps {
  conflicts: ConflictCheckRequest[];
  clients: Client[];
  matters: Matter[];
  onOpenNewCheck: (request: ConflictCheckRequest) => void;
}

export const ConflictsEngineView: React.FC<ConflictsEngineViewProps> = ({
  conflicts,
  clients,
  matters,
  onOpenNewCheck
}) => {
  const [proposedClient, setProposedClient] = useState('');
  const [matterTitle, setMatterTitle] = useState('');
  const [counterparties, setCounterparties] = useState('');
  const [directors, setDirectors] = useState('');
  const [checking, setChecking] = useState(false);
  const [checkResult, setCheckResult] = useState<ConflictCheckRequest | null>(null);

  const handleRunConflictCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!proposedClient || !counterparties) return;

    setChecking(true);
    setTimeout(() => {
      // Perform strict algorithmic check against active database records
      const counterpartyList = counterparties.split(',').map((s) => s.trim().toLowerCase());
      const matchedClient = clients.find((c) => counterpartyList.some((cp) => c.name.toLowerCase().includes(cp)));
      const matchedMatter = matters.find((m) => counterpartyList.some((cp) => m.title.toLowerCase().includes(cp)));

      let status: 'CLEAR' | 'POTENTIAL_CONFLICT' | 'CONFIRMED_CONFLICT' = 'CLEAR';
      let riskAnalysis = 'No active or historic conflict matches found across global office records.';
      const matches: ConflictCheckRequest['matchedRecords'] = [];

      if (matchedClient) {
        status = 'CONFIRMED_CONFLICT';
        riskAnalysis = `Direct adversary match found with active Tier-1 client "${matchedClient.name}". Representation forbidden without formal partner board waiver and Information Barrier clearance.`;
        matches.push({
          type: 'EXISTING_CLIENT',
          name: matchedClient.name,
          details: `Client Code ${matchedClient.code} (${matchedClient.relationshipTier})`
        });
      }

      if (matchedMatter) {
        status = 'CONFIRMED_CONFLICT';
        matches.push({
          type: 'ACTIVE_MATTER',
          name: matchedMatter.title,
          details: `Matter Code ${matchedMatter.code} (Lead Partner: ${matchedMatter.leadPartnerId})`
        });
      }

      const newResult: ConflictCheckRequest = {
        id: `conf-${Date.now()}`,
        matterTitle: matterTitle || 'Proposed New Matter Instruction',
        proposedClientId: 'c-new',
        proposedClientName: proposedClient,
        counterparties: counterparties.split(',').map((s) => s.trim()),
        directorsOrShareholders: directors ? directors.split(',').map((s) => s.trim()) : [],
        requestedByPersonId: 'p-101',
        checkDate: new Date().toISOString().split('T')[0],
        status,
        riskAnalysis,
        matchedRecords: matches
      };

      setCheckResult(newResult);
      onOpenNewCheck(newResult);
      setChecking(false);
    }, 800);
  };

  return (
    <div className="max-w-[1700px] mx-auto px-4 py-8 space-y-8">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1e293b] pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-[#f87171]" />
            <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9] tracking-wider uppercase">
              Institutional Conflicts & Risk Control Engine
            </h1>
          </div>
          <p className="text-xs text-[#94a3b8] font-serif-body pt-1">
            Mandatory clearance across all 6 global office databases prior to opening any matter. Non-negotiable partner rule: AI cannot override conflict controls.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Interactive Conflict Checker Form */}
        <div className="lg:col-span-5 bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-5 shadow-xl">
          <div className="border-b border-[#141d2e] pb-3">
            <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold flex items-center space-x-2">
              <Search className="w-4 h-4 text-[#c5a059]" />
              <span>RUN REAL-TIME CONFLICT CLEARANCE</span>
            </h2>
          </div>

          <form onSubmit={handleRunConflictCheck} className="space-y-4 text-xs font-sans-ui">
            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Proposed Client Name:</label>
              <input
                type="text"
                required
                value={proposedClient}
                onChange={(e) => setProposedClient(e.target.value)}
                placeholder="e.g. Apex Defense Technologies Inc."
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Proposed Matter / Instruction Title:</label>
              <input
                type="text"
                value={matterTitle}
                onChange={(e) => setMatterTitle(e.target.value)}
                placeholder="e.g. Representation on BAE Defense Tender Bid"
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Counterparties & Opposing Parties (Comma Separated):</label>
              <input
                type="text"
                required
                value={counterparties}
                onChange={(e) => setCounterparties(e.target.value)}
                placeholder="e.g. Aurelia Industries PLC, Ministry of Defence"
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <div>
              <label className="block text-[#94a3b8] mb-1 font-medium">Key Directors, Shareholders & Beneficial Owners:</label>
              <input
                type="text"
                value={directors}
                onChange={(e) => setDirectors(e.target.value)}
                placeholder="e.g. Sir John Finch, Gen. Arthur Pendelton"
                className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
              />
            </div>

            <button
              type="submit"
              disabled={checking}
              className="w-full py-2.5 rounded bg-[#991b1b] hover:bg-[#b91c1c] text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              {checking ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Searching Global Office Databases...</span>
                </>
              ) : (
                <>
                  <ShieldAlert className="w-4 h-4" />
                  <span>EXECUTE CONFLICT CHECK</span>
                </>
              )}
            </button>
          </form>

          {checkResult && (
            <div className={`p-4 rounded border text-xs space-y-2 font-mono ${
              checkResult.status === 'CONFIRMED_CONFLICT' ? 'bg-[#7f1d1d]/20 border-[#991b1b] text-[#f87171]' : 'bg-[#064e3b]/20 border-[#047857] text-[#a7f3d0]'
            }`}>
              <div className="flex items-center space-x-2 font-bold uppercase text-sm">
                {checkResult.status === 'CONFIRMED_CONFLICT' ? <XCircle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
                <span>CLEARANCE RESULT: {checkResult.status}</span>
              </div>
              <p className="font-sans-ui text-[#e2e8f0]">{checkResult.riskAnalysis}</p>
            </div>
          )}
        </div>

        {/* Right Column: Historical Conflict Reviews & Information Barriers */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4 shadow-xl">
            <div className="border-b border-[#141d2e] pb-3 flex justify-between items-center">
              <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
                CONFLICT AUDIT & RECENT CHECK RECORDS
              </h2>
              <span className="text-[10px] font-mono text-[#64748b]">Mandatory Audit Trail</span>
            </div>

            <div className="space-y-3">
              {conflicts.map((conf) => (
                <div key={conf.id} className="p-4 rounded bg-[#090d16] border border-[#1e293b] space-y-2">
                  <div className="flex items-center justify-between border-b border-[#1a2333] pb-2">
                    <span className="font-serif-title font-bold text-[#f1f5f9] text-xs">
                      {conf.matterTitle}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-mono uppercase ${
                      conf.status === 'CONFIRMED_CONFLICT' ? 'bg-[#7f1d1d] text-[#fecca3]' : 'bg-[#064e3b] text-[#a7f3d0]'
                    }`}>
                      {conf.status}
                    </span>
                  </div>

                  <p className="text-xs text-[#94a3b8] font-sans-ui">{conf.riskAnalysis}</p>

                  {conf.matchedRecords.length > 0 && (
                    <div className="bg-[#0b0f17] p-2 rounded text-[10px] font-mono text-[#f87171] space-y-1">
                      <p className="font-bold">MATCHED DATABASE RECORDS:</p>
                      {conf.matchedRecords.map((m, i) => (
                        <p key={i}>• {m.type}: {m.name} ({m.details})</p>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* INFORMATION BARRIERS SCHEMATIC */}
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4 shadow-xl">
            <div className="border-b border-[#141d2e] pb-3 flex items-center space-x-2">
              <Lock className="w-4 h-4 text-[#c5a059]" />
              <h2 className="font-serif-title text-xs tracking-widest text-[#dfb76c] uppercase font-bold">
                INFORMATION BARRIER ENFORCEMENT
              </h2>
            </div>
            <p className="text-xs text-[#94a3b8] font-serif-body">
              Enforced at the database authorization layer. Restricts access to matter metadata, documents, notes, billing and strategy for unauthorized team members.
            </p>
            <div className="bg-[#090d16] p-4 rounded border border-[#1e293b] text-center font-mono text-xs text-[#c5a059]">
              CLIENT A TEAM ║ ══ INFORMATION BARRIER ══ ║ CLIENT B TEAM
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
