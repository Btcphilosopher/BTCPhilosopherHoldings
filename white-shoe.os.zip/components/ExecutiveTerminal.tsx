'use client';

import React, { useState } from 'react';
import { 
  Building2, 
  Sparkles, 
  ArrowUpRight, 
  ShieldAlert, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Briefcase, 
  Users, 
  DollarSign, 
  TrendingUp,
  FileText,
  Send,
  HelpCircle,
  ChevronRight
} from 'lucide-react';
import { FIRM_DETAILS, INITIAL_MATTERS, INITIAL_CLIENTS } from '@/lib/data';
import { ActiveTab } from './Navbar';

interface ExecutiveTerminalProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenAskFirm: (initialQuery?: string) => void;
}

export const ExecutiveTerminal: React.FC<ExecutiveTerminalProps> = ({
  setActiveTab,
  onOpenAskFirm
}) => {
  const [quickQuery, setQuickQuery] = useState('');

  const handleQuerySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickQuery.trim()) {
      onOpenAskFirm(quickQuery.trim());
    }
  };

  return (
    <div className="max-w-[1500px] mx-auto px-4 py-8 space-y-10">
      {/* Historic White-Shoe Partnership Masthead Header */}
      <div className="text-center space-y-3 pb-8 border-b border-[#1e293b]/60 relative">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#0f172a] border border-[#c5a059]/30 text-[#c5a059] text-[10px] font-mono tracking-widest uppercase mb-2">
          <span>Est. 1894</span>
          <span>·</span>
          <span>1 Chancery Lane, London</span>
        </div>
        <h1 className="font-serif-title text-3xl sm:text-4xl lg:text-5xl tracking-[0.2em] text-[#f8f6f0] font-bold uppercase leading-tight">
          Ashcombe, Stone & Thorne
        </h1>
        <p className="font-sans-ui text-xs sm:text-sm text-[#94a3b8] tracking-[0.3em] uppercase">
          LONDON · NEW YORK · PARIS · ZURICH · SINGAPORE · DUBAI
        </p>
        <p className="text-xs text-[#64748b] italic max-w-xl mx-auto pt-2 font-serif-body">
          “The computational operating system of an elite professional partnership — unifying judgement, expertise, discretion and trust.”
        </p>
      </div>

      {/* Main Grid: Firm Financials & Operational Scope */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Core Financial & Scale Metrics */}
        <div className="lg:col-span-8 space-y-8">
          {/* FIRM FINANCIAL ECONOMICS */}
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-6 shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#141d2e] pb-3">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-[#c5a059]"></span>
                <h2 className="font-serif-title text-xs tracking-widest text-[#94a3b8] uppercase font-semibold">
                  FIRM ECONOMIC PERFORMANCE (YTD)
                </h2>
              </div>
              <span className="text-[10px] font-mono text-[#64748b] uppercase">GBP Consolidated Accounting</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
              <div className="p-4 rounded bg-[#090d16] border border-[#1a2333] space-y-1">
                <p className="text-[10px] text-[#64748b] font-mono uppercase tracking-wider">REVENUE YTD</p>
                <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">£842.7m</p>
                <p className="text-[10px] text-[#10b981] flex items-center font-mono">
                  <TrendingUp className="w-3 h-3 mr-1" /> +8.4% vs PY
                </p>
              </div>

              <div className="p-4 rounded bg-[#090d16] border border-[#1a2333] space-y-1">
                <p className="text-[10px] text-[#64748b] font-mono uppercase tracking-wider">UNBILLED WIP</p>
                <p className="text-2xl font-serif-title font-bold text-[#dfb76c]">£214.3m</p>
                <p className="text-[10px] text-[#94a3b8] font-mono">Average 38.2 days</p>
              </div>

              <div className="p-4 rounded bg-[#090d16] border border-[#1a2333] space-y-1">
                <p className="text-[10px] text-[#64748b] font-mono uppercase tracking-wider">REALISATION</p>
                <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">94.2%</p>
                <p className="text-[10px] text-[#10b981] font-mono">Target: ≥92.0%</p>
              </div>

              <div className="p-4 rounded bg-[#090d16] border border-[#1a2333] space-y-1">
                <p className="text-[10px] text-[#64748b] font-mono uppercase tracking-wider">COLLECTION</p>
                <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">91.7%</p>
                <p className="text-[10px] text-[#94a3b8] font-mono">Aged Debt: £1.2m</p>
              </div>
            </div>

            {/* INSTITUTIONAL HEADCOUNT & SCALE */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2 border-t border-[#141d2e] text-center">
              <div 
                onClick={() => setActiveTab('CLIENTS')}
                className="p-3 rounded hover:bg-[#0f172a] transition-colors cursor-pointer border border-transparent hover:border-[#334155]"
              >
                <p className="text-xl font-serif-title font-semibold text-[#e2e8f0]">2,481</p>
                <p className="text-[10px] text-[#64748b] uppercase tracking-wider font-sans-ui">CLIENTS</p>
              </div>
              <div 
                onClick={() => setActiveTab('MATTERS')}
                className="p-3 rounded hover:bg-[#0f172a] transition-colors cursor-pointer border border-transparent hover:border-[#334155]"
              >
                <p className="text-xl font-serif-title font-semibold text-[#e2e8f0]">6,902</p>
                <p className="text-[10px] text-[#64748b] uppercase tracking-wider font-sans-ui">MATTERS</p>
              </div>
              <div 
                onClick={() => setActiveTab('ECONOMICS')}
                className="p-3 rounded hover:bg-[#0f172a] transition-colors cursor-pointer border border-transparent hover:border-[#334155]"
              >
                <p className="text-xl font-serif-title font-semibold text-[#c5a059]">318</p>
                <p className="text-[10px] text-[#64748b] uppercase tracking-wider font-sans-ui">PARTNERS</p>
              </div>
              <div 
                onClick={() => setActiveTab('PARTNERS')}
                className="p-3 rounded hover:bg-[#0f172a] transition-colors cursor-pointer border border-transparent hover:border-[#334155]"
              >
                <p className="text-xl font-serif-title font-semibold text-[#e2e8f0]">2,740</p>
                <p className="text-[10px] text-[#64748b] uppercase tracking-wider font-sans-ui">PROFESSIONALS</p>
              </div>
            </div>
          </div>

          {/* KEY HIGH-STAKES MATTERS IN FLIGHT */}
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#141d2e] pb-3">
              <div className="flex items-center space-x-2">
                <Briefcase className="w-4 h-4 text-[#c5a059]" />
                <h3 className="font-serif-title text-xs tracking-widest text-[#94a3b8] uppercase font-semibold">
                  TIER-1 ACTIVE ENGAGEMENTS & MATTERS
                </h3>
              </div>
              <button 
                onClick={() => setActiveTab('MATTERS')} 
                className="text-xs text-[#c5a059] hover:underline flex items-center cursor-pointer font-sans-ui"
              >
                <span>View All 6,902 Matters</span>
                <ChevronRight className="w-3 h-3 ml-1" />
              </button>
            </div>

            <div className="space-y-3">
              {INITIAL_MATTERS.map((matter) => (
                <div 
                  key={matter.id}
                  onClick={() => setActiveTab('MATTERS')}
                  className="p-4 rounded bg-[#090d16] border border-[#1a2333] hover:border-[#334155] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer group"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-[#1e293b] text-[#cbd5e1]">
                        {matter.code}
                      </span>
                      <span className="text-xs font-serif-title font-semibold text-[#f1f5f9] group-hover:text-[#c5a059] transition-colors">
                        {matter.title}
                      </span>
                    </div>
                    <p className="text-xs text-[#94a3b8] font-serif-body">
                      {matter.description}
                    </p>
                    <div className="flex items-center space-x-4 text-[11px] text-[#64748b] pt-1">
                      <span>Jurisdiction: {matter.jurisdiction}</span>
                      <span>·</span>
                      <span>Fee: {matter.feeModel.replace('_', ' ')}</span>
                      <span>·</span>
                      <span>Target: {matter.targetClosingDate}</span>
                    </div>
                  </div>

                  <div className="text-right sm:min-w-[120px] space-y-1 border-t sm:border-t-0 border-[#1a2333] pt-2 sm:pt-0">
                    <p className="text-xs font-mono font-bold text-[#dfb76c]">
                      £{matter.wipAmount.toLocaleString()} WIP
                    </p>
                    <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-mono uppercase ${
                      matter.riskRating === 'HIGH' ? 'bg-[#7f1d1d]/40 text-[#fecca3] border border-[#991b1b]' : 'bg-[#064e3b]/40 text-[#a7f3d0] border border-[#047857]'
                    }`}>
                      {matter.riskRating} RISK
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: TODAY Executive Briefing & Ask the Firm Terminal */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* TODAY ACTION BRIEFS */}
          <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-[#141d2e] pb-3">
              <h3 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-[#10b981] animate-ping"></span>
                <span>TODAY&apos;S PARTNER BRIEFING</span>
              </h3>
              <span className="text-[10px] font-mono text-[#64748b]">10 Sep 2026</span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div 
                onClick={() => setActiveTab('MATTERS')}
                className="p-3 rounded bg-[#090d16] border border-[#1e293b] hover:border-[#c5a059]/50 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-7 h-7 rounded bg-[#1e293b] flex items-center justify-center font-mono font-bold text-[#e2e8f0]">
                    17
                  </div>
                  <div>
                    <p className="font-medium text-[#f1f5f9]">Matters Require Attention</p>
                    <p className="text-[10px] text-[#64748b]">High-risk regulatory approvals & filings</p>
                  </div>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#64748b]" />
              </div>

              <div 
                onClick={() => setActiveTab('MATTERS')}
                className="p-3 rounded bg-[#090d16] border border-[#1e293b] hover:border-[#c5a059]/50 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-7 h-7 rounded bg-[#1e293b] flex items-center justify-center font-mono font-bold text-[#dfb76c]">
                    8
                  </div>
                  <div>
                    <p className="font-medium text-[#f1f5f9]">Deadlines Approaching</p>
                    <p className="text-[10px] text-[#64748b]">FCA announcements & Court Sanction hearings</p>
                  </div>
                </div>
                <Clock className="w-3.5 h-3.5 text-[#64748b]" />
              </div>

              <div 
                onClick={() => setActiveTab('CONFLICTS')}
                className="p-3 rounded bg-[#7f1d1d]/10 border border-[#991b1b]/40 hover:border-[#991b1b] transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-7 h-7 rounded bg-[#7f1d1d] flex items-center justify-center font-mono font-bold text-[#fecca3]">
                    3
                  </div>
                  <div>
                    <p className="font-medium text-[#fecca3]">Conflict Reviews Pending</p>
                    <p className="text-[10px] text-[#f87171]">Project Aegis requires partner clearance</p>
                  </div>
                </div>
                <ShieldAlert className="w-3.5 h-3.5 text-[#f87171]" />
              </div>

              <div 
                onClick={() => setActiveTab('PORTAL')}
                className="p-3 rounded bg-[#090d16] border border-[#1e293b] hover:border-[#c5a059]/50 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-7 h-7 rounded bg-[#1e293b] flex items-center justify-center font-mono font-bold text-[#e2e8f0]">
                    12
                  </div>
                  <div>
                    <p className="font-medium text-[#f1f5f9]">Client Requests Open</p>
                    <p className="text-[10px] text-[#64748b]">Document uploads & e-signatures</p>
                  </div>
                </div>
                <FileText className="w-3.5 h-3.5 text-[#64748b]" />
              </div>

              <div 
                onClick={() => setActiveTab('ECONOMICS')}
                className="p-3 rounded bg-[#090d16] border border-[#1e293b] hover:border-[#c5a059]/50 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-7 h-7 rounded bg-[#1e293b] flex items-center justify-center font-mono font-bold text-[#c5a059]">
                    6
                  </div>
                  <div>
                    <p className="font-medium text-[#f1f5f9]">Partner Decisions Pending</p>
                    <p className="text-[10px] text-[#64748b]">Draw distributions & capital approvals</p>
                  </div>
                </div>
                <TrendingUp className="w-3.5 h-3.5 text-[#64748b]" />
              </div>
            </div>
          </div>

          {/* ASK THE FIRM NATURAL LANGUAGE TERMINAL */}
          <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg p-5 space-y-4 shadow-2xl gold-border-glow">
            <div className="flex items-center space-x-2 border-b border-[#141d2e] pb-3">
              <Sparkles className="w-4 h-4 text-[#c5a059]" />
              <h3 className="font-serif-title text-xs tracking-widest text-[#dfb76c] uppercase font-bold">
                ASK THE FIRM
              </h3>
            </div>

            <p className="text-xs text-[#94a3b8] font-serif-body">
              Query institutional intelligence across clients, matters, partner origination, unbilled WIP, and precedents.
            </p>

            <form onSubmit={handleQuerySubmit} className="space-y-3">
              <div className="relative">
                <input
                  type="text"
                  value={quickQuery}
                  onChange={(e) => setQuickQuery(e.target.value)}
                  placeholder="e.g. 'Show me our most profitable clients in London'"
                  className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-xs text-[#f1f5f9] placeholder-[#475569] focus:outline-none focus:border-[#c5a059]"
                />
                <button
                  type="submit"
                  className="absolute right-1.5 top-1.5 p-1 rounded bg-[#1f293d] hover:bg-[#c5a059] text-[#c5a059] hover:text-black transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

            <div className="space-y-1.5 pt-2">
              <p className="text-[10px] font-mono text-[#64748b] uppercase">Suggested Institutional Queries:</p>
              <div className="flex flex-wrap gap-1.5">
                {[
                  "Who knows European M&A?",
                  "Show unbilled WIP above £1m",
                  "Check conflict for BAE bidder",
                  "Prepare managing partner briefing"
                ].map((promptText) => (
                  <button
                    key={promptText}
                    onClick={() => onOpenAskFirm(promptText)}
                    className="text-[10px] px-2 py-1 rounded bg-[#0f172a] hover:bg-[#1e293b] text-[#cbd5e1] border border-[#1e293b] hover:border-[#c5a059]/40 transition-all text-left cursor-pointer"
                  >
                    &quot;{promptText}&quot;
                  </button>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
