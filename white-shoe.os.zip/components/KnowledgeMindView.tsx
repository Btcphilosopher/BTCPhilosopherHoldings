'use client';

import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Plus, 
  FileText, 
  Download, 
  Sparkles, 
  User, 
  Tag, 
  Globe, 
  Share2,
  ChevronRight,
  Database
} from 'lucide-react';
import { KnowledgeItem, Person, PracticeGroup } from '@/lib/types';

interface KnowledgeMindViewProps {
  knowledge: KnowledgeItem[];
  people: Person[];
}

export const KnowledgeMindView: React.FC<KnowledgeMindViewProps> = ({
  knowledge,
  people
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [expertQuery, setExpertQuery] = useState('');
  const [expertResult, setExpertResult] = useState<string | null>(null);

  const filteredKnowledge = knowledge.filter((item) => {
    const matchesSearch = 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.keyTopics.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesCategory = selectedCategory === 'ALL' || item.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const getAuthorName = (authorId: string) => {
    const p = people.find((person) => person.id === authorId);
    return p ? `${p.name} (${p.grade})` : authorId;
  };

  const handleRunExpertQuery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expertQuery.trim()) return;

    setExpertResult(`INTELLECTUAL CAPITAL GRAPH MATCH:

Experts Identified:
- Lord Henry Ashcombe KC (Senior Partner, London) · Lead on 12 UK/EU Infrastructure Public Takeovers
- Eleanor Vance-Roth (Equity Partner, Zurich) · Tax Structuring Lead on Cross-Border Infrastructure Funds
- Tariq Al-Mansoor (Partner, Dubai) · Port & Energy Concessions Specialist

Relevant Precedent Documents:
1. Precedent: UK NSIA Defense Sector Approval Memorandum (M-501 / Lord Ashcombe KC)
2. Tax Memorandum: Pillar 2 Minimum Tax Structuring for Swiss Family Vehicles (M-502 / E. Vance-Roth)
3. Transatlantic LBO Senior Credit Facility Framework Model (J. Montgomery)`);
  };

  return (
    <div className="max-w-[1700px] mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1e293b] pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-[#c5a059]" />
            <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9] tracking-wider uppercase">
              The Firm&apos;s Collective Mind · Institutional Knowledge Repository
            </h1>
          </div>
          <p className="text-xs text-[#94a3b8] font-serif-body pt-1">
            Precedents, Research Memos, Financial Models, Legal Opinions & Transaction Structures across 132 years of partnership experience.
          </p>
        </div>
      </div>

      {/* INTELLECTUAL CAPITAL GRAPH QUERY PANEL */}
      <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg p-6 space-y-4 shadow-xl gold-border-glow">
        <div className="flex items-center space-x-2 border-b border-[#141d2e] pb-3">
          <Sparkles className="w-4 h-4 text-[#c5a059]" />
          <h2 className="font-serif-title text-xs tracking-widest text-[#dfb76c] uppercase font-bold">
            INTELLECTUAL CAPITAL GRAPH QUERY (“WHO KNOWS WHAT?”)
          </h2>
        </div>

        <form onSubmit={handleRunExpertQuery} className="flex gap-3">
          <input
            type="text"
            value={expertQuery}
            onChange={(e) => setExpertQuery(e.target.value)}
            placeholder="e.g. 'Who knows about European infrastructure M&A?'"
            className="flex-1 bg-[#090d16] border border-[#334155] rounded px-3.5 py-2 text-xs text-[#f1f5f9] placeholder-[#475569] focus:outline-none focus:border-[#c5a059]"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-semibold text-xs transition-all cursor-pointer"
          >
            Find Experts
          </button>
        </form>

        {expertResult && (
          <div className="p-4 rounded bg-[#090d16] border border-[#1a2333] text-xs font-mono text-[#cbd5e1] whitespace-pre-wrap leading-relaxed">
            {expertResult}
          </div>
        )}
      </div>

      {/* Filter & Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-8 relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search precedent library by title, topic, or jurisdiction..."
            className="w-full bg-[#090d16] border border-[#334155] rounded px-3.5 py-2 text-xs text-[#f1f5f9] placeholder-[#475569] focus:outline-none focus:border-[#c5a059] pl-9"
          />
          <Search className="w-4 h-4 text-[#64748b] absolute left-3 top-2.5" />
        </div>

        <div className="md:col-span-4">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-xs text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
          >
            <option value="ALL">All Categories</option>
            <option value="PRECEDENT">Precedents & Opinions</option>
            <option value="TAX_ANALYSIS">Tax Analysis & Rulings</option>
            <option value="TRANSACTION_MODEL">Transaction Models</option>
          </select>
        </div>
      </div>

      {/* Knowledge Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredKnowledge.map((item) => (
          <div
            key={item.id}
            className="bg-[#0b0f17] border border-[#1e293b] hover:border-[#c5a059]/60 rounded-lg p-5 space-y-4 shadow-xl transition-all hover:bg-[#0f172a]/50 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2 border-b border-[#141d2e] pb-3">
                <div>
                  <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e293b] text-[#c5a059]">
                    {item.category.replace('_', ' ')}
                  </span>
                  <h3 className="font-serif-title text-sm font-bold text-[#f1f5f9] pt-1">
                    {item.title}
                  </h3>
                  <p className="text-[10px] text-[#64748b] font-mono">
                    Jurisdiction: {item.jurisdiction} · Practice: {item.practice}
                  </p>
                </div>
              </div>

              <p className="text-xs text-[#94a3b8] font-serif-body leading-relaxed">
                {item.summary}
              </p>

              <div className="flex flex-wrap gap-1.5 pt-1">
                {item.keyTopics.map((topic, i) => (
                  <span key={i} className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#090d16] border border-[#1a2333] text-[#a5b4fc]">
                    #{topic}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-[#141d2e] flex items-center justify-between text-xs text-[#64748b]">
              <span>Author: <strong className="text-[#e2e8f0]">{getAuthorName(item.authorPersonId)}</strong></span>
              <button className="flex items-center space-x-1 text-[#c5a059] hover:underline text-[11px] font-mono cursor-pointer">
                <Download className="w-3.5 h-3.5" />
                <span>{item.fileSize}</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
