'use client';

import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  Plus, 
  Search, 
  Filter, 
  ChevronRight, 
  ShieldCheck, 
  AlertTriangle, 
  DollarSign, 
  Share2, 
  Sparkles,
  Phone,
  Mail,
  ExternalLink
} from 'lucide-react';
import { Client, Person, RelationshipEdge } from '@/lib/types';

interface ClientDirectoryProps {
  clients: Client[];
  people: Person[];
  relationships: RelationshipEdge[];
  onOpenNewClientModal: () => void;
  onSelectClient: (client: Client) => void;
}

export const ClientDirectory: React.FC<ClientDirectoryProps> = ({
  clients,
  people,
  relationships,
  onOpenNewClientModal,
  onSelectClient
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedTier, setSelectedTier] = useState<string>('ALL');
  const [activeClientDetail, setActiveClientDetail] = useState<Client | null>(null);

  const filteredClients = clients.filter((client) => {
    const matchesSearch = 
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.industry.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === 'ALL' || client.category === selectedCategory;
    const matchesTier = selectedTier === 'ALL' || client.relationshipTier === selectedTier;

    return matchesSearch && matchesCategory && matchesTier;
  });

  const getPartnerName = (partnerId: string) => {
    const p = people.find((person) => person.id === partnerId);
    return p ? p.name : partnerId;
  };

  return (
    <div className="max-w-[1700px] mx-auto px-4 py-8 space-y-8">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1e293b] pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-[#c5a059]" />
            <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9] tracking-wider uppercase">
              Client & Institutional Relationship Engine
            </h1>
          </div>
          <p className="text-xs text-[#94a3b8] font-serif-body pt-1">
            Central repository for corporations, sovereign funds, family offices, private equity sponsors & institutions.
          </p>
        </div>

        <button
          onClick={onOpenNewClientModal}
          className="flex items-center space-x-2 px-4 py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-semibold text-xs transition-all gold-border-glow cursor-pointer"
          id="onboard-client-btn"
        >
          <Plus className="w-4 h-4" />
          <span>ONBOARD NEW CLIENT</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-5 relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search client by name, code, or industry..."
            className="w-full bg-[#090d16] border border-[#334155] rounded px-3.5 py-2 text-xs text-[#f1f5f9] placeholder-[#475569] focus:outline-none focus:border-[#c5a059] pl-9"
          />
          <Search className="w-4 h-4 text-[#64748b] absolute left-3 top-2.5" />
        </div>

        <div className="md:col-span-3">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-xs text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
          >
            <option value="ALL">All Client Types</option>
            <option value="MULTINATIONAL GROUP">Multinational Groups</option>
            <option value="PRIVATE EQUITY SPONSOR">Private Equity Sponsors</option>
            <option value="FAMILY OFFICE / PRIVATE CLIENT">Family Offices</option>
            <option value="SOVEREIGN FUND">Sovereign Funds</option>
            <option value="CORPORATION">Corporations</option>
          </select>
        </div>

        <div className="md:col-span-4">
          <select
            value={selectedTier}
            onChange={(e) => setSelectedTier(e.target.value)}
            className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-xs text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
          >
            <option value="ALL">All Relationship Tiers</option>
            <option value="TIER_1_INSTITUTIONAL">Tier 1 Institutional</option>
            <option value="TIER_2_KEY_CLIENT">Tier 2 Key Client</option>
            <option value="TIER_3_REGULAR">Tier 3 Regular</option>
          </select>
        </div>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClients.map((client) => (
          <div
            key={client.id}
            onClick={() => {
              setActiveClientDetail(client);
              onSelectClient(client);
            }}
            className="bg-[#0b0f17] border border-[#1e293b] hover:border-[#c5a059]/60 rounded-lg p-5 space-y-4 shadow-xl transition-all hover:bg-[#0f172a]/50 cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              {/* Header */}
              <div className="flex items-start justify-between gap-2 border-b border-[#141d2e] pb-3">
                <div>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-[#1e293b] text-[#c5a059]">
                    {client.code}
                  </span>
                  <h3 className="font-serif-title text-base font-bold text-[#f1f5f9] group-hover:text-[#dfb76c] transition-colors pt-1">
                    {client.name}
                  </h3>
                  <p className="text-[11px] text-[#94a3b8] font-serif-body">
                    {client.industry} · {client.jurisdiction}
                  </p>
                </div>
                <span className={`px-2 py-0.5 rounded text-[9px] font-mono uppercase border ${
                  client.relationshipTier === 'TIER_1_INSTITUTIONAL' ? 'bg-[#1e1b4b] text-[#a5b4fc] border-[#4338ca]' : 'bg-[#1e293b] text-[#cbd5e1] border-[#334155]'
                }`}>
                  {client.relationshipTier.replace('_', ' ')}
                </span>
              </div>

              {/* Core Details */}
              <p className="text-xs text-[#94a3b8] line-clamp-2 font-sans-ui">
                {client.summaryNote}
              </p>

              <div className="space-y-1.5 pt-1 text-xs">
                <div className="flex justify-between text-[#94a3b8]">
                  <span>Lead Relationship Partner:</span>
                  <span className="font-medium text-[#f1f5f9]">{getPartnerName(client.relationshipPartnerId)}</span>
                </div>
                <div className="flex justify-between text-[#94a3b8]">
                  <span>KYC/AML Status:</span>
                  <span className="flex items-center text-[#10b981] font-mono text-[10px]">
                    <ShieldCheck className="w-3 h-3 mr-1" />
                    {client.kycAmlStatus}
                  </span>
                </div>
              </div>
            </div>

            {/* Financial Metrics Bar */}
            <div className="pt-3 border-t border-[#141d2e] grid grid-cols-3 gap-2 text-center bg-[#090d16] p-2.5 rounded">
              <div>
                <p className="text-[9px] font-mono text-[#64748b] uppercase">BILLED YTD</p>
                <p className="text-xs font-serif-title font-bold text-[#f1f5f9]">
                  £{(client.annualRevenueBilled / 1e6).toFixed(1)}m
                </p>
              </div>
              <div>
                <p className="text-[9px] font-mono text-[#64748b] uppercase">UNBILLED WIP</p>
                <p className="text-xs font-serif-title font-bold text-[#dfb76c]">
                  £{(client.unbilledWip / 1e6).toFixed(1)}m
                </p>
              </div>
              <div>
                <p className="text-[9px] font-mono text-[#64748b] uppercase">MARGIN</p>
                <p className="text-xs font-serif-title font-bold text-[#10b981]">
                  {client.marginPercentage}%
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cross-Selling Intelligence Panel */}
      <div className="bg-[#0b0f17] border border-[#334155] rounded-lg p-6 space-y-4 shadow-xl">
        <div className="flex items-center space-x-2 border-b border-[#141d2e] pb-3">
          <Sparkles className="w-4 h-4 text-[#c5a059]" />
          <h2 className="font-serif-title text-xs tracking-widest text-[#dfb76c] uppercase font-bold">
            CROSS-SELLING & RELATIONSHIP EXPANSION ENGINE
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded bg-[#090d16] border border-[#1e293b] space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-serif-title font-bold text-[#f1f5f9]">Aurelia Industries PLC</span>
              <span className="text-[10px] font-mono text-[#c5a059]">High Opportunity</span>
            </div>
            <p className="text-[#94a3b8]">
              Client currently instructs Ashcombe across <strong className="text-[#e2e8f0]">Corporate, M&A and Tax</strong>. Their 4 European defense subsidiaries have no active instruction with our <strong className="text-[#dfb76c]">Employment & Pension Practice</strong>.
            </p>
            <p className="text-[10px] font-mono text-[#64748b]">Suggested Partner Intro: Eleanor Vance-Roth → Victoria Croft KC</p>
          </div>

          <div className="p-4 rounded bg-[#090d16] border border-[#1e293b] space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-serif-title font-bold text-[#f1f5f9]">Rothschild-Vane Family Office</span>
              <span className="text-[10px] font-mono text-[#c5a059]">Strategic Gap</span>
            </div>
            <p className="text-[#94a3b8]">
              Active in <strong className="text-[#e2e8f0]">Tax and Private Client</strong>. Family is acquiring £450m of UK commercial logistics real estate without using Ashcombe’s <strong className="text-[#dfb76c]">Real Estate & Finance Practice</strong>.
            </p>
            <p className="text-[10px] font-mono text-[#64748b]">Suggested Action: Schedule Zurich/London Partner Sync</p>
          </div>
        </div>
      </div>

      {/* Client Detail Modal */}
      {activeClientDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg w-full max-w-2xl p-6 space-y-6 shadow-2xl relative">
            <div className="flex justify-between items-start border-b border-[#1e293b] pb-4">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#1e293b] text-[#c5a059]">
                  {activeClientDetail.code}
                </span>
                <h2 className="font-serif-title text-xl font-bold text-[#f1f5f9] pt-1">
                  {activeClientDetail.name}
                </h2>
                <p className="text-xs text-[#94a3b8]">
                  {activeClientDetail.category} · {activeClientDetail.jurisdiction}
                </p>
              </div>
              <button
                onClick={() => setActiveClientDetail(null)}
                className="text-[#94a3b8] hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4 bg-[#090d16] p-4 rounded border border-[#1a2333]">
                <div>
                  <p className="text-[10px] font-mono text-[#64748b]">ANNUAL BILLED REVENUE</p>
                  <p className="text-lg font-serif-title font-bold text-[#f1f5f9]">
                    £{activeClientDetail.annualRevenueBilled.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] font-mono text-[#64748b]">ACTIVE UNBILLED WIP</p>
                  <p className="text-lg font-serif-title font-bold text-[#dfb76c]">
                    £{activeClientDetail.unbilledWip.toLocaleString()}
                  </p>
                </div>
              </div>

              <div>
                <p className="font-semibold text-[#f1f5f9] mb-1">Key Client Contacts:</p>
                <div className="space-y-2">
                  {activeClientDetail.contacts.map((c) => (
                    <div key={c.id} className="p-2.5 rounded bg-[#090d16] border border-[#1e293b] flex items-center justify-between">
                      <div>
                        <p className="font-medium text-[#f1f5f9]">{c.name} ({c.role})</p>
                        <p className="text-[10px] text-[#64748b]">{c.email} · {c.phone}</p>
                      </div>
                      {c.isPrimary && (
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#10b981]/20 text-[#a7f3d0] border border-[#047857]">
                          Primary Contact
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-[#1e293b] flex justify-end">
              <button
                onClick={() => setActiveClientDetail(null)}
                className="px-4 py-2 rounded bg-[#1e293b] hover:bg-[#334155] text-xs text-white"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
