'use client';

import React, { useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  Award, 
  PieChart, 
  ShieldCheck, 
  Briefcase, 
  ArrowUpRight,
  ChevronRight
} from 'lucide-react';
import { Person, PartnerEconomics } from '@/lib/types';

interface PartnerTerminalViewProps {
  people: Person[];
  economics: PartnerEconomics[];
}

export const PartnerTerminalView: React.FC<PartnerTerminalViewProps> = ({
  people,
  economics
}) => {
  const partners = people.filter((p) => p.grade.includes('Partner'));

  return (
    <div className="max-w-[1700px] mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1e293b] pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-[#c5a059]" />
            <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9] tracking-wider uppercase">
              Partner Terminal & Partnership Economics Control
            </h1>
          </div>
          <p className="text-xs text-[#94a3b8] font-serif-body pt-1">
            Capital Accounts, Profit Allocation, Origination Attribution, Draw Schedule & Equity Realisation.
          </p>
        </div>
      </div>

      {/* Partnership Performance Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">TOTAL EQUITY PARTNERS</p>
          <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">318</p>
          <p className="text-[10px] text-[#10b981] font-mono">6 Global Offices</p>
        </div>

        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">TOTAL YTD ORIGINATION</p>
          <p className="text-2xl font-serif-title font-bold text-[#dfb76c]">£842.7m</p>
          <p className="text-[10px] text-[#94a3b8] font-mono">Attributable Client Origination</p>
        </div>

        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">AVERAGE PROFIT PER EQUITY PARTNER (PEP)</p>
          <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">£3.42m</p>
          <p className="text-[10px] text-[#10b981] font-mono">+6.2% vs PY</p>
        </div>

        <div className="p-4 rounded bg-[#0b0f17] border border-[#1e293b]">
          <p className="text-[10px] font-mono text-[#64748b] uppercase">PAID DRAW DISTRIBUTION</p>
          <p className="text-2xl font-serif-title font-bold text-[#f1f5f9]">£182.4m</p>
          <p className="text-[10px] text-[#94a3b8] font-mono">Monthly Lock-step Release</p>
        </div>
      </div>

      {/* Partner Ledger Table */}
      <div className="bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-[#141d2e] pb-3">
          <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
            PARTNER CAPITAL ACCOUNTS & ORIGINATION LEDGER
          </h2>
          <span className="text-[10px] font-mono text-[#64748b]">Confidential Partner Access Only</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans-ui">
            <thead className="bg-[#090d16] text-[#64748b] font-mono text-[10px] uppercase border-b border-[#1e293b]">
              <tr>
                <th className="py-3 px-3">Partner Name</th>
                <th className="py-3 px-3">Grade & Office</th>
                <th className="py-3 px-3">Practice</th>
                <th className="py-3 px-3 text-right">Origination YTD (£)</th>
                <th className="py-3 px-3 text-right">Billings YTD (£)</th>
                <th className="py-3 px-3 text-right">Realisation %</th>
                <th className="py-3 px-3 text-right">Capital Account (£)</th>
                <th className="py-3 px-3 text-center">Lock-Step Tier</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#141d2e]">
              {partners.map((partner) => {
                const partnerEcon = economics.find((e) => e.personId === partner.id);
                return (
                  <tr key={partner.id} className="hover:bg-[#0f172a]/50 transition-colors">
                    <td className="py-3 px-3 font-medium text-[#f1f5f9] font-serif-title text-sm">
                      {partner.name}
                    </td>
                    <td className="py-3 px-3 text-[#cbd5e1]">
                      {partner.grade} · <strong className="text-[#f1f5f9]">{partner.office}</strong>
                    </td>
                    <td className="py-3 px-3 text-[#c5a059]">{partner.practice}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-[#dfb76c]">
                      £{(partner.originationYTD / 1e6).toFixed(2)}m
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-[#f1f5f9]">
                      £{(partner.workingBillingsYTD / 1e6).toFixed(2)}m
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-[#10b981] font-bold">
                      {partner.realisationRate}%
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-[#cbd5e1]">
                      {partnerEcon ? `£${(partnerEcon.capitalAccount / 1e6).toFixed(2)}m` : '£2.50m'}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e293b] text-[#c5a059] border border-[#334155]">
                        Tier 1 Senior
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
