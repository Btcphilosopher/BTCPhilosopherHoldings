'use client';

import React, { useState } from 'react';
import { 
  Briefcase, 
  Plus, 
  Search, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  ShieldAlert, 
  User, 
  Calendar, 
  DollarSign,
  ChevronRight,
  Filter,
  Scale,
  Building,
  BarChart,
  Layers
} from 'lucide-react';
import { Matter, Person, Client, PracticeGroup } from '@/lib/types';

interface MatterEngineViewProps {
  matters: Matter[];
  people: Person[];
  clients: Client[];
  onOpenNewMatterModal: () => void;
  onSelectMatter: (matter: Matter) => void;
}

export const MatterEngineView: React.FC<MatterEngineViewProps> = ({
  matters,
  people,
  clients,
  onOpenNewMatterModal,
  onSelectMatter
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedModule, setSelectedModule] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [activeMatterDetail, setActiveMatterDetail] = useState<Matter | null>(null);

  const filteredMatters = matters.filter((m) => {
    const matchesSearch = 
      m.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.practice.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesModule = selectedModule === 'ALL' || m.moduleType === selectedModule;
    const matchesStatus = selectedStatus === 'ALL' || m.status === selectedStatus;

    return matchesSearch && matchesModule && matchesStatus;
  });

  const getClientName = (clientId: string) => {
    const c = clients.find((client) => client.id === clientId);
    return c ? c.name : clientId;
  };

  const getPersonName = (personId: string) => {
    const p = people.find((person) => person.id === personId);
    return p ? p.name : personId;
  };

  return (
    <div className="max-w-[1700px] mx-auto px-4 py-8 space-y-8">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1e293b] pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-[#c5a059]" />
            <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9] tracking-wider uppercase">
              Universal Matter & Engagement Engine
            </h1>
          </div>
          <p className="text-xs text-[#94a3b8] font-serif-body pt-1">
            Unifying Legal Takeovers, Tax Structuring, Forensic Audits, Restructuring & Strategy Projects.
          </p>
        </div>

        <button
          onClick={onOpenNewMatterModal}
          className="flex items-center space-x-2 px-4 py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-semibold text-xs transition-all gold-border-glow cursor-pointer"
          id="open-new-matter-btn"
        >
          <Plus className="w-4 h-4" />
          <span>OPEN NEW MATTER</span>
        </button>
      </div>

      {/* Module Filter Tabs */}
      <div className="flex flex-wrap gap-2 text-xs font-mono">
        {[
          { id: 'ALL', label: 'All Practice Modules', icon: <Layers className="w-3.5 h-3.5" /> },
          { id: 'LEGAL', label: 'Legal Takeovers & Disputes', icon: <Scale className="w-3.5 h-3.5" /> },
          { id: 'TAX', label: 'Tax Advisory & Structuring', icon: <FileText className="w-3.5 h-3.5" /> },
          { id: 'ACCOUNTANCY', label: 'Audit & Forensic Ledger', icon: <Building className="w-3.5 h-3.5" /> },
          { id: 'CONSULTING', label: 'Strategy & Transformations', icon: <BarChart className="w-3.5 h-3.5" /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedModule(tab.id)}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded transition-all cursor-pointer ${
              selectedModule === tab.id
                ? 'bg-[#1e293b] text-[#c5a059] border border-[#c5a059]/40 font-bold'
                : 'bg-[#090d16] text-[#94a3b8] hover:text-white border border-[#1a2333]'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Search & Status Filters */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-8 relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search matter title, code, or practice group..."
            className="w-full bg-[#090d16] border border-[#334155] rounded px-3.5 py-2 text-xs text-[#f1f5f9] placeholder-[#475569] focus:outline-none focus:border-[#c5a059] pl-9"
          />
          <Search className="w-4 h-4 text-[#64748b] absolute left-3 top-2.5" />
        </div>

        <div className="md:col-span-4">
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-xs text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active Engagements</option>
            <option value="CONFLICT_CHECK">Pending Conflict Clearance</option>
            <option value="BILLING">Billing & Pre-Bill Review</option>
            <option value="CLOSED">Closed & Archived</option>
          </select>
        </div>
      </div>

      {/* Matters List Cards */}
      <div className="space-y-4">
        {filteredMatters.map((matter) => (
          <div
            key={matter.id}
            onClick={() => {
              setActiveMatterDetail(matter);
              onSelectMatter(matter);
            }}
            className="bg-[#0b0f17] border border-[#1e293b] hover:border-[#c5a059]/60 rounded-lg p-5 space-y-4 shadow-xl transition-all hover:bg-[#0f172a]/50 cursor-pointer group"
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#141d2e] pb-3">
              <div className="space-y-1">
                <div className="flex items-center space-x-3">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#1e293b] text-[#c5a059] border border-[#334155]">
                    {matter.code}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#0f172a] text-[#a5b4fc] border border-[#3730a3]">
                    {matter.moduleType} MODULE
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-mono uppercase ${
                    matter.riskRating === 'HIGH' ? 'bg-[#7f1d1d]/40 text-[#fecca3] border border-[#991b1b]' : 'bg-[#064e3b]/40 text-[#a7f3d0] border border-[#047857]'
                  }`}>
                    {matter.riskRating} RISK
                  </span>
                </div>
                <h3 className="font-serif-title text-base font-bold text-[#f1f5f9] group-hover:text-[#dfb76c] transition-colors pt-1">
                  {matter.title}
                </h3>
                <p className="text-xs text-[#94a3b8] font-serif-body">
                  Client: <strong className="text-[#e2e8f0]">{getClientName(matter.clientId)}</strong> · Lead Partner: <strong className="text-[#e2e8f0]">{getPersonName(matter.leadPartnerId)}</strong>
                </p>
              </div>

              {/* Financial & Timeline Metrics */}
              <div className="flex items-center space-x-6 text-right">
                <div>
                  <p className="text-[9px] font-mono text-[#64748b] uppercase">AGREED BUDGET</p>
                  <p className="text-xs font-serif-title font-bold text-[#f1f5f9]">
                    £{matter.agreedBudget.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-[9px] font-mono text-[#64748b] uppercase">CURRENT UNBILLED WIP</p>
                  <p className="text-xs font-serif-title font-bold text-[#dfb76c]">
                    £{matter.wipAmount.toLocaleString()}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-[#64748b] group-hover:text-[#c5a059] transition-colors" />
              </div>
            </div>

            {/* Description & Practice-Specific Metadata Preview */}
            <p className="text-xs text-[#94a3b8] font-sans-ui">
              {matter.description}
            </p>

            {/* Sub-module details preview */}
            {matter.legalMeta && (
              <div className="bg-[#090d16] p-3 rounded border border-[#1a2333] text-xs space-y-1 font-mono">
                <p className="text-[#c5a059] font-bold">LEGAL COURT & FORUM DETAILS:</p>
                <p className="text-[#cbd5e1]">Forum: {matter.legalMeta.forum} (Case No: {matter.legalMeta.courtCaseNo})</p>
                <p className="text-[#94a3b8]">Counterparty: {matter.legalMeta.counterparty} · Opposing Counsel: {matter.legalMeta.opposingCounsel}</p>
              </div>
            )}

            {matter.taxMeta && (
              <div className="bg-[#090d16] p-3 rounded border border-[#1a2333] text-xs space-y-1 font-mono">
                <p className="text-[#c5a059] font-bold">TAX ADVISORY & STATUTORY FRAMEWORK:</p>
                <p className="text-[#cbd5e1]">Authority: {matter.taxMeta.taxAuthority} (Rule Version: {matter.taxMeta.ruleVersion})</p>
                <p className="text-[#94a3b8]">Structure: {matter.taxMeta.taxStructureType} · Tax Year: {matter.taxMeta.taxYear}</p>
              </div>
            )}

            {matter.consultingMeta && (
              <div className="bg-[#090d16] p-3 rounded border border-[#1a2333] text-xs space-y-1 font-mono">
                <p className="text-[#c5a059] font-bold">CONSULTING & STRATEGY TRANSFORMATIONS:</p>
                <p className="text-[#cbd5e1]">Phase: {matter.consultingMeta.operatingModelPhase}</p>
                <p className="text-[#94a3b8]">Deliverables: {matter.consultingMeta.deliverables?.join(', ')}</p>
              </div>
            )}

            {/* Deadlines Bar */}
            {matter.deadlines && matter.deadlines.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {matter.deadlines.map((d) => (
                  <span key={d.id} className="inline-flex items-center space-x-1 px-2 py-1 rounded bg-[#0f172a] border border-[#334155] text-[10px] text-[#e2e8f0]">
                    <Clock className="w-3 h-3 text-[#c5a059]" />
                    <span>{d.title}: <strong>{d.date}</strong></span>
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Matter Detail Inspection Modal */}
      {activeMatterDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg w-full max-w-3xl p-6 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b border-[#1e293b] pb-4">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#1e293b] text-[#c5a059]">
                  {activeMatterDetail.code}
                </span>
                <h2 className="font-serif-title text-xl font-bold text-[#f1f5f9] pt-1">
                  {activeMatterDetail.title}
                </h2>
                <p className="text-xs text-[#94a3b8]">
                  {activeMatterDetail.practice} · {activeMatterDetail.jurisdiction}
                </p>
              </div>
              <button onClick={() => setActiveMatterDetail(null)} className="text-[#94a3b8] hover:text-white">✕</button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-4 rounded bg-[#090d16] border border-[#1a2333] space-y-2">
                <p className="font-semibold text-[#f1f5f9]">Matter Overview & Scope:</p>
                <p className="text-[#94a3b8] leading-relaxed">{activeMatterDetail.description}</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-[#090d16] rounded border border-[#1a2333]">
                  <p className="text-[9px] font-mono text-[#64748b]">FEE MODEL</p>
                  <p className="font-bold text-[#f1f5f9]">{activeMatterDetail.feeModel.replace('_', ' ')}</p>
                </div>
                <div className="p-3 bg-[#090d16] rounded border border-[#1a2333]">
                  <p className="text-[9px] font-mono text-[#64748b]">AGREED BUDGET</p>
                  <p className="font-bold text-[#f1f5f9]">£{activeMatterDetail.agreedBudget.toLocaleString()}</p>
                </div>
                <div className="p-3 bg-[#090d16] rounded border border-[#1a2333]">
                  <p className="text-[9px] font-mono text-[#64748b]">UNBILLED WIP</p>
                  <p className="font-bold text-[#dfb76c]">£{activeMatterDetail.wipAmount.toLocaleString()}</p>
                </div>
              </div>

              {/* Tasks Checklist */}
              {activeMatterDetail.tasks && activeMatterDetail.tasks.length > 0 && (
                <div className="space-y-2">
                  <p className="font-semibold text-[#f1f5f9]">Key Work Tasks:</p>
                  <div className="space-y-1.5">
                    {activeMatterDetail.tasks.map((t) => (
                      <div key={t.id} className="p-2.5 rounded bg-[#090d16] border border-[#1e293b] flex items-center justify-between">
                        <span className="text-[#e2e8f0]">{t.title} (Assigned: {getPersonName(t.assigneeId)})</span>
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#1e293b] text-[#c5a059]">
                          Due: {t.dueDate}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-[#1e293b] flex justify-end space-x-3">
              <button
                onClick={() => setActiveMatterDetail(null)}
                className="px-4 py-2 rounded bg-[#1e293b] hover:bg-[#334155] text-xs text-white"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
