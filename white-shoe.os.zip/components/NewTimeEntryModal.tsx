'use client';

import React, { useState } from 'react';
import { X, Clock } from 'lucide-react';
import { TimeEntry, Matter, Person } from '@/lib/types';

interface NewTimeEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  matters: Matter[];
  people: Person[];
  onSave: (entry: TimeEntry) => void;
}

export const NewTimeEntryModal: React.FC<NewTimeEntryModalProps> = ({
  isOpen,
  onClose,
  matters,
  people,
  onSave
}) => {
  const [matterId, setMatterId] = useState(matters[0]?.id || 'm-501');
  const [personId, setPersonId] = useState('p-101'); // Lord Henry Ashcombe KC
  const [hours, setHours] = useState('3.5');
  const [activity, setActivity] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activity) return;

    const selectedPerson = people.find((p) => p.id === personId);
    const rate = selectedPerson ? selectedPerson.rateHourly : 1250;

    const selectedMatter = matters.find((m) => m.id === matterId);

    const newEntry: TimeEntry = {
      id: `t-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      personId,
      matterId,
      clientId: selectedMatter?.clientId || 'c-301',
      activityDescription: activity,
      category: 'BILLABLE',
      hours: parseFloat(hours) || 1.0,
      hourlyRate: rate,
      isApproved: true,
      billedStatus: 'UNBILLED'
    };

    onSave(newEntry);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg w-full max-w-lg p-6 space-y-6 shadow-2xl relative gold-border-glow">
        <div className="flex justify-between items-center border-b border-[#1e293b] pb-3">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif-title text-sm tracking-widest text-[#f1f5f9] font-bold uppercase">
              RECORD PROFESSIONAL TIME ENTRY
            </h2>
          </div>
          <button onClick={onClose} className="text-[#94a3b8] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-sans-ui">
          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Select Professional:</label>
            <select
              value={personId}
              onChange={(e) => setPersonId(e.target.value)}
              className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            >
              {people.map((p) => (
                <option key={p.id} value={p.id}>{p.name} ({p.grade} · £{p.rateHourly}/hr)</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Select Active Matter:</label>
            <select
              value={matterId}
              onChange={(e) => setMatterId(e.target.value)}
              className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            >
              {matters.map((m) => (
                <option key={m.id} value={m.id}>{m.code}: {m.title}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Duration (Hours):</label>
            <input
              type="number"
              step="0.1"
              required
              value={hours}
              onChange={(e) => setHours(e.target.value)}
              className="w-full bg-[#090d16] border border-[#334155] rounded px-3 py-2 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            />
          </div>

          <div>
            <label className="block text-[#94a3b8] mb-1 font-medium">Detailed Work Narrative:</label>
            <textarea
              rows={3}
              required
              value={activity}
              onChange={(e) => setActivity(e.target.value)}
              placeholder="e.g. Attendance on takeover strategy with Counsel and General Counsel..."
              className="w-full bg-[#090d16] border border-[#334155] rounded p-2.5 text-[#f1f5f9] focus:outline-none focus:border-[#c5a059]"
            />
          </div>

          <div className="pt-2 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-[#1e293b] hover:bg-[#334155] text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-bold"
            >
              Submit & Approve Time
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
