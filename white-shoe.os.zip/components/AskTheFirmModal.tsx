'use client';

import React, { useState, useEffect } from 'react';
import { Sparkles, X, Send, Database, FileText, CheckCircle, ExternalLink, RefreshCw } from 'lucide-react';

interface AskTheFirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  onNavigateToTab?: (tab: string) => void;
}

interface Citation {
  label: string;
  source: string;
  recordId: string;
}

export const AskTheFirmModal: React.FC<AskTheFirmModalProps> = ({
  isOpen,
  onClose,
  initialQuery = '',
  onNavigateToTab
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);
  const [citations, setCitations] = useState<Citation[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleExecuteQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    setLoading(true);
    setError(null);
    setResponse(null);

    try {
      const res = await fetch('/api/gemini/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: queryText, userRole: 'Partner' }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to query firm intelligence layer');
      }

      setResponse(data.text);
      if (data.citations) {
        setCitations(data.citations);
      }
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Error executing query.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      const timer = setTimeout(() => {
        setQuery(initialQuery);
        handleExecuteQuery(initialQuery);
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [initialQuery]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleExecuteQuery(query);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0b0f17] border border-[#c5a059]/40 rounded-lg w-full max-w-3xl shadow-2xl overflow-hidden gold-border-glow">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#1e293b] bg-[#080c14]">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded bg-[#0f172a] border border-[#c5a059]/40 flex items-center justify-center text-[#c5a059]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif-title text-sm tracking-widest text-[#f1f5f9] font-bold uppercase">
                ASK THE FIRM · NATURAL LANGUAGE TERMINAL
              </h2>
              <p className="text-[10px] text-[#64748b] font-mono">
                Gemini 3.6 Intelligence Layer · Authoritative Partnership Query Engine
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#94a3b8] hover:text-white p-1 rounded hover:bg-[#1e293b] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Query Input Area */}
        <div className="p-6 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="relative">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask any question regarding clients, matters, partners, WIP, conflicts or precedents..."
                className="w-full bg-[#090d16] border border-[#334155] rounded-lg px-4 py-3 text-sm text-[#f1f5f9] placeholder-[#475569] focus:outline-none focus:border-[#c5a059] pr-12 font-sans-ui"
                autoFocus
              />
              <button
                type="submit"
                disabled={loading}
                className="absolute right-2 top-2 px-3 py-1.5 rounded bg-[#c5a059] hover:bg-[#dfb76c] text-black font-semibold text-xs flex items-center space-x-1 transition-all disabled:opacity-50 cursor-pointer"
              >
                {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">Query</span>
              </button>
            </div>
          </form>

          {/* Quick Preset Prompts */}
          {!response && !loading && (
            <div className="space-y-2">
              <p className="text-[10px] font-mono text-[#64748b] uppercase tracking-wider">Example Executive Queries:</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  "Show me every active M&A matter and their unbilled WIP",
                  "Which partners know Aurelia Industries PLC?",
                  "Find all previous infrastructure transaction precedents",
                  "Prepare the managing partner's morning financial briefing"
                ].map((promptText) => (
                  <button
                    key={promptText}
                    onClick={() => {
                      setQuery(promptText);
                      handleExecuteQuery(promptText);
                    }}
                    className="p-2.5 rounded bg-[#090d16] border border-[#1e293b] hover:border-[#c5a059]/40 text-xs text-[#cbd5e1] text-left hover:text-[#f1f5f9] transition-all cursor-pointer font-serif-body"
                  >
                    &quot;{promptText}&quot;
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading Indicator */}
          {loading && (
            <div className="py-12 text-center space-y-3">
              <RefreshCw className="w-6 h-6 text-[#c5a059] animate-spin mx-auto" />
              <p className="text-xs text-[#94a3b8] font-mono">
                Querying Ashcombe, Stone & Thorne Institutional Mind...
              </p>
            </div>
          )}

          {/* Response Output & Citation Trace */}
          {response && (
            <div className="space-y-4 max-h-[450px] overflow-y-auto pr-2">
              <div className="p-4 rounded bg-[#090d16] border border-[#1a2333] space-y-3">
                <div className="flex items-center justify-between border-b border-[#141d2e] pb-2 text-[10px] font-mono text-[#64748b]">
                  <span className="flex items-center space-x-1 text-[#10b981]">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    AUTHORITATIVE RESPONSE
                  </span>
                  <span>Reviewable AI Output</span>
                </div>

                <div className="prose prose-invert prose-xs text-xs text-[#e2e8f0] font-sans-ui whitespace-pre-wrap leading-relaxed">
                  {response}
                </div>
              </div>

              {/* Citation & Source Trace */}
              {citations.length > 0 && (
                <div className="p-3 rounded bg-[#080c14] border border-[#1e293b] space-y-2">
                  <p className="text-[10px] font-mono text-[#64748b] uppercase tracking-wider flex items-center space-x-1">
                    <Database className="w-3 h-3 text-[#c5a059]" />
                    <span>SYSTEM CITATION TRACEABILITY:</span>
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {citations.map((c, i) => (
                      <div
                        key={i}
                        className="px-2.5 py-1 rounded bg-[#0f172a] border border-[#334155] text-[11px] text-[#cbd5e1] flex items-center space-x-1.5"
                      >
                        <FileText className="w-3 h-3 text-[#c5a059]" />
                        <span className="font-medium text-[#f1f5f9]">{c.label}</span>
                        <span className="text-[9px] text-[#64748b] font-mono">({c.source})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="p-3 rounded bg-[#7f1d1d]/20 border border-[#991b1b] text-xs text-[#f87171]">
              {error}
            </div>
          )}
        </div>

        {/* Footer Note */}
        <div className="px-6 py-3 bg-[#080c14] border-t border-[#1e293b] flex items-center justify-between text-[10px] text-[#64748b] font-mono">
          <span>Non-Negotiable Rule: AI suggestions are reviewable and require human partner sign-off.</span>
          <button
            onClick={onClose}
            className="text-[#94a3b8] hover:text-white transition-colors cursor-pointer"
          >
            Close Terminal
          </button>
        </div>

      </div>
    </div>
  );
};
