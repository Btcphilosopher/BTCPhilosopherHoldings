'use client';

import React, { useState } from 'react';
import { Share2, ZoomIn, ZoomOut, RefreshCw, Filter, Layers, Info } from 'lucide-react';
import { Client, Matter, Person, KnowledgeItem } from '@/lib/types';

interface FirmGraphProps {
  clients: Client[];
  matters: Matter[];
  people: Person[];
  knowledge: KnowledgeItem[];
}

export const FirmGraphInteractive: React.FC<FirmGraphProps> = ({
  clients,
  matters,
  people,
  knowledge
}) => {
  const [selectedNodeType, setSelectedNodeType] = useState<string>('ALL');
  const [selectedNode, setSelectedNode] = useState<any | null>(null);

  // Define graph layout nodes
  const nodes = [
    { id: 'f-1', label: 'Ashcombe, Stone & Thorne', type: 'FIRM', x: 400, y: 300, color: '#c5a059', size: 28 },
    
    // Practices
    { id: 'pr-1', label: 'Corporate & M&A', type: 'PRACTICE', x: 250, y: 150, color: '#818cf8', size: 18 },
    { id: 'pr-2', label: 'Tax Advisory', type: 'PRACTICE', x: 550, y: 150, color: '#38bdf8', size: 18 },
    { id: 'pr-3', label: 'Private Client', type: 'PRACTICE', x: 250, y: 450, color: '#f43f5e', size: 18 },
    { id: 'pr-4', label: 'Restructuring', type: 'PRACTICE', x: 550, y: 450, color: '#fbbf24', size: 18 },

    // Partners
    { id: 'p-1', label: 'Lord Henry Ashcombe KC', type: 'PARTNER', x: 180, y: 100, color: '#a7f3d0', size: 14, details: 'Senior Partner · London' },
    { id: 'p-2', label: 'Eleanor Vance-Roth', type: 'PARTNER', x: 620, y: 100, color: '#a7f3d0', size: 14, details: 'Equity Partner · Zurich' },

    // Clients
    { id: 'c-1', label: 'Aurelia Industries PLC', type: 'CLIENT', x: 100, y: 220, color: '#f472b6', size: 16, details: 'Multinational Group · £14.2m Billed YTD' },
    { id: 'c-2', label: 'Rothschild-Vane Family Office', type: 'CLIENT', x: 700, y: 220, color: '#f472b6', size: 16, details: 'Private Client · Zurich / London' },

    // Matters
    { id: 'm-1', label: 'Project Sovereign', type: 'MATTER', x: 120, y: 320, color: '#dfb76c', size: 15, details: '£2.4bn M&A Takeover (£840k WIP)' },
    { id: 'm-2', label: 'Global Pillar 2 Tax Structuring', type: 'MATTER', x: 680, y: 320, color: '#dfb76c', size: 15, details: 'Cross-Border Swiss Structuring (£420k WIP)' },
  ];

  const links = [
    { source: 'f-1', target: 'pr-1' },
    { source: 'f-1', target: 'pr-2' },
    { source: 'f-1', target: 'pr-3' },
    { source: 'f-1', target: 'pr-4' },
    { source: 'pr-1', target: 'p-1' },
    { source: 'pr-2', target: 'p-2' },
    { source: 'p-1', target: 'c-1' },
    { source: 'p-2', target: 'c-2' },
    { source: 'c-1', target: 'm-1' },
    { source: 'c-2', target: 'm-2' },
  ];

  return (
    <div className="max-w-[1700px] mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1e293b] pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <Share2 className="w-5 h-5 text-[#c5a059]" />
            <h1 className="font-serif-title text-xl font-bold text-[#f1f5f9] tracking-wider uppercase">
              The Firm Relational Graph · Institutional Network Canvas
            </h1>
          </div>
          <p className="text-xs text-[#94a3b8] font-serif-body pt-1">
            Visualizing interconnected relationships between Practices, Partners, Clients, Active Matters, and Knowledge Assets.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* SVG Interactive Canvas */}
        <div className="lg:col-span-8 bg-[#080c14] border border-[#1e293b] rounded-lg p-4 shadow-2xl relative overflow-hidden h-[550px]">
          <svg className="w-full h-full" viewBox="0 0 800 600">
            {/* Draw Links */}
            {links.map((link, i) => {
              const sNode = nodes.find((n) => n.id === link.source);
              const tNode = nodes.find((n) => n.id === link.target);
              if (!sNode || !tNode) return null;

              return (
                <line
                  key={i}
                  x1={sNode.x}
                  y1={sNode.y}
                  x2={tNode.x}
                  y2={tNode.y}
                  stroke="#1e293b"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                />
              );
            })}

            {/* Draw Nodes */}
            {nodes.map((node) => (
              <g
                key={node.id}
                transform={`translate(${node.x},${node.y})`}
                onClick={() => setSelectedNode(node)}
                className="cursor-pointer group"
              >
                <circle
                  r={node.size}
                  fill={node.color}
                  stroke="#080c14"
                  strokeWidth="3"
                  className="transition-all group-hover:scale-125"
                />
                <text
                  y={node.size + 14}
                  textAnchor="middle"
                  fill="#f1f5f9"
                  fontSize="10"
                  fontFamily="Cinzel, serif"
                  fontWeight="bold"
                >
                  {node.label}
                </text>
              </g>
            ))}
          </svg>

          <div className="absolute bottom-4 left-4 bg-[#090d16]/90 border border-[#1e293b] p-3 rounded text-[10px] font-mono text-[#64748b] space-y-1">
            <p className="text-[#c5a059] font-bold">LEGEND:</p>
            <div className="flex items-center space-x-3">
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#c5a059] mr-1"></span>Firm</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#818cf8] mr-1"></span>Practices</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#a7f3d0] mr-1"></span>Partners</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#f472b6] mr-1"></span>Clients</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#dfb76c] mr-1"></span>Matters</span>
            </div>
          </div>
        </div>

        {/* Node Inspection Panel */}
        <div className="lg:col-span-4 bg-[#0b0f17] border border-[#1e293b] rounded-lg p-6 space-y-4 shadow-xl">
          <div className="border-b border-[#141d2e] pb-3 flex items-center space-x-2">
            <Info className="w-4 h-4 text-[#c5a059]" />
            <h2 className="font-serif-title text-xs tracking-widest text-[#f1f5f9] uppercase font-bold">
              GRAPH NODE METADATA INSPECTOR
            </h2>
          </div>

          {selectedNode ? (
            <div className="space-y-3 font-sans-ui text-xs">
              <div className="p-3 bg-[#090d16] rounded border border-[#1e293b]">
                <span className="text-[9px] font-mono text-[#c5a059] uppercase">{selectedNode.type}</span>
                <h3 className="font-serif-title font-bold text-sm text-[#f1f5f9] pt-1">{selectedNode.label}</h3>
                {selectedNode.details && (
                  <p className="text-[#94a3b8] pt-1 font-serif-body">{selectedNode.details}</p>
                )}
              </div>

              <div className="p-3 bg-[#090d16] rounded border border-[#1e293b] space-y-1 font-mono text-[11px]">
                <p className="text-[#64748b]">Connected Relationships:</p>
                <p className="text-[#e2e8f0]">• 12 Associated Active Matters</p>
                <p className="text-[#e2e8f0]">• £1.4m Combined WIP</p>
                <p className="text-[#e2e8f0]">• 4 Indexed Precedents</p>
              </div>
            </div>
          ) : (
            <div className="py-20 text-center text-xs text-[#64748b] font-mono">
              Click any node in the canvas to inspect relationship connectivity & financial stats.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
