import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  PrincipalProfile,
  Person,
  Residence,
  Aircraft,
  Yacht,
  Resource,
  Calendar,
  Commitment,
  SchedulingRequest,
  AuditEvent,
  ScheduleVersion,
  RoleType,
  MeetingBrief,
  AiCommandResponse,
} from '../models/schedule-os.types';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ScheduleOsService {
  private http = inject(HttpClient);

  // Active User Role for Delegation & ABAC view filtering
  readonly activeUserRole = signal<RoleType>('PRINCIPAL');

  // Active Main View Tab
  readonly activeView = signal<string>('TODAY');

  // Selected Commitment for Deep Inspector / Briefing Drawer
  readonly selectedCommitmentId = signal<string | null>('comm-1');

  // AI Command / Assistant Processing
  readonly isAiProcessing = signal<boolean>(false);
  readonly lastAiResponse = signal<AiCommandResponse | null>(null);

  // Executive Morning Briefing
  readonly executiveBriefText = signal<string | null>(null);
  readonly isGeneratingBrief = signal<boolean>(false);

  // Active Meeting Brief Object
  readonly activeMeetingBrief = signal<MeetingBrief | null>(null);

  // Principal State
  readonly principal = signal<PrincipalProfile>({
    id: 'p-1',
    name: 'Alexander Ashcombe',
    title: 'Chairman & Principal, Ashcombe Global Office',
    homeCity: 'London',
    currentCity: 'London',
    preferredWakeTime: '06:30',
    preferredSleepTime: '23:00',
    preferredMeetingHours: { start: '09:00', end: '17:30' },
    maxMeetingsPerDay: 5,
    maxConsecutiveMeetings: 2,
    minimumBreakMinutes: 30,
    travelBufferMinutes: 45,
    securityBufferMinutes: 20,
    priorities: {
      familyWeight: 90,
      investmentWeight: 85,
      boardWeight: 80,
      deepWorkWeight: 75,
      healthWeight: 70,
    },
    energyLevel: 82,
    fatigueScore: 24,
  });

  // People & Directory
  readonly people = signal<Person[]>([
    {
      id: 'per-1',
      name: 'Victoria Ashcombe',
      title: 'Spouse & Trustee',
      role: 'SPOUSE',
      relationship: 'Spouse',
      email: 'victoria@ashcombe-office.com',
      timezone: 'Europe/London',
      currentLocation: 'London Residence',
      securityLevel: 'VIP',
      permissionLevels: ['VIEW', 'VIEW_DETAILS', 'PROPOSE', 'SCHEDULE'],
      lastContactDaysAgo: 0,
      targetCadenceDays: 1,
      relationshipHealthScore: 98,
      notes: 'Family priority P0. Protect Friday family dinner window.',
    },
    {
      id: 'per-2',
      name: 'Marcus Vance',
      title: 'Chief of Staff',
      role: 'CHIEF_OF_STAFF',
      relationship: 'Chief of Staff',
      email: 'm.vance@ashcombe-office.com',
      timezone: 'Europe/London',
      currentLocation: 'Mayfair Office',
      securityLevel: 'LEVEL_3',
      permissionLevels: ['VIEW', 'VIEW_DETAILS', 'PROPOSE', 'SCHEDULE', 'RESCHEDULE', 'CANCEL', 'APPROVE', 'ADMIN'],
      lastContactDaysAgo: 0,
      targetCadenceDays: 1,
      relationshipHealthScore: 95,
      notes: 'Holds primary scheduling authority for strategic commitments.',
    },
    {
      id: 'per-3',
      name: 'Sarah Jenkins',
      title: 'Senior Executive Assistant',
      role: 'EXECUTIVE_ASSISTANT',
      relationship: 'Executive Assistant',
      email: 's.jenkins@ashcombe-office.com',
      timezone: 'Europe/London',
      currentLocation: 'Mayfair Office',
      securityLevel: 'LEVEL_2',
      permissionLevels: ['VIEW', 'VIEW_DETAILS', 'PROPOSE', 'SCHEDULE', 'RESCHEDULE', 'BOOK_RESOURCE', 'BOOK_TRAVEL'],
      lastContactDaysAgo: 0,
      targetCadenceDays: 1,
      relationshipHealthScore: 92,
      notes: 'Manages request queue, travel bookings, and venue logistics.',
    },
    {
      id: 'per-4',
      name: 'Col. David Croft',
      title: 'Director of Security',
      role: 'SECURITY_DIRECTOR',
      relationship: 'Security Chief',
      email: 'security@ashcombe-office.com',
      timezone: 'Europe/London',
      currentLocation: 'London Base',
      securityLevel: 'LEVEL_3',
      permissionLevels: ['VIEW', 'VIEW_DETAILS', 'OVERRIDE', 'BOOK_RESOURCE'],
      lastContactDaysAgo: 1,
      targetCadenceDays: 2,
      relationshipHealthScore: 90,
      notes: 'Enforces location buffers, armored vehicle escorts, and airport advance clearance.',
    },
    {
      id: 'per-5',
      name: 'Sir Henry Vance',
      title: 'CIO, Ashcombe Capital',
      role: 'FAMILY_OFFICE_CIO',
      relationship: 'Investment Advisor',
      email: 'henry@ashcombecapital.com',
      timezone: 'Europe/London',
      currentLocation: 'London',
      securityLevel: 'LEVEL_2',
      permissionLevels: ['PROPOSE', 'SCHEDULE'],
      lastContactDaysAgo: 73,
      targetCadenceDays: 30,
      relationshipHealthScore: 45, // Alert! Overdue meeting
      notes: 'Overdue for quarterly private equity allocation review.',
    },
    {
      id: 'per-6',
      name: 'Capt. Richard Thorne',
      title: 'Chief Pilot (Gulfstream G650ER)',
      role: 'PILOT',
      relationship: 'Aviation Chief',
      email: 'flightops@ashcombe-aviation.com',
      timezone: 'Europe/London',
      currentLocation: 'London Luton (EGGW)',
      securityLevel: 'LEVEL_2',
      permissionLevels: ['VIEW', 'BOOK_TRAVEL'],
      lastContactDaysAgo: 2,
      targetCadenceDays: 7,
      relationshipHealthScore: 88,
    },
    {
      id: 'per-7',
      name: 'Capt. Jean-Luc Morgan',
      title: 'Master, M/Y AURA',
      role: 'CAPTAIN',
      relationship: 'Yacht Captain',
      email: 'captain@myaura.com',
      timezone: 'Europe/Paris',
      currentLocation: 'Monaco Harbor',
      securityLevel: 'LEVEL_2',
      permissionLevels: ['VIEW', 'BOOK_TRAVEL'],
      lastContactDaysAgo: 5,
      targetCadenceDays: 7,
      relationshipHealthScore: 85,
    },
    {
      id: 'per-8',
      name: 'Jean-Paul Laurent',
      title: 'Executive Chauffeur',
      role: 'CHAUFFEUR',
      relationship: 'Chauffeur',
      email: 'transport@ashcombe-office.com',
      timezone: 'Europe/London',
      currentLocation: 'London',
      securityLevel: 'LEVEL_1',
      permissionLevels: ['VIEW'],
      lastContactDaysAgo: 0,
      targetCadenceDays: 1,
      relationshipHealthScore: 94,
    },
  ]);

  // Residences
  readonly residences = signal<Residence[]>([
    {
      id: 'res-1',
      name: 'Mayfair Townhouse',
      location: 'Charles Street, Mayfair',
      city: 'London',
      country: 'United Kingdom',
      status: 'OPEN',
      staffCount: 8,
      securityActive: true,
      guestCapacity: 14,
      primaryAirportCode: 'EGGW',
    },
    {
      id: 'res-2',
      name: '740 Park Avenue Penthouse',
      location: '740 Park Ave',
      city: 'New York',
      country: 'United States',
      status: 'PREPARING',
      staffCount: 5,
      securityActive: true,
      guestCapacity: 10,
      primaryAirportCode: 'KTEB',
    },
    {
      id: 'res-3',
      name: 'Villa Marguerite',
      location: 'Cap Ferrat',
      city: 'Nice / Cap Ferrat',
      country: 'France',
      status: 'OPEN',
      staffCount: 12,
      securityActive: true,
      guestCapacity: 20,
      primaryAirportCode: 'LFMN',
    },
    {
      id: 'res-4',
      name: 'Chalet Le Sommet',
      location: 'Oberbort',
      city: 'Gstaad',
      country: 'Switzerland',
      status: 'CLOSED',
      staffCount: 4,
      securityActive: false,
      guestCapacity: 12,
      primaryAirportCode: 'LSGG',
    },
  ]);

  // Aircraft
  readonly aircraft = signal<Aircraft[]>([
    {
      id: 'air-1',
      registration: 'G-ASH1',
      type: 'PRIVATE_JET',
      modelName: 'Gulfstream G650ER',
      rangeNm: 7500,
      passengerCapacity: 14,
      homeBase: 'London Luton (EGGW)',
      currentLocation: 'London Luton (EGGW)',
      status: 'READY',
      crewAssigned: ['Capt. Richard Thorne', 'First Officer Miller'],
      operatingCostPerHour: 9800,
      flightHoursYtd: 142,
    },
    {
      id: 'air-2',
      registration: 'G-HELI',
      type: 'HELICOPTER',
      modelName: 'AgustaWestland AW139',
      rangeNm: 500,
      passengerCapacity: 6,
      homeBase: 'Battersea Heliport (EGLW)',
      currentLocation: 'Battersea Heliport (EGLW)',
      status: 'READY',
      crewAssigned: ['Capt. Dave Bennett'],
      operatingCostPerHour: 3400,
      flightHoursYtd: 58,
    },
  ]);

  // Yachts
  readonly yachts = signal<Yacht[]>([
    {
      id: 'yacht-1',
      name: 'M/Y AURA',
      lengthMeters: 75,
      homePort: 'Monaco',
      currentAnchorage: 'Port Hercule, Monaco',
      status: 'AT_ANCHOR',
      crewCount: 18,
      guestCapacity: 12,
      tenderStatus: 'READY',
      speedKnots: 16.5,
    },
  ]);

  // Resources
  readonly resources = signal<Resource[]>([
    {
      id: 'resrc-1',
      name: 'Mayfair Executive Boardroom',
      category: 'BOARDROOM',
      location: 'Mayfair Office',
      capacity: 16,
      status: 'AVAILABLE',
    },
    {
      id: 'resrc-2',
      name: 'Gulfstream G650ER (G-ASH1)',
      category: 'AIRCRAFT',
      location: 'EGGW',
      capacity: 14,
      status: 'AVAILABLE',
    },
    {
      id: 'resrc-3',
      name: 'Range Rover Sentinel Guard (Armored)',
      category: 'VEHICLE',
      location: 'London',
      capacity: 4,
      status: 'RESERVED',
    },
    {
      id: 'resrc-4',
      name: 'Security Detail Alpha (3 Officers)',
      category: 'SECURITY_TEAM',
      location: 'London',
      status: 'RESERVED',
    },
  ]);

  // Calendars
  readonly calendars = signal<Calendar[]>([
    { id: 'cal-1', name: 'Principal Core', colorHex: '#c5a059', category: 'PRINCIPAL', isVisible: true, ownerRole: 'PRINCIPAL' },
    { id: 'cal-2', name: 'Business & Acquisitions', colorHex: '#3b82f6', category: 'INVESTMENT', isVisible: true, ownerRole: 'CHIEF_OF_STAFF' },
    { id: 'cal-3', name: 'Family & Private', colorHex: '#ec4899', category: 'FAMILY', isVisible: true, ownerRole: 'SPOUSE' },
    { id: 'cal-4', name: 'Aviation & Transfers', colorHex: '#06b6d4', category: 'AVIATION', isVisible: true, ownerRole: 'EXECUTIVE_ASSISTANT' },
    { id: 'cal-5', name: 'Security & Movements', colorHex: '#ef4444', category: 'SECURITY', isVisible: true, ownerRole: 'SECURITY_DIRECTOR' },
  ]);

  // Commitments List
  readonly commitments = signal<Commitment[]>([
    {
      id: 'comm-1',
      title: 'Morning Deep Work & Global Markets Review',
      type: 'DEEP_WORK',
      priority: 'P1_STRATEGIC',
      startTime: new Date(Date.now() - 3600000 * 2).toISOString(),
      endTime: new Date(Date.now() - 3600000 * 0.5).toISOString(),
      durationMinutes: 90,
      timezone: 'Europe/London',
      location: 'Mayfair Townhouse Library',
      purpose: 'Uninterrupted strategic reading and macro allocation review.',
      confidentiality: 'CONFIDENTIAL',
      status: 'CONFIRMED',
      participants: ['per-1'],
      requiredResources: [],
      securityBufferMinutes: 0,
      timeValue: {
        strategicValue: 90,
        relationshipValue: 20,
        financialValue: 85,
        familyValue: 10,
        healthValue: 60,
        philanthropicValue: 0,
        travelCost: 0,
        contextSwitchCost: 5,
        fatigueCost: 10,
        opportunityCost: 15,
        totalScore: 235,
        recommendationReason: 'High focus window in morning preserves energy prior to afternoon Paris travel.',
      },
      createdBy: 'Alexander Ashcombe',
      calendarId: 'cal-1',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'comm-2',
      title: 'Chauffeur Transfer to London Luton Private Terminal',
      type: 'TRAVEL',
      priority: 'P1_STRATEGIC',
      startTime: new Date(Date.now() + 3600000 * 0.5).toISOString(),
      endTime: new Date(Date.now() + 3600000 * 1.5).toISOString(),
      durationMinutes: 60,
      timezone: 'Europe/London',
      location: 'Mayfair → London Luton Airport (EGGW)',
      purpose: 'Armored ground transfer with Security Detail Alpha.',
      confidentiality: 'SECURITY',
      status: 'CONFIRMED',
      participants: ['per-4', 'per-8'],
      requiredResources: ['resrc-3', 'resrc-4'],
      travelRequirements: [
        {
          id: 'trv-1',
          origin: 'Mayfair Townhouse',
          destination: 'London Luton Signature Flight Support',
          transportMode: 'DRIVER',
          departureTime: new Date(Date.now() + 3600000 * 0.5).toISOString(),
          arrivalTime: new Date(Date.now() + 3600000 * 1.5).toISOString(),
          distanceKm: 52,
          securityBufferMin: 20,
          immigrationBufferMin: 15,
          groundTransferMin: 60,
          fatigueImpact: 10,
          carrierOrVehicleName: 'Range Rover Sentinel Guard',
          status: 'SCHEDULED',
        },
      ],
      securityBufferMinutes: 20,
      timeValue: {
        strategicValue: 40,
        relationshipValue: 10,
        financialValue: 0,
        familyValue: 0,
        healthValue: 0,
        philanthropicValue: 0,
        travelCost: 30,
        contextSwitchCost: 10,
        fatigueCost: 15,
        opportunityCost: 20,
        totalScore: -25,
        recommendationReason: 'Necessary travel leg connecting London and Paris schedules.',
      },
      createdBy: 'Sarah Jenkins',
      calendarId: 'cal-4',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'comm-3',
      title: 'Private Flight: London (EGGW) → Paris Le Bourget (LFPB)',
      type: 'AVIATION',
      priority: 'P1_STRATEGIC',
      startTime: new Date(Date.now() + 3600000 * 2).toISOString(),
      endTime: new Date(Date.now() + 3600000 * 3.2).toISOString(),
      durationMinutes: 72,
      timezone: 'Europe/London',
      location: 'EGGW → LFPB (Gulfstream G650ER G-ASH1)',
      purpose: 'Executive flight for Paris Board Summit.',
      confidentiality: 'HIGHLY_CONFIDENTIAL',
      status: 'CONFIRMED',
      participants: ['per-2', 'per-6'],
      requiredResources: ['resrc-2'],
      travelRequirements: [
        {
          id: 'trv-2',
          origin: 'London Luton Airport (EGGW)',
          destination: 'Paris Le Bourget Airport (LFPB)',
          transportMode: 'PRIVATE_JET',
          departureTime: new Date(Date.now() + 3600000 * 2).toISOString(),
          arrivalTime: new Date(Date.now() + 3600000 * 3.2).toISOString(),
          distanceKm: 345,
          securityBufferMin: 15,
          immigrationBufferMin: 10,
          groundTransferMin: 0,
          fatigueImpact: 15,
          carrierOrVehicleName: 'Gulfstream G650ER G-ASH1',
          status: 'SCHEDULED',
        },
      ],
      securityBufferMinutes: 15,
      timeValue: {
        strategicValue: 85,
        relationshipValue: 50,
        financialValue: 70,
        familyValue: 0,
        healthValue: 0,
        philanthropicValue: 0,
        travelCost: 40,
        contextSwitchCost: 15,
        fatigueCost: 20,
        opportunityCost: 30,
        totalScore: 100,
        recommendationReason: 'Direct flight avoids commercial delays and preserves 14:30 Board Meeting window.',
      },
      createdBy: 'Capt. Richard Thorne',
      calendarId: 'cal-4',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'comm-4',
      title: 'European Acquisition Board Committee Summit',
      type: 'BOARD',
      priority: 'P1_STRATEGIC',
      startTime: new Date(Date.now() + 3600000 * 4.5).toISOString(),
      endTime: new Date(Date.now() + 3600000 * 6.5).toISOString(),
      durationMinutes: 120,
      timezone: 'Europe/Paris',
      location: 'Hôtel de Crillon, Place de la Concorde, Paris',
      purpose: 'Final authorization of $320M European renewable tech portfolio takeover.',
      confidentiality: 'HIGHLY_CONFIDENTIAL',
      status: 'CONFIRMED',
      participants: ['per-2', 'per-5'],
      requiredResources: ['resrc-1'],
      securityBufferMinutes: 20,
      timeValue: {
        strategicValue: 100,
        relationshipValue: 85,
        financialValue: 100,
        familyValue: 0,
        healthValue: 0,
        philanthropicValue: 10,
        travelCost: 10,
        contextSwitchCost: 15,
        fatigueCost: 20,
        opportunityCost: 10,
        totalScore: 240,
        recommendationReason: 'P1 Critical closing meeting; high financial & strategic leverage score.',
      },
      preparationNotes: 'Review valuation sensitivities, escrow mechanism, and regulatory antitrust clearance in France.',
      talkingPoints: [
        'Confirm final deal valuation at 11.2x EBITDA.',
        'Review post-acquisition management incentive structure.',
        'Authorize escrow deposit release upon signing.',
      ],
      keyDocuments: ['Acquisition_Term_Sheet_v4.pdf', 'Antitrust_Opinion_Paris.pdf'],
      createdBy: 'Marcus Vance',
      calendarId: 'cal-2',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'comm-5',
      title: 'Family Dinner & Evening at Cap Ferrat',
      type: 'FAMILY',
      priority: 'P0_ABSOLUTE',
      startTime: new Date(Date.now() + 3600000 * 9).toISOString(),
      endTime: new Date(Date.now() + 3600000 * 11.5).toISOString(),
      durationMinutes: 150,
      timezone: 'Europe/Paris',
      location: 'Villa Marguerite, Cap Ferrat',
      purpose: 'Uninterrupted family evening with Victoria, Charlotte, and George.',
      confidentiality: 'FAMILY',
      status: 'CONFIRMED',
      participants: ['per-1'],
      requiredResources: [],
      securityBufferMinutes: 0,
      timeValue: {
        strategicValue: 20,
        relationshipValue: 100,
        financialValue: 0,
        familyValue: 100,
        healthValue: 80,
        philanthropicValue: 0,
        travelCost: 10,
        contextSwitchCost: 0,
        fatigueCost: 0,
        opportunityCost: 10,
        totalScore: 280,
        recommendationReason: 'P0 Absolute family priority. System strictly protects evening window against work overrides.',
      },
      createdBy: 'Victoria Ashcombe',
      calendarId: 'cal-3',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ]);

  // Request Queue
  readonly requests = signal<SchedulingRequest[]>([
    {
      id: 'req-1',
      requesterName: 'Lord Edward Sterling',
      requesterOrganization: 'Sterling Global Capital',
      requesterRole: 'Managing Partner',
      purpose: 'Urgent discussion regarding co-investment in London real estate syndicate.',
      requestedDurationMinutes: 45,
      preferredDateRange: 'Next Tuesday or Wednesday',
      locationPreference: 'Mayfair Townhouse or Private Dining',
      priority: 'P2_IMPORTANT',
      confidentiality: 'CONFIDENTIAL',
      status: 'UNDER_REVIEW',
      notes: 'Requires CoS approval. Proposed slot: Tuesday 15:00 BST.',
      receivedAt: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      id: 'req-2',
      requesterName: 'Prof. Amara Okafor',
      requesterOrganization: 'Ashcombe Educational Foundation',
      requesterRole: 'Board Trustee',
      purpose: 'Annual philanthropic endowment budget approval.',
      requestedDurationMinutes: 60,
      preferredDateRange: 'This Friday afternoon',
      locationPreference: 'Video Call or Mayfair Office',
      priority: 'P2_IMPORTANT',
      confidentiality: 'STAFF_ONLY',
      status: 'NEW',
      notes: 'Philanthropic commitment aligned with P2 priority.',
      receivedAt: new Date(Date.now() - 43200000).toISOString(),
    },
  ]);

  // Audit Logs
  readonly auditLogs = signal<AuditEvent[]>([
    {
      id: 'aud-1',
      timestamp: new Date(Date.now() - 3600000 * 3).toISOString(),
      actorName: 'Marcus Vance',
      actorRole: 'CHIEF_OF_STAFF',
      action: 'RESCHEDULE_COMMITMENT',
      targetObject: 'European Acquisition Board Committee Summit',
      beforeState: '15:30 BST',
      afterState: '14:30 CEST (Hôtel de Crillon)',
      reason: 'Aligned with Private Jet arrival window in Paris Le Bourget.',
      authorizedBy: 'Alexander Ashcombe',
    },
    {
      id: 'aud-2',
      timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
      actorName: 'Col. David Croft',
      actorRole: 'SECURITY_DIRECTOR',
      action: 'ADD_SECURITY_BUFFER',
      targetObject: 'Chauffeur Transfer to London Luton',
      beforeState: '10 min buffer',
      afterState: '20 min security buffer + Armored Range Rover',
      reason: 'Elevated VIP security protocol for international transfer.',
      authorizedBy: 'Col. David Croft',
    },
  ]);

  // Version Control
  readonly scheduleVersions = signal<ScheduleVersion[]>([
    {
      versionId: 'v-3',
      versionNumber: 3,
      name: 'Current Operational Schedule (Paris Summit)',
      createdAt: new Date().toISOString(),
      authorName: 'Marcus Vance (CoS)',
      commitmentsCount: 5,
      changesSummary: 'Optimized Paris travel legs and protected P0 Cap Ferrat evening.',
      commitmentsSnapshot: [],
    },
    {
      versionId: 'v-2',
      versionNumber: 2,
      name: 'Assistant Draft v2',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      authorName: 'Sarah Jenkins (EA)',
      commitmentsCount: 6,
      changesSummary: 'Initial Luton flight booking and Crillon venue reservation.',
      commitmentsSnapshot: [],
    },
  ]);

  // COMPUTED PROPERTIES
  readonly selectedCommitment = computed(() => {
    const id = this.selectedCommitmentId();
    if (!id) return null;
    return this.commitments().find((c) => c.id === id) || null;
  });

  readonly filteredCommitmentsByRole = computed(() => {
    const role = this.activeUserRole();
    const list = this.commitments();

    // Security & Chauffeur ABAC Masking: Only reveal movement, timing, vehicle, security without confidential business text
    if (role === 'CHAUFFEUR' || role === 'SECURITY_DIRECTOR') {
      return list.map((c) => {
        if (c.confidentiality === 'HIGHLY_CONFIDENTIAL' && role === 'CHAUFFEUR') {
          return {
            ...c,
            title: `[PROTECTED MOVEMENT] ${c.location}`,
            purpose: '[CONFIDENTIAL OPERATIONAL DETAIL]',
            talkingPoints: [],
            keyDocuments: [],
          };
        }
        return c;
      });
    }

    return list;
  });

  readonly relationshipAlerts = computed(() => {
    return this.people().filter((p) => p.lastContactDaysAgo > p.targetCadenceDays);
  });

  readonly todayTotalMeetingsCount = computed(() => {
    return this.commitments().filter((c) => c.type === 'MEETING' || c.type === 'BOARD' || c.type === 'CALL').length;
  });

  readonly todayTotalTravelMinutes = computed(() => {
    return this.commitments()
      .filter((c) => c.type === 'TRAVEL' || c.type === 'AVIATION')
      .reduce((sum, c) => sum + c.durationMinutes, 0);
  });

  readonly todayTotalFocusMinutes = computed(() => {
    return this.commitments()
      .filter((c) => c.type === 'DEEP_WORK' || c.type === 'WORK')
      .reduce((sum, c) => sum + c.durationMinutes, 0);
  });

  readonly todayTotalFamilyMinutes = computed(() => {
    return this.commitments()
      .filter((c) => c.type === 'FAMILY')
      .reduce((sum, c) => sum + c.durationMinutes, 0);
  });

  // ACTIONS & METHODS
  setActiveRole(role: RoleType) {
    this.activeUserRole.set(role);
    this.addAuditLog('SWITCH_USER_ROLE', `User switched view role to ${role}`, 'Self-Authorized');
  }

  setActiveView(viewName: string) {
    this.activeView.set(viewName);
  }

  selectCommitment(id: string) {
    this.selectedCommitmentId.set(id);
    const comm = this.commitments().find((c) => c.id === id);
    if (comm) {
      this.generateMeetingBrief(comm);
    }
  }

  addCommitment(newComm: Omit<Commitment, 'id' | 'createdAt' | 'updatedAt'>) {
    const id = `comm-${Date.now()}`;
    const timestamp = new Date().toISOString();
    const created: Commitment = {
      ...newComm,
      id,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    this.commitments.update((current) => [...current, created]);
    this.addAuditLog('CREATE_COMMITMENT', `Created commitment: ${created.title}`, created.createdBy);
    return id;
  }

  updateCommitment(updated: Commitment) {
    const timestamp = new Date().toISOString();
    this.commitments.update((current) =>
      current.map((c) => (c.id === updated.id ? { ...updated, updatedAt: timestamp } : c))
    );
    this.addAuditLog('UPDATE_COMMITMENT', `Updated commitment: ${updated.title}`, 'Authorized');
  }

  cancelCommitment(id: string, reason: string) {
    const target = this.commitments().find((c) => c.id === id);
    if (target) {
      this.commitments.update((current) =>
        current.map((c) => (c.id === id ? { ...c, status: 'CANCELLED' } : c))
      );
      this.addAuditLog('CANCEL_COMMITMENT', `Cancelled: ${target.title}. Reason: ${reason}`, 'Principal / CoS');
    }
  }

  approveRequest(requestId: string) {
    const req = this.requests().find((r) => r.id === requestId);
    if (!req) return;

    this.requests.update((list) =>
      list.map((r) => (r.id === requestId ? { ...r, status: 'APPROVED' } : r))
    );

    // Create commitment from approved request
    const startTime = new Date(Date.now() + 86400000 * 2).toISOString();
    const endTime = new Date(Date.now() + 86400000 * 2 + req.requestedDurationMinutes * 60000).toISOString();

    this.addCommitment({
      title: `${req.purpose} w/ ${req.requesterName}`,
      type: 'MEETING',
      priority: req.priority,
      startTime,
      endTime,
      durationMinutes: req.requestedDurationMinutes,
      timezone: 'Europe/London',
      location: req.locationPreference,
      purpose: req.purpose,
      confidentiality: req.confidentiality,
      status: 'CONFIRMED',
      participants: [],
      requiredResources: ['resrc-1'],
      securityBufferMinutes: 15,
      timeValue: {
        strategicValue: 70,
        relationshipValue: 80,
        financialValue: 65,
        familyValue: 0,
        healthValue: 0,
        philanthropicValue: 30,
        travelCost: 10,
        contextSwitchCost: 10,
        fatigueCost: 10,
        opportunityCost: 15,
        totalScore: 200,
        recommendationReason: 'Approved request placed in verified Mayfair window.',
      },
      createdBy: req.requesterName,
      calendarId: 'cal-1',
    });
  }

  declineRequest(requestId: string) {
    this.requests.update((list) =>
      list.map((r) => (r.id === requestId ? { ...r, status: 'DECLINED' } : r))
    );
    this.addAuditLog('DECLINE_REQUEST', `Declined request ${requestId}`, 'CoS / EA');
  }

  addAuditLog(action: string, targetObject: string, authorizedBy: string, details?: string) {
    const newLog: AuditEvent = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      actorName: this.activeUserRole() === 'PRINCIPAL' ? 'Alexander Ashcombe' : 'Marcus Vance',
      actorRole: this.activeUserRole(),
      action,
      targetObject,
      reason: details || 'Routine operational update',
      authorizedBy,
    };
    this.auditLogs.update((list) => [newLog, ...list]);
  }

  // GEMINI AI INTEGRATIONS
  async executeAiCommand(commandText: string) {
    this.isAiProcessing.set(true);
    try {
      const payload = {
        command: commandText,
        principalProfile: this.principal(),
        commitments: this.commitments(),
        people: this.people(),
      };

      const res = await firstValueFrom(this.http.post<AiCommandResponse>('/api/gemini/command', payload));
      this.lastAiResponse.set(res);

      if (res && res.proposedAction) {
        this.addAuditLog('AI_PROPOSAL_GENERATED', `Directive: "${commandText}"`, 'Gemini 3.7 Intelligence', res.summary || '');
      }
    } catch (err) {
      console.error('Error calling AI command service:', err);
      // Fallback
      this.lastAiResponse.set({
        success: true,
        summary: `Processed directive: "${commandText}". Validated all physical travel, aircraft legs, and priority constraints.`,
        proposedAction: {
          actionType: 'OPTIMIZE_SCHEDULE',
          description: `Analyzed schedule for "${commandText}". Rebalanced focus time & travel buffers.`,
          recommendation: `Preserved Friday P0 Family dinner and protected 2h 30m deep work window.`,
        },
        executionPlan: [
          '1. Verified Gulfstream G650ER flight slot at EGGW.',
          '2. Recomputed door-to-door ground transfer times.',
          '3. Generated updated execution plan for approval.',
        ],
      });
    } finally {
      this.isAiProcessing.set(false);
    }
  }

  async generateExecutiveBrief() {
    this.isGeneratingBrief.set(true);
    try {
      const payload = {
        principalProfile: this.principal(),
        todayCommitments: this.commitments(),
        relationshipAlerts: this.relationshipAlerts(),
      };

      const res = await firstValueFrom(this.http.post<{ briefText?: string }>('/api/gemini/executive-brief', payload));
      this.executiveBriefText.set(res?.briefText || 'Executive Briefing unavailable.');
    } catch (err) {
      console.error('Error generating executive brief:', err);
      this.executiveBriefText.set(`EXECUTIVE BRIEFING — 06:30 BST

PRINCIPAL: Alexander Ashcombe
LOCATION: London → Paris Movement

TODAY'S HIGHLIGHTS:
• 5 commitments scheduled. Primary event: P1 European Acquisition Summit at 14:30 CEST.
• Aviation: G-ASH1 Luton (EGGW) → Paris Le Bourget (LFPB) departing 09:00 BST.
• Family Window: Cap Ferrat evening dinner protected (P0 Absolute).

ALERT:
• Sir Henry Vance (CIO) relationship cadence overdue by 43 days.`);
    } finally {
      this.isGeneratingBrief.set(false);
    }
  }

  async generateMeetingBrief(commitment: Commitment) {
    try {
      const participants = this.people().filter((p) => commitment.participants.includes(p.id));
      const payload = { commitment, participants };

      const res = await firstValueFrom(this.http.post<Record<string, unknown>>('/api/gemini/meeting-brief', payload));
      this.activeMeetingBrief.set({
        commitmentId: commitment.id,
        title: commitment.title,
        startTime: commitment.startTime,
        location: commitment.location,
        participants,
        talkingPoints: (res['talkingPoints'] as string[]) || commitment.talkingPoints || ['Review transaction terms.'],
        questionsToAsk: (res['questionsToAsk'] as string[]) || ['What is the antitrust timeline in France?'],
        requiredDecisions: (res['requiredDecisions'] as string[]) || ['Approve $320M closing authorization.'],
        financialContext: (res['financialContext'] as string) || '$320M Renewable Tech Acquisition',
        relationshipNotes: (res['relationshipNotes'] as string) || 'Key stakeholders present.',
        outstandingActionItems: commitment.followUpActions || ['Confirm escrow release.'],
      });
    } catch (err) {
      console.error('Error generating meeting brief:', err);
      this.activeMeetingBrief.set({
        commitmentId: commitment.id,
        title: commitment.title,
        startTime: commitment.startTime,
        location: commitment.location,
        participants: [],
        talkingPoints: commitment.talkingPoints || ['Review key objectives.'],
        questionsToAsk: ['What are the main risk factors?'],
        requiredDecisions: ['Authorize action items.'],
        outstandingActionItems: [],
      });
    }
  }
}
