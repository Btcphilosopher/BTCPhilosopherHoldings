import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderNavComponent } from './components/header-nav';
import { TodayDashboardComponent } from './components/today-dashboard';
import { WeeklyCommandCentreComponent } from './components/weekly-command';
import { CalendarFabricComponent } from './components/calendar-fabric';
import { GeographicMapComponent } from './components/geographic-map';
import { RelationshipEngineComponent } from './components/relationships-dir';
import { FleetAndTravelComponent } from './components/fleet-and-travel';
import { ResidencesAndResourcesComponent } from './components/residences-resources';
import { StaffControlCentreComponent } from './components/staff-requests';
import { ScheduleOptimizerComponent } from './components/schedule-optimizer';
import { SecurityAndAuditComponent } from './components/security-audit';
import { PrincipalTerminalComponent } from './components/principal-terminal';
import { CommitmentDrawerComponent } from './components/commitment-drawer';
import { ScheduleOsService } from './services/schedule-os.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderNavComponent,
    TodayDashboardComponent,
    WeeklyCommandCentreComponent,
    CalendarFabricComponent,
    GeographicMapComponent,
    RelationshipEngineComponent,
    FleetAndTravelComponent,
    ResidencesAndResourcesComponent,
    StaffControlCentreComponent,
    ScheduleOptimizerComponent,
    SecurityAndAuditComponent,
    PrincipalTerminalComponent,
    CommitmentDrawerComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  osService = inject(ScheduleOsService);
}

