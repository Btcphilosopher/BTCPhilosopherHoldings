export type RoleType =
  | 'PRINCIPAL'
  | 'SPOUSE'
  | 'CHILD'
  | 'CHIEF_OF_STAFF'
  | 'EXECUTIVE_ASSISTANT'
  | 'SECURITY_DIRECTOR'
  | 'CHAUFFEUR'
  | 'CAPTAIN'
  | 'PILOT'
  | 'FAMILY_OFFICE_CIO'
  | 'GENERAL_COUNSEL'
  | 'CFO'
  | 'ADVISER'
  | 'BOARD_MEMBER'
  | 'GUEST';

export type PermissionLevel =
  | 'VIEW'
  | 'VIEW_DETAILS'
  | 'PROPOSE'
  | 'SCHEDULE'
  | 'RESCHEDULE'
  | 'CANCEL'
  | 'CREATE'
  | 'EDIT'
  | 'INVITE'
  | 'BOOK_RESOURCE'
  | 'BOOK_TRAVEL'
  | 'APPROVE'
  | 'OVERRIDE'
  | 'ADMIN';

export type PriorityClass =
  | 'P0_ABSOLUTE'
  | 'P1_STRATEGIC'
  | 'P2_IMPORTANT'
  | 'P3_NORMAL'
  | 'P4_OPTIONAL'
  | 'P5_DEFERABLE';

export type CommitmentType =
  | 'MEETING'
  | 'CALL'
  | 'BOARD'
  | 'INVESTMENT'
  | 'FAMILY'
  | 'TRAVEL'
  | 'DINNER'
  | 'SOCIAL'
  | 'PHILANTHROPY'
  | 'WORK'
  | 'DEEP_WORK'
  | 'EXERCISE'
  | 'HEALTH'
  | 'EDUCATION'
  | 'LEISURE'
  | 'MEDIA'
  | 'PUBLIC_APPEARANCE'
  | 'PROPERTY'
  | 'YACHT'
  | 'AVIATION'
  | 'PERSONAL';

export type ConfidentialityLevel =
  | 'PUBLIC'
  | 'STAFF_ONLY'
  | 'ADVISERS'
  | 'FAMILY'
  | 'SECURITY'
  | 'CONFIDENTIAL'
  | 'HIGHLY_CONFIDENTIAL';

export type TransportMode =
  | 'WALK'
  | 'CAR'
  | 'DRIVER'
  | 'TRAIN'
  | 'COMMERCIAL_AIR'
  | 'PRIVATE_JET'
  | 'HELICOPTER'
  | 'YACHT'
  | 'TENDER';

export interface TimeValueBreakdown {
  strategicValue: number; // 0-100
  relationshipValue: number;
  financialValue: number;
  familyValue: number;
  healthValue: number;
  philanthropicValue: number;
  travelCost: number;
  contextSwitchCost: number;
  fatigueCost: number;
  opportunityCost: number;
  totalScore: number;
  recommendationReason: string;
}

export interface Person {
  id: string;
  name: string;
  title: string;
  role: RoleType;
  relationship: string;
  email: string;
  phone?: string;
  timezone: string;
  currentLocation: string;
  securityLevel: 'LEVEL_1' | 'LEVEL_2' | 'LEVEL_3' | 'VIP';
  permissionLevels: PermissionLevel[];
  lastContactDaysAgo: number;
  targetCadenceDays: number;
  relationshipHealthScore: number; // 0 - 100
  notes?: string;
  avatarUrl?: string;
}

export interface Residence {
  id: string;
  name: string;
  location: string;
  city: string;
  country: string;
  status: 'OPEN' | 'PREPARING' | 'MAINTENANCE' | 'CLOSED';
  staffCount: number;
  securityActive: boolean;
  guestCapacity: number;
  primaryAirportCode: string;
  imageSeed?: string;
}

export interface Aircraft {
  id: string;
  registration: string;
  type: 'PRIVATE_JET' | 'HELICOPTER' | 'TURBOPROP';
  modelName: string;
  rangeNm: number;
  passengerCapacity: number;
  homeBase: string;
  currentLocation: string;
  status: 'READY' | 'IN_FLIGHT' | 'MAINTENANCE' | 'STANDBY';
  crewAssigned: string[];
  operatingCostPerHour: number;
  flightHoursYtd: number;
}

export interface Yacht {
  id: string;
  name: string;
  lengthMeters: number;
  homePort: string;
  currentAnchorage: string;
  status: 'AT_ANCHOR' | 'CRUISING' | 'PORT_CALL' | 'MAINTENANCE';
  crewCount: number;
  guestCapacity: number;
  tenderStatus: 'READY' | 'DEPLOYED' | 'STOWED';
  speedKnots: number;
}

export interface Resource {
  id: string;
  name: string;
  category:
    | 'BOARDROOM'
    | 'DINING_ROOM'
    | 'AIRCRAFT'
    | 'HELICOPTER'
    | 'YACHT'
    | 'VEHICLE'
    | 'DRIVER'
    | 'PILOT'
    | 'SECURITY_TEAM'
    | 'RESIDENCE'
    | 'SUITE';
  location: string;
  capacity?: number;
  status: 'AVAILABLE' | 'RESERVED' | 'MAINTENANCE';
  assignedToCommitmentId?: string;
  notes?: string;
}

export interface TravelSegment {
  id: string;
  commitmentId?: string;
  origin: string;
  destination: string;
  transportMode: TransportMode;
  departureTime: string; // ISO
  arrivalTime: string; // ISO
  distanceKm: number;
  securityBufferMin: number;
  immigrationBufferMin: number;
  groundTransferMin: number;
  fatigueImpact: number; // 0-100
  carrierOrVehicleName?: string;
  status: 'SCHEDULED' | 'IN_TRANSIT' | 'COMPLETED' | 'DELAYED';
}

export interface Commitment {
  id: string;
  title: string;
  type: CommitmentType;
  priority: PriorityClass;
  startTime: string; // ISO String
  endTime: string; // ISO String
  durationMinutes: number;
  timezone: string;
  location: string;
  destinationCity?: string;
  purpose: string;
  confidentiality: ConfidentialityLevel;
  status: 'CONFIRMED' | 'PROPOSED' | 'TENTATIVE' | 'COMPLETED' | 'CANCELLED';
  participants: string[]; // Person IDs
  requiredResources: string[]; // Resource IDs
  travelRequirements?: TravelSegment[];
  securityBufferMinutes: number;
  timeValue: TimeValueBreakdown;
  preparationNotes?: string;
  talkingPoints?: string[];
  keyDocuments?: string[];
  followUpActions?: string[];
  dependencies?: string[]; // Other Commitment IDs
  createdBy: string;
  approvedBy?: string;
  calendarId: string;
  recurrence?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Calendar {
  id: string;
  name: string;
  colorHex: string;
  category: 'PRINCIPAL' | 'FAMILY' | 'INVESTMENT' | 'BOARD' | 'TRAVEL' | 'SECURITY' | 'RESIDENCE' | 'AVIATION' | 'YACHT';
  isVisible: boolean;
  ownerRole: RoleType;
}

export interface MeetingBrief {
  commitmentId: string;
  title: string;
  startTime: string;
  location: string;
  participants: Person[];
  talkingPoints: string[];
  questionsToAsk: string[];
  requiredDecisions: string[];
  financialContext?: string;
  relationshipNotes?: string;
  outstandingActionItems: string[];
}

export interface AiCommandResponse {
  success?: boolean;
  intent?: string;
  summary?: string;
  proposedAction?: {
    actionType?: string;
    description?: string;
    recommendation?: string;
    affectedCommitments?: string[];
  };
  executionPlan?: string[];
  tradeoffs?: string[];
}

export interface PrincipalProfile {
  id: string;
  name: string;
  title: string;
  homeCity: string;
  currentCity: string;
  preferredWakeTime: string; // e.g. "06:30"
  preferredSleepTime: string; // e.g. "23:00"
  preferredMeetingHours: { start: string; end: string };
  maxMeetingsPerDay: number;
  maxConsecutiveMeetings: number;
  minimumBreakMinutes: number;
  travelBufferMinutes: number;
  securityBufferMinutes: number;
  priorities: {
    familyWeight: number;
    investmentWeight: number;
    boardWeight: number;
    deepWorkWeight: number;
    healthWeight: number;
  };
  energyLevel: number; // 0-100%
  fatigueScore: number; // 0-100
}

export interface SchedulingRequest {
  id: string;
  requesterName: string;
  requesterOrganization: string;
  requesterRole: string;
  purpose: string;
  requestedDurationMinutes: number;
  preferredDateRange: string;
  locationPreference: string;
  priority: PriorityClass;
  confidentiality: ConfidentialityLevel;
  status: 'NEW' | 'UNDER_REVIEW' | 'OPTIONS_GENERATED' | 'PROPOSED' | 'APPROVED' | 'DECLINED' | 'WAITLISTED';
  notes?: string;
  receivedAt: string;
}

export interface ScheduleVersion {
  versionId: string;
  versionNumber: number;
  name: string;
  createdAt: string;
  authorName: string;
  commitmentsCount: number;
  changesSummary: string;
  commitmentsSnapshot: Commitment[];
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actorName: string;
  actorRole: RoleType;
  action: string;
  targetObject: string;
  beforeState?: string;
  afterState?: string;
  reason: string;
  authorizedBy: string;
}

export interface SimulationScenario {
  id: string;
  title: string;
  description: string;
  proposedChanges: string[];
  metricsDelta: {
    travelHoursDelta: number;
    deepWorkHoursDelta: number;
    familyHoursDelta: number;
    fatigueDelta: number;
    conflictsResolved: number;
    timeValueScoreDelta: number;
  };
  comparisonStatus: 'CURRENT' | 'PROPOSED' | 'OPTIMIZED';
}
