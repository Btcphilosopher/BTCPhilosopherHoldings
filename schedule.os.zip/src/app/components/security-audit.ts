import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';
import { RoleType } from '../models/schedule-os.types';

@Component({
  selector: 'app-security-audit',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Security Banner -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-serif-header font-bold text-white tracking-wide">SECURITY MASKING (ABAC/RBAC) & IMMUTABLE AUDIT LOGS</h2>
          <p class="text-xs text-slate-400 font-mono-num">FIELD-LEVEL PERMISSION MASKING • AUDIT TRAIL • PRINCIPAL CONFIDENTIALITY</p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono-num">
          <div class="px-3 py-1.5 rounded bg-emerald-950/40 border border-emerald-500/30 text-emerald-300">
            AUDIT ENCRYPTION: <strong class="text-emerald-200">ACTIVE & VERIFIED</strong>
          </div>
        </div>
      </div>

      <!-- Role Security Masking Test Drawer -->
      <div class="mayfair-card p-5 space-y-3">
        <h3 class="font-serif-header font-bold text-sm text-[#c5a059] flex items-center gap-2">
          <mat-icon>admin_panel_settings</mat-icon>
          ACTIVE ROLE VIEW TESTER: {{ osService.activeUserRole() }}
        </h3>
        <p class="text-xs text-slate-300">
          Depending on the active role, sensitive information is automatically redacted. For example, chauffeurs and external detail see 
          <code class="text-[#c5a059] bg-black/40 px-1 py-0.5 rounded">[PROTECTED MOVEMENT]</code> without exposing internal deal strategy or participant lists.
        </p>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs font-mono-num pt-2">
          @for (role of ['PRINCIPAL', 'CHIEF_OF_STAFF', 'EXECUTIVE_ASSISTANT', 'SECURITY_DIRECTOR', 'CHAUFFEUR', 'SPOUSE']; track role) {
            <button 
              (click)="setRole(role)"
              [class.bg-[#c5a059]]="osService.activeUserRole() === role"
              [class.text-slate-950]="osService.activeUserRole() === role"
              [class.font-bold]="osService.activeUserRole() === role"
              [class.bg-[#080a0e]]="osService.activeUserRole() !== role"
              [class.text-slate-300]="osService.activeUserRole() !== role"
              class="p-2 rounded border border-white/10 hover:border-[#c5a059] transition-all cursor-pointer truncate">
              {{ role }}
            </button>
          }
        </div>
      </div>

      <!-- Immutable Audit Log Stream Table -->
      <div class="space-y-4">
        <h3 class="font-serif-header font-bold text-lg text-white flex items-center gap-2">
          <mat-icon class="text-cyan-400">history_toggle_off</mat-icon>
          SYSTEM AUDIT STREAM
        </h3>

        <div class="mayfair-card overflow-hidden">
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono-num">
              <thead class="bg-[#080a0e] text-[#c5a059] uppercase border-b border-white/10">
                <tr>
                  <th class="p-3">Timestamp</th>
                  <th class="p-3">Actor & Role</th>
                  <th class="p-3">Action</th>
                  <th class="p-3">Target Object</th>
                  <th class="p-3">Reason / Details</th>
                  <th class="p-3">Authorized By</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-white/5 text-slate-300">
                @for (log of osService.auditLogs(); track log.id) {
                  <tr class="hover:bg-white/5 transition-colors">
                    <td class="p-3 text-slate-400 whitespace-nowrap">{{ formatTime(log.timestamp) }}</td>
                    <td class="p-3">
                      <span class="text-white font-bold">{{ log.actorName }}</span>
                      <span class="text-[10px] text-slate-400 block">{{ log.actorRole }}</span>
                    </td>
                    <td class="p-3 font-bold text-cyan-400">{{ log.action }}</td>
                    <td class="p-3 text-white max-w-xs truncate">{{ log.targetObject }}</td>
                    <td class="p-3 text-slate-300 max-w-sm truncate">{{ log.reason }}</td>
                    <td class="p-3 text-[#c5a059] font-bold">{{ log.authorizedBy }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class SecurityAndAuditComponent {
  osService = inject(ScheduleOsService);

  setRole(roleStr: string) {
    this.osService.setActiveRole(roleStr as RoleType);
  }

  formatTime(isoString: string): string {
    const d = new Date(isoString);
    return `${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }
}
