import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-principal-terminal',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Terminal Header -->
      <div class="mayfair-card-gold p-5 space-y-3">
        <div class="flex items-center gap-3">
          <div class="p-2.5 rounded-lg bg-[#c5a059]/20 text-[#c5a059]">
            <mat-icon class="text-2xl">psychology</mat-icon>
          </div>
          <div>
            <h2 class="text-base font-serif-header font-bold text-white tracking-wide">GEMINI 3.7 INTELLIGENCE TERMINAL</h2>
            <p class="text-xs text-slate-400 font-mono-num">NATURAL LANGUAGE DIRECTIVE PARSER • PHYSICAL REALITY ENGINE • ZERO-MUTATION PROPOSAL BUILDER</p>
          </div>
        </div>

        <!-- Quick Preset Prompts -->
        <div class="pt-2 flex flex-wrap gap-2 text-xs">
          <span class="text-slate-400 font-mono-num self-center text-[11px]">PRESETS:</span>
          @for (preset of quickPresets; track preset) {
            <button 
              (click)="onSelectPreset(preset)"
              class="px-2.5 py-1 rounded bg-[#080a0e] hover:bg-[#1a202c] border border-white/10 text-slate-200 transition-all cursor-pointer">
              "{{ preset }}"
            </button>
          }
        </div>
      </div>

      <!-- Main Interactive Command Console -->
      <div class="mayfair-card p-5 space-y-4">
        <div class="flex items-center gap-3 bg-[#080a0e] p-3 rounded-lg border border-white/10">
          <mat-icon class="text-[#c5a059]">terminal</mat-icon>
          <input 
            type="text"
            [(ngModel)]="commandText"
            (keyup.enter)="onSendDirective()"
            placeholder="Type directive for Alexander Ashcombe's schedule..."
            class="bg-transparent text-white text-sm font-mono-num flex-1 focus:outline-none">
          <button 
            (click)="onSendDirective()"
            [disabled]="osService.isAiProcessing()"
            class="px-4 py-2 rounded-lg bg-[#c5a059] hover:bg-[#d4af37] text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer">
            <mat-icon [class.animate-spin]="osService.isAiProcessing()" class="text-sm">
              {{ osService.isAiProcessing() ? 'sync' : 'send' }}
            </mat-icon>
            <span>EVALUATE</span>
          </button>
        </div>

        <!-- Console Log Output Output Stream -->
        @if (osService.lastAiResponse(); as resp) {
          <div class="p-4 rounded-xl bg-[#080a0e] border border-[#c5a059]/40 space-y-3 font-mono-num text-xs">
            <div class="flex items-center justify-between text-[#c5a059] border-b border-white/10 pb-2">
              <span class="font-bold flex items-center gap-1.5">
                <mat-icon class="text-sm">verified</mat-icon>
                AI ANALYSIS & EXECUTION PLAN
              </span>
              <span>MODEL: GEMINI 3.8 FLASH</span>
            </div>

            <p class="text-white text-sm font-sans font-medium">{{ resp.summary }}</p>

            @if (resp.proposedAction) {
              <div class="p-3 rounded bg-[#131720] border border-white/5 space-y-1">
                <p class="text-slate-300"><strong class="text-[#c5a059]">Action Type:</strong> {{ resp.proposedAction.actionType }}</p>
                <p class="text-slate-300"><strong class="text-[#c5a059]">Description:</strong> {{ resp.proposedAction.description }}</p>
                <p class="text-slate-200"><strong class="text-emerald-400">Recommendation:</strong> {{ resp.proposedAction.recommendation }}</p>
              </div>
            }

            @if (resp.executionPlan) {
              <div class="space-y-1 pt-1">
                <span class="text-slate-400 text-[10px] uppercase">Step-by-Step Validation:</span>
                <ul class="space-y-1 text-slate-300">
                  @for (step of resp.executionPlan; track step) {
                    <li class="flex items-center gap-2">
                      <mat-icon class="text-xs text-emerald-400">check_circle_outline</mat-icon>
                      <span>{{ step }}</span>
                    </li>
                  }
                </ul>
              </div>
            }

            <div class="pt-3 border-t border-white/10 flex items-center gap-3">
              <button 
                (click)="authorizeExecution()"
                class="px-4 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer">
                <mat-icon class="text-sm">check</mat-icon>
                <span>AUTHORIZE & MUTATE DATABASE</span>
              </button>
            </div>
          </div>
        }
      </div>

    </div>
  `,
})
export class PrincipalTerminalComponent {
  osService = inject(ScheduleOsService);
  commandText = '';

  readonly quickPresets = [
    'Rebuild tomorrow around the Paris acquisition summit',
    'Find me 3 hours of uninterrupted focus time Thursday',
    'Schedule a 45-minute strategic review with Sir Henry Vance',
    'Verify physical feasibility for London to Gstaad weekend trip',
  ];

  onSelectPreset(preset: string) {
    this.commandText = preset;
    this.onSendDirective();
  }

  onSendDirective() {
    if (!this.commandText.trim()) return;
    this.osService.executeAiCommand(this.commandText);
  }

  authorizeExecution() {
    const resp = this.osService.lastAiResponse();
    if (resp && resp.summary) {
      this.osService.addAuditLog('AUTHORIZE_EXECUTION', resp.summary, 'Principal Authorized');
      this.osService.lastAiResponse.set(null);
      this.commandText = '';
    }
  }
}
