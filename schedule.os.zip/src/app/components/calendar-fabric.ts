import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-calendar-fabric',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Fabric Layer Controls -->
      <div class="mayfair-card p-4 space-y-3">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
          <div>
            <h2 class="text-base font-serif-header font-bold text-white tracking-wide">CALENDAR FABRIC & MULTI-VIEW LAYERS</h2>
            <p class="text-xs text-slate-400 font-mono-num">SINGLE OBJECT AUTHORITATIVE REPRESENTATION • ZERO SYNC DRIFT</p>
          </div>

          <div class="text-xs text-[#c5a059] font-mono-num flex items-center gap-1.5">
            <mat-icon class="text-sm">verified_user</mat-icon>
            <span>5 FABRIC STREAMS ACTIVE</span>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
          @for (cal of osService.calendars(); track cal.id) {
            <button 
              type="button"
              (click)="toggleCalendarVisibility(cal.id)"
              (keydown.enter)="toggleCalendarVisibility(cal.id)"
              [class.opacity-50]="!cal.isVisible"
              class="w-full text-left p-3 rounded-lg bg-[#080a0e] border border-white/10 flex items-center justify-between cursor-pointer hover:border-[#c5a059] transition-all font-sans focus:outline-none">
              <div class="flex items-center gap-2.5">
                <span class="w-3 h-3 rounded-full" [style.background-color]="cal.colorHex"></span>
                <div>
                  <div class="text-xs font-semibold text-white">{{ cal.name }}</div>
                  <div class="text-[10px] text-slate-400 uppercase font-mono-num">{{ cal.ownerRole }}</div>
                </div>
              </div>
              
              <mat-icon class="text-sm text-slate-400">
                {{ cal.isVisible ? 'visibility' : 'visibility_off' }}
              </mat-icon>
            </button>
          }
        </div>
      </div>

      <!-- Calendar View Container -->
      <div class="mayfair-card p-5 space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-3">
            <h3 class="font-serif-header font-bold text-lg text-white">SEPTEMBER 2026</h3>
            <span class="text-xs text-slate-400 font-mono-num">LONDON / PARIS TIMEZONE</span>
          </div>

          <div class="flex items-center gap-2 text-xs">
            <button class="px-3 py-1 rounded bg-[#1c2230] text-white hover:bg-[#283144]">Month</button>
            <button class="px-3 py-1 rounded bg-[#c5a059] text-slate-950 font-bold">Week</button>
            <button class="px-3 py-1 rounded bg-[#1c2230] text-white hover:bg-[#283144]">Day</button>
          </div>
        </div>

        <!-- Month Grid Sample -->
        <div class="grid grid-cols-7 gap-px bg-white/10 rounded-lg overflow-hidden border border-white/10 text-xs">
          @for (dayName of ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN']; track dayName) {
            <div class="bg-[#131720] p-2 text-center text-[11px] font-bold text-[#c5a059] font-mono-num">
              {{ dayName }}
            </div>
          }

          @for (dayNum of monthDays; track dayNum) {
            <div 
              [class.bg-[#1c2230]]="dayNum === 10"
              [class.bg-[#0d1017]]="dayNum !== 10"
              class="min-h-[90px] p-2 flex flex-col justify-between hover:bg-[#1a212e] transition-colors relative">
              <span class="text-[11px] font-mono-num text-slate-400 font-bold">{{ dayNum }}</span>
              
              @if (dayNum === 10) {
                <div class="space-y-1 my-1">
                  <div class="p-1 rounded text-[10px] bg-[#c5a059]/20 border border-[#c5a059]/40 text-[#c5a059] font-medium truncate">
                    09:00 G650ER Flight to Paris
                  </div>
                  <div class="p-1 rounded text-[10px] bg-amber-500/20 border border-amber-500/40 text-amber-300 font-medium truncate">
                    14:30 Acquisition Summit
                  </div>
                  <div class="p-1 rounded text-[10px] bg-pink-500/20 border border-pink-500/40 text-pink-300 font-medium truncate">
                    19:30 Cap Ferrat Family Dinner
                  </div>
                </div>
              }

              @if (dayNum === 11) {
                <div class="p-1 rounded text-[10px] bg-pink-500/20 border border-pink-500/40 text-pink-300 font-medium truncate">
                  Cap Ferrat Retreat
                </div>
              }
            </div>
          }
        </div>
      </div>

    </div>
  `,
})
export class CalendarFabricComponent {
  osService = inject(ScheduleOsService);

  readonly monthDays = Array.from({ length: 30 }, (_, i) => i + 1);

  toggleCalendarVisibility(calId: string) {
    this.osService.calendars.update((cals) =>
      cals.map((c) => (c.id === calId ? { ...c, isVisible: !c.isVisible } : c))
    );
  }
}
