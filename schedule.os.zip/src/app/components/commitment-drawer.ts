import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-commitment-drawer',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (osService.selectedCommitment(); as comm) {
      <div class="mayfair-card-gold p-5 space-y-4 border-t-4 border-t-[#c5a059] bg-[#121622] relative">
        
        <!-- Header Controls -->
        <div class="flex items-start justify-between border-b border-white/10 pb-3 gap-3">
          <div class="space-y-1">
            <div class="flex items-center gap-2">
              <span [class]="getPriorityClassBadge(comm.priority)">{{ comm.priority.replace('_', ' ') }}</span>
              <span class="text-[10px] uppercase font-mono-num px-2 py-0.5 rounded bg-white/10 text-slate-300">
                {{ comm.type }}
              </span>
              <span class="text-[10px] font-mono-num text-[#c5a059] px-2 py-0.5 rounded bg-[#c5a059]/10">
                {{ comm.confidentiality }}
              </span>
            </div>

            <h3 class="text-base font-serif-header font-bold text-white">{{ comm.title }}</h3>
            <p class="text-xs text-slate-400 font-mono-num flex items-center gap-1">
              <mat-icon class="text-sm text-[#c5a059]">schedule</mat-icon>
              {{ formatTime(comm.startTime) }} – {{ formatTime(comm.endTime) }} ({{ comm.durationMinutes }} mins) • {{ comm.timezone }}
            </p>
          </div>

          <button 
            (click)="osService.selectedCommitmentId.set(null)"
            class="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white cursor-pointer">
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <!-- Location & Physical Details -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono-num">
          <div class="p-3 rounded bg-[#080a0e] border border-white/5 space-y-1">
            <span class="text-slate-400 block text-[10px]">LOCATION & SECURITY BUFFER</span>
            <span class="text-white font-bold flex items-center gap-1">
              <mat-icon class="text-sm text-[#c5a059]">place</mat-icon>
              {{ comm.location }}
            </span>
            <span class="text-amber-400 text-[10px] block">
              Security Buffer: {{ comm.securityBufferMinutes }}m • Detail Alpha Active
            </span>
          </div>

          <div class="p-3 rounded bg-[#080a0e] border border-white/5 space-y-1">
            <span class="text-slate-400 block text-[10px]">TIME VALUE SCORE BREAKDOWN</span>
            <div class="flex items-center justify-between">
              <span class="text-white font-bold">Total Score:</span>
              <span class="text-emerald-400 font-bold text-sm">+{{ comm.timeValue.totalScore }}</span>
            </div>
            <p class="text-[10px] text-slate-400 italic">{{ comm.timeValue.recommendationReason }}</p>
          </div>
        </div>

        <!-- Talking Points & Intelligence Briefing -->
        @if (osService.activeMeetingBrief(); as brief) {
          <div class="p-4 rounded-xl bg-[#080a0e] border border-[#c5a059]/30 space-y-3 text-xs">
            <div class="flex items-center justify-between text-[#c5a059] border-b border-white/10 pb-2">
              <span class="font-bold flex items-center gap-1.5 font-serif-header">
                <mat-icon class="text-sm">analytics</mat-icon>
                AI MEETING INTELLIGENCE BRIEF
              </span>
              <span class="text-slate-400 font-mono-num">PREPARED FOR PRINCIPAL</span>
            </div>

            @if (brief.talkingPoints && brief.talkingPoints.length) {
              <div class="space-y-1">
                <span class="text-slate-400 font-bold block text-[11px]">TALKING POINTS:</span>
                <ul class="list-disc list-inside space-y-1 text-slate-200">
                  @for (tp of brief.talkingPoints; track tp) {
                    <li>{{ tp }}</li>
                  }
                </ul>
              </div>
            }

            @if (brief.questionsToAsk && brief.questionsToAsk.length) {
              <div class="space-y-1">
                <span class="text-slate-400 font-bold block text-[11px]">QUESTIONS TO ASK:</span>
                <ul class="list-disc list-inside space-y-1 text-amber-200">
                  @for (q of brief.questionsToAsk; track q) {
                    <li>{{ q }}</li>
                  }
                </ul>
              </div>
            }

            @if (brief.requiredDecisions && brief.requiredDecisions.length) {
              <div class="space-y-1">
                <span class="text-slate-400 font-bold block text-[11px]">REQUIRED DECISIONS:</span>
                <ul class="list-disc list-inside space-y-1 text-emerald-300 font-semibold">
                  @for (d of brief.requiredDecisions; track d) {
                    <li>{{ d }}</li>
                  }
                </ul>
              </div>
            }
          </div>
        }

        <!-- Actions -->
        <div class="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
          <button 
            (click)="osService.generateMeetingBrief(comm)"
            class="px-3 py-1.5 rounded bg-[#1c2230] hover:bg-[#283246] text-[#c5a059] border border-[#c5a059]/30 flex items-center gap-1.5 transition-all cursor-pointer">
            <mat-icon class="text-sm">auto_awesome</mat-icon>
            <span>RE-GENERATE AI BRIEF</span>
          </button>

          <div class="flex items-center gap-2">
            <button 
              (click)="cancelCommitment(comm.id)"
              class="px-3 py-1.5 rounded bg-red-950/60 hover:bg-red-900 border border-red-500/30 text-red-300 font-semibold cursor-pointer">
              CANCEL COMMITMENT
            </button>
          </div>
        </div>

      </div>
    }
  `,
})
export class CommitmentDrawerComponent {
  osService = inject(ScheduleOsService);

  formatTime(isoString: string): string {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  }

  getPriorityClassBadge(priority: string): string {
    if (priority.includes('P0')) return 'text-[10px] font-bold px-2 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30';
    if (priority.includes('P1')) return 'text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30';
    return 'text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700';
  }

  cancelCommitment(id: string) {
    this.osService.cancelCommitment(id, 'Cancelled by Principal');
    this.osService.selectedCommitmentId.set(null);
  }
}
