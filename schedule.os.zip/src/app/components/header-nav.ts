import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';
import { RoleType } from '../models/schedule-os.types';

@Component({
  selector: 'app-header-nav',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="border-b border-white/10 bg-[#0c0e12]/95 backdrop-blur-md sticky top-0 z-50 px-4 lg:px-8 py-3">
      <div class="max-w-[1700px] mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        <!-- Brand & System Status -->
        <div class="flex items-center gap-4">
          <button 
            type="button"
            (click)="osService.setActiveView('TODAY')"
            class="flex items-center gap-2.5 text-left border-none bg-transparent cursor-pointer p-0 focus:outline-none">
            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-[#c5a059] to-[#8a6b2d] flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-[#c5a059]/20">
              <mat-icon class="text-lg">hourglass_top</mat-icon>
            </div>
            <div>
              <div class="font-serif-header font-bold text-lg text-white tracking-widest flex items-center gap-2">
                SCHEDULE<span class="text-[#c5a059]">.OS</span>
                <span class="text-[10px] uppercase font-sans tracking-widest px-2 py-0.5 rounded bg-[#c5a059]/10 text-[#c5a059] border border-[#c5a059]/30">UHNW PRIVATE</span>
              </div>
              <p class="text-[11px] text-slate-400 font-mono-num">PRINCIPAL: ALEXANDER ASHCOMBE • GMT+1 (BST)</p>
            </div>
          </button>

          <!-- Quick Live Metrics Badge -->
          <div class="hidden xl:flex items-center gap-4 pl-6 border-l border-white/10 text-xs text-slate-300">
            <div class="flex items-center gap-1.5 font-mono-num">
              <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>TIME VALUE SCORE: <strong class="text-[#c5a059]">92.4/100</strong></span>
            </div>
            <div class="flex items-center gap-1.5 font-mono-num">
              <mat-icon class="text-sm text-cyan-400">flight_takeoff</mat-icon>
              <span>G-ASH1: <strong class="text-white">LUTON → LE BOURGET</strong></span>
            </div>
            <div class="flex items-center gap-1.5 font-mono-num">
              <mat-icon class="text-sm text-amber-400">bolt</mat-icon>
              <span>ENERGY: <strong class="text-emerald-400">82% OPTIMAL</strong></span>
            </div>
          </div>
        </div>

        <!-- Top Right Controls: Role Switcher & Primary Terminal Launcher -->
        <div class="flex items-center gap-3">
          <!-- Role Switcher (Delegation & RBAC Test Mode) -->
          <div class="flex items-center gap-2 bg-[#131720] border border-white/10 rounded-lg px-2.5 py-1 text-xs">
            <mat-icon class="text-sm text-[#c5a059]">admin_panel_settings</mat-icon>
            <span class="text-slate-400 hidden sm:inline">ACTING AS:</span>
            <select 
              [value]="osService.activeUserRole()"
              (change)="onRoleChange($event)"
              class="bg-transparent text-white font-medium focus:outline-none cursor-pointer pr-1">
              <option value="PRINCIPAL" class="bg-slate-900 text-white">Alexander Ashcombe (Principal)</option>
              <option value="CHIEF_OF_STAFF" class="bg-slate-900 text-white">Marcus Vance (Chief of Staff)</option>
              <option value="EXECUTIVE_ASSISTANT" class="bg-slate-900 text-white">Sarah Jenkins (Executive Assistant)</option>
              <option value="SECURITY_DIRECTOR" class="bg-slate-900 text-white">Col. Croft (Security Chief)</option>
              <option value="CHAUFFEUR" class="bg-slate-900 text-white">Jean-Paul (Chauffeur)</option>
              <option value="SPOUSE" class="bg-slate-900 text-white">Victoria Ashcombe (Spouse)</option>
            </select>
          </div>

          <!-- Command Terminal Quick Launcher -->
          <button 
            (click)="osService.setActiveView('TERMINAL')"
            class="flex items-center gap-2 bg-gradient-to-r from-[#c5a059] to-[#9e7a36] hover:brightness-110 text-slate-950 px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md transition-all cursor-pointer">
            <mat-icon class="text-sm">terminal</mat-icon>
            <span>COMMAND BAR</span>
          </button>
        </div>
      </div>

      <!-- Navigation Tabs Bar -->
      <nav class="max-w-[1700px] mx-auto mt-3 pt-2 border-t border-white/5 flex items-center gap-1 overflow-x-auto text-xs scrollbar-none">
        @for (tab of navTabs; track tab.id) {
          <button 
            (click)="osService.setActiveView(tab.id)"
            [class.bg-[#c5a059]/20]="osService.activeView() === tab.id"
            [class.text-[#c5a059]]="osService.activeView() === tab.id"
            [class.border-[#c5a059]/40]="osService.activeView() === tab.id"
            [class.text-slate-400]="osService.activeView() !== tab.id"
            [class.hover:text-white]="osService.activeView() !== tab.id"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-transparent transition-all whitespace-nowrap cursor-pointer">
            <mat-icon class="text-base">{{ tab.icon }}</mat-icon>
            <span class="font-medium uppercase tracking-wider text-[11px]">{{ tab.label }}</span>
            @if (tab.badge) {
              <span class="ml-1 px-1.5 py-0.2 text-[10px] rounded-full bg-[#c5a059]/20 text-[#c5a059] font-bold">
                {{ tab.badge }}
              </span>
            }
          </button>
        }
      </nav>
    </header>
  `,
})
export class HeaderNavComponent {
  osService = inject(ScheduleOsService);

  readonly navTabs = [
    { id: 'TODAY', label: 'Today', icon: 'dashboard' },
    { id: 'WEEK', label: 'Week Matrix', icon: 'view_week' },
    { id: 'CALENDAR', label: 'Calendar Fabric', icon: 'calendar_month' },
    { id: 'MAP', label: 'Geographic Map', icon: 'map' },
    { id: 'PEOPLE', label: 'People & Cadence', icon: 'contacts', badge: '1 Alert' },
    { id: 'FLEET', label: 'Aviation & Fleet', icon: 'flight' },
    { id: 'RESIDENCES', label: 'Residences', icon: 'villa' },
    { id: 'STAFF', label: 'Request Queue', icon: 'inbox', badge: '2 New' },
    { id: 'OPTIMIZER', label: 'What-If Simulator', icon: 'alt_route' },
    { id: 'SECURITY', label: 'Security & Audit', icon: 'security' },
    { id: 'TERMINAL', label: 'AI Terminal', icon: 'psychology' },
  ];

  onRoleChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.osService.setActiveRole(target.value as RoleType);
  }
}
