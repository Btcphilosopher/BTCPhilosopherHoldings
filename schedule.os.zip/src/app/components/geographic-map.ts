import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-geographic-map',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Overview Banner -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-serif-header font-bold text-white tracking-wide">GEOGRAPHIC SCHEDULE & DOOR-TO-DOOR TRAVEL ENGINE</h2>
          <p class="text-xs text-slate-400 font-mono-num">PHYSICAL REALITY VALIDATION • AIRPORT ADVANCE CLEARANCE • TIMEZONE MATRICES</p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono-num">
          <div class="px-3 py-1.5 rounded bg-[#080a0e] border border-white/10 text-slate-300">
            CURRENT LOCATION: <strong class="text-white">MAYFAIR, LONDON</strong>
          </div>
          <div class="px-3 py-1.5 rounded bg-cyan-950/40 border border-cyan-500/30 text-cyan-300">
            NEXT DESTINATION: <strong class="text-cyan-200">PARIS LE BOURGET (LFPB)</strong>
          </div>
        </div>
      </div>

      <!-- Geographic Map Grid & Flight Legs -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Left 2 Cols: World Map Nodes Visualizer -->
        <div class="lg:col-span-2 mayfair-card p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-white/10 pb-3">
            <h3 class="font-serif-header font-bold text-sm text-white flex items-center gap-2">
              <mat-icon class="text-[#c5a059]">public</mat-icon>
              ACTIVE GLOBAL RESIDENCES & TRAVEL NODES
            </h3>
            <span class="text-xs text-emerald-400 font-mono-num">ALL LEGS VALIDATED (FEASIBLE)</span>
          </div>

          <!-- Stylized Globe / Region Grid Cards -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            <!-- Node 1: London -->
            <div class="p-3.5 rounded-xl bg-[#080a0e] border border-white/10 space-y-2">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span class="font-bold text-sm text-white">London (Mayfair)</span>
                </div>
                <span class="text-[10px] font-mono-num text-[#c5a059] px-2 py-0.5 rounded bg-[#c5a059]/10 border border-[#c5a059]/20">CURRENT BASE</span>
              </div>
              <p class="text-xs text-slate-400">Residence: Mayfair Townhouse • Airport: Luton (EGGW)</p>
              <div class="text-[11px] text-slate-300 font-mono-num flex items-center justify-between pt-1 border-t border-white/5">
                <span>Chauffeur Buffer: 30m</span>
                <span>Security Detail: Alpha</span>
              </div>
            </div>

            <!-- Node 2: Paris -->
            <div class="p-3.5 rounded-xl bg-[#080a0e] border border-cyan-500/30 space-y-2">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
                  <span class="font-bold text-sm text-white">Paris (Le Bourget)</span>
                </div>
                <span class="text-[10px] font-mono-num text-cyan-300 px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/20">ARRIVING 10:12 CEST</span>
              </div>
              <p class="text-xs text-slate-400">Venue: Hôtel de Crillon • Airport: Le Bourget (LFPB)</p>
              <div class="text-[11px] text-slate-300 font-mono-num flex items-center justify-between pt-1 border-t border-white/5">
                <span>Flight Leg: G650ER G-ASH1</span>
                <span>Duration: 72 mins</span>
              </div>
            </div>

            <!-- Node 3: Cap Ferrat -->
            <div class="p-3.5 rounded-xl bg-[#080a0e] border border-pink-500/30 space-y-2">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-pink-400"></span>
                  <span class="font-bold text-sm text-white">Cap Ferrat / Nice</span>
                </div>
                <span class="text-[10px] font-mono-num text-pink-300 px-2 py-0.5 rounded bg-pink-500/10 border border-pink-500/20">EVENING RETREAT</span>
              </div>
              <p class="text-xs text-slate-400">Residence: Villa Marguerite • Airport: Nice Côte d'Azur (LFMN)</p>
              <div class="text-[11px] text-slate-300 font-mono-num flex items-center justify-between pt-1 border-t border-white/5">
                <span>Helicopter Transfer: AW139</span>
                <span>Yacht: M/Y AURA</span>
              </div>
            </div>

            <!-- Node 4: New York -->
            <div class="p-3.5 rounded-xl bg-[#080a0e] border border-white/10 space-y-2 opacity-80">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                  <span class="font-bold text-sm text-white">New York (Manhattan)</span>
                </div>
                <span class="text-[10px] font-mono-num text-slate-400 px-2 py-0.5 rounded bg-white/5">NEXT WEEK</span>
              </div>
              <p class="text-xs text-slate-400">Residence: 740 Park Ave • Airport: Teterboro (KTEB)</p>
              <div class="text-[11px] text-slate-300 font-mono-num flex items-center justify-between pt-1 border-t border-white/5">
                <span>Transatlantic Leg</span>
                <span>Range: 3,450 NM</span>
              </div>
            </div>

          </div>
        </div>

        <!-- Right Col: Active Door-to-Door Breakdown -->
        <div class="mayfair-card p-5 space-y-4">
          <h3 class="font-serif-header font-bold text-sm text-white flex items-center gap-2 border-b border-white/10 pb-3">
            <mat-icon class="text-cyan-400">directions</mat-icon>
            DOOR-TO-DOOR ITINERARY BREAKDOWN
          </h3>

          <div class="space-y-3 text-xs font-mono-num">
            <!-- Segment 1 -->
            <div class="p-3 rounded bg-[#080a0e] border border-white/10 space-y-1">
              <div class="flex items-center justify-between text-[#c5a059] font-bold">
                <span>06:30 – 07:30 BST</span>
                <span>CHAUFFEUR</span>
              </div>
              <p class="text-white">Mayfair Townhouse → London Luton (EGGW)</p>
              <p class="text-slate-400 text-[10px]">Distance: 52 km • Vehicle: Armored Range Rover</p>
            </div>

            <!-- Segment 2 -->
            <div class="p-3 rounded bg-[#080a0e] border border-cyan-500/30 space-y-1">
              <div class="flex items-center justify-between text-cyan-400 font-bold">
                <span>08:00 – 09:12 BST</span>
                <span>PRIVATE JET</span>
              </div>
              <p class="text-white">Luton (EGGW) → Paris Le Bourget (LFPB)</p>
              <p class="text-slate-400 text-[10px]">Gulfstream G650ER G-ASH1 • Pilot: Capt. Thorne</p>
            </div>

            <!-- Segment 3 -->
            <div class="p-3 rounded bg-[#080a0e] border border-white/10 space-y-1">
              <div class="flex items-center justify-between text-[#c5a059] font-bold">
                <span>10:30 – 11:15 CEST</span>
                <span>PARIS CHAUFFEUR</span>
              </div>
              <p class="text-white">Le Bourget (LFPB) → Hôtel de Crillon</p>
              <p class="text-slate-400 text-[10px]">Ground escort • Security detail active</p>
            </div>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class GeographicMapComponent {
  osService = inject(ScheduleOsService);
}
