import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-residences-resources',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Residences Banner -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-serif-header font-bold text-white tracking-wide">RESIDENCES & SCHEDULABLE RESOURCES MATRIX</h2>
          <p class="text-xs text-slate-400 font-mono-num">HOUSEHOLD STAFF READINESS • PRIVATE BOARDROOMS • ARMORED VEHICLE FLEET</p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono-num">
          <div class="px-3 py-1.5 rounded bg-[#080a0e] border border-white/10 text-slate-300">
            RESIDENCES ACTIVE: <strong class="text-white">2 OPEN • 1 PREPARING</strong>
          </div>
        </div>
      </div>

      <!-- Residences Cards -->
      <div class="space-y-4">
        <h3 class="font-serif-header font-bold text-lg text-white flex items-center gap-2">
          <mat-icon class="text-[#c5a059]">villa</mat-icon>
          GLOBAL RESIDENCES
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          @for (res of osService.residences(); track res.id) {
            <div class="mayfair-card p-5 space-y-4 hover:border-[#c5a059]/50 transition-all">
              <div class="flex items-start justify-between border-b border-white/10 pb-3">
                <div>
                  <div class="flex items-center gap-2">
                    <h4 class="text-base font-bold text-white font-serif-header">{{ res.name }}</h4>
                    <span [class]="getResStatusBadge(res.status)" class="text-[10px] font-bold px-2 py-0.5 rounded font-mono-num">
                      {{ res.status }}
                    </span>
                  </div>
                  <p class="text-xs text-slate-400 mt-0.5">{{ res.location }}, {{ res.city }} ({{ res.country }})</p>
                </div>

                <div class="text-right text-xs font-mono-num">
                  <span class="text-slate-400 block text-[10px]">PRIMARY AIRPORT</span>
                  <span class="text-[#c5a059] font-bold">{{ res.primaryAirportCode }}</span>
                </div>
              </div>

              <div class="grid grid-cols-3 gap-3 text-xs font-mono-num">
                <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                  <span class="text-slate-400 block text-[10px]">STAFF ON SITE</span>
                  <span class="text-white font-bold">{{ res.staffCount }} Staff</span>
                </div>
                <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                  <span class="text-slate-400 block text-[10px]">SECURITY DETAIL</span>
                  <span [class]="res.securityActive ? 'text-emerald-400 font-bold' : 'text-slate-500'">
                    {{ res.securityActive ? 'ACTIVE' : 'INACTIVE' }}
                  </span>
                </div>
                <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                  <span class="text-slate-400 block text-[10px]">GUEST CAPACITY</span>
                  <span class="text-white font-bold">{{ res.guestCapacity }} Guests</span>
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Schedulable Resources Table -->
      <div class="space-y-4 pt-4">
        <h3 class="font-serif-header font-bold text-lg text-white flex items-center gap-2">
          <mat-icon class="text-amber-400">meeting_room</mat-icon>
          SCHEDULABLE ASSETS & BOARDROOMS
        </h3>

        <div class="mayfair-card p-4 space-y-3">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            @for (resource of osService.resources(); track resource.id) {
              <div class="p-3.5 rounded-lg bg-[#080a0e] border border-white/10 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-white">{{ resource.name }}</span>
                  <span [class]="resource.status === 'AVAILABLE' ? 'text-emerald-400 bg-emerald-500/10' : 'text-amber-400 bg-amber-500/10'" class="text-[10px] font-mono-num px-2 py-0.5 rounded font-bold">
                    {{ resource.status }}
                  </span>
                </div>
                <div class="text-[11px] text-slate-400 font-mono-num flex justify-between">
                  <span>Category: {{ resource.category }}</span>
                  <span>Location: {{ resource.location }}</span>
                </div>
              </div>
            }
          </div>
        </div>
      </div>

    </div>
  `,
})
export class ResidencesAndResourcesComponent {
  osService = inject(ScheduleOsService);

  getResStatusBadge(status: string): string {
    switch (status) {
      case 'OPEN': return 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
      case 'PREPARING': return 'bg-amber-500/20 text-amber-300 border border-amber-500/30';
      default: return 'bg-slate-800 text-slate-400 border border-slate-700';
    }
  }
}
