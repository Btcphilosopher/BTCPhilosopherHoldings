import { ChangeDetectionStrategy, Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-today-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Metrics Command Bar -->
      <div class="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-3">
        <div class="mayfair-card p-3.5 flex flex-col justify-between">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Next Movement</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-white font-mono-num">London → Paris</span>
            <mat-icon class="text-cyan-400 text-sm">flight_takeoff</mat-icon>
          </div>
          <span class="text-[10px] text-cyan-400 font-mono-num mt-1">EGGW → LFPB • 09:00 BST</span>
        </div>

        <div class="mayfair-card p-3.5 flex flex-col justify-between">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Critical P1 Event</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-white truncate">Acquisition Summit</span>
            <span class="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30">P1</span>
          </div>
          <span class="text-[10px] text-slate-400 font-mono-num mt-1">14:30 CEST • Crillon Paris</span>
        </div>

        <div class="mayfair-card p-3.5 flex flex-col justify-between">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Travel Burden</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-white font-mono-num">2h 12m</span>
            <mat-icon class="text-slate-400 text-sm">directions_car</mat-icon>
          </div>
          <span class="text-[10px] text-slate-400 font-mono-num mt-1">Chauffeur + G650ER Flight</span>
        </div>

        <div class="mayfair-card p-3.5 flex flex-col justify-between">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Meeting Time</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-white font-mono-num">3h 30m</span>
            <mat-icon class="text-slate-400 text-sm">groups</mat-icon>
          </div>
          <span class="text-[10px] text-slate-400 font-mono-num mt-1">2 Strategic • 1 Family</span>
        </div>

        <div class="mayfair-card p-3.5 flex flex-col justify-between">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Focus Protection</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-emerald-400 font-mono-num">2h 30m</span>
            <mat-icon class="text-emerald-400 text-sm">psychology</mat-icon>
          </div>
          <span class="text-[10px] text-emerald-400 font-mono-num mt-1">Morning Library Window</span>
        </div>

        <div class="mayfair-card p-3.5 flex flex-col justify-between">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Family Priority</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-pink-400 font-mono-num">2h 30m</span>
            <span class="text-[10px] px-1.5 py-0.5 rounded bg-pink-500/20 text-pink-300 font-bold border border-pink-500/30">P0</span>
          </div>
          <span class="text-[10px] text-pink-400 font-mono-num mt-1">Cap Ferrat Dinner • 19:30</span>
        </div>

        <div class="mayfair-card p-3.5 flex flex-col justify-between">
          <span class="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Energy Forecast</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-white font-mono-num">82%</span>
            <mat-icon class="text-emerald-400 text-sm">battery_charging_full</mat-icon>
          </div>
          <span class="text-[10px] text-emerald-400 font-mono-num mt-1">Optimal Fatigue Buffer</span>
        </div>

        <div class="mayfair-card p-3.5 flex flex-col justify-between border-amber-500/30 bg-amber-500/5">
          <span class="text-[11px] uppercase tracking-wider text-amber-300 font-medium">System Conflicts</span>
          <div class="mt-1 flex items-center justify-between">
            <span class="font-bold text-sm text-emerald-400 font-mono-num">0 Conflicts</span>
            <mat-icon class="text-emerald-400 text-sm">check_circle</mat-icon>
          </div>
          <span class="text-[10px] text-amber-300/80 font-mono-num mt-1">1 Cadence Alert</span>
        </div>
      </div>

      <!-- 06:30 Executive Briefing Section -->
      <div class="mayfair-card-gold p-5 relative overflow-hidden">
        <div class="absolute -right-10 -bottom-10 opacity-5 pointer-events-none">
          <mat-icon class="text-[180px]">auto_awesome</mat-icon>
        </div>

        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
          <div class="flex items-center gap-3">
            <div class="p-2 rounded-lg bg-[#c5a059]/20 text-[#c5a059]">
              <mat-icon class="text-xl">newspaper</mat-icon>
            </div>
            <div>
              <h2 class="text-base font-serif-header font-bold text-white tracking-wide">06:30 EXECUTIVE MORNING BRIEF</h2>
              <p class="text-xs text-slate-400 font-mono-num">GENERATED BY GEMINI 3.7 INTELLIGENCE • CHIEF OF STAFF ANALYSIS</p>
            </div>
          </div>

          <button 
            (click)="osService.generateExecutiveBrief()"
            [disabled]="osService.isGeneratingBrief()"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1c2230] hover:bg-[#283144] border border-white/10 text-xs text-white transition-all cursor-pointer">
            <mat-icon [class.animate-spin]="osService.isGeneratingBrief()" class="text-sm">sync</mat-icon>
            <span>RE-GENERATE BRIEF</span>
          </button>
        </div>

        <div class="mt-4 text-xs sm:text-sm text-slate-200 leading-relaxed font-sans whitespace-pre-line bg-[#080a0e]/50 p-4 rounded-lg border border-white/5 font-mono-num">
          @if (osService.isGeneratingBrief()) {
            <div class="flex items-center gap-3 py-6 justify-center text-[#c5a059]">
              <mat-icon class="animate-spin">auto_awesome</mat-icon>
              <span>Synthesizing physical realities, aviation logs, and priority constraints for Principal...</span>
            </div>
          } @else {
            {{ osService.executiveBriefText() || defaultBrief }}
          }
        </div>
      </div>

      <!-- Natural Language Quick Command Bar -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row items-center gap-3">
        <div class="flex items-center gap-2 text-[#c5a059] text-sm font-semibold whitespace-nowrap">
          <mat-icon>psychology</mat-icon>
          <span>AI COMMAND:</span>
        </div>
        <input 
          type="text" 
          [(ngModel)]="commandInput"
          (keyup.enter)="onExecuteCommand()"
          placeholder="e.g. 'Rebuild tomorrow around Paris acquisition summit' or 'Find 3 hours of focus time Thursday'..."
          class="mayfair-input flex-1 w-full text-xs sm:text-sm">
        <button 
          (click)="onExecuteCommand()"
          [disabled]="osService.isAiProcessing()"
          class="w-full md:w-auto px-4 py-2 rounded-lg bg-gradient-to-r from-[#c5a059] to-[#9e7a36] text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow cursor-pointer hover:brightness-110">
          <mat-icon class="text-sm">auto_awesome</mat-icon>
          <span>EVALUATE DIRECTIVE</span>
        </button>
      </div>

      @if (osService.lastAiResponse(); as resp) {
        <div class="mayfair-card p-4 border-l-4 border-[#c5a059] space-y-2 bg-[#171d29]">
          <div class="flex items-center justify-between text-xs">
            <span class="font-bold text-[#c5a059] flex items-center gap-1.5">
              <mat-icon class="text-sm">verified</mat-icon>
              GEMINI 3.7 PROPOSED EXECUTION PLAN
            </span>
            <span class="text-slate-400 font-mono-num">STATUS: AWAITING PRINCIPAL / COS AUTHORIZATION</span>
          </div>
          <p class="text-xs text-white">{{ resp.summary }}</p>
          
          @if (resp.proposedAction) {
            <div class="p-3 bg-[#0c0e12] rounded border border-white/10 text-xs text-slate-300 space-y-1">
              <p><strong class="text-white">Recommendation:</strong> {{ resp.proposedAction.recommendation }}</p>
            </div>
          }

          <div class="flex items-center gap-2 pt-1">
            <button 
              (click)="acceptAiProposal()"
              class="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer">
              <mat-icon class="text-sm">check</mat-icon>
              <span>AUTHORIZE & EXECUTE</span>
            </button>
            <button 
              (click)="osService.lastAiResponse.set(null)"
              class="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer">
              DISMISS
            </button>
          </div>
        </div>
      }

      <!-- Today's Physical Timeline & Commitment Map -->
      <div class="space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-[#c5a059]">timeline</mat-icon>
            <h3 class="font-serif-header text-lg font-bold text-white">TODAY'S OPERATIONAL TIMELINE</h3>
            <span class="text-xs text-slate-400 font-mono-num">(THURSDAY, 10 SEPTEMBER 2026)</span>
          </div>

          <div class="flex items-center gap-2 text-xs">
            <span class="text-slate-400">SHOW:</span>
            <span class="px-2 py-0.5 rounded bg-white/10 text-white font-medium">All Commitments</span>
          </div>
        </div>

        <div class="space-y-3">
          @for (comm of osService.filteredCommitmentsByRole(); track comm.id) {
            <button 
              type="button"
              (click)="osService.selectCommitment(comm.id)"
              (keydown.enter)="osService.selectCommitment(comm.id)"
              [class.mayfair-card-gold]="osService.selectedCommitmentId() === comm.id"
              [class.mayfair-card]="osService.selectedCommitmentId() !== comm.id"
              class="w-full text-left p-4 transition-all hover:border-[#c5a059]/50 cursor-pointer relative group block border-none font-sans focus:outline-none">
              
              <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                
                <!-- Left: Time & Location Indicator -->
                <div class="flex items-start gap-3 min-w-[240px]">
                  <div class="p-2.5 rounded-lg bg-[#080a0e] border border-white/10 text-center min-w-[80px]">
                    <div class="text-xs font-mono-num font-bold text-[#c5a059]">
                      {{ formatTime(comm.startTime) }}
                    </div>
                    <div class="text-[10px] text-slate-400 font-mono-num">
                      {{ comm.durationMinutes }}m
                    </div>
                  </div>

                  <div>
                    <div class="flex items-center gap-2">
                      <span [class]="getPriorityClassBadge(comm.priority)">
                        {{ comm.priority.replace('_', ' ') }}
                      </span>
                      <span class="text-[10px] uppercase font-mono-num text-slate-400 px-1.5 py-0.5 rounded bg-white/5 border border-white/10">
                        {{ comm.type }}
                      </span>
                    </div>

                    <h4 class="text-sm font-semibold text-white mt-1 group-hover:text-[#c5a059] transition-colors">
                      {{ comm.title }}
                    </h4>
                    
                    <div class="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
                      <mat-icon class="text-sm text-[#c5a059]">place</mat-icon>
                      <span>{{ comm.location }}</span>
                    </div>
                  </div>
                </div>

                <!-- Middle: Purpose & Details -->
                <div class="flex-1 text-xs text-slate-300 space-y-1">
                  <p class="line-clamp-2 text-slate-300">{{ comm.purpose }}</p>
                  
                  <!-- Travel Requirement preview if applicable -->
                  @if (comm.travelRequirements && comm.travelRequirements.length) {
                    <div class="mt-2 p-2 rounded bg-cyan-950/30 border border-cyan-500/20 text-cyan-200 flex items-center justify-between text-[11px] font-mono-num">
                      <div class="flex items-center gap-2">
                        <mat-icon class="text-sm text-cyan-400">directions_transit</mat-icon>
                        <span>{{ comm.travelRequirements[0].origin }} → {{ comm.travelRequirements[0].destination }}</span>
                      </div>
                      <span class="text-cyan-300 font-bold">{{ comm.travelRequirements[0].carrierOrVehicleName }}</span>
                    </div>
                  }
                </div>

                <!-- Right: Time Value Score & Action Controls -->
                <div class="flex items-center gap-4 justify-between lg:justify-end border-t lg:border-t-0 border-white/5 pt-2 lg:pt-0">
                  <div class="text-right">
                    <span class="text-[10px] uppercase text-slate-400 block font-mono-num">Time Value</span>
                    <span [class]="comm.timeValue.totalScore >= 100 ? 'text-emerald-400' : 'text-amber-400'" class="font-bold text-base font-mono-num">
                      {{ comm.timeValue.totalScore > 0 ? '+' : '' }}{{ comm.timeValue.totalScore }}
                    </span>
                  </div>

                  <button 
                    (click)="osService.selectCommitment(comm.id)"
                    class="px-3 py-1.5 rounded-lg bg-[#1c2230] hover:bg-[#293246] border border-white/10 text-xs text-white flex items-center gap-1.5 transition-all cursor-pointer">
                    <mat-icon class="text-sm text-[#c5a059]">visibility</mat-icon>
                    <span>INSPECT BRIEF</span>
                  </button>
                </div>

              </div>
            </button>
          }
        </div>
      </div>

    </div>
  `,
})
export class TodayDashboardComponent implements OnInit {
  osService = inject(ScheduleOsService);
  commandInput = '';

  readonly defaultBrief = `EXECUTIVE MORNING BRIEFING — 06:30 BST

PRINCIPAL: Alexander Ashcombe
LOCATION: London → Paris Operational Movement

TODAY'S HIGHLIGHTS:
• 5 commitments scheduled. Primary event: P1 European Acquisition Summit at 14:30 CEST.
• Aviation: G-ASH1 Luton (EGGW) → Paris Le Bourget (LFPB) departing 09:00 BST.
• Family Window: Cap Ferrat evening dinner protected (P0 Absolute).

OPERATIONAL ALERTS:
• Chauffeur buffer is 30 mins; security detail team Alpha active.
• Relationship Alert: Sir Henry Vance (CIO) last met 73 days ago.
• Energy score forecast: 82% optimal with 2h 30m protected focus time.`;

  ngOnInit() {
    if (!this.osService.executiveBriefText()) {
      this.osService.executiveBriefText.set(this.defaultBrief);
    }
  }

  formatTime(isoString: string): string {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  }

  getPriorityClassBadge(priority: string): string {
    switch (priority) {
      case 'P0_ABSOLUTE':
        return 'text-[10px] font-bold px-2 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30';
      case 'P1_STRATEGIC':
        return 'text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30';
      case 'P2_IMPORTANT':
        return 'text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30';
      default:
        return 'text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700';
    }
  }

  onExecuteCommand() {
    if (!this.commandInput.trim()) return;
    this.osService.executeAiCommand(this.commandInput);
    this.commandInput = '';
  }

  acceptAiProposal() {
    const resp = this.osService.lastAiResponse();
    if (resp && resp.summary) {
      this.osService.addAuditLog('EXECUTE_AI_PROPOSAL', resp.summary, 'Principal Authorized');
      this.osService.lastAiResponse.set(null);
    }
  }
}
