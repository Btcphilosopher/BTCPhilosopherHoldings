import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-fleet-and-travel',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Top Fleet Header -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-serif-header font-bold text-white tracking-wide">PRIVATE AVIATION & MARITIME FLEET MANAGEMENT</h2>
          <p class="text-xs text-slate-400 font-mono-num">AIRCRAFT DISPATCH • YACHT ANCHORAGES • FLIGHT OPERATIONS & CREW STATUS</p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono-num">
          <div class="px-3 py-1.5 rounded bg-emerald-950/40 border border-emerald-500/30 text-emerald-300">
            FLEET STATUS: <strong class="text-emerald-200">100% OPERATIONAL</strong>
          </div>
        </div>
      </div>

      <!-- Aircraft Section -->
      <div class="space-y-4">
        <h3 class="font-serif-header font-bold text-lg text-white flex items-center gap-2">
          <mat-icon class="text-cyan-400">flight_takeoff</mat-icon>
          PRIVATE AVIATION FLEET
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          @for (plane of osService.aircraft(); track plane.id) {
            <div class="mayfair-card p-5 space-y-4 hover:border-cyan-500/40 transition-all">
              <div class="flex items-start justify-between border-b border-white/10 pb-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-lg font-bold text-white font-mono-num">{{ plane.registration }}</span>
                    <span class="text-xs font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono-num">
                      {{ plane.status }}
                    </span>
                  </div>
                  <h4 class="text-xs font-semibold text-[#c5a059] mt-0.5">{{ plane.modelName }}</h4>
                </div>

                <div class="text-right text-xs font-mono-num">
                  <span class="text-slate-400 block text-[10px]">RANGE</span>
                  <span class="text-white font-bold">{{ plane.rangeNm }} NM</span>
                </div>
              </div>

              <div class="grid grid-cols-2 gap-3 text-xs font-mono-num">
                <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                  <span class="text-slate-400 block text-[10px]">HOME BASE</span>
                  <span class="text-white font-bold truncate block">{{ plane.homeBase }}</span>
                </div>
                <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                  <span class="text-slate-400 block text-[10px]">CURRENT LOCATION</span>
                  <span class="text-cyan-400 font-bold truncate block">{{ plane.currentLocation }}</span>
                </div>
                <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                  <span class="text-slate-400 block text-[10px]">OP COST / HOUR</span>
                  <span class="text-white font-bold">\${{ plane.operatingCostPerHour.toLocaleString() }}</span>
                </div>
                <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                  <span class="text-slate-400 block text-[10px]">YTD FLIGHT HOURS</span>
                  <span class="text-white font-bold">{{ plane.flightHoursYtd }} hrs</span>
                </div>
              </div>

              <div class="text-xs text-slate-300 pt-1">
                <span class="text-[10px] uppercase text-slate-400 block font-mono-num">Assigned Crew:</span>
                <p class="font-mono-num text-[#c5a059]">{{ plane.crewAssigned.join(' • ') }}</p>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Yacht Section -->
      <div class="space-y-4 pt-4">
        <h3 class="font-serif-header font-bold text-lg text-white flex items-center gap-2">
          <mat-icon class="text-blue-400">directions_boat</mat-icon>
          MARITIME FLEET & SUPERYACHT DISPATCH
        </h3>

        @for (yacht of osService.yachts(); track yacht.id) {
          <div class="mayfair-card p-5 space-y-4 hover:border-blue-500/40 transition-all">
            <div class="flex items-start justify-between border-b border-white/10 pb-3">
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-lg font-bold text-white font-serif-header">{{ yacht.name }}</span>
                  <span class="text-xs font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 font-mono-num">
                    {{ yacht.status }}
                  </span>
                </div>
                <p class="text-xs text-slate-400 mt-0.5">{{ yacht.lengthMeters }}m Superyacht • {{ yacht.homePort }} Home Port</p>
              </div>

              <div class="text-right text-xs font-mono-num">
                <span class="text-slate-400 block text-[10px]">SPEED</span>
                <span class="text-white font-bold">{{ yacht.speedKnots }} Knots</span>
              </div>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono-num">
              <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                <span class="text-slate-400 block text-[10px]">ANCHORAGE</span>
                <span class="text-cyan-400 font-bold truncate block">{{ yacht.currentAnchorage }}</span>
              </div>
              <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                <span class="text-slate-400 block text-[10px]">CREW COUNT</span>
                <span class="text-white font-bold">{{ yacht.crewCount }} Staff</span>
              </div>
              <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                <span class="text-slate-400 block text-[10px]">GUEST CAPACITY</span>
                <span class="text-white font-bold">{{ yacht.guestCapacity }} VIPs</span>
              </div>
              <div class="p-2.5 rounded bg-[#080a0e] border border-white/5">
                <span class="text-slate-400 block text-[10px]">TENDER STATUS</span>
                <span class="text-emerald-400 font-bold">{{ yacht.tenderStatus }}</span>
              </div>
            </div>
          </div>
        }
      </div>

    </div>
  `,
})
export class FleetAndTravelComponent {
  osService = inject(ScheduleOsService);
}
