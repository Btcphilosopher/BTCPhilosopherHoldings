import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-relationships-dir',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Relationship Cadence Header Banner -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-serif-header font-bold text-white tracking-wide">RELATIONSHIP HEALTH & CADENCE ENGINE</h2>
          <p class="text-xs text-slate-400 font-mono-num">KEY PERSON CADENCE MONITORING • DELEGATION & PERMISSIONS DIRECTORY</p>
        </div>

        <div class="flex items-center gap-3">
          <div class="px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono-num flex items-center gap-1.5">
            <mat-icon class="text-sm">warning</mat-icon>
            <span>1 RELATIONSHIP CADENCE OVERDUE</span>
          </div>
        </div>
      </div>

      <!-- Cadence Alert Drawer if Overdue -->
      @if (osService.relationshipAlerts().length) {
        <div class="mayfair-card-gold p-4 border-l-4 border-amber-500 space-y-3 bg-[#181a20]">
          <div class="flex items-center justify-between text-xs">
            <span class="font-bold text-amber-400 flex items-center gap-1.5">
              <mat-icon class="text-sm">notification_important</mat-icon>
              OVERDUE CONTACT ALERT: SIR HENRY VANCE (FAMILY OFFICE CIO)
            </span>
            <span class="text-slate-400 font-mono-num">LAST CONTACT: 73 DAYS AGO (TARGET: 30 DAYS)</span>
          </div>
          <p class="text-xs text-slate-200">
            Sir Henry Vance is overdue for the quarterly private equity portfolio allocation review. 
            Gemini recommends scheduling a 45-minute strategic review during next Tuesday's Mayfair focus window.
          </p>

          <div class="flex items-center gap-2 pt-1">
            <button 
              (click)="scheduleOverdueContact('per-5')"
              class="px-3 py-1.5 rounded bg-[#c5a059] hover:bg-[#d4af37] text-slate-950 font-bold text-xs flex items-center gap-1 cursor-pointer">
              <mat-icon class="text-sm">event_available</mat-icon>
              <span>SCHEDULE REVIEW MEETING</span>
            </button>
          </div>
        </div>
      }

      <!-- People Directory Grid -->
      <div class="space-y-4">
        <h3 class="font-serif-header font-bold text-lg text-white flex items-center gap-2">
          <mat-icon class="text-[#c5a059]">people</mat-icon>
          AUTHORIZED PEOPLE & DELEGATED PERMISSIONS
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          @for (person of osService.people(); track person.id) {
            <div class="mayfair-card p-4 space-y-3 hover:border-[#c5a059]/50 transition-all">
              
              <div class="flex items-start justify-between gap-3">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-full bg-[#1c2230] border border-[#c5a059]/30 flex items-center justify-center font-bold text-sm text-[#c5a059] font-serif-header">
                    {{ person.name.charAt(0) }}
                  </div>
                  <div>
                    <h4 class="font-bold text-sm text-white">{{ person.name }}</h4>
                    <p class="text-xs text-[#c5a059]">{{ person.title }}</p>
                    <p class="text-[10px] text-slate-400 font-mono-num">{{ person.relationship }}</p>
                  </div>
                </div>

                <span [class]="getSecurityBadge(person.securityLevel)" class="text-[10px] font-mono-num font-bold px-2 py-0.5 rounded">
                  {{ person.securityLevel }}
                </span>
              </div>

              <div class="p-2.5 rounded bg-[#080a0e] border border-white/5 space-y-1 text-xs">
                <div class="flex justify-between text-[11px] font-mono-num text-slate-400">
                  <span>Location: {{ person.currentLocation }}</span>
                  <span>TZ: {{ person.timezone.split('/')[1] }}</span>
                </div>
                <div class="flex justify-between text-[11px] font-mono-num">
                  <span class="text-slate-400">Relationship Score:</span>
                  <span [class]="person.relationshipHealthScore >= 80 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'">
                    {{ person.relationshipHealthScore }}/100
                  </span>
                </div>
              </div>

              <!-- Permissions Badges -->
              <div class="space-y-1">
                <span class="text-[10px] uppercase text-slate-400 block font-mono-num">Permissions:</span>
                <div class="flex flex-wrap gap-1">
                  @for (perm of person.permissionLevels; track perm) {
                    <span class="text-[9px] font-mono-num px-1.5 py-0.5 rounded bg-white/5 text-slate-300 border border-white/10">
                      {{ perm }}
                    </span>
                  }
                </div>
              </div>

              @if (person.notes) {
                <p class="text-[11px] text-slate-400 italic pt-1 border-t border-white/5">
                  "{{ person.notes }}"
                </p>
              }

            </div>
          }
        </div>
      </div>

    </div>
  `,
})
export class RelationshipEngineComponent {
  osService = inject(ScheduleOsService);

  getSecurityBadge(level: string): string {
    switch (level) {
      case 'VIP': return 'bg-pink-500/20 text-pink-300 border border-pink-500/30';
      case 'LEVEL_3': return 'bg-amber-500/20 text-amber-300 border border-amber-500/30';
      default: return 'bg-slate-800 text-slate-300 border border-slate-700';
    }
  }

  scheduleOverdueContact(personId: string) {
    const person = this.osService.people().find(p => p.id === personId);
    const name = person ? person.name : 'Sir Henry Vance';
    this.osService.executeAiCommand(`Schedule a 45-minute strategic review with ${name}`);
  }
}
