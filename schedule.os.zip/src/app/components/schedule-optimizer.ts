import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-schedule-optimizer',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Optimizer Banner -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-serif-header font-bold text-white tracking-wide">CONSTRAINT SOLVER & "WHAT-IF" SIMULATOR</h2>
          <p class="text-xs text-slate-400 font-mono-num">TRADE-OFF ENGINE • FATIGUE MINIMIZATION • STRATEGIC VALUE OPTIMIZATION</p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono-num">
          <div class="px-3 py-1.5 rounded bg-emerald-950/40 border border-emerald-500/30 text-emerald-300">
            CONSTRAINT ENGINE: <strong class="text-emerald-200">0 VIOLATIONS DETECTED</strong>
          </div>
        </div>
      </div>

      <!-- Simulator Controls & Preset Scenarios -->
      <div class="mayfair-card-gold p-5 space-y-4">
        <h3 class="font-serif-header font-bold text-sm text-[#c5a059] flex items-center gap-2">
          <mat-icon>alt_route</mat-icon>
          SIMULATED SCENARIO COMPARISON
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (scen of scenarios; track scen.id) {
            <button 
              type="button"
              (click)="selectedScenario.set(scen.id)"
              (keydown.enter)="selectedScenario.set(scen.id)"
              [class.mayfair-card-gold]="selectedScenario() === scen.id"
              [class.mayfair-card]="selectedScenario() !== scen.id"
              class="w-full text-left p-4 space-y-3 cursor-pointer hover:border-[#c5a059] transition-all block border-none font-sans focus:outline-none">
              
              <div class="flex items-center justify-between">
                <span class="font-bold text-sm text-white">{{ scen.title }}</span>
                <span [class]="scen.status === 'OPTIMIZED' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-300'" class="text-[10px] font-mono-num px-2 py-0.5 rounded font-bold">
                  {{ scen.status }}
                </span>
              </div>

              <p class="text-xs text-slate-300">{{ scen.description }}</p>

              <div class="grid grid-cols-2 gap-2 text-xs font-mono-num pt-2 border-t border-white/5">
                <div class="text-slate-400">
                  Travel Delta: <span class="text-cyan-400 font-bold">{{ scen.metricsDelta.travelHoursDelta }}h</span>
                </div>
                <div class="text-slate-400">
                  Focus Delta: <span class="text-emerald-400 font-bold">+{{ scen.metricsDelta.deepWorkHoursDelta }}h</span>
                </div>
                <div class="text-slate-400">
                  Family Protection: <span class="text-pink-400 font-bold">+{{ scen.metricsDelta.familyHoursDelta }}h</span>
                </div>
                <div class="text-slate-400">
                  Fatigue Impact: <span class="text-emerald-400 font-bold">{{ scen.metricsDelta.fatigueDelta }}%</span>
                </div>
              </div>
            </button>
          }
        </div>

        <div class="pt-2 flex justify-end">
          <button 
            (click)="applyScenario()"
            class="px-4 py-2 rounded-lg bg-gradient-to-r from-[#c5a059] to-[#9e7a36] text-slate-950 font-bold text-xs flex items-center gap-2 cursor-pointer hover:brightness-110">
            <mat-icon class="text-sm">check_circle</mat-icon>
            <span>APPLY OPTIMIZED SCHEDULE SCENARIO</span>
          </button>
        </div>
      </div>

    </div>
  `,
})
export class ScheduleOptimizerComponent {
  osService = inject(ScheduleOsService);
  selectedScenario = signal<string>('scen-1');

  readonly scenarios = [
    {
      id: 'scen-1',
      title: 'Paris Acquisition Focus (Optimized)',
      description: 'Shifts return leg to Friday morning to guarantee uninterrupted Thursday dinner at Cap Ferrat.',
      status: 'OPTIMIZED',
      metricsDelta: {
        travelHoursDelta: -1.5,
        deepWorkHoursDelta: 2.0,
        familyHoursDelta: 2.5,
        fatigueDelta: -12,
        conflictsResolved: 1,
        timeValueScoreDelta: +45,
      },
    },
    {
      id: 'scen-2',
      title: 'Cap Ferrat Summer Retreat Extension',
      description: 'Consolidates all London board calls into virtual Mayfair stream from Villa Marguerite.',
      status: 'PROPOSED',
      metricsDelta: {
        travelHoursDelta: -4.0,
        deepWorkHoursDelta: 3.5,
        familyHoursDelta: 6.0,
        fatigueDelta: -25,
        conflictsResolved: 2,
        timeValueScoreDelta: +60,
      },
    },
    {
      id: 'scen-3',
      title: 'New York Transatlantic Syndicate Trip',
      description: 'G650ER non-stop flight to Teterboro (KTEB) with 14h mandatory rest before board meeting.',
      status: 'PROPOSED',
      metricsDelta: {
        travelHoursDelta: +7.5,
        deepWorkHoursDelta: -1.0,
        familyHoursDelta: -3.0,
        fatigueDelta: +18,
        conflictsResolved: 0,
        timeValueScoreDelta: +80,
      },
    },
  ];

  applyScenario() {
    this.osService.addAuditLog('APPLY_SIMULATED_SCENARIO', 'Applied Paris Acquisition Focus (Optimized)', 'Principal Authorized');
  }
}
