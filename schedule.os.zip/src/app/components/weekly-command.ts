import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';
import { Commitment } from '../models/schedule-os.types';

@Component({
  selector: 'app-weekly-command',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Weekly High-Level Time Allocation Report -->
      <div class="mayfair-card p-4 space-y-3">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 class="text-base font-serif-header font-bold text-white tracking-wide">WEEKLY COMMAND MATRIX & TIME REPORT</h2>
            <p class="text-xs text-slate-400 font-mono-num">7-DAY ALLOCATION • 07 SEP – 13 SEP 2026</p>
          </div>

          <div class="flex items-center gap-2 text-xs">
            <span class="text-slate-400">OVERLAYS:</span>
            <button 
              (click)="toggleOverlay('travel')"
              [class.bg-cyan-500/20]="showTravelOverlay()"
              [class.text-cyan-300]="showTravelOverlay()"
              class="px-2.5 py-1 rounded border border-white/10 text-slate-300 cursor-pointer">
              Travel & Aviation
            </button>
            <button 
              (click)="toggleOverlay('family')"
              [class.bg-pink-500/20]="showFamilyOverlay()"
              [class.text-pink-300]="showFamilyOverlay()"
              class="px-2.5 py-1 rounded border border-white/10 text-slate-300 cursor-pointer">
              Family (P0)
            </button>
            <button 
              (click)="toggleOverlay('focus')"
              [class.bg-emerald-500/20]="showFocusOverlay()"
              [class.text-emerald-300]="showFocusOverlay()"
              class="px-2.5 py-1 rounded border border-white/10 text-slate-300 cursor-pointer">
              Deep Work
            </button>
          </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-xs pt-2 border-t border-white/5 font-mono-num">
          <div class="bg-[#080a0e] p-2.5 rounded border border-white/5">
            <span class="text-slate-400 block text-[10px]">MEETING HOURS</span>
            <span class="text-white font-bold text-sm">23h 40m</span>
          </div>
          <div class="bg-[#080a0e] p-2.5 rounded border border-white/5">
            <span class="text-slate-400 block text-[10px]">TRAVEL & AVIATION</span>
            <span class="text-cyan-400 font-bold text-sm">9h 20m</span>
          </div>
          <div class="bg-[#080a0e] p-2.5 rounded border border-white/5">
            <span class="text-slate-400 block text-[10px]">DEEP FOCUS</span>
            <span class="text-emerald-400 font-bold text-sm">8h 10m</span>
          </div>
          <div class="bg-[#080a0e] p-2.5 rounded border border-white/5">
            <span class="text-slate-400 block text-[10px]">FAMILY TIME</span>
            <span class="text-pink-400 font-bold text-sm">12h 30m</span>
          </div>
          <div class="bg-[#080a0e] p-2.5 rounded border border-white/5">
            <span class="text-slate-400 block text-[10px]">LEISURE / HEALTH</span>
            <span class="text-amber-400 font-bold text-sm">7h 40m</span>
          </div>
          <div class="bg-[#080a0e] p-2.5 rounded border border-white/5">
            <span class="text-slate-400 block text-[10px]">CONTEXT SWITCHES</span>
            <span class="text-slate-300 font-bold text-sm">14 Switches</span>
          </div>
          <div class="bg-[#080a0e] p-2.5 rounded border border-white/5">
            <span class="text-slate-400 block text-[10px]">CITIES VISITED</span>
            <span class="text-[#c5a059] font-bold text-sm">LON • PAR • NCE</span>
          </div>
        </div>
      </div>

      <!-- 7-Day Grid View -->
      <div class="mayfair-card p-4 overflow-x-auto">
        <div class="min-w-[1000px]">
          
          <!-- Days Header -->
          <div class="grid grid-cols-7 gap-2 mb-3 pb-3 border-b border-white/10 text-center text-xs font-mono-num font-bold text-[#c5a059]">
            @for (day of weekDays; track day.dateStr) {
              <div [class.bg-[#c5a059]/10]="day.isToday" class="p-2 rounded border border-white/5">
                <div>{{ day.dayName }}</div>
                <div class="text-white text-sm mt-0.5">{{ day.dateNumber }} SEP</div>
                <div class="text-[10px] text-slate-400 font-normal mt-0.5">{{ day.city }}</div>
              </div>
            }
          </div>

          <!-- Timeline Slots Grid -->
          <div class="grid grid-cols-7 gap-2 min-h-[500px]">
            @for (day of weekDays; track day.dateStr) {
              <div class="bg-[#080a0e]/60 rounded border border-white/5 p-2 space-y-2 text-xs">
                
                @for (comm of getCommitmentsForDay(day.dayIndex); track comm.id) {
                  <button 
                    type="button"
                    (click)="osService.selectCommitment(comm.id)"
                    (keydown.enter)="osService.selectCommitment(comm.id)"
                    [class.border-[#c5a059]]="osService.selectedCommitmentId() === comm.id"
                    [class.border-pink-500/40]="comm.type === 'FAMILY'"
                    [class.border-cyan-500/40]="comm.type === 'TRAVEL' || comm.type === 'AVIATION'"
                    [class.border-emerald-500/40]="comm.type === 'DEEP_WORK'"
                    class="w-full text-left p-2.5 rounded bg-[#131720] border border-white/10 hover:border-[#c5a059] transition-all cursor-pointer space-y-1 block border-none font-sans focus:outline-none">
                    
                    <div class="flex items-center justify-between text-[10px] font-mono-num text-slate-400">
                      <span>{{ formatTime(comm.startTime) }}</span>
                      <span [class]="getPriorityBadgeClass(comm.priority)">{{ comm.priority.split('_')[0] }}</span>
                    </div>

                    <div class="font-semibold text-white truncate text-[11px]">
                      {{ comm.title }}
                    </div>

                    <div class="text-[10px] text-slate-400 flex items-center gap-1 truncate">
                      <mat-icon class="text-[12px]">place</mat-icon>
                      <span class="truncate">{{ comm.location }}</span>
                    </div>
                  </button>
                }

                @if (!getCommitmentsForDay(day.dayIndex).length) {
                  <div class="h-24 flex items-center justify-center text-[11px] text-slate-600 border border-dashed border-white/5 rounded">
                    Unallocated Slot
                  </div>
                }

              </div>
            }
          </div>

        </div>
      </div>

    </div>
  `,
})
export class WeeklyCommandCentreComponent {
  osService = inject(ScheduleOsService);

  showTravelOverlay = signal<boolean>(true);
  showFamilyOverlay = signal<boolean>(true);
  showFocusOverlay = signal<boolean>(true);

  readonly weekDays = [
    { dayName: 'MON', dateNumber: '07', dateStr: '2026-09-07', city: 'London', isToday: false, dayIndex: 1 },
    { dayName: 'TUE', dateNumber: '08', dateStr: '2026-09-08', city: 'London', isToday: false, dayIndex: 2 },
    { dayName: 'WED', dateNumber: '09', dateStr: '2026-09-09', city: 'London', isToday: false, dayIndex: 3 },
    { dayName: 'THU', dateNumber: '10', dateStr: '2026-09-10', city: 'London → Paris', isToday: true, dayIndex: 4 },
    { dayName: 'FRI', dateNumber: '11', dateStr: '2026-09-11', city: 'Cap Ferrat', isToday: false, dayIndex: 5 },
    { dayName: 'SAT', dateNumber: '12', dateStr: '2026-09-12', city: 'Cap Ferrat / Yacht', isToday: false, dayIndex: 6 },
    { dayName: 'SUN', dateNumber: '13', dateStr: '2026-09-13', city: 'Cap Ferrat → London', isToday: false, dayIndex: 0 },
  ];

  toggleOverlay(type: string) {
    if (type === 'travel') this.showTravelOverlay.update((v) => !v);
    if (type === 'family') this.showFamilyOverlay.update((v) => !v);
    if (type === 'focus') this.showFocusOverlay.update((v) => !v);
  }

  getCommitmentsForDay(dayIndex: number): Commitment[] {
    const all = this.osService.commitments();
    if (dayIndex === 4) {
      return all; // Today's commitments
    }
    return [];
  }

  formatTime(isoString: string): string {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  }

  getPriorityBadgeClass(priority: string): string {
    if (priority.includes('P0')) return 'text-pink-400 font-bold';
    if (priority.includes('P1')) return 'text-amber-400 font-bold';
    return 'text-slate-400';
  }
}
