import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScheduleOsService } from '../services/schedule-os.service';

@Component({
  selector: 'app-staff-requests',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      
      <!-- Queue Header -->
      <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-serif-header font-bold text-white tracking-wide">INBOUND SCHEDULING REQUEST QUEUE & DELEGATION</h2>
          <p class="text-xs text-slate-400 font-mono-num">EXECUTIVE ASSISTANT & COS TRIAGE ENGINE • ACCESS TIER RULES</p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono-num">
          <div class="px-3 py-1.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300">
            PENDING TRIAGE: <strong class="text-amber-200">2 REQUESTS</strong>
          </div>
        </div>
      </div>

      <!-- Access Tier Rules Reference -->
      <div class="mayfair-card p-4 space-y-2">
        <h3 class="font-serif-header font-bold text-xs text-[#c5a059]">PRINCIPAL ACCESS TIER POLICY</h3>
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs font-mono-num">
          <div class="p-2 rounded bg-[#080a0e] border border-white/5">
            <span class="text-pink-400 font-bold block text-[11px]">TIER 1: FAMILY & SPOUSE</span>
            <span class="text-slate-300 text-[10px]">P0 Absolute priority • Direct calendar override</span>
          </div>
          <div class="p-2 rounded bg-[#080a0e] border border-white/5">
            <span class="text-amber-400 font-bold block text-[11px]">TIER 2: BOARD & CIO</span>
            <span class="text-slate-300 text-[10px]">P1 Strategic • CoS approval required</span>
          </div>
          <div class="p-2 rounded bg-[#080a0e] border border-white/5">
            <span class="text-blue-400 font-bold block text-[11px]">TIER 3: INVESTORS / SYNDICATES</span>
            <span class="text-slate-300 text-[10px]">P2 Important • EA review & slot fitting</span>
          </div>
          <div class="p-2 rounded bg-[#080a0e] border border-white/5">
            <span class="text-slate-400 font-bold block text-[11px]">TIER 4: GENERAL PUBLIC</span>
            <span class="text-slate-400 text-[10px]">Closed by default • Written request only</span>
          </div>
        </div>
      </div>

      <!-- Requests List -->
      <div class="space-y-4">
        <h3 class="font-serif-header font-bold text-lg text-white flex items-center gap-2">
          <mat-icon class="text-amber-400">inbox</mat-icon>
          PENDING REQUESTS FOR REVIEW
        </h3>

        <div class="space-y-3">
          @for (req of osService.requests(); track req.id) {
            <div class="mayfair-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-[#c5a059]/50 transition-all">
              
              <div class="space-y-1 max-w-xl">
                <div class="flex items-center gap-2 text-xs">
                  <span class="font-bold text-white text-sm">{{ req.requesterName }}</span>
                  <span class="text-slate-400 font-mono-num">({{ req.requesterOrganization }} — {{ req.requesterRole }})</span>
                  <span [class]="getPriorityBadge(req.priority)" class="text-[10px] font-bold px-1.5 py-0.5 rounded font-mono-num">
                    {{ req.priority }}
                  </span>
                </div>

                <p class="text-xs text-slate-200">{{ req.purpose }}</p>
                
                <div class="flex items-center gap-4 text-[11px] font-mono-num text-slate-400 pt-1">
                  <span>Duration: {{ req.requestedDurationMinutes }}m</span>
                  <span>Preferred: {{ req.preferredDateRange }}</span>
                  <span>Venue: {{ req.locationPreference }}</span>
                </div>
              </div>

              <!-- Action Controls -->
              <div class="flex items-center gap-2 self-end md:self-center">
                @if (req.status === 'APPROVED') {
                  <span class="px-3 py-1.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold font-mono-num flex items-center gap-1">
                    <mat-icon class="text-sm">check_circle</mat-icon> APPROVED & SCHEDULED
                  </span>
                } @else if (req.status === 'DECLINED') {
                  <span class="px-3 py-1.5 rounded bg-red-500/20 text-red-300 border border-red-500/30 text-xs font-bold font-mono-num">
                    DECLINED
                  </span>
                } @else {
                  <button 
                    (click)="osService.approveRequest(req.id)"
                    class="px-3.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 transition-all cursor-pointer">
                    <mat-icon class="text-sm">check</mat-icon>
                    <span>APPROVE & SLOT</span>
                  </button>

                  <button 
                    (click)="osService.declineRequest(req.id)"
                    class="px-3.5 py-1.5 rounded bg-red-950/60 hover:bg-red-900 border border-red-500/30 text-red-300 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer">
                    <mat-icon class="text-sm">close</mat-icon>
                    <span>DECLINE</span>
                  </button>
                }
              </div>

            </div>
          }
        </div>
      </div>

    </div>
  `,
})
export class StaffControlCentreComponent {
  osService = inject(ScheduleOsService);

  getPriorityBadge(priority: string): string {
    if (priority.includes('P1')) return 'bg-amber-500/20 text-amber-300 border border-amber-500/30';
    if (priority.includes('P2')) return 'bg-blue-500/20 text-blue-300 border border-blue-500/30';
    return 'bg-slate-800 text-slate-300 border border-slate-700';
  }
}
