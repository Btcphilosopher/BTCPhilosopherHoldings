import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '10mb' }));

const angularApp = new AngularNodeAppEngine();

// Lazy initialization helper for GoogleGenAI
function getGenAI() {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

/**
 * SCHEDULE.OS Express API endpoints powered by Gemini 3.8
 */
app.post('/api/gemini/command', async (req, res) => {
  try {
    const { command, principalProfile, commitments, people, context } = req.body;
    const ai = getGenAI();

    if (!ai) {
      // Deterministic fallback if API key is missing
      return res.json({
        success: true,
        intent: 'PARSED_COMMAND',
        summary: `Processed natural language directive: "${command}"`,
        proposedAction: {
          actionType: 'PROPOSE_RESCHEDULE',
          description: `Analyzed directive against constraints for Alexander Ashcombe. Validated travel buffers, P0-P5 priorities, and security windows.`,
          recommendation: `Optimized time allocation while protecting family commitments and required aircraft transfer buffers.`,
        },
        executionPlan: [
          '1. Extracted target entities and constraints from prompt.',
          '2. Evaluated door-to-door physical travel feasibility.',
          '3. Verified security detail availability and P1 priority ordering.',
          '4. Drafted proposal version for Principal/CoS authorization.',
        ],
      });
    }

    const systemPrompt = `You are Gemini 3.7 acting as the intelligence & constraint reasoning layer for SCHEDULE.OS, the private operating system for an ultra-high-net-worth principal (Alexander Ashcombe).
Analyze the user's natural language directive. You MUST evaluate physical reality, travel buffers (chauffeur, Gulfstream private jet, helicopter), P0-P5 priority rules, security buffers, and family time protection.
Do not mutate the database directly. Produce a structured proposal execution plan for authorization.
Return JSON with format:
{
  "intent": string,
  "summary": string,
  "proposedAction": {
    "actionType": string,
    "description": string,
    "recommendation": string,
    "affectedCommitments": string[]
  },
  "executionPlan": string[],
  "tradeoffs": string[]
}`;

    const promptText = `Directive: "${command}"
Principal State: ${JSON.stringify(principalProfile || {})}
Context: ${JSON.stringify(context || {})}
People Directory: ${JSON.stringify((people || []).slice(0, 5))}
Commitments Sample: ${JSON.stringify((commitments || []).slice(0, 5))}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, ...parsed });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('Error in /api/gemini/command:', err);
    return res.status(500).json({
      success: false,
      error: message || 'Failed to process command via Gemini AI',
    });
  }
});

app.post('/api/gemini/executive-brief', async (req, res) => {
  try {
    const { principalProfile, todayCommitments, upcomingMovements, relationshipAlerts } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        briefText: `GOOD MORNING ALEXANDER.

TODAY'S OVERVIEW:
• 6 commitments scheduled across London & Paris movement.
• 1 Critical P1 Board Meeting at 14:30 BST (Mayfair Boardroom).
• Private Jet flight G-ASH1 departs London Luton (EGGW) at 09:00 for Paris Le Bourget (LFPB).

OPERATIONAL ALERTS:
• Chauffeur buffer is 30 mins; security detail team Alpha active.
• Relationship Alert: Sir Henry Vance (CIO) last met 73 days ago.
• Energy score forecast: 82% optimal with 2h 30m protected focus time.`,
      });
    }

    const systemPrompt = `You are the Chief of Staff intelligence engine for SCHEDULE.OS. Generate a crisp, authoritative 06:30 AM Executive Morning Brief for Principal Alexander Ashcombe.
Style: Institutional Mayfair private bank, crisp, zero bullet-list fluff, highly structured, operational precision.
Format as clear sections with TODAY, CRITICAL EVENT, TRAVEL, RELATIONSHIP ALERTS, and RECOMMENDATIONS.`;

    const promptText = `Data:
Principal: ${JSON.stringify(principalProfile || {})}
Today's Commitments: ${JSON.stringify(todayCommitments || [])}
Movements: ${JSON.stringify(upcomingMovements || [])}
Relationships: ${JSON.stringify(relationshipAlerts || [])}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    return res.json({ briefText: response.text });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('Error in /api/gemini/executive-brief:', err);
    return res.status(500).json({ success: false, error: message });
  }
});

app.post('/api/gemini/meeting-brief', async (req, res) => {
  try {
    const { commitment, participants } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        summary: `Strategic briefing prepared for ${commitment?.title || 'Meeting'}.`,
        talkingPoints: [
          'Review Q3 private equity portfolio allocation performance.',
          'Discuss cross-border family trust restructuring with General Counsel.',
          'Confirm aviation maintenance schedule for Gulfstream G650ER.',
        ],
        questionsToAsk: [
          'What are the key risk mitigations for the European acquisition?',
          'How does the proposed timeline impact the August Cap Ferrat family retreat?',
        ],
        requiredDecisions: ['Approve $45M tranche allocation for Tech Fund IV.'],
      });
    }

    const systemPrompt = `You are the executive intelligence analyst for SCHEDULE.OS. Prepare a high-density, confidential Meeting Brief for a high-priority commitment.
Return JSON:
{
  "summary": string,
  "talkingPoints": string[],
  "questionsToAsk": string[],
  "requiredDecisions": string[],
  "financialContext": string,
  "relationshipNotes": string
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Commitment: ${JSON.stringify(commitment)}\nParticipants: ${JSON.stringify(participants)}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
      },
    });

    return res.json(JSON.parse(response.text || '{}'));
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('Error in /api/gemini/meeting-brief:', err);
    return res.status(500).json({ success: false, error: message });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
