# AUREOM IMAGING — Architecture & Image-Processing Pipeline

## 1. Repository Structure

```
/
├── app/                              # Native Android Application (Kotlin + Jetpack Compose)
│   └── src/main/java/com/example/
│       ├── domain/model/             # Separated Statuses, Calibration, Annotations, QA, Reports, Audit
│       ├── imaging/
│       │   ├── DicomCodec.kt         # DICOM Part 10 binary parser & writer (8/12/16-bit, MONOCHROME1/2)
│       │   ├── RadiographRenderer.kt # Modality LUT -> VOI Windowing -> Photometric -> Orientation -> ROI
│       │   ├── SyntheticStudyGenerator.kt # Deterministic synthetic radiographs & error fixtures
│       │   └── DerivativeExporter.kt # Clearly labelled reviewed derivative PNG exporter (private storage)
│       ├── data/
│       │   ├── local/                # Room database (AureomDatabase.kt) + KeyStore AES-GCM store
│       │   ├── network/              # Retrofit FastAPI client, DICOMweb adapter, DR equipment simulator, Auth
│       │   └── repository/           # WorkstationRepository (patient isolation, sync, retention, audit)
│       └── ui/
│           ├── theme/                # Graphite & cyan medical-imaging theme + Inter/JetBrains Mono fonts
│           ├── viewmodel/            # WorkstationViewModel (StateFlow)
│           └── components/           # Adaptive Tablet 3-pane / Phone views, Canvas Viewport, QA & Report UI
├── backend/                          # Python + FastAPI Application Backend
│   ├── app/
│   │   ├── main.py                   # REST API, RBAC, patient isolation checks, immutable signed reports
│   │   ├── models.py                 # PostgreSQL / SQLAlchemy schema
│   │   ├── auth.py                   # PBKDF2-SHA256 + HS256 JWT + role enforcement
│   │   ├── dicomweb_adapter.py       # QIDO-RS / WADO-RS / STOW-RS bridge
│   │   └── config.py                 # Environment-driven configuration
│   └── tests/test_api.py             # Pytest verification suite
├── dicom-archive/orthanc.json        # Local Orthanc DICOMweb archive configuration
├── fixtures/generate_fixtures.py     # Standalone synthetic DICOM Part 10 fixture generator
├── docker-compose.yml                # PostgreSQL + Orthanc DICOMweb + FastAPI stack
└── docs/                             # API, Architecture, and Clinical Deployment Readiness Docs
```

## 2. Image-Processing Pipeline

1. **Original Preservation**: Imported or transferred DICOM objects are stored unmodified in app-private `filesDir/dicom_vault/` with SHA-256 verification. Raw pixel matrices (`IntArray`, preserving 8/12/16-bit signed or unsigned values) remain untouched in memory.
2. **Modality LUT**: `P_modality = P_stored * RescaleSlope(0028,1053) + RescaleIntercept(0028,1052)`.
3. **VOI Windowing**: Linear ramp over `[WC - 0.5 - (WW - 1)/2, WC - 0.5 + (WW - 1)/2]` mapped to `[0, 255]`.
4. **Photometric Interpretation & Inversion**: `MONOCHROME1` (0 = white) is inverted relative to `MONOCHROME2` (0 = black), then XORed with the user grayscale inversion toggle.
5. **Android Display Limitation**: Android `Bitmap.Config.ARGB_8888` quantizes the transient viewport surface to 8 bits per channel on standard displays. This is a display-only surface; re-windowing, ROI statistics, and archival references always operate against the original raw pixel matrix.
6. **Persistent Orientation Indicators**: Rotations (`0/90/180/270`) and H/V flips deterministically transform edge markers (`SUP/INF/PT-L/PT-R` when DICOM `ViewPosition`/`Laterality` exist, or `TOP/BOT/IMG-L/IMG-R` when missing). Patient left/right is **never** inferred from pixel appearance.

## 3. Supported-Format Matrix

| Format / Transfer Syntax | UID / Signature | Status | Behavior |
|---|---|---|---|
| DICOM Explicit VR Little Endian | `1.2.840.10008.1.2.1` | Supported | Full 8/12/16-bit monochrome parsing, calibration & metadata |
| DICOM Implicit VR Little Endian | `1.2.840.10008.1.2` | Supported | Full 8/12/16-bit monochrome parsing |
| PNG / JPEG Reference Images | `89 50 4E 47` / `FF D8 FF` | Supported (Reference) | Explicitly tagged `NON-DICOM REFERENCE`, 8-bit, uncalibrated (`px` only) |
| DICOM JPEG 2000 (Lossless/Lossy) | `1.2.840.10008.1.2.4.90/.91` | Rejected Safely | Displays explicit `ERR_UNSUPPORTED_J2K` dialog |
| DICOM JPEG Baseline / RLE / Big Endian | `.4.50`, `.5`, `.2` | Rejected Safely | Displays explicit transfer-syntax error dialog |
| Arbitrary non-imaging files | Other MIME/magic | Rejected Safely | Displays `ERR_UNSUPPORTED_FORMAT` dialog & logs audit event |
