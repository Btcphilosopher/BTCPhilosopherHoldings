# Clinical Deployment & Regulatory Readiness Checklist

Before proposing any clinical deployment of AUREOM IMAGING beyond demonstration:

1. **Intended Jurisdiction & Medical-Device Classification**:
   - Determine regulatory classification under the target jurisdiction (e.g., FDA 21 CFR 892.2050 PACS / Medical Image Management and Processing System in the US; EU MDR 2017/745 Annex VIII Rule 11 software classification; UK MHRA medical device regulations).
   - Verify whether mobile viewing is restricted to informational/secondary review vs primary diagnostic interpretation.
2. **Clinical Safety & Quality Management**:
   - Establish ISO 14971 risk management file, IEC 62304 software lifecycle documentation, and IEC 62366 usability engineering.
   - Maintain strict isolation from X-ray generator exposure/radiation controls.
3. **Display Suitability & Calibration**:
   - Verify display luminance, ambient light conditions, contrast ratio, and DICOM Grayscale Standard Display Function (GSDF / PS3.14) calibration; standard consumer Android 8-bit OLED/LCD panels are **not** calibrated primary diagnostic displays.
4. **Archive Integration & Security**:
   - Enforce TLS 1.2/1.3 mutual authentication or OIDC/SMART-on-FHIR enterprise SSO for DICOMweb (QIDO-RS / WADO-RS / STOW-RS) and FastAPI endpoints; disable local dev cleartext exceptions in `network_security_config.xml`.
   - Validate MDM / device encryption, biometric/PIN lock policies, and automated cache purge compliance under HIPAA / GDPR / NHS DSPT.
