# AUREOM IMAGING — Backend & DICOMweb API Documentation

## Authentication
- `POST /api/v1/auth/login`: Authenticates clinician (`username`, `passcode`) against PBKDF2-SHA256 password hash and returns a signed HS256 bearer token.
- All clinical routes require `Authorization: Bearer <token>`.

## Worklist & Studies
- `GET /api/v1/studies`: Returns examination worklist with separated `acquisition_status`, `receipt_status`, `quality_status`, and `report_status`.

## Patient-Isolated Annotations
- `POST /api/v1/annotations`: Persists an annotation bound to `(patient_id, study_instance_uid, sop_instance_uid)` in `IMAGE_PIXEL_SPACE_ORIGIN_TOP_LEFT`. Returns `409 Conflict` if `patient_id` does not match the study's `patient_id` or if an older `version` causes a conflict.

## Technical Quality Review
- `POST /api/v1/studies/{study_uid}/qa`: Records structured technical QA flags (`positioning_concerns`, `motion_artefact`, `incomplete_field_coverage`, `missing_orientation_info`, `suspected_processing_issues`, `further_review_required`) without inferring diagnostic adequacy or recommending repeat radiation.

## Clinical Reporting & Amendments
- `POST /api/v1/studies/{study_uid}/report`: Saves draft, submits for review, or signs electronically. Signing requires `RADIOLOGIST` or `ADMIN` role (`403 Forbidden` for `RADIOGRAPHER`). Direct mutation after signing returns `409 Conflict`.
- `POST /api/v1/studies/{study_uid}/report/amend`: Appends an immutable linked amendment with reason and author attribution to a signed report.

## Audit & DICOMweb Bridge
- `POST /api/v1/audit` & `GET /api/v1/audit`: Records and queries immutable workstation audit events.
- `GET /api/v1/dicomweb/studies`: Proxies QIDO-RS (`Accept: application/dicom+json`) to the configured Orthanc / DICOMweb imaging archive.
