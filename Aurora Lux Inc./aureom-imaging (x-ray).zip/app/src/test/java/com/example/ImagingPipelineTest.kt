package com.example

import com.example.domain.model.CalibrationState
import com.example.domain.model.DisplaySettings
import com.example.domain.model.ImagePoint
import com.example.domain.model.PhotometricInterpretation
import com.example.domain.model.PixelSpacingInfo
import com.example.domain.model.RadiographPixelData
import com.example.imaging.DicomCodec
import com.example.imaging.DicomParseResult
import com.example.imaging.DicomWriteRequest
import com.example.imaging.RadiographRenderer
import com.example.imaging.SyntheticStudyGenerator
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ImagingPipelineTest {

    @Test
    fun `grayscale interpretation handles MONOCHROME2 vs MONOCHROME1 and rescale parameters`() {
        val mono2 = RadiographPixelData(
            width = 2,
            height = 1,
            bitsAllocated = 16,
            bitsStored = 12,
            pixelRepresentation = 0,
            photometric = PhotometricInterpretation.MONOCHROME2,
            rescaleSlope = 2.0,
            rescaleIntercept = -100.0,
            defaultWindowCenter = 1900.0,
            defaultWindowWidth = 4000.0,
            rawPixels = intArrayOf(0, 2000),
            isDicom = true,
            transferSyntaxUid = DicomCodec.TS_EXPLICIT_VR_LE,
        )
        val settings = DisplaySettings(windowCenter = 1900.0, windowWidth = 4000.0)
        val outMono2 = RadiographRenderer.renderToArgbPixels(mono2, settings).map { it and 0xFF }
        assertTrue("MONOCHROME2 lower pixel should render darker than higher pixel", outMono2[0] < outMono2[1])

        val mono1 = mono2.copy(photometric = PhotometricInterpretation.MONOCHROME1)
        val outMono1 = RadiographRenderer.renderToArgbPixels(mono1, settings).map { it and 0xFF }
        assertTrue("MONOCHROME1 lower pixel should render brighter than higher pixel", outMono1[0] > outMono1[1])

        val inverted = RadiographRenderer.renderToArgbPixels(mono2, settings.copy(inverted = true)).map { it and 0xFF }
        assertEquals(255 - outMono2[0], inverted[0])
        assertEquals(255 - outMono2[1], inverted[1])
    }

    @Test
    fun `windowing narrows contrast and preserves original raw pixels`() {
        val raw = intArrayOf(1000, 1500, 2000, 2500, 3000)
        val snapshot = raw.copyOf()
        val px = RadiographPixelData(
            width = 5,
            height = 1,
            bitsAllocated = 16,
            bitsStored = 12,
            pixelRepresentation = 0,
            photometric = PhotometricInterpretation.MONOCHROME2,
            rescaleSlope = 1.0,
            rescaleIntercept = 0.0,
            defaultWindowCenter = 2000.0,
            defaultWindowWidth = 2000.0,
            rawPixels = raw,
            isDicom = true,
            transferSyntaxUid = DicomCodec.TS_EXPLICIT_VR_LE,
        )
        val narrow = RadiographRenderer.renderToArgbPixels(px, DisplaySettings(windowCenter = 2000.0, windowWidth = 400.0))
            .map { it and 0xFF }
        assertEquals(0, narrow[0])
        assertEquals(0, narrow[1])
        assertEquals(255, narrow[3])
        assertEquals(255, narrow[4])
        assertArrayEquals("Original raw pixel array must remain untouched", snapshot, px.rawPixels)
    }

    @Test
    fun `orientation indicators rotate and flip consistently without inferring missing laterality`() {
        val paDefault = RadiographRenderer.computeOrientationMarkers(
            laterality = null,
            viewOrProjection = "PA",
            rotationDegrees = 0,
            flipHorizontal = false,
            flipVertical = false,
        )
        assertEquals("SUP (H)", paDefault.top)
        assertEquals("INF (F)", paDefault.bottom)
        assertEquals("PT-L", paDefault.left)
        assertEquals("PT-R", paDefault.right)
        assertTrue(paDefault.orientationVerifiedFromDicom)

        val rotated90 = RadiographRenderer.computeOrientationMarkers(
            laterality = null,
            viewOrProjection = "PA",
            rotationDegrees = 90,
            flipHorizontal = false,
            flipVertical = false,
        )
        assertEquals("PT-L", rotated90.top)
        assertEquals("SUP (H)", rotated90.right)
        assertEquals("PT-R", rotated90.bottom)
        assertEquals("INF (F)", rotated90.left)

        val missingOrientation = RadiographRenderer.computeOrientationMarkers(
            laterality = null,
            viewOrProjection = null,
            rotationDegrees = 0,
            flipHorizontal = true,
            flipVertical = false,
        )
        assertFalse(missingOrientation.orientationVerifiedFromDicom)
        assertEquals("IMG-R", missingOrientation.left)
        assertEquals("IMG-L", missingOrientation.right)
    }

    @Test
    fun `annotation coordinate roundtrip remains accurate under rotation flip zoom and pan`() {
        val imgPt = ImagePoint(140f, 320f)
        val settings = DisplaySettings(
            windowCenter = 1850.0,
            windowWidth = 2200.0,
            zoom = 2.25f,
            panX = 48f,
            panY = -36f,
            rotationDegrees = 270,
            flipHorizontal = true,
            flipVertical = false,
        )
        val (sx, sy) = RadiographRenderer.imageToScreen(imgPt, 512f, 512f, 1000f, 800f, settings)
        val recovered = RadiographRenderer.screenToImage(sx, sy, 512f, 512f, 1000f, 800f, settings)
        assertTrue(abs(recovered.x - imgPt.x) < 0.05f)
        assertTrue(abs(recovered.y - imgPt.y) < 0.05f)
    }

    @Test
    fun `measurement calibration enforces pixel only when missing and distinguishes detector plane`() {
        val p1 = ImagePoint(100f, 100f)
        val p2 = ImagePoint(200f, 100f)

        val none = RadiographRenderer.formatLengthMeasurement(
            p1, p2,
            PixelSpacingInfo(null, null, CalibrationState.NONE, "Missing"),
        )
        assertTrue(none.contains("100.0 px"))
        assertFalse(none.contains("mm"))

        val detector = RadiographRenderer.formatLengthMeasurement(
            p1, p2,
            PixelSpacingInfo(0.15, 0.15, CalibrationState.DETECTOR_PLANE, "(0018,1164)"),
        )
        assertTrue(detector.contains("15.0 mm"))
        assertTrue(detector.contains("Detector plane"))

        val calibrated = RadiographRenderer.formatLengthMeasurement(
            p1, p2,
            PixelSpacingInfo(0.10, 0.10, CalibrationState.ANATOMICAL_CALIBRATED, "(0028,0030)"),
        )
        assertTrue(calibrated.contains("10.0 mm"))
        assertFalse(calibrated.contains("Detector plane"))
    }

    @Test
    fun `dicom roundtrip preserves 12-bit pixels and rejects unsupported jpeg 2000 transfer syntax`() {
        val chestBytes = SyntheticStudyGenerator.generateChestPaDicom(isPrior = false)
        val parsed = DicomCodec.parseDicomBytes(chestBytes)
        assertTrue(parsed is DicomParseResult.Success)
        val ok = parsed as DicomParseResult.Success
        assertEquals(512, ok.pixelData.width)
        assertEquals(12, ok.pixelData.bitsStored)
        assertEquals("SYN-PT-10482", ok.metadata.patientId)
        val minPx = ok.pixelData.rawPixels.minOrNull() ?: 0
        val maxPx = ok.pixelData.rawPixels.maxOrNull() ?: 0
        assertTrue("Synthetic radiograph must contain 12-bit dynamic range (got $minPx..$maxPx)", maxPx - minPx > 1000)

        val j2kBytes = SyntheticStudyGenerator.generateUnsupportedJpeg2000Dicom()
        val j2kParsed = DicomCodec.parseDicomBytes(j2kBytes)
        assertTrue(j2kParsed is DicomParseResult.Unsupported)
        assertEquals("ERR_UNSUPPORTED_J2K", (j2kParsed as DicomParseResult.Unsupported).errorCode)

        val nonDicom = DicomCodec.parseDicomBytes("PLAIN_TEXT_FILE".toByteArray())
        assertTrue(nonDicom is DicomParseResult.Unsupported)
    }

    @Test
    fun `signed 16-bit pixel representation decodes negative values properly`() {
        val signedPixels = intArrayOf(-500, 0, 500, 1024)
        val bytes = DicomCodec.writePart10Dicom(
            DicomWriteRequest(
                width = 2,
                height = 2,
                bitsAllocated = 16,
                bitsStored = 12,
                pixelRepresentation = 1,
                rawPixels = signedPixels,
                patientId = "PT-SIGNED",
                patientIdIssuer = "HOSP",
                patientName = "SIGNED^TEST",
                studyInstanceUid = "1.2.3.4",
                seriesInstanceUid = "1.2.3.4.1",
                sopInstanceUid = "1.2.3.4.1.1",
                accessionNumber = "ACC-1",
                studyDescription = "Signed Test",
                acquisitionDate = "20261124",
                acquisitionTime = "010000",
                modality = "DX",
                bodyPart = "CHEST",
            ),
        )
        val res = DicomCodec.parseDicomBytes(bytes) as DicomParseResult.Success
        assertArrayEquals(signedPixels, res.pixelData.rawPixels)
    }
}
