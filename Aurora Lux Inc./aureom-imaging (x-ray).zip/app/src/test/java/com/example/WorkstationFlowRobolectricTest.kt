package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AureomDatabase
import com.example.data.network.SimulatedDrEquipmentAdapter
import com.example.data.repository.ImportOutcome
import com.example.data.repository.WorkstationRepository
import com.example.domain.model.AcquisitionStatus
import com.example.domain.model.AnnotationType
import com.example.domain.model.ClinicianSession
import com.example.domain.model.DisplaySettings
import com.example.domain.model.ImagePoint
import com.example.domain.model.RadiographAnnotation
import com.example.domain.model.ReceiptStatus
import com.example.imaging.DerivativeExporter
import com.example.imaging.DicomCodec
import com.example.imaging.SyntheticStudyGenerator
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class WorkstationFlowRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: AureomDatabase
    private lateinit var repository: WorkstationRepository

    private val testActor = ClinicianSession(
        userId = "usr-rad-01",
        displayName = "Dr. E. Vance",
        role = "RADIOLOGIST",
        token = "test-token",
        authMode = "LOCAL_DEMO_ADAPTER",
        signedInAtIso = "2026-11-24T01:00:00Z",
    )

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AureomDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = WorkstationRepository(context = context, db = db)
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `patient isolation blocks saving annotation onto wrong patient study`() = runTest {
        repository.ensureDemoFixturesSeeded(testActor)
        val studies = db.studyCacheDao().getAll()
        val chestStudy = studies.first { it.patientId == "SYN-PT-10482" }
        val handStudy = studies.first { it.patientId == "SYN-PT-20914" }

        val loadedHand = repository.loadStudyPixels(handStudy.studyInstanceUid)!!
        val mismatchedAnnotation = RadiographAnnotation(
            id = "ann-mismatch-1",
            patientId = chestStudy.patientId,
            studyInstanceUid = chestStudy.studyInstanceUid,
            sopInstanceUid = chestStudy.sopInstanceUid,
            type = AnnotationType.TEXT_NOTE,
            points = listOf(ImagePoint(120f, 120f)),
            text = "Should never attach to Hand patient",
            authorId = testActor.userId,
            authorName = testActor.displayName,
            createdAtIso = "2026-11-24T01:05:00Z",
            updatedAtIso = "2026-11-24T01:05:00Z",
        )

        var threw = false
        try {
            repository.saveAnnotation(mismatchedAnnotation, loadedHand.summary, testActor)
        } catch (ex: IllegalArgumentException) {
            threw = true
        }
        assertTrue("Patient isolation must reject mismatched patient/study annotation", threw)
    }

    @Test
    fun `interrupted transfer emits failure then completes cleanly with verified checksum on retry`() = runTest {
        val adapter = SimulatedDrEquipmentAdapter()
        val studyUid = "1.2.826.0.1.3680043.8.498.4000.INTERRUPTED"

        val failedEvents = adapter.simulateIncomingAcquisition(studyUid, simulateInterruptFailure = true).toList()
        assertEquals(AcquisitionStatus.SCHEDULED, failedEvents[0].acquisitionStatus)
        assertEquals(AcquisitionStatus.ACQUISITION_IN_PROGRESS, failedEvents[1].acquisitionStatus)
        assertEquals(AcquisitionStatus.IMAGE_AVAILABLE, failedEvents[2].acquisitionStatus)
        assertEquals(AcquisitionStatus.TRANSFER_FAILED, failedEvents.last().acquisitionStatus)
        assertEquals(ReceiptStatus.PARTIAL_INTERRUPTED, failedEvents.last().receiptStatus)

        val retryEvents = adapter.simulateIncomingAcquisition(studyUid, simulateInterruptFailure = false).toList()
        val finalEvent = retryEvents.last()
        assertEquals(AcquisitionStatus.TRANSFER_COMPLETE, finalEvent.acquisitionStatus)
        assertEquals(ReceiptStatus.RECEIVED_VERIFIED, finalEvent.receiptStatus)
        assertNotNull(finalEvent.dicomBytes)
        assertEquals(DicomCodec.sha256Hex(finalEvent.dicomBytes!!), finalEvent.sha256)
    }

    @Test
    fun `derivative export preserves original dicom bytes and produces labelled png`() = runTest {
        repository.ensureDemoFixturesSeeded(testActor)
        val chestUid = "1.2.826.0.1.3680043.8.498.1000.CURR"
        val loaded = repository.loadStudyPixels(chestUid)!!
        val originalFile = File(loaded.summary.metadata.originalFilePath)
        val shaBefore = DicomCodec.sha256Hex(originalFile.readBytes())

        val ann = RadiographAnnotation(
            id = "ann-chest-1",
            patientId = loaded.summary.patientId,
            studyInstanceUid = loaded.summary.studyInstanceUid,
            sopInstanceUid = loaded.summary.sopInstanceUid,
            type = AnnotationType.LENGTH,
            points = listOf(ImagePoint(120f, 150f), ImagePoint(220f, 150f)),
            authorId = testActor.userId,
            authorName = testActor.displayName,
            createdAtIso = "2026-11-24T01:10:00Z",
            updatedAtIso = "2026-11-24T01:10:00Z",
            measurementSummary = "14.8 mm [Detector plane] (100 px)",
        )
        repository.saveAnnotation(ann, loaded.summary, testActor)

        val export = DerivativeExporter.exportReviewedDerivative(
            context = context,
            pixelData = loaded.pixelData!!,
            metadata = loaded.summary.metadata,
            displaySettings = DisplaySettings(windowCenter = 1600.0, windowWidth = 1800.0, inverted = true),
            annotations = listOf(ann),
            exportedBy = testActor.displayName,
            exportedAtIso = "2026-11-24T01:12:00Z",
        )
        assertTrue(export.file.exists())
        assertTrue(export.bannerSummary.contains("REVIEWED DERIVATIVE"))

        val shaAfter = DicomCodec.sha256Hex(originalFile.readBytes())
        assertEquals("Original DICOM file must never be mutated by derivative export", shaBefore, shaAfter)
    }

    @Test
    fun `duplicate-safe import skips duplicate dicom and labels png non-dicom`() = runTest {
        val bytes = SyntheticStudyGenerator.generateChestPaDicom(isPrior = false)
        val first = repository.importRawBytes(bytes, "chest_curr.dcm", "DOC-PICKER", testActor)
        assertTrue(first is ImportOutcome.Imported && !first.isDuplicate)

        val second = repository.importRawBytes(bytes, "chest_curr_copy.dcm", "DOC-PICKER", testActor)
        assertTrue(second is ImportOutcome.Imported && second.isDuplicate)

        val pngBytes = SyntheticStudyGenerator.generateNonDicomPngReference()
        val pngRes = repository.importRawBytes(pngBytes, "ref.png", "DOC-PICKER", testActor)
        assertTrue(pngRes is ImportOutcome.Imported)
        assertTrue((pngRes as ImportOutcome.Imported).summary.isNonDicom)
    }
}
