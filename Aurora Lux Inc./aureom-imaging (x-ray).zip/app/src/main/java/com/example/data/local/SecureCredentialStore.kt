package com.example.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.aureomDataStore by preferencesDataStore(name = "aureom_secure_prefs")

data class WorkstationPreferences(
    val backendBaseUrl: String = "http://10.0.2.2:8000",
    val dicomWebBaseUrl: String = "http://10.0.2.2:8042/dicom-web",
    val retentionHours: Int = 168, // 7 days default
    val sessionTimeoutMinutes: Int = 10,
    val textScale: Float = 1.0f,
)

/**
 * Encrypts sensitive workstation credentials (session tokens, DICOMweb bearer credentials)
 * using Android KeyStore AES-256-GCM before storing in DataStore.
 */
class SecureCredentialStore(private val context: Context) {

    private val keyBackendUrl = stringPreferencesKey("backend_base_url")
    private val keyDicomWebUrl = stringPreferencesKey("dicomweb_base_url")
    private val keyRetentionHours = intPreferencesKey("cache_retention_hours")
    private val keyTimeoutMinutes = intPreferencesKey("session_timeout_minutes")
    private val keyTextScale = floatPreferencesKey("ui_text_scale")
    private val keyEncryptedToken = stringPreferencesKey("enc_session_token")
    private val keyEncryptedArchiveCred = stringPreferencesKey("enc_archive_cred")
    private val keySessionUserJson = stringPreferencesKey("session_user_meta")

    val preferencesFlow: Flow<WorkstationPreferences> = context.aureomDataStore.data.map { prefs ->
        WorkstationPreferences(
            backendBaseUrl = prefs[keyBackendUrl] ?: "http://10.0.2.2:8000",
            dicomWebBaseUrl = prefs[keyDicomWebUrl] ?: "http://10.0.2.2:8042/dicom-web",
            retentionHours = prefs[keyRetentionHours] ?: 168,
            sessionTimeoutMinutes = prefs[keyTimeoutMinutes] ?: 10,
            textScale = prefs[keyTextScale] ?: 1.0f,
        )
    }

    suspend fun updatePreferences(transform: (WorkstationPreferences) -> WorkstationPreferences) {
        context.aureomDataStore.edit { prefs ->
            val current = WorkstationPreferences(
                backendBaseUrl = prefs[keyBackendUrl] ?: "http://10.0.2.2:8000",
                dicomWebBaseUrl = prefs[keyDicomWebUrl] ?: "http://10.0.2.2:8042/dicom-web",
                retentionHours = prefs[keyRetentionHours] ?: 168,
                sessionTimeoutMinutes = prefs[keyTimeoutMinutes] ?: 10,
                textScale = prefs[keyTextScale] ?: 1.0f,
            )
            val updated = transform(current)
            prefs[keyBackendUrl] = updated.backendBaseUrl.trim()
            prefs[keyDicomWebUrl] = updated.dicomWebBaseUrl.trim()
            prefs[keyRetentionHours] = updated.retentionHours.coerceIn(1, 720)
            prefs[keyTimeoutMinutes] = updated.sessionTimeoutMinutes.coerceIn(1, 60)
            prefs[keyTextScale] = updated.textScale.coerceIn(0.9f, 1.35f)
        }
    }

    suspend fun saveProtectedToken(token: String, userMetaJson: String) {
        val encrypted = encryptString(token)
        context.aureomDataStore.edit { prefs ->
            prefs[keyEncryptedToken] = encrypted
            prefs[keySessionUserJson] = userMetaJson
        }
    }

    suspend fun readProtectedToken(): Pair<String?, String?> {
        val prefs = context.aureomDataStore.data.first()
        val enc = prefs[keyEncryptedToken] ?: return null to null
        val meta = prefs[keySessionUserJson]
        return runCatching { decryptString(enc) }.getOrNull() to meta
    }

    suspend fun saveArchiveCredential(credential: String) {
        val encrypted = encryptString(credential)
        context.aureomDataStore.edit { prefs ->
            prefs[keyEncryptedArchiveCred] = encrypted
        }
    }

    suspend fun readArchiveCredential(): String? {
        val prefs = context.aureomDataStore.data.first()
        val enc = prefs[keyEncryptedArchiveCred] ?: return null
        return runCatching { decryptString(enc) }.getOrNull()
    }

    suspend fun clearProtectedSession() {
        context.aureomDataStore.edit { prefs ->
            prefs.remove(keyEncryptedToken)
            prefs.remove(keySessionUserJson)
        }
    }

    private fun getOrCreateKey(): SecretKey? {
        return runCatching {
            val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
            val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
            if (existing != null) return existing
            val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
            keyGen.init(
                KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build(),
            )
            keyGen.generateKey()
        }.getOrNull()
    }

    private fun encryptString(plaintext: String): String {
        val key = getOrCreateKey()
            ?: return "PLAIN_TEST:" + Base64.encodeToString(plaintext.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ciphertext, Base64.NO_WRAP)
    }

    private fun decryptString(encoded: String): String {
        if (encoded.startsWith("PLAIN_TEST:")) {
            return String(Base64.decode(encoded.removePrefix("PLAIN_TEST:"), Base64.NO_WRAP), StandardCharsets.UTF_8)
        }
        val key = getOrCreateKey() ?: throw IllegalStateException("KeyStore key unavailable")
        val parts = encoded.split(':')
        require(parts.size == 2)
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val ciphertext = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8)
    }

    companion object {
        private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        private const val KEY_ALIAS = "aureom_workstation_aes_key"
    }
}
