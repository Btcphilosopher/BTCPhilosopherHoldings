package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.WorkstationPreferences
import com.example.data.network.DicomWebStudyEntry
import com.example.domain.model.AnnotationTool
import com.example.domain.model.AuditEvent
import com.example.domain.model.CalibrationState
import com.example.domain.model.ClinicalReport
import com.example.domain.model.DisplaySettings
import com.example.domain.model.ExaminationSummary
import com.example.domain.model.QualityChecklist
import com.example.domain.model.RadiographAnnotation
import com.example.domain.model.RadiographPixelData
import com.example.domain.model.ReportStatus
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanOnContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GraphiteAbyss
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.GraphitePanel
import com.example.ui.theme.StatusCritical
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusInfoBg
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import com.example.ui.viewmodel.InspectorTab

@Composable
fun ToolsInspectorPane(
    selectedTab: InspectorTab,
    onSelectTab: (InspectorTab) -> Unit,
    activeStudy: ExaminationSummary?,
    activePixels: RadiographPixelData?,
    displaySettings: DisplaySettings,
    activeTool: AnnotationTool,
    annotations: List<RadiographAnnotation>,
    qualityChecklist: QualityChecklist?,
    automatedTechnicalFlags: List<String>,
    report: ClinicalReport?,
    auditEvents: List<AuditEvent>,
    preferences: WorkstationPreferences,
    dicomWebQueryResults: List<DicomWebStudyEntry>,
    onUpdateWindowLevel: (Double, Double) -> Unit,
    onUpdateZoomPan: (Float, Float, Float) -> Unit,
    onFitToScreen: () -> Unit,
    onRotateCw90: () -> Unit,
    onFlipH: () -> Unit,
    onFlipV: () -> Unit,
    onToggleInvert: () -> Unit,
    onResetView: () -> Unit,
    onSelectTool: (AnnotationTool) -> Unit,
    onDeleteAnnotation: (RadiographAnnotation) -> Unit,
    onExportDerivative: () -> Unit,
    onSaveQualityChecklist: (Boolean, Boolean, Boolean, Boolean, Boolean, Boolean, String) -> Unit,
    onSaveReportDraft: (String, String, Boolean) -> Unit,
    onSignReport: (String, String) -> Unit,
    onAddAmendment: (String, String) -> Unit,
    onQueryDicomWeb: (Boolean) -> Unit,
    onRetrieveDicomWebEntry: (DicomWebStudyEntry, Boolean) -> Unit,
    onSimulateConflict: () -> Unit,
    onPurgeCache: () -> Unit,
    onClearAndReseed: () -> Unit,
    onUpdateEndpointsAndPolicy: (String, String, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphitePanel),
    ) {
        ScrollableTabRow(
            selectedTabIndex = InspectorTab.entries.indexOf(selectedTab),
            containerColor = GraphiteCard,
            contentColor = CyanPrimary,
            edgePadding = 8.dp,
        ) {
            InspectorTab.entries.forEach { tab ->
                Tab(
                    selected = tab == selectedTab,
                    onClick = { onSelectTab(tab) },
                    text = { Text(tab.title, style = MaterialTheme.typography.labelLarge) },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("inspector_tab_${tab.name}"),
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (selectedTab) {
                InspectorTab.DISPLAY -> DisplayToolsSection(
                    activeStudy = activeStudy,
                    activePixels = activePixels,
                    displaySettings = displaySettings,
                    onUpdateWindowLevel = onUpdateWindowLevel,
                    onUpdateZoomPan = onUpdateZoomPan,
                    onFitToScreen = onFitToScreen,
                    onRotateCw90 = onRotateCw90,
                    onFlipH = onFlipH,
                    onFlipV = onFlipV,
                    onToggleInvert = onToggleInvert,
                    onResetView = onResetView,
                )

                InspectorTab.ANNOTATE -> AnnotateToolsSection(
                    activeStudy = activeStudy,
                    activePixels = activePixels,
                    activeTool = activeTool,
                    annotations = annotations,
                    onSelectTool = onSelectTool,
                    onDeleteAnnotation = onDeleteAnnotation,
                    onExportDerivative = onExportDerivative,
                )

                InspectorTab.QUALITY -> QualityReviewSection(
                    activeStudy = activeStudy,
                    existing = qualityChecklist,
                    automatedFlags = automatedTechnicalFlags,
                    onSaveQuality = onSaveQualityChecklist,
                )

                InspectorTab.REPORT -> ClinicalReportSection(
                    activeStudy = activeStudy,
                    report = report,
                    onSaveDraft = onSaveReportDraft,
                    onSignReport = onSignReport,
                    onAddAmendment = onAddAmendment,
                )

                InspectorTab.ARCHIVE -> ArchiveAndAuditSection(
                    preferences = preferences,
                    auditEvents = auditEvents,
                    dicomWebQueryResults = dicomWebQueryResults,
                    activeStudy = activeStudy,
                    onQueryDicomWeb = onQueryDicomWeb,
                    onRetrieveDicomWebEntry = onRetrieveDicomWebEntry,
                    onSimulateConflict = onSimulateConflict,
                    onPurgeCache = onPurgeCache,
                    onClearAndReseed = onClearAndReseed,
                    onUpdateEndpointsAndPolicy = onUpdateEndpointsAndPolicy,
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DisplayToolsSection(
    activeStudy: ExaminationSummary?,
    activePixels: RadiographPixelData?,
    displaySettings: DisplaySettings,
    onUpdateWindowLevel: (Double, Double) -> Unit,
    onUpdateZoomPan: (Float, Float, Float) -> Unit,
    onFitToScreen: () -> Unit,
    onRotateCw90: () -> Unit,
    onFlipH: () -> Unit,
    onFlipV: () -> Unit,
    onToggleInvert: () -> Unit,
    onResetView: () -> Unit,
) {
    if (activeStudy == null || activePixels == null) {
        Text("Open and confirm a study with verified image pixels to adjust display settings.", style = MaterialTheme.typography.bodySmall)
        return
    }

    val maxRange = if (activePixels.bitsStored <= 8) 255f else 4095f

    Text("WINDOW / LEVEL (VOI LUT)", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
    Text(
        "Window Center: ${displaySettings.windowCenter.toInt()}",
        style = MaterialTheme.typography.labelSmall,
    )
    Slider(
        value = displaySettings.windowCenter.toFloat().coerceIn(-500f, maxRange),
        onValueChange = { onUpdateWindowLevel(it.toDouble(), displaySettings.windowWidth) },
        valueRange = 0f..maxRange,
        colors = SliderDefaults.colors(thumbColor = CyanPrimary, activeTrackColor = CyanPrimary),
        modifier = Modifier.testTag("window_center_slider"),
    )

    Text(
        "Window Width: ${displaySettings.windowWidth.toInt()}",
        style = MaterialTheme.typography.labelSmall,
    )
    Slider(
        value = displaySettings.windowWidth.toFloat().coerceIn(1f, maxRange * 1.5f),
        onValueChange = { onUpdateWindowLevel(displaySettings.windowCenter, it.toDouble()) },
        valueRange = 10f..(maxRange * 1.5f),
        colors = SliderDefaults.colors(thumbColor = CyanPrimary, activeTrackColor = CyanPrimary),
        modifier = Modifier.testTag("window_width_slider"),
    )

    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(
            onClick = { onUpdateWindowLevel(activePixels.defaultWindowCenter, activePixels.defaultWindowWidth) },
            modifier = Modifier.minimumInteractiveComponentSize(),
        ) { Text("DICOM Default", style = MaterialTheme.typography.bodySmall) }
        OutlinedButton(
            onClick = { onUpdateWindowLevel(1400.0, 2000.0) },
            modifier = Modifier.minimumInteractiveComponentSize(),
        ) { Text("Lung", style = MaterialTheme.typography.bodySmall) }
        OutlinedButton(
            onClick = { onUpdateWindowLevel(2400.0, 1800.0) },
            modifier = Modifier.minimumInteractiveComponentSize(),
        ) { Text("Bone", style = MaterialTheme.typography.bodySmall) }
        OutlinedButton(
            onClick = { onUpdateWindowLevel(1800.0, 900.0) },
            modifier = Modifier.minimumInteractiveComponentSize(),
        ) { Text("Mediastinum", style = MaterialTheme.typography.bodySmall) }
    }

    HorizontalDivider(color = GraphiteBorder)
    Text("GEOMETRY & PHOTOMETRIC", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)

    Text("Zoom: ${(displaySettings.zoom * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
    Slider(
        value = displaySettings.zoom,
        onValueChange = { onUpdateZoomPan(it, displaySettings.panX, displaySettings.panY) },
        valueRange = 0.5f..5.0f,
        colors = SliderDefaults.colors(thumbColor = CyanPrimary, activeTrackColor = CyanPrimary),
        modifier = Modifier.testTag("zoom_slider"),
    )

    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(
            onClick = onFitToScreen,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("fit_screen_button"),
        ) { Text("Fit Screen") }
        OutlinedButton(
            onClick = onRotateCw90,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("rotate_90_button"),
        ) {
            Icon(Icons.Filled.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Rot 90°")
        }
        OutlinedButton(
            onClick = onFlipH,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("flip_h_button"),
        ) {
            Icon(Icons.Filled.Flip, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Flip H")
        }
        OutlinedButton(
            onClick = onFlipV,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("flip_v_button"),
        ) {
            Text("Flip V")
        }
        OutlinedButton(
            onClick = onToggleInvert,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("invert_grayscale_button"),
        ) {
            Icon(Icons.Filled.InvertColors, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Invert")
        }
    }

    Button(
        onClick = onResetView,
        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
    ) {
        Text("Restore Default Display Settings")
    }

    HorizontalDivider(color = GraphiteBorder)
    Text("PIXEL & PROCESSING PROVENANCE", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
    Card(colors = CardDefaults.cardColors(containerColor = GraphiteCard), border = BorderStroke(1.dp, GraphiteBorder)) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Transfer Syntax: ${activeStudy.metadata.transferSyntaxUid}", style = MaterialTheme.typography.labelSmall)
            Text("SHA-256: ${activeStudy.metadata.originalSha256.take(20)}…", style = MaterialTheme.typography.labelSmall)
            Text("Spacing: ${activeStudy.metadata.spacingInfo.sourceTag}", style = MaterialTheme.typography.labelSmall)
            activeStudy.metadata.imageProcessingHistory.forEach { step ->
                Text("• $step", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                text = "Display Pipeline Note: Android ARGB_8888 surface renders 8-bit quantized output for viewport display while raw ${activePixels.bitsStored}-bit values remain preserved.",
                style = MaterialTheme.typography.bodySmall,
                color = StatusInfo,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AnnotateToolsSection(
    activeStudy: ExaminationSummary?,
    activePixels: RadiographPixelData?,
    activeTool: AnnotationTool,
    annotations: List<RadiographAnnotation>,
    onSelectTool: (AnnotationTool) -> Unit,
    onDeleteAnnotation: (RadiographAnnotation) -> Unit,
    onExportDerivative: () -> Unit,
) {
    if (activeStudy == null || activePixels == null) {
        Text("Confirm and open an image to annotate or measure.", style = MaterialTheme.typography.bodySmall)
        return
    }

    val calib = activeStudy.metadata.spacingInfo
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (calib.calibrationState == CalibrationState.NONE) StatusWarningBg else StatusInfoBg,
        ),
        border = BorderStroke(
            1.dp,
            if (calib.calibrationState == CalibrationState.NONE) StatusWarning else StatusInfo,
        ),
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(calib.calibrationState.label, style = MaterialTheme.typography.labelMedium)
            Text(
                text = when (calib.calibrationState) {
                    CalibrationState.ANATOMICAL_CALIBRATED -> "Physical mm (${calib.rowSpacingMm} x ${calib.colSpacingMm} mm/px) from ${calib.sourceTag}."
                    CalibrationState.DETECTOR_PLANE -> "Detector-plane spacing (${calib.rowSpacingMm} mm/px). Anatomical magnification is not calibrated."
                    CalibrationState.NONE -> "Physical measurements disabled: pixel units (px) only."
                },
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }

    Text("TOOL PALETTE", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        val toolLabels = listOf(
            AnnotationTool.PAN_ZOOM to "Pan/Zoom",
            AnnotationTool.WINDOW_LEVEL to "W/L Drag",
            AnnotationTool.TEXT_NOTE to "Text Note",
            AnnotationTool.ARROW to "Arrow",
            AnnotationTool.FREEHAND to "Freehand",
            AnnotationTool.LENGTH to "Length",
            AnnotationTool.ANGLE to "Angle (3-pt)",
            AnnotationTool.ROI_BOX to "ROI Stats",
        )
        toolLabels.forEach { (tool, label) ->
            FilterChip(
                selected = activeTool == tool,
                onClick = { onSelectTool(tool) },
                label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                leadingIcon = if (activeTool == tool) {
                    { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                } else null,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("tool_chip_${tool.name}"),
            )
        }
    }

    Button(
        onClick = onExportDerivative,
        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("export_derivative_button"),
    ) {
        Icon(Icons.Filled.IosShare, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text("Export Reviewed Derivative")
    }

    HorizontalDivider(color = GraphiteBorder)
    Text("PATIENT-ISOLATED ANNOTATIONS (${annotations.size})", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)

    if (annotations.isEmpty()) {
        Text(
            "Select a markup/measurement tool above and draw on the radiograph. Stored separately in image pixel coordinates.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    } else {
        annotations.forEach { ann ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GraphiteCard),
                border = BorderStroke(1.dp, GraphiteBorder),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "${ann.type.name}: ${ann.measurementSummary.ifBlank { ann.text }}",
                            style = MaterialTheme.typography.titleSmall,
                            color = CyanOnContainer,
                        )
                        Text(
                            text = "${ann.authorName} • ${ann.createdAtIso.take(19).replace('T', ' ')}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = "Coord: ${ann.coordinateSystem} • Patient: ${ann.patientId}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(
                        onClick = { onDeleteAnnotation(ann) },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete annotation", tint = StatusCritical)
                    }
                }
            }
        }
    }
}

@Composable
private fun QualityReviewSection(
    activeStudy: ExaminationSummary?,
    existing: QualityChecklist?,
    automatedFlags: List<String>,
    onSaveQuality: (Boolean, Boolean, Boolean, Boolean, Boolean, Boolean, String) -> Unit,
) {
    if (activeStudy == null) {
        Text("Select and confirm an examination to record technical QA review.", style = MaterialTheme.typography.bodySmall)
        return
    }

    var positioning by remember(activeStudy.studyInstanceUid, existing) { mutableStateOf(existing?.positioningConcerns ?: false) }
    var motion by remember(activeStudy.studyInstanceUid, existing) { mutableStateOf(existing?.motionArtefact ?: false) }
    var coverage by remember(activeStudy.studyInstanceUid, existing) { mutableStateOf(existing?.incompleteFieldCoverage ?: false) }
    var orientation by remember(activeStudy.studyInstanceUid, existing) { mutableStateOf(existing?.missingOrientationInfo ?: (activeStudy.laterality == null)) }
    var processing by remember(activeStudy.studyInstanceUid, existing) { mutableStateOf(existing?.suspectedProcessingIssues ?: false) }
    var furtherReview by remember(activeStudy.studyInstanceUid, existing) { mutableStateOf(existing?.furtherReviewRequired ?: false) }
    var notes by remember(activeStudy.studyInstanceUid, existing) { mutableStateOf(existing?.technicalNotes ?: "") }

    Text("TECHNICAL IMAGE-QUALITY REVIEW", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
    Text(
        "Record technical observations separately from clinical reporting. Does not auto-recommend repeat exposure.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    if (automatedFlags.isNotEmpty()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = StatusWarningBg),
            border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.5f)),
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("NON-DIAGNOSTIC AUTOMATED CHECKS (LIMITATIONS APPLY)", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                automatedFlags.forEach { flag ->
                    Text("• $flag", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    QaCheckboxRow("Positioning concerns", positioning) { positioning = it }
    QaCheckboxRow("Motion artefact observed", motion) { motion = it }
    QaCheckboxRow("Incomplete anatomical field coverage", coverage) { coverage = it }
    QaCheckboxRow("Missing orientation / laterality metadata", orientation) { orientation = it }
    QaCheckboxRow("Suspected image-processing / LUT issue", processing) { processing = it }
    QaCheckboxRow("Further technical review required", furtherReview) { furtherReview = it }

    OutlinedTextField(
        value = notes,
        onValueChange = { notes = it },
        label = { Text("Technical QA Notes (Non-Diagnostic)") },
        minLines = 2,
        modifier = Modifier.fillMaxWidth().testTag("qa_notes_input"),
    )

    Button(
        onClick = { onSaveQuality(positioning, motion, coverage, orientation, processing, furtherReview, notes) },
        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("save_qa_button"),
    ) {
        Text("Save Technical QA Review")
    }

    if (existing?.reviewedAtIso != null) {
        Text(
            text = "Last QA by ${existing.reviewerName} at ${existing.reviewedAtIso.take(19).replace('T', ' ')}",
            style = MaterialTheme.typography.labelSmall,
            color = StatusVerified,
        )
    }
}

@Composable
private fun QaCheckboxRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ClinicalReportSection(
    activeStudy: ExaminationSummary?,
    report: ClinicalReport?,
    onSaveDraft: (String, String, Boolean) -> Unit,
    onSignReport: (String, String) -> Unit,
    onAddAmendment: (String, String) -> Unit,
) {
    if (activeStudy == null) {
        Text("Confirm and open an examination to author notes or clinical reports.", style = MaterialTheme.typography.bodySmall)
        return
    }

    var techComment by remember(activeStudy.studyInstanceUid, report?.version) { mutableStateOf(report?.technicalComment ?: "") }
    var clinicalText by remember(activeStudy.studyInstanceUid, report?.version) { mutableStateOf(report?.clinicalInterpretation ?: "") }
    var amendReason by remember { mutableStateOf("") }
    var amendText by remember { mutableStateOf("") }

    LaunchedEffect(report) {
        if (report != null) {
            techComment = report.technicalComment
            clinicalText = report.clinicalInterpretation
        }
    }

    val isSignedOrAmended = report?.status == ReportStatus.SIGNED || report?.status == ReportStatus.AMENDED

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("NOTES & REPORTING", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
        StatusChip(
            text = "${report?.status?.label ?: "Unreported"} (v${report?.version ?: 0})",
            fg = if (isSignedOrAmended) StatusVerified else CyanOnContainer,
            bg = GraphiteCard,
        )
    }

    Text(
        "Technical observations and clinical interpretation are stored in separate fields. Human clinician authorship only (no autonomous AI diagnosis).",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    OutlinedTextField(
        value = techComment,
        onValueChange = { techComment = it },
        enabled = !isSignedOrAmended,
        label = { Text("Technical Comment (Exposure / Acquisition)") },
        minLines = 2,
        modifier = Modifier.fillMaxWidth().testTag("report_technical_input"),
    )

    OutlinedTextField(
        value = clinicalText,
        onValueChange = { clinicalText = it },
        enabled = !isSignedOrAmended,
        label = { Text("Clinical Interpretation / Findings") },
        minLines = 4,
        modifier = Modifier.fillMaxWidth().testTag("report_clinical_input"),
    )

    if (!isSignedOrAmended) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { onSaveDraft(techComment, clinicalText, false) },
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("save_draft_report_button"),
            ) {
                Text("Save Draft")
            }
            OutlinedButton(
                onClick = { onSaveDraft(techComment, clinicalText, true) },
                modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
            ) {
                Text("For Review")
            }
        }
        Button(
            onClick = { onSignReport(techComment, clinicalText) },
            enabled = clinicalText.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("sign_report_button"),
        ) {
            Text("Sign Report Electronically")
        }
    } else {
        Text(
            text = "Signed by ${report?.signedBy} at ${report?.signedAtIso?.take(19)?.replace('T', ' ')}. Direct editing locked.",
            style = MaterialTheme.typography.labelSmall,
            color = StatusVerified,
        )
        HorizontalDivider(color = GraphiteBorder)
        Text("ADD LINKED AMENDMENT", style = MaterialTheme.typography.labelMedium, color = StatusWarning)
        OutlinedTextField(
            value = amendReason,
            onValueChange = { amendReason = it },
            label = { Text("Amendment Reason") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("amendment_reason_input"),
        )
        OutlinedTextField(
            value = amendText,
            onValueChange = { amendText = it },
            label = { Text("Amendment Text") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth().testTag("amendment_text_input"),
        )
        Button(
            onClick = {
                onAddAmendment(amendReason, amendText)
                amendReason = ""
                amendText = ""
            },
            enabled = amendReason.isNotBlank() && amendText.isNotBlank(),
            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("submit_amendment_button"),
        ) {
            Text("Append Linked Amendment")
        }
    }

    if (!report?.amendments.isNullOrEmpty()) {
        HorizontalDivider(color = GraphiteBorder)
        Text("LINKED AMENDMENTS", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
        report?.amendments?.forEach { am ->
            Card(colors = CardDefaults.cardColors(containerColor = GraphiteCard)) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${am.reason} • ${am.authorName}", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                    Text(am.amendmentText, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    if (!report?.versionHistory.isNullOrEmpty()) {
        HorizontalDivider(color = GraphiteBorder)
        Text("VERSION HISTORY", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
        report?.versionHistory?.reversed()?.forEach { v ->
            Text(
                text = "v${v.version} [${v.status.label}] ${v.authorName} • ${v.summary}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ArchiveAndAuditSection(
    preferences: WorkstationPreferences,
    auditEvents: List<AuditEvent>,
    dicomWebQueryResults: List<DicomWebStudyEntry>,
    activeStudy: ExaminationSummary?,
    onQueryDicomWeb: (Boolean) -> Unit,
    onRetrieveDicomWebEntry: (DicomWebStudyEntry, Boolean) -> Unit,
    onSimulateConflict: () -> Unit,
    onPurgeCache: () -> Unit,
    onClearAndReseed: () -> Unit,
    onUpdateEndpointsAndPolicy: (String, String, Int) -> Unit,
) {
    var backendUrl by remember(preferences.backendBaseUrl) { mutableStateOf(preferences.backendBaseUrl) }
    var dicomWebUrl by remember(preferences.dicomWebBaseUrl) { mutableStateOf(preferences.dicomWebBaseUrl) }
    var retentionStr by remember(preferences.retentionHours) { mutableStateOf(preferences.retentionHours.toString()) }

    Text("DICOMWEB ARCHIVE ADAPTER (QIDO-RS / WADO-RS)", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
    OutlinedTextField(
        value = backendUrl,
        onValueChange = { backendUrl = it },
        label = { Text("FastAPI Backend URL") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    OutlinedTextField(
        value = dicomWebUrl,
        onValueChange = { dicomWebUrl = it },
        label = { Text("DICOMweb Base URL") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    OutlinedTextField(
        value = retentionStr,
        onValueChange = { retentionStr = it.filter { ch -> ch.isDigit() } },
        label = { Text("Cache Retention (Hours)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { onUpdateEndpointsAndPolicy(backendUrl, dicomWebUrl, retentionStr.toIntOrNull() ?: 168) },
            modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
        ) {
            Text("Save Config")
        }
        Button(
            onClick = { onQueryDicomWeb(true) },
            colors = ButtonDefaults.buttonColors(containerColor = CyanContainer, contentColor = CyanOnContainer),
            modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("qido_local_button"),
        ) {
            Text("QIDO Local")
        }
    }
    OutlinedButton(
        onClick = { onQueryDicomWeb(false) },
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
    ) {
        Text("Query Remote DICOMweb Endpoint")
    }

    dicomWebQueryResults.forEach { entry ->
        Card(colors = CardDefaults.cardColors(containerColor = GraphiteCard), border = BorderStroke(1.dp, GraphiteBorder)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(entry.description, style = MaterialTheme.typography.bodySmall)
                    Text("${entry.patientId} • ${entry.sourceLabel}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(
                    onClick = { onRetrieveDicomWebEntry(entry, entry.sourceLabel == "Local Test Archive") },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                    Icon(Icons.Filled.Download, contentDescription = "Retrieve via WADO-RS", tint = CyanPrimary)
                }
            }
        }
    }

    HorizontalDivider(color = GraphiteBorder)
    Text("CACHE & CONFLICT CONTROLS", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = onPurgeCache,
            modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("purge_cache_button"),
        ) {
            Text("Purge Expired")
        }
        OutlinedButton(
            onClick = onClearAndReseed,
            modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
        ) {
            Text("Reset Demo Cache")
        }
    }
    if (activeStudy != null) {
        OutlinedButton(
            onClick = onSimulateConflict,
            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("simulate_conflict_button"),
        ) {
            Text("Simulate Sync Conflict on Active Study")
        }
    }

    HorizontalDivider(color = GraphiteBorder)
    Text("IMMUTABLE AUDIT TRAIL (${auditEvents.size})", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
    auditEvents.take(30).forEach { ev ->
        Card(
            colors = CardDefaults.cardColors(containerColor = GraphiteCard),
            border = BorderStroke(0.5.dp, GraphiteBorder),
        ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(ev.action, style = MaterialTheme.typography.labelSmall, color = CyanPrimary)
                    Text(ev.timestampIso.take(19).replace('T', ' '), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${ev.actorName} (${ev.actorRole})", style = MaterialTheme.typography.labelSmall)
                Text(ev.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
