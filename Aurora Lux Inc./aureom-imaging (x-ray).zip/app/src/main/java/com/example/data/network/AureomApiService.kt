package com.example.data.network

import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class LoginRequestDto(
    val username: String,
    val passcode: String,
)

@JsonClass(generateAdapter = true)
data class LoginResponseDto(
    val access_token: String,
    val token_type: String,
    val user_id: String,
    val display_name: String,
    val role: String,
)

@JsonClass(generateAdapter = true)
data class StudyDto(
    val study_instance_uid: String,
    val sop_instance_uid: String,
    val patient_id: String,
    val patient_id_issuer: String,
    val patient_name: String,
    val accession_number: String,
    val description: String,
    val acquisition_date_time: String,
    val modality: String,
    val body_part: String,
    val view_or_projection: String?,
    val laterality: String?,
    val source_system: String,
    val acquisition_status: String,
    val receipt_status: String,
    val quality_status: String,
    val report_status: String,
    val sha256_checksum: String?,
)

@JsonClass(generateAdapter = true)
data class AnnotationSyncDto(
    val id: String,
    val patient_id: String,
    val study_instance_uid: String,
    val sop_instance_uid: String,
    val type: String,
    val points_json: String,
    val text: String,
    val author_id: String,
    val author_name: String,
    val coordinate_system: String,
    val measurement_summary: String,
    val version: Int,
)

@JsonClass(generateAdapter = true)
data class ReportSyncDto(
    val study_instance_uid: String,
    val patient_id: String,
    val technical_comment: String,
    val clinical_interpretation: String,
    val status: String,
    val version: Int,
)

@JsonClass(generateAdapter = true)
data class AuditEventDto(
    val id: String,
    val timestamp_iso: String,
    val actor_id: String,
    val actor_name: String,
    val actor_role: String,
    val action: String,
    val patient_id: String?,
    val study_instance_uid: String?,
    val sop_instance_uid: String?,
    val details: String,
)

interface AureomApiService {
    @POST("api/v1/auth/login")
    suspend fun login(@Body body: LoginRequestDto): Response<LoginResponseDto>

    @GET("api/v1/studies")
    suspend fun listStudies(@Header("Authorization") bearer: String): Response<List<StudyDto>>

    @POST("api/v1/annotations")
    suspend fun upsertAnnotation(
        @Header("Authorization") bearer: String,
        @Body body: AnnotationSyncDto,
    ): Response<AnnotationSyncDto>

    @POST("api/v1/studies/{studyUid}/report")
    suspend fun upsertReport(
        @Header("Authorization") bearer: String,
        @Path("studyUid") studyUid: String,
        @Body body: ReportSyncDto,
    ): Response<ReportSyncDto>

    @POST("api/v1/audit")
    suspend fun postAuditEvent(
        @Header("Authorization") bearer: String,
        @Body body: AuditEventDto,
    ): Response<AuditEventDto>
}

object AureomApiClientFactory {
    fun create(baseUrl: String): AureomApiService {
        val normalized = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .writeTimeout(6, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
        return Retrofit.Builder()
            .baseUrl(normalized)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(AureomApiService::class.java)
    }
}
