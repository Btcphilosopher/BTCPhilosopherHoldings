package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ColorErrorText = androidx.compose.ui.graphics.Color(0xFFFCA5A5)

private val AureomDarkColorScheme = darkColorScheme(
    primary = CyanPrimary,
    onPrimary = GraphiteAbyss,
    primaryContainer = CyanContainer,
    onPrimaryContainer = CyanOnContainer,
    secondary = ClinicalSlate,
    onSecondary = GraphiteAbyss,
    secondaryContainer = GraphiteElevated,
    onSecondaryContainer = ClinicalWhite,
    tertiary = StatusInfo,
    onTertiary = GraphiteAbyss,
    background = GraphiteBase,
    onBackground = ClinicalWhite,
    surface = GraphitePanel,
    onSurface = ClinicalWhite,
    surfaceVariant = GraphiteCard,
    onSurfaceVariant = ClinicalSlate,
    outline = GraphiteBorder,
    outlineVariant = GraphiteElevated,
    error = StatusCritical,
    onError = ClinicalWhite,
    errorContainer = StatusCriticalBg,
    onErrorContainer = ColorErrorText,
)

val AureomShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(12.dp),
)

@Composable
fun AureomImagingTheme(
    textScale: Float = 1.0f,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = AureomDarkColorScheme,
        typography = buildAureomTypography(textScale),
        shapes = AureomShapes,
        content = content,
    )
}
