package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cached_studies")
data class StudyCacheEntity(
    @PrimaryKey val studyInstanceUid: String,
    val sopInstanceUid: String,
    val patientId: String,
    val patientIdIssuer: String,
    val patientName: String,
    val accessionNumber: String,
    val description: String,
    val acquisitionDateTime: String,
    val modality: String,
    val bodyPart: String,
    val viewOrProjection: String?,
    val laterality: String?,
    val sourceSystem: String,
    val acquisitionStatus: String,
    val receiptStatus: String,
    val qualityStatus: String,
    val reportStatus: String,
    val syncState: String,
    val downloadedAtIso: String?,
    val lastAccessedEpochMs: Long,
    val isNonDicom: Boolean,
    val transferProgressPercent: Int,
    val transferErrorMessage: String?,
    val priorStudyUid: String?,
    val originalFilePath: String,
    val originalSha256: String,
    val metadataJson: String,
)

@Entity(tableName = "annotations")
data class AnnotationEntity(
    @PrimaryKey val id: String,
    val patientId: String,
    val studyInstanceUid: String,
    val sopInstanceUid: String,
    val type: String,
    val pointsJson: String,
    val text: String,
    val authorId: String,
    val authorName: String,
    val createdAtIso: String,
    val updatedAtIso: String,
    val coordinateSystem: String,
    val measurementSummary: String,
    val roiStatsJson: String?,
    val syncState: String,
    val version: Int,
)

@Entity(tableName = "quality_reviews")
data class QualityReviewEntity(
    @PrimaryKey val studyInstanceUid: String,
    val sopInstanceUid: String,
    val positioningConcerns: Boolean,
    val motionArtefact: Boolean,
    val incompleteFieldCoverage: Boolean,
    val missingOrientationInfo: Boolean,
    val suspectedProcessingIssues: Boolean,
    val furtherReviewRequired: Boolean,
    val technicalNotes: String,
    val reviewerName: String,
    val reviewedAtIso: String?,
    val automatedFlagsJson: String,
)

@Entity(tableName = "clinical_reports")
data class ReportEntity(
    @PrimaryKey val studyInstanceUid: String,
    val patientId: String,
    val technicalComment: String,
    val clinicalInterpretation: String,
    val status: String,
    val authorId: String,
    val authorName: String,
    val updatedAtIso: String,
    val signedBy: String?,
    val signedAtIso: String?,
    val version: Int,
    val syncState: String,
    val amendmentsJson: String,
    val versionHistoryJson: String,
)

@Entity(tableName = "audit_events")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestampIso: String,
    val epochMs: Long,
    val actorId: String,
    val actorName: String,
    val actorRole: String,
    val action: String,
    val patientId: String?,
    val studyInstanceUid: String?,
    val sopInstanceUid: String?,
    val details: String,
)

@Dao
interface StudyCacheDao {
    @Query("SELECT * FROM cached_studies ORDER BY acquisitionDateTime DESC")
    fun observeAll(): Flow<List<StudyCacheEntity>>

    @Query("SELECT * FROM cached_studies")
    suspend fun getAll(): List<StudyCacheEntity>

    @Query("SELECT * FROM cached_studies WHERE studyInstanceUid = :studyUid LIMIT 1")
    suspend fun getByStudyUid(studyUid: String): StudyCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: StudyCacheEntity)

    @Query("DELETE FROM cached_studies WHERE studyInstanceUid = :studyUid")
    suspend fun deleteByStudyUid(studyUid: String)

    @Query("DELETE FROM cached_studies WHERE lastAccessedEpochMs < :cutoffEpochMs")
    suspend fun deleteOlderThan(cutoffEpochMs: Long): Int
}

@Dao
interface AnnotationDao {
    @Query("SELECT * FROM annotations WHERE studyInstanceUid = :studyUid AND patientId = :patientId ORDER BY createdAtIso ASC")
    fun observeForStudy(studyUid: String, patientId: String): Flow<List<AnnotationEntity>>

    @Query("SELECT * FROM annotations WHERE studyInstanceUid = :studyUid")
    suspend fun getForStudy(studyUid: String): List<AnnotationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AnnotationEntity)

    @Query("DELETE FROM annotations WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM annotations WHERE studyInstanceUid = :studyUid")
    suspend fun deleteForStudy(studyUid: String)
}

@Dao
interface QualityReviewDao {
    @Query("SELECT * FROM quality_reviews WHERE studyInstanceUid = :studyUid LIMIT 1")
    fun observeForStudy(studyUid: String): Flow<QualityReviewEntity?>

    @Query("SELECT * FROM quality_reviews WHERE studyInstanceUid = :studyUid LIMIT 1")
    suspend fun getForStudy(studyUid: String): QualityReviewEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: QualityReviewEntity)
}

@Dao
interface ReportDao {
    @Query("SELECT * FROM clinical_reports WHERE studyInstanceUid = :studyUid LIMIT 1")
    fun observeForStudy(studyUid: String): Flow<ReportEntity?>

    @Query("SELECT * FROM clinical_reports WHERE studyInstanceUid = :studyUid LIMIT 1")
    suspend fun getForStudy(studyUid: String): ReportEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ReportEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_events ORDER BY epochMs DESC LIMIT 250")
    fun observeRecent(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: AuditLogEntity)
}

@Database(
    entities = [
        StudyCacheEntity::class,
        AnnotationEntity::class,
        QualityReviewEntity::class,
        ReportEntity::class,
        AuditLogEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun studyCacheDao(): StudyCacheDao
    abstract fun annotationDao(): AnnotationDao
    abstract fun qualityReviewDao(): QualityReviewDao
    abstract fun reportDao(): ReportDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getInstance(context: Context): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_workstation.db",
                ).build().also { INSTANCE = it }
            }
        }
    }
}
