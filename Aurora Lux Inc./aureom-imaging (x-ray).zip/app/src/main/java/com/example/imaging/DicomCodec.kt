package com.example.imaging

import com.example.domain.model.CalibrationState
import com.example.domain.model.ExaminationMetadata
import com.example.domain.model.PhotometricInterpretation
import com.example.domain.model.PixelSpacingInfo
import com.example.domain.model.RadiographPixelData
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

sealed class DicomParseResult {
    data class Success(
        val pixelData: RadiographPixelData,
        val metadata: ExaminationMetadata,
    ) : DicomParseResult()

    data class Unsupported(
        val reason: String,
        val transferSyntaxUid: String? = null,
        val errorCode: String,
    ) : DicomParseResult()
}

data class DicomWriteRequest(
    val width: Int,
    val height: Int,
    val bitsAllocated: Int = 16,
    val bitsStored: Int = 12,
    val pixelRepresentation: Int = 0,
    val photometric: PhotometricInterpretation = PhotometricInterpretation.MONOCHROME2,
    val rescaleSlope: Double = 1.0,
    val rescaleIntercept: Double = 0.0,
    val windowCenter: Double = 2048.0,
    val windowWidth: Double = 2600.0,
    val rawPixels: IntArray,
    val patientId: String,
    val patientIdIssuer: String,
    val patientName: String,
    val studyInstanceUid: String,
    val seriesInstanceUid: String,
    val sopInstanceUid: String,
    val accessionNumber: String,
    val studyDescription: String,
    val acquisitionDate: String,
    val acquisitionTime: String,
    val modality: String,
    val bodyPart: String,
    val viewPosition: String? = null,
    val laterality: String? = null,
    val stationName: String = "AUREOM-DR-SUITE-01",
    val manufacturer: String = "Aureom Medical Systems",
    val pixelSpacingMm: Pair<Double, Double>? = null,
    val imagerPixelSpacingMm: Pair<Double, Double>? = null,
    val transferSyntaxUid: String = DicomCodec.TS_EXPLICIT_VR_LE,
)

object DicomCodec {
    const val TS_IMPLICIT_VR_LE = "1.2.840.10008.1.2"
    const val TS_EXPLICIT_VR_LE = "1.2.840.10008.1.2.1"
    const val TS_EXPLICIT_VR_BE = "1.2.840.10008.1.2.2"
    const val TS_JPEG_BASELINE = "1.2.840.10008.1.2.4.50"
    const val TS_JPEG_2000_LOSSLESS = "1.2.840.10008.1.2.4.90"
    const val TS_JPEG_2000 = "1.2.840.10008.1.2.4.91"
    const val TS_RLE_LOSSLESS = "1.2.840.10008.1.2.5"

    private val LONG_EXPLICIT_VRS = setOf("OB", "OD", "OF", "OL", "OW", "SQ", "UC", "UN", "UR", "UT")

    fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun parseDicomBytes(
        bytes: ByteArray,
        sourceSystem: String = "DICOM-IMPORT",
        originalFilePath: String = "",
    ): DicomParseResult {
        if (bytes.size < 132) {
            return DicomParseResult.Unsupported(
                reason = "File is smaller than 132 bytes and cannot be a valid DICOM Part 10 object.",
                errorCode = "ERR_NOT_DICOM_TOO_SHORT",
            )
        }
        val magic = String(bytes, 128, 4, StandardCharsets.US_ASCII)
        if (magic != "DICM") {
            return DicomParseResult.Unsupported(
                reason = "Missing DICOM Part 10 'DICM' preamble signature. Use PNG/JPEG importer for standard raster files.",
                errorCode = "ERR_MISSING_DICM_PREAMBLE",
            )
        }

        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 132

        val stringTags = mutableMapOf<Int, String>()
        val intTags = mutableMapOf<Int, Int>()
        var pixelDataOffset = -1
        var pixelDataLength = 0
        var transferSyntaxUid = TS_EXPLICIT_VR_LE
        var inMetaGroup = true

        while (pos + 8 <= bytes.size) {
            val group = buffer.getShort(pos).toInt() and 0xFFFF
            val element = buffer.getShort(pos + 2).toInt() and 0xFFFF
            val tag = (group shl 16) or element

            if (group != 0x0002 && inMetaGroup) {
                inMetaGroup = false
                transferSyntaxUid = stringTags[0x00020010]?.trim()?.trimEnd('\u0000') ?: TS_EXPLICIT_VR_LE
                when (transferSyntaxUid) {
                    TS_EXPLICIT_VR_LE, TS_IMPLICIT_VR_LE -> Unit
                    TS_EXPLICIT_VR_BE -> {
                        return DicomParseResult.Unsupported(
                            reason = "Unsupported Transfer Syntax: Explicit VR Big Endian ($transferSyntaxUid). Only Little Endian uncompressed DICOM is supported in this build.",
                            transferSyntaxUid = transferSyntaxUid,
                            errorCode = "ERR_UNSUPPORTED_TRANSFER_SYNTAX_BE",
                        )
                    }
                    TS_JPEG_2000_LOSSLESS, TS_JPEG_2000 -> {
                        return DicomParseResult.Unsupported(
                            reason = "Unsupported compressed Transfer Syntax: JPEG 2000 ($transferSyntaxUid). Decode to Explicit VR Little Endian at the archive gateway before mobile receipt.",
                            transferSyntaxUid = transferSyntaxUid,
                            errorCode = "ERR_UNSUPPORTED_J2K",
                        )
                    }
                    TS_JPEG_BASELINE -> {
                        return DicomParseResult.Unsupported(
                            reason = "Unsupported compressed Transfer Syntax: JPEG Lossy Baseline ($transferSyntaxUid).",
                            transferSyntaxUid = transferSyntaxUid,
                            errorCode = "ERR_UNSUPPORTED_JPEG",
                        )
                    }
                    TS_RLE_LOSSLESS -> {
                        return DicomParseResult.Unsupported(
                            reason = "Unsupported compressed Transfer Syntax: RLE Lossless ($transferSyntaxUid).",
                            transferSyntaxUid = transferSyntaxUid,
                            errorCode = "ERR_UNSUPPORTED_RLE",
                        )
                    }
                    else -> {
                        if (!transferSyntaxUid.startsWith("1.2.840.10008.1.2")) {
                            return DicomParseResult.Unsupported(
                                reason = "Unsupported DICOM Transfer Syntax UID: $transferSyntaxUid",
                                transferSyntaxUid = transferSyntaxUid,
                                errorCode = "ERR_UNSUPPORTED_TS",
                            )
                        }
                    }
                }
            }

            val useExplicit = inMetaGroup || transferSyntaxUid == TS_EXPLICIT_VR_LE

            var vr = "UN"
            var valueLength: Int
            var valueOffset: Int

            if (useExplicit) {
                vr = String(bytes, pos + 4, 2, StandardCharsets.US_ASCII)
                if (vr in LONG_EXPLICIT_VRS) {
                    if (pos + 12 > bytes.size) break
                    valueLength = buffer.getInt(pos + 8)
                    valueOffset = pos + 12
                } else {
                    valueLength = buffer.getShort(pos + 6).toInt() and 0xFFFF
                    valueOffset = pos + 8
                }
            } else {
                valueLength = buffer.getInt(pos + 4)
                valueOffset = pos + 8
                vr = guessImplicitVr(tag)
            }

            // Undefined length (0xFFFFFFFF) e.g. encapsulated pixel data or sequences
            if (valueLength == -1) {
                if (tag == 0x7FE00010) {
                    return DicomParseResult.Unsupported(
                        reason = "Encapsulated/compressed PixelData (undefined length) is not supported for Transfer Syntax $transferSyntaxUid.",
                        transferSyntaxUid = transferSyntaxUid,
                        errorCode = "ERR_ENCAPSULATED_PIXEL_DATA",
                    )
                }
                return DicomParseResult.Unsupported(
                    reason = "Undefined-length DICOM sequences are not supported in this lightweight parser.",
                    transferSyntaxUid = transferSyntaxUid,
                    errorCode = "ERR_UNDEFINED_LENGTH",
                )
            }

            if (valueLength < 0 || valueOffset + valueLength > bytes.size) {
                return DicomParseResult.Unsupported(
                    reason = "Corrupted or truncated DICOM element at tag (0x${tag.toString(16)}).",
                    transferSyntaxUid = transferSyntaxUid,
                    errorCode = "ERR_TRUNCATED_ELEMENT",
                )
            }

            if (tag == 0x7FE00010) {
                pixelDataOffset = valueOffset
                pixelDataLength = valueLength
                break
            }

            when (vr) {
                "US" -> if (valueLength >= 2) intTags[tag] = buffer.getShort(valueOffset).toInt() and 0xFFFF
                "SS" -> if (valueLength >= 2) intTags[tag] = buffer.getShort(valueOffset).toInt()
                "UL" -> if (valueLength >= 4) intTags[tag] = buffer.getInt(valueOffset)
                else -> {
                    val text = String(bytes, valueOffset, valueLength, StandardCharsets.UTF_8)
                        .trimEnd('\u0000', ' ')
                    stringTags[tag] = text
                }
            }

            pos = valueOffset + valueLength
        }

        if (pixelDataOffset < 0 || pixelDataLength <= 0) {
            return DicomParseResult.Unsupported(
                reason = "DICOM file contains no uncompressed PixelData (7FE0,0010).",
                transferSyntaxUid = transferSyntaxUid,
                errorCode = "ERR_NO_PIXEL_DATA",
            )
        }

        val rows = intTags[0x00280010] ?: 0
        val cols = intTags[0x00280011] ?: 0
        val samplesPerPixel = intTags[0x00280002] ?: 1
        val bitsAllocated = intTags[0x00280100] ?: 16
        val bitsStored = intTags[0x00280101] ?: bitsAllocated
        val pixelRepresentation = intTags[0x00280103] ?: 0

        if (rows <= 0 || cols <= 0 || rows > 4096 || cols > 4096) {
            return DicomParseResult.Unsupported(
                reason = "Invalid or unsupported image dimensions: ${cols}x${rows}.",
                transferSyntaxUid = transferSyntaxUid,
                errorCode = "ERR_INVALID_DIMENSIONS",
            )
        }
        if (samplesPerPixel != 1) {
            return DicomParseResult.Unsupported(
                reason = "Unsupported SamplesPerPixel=$samplesPerPixel. Only single-plane monochrome radiographs are supported for DICOM.",
                transferSyntaxUid = transferSyntaxUid,
                errorCode = "ERR_UNSUPPORTED_SAMPLES_PER_PIXEL",
            )
        }
        if (bitsAllocated != 8 && bitsAllocated != 16) {
            return DicomParseResult.Unsupported(
                reason = "Unsupported BitsAllocated=$bitsAllocated (supported: 8 or 16).",
                transferSyntaxUid = transferSyntaxUid,
                errorCode = "ERR_UNSUPPORTED_BIT_DEPTH",
            )
        }

        val expectedBytes = rows * cols * (bitsAllocated / 8)
        if (pixelDataLength < expectedBytes) {
            return DicomParseResult.Unsupported(
                reason = "PixelData length ($pixelDataLength bytes) is smaller than expected ($expectedBytes bytes).",
                transferSyntaxUid = transferSyntaxUid,
                errorCode = "ERR_TRUNCATED_PIXEL_DATA",
            )
        }

        val totalPixels = rows * cols
        val rawPixels = IntArray(totalPixels)
        val mask = if (bitsStored >= 31) -1 else ((1 shl bitsStored) - 1)
        val signBit = 1 shl (bitsStored - 1)

        if (bitsAllocated == 8) {
            for (i in 0 until totalPixels) {
                val v = bytes[pixelDataOffset + i].toInt() and 0xFF
                rawPixels[i] = if (pixelRepresentation == 1 && (v and 0x80) != 0) v - 256 else v
            }
        } else {
            val pxBuf = ByteBuffer.wrap(bytes, pixelDataOffset, expectedBytes)
                .slice()
                .order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until totalPixels) {
                val unsignedVal = pxBuf.getShort(i * 2).toInt() and 0xFFFF and mask
                rawPixels[i] = if (pixelRepresentation == 1 && (unsignedVal and signBit) != 0) {
                    unsignedVal - (1 shl bitsStored)
                } else {
                    unsignedVal
                }
            }
        }

        val photoStr = stringTags[0x00280004]?.trim()?.uppercase() ?: "MONOCHROME2"
        val photometric = when (photoStr) {
            "MONOCHROME1" -> PhotometricInterpretation.MONOCHROME1
            "MONOCHROME2" -> PhotometricInterpretation.MONOCHROME2
            else -> return DicomParseResult.Unsupported(
                reason = "Unsupported PhotometricInterpretation '$photoStr'. Radiographs must be MONOCHROME1 or MONOCHROME2.",
                transferSyntaxUid = transferSyntaxUid,
                errorCode = "ERR_UNSUPPORTED_PHOTOMETRIC",
            )
        }

        val rescaleSlope = stringTags[0x00281053]?.split('\\')?.firstOrNull()?.toDoubleOrNull() ?: 1.0
        val rescaleIntercept = stringTags[0x00281052]?.split('\\')?.firstOrNull()?.toDoubleOrNull() ?: 0.0

        val minRaw = rawPixels.minOrNull() ?: 0
        val maxRaw = rawPixels.maxOrNull() ?: ((1 shl bitsStored) - 1)
        val autoCenter = ((minRaw + maxRaw) / 2.0) * rescaleSlope + rescaleIntercept
        val autoWidth = ((maxRaw - minRaw).coerceAtLeast(1) * rescaleSlope)

        val windowCenter = stringTags[0x00281050]?.split('\\')?.firstOrNull()?.toDoubleOrNull() ?: autoCenter
        val windowWidth = (stringTags[0x00281051]?.split('\\')?.firstOrNull()?.toDoubleOrNull() ?: autoWidth)
            .coerceAtLeast(1.0)

        val pixelSpacing = parseSpacingPair(stringTags[0x00280030])
        val imagerSpacing = parseSpacingPair(stringTags[0x00181164])
        val spacingInfo = when {
            pixelSpacing != null -> PixelSpacingInfo(
                rowSpacingMm = pixelSpacing.first,
                colSpacingMm = pixelSpacing.second,
                calibrationState = CalibrationState.ANATOMICAL_CALIBRATED,
                sourceTag = "(0028,0030) PixelSpacing",
            )
            imagerSpacing != null -> PixelSpacingInfo(
                rowSpacingMm = imagerSpacing.first,
                colSpacingMm = imagerSpacing.second,
                calibrationState = CalibrationState.DETECTOR_PLANE,
                sourceTag = "(0018,1164) ImagerPixelSpacing",
            )
            else -> PixelSpacingInfo(
                rowSpacingMm = null,
                colSpacingMm = null,
                calibrationState = CalibrationState.NONE,
                sourceTag = "Missing both (0028,0030) and (0018,1164)",
            )
        }

        val acqDate = stringTags[0x00080022] ?: stringTags[0x00080020] ?: ""
        val acqTime = stringTags[0x00080032] ?: stringTags[0x00080030] ?: ""
        val formattedDateTime = formatDicomDateTime(acqDate, acqTime)

        val laterality = stringTags[0x00200062]?.takeIf { it.isNotBlank() }
            ?: stringTags[0x00200060]?.takeIf { it.isNotBlank() }
        val viewPos = stringTags[0x00185101]?.takeIf { it.isNotBlank() }

        val metadata = ExaminationMetadata(
            studyInstanceUid = stringTags[0x0020000D]?.takeIf { it.isNotBlank() } ?: "1.2.826.0.1.3680043.8.498.UNKNOWN",
            seriesInstanceUid = stringTags[0x0020000E]?.takeIf { it.isNotBlank() } ?: "1.2.826.0.1.3680043.8.498.SERIES.1",
            sopInstanceUid = stringTags[0x00080018]?.takeIf { it.isNotBlank() } ?: "1.2.826.0.1.3680043.8.498.SOP.1",
            accessionNumber = stringTags[0x00080050]?.takeIf { it.isNotBlank() } ?: "Not supplied",
            patientId = stringTags[0x00100020]?.takeIf { it.isNotBlank() } ?: "Not supplied",
            patientIdIssuer = stringTags[0x00100021]?.takeIf { it.isNotBlank() } ?: "Not supplied",
            patientName = stringTags[0x00100010]?.replace('^', ' ')?.trim()?.takeIf { it.isNotBlank() } ?: "Not supplied",
            examinationDescription = stringTags[0x00081030]?.takeIf { it.isNotBlank() } ?: "Radiographic Study",
            acquisitionDateTime = formattedDateTime,
            modality = stringTags[0x00080060]?.takeIf { it.isNotBlank() } ?: "DX",
            bodyPart = stringTags[0x00180015]?.takeIf { it.isNotBlank() } ?: "Not supplied",
            viewOrProjection = viewPos,
            laterality = laterality,
            sourceSystem = stringTags[0x00081010]?.takeIf { it.isNotBlank() } ?: sourceSystem,
            imageProcessingHistory = listOf(
                "Original ${bitsStored}-bit ${photometric.dicomCode} pixel matrix preserved (${cols}x${rows})",
                "Modality LUT: slope=${rescaleSlope}, intercept=${rescaleIntercept}",
                "Display VOI LUT initialized at WC=${windowCenter.toInt()} / WW=${windowWidth.toInt()}",
            ),
            isNonDicomReference = false,
            spacingInfo = spacingInfo,
            transferSyntaxUid = transferSyntaxUid,
            originalSha256 = sha256Hex(bytes),
            originalFilePath = originalFilePath,
        )

        val pixelData = RadiographPixelData(
            width = cols,
            height = rows,
            bitsAllocated = bitsAllocated,
            bitsStored = bitsStored,
            pixelRepresentation = pixelRepresentation,
            photometric = photometric,
            rescaleSlope = rescaleSlope,
            rescaleIntercept = rescaleIntercept,
            defaultWindowCenter = windowCenter,
            defaultWindowWidth = windowWidth,
            rawPixels = rawPixels,
            isDicom = true,
            transferSyntaxUid = transferSyntaxUid,
        )

        return DicomParseResult.Success(pixelData, metadata)
    }

    fun writePart10Dicom(req: DicomWriteRequest): ByteArray {
        val out = ByteArrayOutputStream()
        // 128-byte preamble + DICM
        out.write(ByteArray(128))
        out.write("DICM".toByteArray(StandardCharsets.US_ASCII))

        // Build Group 0002 Meta Info first so we can write (0002,0000) group length
        val metaBody = ByteArrayOutputStream()
        writeExplicitTag(metaBody, 0x0002, 0x0001, "OB", byteArrayOf(0x00, 0x01))
        writeExplicitString(metaBody, 0x0002, 0x0002, "UI", "1.2.840.10008.5.1.4.1.1.1") // Digital X-Ray
        writeExplicitString(metaBody, 0x0002, 0x0003, "UI", req.sopInstanceUid)
        writeExplicitString(metaBody, 0x0002, 0x0010, "UI", req.transferSyntaxUid)
        writeExplicitString(metaBody, 0x0002, 0x0012, "UI", "1.2.826.0.1.3680043.8.498.1")
        writeExplicitString(metaBody, 0x0002, 0x0013, "SH", "AUREOM_GEN_1")

        val metaBytes = metaBody.toByteArray()
        val lenBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(metaBytes.size).array()
        writeExplicitTag(out, 0x0002, 0x0000, "UL", lenBuf)
        out.write(metaBytes)

        // Dataset tags in strictly ascending tag order
        writeExplicitString(out, 0x0008, 0x0016, "UI", "1.2.840.10008.5.1.4.1.1.1")
        writeExplicitString(out, 0x0008, 0x0018, "UI", req.sopInstanceUid)
        writeExplicitString(out, 0x0008, 0x0020, "DA", req.acquisitionDate)
        writeExplicitString(out, 0x0008, 0x0022, "DA", req.acquisitionDate)
        writeExplicitString(out, 0x0008, 0x0030, "TM", req.acquisitionTime)
        writeExplicitString(out, 0x0008, 0x0032, "TM", req.acquisitionTime)
        writeExplicitString(out, 0x0008, 0x0050, "SH", req.accessionNumber)
        writeExplicitString(out, 0x0008, 0x0060, "CS", req.modality)
        writeExplicitString(out, 0x0008, 0x0070, "LO", req.manufacturer)
        writeExplicitString(out, 0x0008, 0x1010, "SH", req.stationName)
        writeExplicitString(out, 0x0008, 0x1030, "LO", req.studyDescription)

        writeExplicitString(out, 0x0010, 0x0010, "PN", req.patientName)
        writeExplicitString(out, 0x0010, 0x0020, "LO", req.patientId)
        writeExplicitString(out, 0x0010, 0x0021, "LO", req.patientIdIssuer)

        writeExplicitString(out, 0x0018, 0x0015, "CS", req.bodyPart)
        req.imagerPixelSpacingMm?.let {
            writeExplicitString(out, 0x0018, 0x1164, "DS", "${it.first}\\${it.second}")
        }
        req.viewPosition?.let {
            writeExplicitString(out, 0x0018, 0x5101, "CS", it)
        }

        writeExplicitString(out, 0x0020, 0x000D, "UI", req.studyInstanceUid)
        writeExplicitString(out, 0x0020, 0x000E, "UI", req.seriesInstanceUid)
        req.laterality?.let {
            writeExplicitString(out, 0x0020, 0x0062, "CS", it)
        }

        writeExplicitUShort(out, 0x0028, 0x0002, 1)
        writeExplicitString(out, 0x0028, 0x0004, "CS", req.photometric.dicomCode)
        writeExplicitUShort(out, 0x0028, 0x0010, req.height)
        writeExplicitUShort(out, 0x0028, 0x0011, req.width)
        req.pixelSpacingMm?.let {
            writeExplicitString(out, 0x0028, 0x0030, "DS", "${it.first}\\${it.second}")
        }
        writeExplicitUShort(out, 0x0028, 0x0100, req.bitsAllocated)
        writeExplicitUShort(out, 0x0028, 0x0101, req.bitsStored)
        writeExplicitUShort(out, 0x0028, 0x0102, req.bitsStored - 1)
        writeExplicitUShort(out, 0x0028, 0x0103, req.pixelRepresentation)
        writeExplicitString(out, 0x0028, 0x1050, "DS", req.windowCenter.toInt().toString())
        writeExplicitString(out, 0x0028, 0x1051, "DS", req.windowWidth.toInt().toString())
        writeExplicitString(out, 0x0028, 0x1052, "DS", req.rescaleIntercept.toString())
        writeExplicitString(out, 0x0028, 0x1053, "DS", req.rescaleSlope.toString())

        // Pixel Data (7FE0,0010)
        val pxBytes = ByteArray(req.rawPixels.size * (req.bitsAllocated / 8))
        if (req.bitsAllocated == 8) {
            for (i in req.rawPixels.indices) {
                pxBytes[i] = (req.rawPixels[i] and 0xFF).toByte()
            }
            writeExplicitTag(out, 0x7FE0, 0x0010, "OB", pxBytes)
        } else {
            val pxBuf = ByteBuffer.wrap(pxBytes).order(ByteOrder.LITTLE_ENDIAN)
            for (i in req.rawPixels.indices) {
                pxBuf.putShort(i * 2, (req.rawPixels[i] and 0xFFFF).toShort())
            }
            writeExplicitTag(out, 0x7FE0, 0x0010, "OW", pxBytes)
        }

        return out.toByteArray()
    }

    private fun writeExplicitString(out: ByteArrayOutputStream, group: Int, element: Int, vr: String, value: String) {
        var bytes = value.toByteArray(StandardCharsets.UTF_8)
        if (bytes.size % 2 != 0) {
            val pad = if (vr == "UI") 0.toByte() else ' '.code.toByte()
            bytes += pad
        }
        writeExplicitTag(out, group, element, vr, bytes)
    }

    private fun writeExplicitUShort(out: ByteArrayOutputStream, group: Int, element: Int, value: Int) {
        val b = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(value.toShort()).array()
        writeExplicitTag(out, group, element, "US", b)
    }

    private fun writeExplicitTag(out: ByteArrayOutputStream, group: Int, element: Int, vr: String, payload: ByteArray) {
        val header = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
            .putShort(group.toShort())
            .putShort(element.toShort())
            .array()
        out.write(header)
        out.write(vr.toByteArray(StandardCharsets.US_ASCII))
        if (vr in LONG_EXPLICIT_VRS) {
            out.write(byteArrayOf(0, 0))
            out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(payload.size).array())
        } else {
            out.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(payload.size.toShort()).array())
        }
        out.write(payload)
    }

    private fun parseSpacingPair(raw: String?): Pair<Double, Double>? {
        if (raw.isNullOrBlank()) return null
        val parts = raw.split('\\')
        if (parts.size < 2) return null
        val row = parts[0].trim().toDoubleOrNull() ?: return null
        val col = parts[1].trim().toDoubleOrNull() ?: return null
        if (row <= 0.0 || col <= 0.0) return null
        return row to col
    }

    private fun formatDicomDateTime(date: String, time: String): String {
        val d = if (date.length >= 8) "${date.substring(0, 4)}-${date.substring(4, 6)}-${date.substring(6, 8)}" else "Not supplied"
        val t = if (time.length >= 4) "${time.substring(0, 2)}:${time.substring(2, 4)}" else ""
        return if (t.isNotEmpty() && d != "Not supplied") "$d $t" else d
    }

    private fun guessImplicitVr(tag: Int): String = when (tag) {
        0x00280002, 0x00280010, 0x00280011, 0x00280100, 0x00280101, 0x00280102, 0x00280103 -> "US"
        else -> "LO"
    }
}
