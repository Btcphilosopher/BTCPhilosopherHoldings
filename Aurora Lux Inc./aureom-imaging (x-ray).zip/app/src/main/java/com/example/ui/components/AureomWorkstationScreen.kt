package com.example.ui.components

import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GraphiteAbyss
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.GraphitePanel
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.CompactDestination
import com.example.ui.viewmodel.InspectorTab
import com.example.ui.viewmodel.WorkstationViewModel

@Composable
fun AureomWorkstationScreen(
    viewModel: WorkstationViewModel,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val studies by viewModel.studies.collectAsStateWithLifecycle()
    val annotations by viewModel.activeAnnotations.collectAsStateWithLifecycle()
    val qa by viewModel.activeQualityReview.collectAsStateWithLifecycle()
    val report by viewModel.activeReport.collectAsStateWithLifecycle()
    val auditEvents by viewModel.auditEvents.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.statusBannerMessage) {
        val msg = state.statusBannerMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBannerMessage()
        }
    }

    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            var displayName = "imported_file"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) {
                    displayName = cursor.getString(idx) ?: displayName
                }
            }
            viewModel.importDocument(uri, displayName)
        }
    }

    // 1. Auth Gate
    val session = state.session
    if (session == null) {
        AuthSignInScreen(
            isAuthenticating = state.isAuthenticating,
            authError = state.authError,
            backendBaseUrl = prefs.backendBaseUrl,
            onSignIn = viewModel::signIn,
        )
        return
    }

    // 2. Session Lock Overlay (obscures all PHI & radiographs)
    if (state.isSessionLocked) {
        SessionLockedOverlay(
            session = session,
            isAuthenticating = state.isAuthenticating,
            authError = state.authError,
            onUnlock = viewModel::unlockSession,
            onSignOut = viewModel::signOut,
        )
        return
    }

    // Dialogs
    state.pendingConfirmationStudy?.let { pending ->
        PatientConfirmationDialog(
            study = pending,
            onConfirm = { viewModel.confirmAndOpenStudy(pending) },
            onDismiss = viewModel::cancelStudyConfirmation,
        )
    }
    state.unsupportedDialog?.let { err ->
        UnsupportedErrorDialog(error = err, onDismiss = viewModel::dismissUnsupportedDialog)
    }
    if (state.pendingTextNotePoint != null) {
        TextNotePromptDialog(
            onCommit = viewModel::commitTextNote,
            onDismiss = viewModel::dismissTextNotePrompt,
        )
    }
    state.lastExportResult?.let { exportRes ->
        ExportResultDialog(result = exportRes, onDismiss = viewModel::dismissExportResult)
    }
    state.activeConflict?.let { conflict ->
        ConflictResolutionDialog(conflict = conflict, onResolve = viewModel::resolveSyncConflict)
    }

    Scaffold(
        containerColor = GraphiteAbyss,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            WorkstationTopBar(
                clinicianName = session.displayName,
                clinicianRole = session.role,
                authMode = session.authMode,
                textScale = prefs.textScale,
                onChangeTextScale = viewModel::updateTextScale,
                onLockSession = viewModel::lockSession,
                onSignOut = viewModel::signOut,
            )
        },
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            val isTabletLandscape = maxWidth >= 840.dp

            if (isTabletLandscape) {
                // 3-Pane Workstation: Worklist Left | Viewer Center | Tools Right
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .navigationBarsPadding(),
                ) {
                    WorklistPane(
                        studies = studies,
                        activeStudyUid = state.activeStudy?.studyInstanceUid,
                        equipmentState = state.equipmentState,
                        onSelectStudy = viewModel::requestOpenStudy,
                        onRetryTransfer = { uid -> viewModel.simulateEquipmentTransfer(uid, false) },
                        onSimulateIncomingAcquisition = { fail ->
                            val targetUid = if (fail) {
                                "1.2.826.0.1.3680043.8.498.4000.INTERRUPTED"
                            } else {
                                "1.2.826.0.1.3680043.8.498.5000.LIVE_${System.currentTimeMillis()}"
                            }
                            viewModel.simulateEquipmentTransfer(targetUid, fail)
                        },
                        onLaunchDocumentPicker = { documentPicker.launch(arrayOf("*/*")) },
                        onImportUnsupportedJ2kDemo = viewModel::importUnsupportedJ2kDemo,
                        onImportNonDicomPngDemo = viewModel::importNonDicomPngDemo,
                        onQueryLocalArchive = {
                            viewModel.selectInspectorTab(InspectorTab.ARCHIVE)
                            viewModel.queryDicomWebArchive(true)
                        },
                        modifier = Modifier
                            .width(305.dp)
                            .fillMaxHeight(),
                    )

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .fillMaxHeight()
                            .background(GraphiteBorder),
                    )

                    RadiographViewport(
                        activeStudy = state.activeStudy,
                        activePixels = state.activePixels,
                        activeBitmap = state.activeBitmap,
                        displaySettings = state.displaySettings,
                        annotations = annotations,
                        activeTool = state.activeTool,
                        draftPoints = state.draftPoints,
                        isComparisonMode = state.isComparisonMode,
                        comparisonStudy = state.comparisonStudy,
                        comparisonPixels = state.comparisonPixels,
                        comparisonBitmap = state.comparisonBitmap,
                        comparisonDisplaySettings = state.comparisonDisplaySettings,
                        syncComparisonView = state.syncComparisonView,
                        allStudies = studies,
                        onUpdateZoomPan = viewModel::updateZoomPan,
                        onUpdateWindowLevel = viewModel::updateWindowLevel,
                        onUpdateDraftPoints = viewModel::updateDraftPoints,
                        onCommitAnnotation = { type, pts -> viewModel.saveAnnotation(type, pts) },
                        onPromptTextNote = viewModel::promptTextNoteAt,
                        onResetView = viewModel::resetDisplayToDefault,
                        onToggleOverlays = viewModel::toggleOverlays,
                        onToggleComparison = viewModel::toggleComparisonMode,
                        onToggleSyncComparison = viewModel::toggleSyncComparisonView,
                        onSelectComparisonStudy = viewModel::selectComparisonStudy,
                        onRetryTransfer = { uid -> viewModel.simulateEquipmentTransfer(uid, false) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                    )

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .fillMaxHeight()
                            .background(GraphiteBorder),
                    )

                    ToolsInspectorPane(
                        selectedTab = state.inspectorTab,
                        onSelectTab = viewModel::selectInspectorTab,
                        activeStudy = state.activeStudy,
                        activePixels = state.activePixels,
                        displaySettings = state.displaySettings,
                        activeTool = state.activeTool,
                        annotations = annotations,
                        qualityChecklist = qa,
                        automatedTechnicalFlags = state.automatedTechnicalFlags,
                        report = report,
                        auditEvents = auditEvents,
                        preferences = prefs,
                        dicomWebQueryResults = state.dicomWebQueryResults,
                        onUpdateWindowLevel = viewModel::updateWindowLevel,
                        onUpdateZoomPan = viewModel::updateZoomPan,
                        onFitToScreen = viewModel::fitToScreen,
                        onRotateCw90 = viewModel::rotateCw90,
                        onFlipH = viewModel::flipHorizontal,
                        onFlipV = viewModel::flipVertical,
                        onToggleInvert = viewModel::toggleInvertGrayscale,
                        onResetView = viewModel::resetDisplayToDefault,
                        onSelectTool = viewModel::selectTool,
                        onDeleteAnnotation = viewModel::deleteAnnotation,
                        onExportDerivative = viewModel::exportReviewedDerivative,
                        onSaveQualityChecklist = viewModel::saveQualityChecklist,
                        onSaveReportDraft = viewModel::saveReportDraft,
                        onSignReport = viewModel::signReport,
                        onAddAmendment = viewModel::addReportAmendment,
                        onQueryDicomWeb = viewModel::queryDicomWebArchive,
                        onRetrieveDicomWebEntry = viewModel::retrieveDicomWebEntry,
                        onSimulateConflict = viewModel::triggerSyncConflictDemo,
                        onPurgeCache = viewModel::purgeExpiredCache,
                        onClearAndReseed = viewModel::clearAllAndReseedDemo,
                        onUpdateEndpointsAndPolicy = viewModel::updateEndpointsAndPolicy,
                        modifier = Modifier
                            .width(330.dp)
                            .fillMaxHeight(),
                    )
                }
            } else {
                // Adaptive Phone Layout with BackHandler returning to Worklist
                BackHandler(enabled = state.compactDestination != CompactDestination.WORKLIST) {
                    viewModel.selectCompactDestination(CompactDestination.WORKLIST)
                }

                Column(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                    ) {
                        when (state.compactDestination) {
                            CompactDestination.WORKLIST -> WorklistPane(
                                studies = studies,
                                activeStudyUid = state.activeStudy?.studyInstanceUid,
                                equipmentState = state.equipmentState,
                                onSelectStudy = viewModel::requestOpenStudy,
                                onRetryTransfer = { uid -> viewModel.simulateEquipmentTransfer(uid, false) },
                                onSimulateIncomingAcquisition = { fail ->
                                    val targetUid = if (fail) {
                                        "1.2.826.0.1.3680043.8.498.4000.INTERRUPTED"
                                    } else {
                                        "1.2.826.0.1.3680043.8.498.5000.LIVE_${System.currentTimeMillis()}"
                                    }
                                    viewModel.simulateEquipmentTransfer(targetUid, fail)
                                },
                                onLaunchDocumentPicker = { documentPicker.launch(arrayOf("*/*")) },
                                onImportUnsupportedJ2kDemo = viewModel::importUnsupportedJ2kDemo,
                                onImportNonDicomPngDemo = viewModel::importNonDicomPngDemo,
                                onQueryLocalArchive = {
                                    viewModel.selectCompactDestination(CompactDestination.SECURITY)
                                    viewModel.selectInspectorTab(InspectorTab.ARCHIVE)
                                    viewModel.queryDicomWebArchive(true)
                                },
                            )

                            CompactDestination.VIEWER -> RadiographViewport(
                                activeStudy = state.activeStudy,
                                activePixels = state.activePixels,
                                activeBitmap = state.activeBitmap,
                                displaySettings = state.displaySettings,
                                annotations = annotations,
                                activeTool = state.activeTool,
                                draftPoints = state.draftPoints,
                                isComparisonMode = state.isComparisonMode,
                                comparisonStudy = state.comparisonStudy,
                                comparisonPixels = state.comparisonPixels,
                                comparisonBitmap = state.comparisonBitmap,
                                comparisonDisplaySettings = state.comparisonDisplaySettings,
                                syncComparisonView = state.syncComparisonView,
                                allStudies = studies,
                                onUpdateZoomPan = viewModel::updateZoomPan,
                                onUpdateWindowLevel = viewModel::updateWindowLevel,
                                onUpdateDraftPoints = viewModel::updateDraftPoints,
                                onCommitAnnotation = { type, pts -> viewModel.saveAnnotation(type, pts) },
                                onPromptTextNote = viewModel::promptTextNoteAt,
                                onResetView = viewModel::resetDisplayToDefault,
                                onToggleOverlays = viewModel::toggleOverlays,
                                onToggleComparison = viewModel::toggleComparisonMode,
                                onToggleSyncComparison = viewModel::toggleSyncComparisonView,
                                onSelectComparisonStudy = viewModel::selectComparisonStudy,
                                onRetryTransfer = { uid -> viewModel.simulateEquipmentTransfer(uid, false) },
                            )

                            CompactDestination.TOOLS -> ToolsInspectorPane(
                                selectedTab = if (state.inspectorTab == InspectorTab.DISPLAY || state.inspectorTab == InspectorTab.ANNOTATE) state.inspectorTab else InspectorTab.DISPLAY,
                                onSelectTab = viewModel::selectInspectorTab,
                                activeStudy = state.activeStudy,
                                activePixels = state.activePixels,
                                displaySettings = state.displaySettings,
                                activeTool = state.activeTool,
                                annotations = annotations,
                                qualityChecklist = qa,
                                automatedTechnicalFlags = state.automatedTechnicalFlags,
                                report = report,
                                auditEvents = auditEvents,
                                preferences = prefs,
                                dicomWebQueryResults = state.dicomWebQueryResults,
                                onUpdateWindowLevel = viewModel::updateWindowLevel,
                                onUpdateZoomPan = viewModel::updateZoomPan,
                                onFitToScreen = viewModel::fitToScreen,
                                onRotateCw90 = viewModel::rotateCw90,
                                onFlipH = viewModel::flipHorizontal,
                                onFlipV = viewModel::flipVertical,
                                onToggleInvert = viewModel::toggleInvertGrayscale,
                                onResetView = viewModel::resetDisplayToDefault,
                                onSelectTool = viewModel::selectTool,
                                onDeleteAnnotation = viewModel::deleteAnnotation,
                                onExportDerivative = viewModel::exportReviewedDerivative,
                                onSaveQualityChecklist = viewModel::saveQualityChecklist,
                                onSaveReportDraft = viewModel::saveReportDraft,
                                onSignReport = viewModel::signReport,
                                onAddAmendment = viewModel::addReportAmendment,
                                onQueryDicomWeb = viewModel::queryDicomWebArchive,
                                onRetrieveDicomWebEntry = viewModel::retrieveDicomWebEntry,
                                onSimulateConflict = viewModel::triggerSyncConflictDemo,
                                onPurgeCache = viewModel::purgeExpiredCache,
                                onClearAndReseed = viewModel::clearAllAndReseedDemo,
                                onUpdateEndpointsAndPolicy = viewModel::updateEndpointsAndPolicy,
                            )

                            CompactDestination.REPORT -> ToolsInspectorPane(
                                selectedTab = if (state.inspectorTab == InspectorTab.QUALITY || state.inspectorTab == InspectorTab.REPORT) state.inspectorTab else InspectorTab.QUALITY,
                                onSelectTab = viewModel::selectInspectorTab,
                                activeStudy = state.activeStudy,
                                activePixels = state.activePixels,
                                displaySettings = state.displaySettings,
                                activeTool = state.activeTool,
                                annotations = annotations,
                                qualityChecklist = qa,
                                automatedTechnicalFlags = state.automatedTechnicalFlags,
                                report = report,
                                auditEvents = auditEvents,
                                preferences = prefs,
                                dicomWebQueryResults = state.dicomWebQueryResults,
                                onUpdateWindowLevel = viewModel::updateWindowLevel,
                                onUpdateZoomPan = viewModel::updateZoomPan,
                                onFitToScreen = viewModel::fitToScreen,
                                onRotateCw90 = viewModel::rotateCw90,
                                onFlipH = viewModel::flipHorizontal,
                                onFlipV = viewModel::flipVertical,
                                onToggleInvert = viewModel::toggleInvertGrayscale,
                                onResetView = viewModel::resetDisplayToDefault,
                                onSelectTool = viewModel::selectTool,
                                onDeleteAnnotation = viewModel::deleteAnnotation,
                                onExportDerivative = viewModel::exportReviewedDerivative,
                                onSaveQualityChecklist = viewModel::saveQualityChecklist,
                                onSaveReportDraft = viewModel::saveReportDraft,
                                onSignReport = viewModel::signReport,
                                onAddAmendment = viewModel::addReportAmendment,
                                onQueryDicomWeb = viewModel::queryDicomWebArchive,
                                onRetrieveDicomWebEntry = viewModel::retrieveDicomWebEntry,
                                onSimulateConflict = viewModel::triggerSyncConflictDemo,
                                onPurgeCache = viewModel::purgeExpiredCache,
                                onClearAndReseed = viewModel::clearAllAndReseedDemo,
                                onUpdateEndpointsAndPolicy = viewModel::updateEndpointsAndPolicy,
                            )

                            CompactDestination.SECURITY -> ToolsInspectorPane(
                                selectedTab = InspectorTab.ARCHIVE,
                                onSelectTab = viewModel::selectInspectorTab,
                                activeStudy = state.activeStudy,
                                activePixels = state.activePixels,
                                displaySettings = state.displaySettings,
                                activeTool = state.activeTool,
                                annotations = annotations,
                                qualityChecklist = qa,
                                automatedTechnicalFlags = state.automatedTechnicalFlags,
                                report = report,
                                auditEvents = auditEvents,
                                preferences = prefs,
                                dicomWebQueryResults = state.dicomWebQueryResults,
                                onUpdateWindowLevel = viewModel::updateWindowLevel,
                                onUpdateZoomPan = viewModel::updateZoomPan,
                                onFitToScreen = viewModel::fitToScreen,
                                onRotateCw90 = viewModel::rotateCw90,
                                onFlipH = viewModel::flipHorizontal,
                                onFlipV = viewModel::flipVertical,
                                onToggleInvert = viewModel::toggleInvertGrayscale,
                                onResetView = viewModel::resetDisplayToDefault,
                                onSelectTool = viewModel::selectTool,
                                onDeleteAnnotation = viewModel::deleteAnnotation,
                                onExportDerivative = viewModel::exportReviewedDerivative,
                                onSaveQualityChecklist = viewModel::saveQualityChecklist,
                                onSaveReportDraft = viewModel::saveReportDraft,
                                onSignReport = viewModel::signReport,
                                onAddAmendment = viewModel::addReportAmendment,
                                onQueryDicomWeb = viewModel::queryDicomWebArchive,
                                onRetrieveDicomWebEntry = viewModel::retrieveDicomWebEntry,
                                onSimulateConflict = viewModel::triggerSyncConflictDemo,
                                onPurgeCache = viewModel::purgeExpiredCache,
                                onClearAndReseed = viewModel::clearAllAndReseedDemo,
                                onUpdateEndpointsAndPolicy = viewModel::updateEndpointsAndPolicy,
                            )
                        }
                    }

                    NavigationBar(
                        containerColor = GraphitePanel,
                        windowInsets = WindowInsets(0, 0, 0, 0),
                        modifier = Modifier.navigationBarsPadding(),
                    ) {
                        val navItems = listOf(
                            Triple(CompactDestination.WORKLIST, Icons.Filled.FolderOpen, "Worklist"),
                            Triple(CompactDestination.VIEWER, Icons.Filled.Image, "Viewer"),
                            Triple(CompactDestination.TOOLS, Icons.Filled.Build, "Tools"),
                            Triple(CompactDestination.REPORT, Icons.Filled.Assignment, "Report"),
                            Triple(CompactDestination.SECURITY, Icons.Filled.Security, "Audit"),
                        )
                        navItems.forEach { (dest, icon, label) ->
                            NavigationBarItem(
                                selected = state.compactDestination == dest,
                                onClick = { viewModel.selectCompactDestination(dest) },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("compact_nav_${dest.name}"),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkstationTopBar(
    clinicianName: String,
    clinicianRole: String,
    authMode: String,
    textScale: Float,
    onChangeTextScale: (Float) -> Unit,
    onLockSession: () -> Unit,
    onSignOut: () -> Unit,
) {
    var scaleMenuOpen by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(GraphiteCard)
            .statusBarsPadding(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.MedicalServices, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(20.dp))
                Column {
                    Text("AUREOM IMAGING • X-RAY WORKSPACE", style = MaterialTheme.typography.titleSmall, color = CyanPrimary)
                    Text(
                        text = "$clinicianName ($clinicianRole) • $authMode",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "DEMO • NON-DIAGNOSTIC",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusWarning,
                    modifier = Modifier.padding(end = 6.dp),
                )
                Box {
                    IconButton(
                        onClick = { scaleMenuOpen = true },
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("text_scale_button"),
                    ) {
                        Icon(Icons.Filled.TextFields, contentDescription = "Adjust UI Text Size", tint = CyanPrimary)
                    }
                    DropdownMenu(expanded = scaleMenuOpen, onDismissRequest = { scaleMenuOpen = false }) {
                        listOf(1.0f to "Text 100%", 1.15f to "Text 115%", 1.3f to "Text 130%").forEach { (scale, label) ->
                            DropdownMenuItem(
                                text = { Text(if (kotlin.math.abs(textScale - scale) < 0.02f) "✓ $label" else label) },
                                onClick = {
                                    scaleMenuOpen = false
                                    onChangeTextScale(scale)
                                },
                            )
                        }
                    }
                }
                IconButton(
                    onClick = onLockSession,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("lock_session_button"),
                ) {
                    Icon(Icons.Filled.Lock, contentDescription = "Lock Session", tint = CyanPrimary)
                }
                IconButton(
                    onClick = onSignOut,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("sign_out_button"),
                ) {
                    Icon(Icons.Filled.Logout, contentDescription = "Sign Out", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Box(modifier = Modifier.fillMaxWidth().padding(0.dp).background(GraphiteBorder).padding(top = 1.dp))
    }
}
