package com.example.data.network

import com.example.imaging.SyntheticStudyGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import java.util.concurrent.TimeUnit

data class DicomWebStudyEntry(
    val studyInstanceUid: String,
    val seriesInstanceUid: String,
    val sopInstanceUid: String,
    val patientId: String,
    val modality: String,
    val description: String,
    val sourceLabel: String,
)

sealed class DicomWebResult<out T> {
    data class Success<T>(val data: T) : DicomWebResult<T>()
    data class Failure(val statusCode: Int, val message: String) : DicomWebResult<Nothing>()
}

/**
 * Replaceable DICOMweb (PS3.18) adapter for QIDO-RS, WADO-RS, and STOW-RS operations.
 */
interface DicomWebAdapter {
    suspend fun queryStudiesQidoRs(endpoint: String, authHeader: String?): DicomWebResult<List<DicomWebStudyEntry>>
    suspend fun retrieveInstanceWadoRs(
        endpoint: String,
        studyUid: String,
        seriesUid: String,
        sopUid: String,
        authHeader: String?,
    ): DicomWebResult<ByteArray>

    suspend fun storeInstanceStowRs(
        endpoint: String,
        dicomBytes: ByteArray,
        authHeader: String?,
    ): DicomWebResult<String>
}

class HttpDicomWebAdapter : DicomWebAdapter {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    override suspend fun queryStudiesQidoRs(
        endpoint: String,
        authHeader: String?,
    ): DicomWebResult<List<DicomWebStudyEntry>> = withContext(Dispatchers.IO) {
        runCatching {
            val base = endpoint.trimEnd('/')
            val reqBuilder = Request.Builder()
                .url("$base/studies?limit=25")
                .addHeader("Accept", "application/dicom+json")
            if (!authHeader.isNullOrBlank()) reqBuilder.addHeader("Authorization", authHeader)
            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext DicomWebResult.Failure(resp.code, "QIDO-RS HTTP ${resp.code}: ${resp.message}")
                }
                val body = resp.body?.string().orEmpty()
                // Parse minimal JSON summary count for connection verification
                val entries = parseQidoSummary(body, base)
                DicomWebResult.Success(entries)
            }
        }.getOrElse { ex ->
            DicomWebResult.Failure(-1, "DICOMweb archive unreachable (${ex.message ?: "connection failed"})")
        }
    }

    override suspend fun retrieveInstanceWadoRs(
        endpoint: String,
        studyUid: String,
        seriesUid: String,
        sopUid: String,
        authHeader: String?,
    ): DicomWebResult<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            val base = endpoint.trimEnd('/')
            val url = "$base/studies/$studyUid/series/$seriesUid/instances/$sopUid"
            val reqBuilder = Request.Builder()
                .url(url)
                .addHeader("Accept", "application/dicom; transfer-syntax=1.2.840.10008.1.2.1")
            if (!authHeader.isNullOrBlank()) reqBuilder.addHeader("Authorization", authHeader)
            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext DicomWebResult.Failure(resp.code, "WADO-RS HTTP ${resp.code}: ${resp.message}")
                }
                val bytes = resp.body?.bytes()
                    ?: return@withContext DicomWebResult.Failure(resp.code, "Empty WADO-RS payload")
                DicomWebResult.Success(bytes)
            }
        }.getOrElse { ex ->
            DicomWebResult.Failure(-1, "WADO-RS retrieval failed: ${ex.message}")
        }
    }

    override suspend fun storeInstanceStowRs(
        endpoint: String,
        dicomBytes: ByteArray,
        authHeader: String?,
    ): DicomWebResult<String> = withContext(Dispatchers.IO) {
        runCatching {
            val base = endpoint.trimEnd('/')
            val boundary = "aureom_stow_${System.currentTimeMillis()}"
            val headerBytes = ("--$boundary\r\nContent-Type: application/dicom\r\n\r\n").toByteArray()
            val footerBytes = ("\r\n--$boundary--\r\n").toByteArray()
            val payload = headerBytes + dicomBytes + footerBytes
            val mediaType = "multipart/related; type=\"application/dicom\"; boundary=$boundary".toMediaType()
            val reqBuilder = Request.Builder()
                .url("$base/studies")
                .post(payload.toRequestBody(mediaType))
                .addHeader("Accept", "application/dicom+json")
            if (!authHeader.isNullOrBlank()) reqBuilder.addHeader("Authorization", authHeader)
            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext DicomWebResult.Failure(resp.code, "STOW-RS HTTP ${resp.code}: ${resp.message}")
                }
                DicomWebResult.Success("STOW-RS accepted (${resp.code})")
            }
        }.getOrElse { ex ->
            DicomWebResult.Failure(-1, "STOW-RS upload failed: ${ex.message}")
        }
    }

    private fun parseQidoSummary(json: String, source: String): List<DicomWebStudyEntry> {
        if (json.isBlank() || json.trim() == "[]") return emptyList()
        val arr = org.json.JSONArray(json)
        val out = mutableListOf<DicomWebStudyEntry>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val studyUid = extractDicomTag(obj, "0020000D") ?: continue
            val patId = extractDicomTag(obj, "00100020") ?: "Not supplied"
            val mod = extractDicomTag(obj, "00080060") ?: "DX"
            val desc = extractDicomTag(obj, "00081030") ?: "DICOMweb Study"
            out += DicomWebStudyEntry(
                studyInstanceUid = studyUid,
                seriesInstanceUid = "$studyUid.1",
                sopInstanceUid = "$studyUid.1.1",
                patientId = patId,
                modality = mod,
                description = desc,
                sourceLabel = source,
            )
        }
        return out
    }

    private fun extractDicomTag(obj: org.json.JSONObject, tag: String): String? {
        val node = obj.optJSONObject(tag) ?: return null
        val vals = node.optJSONArray("Value") ?: return null
        val first = vals.opt(0) ?: return null
        return if (first is org.json.JSONObject) first.optString("Alphabetic") else first.toString()
    }
}

/**
 * Local in-process test DICOMweb archive adapter for offline APK demonstration and unit tests.
 */
class LocalDemoArchiveAdapter : DicomWebAdapter {
    override suspend fun queryStudiesQidoRs(
        endpoint: String,
        authHeader: String?,
    ): DicomWebResult<List<DicomWebStudyEntry>> = DicomWebResult.Success(
        listOf(
            DicomWebStudyEntry(
                studyInstanceUid = "1.2.826.0.1.3680043.8.498.1000.CURR",
                seriesInstanceUid = "1.2.826.0.1.3680043.8.498.1000.CURR.1",
                sopInstanceUid = "1.2.826.0.1.3680043.8.498.1000.CURR.1.1",
                patientId = "SYN-PT-10482",
                modality = "DX",
                description = "Chest PA Radiograph (Current)",
                sourceLabel = "Local Test Archive",
            ),
            DicomWebStudyEntry(
                studyInstanceUid = "1.2.826.0.1.3680043.8.498.2000.HAND",
                seriesInstanceUid = "1.2.826.0.1.3680043.8.498.2000.HAND.1",
                sopInstanceUid = "1.2.826.0.1.3680043.8.498.2000.HAND.1.1",
                patientId = "SYN-PT-20914",
                modality = "DX",
                description = "Right Hand PA Radiograph (MONOCHROME1)",
                sourceLabel = "Local Test Archive",
            ),
        ),
    )

    override suspend fun retrieveInstanceWadoRs(
        endpoint: String,
        studyUid: String,
        seriesUid: String,
        sopUid: String,
        authHeader: String?,
    ): DicomWebResult<ByteArray> {
        val bytes = when {
            studyUid.contains("HAND") -> SyntheticStudyGenerator.generateHandRightMonochrome1Dicom()
            studyUid.contains("PRIOR") -> SyntheticStudyGenerator.generateChestPaDicom(isPrior = true)
            studyUid.contains("KNEE") -> SyntheticStudyGenerator.generateUncalibratedKneeDicom()
            else -> SyntheticStudyGenerator.generateChestPaDicom(isPrior = false)
        }
        return DicomWebResult.Success(bytes)
    }

    override suspend fun storeInstanceStowRs(
        endpoint: String,
        dicomBytes: ByteArray,
        authHeader: String?,
    ): DicomWebResult<String> = DicomWebResult.Success("Local Test Archive accepted ${dicomBytes.size} bytes")
}
