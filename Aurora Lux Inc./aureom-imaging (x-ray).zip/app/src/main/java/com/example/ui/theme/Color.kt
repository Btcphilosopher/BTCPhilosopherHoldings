package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Graphite Medical-Imaging Palette
val GraphiteAbyss = Color(0xFF0A0D11)
val GraphiteBase = Color(0xFF11161C)
val GraphitePanel = Color(0xFF171D25)
val GraphiteCard = Color(0xFF1E2631)
val GraphiteElevated = Color(0xFF252F3D)
val GraphiteBorder = Color(0xFF2F3B4C)

// Radiographic Canvas
val RadiographVoid = Color(0xFF000000)

// Foreground Text
val ClinicalWhite = Color(0xFFF3F6FA)
val ClinicalSlate = Color(0xFFB3C0D1)
val ClinicalMuted = Color(0xFF7B8B9E)

// Restrained Cyan Controls
val CyanPrimary = Color(0xFF22D3EE)
val CyanMuted = Color(0xFF0891B2)
val CyanContainer = Color(0xFF0E3A47)
val CyanOnContainer = Color(0xFFA5F3FC)

// Clinical Status & Safety Accents
val StatusVerified = Color(0xFF10B981)
val StatusVerifiedBg = Color(0xFF0B3528)
val StatusWarning = Color(0xFFF59E0B)
val StatusWarningBg = Color(0xFF3D2808)
val StatusCritical = Color(0xFFEF4444)
val StatusCriticalBg = Color(0xFF3F1215)
val StatusInfo = Color(0xFF38BDF8)
val StatusInfoBg = Color(0xFF0C2D42)
