package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.AcquisitionStatus
import com.example.domain.model.CalibrationState
import com.example.domain.model.EquipmentConnectionState
import com.example.domain.model.ExaminationSummary
import com.example.domain.model.QualityReviewStatus
import com.example.domain.model.ReceiptStatus
import com.example.domain.model.ReportStatus
import com.example.domain.model.SyncState
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanOnContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GraphiteAbyss
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.GraphiteElevated
import com.example.ui.theme.GraphitePanel
import com.example.ui.theme.StatusCritical
import com.example.ui.theme.StatusCriticalBg
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusInfoBg
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusVerifiedBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorklistPane(
    studies: List<ExaminationSummary>,
    activeStudyUid: String?,
    equipmentState: EquipmentConnectionState,
    onSelectStudy: (ExaminationSummary) -> Unit,
    onRetryTransfer: (String) -> Unit,
    onSimulateIncomingAcquisition: (Boolean) -> Unit,
    onLaunchDocumentPicker: () -> Unit,
    onImportUnsupportedJ2kDemo: () -> Unit,
    onImportNonDicomPngDemo: () -> Unit,
    onQueryLocalArchive: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = remember(studies, searchQuery) {
        if (searchQuery.isBlank()) studies
        else {
            val q = searchQuery.trim().lowercase()
            studies.filter {
                it.patientId.lowercase().contains(q) ||
                    it.patientName.lowercase().contains(q) ||
                    it.description.lowercase().contains(q) ||
                    it.bodyPart.lowercase().contains(q)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphitePanel)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = "WORKLIST & EQUIPMENT",
            style = MaterialTheme.typography.labelMedium,
            color = CyanPrimary,
        )

        // Equipment Integration Card
        Card(
            colors = CardDefaults.cardColors(containerColor = GraphiteCard),
            border = BorderStroke(1.dp, GraphiteBorder),
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                if (equipmentState.connected) StatusVerified else StatusCritical,
                                CircleShape,
                            ),
                    )
                    Icon(
                        imageVector = Icons.Filled.Sensors,
                        contentDescription = "Equipment Adapter",
                        tint = CyanPrimary,
                        modifier = Modifier.size(16.dp),
                    )
                    Text(
                        text = "${equipmentState.deviceId} (${equipmentState.aeTitle})",
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    text = equipmentState.statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (equipmentState.currentStatus != AcquisitionStatus.TRANSFER_COMPLETE &&
                    equipmentState.currentStatus != AcquisitionStatus.TRANSFER_FAILED
                ) {
                    LinearProgressIndicator(
                        progress = { equipmentState.progressPercent / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = CyanPrimary,
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    OutlinedButton(
                        onClick = { onSimulateIncomingAcquisition(false) },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("simulate_dr_acquire_button"),
                    ) {
                        Text("Receive DR", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(
                        onClick = { onSimulateIncomingAcquisition(true) },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("simulate_dr_interrupt_button"),
                    ) {
                        Text("Sim Fail", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Import & Archive Actions
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Button(
                onClick = onLaunchDocumentPicker,
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanContainer,
                    contentColor = CyanOnContainer,
                ),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("import_document_picker_button"),
            ) {
                Icon(Icons.Filled.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Import File")
            }
            OutlinedButton(
                onClick = onQueryLocalArchive,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("query_local_archive_button"),
            ) {
                Icon(Icons.Filled.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Archive")
            }
            OutlinedButton(
                onClick = onImportNonDicomPngDemo,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("import_png_demo_button"),
            ) {
                Icon(Icons.Outlined.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("PNG Ref")
            }
            OutlinedButton(
                onClick = onImportUnsupportedJ2kDemo,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("import_unsupported_demo_button"),
            ) {
                Icon(Icons.Outlined.BrokenImage, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Bad File")
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Filter patient ID, exam, body part…") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("worklist_search_input"),
        )

        HorizontalDivider(color = GraphiteBorder)

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(filtered, key = { it.studyInstanceUid }) { study ->
                StudyWorklistCard(
                    study = study,
                    isActive = study.studyInstanceUid == activeStudyUid,
                    onClick = { onSelectStudy(study) },
                    onRetryTransfer = { onRetryTransfer(study.studyInstanceUid) },
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudyWorklistCard(
    study: ExaminationSummary,
    isActive: Boolean,
    onClick: () -> Unit,
    onRetryTransfer: () -> Unit,
) {
    val borderColor = when {
        isActive -> CyanPrimary
        study.acquisitionStatus == AcquisitionStatus.TRANSFER_FAILED -> StatusCritical
        else -> GraphiteBorder
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("study_card_${study.patientId}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) GraphiteElevated else GraphiteCard,
        ),
        border = BorderStroke(if (isActive) 1.5.dp else 1.dp, borderColor),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = study.patientName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(6.dp))
                StatusChip(
                    text = study.modality,
                    fg = if (study.isNonDicom) StatusWarning else CyanOnContainer,
                    bg = if (study.isNonDicom) StatusWarningBg else CyanContainer,
                )
            }

            Text(
                text = "ID: ${study.patientId} • ${study.patientIdIssuer}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = study.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = "Body: ${study.bodyPart} | View: ${study.viewOrProjection ?: "Not supplied"} | Lat: ${study.laterality ?: "Not supplied"}",
                style = MaterialTheme.typography.bodySmall,
                color = if (study.laterality == null || study.viewOrProjection == null) StatusWarning else MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // 4 explicitly separated status tracks + calibration + sync state
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                StatusChip(
                    text = "Acq: ${study.acquisitionStatus.label}",
                    fg = if (study.acquisitionStatus == AcquisitionStatus.TRANSFER_FAILED) StatusCritical else StatusInfo,
                    bg = if (study.acquisitionStatus == AcquisitionStatus.TRANSFER_FAILED) StatusCriticalBg else StatusInfoBg,
                )
                StatusChip(
                    text = "Rcpt: ${study.receiptStatus.label}",
                    fg = if (study.receiptStatus == ReceiptStatus.RECEIVED_VERIFIED || study.receiptStatus == ReceiptStatus.IMPORTED_LOCAL) StatusVerified else StatusWarning,
                    bg = if (study.receiptStatus == ReceiptStatus.RECEIVED_VERIFIED || study.receiptStatus == ReceiptStatus.IMPORTED_LOCAL) StatusVerifiedBg else StatusWarningBg,
                )
                StatusChip(
                    text = study.qualityStatus.label,
                    fg = when (study.qualityStatus) {
                        QualityReviewStatus.QA_PASSED -> StatusVerified
                        QualityReviewStatus.QA_FLAGGED_FURTHER_REVIEW -> StatusWarning
                        QualityReviewStatus.NOT_REVIEWED -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    bg = GraphiteAbyss,
                )
                StatusChip(
                    text = "Rpt: ${study.reportStatus.label}",
                    fg = if (study.reportStatus == ReportStatus.SIGNED || study.reportStatus == ReportStatus.AMENDED) StatusVerified else CyanOnContainer,
                    bg = GraphiteAbyss,
                )
                if (study.metadata.spacingInfo.calibrationState == CalibrationState.NONE) {
                    StatusChip("PX ONLY", StatusWarning, StatusWarningBg)
                }
                StatusChip(
                    text = study.syncState.label,
                    fg = when (study.syncState) {
                        SyncState.SYNCED -> StatusVerified
                        SyncState.CONFLICT_DETECTED -> StatusCritical
                        else -> StatusWarning
                    },
                    bg = GraphiteAbyss,
                )
            }

            Text(
                text = "Acq: ${study.acquisitionDateTime} • Cached: ${study.downloadedAtIso?.take(16)?.replace('T', ' ') ?: "Not cached"}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (study.acquisitionStatus == AcquisitionStatus.TRANSFER_FAILED) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StatusCriticalBg, MaterialTheme.shapes.small)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = StatusCritical, modifier = Modifier.size(16.dp))
                        Text(
                            text = study.transferErrorMessage ?: "Transfer interrupted (${study.transferProgressPercent}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = onRetryTransfer,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("retry_transfer_button_${study.patientId}"),
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Retry Transfer", modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Retry")
                    }
                }
            }
        }
    }
}

@Composable
fun StatusChip(
    text: String,
    fg: Color,
    bg: Color,
) {
    Surface(
        color = bg,
        shape = MaterialTheme.shapes.extraSmall,
        border = BorderStroke(0.5.dp, fg.copy(alpha = 0.4f)),
    ) {
        Text(
            text = text,
            color = fg,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
}
