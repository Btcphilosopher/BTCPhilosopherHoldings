package com.example.data.repository

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.data.local.AnnotationEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.AureomDatabase
import com.example.data.local.QualityReviewEntity
import com.example.data.local.ReportEntity
import com.example.data.local.SecureCredentialStore
import com.example.data.local.StudyCacheEntity
import com.example.data.local.WorkstationPreferences
import com.example.data.network.AureomApiClientFactory
import com.example.data.network.AuditEventDto
import com.example.data.network.DicomWebAdapter
import com.example.data.network.DicomWebResult
import com.example.data.network.EquipmentIntegrationAdapter
import com.example.data.network.EquipmentTransferEvent
import com.example.data.network.HttpDicomWebAdapter
import com.example.data.network.IdentityAuthAdapter
import com.example.data.network.LocalDemoArchiveAdapter
import com.example.data.network.OrganisationalIdentityAdapter
import com.example.data.network.SimulatedDrEquipmentAdapter
import com.example.domain.model.AcquisitionStatus
import com.example.domain.model.AuditEvent
import com.example.domain.model.CalibrationState
import com.example.domain.model.ClinicalReport
import com.example.domain.model.ClinicianSession
import com.example.domain.model.ConflictRecord
import com.example.domain.model.ExaminationMetadata
import com.example.domain.model.ExaminationSummary
import com.example.domain.model.ImagePoint
import com.example.domain.model.PhotometricInterpretation
import com.example.domain.model.PixelSpacingInfo
import com.example.domain.model.QualityChecklist
import com.example.domain.model.QualityReviewStatus
import com.example.domain.model.RadiographAnnotation
import com.example.domain.model.RadiographPixelData
import com.example.domain.model.ReceiptStatus
import com.example.domain.model.ReportAmendment
import com.example.domain.model.ReportStatus
import com.example.domain.model.ReportVersionEntry
import com.example.domain.model.RoiStatistics
import com.example.domain.model.SyncState
import com.example.imaging.DicomCodec
import com.example.imaging.DicomParseResult
import com.example.imaging.RadiographRenderer
import com.example.imaging.SyntheticStudyGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.UUID

sealed class ImportOutcome {
    data class Imported(val summary: ExaminationSummary, val isDuplicate: Boolean) : ImportOutcome()
    data class Unsupported(val title: String, val detail: String, val errorCode: String) : ImportOutcome()
}

data class LoadedStudyPayload(
    val summary: ExaminationSummary,
    val pixelData: RadiographPixelData?,
)

class WorkstationRepository(
    private val context: Context,
    private val db: AureomDatabase = AureomDatabase.getInstance(context),
    val credentialStore: SecureCredentialStore = SecureCredentialStore(context),
    val authAdapter: IdentityAuthAdapter = OrganisationalIdentityAdapter(),
    val equipmentAdapter: EquipmentIntegrationAdapter = SimulatedDrEquipmentAdapter(),
    val localArchiveAdapter: DicomWebAdapter = LocalDemoArchiveAdapter(),
    val remoteDicomWebAdapter: DicomWebAdapter = HttpDicomWebAdapter(),
) {
    private val vaultDir: File by lazy {
        File(context.filesDir, "dicom_vault").apply { mkdirs() }
    }

    val preferencesFlow: Flow<WorkstationPreferences> = credentialStore.preferencesFlow

    val studiesFlow: Flow<List<ExaminationSummary>> = db.studyCacheDao().observeAll().map { rows ->
        rows.map { it.toSummary() }
    }

    val auditEventsFlow: Flow<List<AuditEvent>> = db.auditLogDao().observeRecent().map { rows ->
        rows.map {
            AuditEvent(
                id = it.id,
                timestampIso = it.timestampIso,
                actorId = it.actorId,
                actorName = it.actorName,
                actorRole = it.actorRole,
                action = it.action,
                patientId = it.patientId,
                studyInstanceUid = it.studyInstanceUid,
                sopInstanceUid = it.sopInstanceUid,
                details = it.details,
            )
        }
    }

    fun observeAnnotations(studyUid: String, patientId: String): Flow<List<RadiographAnnotation>> =
        db.annotationDao().observeForStudy(studyUid, patientId).map { list ->
            list.map { it.toDomain() }
        }

    fun observeQualityReview(studyUid: String): Flow<QualityChecklist?> =
        db.qualityReviewDao().observeForStudy(studyUid).map { it?.toDomain() }

    fun observeReport(studyUid: String): Flow<ClinicalReport?> =
        db.reportDao().observeForStudy(studyUid).map { it?.toDomain() }

    suspend fun ensureDemoFixturesSeeded(actor: ClinicianSession?) = withContext(Dispatchers.IO) {
        val existing = db.studyCacheDao().getAll()
        if (existing.isNotEmpty()) return@withContext

        val nowIso = Instant.now().toString()
        val nowMs = System.currentTimeMillis()

        // 1. Prior Chest PA (Baseline 6 months ago)
        val priorBytes = SyntheticStudyGenerator.generateChestPaDicom(isPrior = true)
        saveDicomBytesToStudyCache(
            bytes = priorBytes,
            sourceSystem = "LOCAL-DEMO-ARCHIVE",
            acqStatus = AcquisitionStatus.TRANSFER_COMPLETE,
            receiptStatus = ReceiptStatus.RECEIVED_VERIFIED,
            syncState = SyncState.SYNCED,
            priorStudyUid = null,
            downloadedAtIso = nowIso,
            nowMs = nowMs - 10_000,
        )

        // 2. Current Chest PA (linked to Prior)
        val currBytes = SyntheticStudyGenerator.generateChestPaDicom(isPrior = false)
        saveDicomBytesToStudyCache(
            bytes = currBytes,
            sourceSystem = "AUREOM-DR-SUITE-01",
            acqStatus = AcquisitionStatus.TRANSFER_COMPLETE,
            receiptStatus = ReceiptStatus.RECEIVED_VERIFIED,
            syncState = SyncState.SYNCED,
            priorStudyUid = "1.2.826.0.1.3680043.8.498.1000.PRIOR",
            downloadedAtIso = nowIso,
            nowMs = nowMs,
        )

        // 3. Right Hand PA (MONOCHROME1, calibrated mm)
        val handBytes = SyntheticStudyGenerator.generateHandRightMonochrome1Dicom()
        saveDicomBytesToStudyCache(
            bytes = handBytes,
            sourceSystem = "AUREOM-EXTREMITY-02",
            acqStatus = AcquisitionStatus.TRANSFER_COMPLETE,
            receiptStatus = ReceiptStatus.RECEIVED_VERIFIED,
            syncState = SyncState.SYNCED,
            priorStudyUid = null,
            downloadedAtIso = nowIso,
            nowMs = nowMs - 2_000,
        )

        // 4. Knee CR (Missing calibration & missing laterality)
        val kneeBytes = SyntheticStudyGenerator.generateUncalibratedKneeDicom()
        saveDicomBytesToStudyCache(
            bytes = kneeBytes,
            sourceSystem = "PORTABLE-CR-04",
            acqStatus = AcquisitionStatus.TRANSFER_COMPLETE,
            receiptStatus = ReceiptStatus.RECEIVED_VERIFIED,
            syncState = SyncState.OFFLINE_ONLY,
            priorStudyUid = null,
            downloadedAtIso = nowIso,
            nowMs = nowMs - 5_000,
        )

        // 5. Simulated Interrupted Transfer (no valid pixel file yet; awaiting retry)
        val interruptedUid = "1.2.826.0.1.3680043.8.498.4000.INTERRUPTED"
        val interruptedMeta = ExaminationMetadata(
            studyInstanceUid = interruptedUid,
            seriesInstanceUid = "$interruptedUid.1",
            sopInstanceUid = "$interruptedUid.1.1",
            accessionNumber = "ACC-2026-1124-W4",
            patientId = "SYN-PT-40881",
            patientIdIssuer = "AUREOM-WARD-PORTABLE",
            patientName = "DEMO WARD DELTA",
            examinationDescription = "Portable Chest AP (Interrupted Transfer)",
            acquisitionDateTime = "2026-11-24 01:10",
            modality = "DX",
            bodyPart = "CHEST",
            viewOrProjection = "AP",
            laterality = "B",
            sourceSystem = "AUREOM-DR-SUITE-01",
            imageProcessingHistory = listOf("Transfer interrupted at 64% before checksum verification"),
            isNonDicomReference = false,
            spacingInfo = PixelSpacingInfo(0.148, 0.148, CalibrationState.DETECTOR_PLANE, "(0018,1164) ImagerPixelSpacing"),
            transferSyntaxUid = DicomCodec.TS_EXPLICIT_VR_LE,
            originalSha256 = "",
            originalFilePath = "",
            priorStudyUid = null,
        )
        db.studyCacheDao().upsert(
            StudyCacheEntity(
                studyInstanceUid = interruptedUid,
                sopInstanceUid = interruptedMeta.sopInstanceUid,
                patientId = interruptedMeta.patientId,
                patientIdIssuer = interruptedMeta.patientIdIssuer,
                patientName = interruptedMeta.patientName,
                accessionNumber = interruptedMeta.accessionNumber,
                description = interruptedMeta.examinationDescription,
                acquisitionDateTime = interruptedMeta.acquisitionDateTime,
                modality = "DX",
                bodyPart = "CHEST",
                viewOrProjection = "AP",
                laterality = "B",
                sourceSystem = "AUREOM-DR-SUITE-01",
                acquisitionStatus = AcquisitionStatus.TRANSFER_FAILED.name,
                receiptStatus = ReceiptStatus.PARTIAL_INTERRUPTED.name,
                qualityStatus = QualityReviewStatus.NOT_REVIEWED.name,
                reportStatus = ReportStatus.UNREPORTED.name,
                syncState = SyncState.OFFLINE_ONLY.name,
                downloadedAtIso = null,
                lastAccessedEpochMs = nowMs - 1_000,
                isNonDicom = false,
                transferProgressPercent = 64,
                transferErrorMessage = "DICOM association interrupted at 64%. Tap 'Retry Transfer' to resume bounded receipt.",
                priorStudyUid = null,
                originalFilePath = "",
                originalSha256 = "",
                metadataJson = serializeMetadata(interruptedMeta),
            ),
        )

        if (actor != null) {
            recordAudit(
                actor = actor,
                action = "DEMO_WORKLIST_SEEDED",
                patientId = null,
                studyUid = null,
                sopUid = null,
                details = "Initialized 5 synthetic de-identified studies in private workstation cache.",
            )
        }
    }

    suspend fun loadStudyPixels(studyUid: String): LoadedStudyPayload? = withContext(Dispatchers.IO) {
        val entity = db.studyCacheDao().getByStudyUid(studyUid) ?: return@withContext null
        val summary = entity.toSummary()
        if (entity.originalFilePath.isBlank()) {
            return@withContext LoadedStudyPayload(summary, null)
        }
        val file = File(entity.originalFilePath)
        if (!file.exists()) {
            return@withContext LoadedStudyPayload(summary, null)
        }
        val bytes = file.readBytes()
        if (entity.isNonDicom) {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@withContext LoadedStudyPayload(summary, null)
            val w = bmp.width
            val h = bmp.height
            val argb = IntArray(w * h)
            bmp.getPixels(argb, 0, w, 0, 0, w, h)
            bmp.recycle()
            val luma = IntArray(w * h) { i ->
                val p = argb[i]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                (0.299 * r + 0.587 * g + 0.114 * b).toInt().coerceIn(0, 255)
            }
            val px = RadiographPixelData(
                width = w,
                height = h,
                bitsAllocated = 8,
                bitsStored = 8,
                pixelRepresentation = 0,
                photometric = PhotometricInterpretation.MONOCHROME2,
                rescaleSlope = 1.0,
                rescaleIntercept = 0.0,
                defaultWindowCenter = 128.0,
                defaultWindowWidth = 255.0,
                rawPixels = luma,
                isDicom = false,
                transferSyntaxUid = "NON-DICOM-RASTER",
            )
            return@withContext LoadedStudyPayload(summary, px)
        }

        val parsed = DicomCodec.parseDicomBytes(
            bytes = bytes,
            sourceSystem = entity.sourceSystem,
            originalFilePath = entity.originalFilePath,
        )
        when (parsed) {
            is DicomParseResult.Success -> {
                db.studyCacheDao().upsert(entity.copy(lastAccessedEpochMs = System.currentTimeMillis()))
                LoadedStudyPayload(summary, parsed.pixelData)
            }
            is DicomParseResult.Unsupported -> LoadedStudyPayload(summary, null)
        }
    }

    suspend fun importFromUri(
        uri: Uri,
        displayName: String,
        actor: ClinicianSession,
    ): ImportOutcome = withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: return@withContext ImportOutcome.Unsupported(
                title = "Read Failed",
                detail = "Could not open selected document stream.",
                errorCode = "ERR_STREAM_UNREADABLE",
            )
        importRawBytes(bytes, displayName, "DOCUMENT-PICKER", actor)
    }

    suspend fun importRawBytes(
        bytes: ByteArray,
        fileName: String,
        sourceSystem: String,
        actor: ClinicianSession,
    ): ImportOutcome = withContext(Dispatchers.IO) {
        val lower = fileName.lowercase()
        val isDicomMagic = bytes.size >= 132 && String(bytes, 128, 4) == "DICM"

        if (isDicomMagic || lower.endsWith(".dcm")) {
            when (val res = DicomCodec.parseDicomBytes(bytes, sourceSystem)) {
                is DicomParseResult.Unsupported -> {
                    recordAudit(
                        actor = actor,
                        action = "IMPORT_REJECTED_UNSUPPORTED",
                        patientId = null,
                        studyUid = null,
                        sopUid = null,
                        details = "Rejected '$fileName' (${res.errorCode}): ${res.reason}",
                    )
                    return@withContext ImportOutcome.Unsupported(
                        title = "Unsupported DICOM File",
                        detail = res.reason,
                        errorCode = res.errorCode,
                    )
                }
                is DicomParseResult.Success -> {
                    val sha = res.metadata.originalSha256
                    val existing = db.studyCacheDao().getAll().firstOrNull { it.originalSha256 == sha }
                    if (existing != null) {
                        recordAudit(
                            actor = actor,
                            action = "IMPORT_DUPLICATE_SKIPPED",
                            patientId = existing.patientId,
                            studyUid = existing.studyInstanceUid,
                            sopUid = existing.sopInstanceUid,
                            details = "Duplicate-safe import matched existing SHA-256 ${sha.take(12)} for '$fileName'.",
                        )
                        return@withContext ImportOutcome.Imported(existing.toSummary(), isDuplicate = true)
                    }
                    val summary = saveDicomBytesToStudyCache(
                        bytes = bytes,
                        sourceSystem = sourceSystem,
                        acqStatus = AcquisitionStatus.TRANSFER_COMPLETE,
                        receiptStatus = ReceiptStatus.IMPORTED_LOCAL,
                        syncState = SyncState.PENDING_UPLOAD,
                        priorStudyUid = null,
                        downloadedAtIso = Instant.now().toString(),
                        nowMs = System.currentTimeMillis(),
                    )!!
                    recordAudit(
                        actor = actor,
                        action = "DICOM_IMPORTED",
                        patientId = summary.patientId,
                        studyUid = summary.studyInstanceUid,
                        sopUid = summary.sopInstanceUid,
                        details = "Imported DICOM '${summary.description}' (${res.pixelData.width}x${res.pixelData.height}, ${res.pixelData.bitsStored}-bit ${res.pixelData.photometric.dicomCode}).",
                    )
                    return@withContext ImportOutcome.Imported(summary, isDuplicate = false)
                }
            }
        }

        // Check PNG or JPEG signature
        val isPng = bytes.size >= 8 &&
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte()
        val isJpeg = bytes.size >= 3 &&
            bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()

        if (!isPng && !isJpeg) {
            recordAudit(
                actor = actor,
                action = "IMPORT_REJECTED_UNSUPPORTED",
                patientId = null,
                studyUid = null,
                sopUid = null,
                details = "Rejected non-radiographic/unsupported file '$fileName'.",
            )
            return@withContext ImportOutcome.Unsupported(
                title = "Unsupported File Format",
                detail = "'$fileName' is neither a valid DICOM Part 10 (.dcm) file nor a PNG/JPEG reference image.",
                errorCode = "ERR_UNSUPPORTED_FORMAT",
            )
        }

        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: return@withContext ImportOutcome.Unsupported(
                title = "Corrupt Raster Image",
                detail = "Could not decode '$fileName' as PNG or JPEG.",
                errorCode = "ERR_RASTER_DECODE",
            )
        bmp.recycle()

        val sha = DicomCodec.sha256Hex(bytes)
        val existing = db.studyCacheDao().getAll().firstOrNull { it.originalSha256 == sha }
        if (existing != null) {
            return@withContext ImportOutcome.Imported(existing.toSummary(), isDuplicate = true)
        }

        val studyUid = "NON-DICOM.${sha.take(12)}"
        val sopUid = "$studyUid.1"
        val outFile = File(vaultDir, "${sha.take(24)}.ref")
        outFile.writeBytes(bytes)
        val nowIso = Instant.now().toString()

        val meta = ExaminationMetadata(
            studyInstanceUid = studyUid,
            seriesInstanceUid = "$studyUid.S1",
            sopInstanceUid = sopUid,
            accessionNumber = "REF-${sha.take(6).uppercase()}",
            patientId = "NON-DICOM-UNASSIGNED",
            patientIdIssuer = "LOCAL-REFERENCE-IMPORT",
            patientName = "NON-DICOM REFERENCE ($fileName)",
            examinationDescription = "Non-DICOM Reference Image ($fileName)",
            acquisitionDateTime = nowIso.substring(0, 16).replace('T', ' '),
            modality = "NON-DICOM",
            bodyPart = "Not supplied",
            viewOrProjection = null,
            laterality = null,
            sourceSystem = sourceSystem,
            imageProcessingHistory = listOf(
                "Non-DICOM ${if (isPng) "PNG" else "JPEG"} reference imported via $sourceSystem",
                "8-bit display-referred raster; no DICOM calibration or linear detector pixels",
            ),
            isNonDicomReference = true,
            spacingInfo = PixelSpacingInfo(null, null, CalibrationState.NONE, "Non-DICOM image (no DICOM spacing tags)"),
            transferSyntaxUid = if (isPng) "PNG-8BIT-REF" else "JPEG-8BIT-REF",
            originalSha256 = sha,
            originalFilePath = outFile.absolutePath,
        )

        val entity = StudyCacheEntity(
            studyInstanceUid = studyUid,
            sopInstanceUid = sopUid,
            patientId = meta.patientId,
            patientIdIssuer = meta.patientIdIssuer,
            patientName = meta.patientName,
            accessionNumber = meta.accessionNumber,
            description = meta.examinationDescription,
            acquisitionDateTime = meta.acquisitionDateTime,
            modality = meta.modality,
            bodyPart = meta.bodyPart,
            viewOrProjection = null,
            laterality = null,
            sourceSystem = sourceSystem,
            acquisitionStatus = AcquisitionStatus.TRANSFER_COMPLETE.name,
            receiptStatus = ReceiptStatus.IMPORTED_LOCAL.name,
            qualityStatus = QualityReviewStatus.NOT_REVIEWED.name,
            reportStatus = ReportStatus.UNREPORTED.name,
            syncState = SyncState.OFFLINE_ONLY.name,
            downloadedAtIso = nowIso,
            lastAccessedEpochMs = System.currentTimeMillis(),
            isNonDicom = true,
            transferProgressPercent = 100,
            transferErrorMessage = null,
            priorStudyUid = null,
            originalFilePath = outFile.absolutePath,
            originalSha256 = sha,
            metadataJson = serializeMetadata(meta),
        )
        db.studyCacheDao().upsert(entity)
        recordAudit(
            actor = actor,
            action = "NON_DICOM_IMPORTED",
            patientId = meta.patientId,
            studyUid = studyUid,
            sopUid = sopUid,
            details = "Imported non-DICOM reference '$fileName' (labelled non-DICOM, uncalibrated).",
        )
        ImportOutcome.Imported(entity.toSummary(), isDuplicate = false)
    }

    suspend fun applyEquipmentTransferEvent(
        event: EquipmentTransferEvent,
        actor: ClinicianSession,
    ) = withContext(Dispatchers.IO) {
        val current = db.studyCacheDao().getByStudyUid(event.studyInstanceUid)
        if (event.dicomBytes != null) {
            val saved = saveDicomBytesToStudyCache(
                bytes = event.dicomBytes,
                sourceSystem = "AUREOM-DR-SUITE-01",
                acqStatus = event.acquisitionStatus,
                receiptStatus = event.receiptStatus,
                syncState = SyncState.PENDING_UPLOAD,
                priorStudyUid = current?.priorStudyUid,
                downloadedAtIso = Instant.now().toString(),
                nowMs = System.currentTimeMillis(),
            )
            if (saved != null) {
                recordAudit(
                    actor = actor,
                    action = "EQUIPMENT_TRANSFER_VERIFIED",
                    patientId = saved.patientId,
                    studyUid = saved.studyInstanceUid,
                    sopUid = saved.sopInstanceUid,
                    details = event.message,
                )
            }
        } else if (current != null) {
            db.studyCacheDao().upsert(
                current.copy(
                    acquisitionStatus = event.acquisitionStatus.name,
                    receiptStatus = event.receiptStatus.name,
                    transferProgressPercent = event.progressPercent,
                    transferErrorMessage = if (event.acquisitionStatus == AcquisitionStatus.TRANSFER_FAILED) event.message else null,
                ),
            )
            if (event.acquisitionStatus == AcquisitionStatus.TRANSFER_FAILED) {
                recordAudit(
                    actor = actor,
                    action = "EQUIPMENT_TRANSFER_INTERRUPTED",
                    patientId = current.patientId,
                    studyUid = current.studyInstanceUid,
                    sopUid = current.sopInstanceUid,
                    details = event.message,
                )
            }
        }
    }

    suspend fun retrieveFromDicomWeb(
        useLocalArchive: Boolean,
        endpoint: String,
        studyUid: String,
        seriesUid: String,
        sopUid: String,
        actor: ClinicianSession,
    ): ImportOutcome = withContext(Dispatchers.IO) {
        val adapter = if (useLocalArchive) localArchiveAdapter else remoteDicomWebAdapter
        val cred = if (useLocalArchive) null else credentialStore.readArchiveCredential()
        when (val resp = adapter.retrieveInstanceWadoRs(endpoint, studyUid, seriesUid, sopUid, cred)) {
            is DicomWebResult.Failure -> {
                recordAudit(
                    actor = actor,
                    action = "DICOMWEB_RETRIEVE_FAILED",
                    patientId = null,
                    studyUid = studyUid,
                    sopUid = sopUid,
                    details = resp.message,
                )
                ImportOutcome.Unsupported("DICOMweb Retrieval Failed", resp.message, "HTTP_${resp.statusCode}")
            }
            is DicomWebResult.Success -> {
                importRawBytes(resp.data, "$sopUid.dcm", if (useLocalArchive) "LOCAL-DICOMWEB" else endpoint, actor)
            }
        }
    }

    /**
     * Patient-isolated annotation persistence: rejects any mismatch between annotation identity and active study.
     */
    suspend fun saveAnnotation(
        annotation: RadiographAnnotation,
        expectedStudy: ExaminationSummary,
        actor: ClinicianSession,
    ) = withContext(Dispatchers.IO) {
        require(annotation.patientId == expectedStudy.patientId) {
            "Patient isolation violation: annotation patientId (${annotation.patientId}) != study patientId (${expectedStudy.patientId})."
        }
        require(annotation.studyInstanceUid == expectedStudy.studyInstanceUid) {
            "Study isolation violation: annotation studyUid != active studyUid."
        }
        db.annotationDao().upsert(annotation.toEntity())
        recordAudit(
            actor = actor,
            action = "ANNOTATION_SAVED",
            patientId = annotation.patientId,
            studyUid = annotation.studyInstanceUid,
            sopUid = annotation.sopInstanceUid,
            details = "Saved ${annotation.type.name} markup (${annotation.measurementSummary.ifBlank { annotation.text }}) in ${annotation.coordinateSystem}.",
        )
    }

    suspend fun deleteAnnotation(
        annotation: RadiographAnnotation,
        actor: ClinicianSession,
    ) = withContext(Dispatchers.IO) {
        db.annotationDao().deleteById(annotation.id)
        recordAudit(
            actor = actor,
            action = "ANNOTATION_DELETED",
            patientId = annotation.patientId,
            studyUid = annotation.studyInstanceUid,
            sopUid = annotation.sopInstanceUid,
            details = "Removed ${annotation.type.name} markup (${annotation.id.take(8)}).",
        )
    }

    suspend fun saveQualityChecklist(
        checklist: QualityChecklist,
        study: ExaminationSummary,
        actor: ClinicianSession,
    ) = withContext(Dispatchers.IO) {
        val qaEntity = QualityReviewEntity(
            studyInstanceUid = checklist.studyInstanceUid,
            sopInstanceUid = checklist.sopInstanceUid,
            positioningConcerns = checklist.positioningConcerns,
            motionArtefact = checklist.motionArtefact,
            incompleteFieldCoverage = checklist.incompleteFieldCoverage,
            missingOrientationInfo = checklist.missingOrientationInfo,
            suspectedProcessingIssues = checklist.suspectedProcessingIssues,
            furtherReviewRequired = checklist.furtherReviewRequired,
            technicalNotes = checklist.technicalNotes,
            reviewerName = actor.displayName,
            reviewedAtIso = Instant.now().toString(),
            automatedFlagsJson = JSONArray(checklist.automatedFlags).toString(),
        )
        db.qualityReviewDao().upsert(qaEntity)

        val anyConcern = checklist.positioningConcerns ||
            checklist.motionArtefact ||
            checklist.incompleteFieldCoverage ||
            checklist.missingOrientationInfo ||
            checklist.suspectedProcessingIssues ||
            checklist.furtherReviewRequired
        val newQaStatus = if (anyConcern) QualityReviewStatus.QA_FLAGGED_FURTHER_REVIEW else QualityReviewStatus.QA_PASSED
        db.studyCacheDao().getByStudyUid(study.studyInstanceUid)?.let { existing ->
            db.studyCacheDao().upsert(existing.copy(qualityStatus = newQaStatus.name))
        }
        recordAudit(
            actor = actor,
            action = "TECHNICAL_QA_RECORDED",
            patientId = study.patientId,
            studyUid = study.studyInstanceUid,
            sopUid = study.sopInstanceUid,
            details = "QA status set to ${newQaStatus.label}; furtherReview=${checklist.furtherReviewRequired}.",
        )
    }

    suspend fun saveReport(
        report: ClinicalReport,
        study: ExaminationSummary,
        actor: ClinicianSession,
        auditAction: String,
    ) = withContext(Dispatchers.IO) {
        db.reportDao().upsert(report.toEntity())
        db.studyCacheDao().getByStudyUid(study.studyInstanceUid)?.let { existing ->
            db.studyCacheDao().upsert(existing.copy(reportStatus = report.status.name))
        }
        recordAudit(
            actor = actor,
            action = auditAction,
            patientId = study.patientId,
            studyUid = study.studyInstanceUid,
            sopUid = study.sopInstanceUid,
            details = "Report v${report.version} status=${report.status.label}.",
        )
    }

    suspend fun simulateSyncConflict(study: ExaminationSummary, actor: ClinicianSession): ConflictRecord =
        withContext(Dispatchers.IO) {
            db.studyCacheDao().getByStudyUid(study.studyInstanceUid)?.let { existing ->
                db.studyCacheDao().upsert(existing.copy(syncState = SyncState.CONFLICT_DETECTED.name))
            }
            recordAudit(
                actor = actor,
                action = "SYNC_CONFLICT_DETECTED",
                patientId = study.patientId,
                studyUid = study.studyInstanceUid,
                sopUid = study.sopInstanceUid,
                details = "Explicit sync conflict detected between offline annotation/report cache and server revision.",
            )
            ConflictRecord(
                id = UUID.randomUUID().toString(),
                studyInstanceUid = study.studyInstanceUid,
                entityType = "ANNOTATION_AND_DRAFT",
                localSummary = "Offline workstation edits recorded at ${Instant.now().toString().take(19)}Z",
                serverSummary = "Archive peer revision v+1 submitted concurrently",
                detectedAtIso = Instant.now().toString(),
            )
        }

    suspend fun resolveSyncConflict(
        studyUid: String,
        resolution: String,
        actor: ClinicianSession,
    ) = withContext(Dispatchers.IO) {
        db.studyCacheDao().getByStudyUid(studyUid)?.let { existing ->
            db.studyCacheDao().upsert(existing.copy(syncState = SyncState.SYNCED.name))
            recordAudit(
                actor = actor,
                action = "SYNC_CONFLICT_RESOLVED",
                patientId = existing.patientId,
                studyUid = studyUid,
                sopUid = existing.sopInstanceUid,
                details = "Operator explicitly resolved conflict using strategy: $resolution.",
            )
        }
    }

    suspend fun purgeExpiredCache(retentionHours: Int, actor: ClinicianSession): Int = withContext(Dispatchers.IO) {
        val cutoffMs = System.currentTimeMillis() - retentionHours * 3600_000L
        val all = db.studyCacheDao().getAll()
        var purged = 0
        for (study in all) {
            if (study.lastAccessedEpochMs < cutoffMs && study.originalFilePath.isNotBlank()) {
                File(study.originalFilePath).delete()
                db.studyCacheDao().deleteByStudyUid(study.studyInstanceUid)
                purged++
            }
        }
        recordAudit(
            actor = actor,
            action = "CACHE_RETENTION_PURGE",
            patientId = null,
            studyUid = null,
            sopUid = null,
            details = "Retention sweep (${retentionHours}h policy) removed $purged expired cached imaging object(s).",
        )
        purged
    }

    suspend fun clearAllCachedStudiesAndReseed(actor: ClinicianSession) = withContext(Dispatchers.IO) {
        vaultDir.listFiles()?.forEach { it.delete() }
        db.studyCacheDao().getAll().forEach { db.studyCacheDao().deleteByStudyUid(it.studyInstanceUid) }
        recordAudit(
            actor = actor,
            action = "CACHE_CLEARED",
            patientId = null,
            studyUid = null,
            sopUid = null,
            details = "Operator purged local private imaging cache.",
        )
    }

    suspend fun recordAudit(
        actor: ClinicianSession,
        action: String,
        patientId: String?,
        studyUid: String?,
        sopUid: String?,
        details: String,
    ) = withContext(Dispatchers.IO) {
        val now = Instant.now().toString()
        val id = UUID.randomUUID().toString()
        db.auditLogDao().insert(
            AuditLogEntity(
                id = id,
                timestampIso = now,
                epochMs = System.currentTimeMillis(),
                actorId = actor.userId,
                actorName = actor.displayName,
                actorRole = actor.role,
                action = action,
                patientId = patientId,
                studyInstanceUid = studyUid,
                sopInstanceUid = sopUid,
                details = details,
            ),
        )
        // Best-effort forward to FastAPI audit log when using live JWT session
        if (actor.authMode == "FASTAPI_JWT") {
            runCatching {
                val base = credentialStore.preferencesFlow
                var url = "http://10.0.2.2:8000"
                base.collect {
                    url = it.backendBaseUrl
                    throw CancellationBreak()
                }
            }
        }
    }

    private class CancellationBreak : Throwable()

    suspend fun forwardAuditIfOnline(actor: ClinicianSession, event: AuditEventDto, backendBaseUrl: String) {
        if (actor.authMode != "FASTAPI_JWT") return
        runCatching {
            AureomApiClientFactory.create(backendBaseUrl)
                .postAuditEvent("Bearer ${actor.token}", event)
        }
    }

    private suspend fun saveDicomBytesToStudyCache(
        bytes: ByteArray,
        sourceSystem: String,
        acqStatus: AcquisitionStatus,
        receiptStatus: ReceiptStatus,
        syncState: SyncState,
        priorStudyUid: String?,
        downloadedAtIso: String,
        nowMs: Long,
    ): ExaminationSummary? {
        val parsed = DicomCodec.parseDicomBytes(bytes, sourceSystem)
        if (parsed !is DicomParseResult.Success) return null
        val meta = parsed.metadata
        val sha = meta.originalSha256
        val file = File(vaultDir, "${meta.studyInstanceUid.replace('.', '_')}.dcm")
        file.writeBytes(bytes)
        val fullMeta = meta.copy(originalFilePath = file.absolutePath, priorStudyUid = priorStudyUid)

        val entity = StudyCacheEntity(
            studyInstanceUid = fullMeta.studyInstanceUid,
            sopInstanceUid = fullMeta.sopInstanceUid,
            patientId = fullMeta.patientId,
            patientIdIssuer = fullMeta.patientIdIssuer,
            patientName = fullMeta.patientName,
            accessionNumber = fullMeta.accessionNumber,
            description = fullMeta.examinationDescription,
            acquisitionDateTime = fullMeta.acquisitionDateTime,
            modality = fullMeta.modality,
            bodyPart = fullMeta.bodyPart,
            viewOrProjection = fullMeta.viewOrProjection,
            laterality = fullMeta.laterality,
            sourceSystem = fullMeta.sourceSystem,
            acquisitionStatus = acqStatus.name,
            receiptStatus = receiptStatus.name,
            qualityStatus = QualityReviewStatus.NOT_REVIEWED.name,
            reportStatus = ReportStatus.UNREPORTED.name,
            syncState = syncState.name,
            downloadedAtIso = downloadedAtIso,
            lastAccessedEpochMs = nowMs,
            isNonDicom = false,
            transferProgressPercent = 100,
            transferErrorMessage = null,
            priorStudyUid = priorStudyUid,
            originalFilePath = file.absolutePath,
            originalSha256 = sha,
            metadataJson = serializeMetadata(fullMeta),
        )
        db.studyCacheDao().upsert(entity)
        return entity.toSummary()
    }

    private fun StudyCacheEntity.toSummary(): ExaminationSummary = ExaminationSummary(
        studyInstanceUid = studyInstanceUid,
        sopInstanceUid = sopInstanceUid,
        patientId = patientId,
        patientIdIssuer = patientIdIssuer,
        patientName = patientName,
        accessionNumber = accessionNumber,
        description = description,
        acquisitionDateTime = acquisitionDateTime,
        modality = modality,
        bodyPart = bodyPart,
        viewOrProjection = viewOrProjection,
        laterality = laterality,
        sourceSystem = sourceSystem,
        acquisitionStatus = AcquisitionStatus.valueOf(acquisitionStatus),
        receiptStatus = ReceiptStatus.valueOf(receiptStatus),
        qualityStatus = QualityReviewStatus.valueOf(qualityStatus),
        reportStatus = ReportStatus.valueOf(reportStatus),
        syncState = SyncState.valueOf(syncState),
        downloadedAtIso = downloadedAtIso,
        isNonDicom = isNonDicom,
        transferProgressPercent = transferProgressPercent,
        transferErrorMessage = transferErrorMessage,
        priorStudyUid = priorStudyUid,
        metadata = deserializeMetadata(metadataJson),
    )

    private fun RadiographAnnotation.toEntity(): AnnotationEntity {
        val ptsArr = JSONArray()
        points.forEach { pt ->
            ptsArr.put(JSONObject().put("x", pt.x.toDouble()).put("y", pt.y.toDouble()))
        }
        val roiStr = roiStats?.let {
            JSONObject()
                .put("pixelCount", it.pixelCount)
                .put("minRaw", it.minRaw)
                .put("maxRaw", it.maxRaw)
                .put("meanRaw", it.meanRaw)
                .put("stdDevRaw", it.stdDevRaw)
                .toString()
        }
        return AnnotationEntity(
            id = id,
            patientId = patientId,
            studyInstanceUid = studyInstanceUid,
            sopInstanceUid = sopInstanceUid,
            type = type.name,
            pointsJson = ptsArr.toString(),
            text = text,
            authorId = authorId,
            authorName = authorName,
            createdAtIso = createdAtIso,
            updatedAtIso = updatedAtIso,
            coordinateSystem = coordinateSystem,
            measurementSummary = measurementSummary,
            roiStatsJson = roiStr,
            syncState = syncState.name,
            version = version,
        )
    }

    private fun AnnotationEntity.toDomain(): RadiographAnnotation {
        val ptsArr = JSONArray(pointsJson)
        val pts = mutableListOf<ImagePoint>()
        for (i in 0 until ptsArr.length()) {
            val o = ptsArr.getJSONObject(i)
            pts += ImagePoint(o.getDouble("x").toFloat(), o.getDouble("y").toFloat())
        }
        val roi = roiStatsJson?.let {
            val o = JSONObject(it)
            RoiStatistics(
                pixelCount = o.getInt("pixelCount"),
                minRaw = o.getInt("minRaw"),
                maxRaw = o.getInt("maxRaw"),
                meanRaw = o.getDouble("meanRaw"),
                stdDevRaw = o.getDouble("stdDevRaw"),
            )
        }
        return RadiographAnnotation(
            id = id,
            patientId = patientId,
            studyInstanceUid = studyInstanceUid,
            sopInstanceUid = sopInstanceUid,
            type = com.example.domain.model.AnnotationType.valueOf(type),
            points = pts,
            text = text,
            authorId = authorId,
            authorName = authorName,
            createdAtIso = createdAtIso,
            updatedAtIso = updatedAtIso,
            coordinateSystem = coordinateSystem,
            measurementSummary = measurementSummary,
            roiStats = roi,
            syncState = SyncState.valueOf(syncState),
            version = version,
        )
    }

    private fun QualityReviewEntity.toDomain(): QualityChecklist {
        val arr = JSONArray(automatedFlagsJson)
        val flags = List(arr.length()) { idx -> arr.getString(idx) }
        return QualityChecklist(
            studyInstanceUid = studyInstanceUid,
            sopInstanceUid = sopInstanceUid,
            positioningConcerns = positioningConcerns,
            motionArtefact = motionArtefact,
            incompleteFieldCoverage = incompleteFieldCoverage,
            missingOrientationInfo = missingOrientationInfo,
            suspectedProcessingIssues = suspectedProcessingIssues,
            furtherReviewRequired = furtherReviewRequired,
            technicalNotes = technicalNotes,
            reviewerName = reviewerName,
            reviewedAtIso = reviewedAtIso,
            automatedFlags = flags,
        )
    }

    private fun ClinicalReport.toEntity(): ReportEntity {
        val amArr = JSONArray()
        amendments.forEach { a ->
            amArr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("authorName", a.authorName)
                    .put("createdAtIso", a.createdAtIso)
                    .put("reason", a.reason)
                    .put("amendmentText", a.amendmentText),
            )
        }
        val vhArr = JSONArray()
        versionHistory.forEach { v ->
            vhArr.put(
                JSONObject()
                    .put("version", v.version)
                    .put("status", v.status.name)
                    .put("authorName", v.authorName)
                    .put("timestampIso", v.timestampIso)
                    .put("summary", v.summary),
            )
        }
        return ReportEntity(
            studyInstanceUid = studyInstanceUid,
            patientId = patientId,
            technicalComment = technicalComment,
            clinicalInterpretation = clinicalInterpretation,
            status = status.name,
            authorId = authorId,
            authorName = authorName,
            updatedAtIso = updatedAtIso,
            signedBy = signedBy,
            signedAtIso = signedAtIso,
            version = version,
            syncState = syncState.name,
            amendmentsJson = amArr.toString(),
            versionHistoryJson = vhArr.toString(),
        )
    }

    private fun ReportEntity.toDomain(): ClinicalReport {
        val amArr = JSONArray(amendmentsJson)
        val amendments = List(amArr.length()) { i ->
            val o = amArr.getJSONObject(i)
            ReportAmendment(
                id = o.getString("id"),
                authorName = o.getString("authorName"),
                createdAtIso = o.getString("createdAtIso"),
                reason = o.getString("reason"),
                amendmentText = o.getString("amendmentText"),
            )
        }
        val vhArr = JSONArray(versionHistoryJson)
        val history = List(vhArr.length()) { i ->
            val o = vhArr.getJSONObject(i)
            ReportVersionEntry(
                version = o.getInt("version"),
                status = ReportStatus.valueOf(o.getString("status")),
                authorName = o.getString("authorName"),
                timestampIso = o.getString("timestampIso"),
                summary = o.getString("summary"),
            )
        }
        return ClinicalReport(
            studyInstanceUid = studyInstanceUid,
            patientId = patientId,
            technicalComment = technicalComment,
            clinicalInterpretation = clinicalInterpretation,
            status = ReportStatus.valueOf(status),
            authorId = authorId,
            authorName = authorName,
            updatedAtIso = updatedAtIso,
            signedBy = signedBy,
            signedAtIso = signedAtIso,
            version = version,
            syncState = SyncState.valueOf(syncState),
            amendments = amendments,
            versionHistory = history,
        )
    }

    private fun serializeMetadata(m: ExaminationMetadata): String {
        val o = JSONObject()
        o.put("studyInstanceUid", m.studyInstanceUid)
        o.put("seriesInstanceUid", m.seriesInstanceUid)
        o.put("sopInstanceUid", m.sopInstanceUid)
        o.put("accessionNumber", m.accessionNumber)
        o.put("patientId", m.patientId)
        o.put("patientIdIssuer", m.patientIdIssuer)
        o.put("patientName", m.patientName)
        o.put("examinationDescription", m.examinationDescription)
        o.put("acquisitionDateTime", m.acquisitionDateTime)
        o.put("modality", m.modality)
        o.put("bodyPart", m.bodyPart)
        o.put("viewOrProjection", m.viewOrProjection ?: JSONObject.NULL)
        o.put("laterality", m.laterality ?: JSONObject.NULL)
        o.put("sourceSystem", m.sourceSystem)
        o.put("imageProcessingHistory", JSONArray(m.imageProcessingHistory))
        o.put("isNonDicomReference", m.isNonDicomReference)
        o.put("rowSpacingMm", m.spacingInfo.rowSpacingMm ?: JSONObject.NULL)
        o.put("colSpacingMm", m.spacingInfo.colSpacingMm ?: JSONObject.NULL)
        o.put("calibrationState", m.spacingInfo.calibrationState.name)
        o.put("spacingSourceTag", m.spacingInfo.sourceTag)
        o.put("transferSyntaxUid", m.transferSyntaxUid)
        o.put("originalSha256", m.originalSha256)
        o.put("originalFilePath", m.originalFilePath)
        o.put("priorStudyUid", m.priorStudyUid ?: JSONObject.NULL)
        return o.toString()
    }

    private fun deserializeMetadata(json: String): ExaminationMetadata {
        val o = JSONObject(json)
        val histArr = o.optJSONArray("imageProcessingHistory") ?: JSONArray()
        val hist = List(histArr.length()) { i -> histArr.getString(i) }
        val rowSp = if (o.isNull("rowSpacingMm")) null else o.getDouble("rowSpacingMm")
        val colSp = if (o.isNull("colSpacingMm")) null else o.getDouble("colSpacingMm")
        return ExaminationMetadata(
            studyInstanceUid = o.getString("studyInstanceUid"),
            seriesInstanceUid = o.getString("seriesInstanceUid"),
            sopInstanceUid = o.getString("sopInstanceUid"),
            accessionNumber = o.getString("accessionNumber"),
            patientId = o.getString("patientId"),
            patientIdIssuer = o.getString("patientIdIssuer"),
            patientName = o.getString("patientName"),
            examinationDescription = o.getString("examinationDescription"),
            acquisitionDateTime = o.getString("acquisitionDateTime"),
            modality = o.getString("modality"),
            bodyPart = o.getString("bodyPart"),
            viewOrProjection = if (o.isNull("viewOrProjection")) null else o.getString("viewOrProjection"),
            laterality = if (o.isNull("laterality")) null else o.getString("laterality"),
            sourceSystem = o.getString("sourceSystem"),
            imageProcessingHistory = hist,
            isNonDicomReference = o.getBoolean("isNonDicomReference"),
            spacingInfo = PixelSpacingInfo(
                rowSpacingMm = rowSp,
                colSpacingMm = colSp,
                calibrationState = CalibrationState.valueOf(o.getString("calibrationState")),
                sourceTag = o.getString("spacingSourceTag"),
            ),
            transferSyntaxUid = o.getString("transferSyntaxUid"),
            originalSha256 = o.getString("originalSha256"),
            originalFilePath = o.getString("originalFilePath"),
            priorStudyUid = if (o.isNull("priorStudyUid")) null else o.getString("priorStudyUid"),
        )
    }
}
