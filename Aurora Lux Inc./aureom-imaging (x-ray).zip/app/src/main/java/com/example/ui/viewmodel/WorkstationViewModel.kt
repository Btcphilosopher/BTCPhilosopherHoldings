package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.WorkstationPreferences
import com.example.data.network.AuthResult
import com.example.data.network.DicomWebResult
import com.example.data.network.DicomWebStudyEntry
import com.example.data.repository.ImportOutcome
import com.example.data.repository.WorkstationRepository
import com.example.domain.model.AnnotationTool
import com.example.domain.model.AnnotationType
import com.example.domain.model.AuditEvent
import com.example.domain.model.ClinicalReport
import com.example.domain.model.ClinicianSession
import com.example.domain.model.ConflictRecord
import com.example.domain.model.DisplaySettings
import com.example.domain.model.EquipmentConnectionState
import com.example.domain.model.ExaminationSummary
import com.example.domain.model.ImagePoint
import com.example.domain.model.QualityChecklist
import com.example.domain.model.RadiographAnnotation
import com.example.domain.model.RadiographPixelData
import com.example.domain.model.ReportAmendment
import com.example.domain.model.ReportStatus
import com.example.domain.model.ReportVersionEntry
import com.example.domain.model.SyncState
import com.example.imaging.DerivativeExportResult
import com.example.imaging.DerivativeExporter
import com.example.imaging.RadiographRenderer
import com.example.imaging.SyntheticStudyGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.util.UUID

enum class InspectorTab(val title: String) {
    DISPLAY("Display"),
    ANNOTATE("Annotate"),
    QUALITY("QA Review"),
    REPORT("Report"),
    ARCHIVE("Audit & Sync"),
}

enum class CompactDestination(val title: String) {
    WORKLIST("Worklist"),
    VIEWER("Viewer"),
    TOOLS("Tools"),
    REPORT("QA / Report"),
    SECURITY("Security"),
}

data class UnsupportedErrorDialogState(
    val title: String,
    val detail: String,
    val errorCode: String,
)

data class WorkstationUiState(
    val session: ClinicianSession? = null,
    val isSessionLocked: Boolean = false,
    val isAuthenticating: Boolean = false,
    val authError: String? = null,
    val preferOfflineDemo: Boolean = true,
    val pendingConfirmationStudy: ExaminationSummary? = null,
    val activeStudy: ExaminationSummary? = null,
    val activePixels: RadiographPixelData? = null,
    val activeBitmap: Bitmap? = null,
    val displaySettings: DisplaySettings = DisplaySettings(1850.0, 2200.0),
    val isComparisonMode: Boolean = false,
    val comparisonStudy: ExaminationSummary? = null,
    val comparisonPixels: RadiographPixelData? = null,
    val comparisonBitmap: Bitmap? = null,
    val comparisonDisplaySettings: DisplaySettings = DisplaySettings(1850.0, 2200.0),
    val syncComparisonView: Boolean = true,
    val activeTool: AnnotationTool = AnnotationTool.PAN_ZOOM,
    val draftPoints: List<ImagePoint> = emptyList(),
    val pendingTextNotePoint: ImagePoint? = null,
    val inspectorTab: InspectorTab = InspectorTab.DISPLAY,
    val compactDestination: CompactDestination = CompactDestination.WORKLIST,
    val automatedTechnicalFlags: List<String> = emptyList(),
    val equipmentState: EquipmentConnectionState = EquipmentConnectionState(),
    val unsupportedDialog: UnsupportedErrorDialogState? = null,
    val activeConflict: ConflictRecord? = null,
    val lastExportResult: DerivativeExportResult? = null,
    val dicomWebQueryResults: List<DicomWebStudyEntry> = emptyList(),
    val statusBannerMessage: String? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class WorkstationViewModel(
    application: Application,
) : AndroidViewModel(application) {

    private val repository = WorkstationRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(WorkstationUiState())
    val uiState: StateFlow<WorkstationUiState> = _uiState.asStateFlow()

    val preferences: StateFlow<WorkstationPreferences> = repository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), WorkstationPreferences())

    val studies: StateFlow<List<ExaminationSummary>> = repository.studiesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditEvents: StateFlow<List<AuditEvent>> = repository.auditEventsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val activeStudyKey = MutableStateFlow<Pair<String, String>?>(null)

    val activeAnnotations: StateFlow<List<RadiographAnnotation>> = activeStudyKey
        .flatMapLatest { key ->
            if (key == null) flowOf(emptyList())
            else repository.observeAnnotations(key.first, key.second)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeQualityReview: StateFlow<QualityChecklist?> = activeStudyKey
        .flatMapLatest { key ->
            if (key == null) flowOf(null) else repository.observeQualityReview(key.first)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeReport: StateFlow<ClinicalReport?> = activeStudyKey
        .flatMapLatest { key ->
            if (key == null) flowOf(null) else repository.observeReport(key.first)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch {
            repository.ensureDemoFixturesSeeded(null)
            _uiState.update { it.copy(equipmentState = repository.equipmentAdapter.getDeviceIdentity()) }
        }
    }

    fun signIn(username: String, passcode: String, preferOfflineDemo: Boolean) {
        viewModelScope.launch {
            _uiState.update { it.copy(isAuthenticating = true, authError = null, preferOfflineDemo = preferOfflineDemo) }
            val result = repository.authAdapter.authenticate(
                username = username,
                passcode = passcode,
                backendBaseUrl = preferences.value.backendBaseUrl,
                preferOfflineDemo = preferOfflineDemo,
            )
            when (result) {
                is AuthResult.Rejected -> {
                    _uiState.update { it.copy(isAuthenticating = false, authError = result.message) }
                }
                is AuthResult.Authenticated -> {
                    repository.credentialStore.saveProtectedToken(
                        result.session.token,
                        "${result.session.userId}|${result.session.displayName}|${result.session.role}",
                    )
                    repository.ensureDemoFixturesSeeded(result.session)
                    repository.recordAudit(
                        actor = result.session,
                        action = "WORKSTATION_SIGN_IN",
                        patientId = null,
                        studyUid = null,
                        sopUid = null,
                        details = "Signed in via ${result.session.authMode} as ${result.session.displayName} (${result.session.role}).",
                    )
                    _uiState.update {
                        it.copy(
                            session = result.session,
                            isSessionLocked = false,
                            isAuthenticating = false,
                            authError = null,
                            statusBannerMessage = "Authenticated as ${result.session.displayName}",
                        )
                    }
                }
            }
        }
    }

    fun lockSession() {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            repository.recordAudit(
                actor = actor,
                action = "SESSION_LOCKED",
                patientId = _uiState.value.activeStudy?.patientId,
                studyUid = _uiState.value.activeStudy?.studyInstanceUid,
                sopUid = _uiState.value.activeStudy?.sopInstanceUid,
                details = "Workstation locked; radiographic display and PHI obscured.",
            )
        }
        _uiState.update { it.copy(isSessionLocked = true, draftPoints = emptyList(), pendingTextNotePoint = null) }
    }

    fun unlockSession(passcode: String) {
        val current = _uiState.value.session ?: return
        val username = if (current.role == "RADIOGRAPHER") "radiographer@aureom.local" else "radiologist@aureom.local"
        viewModelScope.launch {
            _uiState.update { it.copy(isAuthenticating = true, authError = null) }
            val res = repository.authAdapter.authenticate(
                username = username,
                passcode = passcode,
                backendBaseUrl = preferences.value.backendBaseUrl,
                preferOfflineDemo = _uiState.value.preferOfflineDemo,
            )
            when (res) {
                is AuthResult.Authenticated -> {
                    repository.recordAudit(
                        actor = current,
                        action = "SESSION_UNLOCKED",
                        patientId = _uiState.value.activeStudy?.patientId,
                        studyUid = _uiState.value.activeStudy?.studyInstanceUid,
                        sopUid = null,
                        details = "Clinician re-authenticated to unlock session.",
                    )
                    _uiState.update { it.copy(isSessionLocked = false, isAuthenticating = false, authError = null) }
                }
                is AuthResult.Rejected -> {
                    _uiState.update { it.copy(isAuthenticating = false, authError = res.message) }
                }
            }
        }
    }

    fun signOut() {
        val actor = _uiState.value.session
        viewModelScope.launch {
            if (actor != null) {
                repository.recordAudit(
                    actor = actor,
                    action = "WORKSTATION_SIGN_OUT",
                    patientId = null,
                    studyUid = null,
                    sopUid = null,
                    details = "Signed out and cleared protected session token.",
                )
            }
            repository.credentialStore.clearProtectedSession()
        }
        activeStudyKey.value = null
        _uiState.value = WorkstationUiState()
    }

    fun requestOpenStudy(study: ExaminationSummary) {
        // Always require explicit patient & examination confirmation before switching patients or opening
        _uiState.update {
            it.copy(
                pendingConfirmationStudy = study,
                draftPoints = emptyList(),
                pendingTextNotePoint = null,
            )
        }
    }

    fun cancelStudyConfirmation() {
        _uiState.update { it.copy(pendingConfirmationStudy = null) }
    }

    fun confirmAndOpenStudy(study: ExaminationSummary) {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(pendingConfirmationStudy = null) }
            val loaded = repository.loadStudyPixels(study.studyInstanceUid)
            if (loaded == null || loaded.pixelData == null) {
                repository.recordAudit(
                    actor = actor,
                    action = "PATIENT_CONFIRMED_NO_PIXELS",
                    patientId = study.patientId,
                    studyUid = study.studyInstanceUid,
                    sopUid = study.sopInstanceUid,
                    details = "Confirmed ${study.patientId}; image payload unavailable (${study.receiptStatus.label}).",
                )
                activeStudyKey.value = study.studyInstanceUid to study.patientId
                _uiState.update {
                    it.copy(
                        activeStudy = study,
                        activePixels = null,
                        activeBitmap = null,
                        isComparisonMode = false,
                        comparisonStudy = null,
                        comparisonPixels = null,
                        comparisonBitmap = null,
                        compactDestination = CompactDestination.VIEWER,
                        statusBannerMessage = "Study has no verified pixel buffer yet. Use Retry Transfer if interrupted.",
                    )
                }
                return@launch
            }

            val px = loaded.pixelData
            val defaultSettings = DisplaySettings(
                windowCenter = px.defaultWindowCenter,
                windowWidth = px.defaultWindowWidth,
            )
            val bmp = withContext(Dispatchers.Default) {
                RadiographRenderer.renderToBitmap(px, defaultSettings)
            }
            val autoFlags = RadiographRenderer.runNonDiagnosticTechnicalChecks(px, loaded.summary.metadata)

            // Automatically load linked prior comparison if present
            val priorUid = loaded.summary.priorStudyUid
            val priorLoaded = if (priorUid != null) repository.loadStudyPixels(priorUid) else null
            val priorSettings = priorLoaded?.pixelData?.let {
                DisplaySettings(it.defaultWindowCenter, it.defaultWindowWidth)
            } ?: defaultSettings
            val priorBmp = priorLoaded?.pixelData?.let { p ->
                withContext(Dispatchers.Default) { RadiographRenderer.renderToBitmap(p, priorSettings) }
            }

            activeStudyKey.value = loaded.summary.studyInstanceUid to loaded.summary.patientId
            repository.recordAudit(
                actor = actor,
                action = "PATIENT_CONFIRMED_AND_VIEWED",
                patientId = loaded.summary.patientId,
                studyUid = loaded.summary.studyInstanceUid,
                sopUid = loaded.summary.sopInstanceUid,
                details = "Confirmed identity ${loaded.summary.patientId} (${loaded.summary.patientIdIssuer}) and opened '${loaded.summary.description}'.",
            )

            _uiState.update {
                it.copy(
                    activeStudy = loaded.summary,
                    activePixels = px,
                    activeBitmap = bmp,
                    displaySettings = defaultSettings,
                    comparisonStudy = priorLoaded?.summary,
                    comparisonPixels = priorLoaded?.pixelData,
                    comparisonBitmap = priorBmp,
                    comparisonDisplaySettings = priorSettings,
                    isComparisonMode = false,
                    draftPoints = emptyList(),
                    pendingTextNotePoint = null,
                    automatedTechnicalFlags = autoFlags,
                    compactDestination = CompactDestination.VIEWER,
                    statusBannerMessage = "Confirmed ${loaded.summary.patientName} (${loaded.summary.patientId})",
                )
            }
        }
    }

    fun selectComparisonStudy(study: ExaminationSummary) {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            val loaded = repository.loadStudyPixels(study.studyInstanceUid) ?: return@launch
            val px = loaded.pixelData ?: return@launch
            val settings = DisplaySettings(px.defaultWindowCenter, px.defaultWindowWidth)
            val bmp = withContext(Dispatchers.Default) {
                RadiographRenderer.renderToBitmap(px, settings)
            }
            repository.recordAudit(
                actor = actor,
                action = "COMPARISON_STUDY_MOUNTED",
                patientId = loaded.summary.patientId,
                studyUid = loaded.summary.studyInstanceUid,
                sopUid = loaded.summary.sopInstanceUid,
                details = "Mounted comparison image '${loaded.summary.description}' alongside active view.",
            )
            _uiState.update {
                it.copy(
                    isComparisonMode = true,
                    comparisonStudy = loaded.summary,
                    comparisonPixels = px,
                    comparisonBitmap = bmp,
                    comparisonDisplaySettings = settings,
                )
            }
        }
    }

    fun toggleComparisonMode() {
        val state = _uiState.value
        if (!state.isComparisonMode && state.comparisonStudy == null) {
            // Try picking another study from worklist as comparison (preferring same patient)
            val currentUid = state.activeStudy?.studyInstanceUid
            val samePatient = studies.value.firstOrNull {
                it.studyInstanceUid != currentUid && it.patientId == state.activeStudy?.patientId && it.metadata.originalFilePath.isNotBlank()
            } ?: studies.value.firstOrNull {
                it.studyInstanceUid != currentUid && it.metadata.originalFilePath.isNotBlank()
            }
            if (samePatient != null) {
                selectComparisonStudy(samePatient)
                return
            }
        }
        _uiState.update { it.copy(isComparisonMode = !it.isComparisonMode) }
    }

    fun toggleSyncComparisonView() {
        _uiState.update { it.copy(syncComparisonView = !it.syncComparisonView) }
    }

    fun updateWindowLevel(center: Double, width: Double) {
        val px = _uiState.value.activePixels ?: return
        val clampedWidth = width.coerceIn(1.0, 8192.0)
        val clampedCenter = center.coerceIn(-2048.0, 8192.0)
        val newSettings = _uiState.value.displaySettings.copy(
            windowCenter = clampedCenter,
            windowWidth = clampedWidth,
        )
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.Default) {
                RadiographRenderer.renderToBitmap(px, newSettings)
            }
            _uiState.update { it.copy(displaySettings = newSettings, activeBitmap = bmp) }
            if (_uiState.value.syncComparisonView && _uiState.value.isComparisonMode) {
                val cpx = _uiState.value.comparisonPixels
                if (cpx != null) {
                    val cSettings = _uiState.value.comparisonDisplaySettings.copy(
                        windowCenter = clampedCenter,
                        windowWidth = clampedWidth,
                    )
                    val cbmp = withContext(Dispatchers.Default) {
                        RadiographRenderer.renderToBitmap(cpx, cSettings)
                    }
                    _uiState.update { it.copy(comparisonDisplaySettings = cSettings, comparisonBitmap = cbmp) }
                }
            }
        }
    }

    fun updateZoomPan(zoom: Float, panX: Float, panY: Float) {
        val clampedZoom = zoom.coerceIn(0.4f, 8.0f)
        _uiState.update { state ->
            val updated = state.displaySettings.copy(zoom = clampedZoom, panX = panX, panY = panY)
            val compUpdated = if (state.syncComparisonView) {
                state.comparisonDisplaySettings.copy(zoom = clampedZoom, panX = panX, panY = panY)
            } else {
                state.comparisonDisplaySettings
            }
            state.copy(displaySettings = updated, comparisonDisplaySettings = compUpdated)
        }
    }

    fun fitToScreen() {
        _uiState.update {
            it.copy(
                displaySettings = it.displaySettings.copy(zoom = 1.0f, panX = 0f, panY = 0f),
            )
        }
    }

    fun rotateCw90() {
        _uiState.update {
            val next = (it.displaySettings.rotationDegrees + 90) % 360
            it.copy(displaySettings = it.displaySettings.copy(rotationDegrees = next))
        }
    }

    fun flipHorizontal() {
        _uiState.update {
            it.copy(displaySettings = it.displaySettings.copy(flipHorizontal = !it.displaySettings.flipHorizontal))
        }
    }

    fun flipVertical() {
        _uiState.update {
            it.copy(displaySettings = it.displaySettings.copy(flipVertical = !it.displaySettings.flipVertical))
        }
    }

    fun toggleInvertGrayscale() {
        val px = _uiState.value.activePixels ?: return
        val newSettings = _uiState.value.displaySettings.copy(inverted = !_uiState.value.displaySettings.inverted)
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.Default) {
                RadiographRenderer.renderToBitmap(px, newSettings)
            }
            _uiState.update { it.copy(displaySettings = newSettings, activeBitmap = bmp) }
        }
    }

    fun toggleOverlays() {
        _uiState.update {
            it.copy(displaySettings = it.displaySettings.copy(showOverlays = !it.displaySettings.showOverlays))
        }
    }

    fun resetDisplayToDefault() {
        val px = _uiState.value.activePixels ?: return
        val defaultSettings = DisplaySettings(
            windowCenter = px.defaultWindowCenter,
            windowWidth = px.defaultWindowWidth,
        )
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.Default) {
                RadiographRenderer.renderToBitmap(px, defaultSettings)
            }
            _uiState.update {
                it.copy(
                    displaySettings = defaultSettings,
                    activeBitmap = bmp,
                    statusBannerMessage = "Display restored to original DICOM defaults",
                )
            }
        }
    }

    fun selectTool(tool: AnnotationTool) {
        _uiState.update { it.copy(activeTool = tool, draftPoints = emptyList(), pendingTextNotePoint = null) }
    }

    fun updateDraftPoints(points: List<ImagePoint>) {
        _uiState.update { it.copy(draftPoints = points) }
    }

    fun promptTextNoteAt(point: ImagePoint) {
        _uiState.update { it.copy(pendingTextNotePoint = point) }
    }

    fun dismissTextNotePrompt() {
        _uiState.update { it.copy(pendingTextNotePoint = null) }
    }

    fun commitTextNote(text: String) {
        val pt = _uiState.value.pendingTextNotePoint ?: return
        if (text.isBlank()) {
            _uiState.update { it.copy(pendingTextNotePoint = null) }
            return
        }
        saveAnnotation(AnnotationType.TEXT_NOTE, listOf(pt), text.trim())
        _uiState.update { it.copy(pendingTextNotePoint = null) }
    }

    fun saveAnnotation(
        type: AnnotationType,
        points: List<ImagePoint>,
        text: String = "",
    ) {
        val actor = _uiState.value.session ?: return
        val study = _uiState.value.activeStudy ?: return
        val px = _uiState.value.activePixels ?: return
        val now = Instant.now().toString()

        val summary = when (type) {
            AnnotationType.LENGTH -> if (points.size >= 2) {
                RadiographRenderer.formatLengthMeasurement(points[0], points[1], study.metadata.spacingInfo)
            } else ""
            AnnotationType.ANGLE -> if (points.size >= 3) {
                RadiographRenderer.formatAngleMeasurement(points[0], points[1], points[2])
            } else ""
            AnnotationType.ROI_BOX -> if (points.size >= 2) {
                val stats = RadiographRenderer.computeRoiStatistics(px, points[0], points[1])
                "ROI μ=${"%.0f".format(stats.meanRaw)} σ=${"%.0f".format(stats.stdDevRaw)} [${stats.minRaw}..${stats.maxRaw}]"
            } else ""
            AnnotationType.TEXT_NOTE -> text
            AnnotationType.ARROW -> if (text.isNotBlank()) text else "Arrow"
            AnnotationType.FREEHAND -> "Freehand (${points.size} pts)"
        }

        val roiStats = if (type == AnnotationType.ROI_BOX && points.size >= 2) {
            RadiographRenderer.computeRoiStatistics(px, points[0], points[1])
        } else null

        val ann = RadiographAnnotation(
            id = UUID.randomUUID().toString(),
            patientId = study.patientId,
            studyInstanceUid = study.studyInstanceUid,
            sopInstanceUid = study.sopInstanceUid,
            type = type,
            points = points,
            text = text,
            authorId = actor.userId,
            authorName = actor.displayName,
            createdAtIso = now,
            updatedAtIso = now,
            measurementSummary = summary,
            roiStats = roiStats,
            syncState = SyncState.PENDING_UPLOAD,
            version = 1,
        )
        viewModelScope.launch {
            repository.saveAnnotation(ann, study, actor)
            _uiState.update { it.copy(draftPoints = emptyList()) }
        }
    }

    fun deleteAnnotation(annotation: RadiographAnnotation) {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            repository.deleteAnnotation(annotation, actor)
        }
    }

    fun saveQualityChecklist(
        positioning: Boolean,
        motion: Boolean,
        incompleteCoverage: Boolean,
        missingOrientation: Boolean,
        processingIssue: Boolean,
        furtherReview: Boolean,
        technicalNotes: String,
    ) {
        val actor = _uiState.value.session ?: return
        val study = _uiState.value.activeStudy ?: return
        val checklist = QualityChecklist(
            studyInstanceUid = study.studyInstanceUid,
            sopInstanceUid = study.sopInstanceUid,
            positioningConcerns = positioning,
            motionArtefact = motion,
            incompleteFieldCoverage = incompleteCoverage,
            missingOrientationInfo = missingOrientation,
            suspectedProcessingIssues = processingIssue,
            furtherReviewRequired = furtherReview,
            technicalNotes = technicalNotes,
            reviewerName = actor.displayName,
            reviewedAtIso = Instant.now().toString(),
            automatedFlags = _uiState.value.automatedTechnicalFlags,
        )
        viewModelScope.launch {
            repository.saveQualityChecklist(checklist, study, actor)
            _uiState.update { it.copy(statusBannerMessage = "Technical QA review saved by ${actor.displayName}") }
        }
    }

    fun saveReportDraft(technicalComment: String, clinicalInterpretation: String, submitForReview: Boolean) {
        val actor = _uiState.value.session ?: return
        val study = _uiState.value.activeStudy ?: return
        val current = activeReport.value
        if (current?.status == ReportStatus.SIGNED || current?.status == ReportStatus.AMENDED) {
            _uiState.update { it.copy(statusBannerMessage = "Signed reports are immutable; add a linked amendment instead.") }
            return
        }
        val nextStatus = if (submitForReview) ReportStatus.UNDER_REVIEW else ReportStatus.DRAFT_SAVED
        val nextVersion = (current?.version ?: 0) + 1
        val now = Instant.now().toString()
        val entry = ReportVersionEntry(
            version = nextVersion,
            status = nextStatus,
            authorName = actor.displayName,
            timestampIso = now,
            summary = if (submitForReview) "Submitted for review" else "Saved draft",
        )
        val report = ClinicalReport(
            studyInstanceUid = study.studyInstanceUid,
            patientId = study.patientId,
            technicalComment = technicalComment,
            clinicalInterpretation = clinicalInterpretation,
            status = nextStatus,
            authorId = actor.userId,
            authorName = actor.displayName,
            updatedAtIso = now,
            version = nextVersion,
            syncState = SyncState.PENDING_UPLOAD,
            amendments = current?.amendments ?: emptyList(),
            versionHistory = (current?.versionHistory ?: emptyList()) + entry,
        )
        viewModelScope.launch {
            repository.saveReport(
                report = report,
                study = study,
                actor = actor,
                auditAction = if (submitForReview) "REPORT_SUBMITTED_FOR_REVIEW" else "REPORT_DRAFT_SAVED",
            )
            _uiState.update { it.copy(statusBannerMessage = "Report v$nextVersion saved (${nextStatus.label})") }
        }
    }

    fun signReport(technicalComment: String, clinicalInterpretation: String) {
        val actor = _uiState.value.session ?: return
        val study = _uiState.value.activeStudy ?: return
        val current = activeReport.value
        val nextVersion = (current?.version ?: 0) + 1
        val now = Instant.now().toString()
        val entry = ReportVersionEntry(
            version = nextVersion,
            status = ReportStatus.SIGNED,
            authorName = actor.displayName,
            timestampIso = now,
            summary = "Signed electronically by ${actor.displayName}",
        )
        val report = ClinicalReport(
            studyInstanceUid = study.studyInstanceUid,
            patientId = study.patientId,
            technicalComment = technicalComment,
            clinicalInterpretation = clinicalInterpretation,
            status = ReportStatus.SIGNED,
            authorId = actor.userId,
            authorName = actor.displayName,
            updatedAtIso = now,
            signedBy = actor.displayName,
            signedAtIso = now,
            version = nextVersion,
            syncState = SyncState.PENDING_UPLOAD,
            amendments = current?.amendments ?: emptyList(),
            versionHistory = (current?.versionHistory ?: emptyList()) + entry,
        )
        viewModelScope.launch {
            repository.saveReport(report, study, actor, "REPORT_SIGNED")
            _uiState.update { it.copy(statusBannerMessage = "Report signed (v$nextVersion) by ${actor.displayName}") }
        }
    }

    fun addReportAmendment(reason: String, amendmentText: String) {
        val actor = _uiState.value.session ?: return
        val study = _uiState.value.activeStudy ?: return
        val current = activeReport.value ?: return
        if (reason.isBlank() || amendmentText.isBlank()) return
        val now = Instant.now().toString()
        val nextVersion = current.version + 1
        val amendment = ReportAmendment(
            id = UUID.randomUUID().toString(),
            authorName = actor.displayName,
            createdAtIso = now,
            reason = reason.trim(),
            amendmentText = amendmentText.trim(),
        )
        val entry = ReportVersionEntry(
            version = nextVersion,
            status = ReportStatus.AMENDED,
            authorName = actor.displayName,
            timestampIso = now,
            summary = "Linked amendment added: ${reason.trim()}",
        )
        val updated = current.copy(
            status = ReportStatus.AMENDED,
            version = nextVersion,
            updatedAtIso = now,
            amendments = current.amendments + amendment,
            versionHistory = current.versionHistory + entry,
            syncState = SyncState.PENDING_UPLOAD,
        )
        viewModelScope.launch {
            repository.saveReport(updated, study, actor, "REPORT_AMENDED")
            _uiState.update { it.copy(statusBannerMessage = "Linked amendment recorded (v$nextVersion)") }
        }
    }

    fun importDocument(uri: Uri, displayName: String) {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            when (val res = repository.importFromUri(uri, displayName, actor)) {
                is ImportOutcome.Unsupported -> {
                    _uiState.update {
                        it.copy(
                            unsupportedDialog = UnsupportedErrorDialogState(res.title, res.detail, res.errorCode),
                        )
                    }
                }
                is ImportOutcome.Imported -> {
                    val note = if (res.isDuplicate) "Duplicate skipped; opened existing cached study." else "Imported '${res.summary.description}'."
                    _uiState.update { it.copy(statusBannerMessage = note) }
                    requestOpenStudy(res.summary)
                }
            }
        }
    }

    fun importUnsupportedJ2kDemo() {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            val bytes = SyntheticStudyGenerator.generateUnsupportedJpeg2000Dicom()
            when (val res = repository.importRawBytes(bytes, "unsupported_j2k_demo.dcm", "DEMO-LIBRARY", actor)) {
                is ImportOutcome.Unsupported -> {
                    _uiState.update {
                        it.copy(unsupportedDialog = UnsupportedErrorDialogState(res.title, res.detail, res.errorCode))
                    }
                }
                is ImportOutcome.Imported -> Unit
            }
        }
    }

    fun importNonDicomPngDemo() {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            val bytes = SyntheticStudyGenerator.generateNonDicomPngReference()
            when (val res = repository.importRawBytes(bytes, "reference_xray_phantom.png", "DEMO-LIBRARY", actor)) {
                is ImportOutcome.Imported -> {
                    _uiState.update { it.copy(statusBannerMessage = "Imported non-DICOM PNG reference image.") }
                    requestOpenStudy(res.summary)
                }
                is ImportOutcome.Unsupported -> {
                    _uiState.update {
                        it.copy(unsupportedDialog = UnsupportedErrorDialogState(res.title, res.detail, res.errorCode))
                    }
                }
            }
        }
    }

    fun dismissUnsupportedDialog() {
        _uiState.update { it.copy(unsupportedDialog = null) }
    }

    fun simulateEquipmentTransfer(studyUid: String, simulateInterruptFailure: Boolean) {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            repository.equipmentAdapter.simulateIncomingAcquisition(studyUid, simulateInterruptFailure)
                .collect { event ->
                    repository.applyEquipmentTransferEvent(event, actor)
                    _uiState.update {
                        it.copy(
                            equipmentState = it.equipmentState.copy(
                                activeTransferStudyUid = event.studyInstanceUid,
                                currentStatus = event.acquisitionStatus,
                                progressPercent = event.progressPercent,
                                statusMessage = event.message,
                            ),
                            statusBannerMessage = event.message,
                        )
                    }
                }
        }
    }

    fun queryDicomWebArchive(useLocalTestArchive: Boolean) {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            val adapter = if (useLocalTestArchive) repository.localArchiveAdapter else repository.remoteDicomWebAdapter
            val endpoint = preferences.value.dicomWebBaseUrl
            val cred = if (useLocalTestArchive) null else repository.credentialStore.readArchiveCredential()
            when (val res = adapter.queryStudiesQidoRs(endpoint, cred)) {
                is DicomWebResult.Success -> {
                    repository.recordAudit(
                        actor = actor,
                        action = "DICOMWEB_QIDO_QUERY",
                        patientId = null,
                        studyUid = null,
                        sopUid = null,
                        details = "Queried ${if (useLocalTestArchive) "Local Test Archive" else endpoint}: ${res.data.size} study record(s).",
                    )
                    _uiState.update {
                        it.copy(
                            dicomWebQueryResults = res.data,
                            statusBannerMessage = "DICOMweb QIDO-RS returned ${res.data.size} study(ies)",
                        )
                    }
                }
                is DicomWebResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            unsupportedDialog = UnsupportedErrorDialogState(
                                title = "DICOMweb Query Failed",
                                detail = res.message,
                                errorCode = "QIDO_${res.statusCode}",
                            ),
                        )
                    }
                }
            }
        }
    }

    fun retrieveDicomWebEntry(entry: DicomWebStudyEntry, useLocalTestArchive: Boolean) {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            when (
                val res = repository.retrieveFromDicomWeb(
                    useLocalArchive = useLocalTestArchive,
                    endpoint = preferences.value.dicomWebBaseUrl,
                    studyUid = entry.studyInstanceUid,
                    seriesUid = entry.seriesInstanceUid,
                    sopUid = entry.sopInstanceUid,
                    actor = actor,
                )
            ) {
                is ImportOutcome.Imported -> {
                    _uiState.update { it.copy(statusBannerMessage = "WADO-RS retrieved '${res.summary.description}'") }
                    requestOpenStudy(res.summary)
                }
                is ImportOutcome.Unsupported -> {
                    _uiState.update {
                        it.copy(unsupportedDialog = UnsupportedErrorDialogState(res.title, res.detail, res.errorCode))
                    }
                }
            }
        }
    }

    fun exportReviewedDerivative() {
        val actor = _uiState.value.session ?: return
        val study = _uiState.value.activeStudy ?: return
        val px = _uiState.value.activePixels ?: return
        val anns = activeAnnotations.value
        val settings = _uiState.value.displaySettings
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                DerivativeExporter.exportReviewedDerivative(
                    context = getApplication(),
                    pixelData = px,
                    metadata = study.metadata,
                    displaySettings = settings,
                    annotations = anns,
                    exportedBy = actor.displayName,
                    exportedAtIso = Instant.now().toString(),
                )
            }
            repository.recordAudit(
                actor = actor,
                action = "DERIVATIVE_EXPORTED",
                patientId = study.patientId,
                studyUid = study.studyInstanceUid,
                sopUid = study.sopInstanceUid,
                details = "Exported reviewed derivative PNG (${result.file.name}, SHA256=${result.sha256.take(12)}…, ${anns.size} annotations). Original DICOM preserved.",
            )
            _uiState.update {
                it.copy(
                    lastExportResult = result,
                    statusBannerMessage = "Exported reviewed derivative: ${result.file.name}",
                )
            }
        }
    }

    fun dismissExportResult() {
        _uiState.update { it.copy(lastExportResult = null) }
    }

    fun triggerSyncConflictDemo() {
        val actor = _uiState.value.session ?: return
        val study = _uiState.value.activeStudy ?: return
        viewModelScope.launch {
            val conflict = repository.simulateSyncConflict(study, actor)
            _uiState.update { it.copy(activeConflict = conflict) }
        }
    }

    fun resolveSyncConflict(strategy: String) {
        val actor = _uiState.value.session ?: return
        val conflict = _uiState.value.activeConflict ?: return
        viewModelScope.launch {
            repository.resolveSyncConflict(conflict.studyInstanceUid, strategy, actor)
            _uiState.update {
                it.copy(
                    activeConflict = null,
                    statusBannerMessage = "Sync conflict resolved ($strategy)",
                )
            }
        }
    }

    fun purgeExpiredCache() {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            val count = repository.purgeExpiredCache(preferences.value.retentionHours, actor)
            _uiState.update { it.copy(statusBannerMessage = "Purged $count expired cached file(s)") }
        }
    }

    fun clearAllAndReseedDemo() {
        val actor = _uiState.value.session ?: return
        viewModelScope.launch {
            repository.clearAllCachedStudiesAndReseed(actor)
            repository.ensureDemoFixturesSeeded(actor)
            activeStudyKey.value = null
            _uiState.update {
                it.copy(
                    activeStudy = null,
                    activePixels = null,
                    activeBitmap = null,
                    statusBannerMessage = "Local cache cleared and demo fixtures restored",
                )
            }
        }
    }

    fun updateEndpointsAndPolicy(backendUrl: String, dicomWebUrl: String, retentionHours: Int) {
        viewModelScope.launch {
            repository.credentialStore.updatePreferences {
                it.copy(
                    backendBaseUrl = backendUrl,
                    dicomWebBaseUrl = dicomWebUrl,
                    retentionHours = retentionHours,
                )
            }
            _uiState.update { it.copy(statusBannerMessage = "Archive endpoints & retention policy updated") }
        }
    }

    fun updateTextScale(scale: Float) {
        viewModelScope.launch {
            repository.credentialStore.updatePreferences { it.copy(textScale = scale) }
        }
    }

    fun selectInspectorTab(tab: InspectorTab) {
        _uiState.update { it.copy(inspectorTab = tab) }
    }

    fun selectCompactDestination(dest: CompactDestination) {
        _uiState.update { it.copy(compactDestination = dest) }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }
}
