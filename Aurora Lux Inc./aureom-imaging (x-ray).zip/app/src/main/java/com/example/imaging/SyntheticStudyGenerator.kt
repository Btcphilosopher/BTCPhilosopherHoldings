package com.example.imaging

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.example.domain.model.PhotometricInterpretation
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Generates deterministic, synthetic, de-identified 12-bit radiographic DICOM Part 10 fixtures
 * and reference fixtures so the APK demonstrates real DICOM parsing, MONOCHROME1/2 rendering,
 * calibrated vs detector-plane vs uncalibrated measurements, comparison pairs, and error states.
 */
object SyntheticStudyGenerator {

    fun generateChestPaDicom(
        isPrior: Boolean = false,
        studyUid: String = if (isPrior) "1.2.826.0.1.3680043.8.498.1000.PRIOR" else "1.2.826.0.1.3680043.8.498.1000.CURR",
        sopUid: String = if (isPrior) "1.2.826.0.1.3680043.8.498.1000.PRIOR.1" else "1.2.826.0.1.3680043.8.498.1000.CURR.1",
    ): ByteArray {
        val w = 512
        val h = 512
        val pixels = IntArray(w * h)
        val cx = w / 2.0
        val cy = h / 2.0

        for (y in 0 until h) {
            val ny = (y - cy) / (h / 2.0) // -1..1
            for (x in 0 until w) {
                val nx = (x - cx) / (w / 2.0) // -1..1
                var attenuation = 420.0 // Air background

                // Torso soft tissue envelope
                val torsoR = hypot(nx / 0.82, (ny - 0.1) / 0.92)
                if (torsoR < 1.0) {
                    attenuation += 1100.0 * (1.0 - torsoR * 0.45)
                }

                // Lung fields (left and right radiolucent cavities)
                val leftLung = hypot((nx + 0.31) / 0.25, (ny + 0.05) / 0.52)
                val rightLung = hypot((nx - 0.31) / 0.25, (ny + 0.05) / 0.52)
                if (leftLung < 1.0) {
                    val lungClear = (1.0 - leftLung * leftLung) * 780.0
                    attenuation -= lungClear
                    // Subtle bronchovascular texture
                    attenuation += 75.0 * sin(nx * 26.0) * cos(ny * 22.0) * (1.0 - leftLung)
                }
                if (rightLung < 1.0) {
                    val lungClear = (1.0 - rightLung * rightLung) * 780.0
                    attenuation -= lungClear
                    attenuation += 75.0 * sin(nx * 24.0 + 0.8) * cos(ny * 20.0) * (1.0 - rightLung)
                }

                // Posterior & anterior rib arcs
                for (rib in -4..4) {
                    val ribY = rib * 0.13 - 0.06 + 0.09 * nx * nx
                    val dist = abs(ny - ribY)
                    if (dist < 0.024 && abs(nx) in 0.08..0.68) {
                        attenuation += 480.0 * (1.0 - dist / 0.024)
                    }
                }

                // Clavicles
                val clavDistL = abs(ny + 0.48 - 0.16 * (nx + 0.15))
                if (clavDistL < 0.022 && nx in -0.62..-0.06) attenuation += 650.0
                val clavDistR = abs(ny + 0.48 + 0.16 * (nx - 0.15))
                if (clavDistR < 0.022 && nx in 0.06..0.62) attenuation += 650.0

                // Thoracic spine & mediastinum + cardiac silhouette (shifted slightly left)
                if (abs(nx) < 0.11 && ny > -0.7 && ny < 0.6) {
                    attenuation += 920.0 * (1.0 - abs(nx) / 0.14)
                }
                val heart = hypot((nx - 0.11) / 0.21, (ny - 0.22) / 0.24)
                if (heart < 1.0) {
                    attenuation += 860.0 * (1.0 - heart * heart)
                }

                // Diaphragmatic domes
                if (ny > 0.42 - 0.12 * cos(nx * 2.5) && abs(nx) < 0.78) {
                    attenuation += 720.0
                }

                // Subtle focal synthetic phantom marker difference between prior & current
                if (!isPrior) {
                    val marker = hypot((nx - 0.34) / 0.045, (ny - 0.08) / 0.045)
                    if (marker < 1.0) attenuation += 460.0 * (1.0 - marker)
                }

                // Deterministic micro-noise
                val hash = ((x * 73856093) xor (y * 19349663)) and 0x3F
                attenuation += (hash - 32) * 1.1

                pixels[y * w + x] = attenuation.toInt().coerceIn(0, 4095)
            }
        }

        // Burn synthetic radiographic "R" lead marker into top-left of PA image (patient right)
        burnLeadMarker(pixels, w, 34, 34, isR = true, value = 3700)

        return DicomCodec.writePart10Dicom(
            DicomWriteRequest(
                width = w,
                height = h,
                bitsAllocated = 16,
                bitsStored = 12,
                photometric = PhotometricInterpretation.MONOCHROME2,
                windowCenter = 1850.0,
                windowWidth = 2200.0,
                rawPixels = pixels,
                patientId = "SYN-PT-10482",
                patientIdIssuer = "AUREOM-DEMO-HOSP",
                patientName = "DEMO^THORAX^ALPHA",
                studyInstanceUid = studyUid,
                seriesInstanceUid = "$studyUid.1",
                sopInstanceUid = sopUid,
                accessionNumber = if (isPrior) "ACC-2026-0411" else "ACC-2026-1124",
                studyDescription = if (isPrior) "Chest PA Radiograph (Prior Baseline)" else "Chest PA Radiograph (Current)",
                acquisitionDate = if (isPrior) "20260512" else "20261124",
                acquisitionTime = if (isPrior) "091420" else "084215",
                modality = "DX",
                bodyPart = "CHEST",
                viewPosition = "PA",
                laterality = "B",
                stationName = "AUREOM-DR-SUITE-01",
                imagerPixelSpacingMm = 0.148 to 0.148,
            ),
        )
    }

    fun generateHandRightMonochrome1Dicom(): ByteArray {
        val w = 512
        val h = 512
        val pixels = IntArray(w * h)
        // MONOCHROME1: 0 = white (dense bone), 4095 = black (air background)
        for (i in pixels.indices) pixels[i] = 3650

        // Draw synthetic wrist + 5 metacarpals/phalanges
        drawBoneSegment(pixels, w, h, 256.0, 465.0, 256.0, 385.0, 34.0, 900)
        drawBoneSegment(pixels, w, h, 198.0, 465.0, 198.0, 392.0, 22.0, 1050)
        // Carpal cluster
        drawOval(pixels, w, h, 236.0, 358.0, 48.0, 24.0, 1150)

        // Fingers (Thumb to Pinky)
        val rays = listOf(
            listOf(190.0 to 345.0, 132.0 to 275.0, 98.0 to 218.0),
            listOf(212.0 to 332.0, 185.0 to 215.0, 168.0 to 118.0),
            listOf(238.0 to 326.0, 238.0 to 195.0, 236.0 to 82.0),
            listOf(266.0 to 330.0, 286.0 to 206.0, 298.0 to 105.0),
            listOf(292.0 to 340.0, 332.0 to 245.0, 354.0 to 165.0),
        )
        for (ray in rays) {
            for (seg in 0 until ray.size - 1) {
                drawBoneSegment(
                    pixels, w, h,
                    ray[seg].first, ray[seg].second,
                    ray[seg + 1].first, ray[seg + 1].second,
                    11.5 - seg * 2.0,
                    1150 + seg * 120,
                )
            }
        }
        // Soft tissue envelope around hand
        for (y in 0 until h) {
            for (x in 0 until w) {
                val hash = ((x * 2654435761L xor y.toLong()) and 0x1F).toInt()
                pixels[y * w + x] = (pixels[y * w + x] + hash - 16).coerceIn(0, 4095)
            }
        }

        return DicomCodec.writePart10Dicom(
            DicomWriteRequest(
                width = w,
                height = h,
                bitsAllocated = 16,
                bitsStored = 12,
                photometric = PhotometricInterpretation.MONOCHROME1,
                windowCenter = 2250.0,
                windowWidth = 2600.0,
                rawPixels = pixels,
                patientId = "SYN-PT-20914",
                patientIdIssuer = "AUREOM-DEMO-HOSP",
                patientName = "DEMO^MANUS^BRAVO",
                studyInstanceUid = "1.2.826.0.1.3680043.8.498.2000.HAND",
                seriesInstanceUid = "1.2.826.0.1.3680043.8.498.2000.HAND.1",
                sopInstanceUid = "1.2.826.0.1.3680043.8.498.2000.HAND.1.1",
                accessionNumber = "ACC-2026-1119",
                studyDescription = "Right Hand PA Radiograph (MONOCHROME1)",
                acquisitionDate = "20261123",
                acquisitionTime = "141805",
                modality = "DX",
                bodyPart = "HAND",
                viewPosition = "PA",
                laterality = "R",
                stationName = "AUREOM-EXTREMITY-02",
                pixelSpacingMm = 0.10 to 0.10,
            ),
        )
    }

    fun generateUncalibratedKneeDicom(): ByteArray {
        val w = 512
        val h = 512
        val pixels = IntArray(w * h)
        for (i in pixels.indices) pixels[i] = 480

        // Femur shaft + condyles
        drawBoneSegment(pixels, w, h, 256.0, 20.0, 256.0, 228.0, 48.0, 2950)
        drawOval(pixels, w, h, 220.0, 232.0, 44.0, 32.0, 3150)
        drawOval(pixels, w, h, 292.0, 232.0, 44.0, 32.0, 3150)
        // Tibial plateau + shaft + fibula
        drawOval(pixels, w, h, 256.0, 286.0, 88.0, 24.0, 3050)
        drawBoneSegment(pixels, w, h, 256.0, 290.0, 256.0, 495.0, 44.0, 2900)
        drawBoneSegment(pixels, w, h, 325.0, 310.0, 336.0, 495.0, 16.0, 2750)
        // Patella shadow
        drawOval(pixels, w, h, 256.0, 204.0, 34.0, 28.0, 3420)

        for (y in 0 until h) {
            for (x in 0 until w) {
                val hash = ((x * 48271 xor y * 16807) and 0x3F) - 32
                pixels[y * w + x] = (pixels[y * w + x] + hash).coerceIn(0, 4095)
            }
        }

        // Deliberately omit PixelSpacing, ImagerPixelSpacing, Laterality, and ViewPosition
        return DicomCodec.writePart10Dicom(
            DicomWriteRequest(
                width = w,
                height = h,
                bitsAllocated = 16,
                bitsStored = 12,
                photometric = PhotometricInterpretation.MONOCHROME2,
                windowCenter = 1900.0,
                windowWidth = 2800.0,
                rawPixels = pixels,
                patientId = "SYN-PT-31507",
                patientIdIssuer = "AUREOM-MOBILE-UNIT",
                patientName = "DEMO^GENU^CHARLIE",
                studyInstanceUid = "1.2.826.0.1.3680043.8.498.3000.KNEE",
                seriesInstanceUid = "1.2.826.0.1.3680043.8.498.3000.KNEE.1",
                sopInstanceUid = "1.2.826.0.1.3680043.8.498.3000.KNEE.1.1",
                accessionNumber = "ACC-2026-1122",
                studyDescription = "Knee Radiograph (Missing Calibration & Laterality)",
                acquisitionDate = "20261124",
                acquisitionTime = "004810",
                modality = "CR",
                bodyPart = "KNEE",
                viewPosition = null,
                laterality = null,
                stationName = "PORTABLE-CR-04",
                pixelSpacingMm = null,
                imagerPixelSpacingMm = null,
            ),
        )
    }

    fun generateUnsupportedJpeg2000Dicom(): ByteArray {
        val pixels = IntArray(64 * 64) { 1000 }
        return DicomCodec.writePart10Dicom(
            DicomWriteRequest(
                width = 64,
                height = 64,
                rawPixels = pixels,
                patientId = "SYN-PT-99900",
                patientIdIssuer = "EXTERNAL-PACS",
                patientName = "DEMO^UNSUPPORTED^J2K",
                studyInstanceUid = "1.2.826.0.1.3680043.8.498.9999.J2K",
                seriesInstanceUid = "1.2.826.0.1.3680043.8.498.9999.J2K.1",
                sopInstanceUid = "1.2.826.0.1.3680043.8.498.9999.J2K.1.1",
                accessionNumber = "ACC-ERR-J2K",
                studyDescription = "Unsupported Compressed Study",
                acquisitionDate = "20261124",
                acquisitionTime = "010000",
                modality = "DX",
                bodyPart = "CHEST",
                transferSyntaxUid = DicomCodec.TS_JPEG_2000_LOSSLESS,
            ),
        )
    }

    fun generateNonDicomPngReference(): ByteArray {
        val bmp = Bitmap.createBitmap(384, 384, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.rgb(18, 22, 26))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(200, 210, 220)
            style = Paint.Style.STROKE
            strokeWidth = 14f
        }
        canvas.drawCircle(192f, 192f, 110f, paint)
        paint.strokeWidth = 6f
        canvas.drawLine(192f, 60f, 192f, 324f, paint)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(240, 240, 240)
            textSize = 20f
        }
        canvas.drawText("NON-DICOM REF", 112f, 44f, textPaint)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }

    private fun drawBoneSegment(
        pixels: IntArray,
        w: Int,
        h: Int,
        x1: Double,
        y1: Double,
        x2: Double,
        y2: Double,
        radius: Double,
        delta: Int,
    ) {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq < 1e-6) return
        val minX = (minOf(x1, x2) - radius - 2).toInt().coerceIn(0, w - 1)
        val maxX = (maxOf(x1, x2) + radius + 2).toInt().coerceIn(0, w - 1)
        val minY = (minOf(y1, y2) - radius - 2).toInt().coerceIn(0, h - 1)
        val maxY = (maxOf(y1, y2) + radius + 2).toInt().coerceIn(0, h - 1)

        for (y in minY..maxY) {
            for (x in minX..maxX) {
                val t = (((x - x1) * dx + (y - y1) * dy) / lenSq).coerceIn(0.0, 1.0)
                val px = x1 + t * dx
                val py = y1 + t * dy
                val d = hypot(x - px, y - py)
                if (d < radius) {
                    val falloff = sqrt(1.0 - (d / radius) * (d / radius))
                    // If MONOCHROME1 bone has lower value, delta can be handled by caller or absolute target
                    val idx = y * w + x
                    pixels[idx] = if (delta < 1500) {
                        (pixels[idx] - (2200 * falloff).toInt()).coerceIn(300, 4095)
                    } else {
                        (pixels[idx] + (delta * 0.75 * falloff).toInt()).coerceIn(0, 4095)
                    }
                }
            }
        }
    }

    private fun drawOval(
        pixels: IntArray,
        w: Int,
        h: Int,
        cx: Double,
        cy: Double,
        rx: Double,
        ry: Double,
        targetDelta: Int,
    ) {
        val minX = (cx - rx - 2).toInt().coerceIn(0, w - 1)
        val maxX = (cx + rx + 2).toInt().coerceIn(0, w - 1)
        val minY = (cy - ry - 2).toInt().coerceIn(0, h - 1)
        val maxY = (cy + ry + 2).toInt().coerceIn(0, h - 1)
        for (y in minY..maxY) {
            for (x in minX..maxX) {
                val r = hypot((x - cx) / rx, (y - cy) / ry)
                if (r < 1.0) {
                    val f = 1.0 - r * r
                    val idx = y * w + x
                    pixels[idx] = if (targetDelta < 1500) {
                        (pixels[idx] - (2000 * f).toInt()).coerceIn(300, 4095)
                    } else {
                        (pixels[idx] + (targetDelta * 0.65 * f).toInt()).coerceIn(0, 4095)
                    }
                }
            }
        }
    }

    private fun burnLeadMarker(pixels: IntArray, w: Int, ox: Int, oy: Int, isR: Boolean, value: Int) {
        val pattern = if (isR) {
            listOf(
                "11110",
                "10001",
                "11110",
                "10100",
                "10010",
                "10001",
            )
        } else {
            listOf(
                "10000",
                "10000",
                "10000",
                "10000",
                "10000",
                "11111",
            )
        }
        for (r in pattern.indices) {
            for (c in pattern[r].indices) {
                if (pattern[r][c] == '1') {
                    for (dy in 0..2) {
                        for (dx in 0..2) {
                            val px = ox + c * 3 + dx
                            val py = oy + r * 3 + dy
                            if (px in 0 until w && py in 0 until w) {
                                pixels[py * w + px] = value
                            }
                        }
                    }
                }
            }
        }
    }
}
