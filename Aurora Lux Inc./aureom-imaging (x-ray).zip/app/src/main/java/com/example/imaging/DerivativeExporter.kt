package com.example.imaging

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import com.example.domain.model.AnnotationType
import com.example.domain.model.DisplaySettings
import com.example.domain.model.ExaminationMetadata
import com.example.domain.model.RadiographAnnotation
import com.example.domain.model.RadiographPixelData
import java.io.File
import java.io.FileOutputStream

data class DerivativeExportResult(
    val file: File,
    val sha256: String,
    val bannerSummary: String,
)

/**
 * Exports a clearly labelled reviewed derivative PNG to app-private storage (filesDir/exports/).
 * Never alters original DICOM pixel data and never writes patient images to the public photo gallery.
 */
object DerivativeExporter {

    fun exportReviewedDerivative(
        context: Context,
        pixelData: RadiographPixelData,
        metadata: ExaminationMetadata,
        displaySettings: DisplaySettings,
        annotations: List<RadiographAnnotation>,
        exportedBy: String,
        exportedAtIso: String,
    ): DerivativeExportResult {
        val baseBitmap = RadiographRenderer.renderToBitmap(pixelData, displaySettings)
        val rot = ((displaySettings.rotationDegrees % 360) + 360) % 360
        val outW = if (rot == 90 || rot == 270) baseBitmap.height else baseBitmap.width
        val outH = if (rot == 90 || rot == 270) baseBitmap.width else baseBitmap.height

        val headerHeight = 84
        val footerHeight = 76
        val finalBitmap = Bitmap.createBitmap(
            outW.coerceAtLeast(640),
            outH + headerHeight + footerHeight,
            Bitmap.Config.ARGB_8888,
        )
        val canvas = Canvas(finalBitmap)
        canvas.drawColor(Color.rgb(12, 16, 21))

        val xOffset = (finalBitmap.width - outW) / 2f
        val matrix = Matrix().apply {
            postTranslate(-baseBitmap.width / 2f, -baseBitmap.height / 2f)
            postScale(
                if (displaySettings.flipHorizontal) -1f else 1f,
                if (displaySettings.flipVertical) -1f else 1f,
            )
            postRotate(rot.toFloat())
            postTranslate(xOffset + outW / 2f, headerHeight + outH / 2f)
        }
        canvas.drawBitmap(baseBitmap, matrix, Paint(Paint.FILTER_BITMAP_FLAG))

        // Draw annotations transformed into the exported image frame
        val annPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(34, 211, 238)
            strokeWidth = 2.5f
            style = Paint.Style.STROKE
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(243, 246, 250)
            textSize = 16f
            typeface = Typeface.MONOSPACE
        }

        for (ann in annotations) {
            val mapped = ann.points.map { pt ->
                val (sx, sy) = RadiographRenderer.imageToScreen(
                    pt = pt,
                    imgW = pixelData.width.toFloat(),
                    imgH = pixelData.height.toFloat(),
                    viewW = outW.toFloat(),
                    viewH = outH.toFloat(),
                    settings = displaySettings.copy(zoom = 1.0f, panX = 0f, panY = 0f),
                )
                (sx + xOffset) to (sy + headerHeight)
            }
            when (ann.type) {
                AnnotationType.ARROW, AnnotationType.LENGTH -> if (mapped.size >= 2) {
                    canvas.drawLine(mapped[0].first, mapped[0].second, mapped[1].first, mapped[1].second, annPaint)
                    if (ann.measurementSummary.isNotBlank()) {
                        canvas.drawText(ann.measurementSummary, mapped[1].first + 6f, mapped[1].second - 6f, textPaint)
                    }
                }
                AnnotationType.ANGLE -> if (mapped.size >= 3) {
                    canvas.drawLine(mapped[0].first, mapped[0].second, mapped[1].first, mapped[1].second, annPaint)
                    canvas.drawLine(mapped[1].first, mapped[1].second, mapped[2].first, mapped[2].second, annPaint)
                    canvas.drawText(ann.measurementSummary, mapped[1].first + 8f, mapped[1].second - 8f, textPaint)
                }
                AnnotationType.FREEHAND -> if (mapped.size >= 2) {
                    val path = Path().apply {
                        moveTo(mapped[0].first, mapped[0].second)
                        for (i in 1 until mapped.size) lineTo(mapped[i].first, mapped[i].second)
                    }
                    canvas.drawPath(path, annPaint)
                }
                AnnotationType.ROI_BOX -> if (mapped.size >= 2) {
                    canvas.drawRect(
                        minOf(mapped[0].first, mapped[1].first),
                        minOf(mapped[0].second, mapped[1].second),
                        maxOf(mapped[0].first, mapped[1].first),
                        maxOf(mapped[0].second, mapped[1].second),
                        annPaint,
                    )
                    if (ann.measurementSummary.isNotBlank()) {
                        canvas.drawText(ann.measurementSummary, mapped[0].first, minOf(mapped[0].second, mapped[1].second) - 6f, textPaint)
                    }
                }
                AnnotationType.TEXT_NOTE -> if (mapped.isNotEmpty()) {
                    canvas.drawCircle(mapped[0].first, mapped[0].second, 5f, annPaint)
                    canvas.drawText(ann.text, mapped[0].first + 10f, mapped[0].second + 4f, textPaint)
                }
            }
        }

        // Header banner clearly identifying reviewed derivative
        val bannerPaint = Paint().apply { color = Color.rgb(14, 58, 71) }
        canvas.drawRect(0f, 0f, finalBitmap.width.toFloat(), headerHeight.toFloat(), bannerPaint)
        val headerTitle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(165, 243, 252)
            textSize = 18f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val headerSub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(243, 246, 250)
            textSize = 14f
            typeface = Typeface.MONOSPACE
        }
        val tagLabel = "REVIEWED DERIVATIVE • ANNOTATED EXPORT (${annotations.size} MARKUPS) • NOT PRIMARY ARCHIVE"
        canvas.drawText(tagLabel, 14f, 28f, headerTitle)
        canvas.drawText(
            "PT: ${metadata.patientId} (${metadata.patientIdIssuer}) | STUDY: ${metadata.studyInstanceUid.takeLast(16)} | MOD: ${metadata.modality}",
            14f,
            52f,
            headerSub,
        )
        canvas.drawText(
            "WC/WW: ${displaySettings.windowCenter.toInt()}/${displaySettings.windowWidth.toInt()} | CALIB: ${metadata.spacingInfo.calibrationState.label}",
            14f,
            72f,
            headerSub,
        )

        // Footer banner
        canvas.drawRect(
            0f,
            (finalBitmap.height - footerHeight).toFloat(),
            finalBitmap.width.toFloat(),
            finalBitmap.height.toFloat(),
            bannerPaint,
        )
        canvas.drawText(
            "EXPORTED BY: $exportedBy | TIME: $exportedAtIso | SOURCE: ${metadata.sourceSystem}",
            14f,
            (finalBitmap.height - 46).toFloat(),
            headerSub,
        )
        canvas.drawText(
            "8-BIT DISPLAY RENDERING DERIVATIVE • ORIGINAL PIXELS PRESERVED SEPARATELY",
            14f,
            (finalBitmap.height - 20).toFloat(),
            headerSub,
        )

        val exportDir = File(context.filesDir, "exports").apply { mkdirs() }
        val safeId = metadata.patientId.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val outFile = File(exportDir, "AUREOM_DERIVATIVE_${safeId}_${System.currentTimeMillis()}.png")
        FileOutputStream(outFile).use { fos ->
            finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
        }
        val sha = DicomCodec.sha256Hex(outFile.readBytes())
        baseBitmap.recycle()
        finalBitmap.recycle()

        return DerivativeExportResult(
            file = outFile,
            sha256 = sha,
            bannerSummary = tagLabel,
        )
    }
}
