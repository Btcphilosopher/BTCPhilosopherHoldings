package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AureomWorkstationScreen
import com.example.ui.theme.AureomImagingTheme
import com.example.ui.viewmodel.WorkstationViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            val workstationViewModel: WorkstationViewModel = viewModel()
            val prefs by workstationViewModel.preferences.collectAsStateWithLifecycle()
            AureomImagingTheme(textScale = prefs.textScale) {
                AureomWorkstationScreen(viewModel = workstationViewModel)
            }
        }
    }
}
