package com.example.data.network

import com.example.domain.model.ClinicianSession
import java.security.MessageDigest
import java.time.Instant

sealed class AuthResult {
    data class Authenticated(val session: ClinicianSession) : AuthResult()
    data class Rejected(val message: String) : AuthResult()
}

/**
 * Replaceable organisational identity adapter.
 * Attempts FastAPI OAuth2/JWT backend login when reachable, and supports isolated local
 * demonstration clinician verification when running offline as a standalone APK.
 */
interface IdentityAuthAdapter {
    suspend fun authenticate(
        username: String,
        passcode: String,
        backendBaseUrl: String,
        preferOfflineDemo: Boolean,
    ): AuthResult
}

class OrganisationalIdentityAdapter : IdentityAuthAdapter {

    // Salted SHA-256 hashes of demo clinician passcodes (never plaintext secrets)
    private data class DemoAccount(
        val userId: String,
        val displayName: String,
        val role: String,
        val salt: String,
        val passcodeHashHex: String,
    )

    private val demoAccounts = mapOf(
        "radiologist@aureom.local" to DemoAccount(
            userId = "usr-rad-01",
            displayName = "Dr. E. Vance (Radiologist)",
            role = "RADIOLOGIST",
            salt = "aureom-rad-salt-2026",
            passcodeHashHex = sha256("aureom-rad-salt-2026:aureom-demo-2026"),
        ),
        "radiographer@aureom.local" to DemoAccount(
            userId = "usr-tech-02",
            displayName = "M. Patel (Senior Radiographer)",
            role = "RADIOGRAPHER",
            salt = "aureom-tech-salt-2026",
            passcodeHashHex = sha256("aureom-tech-salt-2026:aureom-tech-2026"),
        ),
    )

    override suspend fun authenticate(
        username: String,
        passcode: String,
        backendBaseUrl: String,
        preferOfflineDemo: Boolean,
    ): AuthResult {
        val normalizedUser = username.trim().lowercase()
        if (normalizedUser.isBlank() || passcode.isBlank()) {
            return AuthResult.Rejected("Enter clinician identifier and workstation passcode.")
        }

        if (!preferOfflineDemo) {
            val remote = runCatching {
                val api = AureomApiClientFactory.create(backendBaseUrl)
                val resp = api.login(LoginRequestDto(normalizedUser, passcode))
                if (resp.isSuccessful) {
                    val body = resp.body()
                    if (body != null) {
                        AuthResult.Authenticated(
                            ClinicianSession(
                                userId = body.user_id,
                                displayName = body.display_name,
                                role = body.role,
                                token = body.access_token,
                                authMode = "FASTAPI_JWT",
                                signedInAtIso = Instant.now().toString(),
                            ),
                        )
                    } else null
                } else if (resp.code() == 401 || resp.code() == 403) {
                    AuthResult.Rejected("Directory rejected credentials (HTTP ${resp.code()}).")
                } else null
            }.getOrNull()

            if (remote != null) return remote
        }

        // Offline / Local Demonstration Identity Adapter fallback
        val demo = demoAccounts[normalizedUser]
        if (demo != null && sha256("${demo.salt}:$passcode") == demo.passcodeHashHex) {
            return AuthResult.Authenticated(
                ClinicianSession(
                    userId = demo.userId,
                    displayName = demo.displayName,
                    role = demo.role,
                    token = "demo-local-${sha256("$normalizedUser:${System.currentTimeMillis()}").take(24)}",
                    authMode = "LOCAL_DEMO_ADAPTER",
                    signedInAtIso = Instant.now().toString(),
                ),
            )
        }

        return AuthResult.Rejected(
            "Invalid clinician credentials or backend unreachable. Check username/passcode or enable Local Demo Workstation Mode.",
        )
    }

    companion object {
        private fun sha256(input: String): String {
            val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
            return bytes.joinToString("") { "%02x".format(it) }
        }
    }
}
