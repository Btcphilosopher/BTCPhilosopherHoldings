package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.domain.model.ConflictRecord
import com.example.domain.model.ExaminationSummary
import com.example.imaging.DerivativeExportResult
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GraphiteAbyss
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.StatusCritical
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import com.example.ui.viewmodel.UnsupportedErrorDialogState

@Composable
fun PatientConfirmationDialog(
    study: ExaminationSummary,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = CyanPrimary)
                Text("Confirm Patient & Examination")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Verify identity before mounting image or enabling annotations:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Card(
                    colors = CardDefaults.cardColors(containerColor = GraphiteCard),
                    border = BorderStroke(1.dp, CyanPrimary.copy(alpha = 0.5f)),
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text("Patient: ${study.patientName}", style = MaterialTheme.typography.titleMedium)
                        Text("Patient ID: ${study.patientId}", style = MaterialTheme.typography.labelMedium, color = CyanPrimary)
                        Text("Issuing Authority: ${study.patientIdIssuer}", style = MaterialTheme.typography.bodySmall)
                        Text("Accession: ${study.accessionNumber}", style = MaterialTheme.typography.bodySmall)
                        Text("Study: ${study.description}", style = MaterialTheme.typography.bodyMedium)
                        Text("Modality / Body: ${study.modality} / ${study.bodyPart}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "View: ${study.viewOrProjection ?: "Not supplied"} | Laterality: ${study.laterality ?: "Not supplied"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (study.laterality == null || study.viewOrProjection == null) StatusWarning else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
                if (study.isNonDicom) {
                    Text(
                        text = "NON-DICOM REFERENCE: No spatial calibration or DICOM raw linear pixel guarantee.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusWarning,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("confirm_patient_button"),
            ) {
                Text("Confirm & Open")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("cancel_patient_button"),
            ) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun UnsupportedErrorDialog(
    error: UnsupportedErrorDialogState,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Filled.Warning, contentDescription = null, tint = StatusCritical)
                Text(error.title)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(error.detail, style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = "Code: ${error.errorCode}",
                    style = MaterialTheme.typography.labelMedium,
                    color = StatusWarning,
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("dismiss_unsupported_dialog"),
            ) {
                Text("Acknowledge")
            }
        },
    )
}

@Composable
fun TextNotePromptDialog(
    onCommit: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var noteText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Image Text Note") },
        text = {
            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                label = { Text("Annotation text") },
                singleLine = false,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("annotation_note_input"),
            )
        },
        confirmButton = {
            Button(
                onClick = { onCommit(noteText) },
                enabled = noteText.isNotBlank(),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("commit_note_button"),
            ) {
                Text("Save Note")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, modifier = Modifier.minimumInteractiveComponentSize()) {
                Text("Cancel")
            }
        },
    )
}

@Composable
fun ExportResultDialog(
    result: DerivativeExportResult,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reviewed Derivative Exported") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = result.bannerSummary,
                    style = MaterialTheme.typography.labelMedium,
                    color = StatusVerified,
                )
                Text(
                    text = "File saved to private workstation export directory (NOT added to personal photo gallery):",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    text = "${result.file.name}\nSHA-256: ${result.sha256.take(24)}…",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanPrimary,
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        result.file,
                    )
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "Aureom Reviewed Derivative Export")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Send through authorised workflow"))
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("share_derivative_button"),
            ) {
                Icon(Icons.Filled.Share, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Authorised Share")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("close_export_dialog"),
            ) {
                Text("Done")
            }
        },
    )
}

@Composable
fun ConflictResolutionDialog(
    conflict: ConflictRecord,
    onResolve: (String) -> Unit,
) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Explicit Conflict Resolution Required") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Offline edits conflict with an archive peer revision. Automatic silent overwrite is blocked.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StatusWarningBg, MaterialTheme.shapes.small)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text("Local: ${conflict.localSummary}", style = MaterialTheme.typography.bodySmall)
                    Text("Server: ${conflict.serverSummary}", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onResolve("KEEP_LOCAL_AS_NEW_VERSION") },
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("resolve_keep_local"),
            ) {
                Text("Keep Local (New Ver)")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = { onResolve("ACCEPT_SERVER_REVISION") },
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("resolve_accept_server"),
            ) {
                Text("Accept Server")
            }
        },
    )
}
