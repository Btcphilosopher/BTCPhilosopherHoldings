package com.example.domain.model

enum class AcquisitionStatus(val label: String) {
    SCHEDULED("Scheduled"),
    ACQUISITION_IN_PROGRESS("Acquiring"),
    IMAGE_AVAILABLE("Image Available"),
    TRANSFER_COMPLETE("Transferred"),
    TRANSFER_FAILED("Transfer Failed"),
}

enum class ReceiptStatus(val label: String) {
    PENDING("Pending Receipt"),
    PARTIAL_INTERRUPTED("Interrupted"),
    RECEIVED_VERIFIED("Verified"),
    IMPORTED_LOCAL("Local Import"),
    CHECKSUM_MISMATCH("Checksum Error"),
}

enum class QualityReviewStatus(val label: String) {
    NOT_REVIEWED("QA Pending"),
    QA_PASSED("QA Accepted"),
    QA_FLAGGED_FURTHER_REVIEW("QA Flagged"),
}

enum class ReportStatus(val label: String) {
    UNREPORTED("Unreported"),
    DRAFT_SAVED("Draft"),
    UNDER_REVIEW("In Review"),
    SIGNED("Signed"),
    AMENDED("Amended"),
}

enum class SyncState(val label: String) {
    SYNCED("Synced"),
    PENDING_UPLOAD("Pending Sync"),
    OFFLINE_ONLY("Offline Cache"),
    CONFLICT_DETECTED("Conflict"),
}

enum class PhotometricInterpretation(val dicomCode: String) {
    MONOCHROME1("MONOCHROME1"),
    MONOCHROME2("MONOCHROME2"),
    RGB_NON_DICOM("RGB_NON_DICOM"),
}

enum class CalibrationState(val label: String) {
    NONE("Missing calibration (px only)"),
    DETECTOR_PLANE("Detector-plane spacing (magnification uncalibrated)"),
    ANATOMICAL_CALIBRATED("Calibrated physical spacing (mm)"),
}

enum class AnnotationTool {
    PAN_ZOOM,
    WINDOW_LEVEL,
    TEXT_NOTE,
    ARROW,
    FREEHAND,
    LENGTH,
    ANGLE,
    ROI_BOX,
}

enum class AnnotationType {
    TEXT_NOTE,
    ARROW,
    FREEHAND,
    LENGTH,
    ANGLE,
    ROI_BOX,
}

data class PixelSpacingInfo(
    val rowSpacingMm: Double?,
    val colSpacingMm: Double?,
    val calibrationState: CalibrationState,
    val sourceTag: String,
)

data class RadiographPixelData(
    val width: Int,
    val height: Int,
    val bitsAllocated: Int,
    val bitsStored: Int,
    val pixelRepresentation: Int, // 0 = unsigned, 1 = signed two's complement
    val photometric: PhotometricInterpretation,
    val rescaleSlope: Double,
    val rescaleIntercept: Double,
    val defaultWindowCenter: Double,
    val defaultWindowWidth: Double,
    val rawPixels: IntArray, // Preserves original 8/12/16-bit integer values without 8-bit loss
    val isDicom: Boolean,
    val transferSyntaxUid: String,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is RadiographPixelData) return false
        return width == other.width &&
            height == other.height &&
            bitsStored == other.bitsStored &&
            photometric == other.photometric &&
            rawPixels.contentEquals(other.rawPixels)
    }

    override fun hashCode(): Int {
        var result = width
        result = 31 * result + height
        result = 31 * result + rawPixels.contentHashCode()
        return result
    }
}

data class ExaminationMetadata(
    val studyInstanceUid: String,
    val seriesInstanceUid: String,
    val sopInstanceUid: String,
    val accessionNumber: String,
    val patientId: String,
    val patientIdIssuer: String,
    val patientName: String,
    val examinationDescription: String,
    val acquisitionDateTime: String,
    val modality: String,
    val bodyPart: String,
    val viewOrProjection: String?, // null -> explicitly displayed as "Not supplied"
    val laterality: String?,       // null -> explicitly displayed as "Not supplied" (NEVER inferred)
    val sourceSystem: String,
    val imageProcessingHistory: List<String>,
    val isNonDicomReference: Boolean,
    val spacingInfo: PixelSpacingInfo,
    val transferSyntaxUid: String,
    val originalSha256: String,
    val originalFilePath: String,
    val priorStudyUid: String? = null,
)

data class ExaminationSummary(
    val studyInstanceUid: String,
    val sopInstanceUid: String,
    val patientId: String,
    val patientIdIssuer: String,
    val patientName: String,
    val accessionNumber: String,
    val description: String,
    val acquisitionDateTime: String,
    val modality: String,
    val bodyPart: String,
    val viewOrProjection: String?,
    val laterality: String?,
    val sourceSystem: String,
    val acquisitionStatus: AcquisitionStatus,
    val receiptStatus: ReceiptStatus,
    val qualityStatus: QualityReviewStatus,
    val reportStatus: ReportStatus,
    val syncState: SyncState,
    val downloadedAtIso: String?,
    val isNonDicom: Boolean,
    val transferProgressPercent: Int = 100,
    val transferErrorMessage: String? = null,
    val priorStudyUid: String? = null,
    val metadata: ExaminationMetadata,
)

data class DisplaySettings(
    val windowCenter: Double,
    val windowWidth: Double,
    val zoom: Float = 1.0f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val rotationDegrees: Int = 0, // 0, 90, 180, 270
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    val inverted: Boolean = false,
    val showOverlays: Boolean = true,
) {
    fun isModifiedFromDefault(defaultCenter: Double, defaultWidth: Double): Boolean {
        return kotlin.math.abs(windowCenter - defaultCenter) > 0.5 ||
            kotlin.math.abs(windowWidth - defaultWidth) > 0.5 ||
            kotlin.math.abs(zoom - 1.0f) > 0.01f ||
            kotlin.math.abs(panX) > 1f ||
            kotlin.math.abs(panY) > 1f ||
            rotationDegrees != 0 ||
            flipHorizontal ||
            flipVertical ||
            inverted
    }
}

data class ImagePoint(
    val x: Float, // Image pixel X in [0, imageWidth]
    val y: Float, // Image pixel Y in [0, imageHeight]
)

data class RoiStatistics(
    val pixelCount: Int,
    val minRaw: Int,
    val maxRaw: Int,
    val meanRaw: Double,
    val stdDevRaw: Double,
)

data class RadiographAnnotation(
    val id: String,
    val patientId: String,
    val studyInstanceUid: String,
    val sopInstanceUid: String,
    val type: AnnotationType,
    val points: List<ImagePoint>,
    val text: String = "",
    val authorId: String,
    val authorName: String,
    val createdAtIso: String,
    val updatedAtIso: String,
    val coordinateSystem: String = "IMAGE_PIXEL_SPACE_ORIGIN_TOP_LEFT",
    val measurementSummary: String = "",
    val roiStats: RoiStatistics? = null,
    val syncState: SyncState = SyncState.SYNCED,
    val version: Int = 1,
)

data class QualityChecklist(
    val studyInstanceUid: String,
    val sopInstanceUid: String,
    val positioningConcerns: Boolean = false,
    val motionArtefact: Boolean = false,
    val incompleteFieldCoverage: Boolean = false,
    val missingOrientationInfo: Boolean = false,
    val suspectedProcessingIssues: Boolean = false,
    val furtherReviewRequired: Boolean = false,
    val technicalNotes: String = "",
    val reviewerName: String = "",
    val reviewedAtIso: String? = null,
    val automatedFlags: List<String> = emptyList(),
)

data class ReportAmendment(
    val id: String,
    val authorName: String,
    val createdAtIso: String,
    val reason: String,
    val amendmentText: String,
)

data class ReportVersionEntry(
    val version: Int,
    val status: ReportStatus,
    val authorName: String,
    val timestampIso: String,
    val summary: String,
)

data class ClinicalReport(
    val studyInstanceUid: String,
    val patientId: String,
    val technicalComment: String = "",
    val clinicalInterpretation: String = "",
    val status: ReportStatus = ReportStatus.UNREPORTED,
    val authorId: String = "",
    val authorName: String = "",
    val updatedAtIso: String = "",
    val signedBy: String? = null,
    val signedAtIso: String? = null,
    val version: Int = 1,
    val syncState: SyncState = SyncState.SYNCED,
    val amendments: List<ReportAmendment> = emptyList(),
    val versionHistory: List<ReportVersionEntry> = emptyList(),
)

data class AuditEvent(
    val id: String,
    val timestampIso: String,
    val actorId: String,
    val actorName: String,
    val actorRole: String,
    val action: String,
    val patientId: String? = null,
    val studyInstanceUid: String? = null,
    val sopInstanceUid: String? = null,
    val details: String,
)

data class ClinicianSession(
    val userId: String,
    val displayName: String,
    val role: String,
    val token: String,
    val authMode: String, // "FASTAPI_JWT" or "LOCAL_DEMO_ADAPTER"
    val signedInAtIso: String,
)

data class ConflictRecord(
    val id: String,
    val studyInstanceUid: String,
    val entityType: String, // "ANNOTATION" or "REPORT"
    val localSummary: String,
    val serverSummary: String,
    val detectedAtIso: String,
)

data class OrientationMarkers(
    val top: String,
    val bottom: String,
    val left: String,
    val right: String,
    val orientationVerifiedFromDicom: Boolean,
)

data class EquipmentConnectionState(
    val deviceId: String = "AUREOM-DR-SUITE-01",
    val aeTitle: String = "AUREOM_DX_01",
    val connected: Boolean = true,
    val activeTransferStudyUid: String? = null,
    val statusMessage: String = "Connected (Standby • Generator console isolated)",
    val currentStatus: AcquisitionStatus = AcquisitionStatus.TRANSFER_COMPLETE,
    val progressPercent: Int = 100,
)
