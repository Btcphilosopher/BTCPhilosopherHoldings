package com.example.data.network

import com.example.domain.model.AcquisitionStatus
import com.example.domain.model.EquipmentConnectionState
import com.example.domain.model.PhotometricInterpretation
import com.example.domain.model.ReceiptStatus
import com.example.imaging.DicomCodec
import com.example.imaging.DicomWriteRequest
import com.example.imaging.SyntheticStudyGenerator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.math.hypot

data class EquipmentTransferEvent(
    val studyInstanceUid: String,
    val acquisitionStatus: AcquisitionStatus,
    val receiptStatus: ReceiptStatus,
    val progressPercent: Int,
    val message: String,
    val dicomBytes: ByteArray? = null,
    val sha256: String? = null,
)

/**
 * Replaceable equipment adapter receiving acquisition notifications and DICOM objects from compatible DR/CR hardware.
 * Radiation generation and exposure control remain strictly isolated on the manufacturer's console.
 */
interface EquipmentIntegrationAdapter {
    fun getDeviceIdentity(): EquipmentConnectionState
    fun simulateIncomingAcquisition(
        studyUid: String,
        simulateInterruptFailure: Boolean,
    ): Flow<EquipmentTransferEvent>
}

class SimulatedDrEquipmentAdapter : EquipmentIntegrationAdapter {
    override fun getDeviceIdentity(): EquipmentConnectionState = EquipmentConnectionState(
        deviceId = "AUREOM-DR-SUITE-01",
        aeTitle = "AUREOM_DX_01",
        connected = true,
        statusMessage = "Connected • Worklist listener active • Exposure control isolated",
    )

    override fun simulateIncomingAcquisition(
        studyUid: String,
        simulateInterruptFailure: Boolean,
    ): Flow<EquipmentTransferEvent> = flow {
        emit(
            EquipmentTransferEvent(
                studyInstanceUid = studyUid,
                acquisitionStatus = AcquisitionStatus.SCHEDULED,
                receiptStatus = ReceiptStatus.PENDING,
                progressPercent = 0,
                message = "Examination scheduled on AUREOM-DR-SUITE-01 (awaiting console release)",
            ),
        )
        delay(350)
        emit(
            EquipmentTransferEvent(
                studyInstanceUid = studyUid,
                acquisitionStatus = AcquisitionStatus.ACQUISITION_IN_PROGRESS,
                receiptStatus = ReceiptStatus.PENDING,
                progressPercent = 20,
                message = "Manufacturer console acquiring radiograph (no workstation exposure control)",
            ),
        )
        delay(400)
        emit(
            EquipmentTransferEvent(
                studyInstanceUid = studyUid,
                acquisitionStatus = AcquisitionStatus.IMAGE_AVAILABLE,
                receiptStatus = ReceiptStatus.PENDING,
                progressPercent = 45,
                message = "Image available on modality buffer; initiating bounded DICOM transfer",
            ),
        )
        delay(350)

        if (simulateInterruptFailure) {
            emit(
                EquipmentTransferEvent(
                    studyInstanceUid = studyUid,
                    acquisitionStatus = AcquisitionStatus.TRANSFER_FAILED,
                    receiptStatus = ReceiptStatus.PARTIAL_INTERRUPTED,
                    progressPercent = 64,
                    message = "Transfer interrupted at 64% (DICOM association reset / partial payload discarded)",
                ),
            )
            return@flow
        }

        val bytes = buildSimulatedMobileChestDicom(studyUid)
        val sha = DicomCodec.sha256Hex(bytes)
        emit(
            EquipmentTransferEvent(
                studyInstanceUid = studyUid,
                acquisitionStatus = AcquisitionStatus.TRANSFER_COMPLETE,
                receiptStatus = ReceiptStatus.RECEIVED_VERIFIED,
                progressPercent = 100,
                message = "Transfer complete • SHA-256 verified (${sha.take(12)}…)",
                dicomBytes = bytes,
                sha256 = sha,
            ),
        )
    }

    private fun buildSimulatedMobileChestDicom(studyUid: String): ByteArray {
        if (studyUid.contains("CURR")) return SyntheticStudyGenerator.generateChestPaDicom(isPrior = false)
        val w = 512
        val h = 512
        val pixels = IntArray(w * h)
        for (y in 0 until h) {
            val ny = (y - 256.0) / 256.0
            for (x in 0 until w) {
                val nx = (x - 256.0) / 256.0
                var v = 460.0
                val torso = hypot(nx / 0.80, (ny - 0.08) / 0.90)
                if (torso < 1.0) v += 1050.0 * (1.0 - torso * 0.4)
                val l = hypot((nx + 0.30) / 0.24, (ny + 0.04) / 0.50)
                val r = hypot((nx - 0.30) / 0.24, (ny + 0.04) / 0.50)
                if (l < 1.0) v -= (1.0 - l * l) * 740.0
                if (r < 1.0) v -= (1.0 - r * r) * 740.0
                if (kotlin.math.abs(nx) < 0.11 && ny in -0.7..0.55) v += 860.0
                val heart = hypot((nx - 0.12) / 0.20, (ny - 0.20) / 0.22)
                if (heart < 1.0) v += 780.0 * (1.0 - heart * heart)
                pixels[y * w + x] = v.toInt().coerceIn(0, 4095)
            }
        }
        return DicomCodec.writePart10Dicom(
            DicomWriteRequest(
                width = w,
                height = h,
                bitsAllocated = 16,
                bitsStored = 12,
                photometric = PhotometricInterpretation.MONOCHROME2,
                windowCenter = 1750.0,
                windowWidth = 2200.0,
                rawPixels = pixels,
                patientId = "SYN-PT-40881",
                patientIdIssuer = "AUREOM-WARD-PORTABLE",
                patientName = "DEMO^WARD^DELTA",
                studyInstanceUid = studyUid,
                seriesInstanceUid = "$studyUid.1",
                sopInstanceUid = "$studyUid.1.1",
                accessionNumber = "ACC-2026-1124-W4",
                studyDescription = "Portable Chest AP (Equipment Transfer)",
                acquisitionDate = "20261124",
                acquisitionTime = "011000",
                modality = "DX",
                bodyPart = "CHEST",
                viewPosition = "AP",
                laterality = "B",
                stationName = "AUREOM-DR-SUITE-01",
                imagerPixelSpacingMm = 0.148 to 0.148,
            ),
        )
    }
}
