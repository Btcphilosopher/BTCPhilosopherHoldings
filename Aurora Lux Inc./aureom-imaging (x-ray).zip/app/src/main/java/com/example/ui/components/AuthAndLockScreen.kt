package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.domain.model.ClinicianSession
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanOnContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GraphiteAbyss
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.GraphitePanel
import com.example.ui.theme.StatusCritical
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg

@Composable
fun AuthSignInScreen(
    isAuthenticating: Boolean,
    authError: String?,
    backendBaseUrl: String,
    onSignIn: (username: String, passcode: String, preferOfflineDemo: Boolean) -> Unit,
) {
    var username by remember { mutableStateOf("radiologist@aureom.local") }
    var passcode by remember { mutableStateOf("") }
    var preferOfflineDemo by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteAbyss)
            .systemBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphitePanel),
            border = BorderStroke(1.dp, GraphiteBorder),
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(CyanContainer, MaterialTheme.shapes.medium),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MedicalServices,
                            contentDescription = "Aureom Imaging Workstation",
                            tint = CyanPrimary,
                        )
                    }
                    Column {
                        Text(
                            text = "AUREOM IMAGING",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = "X-Ray Workspace • Organisational Access",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyanPrimary,
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = StatusWarningBg),
                    border = BorderStroke(1.dp, StatusWarning.copy(alpha = 0.5f)),
                ) {
                    Text(
                        text = "DEMONSTRATION WORKSTATION: Uses synthetic de-identified radiographs. Not cleared for primary clinical diagnosis or X-ray generator control.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(12.dp),
                    )
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Clinician Identifier") },
                    leadingIcon = { Icon(Icons.Outlined.Badge, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_username_input"),
                )

                OutlinedTextField(
                    value = passcode,
                    onValueChange = { passcode = it },
                    label = { Text("Workstation Passcode") },
                    leadingIcon = { Icon(Icons.Outlined.Key, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_passcode_input"),
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Local Demo Identity Adapter",
                            style = MaterialTheme.typography.titleSmall,
                        )
                        Text(
                            text = if (preferOfflineDemo) {
                                "Standalone offline verification active"
                            } else {
                                "Authenticates against $backendBaseUrl"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = preferOfflineDemo,
                        onCheckedChange = { preferOfflineDemo = it },
                        modifier = Modifier.testTag("offline_auth_switch"),
                    )
                }

                // Quick-fill demonstration credentials helper
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(
                        onClick = {
                            username = "radiologist@aureom.local"
                            passcode = "aureom-demo-2026"
                        },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("quickfill_radiologist_button"),
                    ) {
                        Text("Demo Radiologist", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(
                        onClick = {
                            username = "radiographer@aureom.local"
                            passcode = "aureom-tech-2026"
                        },
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("quickfill_radiographer_button"),
                    ) {
                        Text("Demo Radiographer", style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (authError != null) {
                    Text(
                        text = authError,
                        color = StatusCritical,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.testTag("auth_error_text"),
                    )
                }

                Button(
                    onClick = { onSignIn(username, passcode, preferOfflineDemo) },
                    enabled = !isAuthenticating,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanPrimary,
                        contentColor = GraphiteAbyss,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("login_submit_button"),
                ) {
                    if (isAuthenticating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = GraphiteAbyss,
                            strokeWidth = 2.dp,
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Sign In to Workstation")
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Security,
                        contentDescription = null,
                        tint = CyanOnContainer,
                        modifier = Modifier.size(16.dp),
                    )
                    Text(
                        text = "Session tokens protected with Android KeyStore AES-256-GCM. Private app cache only.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
fun SessionLockedOverlay(
    session: ClinicianSession,
    isAuthenticating: Boolean,
    authError: String?,
    onUnlock: (passcode: String) -> Unit,
    onSignOut: () -> Unit,
) {
    var passcode by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteAbyss)
            .systemBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GraphiteCard),
            border = BorderStroke(1.dp, CyanPrimary.copy(alpha = 0.5f)),
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = "Session locked",
                    tint = CyanPrimary,
                    modifier = Modifier.size(40.dp),
                )
                Text(
                    text = "Workstation Session Locked",
                    style = MaterialTheme.typography.titleLarge,
                )
                Text(
                    text = "Patient imagery and identifiers are obscured. Re-authenticate as ${session.displayName} to resume.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = passcode,
                    onValueChange = { passcode = it },
                    label = { Text("Enter Passcode") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("unlock_passcode_input"),
                )
                if (authError != null) {
                    Text(authError, color = StatusCritical, style = MaterialTheme.typography.bodySmall)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("lock_sign_out_button"),
                    ) {
                        Text("Sign Out")
                    }
                    Button(
                        onClick = { onUnlock(passcode) },
                        enabled = !isAuthenticating,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanPrimary,
                            contentColor = GraphiteAbyss,
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("unlock_submit_button"),
                    ) {
                        Text("Unlock")
                    }
                }
            }
        }
    }
}
