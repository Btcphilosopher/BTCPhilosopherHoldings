package com.example.imaging

import android.graphics.Bitmap
import com.example.domain.model.CalibrationState
import com.example.domain.model.DisplaySettings
import com.example.domain.model.ExaminationMetadata
import com.example.domain.model.ImagePoint
import com.example.domain.model.OrientationMarkers
import com.example.domain.model.PhotometricInterpretation
import com.example.domain.model.PixelSpacingInfo
import com.example.domain.model.RadiographPixelData
import com.example.domain.model.RoiStatistics
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object RadiographRenderer {

    /**
     * Renders preserved raw pixels through Modality LUT -> VOI Windowing -> Photometric Interpretation -> Inversion
     * into a transient 8-bit ARGB buffer for Android Bitmap display.
     *
     * Limitation note: Standard Android Bitmap.Config.ARGB_8888 quantizes display output to 8 bits per channel.
     * Original 12/16-bit pixel matrices in RadiographPixelData are never modified by this rendering pass.
     */
    fun renderToArgbPixels(
        pixelData: RadiographPixelData,
        settings: DisplaySettings,
    ): IntArray {
        val count = pixelData.width * pixelData.height
        val out = IntArray(count)
        val raw = pixelData.rawPixels
        val slope = pixelData.rescaleSlope
        val intercept = pixelData.rescaleIntercept
        val ww = settings.windowWidth.coerceAtLeast(1.0)
        val wc = settings.windowCenter
        val low = wc - 0.5 - (ww - 1.0) / 2.0
        val high = wc - 0.5 + (ww - 1.0) / 2.0
        val denom = (high - low).coerceAtLeast(1e-6)
        val isMono1 = pixelData.photometric == PhotometricInterpretation.MONOCHROME1
        val invertFinal = isMono1 xor settings.inverted

        for (i in 0 until count) {
            val modalityVal = raw[i] * slope + intercept
            val norm = when {
                modalityVal <= low -> 0.0
                modalityVal > high -> 255.0
                else -> ((modalityVal - low) / denom) * 255.0
            }
            var g = norm.toInt().coerceIn(0, 255)
            if (invertFinal) {
                g = 255 - g
            }
            out[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        return out
    }

    fun renderToBitmap(
        pixelData: RadiographPixelData,
        settings: DisplaySettings,
    ): Bitmap {
        val argb = renderToArgbPixels(pixelData, settings)
        val bitmap = Bitmap.createBitmap(pixelData.width, pixelData.height, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(argb, 0, pixelData.width, 0, 0, pixelData.width, pixelData.height)
        return bitmap
    }

    /**
     * Computes persistent edge orientation labels after applying rotation (0/90/180/270) and H/V flip.
     * Crucially: never infers anatomical Left/Right from pixel appearance. When DICOM laterality/view is
     * missing, uses neutral frame-relative edge indicators (IMG-L / IMG-R / TOP / BOT).
     */
    fun computeOrientationMarkers(
        laterality: String?,
        viewOrProjection: String?,
        rotationDegrees: Int,
        flipHorizontal: Boolean,
        flipVertical: Boolean,
    ): OrientationMarkers {
        val hasVerifiedAnatomical = !viewOrProjection.isNullOrBlank() &&
            (viewOrProjection.equals("PA", true) || viewOrProjection.equals("AP", true))

        // Base un-transformed edge labels
        var top = if (hasVerifiedAnatomical) "SUP (H)" else "TOP"
        var bottom = if (hasVerifiedAnatomical) "INF (F)" else "BOT"
        var left = when {
            viewOrProjection.equals("PA", true) -> "PT-L"
            viewOrProjection.equals("AP", true) -> "PT-R"
            !laterality.isNullOrBlank() -> "LAT:${laterality}"
            else -> "IMG-L"
        }
        var right = when {
            viewOrProjection.equals("PA", true) -> "PT-R"
            viewOrProjection.equals("AP", true) -> "PT-L"
            !laterality.isNullOrBlank() -> "LAT:${laterality}"
            else -> "IMG-R"
        }

        // Apply flips first (in image coordinate frame)
        if (flipHorizontal) {
            val tmp = left
            left = right
            right = tmp
        }
        if (flipVertical) {
            val tmp = top
            top = bottom
            bottom = tmp
        }

        // Apply clockwise 90-degree rotation steps
        val steps = ((rotationDegrees % 360) + 360) % 360 / 90
        repeat(steps) {
            val prevTop = top
            top = left
            left = bottom
            bottom = right
            right = prevTop
        }

        return OrientationMarkers(
            top = top,
            bottom = bottom,
            left = left,
            right = right,
            orientationVerifiedFromDicom = hasVerifiedAnatomical,
        )
    }

    fun computeRoiStatistics(
        pixelData: RadiographPixelData,
        p1: ImagePoint,
        p2: ImagePoint,
    ): RoiStatistics {
        val xMin = min(p1.x, p2.x).toInt().coerceIn(0, pixelData.width - 1)
        val xMax = max(p1.x, p2.x).toInt().coerceIn(0, pixelData.width - 1)
        val yMin = min(p1.y, p2.y).toInt().coerceIn(0, pixelData.height - 1)
        val yMax = max(p1.y, p2.y).toInt().coerceIn(0, pixelData.height - 1)

        var count = 0
        var minVal = Int.MAX_VALUE
        var maxVal = Int.MIN_VALUE
        var sum = 0.0
        var sumSq = 0.0

        for (y in yMin..yMax) {
            val rowOffset = y * pixelData.width
            for (x in xMin..xMax) {
                val v = pixelData.rawPixels[rowOffset + x]
                if (v < minVal) minVal = v
                if (v > maxVal) maxVal = v
                sum += v
                sumSq += v.toDouble() * v.toDouble()
                count++
            }
        }
        if (count == 0) return RoiStatistics(0, 0, 0, 0.0, 0.0)
        val mean = sum / count
        val variance = (sumSq / count - mean * mean).coerceAtLeast(0.0)
        return RoiStatistics(
            pixelCount = count,
            minRaw = minVal,
            maxRaw = maxVal,
            meanRaw = mean,
            stdDevRaw = sqrt(variance),
        )
    }

    /**
     * Optional non-diagnostic technical flags. Never infers clinical diagnostic adequacy or recommends repeat radiation.
     */
    fun runNonDiagnosticTechnicalChecks(
        pixelData: RadiographPixelData,
        metadata: ExaminationMetadata,
    ): List<String> {
        val flags = mutableListOf<String>()
        if (metadata.isNonDicomReference) {
            flags += "Non-DICOM 8-bit raster import: raw detector dynamic range and spatial calibration absent."
        }
        if (metadata.spacingInfo.calibrationState == CalibrationState.NONE) {
            flags += "Calibration tags (0028,0030)/(0018,1164) absent: physical measurements disabled (pixel units only)."
        } else if (metadata.spacingInfo.calibrationState == CalibrationState.DETECTOR_PLANE) {
            flags += "Detector-plane spacing only (0018,1164): geometric magnification at anatomy plane is uncalibrated."
        }
        if (metadata.laterality.isNullOrBlank()) {
            flags += "DICOM Laterality tag not supplied: verify anatomical side from physical lead marker / order."
        }
        if (metadata.viewOrProjection.isNullOrBlank()) {
            flags += "View/Projection tag (0018,5101) not supplied."
        }
        // Check saturation at max code value
        val maxPossible = (1 shl pixelData.bitsStored) - 1
        var saturated = 0
        val step = 4
        var sampled = 0
        for (i in pixelData.rawPixels.indices step step) {
            if (pixelData.rawPixels[i] >= maxPossible - 2) saturated++
            sampled++
        }
        if (sampled > 0 && saturated.toDouble() / sampled > 0.25) {
            flags += "Over 25% of sampled pixels are near maximum bit code ($maxPossible); verify exposure/clipping manually."
        }
        return flags
    }

    fun formatLengthMeasurement(
        p1: ImagePoint,
        p2: ImagePoint,
        spacingInfo: PixelSpacingInfo,
    ): String {
        val dx = (p2.x - p1.x).toDouble()
        val dy = (p2.y - p1.y).toDouble()
        val pxDist = hypot(dx, dy)
        return when (spacingInfo.calibrationState) {
            CalibrationState.ANATOMICAL_CALIBRATED -> {
                val colMm = spacingInfo.colSpacingMm ?: return "${"%.1f".format(pxDist)} px"
                val rowMm = spacingInfo.rowSpacingMm ?: return "${"%.1f".format(pxDist)} px"
                val mmDist = hypot(dx * colMm, dy * rowMm)
                "${"%.1f".format(mmDist)} mm (${"%.0f".format(pxDist)} px)"
            }
            CalibrationState.DETECTOR_PLANE -> {
                val colMm = spacingInfo.colSpacingMm ?: return "${"%.1f".format(pxDist)} px"
                val rowMm = spacingInfo.rowSpacingMm ?: return "${"%.1f".format(pxDist)} px"
                val mmDist = hypot(dx * colMm, dy * rowMm)
                "${"%.1f".format(mmDist)} mm [Detector plane] (${"%.0f".format(pxDist)} px)"
            }
            CalibrationState.NONE -> {
                "${"%.1f".format(pxDist)} px (Uncalibrated)"
            }
        }
    }

    fun formatAngleMeasurement(p1: ImagePoint, vertex: ImagePoint, p2: ImagePoint): String {
        val v1x = (p1.x - vertex.x).toDouble()
        val v1y = (p1.y - vertex.y).toDouble()
        val v2x = (p2.x - vertex.x).toDouble()
        val v2y = (p2.y - vertex.y).toDouble()
        val mag1 = hypot(v1x, v1y)
        val mag2 = hypot(v2x, v2y)
        if (mag1 < 1e-3 || mag2 < 1e-3) return "0.0°"
        val cosTheta = ((v1x * v2x + v1y * v2y) / (mag1 * mag2)).coerceIn(-1.0, 1.0)
        val deg = Math.toDegrees(acos(cosTheta))
        return "${"%.1f".format(deg)}°"
    }

    /**
     * Maps normalized/image pixel coordinates (0..imgW, 0..imgH) into viewport screen coordinates
     * and vice versa, honoring fit-to-screen, zoom, pan, 90-degree rotations, and H/V flips.
     */
    fun imageToScreen(
        pt: ImagePoint,
        imgW: Float,
        imgH: Float,
        viewW: Float,
        viewH: Float,
        settings: DisplaySettings,
    ): Pair<Float, Float> {
        val rotSteps = ((settings.rotationDegrees % 360) + 360) % 360
        val effW = if (rotSteps == 90 || rotSteps == 270) imgH else imgW
        val effH = if (rotSteps == 90 || rotSteps == 270) imgW else imgH
        val baseScale = min(viewW / effW.coerceAtLeast(1f), viewH / effH.coerceAtLeast(1f))
        val scale = baseScale * settings.zoom

        // Center-relative coords in original image space
        var cx = pt.x - imgW / 2f
        var cy = pt.y - imgH / 2f
        if (settings.flipHorizontal) cx = -cx
        if (settings.flipVertical) cy = -cy

        val (rx, ry) = when (rotSteps) {
            90 -> -cy to cx
            180 -> -cx to -cy
            270 -> cy to -cx
            else -> cx to cy
        }

        val sx = viewW / 2f + settings.panX + rx * scale
        val sy = viewH / 2f + settings.panY + ry * scale
        return sx to sy
    }

    fun screenToImage(
        sx: Float,
        sy: Float,
        imgW: Float,
        imgH: Float,
        viewW: Float,
        viewH: Float,
        settings: DisplaySettings,
    ): ImagePoint {
        val rotSteps = ((settings.rotationDegrees % 360) + 360) % 360
        val effW = if (rotSteps == 90 || rotSteps == 270) imgH else imgW
        val effH = if (rotSteps == 90 || rotSteps == 270) imgW else imgH
        val baseScale = min(viewW / effW.coerceAtLeast(1f), viewH / effH.coerceAtLeast(1f))
        val scale = (baseScale * settings.zoom).coerceAtLeast(0.001f)

        val rx = (sx - viewW / 2f - settings.panX) / scale
        val ry = (sy - viewH / 2f - settings.panY) / scale

        var (cx, cy) = when (rotSteps) {
            90 -> ry to -rx
            180 -> -rx to -ry
            270 -> -ry to rx
            else -> rx to ry
        }
        if (settings.flipHorizontal) cx = -cx
        if (settings.flipVertical) cy = -cy

        return ImagePoint(
            x = (cx + imgW / 2f).coerceIn(0f, imgW),
            y = (cy + imgH / 2f).coerceIn(0f, imgH),
        )
    }
}
