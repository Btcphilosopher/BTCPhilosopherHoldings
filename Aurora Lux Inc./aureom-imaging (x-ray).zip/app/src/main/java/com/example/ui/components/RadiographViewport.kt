package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AnnotationTool
import com.example.domain.model.AnnotationType
import com.example.domain.model.CalibrationState
import com.example.domain.model.DisplaySettings
import com.example.domain.model.ExaminationSummary
import com.example.domain.model.ImagePoint
import com.example.domain.model.RadiographAnnotation
import com.example.domain.model.RadiographPixelData
import com.example.imaging.RadiographRenderer
import com.example.ui.theme.ClinicalWhite
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanOnContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GraphiteAbyss
import com.example.ui.theme.GraphiteBorder
import com.example.ui.theme.GraphiteCard
import com.example.ui.theme.GraphitePanel
import com.example.ui.theme.RadiographVoid
import com.example.ui.theme.StatusVerified
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun RadiographViewport(
    activeStudy: ExaminationSummary?,
    activePixels: RadiographPixelData?,
    activeBitmap: Bitmap?,
    displaySettings: DisplaySettings,
    annotations: List<RadiographAnnotation>,
    activeTool: AnnotationTool,
    draftPoints: List<ImagePoint>,
    isComparisonMode: Boolean,
    comparisonStudy: ExaminationSummary?,
    comparisonPixels: RadiographPixelData?,
    comparisonBitmap: Bitmap?,
    comparisonDisplaySettings: DisplaySettings,
    syncComparisonView: Boolean,
    allStudies: List<ExaminationSummary>,
    onUpdateZoomPan: (Float, Float, Float) -> Unit,
    onUpdateWindowLevel: (Double, Double) -> Unit,
    onUpdateDraftPoints: (List<ImagePoint>) -> Unit,
    onCommitAnnotation: (AnnotationType, List<ImagePoint>) -> Unit,
    onPromptTextNote: (ImagePoint) -> Unit,
    onResetView: () -> Unit,
    onToggleOverlays: () -> Unit,
    onToggleComparison: () -> Unit,
    onToggleSyncComparison: () -> Unit,
    onSelectComparisonStudy: (ExaminationSummary) -> Unit,
    onRetryTransfer: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GraphiteAbyss),
    ) {
        // Top Viewport Action Bar (Single-action Reset View, Compare, Overlay toggle)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(GraphitePanel)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                if (activeStudy != null) {
                    Text(
                        text = "${activeStudy.patientName} • ${activeStudy.patientId} (${activeStudy.patientIdIssuer})",
                        style = MaterialTheme.typography.titleSmall,
                        color = ClinicalWhite,
                    )
                    Text(
                        text = "${activeStudy.description} | Study: ${activeStudy.studyInstanceUid.takeLast(14)} | Acc: ${activeStudy.accessionNumber}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Text(
                        text = "Select and confirm an examination from the worklist",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(
                    onClick = onToggleOverlays,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_overlays_button"),
                ) {
                    Icon(
                        imageVector = if (displaySettings.showOverlays) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = "Toggle Overlays",
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("HUD", style = MaterialTheme.typography.bodySmall)
                }

                OutlinedButton(
                    onClick = onToggleComparison,
                    enabled = activeStudy != null,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_comparison_button"),
                ) {
                    Icon(Icons.Filled.Compare, contentDescription = "Compare Studies", modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (isComparisonMode) "Single" else "Compare", style = MaterialTheme.typography.bodySmall)
                }

                Button(
                    onClick = onResetView,
                    enabled = activePixels != null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanContainer,
                        contentColor = CyanOnContainer,
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("reset_view_button"),
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = "Reset View", modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Reset View", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // Comparison Picker Strip when comparing
        if (isComparisonMode) {
            var menuOpen by remember { mutableStateOf(false) }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GraphiteCard)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = "Comparing: ${activeStudy?.description ?: "—"}  vs  ${comparisonStudy?.description ?: "None"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanOnContainer,
                    modifier = Modifier.weight(1f),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onToggleSyncComparison,
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Text(if (syncComparisonView) "Sync: ON" else "Sync: OFF", style = MaterialTheme.typography.labelSmall)
                    }
                    Box {
                        OutlinedButton(
                            onClick = { menuOpen = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("pick_comparison_study_button"),
                        ) {
                            Text("Pick Study", style = MaterialTheme.typography.labelSmall)
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            allStudies
                                .filter { it.studyInstanceUid != activeStudy?.studyInstanceUid && it.metadata.originalFilePath.isNotBlank() }
                                .forEach { candidate ->
                                    DropdownMenuItem(
                                        text = { Text("${candidate.patientId}: ${candidate.description}") },
                                        onClick = {
                                            menuOpen = false
                                            onSelectComparisonStudy(candidate)
                                        },
                                    )
                                }
                        }
                    }
                }
            }
        }

        // Main Radiograph Canvas Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(RadiographVoid),
            contentAlignment = Alignment.Center,
        ) {
            if (activeStudy == null) {
                Text(
                    text = "No active examination confirmed.\nOpen a study from the worklist to verify patient identity and view.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp),
                )
            } else if (activePixels == null || activeBitmap == null) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(24.dp),
                ) {
                    Text(
                        text = "Image payload unavailable (${activeStudy.receiptStatus.label})",
                        style = MaterialTheme.typography.titleMedium,
                        color = StatusWarning,
                    )
                    Text(
                        text = activeStudy.transferErrorMessage ?: "Original DICOM bytes are not yet cached locally.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = { onRetryTransfer(activeStudy.studyInstanceUid) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = GraphiteAbyss),
                        modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                        Text("Retry Equipment Transfer")
                    }
                }
            } else if (isComparisonMode) {
                Row(modifier = Modifier.fillMaxSize()) {
                    SingleRadiographCanvas(
                        study = activeStudy,
                        pixelData = activePixels,
                        bitmap = activeBitmap,
                        displaySettings = displaySettings,
                        annotations = annotations,
                        activeTool = activeTool,
                        draftPoints = draftPoints,
                        onUpdateZoomPan = onUpdateZoomPan,
                        onUpdateWindowLevel = onUpdateWindowLevel,
                        onUpdateDraftPoints = onUpdateDraftPoints,
                        onCommitAnnotation = onCommitAnnotation,
                        onPromptTextNote = onPromptTextNote,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                    )
                    Box(
                        modifier = Modifier
                            .width(2.dp)
                            .fillMaxHeight()
                            .background(GraphiteBorder),
                    )
                    if (comparisonStudy != null && comparisonPixels != null && comparisonBitmap != null) {
                        SingleRadiographCanvas(
                            study = comparisonStudy,
                            pixelData = comparisonPixels,
                            bitmap = comparisonBitmap,
                            displaySettings = comparisonDisplaySettings,
                            annotations = emptyList(),
                            activeTool = AnnotationTool.PAN_ZOOM,
                            draftPoints = emptyList(),
                            onUpdateZoomPan = { _, _, _ -> },
                            onUpdateWindowLevel = { _, _ -> },
                            onUpdateDraftPoints = {},
                            onCommitAnnotation = { _, _ -> },
                            onPromptTextNote = {},
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .background(RadiographVoid),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("Select a second study to compare", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                SingleRadiographCanvas(
                    study = activeStudy,
                    pixelData = activePixels,
                    bitmap = activeBitmap,
                    displaySettings = displaySettings,
                    annotations = annotations,
                    activeTool = activeTool,
                    draftPoints = draftPoints,
                    onUpdateZoomPan = onUpdateZoomPan,
                    onUpdateWindowLevel = onUpdateWindowLevel,
                    onUpdateDraftPoints = onUpdateDraftPoints,
                    onCommitAnnotation = onCommitAnnotation,
                    onPromptTextNote = onPromptTextNote,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

@Composable
private fun SingleRadiographCanvas(
    study: ExaminationSummary,
    pixelData: RadiographPixelData,
    bitmap: Bitmap,
    displaySettings: DisplaySettings,
    annotations: List<RadiographAnnotation>,
    activeTool: AnnotationTool,
    draftPoints: List<ImagePoint>,
    onUpdateZoomPan: (Float, Float, Float) -> Unit,
    onUpdateWindowLevel: (Double, Double) -> Unit,
    onUpdateDraftPoints: (List<ImagePoint>) -> Unit,
    onCommitAnnotation: (AnnotationType, List<ImagePoint>) -> Unit,
    onPromptTextNote: (ImagePoint) -> Unit,
    modifier: Modifier = Modifier,
) {
    val textMeasurer = rememberTextMeasurer()
    val density = LocalDensity.current
    val imageBitmap = remember(bitmap) { bitmap.asImageBitmap() }
    val orientation = remember(
        study.laterality,
        study.viewOrProjection,
        displaySettings.rotationDegrees,
        displaySettings.flipHorizontal,
        displaySettings.flipVertical,
    ) {
        RadiographRenderer.computeOrientationMarkers(
            laterality = study.laterality,
            viewOrProjection = study.viewOrProjection,
            rotationDegrees = displaySettings.rotationDegrees,
            flipHorizontal = displaySettings.flipHorizontal,
            flipVertical = displaySettings.flipVertical,
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .background(RadiographVoid)
            .clipToBounds()
            .testTag("radiograph_canvas_${study.patientId}"),
    ) {
        val viewW = with(density) { maxWidth.toPx() }
        val viewH = with(density) { maxHeight.toPx() }
        val imgW = pixelData.width.toFloat()
        val imgH = pixelData.height.toFloat()

        val gestureModifier = when (activeTool) {
            AnnotationTool.PAN_ZOOM -> Modifier.pointerInput(study.studyInstanceUid, displaySettings) {
                detectTransformGestures { _, pan, zoom, _ ->
                    onUpdateZoomPan(
                        displaySettings.zoom * zoom,
                        displaySettings.panX + pan.x,
                        displaySettings.panY + pan.y,
                    )
                }
            }
            AnnotationTool.WINDOW_LEVEL -> Modifier.pointerInput(study.studyInstanceUid, displaySettings) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val deltaW = dragAmount.x * 4.0
                    val deltaC = -dragAmount.y * 4.0
                    onUpdateWindowLevel(
                        displaySettings.windowCenter + deltaC,
                        displaySettings.windowWidth + deltaW,
                    )
                }
            }
            AnnotationTool.TEXT_NOTE -> Modifier.pointerInput(study.studyInstanceUid, displaySettings, viewW, viewH) {
                detectTapGestures { offset ->
                    val pt = RadiographRenderer.screenToImage(offset.x, offset.y, imgW, imgH, viewW, viewH, displaySettings)
                    onPromptTextNote(pt)
                }
            }
            AnnotationTool.ANGLE -> Modifier.pointerInput(study.studyInstanceUid, displaySettings, draftPoints, viewW, viewH) {
                detectTapGestures { offset ->
                    val pt = RadiographRenderer.screenToImage(offset.x, offset.y, imgW, imgH, viewW, viewH, displaySettings)
                    val next = draftPoints + pt
                    if (next.size >= 3) {
                        onCommitAnnotation(AnnotationType.ANGLE, next.take(3))
                    } else {
                        onUpdateDraftPoints(next)
                    }
                }
            }
            AnnotationTool.ARROW, AnnotationTool.LENGTH, AnnotationTool.ROI_BOX, AnnotationTool.FREEHAND -> {
                Modifier.pointerInput(activeTool, study.studyInstanceUid, displaySettings, viewW, viewH) {
                    var currentPts = listOf<ImagePoint>()
                    detectDragGestures(
                        onDragStart = { start ->
                            val pt = RadiographRenderer.screenToImage(start.x, start.y, imgW, imgH, viewW, viewH, displaySettings)
                            currentPts = listOf(pt, pt)
                            onUpdateDraftPoints(currentPts)
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val pt = RadiographRenderer.screenToImage(change.position.x, change.position.y, imgW, imgH, viewW, viewH, displaySettings)
                            currentPts = if (activeTool == AnnotationTool.FREEHAND) {
                                currentPts + pt
                            } else {
                                listOf(currentPts.first(), pt)
                            }
                            onUpdateDraftPoints(currentPts)
                        },
                        onDragEnd = {
                            if (currentPts.size >= 2) {
                                val type = when (activeTool) {
                                    AnnotationTool.ARROW -> AnnotationType.ARROW
                                    AnnotationTool.LENGTH -> AnnotationType.LENGTH
                                    AnnotationTool.ROI_BOX -> AnnotationType.ROI_BOX
                                    else -> AnnotationType.FREEHAND
                                }
                                onCommitAnnotation(type, currentPts)
                            }
                            currentPts = emptyList()
                        },
                    )
                }
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .then(gestureModifier),
        ) {
            val rot = ((displaySettings.rotationDegrees % 360) + 360) % 360
            val effW = if (rot == 90 || rot == 270) imgH else imgW
            val effH = if (rot == 90 || rot == 270) imgW else imgH
            val baseScale = min(size.width / effW.coerceAtLeast(1f), size.height / effH.coerceAtLeast(1f))
            val scale = baseScale * displaySettings.zoom
            val drawW = (imgW * scale).roundToInt()
            val drawH = (imgH * scale).roundToInt()

            withTransform({
                translate(left = size.width / 2f + displaySettings.panX, top = size.height / 2f + displaySettings.panY)
                rotate(degrees = rot.toFloat(), pivot = Offset.Zero)
                scale(
                    scaleX = if (displaySettings.flipHorizontal) -1f else 1f,
                    scaleY = if (displaySettings.flipVertical) -1f else 1f,
                    pivot = Offset.Zero,
                )
            }) {
                drawImage(
                    image = imageBitmap,
                    dstOffset = IntOffset(-drawW / 2, -drawH / 2),
                    dstSize = IntSize(drawW, drawH),
                )
            }

            // Saved annotations
            annotations.forEach { ann ->
                drawRadiographAnnotation(
                    type = ann.type,
                    points = ann.points,
                    label = ann.measurementSummary.ifBlank { ann.text },
                    imgW = imgW,
                    imgH = imgH,
                    settings = displaySettings,
                    color = CyanPrimary,
                    textMeasurer = textMeasurer,
                )
            }

            // Live draft annotation preview
            if (draftPoints.isNotEmpty()) {
                val draftType = when (activeTool) {
                    AnnotationTool.ARROW -> AnnotationType.ARROW
                    AnnotationTool.LENGTH -> AnnotationType.LENGTH
                    AnnotationTool.ROI_BOX -> AnnotationType.ROI_BOX
                    AnnotationTool.ANGLE -> AnnotationType.ANGLE
                    else -> AnnotationType.FREEHAND
                }
                val liveLabel = when {
                    draftType == AnnotationType.LENGTH && draftPoints.size >= 2 ->
                        RadiographRenderer.formatLengthMeasurement(draftPoints[0], draftPoints[1], study.metadata.spacingInfo)
                    draftType == AnnotationType.ANGLE && draftPoints.size >= 3 ->
                        RadiographRenderer.formatAngleMeasurement(draftPoints[0], draftPoints[1], draftPoints[2])
                    else -> ""
                }
                drawRadiographAnnotation(
                    type = draftType,
                    points = draftPoints,
                    label = liveLabel,
                    imgW = imgW,
                    imgH = imgH,
                    settings = displaySettings,
                    color = StatusWarning,
                    textMeasurer = textMeasurer,
                )
            }
        }

        // Persistent Orientation Indicators along all 4 edges (never hidden by HUD toggle)
        OrientationEdgeBadge(orientation.top, orientation.orientationVerifiedFromDicom, Modifier.align(Alignment.TopCenter).padding(top = 6.dp))
        OrientationEdgeBadge(orientation.bottom, orientation.orientationVerifiedFromDicom, Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp))
        OrientationEdgeBadge(orientation.left, orientation.orientationVerifiedFromDicom, Modifier.align(Alignment.CenterStart).padding(start = 6.dp))
        OrientationEdgeBadge(orientation.right, orientation.orientationVerifiedFromDicom, Modifier.align(Alignment.CenterEnd).padding(end = 6.dp))

        // Unobtrusive Corner Overlays
        if (displaySettings.showOverlays) {
            // Top-left: Patient & Study
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .background(GraphiteAbyss.copy(alpha = 0.72f), MaterialTheme.shapes.extraSmall)
                    .padding(horizontal = 8.dp, vertical = 5.dp),
            ) {
                Text("${study.patientName} (${study.patientId})", style = MaterialTheme.typography.labelSmall, color = ClinicalWhite)
                Text("${study.modality} • ${study.bodyPart} • View: ${study.viewOrProjection ?: "Not supplied"}", style = MaterialTheme.typography.labelSmall, color = CyanOnContainer)
                Text("Lat: ${study.laterality ?: "Not supplied (do not infer)"}", style = MaterialTheme.typography.labelSmall, color = if (study.laterality == null) StatusWarning else ClinicalWhite)
            }

            // Top-right: Calibration & Format Safety Badge
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .background(
                        if (study.isNonDicom || study.metadata.spacingInfo.calibrationState == CalibrationState.NONE) {
                            StatusWarningBg.copy(alpha = 0.88f)
                        } else {
                            GraphiteAbyss.copy(alpha = 0.72f)
                        },
                        MaterialTheme.shapes.extraSmall,
                    )
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalAlignment = Alignment.End,
            ) {
                if (study.isNonDicom) {
                    Text("NON-DICOM REFERENCE", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                }
                Text(
                    text = when (study.metadata.spacingInfo.calibrationState) {
                        CalibrationState.ANATOMICAL_CALIBRATED -> "CALIBRATED (mm)"
                        CalibrationState.DETECTOR_PLANE -> "DETECTOR PLANE (mm)"
                        CalibrationState.NONE -> "NO CALIBRATION (PX ONLY)"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (study.metadata.spacingInfo.calibrationState == CalibrationState.NONE) StatusWarning else StatusVerified,
                )
                Text(
                    text = "${pixelData.width}x${pixelData.height} • ${pixelData.bitsStored}b ${pixelData.photometric.dicomCode}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ClinicalWhite,
                )
            }

            // Bottom-left: Display transform readout
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
                    .background(GraphiteAbyss.copy(alpha = 0.72f), MaterialTheme.shapes.extraSmall)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = "WC ${displaySettings.windowCenter.toInt()} / WW ${displaySettings.windowWidth.toInt()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanPrimary,
                )
                Text(
                    text = "Z ${(displaySettings.zoom * 100).toInt()}% • R ${displaySettings.rotationDegrees}°${if (displaySettings.flipHorizontal) " FH" else ""}${if (displaySettings.flipVertical) " FV" else ""}${if (displaySettings.inverted) " INV" else ""}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ClinicalWhite,
                )
            }
        }
    }
}

@Composable
private fun OrientationEdgeBadge(
    label: String,
    verifiedFromDicom: Boolean,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = GraphiteAbyss.copy(alpha = 0.8f),
        shape = MaterialTheme.shapes.extraSmall,
        border = BorderStroke(0.5.dp, if (verifiedFromDicom) CyanPrimary.copy(alpha = 0.7f) else StatusWarning.copy(alpha = 0.7f)),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (verifiedFromDicom) CyanPrimary else StatusWarning,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
}

private fun DrawScope.drawRadiographAnnotation(
    type: AnnotationType,
    points: List<ImagePoint>,
    label: String,
    imgW: Float,
    imgH: Float,
    settings: DisplaySettings,
    color: Color,
    textMeasurer: TextMeasurer,
) {
    val mapped = points.map { pt ->
        val (sx, sy) = RadiographRenderer.imageToScreen(pt, imgW, imgH, size.width, size.height, settings)
        Offset(sx, sy)
    }
    val textStyle = TextStyle(color = ClinicalWhite, fontSize = 11.sp)

    when (type) {
        AnnotationType.ARROW -> if (mapped.size >= 2) {
            val start = mapped[0]
            val end = mapped[1]
            drawLine(color = color, start = start, end = end, strokeWidth = 3f)
            val angle = atan2(end.y - start.y, end.x - start.x)
            val headLen = 16f
            val a1 = angle + Math.toRadians(150.0).toFloat()
            val a2 = angle - Math.toRadians(150.0).toFloat()
            drawLine(color, end, Offset(end.x + headLen * cos(a1), end.y + headLen * sin(a1)), strokeWidth = 3f)
            drawLine(color, end, Offset(end.x + headLen * cos(a2), end.y + headLen * sin(a2)), strokeWidth = 3f)
            if (label.isNotBlank()) drawLabelPill(textMeasurer, label, end + Offset(6f, -18f), textStyle)
        }
        AnnotationType.LENGTH -> if (mapped.size >= 2) {
            val a = mapped[0]
            val b = mapped[1]
            drawLine(color = color, start = a, end = b, strokeWidth = 3f)
            drawCircle(color = color, radius = 5f, center = a)
            drawCircle(color = color, radius = 5f, center = b)
            if (label.isNotBlank()) {
                val mid = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
                drawLabelPill(textMeasurer, label, mid + Offset(6f, -18f), textStyle)
            }
        }
        AnnotationType.ANGLE -> {
            mapped.forEach { drawCircle(color = color, radius = 5f, center = it) }
            if (mapped.size >= 2) drawLine(color, mapped[0], mapped[1], strokeWidth = 3f)
            if (mapped.size >= 3) {
                drawLine(color, mapped[1], mapped[2], strokeWidth = 3f)
                if (label.isNotBlank()) drawLabelPill(textMeasurer, label, mapped[1] + Offset(8f, -18f), textStyle)
            }
        }
        AnnotationType.FREEHAND -> if (mapped.size >= 2) {
            val path = Path().apply {
                moveTo(mapped[0].x, mapped[0].y)
                for (i in 1 until mapped.size) lineTo(mapped[i].x, mapped[i].y)
            }
            drawPath(path, color = color, style = Stroke(width = 3f))
        }
        AnnotationType.ROI_BOX -> if (mapped.size >= 2) {
            val left = minOf(mapped[0].x, mapped[1].x)
            val top = minOf(mapped[0].y, mapped[1].y)
            val right = maxOf(mapped[0].x, mapped[1].x)
            val bottom = maxOf(mapped[0].y, mapped[1].y)
            drawRect(
                color = color,
                topLeft = Offset(left, top),
                size = Size((right - left).coerceAtLeast(1f), (bottom - top).coerceAtLeast(1f)),
                style = Stroke(width = 2.5f),
            )
            if (label.isNotBlank()) drawLabelPill(textMeasurer, label, Offset(left, top - 20f), textStyle)
        }
        AnnotationType.TEXT_NOTE -> if (mapped.isNotEmpty()) {
            drawCircle(color = color, radius = 6f, center = mapped[0])
            drawLabelPill(textMeasurer, label, mapped[0] + Offset(10f, -10f), textStyle)
        }
    }
}

private fun DrawScope.drawLabelPill(
    textMeasurer: TextMeasurer,
    text: String,
    origin: Offset,
    style: TextStyle,
) {
    val result = textMeasurer.measure(text, style = style)
    val x = origin.x.coerceIn(4f, (size.width - result.size.width - 12f).coerceAtLeast(4f))
    val y = origin.y.coerceIn(4f, (size.height - result.size.height - 8f).coerceAtLeast(4f))
    drawRect(
        color = Color(0xCC0A0D11),
        topLeft = Offset(x - 4f, y - 2f),
        size = Size(result.size.width + 8f, result.size.height + 4f),
    )
    drawText(result, topLeft = Offset(x, y))
}
