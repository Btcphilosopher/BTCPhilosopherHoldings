from fastapi.testclient import TestClient
from app.main import app, Base, engine, SessionLocal, seed_initial_data


def setup_module():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_initial_data(db)


def test_auth_patient_isolation_and_signed_report_immutability():
    client = TestClient(app)

    # Unauthenticated access rejected
    assert client.get("/api/v1/studies").status_code == 401

    # Sign in as Radiographer -> allowed to save annotations & draft, forbidden to sign clinical report
    tech_login = client.post(
        "/api/v1/auth/login",
        json={"username": "radiographer@aureom.local", "passcode": "aureom-tech-2026"},
    )
    assert tech_login.status_code == 200
    tech_headers = {"Authorization": f"Bearer {tech_login.json()['access_token']}"}

    # Patient isolation check: wrong patient_id for Chest study must fail 409
    bad_ann = client.post(
        "/api/v1/annotations",
        headers=tech_headers,
        json={
            "patient_id": "SYN-PT-20914",
            "study_instance_uid": "1.2.826.0.1.3680043.8.498.1000.CURR",
            "sop_instance_uid": "1.2.826.0.1.3680043.8.498.1000.CURR.1",
            "type": "LENGTH",
            "points_json": "[]",
        },
    )
    assert bad_ann.status_code == 409

    # Radiographer cannot sign final clinical report (403)
    forbidden_sign = client.post(
        "/api/v1/studies/1.2.826.0.1.3680043.8.498.1000.CURR/report",
        headers=tech_headers,
        json={
            "patient_id": "SYN-PT-10482",
            "technical_comment": "Adequate inspiration",
            "clinical_interpretation": "Draft",
            "status": "SIGNED",
        },
    )
    assert forbidden_sign.status_code == 403

    # Radiologist signs and adds linked amendment
    rad_login = client.post(
        "/api/v1/auth/login",
        json={"username": "radiologist@aureom.local", "passcode": "aureom-demo-2026"},
    )
    assert rad_login.status_code == 200
    rad_headers = {"Authorization": f"Bearer {rad_login.json()['access_token']}"}

    signed = client.post(
        "/api/v1/studies/1.2.826.0.1.3680043.8.498.1000.CURR/report",
        headers=rad_headers,
        json={
            "patient_id": "SYN-PT-10482",
            "technical_comment": "PA chest centered",
            "clinical_interpretation": "Synthetic phantom baseline reviewed.",
            "status": "SIGNED",
        },
    )
    assert signed.status_code == 200

    # Direct edit after sign must fail 409
    direct_edit = client.post(
        "/api/v1/studies/1.2.826.0.1.3680043.8.498.1000.CURR/report",
        headers=rad_headers,
        json={
            "patient_id": "SYN-PT-10482",
            "technical_comment": "Edited",
            "clinical_interpretation": "Edited",
            "status": "DRAFT_SAVED",
        },
    )
    assert direct_edit.status_code == 409

    amended = client.post(
        "/api/v1/studies/1.2.826.0.1.3680043.8.498.1000.CURR/report/amend",
        headers=rad_headers,
        json={"reason": "Addendum note", "amendment_text": "Compared with prior study."},
    )
    assert amended.status_code == 200
    assert amended.json()["status"] == "AMENDED"
