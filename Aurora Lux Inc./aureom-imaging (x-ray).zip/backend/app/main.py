import json
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session, sessionmaker

from app.auth import (
    create_access_token,
    get_demo_seed_passcode,
    hash_password,
    require_clinician,
    require_role,
    verify_password,
)
from app.config import settings
from app.dicomweb_adapter import DicomWebArchiveAdapter
from app.models import (
    AnnotationModel,
    AuditLogModel,
    Base,
    QualityReviewModel,
    ReportModel,
    StudyModel,
    UserModel,
)

engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def seed_initial_data(db: Session):
    if not db.scalar(select(UserModel).limit(1)):
        rad_pass = get_demo_seed_passcode("AUREOM_DEMO_RAD_PASS", "aureom-demo-2026")
        tech_pass = get_demo_seed_passcode("AUREOM_DEMO_TECH_PASS", "aureom-tech-2026")
        db.add_all([
            UserModel(
                id="usr-rad-01",
                username="radiologist@aureom.local",
                display_name="Dr. E. Vance (Radiologist)",
                role="RADIOLOGIST",
                password_hash=hash_password(rad_pass),
            ),
            UserModel(
                id="usr-tech-02",
                username="radiographer@aureom.local",
                display_name="M. Patel (Senior Radiographer)",
                role="RADIOGRAPHER",
                password_hash=hash_password(tech_pass),
            ),
        ])
    if not db.scalar(select(StudyModel).limit(1)):
        db.add_all([
            StudyModel(
                study_instance_uid="1.2.826.0.1.3680043.8.498.1000.CURR",
                sop_instance_uid="1.2.826.0.1.3680043.8.498.1000.CURR.1",
                patient_id="SYN-PT-10482",
                patient_id_issuer="AUREOM-DEMO-HOSP",
                patient_name="DEMO THORAX ALPHA",
                accession_number="ACC-2026-1124",
                description="Chest PA Radiograph (Current)",
                acquisition_date_time="2026-11-24 08:42",
                modality="DX",
                body_part="CHEST",
                view_or_projection="PA",
                laterality="B",
                source_system="AUREOM-DR-SUITE-01",
                acquisition_status="TRANSFER_COMPLETE",
                receipt_status="RECEIVED_VERIFIED",
                quality_status="NOT_REVIEWED",
                report_status="UNREPORTED",
            ),
            StudyModel(
                study_instance_uid="1.2.826.0.1.3680043.8.498.2000.HAND",
                sop_instance_uid="1.2.826.0.1.3680043.8.498.2000.HAND.1.1",
                patient_id="SYN-PT-20914",
                patient_id_issuer="AUREOM-DEMO-HOSP",
                patient_name="DEMO MANUS BRAVO",
                accession_number="ACC-2026-1119",
                description="Right Hand PA Radiograph (MONOCHROME1)",
                acquisition_date_time="2026-11-23 14:18",
                modality="DX",
                body_part="HAND",
                view_or_projection="PA",
                laterality="R",
                source_system="AUREOM-EXTREMITY-02",
                acquisition_status="TRANSFER_COMPLETE",
                receipt_status="RECEIVED_VERIFIED",
                quality_status="NOT_REVIEWED",
                report_status="UNREPORTED",
            ),
            StudyModel(
                study_instance_uid="1.2.826.0.1.3680043.8.498.3000.KNEE",
                sop_instance_uid="1.2.826.0.1.3680043.8.498.3000.KNEE.1.1",
                patient_id="SYN-PT-31507",
                patient_id_issuer="AUREOM-MOBILE-UNIT",
                patient_name="DEMO GENU CHARLIE",
                accession_number="ACC-2026-1122",
                description="Knee Radiograph (Missing Calibration & Laterality)",
                acquisition_date_time="2026-11-24 00:48",
                modality="CR",
                body_part="KNEE",
                view_or_projection=None,
                laterality=None,
                source_system="PORTABLE-CR-04",
                acquisition_status="TRANSFER_COMPLETE",
                receipt_status="RECEIVED_VERIFIED",
                quality_status="NOT_REVIEWED",
                report_status="UNREPORTED",
            ),
        ])
    db.commit()


app = FastAPI(
    title="Aureom Imaging Workstation API",
    version="1.0.0",
    description="Backend API for Aureom X-Ray Workspace: Auth, Worklist, Patient-Isolated Annotations, QA, Versioned Reports, DICOMweb Bridge, and Audit Log.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_initial_data(db)


class LoginRequest(BaseModel):
    username: str
    passcode: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    display_name: str
    role: str


class AnnotationIn(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    patient_id: str
    study_instance_uid: str
    sop_instance_uid: str
    type: str
    points_json: str
    text: str = ""
    coordinate_system: str = "IMAGE_PIXEL_SPACE_ORIGIN_TOP_LEFT"
    measurement_summary: str = ""
    version: int = 1


class QualityReviewIn(BaseModel):
    positioning_concerns: bool = False
    motion_artefact: bool = False
    incomplete_field_coverage: bool = False
    missing_orientation_info: bool = False
    suspected_processing_issues: bool = False
    further_review_required: bool = False
    technical_notes: str = ""


class ReportIn(BaseModel):
    patient_id: str
    technical_comment: str = ""
    clinical_interpretation: str = ""
    status: str = "DRAFT_SAVED"
    expected_version: Optional[int] = None


class AmendmentIn(BaseModel):
    reason: str
    amendment_text: str


class AuditEventIn(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp_iso: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    actor_id: str
    actor_name: str
    actor_role: str
    action: str
    patient_id: Optional[str] = None
    study_instance_uid: Optional[str] = None
    sop_instance_uid: Optional[str] = None
    details: str


def _write_audit(db: Session, user: dict, action: str, details: str, patient_id: Optional[str] = None, study_uid: Optional[str] = None):
    db.add(
        AuditLogModel(
            id=str(uuid.uuid4()),
            timestamp_iso=datetime.now(timezone.utc).isoformat(),
            actor_id=user["sub"],
            actor_name=user["display_name"],
            actor_role=user["role"],
            action=action,
            patient_id=patient_id,
            study_instance_uid=study_uid,
            sop_instance_uid=None,
            details=details,
        )
    )


@app.get("/health")
def health():
    return {"status": "ok", "service": "aureom-imaging-api"}


@app.post("/api/v1/auth/login", response_model=LoginResponse)
def login(body: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(UserModel).where(UserModel.username == body.username.strip().lower()))
    if user is None or not user.active or not verify_password(body.passcode, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid clinician credentials")
    token = create_access_token(user.id, user.username, user.display_name, user.role)
    db.add(
        AuditLogModel(
            id=str(uuid.uuid4()),
            timestamp_iso=datetime.now(timezone.utc).isoformat(),
            actor_id=user.id,
            actor_name=user.display_name,
            actor_role=user.role,
            action="API_LOGIN",
            details=f"Authenticated clinician {user.username}",
        )
    )
    db.commit()
    return LoginResponse(
        access_token=token,
        user_id=user.id,
        display_name=user.display_name,
        role=user.role,
    )


@app.get("/api/v1/studies")
def list_studies(user: dict = Depends(require_clinician), db: Session = Depends(get_db)):
    rows = db.scalars(select(StudyModel).order_by(StudyModel.acquisition_date_time.desc())).all()
    return [
        {
            "study_instance_uid": s.study_instance_uid,
            "sop_instance_uid": s.sop_instance_uid,
            "patient_id": s.patient_id,
            "patient_id_issuer": s.patient_id_issuer,
            "patient_name": s.patient_name,
            "accession_number": s.accession_number,
            "description": s.description,
            "acquisition_date_time": s.acquisition_date_time,
            "modality": s.modality,
            "body_part": s.body_part,
            "view_or_projection": s.view_or_projection,
            "laterality": s.laterality,
            "source_system": s.source_system,
            "acquisition_status": s.acquisition_status,
            "receipt_status": s.receipt_status,
            "quality_status": s.quality_status,
            "report_status": s.report_status,
            "sha256_checksum": s.sha256_checksum,
        }
        for s in rows
    ]


@app.post("/api/v1/annotations")
def upsert_annotation(
    body: AnnotationIn,
    user: dict = Depends(require_clinician),
    db: Session = Depends(get_db),
):
    study = db.get(StudyModel, body.study_instance_uid)
    if study is None:
        raise HTTPException(status_code=404, detail="Study not found")
    # Server-side patient isolation enforcement
    if study.patient_id != body.patient_id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Patient isolation violation: annotation patient_id does not match study patient_id",
        )
    existing = db.get(AnnotationModel, body.id)
    if existing is not None:
        if body.version < existing.version:
            raise HTTPException(status_code=409, detail="Annotation version conflict; resolve explicitly")
        existing.points_json = body.points_json
        existing.text = body.text
        existing.measurement_summary = body.measurement_summary
        existing.version = existing.version + 1
        row = existing
    else:
        row = AnnotationModel(
            id=body.id,
            patient_id=body.patient_id,
            study_instance_uid=body.study_instance_uid,
            sop_instance_uid=body.sop_instance_uid,
            type=body.type,
            points_json=body.points_json,
            text=body.text,
            author_id=user["sub"],
            author_name=user["display_name"],
            coordinate_system=body.coordinate_system,
            measurement_summary=body.measurement_summary,
            version=1,
        )
        db.add(row)
    _write_audit(db, user, "ANNOTATION_UPSERT", f"Saved {body.type} on {body.study_instance_uid}", body.patient_id, body.study_instance_uid)
    db.commit()
    return {
        "id": row.id,
        "patient_id": row.patient_id,
        "study_instance_uid": row.study_instance_uid,
        "sop_instance_uid": row.sop_instance_uid,
        "type": row.type,
        "points_json": row.points_json,
        "text": row.text,
        "author_id": row.author_id,
        "author_name": row.author_name,
        "coordinate_system": row.coordinate_system,
        "measurement_summary": row.measurement_summary,
        "version": row.version,
    }


@app.post("/api/v1/studies/{study_uid}/qa")
def submit_qa(
    study_uid: str,
    body: QualityReviewIn,
    user: dict = Depends(require_clinician),
    db: Session = Depends(get_db),
):
    study = db.get(StudyModel, study_uid)
    if study is None:
        raise HTTPException(status_code=404, detail="Study not found")
    flagged = any([
        body.positioning_concerns,
        body.motion_artefact,
        body.incomplete_field_coverage,
        body.missing_orientation_info,
        body.suspected_processing_issues,
        body.further_review_required,
    ])
    qa = db.get(QualityReviewModel, study_uid) or QualityReviewModel(
        study_instance_uid=study_uid,
        reviewer_name=user["display_name"],
    )
    qa.positioning_concerns = body.positioning_concerns
    qa.motion_artefact = body.motion_artefact
    qa.incomplete_field_coverage = body.incomplete_field_coverage
    qa.missing_orientation_info = body.missing_orientation_info
    qa.suspected_processing_issues = body.suspected_processing_issues
    qa.further_review_required = body.further_review_required
    qa.technical_notes = body.technical_notes
    qa.reviewer_name = user["display_name"]
    db.add(qa)
    study.quality_status = "QA_FLAGGED_FURTHER_REVIEW" if flagged else "QA_PASSED"
    _write_audit(db, user, "QA_RECORDED", f"QA set to {study.quality_status}", study.patient_id, study_uid)
    db.commit()
    return {"study_instance_uid": study_uid, "quality_status": study.quality_status}


@app.post("/api/v1/studies/{study_uid}/report")
def upsert_report(
    study_uid: str,
    body: ReportIn,
    user: dict = Depends(require_clinician),
    db: Session = Depends(get_db),
):
    study = db.get(StudyModel, study_uid)
    if study is None:
        raise HTTPException(status_code=404, detail="Study not found")
    if study.patient_id != body.patient_id:
        raise HTTPException(status_code=409, detail="Patient isolation violation on report")
    if body.status == "SIGNED" and user["role"] not in ("RADIOLOGIST", "ADMIN"):
        raise HTTPException(status_code=403, detail="Only RADIOLOGIST or ADMIN may sign clinical reports")

    existing = db.get(ReportModel, study_uid)
    if existing and existing.status in ("SIGNED", "AMENDED"):
        raise HTTPException(status_code=409, detail="Signed reports are immutable; use the amendment endpoint")
    if existing and body.expected_version is not None and body.expected_version != existing.version:
        raise HTTPException(status_code=409, detail="Report version conflict")

    next_version = (existing.version + 1) if existing else 1
    history = json.loads(existing.version_history_json) if existing else []
    history.append({
        "version": next_version,
        "status": body.status,
        "author_name": user["display_name"],
        "timestamp_iso": datetime.now(timezone.utc).isoformat(),
    })

    report = existing or ReportModel(
        study_instance_uid=study_uid,
        patient_id=body.patient_id,
        author_id=user["sub"],
        author_name=user["display_name"],
    )
    report.technical_comment = body.technical_comment
    report.clinical_interpretation = body.clinical_interpretation
    report.status = body.status
    report.version = next_version
    report.signed_by = user["display_name"] if body.status == "SIGNED" else None
    report.version_history_json = json.dumps(history)
    db.add(report)
    study.report_status = body.status
    _write_audit(db, user, f"REPORT_{body.status}", f"Report v{next_version}", study.patient_id, study_uid)
    db.commit()
    return {
        "study_instance_uid": study_uid,
        "patient_id": report.patient_id,
        "technical_comment": report.technical_comment,
        "clinical_interpretation": report.clinical_interpretation,
        "status": report.status,
        "version": report.version,
    }


@app.post("/api/v1/studies/{study_uid}/report/amend")
def amend_report(
    study_uid: str,
    body: AmendmentIn,
    user: dict = Depends(require_role("RADIOLOGIST", "ADMIN")),
    db: Session = Depends(get_db),
):
    report = db.get(ReportModel, study_uid)
    study = db.get(StudyModel, study_uid)
    if report is None or study is None:
        raise HTTPException(status_code=404, detail="Signed report not found")
    if report.status not in ("SIGNED", "AMENDED"):
        raise HTTPException(status_code=400, detail="Only signed reports can receive linked amendments")

    amendments = json.loads(report.amendments_json)
    amendments.append({
        "id": str(uuid.uuid4()),
        "author_name": user["display_name"],
        "created_at_iso": datetime.now(timezone.utc).isoformat(),
        "reason": body.reason,
        "amendment_text": body.amendment_text,
    })
    report.version += 1
    report.status = "AMENDED"
    report.amendments_json = json.dumps(amendments)
    study.report_status = "AMENDED"
    _write_audit(db, user, "REPORT_AMENDED", f"Amendment added: {body.reason}", study.patient_id, study_uid)
    db.commit()
    return {"study_instance_uid": study_uid, "status": report.status, "version": report.version, "amendments": amendments}


@app.post("/api/v1/audit")
def post_audit(body: AuditEventIn, user: dict = Depends(require_clinician), db: Session = Depends(get_db)):
    row = AuditLogModel(
        id=body.id,
        timestamp_iso=body.timestamp_iso,
        actor_id=user["sub"],
        actor_name=user["display_name"],
        actor_role=user["role"],
        action=body.action,
        patient_id=body.patient_id,
        study_instance_uid=body.study_instance_uid,
        sop_instance_uid=body.sop_instance_uid,
        details=body.details,
    )
    db.add(row)
    db.commit()
    return body


@app.get("/api/v1/audit")
def list_audit(user: dict = Depends(require_clinician), db: Session = Depends(get_db)):
    rows = db.scalars(select(AuditLogModel).order_by(AuditLogModel.timestamp_iso.desc()).limit(200)).all()
    return [
        {
            "id": r.id,
            "timestamp_iso": r.timestamp_iso,
            "actor_id": r.actor_id,
            "actor_name": r.actor_name,
            "actor_role": r.actor_role,
            "action": r.action,
            "patient_id": r.patient_id,
            "study_instance_uid": r.study_instance_uid,
            "details": r.details,
        }
        for r in rows
    ]


@app.get("/api/v1/dicomweb/studies")
async def dicomweb_qido(user: dict = Depends(require_clinician)):
    adapter = DicomWebArchiveAdapter()
    try:
        return await adapter.query_studies_qido()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"DICOMweb archive unavailable: {exc}")
