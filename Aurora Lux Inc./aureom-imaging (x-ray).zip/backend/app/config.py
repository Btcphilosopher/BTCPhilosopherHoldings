import os
import secrets


class Settings:
    DATABASE_URL: str = os.environ.get(
        "DATABASE_URL",
        "sqlite:///./aureom_dev.db",
    )
    DICOMWEB_BASE_URL: str = os.environ.get(
        "DICOMWEB_BASE_URL",
        "http://dicom-archive:8042/dicom-web",
    )
    DICOMWEB_USERNAME: str = os.environ.get("DICOMWEB_USERNAME", "")
    DICOMWEB_PASSWORD: str = os.environ.get("DICOMWEB_PASSWORD", "")
    JWT_SECRET: str = os.environ.get("AUREOM_JWT_SECRET") or secrets.token_hex(32)
    TOKEN_TTL_SECONDS: int = int(os.environ.get("AUREOM_TOKEN_TTL_SECONDS", "3600"))
    ALLOWED_ORIGINS: list[str] = [
        o.strip()
        for o in os.environ.get("AUREOM_ALLOWED_ORIGINS", "http://localhost:8000,http://10.0.2.2:8000").split(",")
        if o.strip()
    ]


settings = Settings()
