from datetime import datetime, timezone
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class UserModel(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    username: Mapped[str] = mapped_column(String(128), unique=True, nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(String(128), nullable=False)
    role: Mapped[str] = mapped_column(String(32), nullable=False)  # RADIOLOGIST, RADIOGRAPHER, ADMIN
    password_hash: Mapped[str] = mapped_column(String(256), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class StudyModel(Base):
    __tablename__ = "examinations"

    study_instance_uid: Mapped[str] = mapped_column(String(128), primary_key=True)
    sop_instance_uid: Mapped[str] = mapped_column(String(128), nullable=False)
    patient_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    patient_id_issuer: Mapped[str] = mapped_column(String(64), nullable=False)
    patient_name: Mapped[str] = mapped_column(String(128), nullable=False)
    accession_number: Mapped[str] = mapped_column(String(64), nullable=False)
    description: Mapped[str] = mapped_column(String(256), nullable=False)
    acquisition_date_time: Mapped[str] = mapped_column(String(32), nullable=False)
    modality: Mapped[str] = mapped_column(String(16), nullable=False)
    body_part: Mapped[str] = mapped_column(String(64), nullable=False)
    view_or_projection: Mapped[str | None] = mapped_column(String(32), nullable=True)
    laterality: Mapped[str | None] = mapped_column(String(16), nullable=True)
    source_system: Mapped[str] = mapped_column(String(64), nullable=False)
    acquisition_status: Mapped[str] = mapped_column(String(32), nullable=False)
    receipt_status: Mapped[str] = mapped_column(String(32), nullable=False)
    quality_status: Mapped[str] = mapped_column(String(32), nullable=False)
    report_status: Mapped[str] = mapped_column(String(32), nullable=False)
    sha256_checksum: Mapped[str | None] = mapped_column(String(64), nullable=True)
    archive_object_uri: Mapped[str | None] = mapped_column(String(256), nullable=True)


class AnnotationModel(Base):
    __tablename__ = "annotations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    patient_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    study_instance_uid: Mapped[str] = mapped_column(
        String(128), ForeignKey("examinations.study_instance_uid", ondelete="CASCADE"), nullable=False, index=True
    )
    sop_instance_uid: Mapped[str] = mapped_column(String(128), nullable=False)
    type: Mapped[str] = mapped_column(String(32), nullable=False)
    points_json: Mapped[str] = mapped_column(Text, nullable=False)
    text: Mapped[str] = mapped_column(Text, default="", nullable=False)
    author_id: Mapped[str] = mapped_column(String(64), nullable=False)
    author_name: Mapped[str] = mapped_column(String(128), nullable=False)
    coordinate_system: Mapped[str] = mapped_column(String(64), nullable=False)
    measurement_summary: Mapped[str] = mapped_column(String(256), default="", nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, nullable=False)


class QualityReviewModel(Base):
    __tablename__ = "quality_reviews"

    study_instance_uid: Mapped[str] = mapped_column(
        String(128), ForeignKey("examinations.study_instance_uid", ondelete="CASCADE"), primary_key=True
    )
    positioning_concerns: Mapped[bool] = mapped_column(Boolean, default=False)
    motion_artefact: Mapped[bool] = mapped_column(Boolean, default=False)
    incomplete_field_coverage: Mapped[bool] = mapped_column(Boolean, default=False)
    missing_orientation_info: Mapped[bool] = mapped_column(Boolean, default=False)
    suspected_processing_issues: Mapped[bool] = mapped_column(Boolean, default=False)
    further_review_required: Mapped[bool] = mapped_column(Boolean, default=False)
    technical_notes: Mapped[str] = mapped_column(Text, default="")
    reviewer_name: Mapped[str] = mapped_column(String(128), nullable=False)
    reviewed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, nullable=False)


class ReportModel(Base):
    __tablename__ = "clinical_reports"

    study_instance_uid: Mapped[str] = mapped_column(
        String(128), ForeignKey("examinations.study_instance_uid", ondelete="CASCADE"), primary_key=True
    )
    patient_id: Mapped[str] = mapped_column(String(64), nullable=False)
    technical_comment: Mapped[str] = mapped_column(Text, default="", nullable=False)
    clinical_interpretation: Mapped[str] = mapped_column(Text, default="", nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False)
    author_id: Mapped[str] = mapped_column(String(64), nullable=False)
    author_name: Mapped[str] = mapped_column(String(128), nullable=False)
    signed_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    amendments_json: Mapped[str] = mapped_column(Text, default="[]", nullable=False)
    version_history_json: Mapped[str] = mapped_column(Text, default="[]", nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, nullable=False)


class AuditLogModel(Base):
    __tablename__ = "audit_events"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    timestamp_iso: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    actor_id: Mapped[str] = mapped_column(String(64), nullable=False)
    actor_name: Mapped[str] = mapped_column(String(128), nullable=False)
    actor_role: Mapped[str] = mapped_column(String(32), nullable=False)
    action: Mapped[str] = mapped_column(String(64), nullable=False)
    patient_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    study_instance_uid: Mapped[str | None] = mapped_column(String(128), nullable=True)
    sop_instance_uid: Mapped[str | None] = mapped_column(String(128), nullable=True)
    details: Mapped[str] = mapped_column(Text, nullable=False)
