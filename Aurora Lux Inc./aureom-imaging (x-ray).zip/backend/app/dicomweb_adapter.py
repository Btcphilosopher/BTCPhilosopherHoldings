import httpx
from typing import Optional

from app.config import settings


class DicomWebArchiveAdapter:
    """
    Documented DICOMweb (QIDO-RS, WADO-RS, STOW-RS) adapter communicating with an
    authorised imaging archive (e.g., Orthanc DICOMweb plugin in Docker Compose).
    """

    def __init__(self, base_url: Optional[str] = None):
        self.base_url = (base_url or settings.DICOMWEB_BASE_URL).rstrip("/")

    def _auth(self):
        if settings.DICOMWEB_USERNAME and settings.DICOMWEB_PASSWORD:
            return (settings.DICOMWEB_USERNAME, settings.DICOMWEB_PASSWORD)
        return None

    async def query_studies_qido(self, limit: int = 25) -> list[dict]:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.get(
                f"{self.base_url}/studies",
                params={"limit": limit},
                headers={"Accept": "application/dicom+json"},
                auth=self._auth(),
            )
            resp.raise_for_status()
            return resp.json()

    async def retrieve_instance_wado(self, study_uid: str, series_uid: str, sop_uid: str) -> bytes:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"{self.base_url}/studies/{study_uid}/series/{series_uid}/instances/{sop_uid}",
                headers={"Accept": "application/dicom; transfer-syntax=1.2.840.10008.1.2.1"},
                auth=self._auth(),
            )
            resp.raise_for_status()
            return resp.content

    async def store_instance_stow(self, dicom_bytes: bytes) -> dict:
        boundary = "aureom_stow_boundary"
        body = (
            f"--{boundary}\r\nContent-Type: application/dicom\r\n\r\n".encode("utf-8")
            + dicom_bytes
            + f"\r\n--{boundary}--\r\n".encode("utf-8")
        )
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                f"{self.base_url}/studies",
                content=body,
                headers={
                    "Content-Type": f'multipart/related; type="application/dicom"; boundary={boundary}',
                    "Accept": "application/dicom+json",
                },
                auth=self._auth(),
            )
            resp.raise_for_status()
            return resp.json() if resp.content else {"status": "accepted"}
