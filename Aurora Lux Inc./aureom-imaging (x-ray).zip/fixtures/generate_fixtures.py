#!/usr/bin/env python3
"""
Generates standalone synthetic DICOM Part 10 and reference fixtures in ./fixtures/out/
for uploading to Orthanc DICOMweb (STOW-RS) or importing via Android Document Picker.
Requires: pydicom, numpy, pillow
"""
from pathlib import Path
import struct

OUT_DIR = Path(__file__).parent / "out"


def build_minimal_explicit_le_dicom(
    filename: str,
    patient_id: str,
    patient_name: str,
    study_uid: str,
    sop_uid: str,
    modality: str,
    body_part: str,
    photometric: str,
    width: int = 256,
    height: int = 256,
) -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    # Build minimal DICOM Part 10 Explicit VR Little Endian binary
    buf = bytearray(128) + b"DICM"

    def tag_str(g: int, e: int, vr: str, val: str) -> bytes:
        raw = val.encode("utf-8")
        if len(raw) % 2 != 0:
            raw += b"\x00" if vr == "UI" else b" "
        return struct.pack("<HH", g, e) + vr.encode("ascii") + struct.pack("<H", len(raw)) + raw

    def tag_us(g: int, e: int, val: int) -> bytes:
        return struct.pack("<HH", g, e) + b"US" + struct.pack("<HH", 2, val)

    meta = (
        struct.pack("<HH", 0x0002, 0x0001) + b"OB\x00\x00" + struct.pack("<I", 2) + b"\x00\x01"
        + tag_str(0x0002, 0x0002, "UI", "1.2.840.10008.5.1.4.1.1.1")
        + tag_str(0x0002, 0x0003, "UI", sop_uid)
        + tag_str(0x0002, 0x0010, "UI", "1.2.840.10008.1.2.1")
    )
    buf += struct.pack("<HH", 0x0002, 0x0000) + b"UL" + struct.pack("<HI", 4, len(meta)) + meta
    buf += tag_str(0x0008, 0x0018, "UI", sop_uid)
    buf += tag_str(0x0008, 0x0060, "CS", modality)
    buf += tag_str(0x0008, 0x1030, "LO", f"Synthetic {body_part} Study")
    buf += tag_str(0x0010, 0x0010, "PN", patient_name)
    buf += tag_str(0x0010, 0x0020, "LO", patient_id)
    buf += tag_str(0x0010, 0x0021, "LO", "AUREOM-DEMO-HOSP")
    buf += tag_str(0x0018, 0x0015, "CS", body_part)
    buf += tag_str(0x0020, 0x000D, "UI", study_uid)
    buf += tag_str(0x0020, 0x000E, "UI", f"{study_uid}.1")
    buf += tag_us(0x0028, 0x0002, 1)
    buf += tag_str(0x0028, 0x0004, "CS", photometric)
    buf += tag_us(0x0028, 0x0010, height)
    buf += tag_us(0x0028, 0x0011, width)
    buf += tag_us(0x0028, 0x0100, 16)
    buf += tag_us(0x0028, 0x0101, 12)
    buf += tag_us(0x0028, 0x0102, 11)
    buf += tag_us(0x0028, 0x0103, 0)
    buf += tag_str(0x0028, 0x1050, "DS", "2048")
    buf += tag_str(0x0028, 0x1051, "DS", "2400")

    px = bytearray(width * height * 2)
    for y in range(height):
        for x in range(width):
            v = ((x * 8 + y * 8) % 4096)
            struct.pack_into("<H", px, (y * width + x) * 2, v)
    buf += struct.pack("<HH", 0x7FE0, 0x0010) + b"OW\x00\x00" + struct.pack("<I", len(px)) + px

    out_path = OUT_DIR / filename
    out_path.write_bytes(buf)
    return out_path


if __name__ == "__main__":
    p = build_minimal_explicit_le_dicom(
        "synthetic_chest_pa.dcm",
        "SYN-PT-10482",
        "DEMO^THORAX^ALPHA",
        "1.2.826.0.1.3680043.8.498.1000.CURR",
        "1.2.826.0.1.3680043.8.498.1000.CURR.1",
        "DX",
        "CHEST",
        "MONOCHROME2",
    )
    print(f"Generated {p}")
