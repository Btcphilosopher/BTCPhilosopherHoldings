# AUREOM IMAGING — X-Ray Workspace

Native Android (Kotlin + Jetpack Compose) radiographic review workstation paired with a Python/FastAPI + PostgreSQL + Orthanc DICOMweb local demonstration stack.

> **Safety Notice:** Demonstration build using synthetic, de-identified radiographs. Not cleared for primary clinical diagnosis, autonomous AI interpretation, or X-ray generator exposure control.

## Quick Start: Local Backend Stack (Docker Compose)
```bash
docker compose up --build
```
- FastAPI Backend: `http://localhost:8000` (Android Emulator connects via `http://10.0.2.2:8000`)
- Orthanc DICOMweb Archive: `http://localhost:8042/dicom-web` (Android Emulator: `http://10.0.2.2:8042/dicom-web`)
- PostgreSQL: `localhost:5432`

## Building & Testing Android APK
```bash
gradle :app:assembleDebug
gradle :app:testDebugUnitTest
```

## Running Backend Tests
```bash
cd backend
pip install -r requirements.txt
pytest
```

## Demo Clinician Credentials
- Radiologist (`RADIOLOGIST`): `radiologist@aureom.local` / `aureom-demo-2026`
- Radiographer (`RADIOGRAPHER`): `radiographer@aureom.local` / `aureom-tech-2026`

## Documentation
- [Architecture & Image Pipeline](docs/ARCHITECTURE.md)
- [REST & DICOMweb API](docs/API.md)
- [Clinical Deployment Checklist](docs/CLINICAL_DEPLOYMENT_CHECKLIST.md)
