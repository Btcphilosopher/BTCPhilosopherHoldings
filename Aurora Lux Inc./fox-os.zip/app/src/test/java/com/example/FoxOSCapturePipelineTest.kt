package com.example

import com.example.foxos.engine.CaptureEngine
import com.example.foxos.engine.ExposureEngine
import com.example.foxos.hal.HardwareAbstractionLayer
import com.example.foxos.model.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class FoxOSCapturePipelineTest {

    private lateinit var hal: HardwareAbstractionLayer
    private lateinit var captureEngine: CaptureEngine
    private val testDispatcher = UnconfinedTestDispatcher()
    private val testScope = TestScope(testDispatcher)

    @Before
    fun setUp() {
        hal = HardwareAbstractionLayer(CameraModel.FOX_ONE)
        captureEngine = CaptureEngine(hal, testScope)
    }

    @Test
    fun testHardwareCapabilityManifests() {
        val foxOne = HardwareManifestRegistry.getManifest(CameraModel.FOX_ONE)
        assertEquals(45.7, foxOne.sensorResolutionMp, 0.01)
        assertEquals(10, foxOne.maxContinuousFps)
        assertTrue(foxOne.hasEyeTracking)

        val foxPro = HardwareManifestRegistry.getManifest(CameraModel.FOX_PRO)
        assertEquals(24.2, foxPro.sensorResolutionMp, 0.01)
        assertEquals(30, foxPro.maxContinuousFps)

        val foxCompact = HardwareManifestRegistry.getManifest(CameraModel.FOX_COMPACT)
        assertEquals(26.1, foxCompact.sensorResolutionMp, 0.01)
        assertEquals(8, foxCompact.maxContinuousFps)
    }

    @Test
    fun testExposureEngineCalculation() {
        val settings = ExposureSettings(
            mode = ExposureMode.MANUAL,
            aperture = "f/2.8",
            apertureValue = 2.8,
            shutterSpeed = "1/500",
            shutterSpeedSec = 0.002,
            iso = 400,
            meteringMode = MeteringMode.MULTI_ZONE
        )

        val metering = ExposureEngine.evaluateExposure(settings)
        assertTrue("Calculated EV should be within valid range", metering.calculatedEv in 0.0..30.0)
        assertEquals(32, metering.histogramLuminance.size)
    }

    @Test
    fun testPhotographerProfileApplication() {
        captureEngine.applyPhotographerProfile(DefaultProfiles.StreetDocumentarian)

        assertEquals(ExposureMode.SHUTTER_PRIORITY, captureEngine.exposureSettings.value.mode)
        assertEquals(PictureProfileType.FOX_MONOCHROME, captureEngine.selectedProfile.value)
        assertEquals(CaptureFormat.JPEG_FINE, captureEngine.selectedFormat.value)
        assertEquals(FocusMode.CONTINUOUS_AF, captureEngine.focusSettings.value.focusMode)
    }

    @Test
    fun testHalfPressAutofocusLock() {
        assertEquals(false, captureEngine.focusSettings.value.isFocusLocked)
        captureEngine.onHalfPressShutter()
        assertEquals(true, captureEngine.focusSettings.value.isFocusLocked)
        captureEngine.onReleaseHalfPressShutter()
        assertEquals(false, captureEngine.focusSettings.value.isFocusLocked)
    }

    @Test
    fun testFaultInjectionAndRecovery() = runTest {
        hal.simulateStorageWriteFailure = true
        captureEngine.triggerShutterCapture()

        assertEquals(CameraOperationalState.ERROR, captureEngine.operationalState.value)
        assertNotNull(captureEngine.errorMessage.value)

        captureEngine.resetErrorState()
        assertEquals(CameraOperationalState.READY, captureEngine.operationalState.value)
        assertNull(captureEngine.errorMessage.value)
        assertFalse(hal.simulateStorageWriteFailure)
    }
}
