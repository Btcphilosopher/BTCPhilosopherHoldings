package com.example.foxos.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.engine.CaptureEngine
import com.example.foxos.model.CapturedPhoto
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun GalleryScreen(
    engine: CaptureEngine
) {
    val mediaList by engine.capturedMediaList.collectAsState()
    var selectedPhoto by remember { mutableStateOf<CapturedPhoto?>(mediaList.firstOrNull()) }

    LaunchedEffect(mediaList) {
        if (selectedPhoto == null && mediaList.isNotEmpty()) {
            selectedPhoto = mediaList.first()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FoxGraphiteDark)
            .padding(12.dp)
            .testTag("gallery_screen")
    ) {
        Text(
            text = "FOX MEDIA ARCHIVE & EXIF INSPECTOR",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = FoxBrassAccent,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (mediaList.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = "Empty Gallery",
                        tint = FoxTextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No captured photos in media buffer yet.",
                        color = FoxTextSecondary,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Use Viewfinder mode to trigger shutter capture.",
                        color = FoxTextMuted,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Left Column: Photo Preview + EXIF Details
                selectedPhoto?.let { photo ->
                    Column(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight()
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color.Black, RoundedCornerShape(6.dp))
                                .border(1.dp, FoxBrassMuted, RoundedCornerShape(6.dp))
                        ) {
                            Image(
                                painter = painterResource(id = photo.imageDrawableRes),
                                contentDescription = photo.filename,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Overlay Badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = photo.filename,
                                    color = FoxBrassAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // EXIF Inspector Card
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = FoxGraphiteSurface,
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, FoxGraphiteBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "TECHNICAL EXIF RECORD",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FoxBrassAccent,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "EXPOSURE: ${photo.shutterSpeed} @ ${photo.aperture} ISO ${photo.iso}",
                                        fontSize = 11.sp,
                                        color = FoxTextPrimary,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = photo.pictureProfile.title,
                                        fontSize = 11.sp,
                                        color = FoxBrassAccent,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Text(
                                    text = "LENS: ${photo.lensModel} (${photo.focalLengthMm}mm)",
                                    fontSize = 10.sp,
                                    color = FoxTextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "TIME: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).format(Date(photo.timestampMs))}",
                                    fontSize = 10.sp,
                                    color = FoxTextMuted,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "STORAGE: RAW: ${photo.rawSizeBytes / (1024 * 1024)}MB | JPEG: ${photo.jpegSizeBytes / (1024 * 1024)}MB",
                                    fontSize = 10.sp,
                                    color = FoxStatusFocusLock,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // Right Column: Grid of Captured Photos
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "BUFFER THUMBNAILS (${mediaList.size})",
                        fontSize = 11.sp,
                        color = FoxTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(mediaList) { item ->
                            val isSelected = selectedPhoto?.id == item.id
                            Box(
                                modifier = Modifier
                                    .aspectRatio(1.2f)
                                    .background(FoxGraphiteElevated, RoundedCornerShape(4.dp))
                                    .border(
                                        2.dp,
                                        if (isSelected) FoxBrassAccent else FoxGraphiteBorder,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .clickable { selectedPhoto = item }
                            ) {
                                Image(
                                    painter = painterResource(id = item.imageDrawableRes),
                                    contentDescription = item.filename,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .fillMaxWidth()
                                        .background(Color.Black.copy(alpha = 0.7f))
                                        .padding(vertical = 2.dp, horizontal = 4.dp)
                                ) {
                                    Text(
                                        text = item.aperture + " " + item.shutterSpeed,
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
