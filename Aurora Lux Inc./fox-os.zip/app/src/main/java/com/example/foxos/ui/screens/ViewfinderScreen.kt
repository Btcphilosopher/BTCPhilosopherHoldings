package com.example.foxos.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.foxos.engine.CaptureEngine
import com.example.foxos.hal.HardwareAbstractionLayer
import com.example.foxos.ui.components.*

@Composable
fun ViewfinderScreen(
    engine: CaptureEngine,
    hal: HardwareAbstractionLayer,
    onModelClick: () -> Unit
) {
    val model by hal.activeModel.collectAsState()
    val state by engine.operationalState.collectAsState()
    val batteryPercent by hal.batteryPercent.collectAsState()
    val tempCelsius by hal.sensorTempCelsius.collectAsState()
    val cardHealth by hal.card1HealthPercent.collectAsState()
    val lensName by hal.connectedLensName.collectAsState()
    val focusDistance by hal.focusDistanceMeters.collectAsState()

    val exposureSettings by engine.exposureSettings.collectAsState()
    val focusSettings by engine.focusSettings.collectAsState()
    val selectedProfile by engine.selectedProfile.collectAsState()
    val selectedFormat by engine.selectedFormat.collectAsState()
    val errorMessage by engine.errorMessage.collectAsState()

    var showQuickMenu by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Telemetry Header
        HeaderTelemetryBar(
            model = model,
            state = state,
            batteryPercent = batteryPercent,
            tempCelsius = tempCelsius,
            cardHealthPercent = cardHealth,
            remainingFrames = hal.getRemainingFramesEstimate(),
            firmwareVersion = "1.2.0-ENG",
            onModelClick = onModelClick
        )

        Box(modifier = Modifier.weight(1f)) {
            // Live Viewfinder Screen
            ViewfinderOverlay(
                operationalState = state,
                exposureSettings = exposureSettings,
                focusSettings = focusSettings,
                pictureProfile = selectedProfile,
                selectedFormat = selectedFormat,
                lensName = lensName,
                focusDistanceMeters = focusDistance,
                errorMessage = errorMessage,
                onFocusPointTap = { xRatio, yRatio ->
                    engine.updateFocusSettings {
                        it.copy(focusPointXRatio = xRatio, focusPointYRatio = yRatio)
                    }
                },
                onHalfPressShutter = { engine.onHalfPressShutter() },
                onReleaseHalfPress = { engine.onReleaseHalfPressShutter() },
                onFullPressShutter = { engine.triggerShutterCapture() },
                onQuickMenuClick = { showQuickMenu = !showQuickMenu }
            )

            // Quick Control Overlay Menu
            if (showQuickMenu) {
                QuickControlMenu(
                    selectedProfile = selectedProfile,
                    selectedFormat = selectedFormat,
                    meteringMode = exposureSettings.meteringMode,
                    subjectDetection = focusSettings.subjectDetection,
                    onSelectProfile = { engine.selectPictureProfile(it) },
                    onSelectFormat = { engine.selectCaptureFormat(it) },
                    onSelectMetering = { mode ->
                        engine.updateExposureSettings { it.copy(meteringMode = mode) }
                    },
                    onSelectSubjectDetection = { sd ->
                        engine.updateFocusSettings { it.copy(subjectDetection = sd) }
                    },
                    onDismiss = { showQuickMenu = false }
                )
            }
        }

        // Bottom Physical Dials Bar
        PhysicalControlsBar(
            exposureSettings = exposureSettings,
            focusSettings = focusSettings,
            onExposureChange = { transform -> engine.updateExposureSettings(transform) },
            onFocusChange = { transform -> engine.updateFocusSettings(transform) }
        )
    }
}
