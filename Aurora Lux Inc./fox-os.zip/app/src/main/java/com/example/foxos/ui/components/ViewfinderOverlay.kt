package com.example.foxos.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.foxos.engine.ExposureEngine
import com.example.foxos.model.*
import com.example.ui.theme.*

@Composable
fun ViewfinderOverlay(
    operationalState: CameraOperationalState,
    exposureSettings: ExposureSettings,
    focusSettings: FocusSettings,
    pictureProfile: PictureProfileType,
    selectedFormat: CaptureFormat,
    lensName: String,
    focusDistanceMeters: Float,
    errorMessage: String?,
    onFocusPointTap: (Float, Float) -> Unit,
    onHalfPressShutter: () -> Unit,
    onReleaseHalfPress: () -> Unit,
    onFullPressShutter: () -> Unit,
    onQuickMenuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showGridLines by remember { mutableStateOf(true) }
    var showHistogram by remember { mutableStateOf(true) }

    val meteringResult = remember(exposureSettings) {
        ExposureEngine.evaluateExposure(exposureSettings)
    }

    // Pick image feed based on picture profile
    val feedImageRes = when (pictureProfile) {
        PictureProfileType.FOX_MONOCHROME -> R.drawable.fox_sample_monochrome_1792913969843
        PictureProfileType.FOX_PORTRAIT -> R.drawable.fox_sample_portrait_1792913957683
        else -> R.drawable.fox_sample_landscape_1792913946568
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val xRatio = offset.x / size.width
                    val yRatio = offset.y / size.height
                    onFocusPointTap(xRatio, yRatio)
                }
            }
            .testTag("viewfinder_canvas")
    ) {
        // 1. Live Viewfeed Image
        Image(
            painter = painterResource(id = feedImageRes),
            contentDescription = "EVF Sensor Viewfinder Stream",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Grid lines overlay (Rule of Thirds)
        if (showGridLines) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                val col1 = w / 3f
                val col2 = w * 2f / 3f
                val row1 = h / 3f
                val row2 = h * 2f / 3f

                val gridColor = Color.White.copy(alpha = 0.25f)

                drawLine(gridColor, Offset(col1, 0f), Offset(col1, h), strokeWidth = 1f)
                drawLine(gridColor, Offset(col2, 0f), Offset(col2, h), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, row1), Offset(w, row1), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, row2), Offset(w, row2), strokeWidth = 1f)
            }
        }

        // 3. Focus Box & Peaking Aid
        Canvas(modifier = Modifier.fillMaxSize()) {
            val focusX = size.width * focusSettings.focusPointXRatio
            val focusY = size.height * focusSettings.focusPointYRatio
            val boxSize = 64.dp.toPx()

            val boxColor = if (focusSettings.isFocusLocked) FoxStatusFocusLock else FoxBrassAccent

            drawRect(
                color = boxColor,
                topLeft = Offset(focusX - boxSize / 2f, focusY - boxSize / 2f),
                size = Size(boxSize, boxSize),
                style = Stroke(width = 2.dp.toPx())
            )

            // Focus center crosshair
            drawLine(
                color = boxColor,
                start = Offset(focusX - 8.dp.toPx(), focusY),
                end = Offset(focusX + 8.dp.toPx(), focusY),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = boxColor,
                start = Offset(focusX, focusY - 8.dp.toPx()),
                end = Offset(focusX, focusY + 8.dp.toPx()),
                strokeWidth = 1.dp.toPx()
            )
        }

        // 4. Horizon Artificial Level
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(bottom = 40.dp)
        ) {
            Canvas(modifier = Modifier.size(160.dp, 2.dp)) {
                drawLine(
                    color = FoxStatusFocusLock.copy(alpha = 0.8f),
                    start = Offset(0f, size.height / 2f),
                    end = Offset(size.width, size.height / 2f),
                    strokeWidth = 2.dp.toPx()
                )
            }
        }

        // 5. Top Viewfinder Telemetry Overlay (Aperture, Shutter, ISO, Profile, EV)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Exposure readout
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = exposureSettings.shutterSpeed,
                        color = FoxBrassAccent,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = exposureSettings.aperture,
                        color = FoxBrassAccent,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "ISO ${exposureSettings.iso}",
                        color = FoxTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${if (exposureSettings.exposureCompensation >= 0) "+" else ""}${String.format("%.1f", exposureSettings.exposureCompensation)} EV",
                        color = FoxTextSecondary,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Profile & Lens
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = pictureProfile.title.uppercase(),
                        color = FoxBrassAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(
                        onClick = onQuickMenuClick,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("quick_menu_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "My Fox Quick Menu",
                            tint = FoxBrassAccent
                        )
                    }
                }
            }
        }

        // 6. Error Banner if in Error / Degraded State
        errorMessage?.let { error ->
            Surface(
                color = FoxStatusRecording,
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(top = 40.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Fault Warning",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = error,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 7. Bottom Viewfinder Bar (Focus Distance, Format, Histogram, Shutter Button)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.65f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Lens & Focus status
            Column {
                Text(
                    text = lensName,
                    fontSize = 11.sp,
                    color = FoxTextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "DIST: ${String.format("%.2f", focusDistanceMeters)}m | FORMAT: ${selectedFormat.extension}",
                    fontSize = 10.sp,
                    color = FoxTextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Real-time Histogram Widget
            if (showHistogram) {
                Canvas(
                    modifier = Modifier
                        .size(100.dp, 36.dp)
                        .background(FoxGraphiteDark, RoundedCornerShape(2.dp))
                        .border(1.dp, FoxGraphiteBorder, RoundedCornerShape(2.dp))
                        .padding(2.dp)
                ) {
                    val bins = meteringResult.histogramLuminance
                    val step = size.width / bins.size.toFloat()
                    for (i in bins.indices) {
                        val barHeight = bins[i] * size.height
                        drawRect(
                            color = FoxBrassAccent.copy(alpha = 0.85f),
                            topLeft = Offset(i * step, size.height - barHeight),
                            size = Size(step - 0.5f, barHeight)
                        )
                    }
                }
            }

            // Tactile Shutter Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = { onFullPressShutter() },
                    modifier = Modifier
                        .size(54.dp)
                        .testTag("shutter_release_button"),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (focusSettings.isFocusLocked) FoxStatusFocusLock else FoxBrassAccent,
                        contentColor = Color.Black
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Camera,
                        contentDescription = "Trigger Shutter Capture",
                        modifier = Modifier.size(24.dp)
                    )
                }
                Text(
                    text = if (focusSettings.isFocusLocked) "[AF-LOCK]" else "SHUTTER",
                    fontSize = 9.sp,
                    color = if (focusSettings.isFocusLocked) FoxStatusFocusLock else FoxTextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}
