package com.example.foxos.hal

import com.example.foxos.model.CameraModel
import com.example.foxos.model.HardwareManifestRegistry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.max
import kotlin.math.min

/**
 * Hardware Abstraction Layer (HAL) for Fox OS
 * Supports mock hardware implementations for software testing and HAL bindings
 */
class HardwareAbstractionLayer(initialModel: CameraModel = CameraModel.FOX_ONE) {

    private val _activeModel = MutableStateFlow(initialModel)
    val activeModel: StateFlow<CameraModel> = _activeModel.asStateFlow()

    // Sensor State
    private val _sensorTempCelsius = MutableStateFlow(28.5)
    val sensorTempCelsius: StateFlow<Double> = _sensorTempCelsius.asStateFlow()

    private val _readoutFps = MutableStateFlow(60)
    val readoutFps: StateFlow<Int> = _readoutFps.asStateFlow()

    // Lens Mount State
    private val _connectedLensName = MutableStateFlow("Fox-F Prime 35mm f/1.4 Lens")
    val connectedLensName: StateFlow<String> = _connectedLensName.asStateFlow()

    private val _currentFocalLengthMm = MutableStateFlow(35)
    val currentFocalLengthMm: StateFlow<Int> = _currentFocalLengthMm.asStateFlow()

    private val _focusDistanceMeters = MutableStateFlow(1.8f)
    val focusDistanceMeters: StateFlow<Float> = _focusDistanceMeters.asStateFlow()

    // Media & Storage State
    private val _card1CapacityGb = MutableStateFlow(128)
    val card1CapacityGb: StateFlow<Int> = _card1CapacityGb.asStateFlow()

    private val _card1UsedGb = MutableStateFlow(24.2)
    val card1UsedGb: StateFlow<Double> = _card1UsedGb.asStateFlow()

    private val _card1HealthPercent = MutableStateFlow(98)
    val card1HealthPercent: StateFlow<Int> = _card1HealthPercent.asStateFlow()

    private val _card1WriteSpeedMBs = MutableStateFlow(280)
    val card1WriteSpeedMBs: StateFlow<Int> = _card1WriteSpeedMBs.asStateFlow()

    // Power & Thermal State
    private val _batteryPercent = MutableStateFlow(92)
    val batteryPercent: StateFlow<Int> = _batteryPercent.asStateFlow()

    private val _isCharging = MutableStateFlow(false)
    val isCharging: StateFlow<Boolean> = _isCharging.asStateFlow()

    // Fault Injection Flags
    var simulateStorageWriteFailure = false
    var simulateSensorTimeout = false
    var simulateOverheatingFault = false

    fun switchCameraModel(model: CameraModel) {
        _activeModel.value = model
        when (model) {
            CameraModel.FOX_ONE -> {
                _connectedLensName.value = "Fox-F Prime 35mm f/1.4 Lens"
                _currentFocalLengthMm.value = 35
                _card1WriteSpeedMBs.value = 280
            }
            CameraModel.FOX_PRO -> {
                _connectedLensName.value = "Fox-F Zoom 70-200mm f/2.8 IS Lens"
                _currentFocalLengthMm.value = 85
                _card1WriteSpeedMBs.value = 1600
            }
            CameraModel.FOX_COMPACT -> {
                _connectedLensName.value = "Fox Compact Fixed 23mm f/2.0 Lens"
                _currentFocalLengthMm.value = 23
                _card1WriteSpeedMBs.value = 220
            }
        }
    }

    fun updateFocusDistance(distance: Float) {
        _focusDistanceMeters.value = max(0.2f, min(100.0f, distance))
    }

    fun consumeBattery(amount: Int = 1) {
        _batteryPercent.value = max(0, _batteryPercent.value - amount)
    }

    fun recordImageWritten(fileSizeBytes: Long) {
        val sizeGb = fileSizeBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        _card1UsedGb.value = min(_card1CapacityGb.value.toDouble(), _card1UsedGb.value + sizeGb)
        // Heating sensor slightly on capture
        _sensorTempCelsius.value = min(75.0, _sensorTempCelsius.value + 0.4)
    }

    fun coolSensorOverTime() {
        if (_sensorTempCelsius.value > 28.0) {
            _sensorTempCelsius.value = max(28.0, _sensorTempCelsius.value - 0.2)
        }
    }

    fun triggerThermalSpike(targetTempC: Double = 62.0) {
        _sensorTempCelsius.value = targetTempC
    }

    fun getRemainingFramesEstimate(avgFrameMb: Double = 48.0): Int {
        val freeMb = (_card1CapacityGb.value - _card1UsedGb.value) * 1024.0
        return max(0, (freeMb / avgFrameMb).toInt())
    }
}
