package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Fox OS Signature Palette - British Precision Instrument Design
val FoxGraphiteDark = Color(0xFF101113)
val FoxGraphiteSurface = Color(0xFF191B1F)
val FoxGraphiteElevated = Color(0xFF23262C)
val FoxGraphiteBorder = Color(0xFF32363F)

val FoxBrassAccent = Color(0xFFD4AF37)
val FoxBrassHover = Color(0xFFE5C158)
val FoxBrassMuted = Color(0xFF8A7224)

val FoxTextPrimary = Color(0xFFEDEEF0)
val FoxTextSecondary = Color(0xFFA0A5B0)
val FoxTextMuted = Color(0xFF6B707C)

val FoxStatusRecording = Color(0xFFE53935)
val FoxStatusFocusLock = Color(0xFF43A047)
val FoxStatusWarning = Color(0xFFFB8C00)
val FoxStatusZebraClipping = Color(0xFF00E676)
