package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FoxColorScheme = darkColorScheme(
    primary = FoxBrassAccent,
    onPrimary = Color.Black,
    primaryContainer = FoxBrassMuted,
    onPrimaryContainer = FoxTextPrimary,
    secondary = FoxTextSecondary,
    onSecondary = Color.Black,
    background = FoxGraphiteDark,
    onBackground = FoxTextPrimary,
    surface = FoxGraphiteSurface,
    onSurface = FoxTextPrimary,
    surfaceVariant = FoxGraphiteElevated,
    onSurfaceVariant = FoxTextSecondary,
    outline = FoxGraphiteBorder,
    error = FoxStatusRecording,
    onError = Color.White
)

@Composable
fun FoxOSTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FoxColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    FoxOSTheme(content = content)
}
