package com.example.foxos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.model.CameraModel
import com.example.foxos.model.HardwareManifestRegistry
import com.example.ui.theme.*

@Composable
fun CapabilitiesManifestScreen() {
    val models = CameraModel.entries

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FoxGraphiteDark)
            .padding(12.dp)
            .testTag("capabilities_manifest_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "DECLARATIVE HARDWARE CAPABILITY MANIFESTS",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = FoxBrassAccent,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Fox OS derives active hardware features, buffer sizing, and codec pipelines directly from camera body manifests.",
                fontSize = 11.sp,
                color = FoxTextSecondary
            )
        }

        items(models) { model ->
            val manifest = HardwareManifestRegistry.getManifest(model)
            Card(
                colors = CardDefaults.cardColors(containerColor = FoxGraphiteSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, FoxGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = manifest.model.displayName.uppercase(),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = FoxBrassAccent,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = manifest.model.subtitle,
                            fontSize = 10.sp,
                            color = FoxTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "SENSOR: ${manifest.model.sensorDescription} (${manifest.sensorResolutionMp} MP)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FoxTextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "DIMENSIONS: ${manifest.sensorWidthMm}mm x ${manifest.sensorHeightMm}mm | ISO RANGE: ${manifest.baseIso} - ${manifest.maxIso}",
                        fontSize = 10.sp,
                        color = FoxTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "BURST: ${manifest.maxContinuousFps} FPS RAW (Max Buffer: ${manifest.maxBufferFrames} frames)",
                        fontSize = 10.sp,
                        color = FoxStatusFocusLock,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "STORAGE SLOTS: ${manifest.storageSlots.joinToString { "Slot ${it.slotNumber}: ${it.mediaType} (${it.maxWriteSpeedMBs}MB/s)" }}",
                        fontSize = 10.sp,
                        color = FoxTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "VIDEO PIPELINE: ${manifest.videoMaxResolution} @ ${manifest.videoMaxFps} FPS",
                        fontSize = 10.sp,
                        color = FoxTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "TARGET USER: ${manifest.model.targetUser}",
                        fontSize = 10.sp,
                        color = FoxBrassMuted,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
