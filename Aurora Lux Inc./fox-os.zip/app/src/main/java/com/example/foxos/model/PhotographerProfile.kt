package com.example.foxos.model

/**
 * Versioned, exportable Photographer Configurations
 */
data class PhotographerProfile(
    val id: String,
    val name: String,
    val author: String,
    val description: String,
    val preferredExposureMode: ExposureMode,
    val defaultPictureProfile: PictureProfileType,
    val defaultFormat: CaptureFormat,
    val defaultMetering: MeteringMode,
    val defaultFocusMode: FocusMode,
    val autoIsoLimit: Int,
    val customDialMapping: String, // e.g. "Front Dial: Aperture | Rear Dial: Shutter"
    val filePrefix: String = "FOX",
    val version: String = "1.0.0"
)

object DefaultProfiles {
    val FoxStillsPro = PhotographerProfile(
        id = "profile_stills_pro",
        name = "Fox Stills Pro",
        author = "Fox Precision Lab",
        description = "Optimized for studio, portrait & high dynamic range RAW capture",
        preferredExposureMode = ExposureMode.MANUAL,
        defaultPictureProfile = PictureProfileType.FOX_NATURAL,
        defaultFormat = CaptureFormat.RAW_PLUS_JPEG,
        defaultMetering = MeteringMode.SPOT,
        defaultFocusMode = FocusMode.SINGLE_AF,
        autoIsoLimit = 3200,
        customDialMapping = "Front: Aperture | Rear: Shutter | Wheel: ISO",
        filePrefix = "FOX_PRO"
    )

    val StreetDocumentarian = PhotographerProfile(
        id = "profile_street",
        name = "Street Documentarian",
        author = "London Photographic Society",
        description = "High contrast monochrome rendering, fast shutter priority & zone AF",
        preferredExposureMode = ExposureMode.SHUTTER_PRIORITY,
        defaultPictureProfile = PictureProfileType.FOX_MONOCHROME,
        defaultFormat = CaptureFormat.JPEG_FINE,
        defaultMetering = MeteringMode.CENTER_WEIGHTED,
        defaultFocusMode = FocusMode.CONTINUOUS_AF,
        autoIsoLimit = 12800,
        customDialMapping = "Front: Shutter Speed | Rear: Exposure Comp",
        filePrefix = "FOX_DOC"
    )

    val LandscapeMaster = PhotographerProfile(
        id = "profile_landscape",
        name = "Landscape Master",
        author = "Scottish Highlands Expedition",
        description = "Aperture priority, base ISO lock, vivid shadow micro-contrast",
        preferredExposureMode = ExposureMode.APERTURE_PRIORITY,
        defaultPictureProfile = PictureProfileType.FOX_LANDSCAPE,
        defaultFormat = CaptureFormat.RAW_DNG,
        defaultMetering = MeteringMode.MULTI_ZONE,
        defaultFocusMode = FocusMode.MANUAL_FOCUS,
        autoIsoLimit = 800,
        customDialMapping = "Front: Aperture | Rear: Focus Magnify",
        filePrefix = "FOX_LND"
    )

    val initialProfiles = listOf(FoxStillsPro, StreetDocumentarian, LandscapeMaster)
}
