package com.example.foxos.engine

import com.example.foxos.hal.HardwareAbstractionLayer
import com.example.foxos.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Core Capture Engine supervising state transitions, shutter priority,
 * autofocus lock, and burst buffer management.
 */
class CaptureEngine(
    val hal: HardwareAbstractionLayer,
    private val scope: CoroutineScope
) {
    private val _operationalState = MutableStateFlow(CameraOperationalState.READY)
    val operationalState: StateFlow<CameraOperationalState> = _operationalState.asStateFlow()

    private val _exposureSettings = MutableStateFlow(ExposureSettings())
    val exposureSettings: StateFlow<ExposureSettings> = _exposureSettings.asStateFlow()

    private val _focusSettings = MutableStateFlow(FocusSettings())
    val focusSettings: StateFlow<FocusSettings> = _focusSettings.asStateFlow()

    private val _selectedProfile = MutableStateFlow(PictureProfileType.FOX_NATURAL)
    val selectedProfile: StateFlow<PictureProfileType> = _selectedProfile.asStateFlow()

    private val _selectedFormat = MutableStateFlow(CaptureFormat.RAW_PLUS_JPEG)
    val selectedFormat: StateFlow<CaptureFormat> = _selectedFormat.asStateFlow()

    private val _bufferedFrames = MutableStateFlow(0)
    val bufferedFrames: StateFlow<Int> = _bufferedFrames.asStateFlow()

    private val _capturedMediaList = MutableStateFlow<List<CapturedPhoto>>(emptyList())
    val capturedMediaList: StateFlow<List<CapturedPhoto>> = _capturedMediaList.asStateFlow()

    private val _lastCapturedPhoto = MutableStateFlow<CapturedPhoto?>(null)
    val lastCapturedPhoto: StateFlow<CapturedPhoto?> = _lastCapturedPhoto.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Half-press AF lock trigger
    fun onHalfPressShutter() {
        if (_operationalState.value != CameraOperationalState.READY) return
        _focusSettings.value = _focusSettings.value.copy(isFocusLocked = true)
    }

    fun onReleaseHalfPressShutter() {
        _focusSettings.value = _focusSettings.value.copy(isFocusLocked = false)
    }

    // Full press capture trigger
    fun triggerShutterCapture() {
        if (!_operationalState.value.isReadyForCapture) return

        // Check for fault injections
        if (hal.simulateStorageWriteFailure) {
            _operationalState.value = CameraOperationalState.ERROR
            _errorMessage.value = "Storage Fault: Media write failed or card unformatted (E-204)"
            return
        }

        if (hal.sensorTempCelsius.value >= 60.0) {
            _operationalState.value = CameraOperationalState.DEGRADED
            _errorMessage.value = "Thermal Warning: Sensor temperature exceeds 60°C. Capture restricted."
            return
        }

        scope.launch {
            try {
                // Step 1: Capturing Sensor Readout
                _operationalState.value = CameraOperationalState.CAPTURING
                _bufferedFrames.value += 1
                hal.consumeBattery(1)
                delay(80)

                // Step 2: ISP Processing
                _operationalState.value = CameraOperationalState.PROCESSING
                delay(120)

                // Step 3: Writing to Storage
                _operationalState.value = CameraOperationalState.SAVING
                val photo = ImagingEngine.processCapture(
                    hal = hal,
                    exposureSettings = _exposureSettings.value,
                    focusSettings = _focusSettings.value,
                    pictureProfile = _selectedProfile.value,
                    format = _selectedFormat.value
                )

                _capturedMediaList.value = listOf(photo) + _capturedMediaList.value
                _lastCapturedPhoto.value = photo
                _bufferedFrames.value = (bufferedFrames.value - 1).coerceAtLeast(0)

                // Step 4: Return to Ready
                _focusSettings.value = _focusSettings.value.copy(isFocusLocked = false)
                _operationalState.value = CameraOperationalState.READY
                _errorMessage.value = null

            } catch (e: Exception) {
                _operationalState.value = CameraOperationalState.ERROR
                _errorMessage.value = "Capture Error: ${e.message}"
            }
        }
    }

    // Direct Control Updates
    fun updateExposureSettings(transform: (ExposureSettings) -> ExposureSettings) {
        _exposureSettings.value = transform(_exposureSettings.value)
    }

    fun updateFocusSettings(transform: (FocusSettings) -> FocusSettings) {
        _focusSettings.value = transform(_focusSettings.value)
    }

    fun selectPictureProfile(profile: PictureProfileType) {
        _selectedProfile.value = profile
    }

    fun selectCaptureFormat(format: CaptureFormat) {
        _selectedFormat.value = format
    }

    fun resetErrorState() {
        _operationalState.value = CameraOperationalState.READY
        _errorMessage.value = null
        hal.simulateStorageWriteFailure = false
        hal.simulateSensorTimeout = false
        hal.simulateOverheatingFault = false
    }

    fun applyPhotographerProfile(profile: PhotographerProfile) {
        _exposureSettings.value = _exposureSettings.value.copy(
            mode = profile.preferredExposureMode,
            meteringMode = profile.defaultMetering,
            autoIsoMax = profile.autoIsoLimit
        )
        _focusSettings.value = _focusSettings.value.copy(
            focusMode = profile.defaultFocusMode
        )
        _selectedProfile.value = profile.defaultPictureProfile
        _selectedFormat.value = profile.defaultFormat
    }
}
