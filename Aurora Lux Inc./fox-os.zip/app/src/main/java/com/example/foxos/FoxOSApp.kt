package com.example.foxos

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.engine.CaptureEngine
import com.example.foxos.firmware.FirmwareService
import com.example.foxos.hal.HardwareAbstractionLayer
import com.example.foxos.model.CameraModel
import com.example.foxos.ui.screens.*
import com.example.ui.theme.*

enum class FoxNavigationTab(val label: String, val icon: ImageVector) {
    VIEWFINDER("VIEWFINDER", Icons.Default.CameraAlt),
    GALLERY("GALLERY", Icons.Default.PhotoLibrary),
    SETTINGS("PROFILES", Icons.Default.Tune),
    DIAGNOSTICS("CONSOLE", Icons.Default.Terminal),
    MANIFEST("MANIFEST", Icons.Default.Memory)
}

@Composable
fun FoxOSApp() {
    val coroutineScope = rememberCoroutineScope()
    val hal = remember { HardwareAbstractionLayer(CameraModel.FOX_ONE) }
    val captureEngine = remember { CaptureEngine(hal, coroutineScope) }
    val firmwareService = remember { FirmwareService() }

    var selectedTab by remember { mutableStateOf(FoxNavigationTab.VIEWFINDER) }
    var showModelDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = FoxGraphiteDark,
        bottomBar = {
            NavigationBar(
                containerColor = FoxGraphiteSurface,
                contentColor = FoxTextPrimary,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                FoxNavigationTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (isSelected) FoxBrassAccent else FoxTextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) FoxBrassAccent else FoxTextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = FoxGraphiteElevated
                        ),
                        modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                FoxNavigationTab.VIEWFINDER -> ViewfinderScreen(
                    engine = captureEngine,
                    hal = hal,
                    onModelClick = { showModelDialog = true }
                )
                FoxNavigationTab.GALLERY -> GalleryScreen(
                    engine = captureEngine
                )
                FoxNavigationTab.SETTINGS -> SettingsAndProfilesScreen(
                    engine = captureEngine,
                    firmwareService = firmwareService
                )
                FoxNavigationTab.DIAGNOSTICS -> EngineeringConsoleScreen(
                    engine = captureEngine,
                    hal = hal
                )
                FoxNavigationTab.MANIFEST -> CapabilitiesManifestScreen()
            }

            // Camera Model Switcher Dialog
            if (showModelDialog) {
                AlertDialog(
                    onDismissRequest = { showModelDialog = false },
                    title = {
                        Text(
                            text = "SELECT FOX CAMERA BODY",
                            color = FoxBrassAccent,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            CameraModel.entries.forEach { model ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            hal.switchCameraModel(model)
                                            showModelDialog = false
                                        },
                                    color = FoxGraphiteElevated,
                                    shape = RoundedCornerShape(6.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, FoxGraphiteBorder)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = model.displayName.uppercase(),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = FoxBrassAccent,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = model.sensorDescription,
                                            fontSize = 11.sp,
                                            color = FoxTextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showModelDialog = false }) {
                            Text("CLOSE", color = FoxTextSecondary, fontFamily = FontFamily.Monospace)
                        }
                    },
                    containerColor = FoxGraphiteSurface
                )
            }
        }
    }
}
