package com.example.foxos.model

/**
 * Camera Models in the Fox Series
 */
enum class CameraModel(
    val displayName: String,
    val subtitle: String,
    val sensorDescription: String,
    val targetUser: String
) {
    FOX_ONE(
        displayName = "Fox One",
        subtitle = "Reference Stills Camera",
        sensorDescription = "45.7 MP Full-Frame BSI CMOS Sensor",
        targetUser = "Fine Art & Studio Photographers"
    ),
    FOX_PRO(
        displayName = "Fox Pro",
        subtitle = "Professional High-Speed & Cinema",
        sensorDescription = "24.2 MP Full-Frame Stacked CMOS Sensor",
        targetUser = "Photojournalists & Motion Creatives"
    ),
    FOX_COMPACT(
        displayName = "Fox Compact",
        subtitle = "Minimal Street Reference",
        sensorDescription = "26.1 MP APS-C X-Trans Sensor",
        targetUser = "Documentary & Everyday Enthusiasts"
    )
}

/**
 * Declarative Hardware Capability Manifest
 */
data class HardwareCapabilityManifest(
    val model: CameraModel,
    val sensorResolutionMp: Double,
    val sensorWidthMm: Double,
    val sensorHeightMm: Double,
    val baseIso: Int,
    val maxIso: Int,
    val supportedShutterModes: List<String>,
    val minShutterSpeedSec: Double, // e.g. 1/8000
    val maxShutterSpeedSec: Double, // e.g. 30.0
    val maxContinuousFps: Int,
    val storageSlots: List<StorageSlotSpec>,
    val autofocusTypes: List<String>,
    val hasEyeTracking: Boolean,
    val hasVehicleTracking: Boolean,
    val videoMaxResolution: String,
    val videoMaxFps: Int,
    val maxBufferFrames: Int,
    val thermalMaxOperatingTempC: Double
)

data class StorageSlotSpec(
    val slotNumber: Int,
    val mediaType: String, // e.g. "SD UHS-II", "CFexpress Type B"
    val maxWriteSpeedMBs: Int
)

object HardwareManifestRegistry {
    val FoxOneManifest = HardwareCapabilityManifest(
        model = CameraModel.FOX_ONE,
        sensorResolutionMp = 45.7,
        sensorWidthMm = 35.9,
        sensorHeightMm = 23.9,
        baseIso = 64,
        maxIso = 51200,
        supportedShutterModes = listOf("Mechanical Shutter", "Electronic Shutter", "Hybrid EFCS"),
        minShutterSpeedSec = 1.0 / 8000.0,
        maxShutterSpeedSec = 30.0,
        maxContinuousFps = 10,
        storageSlots = listOf(
            StorageSlotSpec(1, "SD UHS-II", 300),
            StorageSlotSpec(2, "SD UHS-II", 300)
        ),
        autofocusTypes = listOf("Hybrid Phase/Contrast", "Precision Single AF", "Manual Peaking"),
        hasEyeTracking = true,
        hasVehicleTracking = true,
        videoMaxResolution = "4K DCI (3840x2160)",
        videoMaxFps = 60,
        maxBufferFrames = 80,
        thermalMaxOperatingTempC = 55.0
    )

    val FoxProManifest = HardwareCapabilityManifest(
        model = CameraModel.FOX_PRO,
        sensorResolutionMp = 24.2,
        sensorWidthMm = 35.8,
        sensorHeightMm = 23.8,
        baseIso = 100,
        maxIso = 102400,
        supportedShutterModes = listOf("High-Speed Electronic", "Mechanical Shutter"),
        minShutterSpeedSec = 1.0 / 32000.0,
        maxShutterSpeedSec = 30.0,
        maxContinuousFps = 30,
        storageSlots = listOf(
            StorageSlotSpec(1, "CFexpress Type B", 1700),
            StorageSlotSpec(2, "CFexpress Type B", 1700)
        ),
        autofocusTypes = listOf("Quad-Pixel Phase Detection", "Deep Neural AF Tracking"),
        hasEyeTracking = true,
        hasVehicleTracking = true,
        videoMaxResolution = "6K RAW Uncompressed",
        videoMaxFps = 120,
        maxBufferFrames = 250,
        thermalMaxOperatingTempC = 60.0
    )

    val FoxCompactManifest = HardwareCapabilityManifest(
        model = CameraModel.FOX_COMPACT,
        sensorResolutionMp = 26.1,
        sensorWidthMm = 23.5,
        sensorHeightMm = 15.6,
        baseIso = 160,
        maxIso = 25600,
        supportedShutterModes = listOf("Leaf Shutter", "Electronic Shutter"),
        minShutterSpeedSec = 1.0 / 4000.0,
        maxShutterSpeedSec = 30.0,
        maxContinuousFps = 8,
        storageSlots = listOf(
            StorageSlotSpec(1, "SD UHS-II", 250)
        ),
        autofocusTypes = listOf("Contrast AF", "Zone Phase Detection"),
        hasEyeTracking = true,
        hasVehicleTracking = false,
        videoMaxResolution = "4K UHD (3840x2160)",
        videoMaxFps = 30,
        maxBufferFrames = 40,
        thermalMaxOperatingTempC = 50.0
    )

    fun getManifest(model: CameraModel): HardwareCapabilityManifest {
        return when (model) {
            CameraModel.FOX_ONE -> FoxOneManifest
            CameraModel.FOX_PRO -> FoxProManifest
            CameraModel.FOX_COMPACT -> FoxCompactManifest
        }
    }
}
