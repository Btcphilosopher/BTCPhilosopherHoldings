package com.example.foxos.model

/**
 * Capture State Machine Operational States
 */
enum class CameraOperationalState(val label: String, val isReadyForCapture: Boolean) {
    OFF("Power Off", false),
    BOOTING("Bootloader Loading...", false),
    INITIALISING("Initialising Hardware Sensor & Lens...", false),
    READY("Ready", true),
    CAPTURING("Capturing Readout...", false),
    PROCESSING("Demosaicing & ISP Pipeline...", false),
    SAVING("Writing to Storage...", false),
    DEGRADED("Degraded (Buffer High / High Temp)", true),
    ERROR("System Fault / Card Error", false),
    UPDATING("Firmware Flashing A/B...", false),
    RECOVERY("Safe Recovery Mode", false)
}

enum class ExposureMode(val label: String, val shortCode: String) {
    MANUAL("Manual", "M"),
    APERTURE_PRIORITY("Aperture Priority", "A"),
    SHUTTER_PRIORITY("Shutter Priority", "S"),
    PROGRAM_AUTO("Program Auto", "P")
}

enum class MeteringMode(val label: String) {
    SPOT("Spot Metering (3.5%)"),
    CENTER_WEIGHTED("Center-Weighted Average"),
    MULTI_ZONE("Evaluative Multi-Zone")
}

enum class FocusMode(val label: String, val shortCode: String) {
    SINGLE_AF("Single AF (AF-S)", "S-AF"),
    CONTINUOUS_AF("Continuous AF (AF-C)", "C-AF"),
    MANUAL_FOCUS("Manual Focus (MF)", "MF")
}

enum class SubjectDetectionMode(val label: String) {
    OFF("Disabled"),
    HUMAN_EYE("Human Eye & Face Detection"),
    ANIMAL("Animal & Bird Tracking"),
    VEHICLE("Motorsport & Aircraft")
}

enum class PictureProfileType(
    val id: String,
    val title: String,
    val description: String,
    val defaultContrast: Int, // -5 to +5
    val defaultSaturation: Int,
    val defaultSharpness: Int,
    val defaultNoiseReduction: Int
) {
    FOX_NATURAL(
        id = "fox_natural",
        title = "Fox Natural",
        description = "Neutral colour rendering, balanced contrast and faithful tonality",
        defaultContrast = 0,
        defaultSaturation = 0,
        defaultSharpness = 0,
        defaultNoiseReduction = 0
    ),
    FOX_DOCUMENTARY(
        id = "fox_documentary",
        title = "Fox Documentary",
        description = "Realistic reporter tones, controlled highlights and moderate local contrast",
        defaultContrast = +1,
        defaultSaturation = -1,
        defaultSharpness = +1,
        defaultNoiseReduction = 0
    ),
    FOX_PORTRAIT(
        id = "fox_portrait",
        title = "Fox Portrait",
        description = "Restrained skin-tone rendering, gentle shadow roll-off and smooth gradations",
        defaultContrast = -1,
        defaultSaturation = 0,
        defaultSharpness = -1,
        defaultNoiseReduction = +1
    ),
    FOX_LANDSCAPE(
        id = "fox_landscape",
        title = "Fox Landscape",
        description = "Nuanced greens and blues, micro-contrast enhancement and sky retention",
        defaultContrast = +2,
        defaultSaturation = +2,
        defaultSharpness = +2,
        defaultNoiseReduction = 0
    ),
    FOX_MONOCHROME(
        id = "fox_monochrome",
        title = "Fox Monochrome",
        description = "Classic British black-and-white tonal curve with simulated film grain",
        defaultContrast = +2,
        defaultSaturation = -5,
        defaultSharpness = +1,
        defaultNoiseReduction = -1
    ),
    FOX_CINEMA(
        id = "fox_cinema",
        title = "Fox Cinema (Log)",
        description = "Flat dynamic profile for motion grading and maximum highlight retention",
        defaultContrast = -3,
        defaultSaturation = -2,
        defaultSharpness = -2,
        defaultNoiseReduction = -1
    )
}

enum class CaptureFormat(val label: String, val extension: String) {
    RAW_DNG("Uncompressed RAW (.DNG)", "DNG"),
    JPEG_FINE("Fine JPEG (.JPG)", "JPG"),
    RAW_PLUS_JPEG("RAW + Fine JPEG (.DNG+.JPG)", "DNG+JPG")
}

data class ExposureSettings(
    val mode: ExposureMode = ExposureMode.MANUAL,
    val aperture: String = "f/2.8",
    val apertureValue: Double = 2.8,
    val shutterSpeed: String = "1/500",
    val shutterSpeedSec: Double = 0.002,
    val iso: Int = 400,
    val isAutoIso: Boolean = false,
    val autoIsoMax: Int = 6400,
    val exposureCompensation: Double = 0.0, // -3.0 to +3.0 EV
    val meteringMode: MeteringMode = MeteringMode.MULTI_ZONE,
    val evfSimulationEnabled: Boolean = true
)

data class FocusSettings(
    val focusMode: FocusMode = FocusMode.SINGLE_AF,
    val focusPointXRatio: Float = 0.5f, // 0.0 to 1.0 on preview frame
    val focusPointYRatio: Float = 0.5f,
    val isFocusLocked: Boolean = false,
    val subjectDetection: SubjectDetectionMode = SubjectDetectionMode.HUMAN_EYE,
    val focusPeakingEnabled: Boolean = true,
    val focusPeakingColorHex: String = "#00E676",
    val focusMagnification: Int = 1 // 1x, 3x, 6x
)
