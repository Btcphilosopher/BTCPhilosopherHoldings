package com.example.foxos.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.engine.CaptureEngine
import com.example.foxos.firmware.FirmwareService
import com.example.foxos.model.DefaultProfiles
import com.example.foxos.model.PhotographerProfile
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsAndProfilesScreen(
    engine: CaptureEngine,
    firmwareService: FirmwareService
) {
    val coroutineScope = rememberCoroutineScope()
    val currentFwVersion by firmwareService.currentVersion.collectAsState()
    val activePartition by firmwareService.activePartition.collectAsState()
    val isFlashing by firmwareService.isFlashing.collectAsState()
    val progressPercent by firmwareService.updateProgressPercent.collectAsState()
    val updateStatus by firmwareService.updateStatusText.collectAsState()

    var activeProfileId by remember { mutableStateOf(DefaultProfiles.FoxStillsPro.id) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FoxGraphiteDark)
            .padding(12.dp)
            .testTag("settings_profiles_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "PHOTOGRAPHER PROFILES & FIRMWARE MANAGEMENT",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = FoxBrassAccent,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        // Section 1: Photographer Profiles
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = FoxGraphiteSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, FoxGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "SELECT PHOTOGRAPHER PROFILE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FoxBrassAccent,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    DefaultProfiles.initialProfiles.forEach { profile ->
                        val isSelected = activeProfileId == profile.id
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(
                                    if (isSelected) FoxBrassMuted else FoxGraphiteElevated,
                                    RoundedCornerShape(6.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) FoxBrassAccent else FoxGraphiteBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable {
                                    activeProfileId = profile.id
                                    engine.applyPhotographerProfile(profile)
                                }
                                .padding(12.dp)
                                .testTag("select_profile_${profile.id}")
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = profile.name.uppercase(),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) FoxBrassAccent else FoxTextPrimary,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = profile.author,
                                        fontSize = 10.sp,
                                        color = FoxTextMuted,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = profile.description,
                                    fontSize = 11.sp,
                                    color = FoxTextSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "MAPPINGS: ${profile.customDialMapping} | PREFIX: ${profile.filePrefix}",
                                    fontSize = 9.sp,
                                    color = FoxStatusFocusLock,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Firmware Service (A/B Partition Flashing & Signature Check)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = FoxGraphiteSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, FoxBrassAccent)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "FOX FIRMWARE SERVICE (A/B RECOVERY)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = FoxBrassAccent,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "ACTIVE: $currentFwVersion",
                            fontSize = 11.sp,
                            color = FoxStatusFocusLock,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Partition Slot: $activePartition",
                        fontSize = 10.sp,
                        color = FoxTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val pkg = firmwareService.availablePackage
                    Text(
                        text = "AVAILABLE FIRMWARE UPDATE: v${pkg.version}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FoxTextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = pkg.releaseNotes,
                        fontSize = 11.sp,
                        color = FoxTextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isFlashing) {
                        Column {
                            LinearProgressIndicator(
                                progress = { progressPercent / 100f },
                                modifier = Modifier.fillMaxWidth().height(6.dp),
                                color = FoxBrassAccent,
                                trackColor = FoxGraphiteElevated
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$updateStatus ($progressPercent%)",
                                fontSize = 10.sp,
                                color = FoxBrassAccent,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    firmwareService.installFirmware(pkg) {}
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FoxBrassAccent, contentColor = Color.Black),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth().testTag("install_firmware_button")
                        ) {
                            Text(
                                text = "VERIFY & INSTALL FIRMWARE V${pkg.version}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
