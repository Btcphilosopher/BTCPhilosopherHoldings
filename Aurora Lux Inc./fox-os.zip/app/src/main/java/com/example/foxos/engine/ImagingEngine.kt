package com.example.foxos.engine

import com.example.R
import com.example.foxos.hal.HardwareAbstractionLayer
import com.example.foxos.model.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

object ImagingEngine {

    private var photoCounter = 1001

    /**
     * Executes the Fox OS RAW Development & JPEG Encoding Pipeline
     */
    suspend fun processCapture(
        hal: HardwareAbstractionLayer,
        exposureSettings: ExposureSettings,
        focusSettings: FocusSettings,
        pictureProfile: PictureProfileType,
        format: CaptureFormat
    ): CapturedPhoto {
        val model = hal.activeModel.value
        val manifest = HardwareManifestRegistry.getManifest(model)

        // Stage 1: Sensor Readout & Black Level Correction (Simulated timing)
        delay(40) 

        // Stage 2: Demosaicing & Colour Reconstruction
        delay(60)

        // Stage 3: Picture Profile Tone Curve & Sharpening
        delay(50)

        // Generate Filename
        val timestamp = System.currentTimeMillis()
        val timeString = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.UK).format(Date(timestamp))
        val filename = "FOX_${model.name}_${timeString}_$photoCounter.${format.extension.lowercase()}"
        photoCounter++

        // Pick sample image drawable based on picture profile
        val sampleDrawableRes = when (pictureProfile) {
            PictureProfileType.FOX_MONOCHROME -> R.drawable.fox_sample_monochrome_1792913969843
            PictureProfileType.FOX_PORTRAIT -> R.drawable.fox_sample_portrait_1792913957683
            else -> R.drawable.fox_sample_landscape_1792913946568
        }

        // File size calculation based on sensor resolution and format
        val rawSizeMb = (manifest.sensorResolutionMp * 1.8).toLong() * 1024 * 1024
        val jpegSizeMb = (manifest.sensorResolutionMp * 0.35).toLong() * 1024 * 1024

        val (rawBytes, jpegBytes) = when (format) {
            CaptureFormat.RAW_DNG -> Pair(rawSizeMb, 0L)
            CaptureFormat.JPEG_FINE -> Pair(0L, jpegSizeMb)
            CaptureFormat.RAW_PLUS_JPEG -> Pair(rawSizeMb, jpegSizeMb)
        }

        // Compute EXIF Histogram
        val metering = ExposureEngine.evaluateExposure(exposureSettings)

        // Record to HAL media storage
        hal.recordImageWritten(rawBytes + jpegBytes)

        return CapturedPhoto(
            id = UUID.randomUUID().toString(),
            filename = filename,
            timestampMs = timestamp,
            cameraModel = model,
            aperture = exposureSettings.aperture,
            shutterSpeed = exposureSettings.shutterSpeed,
            iso = exposureSettings.iso,
            focalLengthMm = hal.currentFocalLengthMm.value,
            lensModel = hal.connectedLensName.value,
            pictureProfile = pictureProfile,
            format = format,
            rawSizeBytes = rawBytes,
            jpegSizeBytes = jpegBytes,
            imageDrawableRes = sampleDrawableRes,
            histogramLuminance = metering.histogramLuminance
        )
    }
}
