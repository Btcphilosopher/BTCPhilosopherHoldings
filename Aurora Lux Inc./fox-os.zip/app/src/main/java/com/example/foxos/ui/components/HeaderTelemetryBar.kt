package com.example.foxos.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.model.CameraModel
import com.example.foxos.model.CameraOperationalState
import com.example.ui.theme.*

@Composable
fun HeaderTelemetryBar(
    model: CameraModel,
    state: CameraOperationalState,
    batteryPercent: Int,
    tempCelsius: Double,
    cardHealthPercent: Int,
    remainingFrames: Int,
    firmwareVersion: String,
    onModelClick: () -> Unit
) {
    val stateBgColor by animateColorAsState(
        targetValue = when (state) {
            CameraOperationalState.READY -> FoxStatusFocusLock
            CameraOperationalState.CAPTURING, CameraOperationalState.SAVING -> FoxBrassAccent
            CameraOperationalState.ERROR -> FoxStatusRecording
            CameraOperationalState.DEGRADED -> FoxStatusWarning
            else -> FoxGraphiteBorder
        },
        label = "stateColor"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("header_telemetry_bar"),
        color = FoxGraphiteDark
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Camera Brand & Model Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "FOX OS",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = FoxBrassAccent,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    OutlinedButton(
                        onClick = onModelClick,
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("model_selector_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = FoxTextPrimary
                        )
                    ) {
                        Text(
                            text = model.displayName.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Select Camera Model",
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Status pill
                    Box(
                        modifier = Modifier
                            .background(stateBgColor, RoundedCornerShape(3.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = state.label.uppercase(),
                            color = Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Right: System Telemetry (Battery, Temp, Storage, FW)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Memory Card Frames
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SdCard,
                            contentDescription = "Card Status",
                            tint = FoxBrassAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${remainingFrames}f",
                            fontSize = 11.sp,
                            color = FoxTextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Temperature
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Thermostat,
                            contentDescription = "Temperature",
                            tint = if (tempCelsius > 55.0) FoxStatusRecording else FoxTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "${String.format("%.1f", tempCelsius)}°C",
                            fontSize = 11.sp,
                            color = if (tempCelsius > 55.0) FoxStatusRecording else FoxTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Battery
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when {
                                batteryPercent > 70 -> Icons.Default.BatteryFull
                                batteryPercent > 30 -> Icons.Default.Battery5Bar
                                else -> Icons.Default.Battery1Bar
                            },
                            contentDescription = "Battery",
                            tint = if (batteryPercent < 20) FoxStatusRecording else FoxBrassAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "$batteryPercent%",
                            fontSize = 11.sp,
                            color = FoxTextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            HorizontalDivider(color = FoxGraphiteBorder, thickness = 1.dp)
        }
    }
}
