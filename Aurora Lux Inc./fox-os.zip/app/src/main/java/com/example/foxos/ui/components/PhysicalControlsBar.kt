package com.example.foxos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.model.*
import com.example.ui.theme.*

@Composable
fun PhysicalControlsBar(
    exposureSettings: ExposureSettings,
    focusSettings: FocusSettings,
    onExposureChange: ((ExposureSettings) -> ExposureSettings) -> Unit,
    onFocusChange: ((FocusSettings) -> FocusSettings) -> Unit
) {
    val shutterSpeeds = listOf("1/8000", "1/4000", "1/2000", "1/1000", "1/500", "1/250", "1/125", "1/60", "1/30", "1/15", "1/4", "1s", "2s")
    val apertures = listOf("f/1.4", "f/1.8", "f/2.0", "f/2.8", "f/4.0", "f/5.6", "f/8.0", "f/11", "f/16")
    val isoList = listOf(64, 100, 200, 400, 800, 1600, 3200, 6400, 12800, 25600)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("physical_controls_bar"),
        color = FoxGraphiteSurface
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            // Mode & Focus Switches Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Exposure Mode Selector (M, A, S, P)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MODE:",
                        fontSize = 10.sp,
                        color = FoxTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    ExposureMode.entries.forEach { mode ->
                        val isSelected = exposureSettings.mode == mode
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) FoxBrassAccent else FoxGraphiteElevated,
                                    RoundedCornerShape(4.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) FoxBrassHover else FoxGraphiteBorder,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { onExposureChange { it.copy(mode = mode) } }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("mode_${mode.shortCode.lowercase()}")
                        ) {
                            Text(
                                text = mode.shortCode,
                                color = if (isSelected) Color.Black else FoxTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Focus Mode Switch (S-AF, C-AF, MF)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AF/MF:",
                        fontSize = 10.sp,
                        color = FoxTextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    FocusMode.entries.forEach { fm ->
                        val isSelected = focusSettings.focusMode == fm
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) FoxStatusFocusLock else FoxGraphiteElevated,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { onFocusChange { it.copy(focusMode = fm) } }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                .testTag("focus_${fm.shortCode.lowercase()}")
                        ) {
                            Text(
                                text = fm.shortCode,
                                color = if (isSelected) Color.White else FoxTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Tactile Dial 1: Shutter Speed Selector Ring
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "SHUTTER",
                    fontSize = 9.sp,
                    color = FoxBrassAccent,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(55.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(shutterSpeeds) { speed ->
                        val isSelected = exposureSettings.shutterSpeed == speed
                        val speedSec = when (speed) {
                            "1/8000" -> 1.0/8000.0
                            "1/4000" -> 1.0/4000.0
                            "1/2000" -> 1.0/2000.0
                            "1/1000" -> 1.0/1000.0
                            "1/500" -> 1.0/500.0
                            "1/250" -> 1.0/250.0
                            "1/125" -> 1.0/125.0
                            "1/60" -> 1.0/60.0
                            "1/30" -> 1.0/30.0
                            "1/15" -> 1.0/15.0
                            "1/4" -> 0.25
                            "1s" -> 1.0
                            else -> 2.0
                        }
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) FoxBrassMuted else FoxGraphiteElevated,
                                    RoundedCornerShape(3.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) FoxBrassAccent else FoxGraphiteBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .clickable {
                                    onExposureChange {
                                        it.copy(shutterSpeed = speed, shutterSpeedSec = speedSec)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = speed,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isSelected) FoxBrassAccent else FoxTextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Tactile Dial 2: Aperture Selector Ring
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "APERTURE",
                    fontSize = 9.sp,
                    color = FoxBrassAccent,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(55.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(apertures) { aperture ->
                        val isSelected = exposureSettings.aperture == aperture
                        val apertureVal = aperture.replace("f/", "").toDoubleOrNull() ?: 2.8
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) FoxBrassMuted else FoxGraphiteElevated,
                                    RoundedCornerShape(3.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) FoxBrassAccent else FoxGraphiteBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .clickable {
                                    onExposureChange {
                                        it.copy(aperture = aperture, apertureValue = apertureVal)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = aperture,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isSelected) FoxBrassAccent else FoxTextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Tactile Dial 3: ISO Selector Ring
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "ISO DIAL",
                    fontSize = 9.sp,
                    color = FoxBrassAccent,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(55.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(isoList) { isoVal ->
                        val isSelected = exposureSettings.iso == isoVal
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) FoxBrassMuted else FoxGraphiteElevated,
                                    RoundedCornerShape(3.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) FoxBrassAccent else FoxGraphiteBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .clickable {
                                    onExposureChange {
                                        it.copy(iso = isoVal, isAutoIso = false)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "$isoVal",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isSelected) FoxBrassAccent else FoxTextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
    }
}
