package com.example.foxos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.engine.CaptureEngine
import com.example.foxos.hal.HardwareAbstractionLayer
import com.example.foxos.model.HardwareManifestRegistry
import com.example.ui.theme.*

@Composable
fun EngineeringConsoleScreen(
    engine: CaptureEngine,
    hal: HardwareAbstractionLayer
) {
    val model by hal.activeModel.collectAsState()
    val manifest = HardwareManifestRegistry.getManifest(model)
    val tempCelsius by hal.sensorTempCelsius.collectAsState()
    val cardWriteSpeed by hal.card1WriteSpeedMBs.collectAsState()
    val state by engine.operationalState.collectAsState()

    var consoleLogs by remember {
        mutableStateOf(
            listOf(
                "[00:00:01] Fox Kernel 5.15.0-fox-arm64 loaded.",
                "[00:00:02] Sensor HAL initialized: ${manifest.model.sensorDescription}.",
                "[00:00:03] Storage Mount: Card Slot 1 (UHS-II) ready @ ${cardWriteSpeed}MB/s.",
                "[00:00:04] Capture Engine State -> ${state.name}."
            )
        )
    }

    fun log(msg: String) {
        consoleLogs = listOf("[${System.currentTimeMillis() % 100000}] $msg") + consoleLogs
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FoxGraphiteDark)
            .padding(12.dp)
            .testTag("engineering_console_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FOX ENGINEERING CONSOLE — INTERNAL DIAGNOSTICS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = FoxBrassAccent,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "DEV BUILD #4920",
                    fontSize = 11.sp,
                    color = FoxStatusFocusLock,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Section 1: Hardware Telemetry Metrics
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = FoxGraphiteSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, FoxGraphiteBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "SENSOR & READOUT TELEMETRY (${model.displayName.uppercase()})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FoxBrassAccent,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Sensor: ${manifest.model.sensorDescription}",
                        fontSize = 11.sp,
                        color = FoxTextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Thermal State: ${String.format("%.1f", tempCelsius)}°C", fontSize = 11.sp, color = if (tempCelsius > 55.0) FoxStatusRecording else FoxStatusFocusLock, fontFamily = FontFamily.Monospace)
                        Text("Write Speed: ${cardWriteSpeed} MB/s", fontSize = 11.sp, color = FoxTextSecondary, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Section 2: Fault Injection Suite
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = FoxGraphiteSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, FoxStatusRecording)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "FAULT INJECTION SUITE (SIMULATE HARDWARE FAULTS)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FoxStatusRecording,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                hal.simulateStorageWriteFailure = true
                                log("FAULT INJECTED: Storage Card Write Error triggered.")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FoxStatusRecording),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f).testTag("inject_storage_error")
                        ) {
                            Text("Simulate Card Error", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }

                        Button(
                            onClick = {
                                hal.triggerThermalSpike(63.5)
                                log("FAULT INJECTED: Sensor Thermal Spike (63.5°C) triggered.")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FoxStatusWarning),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f).testTag("inject_thermal_spike")
                        ) {
                            Text("Trigger Overheat", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Button(
                        onClick = {
                            engine.resetErrorState()
                            log("RECOVERY EXECUTE: Hardware faults cleared. Operational state -> READY.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FoxStatusFocusLock),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("execute_system_recovery")
                    ) {
                        Text("Execute System Recovery & Reset Faults", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section 3: Live System Log Console
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                border = androidx.compose.foundation.BorderStroke(1.dp, FoxBrassMuted)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)
                ) {
                    Text(
                        text = "SYSTEM KERNEL & CAPTURE LOG TRACE",
                        fontSize = 10.sp,
                        color = FoxBrassAccent,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    consoleLogs.forEach { logLine ->
                        Text(
                            text = logLine,
                            fontSize = 10.sp,
                            color = FoxTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
