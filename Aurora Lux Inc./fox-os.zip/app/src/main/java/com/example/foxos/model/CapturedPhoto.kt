package com.example.foxos.model

/**
 * Metadata record for captured photographs saved in Fox OS media service
 */
data class CapturedPhoto(
    val id: String,
    val filename: String,
    val timestampMs: Long,
    val cameraModel: CameraModel,
    val aperture: String,
    val shutterSpeed: String,
    val iso: Int,
    val focalLengthMm: Int,
    val lensModel: String,
    val pictureProfile: PictureProfileType,
    val format: CaptureFormat,
    val rawSizeBytes: Long,
    val jpegSizeBytes: Long,
    val imageDrawableRes: Int, // Resource ID or drawable
    val histogramLuminance: List<Float>, // 32 bin values 0.0 - 1.0
    val latitude: Double? = 51.5074, // London reference coordinates
    val longitude: Double? = -0.1278,
    val isVerifiedOnCard: Boolean = true
)
