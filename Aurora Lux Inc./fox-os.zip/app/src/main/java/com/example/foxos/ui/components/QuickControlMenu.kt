package com.example.foxos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foxos.model.*
import com.example.ui.theme.*

@Composable
fun QuickControlMenu(
    selectedProfile: PictureProfileType,
    selectedFormat: CaptureFormat,
    meteringMode: MeteringMode,
    subjectDetection: SubjectDetectionMode,
    onSelectProfile: (PictureProfileType) -> Unit,
    onSelectFormat: (CaptureFormat) -> Unit,
    onSelectMetering: (MeteringMode) -> Unit,
    onSelectSubjectDetection: (SubjectDetectionMode) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .testTag("quick_control_menu"),
        shape = RoundedCornerShape(8.dp),
        color = FoxGraphiteSurface,
        tonalElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, FoxBrassMuted)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MY FOX QUICK CONTROLS",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = FoxBrassAccent,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Menu",
                        tint = FoxTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 1: Picture Profile
            Text(
                text = "PICTURE PROFILE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = FoxTextMuted,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                PictureProfileType.entries.chunked(2).forEach { rowProfiles ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        rowProfiles.forEach { profile ->
                            val isSelected = selectedProfile == profile
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (isSelected) FoxBrassMuted else FoxGraphiteElevated,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) FoxBrassAccent else FoxGraphiteBorder,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .clickable { onSelectProfile(profile) }
                                    .padding(vertical = 8.dp, horizontal = 10.dp)
                                    .testTag("qmenu_profile_${profile.id}")
                            ) {
                                Text(
                                    text = profile.title,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) FoxBrassAccent else FoxTextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Section 2: Capture Format
            Text(
                text = "FILE FORMAT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = FoxTextMuted,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                CaptureFormat.entries.forEach { fmt ->
                    val isSelected = selectedFormat == fmt
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (isSelected) FoxBrassMuted else FoxGraphiteElevated,
                                RoundedCornerShape(4.dp)
                            )
                            .border(
                                1.dp,
                                if (isSelected) FoxBrassAccent else FoxGraphiteBorder,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { onSelectFormat(fmt) }
                            .padding(vertical = 8.dp, horizontal = 8.dp)
                            .testTag("qmenu_format_${fmt.extension.lowercase()}")
                    ) {
                        Text(
                            text = fmt.extension,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) FoxBrassAccent else FoxTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Section 3: Subject Detection
            Text(
                text = "SUBJECT DETECTION AF",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = FoxTextMuted,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                SubjectDetectionMode.entries.forEach { sd ->
                    val isSelected = subjectDetection == sd
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (isSelected) FoxStatusFocusLock else FoxGraphiteElevated,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { onSelectSubjectDetection(sd) }
                            .padding(vertical = 6.dp, horizontal = 6.dp)
                    ) {
                        Text(
                            text = sd.label.split(" ").first(),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else FoxTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
