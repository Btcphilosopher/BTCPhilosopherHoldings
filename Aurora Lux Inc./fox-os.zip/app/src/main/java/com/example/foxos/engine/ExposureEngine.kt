package com.example.foxos.engine

import com.example.foxos.model.ExposureSettings
import com.example.foxos.model.MeteringMode

data class MeteringResult(
    val calculatedEv: Double,
    val histogramLuminance: List<Float>, // 32 normalized bins
    val highlightClippingRatio: Float, // 0.0 to 1.0
    val shadowUnderexposedRatio: Float
)

object ExposureEngine {

    /**
     * Compute simulated scene exposure based on camera settings and metering mode
     */
    fun evaluateExposure(settings: ExposureSettings): MeteringResult {
        // EV100 formula: log2(Aperture^2 / ShutterSpeed) - log2(ISO/100)
        val shutterSec = settings.shutterSpeedSec
        val aperture = settings.apertureValue
        val iso = settings.iso

        val evBase = Math.log(aperture * aperture / shutterSec) / Math.log(2.0)
        val isoCompensation = Math.log(iso / 100.0) / Math.log(2.0)
        val calculatedEv = evBase - isoCompensation + settings.exposureCompensation

        // Generate synthetic histogram based on EV shift
        val shiftFactor = ((calculatedEv - 12.0) / 6.0).coerceIn(-1.5, 1.5)
        
        val histogram = MutableList(32) { 0.0f }
        for (i in 0 until 32) {
            val center = 16.0 + shiftFactor * 8.0
            val dist = Math.abs(i - center)
            val weight = Math.exp(-0.15 * dist * dist).toFloat()
            histogram[i] = (weight + 0.05f).coerceIn(0.01f, 1.0f)
        }

        // Adjust weighting based on Metering Mode
        val highlightThresholdBin = 28
        val shadowThresholdBin = 3

        val totalWeight = histogram.sum()
        val highlightWeight = histogram.subList(highlightThresholdBin, 32).sum()
        val shadowWeight = histogram.subList(0, shadowThresholdBin).sum()

        val highlightClippingRatio = when (settings.meteringMode) {
            MeteringMode.SPOT -> (highlightWeight / totalWeight * 1.5f).coerceIn(0f, 1f)
            MeteringMode.CENTER_WEIGHTED -> (highlightWeight / totalWeight * 1.2f).coerceIn(0f, 1f)
            MeteringMode.MULTI_ZONE -> (highlightWeight / totalWeight * 0.9f).coerceIn(0f, 1f)
        }

        val shadowUnderexposedRatio = (shadowWeight / totalWeight).coerceIn(0f, 1f)

        return MeteringResult(
            calculatedEv = calculatedEv,
            histogramLuminance = histogram,
            highlightClippingRatio = highlightClippingRatio,
            shadowUnderexposedRatio = shadowUnderexposedRatio
        )
    }
}
