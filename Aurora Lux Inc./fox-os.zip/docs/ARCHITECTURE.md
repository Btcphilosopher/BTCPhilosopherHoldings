# Fox OS Architecture & System Boundaries

## System Overview

Fox OS uses a modular architecture with explicit boundaries between hardware abstraction, exposure calculation, capture orchestration, imaging pipeline, and presentation.

```
┌─────────────────────────────────────────────────────────┐
│              Fox OS Graphical Viewfinder UI             │
│   (ViewfinderOverlay, PhysicalControlsBar, Q-Menu)     │
└───────────────────────────┬─────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────┐
│                 Fox Capture Engine                      │
│   (State Supervisor, Shutter Priority, Buffer Queue)    │
└────────┬──────────────────┬──────────────────┬──────────┘
         │                  │                  │
┌────────▼─────────┐ ┌──────▼──────────┐ ┌─────▼──────────┐
│ Exposure Engine  │ │  Imaging Engine │ │ Firmware Service│
│ (Metering, EV)   │ │ (RAW, Picture)  │ │ (A/B Flashing)  │
└────────┬─────────┘ └──────┬──────────┘ └─────┬──────────┘
         │                  │                  │
┌────────▼──────────────────▼──────────────────▼──────────┐
│           Fox Hardware Abstraction Layer (HAL)          │
│     (Sensor HAL, Lens Mount, Storage, Power/Thermal)    │
└─────────────────────────────────────────────────────────┘
```

## Component Responsibilities

1. **Hardware Abstraction Layer (`hal/`)**:
   - Isolates sensor, lens, storage card, and thermal sensors from upper services.
   - Provides mock hardware implementations for continuous integration and rapid prototyping.

2. **Capture Engine (`engine/CaptureEngine.kt`)**:
   - Enforces valid state transitions (`READY` → `CAPTURING` → `PROCESSING` → `SAVING` → `READY`).
   - Grants top priority to the physical shutter release over nonessential tasks.

3. **Imaging Engine (`engine/ImagingEngine.kt`)**:
   - Manages Demosaicing, tone mapping, picture profiles (*Fox Natural*, *Monochrome*, *Landscape*), and EXIF file generation.

4. **Exposure Engine (`engine/ExposureEngine.kt`)**:
   - Computes light metering (Spot, Center-Weighted, Multi-Zone) and real-time RGB/Luminance histograms.

5. **Firmware Service (`firmware/FirmwareService.kt`)**:
   - Verifies SHA-256 cryptographic signatures and safely manages A/B partition flashing.
