# Fox OS — Operating System for the Fox Series Digital Cameras

> **Fox Camera Company** — Precision British Camera Engineering

Fox OS is a production-oriented embedded camera operating system designed for the **Fox Series** of digital cameras (**Fox One**, **Fox Pro**, **Fox Compact**). It combines the immediacy of a traditional mechanical camera with the computational power of a modern imaging pipeline.

---

## 📷 Key Architecture & Features

1. **Photographic Immediacy**: Instant boot-to-ready capture state with tactile exposure controls (Shutter Wheel, Aperture Ring, ISO Dial, Exposure Compensation, AF/MF Switch).
2. **Deterministic Capture Engine**: Strict operational state machine (`OFF` → `BOOTING` → `INITIALISING` → `READY` → `CAPTURING` → `PROCESSING` → `SAVING` → `READY` / `DEGRADED` / `ERROR` / `RECOVERY`).
3. **Fox Imaging Engine**: Demosaicing, tone-curve rendering, EXIF metadata generation, and versioned Picture Profiles (*Fox Natural*, *Fox Documentary*, *Fox Portrait*, *Fox Landscape*, *Fox Monochrome*, *Fox Cinema*).
4. **Hardware Abstraction Layer (HAL)**: Independent mock sensor, electronic lens mount, dual-slot storage, and power/thermal telemetry.
5. **Fox Engineering Console**: Internal developer diagnostic suite for sensor mode inspection, frame timing, CPU/thermal metrics, and fault injection (card write errors, thermal spikes).
6. **Photographer Profiles**: Exportable & versioned settings (*Fox Stills Pro*, *Street Documentarian*, *Landscape Master*).
7. **Firmware Service**: Cryptographically signed SHA-256 firmware packages with A/B recovery partition flashing.

---

## 🛠 Repository & Code Structure

```
fox-os/
├── app/src/main/java/com/example/
│   ├── MainActivity.kt               # Entry Point
│   ├── foxos/
│   │   ├── FoxOSApp.kt               # Main Navigation & Camera Model Switcher
│   │   ├── model/
│   │   │   ├── CameraProfile.kt      # Hardware Capability Manifests (Fox One, Fox Pro, Fox Compact)
│   │   │   ├── CameraState.kt        # State Machine Enums & Exposure/Focus Settings
│   │   │   ├── CapturedPhoto.kt      # EXIF Metadata & Media Storage Model
│   │   │   └── PhotographerProfile.kt # Exportable Photographer Profiles
│   │   ├── hal/
│   │   │   └── HardwareAbstractionLayer.kt # Sensor, Lens, Storage & Power HAL
│   │   ├── engine/
│   │   │   ├── CaptureEngine.kt      # State Machine Supervisor & Shutter Priority
│   │   │   ├── ExposureEngine.kt     # Light Metering & Real-time Histogram Calculator
│   │   │   └── ImagingEngine.kt      # RAW Demosaicing & JPEG Pipeline
│   │   ├── firmware/
│   │   │   └── FirmwareService.kt    # A/B Partition Flashing & Signature Check
│   │   └── ui/
│   │       ├── components/           # Telemetry Bar, Viewfinder, Physical Dials, Q-Menu
│   │       └── screens/              # Viewfinder, Gallery, Console, Settings, Manifest
│   └── ui/theme/                      # Precision British Camera Palette (Graphite & Brass)
└── app/src/test/java/com/example/
    └── FoxOSCapturePipelineTest.kt   # Automated Pipeline Unit Tests
```

---

## ⚙ Build & Run Instructions

```bash
# Compile the application
compile_applet

# Execute automated JVM / Robolectric unit tests
gradle :app:testDebugUnitTest
```

---

## 🇬🇧 Product Philosophy

- **British Engineering**: Precision, reliability, restrained design, and serviceability.
- **Optical Integrity**: Preserve original sensor data while providing intuitive photographer controls.
- **Immediate Response**: Zero menu friction between shutter press and frame capture.
