# Printara

**High-Fidelity Inkless / Tonerless Printer Simulator**  
Python 3.11+ · Linux · Research & Factory Optimisation

---

## Overview

Printara is a modular, physics-driven Python simulator for next-generation inkless printing technology.  
It models a Dyson-style consumer/industrial printer across six coupled simulation layers:

| Layer | Module | What it models |
|---|---|---|
| Printing / Deposition | `printing.py` | Heat-activated, electrostatic, and nanoparticle mechanisms; coverage maps; print fidelity metrics |
| Energy & Power | `energy.py` | Per-page power draw, energy accounting, CO₂ estimate, current draw |
| Thermal | `thermal.py` | PID-controlled head temperature (lumped-capacitance); 2-D paper surface heat map (finite-difference) |
| Materials & Mechanics | `materials.py` | Paper catalogue with coating effects; Paris-law roller wear; Arrhenius head-element failure |
| Safety & Reliability | `safety.py` | Real-time threshold monitoring; RUL / health scoring; maintenance predictor |
| Visualisation & Reports | `visualization.py` | 7-panel dark-mode dashboard; scenario comparison bar charts; JSON + CSV export |

Scenario runner (`scenarios.py`) and orchestration core (`core.py`) tie everything together.

---

## Quick Start

```bash
# Install dependencies
pip install numpy scipy matplotlib pandas

# Run a single 300-page baseline simulation
python -m printara.main --pages 300

# Run a specific scenario
python -m printara.main --scenario high_volume_factory

# Compare multiple scenarios
python -m printara.main --scenarios baseline cold_start tropical_humid nanoparticle_mechanism

# List all built-in scenarios
python -m printara.main --list-scenarios

# Change deposition mechanism and paper
python -m printara.main --mechanism electrostatic --paper glossy_coated_120gsm --pages 100

# Skip plots (headless / CI)
python -m printara.main --pages 200 --no-plots
```

All outputs land in `printara_output/` by default (override with `--output-dir`).

---

## Project Structure

```
printara/
├── __init__.py         # Public API surface
├── utils.py            # PrintaraConfig, logging, helpers
├── printing.py         # Deposition mechanics, fidelity metrics
├── energy.py           # Power draw, energy accounting
├── thermal.py          # Head PID model, 2-D paper heat map
├── materials.py        # Paper catalogue, roller wear, head lifecycle
├── scenarios.py        # Scenario definitions + runner
├── safety.py           # Fault detection, maintenance predictor
├── visualization.py    # Dashboard, comparison charts, JSON report
├── core.py             # SimulationCore — page-by-page orchestration
└── main.py             # CLI entry point
```

---

## Built-in Scenarios

| Scenario | Pages | Description |
|---|---|---|
| `baseline` | 50 | Standard office, default settings |
| `high_volume_factory` | 500 | Factory run, 32°C ambient |
| `cold_start` | 80 | 8°C cold room, 25 ppm warm-up |
| `tropical_humid` | 100 | 34°C / 88% RH — paper absorption stress |
| `premium_glossy` | 100 | Heavy-gloss 120 g/m² paper |
| `electrostatic_mechanism` | 100 | Electrostatic deposition |
| `nanoparticle_mechanism` | 100 | Nanoparticle jetting |
| `speed_ramp_high` | 200 | 100 ppm throughput stress |
| `speed_ramp_low` | 50 | 25 ppm — maximum quality mode |
| `wear_endurance` | 1 000 | Long-run reliability test |

---

## Deposition Mechanisms

### Heat-Activated (default)
Resistive printhead elements rapidly heat the paper surface above the chromogenic
activation threshold. Temperature is maintained by a proportional controller.
- Operating head temp: ~165–180 °C
- Energy: ~0.17–0.26 Wh/page (A4, 60 ppm)
- Quality driver: dwell time, paper activation threshold, humidity

### Electrostatic
Charge-patterning drum attracts nano-particles to the substrate.
- Operating temp: ~100 °C
- Energy: ~0.10 Wh/page
- Quality driver: field strength, particle mobility

### Nanoparticle
Precision jetting of functional droplets (2–3 pL).
- Operating temp: ~75 °C (no bulk heating)
- Energy: ~0.08 Wh/page (lowest)
- Quality driver: jetting frequency, droplet volume

---

## Physics Models

### Thermal
Lumped-capacitance model:

```
dT/dt = [P_in(t) - h·(T - T_amb)] / C_th
```

- `C_th` = thermal mass (J/K), configurable
- `h` = Newton cooling coefficient (W/K)
- `P_in` = setpoint-controller output, clamped to `peak_power_W`

2-D paper model: explicit finite-difference on a (depth × width) grid with
Neumann (flux) BC at the top surface and Dirichlet (ambient) at the bottom.

### Mechanical Wear (Paris Law)
```
da/dN = C · ΔK^m
wear_index += da_per_cycle · n · scale
```

Roller OD shrinks by 0.5% per unit wear index; diameter tolerance degrades
from ±2 µm (new) to ±8 µm (end-of-life), feeding directly into registration error.

### Head Element Failure (Arrhenius)
```
p_fail = base_rate · 2^((T_head - T_nominal) / 10)
failures ~ Binomial(surviving_elements, p_fail · Δcycles)
```

Failed elements appear as dead pixels; their fraction reduces print quality score.

### Print Fidelity
Metrics derived from comparison of ideal coverage map vs. simulated density map:

| Metric | Method |
|---|---|
| MTF50 (lp/mm) | 10→90% rise distance at step-edge strip |
| Dot gain (%) | Area comparison at 30% threshold |
| Dmax / Dmin | Max/2nd-percentile density |
| Uniformity CV (%) | Coefficient of variation in active regions |
| Quality score | Weighted composite 0–100 |

---

## Configuration

All parameters live in `PrintaraConfig` (a Python dataclass).  
Key fields:

```python
from printara import PrintaraConfig, SimulationCore

cfg = PrintaraConfig(
    printer_model          = "Printara DX-1",
    deposition_mechanism   = "heat_activated",   # heat_activated | electrostatic | nanoparticle
    dpi                    = 1200,
    page_width_mm          = 210.0,
    page_height_mm         = 297.0,
    print_speed_ppm        = 60.0,
    peak_power_W           = 1_800.0,
    max_safe_temp_C        = 220.0,
    thermal_mass_J_per_K   = 420.0,
    cooling_coeff_W_per_K  = 5.8,
    paper_type             = "standard_80gsm",   # see materials.PAPER_CATALOGUE
    env_humidity_pct       = 50.0,
    env_temperature_C      = 22.0,
    pages_per_batch        = 300,
    random_seed            = 42,
    output_dir             = "printara_output",
)

cfg.apply_seed()
core = SimulationCore(cfg)
core.run()
summary = core.full_summary()
```

Configs can be serialised to / loaded from JSON:
```python
cfg.save("my_config.json")
cfg2 = PrintaraConfig.load("my_config.json")
```

---

## Paper Catalogue

| Key | Name | GSM | Coating | Act. Temp |
|---|---|---|---|---|
| `standard_80gsm` | Standard 80 g/m² | 80 | none | 145°C |
| `premium_90gsm` | Premium 90 g/m² | 90 | none | 140°C |
| `glossy_coated_120gsm` | Glossy Coated 120 g/m² | 120 | heavy_gloss | 130°C |
| `matte_coated_100gsm` | Matte Coated 100 g/m² | 100 | matte | 140°C |
| `recycled_75gsm` | Recycled 75 g/m² | 75 | none | 152°C |

---

## Outputs

| File | Description |
|---|---|
| `dashboard_<ts>.png` | 7-panel engineering dashboard |
| `scenario_comparison_<ts>.png` | Cross-scenario bar charts |
| `report_<ts>.json` | Full structured summary |
| `scenarios_<ts>.csv` | Scenario comparison table |
| `config.json` | Saved run configuration |

---

## Programmatic API

```python
from printara import (
    PrintaraConfig, SimulationCore,
    ScenarioRunner, get_scenario,
    plot_run_dashboard, plot_scenario_comparison,
)

# Single run
cfg = PrintaraConfig(pages_per_batch=500)
core = SimulationCore(cfg)
core.run()
print(core.full_summary())
plot_run_dashboard(core)

# Scenario comparison
runner = ScenarioRunner(cfg)
runner.run_many(["baseline", "high_volume_factory", "nanoparticle_mechanism"])
plot_scenario_comparison(runner)

# Custom scenario
from printara.scenarios import ScenarioDefinition
custom = ScenarioDefinition(
    name="my_test",
    description="Humid recycled paper",
    pages=200,
    overrides={"paper_type": "recycled_75gsm", "env_humidity_pct": 75.0},
)
runner.run(custom)
```

---

## Dependencies

```
numpy>=1.26
scipy>=1.11
matplotlib>=3.8
pandas>=2.0         # optional (CSV export falls back to plain text)
```

---

## License
MIT
