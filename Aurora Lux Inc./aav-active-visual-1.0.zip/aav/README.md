# AAV — Active Visual

A **proposed, custom** interactive image format using the `.aav` extension: an image combined with
selectable regions, highlights, lighting effects, links, pixelation, annotations and controlled
animation.

An `.aav` file needs a compatible viewer. It is not an image file, and ordinary image viewers will
not show its interactive behaviour; each file carries a static `preview.png` for that case. The
format is not standardised and has no registered media type — see `docs/NAMING.md`, which also
records one existing, unrelated use of the `.aav` extension and a naming inconsistency you should
resolve before publishing.

| Part | Where | What |
|---|---|---|
| Format specification | `docs/SPEC.md` | Container, manifest, geometry, effects, state machine, links, redaction, limits, versioning |
| Naming and conflict check | `docs/NAMING.md` | Identifiers, what was checked and what was not |
| JSON Schema | `schema/aav-1.0.schema.json` | Generated from `schema/limits.json` and `schema/effect-specs.json` |
| Conformance vectors | `conformance/manifests.json` | 114 manifests with expected issue codes, run against both validators |
| Python package and CLI | `python/` | Validation, packaging, extraction, rendering, redaction, HTML export |
| Browser runtime | `web/src/core/` | TypeScript: validator, container, state machine, renderer (Canvas 2D + optional WebGL2) |
| Viewer | `web/src/viewer/`, `web/viewer.html` | Client-side viewer, embeddable class |
| Editor | `web/src/editor/`, `web/editor.html` | React editor |
| Examples | `examples/` | Three original documents and the script that draws and builds them |

## Quick start

Requirements: Python ≥ 3.10 and Node.js ≥ 22.12.

```bash
cd python
pip install -e ".[dev]"
```

```bash
cd web
npm ci
```

```bash
npm run build
```

`npm run build` type-checks, builds the single-file viewer bundle, copies it into the Python
package (for `aav export-html` and the browser render engine) and builds the static site in
`web/dist/`. A built `web/dist/` is included in this archive, so you can also serve it directly:

```bash
aav serve web/dist
```

then open <http://127.0.0.1:8137/> (viewer, editor and the three examples). For development with
hot reload:

```bash
npm run dev
```

Everything runs in the browser. There is no account, upload or backend; the "server" only hands
out static files.

## The core workflow

In the editor (`editor.html`):

1. **Import image** — PNG, JPEG or WebP are packaged as they are; other formats the browser can
   read are converted to PNG.
2. **Draw a region** — Rectangle or Polygon tool; reshape with the handles or the numeric fields.
3. **Assign a highlight** — *Add highlight* (outline + tint for hover, focus and selection) or
   *Add glow on hover*, or add any effect and tune its sliders per interaction state.
4. **Activate a panel** — create a panel in the *Panels* tab, then under *Triggers and actions →
   Activate* add *Open information panel*.
5. **Preview** — the real viewer runs on the document; what you do there is not saved unless you
   choose *Capture current preview state*.
6. **Save .aav** — writes a validated, deterministic file with a fresh static preview.
7. **Open .aav** — reopen it in the editor or viewer.
8. **Export PNG / Export HTML / Redacted copy…**

The same from Python is shown in `python/README.md`, and from the shell:

```bash
aav create image.png --output example.aav
```

```bash
aav validate example.aav
```

```bash
aav inspect example.aav
```

```bash
aav extract example.aav --output extracted/
```

```bash
aav render example.aav --output preview.png
```

```bash
aav pack extracted/ --output example.aav
```

Also: `aav redact FILE -o OUT --region ID` (permanent, verified), `aav export-html FILE -o page.html`,
`aav migrate FILE -o OUT`, `aav serve [DIR]`. `aav inspect` lists every link destination in a file.

## Examples

`python examples/build_examples.py --engine browser` draws the artwork procedurally and builds:

* **Illuminated Building** — ten windows that glow on hover/focus and open room panels; a polygon
  roof; an arched door hit-tested through a raster mask; a lamp that toggles an overlay layer; a
  light that follows the pointer on the forecourt; "all lights" buttons driving a region group and
  a bounded pulse animation.
* **Interactive Product** — camera components highlighted by outline, tint and brightness with
  multi-selection; annotation labels shown on activation; panels with documentation links; an
  external link and a link to another AAV document, both behind confirmation.
* **Pixel Art Playground** — stepped pixelation (block sizes 1/20/40/80), greyscale, vivid and dusk
  colour treatments, a short sun pulse and a reversible blur.

Rebuilding the examples twice gives byte-identical files.

## Rendering engines and portability

Static rendering (`aav render`, previews written on save) has two engines:

| Engine | Fidelity | Needs |
|---|---|---|
| `browser` | Full: the same TypeScript renderer the viewer uses, in headless Chromium | Node.js and a resolvable `playwright` package with a Chromium build; the embedded bundle in `python/src/aav/data/` |
| `basic` | **Layers only.** Image and text layers with visibility, opacity, placement, transforms and clips. Region effects are *not* applied. Text uses Pillow's built-in face (no bold), so glyphs differ from browsers | Pillow ≥ 10.1 |

`auto` (the default for `render`, `pack`, `redact` and `Document.save`) uses `browser` when the
document has region effects and the engine is available, and otherwise `basic`, printing a notice
if it had to fall back. `aav create` always uses `basic`, which is exact for a single image layer.
Set `AAV_NODE_MODULES` to a directory containing `node_modules/playwright` if Node cannot find it.

Text is drawn with the platform's generic `sans-serif`/`serif`/`monospace` fonts, so text layers do
not render identically across machines. Everything else in a render is deterministic for a given
browser build.

## Security model in brief

* The container is a restricted ZIP profile: no path traversal, duplicate (case-insensitive)
  names, encryption, ZIP64, prefixes, comments or overlapping entries; sizes bounded before and
  during decompression; image dimensions checked from headers before decoding.
* No scripts, no HTML, no external resources. Panel text is a small plain-text format rendered
  through text nodes.
* Only `https://` links, validated; they and document links can only run from an explicit
  activation, and the viewer shows the destination and asks first.
* The built pages ship a Content-Security-Policy (`default-src 'none'`, scripts from self only);
  the standalone HTML export allows exactly its one inline script by hash and no network at all.
* Reversible display effects are never called redaction; the separate permanent-redaction export
  is verified before it is written.

Details: `docs/SPEC.md` sections 3, 9–12.

## Tests and actual results

Run on 2026-11-24 with Python 3.13.18, Pillow 13.0.0, pytest 9.1.1, jsonschema 4.26.0, Node 22.23.5,
TypeScript 7.0.2, Vite 8.3.8, Vitest 5.1.1, React 19.3.1, Playwright 1.63.0 (headless Chromium).

| Check | Command | Result |
|---|---|---|
| Schema is up to date | `python tools/build_schema.py --check` | up to date |
| Python tests | `cd python && python -m pytest` | **349 passed**, 0 skipped |
| Type check | `cd web && npx tsc --noEmit` | no errors |
| TypeScript unit tests | `cd web && npm test` | **379 passed** (7 files) |
| Browser end-to-end tests | `cd web && npm run test:e2e` | **29 passed** |
| Example validation | `aav validate --strict examples/*.aav` | 3 valid, no warnings |

What they cover:

* **Archive validation and malformed files** — traversal, duplicates, zip bombs (ratio and
  lying sizes), oversized dimensions, encryption, bad methods, ZIP64, prefixes, comments,
  truncation, CRC, overlapping entries, non-UTF-8 names, tampered or mistyped assets, unsupported
  versions (both languages).
* **Validator agreement** — the 114 conformance vectors against the Python validator, the
  TypeScript validator and the JSON Schema (via `jsonschema` and Ajv).
* **Cross-implementation fidelity** — the Python-built examples load in TypeScript and re-save
  byte for byte; files saved by the browser editor pass `aav validate --strict`.
* **Coordinate transformations** — view round trips, zoom about a point, layer matrices (same
  numbers in both languages), high-DPI and zoomed hit testing in a real browser.
* **Overlapping hit targets** — z-order, array order, half-open edges, non-interactive regions,
  mask alpha, Alt+click stepping.
* **Effect ordering** — fixed pipeline order with cases where the order is observable; each
  formula; pixelation grid stability; WebGL2 against the CPU reference (max difference ≤ 2/255).
* **Keyboard, touch and reduced motion** — Tab/Enter/Space/Escape, focus movement and return,
  roving list, tap-as-hover-plus-activate, reduced-motion behaviour.
* **Save/load fidelity** — Python and editor round trips, deterministic output, undo/redo.
* **Unsafe links** — the same vector list in both languages, validator rejection, confirmation
  dialog behaviour, no cross-origin requests on open.
* **Redaction exports** — pixels, metadata, hidden layers, unused assets, transformed layers, masks,
  stale previews, and that verification catches tampering (Python and browser).
* **Standalone HTML** — opens from `file://` with no network requests and no CSP violations; still
  shows the preview and region names with JavaScript disabled.

Four bugs were found by these tests while building and fixed: a spurious "outside the document"
warning when the canvas size was itself invalid; a mismatch between the two validators' handling
of explicit `null`; the viewer pulling keyboard focus back to a newly opened panel after the user
had already moved on; and the editor canvas shifting by a few pixels when a tool was chosen
(a longer hint line wrapped and resized it). The last showed up as an intermittent failure in a
from-scratch run of the packaged archive, after which the whole browser suite was run five times
over (145 of 145 passed).

The archive was verified by extracting it into an empty directory and running the installation,
build and every suite above from there; the examples rebuilt there are byte-identical to the
shipped ones.

## Dependency compatibility

Versions were taken from the npm registry and checked against the projects' own documentation or
package metadata on 2026-11-24:

* Vite 8 requires Node `^20.19.0 || >=22.12.0`; Vitest 5 requires Node `^22.12.0 || ^24.0.0 || >=26.0.0`
  and accepts Vite 6.4, 7 or 8; `@vitejs/plugin-react` 6 requires Vite 8. Hence Node ≥ 22.12.
* React 19 does not bundle its types: `@types/react` and `@types/react-dom` are dev dependencies.
* Pillow's `ImageFont.load_default(size=…)` (used by the basic engine) exists since Pillow 10.1.
* `@playwright/test` is pinned to 1.63.0 because that matches the Chromium build installed where
  this was developed. On another machine either run `npx playwright install chromium` or change
  the pin to a version whose browser you have.
* TypeScript 7 and Vite 8 are recent majors; this project was only built and tested with the
  versions in `web/package-lock.json`.

## What is not supported or not verified

Format-level omissions are listed in `docs/SPEC.md` section 16. About this implementation:

* **Browsers.** Tested only in headless Chromium. Firefox and Safari were not tested. WebGL2 was
  exercised only through Chromium's software renderer.
* **Assistive technology.** Roles, names, focus order and live announcements are tested
  structurally. No testing with an actual screen reader was done.
* **Pinch zoom** is implemented but has no automated test.
* **Performance.** Effects run at document resolution, mostly on the CPU. No benchmarking or
  tuning was done; full-canvas blur or pixelation on very large documents will be slow.
* **Python `basic` engine** does not apply region effects (see above).
* **Mask outlines** are approximate (derived by dilation).
* **Browser redaction** re-encodes through a canvas; RGB values of semi-transparent pixels in
  overlay assets can shift slightly in that round trip. The Python redaction has an extra
  rendered-layer cross-check that the browser version does not.
* **Duplicate JSON keys** are rejected by Python but not detectable in the browser.
* **Byte-identical output across the two writers** is tested on the examples, not guaranteed for
  every possible non-integer number.
* **Editor scope.** No multi-select of regions, copy/paste, snapping or guides; layer transforms
  are numeric only; effect ids are fixed when created; history is in memory only (no autosave).
* **Thumbnails** are lossless WebP from Python (when Pillow has WebP) and PNG from the editor.
* **Naming.** The IANA registry could not be read directly; see `docs/NAMING.md`.
* **Licence.** None has been chosen for this code. The example documents' metadata declares
  CC0-1.0 for their generated artwork; change that if it is not what you intend.

## Repository layout

```
conformance/manifests.json     shared validator test vectors
docs/SPEC.md, docs/NAMING.md   specification, naming and conflict check
examples/                      build_examples.py and the three .aav files
python/src/aav/                library and CLI; data/ holds schema, limits and the embedded viewer
python/tests/                  pytest suite
schema/                        limits.json, effect-specs.json (sources) and the generated JSON Schema
tools/build_schema.py          regenerates the schema and syncs the shared data files
web/src/core/                  format runtime (no DOM except renderer.ts, webgl.ts, redact.ts)
web/src/viewer/                viewer component and page
web/src/editor/                React editor
web/tests/                     Vitest unit tests
web/e2e/                       Playwright tests (run against the production build)
web/dist/                      prebuilt static site
```

`schema/limits.json` and `schema/effect-specs.json` are the single source for every limit and
effect parameter. After editing them, run `python tools/build_schema.py` to regenerate the schema
and the copies used by the Python package and the web code; both test suites check the copies match.
