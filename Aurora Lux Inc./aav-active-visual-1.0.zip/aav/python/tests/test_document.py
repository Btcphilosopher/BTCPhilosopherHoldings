"""Authoring API, save/load fidelity, CLI commands, rendering and migration."""
from __future__ import annotations

import io
import json
import shutil

import pytest
from PIL import Image

from aav import AavError, Document, migrate, read_archive, read_zip, write_zip
from aav.cli import main as cli
from aav.geometry import apply, image_matrix, invert, layer_transform, multiply
from aav.render import find_render_tools, render_basic, render_png

from conftest import CONFORMANCE, ROOT, gradient_png, png_bytes


def test_save_load_fidelity(sample_doc, tmp_path):
    before = json.loads(json.dumps(sample_doc.manifest))
    sample_doc.save(tmp_path / "doc.aav", engine="basic")
    loaded = Document.open(tmp_path / "doc.aav")
    after = loaded.manifest
    for key in ("document", "layers", "regions", "panels", "metadata"):
        assert after[key] == before[key], key
    asset = after["assets"]["base"]
    assert (asset["width"], asset["height"]) == (320, 200) and len(asset["sha256"]) == 64
    assert loaded.files[asset["path"]] == gradient_png(320, 200), "asset bytes are stored untouched"
    assert after["thumbnail"] in loaded.files and "preview.png" in loaded.files


def test_conformance_base_survives_a_round_trip(tmp_path):
    doc = Document(json.loads(json.dumps(CONFORMANCE["base"])))
    doc.manifest["assets"]["base"].pop("sha256")
    doc.files = {"assets/base.png": png_bytes(800, 600), "assets/overlay.webp": _webp(200, 100),
                 "masks/window.png": png_bytes(64, 64, (255, 255, 255, 128))}
    doc.save(tmp_path / "base.aav", engine="basic")
    loaded = Document.open(tmp_path / "base.aav").manifest
    expected = json.loads(json.dumps(CONFORMANCE["base"]))
    for manifest in (loaded, expected):
        for asset in manifest["assets"].values():
            for key in ("sha256", "width", "height"):
                asset.pop(key, None)
    assert loaded == expected


def _webp(width: int, height: int) -> bytes:
    out = io.BytesIO()
    Image.new("RGBA", (width, height), (200, 40, 40, 200)).save(out, "WEBP", lossless=True)
    return out.getvalue()


def test_invalid_documents_cannot_be_saved(sample_doc, tmp_path):
    sample_doc.region("window")["events"]["activate"][0]["panel"] = "missing"
    with pytest.raises(AavError) as exc:
        sample_doc.save(tmp_path / "bad.aav", engine="basic")
    assert {i.code for i in exc.value.issues} == {"E_REF"}
    assert not (tmp_path / "bad.aav").exists()


def test_create_rejects_non_images_and_oversize(tmp_path):
    with pytest.raises(AavError):
        Document.create(b"not an image")
    big = bytearray(png_bytes(2, 2))
    big[16:24] = (9000).to_bytes(4, "big") + (9000).to_bytes(4, "big")
    with pytest.raises(AavError):
        Document.create(bytes(big))


def test_layer_matrix_and_inverse_agree():
    layer = {"id": "l", "type": "image", "asset": "a", "x": 100, "y": 50, "width": 200, "height": 100,
             "transform": {"translate_x": 10, "translate_y": -5, "scale_x": 1.5, "scale_y": 0.5, "rotation": 90,
                           "origin_x": 100, "origin_y": 50}}
    m = image_matrix(layer, 20, 10, 800, 600)
    # Asset origin maps to the layer origin (which is the transform origin), then moves by the translation.
    assert apply(m, 0, 0) == pytest.approx((110, 45))
    # One asset pixel along +x is 10 document px, scaled 1.5 and rotated a quarter turn clockwise: +15 in y.
    assert apply(m, 1, 0) == pytest.approx((110, 60))
    assert apply(m, 0, 1) == pytest.approx((105, 45))
    x, y = apply(multiply(invert(m), m), 7.25, -3.5)
    assert (x, y) == pytest.approx((7.25, -3.5))
    assert layer_transform({"id": "l", "type": "image", "asset": "a"}, 800, 600) == (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def test_basic_render_matches_layers(tmp_path):
    doc = Document.new(40, 20, title="Render")
    doc.add_asset("red", png_bytes(10, 10, (255, 0, 0, 255)))
    doc.add_asset("blue", png_bytes(4, 4, (0, 0, 255, 255)))
    doc.manifest["document"]["background"] = "#00FF00"
    doc.add_image_layer("a", "red", x=0, y=0, width=20, height=20)
    doc.add_image_layer("b", "blue", x=20, y=0, width=20, height=20, opacity=0.5)
    doc.add_image_layer("hidden", "blue", visible=False)
    doc.add_image_layer("clipped", "blue", x=0, y=0, width=40, height=20, clip={"x": 0, "y": 15, "width": 5, "height": 5})
    image = render_basic(doc.package())
    assert image.getpixel((5, 5)) == (255, 0, 0, 255)
    r, g, b, a = image.getpixel((30, 10))
    assert a == 255 and abs(g - 127) <= 2 and abs(b - 128) <= 2 and r == 0  # half blue over green
    assert image.getpixel((2, 17)) == (0, 0, 255, 255) and image.getpixel((10, 17)) == (255, 0, 0, 255)


def test_text_layer_renders_and_reports_engine(tmp_path):
    doc = Document.new(200, 60, title="Text")
    doc.manifest["document"]["background"] = "#000000"
    doc.add_text_layer("t", "Hello", 100, 10, font_size=30, align="centre", colour="#FFFFFF")
    data, used = render_png(doc.package(), "basic")
    image = Image.open(io.BytesIO(data)).convert("L")
    assert used == "basic" and image.getbbox() is not None and image.getpixel((2, 2)) == 0


@pytest.mark.skipif(find_render_tools() is None, reason="browser engine needs Node.js and the embedded viewer bundle")
def test_browser_engine_applies_effects(tmp_path):
    doc = Document.create(png_bytes(64, 64, (100, 100, 100, 255)), title="Fx")
    doc.add_region("r", "Bright", Document.rect(0, 0, 32, 64), target_layer="background",
                   effects={"b": {"type": "brightness", "amount": 2}})
    browser, used = render_png(doc.package(), "browser")
    image = Image.open(io.BytesIO(browser)).convert("RGBA")
    assert used == "browser" and image.size == (64, 64)
    assert image.getpixel((10, 30))[:3] == (200, 200, 200), "inside the region the layer is twice as bright"
    assert image.getpixel((50, 30))[:3] == (100, 100, 100), "outside it is untouched"
    basic = Image.open(io.BytesIO(render_png(doc.package(), "basic")[0])).convert("RGBA")
    assert basic.getpixel((10, 30))[:3] == (100, 100, 100), "the basic engine documents that it skips effects"


def test_cli_workflow(tmp_path, capsys):
    image = tmp_path / "photo.png"
    image.write_bytes(gradient_png(120, 80))
    out = tmp_path / "example.aav"
    assert cli(["create", str(image), "--output", str(out), "--title", "CLI demo"]) == 0
    assert cli(["validate", "--strict", str(out)]) == 0
    assert "valid" in capsys.readouterr().out
    assert cli(["inspect", str(out)]) == 0
    text = capsys.readouterr().out
    assert "CLI demo" in text and "120 x 80" in text and "assets/base.png" in text
    assert cli(["inspect", "--json", str(out)]) == 0
    assert json.loads(capsys.readouterr().out)["document"]["title"] == "CLI demo"

    extracted = tmp_path / "extracted"
    assert cli(["extract", str(out), "--output", str(extracted)]) == 0
    assert (extracted / "manifest.json").is_file() and (extracted / "assets" / "base.png").is_file()
    assert cli(["extract", str(out), "--output", str(extracted)]) == 2, "refuses to overwrite without --force"

    # Edit the extracted manifest by hand, then pack it again.
    manifest = json.loads((extracted / "manifest.json").read_text())
    manifest["regions"] = [{"id": "r", "label": "Region", "shape": {"type": "rect", "x": 5, "y": 5, "width": 30, "height": 20}}]
    (extracted / "manifest.json").write_text(json.dumps(manifest))
    packed = tmp_path / "packed.aav"
    assert cli(["pack", str(extracted), "--output", str(packed), "--engine", "basic"]) == 0
    assert Document.open(packed).manifest["regions"][0]["id"] == "r"
    assert cli(["pack", str(extracted), "--output", str(tmp_path / "again.aav"), "--engine", "basic"]) == 0
    assert packed.read_bytes() == (tmp_path / "again.aav").read_bytes(), "packing is deterministic"

    png = tmp_path / "preview.png"
    assert cli(["render", str(packed), "--output", str(png), "--engine", "basic"]) == 0
    assert Image.open(png).size == (120, 80)
    capsys.readouterr()


def test_cli_reports_invalid_files(tmp_path, capsys):
    bad = tmp_path / "bad.aav"
    bad.write_bytes(b"PK\x03\x04 nonsense")
    assert cli(["validate", str(bad)]) == 1
    assert "INVALID" in capsys.readouterr().out
    assert cli(["inspect", str(bad)]) == 1
    assert cli(["validate", str(tmp_path / "missing.aav")]) == 2
    capsys.readouterr()


def test_pack_refuses_symlinks_and_unreferenced_files(tmp_path, sample_doc, capsys):
    sample_doc.save(tmp_path / "d.aav", engine="basic")
    root = tmp_path / "dir"
    assert cli(["extract", str(tmp_path / "d.aav"), "--output", str(root)]) == 0
    (root / "assets" / "stray.png").write_bytes(png_bytes(2, 2))
    assert cli(["pack", str(root), "--output", str(tmp_path / "o.aav"), "--engine", "basic"]) == 1
    assert cli(["pack", str(root), "--output", str(tmp_path / "o.aav"), "--engine", "basic", "--allow-extra-files"]) == 0
    (root / "assets" / "link.png").symlink_to(root / "assets" / "stray.png")
    assert cli(["pack", str(root), "--output", str(tmp_path / "o2.aav"), "--engine", "basic"]) == 1
    capsys.readouterr()


def test_migration_from_the_pre_release_draft(tmp_path, sample_doc, capsys):
    data = sample_doc.save(tmp_path / "new.aav", engine="basic")
    files = read_zip(data)
    manifest = json.loads(files["manifest.json"])
    manifest["version"] = "0.9"
    manifest["hotspots"] = manifest.pop("regions")
    manifest["document"]["size"] = [manifest["document"].pop("width"), manifest["document"].pop("height")]
    manifest["hotspots"][0]["effects"]["glow"]["color"] = manifest["hotspots"][0]["effects"]["glow"].pop("colour")
    files["manifest.json"] = json.dumps(manifest).encode()
    old = tmp_path / "old.aav"
    old.write_bytes(write_zip(files))
    with pytest.raises(AavError) as exc:
        read_archive(old)
    assert {i.code for i in exc.value.issues} == {"E_VERSION"} and "migrate" in str(exc.value)
    migrated, steps = migrate(manifest)
    assert steps == ["0.9 -> 1.0"] and migrated["regions"][0]["effects"]["glow"]["colour"] == "#FFD47A"
    assert cli(["migrate", str(old), "--output", str(tmp_path / "migrated.aav")]) == 0
    assert Document.open(tmp_path / "migrated.aav").manifest["document"]["width"] == 320
    with pytest.raises(AavError):
        migrate({"format": "aureom-active-visual", "version": "7.3"})
    capsys.readouterr()


def test_examples_are_valid_and_reproducible():
    examples = sorted((ROOT / "examples").glob("*.aav"))
    assert [p.name for p in examples] == ["illuminated-building.aav", "interactive-product.aav",
                                          "pixel-art-playground.aav"]
    for path in examples:
        package, warnings = read_archive(path, strict=True)
        assert not warnings, path.name
        assert package.manifest["document"]["description"], "every example has an accessible description"
        assert all(r["label"] for r in package.manifest["regions"])
        assert path.read_bytes() == (ROOT / "web" / "public" / "examples" / path.name).read_bytes()


@pytest.mark.skipif(shutil.which("node") is None or find_render_tools() is None, reason="needs the embedded viewer bundle")
def test_html_export_is_self_contained(tmp_path, sample_doc, capsys):
    sample_doc.save(tmp_path / "d.aav", engine="basic")
    out = tmp_path / "page.html"
    assert cli(["export-html", str(tmp_path / "d.aav"), "--output", str(out)]) == 0
    html = out.read_text("utf-8")
    assert "default-src 'none'" in html and "script-src 'sha256-" in html
    assert 'id="aav-data"' in html and "data:image/png;base64," in html
    assert "http://" not in html.split("<script>")[0], "no external resources are referenced"
    assert "<li>Window</li>" in html, "region names are present for readers without JavaScript"
    capsys.readouterr()
