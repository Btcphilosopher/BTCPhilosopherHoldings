"""Permanent redaction: the output must not contain recoverable copies of the redacted pixels."""
from __future__ import annotations

import io

import pytest
from PIL import Image, ImageChops, PngImagePlugin

from aav import AavError, Document, Package, read_archive, read_zip, redact, sha256_hex, verify_redaction, write_archive
from aav.cli import main as cli


SECRET = (250, 10, 200)


def background(width: int, height: int) -> Image.Image:
    """A varied background whose blue channel never exceeds 99, so it cannot resemble SECRET (blue 200)."""
    image = Image.new("RGB", (width, height))
    image.putdata([((x * 255) // (width - 1), (y * 255) // (height - 1), (x * 7 + y * 13) % 100)
                   for y in range(height) for x in range(width)])
    return image


def secret_image(width=200, height=120, box=(60, 30, 140, 80)) -> bytes:
    """The background with a distinctive block of colour that must not survive redaction."""
    image = background(width, height)
    image.paste(SECRET, box)
    info = PngImagePlugin.PngInfo()
    info.add_text("Comment", "the code is 4711")  # metadata that must be stripped too
    out = io.BytesIO()
    image.save(out, "PNG", pnginfo=info)
    return out.getvalue()


def contains_secret(png: bytes) -> bool:
    """True if any pixel has the secret's signature: high blue with low green. Neither the background
    (blue <= 99) nor white or black fills match it."""
    image = Image.open(io.BytesIO(png)).convert("RGB")
    high_blue = image.getchannel("B").point(lambda v: 255 if v > 150 else 0)
    low_green = image.getchannel("G").point(lambda v: 255 if v < 60 else 0)
    return ImageChops.multiply(high_blue, low_green).getbbox() is not None


def test_the_detector_itself_is_sound():
    out = io.BytesIO()
    background(200, 120).save(out, "PNG")
    assert not contains_secret(out.getvalue()), "the plain background must not trigger the detector"
    for flat in ((255, 255, 255), (0, 0, 0), (16, 32, 48)):
        out = io.BytesIO()
        Image.new("RGB", (8, 8), flat).save(out, "PNG")
        assert not contains_secret(out.getvalue()), f"a flat {flat} fill must not trigger the detector"
    assert contains_secret(secret_image())


@pytest.fixture
def secret_doc():
    doc = Document.create(secret_image(), title="Secret")
    doc.add_region("secret", "Sensitive area", Document.rect(60, 30, 80, 50), target_layer="background",
                   effects={"hide": {"type": "pixelate", "block_size": 16}})
    doc.add_region("other", "Other", Document.rect(0, 0, 20, 20))
    return doc


def test_display_pixelation_is_not_redaction(secret_doc, tmp_path):
    """The reversible effect leaves the original in the archive: this is exactly why it is not called redaction."""
    data = secret_doc.save(tmp_path / "pixelated.aav", engine="basic")
    files = read_zip(data)
    assert contains_secret(files["assets/base.png"])
    assert b"4711" in files["assets/base.png"]


def test_redaction_removes_pixels_metadata_and_previews(secret_doc, tmp_path):
    secret_doc.save(tmp_path / "in.aav", engine="basic")
    original, _ = read_archive(tmp_path / "in.aav")
    result = redact(original, ["secret"], engine="basic")
    data = write_archive(result, tmp_path / "out.aav", strict=True)

    assert b"4711" not in data, "text metadata from the original asset must not survive"
    for name, payload in result.files.items():
        assert not contains_secret(payload), f"{name} still shows the redacted content"
    image = Image.open(io.BytesIO(result.files["assets/base.png"])).convert("RGBA")
    assert all(image.getpixel((x, y)) == (0, 0, 0, 255) for x in range(60, 140, 7) for y in range(30, 80, 7))
    assert image.getpixel((10, 100))[:3] == background(200, 120).getpixel((10, 100)), "pixels outside are untouched"
    assert result.manifest["redaction"] == {"method": "fill", "colour": "#000000", "regions": ["secret"],
                                            "tool": result.manifest["redaction"]["tool"]}
    original_hashes = {sha256_hex(v) for v in original.files.values()}
    assert not original_hashes & {sha256_hex(v) for v in result.files.values()}
    assert verify_redaction(original, result) == []
    reopened, warnings = read_archive(tmp_path / "out.aav", strict=True)
    assert not warnings and reopened.manifest["regions"][0]["id"] == "secret"


def test_redaction_covers_every_layer_hidden_layers_and_unused_assets(tmp_path):
    doc = Document.create(secret_image(), title="Layers")
    doc.add_asset("copy", secret_image())                       # hidden duplicate of the original
    doc.add_image_layer("hidden-original", "copy", visible=False)
    doc.add_asset("orphan", secret_image(), filename="orphan.png")   # packaged but used by nothing
    doc.files["assets/forgotten.png"] = secret_image()          # not even in the manifest
    doc.add_region("secret", "Sensitive", Document.rect(60, 30, 80, 50))
    doc.finalise(engine="basic")
    package = Package(doc.manifest, doc.files)
    result = redact(package, ["secret"], engine="basic")
    assert sorted(result.manifest["assets"]) == ["base", "copy"]
    assert sorted(result.files) == ["assets/base.png", "assets/copy.png", "preview.png", result.manifest["thumbnail"]]
    assert not any(contains_secret(v) for v in result.files.values())


def test_redaction_follows_layer_placement_and_transform(tmp_path):
    # The asset is shown at half size, offset and rotated; the region is drawn where the secret appears.
    doc = Document.new(300, 300, title="Transformed")
    doc.add_asset("img", secret_image(200, 120, (60, 30, 140, 80)))
    doc.add_image_layer("photo", "img", x=50, y=100, width=100, height=60,
                        transform={"rotation": 90, "origin_x": 50, "origin_y": 100})
    # Asset box (60..140, 30..80) -> layer box (80..120, 115..140) -> rotated 90 deg clockwise about (50, 100).
    doc.add_region("secret", "Sensitive", Document.rect(8, 128, 30, 44))
    doc.finalise(engine="basic")
    result = redact(doc.package(), ["secret"], engine="basic")
    assert not contains_secret(result.files["assets/img.png"])
    assert verify_redaction(doc.package(), result) == []


def test_mask_regions_and_mask_only_assets(tmp_path):
    doc = Document.create(secret_image(), title="Mask")
    # A mask whose colour channels smuggle the original picture: only its alpha may survive.
    mask = Image.open(io.BytesIO(secret_image())).convert("RGBA").crop((60, 30, 140, 80))
    mask.putalpha(Image.new("L", mask.size, 255))
    out = io.BytesIO()
    mask.save(out, "PNG")
    doc.add_asset("m", out.getvalue(), folder="masks")
    doc.add_region("secret", "Sensitive", Document.mask("m", x=60, y=30, width=80, height=50))
    doc.finalise(engine="basic")
    result = redact(doc.package(), ["secret"], colour="#102030", engine="basic")
    assert not any(contains_secret(v) for v in result.files.values())
    cleaned = Image.open(io.BytesIO(result.files["masks/m.png"])).convert("RGBA")
    assert cleaned.getcolors() == [(80 * 50, (255, 255, 255, 255))], "the mask keeps its alpha and nothing else"
    assert Image.open(io.BytesIO(result.files["assets/base.png"])).convert("RGB").getpixel((100, 55)) == (16, 32, 48)


def test_verification_detects_tampering(secret_doc, tmp_path):
    secret_doc.finalise(engine="basic")
    original = secret_doc.package()
    good = redact(original, ["secret"], engine="basic")

    leaked = good.copy()
    leaked.files["assets/extra.png"] = original.files["assets/base.png"]
    assert any(i.code in ("E_UNREFERENCED", "E_REDACTION") for i in verify_redaction(original, leaked))

    restored = good.copy()
    restored.files["assets/base.png"] = original.files["assets/base.png"]
    restored.manifest["assets"]["base"]["sha256"] = sha256_hex(original.files["assets/base.png"])
    problems = verify_redaction(original, restored)
    assert any("differ from the fill colour" in i.message for i in problems)
    assert any("byte-identical" in i.message for i in problems)

    stale_preview = good.copy()
    stale_preview.files["preview.png"] = original.files["preview.png"]
    assert any("byte-identical" in i.message for i in verify_redaction(original, stale_preview))

    no_record = good.copy()
    del no_record.manifest["redaction"]
    assert verify_redaction(original, no_record)


def test_redaction_rejects_unknown_regions_and_empty_lists(secret_doc):
    secret_doc.finalise(engine="basic")
    with pytest.raises(AavError):
        redact(secret_doc.package(), ["nope"], engine="basic")
    with pytest.raises(AavError):
        redact(secret_doc.package(), [], engine="basic")


def test_redact_cli(secret_doc, tmp_path, capsys):
    secret_doc.save(tmp_path / "in.aav", engine="basic")
    assert cli(["redact", str(tmp_path / "in.aav"), "--output", str(tmp_path / "out.aav"), "--region", "secret",
                "--engine", "basic"]) == 0
    assert "verification passed" in capsys.readouterr().out
    assert cli(["validate", "--strict", str(tmp_path / "out.aav")]) == 0
    assert not contains_secret(read_zip((tmp_path / "out.aav").read_bytes())["preview.png"])
    assert (tmp_path / "in.aav").exists(), "the source file is never modified"
    capsys.readouterr()
