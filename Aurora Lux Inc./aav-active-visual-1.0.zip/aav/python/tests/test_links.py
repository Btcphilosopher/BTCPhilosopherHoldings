"""Link safety and the restricted text grammar."""
from __future__ import annotations

import pytest

from aav.links import document_href_problem, external_url_problem, text_links

SAFE = ["https://example.org", "https://example.org/", "https://sub.example.org:8443/a/b?c=d&e=f#g",
        "https://example.org/%E2%9C%93", "https://xn--bcher-kva.example/"]
UNSAFE = ["http://example.org/", "HTTPS://example.org/", "javascript:alert(1)", "JaVaScRiPt:alert(1)",
          "data:text/html,<script>alert(1)</script>", "file:///etc/passwd", "ftp://example.org/x", "blob:https://x/y",
          "vbscript:msgbox(1)", "//example.org/", "/relative", "example.org", "", " https://example.org/",
          "https://example.org/a b", "https://example.org/\n", "https://example.org/\t", "https://",
          "https:///path", "https://user@example.org/", "https://user:pw@example.org/",
          "https://example.org\\@evil.example/", "https://example.org@evil.example/", "https://[::1]/",
          "https://exa mple.org/", "https://example.org:99999/", "https://.example.org/", "https://a..b/",
          "https://example.org/" + "a" * 3000, 42, None, ["https://example.org/"]]


@pytest.mark.parametrize("url", SAFE)
def test_safe_urls(url):
    assert external_url_problem(url) is None


@pytest.mark.parametrize("url", UNSAFE, ids=[repr(u)[:40] for u in UNSAFE])
def test_unsafe_urls(url):
    assert external_url_problem(url) is not None


@pytest.mark.parametrize("href,ok", [
    ("other.aav", True), ("rooms/first-floor.aav", True), ("https://example.org/a.aav", True),
    ("../other.aav", False), ("rooms/../other.aav", False), ("/abs.aav", False), ("./x.aav", False),
    ("file:///x.aav", False), ("javascript:x.aav", False), ("other.html", False), ("other.aav?x=1", False),
    ("a\\b.aav", False), ("http://example.org/a.aav", False), ("", False), ("a b.aav", False), ("x//y.aav", False),
])
def test_document_links(href, ok):
    assert (document_href_problem(href) is None) == ok


def test_text_links_are_found_and_escapes_respected():
    text = r"See [docs](https://example.org/a) and [room](#region:r1), not \[this](javascript:x) or `[code](https://x.example/)`."
    assert text_links(text) == [("docs", "https://example.org/a"), ("room", "#region:r1")]
    assert text_links("<a href='javascript:alert(1)'>x</a>") == [], "HTML is never parsed as a link"
