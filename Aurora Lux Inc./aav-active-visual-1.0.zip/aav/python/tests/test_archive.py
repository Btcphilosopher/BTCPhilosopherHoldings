"""Container safety: every malformed or hostile archive must be rejected with a specific code."""
from __future__ import annotations

import io
import json
import struct
import zipfile
import zlib

import pytest

from aav import AavError, Document, read_archive, read_zip, sha256_hex, sniff_image, write_zip
from aav.archive import entry_path_problem, load_unvalidated
from aav.limits import LIMITS

from conftest import gradient_png, png_bytes


def codes(excinfo) -> set[str]:
    return {i.code for i in excinfo.value.issues}


def raw_zip(entries: list[tuple[str | bytes, bytes]], *, method: int = 0, flags: int = 0x0800, comment: bytes = b"",
            prefix: bytes = b"", lie_usize: int | None = None, central_name: bytes | None = None) -> bytes:
    """Hand-build a ZIP so tests can violate the profile in ways zipfile refuses to."""
    body, central = bytearray(prefix), bytearray()
    for name, payload in entries:
        raw_name = name.encode("utf-8") if isinstance(name, str) else name
        data = payload
        if method == 8:
            comp = zlib.compressobj(9, zlib.DEFLATED, -15)
            data = comp.compress(payload) + comp.flush()
        usize = len(payload) if lie_usize is None else lie_usize
        header = struct.pack("<HHHHHIIIHH", 20, flags, method, 0, 0x21, zlib.crc32(payload) & 0xFFFFFFFF, len(data), usize,
                             len(raw_name), 0)
        offset = len(body)
        body += b"PK\x03\x04" + header + raw_name + data
        cname = central_name or raw_name
        cheader = struct.pack("<HHHHHIIIHH", 20, flags, method, 0, 0x21, zlib.crc32(payload) & 0xFFFFFFFF, len(data),
                              usize, len(cname), 0)
        central += b"PK\x01\x02" + struct.pack("<H", 20) + cheader + struct.pack("<HHHII", 0, 0, 0, 0, offset) + cname
    eocd = b"PK\x05\x06" + struct.pack("<HHHHIIH", 0, 0, len(entries), len(entries), len(central), len(body),
                                       len(comment)) + comment
    return bytes(body + central + eocd)


@pytest.fixture
def good(sample_doc, tmp_path) -> bytes:
    return sample_doc.save(tmp_path / "good.aav", engine="basic")


def test_round_trip_and_determinism(sample_doc, tmp_path):
    first = sample_doc.save(tmp_path / "a.aav", engine="basic")
    again = Document.open(tmp_path / "a.aav").save(tmp_path / "b.aav", engine="basic", keep_preview=True)
    assert first == again, "saving an unchanged document must be byte-identical"
    files = read_zip(first)
    assert list(files)[:2] == ["manifest.json", "preview.png"], "manifest and preview come first"
    assert list(files)[2:] == sorted(list(files)[2:])
    with zipfile.ZipFile(io.BytesIO(first)) as zf:  # ordinary ZIP tools can read it
        assert zf.testzip() is None
        assert all(i.date_time == (1980, 1, 1, 0, 0, 0) and i.compress_type == 0 for i in zf.infolist())


def test_reads_deflated_archives_from_other_tools(good):
    buf = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(good)) as src, zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            dst.writestr(info.filename, src.read(info))
    package, _ = read_archive(buf.getvalue())
    assert package.manifest["document"]["title"] == "Sample"


@pytest.mark.parametrize("name", ["../evil.png", "assets/../../evil.png", "/etc/passwd", "assets\\evil.png",
                                  "C:/evil.png", "assets//x.png", "./manifest.json", "assets/./x.png", "a\x00b",
                                  "assets/x\n.png", "", "e\u0301.png"])
def test_unsafe_entry_names_are_rejected(name):
    assert entry_path_problem(name) is not None
    if name:
        with pytest.raises(AavError) as exc:
            read_zip(raw_zip([("manifest.json", b"{}"), (name, b"x")]))
        assert codes(exc) == {"E_ARCHIVE_PATH"}


def test_safe_entry_names_are_accepted():
    for name in ("manifest.json", "assets/base.webp", "masks/window.png", "thumbnails/preview.webp", "assets/é.png"):
        assert entry_path_problem(name) is None


def test_non_utf8_name_is_rejected():
    with pytest.raises(AavError) as exc:
        read_zip(raw_zip([(b"\xff\xfe.png", b"x")]))
    assert codes(exc) == {"E_ARCHIVE_PATH"}
    with pytest.raises(AavError) as exc:  # non-ASCII without the UTF-8 flag
        read_zip(raw_zip([("é.png", b"x")], flags=0))
    assert codes(exc) == {"E_ARCHIVE_PATH"}


@pytest.mark.parametrize("names", [("assets/a.png", "assets/a.png"), ("assets/a.png", "assets/A.PNG"),
                                   ("manifest.json", "MANIFEST.JSON")])
def test_duplicate_paths_are_rejected(names):
    with pytest.raises(AavError) as exc:
        read_zip(raw_zip([(n, b"x") for n in names]))
    assert codes(exc) == {"E_ARCHIVE_DUPLICATE"}


def test_zip_bomb_by_ratio_is_rejected():
    with pytest.raises(AavError) as exc:
        read_zip(raw_zip([("assets/bomb.png", b"\0" * (8 * 1024 * 1024))], method=8))
    assert codes(exc) == {"E_ARCHIVE_RATIO"}


def test_declared_size_is_enforced_while_inflating():
    # Declares 10 bytes but inflates to a megabyte: must stop, not allocate.
    with pytest.raises(AavError) as exc:
        read_zip(raw_zip([("assets/x.png", b"A" * 1_000_000)], method=8, lie_usize=10))
    assert codes(exc) == {"E_ARCHIVE_SIZE"}


def test_oversized_entry_and_total_are_rejected():
    limit = LIMITS["archive"]["max_file_bytes"]
    with pytest.raises(AavError) as exc:
        read_zip(raw_zip([("assets/x.png", b"")], lie_usize=limit + 1, method=8))
    assert codes(exc) == {"E_ARCHIVE_LIMIT"}
    with pytest.raises(AavError) as exc:
        read_zip(raw_zip([(f"assets/{i}.png", b"") for i in range(LIMITS["archive"]["max_entries"] + 1)]))
    assert codes(exc) == {"E_ARCHIVE_LIMIT"}


def test_structural_violations_are_rejected(good):
    cases = {
        "prefix": (raw_zip([("manifest.json", b"{}")], prefix=b"GIF89a junk"), "E_ARCHIVE_FORMAT"),
        "comment": (raw_zip([("manifest.json", b"{}")], comment=b"hello"), "E_ARCHIVE_FORMAT"),
        "trailing": (good + b"\0\0", "E_ARCHIVE_FORMAT"),
        "truncated": (good[:-10], "E_ARCHIVE_FORMAT"),
        "not a zip": (b"this is not a zip file at all, just text", "E_ARCHIVE_FORMAT"),
        "empty": (b"", "E_ARCHIVE_FORMAT"),
        "encrypted": (raw_zip([("manifest.json", b"{}")], flags=0x0801), "E_ARCHIVE_ENCRYPTED"),
        "method": (raw_zip([("manifest.json", b"{}")], method=0).replace(b"\x14\x00\x00\x08\x00\x00", b"\x14\x00\x00\x08\x0c\x00"),
                   "E_ARCHIVE_METHOD"),
        "name mismatch": (raw_zip([("manifest.json", b"{}")], central_name=b"manifest.jso2"), "E_ARCHIVE_FORMAT"),
    }
    for label, (data, expected) in cases.items():
        with pytest.raises(AavError) as exc:
            read_zip(data)
        assert codes(exc) == {expected}, label


def test_crc_mismatch_is_rejected(good):
    index = good.index(b"IDAT") + 8
    corrupted = good[:index] + bytes([good[index] ^ 0xFF]) + good[index + 1:]
    with pytest.raises(AavError) as exc:
        read_zip(corrupted)
    assert codes(exc) == {"E_ARCHIVE_CRC"}


def test_zip64_markers_are_rejected(good):
    eocd = len(good) - 22
    patched = good[:eocd + 16] + b"\xff\xff\xff\xff" + good[eocd + 20:]
    with pytest.raises(AavError) as exc:
        read_zip(patched)
    assert codes(exc) == {"E_ARCHIVE_FORMAT"}


def test_overlapping_entries_are_rejected():
    data = bytearray(raw_zip([("assets/a.png", b"A" * 64), ("assets/b.png", b"B" * 64)]))
    cd = data.index(b"PK\x01\x02")
    second = data.index(b"PK\x01\x02", cd + 4)
    data[second + 42:second + 46] = struct.pack("<I", 0)  # point the second entry at the first one's bytes
    data[second + 46:second + 46 + 12] = b"assets/a.png"
    with pytest.raises(AavError) as exc:
        read_zip(bytes(data))
    assert codes(exc) <= {"E_ARCHIVE_OVERLAP", "E_ARCHIVE_DUPLICATE"} and codes(exc)


def test_missing_manifest_and_bad_json():
    with pytest.raises(AavError) as exc:
        read_archive(raw_zip([("preview.png", png_bytes(1, 1))]))
    assert codes(exc) == {"E_ARCHIVE_MISSING"}
    with pytest.raises(AavError) as exc:
        read_archive(raw_zip([("manifest.json", b"{not json")]))
    assert codes(exc) == {"E_JSON"}


def rebuild(good: bytes, mutate) -> bytes:
    files = read_zip(good)
    manifest = json.loads(files["manifest.json"])
    mutate(manifest, files)
    files["manifest.json"] = json.dumps(manifest).encode()
    return write_zip(files)


def test_asset_hash_type_and_size_mismatches(good):
    def bad_hash(m, f):
        m["assets"]["base"]["sha256"] = "0" * 64

    def bad_type(m, f):
        m["assets"]["base"]["media_type"] = "image/jpeg"
        m["assets"]["base"].pop("sha256")

    def bad_size(m, f):
        m["assets"]["base"]["width"] = 999

    def swapped(m, f):  # contents replaced after hashing
        f[m["assets"]["base"]["path"]] = gradient_png(320, 200)[:-1] + b"\x00"

    def not_image(m, f):
        f[m["assets"]["base"]["path"]] = b"<svg xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>"

    def missing(m, f):
        del f[m["assets"]["base"]["path"]]

    def no_preview(m, f):
        del f["preview.png"]

    for mutate, expected in ((bad_hash, "E_ASSET_HASH"), (bad_type, "E_ASSET_TYPE"), (bad_size, "E_ASSET_DIMENSIONS"),
                             (swapped, "E_ASSET_HASH"), (not_image, "E_ASSET_TYPE"), (missing, "E_ARCHIVE_MISSING"),
                             (no_preview, "E_ARCHIVE_MISSING")):
        with pytest.raises(AavError) as exc:
            read_archive(rebuild(good, mutate))
        assert expected in codes(exc), mutate.__name__


def test_oversized_image_dimensions_are_rejected_from_the_header(good):
    huge = bytearray(png_bytes(4, 4))
    huge[16:24] = struct.pack(">II", 60000, 60000)  # header claims a 3.6-gigapixel image; nothing is decoded
    assert sniff_image(bytes(huge)) == ("image/png", 60000, 60000)

    def mutate(m, f):
        f[m["assets"]["base"]["path"]] = bytes(huge)
        for key in ("sha256", "width", "height"):
            m["assets"]["base"].pop(key)

    with pytest.raises(AavError) as exc:
        read_archive(rebuild(good, mutate))
    assert "E_ASSET_DIMENSIONS" in codes(exc)


def test_unreferenced_files_warn_or_fail_in_strict_mode(good):
    data = rebuild(good, lambda m, f: f.__setitem__("assets/hidden-original.png", png_bytes(8, 8)))
    _, warnings = read_archive(data)
    assert [w.code for w in warnings] == ["W_UNREFERENCED"]
    with pytest.raises(AavError) as exc:
        read_archive(data, strict=True)
    assert codes(exc) == {"E_UNREFERENCED"}


def test_unsupported_version_is_reported_but_container_stays_readable(good):
    data = rebuild(good, lambda m, f: m.__setitem__("version", "2.0"))
    with pytest.raises(AavError) as exc:
        read_archive(data)
    assert codes(exc) == {"E_VERSION"}
    package = load_unvalidated(data)  # a viewer can still show the static preview
    assert sniff_image(package.files["preview.png"])[0] == "image/png"


def test_sniff_image_formats():
    from PIL import Image
    for fmt, expected in (("PNG", "image/png"), ("JPEG", "image/jpeg"), ("WEBP", "image/webp")):
        out = io.BytesIO()
        Image.new("RGB", (37, 21), (1, 2, 3)).save(out, fmt)
        assert sniff_image(out.getvalue()) == (expected, 37, 21), fmt
    out = io.BytesIO()
    Image.new("RGBA", (37, 21), (1, 2, 3, 4)).save(out, "WEBP", lossless=True)
    assert sniff_image(out.getvalue()) == ("image/webp", 37, 21)
    assert sniff_image(b"GIF89a" + b"\0" * 40) is None
    assert sniff_image(b"") is None
    assert len(sha256_hex(b"")) == 64
