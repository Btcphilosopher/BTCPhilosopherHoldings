"""Manifest validation: shared conformance vectors, JSON Schema agreement, strict parsing."""
from __future__ import annotations

import json

import jsonschema
import pytest

from aav import AavError, canonical_json, parse_manifest, validate_manifest
from aav.limits import schema

from conftest import CONFORMANCE, ROOT, case_manifest

CASES = CONFORMANCE["cases"]
SCHEMA_VALIDATOR = jsonschema.Draft202012Validator(schema())


@pytest.mark.parametrize("case", CASES, ids=[c["name"] for c in CASES])
def test_conformance_codes(case):
    issues = validate_manifest(case_manifest(case))
    assert sorted({i.code for i in issues}) == sorted(case["codes"]), [str(i) for i in issues]


@pytest.mark.parametrize("case", [c for c in CASES if c["schema"] != "skip"],
                         ids=[c["name"] for c in CASES if c["schema"] != "skip"])
def test_conformance_json_schema(case):
    errors = list(SCHEMA_VALIDATOR.iter_errors(case_manifest(case)))
    assert (not errors) == (case["schema"] == "valid"), [e.message for e in errors[:3]]


def test_schema_never_accepts_what_validator_rejects_structurally():
    """Anything the schema rejects, the validator must reject too (the schema is the weaker check)."""
    for case in CASES:
        if case["schema"] == "invalid":
            assert any(i.severity == "error" for i in validate_manifest(case_manifest(case))), case["name"]


def test_packaged_data_matches_repository_copies():
    import aav.limits as limits
    for name in ("limits.json", "effect-specs.json", "aav-1.0.schema.json"):
        assert limits._load(name) == json.loads((ROOT / "schema" / name).read_text("utf-8")), name


@pytest.mark.parametrize("text", [
    '{"format": "aureom-active-visual", "version": "1.0", "x": NaN}',
    '{"format": "aureom-active-visual", "version": "1.0", "x": Infinity}',
    '{"format": "aureom-active-visual", "version": "1.0", "x": -Infinity}',
    '{"format": "a", "format": "b"}',
    '{"format": "aureom-active-visual",}',
    '[1, 2, 3]',
    '',
])
def test_parse_rejects_non_standard_json(text):
    with pytest.raises(AavError):
        parse_manifest(text.encode())


def test_parse_rejects_bom_bad_utf8_and_oversize():
    with pytest.raises(AavError):
        parse_manifest(b"\xef\xbb\xbf{}")
    with pytest.raises(AavError):
        parse_manifest(b'{"a": "\xff"}')
    with pytest.raises(AavError):
        parse_manifest(b'{"a": "' + b"x" * (5 * 1024 * 1024) + b'"}')


def test_overflowing_number_is_reported_as_non_finite():
    manifest = parse_manifest(json.dumps(CONFORMANCE["base"]).replace('"x": 400, "y": 220', '"x": 1e999, "y": 220'))
    assert "E_NONFINITE" in {i.code for i in validate_manifest(manifest)}


def test_deeply_nested_json_does_not_crash():
    with pytest.raises(AavError):
        parse_manifest(("[" * 200000 + "]" * 200000).encode())


def test_canonical_json_is_sorted_stable_and_integer_clean():
    a = canonical_json({"b": 1.0, "a": [3, {"z": 0.5, "y": 2.0}], "é": "ü"})
    b = canonical_json({"é": "ü", "a": [3, {"y": 2, "z": 0.5}], "b": 1})
    assert a == b
    assert a.decode("utf-8") == '{\n  "a": [\n    3,\n    {\n      "y": 2,\n      "z": 0.5\n    }\n  ],\n  "b": 1,\n  "é": "ü"\n}\n'
    with pytest.raises(AavError):
        canonical_json({"a": float("nan")})
