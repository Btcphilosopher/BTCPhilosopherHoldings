from __future__ import annotations

import copy
import io
import json
from pathlib import Path

import pytest
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
CONFORMANCE = json.loads((ROOT / "conformance" / "manifests.json").read_text("utf-8"))


def apply_ops(base: dict, ops: list[dict]) -> dict:
    """Apply the conformance patch operations (see conformance/manifests.json)."""
    doc = copy.deepcopy(base)
    for op in ops:
        parts = op["path"].split("/")[1:]
        node = doc
        for part in parts[:-1]:
            node = node[int(part)] if isinstance(node, list) else node[part]
        last = parts[-1]
        if op["op"] == "remove":
            if isinstance(node, list):
                del node[int(last)]
            else:
                del node[last]
            continue
        if "repeat" in op:
            value = [copy.deepcopy(op["repeat"]["value"]) for _ in range(op["repeat"]["count"])]
        elif "repeat_string" in op:
            value = op["repeat_string"]["value"] * op["repeat_string"]["count"]
        else:
            value = copy.deepcopy(op["value"])
        if isinstance(node, list):
            if last == "-":
                node.append(value)
            else:
                node[int(last)] = value
        else:
            node[last] = value
    return doc


def case_manifest(case: dict) -> dict:
    return copy.deepcopy(case["manifest"]) if "manifest" in case else apply_ops(CONFORMANCE["base"], case["ops"])


def png_bytes(width: int, height: int, colour=(40, 60, 90, 255), mode: str = "RGBA") -> bytes:
    out = io.BytesIO()
    Image.new(mode, (width, height), colour).save(out, "PNG")
    return out.getvalue()


def gradient_png(width: int, height: int) -> bytes:
    image = Image.new("RGB", (width, height))
    image.putdata([((x * 255) // max(1, width - 1), (y * 255) // max(1, height - 1), (x * 7 + y * 13) % 256)
                   for y in range(height) for x in range(width)])
    out = io.BytesIO()
    image.save(out, "PNG")
    return out.getvalue()


@pytest.fixture
def sample_doc():
    from aav import Document
    doc = Document.create(gradient_png(320, 200), title="Sample")
    doc.add_region("window", "Window", Document.rect(40, 30, 100, 80), target_layer="background",
                   effects={"glow": {"type": "glow", "colour": "#FFD47A", "intensity": 0}},
                   events={"activate": [{"action": "open_panel", "panel": "info"}]})
    doc.add_region("roof", "Roof", Document.polygon([(200, 20), (300, 20), (250, 90)]))
    doc.add_panel("info", "Info", "Some **text** with a [link](https://example.org/).")
    return doc
