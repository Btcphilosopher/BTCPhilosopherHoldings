# aav (Python)

Authoring library and command-line tool for the proposed `.aav` Active Visual container.
See `../README.md` for the whole project and `../docs/SPEC.md` for the format.

```bash
pip install -e ".[dev]"
```

```python
from aav import Document

doc = Document.create("building.png", title="Interactive Building",
                      description="A building with selectable rooms.")
doc.add_panel("room", "First-floor room", "Example information about this space.")
doc.add_region("window-01", "First-floor window", Document.rect(400, 220, 120, 160),
               target_layer="background",
               effects={"illumination": {"type": "glow", "colour": "#FFD47A", "intensity": 0, "radius": 18}},
               events={"pointer_enter": [{"action": "set_effect", "effect": "illumination",
                                          "property": "intensity", "value": 0.8}],
                       "pointer_leave": [{"action": "set_effect", "effect": "illumination",
                                          "property": "intensity", "value": 0}],
                       "activate": [{"action": "open_panel", "panel": "room"}]})
doc.save("building.aav")            # validates strictly, renders the preview, writes deterministically

package, warnings = __import__("aav").read_archive("building.aav")   # raises AavError if invalid
```

Validation, inspection, extraction and packing need only the standard library. Pillow is used for
previews, thumbnails and redaction. The `browser` render engine additionally needs Node.js and a
resolvable `playwright` package; it uses the viewer bundle embedded in `src/aav/data/`.

Modules: `manifest` (validator, canonical JSON), `archive` (ZIP profile, package checks), `document`
(builder), `render`, `redact`, `migrate`, `htmlexport`, `links`, `geometry`, `cli`.
