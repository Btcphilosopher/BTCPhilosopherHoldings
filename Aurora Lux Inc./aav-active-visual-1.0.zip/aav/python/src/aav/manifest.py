"""Manifest validation and canonical serialisation.

This is the reference validator. ``web/src/core/validate.ts`` implements the
same rules with the same issue codes; ``conformance/manifests.json`` holds the
vectors both are tested against.
"""
from __future__ import annotations

import json
import math
import re
from typing import Any

from .errors import AavError, Issue
from .limits import (ACTIONS, EFFECT_TYPES, FORMAT, LIMITS, SUPPORTED_MAJOR, SUPPORTED_MINOR, TRIGGERS,
                     USER_GESTURE_ACTIONS)
from .links import document_href_problem, external_url_problem, text_links

M = LIMITS["manifest"]
R = LIMITS["runtime"]
IMG = LIMITS["image"]
COORD = M["coordinate_limit"]
_ID = re.compile(M["id_pattern"])
_COLOUR = re.compile(M["colour_pattern"])
_ASSET_PATH = re.compile(M["asset_path_pattern"])
_THUMB_PATH = re.compile(M["thumbnail_path_pattern"])
_LANG = re.compile(r"^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8})*$")
_SHA = re.compile(r"^[0-9a-f]{64}$")
_VERSION = re.compile(r"^(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})$")
MASK_MEDIA_TYPES = ("image/png", "image/webp")
_MISSING: Any = object()  # distinguishes an absent key from an explicit JSON null


def is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


class _Checker:
    def __init__(self) -> None:
        self.issues: list[Issue] = []
        self.lenient = False  # set for newer minor versions: unknown things become warnings

    def add(self, code: str, path: str, message: str) -> None:
        self.issues.append(Issue(code, path, message))

    def unknown(self, path: str, message: str) -> None:
        self.add("W_UNKNOWN" if self.lenient else "E_UNKNOWN_PROPERTY", path, message)

    def obj(self, value: Any, path: str, allowed: tuple[str, ...], required: tuple[str, ...] = ()) -> bool:
        if not isinstance(value, dict):
            self.add("E_TYPE", path, "expected an object")
            return False
        for key in value:
            if key not in allowed and not key.startswith("x-"):
                self.unknown(f"{path}/{key}", f"unknown property '{key}'")
        for key in required:
            if key not in value:
                self.add("E_REQUIRED", f"{path}/{key}", f"missing required property '{key}'")
        return True

    def string(self, value: Any, path: str, max_len: int, min_len: int = 0,
               pattern: re.Pattern | None = None) -> bool:
        if not isinstance(value, str):
            self.add("E_TYPE", path, "expected a string")
            return False
        if len(value) > max_len or len(value) < min_len:
            self.add("E_RANGE", path, f"length must be between {min_len} and {max_len} characters")
            return False
        if pattern is not None and not pattern.match(value):
            self.add("E_PATTERN", path, "value has an invalid format")
            return False
        return True

    def number(self, value: Any, path: str, lo: float, hi: float, *, integer: bool = False,
               exclusive_min: bool = False) -> bool:
        if not is_number(value):
            self.add("E_TYPE", path, "expected a number")
            return False
        if not math.isfinite(value):
            self.add("E_NONFINITE", path, "number must be finite")
            return False
        if integer and float(value) != math.floor(value):
            self.add("E_TYPE", path, "expected an integer")
            return False
        if value > hi or value < lo or (exclusive_min and value <= lo):
            bound = f"greater than {lo}" if exclusive_min else f"at least {lo}"
            self.add("E_RANGE", path, f"must be {bound} and at most {hi}")
            return False
        return True

    def boolean(self, value: Any, path: str) -> bool:
        if not isinstance(value, bool):
            self.add("E_TYPE", path, "expected true or false")
            return False
        return True

    def enum(self, value: Any, path: str, values: tuple | list) -> bool:
        if isinstance(value, bool) or value not in values:
            self.add("E_ENUM", path, "must be one of: " + ", ".join(str(v) for v in values))
            return False
        return True

    def ident(self, value: Any, path: str) -> bool:
        if not isinstance(value, str):
            self.add("E_TYPE", path, "expected an identifier string")
            return False
        if not _ID.match(value):
            self.add("E_PATTERN", path, "identifiers use 1-64 characters from A-Z a-z 0-9 . _ - and start "
                                        "with a letter or digit")
            return False
        return True

    def colour(self, value: Any, path: str) -> bool:
        if not isinstance(value, str):
            self.add("E_TYPE", path, "expected a colour string")
            return False
        if not _COLOUR.match(value):
            self.add("E_PATTERN", path, "colours are written #RRGGBB or #RRGGBBAA")
            return False
        return True

    def coord(self, value: Any, path: str) -> bool:
        return self.number(value, path, -COORD, COORD)

    def size(self, value: Any, path: str) -> bool:
        return self.number(value, path, 0, COORD, exclusive_min=True)

    def id_map(self, value: Any, path: str, max_props: int) -> dict:
        if not isinstance(value, dict):
            self.add("E_TYPE", path, "expected an object keyed by identifier")
            return {}
        if len(value) > max_props:
            self.add("E_LIMIT", path, f"at most {max_props} entries are allowed")
        for key in value:
            self.ident(key, f"{path}/{key}")
        return value

    def array(self, value: Any, path: str, max_items: int, min_items: int = 0) -> list:
        if not isinstance(value, list):
            self.add("E_TYPE", path, "expected an array")
            return []
        if len(value) > max_items:
            self.add("E_LIMIT", path, f"at most {max_items} items are allowed")
            return []
        if len(value) < min_items:
            self.add("E_RANGE", path, f"at least {min_items} item(s) are required")
        return value


def check_prop_value(c: _Checker, spec: dict, value: Any, path: str) -> bool:
    kind = spec["kind"]
    if kind == "number":
        return c.number(value, path, spec["min"], spec["max"])
    if kind == "colour":
        return c.colour(value, path)
    if kind == "enum":
        return c.enum(value, path, spec["values"])
    return c.boolean(value, path)


def polygon_area(points: list) -> float:
    total = 0.0
    for i, (x1, y1) in enumerate(points):
        x2, y2 = points[(i + 1) % len(points)]
        total += x1 * y2 - x2 * y1
    return total / 2


def shape_bounds(shape: dict, doc_w: float, doc_h: float) -> tuple[float, float, float, float]:
    """Bounding box (x, y, width, height) in document pixels. Assumes a valid shape."""
    if shape["type"] == "polygon":
        xs = [p[0] for p in shape["points"]]
        ys = [p[1] for p in shape["points"]]
        return min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)
    if shape["type"] == "mask":
        return (shape.get("x", 0), shape.get("y", 0), shape.get("width", doc_w), shape.get("height", doc_h))
    return shape["x"], shape["y"], shape["width"], shape["height"]


def validate_manifest(manifest: Any) -> list[Issue]:
    """Validate a parsed manifest. Returns every issue found (errors and warnings)."""
    c = _Checker()
    if not isinstance(manifest, dict):
        c.add("E_TYPE", "", "manifest must be a JSON object")
        return c.issues
    if manifest.get("format") != FORMAT:
        c.add("E_FORMAT", "/format", f"format must be '{FORMAT}'")
        return c.issues
    version = manifest.get("version")
    match = _VERSION.match(version) if isinstance(version, str) else None
    if not match:
        c.add("E_VERSION", "/version", "version must be a 'MAJOR.MINOR' string")
        return c.issues
    major, minor = int(match.group(1)), int(match.group(2))
    if major != SUPPORTED_MAJOR:
        hint = " (use 'aav migrate' for pre-release drafts)" if major < SUPPORTED_MAJOR else ""
        c.add("E_VERSION", "/version", f"unsupported schema version {version}; this implementation reads "
                                       f"{SUPPORTED_MAJOR}.x{hint}")
        return c.issues
    if minor > SUPPORTED_MINOR:
        c.lenient = True
        c.add("W_NEWER_MINOR", "/version", f"document uses schema {version}; features newer than "
                                           f"{SUPPORTED_MAJOR}.{SUPPORTED_MINOR} are ignored")

    c.obj(manifest, "", ("format", "version", "document", "metadata", "settings", "assets", "layers", "regions",
                         "groups", "panels", "animations", "events", "default_state", "preview", "thumbnail",
                         "redaction"),
          ("document", "layers", "preview"))

    doc_w, doc_h = _check_document(c, manifest.get("document"))
    _check_metadata(c, manifest)
    assets = _check_assets(c, manifest.get("assets", {}))
    layer_ids = _check_layers(c, manifest.get("layers", []), assets)

    regions_raw = manifest.get("regions", [])
    regions = c.array(regions_raw, "/regions", M["max_regions"])
    region_map: dict[str, dict] = {}
    for i, region in enumerate(regions):
        if isinstance(region, dict) and isinstance(region.get("id"), str):
            if region["id"] in region_map:
                c.add("E_DUPLICATE_ID", f"/regions/{i}/id", f"duplicate region id '{region['id']}'")
            else:
                region_map[region["id"]] = region

    groups = c.id_map(manifest.get("groups", {}), "/groups", M["max_groups"])
    panels = c.id_map(manifest.get("panels", {}), "/panels", M["max_panels"])
    animations = c.id_map(manifest.get("animations", {}), "/animations", M["max_animations"])
    refs = _Refs(layer_ids, region_map, groups, panels, animations, assets)

    for i, region in enumerate(regions):
        _check_region(c, region, f"/regions/{i}", refs, doc_w, doc_h)

    for gid, group in groups.items():
        path = f"/groups/{gid}"
        if not c.obj(group, path, ("label", "description", "regions"), ("label", "regions")):
            continue
        if "label" in group:
            c.string(group["label"], f"{path}/label", M["max_label"], 1)
        if "description" in group:
            c.string(group["description"], f"{path}/description", M["max_description"])
        members = c.array(group.get("regions", []), f"{path}/regions", M["max_regions"], 1)
        seen: set[str] = set()
        for j, rid in enumerate(members):
            if not c.ident(rid, f"{path}/regions/{j}"):
                continue
            if rid in seen:
                c.add("E_DUPLICATE_ID", f"{path}/regions/{j}", f"region '{rid}' is listed twice")
            seen.add(rid)
            if rid not in region_map:
                c.add("E_REF", f"{path}/regions/{j}", f"unknown region '{rid}'")

    for pid, panel in panels.items():
        path = f"/panels/{pid}"
        if not c.obj(panel, path, ("title", "text"), ("title", "text")):
            continue
        if "title" in panel:
            c.string(panel["title"], f"{path}/title", M["max_title"], 1)
        if "text" in panel and c.string(panel["text"], f"{path}/text", M["max_panel_text"]):
            _check_text_links(c, panel["text"], f"{path}/text", refs)

    for aid, anim in animations.items():
        _check_animation(c, anim, f"/animations/{aid}", refs)

    events = manifest.get("events", _MISSING)
    if events is not _MISSING and c.obj(events, "/events", ("document_load",)):
        _check_actions(c, events.get("document_load", []), "/events/document_load", "document_load", None, refs)

    _check_default_state(c, manifest.get("default_state", _MISSING), refs)

    if "preview" in manifest and manifest["preview"] != "preview.png":
        c.add("E_ENUM", "/preview", "preview must be 'preview.png'")
    if "thumbnail" in manifest:
        c.string(manifest["thumbnail"], "/thumbnail", 200, 1, _THUMB_PATH)

    redaction = manifest.get("redaction", _MISSING)
    if redaction is not _MISSING and c.obj(redaction, "/redaction", ("method", "colour", "regions", "tool"),
                                       ("method", "regions")):
        if "method" in redaction:
            c.enum(redaction["method"], "/redaction/method", ("fill",))
        if "colour" in redaction:
            c.colour(redaction["colour"], "/redaction/colour")
        if "tool" in redaction:
            c.string(redaction["tool"], "/redaction/tool", 200)
        for j, rid in enumerate(c.array(redaction.get("regions", []), "/redaction/regions", M["max_regions"])):
            if c.ident(rid, f"/redaction/regions/{j}") and rid not in region_map:
                c.add("E_REF", f"/redaction/regions/{j}", f"unknown region '{rid}'")
    return c.issues


class _Refs:
    def __init__(self, layers, regions, groups, panels, animations, assets):
        self.layers: set[str] = layers
        self.regions: dict[str, dict] = regions
        self.groups: dict[str, Any] = groups
        self.panels: dict[str, Any] = panels
        self.animations: dict[str, Any] = animations
        self.assets: dict[str, Any] = assets

    def effect(self, region_id: str, effect_id: Any) -> dict | None:
        """The effect definition if it exists and has a known type."""
        region = self.regions.get(region_id)
        effects = region.get("effects") if isinstance(region, dict) else None
        effect = effects.get(effect_id) if isinstance(effects, dict) and isinstance(effect_id, str) else None
        if isinstance(effect, dict) and isinstance(effect.get("type"), str) and effect["type"] in EFFECT_TYPES:
            return effect
        return None


def _check_document(c: _Checker, doc: Any) -> tuple[float, float]:
    if not c.obj(doc, "/document", ("id", "title", "width", "height", "description", "language", "colour_space",
                                    "background"), ("id", "title", "width", "height")):
        return math.inf, math.inf
    if "id" in doc:
        c.ident(doc["id"], "/document/id")
    if "title" in doc:
        c.string(doc["title"], "/document/title", M["max_title"], 1)
    ok_w = "width" in doc and c.number(doc["width"], "/document/width", 1, M["max_dimension"], integer=True)
    ok_h = "height" in doc and c.number(doc["height"], "/document/height", 1, M["max_dimension"], integer=True)
    if ok_w and ok_h and doc["width"] * doc["height"] > M["max_document_pixels"]:
        c.add("E_LIMIT", "/document", f"document area exceeds {M['max_document_pixels']} pixels")
    if "description" in doc:
        c.string(doc["description"], "/document/description", M["max_description"])
    if "language" in doc:
        c.string(doc["language"], "/document/language", 64, 2, _LANG)
    if "colour_space" in doc and doc["colour_space"] != "srgb":
        c.add("E_ENUM", "/document/colour_space", "only 'srgb' is defined in schema 1.0")
    if "background" in doc:
        c.colour(doc["background"], "/document/background")
    # With an invalid canvas size the "outside the document" warning is meaningless, so it is suppressed.
    return (doc["width"] if ok_w else math.inf), (doc["height"] if ok_h else math.inf)


def _check_metadata(c: _Checker, manifest: dict) -> None:
    meta = manifest.get("metadata", _MISSING)
    if meta is not _MISSING and c.obj(meta, "/metadata", ("author", "licence", "created", "generator", "source")):
        for key, limit in (("author", 500), ("licence", 500), ("created", 64), ("generator", 200), ("source", 500)):
            if key in meta:
                c.string(meta[key], f"/metadata/{key}", limit)
    settings = manifest.get("settings", _MISSING)
    if settings is not _MISSING and c.obj(settings, "/settings", ("selection", "default_highlight", "pan_zoom",
                                                              "image_rendering")):
        if "selection" in settings:
            c.enum(settings["selection"], "/settings/selection", ("single", "multiple", "none"))
        if "default_highlight" in settings:
            c.boolean(settings["default_highlight"], "/settings/default_highlight")
        if "pan_zoom" in settings:
            c.boolean(settings["pan_zoom"], "/settings/pan_zoom")
        if "image_rendering" in settings:
            c.enum(settings["image_rendering"], "/settings/image_rendering", ("smooth", "pixelated"))


def _check_assets(c: _Checker, assets_raw: Any) -> dict:
    assets = c.id_map(assets_raw, "/assets", M["max_assets"])
    paths: dict[str, str] = {}
    for aid, asset in assets.items():
        path = f"/assets/{aid}"
        if not c.obj(asset, path, ("path", "media_type", "sha256", "width", "height"), ("path", "media_type")):
            continue
        if "path" in asset and c.string(asset["path"], f"{path}/path", 200, 1, _ASSET_PATH):
            key = asset["path"].lower()
            if key in paths:
                c.add("E_DUPLICATE_PATH", f"{path}/path", f"path is already used by asset '{paths[key]}'")
            paths[key] = aid
        if "media_type" in asset:
            c.enum(asset["media_type"], f"{path}/media_type", IMG["media_types"])
        if "sha256" in asset:
            c.string(asset["sha256"], f"{path}/sha256", 64, 64, _SHA)
        for key in ("width", "height"):
            if key in asset:
                c.number(asset[key], f"{path}/{key}", 1, IMG["max_dimension"], integer=True)
    return assets


def _check_layers(c: _Checker, layers_raw: Any, assets: dict) -> set[str]:
    ids: set[str] = set()
    for i, layer in enumerate(c.array(layers_raw, "/layers", M["max_layers"], 1)):
        path = f"/layers/{i}"
        if not isinstance(layer, dict):
            c.add("E_TYPE", path, "expected an object")
            continue
        kind = layer.get("type")
        common = ("id", "type", "name", "visible", "opacity", "transform", "clip")
        if kind == "image":
            c.obj(layer, path, common + ("asset", "x", "y", "width", "height"), ("id", "type", "asset"))
            if "asset" in layer and c.ident(layer["asset"], f"{path}/asset") and layer["asset"] not in assets:
                c.add("E_REF", f"{path}/asset", f"unknown asset '{layer['asset']}'")
        elif kind == "text":
            c.obj(layer, path, common + ("text", "x", "y", "font_size", "font_family", "font_weight", "colour",
                                         "align", "background", "padding", "max_width", "line_height"),
                  ("id", "type", "text", "x", "y"))
            if "text" in layer:
                c.string(layer["text"], f"{path}/text", M["max_layer_text"], 1)
            if "font_size" in layer:
                c.number(layer["font_size"], f"{path}/font_size", 4, 512)
            if "font_family" in layer:
                c.enum(layer["font_family"], f"{path}/font_family", ("sans-serif", "serif", "monospace"))
            if "font_weight" in layer:
                c.enum(layer["font_weight"], f"{path}/font_weight", (400, 700))
            if "align" in layer:
                c.enum(layer["align"], f"{path}/align", ("left", "centre", "right"))
            for key in ("colour", "background"):
                if key in layer:
                    c.colour(layer[key], f"{path}/{key}")
            if "padding" in layer:
                c.number(layer["padding"], f"{path}/padding", 0, 64)
            if "max_width" in layer:
                c.size(layer["max_width"], f"{path}/max_width")
            if "line_height" in layer:
                c.number(layer["line_height"], f"{path}/line_height", 0.8, 3)
        else:
            if c.lenient and isinstance(kind, str):
                c.add("W_UNKNOWN", f"{path}/type", f"unknown layer type '{kind}' is ignored")
            else:
                c.add("E_ENUM", f"{path}/type", "layer type must be 'image' or 'text'")
            continue
        if "id" in layer and c.ident(layer["id"], f"{path}/id"):
            if layer["id"] in ids:
                c.add("E_DUPLICATE_ID", f"{path}/id", f"duplicate layer id '{layer['id']}'")
            ids.add(layer["id"])
        if "name" in layer:
            c.string(layer["name"], f"{path}/name", M["max_label"])
        if "visible" in layer:
            c.boolean(layer["visible"], f"{path}/visible")
        if "opacity" in layer:
            c.number(layer["opacity"], f"{path}/opacity", 0, 1)
        for key in ("x", "y"):
            if key in layer:
                c.coord(layer[key], f"{path}/{key}")
        if kind == "image":
            for key in ("width", "height"):
                if key in layer:
                    c.size(layer[key], f"{path}/{key}")
        transform = layer.get("transform", _MISSING)
        if transform is not _MISSING and c.obj(transform, f"{path}/transform",
                                           ("translate_x", "translate_y", "scale_x", "scale_y", "rotation",
                                            "origin_x", "origin_y")):
            for key in ("translate_x", "translate_y", "origin_x", "origin_y"):
                if key in transform:
                    c.coord(transform[key], f"{path}/transform/{key}")
            for key in ("scale_x", "scale_y"):
                if key in transform and c.number(transform[key], f"{path}/transform/{key}", -100, 100) \
                        and transform[key] == 0:
                    c.add("E_GEOMETRY", f"{path}/transform/{key}", "scale must not be zero")
            if "rotation" in transform:
                c.number(transform["rotation"], f"{path}/transform/rotation", -360, 360)
        clip = layer.get("clip", _MISSING)
        if clip is not _MISSING and c.obj(clip, f"{path}/clip", ("x", "y", "width", "height"),
                                      ("x", "y", "width", "height")):
            for key in ("x", "y"):
                if key in clip:
                    c.coord(clip[key], f"{path}/clip/{key}")
            for key in ("width", "height"):
                if key in clip:
                    c.size(clip[key], f"{path}/clip/{key}")
    return ids


def _check_shape(c: _Checker, shape: Any, path: str, refs: _Refs) -> bool:
    if not isinstance(shape, dict):
        c.add("E_TYPE", path, "expected an object")
        return False
    before = len(c.issues)
    kind = shape.get("type")
    if kind == "rect":
        c.obj(shape, path, ("type", "x", "y", "width", "height"), ("type", "x", "y", "width", "height"))
        for key in ("x", "y"):
            if key in shape:
                c.coord(shape[key], f"{path}/{key}")
        for key in ("width", "height"):
            if key in shape and is_number(shape[key]) and math.isfinite(shape[key]) and shape[key] <= 0:
                c.add("E_GEOMETRY", f"{path}/{key}", "rectangle width and height must be greater than zero")
            elif key in shape:
                c.size(shape[key], f"{path}/{key}")
    elif kind == "polygon":
        c.obj(shape, path, ("type", "points"), ("type", "points"))
        points = shape.get("points")
        if not isinstance(points, list):
            if "points" in shape:
                c.add("E_TYPE", f"{path}/points", "expected an array of [x, y] pairs")
        elif len(points) > M["max_polygon_points"]:
            c.add("E_LIMIT", f"{path}/points", f"at most {M['max_polygon_points']} points are allowed")
        elif len(points) < 3:
            c.add("E_GEOMETRY", f"{path}/points", "a polygon needs at least three points")
        else:
            good = True
            for j, point in enumerate(points):
                if not isinstance(point, list) or len(point) != 2:
                    c.add("E_TYPE", f"{path}/points/{j}", "expected an [x, y] pair")
                    good = False
                else:
                    good = c.coord(point[0], f"{path}/points/{j}/0") and good
                    good = c.coord(point[1], f"{path}/points/{j}/1") and good
            if good and abs(polygon_area(points)) < 1e-6:
                c.add("E_GEOMETRY", f"{path}/points", "polygon has no area")
    elif kind == "mask":
        c.obj(shape, path, ("type", "asset", "x", "y", "width", "height", "threshold", "hit_test"),
              ("type", "asset"))
        if "asset" in shape and c.ident(shape["asset"], f"{path}/asset"):
            asset = refs.assets.get(shape["asset"])
            if asset is None:
                c.add("E_REF", f"{path}/asset", f"unknown asset '{shape['asset']}'")
            elif isinstance(asset, dict) and asset.get("media_type") not in MASK_MEDIA_TYPES:
                c.add("E_ASSET_TYPE", f"{path}/asset", "mask assets must be PNG or WebP (an alpha channel is needed)")
        for key in ("x", "y"):
            if key in shape:
                c.coord(shape[key], f"{path}/{key}")
        for key in ("width", "height"):
            if key in shape:
                c.size(shape[key], f"{path}/{key}")
        if "threshold" in shape:
            c.number(shape["threshold"], f"{path}/threshold", 0, 1, exclusive_min=True)
        if "hit_test" in shape:
            c.enum(shape["hit_test"], f"{path}/hit_test", ("alpha", "bounds"))
    else:
        c.add("E_ENUM", f"{path}/type", "shape type must be 'rect', 'polygon' or 'mask'")
    return len(c.issues) == before


def _check_region(c: _Checker, region: Any, path: str, refs: _Refs, doc_w: float, doc_h: float) -> None:
    if not c.obj(region, path, ("id", "label", "description", "shape", "target_layer", "z_index", "interactive",
                                "selectable", "tooltip", "effects", "states", "events"),
                 ("id", "label", "shape")):
        return
    rid = region.get("id")
    if "id" in region:
        c.ident(rid, f"{path}/id")
    if "label" in region:
        c.string(region["label"], f"{path}/label", M["max_label"], 1)
    if "description" in region:
        c.string(region["description"], f"{path}/description", M["max_description"])
    if "tooltip" in region:
        c.string(region["tooltip"], f"{path}/tooltip", M["max_tooltip"])
    if "shape" in region and _check_shape(c, region["shape"], f"{path}/shape", refs):
        x, y, w, h = shape_bounds(region["shape"], doc_w, doc_h)
        if x >= doc_w or y >= doc_h or x + w <= 0 or y + h <= 0:
            c.add("W_OUTSIDE", f"{path}/shape", "region lies entirely outside the document")
    if "target_layer" in region and c.ident(region["target_layer"], f"{path}/target_layer") \
            and region["target_layer"] not in refs.layers:
        c.add("E_REF", f"{path}/target_layer", f"unknown layer '{region['target_layer']}'")
    if "z_index" in region:
        c.number(region["z_index"], f"{path}/z_index", -1000, 1000, integer=True)
    for key in ("interactive", "selectable"):
        if key in region:
            c.boolean(region[key], f"{path}/{key}")

    effects = c.id_map(region.get("effects", {}), f"{path}/effects", len(EFFECT_TYPES))
    seen_types: dict[str, str] = {}
    for eid, effect in effects.items():
        epath = f"{path}/effects/{eid}"
        if not isinstance(effect, dict):
            c.add("E_TYPE", epath, "expected an object")
            continue
        kind = effect.get("type")
        if not isinstance(kind, str) or kind not in EFFECT_TYPES:
            if c.lenient and isinstance(kind, str):
                c.add("W_UNKNOWN", f"{epath}/type", f"unknown effect type '{kind}' is ignored")
            else:
                c.add("E_ENUM", f"{epath}/type", "unknown effect type; expected one of: " + ", ".join(EFFECT_TYPES))
            continue
        if kind in seen_types:
            c.add("E_EFFECT_DUPLICATE", epath, f"region already has a '{kind}' effect ('{seen_types[kind]}'); "
                                               "at most one effect of each type is allowed per region")
        seen_types[kind] = eid
        props = EFFECT_TYPES[kind]["props"]
        for key, value in effect.items():
            if key == "type" or key.startswith("x-"):
                continue
            if key not in props:
                c.unknown(f"{epath}/{key}", f"'{kind}' has no property '{key}'")
            else:
                check_prop_value(c, props[key], value, f"{epath}/{key}")

    states = region.get("states", _MISSING)
    if states is not _MISSING and c.obj(states, f"{path}/states", ("hover", "selected", "focus")):
        for state in ("hover", "selected", "focus"):
            if state not in states:
                continue
            overrides = states[state]
            spath = f"{path}/states/{state}"
            if not isinstance(overrides, dict):
                c.add("E_TYPE", spath, "expected an object keyed by effect id")
                continue
            for eid, values in overrides.items():
                effect = refs.effect(rid, eid) if isinstance(rid, str) else None
                if effect is None:
                    c.add("E_REF", f"{spath}/{eid}", f"region has no effect '{eid}'")
                    continue
                if not isinstance(values, dict):
                    c.add("E_TYPE", f"{spath}/{eid}", "expected an object of property overrides")
                    continue
                props = EFFECT_TYPES[effect["type"]]["props"]
                for key, value in values.items():
                    if key not in props:
                        c.add("E_EFFECT_PROPERTY", f"{spath}/{eid}/{key}",
                              f"'{effect['type']}' has no property '{key}'")
                    else:
                        check_prop_value(c, props[key], value, f"{spath}/{eid}/{key}")

    events = region.get("events", _MISSING)
    if events is not _MISSING and c.obj(events, f"{path}/events", TRIGGERS):
        for trigger in TRIGGERS:
            if trigger in events:
                _check_actions(c, events[trigger], f"{path}/events/{trigger}", trigger,
                               rid if isinstance(rid, str) else None, refs)


def _effect_targets(c: _Checker, action: dict, path: str, self_region: str | None, refs: _Refs) -> list[str] | None:
    """Resolve region/group/self targeting. Returns region ids, or None if invalid."""
    has_region, has_group = "region" in action, "group" in action
    if has_region and has_group:
        c.add("E_TARGET", path, "give either 'region' or 'group', not both")
        return None
    if has_region:
        if not c.ident(action["region"], f"{path}/region"):
            return None
        if action["region"] not in refs.regions:
            c.add("E_REF", f"{path}/region", f"unknown region '{action['region']}'")
            return None
        return [action["region"]]
    if has_group:
        if not c.ident(action["group"], f"{path}/group"):
            return None
        group = refs.groups.get(action["group"])
        if group is None:
            c.add("E_REF", f"{path}/group", f"unknown group '{action['group']}'")
            return None
        members = group.get("regions") if isinstance(group, dict) else None
        return [m for m in members if isinstance(m, str) and m in refs.regions] if isinstance(members, list) else []
    if self_region is None:
        c.add("E_TARGET", path, "this action needs an explicit 'region' or 'group' outside a region handler")
        return None
    return [self_region]


def _check_actions(c: _Checker, actions: Any, path: str, trigger: str, self_region: str | None,
                   refs: _Refs) -> None:
    for i, action in enumerate(c.array(actions, path, M["max_actions_per_handler"])):
        apath = f"{path}/{i}"
        if not isinstance(action, dict):
            c.add("E_TYPE", apath, "expected an object")
            continue
        name = action.get("action")
        if not isinstance(name, str) or name not in ACTIONS:
            if c.lenient and isinstance(name, str):
                c.add("W_UNKNOWN", f"{apath}/action", f"unknown action '{name}' is ignored")
            else:
                c.add("E_ENUM", f"{apath}/action", "unknown action; expected one of: " + ", ".join(ACTIONS))
            continue
        if name in USER_GESTURE_ACTIONS and trigger != "activate":
            c.add("E_TRIGGER", apath, f"'{name}' may only run from an 'activate' handler, never from '{trigger}'")
        if name == "set_effect":
            c.obj(action, apath, ("action", "effect", "property", "value", "region", "group", "duration_ms",
                                  "easing"), ("effect", "property", "value"))
            if "easing" in action:
                c.enum(action["easing"], f"{apath}/easing", ("linear", "ease-in-out"))
            duration_ok = "duration_ms" not in action or c.number(action["duration_ms"], f"{apath}/duration_ms", 0,
                                                                  R["max_transition_ms"])
            targets = _effect_targets(c, action, apath, self_region, refs)
            if targets is None or not all(k in action for k in ("effect", "property", "value")):
                continue
            if not c.ident(action["effect"], f"{apath}/effect"):
                continue
            matched = [refs.effect(t, action["effect"]) for t in targets]
            matched = [m for m in matched if m is not None]
            if not matched:
                c.add("E_REF", f"{apath}/effect", f"no targeted region has an effect '{action['effect']}'")
                continue
            for effect in matched:
                spec = EFFECT_TYPES[effect["type"]]["props"].get(action["property"]) \
                    if isinstance(action["property"], str) else None
                if spec is None:
                    c.add("E_EFFECT_PROPERTY", f"{apath}/property",
                          f"'{effect['type']}' has no property '{action['property']}'")
                    break
                if not check_prop_value(c, spec, action["value"], f"{apath}/value"):
                    break
                if duration_ok and action.get("duration_ms", 0) > 0 and spec["kind"] != "number":
                    c.add("E_EFFECT_PROPERTY", f"{apath}/duration_ms", "only numeric properties can be transitioned")
                    break
        elif name == "toggle_layer":
            c.obj(action, apath, ("action", "layer", "mode"), ("layer",))
            if "layer" in action and c.ident(action["layer"], f"{apath}/layer") and action["layer"] not in refs.layers:
                c.add("E_REF", f"{apath}/layer", f"unknown layer '{action['layer']}'")
            if "mode" in action:
                c.enum(action["mode"], f"{apath}/mode", ("show", "hide", "toggle"))
        elif name == "select_region":
            c.obj(action, apath, ("action", "region", "group", "mode", "reveal"))
            _effect_targets(c, action, apath, self_region, refs)
            if "mode" in action:
                c.enum(action["mode"], f"{apath}/mode", ("select", "deselect", "toggle"))
            if "reveal" in action:
                c.boolean(action["reveal"], f"{apath}/reveal")
        elif name == "show_tooltip":
            c.obj(action, apath, ("action", "text", "region"))
            if "text" in action:
                c.string(action["text"], f"{apath}/text", M["max_tooltip"], 1)
            if "region" in action:
                if c.ident(action["region"], f"{apath}/region") and action["region"] not in refs.regions:
                    c.add("E_REF", f"{apath}/region", f"unknown region '{action['region']}'")
            elif self_region is None:
                c.add("E_TARGET", apath, "show_tooltip needs a 'region' outside a region handler")
        elif name == "open_panel":
            c.obj(action, apath, ("action", "panel"), ("panel",))
            if "panel" in action and c.ident(action["panel"], f"{apath}/panel") and action["panel"] not in refs.panels:
                c.add("E_REF", f"{apath}/panel", f"unknown panel '{action['panel']}'")
        elif name == "navigate_document":
            c.obj(action, apath, ("action", "href", "label"), ("href",))
            if "href" in action:
                problem = document_href_problem(action["href"])
                if problem:
                    c.add("E_LINK", f"{apath}/href", problem)
            if "label" in action:
                c.string(action["label"], f"{apath}/label", M["max_label"])
        elif name == "open_link":
            c.obj(action, apath, ("action", "url", "label"), ("url",))
            if "url" in action:
                problem = external_url_problem(action["url"])
                if problem:
                    c.add("E_LINK", f"{apath}/url", problem)
            if "label" in action:
                c.string(action["label"], f"{apath}/label", M["max_label"])
        elif name in ("play_animation", "stop_animation"):
            c.obj(action, apath, ("action", "animation"), ("animation",) if name == "play_animation" else ())
            if "animation" in action and c.ident(action["animation"], f"{apath}/animation") \
                    and action["animation"] not in refs.animations:
                c.add("E_REF", f"{apath}/animation", f"unknown animation '{action['animation']}'")
        elif name == "reset_view":
            c.obj(action, apath, ("action",))


def _check_text_links(c: _Checker, text: str, path: str, refs: _Refs) -> None:
    for _label, target in text_links(text):
        if target.startswith("#region:"):
            if target[len("#region:"):] not in refs.regions:
                c.add("E_REF", path, f"text links to unknown region '{target[len('#region:'):]}'")
        elif target.startswith("#panel:"):
            if target[len("#panel:"):] not in refs.panels:
                c.add("E_REF", path, f"text links to unknown panel '{target[len('#panel:'):]}'")
        else:
            problem = external_url_problem(target)
            if problem:
                c.add("E_LINK", path, f"link target '{target[:80]}' is not allowed: {problem}")


def _check_animation(c: _Checker, anim: Any, path: str, refs: _Refs) -> None:
    if not c.obj(anim, path, ("type", "region", "effect", "property", "from", "to", "duration_ms", "iterations",
                              "easing", "end"),
                 ("type", "region", "effect", "property", "from", "to", "duration_ms")):
        return
    if "type" in anim:
        c.enum(anim["type"], f"{path}/type", ("fade", "pulse"))
    if "easing" in anim:
        c.enum(anim["easing"], f"{path}/easing", ("linear", "ease-in-out"))
    if "end" in anim:
        c.enum(anim["end"], f"{path}/end", ("hold", "revert"))
    duration_ok = "duration_ms" in anim and c.number(anim["duration_ms"], f"{path}/duration_ms",
                                                     R["min_animation_ms"], R["max_animation_ms"])
    iterations_ok = "iterations" not in anim or c.number(anim["iterations"], f"{path}/iterations", 1,
                                                         R["max_animation_iterations"], integer=True)
    if duration_ok and iterations_ok and anim["duration_ms"] * anim.get("iterations", 1) > R["max_animation_total_ms"]:
        c.add("E_ANIMATION", path, f"total running time (duration_ms x iterations) must not exceed "
                                   f"{R['max_animation_total_ms']} ms")
    if not ("region" in anim and c.ident(anim["region"], f"{path}/region")):
        return
    if anim["region"] not in refs.regions:
        c.add("E_REF", f"{path}/region", f"unknown region '{anim['region']}'")
        return
    if not ("effect" in anim and c.ident(anim["effect"], f"{path}/effect")):
        return
    effect = refs.effect(anim["region"], anim["effect"])
    if effect is None:
        c.add("E_REF", f"{path}/effect", f"region '{anim['region']}' has no effect '{anim['effect']}'")
        return
    spec = EFFECT_TYPES[effect["type"]]["props"].get(anim.get("property")) \
        if isinstance(anim.get("property"), str) else None
    if spec is None or spec["kind"] != "number":
        c.add("E_EFFECT_PROPERTY", f"{path}/property", "animations need a numeric property of the effect")
        return
    for key in ("from", "to"):
        if key in anim:
            c.number(anim[key], f"{path}/{key}", spec["min"], spec["max"])


def _check_default_state(c: _Checker, state: Any, refs: _Refs) -> None:
    if state is _MISSING or not c.obj(state, "/default_state", ("selected", "panel", "view")):
        return
    seen: set[str] = set()
    for j, rid in enumerate(c.array(state.get("selected", []), "/default_state/selected", M["max_regions"])):
        if not c.ident(rid, f"/default_state/selected/{j}"):
            continue
        if rid in seen:
            c.add("E_DUPLICATE_ID", f"/default_state/selected/{j}", f"region '{rid}' is listed twice")
        seen.add(rid)
        if rid not in refs.regions:
            c.add("E_REF", f"/default_state/selected/{j}", f"unknown region '{rid}'")
    panel = state.get("panel")
    if panel is not None and c.ident(panel, "/default_state/panel") and panel not in refs.panels:
        c.add("E_REF", "/default_state/panel", f"unknown panel '{panel}'")
    view = state.get("view", _MISSING)
    if view is not _MISSING and c.obj(view, "/default_state/view", ("zoom", "centre_x", "centre_y")):
        if "zoom" in view and view["zoom"] != "fit":
            c.number(view["zoom"], "/default_state/view/zoom", R["min_zoom"], R["max_zoom"])
        for key in ("centre_x", "centre_y"):
            if key in view:
                c.coord(view[key], f"/default_state/view/{key}")


# --------------------------------------------------------------------------- JSON

def _reject_constant(name: str):
    raise ValueError(f"non-finite number literal '{name}' is not allowed")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate object key '{key}'")
        out[key] = value
    return out


def parse_manifest(data: bytes | str) -> dict:
    """Parse manifest JSON strictly: UTF-8, no BOM, no NaN/Infinity, no duplicate keys."""
    if isinstance(data, bytes):
        if len(data) > M["max_bytes"]:
            raise AavError(Issue("E_LIMIT", "manifest.json", f"manifest is larger than {M['max_bytes']} bytes"))
        if data.startswith(b"\xef\xbb\xbf"):
            raise AavError(Issue("E_JSON", "manifest.json", "manifest must not start with a byte-order mark"))
        try:
            data = data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AavError(Issue("E_JSON", "manifest.json", f"manifest is not valid UTF-8: {exc}")) from None
    try:
        value = json.loads(data, parse_constant=_reject_constant, object_pairs_hook=_unique_object)
    except (ValueError, RecursionError) as exc:
        raise AavError(Issue("E_JSON", "manifest.json", f"manifest is not valid JSON: {exc}")) from None
    if not isinstance(value, dict):
        raise AavError(Issue("E_TYPE", "", "manifest must be a JSON object"))
    return value


def _normalise(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _normalise(value[k]) for k in sorted(value)}
    if isinstance(value, (list, tuple)):
        return [_normalise(v) for v in value]
    if isinstance(value, float):
        if not math.isfinite(value):
            raise AavError(Issue("E_NONFINITE", "", "manifest contains a non-finite number"))
        if value.is_integer() and abs(value) < 2 ** 53:
            return int(value)
    return value


def canonical_json(manifest: dict) -> bytes:
    """Canonical manifest bytes: sorted keys, two-space indent, LF, UTF-8, trailing newline.

    Integer-valued numbers are written without a fraction. Byte equality with
    the TypeScript writer holds for manifests whose non-integer numbers print
    identically in both languages (true for ordinary decimals).
    """
    return (json.dumps(_normalise(manifest), indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
