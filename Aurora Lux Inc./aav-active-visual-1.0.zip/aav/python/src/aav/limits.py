"""Limits and effect tables, loaded from the shared JSON data files."""
from __future__ import annotations

import json
from importlib import resources


def _load(name: str) -> dict:
    return json.loads(resources.files("aav").joinpath("data", name).read_text("utf-8"))


LIMITS: dict = _load("limits.json")
EFFECT_SPECS: dict = _load("effect-specs.json")

FORMAT: str = LIMITS["format"]
VERSION: str = LIMITS["version"]
SUPPORTED_MAJOR: int = LIMITS["supported_major"]
SUPPORTED_MINOR: int = LIMITS["supported_minor"]
MEDIA_TYPE: str = LIMITS["provisional_media_type"]
PIPELINE: list[str] = EFFECT_SPECS["pipeline"]
EFFECT_TYPES: dict = EFFECT_SPECS["types"]

TRIGGERS = ("pointer_enter", "pointer_leave", "activate", "focus", "blur")
ACTIONS = ("set_effect", "toggle_layer", "select_region", "show_tooltip", "open_panel",
           "navigate_document", "open_link", "play_animation", "stop_animation", "reset_view")
# Actions that leave the document. They may only run from an explicit user activation.
USER_GESTURE_ACTIONS = ("open_link", "navigate_document")


def schema() -> dict:
    return _load("aav-1.0.schema.json")
