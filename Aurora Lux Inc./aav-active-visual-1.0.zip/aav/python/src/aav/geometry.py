"""Document-space geometry shared by the renderer and the redaction export.

Matrices are 6-tuples (a, b, c, d, e, f) with the Canvas 2D convention:
x' = a*x + c*y + e, y' = b*x + d*y + f.
"""
from __future__ import annotations

import math

Matrix = tuple[float, float, float, float, float, float]
IDENTITY: Matrix = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def multiply(m: Matrix, n: Matrix) -> Matrix:
    """Return m x n (apply n first, then m)."""
    a1, b1, c1, d1, e1, f1 = m
    a2, b2, c2, d2, e2, f2 = n
    return (a1 * a2 + c1 * b2, b1 * a2 + d1 * b2, a1 * c2 + c1 * d2, b1 * c2 + d1 * d2,
            a1 * e2 + c1 * f2 + e1, b1 * e2 + d1 * f2 + f1)


def invert(m: Matrix) -> Matrix:
    a, b, c, d, e, f = m
    det = a * d - b * c
    if abs(det) < 1e-12:
        raise ValueError("matrix is not invertible")
    return (d / det, -b / det, -c / det, a / det, (c * f - d * e) / det, (b * e - a * f) / det)


def apply(m: Matrix, x: float, y: float) -> tuple[float, float]:
    return m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]


def layer_box(layer: dict, doc_w: float, doc_h: float) -> tuple[float, float, float, float]:
    """Untransformed layer box. Image layers default to filling the document."""
    x, y = layer.get("x", 0), layer.get("y", 0)
    if layer.get("type") == "image":
        return x, y, layer.get("width", doc_w), layer.get("height", doc_h)
    return x, y, 0, 0


def layer_transform(layer: dict, doc_w: float, doc_h: float) -> Matrix:
    """T = translate(t) . translate(o) . rotate(r) . scale(s) . translate(-o)."""
    t = layer.get("transform")
    if not t:
        return IDENTITY
    x, y, w, h = layer_box(layer, doc_w, doc_h)
    ox, oy = t.get("origin_x", x + w / 2), t.get("origin_y", y + h / 2)
    angle = math.radians(t.get("rotation", 0))
    cos, sin = math.cos(angle), math.sin(angle)
    sx, sy = t.get("scale_x", 1), t.get("scale_y", 1)
    m: Matrix = (1, 0, 0, 1, t.get("translate_x", 0) + ox, t.get("translate_y", 0) + oy)
    m = multiply(m, (cos, sin, -sin, cos, 0, 0))
    m = multiply(m, (sx, 0, 0, sy, 0, 0))
    return multiply(m, (1, 0, 0, 1, -ox, -oy))


def image_matrix(layer: dict, asset_w: int, asset_h: int, doc_w: float, doc_h: float) -> Matrix:
    """Map asset pixel coordinates to document coordinates for an image layer."""
    x, y, w, h = layer_box(layer, doc_w, doc_h)
    return multiply(layer_transform(layer, doc_w, doc_h), (w / asset_w, 0, 0, h / asset_h, x, y))


def parse_colour(value: str) -> tuple[int, int, int, int]:
    value = value.lstrip("#")
    r, g, b = (int(value[i:i + 2], 16) for i in (0, 2, 4))
    return r, g, b, int(value[6:8], 16) if len(value) == 8 else 255
