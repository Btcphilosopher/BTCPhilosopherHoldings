#!/usr/bin/env node
// Render the default state of an .aav file to PNG with the reference renderer in headless Chromium.
//
//   node render.mjs --input doc.aav --output out.png [--bundle aav-viewer.iife.js] [--backend cpu|webgl2|auto]
//
// The page is created from a string and never navigates; the document is passed in as base64.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { delimiter, resolve } from 'node:path';

function arg(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 && process.argv[index + 1] ? process.argv[index + 1] : fallback;
}

async function loadChromium() {
  const roots = [import.meta.dirname, process.cwd(), ...(process.env.AAV_PLAYWRIGHT_PATHS ?? '').split(delimiter),
    ...(process.env.NODE_PATH ?? '').split(delimiter)].filter(Boolean);
  for (const root of roots) {
    for (const name of ['playwright', '@playwright/test', 'playwright-core']) {
      try {
        const mod = createRequire(resolve(root, 'noop.js'))(name);
        if (mod.chromium) return mod.chromium;
      } catch { /* try the next location */ }
    }
  }
  throw new Error('Playwright was not found. Install it (npm install playwright) or set AAV_PLAYWRIGHT_PATHS.');
}

const input = arg('input');
const output = arg('output');
const here = import.meta.dirname;
const bundle = arg('bundle', [resolve(here, 'aav-viewer.iife.js'), resolve(here, '..', 'dist-standalone', 'aav-viewer.iife.js')]
  .find((candidate) => existsSync(candidate)));
if (!input || !output || !bundle) {
  console.error('usage: render.mjs --input doc.aav --output out.png [--bundle aav-viewer.iife.js]');
  process.exit(2);
}

const chromium = await loadChromium();
const browser = await chromium.launch();
try {
  const context = await browser.newContext({ offline: true, javaScriptEnabled: true });
  const page = await context.newPage();
  await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body></body></html>');
  await page.addScriptTag({ content: readFileSync(bundle, 'utf-8') });
  const png = await page.evaluate(([data, backend]) => globalThis.AAV.renderToPngBase64(data, backend),
    [readFileSync(input).toString('base64'), arg('backend', 'cpu')]);
  writeFileSync(output, Buffer.from(png, 'base64'));
} catch (error) {
  console.error(String(error?.message ?? error).split('\n')[0]);
  process.exitCode = 1;
} finally {
  await browser.close();
}
