"""Permanent redaction export.

Display effects such as ``pixelate`` and ``blur`` are reversible: the original
pixels stay in the archive and anyone can extract them. This module instead
produces a *new* document in which the chosen regions have been destroyed in
every distributed image:

1. every image layer's source asset has the region area replaced by a solid
   colour (mapped through the layer's placement and transform);
2. all assets are re-encoded as PNG from raw pixels (no EXIF, ICC or text chunks);
3. mask-only assets keep their alpha but lose their colour channels;
4. assets no layer or mask uses, and files the manifest does not reference,
   are dropped;
5. preview and thumbnail are regenerated from the redacted content;
6. the result is verified before it is returned.

Only solid fill is offered. Mosaic or blur "redaction" can leak the underlying
content and is deliberately not provided here.
"""
from __future__ import annotations

import copy
import math
import struct

from . import __version__
from .archive import PREVIEW, Package, complete_assets, referenced_paths, sha256_hex, validate_package
from .errors import AavError, Issue, errors_only
from .geometry import image_matrix, parse_colour
from .render import _pil, decode_image, encode_png, make_thumbnail, render_layer, render_png

_ALLOWED_PNG_CHUNKS = {b"IHDR", b"PLTE", b"tRNS", b"IDAT", b"IEND"}


def region_mask(package: Package, region: dict):
    """Conservative document-space coverage of a region as an 'L' image (255 = inside)."""
    Image, ImageDraw, _ = _pil()
    from PIL import ImageFilter
    doc = package.manifest["document"]
    mask = Image.new("L", (doc["width"], doc["height"]), 0)
    shape = region["shape"]
    draw = ImageDraw.Draw(mask)
    if shape["type"] == "rect":
        draw.rectangle([math.floor(shape["x"]), math.floor(shape["y"]),
                        math.ceil(shape["x"] + shape["width"]) - 1, math.ceil(shape["y"] + shape["height"]) - 1],
                       fill=255)
    elif shape["type"] == "polygon":
        draw.polygon([tuple(p) for p in shape["points"]], fill=255, outline=255)
    else:
        asset = package.manifest["assets"][shape["asset"]]
        alpha = decode_image(package.files[asset["path"]]).getchannel("A")
        x, y = math.floor(shape.get("x", 0)), math.floor(shape.get("y", 0))
        width = max(1, math.ceil(shape.get("width", doc["width"])))
        height = max(1, math.ceil(shape.get("height", doc["height"])))
        if shape.get("hit_test") == "bounds":
            draw.rectangle([x, y, x + width - 1, y + height - 1], fill=255)
        else:
            placed = alpha.resize((width, height), Image.Resampling.BILINEAR).point(lambda v: 255 if v else 0)
            mask.paste(placed, (x, y))
    # One pixel of dilation covers anti-aliased edges.
    return mask.filter(ImageFilter.MaxFilter(3))


def _asset_mask(doc_mask, layer: dict, asset_size: tuple[int, int], doc_size: tuple[int, int]):
    """Map a document-space mask into the pixel grid of an image layer's asset."""
    Image, _, _ = _pil()
    from PIL import ImageFilter
    a, b, c, d, e, f = image_matrix(layer, asset_size[0], asset_size[1], *doc_size)
    stretch = max(abs(a), abs(b), abs(c), abs(d))  # document pixels per asset pixel
    if stretch > 1:
        doc_mask = doc_mask.filter(ImageFilter.MaxFilter(min(2 * math.ceil(stretch) + 1, 255)))
    mapped = doc_mask.transform(asset_size, Image.Transform.AFFINE, (a, c, e, b, d, f),
                                resample=Image.Resampling.BILINEAR)
    return mapped.point(lambda v: 255 if v else 0).filter(ImageFilter.MaxFilter(3))


def _union_masks(package: Package, region_ids: list[str]):
    from PIL import ImageChops
    regions = {r["id"]: r for r in package.manifest.get("regions", [])}
    missing = [rid for rid in region_ids if rid not in regions]
    if missing:
        raise AavError(Issue("E_REF", "/redaction/regions", "unknown region(s): " + ", ".join(missing)))
    union = None
    for rid in region_ids:
        mask = region_mask(package, regions[rid])
        union = mask if union is None else ImageChops.lighter(union, mask)
    return union


def _asset_usage(manifest: dict) -> tuple[set[str], set[str]]:
    layer_assets = {layer["asset"] for layer in manifest["layers"] if layer["type"] == "image"}
    mask_assets = {r["shape"]["asset"] for r in manifest.get("regions", []) if r["shape"]["type"] == "mask"}
    return layer_assets, mask_assets


def redact(package: Package, region_ids: list[str], *, colour: str = "#000000", engine: str = "auto") -> Package:
    """Return a new package with the given regions permanently removed. Raises if verification fails."""
    Image, _, _ = _pil()
    from PIL import ImageChops
    if not region_ids:
        raise AavError("redaction needs at least one region id")
    issues = validate_package(package)
    if errors_only(issues):
        raise AavError(errors_only(issues))
    fill = parse_colour(colour)[:3] + (255,)
    out = Package(copy.deepcopy(package.manifest), {})
    manifest = out.manifest
    doc_size = (manifest["document"]["width"], manifest["document"]["height"])
    doc_mask = _union_masks(package, region_ids)
    layer_assets, mask_assets = _asset_usage(manifest)

    asset_masks: dict[str, object] = {}
    for layer in manifest["layers"]:
        if layer["type"] != "image":
            continue
        asset = manifest["assets"][layer["asset"]]
        size = (asset.get("width"), asset.get("height"))
        if None in size:
            size = decode_image(package.files[asset["path"]]).size
        mask = _asset_mask(doc_mask, layer, size, doc_size)
        previous = asset_masks.get(layer["asset"])
        asset_masks[layer["asset"]] = mask if previous is None else ImageChops.lighter(previous, mask)

    new_assets: dict[str, dict] = {}
    for aid, asset in manifest.get("assets", {}).items():
        if aid not in layer_assets and aid not in mask_assets:
            continue  # unused: a possible hidden original, so it is not carried over
        image = decode_image(package.files[asset["path"]])
        if aid in layer_assets:
            image.paste(Image.new("RGBA", image.size, fill), (0, 0), asset_masks[aid])
        else:
            white = Image.new("RGBA", image.size, (255, 255, 255, 0))
            white.putalpha(image.getchannel("A"))
            image = white
        folder = asset["path"].split("/")[0]
        path = f"{folder}/{aid}.png"
        out.files[path] = encode_png(image)
        new_assets[aid] = {"path": path, "media_type": "image/png"}
    manifest["assets"] = new_assets
    manifest.pop("thumbnail", None)
    manifest["redaction"] = {"method": "fill", "colour": "#%02X%02X%02X" % fill[:3], "regions": list(region_ids),
                             "tool": f"aav-python {__version__}"}
    complete_assets(out)
    out.files[PREVIEW], _ = render_png(out, engine)
    thumb_path, thumb = make_thumbnail(out.files[PREVIEW])
    manifest["thumbnail"] = thumb_path
    out.files[thumb_path] = thumb

    problems = verify_redaction(package, out)
    if problems:
        raise AavError(problems)
    return out


def _png_chunks(data: bytes) -> list[bytes]:
    names, pos = [], 8
    while pos + 8 <= len(data):
        length = struct.unpack(">I", data[pos:pos + 4])[0]
        names.append(data[pos + 4:pos + 8])
        pos += 12 + length
    return names


def verify_redaction(original: Package, redacted: Package) -> list[Issue]:
    """Check that ``redacted`` carries no recoverable copy of the redacted areas of ``original``.

    Returns a list of problems; an empty list means every check passed.
    """
    from PIL import ImageChops, ImageFilter
    issues: list[Issue] = [i for i in validate_package(redacted, strict=True) if i.severity == "error"]
    record = redacted.manifest.get("redaction")
    if issues or not isinstance(record, dict) or not record.get("regions"):
        return issues or [Issue("E_REDACTION", "/redaction", "document has no redaction record")]
    manifest = redacted.manifest
    fill = parse_colour(record.get("colour", "#000000"))[:3] + (255,)
    doc_size = (manifest["document"]["width"], manifest["document"]["height"])
    doc_mask = _union_masks(redacted, record["regions"])
    layer_assets, mask_assets = _asset_usage(manifest)

    # 1. No unused assets, no unreferenced files (strict validation covered files).
    for aid in manifest.get("assets", {}):
        if aid not in layer_assets and aid not in mask_assets:
            issues.append(Issue("E_REDACTION", f"/assets/{aid}", "asset is not used by any layer or mask"))
    extra = set(redacted.files) - referenced_paths(manifest)
    for name in sorted(extra):
        issues.append(Issue("E_REDACTION", name, "unreferenced file present"))

    # 2. No byte-identical copy of an original file that showed redacted content survives.
    #    An original is "sensitive" if its pixels under the regions were not already the fill
    #    colour; the original preview and thumbnail are sensitive whenever any asset is.
    sensitive: dict[str, str] = {}
    try:
        original_mask = _union_masks(original, record["regions"])
        original_doc = (original.manifest["document"]["width"], original.manifest["document"]["height"])
        for layer in original.manifest["layers"]:
            if layer["type"] != "image":
                continue
            path = original.manifest["assets"][layer["asset"]]["path"]
            image = decode_image(original.files[path])
            mask = _asset_mask(original_mask, layer, image.size, original_doc)
            from PIL import Image
            diff = ImageChops.difference(image, Image.new("RGBA", image.size, fill)).convert("L")
            if ImageChops.multiply(diff.point(lambda v: 255 if v else 0), mask).getbbox() is not None:
                sensitive[sha256_hex(original.files[path])] = path
        if sensitive:
            used_original = referenced_paths(original.manifest)
            for name, data in original.files.items():
                if name == PREVIEW or name.startswith("thumbnails/") or name not in used_original:
                    sensitive[sha256_hex(data)] = name
    except (KeyError, AavError, OSError):
        sensitive = {sha256_hex(data): name for name, data in original.files.items()}
    for name, data in redacted.files.items():
        source = sensitive.get(sha256_hex(data))
        if source is not None:
            issues.append(Issue("E_REDACTION", name, f"file is byte-identical to original '{source}', which "
                                                     "shows redacted content"))

    # 3. Every asset is a metadata-free PNG.
    for name, data in redacted.files.items():
        if name.startswith(("assets/", "masks/")) or name == PREVIEW:
            if data[:8] != b"\x89PNG\r\n\x1a\n":
                issues.append(Issue("E_REDACTION", name, "redacted exports must contain PNG images only"))
                continue
            stray = sorted({c.decode("latin-1") for c in _png_chunks(data)} -
                           {c.decode("latin-1") for c in _ALLOWED_PNG_CHUNKS})
            if stray:
                issues.append(Issue("E_REDACTION", name, "PNG carries extra chunks: " + ", ".join(stray)))

    # 4. In asset space: every pixel under the mapped region equals the fill colour.
    fill_image_cache: dict[tuple[int, int], object] = {}
    for layer in manifest["layers"]:
        if layer["type"] != "image":
            continue
        asset = manifest["assets"][layer["asset"]]
        image = decode_image(redacted.files[asset["path"]])
        mask = _asset_mask(doc_mask, layer, image.size, doc_size)
        from PIL import Image
        solid = fill_image_cache.setdefault(image.size, Image.new("RGBA", image.size, fill))
        diff = ImageChops.difference(image, solid).convert("L").point(lambda v: 255 if v else 0)
        if ImageChops.multiply(diff, mask).getbbox() is not None:
            issues.append(Issue("E_REDACTION", f"/layers/{layer['id']}",
                                "asset pixels inside a redacted region differ from the fill colour"))

    # 5. Independently, in document space: each rendered image layer shows only the fill
    #    colour well inside the regions (3 px erosion absorbs resampling at the edges).
    core = doc_mask.filter(ImageFilter.MinFilter(7))
    if core.getbbox() is not None:
        for layer in manifest["layers"]:
            if layer["type"] != "image":
                continue
            plain = dict(layer, opacity=1)
            plain.pop("clip", None)
            rendered = render_layer(redacted, plain)
            visible = rendered.getchannel("A").point(lambda v: 255 if v > 250 else 0)
            from PIL import Image
            solid = Image.new("RGBA", rendered.size, fill)
            diff = ImageChops.difference(rendered.convert("RGB"), solid.convert("RGB")).convert("L")
            diff = diff.point(lambda v: 255 if v > 2 else 0)
            if ImageChops.multiply(ImageChops.multiply(diff, core), visible).getbbox() is not None:
                issues.append(Issue("E_REDACTION", f"/layers/{layer['id']}",
                                    "rendered layer still shows non-fill pixels inside a redacted region"))
    return issues
