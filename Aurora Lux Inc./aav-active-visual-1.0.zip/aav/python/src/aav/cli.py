"""Command line interface: ``aav <command>``."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .archive import (MANIFEST, PREVIEW, Package, complete_assets, load_unvalidated, read_archive, read_zip,
                      sha256_hex, sniff_image, validate_package, write_archive)
from .document import Document
from .errors import AavError, Issue, errors_only
from .htmlexport import export_html
from .limits import MEDIA_TYPE
from .manifest import canonical_json, parse_manifest
from .migrate import migrate
from .redact import redact
from .render import make_thumbnail, render_png


def _print_issues(issues: list[Issue], stream=sys.stderr) -> None:
    for issue in issues:
        print(f"  {issue}", file=stream)


def cmd_create(args) -> int:
    doc = Document.create(args.image, title=args.title, doc_id=args.id, description=args.description or "")
    doc.save(args.output, engine="basic")
    print(f"created {args.output} ({doc.manifest['document']['width']}x{doc.manifest['document']['height']}, "
          f"1 layer, 0 regions)")
    return 0


def cmd_validate(args) -> int:
    status = 0
    for path in args.files:
        try:
            _, warnings = read_archive(path, strict=args.strict)
        except AavError as exc:
            status = 1
            if args.json:
                print(json.dumps({"file": path, "valid": False, "issues": [i.to_dict() for i in exc.issues]}))
            else:
                print(f"{path}: INVALID ({len(errors_only(exc.issues))} error(s))")
                _print_issues(exc.issues, sys.stdout)
            continue
        except OSError as exc:
            print(f"{path}: cannot read: {exc}", file=sys.stderr)
            status = 2
            continue
        if args.json:
            print(json.dumps({"file": path, "valid": True, "issues": [i.to_dict() for i in warnings]}))
        else:
            print(f"{path}: valid" + (f" ({len(warnings)} warning(s))" if warnings else ""))
            _print_issues(warnings, sys.stdout)
    return status


def _links(manifest: dict) -> list[dict]:
    from .links import text_links
    out = []

    def scan(actions, where):
        for action in actions or []:
            if action.get("action") == "open_link":
                out.append({"where": where, "kind": "external", "target": action["url"]})
            elif action.get("action") == "navigate_document":
                out.append({"where": where, "kind": "document", "target": action["href"]})

    for region in manifest.get("regions", []):
        for trigger, actions in region.get("events", {}).items():
            scan(actions, f"region {region['id']} ({trigger})")
    for pid, panel in manifest.get("panels", {}).items():
        for _label, target in text_links(panel["text"]):
            kind = "internal" if target.startswith("#") else "external"
            out.append({"where": f"panel {pid}", "kind": kind, "target": target})
    return out


def cmd_inspect(args) -> int:
    package, warnings = read_archive(args.file)
    m = package.manifest
    doc = m["document"]
    files = [{"path": MANIFEST, "bytes": len(canonical_json(m))}]
    for name in sorted(package.files):
        info = sniff_image(package.files[name])
        files.append({"path": name, "bytes": len(package.files[name]), "sha256": sha256_hex(package.files[name]),
                      **({"image": f"{info[0]} {info[1]}x{info[2]}"} if info else {})})
    summary = {
        "file": str(args.file), "format": m["format"], "version": m["version"],
        "provisional_media_type": MEDIA_TYPE, "document": doc, "metadata": m.get("metadata", {}),
        "layers": [{"id": l["id"], "type": l["type"], "visible": l.get("visible", True)} for l in m["layers"]],
        "regions": [{"id": r["id"], "label": r["label"], "shape": r["shape"]["type"],
                     "target_layer": r.get("target_layer"),
                     "effects": {k: v["type"] for k, v in r.get("effects", {}).items()},
                     "triggers": sorted(r.get("events", {}))} for r in m.get("regions", [])],
        "groups": sorted(m.get("groups", {})), "panels": sorted(m.get("panels", {})),
        "animations": sorted(m.get("animations", {})), "links": _links(m),
        "redaction": m.get("redaction"), "files": files, "warnings": [i.to_dict() for i in warnings],
    }
    if args.json:
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        return 0
    print(f"{args.file}: {m['format']} {m['version']}")
    print(f"  title:       {doc['title']}  (id {doc['id']})")
    print(f"  canvas:      {doc['width']} x {doc['height']} px, {doc.get('colour_space', 'srgb')}")
    if doc.get("description"):
        print(f"  description: {doc['description']}")
    for key, value in summary["metadata"].items():
        print(f"  {key + ':':<12} {value}")
    print(f"  layers ({len(m['layers'])}):")
    for layer in summary["layers"]:
        print(f"    - {layer['id']} [{layer['type']}]" + ("" if layer["visible"] else " (hidden)"))
    print(f"  regions ({len(summary['regions'])}):")
    for region in summary["regions"]:
        effects = ", ".join(f"{k}:{v}" for k, v in region["effects"].items()) or "none"
        print(f"    - {region['id']} \"{region['label']}\" [{region['shape']}] effects: {effects}; "
              f"triggers: {', '.join(region['triggers']) or 'none'}")
    for name in ("groups", "panels", "animations"):
        if summary[name]:
            print(f"  {name}: {', '.join(summary[name])}")
    print(f"  links ({len(summary['links'])}):")
    for link in summary["links"]:
        print(f"    - [{link['kind']}] {link['target']}  <- {link['where']}")
    if summary["redaction"]:
        print(f"  redaction:   {summary['redaction']['method']} over {', '.join(summary['redaction']['regions'])}")
    print("  files:")
    for entry in files:
        extra = f"  {entry['image']}" if "image" in entry else ""
        print(f"    {entry['bytes']:>10}  {entry['path']}{extra}")
    _print_issues(warnings, sys.stdout)
    return 0


def cmd_extract(args) -> int:
    package, _ = read_archive(args.file)
    out = Path(args.output)
    if out.exists() and any(out.iterdir()) and not args.force:
        print(f"aav: output directory '{out}' is not empty (use --force)", file=sys.stderr)
        return 2
    root = out.resolve()
    files = {MANIFEST: canonical_json(package.manifest), **package.files}
    for name, data in files.items():
        target = (root / name).resolve()
        if root not in target.parents:  # defence in depth; names were already validated
            raise AavError(Issue("E_ARCHIVE_PATH", name, "entry would be written outside the output directory"))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print(f"extracted {len(files)} file(s) to {out}")
    return 0


def cmd_render(args) -> int:
    package, _ = read_archive(args.file)
    data, used = render_png(package, args.engine)
    Path(args.output).write_bytes(data)
    note = "" if used == "browser" else " (layers only; region effects are not applied by the basic engine)"
    print(f"rendered {args.output} with the {used} engine{note}")
    return 0


def cmd_pack(args) -> int:
    root = Path(args.directory)
    manifest_path = root / MANIFEST
    if not manifest_path.is_file():
        print(f"aav: {manifest_path} not found", file=sys.stderr)
        return 2
    manifest = parse_manifest(manifest_path.read_bytes())
    files: dict[str, bytes] = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise AavError(Issue("E_ARCHIVE_PATH", str(path), "symbolic links are not packed"))
        if path.is_file() and path != manifest_path:
            files[path.relative_to(root).as_posix()] = path.read_bytes()
    doc = Document(manifest, files)
    used = doc.finalise(engine=args.engine, keep_preview=not args.render_preview)
    write_archive(doc.package(), args.output, strict=not args.allow_extra_files)
    print(f"packed {args.output} ({len(doc.files) + 1} files; preview: {used})")
    return 0


def cmd_redact(args) -> int:
    package, _ = read_archive(args.file)
    result = redact(package, args.region, colour=args.colour, engine=args.engine)
    write_archive(result, args.output, strict=True)
    print(f"wrote {args.output}: {len(args.region)} region(s) permanently filled with "
          f"{result.manifest['redaction']['colour']}; verification passed")
    print("  note: all assets were re-encoded as PNG and unused files were removed.")
    return 0


def cmd_export_html(args) -> int:
    package, _ = read_archive(args.file)
    Path(args.output).write_text(export_html(package), "utf-8")
    print(f"wrote {args.output} (self-contained; opens from disk without a server)")
    return 0


def cmd_migrate(args) -> int:
    files = read_zip(Path(args.file).read_bytes())
    if MANIFEST not in files:
        raise AavError(Issue("E_ARCHIVE_MISSING", MANIFEST, "manifest.json is missing"))
    manifest, steps = migrate(parse_manifest(files.pop(MANIFEST)))
    package = Package(manifest, files)
    complete_assets(package)
    if PREVIEW not in files:
        package.files[PREVIEW], _ = render_png(package, "basic")
    if "thumbnail" not in manifest:
        manifest["thumbnail"], data = make_thumbnail(package.files[PREVIEW])
        package.files[manifest["thumbnail"]] = data
    write_archive(package, args.output, strict=False)
    print(f"wrote {args.output}; migrations applied: {', '.join(steps) or 'none (already current)'}")
    return 0


def cmd_serve(args) -> int:
    import functools
    import http.server

    class Handler(http.server.SimpleHTTPRequestHandler):
        extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, ".aav": MEDIA_TYPE,
                          ".mjs": "text/javascript", ".js": "text/javascript"}

        def end_headers(self):
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Cache-Control", "no-store")
            super().end_headers()

    handler = functools.partial(Handler, directory=args.directory)
    with http.server.ThreadingHTTPServer((args.host, args.port), handler) as server:
        print(f"serving {args.directory} at http://{args.host}:{args.port}/ (Ctrl+C to stop)")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print()
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aav", description="Create, inspect and convert .aav Active Visual "
                                                             "documents (a proposed custom format).")
    parser.add_argument("--version", action="version", version=f"aav {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)
    engine = {"choices": ["auto", "basic", "browser"], "default": "auto",
              "help": "static renderer: 'browser' is full fidelity (needs Node.js + Playwright), 'basic' draws "
                      "layers only"}

    p = sub.add_parser("create", help="start a document from an image")
    p.add_argument("image")
    p.add_argument("--output", "-o", required=True)
    p.add_argument("--title")
    p.add_argument("--id")
    p.add_argument("--description")
    p.set_defaults(func=cmd_create)

    p = sub.add_parser("validate", help="check one or more .aav files")
    p.add_argument("files", nargs="+")
    p.add_argument("--strict", action="store_true", help="treat unreferenced files and incomplete asset records "
                                                         "as errors")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("inspect", help="describe a document, including every link destination")
    p.add_argument("file")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_inspect)

    p = sub.add_parser("extract", help="unpack a document into a directory")
    p.add_argument("file")
    p.add_argument("--output", "-o", required=True)
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_extract)

    p = sub.add_parser("render", help="render the default state to PNG")
    p.add_argument("file")
    p.add_argument("--output", "-o", required=True)
    p.add_argument("--engine", **engine)
    p.set_defaults(func=cmd_render)

    p = sub.add_parser("pack", help="pack a directory containing manifest.json")
    p.add_argument("directory")
    p.add_argument("--output", "-o", required=True)
    p.add_argument("--engine", **engine)
    p.add_argument("--render-preview", action="store_true", help="regenerate preview.png even if one exists")
    p.add_argument("--allow-extra-files", action="store_true", help="keep files the manifest does not reference")
    p.set_defaults(func=cmd_pack)

    p = sub.add_parser("redact", help="permanently destroy regions in a new copy (not reversible)")
    p.add_argument("file")
    p.add_argument("--output", "-o", required=True)
    p.add_argument("--region", "-r", action="append", required=True, help="region id; repeat for several")
    p.add_argument("--colour", default="#000000")
    p.add_argument("--engine", **engine)
    p.set_defaults(func=cmd_redact)

    p = sub.add_parser("export-html", help="write a self-contained HTML page with the viewer embedded")
    p.add_argument("file")
    p.add_argument("--output", "-o", required=True)
    p.set_defaults(func=cmd_export_html)

    p = sub.add_parser("migrate", help="upgrade a pre-release draft document to the current schema")
    p.add_argument("file")
    p.add_argument("--output", "-o", required=True)
    p.set_defaults(func=cmd_migrate)

    p = sub.add_parser("serve", help="serve a directory over HTTP for local viewing")
    p.add_argument("directory", nargs="?", default=".")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8137)
    p.set_defaults(func=cmd_serve)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except AavError as exc:
        print(f"aav: {len(exc.issues)} problem(s):", file=sys.stderr)
        _print_issues(exc.issues)
        return 1
    except OSError as exc:
        print(f"aav: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
