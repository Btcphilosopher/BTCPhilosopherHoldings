"""High-level authoring API.

    from aav import Document

    doc = Document.create("building.png", title="Interactive Building")
    doc.add_region("window-01", "First-floor window", Document.rect(400, 220, 120, 160),
                   target_layer="background",
                   effects={"illumination": {"type": "glow", "colour": "#FFD47A", "intensity": 0}},
                   events={"activate": [{"action": "open_panel", "panel": "room"}]})
    doc.add_panel("room", "First-floor room", "Example information about this space.")
    doc.save("building.aav")
"""
from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import Any

from . import __version__
from .archive import PLACEHOLDER_PNG, PREVIEW, Package, complete_assets, read_archive, sniff_image, validate_package, write_archive
from .errors import AavError, Issue
from .limits import FORMAT, LIMITS, VERSION
from .render import make_thumbnail, render_png

_EXT = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}
_SLUG = re.compile(r"[^A-Za-z0-9._-]+")


def slugify(text: str, fallback: str = "document") -> str:
    slug = _SLUG.sub("-", text.strip()).strip("-._").lower()[:64]
    return slug or fallback


class Document:
    """A mutable AAV document: a manifest dict plus packaged files."""

    def __init__(self, manifest: dict, files: dict[str, bytes] | None = None):
        self.manifest = manifest
        self.files: dict[str, bytes] = files or {}

    # ------------------------------------------------------------------ construction
    @classmethod
    def new(cls, width: int, height: int, *, title: str, doc_id: str | None = None,
            description: str = "") -> "Document":
        manifest: dict[str, Any] = {
            "format": FORMAT,
            "version": VERSION,
            "document": {"id": doc_id or slugify(title), "title": title, "width": width, "height": height,
                         "colour_space": "srgb"},
            "metadata": {"generator": f"aav-python {__version__}"},
            "assets": {},
            "layers": [],
            "regions": [],
            "panels": {},
            "preview": PREVIEW,
        }
        if description:
            manifest["document"]["description"] = description
        return cls(manifest)

    @classmethod
    def create(cls, image: str | Path | bytes, *, title: str | None = None, doc_id: str | None = None,
               description: str = "") -> "Document":
        """Start a document from one image, which becomes the full-size 'background' layer."""
        data = image if isinstance(image, (bytes, bytearray)) else Path(image).read_bytes()
        info = sniff_image(bytes(data))
        if info is None:
            raise AavError(Issue("E_ASSET_TYPE", str(image)[:80] if not isinstance(image, bytes) else "image",
                                 "input is not a PNG, JPEG or WebP image"))
        _, width, height = info
        m = LIMITS["manifest"]
        if width > m["max_dimension"] or height > m["max_dimension"] or width * height > m["max_document_pixels"]:
            raise AavError(Issue("E_LIMIT", "/document", f"image is {width}x{height}; documents are limited to "
                                                         f"{m['max_dimension']} px per side and "
                                                         f"{m['max_document_pixels']} pixels"))
        if title is None:
            title = Path(image).stem if not isinstance(image, (bytes, bytearray)) else "Untitled"
        doc = cls.new(width, height, title=title, doc_id=doc_id, description=description)
        doc.add_asset("base", bytes(data))
        doc.add_image_layer("background", "base", name="Background")
        return doc

    @classmethod
    def open(cls, path: str | Path | bytes) -> "Document":
        package, _ = read_archive(path)
        return cls(package.manifest, package.files)

    # ------------------------------------------------------------------ building blocks
    def add_asset(self, asset_id: str, data: bytes, *, folder: str = "assets", filename: str | None = None) -> str:
        info = sniff_image(data)
        if info is None:
            raise AavError(Issue("E_ASSET_TYPE", asset_id, "asset is not a PNG, JPEG or WebP image"))
        media_type, width, height = info
        path = f"{folder}/{filename or asset_id + '.' + _EXT[media_type]}"
        self.manifest.setdefault("assets", {})[asset_id] = {"path": path, "media_type": media_type}
        self.files[path] = data
        return asset_id

    def add_image_layer(self, layer_id: str, asset: str, **props: Any) -> dict:
        layer = {"id": layer_id, "type": "image", "asset": asset, **props}
        self.manifest["layers"].append(layer)
        return layer

    def add_text_layer(self, layer_id: str, text: str, x: float, y: float, **props: Any) -> dict:
        layer = {"id": layer_id, "type": "text", "text": text, "x": x, "y": y, **props}
        self.manifest["layers"].append(layer)
        return layer

    @staticmethod
    def rect(x: float, y: float, width: float, height: float) -> dict:
        return {"type": "rect", "x": x, "y": y, "width": width, "height": height}

    @staticmethod
    def polygon(points: list[tuple[float, float]]) -> dict:
        return {"type": "polygon", "points": [[px, py] for px, py in points]}

    @staticmethod
    def mask(asset: str, **placement: Any) -> dict:
        return {"type": "mask", "asset": asset, **placement}

    def add_region(self, region_id: str, label: str, shape: dict, **props: Any) -> dict:
        region = {"id": region_id, "label": label, "shape": shape, **props}
        self.manifest.setdefault("regions", []).append(region)
        return region

    def add_group(self, group_id: str, label: str, regions: list[str], **props: Any) -> dict:
        group = {"label": label, "regions": list(regions), **props}
        self.manifest.setdefault("groups", {})[group_id] = group
        return group

    def add_panel(self, panel_id: str, title: str, text: str) -> dict:
        panel = {"title": title, "text": text}
        self.manifest.setdefault("panels", {})[panel_id] = panel
        return panel

    def add_animation(self, animation_id: str, **props: Any) -> dict:
        self.manifest.setdefault("animations", {})[animation_id] = props
        return props

    def region(self, region_id: str) -> dict:
        for region in self.manifest.get("regions", []):
            if region.get("id") == region_id:
                return region
        raise KeyError(region_id)

    # ------------------------------------------------------------------ output
    def package(self) -> Package:
        return Package(self.manifest, self.files)

    def validate(self, *, strict: bool = False) -> list[Issue]:
        return validate_package(self.package(), strict=strict)

    def finalise(self, *, engine: str = "auto", keep_preview: bool = False) -> str:
        """Complete asset records and (re)build preview and thumbnail. Returns the engine used."""
        package = self.package()
        complete_assets(package)
        used = "kept"
        if not (keep_preview and PREVIEW in self.files):
            # The manifest must be valid before a renderer is pointed at it.
            probe = Package(copy.deepcopy(self.manifest), {**self.files, PREVIEW: PLACEHOLDER_PNG})
            probe.manifest.pop("thumbnail", None)
            errors = [i for i in validate_package(probe) if i.severity == "error"]
            if errors:
                raise AavError(errors)
            self.files[PREVIEW], used = render_png(package, engine)
        old = self.manifest.get("thumbnail")
        if old:
            self.files.pop(old, None)
        path, data = make_thumbnail(self.files[PREVIEW])
        self.manifest["thumbnail"] = path
        self.files[path] = data
        self.manifest["preview"] = PREVIEW
        return used

    def save(self, path: str | Path, *, engine: str = "auto", keep_preview: bool = False) -> bytes:
        """Finalise, validate strictly and write a deterministic .aav file."""
        self.finalise(engine=engine, keep_preview=keep_preview)
        return write_archive(self.package(), path, strict=True)

