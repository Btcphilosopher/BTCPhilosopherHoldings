"""Version migration.

Schema 1.0 is the first published version. The only migration shipped is from
the unpublished pre-release draft ("0.9") used while the format was being
designed; it exists mainly to exercise and document the mechanism:

* ``hotspots``            -> ``regions``
* ``document.size: [w,h]``-> ``document.width`` / ``document.height``
* ``color`` keys          -> ``colour``

Rules for future versions are in docs/SPEC.md section 13.
"""
from __future__ import annotations

import copy
from typing import Any, Callable

from .errors import AavError, Issue
from .limits import FORMAT, VERSION


def _rename_key(value: Any, old: str, new: str) -> Any:
    if isinstance(value, dict):
        return {(new if k == old else k): _rename_key(v, old, new) for k, v in value.items()}
    if isinstance(value, list):
        return [_rename_key(v, old, new) for v in value]
    return value


def _from_0_9(manifest: dict) -> dict:
    out = _rename_key(manifest, "color", "colour")
    if "hotspots" in out:
        out["regions"] = out.pop("hotspots")
    doc = out.get("document")
    if isinstance(doc, dict) and isinstance(doc.get("size"), list) and len(doc["size"]) == 2:
        doc["width"], doc["height"] = doc.pop("size")
    out["version"] = "1.0"
    return out


MIGRATIONS: dict[str, Callable[[dict], dict]] = {"0.9": _from_0_9}


def migrate(manifest: dict) -> tuple[dict, list[str]]:
    """Upgrade a manifest to the current version. Returns (manifest, steps applied)."""
    if not isinstance(manifest, dict) or manifest.get("format") != FORMAT:
        raise AavError(Issue("E_FORMAT", "/format", f"format must be '{FORMAT}'"))
    out = copy.deepcopy(manifest)
    steps: list[str] = []
    while out.get("version") in MIGRATIONS:
        before = out["version"]
        out = MIGRATIONS[before](out)
        steps.append(f"{before} -> {out['version']}")
    if not steps and str(out.get("version", "")).split(".")[0] != VERSION.split(".")[0]:
        raise AavError(Issue("E_VERSION", "/version", f"no migration path from version {out.get('version')!r}"))
    return out, steps
