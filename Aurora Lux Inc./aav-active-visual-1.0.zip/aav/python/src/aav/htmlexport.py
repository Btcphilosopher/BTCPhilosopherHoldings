"""Standalone HTML export: one file containing the viewer, its styles and the document."""
from __future__ import annotations

import base64
import hashlib
import html
import re
from importlib import resources

from .archive import MANIFEST, PREVIEW, Package, write_zip
from .errors import AavError
from .manifest import canonical_json


def _data(name: str) -> str:
    path = resources.files("aav").joinpath("data", name)
    if not path.is_file():
        raise AavError(f"bundled viewer file '{name}' is missing; run 'npm run build' in web/ to embed it")
    return path.read_text("utf-8")


def build_standalone_html(template: str, script: str, style: str, title: str, description: str, language: str,
                          region_labels: list[str], preview_png: bytes, archive: bytes) -> str:
    """Fill the standalone template. Mirrors web/src/core/htmlexport.ts."""
    script = script.replace("</script", "<\\/script")
    digest = base64.b64encode(hashlib.sha256(script.encode("utf-8")).digest()).decode("ascii")
    regions = "".join(f"<li>{html.escape(label)}</li>" for label in region_labels)
    values = {
        "LANG": html.escape(language, quote=True),
        "TITLE": html.escape(title),
        "DESCRIPTION": html.escape(description, quote=True),
        "SCRIPT_HASH": digest,
        "STYLE": style.replace("</style", "<\\/style"),
        "REGIONS": regions,
        "PREVIEW": base64.b64encode(preview_png).decode("ascii"),
        "ARCHIVE": base64.b64encode(archive).decode("ascii"),
        "SCRIPT": script,
    }
    # Single pass, so text substituted for one placeholder is never scanned for another.
    return re.sub(r"\{\{([A-Z_]+)\}\}", lambda m: values.get(m.group(1), m.group(0)), template)


def export_html(package: Package) -> str:
    doc = package.manifest["document"]
    labels = [r["label"] for r in package.manifest.get("regions", []) if r.get("interactive", True)]
    archive = write_zip({MANIFEST: canonical_json(package.manifest), **package.files})
    return build_standalone_html(_data("standalone-template.html"), _data("aav-viewer.iife.js"),
                                 _data("aav-viewer.css"), doc["title"], doc.get("description", ""),
                                 doc.get("language", "en"), labels, package.files[PREVIEW], archive)
