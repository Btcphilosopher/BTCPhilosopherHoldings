"""Link and restricted-text rules. Mirrors web/src/core/links.ts and text.ts."""
from __future__ import annotations

import re

from .limits import LIMITS

_MAX_URL = LIMITS["manifest"]["max_url"]
_AUTHORITY = re.compile(r"^[A-Za-z0-9.-]+(:[0-9]{1,5})?$")
_REL_SEGMENT = re.compile(r"^[A-Za-z0-9._~-]+$")

# Inline token grammar of AAV text. The same expression is used in text.ts.
INLINE_TOKEN = re.compile(
    r"(\\[\\*\[\]`()])|(`[^`\n]+`)|(\*\*[^*\n]+\*\*)|(\*[^*\n]+\*)|(\[[^\]\n]*\]\([^)\s]*\))"
)
_LINK = re.compile(r"^\[([^\]\n]*)\]\(([^)\s]*)\)$")


def external_url_problem(url: object) -> str | None:
    """Return why ``url`` is not an acceptable external link, or None if it is."""
    if not isinstance(url, str):
        return "URL must be a string"
    if len(url) > _MAX_URL:
        return f"URL is longer than {_MAX_URL} characters"
    if any(ord(c) <= 0x20 or ord(c) == 0x7F for c in url) or "\\" in url:
        return "URL contains whitespace, control characters or a backslash"
    if not url.startswith("https://"):
        return "only https:// URLs are allowed"
    authority = re.split(r"[/?#]", url[len("https://"):], maxsplit=1)[0]
    if "@" in authority:
        return "URLs with embedded credentials are not allowed"
    if not _AUTHORITY.match(authority) or authority.startswith(".") or ".." in authority:
        return "URL host is missing or malformed"
    port = authority.partition(":")[2]
    if port and int(port) > 65535:
        return "URL port is out of range"
    return None


def document_href_problem(href: object) -> str | None:
    """Validate a ``navigate_document`` target: https URL or relative .aav path."""
    if not isinstance(href, str) or not href:
        return "href must be a non-empty string"
    if href.startswith("https://"):
        return external_url_problem(href)
    if len(href) > _MAX_URL:
        return f"href is longer than {_MAX_URL} characters"
    if not href.endswith(".aav"):
        return "relative document links must end in .aav"
    for segment in href.split("/"):
        if segment in ("", ".", "..") or not _REL_SEGMENT.match(segment):
            return "relative document links must be plain forward-slash paths without '..', schemes or queries"
    return None


def text_links(text: str) -> list[tuple[str, str]]:
    """Return (label, target) for every link token in a restricted-text string."""
    out = []
    for match in INLINE_TOKEN.finditer(text):
        if match.group(5):
            label, target = _LINK.match(match.group(5)).groups()
            out.append((label, target))
    return out
