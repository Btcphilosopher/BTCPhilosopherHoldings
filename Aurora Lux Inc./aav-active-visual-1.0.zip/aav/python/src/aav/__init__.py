"""AAV (Active Visual): authoring library for the proposed .aav interactive image container."""
__version__ = "1.0.0"

from .archive import (Package, load_unvalidated, read_archive, read_zip, sha256_hex, sniff_image,  # noqa: E402
                      validate_package, write_archive, write_zip)
from .document import Document  # noqa: E402
from .errors import AavError, Issue, errors_only  # noqa: E402
from .limits import EFFECT_SPECS, FORMAT, LIMITS, MEDIA_TYPE, VERSION  # noqa: E402
from .manifest import canonical_json, parse_manifest, validate_manifest  # noqa: E402
from .migrate import migrate  # noqa: E402
from .redact import redact, verify_redaction  # noqa: E402

__all__ = [
    "AavError", "Document", "EFFECT_SPECS", "FORMAT", "Issue", "LIMITS", "MEDIA_TYPE", "Package", "VERSION",
    "canonical_json", "errors_only", "load_unvalidated", "migrate", "parse_manifest", "read_archive", "read_zip",
    "redact", "sha256_hex", "sniff_image", "validate_manifest", "validate_package", "verify_redaction",
    "write_archive", "write_zip",
]
