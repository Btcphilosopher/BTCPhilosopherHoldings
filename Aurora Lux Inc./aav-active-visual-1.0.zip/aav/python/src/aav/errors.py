"""Issue and exception types shared by every AAV check."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Issue:
    """One validation finding.

    ``code`` is stable and shared with the TypeScript validator (``E_*`` for
    errors, ``W_*`` for warnings). ``path`` is a JSON pointer into the manifest
    or an archive entry name.
    """

    code: str
    path: str
    message: str

    @property
    def severity(self) -> str:
        return "warning" if self.code.startswith("W_") else "error"

    def __str__(self) -> str:
        where = self.path or "/"
        return f"{self.severity}: {self.code} at {where}: {self.message}"

    def to_dict(self) -> dict:
        return {"code": self.code, "severity": self.severity, "path": self.path, "message": self.message}


class AavError(Exception):
    """Raised when a document cannot be read or fails validation."""

    def __init__(self, issues: list[Issue] | Issue | str):
        if isinstance(issues, str):
            issues = [Issue("E_INTERNAL", "", issues)]
        elif isinstance(issues, Issue):
            issues = [issues]
        self.issues = issues
        super().__init__("; ".join(str(i) for i in issues[:5]) + (" ..." if len(issues) > 5 else ""))


def errors_only(issues: list[Issue]) -> list[Issue]:
    return [i for i in issues if i.severity == "error"]
