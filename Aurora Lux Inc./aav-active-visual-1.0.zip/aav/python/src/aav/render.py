"""Static rendering.

Two engines exist:

* ``basic``: a Pillow compositor. Draws image and text layers with visibility,
  opacity, placement, transforms and clips. It does NOT apply region effects,
  and text uses Pillow's built-in face, so glyph shapes differ from browsers.
* ``browser``: runs the TypeScript reference renderer in headless Chromium via
  Node.js and Playwright. Full fidelity, including effects in their default
  state. Needs ``node`` and a resolvable ``playwright`` package.

``auto`` uses the browser engine when the document has region effects and the
engine is available, otherwise the basic engine.
"""
from __future__ import annotations

import io
import os
import shutil
import subprocess
import sys
import tempfile
from importlib import resources
from pathlib import Path

from .archive import MANIFEST, PLACEHOLDER_PNG, PREVIEW, Package, write_zip
from .errors import AavError
from .geometry import image_matrix, invert, layer_transform, parse_colour
from .limits import LIMITS
from .manifest import canonical_json


def _pil():
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as exc:  # pragma: no cover
        raise AavError("Pillow is required for rendering: pip install Pillow") from exc
    Image.MAX_IMAGE_PIXELS = LIMITS["image"]["max_dimension"] ** 2
    return Image, ImageDraw, ImageFont


def decode_image(data: bytes):
    Image, _, _ = _pil()
    image = Image.open(io.BytesIO(data))
    image.load()
    return image.convert("RGBA")


def encode_png(image) -> bytes:
    """Encode without metadata chunks, deterministically for a given Pillow/zlib."""
    Image, _, _ = _pil()
    # Rebuild from raw pixels so nothing in image.info (ICC, EXIF, text) can reach the file.
    clean = Image.frombytes("RGBA", image.size, image.convert("RGBA").tobytes())
    out = io.BytesIO()
    clean.save(out, "PNG", optimize=False, compress_level=9)
    return out.getvalue()


def text_lines(layer: dict, measure) -> list[str]:
    """Split on newlines, then greedy word-wrap to max_width if given."""
    lines: list[str] = []
    max_width = layer.get("max_width")
    for raw in layer["text"].split("\n"):
        if max_width is None:
            lines.append(raw)
            continue
        current = ""
        for word in raw.split(" "):
            trial = word if not current else current + " " + word
            if current and measure(trial) > max_width:
                lines.append(current)
                current = word
            else:
                current = trial
        lines.append(current)
    return lines


def _draw_text_layer(layer: dict, size: tuple[int, int]):
    Image, ImageDraw, ImageFont = _pil()
    surface = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(surface)
    font_size = layer.get("font_size", 24)
    font = ImageFont.load_default(size=font_size)
    lines = text_lines(layer, lambda s: draw.textlength(s, font=font))
    line_height = font_size * layer.get("line_height", 1.25)
    width = max((draw.textlength(line, font=font) for line in lines), default=0)
    height = line_height * len(lines)
    align = layer.get("align", "left")
    left = layer["x"] - (width / 2 if align == "centre" else width if align == "right" else 0)
    top = layer["y"]
    if "background" in layer:
        pad = layer.get("padding", 6)
        draw.rectangle([left - pad, top - pad, left + width + pad, top + height + pad],
                       fill=parse_colour(layer["background"]))
    colour = parse_colour(layer.get("colour", "#FFFFFF"))
    for i, line in enumerate(lines):
        line_width = draw.textlength(line, font=font)
        x = left + (width - line_width) * (0.5 if align == "centre" else 1 if align == "right" else 0)
        y = top + i * line_height + (line_height - font_size) / 2
        draw.text((x, y), line, font=font, fill=colour, anchor="la")
    return surface


def render_layer(package: Package, layer: dict):
    """Render one layer onto a transparent document-sized RGBA surface."""
    Image, ImageDraw, _ = _pil()
    doc = package.manifest["document"]
    size = (doc["width"], doc["height"])
    if layer["type"] == "image":
        asset = package.manifest["assets"][layer["asset"]]
        source = decode_image(package.files[asset["path"]])
        matrix = invert(image_matrix(layer, source.width, source.height, *size))
        a, b, c, d, e, f = matrix
        if matrix == (1.0, 0.0, 0.0, 1.0, 0.0, 0.0) and source.size == size:
            surface = source
        else:
            # Pillow samples at pixel centres itself, so the coefficients are the plain inverse map.
            surface = source.transform(size, Image.Transform.AFFINE, (a, c, e, b, d, f),
                                       resample=Image.Resampling.BICUBIC)
    elif layer["type"] == "text":
        surface = _draw_text_layer(layer, size)
        if layer.get("transform"):
            a, b, c, d, e, f = invert(layer_transform(layer, *size))
            surface = surface.transform(size, Image.Transform.AFFINE, (a, c, e, b, d, f),
                                        resample=Image.Resampling.BICUBIC)
    else:
        return Image.new("RGBA", size, (0, 0, 0, 0))
    clip = layer.get("clip")
    opacity = layer.get("opacity", 1)
    if clip or opacity < 1:
        alpha = surface.getchannel("A")
        if clip:
            mask = Image.new("L", size, 0)
            ImageDraw.Draw(mask).rectangle([clip["x"], clip["y"], clip["x"] + clip["width"] - 1,
                                            clip["y"] + clip["height"] - 1], fill=255)
            from PIL import ImageChops
            alpha = ImageChops.multiply(alpha, mask)
        if opacity < 1:
            alpha = alpha.point(lambda v: round(v * opacity))
        surface.putalpha(alpha)
    return surface


def render_basic(package: Package):
    """Composite all visible layers in their saved state. Region effects are not applied."""
    Image, _, _ = _pil()
    doc = package.manifest["document"]
    canvas = Image.new("RGBA", (doc["width"], doc["height"]), parse_colour(doc.get("background", "#00000000")))
    for layer in package.manifest["layers"]:
        if layer.get("visible", True):
            canvas = Image.alpha_composite(canvas, render_layer(package, layer))
    return canvas


def has_region_effects(manifest: dict) -> bool:
    return any(region.get("effects") for region in manifest.get("regions", []))


def find_render_tools() -> tuple[str, Path, Path] | None:
    """Locate (node, render script, viewer bundle) for the browser engine."""
    node = shutil.which("node")
    data = resources.files("aav").joinpath("data")
    script, bundle = Path(str(data.joinpath("render.mjs"))), Path(str(data.joinpath("aav-viewer.iife.js")))
    if node and script.is_file() and bundle.is_file():
        return node, script, bundle
    return None


def _playwright_search_dirs() -> list[str]:
    dirs = [os.environ.get("AAV_NODE_MODULES", "")]
    here = Path(__file__).resolve()
    dirs += [str(parent / "web") for parent in here.parents]
    return [d for d in dirs if d and Path(d).is_dir()]


def render_browser(package: Package, *, timeout: float = 120) -> bytes:
    """Render with the reference renderer in headless Chromium. Returns PNG bytes."""
    tools = find_render_tools()
    if tools is None:
        raise AavError("browser engine unavailable: needs Node.js plus the bundled viewer "
                       "(run 'npm run build' in web/ to embed it)")
    node, script, bundle = tools
    with tempfile.TemporaryDirectory(prefix="aav-render-") as tmp:
        source, target = Path(tmp, "in.aav"), Path(tmp, "out.png")
        # The renderer validates what it is given, so supply a stand-in for a preview that does not exist yet.
        manifest = dict(package.manifest)
        files = dict(package.files)
        files.setdefault(PREVIEW, PLACEHOLDER_PNG)
        if manifest.get("thumbnail") not in files:
            manifest.pop("thumbnail", None)
        source.write_bytes(write_zip({MANIFEST: canonical_json(manifest), **files}))
        env = dict(os.environ, AAV_PLAYWRIGHT_PATHS=os.pathsep.join(_playwright_search_dirs()))
        result = subprocess.run([node, str(script), "--input", str(source), "--output", str(target),
                                 "--bundle", str(bundle)], capture_output=True, text=True, timeout=timeout, env=env)
        if result.returncode != 0 or not target.is_file():
            raise AavError("browser engine failed: " + (result.stderr.strip() or result.stdout.strip() or
                                                       f"exit code {result.returncode}"))
        return target.read_bytes()


def render_png(package: Package, engine: str = "auto") -> tuple[bytes, str]:
    """Render the default state to PNG. Returns (png_bytes, engine_used)."""
    if engine not in ("auto", "basic", "browser"):
        raise AavError(f"unknown render engine '{engine}'")
    if engine == "browser":
        return render_browser(package), "browser"
    if engine == "auto" and has_region_effects(package.manifest) and find_render_tools():
        try:
            return render_browser(package), "browser"
        except (AavError, subprocess.SubprocessError, OSError) as exc:
            print(f"aav: browser engine failed ({exc}); falling back to the basic engine, which draws layers "
                  "only", file=sys.stderr)
            return encode_png(render_basic(package)), "basic"
    if engine == "auto" and has_region_effects(package.manifest):
        print("aav: browser render engine unavailable; using the basic engine, which draws layers only "
              "(region effects are not applied)", file=sys.stderr)
    return encode_png(render_basic(package)), "basic"


def make_thumbnail(preview_png: bytes, max_side: int = 256) -> tuple[str, bytes]:
    """Return (archive path, bytes) of a thumbnail derived from the preview."""
    Image, _, _ = _pil()
    from PIL import features
    image = decode_image(preview_png)
    image.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
    out = io.BytesIO()
    if features.check("webp"):
        image.save(out, "WEBP", lossless=True, method=4, exact=True)
        return "thumbnails/preview.webp", out.getvalue()
    return "thumbnails/preview.png", encode_png(image)
