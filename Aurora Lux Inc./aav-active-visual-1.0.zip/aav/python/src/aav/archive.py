"""The .aav container: a restricted, deterministic ZIP profile.

Reading uses a purpose-built parser instead of :mod:`zipfile` so that every
structural rule in docs/SPEC.md section 3 is enforced the same way as in
``web/src/core/zip.ts``: no prefix or trailing bytes, no comments, no ZIP64,
no encryption, stored/deflate only, bounded sizes, no overlapping entries.
"""
from __future__ import annotations

import hashlib
import struct
import unicodedata
import zlib
from dataclasses import dataclass, field
from pathlib import Path

from .errors import AavError, Issue, errors_only
from .limits import LIMITS
from .manifest import canonical_json, parse_manifest, validate_manifest

A = LIMITS["archive"]
IMG = LIMITS["image"]
MANIFEST = "manifest.json"
PREVIEW = "preview.png"
_DOS_TIME, _DOS_DATE = 0, 0x0021  # 1980-01-01 00:00:00
# 1x1 transparent PNG: stands in for preview.png while the real preview is being rendered.
PLACEHOLDER_PNG = bytes.fromhex(
    "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000"
    "000d4944415478da63606060600000000500017aa857500000000049454e44ae426082")
_FLAG_UTF8 = 0x0800


@dataclass
class Package:
    """An AAV document in memory: the manifest plus every other archive entry."""

    manifest: dict
    files: dict[str, bytes] = field(default_factory=dict)

    def copy(self) -> "Package":
        import copy
        return Package(copy.deepcopy(self.manifest), dict(self.files))


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# --------------------------------------------------------------------------- images

def sniff_image(data: bytes) -> tuple[str, int, int] | None:
    """Return (media_type, width, height) from the header bytes, without decoding pixels."""
    if data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) >= 24 and data[12:16] == b"IHDR":
        width, height = struct.unpack(">II", data[16:24])
        return "image/png", width, height
    if data[:3] == b"\xff\xd8\xff":
        pos = 2
        while pos + 4 <= len(data):
            if data[pos] != 0xFF:
                return None
            marker = data[pos + 1]
            if marker == 0xFF:
                pos += 1
                continue
            if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
                pos += 2
                continue
            length = struct.unpack(">H", data[pos + 2:pos + 4])[0]
            if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
                if pos + 9 > len(data):
                    return None
                height, width = struct.unpack(">HH", data[pos + 5:pos + 9])
                return "image/jpeg", width, height
            if length < 2:
                return None
            pos += 2 + length
        return None
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP" and len(data) >= 30:
        chunk = data[12:16]
        if chunk == b"VP8 " and data[23:26] == b"\x9d\x01\x2a":
            width, height = struct.unpack("<HH", data[26:30])
            return "image/webp", width & 0x3FFF, height & 0x3FFF
        if chunk == b"VP8L" and data[20] == 0x2F:
            bits = struct.unpack("<I", data[21:25])[0]
            return "image/webp", (bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1
        if chunk == b"VP8X":
            width = int.from_bytes(data[24:27], "little") + 1
            height = int.from_bytes(data[27:30], "little") + 1
            return "image/webp", width, height
    return None


# --------------------------------------------------------------------------- reading

def entry_path_problem(name: str) -> str | None:
    """Why an archive entry name is unsafe, or None."""
    if not name:
        return "empty name"
    if len(name.encode("utf-8")) > A["max_path_length"]:
        return f"name is longer than {A['max_path_length']} bytes"
    if any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in name):
        return "name contains control characters"
    if "\\" in name or ":" in name:
        return "name contains a backslash or colon"
    if name.startswith("/"):
        return "absolute paths are not allowed"
    if unicodedata.normalize("NFC", name) != name:
        return "name is not NFC-normalised"
    segments = name[:-1].split("/") if name.endswith("/") else name.split("/")
    if any(seg in ("", ".", "..") for seg in segments):
        return "name contains an empty, '.' or '..' segment"
    return None


def _fail(code: str, path: str, message: str):
    raise AavError(Issue(code, path, message))


def read_zip(data: bytes) -> dict[str, bytes]:
    """Parse the restricted ZIP profile and return {name: bytes}. Raises AavError."""
    n = len(data)
    if n > A["max_total_bytes"] + 16 * 1024 * 1024:
        _fail("E_ARCHIVE_LIMIT", "", "container is larger than the total size limit")
    if n < 22 or data[:4] != b"PK\x03\x04":
        _fail("E_ARCHIVE_FORMAT", "", "not an AAV container: the file must begin with a ZIP local file header")
    eocd = n - 22
    if data[eocd:eocd + 4] != b"PK\x05\x06":
        _fail("E_ARCHIVE_FORMAT", "", "ZIP end record not found at the end of the file (archive comments and "
                                      "trailing data are not allowed)")
    disk, cd_disk, disk_entries, entries, cd_size, cd_offset, comment_len = struct.unpack(
        "<HHHHIIH", data[eocd + 4:eocd + 22])
    if disk or cd_disk or disk_entries != entries or comment_len:
        _fail("E_ARCHIVE_FORMAT", "", "multi-disk archives and archive comments are not allowed")
    if entries == 0xFFFF or cd_size == 0xFFFFFFFF or cd_offset == 0xFFFFFFFF:
        _fail("E_ARCHIVE_FORMAT", "", "ZIP64 archives are not supported")
    if entries > A["max_entries"]:
        _fail("E_ARCHIVE_LIMIT", "", f"archive has more than {A['max_entries']} entries")
    if cd_offset + cd_size != eocd:
        _fail("E_ARCHIVE_FORMAT", "", "central directory does not end at the end record")

    records = []
    seen: dict[str, str] = {}
    total = 0
    pos = cd_offset
    for _ in range(entries):
        if pos + 46 > eocd or data[pos:pos + 4] != b"PK\x01\x02":
            _fail("E_ARCHIVE_FORMAT", "", "corrupt central directory")
        (_made, _need, flags, method, _time, _date, crc, csize, usize, nlen, xlen, clen, _dsk, _iattr, _eattr,
         offset) = struct.unpack("<HHHHHHIIIHHHHHII", data[pos + 4:pos + 46])
        raw_name = data[pos + 46:pos + 46 + nlen]
        pos += 46 + nlen + xlen + clen
        if pos > eocd or len(raw_name) != nlen:
            _fail("E_ARCHIVE_FORMAT", "", "corrupt central directory")
        try:
            name = raw_name.decode("utf-8" if flags & _FLAG_UTF8 else "ascii")
        except UnicodeDecodeError:
            _fail("E_ARCHIVE_PATH", repr(raw_name), "entry name is not valid UTF-8 (or not ASCII without the "
                                                    "UTF-8 flag)")
        problem = entry_path_problem(name)
        if problem:
            _fail("E_ARCHIVE_PATH", name, f"unsafe entry name: {problem}")
        if flags & 0x0041:
            _fail("E_ARCHIVE_ENCRYPTED", name, "encrypted entries are not allowed")
        if method not in (0, 8):
            _fail("E_ARCHIVE_METHOD", name, f"compression method {method} is not allowed (stored or deflate only)")
        if 0xFFFFFFFF in (csize, usize, offset):
            _fail("E_ARCHIVE_FORMAT", name, "ZIP64 entries are not supported")
        key = name.rstrip("/").lower()
        if key in seen:
            _fail("E_ARCHIVE_DUPLICATE", name, f"duplicate entry (matches '{seen[key]}' ignoring case)")
        seen[key] = name
        if usize > A["max_file_bytes"]:
            _fail("E_ARCHIVE_LIMIT", name, f"entry is larger than {A['max_file_bytes']} bytes uncompressed")
        total += usize
        if total > A["max_total_bytes"]:
            _fail("E_ARCHIVE_LIMIT", name, f"archive expands to more than {A['max_total_bytes']} bytes")
        if usize > A["ratio_floor_bytes"] and csize * A["max_ratio"] < usize:
            _fail("E_ARCHIVE_RATIO", name, f"compression ratio exceeds {A['max_ratio']}:1")
        if method == 0 and csize != usize:
            _fail("E_ARCHIVE_SIZE", name, "stored entry has mismatched sizes")
        records.append((name, raw_name, method, crc, csize, usize, offset))
    if pos != eocd:
        _fail("E_ARCHIVE_FORMAT", "", "central directory size does not match its contents")

    spans = []
    for name, raw_name, method, crc, csize, usize, offset in records:
        if offset + 30 > cd_offset or data[offset:offset + 4] != b"PK\x03\x04":
            _fail("E_ARCHIVE_FORMAT", name, "local file header is missing")
        lnlen, lxlen = struct.unpack("<HH", data[offset + 26:offset + 30])
        if data[offset + 30:offset + 30 + lnlen] != raw_name:
            _fail("E_ARCHIVE_FORMAT", name, "local and central entry names differ")
        start = offset + 30 + lnlen + lxlen
        if start + csize > cd_offset:
            _fail("E_ARCHIVE_FORMAT", name, "entry data runs past the central directory")
        spans.append((offset, start + csize, name))
    spans.sort()
    for (_, end, name), (next_offset, _, next_name) in zip(spans, spans[1:]):
        if next_offset < end:
            _fail("E_ARCHIVE_OVERLAP", next_name, f"entry overlaps '{name}'")

    out: dict[str, bytes] = {}
    for (name, raw_name, method, crc, csize, usize, offset) in records:
        lnlen, lxlen = struct.unpack("<HH", data[offset + 26:offset + 30])
        start = offset + 30 + lnlen + lxlen
        raw = data[start:start + csize]
        if method == 8:
            inflater = zlib.decompressobj(-15)
            try:
                payload = inflater.decompress(raw, usize + 1)
            except zlib.error as exc:
                _fail("E_ARCHIVE_FORMAT", name, f"corrupt deflate stream: {exc}")
            if len(payload) != usize or not inflater.eof:
                _fail("E_ARCHIVE_SIZE", name, "entry does not inflate to its declared size")
        else:
            payload = raw
        if zlib.crc32(payload) & 0xFFFFFFFF != crc:
            _fail("E_ARCHIVE_CRC", name, "CRC-32 mismatch")
        if name.endswith("/"):
            if usize:
                _fail("E_ARCHIVE_PATH", name, "directory entries must be empty")
            continue
        out[name] = payload
    return out


def write_zip(files: dict[str, bytes]) -> bytes:
    """Write a deterministic archive: fixed order, stored entries, fixed timestamps."""
    order = [n for n in (MANIFEST, PREVIEW) if n in files] + sorted(n for n in files if n not in (MANIFEST, PREVIEW))
    body = bytearray()
    central = bytearray()
    for name in order:
        problem = entry_path_problem(name)
        if problem or name.endswith("/"):
            raise AavError(Issue("E_ARCHIVE_PATH", name, f"unsafe entry name: {problem or 'directory entry'}"))
        payload = files[name]
        raw_name = name.encode("utf-8")
        crc = zlib.crc32(payload) & 0xFFFFFFFF
        offset = len(body)
        header = struct.pack("<HHHHHIIIHH", 20, _FLAG_UTF8, 0, _DOS_TIME, _DOS_DATE, crc, len(payload), len(payload),
                             len(raw_name), 0)
        body += b"PK\x03\x04" + header + raw_name + payload
        central += b"PK\x01\x02" + struct.pack("<H", 20) + header + struct.pack("<HHHII", 0, 0, 0, 0, offset) + raw_name
    eocd = b"PK\x05\x06" + struct.pack("<HHHHIIH", 0, 0, len(order), len(order), len(central), len(body), 0)
    return bytes(body + central + eocd)


# --------------------------------------------------------------------------- packages

def referenced_paths(manifest: dict) -> set[str]:
    paths = {MANIFEST, PREVIEW}
    assets = manifest.get("assets")
    if isinstance(assets, dict):
        for asset in assets.values():
            if isinstance(asset, dict) and isinstance(asset.get("path"), str):
                paths.add(asset["path"])
    if isinstance(manifest.get("thumbnail"), str):
        paths.add(manifest["thumbnail"])
    return paths


def validate_package(package: Package, *, strict: bool = False) -> list[Issue]:
    """Validate the manifest and its consistency with the packaged files."""
    issues = validate_manifest(package.manifest)
    if errors_only(issues):
        return issues
    manifest, files = package.manifest, package.files

    def image_ok(path: str, expected_type: str | None) -> tuple[int, int] | None:
        info = sniff_image(files[path])
        if info is None:
            issues.append(Issue("E_ASSET_TYPE", path, "file is not a recognisable PNG, JPEG or WebP image"))
            return None
        media_type, width, height = info
        if expected_type and media_type != expected_type:
            issues.append(Issue("E_ASSET_TYPE", path, f"file content is {media_type} but {expected_type} is declared"))
            return None
        if not (1 <= width <= IMG["max_dimension"] and 1 <= height <= IMG["max_dimension"]):
            issues.append(Issue("E_ASSET_DIMENSIONS", path, f"image is {width}x{height}; each side must be 1 to "
                                                            f"{IMG['max_dimension']} pixels"))
            return None
        return width, height

    if PREVIEW not in files:
        issues.append(Issue("E_ARCHIVE_MISSING", PREVIEW, "static preview is missing"))
    else:
        image_ok(PREVIEW, "image/png")
    thumbnail = manifest.get("thumbnail")
    if thumbnail:
        if thumbnail not in files:
            issues.append(Issue("E_ARCHIVE_MISSING", thumbnail, "thumbnail is declared but missing"))
        else:
            image_ok(thumbnail, None)

    total_pixels = 0
    for aid, asset in manifest.get("assets", {}).items():
        path = asset["path"]
        if path not in files:
            issues.append(Issue("E_ARCHIVE_MISSING", path, f"asset '{aid}' is missing from the archive"))
            continue
        size = image_ok(path, asset["media_type"])
        if size is None:
            continue
        total_pixels += size[0] * size[1]
        if ("width" in asset and asset["width"] != size[0]) or ("height" in asset and asset["height"] != size[1]):
            issues.append(Issue("E_ASSET_DIMENSIONS", f"/assets/{aid}", f"declared size does not match the image "
                                                                        f"({size[0]}x{size[1]})"))
        if "sha256" in asset:
            if asset["sha256"] != sha256_hex(files[path]):
                issues.append(Issue("E_ASSET_HASH", f"/assets/{aid}/sha256", "SHA-256 does not match the file"))
        if not all(k in asset for k in ("sha256", "width", "height")):
            issues.append(Issue("E_ASSET_INCOMPLETE" if strict else "W_ASSET_INCOMPLETE", f"/assets/{aid}",
                                "asset should declare sha256, width and height"))
    if total_pixels > IMG["max_total_pixels"]:
        issues.append(Issue("E_LIMIT", "/assets", f"assets decode to more than {IMG['max_total_pixels']} pixels"))

    used = referenced_paths(manifest)
    for name in sorted(files):
        if name not in used:
            issues.append(Issue("E_UNREFERENCED" if strict else "W_UNREFERENCED", name,
                                "file is not referenced by the manifest"))
    return issues


def read_archive(source: str | Path | bytes, *, strict: bool = False) -> tuple[Package, list[Issue]]:
    """Read and fully validate an .aav file.

    Raises :class:`AavError` if the container or manifest has errors. Returns
    the package and any warnings.
    """
    data = source if isinstance(source, (bytes, bytearray)) else Path(source).read_bytes()
    files = read_zip(bytes(data))
    if MANIFEST not in files:
        raise AavError(Issue("E_ARCHIVE_MISSING", MANIFEST, "manifest.json is missing"))
    manifest = parse_manifest(files.pop(MANIFEST))
    package = Package(manifest, files)
    issues = validate_package(package, strict=strict)
    if errors_only(issues):
        raise AavError(issues)
    return package, issues


def load_unvalidated(source: str | Path | bytes) -> Package:
    """Read the container (with all archive safety checks) but skip manifest validation."""
    data = source if isinstance(source, (bytes, bytearray)) else Path(source).read_bytes()
    files = read_zip(bytes(data))
    if MANIFEST not in files:
        raise AavError(Issue("E_ARCHIVE_MISSING", MANIFEST, "manifest.json is missing"))
    return Package(parse_manifest(files.pop(MANIFEST)), files)


def complete_assets(package: Package) -> None:
    """Fill in sha256, width and height for every asset from the packaged bytes."""
    for aid, asset in package.manifest.get("assets", {}).items():
        data = package.files.get(asset.get("path", ""))
        if data is None:
            raise AavError(Issue("E_ARCHIVE_MISSING", asset.get("path", ""), f"asset '{aid}' has no file"))
        info = sniff_image(data)
        if info is None:
            raise AavError(Issue("E_ASSET_TYPE", asset["path"], "file is not a PNG, JPEG or WebP image"))
        asset["sha256"] = sha256_hex(data)
        asset["width"], asset["height"] = info[1], info[2]


def write_archive(package: Package, dest: str | Path | None = None, *, strict: bool = True) -> bytes:
    """Validate and serialise a package deterministically. Returns the bytes written."""
    issues = validate_package(package, strict=strict)
    if errors_only(issues):
        raise AavError(errors_only(issues))
    files = {MANIFEST: canonical_json(package.manifest), **package.files}
    data = write_zip(files)
    if dest is not None:
        Path(dest).write_bytes(data)
    return data
