/**
 * The editing canvas: the document rendered in its saved state, with region
 * outlines and geometry handles drawn on top in screen space.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent as ReactKeyboardEvent, PointerEvent as ReactPointerEvent } from 'react';
import { docToScreen, fitView, panBy, screenToDoc, zoomAt } from '../core/geometry';
import type { View } from '../core/geometry';
import { regionContains } from '../core/hittest';
import { parseColour } from '../core/pixels';
import { SceneRenderer } from '../core/renderer';
import type { DecodedAsset } from '../core/renderer';
import { Machine } from '../core/state';
import type { Manifest, Region, Shape, StateName } from '../core/types';
import { shapeBounds } from '../core/validate';
import type { Selection, Tool } from './store';
import { deleteRegion, uniqueId } from './store';

interface Props {
  manifest: Manifest;
  assets: ReadonlyMap<string, DecodedAsset>;
  selection: Selection;
  tool: Tool;
  /** Interaction state to preview on the selected region, or null for the plain saved state. */
  previewState: StateName | null;
  renderable: boolean;
  onSelect: (selection: Selection) => void;
  onTool: (tool: Tool) => void;
  update: (fn: (draft: Manifest) => void, key?: string) => void;
}

type Drag =
  | { type: 'pan'; lastX: number; lastY: number }
  | { type: 'draw-rect'; startX: number; startY: number; x: number; y: number }
  | { type: 'move'; id: string; startX: number; startY: number; original: Shape; moved: boolean }
  | { type: 'handle'; id: string; handle: string; original: Shape }
  | { type: 'vertex'; id: string; index: number };

const HANDLES = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'] as const;
const round = (v: number) => Math.round(v);

/** Box of a rect or mask shape with defaults filled in. */
function boxOf(shape: Shape, docW: number, docH: number) {
  return shapeBounds(shape, docW, docH);
}

function moved(shape: Shape, dx: number, dy: number, docW: number, docH: number): Shape {
  if (shape.type === 'polygon') return { ...shape, points: shape.points.map(([x, y]) => [round(x + dx), round(y + dy)]) };
  const b = boxOf(shape, docW, docH);
  if (shape.type === 'mask') return { ...shape, x: round(b.x + dx), y: round(b.y + dy), width: b.width, height: b.height };
  return { ...shape, x: round(b.x + dx), y: round(b.y + dy) };
}

function resized(shape: Shape, handle: string, px: number, py: number, docW: number, docH: number): Shape {
  if (shape.type === 'polygon') return shape;
  const b = boxOf(shape, docW, docH);
  let x0 = b.x, y0 = b.y, x1 = b.x + b.width, y1 = b.y + b.height;
  if (handle.includes('w')) x0 = round(px);
  if (handle.includes('e')) x1 = round(px);
  if (handle.includes('n')) y0 = round(py);
  if (handle.includes('s')) y1 = round(py);
  const x = Math.min(x0, x1), y = Math.min(y0, y1);
  return { ...shape, x, y, width: Math.max(1, Math.abs(x1 - x0)), height: Math.max(1, Math.abs(y1 - y0)) };
}

export function Stage({ manifest, assets, selection, tool, previewState, renderable, onSelect, onTool, update }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ width: 1, height: 1 });
  const [view, setView] = useState<View>({ scale: 1, tx: 0, ty: 0 });
  const [fitted, setFitted] = useState(true);
  const [drag, setDrag] = useState<Drag | null>(null);
  const [polygon, setPolygon] = useState<[number, number][] | null>(null);
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null);
  const [stale, setStale] = useState(false);
  const doc = manifest.document;
  const regions = useMemo(() => manifest.regions ?? [], [manifest.regions]);
  const selected = selection.kind === 'region' ? regions.find((r) => r.id === selection.id) : undefined;

  const renderer = useMemo(() => {
    try {
      return new SceneRenderer(manifest, assets, { backend: 'cpu' });
    } catch {
      return null;
    }
    // A new renderer is only needed when the decoded assets change; manifest edits go through setManifest.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assets]);
  useEffect(() => () => renderer?.dispose(), [renderer]);

  useEffect(() => {
    const el = wrapRef.current!;
    const observer = new ResizeObserver(() => setSize({ width: el.clientWidth || 1, height: el.clientHeight || 1 }));
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (fitted) setView(fitView(doc.width, doc.height, size.width, size.height, 24));
  }, [fitted, doc.width, doc.height, size.width, size.height]);

  // Draw the document, then the mask tints that make mask regions visible while editing.
  useEffect(() => {
    const canvas = canvasRef.current!;
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const w = Math.round(size.width * dpr), h = Math.round(size.height * dpr);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    const ctx = canvas.getContext('2d')!;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, w, h);
    if (!renderer) return;
    let surface: HTMLCanvasElement | null = null;
    if (renderable) {
      try {
        renderer.setManifest(manifest);
        const machine = new Machine(manifest, { reducedMotion: true, now: () => 0 });
        if (previewState && selected) {
          if (previewState === 'hover') machine.hovered = selected.id;
          else if (previewState === 'focus') machine.focused = selected.id;
          else machine.selected = [selected.id];
        }
        surface = renderer.render(machine, 0);
        setStale(false);
      } catch {
        surface = renderer.surface;
        setStale(true);
      }
    } else {
      surface = renderer.surface; // keep showing the last good frame while the document has errors
      setStale(true);
    }
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.tx, dpr * view.ty);
    ctx.imageSmoothingEnabled = !(manifest.settings?.image_rendering === 'pixelated' && dpr * view.scale >= 1);
    ctx.fillStyle = '#0d0e10';
    ctx.fillRect(0, 0, doc.width, doc.height);
    if (surface && surface.width === doc.width && surface.height === doc.height) ctx.drawImage(surface, 0, 0);
    if (renderable) {
      for (const region of regions) {
        if (region.shape.type !== 'mask') continue;
        try {
          const cov = renderer.coverage(region, 0);
          if (!cov) continue;
          ctx.globalAlpha = region.id === selected?.id ? 0.4 : 0.22;
          ctx.drawImage(renderer.stamp(cov.rect, cov.alpha, parseColour(region.id === selected?.id ? '#A78BFA' : '#5AD8E6'), 1), cov.rect.x, cov.rect.y);
          ctx.globalAlpha = 1;
        } catch { /* a mask whose asset is not decoded yet is simply not tinted */ }
      }
    }
  }, [renderer, manifest, view, size, previewState, selected, renderable, doc.width, doc.height, regions]);

  const local = (event: { clientX: number; clientY: number }) => {
    const rect = wrapRef.current!.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  };

  const hitRegion = useCallback((x: number, y: number): Region | undefined => {
    const masks = renderer?.masks ?? new Map();
    const hits = regions.filter((r) => {
      // In the editor a mask is grabbed by its box, so fully transparent masks can still be moved.
      if (r.shape.type === 'mask') {
        const b = boxOf(r.shape, doc.width, doc.height);
        return x >= b.x && x < b.x + b.width && y >= b.y && y < b.y + b.height;
      }
      return regionContains(r, x, y, doc.width, doc.height, masks);
    });
    if (selected && hits.includes(selected)) return selected;
    return hits.sort((a, b) => (b.z_index ?? 0) - (a.z_index ?? 0) || regions.indexOf(b) - regions.indexOf(a))[0];
  }, [regions, renderer, doc.width, doc.height, selected]);

  const setShape = (id: string, shape: Shape) => update((m) => {
    const region = (m.regions ?? []).find((r) => r.id === id);
    if (region) region.shape = shape;
  }, `geometry:${id}`);

  const addRegion = (shape: Shape) => {
    const id = uniqueId('region', regions.map((r) => r.id));
    update((m) => {
      const target = m.layers.find((l) => l.type === 'image')?.id;
      const region: Region = { id, label: `Region ${id.split('-')[1]}`, shape };
      if (target) region.target_layer = target;
      m.regions = [...(m.regions ?? []), region];
    });
    onSelect({ kind: 'region', id });
    onTool('select');
  };

  const closePolygon = () => {
    if (polygon && polygon.length >= 3) addRegion({ type: 'polygon', points: polygon });
    setPolygon(null);
  };

  const onPointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (event.button !== 0 && event.button !== 1) return;
    wrapRef.current!.focus({ preventScroll: true });
    const p = local(event), d = screenToDoc(view, p.x, p.y);
    const target = event.target as Element;
    try { wrapRef.current!.setPointerCapture(event.pointerId); } catch { /* synthetic events */ }
    if (tool === 'pan' || event.button === 1) {
      setDrag({ type: 'pan', lastX: p.x, lastY: p.y });
    } else if (tool === 'rect') {
      setDrag({ type: 'draw-rect', startX: round(d.x), startY: round(d.y), x: round(d.x), y: round(d.y) });
    } else if (tool === 'polygon') {
      const point: [number, number] = [round(d.x), round(d.y)];
      if (polygon && polygon.length >= 3) {
        const first = docToScreen(view, polygon[0][0], polygon[0][1]);
        if (Math.hypot(first.x - p.x, first.y - p.y) < 10) {
          closePolygon();
          return;
        }
      }
      setPolygon([...(polygon ?? []), point]);
    } else {
      const handle = target.closest<SVGElement>('[data-handle]')?.dataset.handle;
      const vertex = target.closest<SVGElement>('[data-vertex]')?.dataset.vertex;
      const insert = target.closest<SVGElement>('[data-insert]')?.dataset.insert;
      if (selected && vertex !== undefined) {
        setDrag({ type: 'vertex', id: selected.id, index: Number(vertex) });
      } else if (selected && insert !== undefined && selected.shape.type === 'polygon') {
        const index = Number(insert) + 1;
        const points = [...selected.shape.points];
        points.splice(index, 0, [round(d.x), round(d.y)]);
        setShape(selected.id, { type: 'polygon', points });
        setDrag({ type: 'vertex', id: selected.id, index });
      } else if (selected && handle) {
        setDrag({ type: 'handle', id: selected.id, handle, original: selected.shape });
      } else {
        const hit = hitRegion(d.x, d.y);
        if (hit) {
          onSelect({ kind: 'region', id: hit.id });
          setDrag({ type: 'move', id: hit.id, startX: d.x, startY: d.y, original: hit.shape, moved: false });
        } else {
          onSelect({ kind: 'none' });
          setDrag({ type: 'pan', lastX: p.x, lastY: p.y });
        }
      }
    }
  };

  const onPointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    const p = local(event), d = screenToDoc(view, p.x, p.y);
    if (tool === 'polygon' && polygon) setCursor({ x: round(d.x), y: round(d.y) });
    if (!drag) return;
    if (drag.type === 'pan') {
      setFitted(false);
      setView((v) => panBy(v, p.x - drag.lastX, p.y - drag.lastY));
      setDrag({ ...drag, lastX: p.x, lastY: p.y });
    } else if (drag.type === 'draw-rect') {
      setDrag({ ...drag, x: round(d.x), y: round(d.y) });
    } else if (drag.type === 'move') {
      const dx = d.x - drag.startX, dy = d.y - drag.startY;
      if (!drag.moved && Math.hypot(dx, dy) * view.scale < 3) return;
      if (!drag.moved) setDrag({ ...drag, moved: true });
      setShape(drag.id, moved(drag.original, dx, dy, doc.width, doc.height));
    } else if (drag.type === 'handle') {
      setShape(drag.id, resized(drag.original, drag.handle, d.x, d.y, doc.width, doc.height));
    } else if (drag.type === 'vertex') {
      const region = regions.find((r) => r.id === drag.id);
      if (region?.shape.type === 'polygon') {
        setShape(drag.id, { type: 'polygon', points: region.shape.points.map((pt, i) => (i === drag.index ? [round(d.x), round(d.y)] : pt)) });
      }
    }
  };

  const onPointerUp = () => {
    if (drag?.type === 'draw-rect') {
      const x = Math.min(drag.startX, drag.x), y = Math.min(drag.startY, drag.y);
      const width = Math.abs(drag.x - drag.startX), height = Math.abs(drag.y - drag.startY);
      if (width >= 2 && height >= 2) addRegion({ type: 'rect', x, y, width, height });
    }
    setDrag(null);
  };

  const onWheel = useCallback((event: WheelEvent) => {
    event.preventDefault();
    const rect = wrapRef.current!.getBoundingClientRect();
    setFitted(false);
    setView((v) => zoomAt(v, Math.exp(-event.deltaY * (event.deltaMode === 1 ? 0.05 : 0.0015)), event.clientX - rect.left, event.clientY - rect.top));
  }, []);
  useEffect(() => {
    const el = wrapRef.current!;
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [onWheel]);

  const onKeyDown = (event: ReactKeyboardEvent<HTMLDivElement>) => {
    if (event.target !== event.currentTarget) return;
    const zoom = (factor: number) => {
      setFitted(false);
      setView((v) => zoomAt(v, factor, size.width / 2, size.height / 2));
    };
    if (event.key === 'Escape') {
      setPolygon(null);
      setDrag(null);
    } else if (event.key === 'Enter' && polygon) {
      closePolygon();
    } else if (event.key === 'Backspace' && polygon) {
      setPolygon(polygon.length > 1 ? polygon.slice(0, -1) : null);
    } else if ((event.key === 'Delete' || event.key === 'Backspace') && selected) {
      update((m) => deleteRegion(m, selected.id));
    } else if (event.key.startsWith('Arrow') && selected) {
      const step = event.shiftKey ? 10 : 1;
      const dx = event.key === 'ArrowLeft' ? -step : event.key === 'ArrowRight' ? step : 0;
      const dy = event.key === 'ArrowUp' ? -step : event.key === 'ArrowDown' ? step : 0;
      setShape(selected.id, moved(selected.shape, dx, dy, doc.width, doc.height));
    } else if (event.key === '+' || event.key === '=') zoom(1.25);
    else if (event.key === '-') zoom(0.8);
    else if (event.key === '0') setFitted(true);
    else return;
    event.preventDefault();
  };

  const onDoubleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (tool === 'polygon' && polygon) {
      // The second click of a double-click already added a point; drop it and close.
      const points = polygon.slice(0, -1);
      if (points.length >= 3) addRegion({ type: 'polygon', points });
      setPolygon(null);
      return;
    }
    const vertex = (event.target as Element).closest<SVGElement>('[data-vertex]')?.dataset.vertex;
    if (selected?.shape.type === 'polygon' && vertex !== undefined && selected.shape.points.length > 3) {
      setShape(selected.id, { type: 'polygon', points: selected.shape.points.filter((_, i) => i !== Number(vertex)) });
    }
  };

  const s = (x: number, y: number) => docToScreen(view, x, y);
  const outline = (region: Region) => {
    const active = region.id === selected?.id;
    const cls = `rg${active ? ' rg-on' : ''}${region.interactive === false ? ' rg-passive' : ''}`;
    if (region.shape.type === 'polygon') {
      return <polygon key={region.id} className={cls} points={region.shape.points.map(([x, y]) => { const p = s(x, y); return `${p.x},${p.y}`; }).join(' ')} />;
    }
    const b = boxOf(region.shape, doc.width, doc.height), a = s(b.x, b.y);
    return <rect key={region.id} className={`${cls}${region.shape.type === 'mask' ? ' rg-mask' : ''}`} x={a.x} y={a.y}
      width={b.width * view.scale} height={b.height * view.scale} />;
  };

  const handles = () => {
    if (!selected || tool !== 'select') return null;
    if (selected.shape.type === 'polygon') {
      const pts = selected.shape.points;
      return (
        <>
          {pts.map(([x, y], i) => {
            const [nx, ny] = pts[(i + 1) % pts.length];
            const m = s((x + nx) / 2, (y + ny) / 2);
            return <circle key={`m${i}`} className="hd hd-mid" data-insert={i} cx={m.x} cy={m.y} r={4}><title>Drag to add a point</title></circle>;
          })}
          {pts.map(([x, y], i) => {
            const p = s(x, y);
            return <rect key={`v${i}`} className="hd" data-vertex={i} x={p.x - 5} y={p.y - 5} width={10} height={10}><title>Drag to move; double-click to remove</title></rect>;
          })}
        </>
      );
    }
    const b = boxOf(selected.shape, doc.width, doc.height);
    return HANDLES.map((hname) => {
      const fx = hname.includes('w') ? 0 : hname.includes('e') ? 1 : 0.5;
      const fy = hname.includes('n') ? 0 : hname.includes('s') ? 1 : 0.5;
      const p = s(b.x + b.width * fx, b.y + b.height * fy);
      return <rect key={hname} className="hd" data-handle={hname} x={p.x - 5} y={p.y - 5} width={10} height={10}
        style={{ cursor: `${hname}-resize` }} />;
    });
  };

  const draft = () => {
    if (drag?.type === 'draw-rect') {
      const a = s(Math.min(drag.startX, drag.x), Math.min(drag.startY, drag.y));
      return <rect className="rg rg-draft" x={a.x} y={a.y} width={Math.abs(drag.x - drag.startX) * view.scale} height={Math.abs(drag.y - drag.startY) * view.scale} />;
    }
    if (polygon) {
      const pts = [...polygon, ...(cursor ? [[cursor.x, cursor.y] as [number, number]] : [])];
      return (
        <>
          <polyline className="rg rg-draft" points={pts.map(([x, y]) => { const p = s(x, y); return `${p.x},${p.y}`; }).join(' ')} />
          {polygon.map(([x, y], i) => { const p = s(x, y); return <circle key={i} className={`hd${i === 0 ? ' hd-first' : ''}`} cx={p.x} cy={p.y} r={i === 0 ? 6 : 3} />; })}
        </>
      );
    }
    return null;
  };

  const origin = s(0, 0);
  const hint = tool === 'rect' ? 'Drag to draw a rectangle.' : tool === 'polygon'
    ? 'Click to add points. Double-click, press Enter, or click the first point to finish. Esc cancels.'
    : tool === 'pan' ? 'Drag to pan. Scroll to zoom.' : 'Click a region to select it. Drag to move, use the handles to reshape. Arrow keys nudge.';
  return (
    <div className="stage-wrap">
      <div ref={wrapRef} className={`stage tool-${tool}`} tabIndex={0} role="application" data-testid="stage"
        aria-label={`Editing canvas, ${regions.length} regions. ${hint}`}
        onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={() => setDrag(null)}
        onKeyDown={onKeyDown} onDoubleClick={onDoubleClick}>
        <canvas ref={canvasRef} className="stage-canvas" aria-hidden="true" />
        <svg className="stage-svg" width={size.width} height={size.height} aria-hidden="true">
          <rect className="doc-frame" x={origin.x} y={origin.y} width={doc.width * view.scale} height={doc.height * view.scale} />
          {regions.filter((r) => r.shape && typeof r.shape === 'object').map(outline)}
          {handles()}
          {draft()}
          {selected ? (() => { const b = boxOf(selected.shape, doc.width, doc.height), a = s(b.x, b.y); return <text className="rg-label" x={a.x + 2} y={a.y - 6}>{selected.label}</text>; })() : null}
        </svg>
      </div>
      <div className="stage-foot">
        <span className="hint" title={hint}>{hint}</span>
        {stale ? <span className="stale" role="status">Preview paused: fix the errors listed to refresh it.</span> : null}
        <button type="button" className="btn btn-small" aria-label="Zoom out" onClick={() => { setFitted(false); setView((v) => zoomAt(v, 0.8, size.width / 2, size.height / 2)); }}>−</button>
        <span className="zoom" aria-live="off">{Math.round(view.scale * 100)}%</span>
        <button type="button" className="btn btn-small" aria-label="Zoom in" onClick={() => { setFitted(false); setView((v) => zoomAt(v, 1.25, size.width / 2, size.height / 2)); }}>+</button>
        <button type="button" className="btn btn-small" onClick={() => setFitted(true)}>Fit</button>
      </div>
    </div>
  );
}
