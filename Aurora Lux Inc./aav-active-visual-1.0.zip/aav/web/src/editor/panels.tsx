/** Side panels of the editor: layers, regions, information panels, document settings and the error list. */
import { useEffect, useRef } from 'react';
import { LIMITS } from '../core/limits';
import type { Animation, Issue, Layer, Manifest, TextLayer } from '../core/types';
import { isError } from '../core/types';
import { renderText } from '../viewer/textdom';
import { ActionList } from './ActionList';
import { CheckField, ColourField, CommitField, NumberField, Section, SelectField, TextField } from './fields';
import type { Selection } from './store';
import { issueTarget, renameLayer, renamePanel, uniqueId } from './store';

type Update = (fn: (draft: Manifest) => void, key?: string) => void;
const ID_RE = new RegExp(LIMITS.manifest.id_pattern);

export function LayerList({ manifest, selection, onSelect, update, onAddImage }: { manifest: Manifest; selection: Selection;
  onSelect: (s: Selection) => void; update: Update; onAddImage: () => void }) {
  const layers = manifest.layers;
  const move = (index: number, delta: number) => update((m) => {
    const [item] = m.layers.splice(index, 1);
    m.layers.splice(index + delta, 0, item);
  });
  return (
    <Section title="Layers" actions={
      <span className="row">
        <button type="button" className="btn btn-small" onClick={onAddImage}>+ Image</button>
        <button type="button" className="btn btn-small" onClick={() => {
          const id = uniqueId('text', layers.map((l) => l.id));
          update((m) => { m.layers.push({ id, type: 'text', text: 'Label', x: Math.round(m.document.width / 2), y: Math.round(m.document.height / 2),
            font_size: Math.max(14, Math.round(m.document.height / 30)), align: 'centre', colour: '#F4F0E6', background: '#15171ACC', padding: 8, name: 'Text label' }); });
          onSelect({ kind: 'layer', id });
        }}>+ Text</button>
      </span>}>
      <ul className="list" aria-label="Layers, top first">
        {[...layers].map((layer, index) => ({ layer, index })).reverse().map(({ layer, index }) => (
          <li key={layer.id} className={selection.kind === 'layer' && selection.id === layer.id ? 'on' : ''}>
            <input type="checkbox" checked={layer.visible !== false} aria-label={`Show layer ${layer.name ?? layer.id}`}
              onChange={(e) => update((m) => { const l = m.layers[index]; if (e.target.checked) delete l.visible; else l.visible = false; })} />
            <button type="button" className="list-main" onClick={() => onSelect({ kind: 'layer', id: layer.id })}>
              {layer.name ?? layer.id} <span className="tag">{layer.type}</span>
            </button>
            <button type="button" className="btn-icon" aria-label={`Move ${layer.name ?? layer.id} up`} disabled={index === layers.length - 1} onClick={() => move(index, 1)}>↑</button>
            <button type="button" className="btn-icon" aria-label={`Move ${layer.name ?? layer.id} down`} disabled={index === 0} onClick={() => move(index, -1)}>↓</button>
          </li>
        ))}
      </ul>
    </Section>
  );
}

export function RegionList({ manifest, selection, onSelect }: { manifest: Manifest; selection: Selection; onSelect: (s: Selection) => void }) {
  const regions = manifest.regions ?? [];
  return (
    <Section title={`Regions (${regions.length})`}>
      {regions.length ? (
        <ul className="list" aria-label="Regions">
          {regions.map((region) => (
            <li key={region.id} className={selection.kind === 'region' && selection.id === region.id ? 'on' : ''}>
              <button type="button" className="list-main" onClick={() => onSelect({ kind: 'region', id: region.id })}>
                {region.label || region.id} <span className="tag">{region.shape?.type}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : <p className="note">No regions yet. Choose the Rectangle or Polygon tool and draw on the image.</p>}
    </Section>
  );
}

export function LayerInspector({ manifest, layer, update }: { manifest: Manifest; layer: Layer; update: Update }) {
  const index = manifest.layers.indexOf(layer);
  const edit = (fn: (l: Layer) => void, key?: string) => update((m) => fn(m.layers[index]), key);
  const set = <K extends string>(key: K, value: unknown, undo = key) => edit((l) => { (l as unknown as Record<string, unknown>)[key] = value; }, `layer:${layer.id}:${undo}`);
  const ids = manifest.layers.map((l) => l.id);
  const t = layer.transform ?? {};
  const setTransform = (key: string, value: number, neutral: number) => edit((l) => {
    const next = { ...l.transform, [key]: value } as Record<string, number>;
    if (value === neutral) delete next[key];
    if (Object.keys(next).length) l.transform = next; else delete l.transform;
  }, `layer:${layer.id}:t:${key}`);
  return (
    <div className="inspector" data-testid="layer-inspector">
      <Section title={`Layer (${layer.type})`} actions={
        <button type="button" className="btn btn-small btn-danger" disabled={manifest.layers.length <= 1}
          onClick={() => update((m) => { m.layers.splice(index, 1); })}>Delete</button>}>
        <TextField label="Name" value={layer.name ?? ''} onChange={(v) => edit((l) => { if (v) l.name = v; else delete l.name; }, `layer:${layer.id}:name`)} />
        <CommitField label="Identifier" value={layer.id} onCommit={(v) => { if (ID_RE.test(v) && !ids.includes(v)) update((m) => renameLayer(m, layer.id, v)); }} />
        <NumberField label="Opacity" value={layer.opacity ?? 1} min={0} max={1} step={0.05} onChange={(v) => { if (v >= 0 && v <= 1) set('opacity', v); }} />
        {layer.type === 'image' ? (
          <>
            <SelectField label="Image asset" value={layer.asset} options={Object.keys(manifest.assets ?? {})} onChange={(v) => set('asset', v)} />
            <div className="grid4">
              <NumberField label="X" value={layer.x ?? 0} onChange={(v) => set('x', v)} />
              <NumberField label="Y" value={layer.y ?? 0} onChange={(v) => set('y', v)} />
              <NumberField label="Width" value={layer.width ?? manifest.document.width} min={1} onChange={(v) => { if (v > 0) set('width', v); }} />
              <NumberField label="Height" value={layer.height ?? manifest.document.height} min={1} onChange={(v) => { if (v > 0) set('height', v); }} />
            </div>
          </>
        ) : <TextLayerFields layer={layer} set={set} edit={edit as (fn: (l: TextLayer) => void, key?: string) => void} />}
      </Section>
      <Section title="Transform">
        <div className="grid4">
          <NumberField label="Move X" value={t.translate_x ?? 0} onChange={(v) => setTransform('translate_x', v, 0)} />
          <NumberField label="Move Y" value={t.translate_y ?? 0} onChange={(v) => setTransform('translate_y', v, 0)} />
          <NumberField label="Scale X" value={t.scale_x ?? 1} step={0.05} min={-100} max={100} onChange={(v) => { if (v !== 0) setTransform('scale_x', v, 1); }} />
          <NumberField label="Scale Y" value={t.scale_y ?? 1} step={0.05} min={-100} max={100} onChange={(v) => { if (v !== 0) setTransform('scale_y', v, 1); }} />
        </div>
        <NumberField label="Rotation (degrees, clockwise)" value={t.rotation ?? 0} min={-360} max={360} onChange={(v) => setTransform('rotation', v, 0)} />
        <CheckField label="Clip to a rectangle" checked={layer.clip !== undefined} onChange={(on) => edit((l) => {
          if (on) l.clip = { x: 0, y: 0, width: manifest.document.width, height: manifest.document.height }; else delete l.clip;
        })} />
        {layer.clip ? (
          <div className="grid4">
            {(['x', 'y', 'width', 'height'] as const).map((key) => (
              <NumberField key={key} label={`Clip ${key}`} value={layer.clip![key]} min={key === 'width' || key === 'height' ? 1 : undefined}
                onChange={(v) => { if (key === 'x' || key === 'y' || v > 0) edit((l) => { l.clip = { ...l.clip!, [key]: v }; }, `layer:${layer.id}:clip:${key}`); }} />
            ))}
          </div>
        ) : null}
      </Section>
    </div>
  );
}

function TextLayerFields({ layer, set, edit }: { layer: TextLayer; set: (key: string, value: unknown) => void;
  edit: (fn: (l: TextLayer) => void, key?: string) => void }) {
  return (
    <>
      <TextField label="Text" multiline value={layer.text} onChange={(v) => set('text', v)} error={layer.text ? null : 'Text is required'} />
      <div className="grid4">
        <NumberField label="X" value={layer.x} onChange={(v) => set('x', v)} />
        <NumberField label="Y" value={layer.y} onChange={(v) => set('y', v)} />
        <NumberField label="Size (px)" value={layer.font_size ?? 24} min={4} max={512} onChange={(v) => { if (v >= 4 && v <= 512) set('font_size', v); }} />
        <SelectField label="Weight" value={String(layer.font_weight ?? 400)} options={['400', '700']} onChange={(v) => set('font_weight', Number(v || 400))} />
      </div>
      <div className="row">
        <SelectField label="Font" value={layer.font_family ?? 'sans-serif'} options={['sans-serif', 'serif', 'monospace']} onChange={(v) => set('font_family', v || 'sans-serif')} />
        <SelectField label="Align" value={layer.align ?? 'left'} options={['left', 'centre', 'right']} onChange={(v) => set('align', v || 'left')} />
      </div>
      <ColourField label="Text colour" value={layer.colour ?? '#FFFFFF'} onChange={(v) => set('colour', v)} />
      <CheckField label="Background box" checked={layer.background !== undefined} onChange={(on) => edit((l) => { if (on) l.background = '#15171ACC'; else delete l.background; })} />
      {layer.background !== undefined ? <ColourField label="Background colour" value={layer.background} onChange={(v) => set('background', v)} /> : null}
    </>
  );
}

function TextPreview({ source }: { source: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { ref.current?.replaceChildren(renderText(source, () => undefined)); }, [source]);
  return <div ref={ref} className="aav-panel-body text-preview" aria-label="Formatted preview" />;
}

export function PanelsEditor({ manifest, selection, onSelect, update, issues }: { manifest: Manifest; selection: Selection;
  onSelect: (s: Selection) => void; update: Update; issues: Issue[] }) {
  const panels = manifest.panels ?? {};
  const ids = Object.keys(panels);
  const currentId = selection.kind === 'panel' && ids.includes(selection.id) ? selection.id : ids[0];
  const current = currentId ? panels[currentId] : undefined;
  const textIssues = issues.filter((i) => i.path === `/panels/${currentId}/text`);
  return (
    <div className="inspector" data-testid="panels-editor">
      <Section title="Information panels" actions={
        <button type="button" className="btn btn-small" onClick={() => {
          const id = uniqueId('panel', ids);
          update((m) => { m.panels = { ...m.panels, [id]: { title: 'New panel', text: 'Describe this part of the image.' } }; });
          onSelect({ kind: 'panel', id });
        }}>+ Panel</button>}>
        {ids.length ? (
          <ul className="list" aria-label="Panels">
            {ids.map((id) => (
              <li key={id} className={id === currentId ? 'on' : ''}>
                <button type="button" className="list-main" onClick={() => onSelect({ kind: 'panel', id })}>{panels[id].title || id} <span className="tag">{id}</span></button>
              </li>
            ))}
          </ul>
        ) : <p className="note">Panels hold the text that opens when a region is activated.</p>}
      </Section>
      {current && currentId ? (
        <Section title="Edit panel" actions={
          <button type="button" className="btn btn-small btn-danger" onClick={() => update((m) => { delete m.panels![currentId]; })}>Delete</button>}>
          <CommitField label="Identifier" value={currentId} onCommit={(v) => {
            if (ID_RE.test(v) && !ids.includes(v)) { update((m) => renamePanel(m, currentId, v)); onSelect({ kind: 'panel', id: v }); }
          }} />
          <TextField label="Title" value={current.title} onChange={(v) => update((m) => { m.panels![currentId].title = v; }, `panel:${currentId}:title`)}
            error={current.title ? null : 'A panel needs a title'} />
          <TextField label="Text" multiline rows={8} value={current.text} onChange={(v) => update((m) => { m.panels![currentId].text = v; }, `panel:${currentId}:text`)}
            error={textIssues[0]?.message ?? null}
            hint="Plain text with **bold**, *italic*, `code`, “- ” lists, “# ” headings and [label](https://…), [label](#region:id) or [label](#panel:id) links. HTML is shown as text." />
          <TextPreview source={current.text} />
        </Section>
      ) : null}
    </div>
  );
}

const NEW_ANIMATION = (m: Manifest): Animation | null => {
  for (const region of m.regions ?? []) {
    for (const [effectId, def] of Object.entries(region.effects ?? {})) {
      const prop = def.type === 'glow' ? 'intensity' : def.type === 'outline' || def.type === 'opacity' ? (def.type === 'outline' ? 'opacity' : 'amount')
        : def.type === 'pixelate' ? 'block_size' : def.type === 'blur' ? 'radius' : def.type === 'spotlight' ? 'intensity' : 'amount';
      return { type: 'pulse', region: region.id, effect: effectId, property: prop, from: 0, to: 1, duration_ms: 1200, iterations: 2 };
    }
  }
  return null;
};

export function DocumentInspector({ manifest, update, onCapture }: { manifest: Manifest; update: Update; onCapture: (() => void) | null }) {
  const doc = manifest.document;
  const setDoc = (key: string, value: string) => update((m) => {
    const d = m.document as unknown as Record<string, unknown>;
    if (value === '') delete d[key]; else d[key] = value;
  }, `doc:${key}`);
  const settings = manifest.settings ?? {};
  const setSetting = (key: string, value: unknown) => update((m) => { m.settings = { ...m.settings, [key]: value }; });
  const regions = (manifest.regions ?? []).map((r) => ({ value: r.id, label: `${r.label} (${r.id})` }));
  const groups = manifest.groups ?? {};
  const animations = manifest.animations ?? {};
  return (
    <div className="inspector" data-testid="document-inspector">
      <Section title="Document">
        <TextField label="Title" value={doc.title} onChange={(v) => setDoc('title', v)} error={doc.title ? null : 'A title is required'} />
        <TextField label="Description (alternative text for the whole image)" multiline value={doc.description ?? ''} onChange={(v) => setDoc('description', v)}
          hint="Describe what the picture shows for people who cannot see it." />
        <div className="row">
          <CommitField label="Identifier" value={doc.id} onCommit={(v) => { if (ID_RE.test(v)) setDoc('id', v); }} />
          <TextField label="Language (BCP 47)" value={doc.language ?? ''} placeholder="en" onChange={(v) => setDoc('language', v)} />
        </div>
        <p className="note">Canvas: {doc.width} × {doc.height} px, sRGB.</p>
        <CheckField label="Solid background colour" checked={doc.background !== undefined} onChange={(on) => setDoc('background', on ? '#15171A' : '')} />
        {doc.background !== undefined ? <ColourField label="Background" value={doc.background} onChange={(v) => setDoc('background', v)} /> : null}
        <div className="row">
          <TextField label="Author" value={manifest.metadata?.author ?? ''} onChange={(v) => update((m) => { m.metadata = { ...m.metadata }; if (v) m.metadata.author = v; else delete m.metadata.author; }, 'meta:author')} />
          <TextField label="Licence" value={manifest.metadata?.licence ?? ''} onChange={(v) => update((m) => { m.metadata = { ...m.metadata }; if (v) m.metadata.licence = v; else delete m.metadata.licence; }, 'meta:licence')} />
        </div>
      </Section>
      <Section title="Viewer behaviour">
        <SelectField label="Selection" value={settings.selection ?? 'single'} onChange={(v) => setSetting('selection', v || 'single')}
          options={[{ value: 'single', label: 'One region at a time' }, { value: 'multiple', label: 'Several regions (toggle)' }, { value: 'none', label: 'No selection' }]} />
        <CheckField label="Default hover/selection highlight for unstyled regions" checked={settings.default_highlight !== false} onChange={(v) => setSetting('default_highlight', v)} />
        <CheckField label="Allow pan and zoom" checked={settings.pan_zoom !== false} onChange={(v) => setSetting('pan_zoom', v)} />
        <SelectField label="Enlarged image" value={settings.image_rendering ?? 'smooth'} onChange={(v) => setSetting('image_rendering', v || 'smooth')}
          options={[{ value: 'smooth', label: 'Smooth' }, { value: 'pixelated', label: 'Crisp pixels' }]} />
      </Section>
      <Section title="Default state">
        <p className="note">
          Saved state: {manifest.default_state?.selected?.length ? `selected ${manifest.default_state.selected.join(', ')}` : 'nothing selected'};{' '}
          {manifest.default_state?.panel ? `panel “${manifest.default_state.panel}” open` : 'no panel open'}.
          What you do in Preview is not saved unless you capture it.
        </p>
        <div className="row">
          <button type="button" className="btn btn-small" disabled={!onCapture} onClick={() => onCapture?.()}
            title={onCapture ? '' : 'Switch to Preview, set up the state, then capture it'}>Capture current preview state</button>
          <button type="button" className="btn btn-small" disabled={!manifest.default_state} onClick={() => update((m) => { delete m.default_state; })}>Clear</button>
        </div>
      </Section>
      <Section title="Region groups" actions={
        <button type="button" className="btn btn-small" disabled={!regions.length} onClick={() => update((m) => {
          m.groups = { ...m.groups, [uniqueId('group', Object.keys(m.groups ?? {}))]: { label: 'New group', regions: [m.regions![0].id] } };
        })}>+ Group</button>}>
        {Object.entries(groups).map(([gid, group]) => (
          <div className="effect" key={gid}>
            <div className="effect-head"><strong>{gid}</strong>
              <button type="button" className="btn-icon" aria-label={`Remove group ${gid}`} onClick={() => update((m) => { delete m.groups![gid]; })}>✕</button></div>
            <TextField label="Label" value={group.label} onChange={(v) => update((m) => { m.groups![gid].label = v; }, `group:${gid}`)} />
            <fieldset className="checks"><legend>Members</legend>
              {regions.map((r) => (
                <CheckField key={r.value} label={r.label} checked={group.regions.includes(r.value)} onChange={(on) => update((m) => {
                  const g = m.groups![gid];
                  g.regions = on ? [...g.regions, r.value] : g.regions.filter((id) => id !== r.value);
                })} />
              ))}
            </fieldset>
          </div>
        ))}
      </Section>
      <Section title="Animations" actions={
        <button type="button" className="btn btn-small" disabled={!NEW_ANIMATION(manifest)} title={NEW_ANIMATION(manifest) ? '' : 'Add an effect to a region first'}
          onClick={() => update((m) => { const a = NEW_ANIMATION(m); if (a) m.animations = { ...m.animations, [uniqueId('animation', Object.keys(m.animations ?? {}))]: a }; })}>+ Animation</button>}>
        {Object.entries(animations).map(([aid, anim]) => {
          const region = (manifest.regions ?? []).find((r) => r.id === anim.region);
          const set = (key: string, value: unknown) => update((m) => { (m.animations![aid] as unknown as Record<string, unknown>)[key] = value; }, `anim:${aid}:${key}`);
          return (
            <div className="effect" key={aid}>
              <div className="effect-head"><strong>{aid}</strong>
                <button type="button" className="btn-icon" aria-label={`Remove animation ${aid}`} onClick={() => update((m) => { delete m.animations![aid]; })}>✕</button></div>
              <div className="row">
                <SelectField label="Type" value={anim.type} options={['pulse', 'fade']} onChange={(v) => set('type', v || 'pulse')} />
                <SelectField label="Region" value={anim.region} options={regions} onChange={(v) => set('region', v)} />
              </div>
              <div className="row">
                <SelectField label="Effect" value={anim.effect} options={Object.keys(region?.effects ?? {})} onChange={(v) => set('effect', v)} />
                <TextField label="Property" value={anim.property} onChange={(v) => set('property', v)} />
              </div>
              <div className="grid4">
                <NumberField label="From" value={anim.from} step={0.1} onChange={(v) => set('from', v)} />
                <NumberField label="To" value={anim.to} step={0.1} onChange={(v) => set('to', v)} />
                <NumberField label="Cycle (ms)" value={anim.duration_ms} min={LIMITS.runtime.min_animation_ms} max={LIMITS.runtime.max_animation_ms} step={50} onChange={(v) => set('duration_ms', v)} />
                <NumberField label="Repeats" value={anim.iterations ?? 1} min={1} max={LIMITS.runtime.max_animation_iterations} onChange={(v) => set('iterations', Math.round(v))} />
              </div>
            </div>
          );
        })}
        <p className="note">Animations run only when an action plays them, are bounded to {LIMITS.runtime.max_animation_total_ms / 1000} s in total, and are skipped when reduced motion is on.</p>
      </Section>
      <Section title="When the document opens">
        <ActionList manifest={manifest} actions={manifest.events?.document_load ?? []} trigger="document_load" selfRegion={null}
          onChange={(next) => update((m) => { if (next.length) m.events = { document_load: next }; else delete m.events; }, 'docload')} />
      </Section>
    </div>
  );
}

export function ErrorList({ manifest, issues, onSelect }: { manifest: Manifest; issues: Issue[]; onSelect: (s: Selection) => void }) {
  const errors = issues.filter(isError), warnings = issues.filter((i) => !isError(i));
  return (
    <div className="inspector" data-testid="error-list">
      <Section title={`Document check: ${errors.length} error${errors.length === 1 ? '' : 's'}, ${warnings.length} warning${warnings.length === 1 ? '' : 's'}`}>
        {!issues.length ? <p className="note ok">No problems found. The document can be saved and exported.</p> : null}
        <ul className="issues">
          {[...errors, ...warnings].map((issue, index) => {
            const target = issueTarget(manifest, issue.path);
            return (
              <li key={index} className={isError(issue) ? 'err' : 'warn'}>
                <button type="button" disabled={target.kind === 'none'} onClick={() => onSelect(target)}>
                  <strong>{isError(issue) ? 'Error' : 'Warning'}</strong> <code>{issue.path || '/'}</code><br />{issue.message} <span className="tag">{issue.code}</span>
                </button>
              </li>
            );
          })}
        </ul>
        {errors.length ? <p className="note">Saving and exporting are disabled until the errors are fixed.</p> : null}
      </Section>
    </div>
  );
}
