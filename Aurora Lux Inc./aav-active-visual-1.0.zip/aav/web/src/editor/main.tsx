import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '../viewer/viewer.css';
import './editor.css';
import { App } from './App';

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
