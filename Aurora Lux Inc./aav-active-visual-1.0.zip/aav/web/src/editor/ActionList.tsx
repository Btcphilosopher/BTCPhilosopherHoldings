/** Editor for a list of declarative actions (one trigger's handler). */
import { documentHrefProblem, externalUrlProblem } from '../core/links';
import { ACTIONS, EFFECT_TYPES, LIMITS, USER_GESTURE_ACTIONS, own } from '../core/limits';
import type { Action, ActionName, Manifest, PropValue } from '../core/types';
import { CheckField, NumberField, PropControl, SelectField, TextField } from './fields';

interface Props {
  manifest: Manifest;
  actions: Action[];
  trigger: string;
  /** Region whose handler this is; null for document_load. */
  selfRegion: string | null;
  onChange: (actions: Action[]) => void;
}

const LABELS: Record<ActionName, string> = {
  set_effect: 'Set effect value', toggle_layer: 'Show / hide layer', select_region: 'Select region',
  show_tooltip: 'Show tooltip', open_panel: 'Open information panel', navigate_document: 'Open another AAV document',
  open_link: 'Open external link', play_animation: 'Play animation', stop_animation: 'Stop animation', reset_view: 'Reset view',
};

function blank(name: ActionName, manifest: Manifest, selfRegion: string | null): Action {
  const first = <T,>(o: Record<string, T> | undefined) => Object.keys(o ?? {})[0] ?? '';
  switch (name) {
    case 'set_effect': {
      const region = (manifest.regions ?? []).find((r) => r.id === selfRegion) ?? (manifest.regions ?? []).find((r) => r.effects && Object.keys(r.effects).length);
      const effectId = first(region?.effects);
      const def = effectId ? region!.effects![effectId] : undefined;
      const prop = def ? Object.entries(EFFECT_TYPES[def.type].props).find(([, s]) => s.kind === 'number')?.[0] ?? Object.keys(EFFECT_TYPES[def.type].props)[0] : '';
      const spec = def && prop ? EFFECT_TYPES[def.type].props[prop] : undefined;
      const action: Action = { action: 'set_effect', effect: effectId, property: prop, value: (spec?.default ?? spec?.min ?? 0) as PropValue };
      if (selfRegion === null && region) action.region = region.id;
      return action;
    }
    case 'toggle_layer': return { action: 'toggle_layer', layer: manifest.layers[0]?.id ?? '', mode: 'toggle' };
    case 'select_region': return selfRegion === null ? { action: 'select_region', region: manifest.regions?.[0]?.id ?? '' } : { action: 'select_region' };
    case 'show_tooltip': return selfRegion === null ? { action: 'show_tooltip', region: manifest.regions?.[0]?.id ?? '' } : { action: 'show_tooltip' };
    case 'open_panel': return { action: 'open_panel', panel: first(manifest.panels) };
    case 'navigate_document': return { action: 'navigate_document', href: 'other.aav' };
    case 'open_link': return { action: 'open_link', url: 'https://example.org/' };
    case 'play_animation': return { action: 'play_animation', animation: first(manifest.animations) };
    case 'stop_animation': return { action: 'stop_animation' };
    default: return { action: 'reset_view' };
  }
}

export function ActionList({ manifest, actions, trigger, selfRegion, onChange }: Props) {
  const regions = (manifest.regions ?? []).map((r) => ({ value: r.id, label: `${r.label} (${r.id})` }));
  const groups = Object.entries(manifest.groups ?? {}).map(([id, g]) => ({ value: id, label: `${g.label} (${id})` }));
  const set = (index: number, next: Action) => onChange(actions.map((a, i) => (i === index ? next : a)));
  const move = (index: number, delta: number) => {
    const next = [...actions];
    const [item] = next.splice(index, 1);
    next.splice(index + delta, 0, item);
    onChange(next);
  };
  const available = ACTIONS.filter((name) => trigger === 'activate' || !USER_GESTURE_ACTIONS.includes(name));

  const targetFields = (action: Extract<Action, { action: 'set_effect' | 'select_region' }>, index: number) => {
    const mode = action.group !== undefined ? 'group' : action.region !== undefined ? 'region' : 'self';
    const modes = [...(selfRegion !== null ? [{ value: 'self', label: 'This region' }] : []),
      { value: 'region', label: 'Another region' }, ...(groups.length ? [{ value: 'group', label: 'A group' }] : [])];
    return (
      <>
        <SelectField label="Target" value={mode} options={modes} onChange={(m) => {
          const { region: _r, group: _g, ...rest } = action as Action & { region?: string; group?: string };
          set(index, (m === 'region' ? { ...rest, region: regions[0]?.value ?? '' } : m === 'group' ? { ...rest, group: groups[0]?.value ?? '' } : rest) as Action);
        }} />
        {mode === 'region' ? <SelectField label="Region" value={action.region ?? ''} options={regions} onChange={(v) => set(index, { ...action, region: v } as Action)} /> : null}
        {mode === 'group' ? <SelectField label="Group" value={action.group ?? ''} options={groups} onChange={(v) => set(index, { ...action, group: v } as Action)} /> : null}
      </>
    );
  };

  const body = (action: Action, index: number) => {
    switch (action.action) {
      case 'set_effect': {
        const targetIds = action.region !== undefined ? [action.region]
          : action.group !== undefined ? own(manifest.groups, action.group)?.regions ?? [] : selfRegion ? [selfRegion] : [];
        const targetRegions = (manifest.regions ?? []).filter((r) => targetIds.includes(r.id));
        const effectIds = [...new Set(targetRegions.flatMap((r) => Object.keys(r.effects ?? {})))];
        const def = targetRegions.map((r) => own(r.effects, action.effect)).find((d) => d && own(EFFECT_TYPES, d.type));
        const props = def ? EFFECT_TYPES[def.type].props : {};
        const spec = own(props, action.property);
        return (
          <>
            {targetFields(action, index)}
            <SelectField label="Effect" value={action.effect} options={effectIds} onChange={(v) => set(index, { ...action, effect: v })}
              error={effectIds.length ? null : 'The target has no effects yet'} />
            <SelectField label="Property" value={action.property} options={Object.keys(props)}
              onChange={(v) => set(index, { ...action, property: v, value: (own(props, v)?.default ?? own(props, v)?.min ?? 0) as PropValue })} />
            {spec ? <PropControl label="Value" spec={spec} value={action.value} onChange={(v) => set(index, { ...action, value: v })} /> : null}
            {spec?.kind === 'number'
              ? <NumberField label="Fade time (ms)" value={action.duration_ms ?? 0} min={0} max={LIMITS.runtime.max_transition_ms} step={50}
                onChange={(v) => set(index, { ...action, duration_ms: v })} hint="0 changes the value at once" />
              : null}
          </>
        );
      }
      case 'toggle_layer':
        return (
          <>
            <SelectField label="Layer" value={action.layer} options={manifest.layers.map((l) => ({ value: l.id, label: l.name ?? l.id }))}
              onChange={(v) => set(index, { ...action, layer: v })} />
            <SelectField label="Mode" value={action.mode ?? 'toggle'} options={['toggle', 'show', 'hide']}
              onChange={(v) => set(index, { ...action, mode: v || 'toggle' })} />
          </>
        );
      case 'select_region':
        return (
          <>
            {targetFields(action, index)}
            <SelectField label="Mode" value={action.mode ?? 'select'} options={['select', 'deselect', 'toggle']}
              onChange={(v) => set(index, { ...action, mode: v || 'select' })} />
            <CheckField label="Bring it into view" checked={action.reveal === true} onChange={(v) => set(index, { ...action, reveal: v })} />
          </>
        );
      case 'show_tooltip':
        return (
          <>
            <TextField label="Text" value={action.text ?? ''} placeholder="Defaults to the region tooltip or label"
              onChange={(v) => { const { text: _t, ...rest } = action; set(index, v ? { ...rest, text: v } : rest); }} />
            <SelectField label="Attach to" value={action.region ?? ''} options={regions} allowEmpty={selfRegion !== null ? 'This region' : undefined}
              onChange={(v) => { const { region: _r, ...rest } = action; set(index, v ? { ...rest, region: v } : rest); }} />
          </>
        );
      case 'open_panel':
        return <SelectField label="Panel" value={action.panel} options={Object.entries(manifest.panels ?? {}).map(([id, p]) => ({ value: id, label: `${p.title} (${id})` }))}
          onChange={(v) => set(index, { ...action, panel: v })} error={Object.keys(manifest.panels ?? {}).length ? null : 'Create a panel first (Panels tab)'} />;
      case 'open_link':
        return (
          <>
            <TextField label="HTTPS address" value={action.url} onChange={(v) => set(index, { ...action, url: v })}
              error={externalUrlProblem(action.url)} hint="The viewer shows this address and asks before opening it." />
            <TextField label="Link label" value={action.label ?? ''} onChange={(v) => { const { label: _l, ...rest } = action; set(index, v ? { ...rest, label: v } : rest); }} />
          </>
        );
      case 'navigate_document':
        return (
          <>
            <TextField label="Document (relative .aav path or https URL)" value={action.href} onChange={(v) => set(index, { ...action, href: v })}
              error={documentHrefProblem(action.href)} hint="Opened only after the user confirms." />
            <TextField label="Link label" value={action.label ?? ''} onChange={(v) => { const { label: _l, ...rest } = action; set(index, v ? { ...rest, label: v } : rest); }} />
          </>
        );
      case 'play_animation':
      case 'stop_animation':
        return <SelectField label="Animation" value={action.animation ?? ''} options={Object.keys(manifest.animations ?? {})}
          allowEmpty={action.action === 'stop_animation' ? 'All animations' : undefined}
          onChange={(v) => {
            if (action.action === 'play_animation') set(index, { ...action, animation: v });
            else set(index, v ? { action: 'stop_animation', animation: v } : { action: 'stop_animation' });
          }}
          error={action.action === 'play_animation' && !Object.keys(manifest.animations ?? {}).length ? 'Create an animation first (Document tab)' : null} />;
      default:
        return null;
    }
  };

  return (
    <div className="actions">
      {actions.map((action, index) => (
        <div className="action" key={index}>
          <div className="action-head">
            <SelectField label={`Action ${index + 1}`} value={action.action} options={available.map((n) => ({ value: n, label: LABELS[n] }))}
              onChange={(v) => { if (v) set(index, blank(v, manifest, selfRegion)); }} />
            <span className="action-tools">
              <button type="button" className="btn-icon" aria-label={`Move action ${index + 1} up`} disabled={index === 0} onClick={() => move(index, -1)}>↑</button>
              <button type="button" className="btn-icon" aria-label={`Move action ${index + 1} down`} disabled={index === actions.length - 1} onClick={() => move(index, 1)}>↓</button>
              <button type="button" className="btn-icon" aria-label={`Remove action ${index + 1}`} onClick={() => onChange(actions.filter((_, i) => i !== index))}>✕</button>
            </span>
          </div>
          {body(action, index)}
        </div>
      ))}
      <button type="button" className="btn btn-small" disabled={actions.length >= LIMITS.manifest.max_actions_per_handler}
        onClick={() => onChange([...actions, blank(trigger === 'activate' ? 'open_panel' : 'set_effect', manifest, selfRegion)])}>
        Add action
      </button>
    </div>
  );
}
