/** File input and output for the editor. Everything stays in the browser. */
import { buildStandaloneHtml } from '../core/htmlexport';
import { sniffImage } from '../core/imageinfo';
import { LIMITS } from '../core/limits';
import { migrate, needsMigration } from '../core/migrate';
import { completeAssets, loadUnvalidated, savePackage, validatePackage } from '../core/package';
import { redactPackage } from '../core/redact';
import { canvasToPng, decodeAssets, makeCanvas, makeThumbnail, renderPreviewPng } from '../core/renderer';
import template from '../core/standalone-template.html?raw';
import type { AavPackage, Manifest } from '../core/types';
import { AavError, errorsOnly } from '../core/types';
import { PREVIEW } from '../core/zip';
import type { EditorDoc } from './store';
import { newManifest, slugify } from './store';

const EXT: Record<string, string> = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };
const M = LIMITS.manifest;

export interface ImportedImage { bytes: Uint8Array; mediaType: string; width: number; height: number }

/**
 * Accept PNG, JPEG and WebP as they are. Anything else the browser can decode
 * (GIF, BMP, AVIF...) is converted to PNG, since those types may not be packaged.
 */
export async function readImage(file: Blob): Promise<ImportedImage> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const info = sniffImage(bytes);
  if (info) {
    if (info.width > LIMITS.image.max_dimension || info.height > LIMITS.image.max_dimension) {
      throw new AavError(`image is ${info.width}x${info.height}; the limit is ${LIMITS.image.max_dimension} pixels per side`);
    }
    return { bytes, mediaType: info.mediaType, width: info.width, height: info.height };
  }
  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new AavError('this file is not an image the browser can read');
  }
  if (bitmap.width > LIMITS.image.max_dimension || bitmap.height > LIMITS.image.max_dimension) {
    throw new AavError(`image is ${bitmap.width}x${bitmap.height}; the limit is ${LIMITS.image.max_dimension} pixels per side`);
  }
  const { canvas, ctx } = makeCanvas(bitmap.width, bitmap.height);
  ctx.drawImage(bitmap, 0, 0);
  const png = await canvasToPng(canvas);
  return { bytes: png, mediaType: 'image/png', width: bitmap.width, height: bitmap.height };
}

/** Start a new document from an image. */
export async function importImage(file: File): Promise<EditorDoc> {
  const image = await readImage(file);
  if (image.width > M.max_dimension || image.height > M.max_dimension || image.width * image.height > M.max_document_pixels) {
    throw new AavError(`image is ${image.width}x${image.height}; documents are limited to ${M.max_dimension} pixels per side ` +
      `and ${M.max_document_pixels} pixels in total`);
  }
  const title = file.name.replace(/\.[^.]+$/, '') || 'Untitled';
  const path = `assets/base.${EXT[image.mediaType]}`;
  return { manifest: newManifest(title, image.width, image.height, path, image.mediaType), files: new Map([[path, image.bytes]]) };
}

/**
 * Prepare a mask asset. Masks need an alpha channel: an image that is fully
 * opaque is converted so that its brightness becomes the alpha (white = inside).
 */
export async function readMask(file: Blob): Promise<ImportedImage> {
  const bitmap = await createImageBitmap(file).catch(() => { throw new AavError('this file is not an image the browser can read'); });
  if (bitmap.width > LIMITS.image.max_dimension || bitmap.height > LIMITS.image.max_dimension) {
    throw new AavError('mask image is too large');
  }
  const { canvas, ctx } = makeCanvas(bitmap.width, bitmap.height, true);
  ctx.drawImage(bitmap, 0, 0);
  const img = ctx.getImageData(0, 0, bitmap.width, bitmap.height);
  let opaque = true;
  for (let i = 3; i < img.data.length; i += 4) if (img.data[i] < 255) { opaque = false; break; }
  for (let i = 0; i < img.data.length; i += 4) {
    if (opaque) img.data[i + 3] = Math.round(0.2126 * img.data[i] + 0.7152 * img.data[i + 1] + 0.0722 * img.data[i + 2]);
    img.data[i] = img.data[i + 1] = img.data[i + 2] = 255; // masks carry coverage only
  }
  ctx.putImageData(img, 0, 0);
  return { bytes: await canvasToPng(canvas), mediaType: 'image/png', width: bitmap.width, height: bitmap.height };
}

/** Add image bytes to a document as a new asset; returns the asset id. */
export function addAsset(doc: EditorDoc, manifest: Manifest, image: ImportedImage, folder: 'assets' | 'masks', hint: string):
  { id: string; files: Map<string, Uint8Array> } {
  const taken = new Set(Object.keys(manifest.assets ?? {}));
  const paths = new Set(Object.values(manifest.assets ?? {}).map((a) => a.path.toLowerCase()));
  const base = slugify(hint, folder === 'masks' ? 'mask' : 'image').slice(0, 40);
  let id = base;
  for (let n = 2; taken.has(id) || paths.has(`${folder}/${id}.${EXT[image.mediaType]}`); n++) id = `${base}-${n}`;
  const path = `${folder}/${id}.${EXT[image.mediaType]}`;
  manifest.assets = { ...manifest.assets, [id]: { path, media_type: image.mediaType as 'image/png' } };
  const files = new Map(doc.files);
  files.set(path, image.bytes);
  return { id, files };
}

/** Open an .aav file for editing. Pre-release drafts are migrated. Throws AavError; the caller keeps its current document. */
export async function openAav(bytes: Uint8Array): Promise<{ doc: EditorDoc; notes: string[] }> {
  const pkg = loadUnvalidated(bytes);
  const notes: string[] = [];
  if (needsMigration(pkg.manifest)) {
    const result = migrate(pkg.manifest);
    pkg.manifest = result.manifest as unknown as Manifest;
    notes.push(`Migrated from an older schema (${result.steps.join(', ')}). Save to keep the upgrade.`);
  }
  const issues = await validatePackage(pkg, { requirePreview: false });
  if (errorsOnly(issues).length) throw new AavError(errorsOnly(issues));
  for (const issue of issues) if (issue.code !== 'W_UNREFERENCED') notes.push(`${issue.code}: ${issue.message}`);
  const used = new Set(Object.values(pkg.manifest.assets ?? {}).map((a) => a.path));
  const files = new Map([...pkg.files].filter(([name]) => used.has(name)));
  const manifest = pkg.manifest;
  delete manifest.thumbnail;
  return { doc: { manifest, files }, notes };
}

/** Build the complete package for saving: asset records, a fresh preview and thumbnail, nothing unreferenced. */
export async function buildPackage(doc: EditorDoc): Promise<AavPackage> {
  const manifest = structuredClone(doc.manifest);
  const used = new Set(Object.values(manifest.assets ?? {}).map((a) => a.path));
  const pkg: AavPackage = { manifest, files: new Map([...doc.files].filter(([name]) => used.has(name))) };
  manifest.preview = PREVIEW;
  delete manifest.thumbnail;
  manifest.metadata = { ...manifest.metadata, generator: 'aav-editor 1.0.0' };
  await completeAssets(pkg);
  const errors = errorsOnly(await validatePackage(pkg, { requirePreview: false }));
  if (errors.length) throw new AavError(errors);
  const preview = await renderPreviewPng(manifest, await decodeAssets(pkg));
  pkg.files.set(PREVIEW, preview);
  manifest.thumbnail = 'thumbnails/preview.png';
  pkg.files.set(manifest.thumbnail, await makeThumbnail(preview));
  return pkg;
}

export async function saveAav(doc: EditorDoc): Promise<Uint8Array> {
  return savePackage(await buildPackage(doc), { strict: true });
}

export async function exportPng(doc: EditorDoc): Promise<Uint8Array> {
  return (await buildPackage(doc)).files.get(PREVIEW)!;
}

export async function exportHtml(doc: EditorDoc): Promise<string> {
  const fetchText = async (name: string) => {
    const response = await fetch(new URL(`standalone/${name}`, document.baseURI), { cache: 'no-store' });
    if (!response.ok) throw new AavError(`the viewer bundle (${name}) is not available; run "npm run build" in web/`);
    return response.text();
  };
  const [script, style] = await Promise.all([fetchText('aav-viewer.iife.js'), fetchText('aav-viewer.css')]);
  return buildStandaloneHtml({ template, script, style }, await buildPackage(doc));
}

export async function exportRedacted(doc: EditorDoc, regionIds: string[], colour: string): Promise<Uint8Array> {
  return savePackage(await redactPackage(await buildPackage(doc), regionIds, colour), { strict: true });
}

export function download(data: Uint8Array | string, filename: string, type: string): void {
  const blob = new Blob([data as BlobPart], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}
