/** Editor document model, undo/redo history and manifest editing helpers. Pure logic, unit-tested under Node. */
import { EFFECT_TYPES, FORMAT, VERSION } from '../core/limits';
import type { Action, EffectDef, EffectType, Issue, Manifest, PropValue, Region } from '../core/types';
import { validateManifest } from '../core/validate';

export interface EditorDoc { manifest: Manifest; files: Map<string, Uint8Array> }
export type Selection = { kind: 'none' } | { kind: 'region' | 'layer' | 'panel'; id: string };
export type Tool = 'select' | 'rect' | 'polygon' | 'pan';

export interface EditorState {
  doc: EditorDoc | null;
  past: EditorDoc[];
  future: EditorDoc[];
  selection: Selection;
  tool: Tool;
  mode: 'edit' | 'preview';
  dirty: boolean;
  /** Key and time of the last change, used to merge a drag or a slider sweep into one undo step. */
  lastKey: string | null;
  lastTime: number;
}

export type EditorAction =
  | { type: 'load'; doc: EditorDoc | null }
  | { type: 'change'; doc: EditorDoc; key?: string; time?: number }
  | { type: 'undo' } | { type: 'redo' } | { type: 'saved' }
  | { type: 'select'; selection: Selection }
  | { type: 'tool'; tool: Tool }
  | { type: 'mode'; mode: 'edit' | 'preview' };

export const HISTORY_LIMIT = 100;
const MERGE_WINDOW_MS = 800;

export const initialState: EditorState = {
  doc: null, past: [], future: [], selection: { kind: 'none' }, tool: 'select', mode: 'edit', dirty: false,
  lastKey: null, lastTime: 0,
};

/** Drop a selection whose target no longer exists (after undo, delete or rename). */
function keepSelection(selection: Selection, doc: EditorDoc | null): Selection {
  if (!doc || selection.kind === 'none') return { kind: 'none' };
  const m = doc.manifest;
  const exists = selection.kind === 'region' ? (m.regions ?? []).some((r) => r.id === selection.id)
    : selection.kind === 'layer' ? m.layers.some((l) => l.id === selection.id)
      : Object.prototype.hasOwnProperty.call(m.panels ?? {}, selection.id);
  return exists ? selection : { kind: 'none' };
}

export function reducer(state: EditorState, action: EditorAction): EditorState {
  switch (action.type) {
    case 'load':
      return { ...initialState, doc: action.doc, tool: state.tool };
    case 'change': {
      if (!state.doc) return state;
      const time = action.time ?? Date.now();
      const merge = action.key !== undefined && action.key === state.lastKey && time - state.lastTime < MERGE_WINDOW_MS
        && state.past.length > 0;
      const past = merge ? state.past : [...state.past, state.doc].slice(-HISTORY_LIMIT);
      return { ...state, doc: action.doc, past, future: [], dirty: true, lastKey: action.key ?? null, lastTime: time,
        selection: keepSelection(state.selection, action.doc) };
    }
    case 'undo': {
      if (!state.doc || !state.past.length) return state;
      const doc = state.past[state.past.length - 1];
      return { ...state, doc, past: state.past.slice(0, -1), future: [state.doc, ...state.future], dirty: true,
        lastKey: null, selection: keepSelection(state.selection, doc) };
    }
    case 'redo': {
      if (!state.doc || !state.future.length) return state;
      const doc = state.future[0];
      return { ...state, doc, past: [...state.past, state.doc], future: state.future.slice(1), dirty: true,
        lastKey: null, selection: keepSelection(state.selection, doc) };
    }
    case 'saved':
      return { ...state, dirty: false };
    case 'select':
      return { ...state, selection: keepSelection(action.selection, state.doc) };
    case 'tool':
      return { ...state, tool: action.tool };
    case 'mode':
      return { ...state, mode: action.mode };
    default:
      return state;
  }
}

// ----------------------------------------------------------------------------- manifest helpers

export function newManifest(title: string, width: number, height: number, assetPath: string, mediaType: string): Manifest {
  return {
    format: FORMAT, version: VERSION,
    document: { id: slugify(title), title, width, height, colour_space: 'srgb' },
    metadata: { generator: 'aav-editor 1.0.0' },
    assets: { base: { path: assetPath, media_type: mediaType as 'image/png' } },
    layers: [{ id: 'background', type: 'image', asset: 'base', name: 'Background' }],
    regions: [], panels: {}, preview: 'preview.png',
  };
}

export function slugify(text: string, fallback = 'document'): string {
  const slug = text.trim().replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^[-._]+|[-._]+$/g, '').toLowerCase().slice(0, 64);
  return slug || fallback;
}

export function uniqueId(prefix: string, taken: Iterable<string>): string {
  const used = new Set(taken);
  for (let n = 1; ; n++) {
    const id = `${prefix}-${n}`;
    if (!used.has(id)) return id;
  }
}

/** Visit every action in the manifest (region handlers and document_load). */
export function forEachAction(m: Manifest, visit: (action: Action) => void): void {
  for (const region of m.regions ?? []) {
    for (const actions of Object.values(region.events ?? {})) actions?.forEach(visit);
  }
  m.events?.document_load?.forEach(visit);
}

function retargetText(m: Manifest, kind: 'region' | 'panel', from: string, to: string): void {
  for (const panel of Object.values(m.panels ?? {})) {
    panel.text = panel.text.split(`(#${kind}:${from})`).join(`(#${kind}:${to})`);
  }
}

/** Rename a region and every reference to it. */
export function renameRegion(m: Manifest, from: string, to: string): void {
  for (const region of m.regions ?? []) if (region.id === from) region.id = to;
  for (const group of Object.values(m.groups ?? {})) group.regions = group.regions.map((id) => (id === from ? to : id));
  forEachAction(m, (a) => { if ('region' in a && a.region === from) a.region = to; });
  for (const anim of Object.values(m.animations ?? {})) if (anim.region === from) anim.region = to;
  if (m.default_state?.selected) m.default_state.selected = m.default_state.selected.map((id) => (id === from ? to : id));
  if (m.redaction) m.redaction.regions = m.redaction.regions.map((id) => (id === from ? to : id));
  retargetText(m, 'region', from, to);
}

export function renameLayer(m: Manifest, from: string, to: string): void {
  for (const layer of m.layers) if (layer.id === from) layer.id = to;
  for (const region of m.regions ?? []) if (region.target_layer === from) region.target_layer = to;
  forEachAction(m, (a) => { if (a.action === 'toggle_layer' && a.layer === from) a.layer = to; });
}

export function renamePanel(m: Manifest, from: string, to: string): void {
  if (!m.panels || !(from in m.panels) || to in m.panels) return;
  m.panels = Object.fromEntries(Object.entries(m.panels).map(([id, panel]) => [id === from ? to : id, panel]));
  forEachAction(m, (a) => { if (a.action === 'open_panel' && a.panel === from) a.panel = to; });
  if (m.default_state?.panel === from) m.default_state.panel = to;
  retargetText(m, 'panel', from, to);
}

/** Remove a region and the references that can be dropped silently. Actions that named it are left for the error list. */
export function deleteRegion(m: Manifest, id: string): void {
  m.regions = (m.regions ?? []).filter((r) => r.id !== id);
  for (const [gid, group] of Object.entries(m.groups ?? {})) {
    group.regions = group.regions.filter((r) => r !== id);
    if (!group.regions.length) delete m.groups![gid];
  }
  if (m.default_state?.selected) m.default_state.selected = m.default_state.selected.filter((r) => r !== id);
  for (const [aid, anim] of Object.entries(m.animations ?? {})) if (anim.region === id) delete m.animations![aid];
}

/** A new effect of the given type with every property at its documented default. */
export function defaultEffect(type: EffectType): EffectDef {
  const effect: EffectDef = { type };
  for (const [name, spec] of Object.entries(EFFECT_TYPES[type].props)) {
    if (spec.default !== null) effect[name] = spec.default as PropValue;
  }
  return effect;
}

/** Highlight preset: outline and tint that appear on hover and focus, and stay (in violet) while selected. */
export function applyHighlightPreset(region: Region): void {
  region.effects = {
    ...region.effects,
    edge: { type: 'outline', colour: '#5AD8E6', width: 3, opacity: 0 },
    wash: { type: 'tint', colour: '#5AD8E6', amount: 0, mode: 'normal' },
  };
  const on = { edge: { opacity: 1 }, wash: { amount: 0.16 } };
  region.states = {
    ...region.states,
    hover: { ...region.states?.hover, ...on },
    focus: { ...region.states?.focus, ...on },
    selected: { ...region.states?.selected, edge: { opacity: 1, colour: '#A78BFA' }, wash: { amount: 0.22, colour: '#A78BFA' } },
  };
}

/** Glow preset: light that fades in on hover, using set_effect actions as in the specification's example. */
export function applyGlowPreset(region: Region): void {
  region.effects = { ...region.effects, illumination: { type: 'glow', colour: '#FFD47A', intensity: 0, radius: 18 } };
  const set = (value: number): Action => ({ action: 'set_effect', effect: 'illumination', property: 'intensity', value, duration_ms: 200 });
  region.events = {
    ...region.events,
    pointer_enter: [...(region.events?.pointer_enter ?? []).filter((a) => !(a.action === 'set_effect' && a.effect === 'illumination')), set(0.8)],
    pointer_leave: [...(region.events?.pointer_leave ?? []).filter((a) => !(a.action === 'set_effect' && a.effect === 'illumination')), set(0)],
  };
  region.states = { ...region.states, focus: { ...region.states?.focus, illumination: { intensity: 0.8 } } };
}

/** Manifest issues plus the file-level problems the editor can see without hashing. */
export function documentIssues(doc: EditorDoc): Issue[] {
  const issues = validateManifest(doc.manifest);
  for (const [id, asset] of Object.entries(doc.manifest.assets ?? {})) {
    if (asset && typeof asset.path === 'string' && !doc.files.has(asset.path)) {
      issues.push({ code: 'E_ARCHIVE_MISSING', path: `/assets/${id}`, message: `file '${asset.path}' is missing` });
    }
  }
  return issues;
}

/** Map an issue path such as /regions/3/effects/glow to the thing to select. */
export function issueTarget(manifest: Manifest, path: string): Selection {
  const parts = path.split('/').slice(1);
  if (parts[0] === 'regions' && parts[1] !== undefined) {
    const region = (manifest.regions ?? [])[Number(parts[1])];
    if (region && typeof region.id === 'string') return { kind: 'region', id: region.id };
  }
  if (parts[0] === 'layers' && parts[1] !== undefined) {
    const layer = manifest.layers[Number(parts[1])];
    if (layer && typeof layer.id === 'string') return { kind: 'layer', id: layer.id };
  }
  if (parts[0] === 'panels' && parts[1] !== undefined) return { kind: 'panel', id: parts[1] };
  return { kind: 'none' };
}
