/** Inspector for one region: identity, accessibility text, geometry, effects per state, and trigger handlers. */
import { useRef } from 'react';
import { EFFECT_TYPES, LIMITS, PIPELINE, TRIGGERS, own } from '../core/limits';
import type { EffectType, Manifest, PropValue, Region, StateName, Trigger } from '../core/types';
import { shapeBounds } from '../core/validate';
import { ActionList } from './ActionList';
import { CheckField, CommitField, NumberField, PropControl, Section, SelectField, TextField } from './fields';
import { applyGlowPreset, applyHighlightPreset, defaultEffect, deleteRegion, renameRegion } from './store';

interface Props {
  manifest: Manifest;
  region: Region;
  stateTab: StateName | null;
  onStateTab: (state: StateName | null) => void;
  update: (fn: (draft: Manifest) => void, key?: string) => void;
  onImportMask: (file: File, regionId: string) => void;
}

const ID_RE = new RegExp(LIMITS.manifest.id_pattern);
const TRIGGER_LABELS: Record<Trigger, string> = {
  pointer_enter: 'Pointer enters (hover starts)', pointer_leave: 'Pointer leaves', activate: 'Activate (click, tap, Enter, Space)',
  focus: 'Keyboard focus arrives', blur: 'Keyboard focus leaves',
};
const STATE_TABS: { id: StateName | null; label: string }[] = [
  { id: null, label: 'Saved' }, { id: 'hover', label: 'Hover' }, { id: 'selected', label: 'Selected' }, { id: 'focus', label: 'Focus' },
];

export function RegionInspector({ manifest, region, stateTab, onStateTab, update, onImportMask }: Props) {
  const maskInput = useRef<HTMLInputElement>(null);
  const doc = manifest.document;
  const edit = (fn: (r: Region, m: Manifest) => void, key?: string) => update((m) => {
    const target = (m.regions ?? []).find((r) => r.id === region.id);
    if (target) fn(target, m);
  }, key);
  const ids = (manifest.regions ?? []).map((r) => r.id);
  const shape = region.shape;
  const bounds = shapeBounds(shape, doc.width, doc.height);
  const usedTypes = new Set(Object.values(region.effects ?? {}).map((e) => e.type));
  const freeTypes = PIPELINE.filter((t) => !usedTypes.has(t));
  const needsTarget = Object.values(region.effects ?? {}).some((e) => EFFECT_TYPES[e.type]?.stage !== 'overlay');

  const setBox = (key: 'x' | 'y' | 'width' | 'height', value: number) => edit((r) => {
    if (r.shape.type === 'polygon') return;
    const b = shapeBounds(r.shape, doc.width, doc.height);
    r.shape = { ...r.shape, x: b.x, y: b.y, width: b.width, height: b.height, [key]: value };
  }, `geometry:${region.id}`);

  return (
    <div className="inspector" data-testid="region-inspector">
      <Section title="Region" actions={<button type="button" className="btn btn-small btn-danger" onClick={() => update((m) => deleteRegion(m, region.id))}>Delete</button>}>
        <TextField label="Name (read by screen readers)" value={region.label} onChange={(v) => edit((r) => { r.label = v; }, `label:${region.id}`)}
          error={region.label.trim() ? null : 'A region needs a name'} />
        <CommitField label="Identifier" value={region.id} hint="Stable id used by actions and links."
          onCommit={(v) => { if (ID_RE.test(v) && !ids.includes(v)) update((m) => renameRegion(m, region.id, v)); }}
          error={null} />
        <TextField label="Description (accessibility)" value={region.description ?? ''} multiline rows={2}
          onChange={(v) => edit((r) => { if (v) r.description = v; else delete r.description; }, `desc:${region.id}`)} />
        <TextField label="Tooltip text" value={region.tooltip ?? ''}
          onChange={(v) => edit((r) => { if (v) r.tooltip = v; else delete r.tooltip; }, `tip:${region.id}`)} />
        <SelectField label="Effects apply to" value={region.target_layer ?? ''} allowEmpty="The whole composite"
          options={manifest.layers.map((l) => ({ value: l.id, label: l.name ?? l.id }))}
          onChange={(v) => edit((r) => { if (v) r.target_layer = v; else delete r.target_layer; })} />
        <div className="row">
          <NumberField label="Stacking (z-index)" value={region.z_index ?? 0} min={-1000} max={1000} onChange={(v) => edit((r) => { r.z_index = Math.round(v); }, `z:${region.id}`)} />
          <CheckField label="Interactive" checked={region.interactive !== false} onChange={(v) => edit((r) => { if (v) delete r.interactive; else r.interactive = false; })} />
          <CheckField label="Selectable" checked={region.selectable !== false} onChange={(v) => edit((r) => { if (v) delete r.selectable; else r.selectable = false; })} />
        </div>
      </Section>

      <Section title={`Geometry (${shape.type})`}>
        {shape.type === 'polygon' ? (
          <TextField label={`Points (${shape.points.length}), one "x, y" per line`} multiline rows={Math.min(8, shape.points.length)}
            value={shape.points.map((p) => `${p[0]}, ${p[1]}`).join('\n')}
            onChange={(v) => {
              const points = v.split('\n').map((line) => line.split(',').map((n) => Number(n.trim()))).filter((p) => p.length === 2 && p.every(Number.isFinite)) as [number, number][];
              if (points.length >= 3) edit((r) => { r.shape = { type: 'polygon', points }; }, `geometry:${region.id}`);
            }} hint="Drag the handles on the canvas, or edit the numbers here." />
        ) : (
          <div className="grid4">
            <NumberField label="X" value={bounds.x} onChange={(v) => setBox('x', v)} />
            <NumberField label="Y" value={bounds.y} onChange={(v) => setBox('y', v)} />
            <NumberField label="Width" value={bounds.width} min={1} onChange={(v) => { if (v > 0) setBox('width', v); }} />
            <NumberField label="Height" value={bounds.height} min={1} onChange={(v) => { if (v > 0) setBox('height', v); }} />
          </div>
        )}
        {shape.type === 'mask' ? (
          <>
            <NumberField label="Alpha threshold for hit testing" value={shape.threshold ?? 0.5} min={0.01} max={1} step={0.05}
              onChange={(v) => edit((r) => { if (r.shape.type === 'mask' && v > 0 && v <= 1) r.shape.threshold = v; }, `thr:${region.id}`)} />
            <SelectField label="Pointer hits" value={shape.hit_test ?? 'alpha'} options={[{ value: 'alpha', label: 'Opaque pixels only' }, { value: 'bounds', label: 'The whole box' }]}
              onChange={(v) => edit((r) => { if (r.shape.type === 'mask') r.shape.hit_test = (v || 'alpha') as 'alpha' | 'bounds'; })} />
          </>
        ) : null}
        <input ref={maskInput} type="file" accept="image/*" className="visually-hidden" aria-label="Choose a mask image"
          onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) onImportMask(f, region.id); }} />
        <button type="button" className="btn btn-small" onClick={() => maskInput.current?.click()}>
          {shape.type === 'mask' ? 'Replace mask image…' : 'Use a mask image for this region…'}
        </button>
      </Section>

      <Section title="Highlight and effects">
        <div className="row">
          <button type="button" className="btn btn-small" onClick={() => edit(applyHighlightPreset)}>Add highlight (outline + tint)</button>
          <button type="button" className="btn btn-small" onClick={() => edit(applyGlowPreset)}>Add glow on hover</button>
        </div>
        {!region.states && !Object.keys(region.effects ?? {}).length
          ? <p className="note">No custom styling yet: the viewer's default hover and selection highlight is used.</p> : null}
        {needsTarget && !region.target_layer ? <p className="note">These effects act on the whole composite. Choose a layer above to confine them to one layer.</p> : null}
        <div className="tabs" role="tablist" aria-label="Interaction state being edited">
          {STATE_TABS.map((tab) => (
            <button key={tab.label} type="button" role="tab" aria-selected={stateTab === tab.id} className={stateTab === tab.id ? 'on' : ''}
              onClick={() => onStateTab(tab.id)}>{tab.label}</button>
          ))}
        </div>
        <p className="note">
          {stateTab === null ? 'Values saved in the document: how the region looks when nothing is happening.'
            : `Tick a property to override it while the region is in the "${stateTab}" state. The canvas previews that state.`}
        </p>
        {Object.entries(region.effects ?? {}).map(([effectId, def]) => {
          const spec = own(EFFECT_TYPES, def.type);
          if (!spec) return <p key={effectId} className="note">Unknown effect type “{String(def.type)}”.</p>;
          const overrides = stateTab ? region.states?.[stateTab]?.[effectId] ?? {} : null;
          return (
            <div className="effect" key={effectId}>
              <div className="effect-head">
                <strong>{effectId}</strong><span className="tag">{def.type}</span>
                <button type="button" className="btn-icon" aria-label={`Remove effect ${effectId}`} onClick={() => edit((r) => {
                  delete r.effects![effectId];
                  for (const s of ['hover', 'selected', 'focus'] as StateName[]) if (r.states?.[s]) delete r.states[s]![effectId];
                })}>✕</button>
              </div>
              {Object.entries(spec.props).map(([prop, propSpec]) => {
                if (propSpec.default === null && def[prop] === undefined && stateTab === null) {
                  return <CheckField key={prop} label={`Set a custom ${prop}`} checked={false} onChange={() => edit((r) => {
                    r.effects![effectId][prop] = prop === 'x' ? bounds.x + bounds.width / 2 : bounds.y + bounds.height / 2;
                  })} />;
                }
                const base = def[prop] ?? propSpec.default;
                if (overrides === null) {
                  return <PropControl key={prop} label={prop} spec={propSpec} value={base}
                    onChange={(v) => edit((r) => { r.effects![effectId][prop] = v; }, `fx:${region.id}:${effectId}:${prop}`)} />;
                }
                const active = Object.prototype.hasOwnProperty.call(overrides, prop);
                return (
                  <div className={`override${active ? ' on' : ''}`} key={prop}>
                    <CheckField label={`Override ${prop}`} checked={active} onChange={(on) => edit((r) => {
                      const st = stateTab!;
                      r.states = { ...r.states, [st]: { ...r.states?.[st] } };
                      const forEffect = { ...r.states[st]![effectId] };
                      if (on) forEffect[prop] = (base ?? propSpec.min ?? 0) as PropValue;
                      else delete forEffect[prop];
                      if (Object.keys(forEffect).length) r.states[st]![effectId] = forEffect;
                      else delete r.states[st]![effectId];
                      if (!Object.keys(r.states[st]!).length) delete r.states[st];
                      if (!Object.keys(r.states).length) delete r.states;
                    })} />
                    {active ? <PropControl label={prop} spec={propSpec} value={overrides[prop]}
                      onChange={(v) => edit((r) => { r.states![stateTab!]![effectId][prop] = v; }, `st:${region.id}:${stateTab}:${effectId}:${prop}`)} /> : null}
                  </div>
                );
              })}
            </div>
          );
        })}
        {freeTypes.length ? (
          <SelectField label="Add an effect" value="" allowEmpty="Choose a type…" options={freeTypes.map((t) => ({ value: t, label: `${t}: ${EFFECT_TYPES[t].summary}` }))}
            onChange={(type) => { if (type) edit((r) => { r.effects = { ...r.effects, [uniqueEffectId(r, type)]: defaultEffect(type as EffectType) }; }); }} />
        ) : null}
      </Section>

      <Section title="Triggers and actions">
        {TRIGGERS.map((trigger) => {
          const actions = region.events?.[trigger] ?? [];
          return (
            <details key={trigger} open={actions.length > 0} className="trigger">
              <summary>{TRIGGER_LABELS[trigger]} <span className="tag">{actions.length}</span></summary>
              <ActionList manifest={manifest} actions={actions} trigger={trigger} selfRegion={region.id}
                onChange={(next) => edit((r) => {
                  r.events = { ...r.events };
                  if (next.length) r.events[trigger] = next;
                  else delete r.events[trigger];
                  if (!Object.keys(r.events).length) delete r.events;
                }, `ev:${region.id}:${trigger}`)} />
            </details>
          );
        })}
      </Section>
    </div>
  );
}

function uniqueEffectId(region: Region, type: string): string {
  const taken = new Set(Object.keys(region.effects ?? {}));
  if (!taken.has(type)) return type;
  for (let n = 2; ; n++) if (!taken.has(`${type}-${n}`)) return `${type}-${n}`;
}
