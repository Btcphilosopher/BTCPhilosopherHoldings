/** The AAV editor. Client-side only: nothing is uploaded, and there is no account or backend. */
import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import type { DecodedAsset } from '../core/renderer';
import type { Manifest, StateName } from '../core/types';
import { AavError, errorsOnly } from '../core/types';
import { LayerInspector, DocumentInspector, ErrorList, LayerList, PanelsEditor, RegionList } from './panels';
import { Preview } from './Preview';
import type { PreviewHandle } from './Preview';
import { RegionInspector } from './RegionInspector';
import { Stage } from './Stage';
import { addAsset, download, exportHtml, exportPng, exportRedacted, importImage, openAav, readImage, readMask, saveAav } from './io';
import type { EditorDoc, Selection, Tool } from './store';
import { documentIssues, initialState, reducer, slugify, uniqueId } from './store';

type Tab = 'selection' | 'panels' | 'document' | 'problems';
interface Notice { kind: 'error' | 'info'; text: string; details?: string[] }

const TOOLS: { id: Tool; label: string; hint: string }[] = [
  { id: 'select', label: 'Select', hint: 'Select, move and reshape regions' },
  { id: 'rect', label: 'Rectangle', hint: 'Draw a rectangular region' },
  { id: 'polygon', label: 'Polygon', hint: 'Draw a polygon region point by point' },
  { id: 'pan', label: 'Pan', hint: 'Move the view' },
];

function describe(error: unknown): Notice {
  if (error instanceof AavError) {
    return { kind: 'error', text: error.issues.length === 1 ? error.issues[0].message : `${error.issues.length} problems were found.`,
      details: error.issues.length > 1 ? error.issues.slice(0, 12).map((i) => `${i.code}${i.path ? ` at ${i.path}` : ''}: ${i.message}`) : undefined };
  }
  return { kind: 'error', text: error instanceof Error ? error.message : String(error) };
}

/** Decode the document's assets, reusing bitmaps for bytes that have not changed. */
function useAssets(doc: EditorDoc | null): ReadonlyMap<string, DecodedAsset> {
  const cache = useRef(new WeakMap<Uint8Array, DecodedAsset>());
  const [assets, setAssets] = useState<ReadonlyMap<string, DecodedAsset>>(new Map());
  const key = doc ? JSON.stringify(Object.entries(doc.manifest.assets ?? {}).map(([id, a]) => [id, a?.path])) : '';
  const files = doc?.files;
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const out = new Map<string, DecodedAsset>();
      for (const [id, path] of (key ? JSON.parse(key) : []) as [string, string][]) {
        const bytes = files?.get(path);
        if (!bytes) continue;
        let decoded = cache.current.get(bytes);
        if (!decoded) {
          try {
            const bitmap = await createImageBitmap(new Blob([bytes as Uint8Array<ArrayBuffer>]), { colorSpaceConversion: 'none' });
            decoded = { image: bitmap, width: bitmap.width, height: bitmap.height };
            cache.current.set(bytes, decoded);
          } catch { continue; }
        }
        out.set(id, decoded);
      }
      if (!cancelled) setAssets(out);
    })();
    return () => { cancelled = true; };
  }, [key, files]);
  return assets;
}

export function App() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [tab, setTab] = useState<Tab>('selection');
  const [notice, setNotice] = useState<Notice | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [stateTab, setStateTab] = useState<StateName | null>(null);
  const [redactOpen, setRedactOpen] = useState(false);
  const imageInput = useRef<HTMLInputElement>(null);
  const aavInput = useRef<HTMLInputElement>(null);
  const layerInput = useRef<HTMLInputElement>(null);
  const previewHandle = useRef<PreviewHandle | null>(null);
  const { doc, selection } = state;
  const assets = useAssets(doc);
  const issues = useMemo(() => (doc ? documentIssues(doc) : []), [doc]);
  const errorCount = errorsOnly(issues).length;
  const warningCount = issues.length - errorCount;

  const update = useCallback((fn: (draft: Manifest) => void, key?: string) => {
    if (!state.doc) return;
    const draft = structuredClone(state.doc.manifest);
    fn(draft);
    dispatch({ type: 'change', doc: { manifest: draft, files: state.doc.files }, key });
  }, [state.doc]);

  const select = useCallback((next: Selection) => {
    dispatch({ type: 'select', selection: next });
    if (next.kind === 'panel') setTab('panels');
    else if (next.kind !== 'none') setTab('selection');
    setStateTab(null);
  }, []);

  const run = async (label: string, task: () => Promise<void>) => {
    setBusy(label);
    try {
      await task();
    } catch (error) {
      setNotice(describe(error));
    } finally {
      setBusy(null);
    }
  };

  const fileBase = doc ? slugify(doc.manifest.document.title || doc.manifest.document.id) : 'document';

  const onImportImage = (file: File) => run('Importing image…', async () => {
    const next = await importImage(file); // throws before anything is replaced
    dispatch({ type: 'load', doc: next });
    setNotice({ kind: 'info', text: `Imported ${file.name}. Draw a region with the Rectangle or Polygon tool.` });
    setTab('selection');
  });

  const onOpenAav = (file: File) => run('Opening…', async () => {
    const { doc: next, notes } = await openAav(new Uint8Array(await file.arrayBuffer())); // the current document survives a failure
    dispatch({ type: 'load', doc: next });
    setNotice(notes.length ? { kind: 'info', text: `Opened ${file.name}.`, details: notes } : null);
  });

  const onAddImageLayer = (file: File) => run('Adding layer…', async () => {
    if (!doc) return;
    const image = await readImage(file);
    const manifest = structuredClone(doc.manifest);
    const { id, files } = addAsset(doc, manifest, image, 'assets', file.name.replace(/\.[^.]+$/, ''));
    const layerId = uniqueId('overlay', manifest.layers.map((l) => l.id));
    manifest.layers.push({ id: layerId, type: 'image', asset: id, name: file.name, x: 0, y: 0, width: Math.min(image.width, manifest.document.width),
      height: Math.min(image.height, manifest.document.height) });
    dispatch({ type: 'change', doc: { manifest, files } });
    select({ kind: 'layer', id: layerId });
  });

  const onImportMask = (file: File, regionId: string) => run('Importing mask…', async () => {
    if (!doc) return;
    const image = await readMask(file);
    const manifest = structuredClone(doc.manifest);
    const { id, files } = addAsset(doc, manifest, image, 'masks', `${regionId}-mask`);
    const region = (manifest.regions ?? []).find((r) => r.id === regionId);
    if (!region) return;
    const b = region.shape.type === 'polygon'
      ? (() => { const xs = region.shape.points.map((p) => p[0]), ys = region.shape.points.map((p) => p[1]);
        return { x: Math.min(...xs), y: Math.min(...ys), width: Math.max(...xs) - Math.min(...xs), height: Math.max(...ys) - Math.min(...ys) }; })()
      : { x: region.shape.x ?? 0, y: region.shape.y ?? 0, width: region.shape.width ?? manifest.document.width, height: region.shape.height ?? manifest.document.height };
    region.shape = { type: 'mask', asset: id, x: b.x, y: b.y, width: Math.max(1, b.width), height: Math.max(1, b.height), threshold: 0.5, hit_test: 'alpha' };
    dispatch({ type: 'change', doc: { manifest, files } });
  });

  const onSave = () => run('Saving…', async () => {
    if (!doc) return;
    download(await saveAav(doc), `${fileBase}.aav`, 'application/octet-stream');
    dispatch({ type: 'saved' });
    setNotice({ kind: 'info', text: `Saved ${fileBase}.aav with a fresh static preview.` });
  });
  const onExportPng = () => run('Rendering…', async () => { if (doc) download(await exportPng(doc), `${fileBase}.png`, 'image/png'); });
  const onExportHtml = () => run('Exporting…', async () => {
    if (!doc) return;
    download(await exportHtml(doc), `${fileBase}.html`, 'text/html');
    setNotice({ kind: 'info', text: `Exported ${fileBase}.html. It is self-contained and opens directly from disk.` });
  });

  const captureState = () => {
    const snapshot = previewHandle.current?.snapshot();
    if (!snapshot) return;
    update((m) => { m.default_state = { ...m.default_state, selected: snapshot.selected, panel: snapshot.panel }; });
    setNotice({ kind: 'info', text: 'The current preview state is now the document default.' });
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const mod = event.ctrlKey || event.metaKey;
      const inField = event.target instanceof HTMLElement && /^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName);
      if (!mod) return;
      const k = event.key.toLowerCase();
      if (k === 's') { event.preventDefault(); if (doc && !errorCount) onSave(); }
      else if (!inField && k === 'z' && !event.shiftKey) { event.preventDefault(); dispatch({ type: 'undo' }); }
      else if (!inField && (k === 'y' || (k === 'z' && event.shiftKey))) { event.preventDefault(); dispatch({ type: 'redo' }); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  useEffect(() => {
    if (!state.dirty) return;
    const warn = (event: BeforeUnloadEvent) => event.preventDefault();
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [state.dirty]);

  // Inspection hook for automated tests; holds no secrets and does nothing on its own.
  useEffect(() => {
    (window as unknown as { __aavEditor?: unknown }).__aavEditor = { manifest: doc?.manifest ?? null, issues, dirty: state.dirty,
      undoDepth: state.past.length, redoDepth: state.future.length };
  });

  const selectedRegion = doc && selection.kind === 'region' ? (doc.manifest.regions ?? []).find((r) => r.id === selection.id) : undefined;
  const selectedLayer = doc && selection.kind === 'layer' ? doc.manifest.layers.find((l) => l.id === selection.id) : undefined;
  const pick = (ref: React.RefObject<HTMLInputElement | null>) => ref.current?.click();
  const fileInput = (ref: React.RefObject<HTMLInputElement | null>, accept: string, label: string, onFile: (f: File) => void) => (
    <input ref={ref} type="file" accept={accept} className="visually-hidden" aria-label={label} tabIndex={-1}
      onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) onFile(f); }} />
  );

  return (
    <div className="app">
      <header className="topbar">
        <h1><span>AAV</span> Editor</h1>
        <div className="group" role="group" aria-label="File">
          <button type="button" className="btn" onClick={() => pick(imageInput)}>Import image</button>
          <button type="button" className="btn" onClick={() => pick(aavInput)}>Open .aav</button>
          <button type="button" className="btn btn-primary" disabled={!doc || errorCount > 0 || !!busy} onClick={onSave}
            title={errorCount ? 'Fix the listed errors before saving' : 'Save as an .aav file (Ctrl+S)'}>Save .aav</button>
        </div>
        <div className="group" role="group" aria-label="Export">
          <button type="button" className="btn" disabled={!doc || errorCount > 0 || !!busy} onClick={onExportPng}>Export PNG</button>
          <button type="button" className="btn" disabled={!doc || errorCount > 0 || !!busy} onClick={onExportHtml}>Export HTML</button>
          <button type="button" className="btn" disabled={!doc || errorCount > 0 || !!busy || !(doc.manifest.regions ?? []).length}
            onClick={() => setRedactOpen(true)}>Redacted copy…</button>
        </div>
        <div className="group" role="group" aria-label="History">
          <button type="button" className="btn" disabled={!state.past.length} onClick={() => dispatch({ type: 'undo' })} title="Undo (Ctrl+Z)">Undo</button>
          <button type="button" className="btn" disabled={!state.future.length} onClick={() => dispatch({ type: 'redo' })} title="Redo (Ctrl+Shift+Z)">Redo</button>
        </div>
        <span className="spacer" />
        {busy ? <span className="busy" role="status">{busy}</span> : null}
        {doc ? (
          <button type="button" className={`btn badge ${errorCount ? 'badge-err' : warningCount ? 'badge-warn' : 'badge-ok'}`} onClick={() => setTab('problems')}>
            {errorCount ? `${errorCount} error${errorCount === 1 ? '' : 's'}` : warningCount ? `${warningCount} warning${warningCount === 1 ? '' : 's'}` : 'No problems'}
          </button>
        ) : null}
        <a href="viewer.html">Viewer</a>
        {fileInput(imageInput, 'image/*', 'Choose an image to import', onImportImage)}
        {fileInput(aavInput, '.aav', 'Choose an .aav file to open', onOpenAav)}
        {fileInput(layerInput, 'image/*', 'Choose an image for a new layer', onAddImageLayer)}
      </header>

      {notice ? (
        <div className={`notice notice-${notice.kind}`} role={notice.kind === 'error' ? 'alert' : 'status'}>
          <div><strong>{notice.kind === 'error' ? 'Problem: ' : ''}</strong>{notice.text}
            {notice.details ? <ul>{notice.details.map((d, i) => <li key={i}>{d}</li>)}</ul> : null}</div>
          <button type="button" className="btn btn-small" onClick={() => setNotice(null)}>Dismiss</button>
        </div>
      ) : null}

      {!doc ? (
        <main className="empty">
          <h2>Start with an image</h2>
          <p>Import a PNG, JPEG or WebP image, or open an existing <code>.aav</code> file. Everything happens in this browser tab; nothing is uploaded.</p>
          <div className="row">
            <button type="button" className="btn btn-primary" onClick={() => pick(imageInput)}>Import image</button>
            <button type="button" className="btn" onClick={() => pick(aavInput)}>Open .aav</button>
          </div>
          <ol>
            <li>Import an image.</li><li>Draw a region.</li><li>Add a highlight and an action.</li><li>Preview, then save the <code>.aav</code> file.</li>
          </ol>
        </main>
      ) : (
        <main className="work">
          <aside className="left" aria-label="Layers and regions">
            <LayerList manifest={doc.manifest} selection={selection} onSelect={select} update={update} onAddImage={() => pick(layerInput)} />
            <RegionList manifest={doc.manifest} selection={selection} onSelect={select} />
          </aside>
          <section className="centre" aria-label="Canvas">
            <div className="toolbar" role="toolbar" aria-label="Tools">
              {TOOLS.map((t) => (
                <button key={t.id} type="button" className={`btn${state.tool === t.id ? ' on' : ''}`} aria-pressed={state.tool === t.id} title={t.hint}
                  disabled={state.mode === 'preview'} onClick={() => dispatch({ type: 'tool', tool: t.id })}>{t.label}</button>
              ))}
              <span className="spacer" />
              <div className="seg" role="group" aria-label="Mode">
                <button type="button" className={`btn${state.mode === 'edit' ? ' on' : ''}`} aria-pressed={state.mode === 'edit'} onClick={() => dispatch({ type: 'mode', mode: 'edit' })}>Edit</button>
                <button type="button" className={`btn${state.mode === 'preview' ? ' on' : ''}`} aria-pressed={state.mode === 'preview'} disabled={errorCount > 0}
                  title={errorCount ? 'Fix the listed errors to preview' : 'Try the interactions'} onClick={() => dispatch({ type: 'mode', mode: 'preview' })}>Preview</button>
              </div>
            </div>
            {state.mode === 'preview' && errorCount === 0
              ? <Preview doc={doc} assets={assets} handle={previewHandle} />
              : <Stage manifest={doc.manifest} assets={assets} selection={selection} tool={state.tool} previewState={stateTab} renderable={errorCount === 0}
                onSelect={select} onTool={(tool) => dispatch({ type: 'tool', tool })} update={update} />}
          </section>
          <aside className="right" aria-label="Properties">
            <div className="tabs" role="tablist" aria-label="Property panels">
              {([['selection', 'Selection'], ['panels', 'Panels'], ['document', 'Document'], ['problems', `Problems (${issues.length})`]] as [Tab, string][]).map(([id, label]) => (
                <button key={id} type="button" role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{label}</button>
              ))}
            </div>
            <div className="tabbody" role="tabpanel">
              {tab === 'selection' ? (
                selectedRegion ? <RegionInspector manifest={doc.manifest} region={selectedRegion} stateTab={stateTab} onStateTab={setStateTab} update={update} onImportMask={onImportMask} />
                  : selectedLayer ? <LayerInspector manifest={doc.manifest} layer={selectedLayer} update={update} />
                    : <p className="note pad">Nothing selected. Click a region on the canvas or in the list, or draw a new one.</p>
              ) : tab === 'panels' ? <PanelsEditor manifest={doc.manifest} selection={selection} onSelect={select} update={update} issues={issues} />
                : tab === 'document' ? <DocumentInspector manifest={doc.manifest} update={update} onCapture={state.mode === 'preview' ? captureState : null} />
                  : <ErrorList manifest={doc.manifest} issues={issues} onSelect={select} />}
            </div>
          </aside>
        </main>
      )}
      {doc && redactOpen ? <RedactDialog doc={doc} fileBase={fileBase} onClose={() => setRedactOpen(false)} onNotice={setNotice} /> : null}
    </div>
  );
}

function RedactDialog({ doc, fileBase, onClose, onNotice }: { doc: EditorDoc; fileBase: string; onClose: () => void; onNotice: (n: Notice) => void }) {
  const ref = useRef<HTMLDialogElement>(null);
  const [chosen, setChosen] = useState<string[]>([]);
  const [colour, setColour] = useState('#000000');
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { ref.current?.showModal(); }, []);
  const regions = doc.manifest.regions ?? [];
  const go = async () => {
    setWorking(true);
    setError(null);
    try {
      download(await exportRedacted(doc, chosen, colour), `${fileBase}-redacted.aav`, 'application/octet-stream');
      onNotice({ kind: 'info', text: `Wrote ${fileBase}-redacted.aav. ${chosen.length} region(s) were permanently filled and the result was verified. ` +
        'Your open document is unchanged.' });
      onClose();
    } catch (e) {
      setError(describe(e).text);
    } finally {
      setWorking(false);
    }
  };
  return (
    <dialog ref={ref} className="dialog" onClose={onClose} aria-labelledby="redact-title">
      <h2 id="redact-title">Export a permanently redacted copy</h2>
      <p>
        Pixelation and blur effects only change how the image is <em>displayed</em>: the original pixels stay inside the file and can be extracted.
        This export is different. It writes a <strong>new file</strong> in which the chosen regions are replaced by a solid colour in every image,
        hidden originals and old previews are removed, and the result is checked. It cannot be undone in that copy.
      </p>
      <fieldset className="checks"><legend>Regions to destroy</legend>
        {regions.map((r) => (
          <label key={r.id}><input type="checkbox" checked={chosen.includes(r.id)}
            onChange={(e) => setChosen(e.target.checked ? [...chosen, r.id] : chosen.filter((id) => id !== r.id))} /> {r.label} <span className="tag">{r.id}</span></label>
        ))}
      </fieldset>
      <label className="row">Fill colour <input type="color" value={colour} onChange={(e) => setColour(e.target.value.toUpperCase())} /></label>
      {error ? <p className="note err" role="alert">{error}</p> : null}
      <div className="row end">
        <button type="button" className="btn" onClick={() => ref.current?.close()}>Cancel</button>
        <button type="button" className="btn btn-primary" disabled={!chosen.length || working} onClick={go}>{working ? 'Working…' : 'Export redacted copy'}</button>
      </div>
    </dialog>
  );
}
