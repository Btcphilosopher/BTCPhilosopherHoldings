/** Small form controls shared by the inspectors. Every control has a visible label and reports invalid input. */
import { useEffect, useId, useState } from 'react';
import type { ReactNode } from 'react';
import type { PropSpec } from '../core/limits';
import { propValueProblem } from '../core/validate';

export function Field({ label, children, error, hint }: { label: string; children: (id: string) => ReactNode; error?: string | null;
  hint?: string }) {
  const id = useId();
  return (
    <div className={`fld${error ? ' fld-bad' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children(id)}
      {hint && !error ? <small>{hint}</small> : null}
      {error ? <small className="fld-err" role="alert">{error}</small> : null}
    </div>
  );
}

export function TextField({ label, value, onChange, multiline, error, hint, placeholder, rows = 3 }: {
  label: string; value: string; onChange: (v: string) => void; multiline?: boolean; error?: string | null; hint?: string;
  placeholder?: string; rows?: number }) {
  return (
    <Field label={label} error={error} hint={hint}>
      {(id) => multiline
        ? <textarea id={id} value={value} rows={rows} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
        : <input id={id} type="text" value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />}
    </Field>
  );
}

/**
 * Text field that commits on blur or Enter. Used for identifiers, where every
 * keystroke would otherwise rename references throughout the document.
 */
export function CommitField({ label, value, onCommit, error, hint }: { label: string; value: string; onCommit: (v: string) => void;
  error?: string | null; hint?: string }) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  return (
    <Field label={label} error={error} hint={hint}>
      {(id) => <input id={id} type="text" value={draft} onChange={(e) => setDraft(e.target.value)}
        onBlur={() => { if (draft !== value) onCommit(draft); }}
        onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }} />}
    </Field>
  );
}

export function NumberField({ label, value, onChange, min, max, step = 1, error, hint }: {
  label: string; value: number | undefined; onChange: (v: number) => void; min?: number; max?: number; step?: number;
  error?: string | null; hint?: string }) {
  const [draft, setDraft] = useState(value === undefined ? '' : String(value));
  useEffect(() => { setDraft((d) => (Number(d) === value ? d : value === undefined ? '' : String(value))); }, [value]);
  const parsed = Number(draft);
  const local = draft.trim() === '' || !Number.isFinite(parsed) ? 'Enter a number'
    : (min !== undefined && parsed < min) || (max !== undefined && parsed > max) ? `Must be between ${min} and ${max}` : null;
  return (
    <Field label={label} error={error ?? (draft === '' && value === undefined ? null : local)} hint={hint}>
      {(id) => <input id={id} type="number" inputMode="decimal" value={draft} min={min} max={max} step={step}
        onChange={(e) => {
          setDraft(e.target.value);
          const v = Number(e.target.value);
          if (e.target.value.trim() !== '' && Number.isFinite(v)) onChange(v);
        }} />}
    </Field>
  );
}

export function SelectField<T extends string>({ label, value, options, onChange, error, allowEmpty }: {
  label: string; value: T | ''; options: readonly (T | { value: T; label: string })[]; onChange: (v: T | '') => void;
  error?: string | null; allowEmpty?: string }) {
  const list = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  const missing = value !== '' && !list.some((o) => o.value === value);
  return (
    <Field label={label} error={error ?? (missing ? `'${value}' does not exist` : null)}>
      {(id) => (
        <select id={id} value={value} onChange={(e) => onChange(e.target.value as T | '')}>
          {allowEmpty !== undefined ? <option value="">{allowEmpty}</option> : null}
          {missing ? <option value={value}>{value} (missing)</option> : null}
          {list.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      )}
    </Field>
  );
}

export function CheckField({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  const id = useId();
  return (
    <div className="fld fld-check">
      <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <label htmlFor={id}>{label}</label>
    </div>
  );
}

export function ColourField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const valid = /^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$/.test(value);
  return (
    <Field label={label} error={valid ? null : 'Use #RRGGBB or #RRGGBBAA'}>
      {(id) => (
        <span className="fld-colour">
          <input type="color" aria-label={`${label} picker`} value={valid ? value.slice(0, 7) : '#000000'}
            onChange={(e) => onChange(e.target.value.toUpperCase() + (valid ? value.slice(7) : ''))} />
          <input id={id} type="text" value={value} onChange={(e) => onChange(e.target.value)} />
        </span>
      )}
    </Field>
  );
}

const stepFor = (spec: PropSpec): number => {
  const span = (spec.max ?? 1) - (spec.min ?? 0);
  return span > 64 ? 1 : span > 8 ? 0.5 : 0.01;
};

/** A control for one effect property, chosen from its specification: slider, colour, select or checkbox. */
export function PropControl({ label, spec, value, onChange }: { label: string; spec: PropSpec; value: unknown;
  onChange: (v: number | string | boolean) => void }) {
  const problem = propValueProblem(spec, value);
  if (spec.kind === 'colour') return <ColourField label={label} value={String(value ?? '')} onChange={onChange} />;
  if (spec.kind === 'boolean') return <CheckField label={label} checked={value === true} onChange={onChange} />;
  if (spec.kind === 'enum') {
    return <SelectField label={label} value={String(value ?? '')} options={spec.values!} onChange={(v) => onChange(v)} error={problem} />;
  }
  const numeric = typeof value === 'number' ? value : Number(value);
  const sliderMax = Math.min(spec.max!, spec.unit === 'px' && spec.max! > 512 ? 2048 : spec.max!);
  return (
    <Field label={`${label}${spec.unit ? ` (${spec.unit})` : ''}`} error={problem}>
      {(id) => (
        <span className="fld-slider">
          <input id={id} type="range" min={spec.min} max={sliderMax} step={stepFor(spec)}
            value={Number.isFinite(numeric) ? numeric : spec.min} onChange={(e) => onChange(Number(e.target.value))} />
          <input type="number" aria-label={`${label} value`} min={spec.min} max={spec.max} step={stepFor(spec)}
            value={Number.isFinite(numeric) ? numeric : ''} onChange={(e) => { if (e.target.value !== '') onChange(Number(e.target.value)); }} />
        </span>
      )}
    </Field>
  );
}

export function Section({ title, children, actions }: { title: string; children: ReactNode; actions?: ReactNode }) {
  return (
    <section className="sec">
      <header><h3>{title}</h3>{actions}</header>
      {children}
    </section>
  );
}
