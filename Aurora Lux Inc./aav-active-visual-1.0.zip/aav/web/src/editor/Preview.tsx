/** Preview mode: the real viewer running on a snapshot of the document being edited. */
import { useEffect, useRef, useState } from 'react';
import type { DecodedAsset } from '../core/renderer';
import type { AavPackage, Manifest } from '../core/types';
import { AavViewer } from '../viewer/viewer';
import type { EditorDoc } from './store';

export interface PreviewHandle { snapshot: () => { selected: string[]; panel: string | null } | null }

export function Preview({ doc, handle }: { doc: EditorDoc; assets: ReadonlyMap<string, DecodedAsset>; handle: React.RefObject<PreviewHandle | null> }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let viewer: AavViewer | null = null;
    let cancelled = false;
    const pkg: AavPackage = { manifest: structuredClone(doc.manifest) as Manifest, files: new Map(doc.files) };
    AavViewer.create(hostRef.current!, pkg, { baseUrl: null }).then((v) => {
      if (cancelled) v.destroy();
      else {
        viewer = v;
        handle.current = { snapshot: () => v.machine.snapshot() };
        (window as unknown as { __aavViewer?: AavViewer }).__aavViewer = v;
      }
    }).catch((e: unknown) => setError(e instanceof Error ? e.message : String(e)));
    return () => {
      cancelled = true;
      handle.current = null;
      viewer?.destroy();
    };
  }, [doc, handle]);
  return (
    <div className="preview" data-testid="preview">
      {error ? <p className="note err" role="alert">Preview unavailable: {error}</p> : null}
      <div ref={hostRef} className="preview-host" />
    </div>
  );
}
