/**
 * Single-file bundle (IIFE, global `AAV`). Used by:
 *  - the standalone HTML export, where it boots from the embedded #aav-data element;
 *  - headless static rendering (scripts/render.mjs), which calls AAV.renderToPngBase64.
 * It performs no network requests.
 */
import './viewer/viewer.css';
import { base64Decode, base64Encode } from './core/htmlexport';
import { VERSION } from './core/limits';
import { loadPackage } from './core/package';
import { decodeAssets, renderPreviewPng } from './core/renderer';
import { describeError, openDocument } from './viewer/load';
import type { ViewerOptions } from './viewer/viewer';
import { AavViewer } from './viewer/viewer';

export const version = VERSION;

export async function mount(container: HTMLElement, bytes: Uint8Array, options: ViewerOptions = {}): Promise<AavViewer> {
  return (await openDocument(container, bytes, options)).viewer;
}

/** Validate an archive and render its default state. Returns base64 PNG at document resolution. */
export async function renderToPngBase64(archiveBase64: string, backend: 'auto' | 'cpu' | 'webgl2' = 'cpu'): Promise<string> {
  const { pkg } = await loadPackage(base64Decode(archiveBase64));
  return base64Encode(await renderPreviewPng(pkg.manifest, await decodeAssets(pkg), backend));
}

async function boot(): Promise<void> {
  const data = document.getElementById('aav-data');
  const root = document.getElementById('aav-root');
  if (!data || !root) return;
  const fallback = document.getElementById('aav-fallback');
  const host = document.createElement('div');
  host.className = 'aav-host';
  try {
    const viewer = await mount(host, base64Decode(data.textContent ?? ''), { baseUrl: null });
    root.replaceChildren(host);
    (window as unknown as { __aavViewer?: AavViewer }).__aavViewer = viewer;
  } catch (error) {
    // Leave the static preview in place and say why the interactive version is unavailable.
    const note = document.createElement('p');
    note.className = 'aav-notice';
    const { message, details } = describeError(error);
    note.textContent = `${message} ${details[0] ?? ''}`;
    (fallback ?? root).prepend(note);
  }
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => void boot());
  else void boot();
}
