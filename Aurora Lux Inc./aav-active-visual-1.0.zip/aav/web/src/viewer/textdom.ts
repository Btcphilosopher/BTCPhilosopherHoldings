/** Build DOM nodes from AAV restricted text. Only createElement and textContent are used: no HTML parsing. */
import { parseText } from '../core/text';
import type { Inline, LinkTarget } from '../core/text';

export type LinkHandler = (target: LinkTarget, label: string) => void;

function inlineNodes(nodes: Inline[], onLink: LinkHandler): Node[] {
  return nodes.map((node) => {
    if (node.type === 'text') return document.createTextNode(node.text);
    if (node.type === 'break') return document.createElement('br');
    if (node.type === 'link') {
      const target = node.target;
      if (target.kind === 'external') {
        const a = document.createElement('a');
        a.href = target.url;
        a.rel = 'noopener noreferrer';
        a.target = '_blank';
        a.className = 'aav-link aav-link-external';
        a.textContent = node.text;
        const host = document.createElement('span');
        host.className = 'aav-link-host';
        host.textContent = ` (${target.url.slice('https://'.length).split(/[/?#]/, 1)[0]})`;
        a.append(host);
        a.title = target.url;
        // Links never navigate directly: the host shows the destination and asks first.
        a.addEventListener('click', (event) => {
          event.preventDefault();
          onLink(target, node.text);
        });
        return a;
      }
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'aav-link aav-link-internal';
      button.textContent = node.text;
      button.addEventListener('click', () => onLink(target, node.text));
      return button;
    }
    const el = document.createElement(node.type === 'bold' ? 'strong' : node.type === 'italic' ? 'em' : 'code');
    el.textContent = node.text;
    return el;
  });
}

export function renderText(source: string, onLink: LinkHandler): DocumentFragment {
  const fragment = document.createDocumentFragment();
  for (const block of parseText(source)) {
    if (block.type === 'list') {
      const ul = document.createElement('ul');
      for (const item of block.items) {
        const li = document.createElement('li');
        li.append(...inlineNodes(item, onLink));
        ul.append(li);
      }
      fragment.append(ul);
    } else {
      const el = document.createElement(block.type === 'heading' ? 'h3' : 'p');
      el.append(...inlineNodes(block.content, onLink));
      fragment.append(el);
    }
  }
  return fragment;
}
