/** The standalone viewer page (viewer.html). Client-side only: files are read locally and never uploaded. */
import './viewer.css';
import './page.css';
import { describeError, openDocument, showFailure } from './load';
import type { AavViewer } from './viewer';

const container = document.getElementById('viewer')!;
const body = document.querySelector<HTMLElement>('.page-body')!;
const banner = document.getElementById('banner')!;
const bannerText = document.getElementById('banner-text')!;
const fileInput = document.getElementById('file') as HTMLInputElement;
const examples = document.getElementById('examples') as HTMLSelectElement;
let current: AavViewer | null = null;

function showBanner(text: string | null): void {
  banner.hidden = text === null;
  bannerText.textContent = text ?? '';
}

async function load(bytes: Uint8Array, baseUrl: string | null, name: string): Promise<void> {
  const scratch = document.createElement('div');
  scratch.style.height = '100%';
  try {
    const { viewer } = await openDocument(scratch, bytes, { baseUrl, onNavigate: (url) => void loadUrl(url) });
    current?.destroy();
    current = viewer;
    container.replaceChildren(scratch);
    document.title = `${viewer.manifest.document.title} – AAV Viewer`;
    showBanner(null);
    (window as unknown as { __aavViewer?: AavViewer }).__aavViewer = viewer;
  } catch (error) {
    if (current) {
      // Keep the document that is already open; just report the failure.
      const { message, details } = describeError(error);
      showBanner(`${name}: ${message} ${details[0] ?? ''}`);
    } else {
      showBanner(null);
      showFailure(container, bytes, error);
    }
  }
}

/** Only same-origin documents are fetched, and only after the user chose or confirmed them. */
async function loadUrl(url: string): Promise<void> {
  try {
    const resolved = new URL(url, location.href);
    if (resolved.origin !== location.origin) throw new Error('only documents from this site can be loaded here');
    const response = await fetch(resolved, { credentials: 'omit', referrerPolicy: 'no-referrer', cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    await load(new Uint8Array(await response.arrayBuffer()), resolved.href, resolved.pathname.split('/').pop() ?? 'document');
  } catch (error) {
    showBanner(`Could not load ${url}: ${(error as Error).message}`);
  }
}

async function loadFile(file: File): Promise<void> {
  await load(new Uint8Array(await file.arrayBuffer()), null, file.name);
}

document.getElementById('open')!.addEventListener('click', () => fileInput.click());
document.getElementById('banner-close')!.addEventListener('click', () => showBanner(null));
fileInput.addEventListener('change', () => {
  const file = fileInput.files?.[0];
  fileInput.value = '';
  if (file) void loadFile(file);
});
examples.addEventListener('change', () => {
  if (examples.value) void loadUrl(examples.value);
});
body.addEventListener('dragover', (event) => {
  event.preventDefault();
  body.classList.add('dragover');
});
body.addEventListener('dragleave', () => body.classList.remove('dragover'));
body.addEventListener('drop', (event) => {
  event.preventDefault();
  body.classList.remove('dragover');
  const file = event.dataTransfer?.files[0];
  if (file) void loadFile(file);
});

const source = new URLSearchParams(location.search).get('src');
if (source) {
  if ([...examples.options].some((o) => o.value === source)) examples.value = source;
  void loadUrl(source);
}
