/** Opening documents in a viewer, with a static fallback when that is not possible. */
import { loadPackage, loadUnvalidated } from '../core/package';
import { AavError } from '../core/types';
import type { Issue } from '../core/types';
import { PREVIEW } from '../core/zip';
import { AavViewer, showFallback } from './viewer';
import type { ViewerOptions } from './viewer';

export interface OpenResult { viewer: AavViewer; warnings: Issue[] }

/**
 * Validate `bytes` and mount a viewer in `container`. The container is left
 * untouched if anything fails, so a document that is already open survives a
 * failed import.
 */
export async function openDocument(container: HTMLElement, bytes: Uint8Array, options: ViewerOptions = {}): Promise<OpenResult> {
  const { pkg, warnings } = await loadPackage(bytes);
  return { viewer: await AavViewer.create(container, pkg, options), warnings };
}

export function describeError(error: unknown): { message: string; details: string[] } {
  if (error instanceof AavError) {
    return {
      message: 'This file could not be opened as an AAV document.',
      details: error.issues.map((i) => `${i.code}${i.path ? ` at ${i.path}` : ''}: ${i.message}`),
    };
  }
  return { message: 'This file could not be opened.', details: [error instanceof Error ? error.message : String(error)] };
}

/**
 * Show why a document failed, with its static preview when the container
 * itself was readable (for example a newer schema version): the picture stays
 * available even though interaction is not.
 */
export function showFailure(container: HTMLElement, bytes: Uint8Array | null, error: unknown): void {
  const { message, details } = describeError(error);
  let preview: Uint8Array | null = null;
  let title: string | undefined;
  if (bytes) {
    try {
      const pkg = loadUnvalidated(bytes);
      preview = pkg.files.get(PREVIEW) ?? null;
      const candidate = (pkg.manifest as { document?: { title?: unknown } }).document?.title;
      if (typeof candidate === 'string') title = candidate.slice(0, 200);
    } catch { /* the container is unreadable: no preview to show */ }
  }
  showFallback(container, preview ? `${message} Showing its static preview instead.` : message, details, preview, title);
}
