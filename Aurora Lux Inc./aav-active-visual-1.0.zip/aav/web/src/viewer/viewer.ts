/**
 * The AAV viewer: an embeddable, client-side component.
 *
 *   const viewer = await AavViewer.create(container, pkg, { baseUrl });
 *
 * It owns no network access. Links and document navigation always go through
 * a confirmation dialog that shows the destination; nothing leaves the page
 * without an explicit user action.
 */
import { centredView, clampRect, docToScreen, fitView, panBy, screenToDoc, zoomAt } from '../core/geometry';
import type { View } from '../core/geometry';
import { hitTestAll } from '../core/hittest';
import { documentHrefProblem, externalUrlProblem } from '../core/links';
import { own } from '../core/limits';
import { parseColour } from '../core/pixels';
import { SceneRenderer, decodeAssets, tracePath } from '../core/renderer';
import type { HostRequest } from '../core/state';
import { Machine } from '../core/state';
import type { LinkTarget } from '../core/text';
import type { AavPackage, Manifest, Region } from '../core/types';
import { shapeBounds } from '../core/validate';
import { renderText } from './textdom';

export interface ViewerOptions {
  /** URL the document came from; relative navigate_document targets resolve against it. */
  baseUrl?: string | null;
  /** Called after the user confirms opening another document. If absent, https targets open in a new tab. */
  onNavigate?: (url: string) => void;
  backend?: 'auto' | 'cpu' | 'webgl2';
  /** Overrides the prefers-reduced-motion media query. */
  reducedMotion?: boolean;
  /** Hide the side panel's region list (the regions stay keyboard reachable on the canvas). */
  compact?: boolean;
}

const CYAN = '#5AD8E6';
const VIOLET = '#A78BFA';

function h<K extends keyof HTMLElementTagNameMap>(tag: K, props: Record<string, string> = {},
                                                  ...children: (Node | string)[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === 'class') el.className = value;
    else if (key === 'text') el.textContent = value;
    else el.setAttribute(key, value);
  }
  el.append(...children);
  return el;
}

let uid = 0;

export class AavViewer {
  readonly manifest: Manifest;
  readonly machine: Machine;
  readonly renderer: SceneRenderer;
  readonly root: HTMLElement;
  view: View = { scale: 1, tx: 0, ty: 0 };

  private options: ViewerOptions;
  private stage!: HTMLElement;
  private canvas!: HTMLCanvasElement;
  private ctx!: CanvasRenderingContext2D;
  private proxyLayer!: HTMLElement;
  private proxies = new Map<string, HTMLButtonElement>();
  private listItems = new Map<string, HTMLButtonElement>();
  private tooltipEl!: HTMLElement;
  private panelEl!: HTMLElement;
  private panelTitle!: HTMLElement;
  private panelBody!: HTMLElement;
  private confirmEl!: HTMLDialogElement;
  private liveEl!: HTMLElement;
  private statusEl!: HTMLElement;
  private motionBox!: HTMLInputElement;
  private id = `aav${++uid}`;
  private frame = 0;
  private surfaceRevision = -1;
  private domRevision = -1;
  private viewDirty = true;
  private fitted = true;
  private destroyed = false;
  private resizeObserver: ResizeObserver;
  private pointers = new Map<number, { x: number; y: number; startX: number; startY: number; type: string }>();
  private dragging = false;
  private pinchDistance = 0;
  private lastKeyboard = false;
  private lastPanel: string | null = null;
  private lastSelected = '';
  private returnFocus: HTMLElement | null = null;
  private cleanup: (() => void)[] = [];

  /** Decode the assets of an already validated package and mount a viewer in `container`. */
  static async create(container: HTMLElement, pkg: AavPackage, options: ViewerOptions = {}): Promise<AavViewer> {
    const assets = await decodeAssets(pkg);
    return new AavViewer(container, pkg.manifest, new SceneRenderer(pkg.manifest, assets, { backend: options.backend }), options);
  }

  private constructor(container: HTMLElement, manifest: Manifest, renderer: SceneRenderer, options: ViewerOptions) {
    this.manifest = manifest;
    this.renderer = renderer;
    this.options = options;
    const media = typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)') : null;
    this.machine = new Machine(manifest, { reducedMotion: options.reducedMotion ?? media?.matches ?? false });
    this.root = this.build();
    container.replaceChildren(this.root);
    this.resizeObserver = new ResizeObserver(() => this.onResize());
    this.resizeObserver.observe(this.stage);
    this.bindEvents();
    this.onResize();
    this.handle(this.machine.load());
    this.applyDefaultView();
    this.requestRender();
    this.root.dataset.aavReady = 'true';
  }

  destroy(): void {
    this.destroyed = true;
    cancelAnimationFrame(this.frame);
    this.resizeObserver.disconnect();
    this.cleanup.forEach((fn) => fn());
    this.renderer.dispose();
    this.root.remove();
  }

  // --------------------------------------------------------------------------- DOM

  private interactiveRegions(): Region[] {
    return (this.manifest.regions ?? []).filter((r) => r.interactive !== false);
  }

  private build(): HTMLElement {
    const doc = this.manifest.document;
    const descId = `${this.id}-desc`, tipId = `${this.id}-tip`, panelTitleId = `${this.id}-panel-title`;
    const button = (label: string, title: string, onClick: () => void, extra = '') => {
      const el = h('button', { type: 'button', class: `aav-btn ${extra}`.trim(), title, 'aria-label': title, text: label });
      el.addEventListener('click', onClick);
      return el;
    };

    this.statusEl = h('span', { class: 'aav-status' });
    this.motionBox = h('input', { type: 'checkbox' });
    this.motionBox.checked = this.machine.reducedMotion;
    this.motionBox.addEventListener('change', () => {
      this.machine.setReducedMotion(this.motionBox.checked);
      this.requestRender();
    });
    const toolbar = h('div', { class: 'aav-toolbar', role: 'toolbar', 'aria-label': 'View controls' },
      button('−', 'Zoom out', () => this.zoomBy(1 / 1.25)),
      button('+', 'Zoom in', () => this.zoomBy(1.25)),
      button('Fit', 'Fit image to view', () => this.resetView()),
      button('Reset', 'Reset interactive state', () => this.resetState()),
      h('label', { class: 'aav-check' }, this.motionBox, 'Reduce motion'),
      h('span', { class: 'aav-spacer' }), this.statusEl);
    if (this.manifest.settings?.pan_zoom === false) toolbar.querySelectorAll<HTMLElement>('.aav-btn').forEach((b, i) => { if (i < 3) b.hidden = true; });

    this.canvas = h('canvas', { class: 'aav-canvas', role: 'img', 'aria-label': doc.title, 'aria-describedby': descId });
    const ctx = this.canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D is not available');
    this.ctx = ctx;
    this.proxyLayer = h('div', { class: 'aav-proxies' });
    this.tooltipEl = h('div', { class: 'aav-tooltip', role: 'tooltip', id: tipId, hidden: '' });
    this.stage = h('div', { class: 'aav-stage', tabindex: '0', role: 'group',
      'aria-label': `Interactive image: ${doc.title}. Use Tab to move between regions, Enter to activate.` },
      this.canvas, this.proxyLayer, this.tooltipEl);

    for (const region of this.interactiveRegions()) {
      const proxy = h('button', { type: 'button', class: 'aav-proxy', 'aria-label': region.label, 'data-region': region.id });
      if (region.description) proxy.setAttribute('aria-description', region.description);
      proxy.addEventListener('focus', () => { this.lastKeyboard = true; this.handle(this.machine.focus(region.id)); });
      proxy.addEventListener('blur', () => this.handle(this.machine.focus(null)));
      proxy.addEventListener('click', () => { this.lastKeyboard = true; this.returnFocus = proxy; this.handle(this.machine.activate(region.id)); });
      this.proxies.set(region.id, proxy);
      this.proxyLayer.append(proxy);
    }

    const list = h('ul', { class: 'aav-region-list' });
    const addItem = (region: Region) => {
      const item = h('button', { type: 'button', class: 'aav-region-item', 'aria-pressed': 'false', 'data-region': region.id,
        tabindex: '-1', text: region.label });
      if (region.description) item.title = region.description;
      item.addEventListener('focus', () => this.handle(this.machine.focus(region.id)));
      item.addEventListener('blur', () => this.handle(this.machine.focus(null)));
      item.addEventListener('click', () => {
        this.lastKeyboard = true;
        this.returnFocus = item;
        this.handle(this.machine.activate(region.id));
        this.reveal(region.id);
      });
      this.listItems.set(region.id, item);
      list.append(h('li', {}, item));
    };
    const grouped = new Set<string>();
    for (const [gid, group] of Object.entries(this.manifest.groups ?? {})) {
      const members = group.regions.map((id) => this.interactiveRegions().find((r) => r.id === id)).filter((r): r is Region => !!r && !grouped.has(r.id));
      if (!members.length) continue;
      list.append(h('li', { class: 'aav-group-label', 'data-group': gid, text: group.label }));
      members.forEach((r) => { grouped.add(r.id); addItem(r); });
    }
    const rest = this.interactiveRegions().filter((r) => !grouped.has(r.id));
    if (grouped.size && rest.length) list.append(h('li', { class: 'aav-group-label', text: 'Other regions' }));
    rest.forEach(addItem);
    // One tab stop for the whole list; arrow keys move inside it (roving tabindex).
    const items = [...this.listItems.values()];
    if (items[0]) items[0].tabIndex = 0;
    list.addEventListener('keydown', (event) => {
      const index = items.indexOf(document.activeElement as HTMLButtonElement);
      const next = event.key === 'ArrowDown' ? index + 1 : event.key === 'ArrowUp' ? index - 1
        : event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : -2;
      if (next === -2 || index < 0) return;
      event.preventDefault();
      const target = items[Math.min(items.length - 1, Math.max(0, next))];
      items.forEach((it) => (it.tabIndex = it === target ? 0 : -1));
      target.focus();
    });

    this.panelTitle = h('h2', { class: 'aav-panel-title', id: panelTitleId, tabindex: '-1' });
    this.panelBody = h('div', { class: 'aav-panel-body' });
    this.panelEl = h('section', { class: 'aav-panel', role: 'region', 'aria-labelledby': panelTitleId, hidden: '' },
      h('div', { class: 'aav-panel-head' }, this.panelTitle, button('Close', 'Close panel', () => this.closePanel())),
      this.panelBody);

    const side = h('aside', { class: 'aav-side' },
      h('h1', { text: doc.title }),
      h('p', { class: 'aav-desc', id: descId, text: doc.description ?? '' }),
      this.panelEl);
    if (!this.options.compact && items.length) {
      side.append(h('nav', { 'aria-label': 'Regions' }, h('h2', { text: 'Regions' }), list));
    }

    this.confirmEl = h('dialog', { class: 'aav-confirm' });
    this.liveEl = h('div', { class: 'aav-live', 'aria-live': 'polite', role: 'status' });
    const root = h('div', { class: 'aav-viewer' }, h('div', { class: 'aav-main' }, toolbar, this.stage), side, this.confirmEl, this.liveEl);
    if (doc.language) root.lang = doc.language;
    this.statusEl.textContent = `${doc.width}×${doc.height} · ${this.renderer.backend.name === 'webgl2' ? 'WebGL2 effects' : 'Canvas effects'}`;
    return root;
  }

  // --------------------------------------------------------------------------- events

  private stagePoint(event: { clientX: number; clientY: number }): { x: number; y: number } {
    const rect = this.stage.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  private hitsAt(sx: number, sy: number): { regions: Region[]; point: { x: number; y: number } } {
    const point = screenToDoc(this.view, sx, sy);
    return { regions: hitTestAll(this.manifest, point.x, point.y, this.renderer.masks), point };
  }

  private bindEvents(): void {
    const stage = this.stage;
    const canPanZoom = this.manifest.settings?.pan_zoom !== false;
    const on = <K extends keyof HTMLElementEventMap>(el: HTMLElement | Window, type: K,
                                                     fn: (e: HTMLElementEventMap[K]) => void, opts?: AddEventListenerOptions) => {
      el.addEventListener(type, fn as EventListener, opts);
      this.cleanup.push(() => el.removeEventListener(type, fn as EventListener, opts));
    };

    on(stage, 'pointerdown', (event) => {
      if (event.pointerType === 'mouse' && event.button !== 0) return;
      const p = this.stagePoint(event);
      this.pointers.set(event.pointerId, { ...p, startX: p.x, startY: p.y, type: event.pointerType });
      this.lastKeyboard = false;
      if (this.pointers.size === 1) this.dragging = false;
      if (this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        this.pinchDistance = Math.hypot(a.x - b.x, a.y - b.y);
        this.dragging = true;
      }
      try { stage.setPointerCapture(event.pointerId); } catch { /* synthetic events have no capture */ }
    });

    on(stage, 'pointermove', (event) => {
      const p = this.stagePoint(event);
      const held = this.pointers.get(event.pointerId);
      if (!held) {
        if (event.pointerType !== 'touch') {
          const { regions, point } = this.hitsAt(p.x, p.y);
          this.handle(this.machine.pointerMove(regions[0]?.id ?? null, point));
          stage.style.cursor = regions[0] ? 'pointer' : 'default';
        }
        return;
      }
      const dx = p.x - held.x, dy = p.y - held.y;
      held.x = p.x; held.y = p.y;
      if (this.pointers.size === 2 && canPanZoom) {
        const [a, b] = [...this.pointers.values()];
        const distance = Math.hypot(a.x - b.x, a.y - b.y);
        if (this.pinchDistance > 0 && distance > 0) {
          this.setView(zoomAt(this.view, distance / this.pinchDistance, (a.x + b.x) / 2, (a.y + b.y) / 2));
        }
        this.pinchDistance = distance;
        return;
      }
      const threshold = held.type === 'touch' ? 8 : 4;
      if (!this.dragging && Math.hypot(p.x - held.startX, p.y - held.startY) > threshold) this.dragging = true;
      if (this.dragging && canPanZoom) this.setView(panBy(this.view, dx, dy));
      else if (held.type !== 'touch') {
        const { regions, point } = this.hitsAt(p.x, p.y);
        this.handle(this.machine.pointerMove(regions[0]?.id ?? null, point));
      }
    });

    const release = (event: PointerEvent, cancelled: boolean) => {
      const held = this.pointers.get(event.pointerId);
      if (!held) return;
      this.pointers.delete(event.pointerId);
      const wasDragging = this.dragging;
      if (this.pointers.size === 0) this.dragging = false;
      if (cancelled || wasDragging) return;
      const { regions, point } = this.hitsAt(held.x, held.y);
      let target: Region | undefined = regions[0];
      if (event.altKey && regions.length > 1) {
        // Alt+click steps down through overlapping regions.
        const current = regions.findIndex((r) => this.machine.isSelected(r.id));
        target = regions[(current + 1) % regions.length];
      }
      // Touch has no hover: a tap first "enters" the region, then activates it.
      if (held.type === 'touch') this.handle(this.machine.pointerMove(target?.id ?? null, point));
      this.returnFocus = null;
      this.handle(this.machine.activate(target?.id ?? null));
    };
    on(stage, 'pointerup', (event) => release(event, false));
    on(stage, 'pointercancel', (event) => release(event, true));
    on(stage, 'pointerleave', (event) => {
      if (event.pointerType !== 'touch' && !this.pointers.has(event.pointerId)) this.handle(this.machine.pointerMove(null, null));
    });

    on(stage, 'wheel', (event) => {
      if (!canPanZoom) return;
      event.preventDefault();
      const p = this.stagePoint(event);
      this.setView(zoomAt(this.view, Math.exp(-event.deltaY * (event.deltaMode === 1 ? 0.05 : 0.0015)), p.x, p.y));
    }, { passive: false });

    on(this.root, 'keydown', (event) => {
      if (event.key === 'Escape') {
        if (this.confirmEl.open) return; // the dialog handles its own Escape
        const closed = this.machine.dismiss();
        if (closed) {
          event.preventDefault();
          if (closed === 'panel') this.restoreFocus();
          this.requestRender();
        }
        return;
      }
      const inStage = event.target instanceof Node && this.stage.contains(event.target);
      if (!inStage || !canPanZoom || event.ctrlKey || event.metaKey || event.altKey) return;
      const step = 48;
      const actions: Record<string, () => void> = {
        '+': () => this.zoomBy(1.25), '=': () => this.zoomBy(1.25), '-': () => this.zoomBy(1 / 1.25), '_': () => this.zoomBy(1 / 1.25),
        '0': () => this.resetView(),
        ArrowLeft: () => this.setView(panBy(this.view, step, 0)), ArrowRight: () => this.setView(panBy(this.view, -step, 0)),
        ArrowUp: () => this.setView(panBy(this.view, 0, step)), ArrowDown: () => this.setView(panBy(this.view, 0, -step)),
      };
      const action = actions[event.key];
      if (action) {
        event.preventDefault();
        action();
      }
    });
  }

  // --------------------------------------------------------------------------- view

  private stageSize(): { width: number; height: number } {
    return { width: this.stage.clientWidth || 1, height: this.stage.clientHeight || 1 };
  }

  private onResize(): void {
    const { width, height } = this.stageSize();
    const dpr = Math.min(window.devicePixelRatio || 1, 4);
    const w = Math.max(1, Math.round(width * dpr)), ht = Math.max(1, Math.round(height * dpr));
    if (this.canvas.width !== w || this.canvas.height !== ht) {
      this.canvas.width = w;
      this.canvas.height = ht;
    }
    if (this.fitted) this.view = fitView(this.manifest.document.width, this.manifest.document.height, width, height, 12);
    this.viewDirty = true;
    this.requestRender();
  }

  private applyDefaultView(): void {
    const view = this.manifest.default_state?.view;
    const { width, height } = this.stageSize();
    const doc = this.manifest.document;
    if (view && typeof view.zoom === 'number') {
      this.fitted = false;
      this.view = centredView(view.zoom, view.centre_x ?? doc.width / 2, view.centre_y ?? doc.height / 2, width, height);
    } else {
      this.fitted = true;
      this.view = fitView(doc.width, doc.height, width, height, 12);
    }
    this.viewDirty = true;
  }

  setView(view: View): void {
    this.view = view;
    this.fitted = false;
    this.viewDirty = true;
    this.requestRender();
  }

  resetView(): void {
    this.applyDefaultView();
    this.requestRender();
  }

  private zoomBy(factor: number): void {
    const { width, height } = this.stageSize();
    this.setView(zoomAt(this.view, factor, width / 2, height / 2));
  }

  /** Bring a region into view if it is not fully visible. */
  reveal(regionId: string): void {
    const region = (this.manifest.regions ?? []).find((r) => r.id === regionId);
    if (!region) return;
    const { width, height } = this.stageSize();
    const b = shapeBounds(region.shape, this.manifest.document.width, this.manifest.document.height);
    const a = docToScreen(this.view, b.x, b.y), c = docToScreen(this.view, b.x + b.width, b.y + b.height);
    if (a.x >= 0 && a.y >= 0 && c.x <= width && c.y <= height) return;
    if (this.manifest.settings?.pan_zoom === false) return;
    const scale = Math.min(this.view.scale, (width * 0.8) / b.width, (height * 0.8) / b.height);
    this.setView(centredView(scale, b.x + b.width / 2, b.y + b.height / 2, width, height));
  }

  resetState(): void {
    this.handle(this.machine.reset());
    this.resetView();
    this.announce('Interactive state reset');
  }

  // --------------------------------------------------------------------------- host requests

  private handle(requests: HostRequest[]): void {
    for (const request of requests) {
      if (request.type === 'reset_view') this.resetView();
      else if (request.type === 'reveal') this.reveal(request.region);
      else if (request.type === 'open_link') this.confirmLink(request.url, request.label);
      else if (request.type === 'navigate_document') this.confirmNavigate(request.href, request.label);
    }
    this.requestRender();
  }

  private showConfirm(title: string, detail: string, url: string, confirmLabel: string, onConfirm: (() => void) | null): void {
    const dialog = this.confirmEl;
    const authority = url.startsWith('https://') ? url.slice(8).split(/[/?#]/, 1)[0] : '';
    const urlEl = h('code', { class: 'aav-confirm-url' });
    if (authority) urlEl.append('https://', h('strong', { text: authority }), url.slice(8 + authority.length));
    else urlEl.textContent = url;
    const cancel = h('button', { type: 'button', class: 'aav-btn', text: onConfirm ? 'Cancel' : 'Close' });
    cancel.addEventListener('click', () => dialog.close());
    const actions = h('div', { class: 'aav-confirm-actions' }, cancel);
    if (onConfirm) {
      const go = h('button', { type: 'button', class: 'aav-btn aav-btn-primary', text: confirmLabel });
      go.addEventListener('click', () => {
        dialog.close();
        onConfirm();
      });
      actions.append(go);
    }
    dialog.replaceChildren(h('h2', { text: title }), h('p', { text: detail }), urlEl, actions);
    if (dialog.open) dialog.close();
    dialog.showModal();
    cancel.focus(); // the safe choice has focus by default
  }

  private confirmLink(url: string, label?: string): void {
    if (externalUrlProblem(url) !== null) return; // validated already; never open anything unsafe
    this.showConfirm('Open external link?', label ? `"${label}" leaves this document and opens in a new tab:` :
      'This leaves the document and opens in a new tab:', url, 'Open link',
    () => window.open(url, '_blank', 'noopener,noreferrer'));
  }

  private confirmNavigate(href: string, label?: string): void {
    if (documentHrefProblem(href) !== null) return;
    const isAbsolute = href.startsWith('https://');
    let resolved: string | null = isAbsolute ? href : null;
    if (!isAbsolute && this.options.baseUrl) {
      try { resolved = new URL(href, this.options.baseUrl).href; } catch { resolved = null; }
    }
    const detail = label ? `"${label}" opens another AAV document:` : 'This opens another AAV document:';
    if (resolved === null) {
      this.showConfirm('Linked document', 'This document links to another AAV file. It cannot be opened from here ' +
        'because the current document has no location; open the file manually:', href, '', null);
      return;
    }
    const target = resolved;
    this.showConfirm('Open another document?', detail, target, 'Open document', () => {
      if (this.options.onNavigate) this.options.onNavigate(target);
      else if (target.startsWith('https://')) window.open(target, '_blank', 'noopener,noreferrer');
    });
  }

  private onTextLink = (target: LinkTarget, label: string): void => {
    if (target.kind === 'external') this.confirmLink(target.url, label);
    else this.handle(this.machine.followInternalLink(target));
  };

  private closePanel(): void {
    this.machine.closePanel();
    this.restoreFocus();
    this.requestRender();
  }

  private restoreFocus(): void {
    if (this.returnFocus && this.returnFocus.isConnected) this.returnFocus.focus();
    this.returnFocus = null;
  }

  private announce(text: string): void {
    this.liveEl.textContent = '';
    // A fresh text node after a tick makes screen readers announce repeated messages.
    setTimeout(() => { if (!this.destroyed) this.liveEl.textContent = text; }, 30);
  }

  // --------------------------------------------------------------------------- rendering

  requestRender(): void {
    if (this.destroyed || this.frame) return;
    this.frame = requestAnimationFrame((time) => {
      this.frame = 0;
      this.draw(time);
    });
  }

  /** Render synchronously. Tests and static capture use this instead of waiting for a frame. */
  renderNow(time: number = performance.now()): void {
    cancelAnimationFrame(this.frame);
    this.frame = 0;
    this.draw(time);
  }

  private draw(time: number): void {
    if (this.destroyed) return;
    const machine = this.machine;
    const moving = machine.tick(time);
    const surfaceChanged = moving || machine.revision !== this.surfaceRevision;
    if (surfaceChanged) {
      this.renderer.render(machine, time);
      this.surfaceRevision = machine.revision;
    }
    if (surfaceChanged || this.viewDirty) this.blit();
    if (machine.revision !== this.domRevision || this.viewDirty) {
      this.syncDom();
      this.domRevision = machine.revision;
    }
    this.viewDirty = false;
    if (moving) this.requestRender();
  }

  private blit(): void {
    const { ctx, canvas, view } = this;
    const dpr = canvas.width / this.stageSize().width;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.tx, dpr * view.ty);
    // Smooth when shrinking; when enlarging, honour the document's image_rendering preference.
    ctx.imageSmoothingEnabled = !(this.manifest.settings?.image_rendering === 'pixelated' && dpr * view.scale >= 1);
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(this.renderer.surface, 0, 0);
    this.drawChrome(dpr);
  }

  /** Viewer chrome in screen space: default hover/selection highlights and the keyboard focus ring. */
  private drawChrome(dpr: number): void {
    const defaults = this.manifest.settings?.default_highlight !== false;
    for (const region of this.interactiveRegions()) {
      const state = this.machine.statesOf(region.id);
      if (defaults && !region.states) {
        if (state.selected) this.highlight(region, VIOLET, 3, 0.18, dpr);
        if (state.hover) this.highlight(region, CYAN, 2, 0.12, dpr);
      }
    }
    const focused = this.machine.focused !== null ? this.interactiveRegions().find((r) => r.id === this.machine.focused) : undefined;
    if (focused) {
      // Always drawn, whatever the document defines: a dark halo under a light dashed ring.
      this.highlight(focused, '#000000', 5, 0, dpr);
      this.highlight(focused, '#FFFFFF', 2.5, 0, dpr, [6, 4]);
    }
  }

  private highlight(region: Region, colour: string, widthPx: number, fillAlpha: number, dpr: number, dash: number[] = []): void {
    const { ctx, view } = this;
    ctx.save();
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.tx, dpr * view.ty);
    if (tracePath(ctx, region.shape)) {
      ctx.setTransform(1, 0, 0, 1, 0, 0); // stroke in device pixels so the width does not scale with zoom
      if (fillAlpha > 0) {
        ctx.globalAlpha = fillAlpha;
        ctx.fillStyle = colour;
        ctx.fill('evenodd');
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = colour;
      ctx.lineWidth = widthPx * dpr;
      ctx.lineJoin = 'round';
      ctx.setLineDash(dash.map((d) => d * dpr));
      ctx.stroke();
    } else {
      const rgb = parseColour(colour);
      if (fillAlpha > 0) {
        const cov = this.renderer.coverage(region, 0);
        if (cov) {
          ctx.globalAlpha = fillAlpha;
          ctx.drawImage(this.renderer.stamp(cov.rect, cov.alpha, rgb, 1), cov.rect.x, cov.rect.y);
        }
      }
      const band = this.renderer.maskOutline(region, Math.max(1, widthPx / view.scale));
      if (band) {
        ctx.globalAlpha = 1;
        ctx.drawImage(this.renderer.stamp(band.rect, band.alpha, rgb, 1), band.rect.x, band.rect.y);
      }
    }
    ctx.restore();
  }

  private syncDom(): void {
    const { machine, view } = this;
    const doc = this.manifest.document;
    const { width, height } = this.stageSize();
    for (const region of this.interactiveRegions()) {
      const b = clampRect(shapeBounds(region.shape, doc.width, doc.height), doc.width, doc.height) ??
        { x: 0, y: 0, width: 1, height: 1 };
      const a = docToScreen(view, b.x, b.y);
      const proxy = this.proxies.get(region.id)!;
      proxy.style.left = `${a.x}px`;
      proxy.style.top = `${a.y}px`;
      proxy.style.width = `${Math.max(1, b.width * view.scale)}px`;
      proxy.style.height = `${Math.max(1, b.height * view.scale)}px`;
      const selected = machine.isSelected(region.id);
      if (region.selectable !== false && machine.selectionMode() !== 'none') proxy.setAttribute('aria-pressed', String(selected));
      const item = this.listItems.get(region.id);
      if (item) {
        item.setAttribute('aria-pressed', String(selected));
        item.dataset.hover = String(machine.hovered === region.id);
      }
    }

    const tip = machine.tooltip;
    const anchor = tip ? (this.manifest.regions ?? []).find((r) => r.id === tip.anchor) : undefined;
    if (tip && anchor) {
      const b = shapeBounds(anchor.shape, doc.width, doc.height);
      const p = docToScreen(view, b.x + b.width / 2, b.y);
      this.tooltipEl.textContent = tip.text;
      this.tooltipEl.hidden = false;
      this.tooltipEl.style.left = `${Math.min(width - 8, Math.max(8, p.x))}px`;
      this.tooltipEl.style.top = `${Math.min(height - 8, Math.max(34, p.y - 8))}px`;
      this.proxies.get(tip.anchor)?.setAttribute('aria-describedby', this.tooltipEl.id);
    } else if (!this.tooltipEl.hidden) {
      this.tooltipEl.hidden = true;
      this.proxies.forEach((p) => p.removeAttribute('aria-describedby'));
    }

    const panel = machine.panel !== null ? own(this.manifest.panels, machine.panel) : undefined;
    if (machine.panel !== this.lastPanel) {
      this.lastPanel = machine.panel;
      if (panel) {
        this.panelTitle.textContent = panel.title;
        this.panelBody.replaceChildren(renderText(panel.text, this.onTextLink));
        this.panelEl.hidden = false;
        this.panelEl.dataset.panel = machine.panel!;
        this.announce(`Panel opened: ${panel.title}`);
        // Move focus to the panel for keyboard users, but only if focus is still where the activation
        // happened: this runs a frame later, and must not pull focus back from wherever the user went next.
        const active = document.activeElement;
        if (this.lastKeyboard && (active === this.returnFocus || active === document.body || active === null)) this.panelTitle.focus();
      } else {
        this.panelEl.hidden = true;
        delete this.panelEl.dataset.panel;
      }
    }

    const selectedKey = machine.selected.join('\u0000');
    if (selectedKey !== this.lastSelected) {
      this.lastSelected = selectedKey;
      const labels = machine.selected.map((id) => (this.manifest.regions ?? []).find((r) => r.id === id)?.label ?? id);
      if (machine.panel === null || !panel) this.announce(labels.length ? `Selected: ${labels.join(', ')}` : 'Selection cleared');
    }
  }
}

/** Show the static preview and the reason when a document cannot be displayed interactively. */
export function showFallback(container: HTMLElement, message: string, details: string[], previewPng?: Uint8Array | null,
                             title?: string): void {
  const box = h('div', { class: 'aav-fallback', role: 'alert' }, h('p', { class: 'aav-notice', text: message }));
  if (previewPng && previewPng[0] === 0x89 && previewPng[1] === 0x50) {
    const img = h('img', { alt: title ? `Static preview of ${title}` : 'Static preview' });
    const url = URL.createObjectURL(new Blob([previewPng as Uint8Array<ArrayBuffer>], { type: 'image/png' }));
    img.addEventListener('load', () => URL.revokeObjectURL(url));
    img.src = url;
    box.append(img);
  }
  if (details.length) {
    const list = h('ul');
    details.slice(0, 20).forEach((d) => list.append(h('li', { class: 'aav-issue', text: d })));
    box.append(list);
  }
  container.replaceChildren(box);
}
