/** Link safety rules. Mirrors python/src/aav/links.py. */
import { LIMITS } from './limits';

const MAX_URL = LIMITS.manifest.max_url;
const AUTHORITY = /^[A-Za-z0-9.-]+(:[0-9]{1,5})?$/;
const REL_SEGMENT = /^[A-Za-z0-9._~-]+$/;

/** Why `url` is not an acceptable external link, or null if it is. */
export function externalUrlProblem(url: unknown): string | null {
  if (typeof url !== 'string') return 'URL must be a string';
  if (url.length > MAX_URL) return `URL is longer than ${MAX_URL} characters`;
  // eslint-disable-next-line no-control-regex
  if (/[\u0000- \u007f\\]/.test(url)) return 'URL contains whitespace, control characters or a backslash';
  if (!url.startsWith('https://')) return 'only https:// URLs are allowed';
  const authority = url.slice('https://'.length).split(/[/?#]/, 1)[0];
  if (authority.includes('@')) return 'URLs with embedded credentials are not allowed';
  if (!AUTHORITY.test(authority) || authority.startsWith('.') || authority.includes('..')) {
    return 'URL host is missing or malformed';
  }
  const port = authority.split(':')[1];
  if (port && Number(port) > 65535) return 'URL port is out of range';
  return null;
}

/** Validate a navigate_document target: https URL or relative .aav path. */
export function documentHrefProblem(href: unknown): string | null {
  if (typeof href !== 'string' || !href) return 'href must be a non-empty string';
  if (href.startsWith('https://')) return externalUrlProblem(href);
  if (href.length > MAX_URL) return `href is longer than ${MAX_URL} characters`;
  if (!href.endsWith('.aav')) return 'relative document links must end in .aav';
  for (const segment of href.split('/')) {
    if (segment === '' || segment === '.' || segment === '..' || !REL_SEGMENT.test(segment)) {
      return "relative document links must be plain forward-slash paths without '..', schemes or queries";
    }
  }
  return null;
}

export const isSafeExternalUrl = (url: unknown): url is string => externalUrlProblem(url) === null;
