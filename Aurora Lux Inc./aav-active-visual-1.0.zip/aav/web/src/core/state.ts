/**
 * The interaction state machine. Pure logic: no DOM, no rendering, no timers.
 *
 * Runtime state lives here and never in the manifest. The host (viewer) feeds
 * in pointer, keyboard and focus events; the machine runs the declarative
 * actions and hands back "host requests" for things only a host may do
 * (confirming and opening links, moving the view).
 *
 * Loop safety: actions never synthesise triggers. `select_region` does not
 * fire `activate`, finishing an animation fires nothing. Each host event runs
 * the actions of at most a fixed number of handlers, and a per-event budget
 * (runtime.max_actions_per_dispatch) is enforced as a second line of defence.
 */
import { EFFECT_TYPES, LIMITS, PIPELINE, own } from './limits';
import type { Action, Animation, EffectDef, EffectType, Manifest, PropValue, Region, StateName, Trigger } from './types';

const R = LIMITS.runtime;

export type HostRequest =
  | { type: 'open_link'; url: string; label?: string; region: string | null }
  | { type: 'navigate_document'; href: string; label?: string; region: string | null }
  | { type: 'reset_view' }
  | { type: 'reveal'; region: string };

export interface ResolvedEffect { id: string; type: EffectType; props: Record<string, PropValue> }
interface Transition { from: number; to: number; start: number; duration: number; easing: string }

export interface MachineOptions { reducedMotion?: boolean; now?: () => number }

export const ease = (name: string | undefined, p: number): number =>
  name === 'linear' ? p : 0.5 - 0.5 * Math.cos(Math.PI * p);

const key = (region: string, effect: string, prop: string) => `${region}\u0000${effect}\u0000${prop}`;

/** Clamp a runtime value to the property's declared range (defence in depth; validation already checked it). */
function clampProp(type: EffectType, prop: string, value: PropValue): PropValue {
  const spec = own(EFFECT_TYPES[type].props, prop);
  if (spec && spec.kind === 'number' && typeof value === 'number') {
    return Number.isFinite(value) ? Math.min(spec.max!, Math.max(spec.min!, value)) : (spec.default as number) ?? spec.min!;
  }
  return value;
}

export class Machine {
  readonly manifest: Manifest;
  hovered: string | null = null;
  focused: string | null = null;
  selected: string[] = [];
  panel: string | null = null;
  tooltip: { owner: string; anchor: string; text: string } | null = null;
  pointer: { x: number; y: number } | null = null;
  reducedMotion: boolean;
  /** Bumped on every state change, so hosts can skip redundant renders. */
  revision = 0;
  /** True if the last event hit the action budget (should never happen with a valid manifest). */
  budgetExceeded = false;

  private overrides = new Map<string, PropValue>();
  private transitions = new Map<string, Transition>();
  private layerVisible = new Map<string, boolean>();
  private running = new Map<string, number>();
  private regions = new Map<string, Region>();
  private animationsByKey = new Map<string, string[]>();
  private now: () => number;
  private budget = 0;
  private requests: HostRequest[] = [];

  constructor(manifest: Manifest, options: MachineOptions = {}) {
    this.manifest = manifest;
    this.reducedMotion = options.reducedMotion ?? false;
    this.now = options.now ?? (() => (typeof performance !== 'undefined' ? performance.now() : Date.now()));
    for (const region of manifest.regions ?? []) this.regions.set(region.id, region);
    for (const [id, anim] of Object.entries(manifest.animations ?? {})) {
      const k = key(anim.region, anim.effect, anim.property);
      this.animationsByKey.set(k, [...(this.animationsByKey.get(k) ?? []), id]);
    }
  }

  // --------------------------------------------------------------------------- host events

  /** Apply the default state and run document_load. Call once after construction, and again after reset(). */
  load(): HostRequest[] {
    return this.event(() => {
      const state = this.manifest.default_state;
      this.selected = (state?.selected ?? []).filter((id) => this.regions.has(id));
      if (this.selectionMode() === 'single') this.selected = this.selected.slice(0, 1);
      if (this.selectionMode() === 'none') this.selected = [];
      this.panel = state?.panel != null && own(this.manifest.panels, state.panel) ? state.panel : null;
      this.run(this.manifest.events?.document_load, null);
    });
  }

  /** Forget all runtime state and return to the saved default state. */
  reset(): HostRequest[] {
    this.hovered = this.focused = this.panel = this.tooltip = this.pointer = null;
    this.selected = [];
    this.overrides.clear();
    this.transitions.clear();
    this.layerVisible.clear();
    this.running.clear();
    return this.load();
  }

  /** The pointer is now over `regionId` (or nothing). Fires pointer_leave / pointer_enter as needed. */
  pointerMove(regionId: string | null, point?: { x: number; y: number } | null): HostRequest[] {
    const next = regionId !== null && this.regions.has(regionId) ? regionId : null;
    if (point !== undefined) this.pointer = point;
    if (next === this.hovered) {
      // Plain movement inside one region changes nothing unless a light is following the pointer.
      if (next !== null && this.followsPointer(next)) this.revision++;
      return [];
    }
    return this.event(() => {
      const previous = this.hovered;
      this.hovered = next;
      if (previous !== null) {
        if (this.tooltip?.owner === previous) this.tooltip = null;
        this.fire(previous, 'pointer_leave');
      }
      if (next !== null) this.fire(next, 'pointer_enter');
    });
  }

  /**
   * Click, tap, Enter or Space on a region; null means "activated empty space".
   * Selection is updated first, then the region's activate handler runs.
   */
  activate(regionId: string | null): HostRequest[] {
    return this.event(() => {
      const region = regionId !== null ? this.regions.get(regionId) : undefined;
      if (!region) {
        if (this.selectionMode() === 'single') this.selected = [];
        this.tooltip = null;
        return;
      }
      if (region.interactive === false) return;
      if (region.selectable !== false) this.select([region.id], this.selectionMode() === 'multiple' ? 'toggle' : 'select');
      this.fire(region.id, 'activate');
    });
  }

  focus(regionId: string | null): HostRequest[] {
    return this.event(() => {
      const next = regionId !== null && this.regions.has(regionId) ? regionId : null;
      if (next === this.focused) return;
      const previous = this.focused;
      this.focused = next;
      if (previous !== null) {
        if (this.tooltip?.owner === previous) this.tooltip = null;
        this.fire(previous, 'blur');
      }
      if (next !== null) this.fire(next, 'focus');
    });
  }

  blur(): HostRequest[] {
    return this.focus(null);
  }

  /** Escape: close the tooltip if one is open, otherwise the panel. Returns what was closed. */
  dismiss(): 'tooltip' | 'panel' | null {
    const closed = this.tooltip ? 'tooltip' : this.panel ? 'panel' : null;
    if (closed === 'tooltip') this.tooltip = null;
    else if (closed === 'panel') this.panel = null;
    if (closed) this.revision++;
    return closed;
  }

  closePanel(): void {
    if (this.panel !== null) {
      this.panel = null;
      this.revision++;
    }
  }

  /** Follow a link inside panel text. Region links select and reveal; panel links open. */
  followInternalLink(target: { kind: 'region' | 'panel'; id: string }): HostRequest[] {
    return this.event(() => {
      if (target.kind === 'panel') {
        if (own(this.manifest.panels, target.id)) this.panel = target.id;
      } else if (this.regions.has(target.id)) {
        this.select([target.id], 'select');
        this.requests.push({ type: 'reveal', region: target.id });
      }
    });
  }

  setReducedMotion(on: boolean): void {
    this.reducedMotion = on;
    if (on) {
      // Settle everything that is moving: transitions jump to their target, animations to their end state.
      this.transitions.clear();
      for (const id of [...this.running.keys()]) this.finish(id);
      this.revision++;
    }
  }

  // --------------------------------------------------------------------------- queries

  selectionMode(): 'single' | 'multiple' | 'none' {
    return this.manifest.settings?.selection ?? 'single';
  }

  isSelected(regionId: string): boolean {
    return this.selected.includes(regionId);
  }

  isLayerVisible(layerId: string): boolean {
    const runtime = this.layerVisible.get(layerId);
    if (runtime !== undefined) return runtime;
    return this.manifest.layers.find((l) => l.id === layerId)?.visible !== false;
  }

  /** Which interaction states currently apply to a region. */
  statesOf(regionId: string): Record<StateName, boolean> {
    return { hover: this.hovered === regionId, selected: this.isSelected(regionId), focus: this.focused === regionId };
  }

  /**
   * Resolve one effect property at time `t`. Priority, lowest to highest:
   * saved value < set_effect (with its transition) < selected < hover < focus < running animation.
   */
  propValue(regionId: string, effectId: string, prop: string, t: number = this.now()): PropValue | undefined {
    const region = this.regions.get(regionId);
    const effect = own(region?.effects, effectId);
    if (!region || !effect || !own(EFFECT_TYPES, effect.type)) return undefined;
    const spec = own(EFFECT_TYPES[effect.type].props, prop);
    if (!spec) return undefined;
    const k = key(regionId, effectId, prop);
    let value: PropValue | undefined = effect[prop] ?? (spec.default ?? undefined);
    const override = this.overrides.get(k);
    if (override !== undefined) {
      value = override;
      const tr = this.transitions.get(k);
      if (tr && t < tr.start + tr.duration) {
        value = tr.from + (tr.to - tr.from) * ease(tr.easing, Math.max(0, (t - tr.start) / tr.duration));
      }
    }
    for (const state of ['selected', 'hover', 'focus'] as StateName[]) {
      const active = state === 'selected' ? this.isSelected(regionId)
        : state === 'hover' ? this.hovered === regionId : this.focused === regionId;
      if (!active) continue;
      const stateValue = own(own(region.states?.[state], effectId), prop);
      if (stateValue !== undefined) value = stateValue;
    }
    const animated = this.animatedValue(k, t);
    if (animated !== undefined) value = animated;
    return value === undefined ? undefined : clampProp(effect.type, prop, value);
  }

  /** The region's effects with every property resolved, in pipeline order. Unknown effect types are skipped. */
  effectsFor(regionId: string, t: number = this.now()): ResolvedEffect[] {
    const region = this.regions.get(regionId);
    if (!region?.effects) return [];
    const out: ResolvedEffect[] = [];
    for (const [id, def] of Object.entries(region.effects) as [string, EffectDef][]) {
      const spec = own(EFFECT_TYPES, def.type);
      if (!spec) continue;
      const props: Record<string, PropValue> = {};
      for (const prop of Object.keys(spec.props)) {
        const value = this.propValue(regionId, id, prop, t);
        if (value !== undefined) props[prop] = value;
      }
      out.push({ id, type: def.type, props });
    }
    return out.sort((a, b) => PIPELINE.indexOf(a.type) - PIPELINE.indexOf(b.type) || (a.id < b.id ? -1 : 1));
  }

  /** True if the region has a spotlight whose follow_pointer currently resolves to true. */
  followsPointer(regionId: string): boolean {
    const effects = this.regions.get(regionId)?.effects;
    if (!effects) return false;
    return Object.entries(effects).some(([id, def]) =>
      def.type === 'spotlight' && this.propValue(regionId, id, 'follow_pointer') === true);
  }

  isAnimating(): boolean {
    return this.running.size > 0 || this.transitions.size > 0;
  }

  runningAnimations(): string[] {
    return [...this.running.keys()];
  }

  /** Advance time: retire finished animations and transitions. Returns true while anything is still moving. */
  tick(t: number = this.now()): boolean {
    for (const [id, start] of [...this.running]) {
      const anim = this.manifest.animations![id];
      if (t - start >= anim.duration_ms * (anim.iterations ?? 1)) this.finish(id);
    }
    for (const [k, tr] of [...this.transitions]) {
      if (t >= tr.start + tr.duration) {
        this.transitions.delete(k);
        this.revision++;
      }
    }
    return this.isAnimating();
  }

  /** The parts of runtime state an author may deliberately save as the document's default state. */
  snapshot(): { selected: string[]; panel: string | null } {
    return { selected: [...this.selected], panel: this.panel };
  }

  // --------------------------------------------------------------------------- internals

  private event(body: () => void): HostRequest[] {
    this.budget = R.max_actions_per_dispatch;
    this.budgetExceeded = false;
    this.requests = [];
    body();
    this.revision++;
    return this.requests;
  }

  private fire(regionId: string, trigger: Trigger): void {
    this.run(this.regions.get(regionId)?.events?.[trigger], regionId);
  }

  private run(actions: Action[] | undefined, self: string | null): void {
    for (const action of actions ?? []) {
      if (this.budget <= 0) {
        this.budgetExceeded = true;
        return;
      }
      this.budget--;
      this.perform(action, self);
    }
  }

  private targets(action: { region?: string; group?: string }, self: string | null): string[] {
    if (action.region !== undefined) return this.regions.has(action.region) ? [action.region] : [];
    if (action.group !== undefined) {
      return (own(this.manifest.groups, action.group)?.regions ?? []).filter((id) => this.regions.has(id));
    }
    return self !== null ? [self] : [];
  }

  private select(ids: string[], mode: 'select' | 'deselect' | 'toggle'): void {
    const policy = this.selectionMode();
    if (policy === 'none') return;
    const selectable = ids.filter((id) => this.regions.get(id)?.selectable !== false);
    for (const id of selectable) {
      const has = this.selected.includes(id);
      const want = mode === 'select' ? true : mode === 'deselect' ? false : !has;
      if (want && !has) this.selected = policy === 'single' ? [id] : [...this.selected, id];
      else if (!want && has) this.selected = this.selected.filter((s) => s !== id);
    }
  }

  private perform(action: Action, self: string | null): void {
    switch (action.action) {
      case 'set_effect': {
        for (const regionId of this.targets(action, self)) {
          const effect = own(this.regions.get(regionId)!.effects, action.effect);
          const spec = effect && own(EFFECT_TYPES, effect.type) ? own(EFFECT_TYPES[effect.type].props, action.property) : undefined;
          if (!effect || !spec) continue;
          const k = key(regionId, action.effect, action.property);
          const value = clampProp(effect.type, action.property, action.value);
          const duration = this.reducedMotion ? 0 : Math.min(action.duration_ms ?? 0, R.max_transition_ms);
          if (duration > 0 && typeof value === 'number') {
            const t = this.now();
            const current = this.underlying(regionId, action.effect, action.property, t);
            if (typeof current === 'number' && current !== value) {
              this.transitions.set(k, { from: current, to: value, start: t, duration, easing: action.easing ?? 'ease-in-out' });
            }
          } else this.transitions.delete(k);
          this.overrides.set(k, value);
        }
        break;
      }
      case 'toggle_layer': {
        if (!this.manifest.layers.some((l) => l.id === action.layer)) break;
        const mode = action.mode ?? 'toggle';
        this.layerVisible.set(action.layer, mode === 'show' ? true : mode === 'hide' ? false : !this.isLayerVisible(action.layer));
        break;
      }
      case 'select_region': {
        const ids = this.targets(action, self);
        this.select(ids, action.mode ?? 'select');
        if (action.reveal && ids.length) this.requests.push({ type: 'reveal', region: ids[0] });
        break;
      }
      case 'show_tooltip': {
        const anchor = action.region ?? self;
        const region = anchor !== null ? this.regions.get(anchor) : undefined;
        if (region) this.tooltip = { owner: self ?? region.id, anchor: region.id, text: action.text ?? region.tooltip ?? region.label };
        break;
      }
      case 'open_panel':
        if (own(this.manifest.panels, action.panel)) this.panel = action.panel;
        break;
      case 'open_link':
        this.requests.push({ type: 'open_link', url: action.url, label: action.label, region: self });
        break;
      case 'navigate_document':
        this.requests.push({ type: 'navigate_document', href: action.href, label: action.label, region: self });
        break;
      case 'play_animation': {
        const anim = own(this.manifest.animations, action.animation);
        if (!anim) break;
        if (this.reducedMotion) {
          this.settle(anim);
          break;
        }
        if (!this.running.has(action.animation) && this.running.size >= R.max_running_animations) break;
        this.running.delete(action.animation); // restarting moves it to the end: newest wins on shared properties
        this.running.set(action.animation, this.now());
        break;
      }
      case 'stop_animation':
        if (action.animation === undefined) this.running.clear();
        else this.running.delete(action.animation);
        break;
      case 'reset_view':
        this.requests.push({ type: 'reset_view' });
        break;
      default:
        break; // unknown actions from newer minor versions are ignored
    }
  }

  /** Value ignoring interaction states and animations: what a transition starts from. */
  private underlying(regionId: string, effectId: string, prop: string, t: number): PropValue | undefined {
    const k = key(regionId, effectId, prop);
    const override = this.overrides.get(k);
    if (override !== undefined) {
      const tr = this.transitions.get(k);
      if (tr && t < tr.start + tr.duration) return tr.from + (tr.to - tr.from) * ease(tr.easing, (t - tr.start) / tr.duration);
      return override;
    }
    const effect = own(this.regions.get(regionId)?.effects, effectId);
    if (!effect) return undefined;
    return effect[prop] ?? (own(EFFECT_TYPES[effect.type].props, prop)?.default ?? undefined);
  }

  private animatedValue(k: string, t: number): number | undefined {
    const ids = this.animationsByKey.get(k);
    if (!ids || this.running.size === 0) return undefined;
    let value: number | undefined;
    for (const [id, start] of this.running) { // insertion order: the most recently started wins
      if (!ids.includes(id)) continue;
      const anim = this.manifest.animations![id];
      const elapsed = Math.max(0, t - start);
      if (elapsed >= anim.duration_ms * (anim.iterations ?? 1)) {
        value = this.endValue(anim) ?? value;
        continue;
      }
      const p = (elapsed % anim.duration_ms) / anim.duration_ms;
      const shaped = anim.type === 'pulse' ? ease(anim.easing, 1 - Math.abs(2 * p - 1)) : ease(anim.easing, p);
      value = anim.from + (anim.to - anim.from) * shaped;
    }
    return value;
  }

  /** The value an animation leaves behind, or undefined if it reverts. */
  private endValue(anim: Animation): number | undefined {
    const end = anim.end ?? (anim.type === 'fade' ? 'hold' : 'revert');
    if (end !== 'hold') return undefined;
    return anim.type === 'fade' ? anim.to : anim.from;
  }

  private settle(anim: Animation): void {
    const value = this.endValue(anim);
    if (value === undefined) return;
    const k = key(anim.region, anim.effect, anim.property);
    this.transitions.delete(k);
    this.overrides.set(k, value);
  }

  private finish(id: string): void {
    this.running.delete(id);
    const anim = own(this.manifest.animations, id);
    if (anim) this.settle(anim);
    this.revision++;
  }
}
