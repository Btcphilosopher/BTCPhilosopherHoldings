/**
 * The .aav container: a restricted, deterministic ZIP profile.
 * Mirrors python/src/aav/archive.py (read_zip / write_zip). See docs/SPEC.md section 3.
 */
import { Inflate } from 'fflate';
import { LIMITS } from './limits';
import { AavError } from './types';

const A = LIMITS.archive;
export const MANIFEST = 'manifest.json';
export const PREVIEW = 'preview.png';
const FLAG_UTF8 = 0x0800;
const DOS_TIME = 0, DOS_DATE = 0x0021; // 1980-01-01 00:00:00

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

export function crc32(data: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** Why an archive entry name is unsafe, or null. */
export function entryPathProblem(name: string): string | null {
  if (!name) return 'empty name';
  if (new TextEncoder().encode(name).length > A.max_path_length) return `name is longer than ${A.max_path_length} bytes`;
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u001f\u007f]/.test(name)) return 'name contains control characters';
  if (name.includes('\\') || name.includes(':')) return 'name contains a backslash or colon';
  if (name.startsWith('/')) return 'absolute paths are not allowed';
  if (name.normalize('NFC') !== name) return 'name is not NFC-normalised';
  const segments = (name.endsWith('/') ? name.slice(0, -1) : name).split('/');
  if (segments.some((s) => s === '' || s === '.' || s === '..')) return "name contains an empty, '.' or '..' segment";
  return null;
}

function fail(code: string, path: string, message: string): never {
  throw new AavError({ code, path, message });
}

function sig(data: Uint8Array, pos: number, a: number, b: number): boolean {
  return data[pos] === 0x50 && data[pos + 1] === 0x4b && data[pos + 2] === a && data[pos + 3] === b;
}

function inflateBounded(raw: Uint8Array, size: number, name: string): Uint8Array {
  const out = new Uint8Array(size);
  let pos = 0;
  try {
    const inflater = new Inflate((chunk) => {
      if (pos + chunk.length > size) throw new Error('too large');
      out.set(chunk, pos);
      pos += chunk.length;
    });
    const step = 16384; // small input slices bound the transient output of a hostile stream
    for (let i = 0; i < raw.length || i === 0; i += step) {
      inflater.push(raw.subarray(i, i + step), i + step >= raw.length);
    }
  } catch (err) {
    if (err instanceof Error && err.message === 'too large') {
      fail('E_ARCHIVE_SIZE', name, 'entry does not inflate to its declared size');
    }
    fail('E_ARCHIVE_FORMAT', name, 'corrupt deflate stream');
  }
  if (pos !== size) fail('E_ARCHIVE_SIZE', name, 'entry does not inflate to its declared size');
  return out;
}

interface Entry {
  name: string; rawName: Uint8Array; method: number; crc: number; csize: number; usize: number; offset: number;
}

/** Parse the restricted ZIP profile. Throws AavError on any violation. */
export function readZip(data: Uint8Array): Map<string, Uint8Array> {
  const n = data.length;
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  if (n > A.max_total_bytes + 16 * 1024 * 1024) fail('E_ARCHIVE_LIMIT', '', 'container is larger than the total size limit');
  if (n < 22 || !sig(data, 0, 3, 4)) {
    fail('E_ARCHIVE_FORMAT', '', 'not an AAV container: the file must begin with a ZIP local file header');
  }
  const eocd = n - 22;
  if (!sig(data, eocd, 5, 6)) {
    fail('E_ARCHIVE_FORMAT', '',
      'ZIP end record not found at the end of the file (archive comments and trailing data are not allowed)');
  }
  const disk = view.getUint16(eocd + 4, true), cdDisk = view.getUint16(eocd + 6, true);
  const diskEntries = view.getUint16(eocd + 8, true), entries = view.getUint16(eocd + 10, true);
  const cdSize = view.getUint32(eocd + 12, true), cdOffset = view.getUint32(eocd + 16, true);
  const commentLen = view.getUint16(eocd + 20, true);
  if (disk || cdDisk || diskEntries !== entries || commentLen) {
    fail('E_ARCHIVE_FORMAT', '', 'multi-disk archives and archive comments are not allowed');
  }
  if (entries === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff) {
    fail('E_ARCHIVE_FORMAT', '', 'ZIP64 archives are not supported');
  }
  if (entries > A.max_entries) fail('E_ARCHIVE_LIMIT', '', `archive has more than ${A.max_entries} entries`);
  if (cdOffset + cdSize !== eocd) fail('E_ARCHIVE_FORMAT', '', 'central directory does not end at the end record');

  const records: Entry[] = [];
  const seen = new Map<string, string>();
  let total = 0;
  let pos = cdOffset;
  for (let i = 0; i < entries; i++) {
    if (pos + 46 > eocd || !sig(data, pos, 1, 2)) fail('E_ARCHIVE_FORMAT', '', 'corrupt central directory');
    const flags = view.getUint16(pos + 8, true), method = view.getUint16(pos + 10, true);
    const crc = view.getUint32(pos + 16, true), csize = view.getUint32(pos + 20, true);
    const usize = view.getUint32(pos + 24, true), nlen = view.getUint16(pos + 28, true);
    const xlen = view.getUint16(pos + 30, true), clen = view.getUint16(pos + 32, true);
    const offset = view.getUint32(pos + 42, true);
    const rawName = data.subarray(pos + 46, pos + 46 + nlen);
    pos += 46 + nlen + xlen + clen;
    if (pos > eocd || rawName.length !== nlen) fail('E_ARCHIVE_FORMAT', '', 'corrupt central directory');
    let name = '';
    try {
      if (!(flags & FLAG_UTF8) && rawName.some((b) => b > 0x7f)) throw new Error('not ascii');
      name = new TextDecoder('utf-8', { fatal: true }).decode(rawName);
    } catch {
      fail('E_ARCHIVE_PATH', '(undecodable)', 'entry name is not valid UTF-8 (or not ASCII without the UTF-8 flag)');
    }
    const problem = entryPathProblem(name);
    if (problem) fail('E_ARCHIVE_PATH', name, `unsafe entry name: ${problem}`);
    if (flags & 0x0041) fail('E_ARCHIVE_ENCRYPTED', name, 'encrypted entries are not allowed');
    if (method !== 0 && method !== 8) {
      fail('E_ARCHIVE_METHOD', name, `compression method ${method} is not allowed (stored or deflate only)`);
    }
    if (csize === 0xffffffff || usize === 0xffffffff || offset === 0xffffffff) {
      fail('E_ARCHIVE_FORMAT', name, 'ZIP64 entries are not supported');
    }
    const key = name.replace(/\/+$/, '').toLowerCase();
    if (seen.has(key)) fail('E_ARCHIVE_DUPLICATE', name, `duplicate entry (matches '${seen.get(key)}' ignoring case)`);
    seen.set(key, name);
    if (usize > A.max_file_bytes) {
      fail('E_ARCHIVE_LIMIT', name, `entry is larger than ${A.max_file_bytes} bytes uncompressed`);
    }
    total += usize;
    if (total > A.max_total_bytes) fail('E_ARCHIVE_LIMIT', name, `archive expands to more than ${A.max_total_bytes} bytes`);
    if (usize > A.ratio_floor_bytes && csize * A.max_ratio < usize) {
      fail('E_ARCHIVE_RATIO', name, `compression ratio exceeds ${A.max_ratio}:1`);
    }
    if (method === 0 && csize !== usize) fail('E_ARCHIVE_SIZE', name, 'stored entry has mismatched sizes');
    records.push({ name, rawName, method, crc, csize, usize, offset });
  }
  if (pos !== eocd) fail('E_ARCHIVE_FORMAT', '', 'central directory size does not match its contents');

  const spans: { start: number; end: number; name: string; dataStart: number }[] = [];
  for (const r of records) {
    if (r.offset + 30 > cdOffset || !sig(data, r.offset, 3, 4)) {
      fail('E_ARCHIVE_FORMAT', r.name, 'local file header is missing');
    }
    const lnlen = view.getUint16(r.offset + 26, true), lxlen = view.getUint16(r.offset + 28, true);
    const localName = data.subarray(r.offset + 30, r.offset + 30 + lnlen);
    if (localName.length !== r.rawName.length || localName.some((b, i) => b !== r.rawName[i])) {
      fail('E_ARCHIVE_FORMAT', r.name, 'local and central entry names differ');
    }
    const dataStart = r.offset + 30 + lnlen + lxlen;
    if (dataStart + r.csize > cdOffset) fail('E_ARCHIVE_FORMAT', r.name, 'entry data runs past the central directory');
    spans.push({ start: r.offset, end: dataStart + r.csize, name: r.name, dataStart });
  }
  const sorted = [...spans].sort((a, b) => a.start - b.start);
  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i].start < sorted[i - 1].end) {
      fail('E_ARCHIVE_OVERLAP', sorted[i].name, `entry overlaps '${sorted[i - 1].name}'`);
    }
  }

  const out = new Map<string, Uint8Array>();
  records.forEach((r, i) => {
    const raw = data.subarray(spans[i].dataStart, spans[i].dataStart + r.csize);
    const payload = r.method === 8 ? inflateBounded(raw, r.usize, r.name) : raw.slice();
    if (crc32(payload) !== r.crc) fail('E_ARCHIVE_CRC', r.name, 'CRC-32 mismatch');
    if (r.name.endsWith('/')) {
      if (r.usize) fail('E_ARCHIVE_PATH', r.name, 'directory entries must be empty');
      return;
    }
    out.set(r.name, payload);
  });
  return out;
}

/** Write a deterministic archive: fixed order, stored entries, fixed timestamps. */
export function writeZip(files: Map<string, Uint8Array>): Uint8Array {
  const names = [...files.keys()];
  const head = [MANIFEST, PREVIEW].filter((n) => files.has(n));
  const rest = names.filter((n) => !head.includes(n)).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  const order = [...head, ...rest];
  const encoder = new TextEncoder();
  const encoded = order.map((name) => {
    const problem = entryPathProblem(name);
    if (problem || name.endsWith('/')) fail('E_ARCHIVE_PATH', name, `unsafe entry name: ${problem ?? 'directory entry'}`);
    return encoder.encode(name);
  });
  let bodySize = 0, centralSize = 0;
  order.forEach((name, i) => {
    bodySize += 30 + encoded[i].length + files.get(name)!.length;
    centralSize += 46 + encoded[i].length;
  });
  const out = new Uint8Array(bodySize + centralSize + 22);
  const view = new DataView(out.buffer);
  let pos = 0, cpos = bodySize;
  order.forEach((name, i) => {
    const payload = files.get(name)!, rawName = encoded[i], crc = crc32(payload);
    const writeCommon = (at: number) => {
      view.setUint16(at, 20, true); view.setUint16(at + 2, FLAG_UTF8, true); view.setUint16(at + 4, 0, true);
      view.setUint16(at + 6, DOS_TIME, true); view.setUint16(at + 8, DOS_DATE, true);
      view.setUint32(at + 10, crc, true); view.setUint32(at + 14, payload.length, true);
      view.setUint32(at + 18, payload.length, true); view.setUint16(at + 22, rawName.length, true);
      view.setUint16(at + 24, 0, true);
    };
    view.setUint32(cpos, 0x02014b50, true); view.setUint16(cpos + 4, 20, true);
    writeCommon(cpos + 6);
    view.setUint32(cpos + 42, pos, true);
    out.set(rawName, cpos + 46);
    cpos += 46 + rawName.length;
    view.setUint32(pos, 0x04034b50, true);
    writeCommon(pos + 4);
    out.set(rawName, pos + 30);
    out.set(payload, pos + 30 + rawName.length);
    pos += 30 + rawName.length + payload.length;
  });
  view.setUint32(cpos, 0x06054b50, true);
  view.setUint16(cpos + 8, order.length, true); view.setUint16(cpos + 10, order.length, true);
  view.setUint32(cpos + 12, centralSize, true); view.setUint32(cpos + 16, bodySize, true);
  return out;
}
