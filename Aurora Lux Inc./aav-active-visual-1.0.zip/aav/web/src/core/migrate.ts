/**
 * Version migration. Mirrors python/src/aav/migrate.py.
 *
 * Schema 1.0 is the first published version. The single migration shipped is
 * from the unpublished pre-release draft "0.9" and exists mainly to exercise
 * and document the mechanism (SPEC section 13).
 */
import { FORMAT, VERSION } from './limits';
import { AavError } from './types';

type Json = unknown;

function renameKey(value: Json, from: string, to: string): Json {
  if (Array.isArray(value)) return value.map((v) => renameKey(v, from, to));
  if (typeof value === 'object' && value !== null) {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k === from ? to : k, renameKey(v, from, to)]));
  }
  return value;
}

function from09(manifest: Record<string, Json>): Record<string, Json> {
  const out = renameKey(manifest, 'color', 'colour') as Record<string, Json>;
  if ('hotspots' in out) {
    out.regions = out.hotspots;
    delete out.hotspots;
  }
  const doc = out.document as Record<string, Json> | undefined;
  if (doc && Array.isArray(doc.size) && doc.size.length === 2) {
    [doc.width, doc.height] = doc.size;
    delete doc.size;
  }
  out.version = '1.0';
  return out;
}

const MIGRATIONS: Record<string, (m: Record<string, Json>) => Record<string, Json>> = { '0.9': from09 };

export const needsMigration = (manifest: unknown): boolean =>
  typeof manifest === 'object' && manifest !== null &&
  Object.prototype.hasOwnProperty.call(MIGRATIONS, String((manifest as { version?: unknown }).version));

/** Upgrade a manifest to the current version. Returns the new manifest and the steps applied. */
export function migrate(manifest: unknown): { manifest: Record<string, Json>; steps: string[] } {
  if (typeof manifest !== 'object' || manifest === null || (manifest as { format?: unknown }).format !== FORMAT) {
    throw new AavError({ code: 'E_FORMAT', path: '/format', message: `format must be '${FORMAT}'` });
  }
  let out = structuredClone(manifest) as Record<string, Json>;
  const steps: string[] = [];
  while (Object.prototype.hasOwnProperty.call(MIGRATIONS, String(out.version))) {
    const before = String(out.version);
    out = MIGRATIONS[before](out);
    steps.push(`${before} -> ${String(out.version)}`);
  }
  if (!steps.length && String(out.version ?? '').split('.')[0] !== VERSION.split('.')[0]) {
    throw new AavError({ code: 'E_VERSION', path: '/version', message: `no migration path from version ${JSON.stringify(out.version)}` });
  }
  return { manifest: out, steps };
}
