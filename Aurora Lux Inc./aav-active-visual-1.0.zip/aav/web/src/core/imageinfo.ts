/** Image type and size from header bytes only, without decoding pixels. Mirrors sniff_image in archive.py. */
export interface ImageInfo { mediaType: 'image/png' | 'image/jpeg' | 'image/webp'; width: number; height: number }

const ascii = (d: Uint8Array, at: number, text: string): boolean =>
  [...text].every((ch, i) => d[at + i] === ch.charCodeAt(0));

export function sniffImage(d: Uint8Array): ImageInfo | null {
  const view = new DataView(d.buffer, d.byteOffset, d.byteLength);
  if (d.length >= 24 && d[0] === 0x89 && ascii(d, 1, 'PNG\r\n\x1a\n') && ascii(d, 12, 'IHDR')) {
    return { mediaType: 'image/png', width: view.getUint32(16), height: view.getUint32(20) };
  }
  if (d.length >= 4 && d[0] === 0xff && d[1] === 0xd8 && d[2] === 0xff) {
    let pos = 2;
    while (pos + 4 <= d.length) {
      if (d[pos] !== 0xff) return null;
      const marker = d[pos + 1];
      if (marker === 0xff) { pos += 1; continue; }
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { pos += 2; continue; }
      const length = view.getUint16(pos + 2);
      if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
        if (pos + 9 > d.length) return null;
        return { mediaType: 'image/jpeg', width: view.getUint16(pos + 7), height: view.getUint16(pos + 5) };
      }
      if (length < 2) return null;
      pos += 2 + length;
    }
    return null;
  }
  if (d.length >= 30 && ascii(d, 0, 'RIFF') && ascii(d, 8, 'WEBP')) {
    if (ascii(d, 12, 'VP8 ') && d[23] === 0x9d && d[24] === 0x01 && d[25] === 0x2a) {
      return { mediaType: 'image/webp', width: view.getUint16(26, true) & 0x3fff, height: view.getUint16(28, true) & 0x3fff };
    }
    if (ascii(d, 12, 'VP8L') && d[20] === 0x2f) {
      const bits = view.getUint32(21, true);
      return { mediaType: 'image/webp', width: (bits & 0x3fff) + 1, height: ((bits >>> 14) & 0x3fff) + 1 };
    }
    if (ascii(d, 12, 'VP8X')) {
      return {
        mediaType: 'image/webp',
        width: (d[24] | (d[25] << 8) | (d[26] << 16)) + 1,
        height: (d[27] | (d[28] << 8) | (d[29] << 16)) + 1,
      };
    }
  }
  return null;
}
