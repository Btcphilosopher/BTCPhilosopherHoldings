/**
 * Optional WebGL2 backend for the per-pixel colour stage.
 *
 * The scene is always composited with Canvas 2D. Only `colourChain` (brightness,
 * contrast, saturation, tint, spotlight, opacity) is replaceable: this backend
 * runs the same arithmetic in a fragment shader. Spatial effects (pixelate,
 * blur) and overlays (glow, outline) always use the reference CPU code.
 */
import type { ColourChain, PixelBuffer } from './pixels';
import { colourChain } from './pixels';

/** A colour-stage implementation. Draws the processed buffer into `target` at (0, 0). */
export interface ColourBackend {
  readonly name: 'cpu' | 'webgl2';
  run(img: ImageData, chain: ColourChain, originX: number, originY: number, target: CanvasRenderingContext2D): void;
  dispose(): void;
}

export class CpuBackend implements ColourBackend {
  readonly name = 'cpu' as const;
  run(img: ImageData, chain: ColourChain, originX: number, originY: number, target: CanvasRenderingContext2D): void {
    colourChain(img as PixelBuffer, chain, originX, originY);
    target.putImageData(img, 0, 0);
  }
  dispose(): void { /* nothing to release */ }
}

const VERTEX = `#version 300 es
in vec2 position;
out vec2 uv;
void main() {
  uv = vec2(position.x * 0.5 + 0.5, 0.5 - position.y * 0.5);
  gl_Position = vec4(position, 0.0, 1.0);
}`;

const FRAGMENT = `#version 300 es
precision highp float;
uniform sampler2D source;
uniform vec2 size;
uniform vec2 origin;
uniform float brightness;
uniform float contrast;
uniform float saturation;
uniform vec4 tint;        // rgb, amount
uniform int tintMode;     // -1 off, 0 normal, 1 multiply, 2 screen
uniform vec4 lightColour; // rgb, intensity
uniform vec4 light;       // x, y, radius, falloff
uniform float ambient;
uniform bool lightOn;
uniform float opacity;
in vec2 uv;
out vec4 outColour;
void main() {
  vec4 texel = texture(source, uv);
  vec3 c = texel.rgb * brightness;
  c = (c - 0.5) * contrast + 0.5;
  float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = clamp(vec3(luma) + (c - vec3(luma)) * saturation, 0.0, 1.0);
  if (tintMode == 0) c += (tint.rgb - c) * tint.a;
  else if (tintMode == 1) c += (c * tint.rgb - c) * tint.a;
  else if (tintMode == 2) c += (1.0 - (1.0 - c) * (1.0 - tint.rgb) - c) * tint.a;
  if (lightOn) {
    float d = distance(origin + uv * size, light.xy) / light.z;
    float l = d < 1.0 ? pow(1.0 - d, light.w) * lightColour.a : 0.0;
    c *= ambient + l * lightColour.rgb;
  }
  c = clamp(c, 0.0, 1.0);
  float a = texel.a * clamp(opacity, 0.0, 1.0);
  outColour = vec4(c * a, a);
}`;

export class WebGL2Backend implements ColourBackend {
  readonly name = 'webgl2' as const;
  private canvas: HTMLCanvasElement;
  private gl: WebGL2RenderingContext;
  private program: WebGLProgram;
  private texture: WebGLTexture;
  private uniforms: Record<string, WebGLUniformLocation | null> = {};
  private maxSize: number;
  private fallback = new CpuBackend();
  lost = false;

  private constructor(canvas: HTMLCanvasElement, gl: WebGL2RenderingContext, program: WebGLProgram) {
    this.canvas = canvas;
    this.gl = gl;
    this.program = program;
    this.maxSize = gl.getParameter(gl.MAX_TEXTURE_SIZE) as number;
    for (const name of ['source', 'size', 'origin', 'brightness', 'contrast', 'saturation', 'tint', 'tintMode',
      'lightColour', 'light', 'ambient', 'lightOn', 'opacity']) {
      this.uniforms[name] = gl.getUniformLocation(program, name);
    }
    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const location = gl.getAttribLocation(program, 'position');
    gl.enableVertexAttribArray(location);
    gl.vertexAttribPointer(location, 2, gl.FLOAT, false, 0, 0);
    this.texture = gl.createTexture()!;
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    canvas.addEventListener('webglcontextlost', (event) => {
      event.preventDefault();
      this.lost = true; // every later call falls back to the CPU path
    });
  }

  /** Returns null when WebGL2 is unavailable or the shaders do not compile. */
  static create(): WebGL2Backend | null {
    if (typeof document === 'undefined') return null;
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl2', { premultipliedAlpha: true, antialias: false, depth: false, stencil: false });
      if (!gl) return null;
      const compile = (type: number, source: string): WebGLShader | null => {
        const shader = gl.createShader(type);
        if (!shader) return null;
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        return gl.getShaderParameter(shader, gl.COMPILE_STATUS) ? shader : null;
      };
      const vs = compile(gl.VERTEX_SHADER, VERTEX), fs = compile(gl.FRAGMENT_SHADER, FRAGMENT);
      const program = gl.createProgram();
      if (!vs || !fs || !program) return null;
      gl.attachShader(program, vs);
      gl.attachShader(program, fs);
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return null;
      gl.useProgram(program);
      return new WebGL2Backend(canvas, gl, program);
    } catch {
      return null;
    }
  }

  run(img: ImageData, chain: ColourChain, originX: number, originY: number, target: CanvasRenderingContext2D): void {
    const gl = this.gl;
    if (this.lost || gl.isContextLost() || img.width > this.maxSize || img.height > this.maxSize) {
      this.fallback.run(img, chain, originX, originY, target);
      return;
    }
    if (this.canvas.width !== img.width || this.canvas.height !== img.height) {
      this.canvas.width = img.width;
      this.canvas.height = img.height;
    }
    gl.viewport(0, 0, img.width, img.height);
    gl.useProgram(this.program);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, img.width, img.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, img.data);
    const u = this.uniforms;
    gl.uniform1i(u.source, 0);
    gl.uniform2f(u.size, img.width, img.height);
    gl.uniform2f(u.origin, originX, originY);
    gl.uniform1f(u.brightness, chain.brightness);
    gl.uniform1f(u.contrast, chain.contrast);
    gl.uniform1f(u.saturation, chain.saturation);
    const t = chain.tint;
    gl.uniform4f(u.tint, t?.r ?? 0, t?.g ?? 0, t?.b ?? 0, t?.amount ?? 0);
    gl.uniform1i(u.tintMode, t ? t.mode : -1);
    const s = chain.spotlight;
    gl.uniform1i(u.lightOn, s ? 1 : 0);
    gl.uniform4f(u.lightColour, s?.r ?? 0, s?.g ?? 0, s?.b ?? 0, s?.intensity ?? 0);
    gl.uniform4f(u.light, s?.x ?? 0, s?.y ?? 0, s?.radius ?? 1, s?.falloff ?? 1);
    gl.uniform1f(u.ambient, s?.ambient ?? 1);
    gl.uniform1f(u.opacity, chain.opacity);
    gl.disable(gl.BLEND);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    target.save();
    target.setTransform(1, 0, 0, 1, 0, 0);
    target.globalCompositeOperation = 'copy';
    target.drawImage(this.canvas, 0, 0);
    target.restore();
  }

  dispose(): void {
    this.gl.getExtension('WEBGL_lose_context')?.loseContext();
  }
}

/** 'auto' picks WebGL2 when it works and silently uses the CPU reference otherwise. */
export function createBackend(preference: 'auto' | 'cpu' | 'webgl2' = 'auto'): ColourBackend {
  if (preference !== 'cpu') {
    const gpu = WebGL2Backend.create();
    if (gpu) return gpu;
  }
  return new CpuBackend();
}
