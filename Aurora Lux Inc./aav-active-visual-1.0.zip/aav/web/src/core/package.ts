/** Loading, validating and saving whole documents. Mirrors the package half of archive.py. */
import { sniffImage } from './imageinfo';
import { LIMITS } from './limits';
import type { AavPackage, Issue, Manifest } from './types';
import { AavError, errorsOnly } from './types';
import { validateManifest } from './validate';
import { MANIFEST, PREVIEW, readZip, writeZip } from './zip';

const IMG = LIMITS.image;

const K = new Uint32Array(64);
(() => {
  let n = 0;
  for (let candidate = 2; n < 64; candidate++) {
    let prime = true;
    for (let d = 2; d * d <= candidate; d++) if (candidate % d === 0) { prime = false; break; }
    if (prime) K[n++] = (Math.cbrt(candidate) % 1) * 2 ** 32;
  }
})();

/** Synchronous SHA-256, used where SubtleCrypto is unavailable (non-secure contexts). */
export function sha256Sync(data: Uint8Array): string {
  const h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
    0x5be0cd19]);
  const padded = new Uint8Array((((data.length + 8) >> 6) + 1) << 6);
  padded.set(data);
  padded[data.length] = 0x80;
  const view = new DataView(padded.buffer);
  view.setUint32(padded.length - 8, Math.floor(data.length / 2 ** 29));
  view.setUint32(padded.length - 4, (data.length << 3) >>> 0);
  const w = new Uint32Array(64);
  const rotr = (x: number, r: number) => (x >>> r) | (x << (32 - r));
  for (let off = 0; off < padded.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4);
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
      const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let i = 0; i < 64; i++) {
      const t1 = (hh + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
      const t2 = ((rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
  }
  return [...h].map((x) => x.toString(16).padStart(8, '0')).join('');
}

export async function sha256Hex(data: Uint8Array): Promise<string> {
  const subtle = globalThis.crypto?.subtle;
  if (!subtle) return sha256Sync(data);
  const digest = await subtle.digest('SHA-256', data as Uint8Array<ArrayBuffer>);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** Parse manifest JSON strictly: UTF-8, no BOM, bounded size. JSON.parse already rejects NaN/Infinity literals. */
export function parseManifest(bytes: Uint8Array): Manifest {
  if (bytes.length > LIMITS.manifest.max_bytes) {
    throw new AavError({ code: 'E_LIMIT', path: MANIFEST, message: `manifest is larger than ${LIMITS.manifest.max_bytes} bytes` });
  }
  if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    throw new AavError({ code: 'E_JSON', path: MANIFEST, message: 'manifest must not start with a byte-order mark' });
  }
  let value: unknown;
  try {
    value = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  } catch (err) {
    throw new AavError({ code: 'E_JSON', path: MANIFEST, message: `manifest is not valid UTF-8 JSON: ${(err as Error).message}` });
  }
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new AavError({ code: 'E_TYPE', path: '', message: 'manifest must be a JSON object' });
  }
  return value as Manifest;
}

function sortKeys(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortKeys);
  if (typeof value === 'object' && value !== null) {
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(value).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))) {
      const v = (value as Record<string, unknown>)[key];
      if (v !== undefined) out[key] = sortKeys(v);
    }
    return out;
  }
  if (typeof value === 'number' && !Number.isFinite(value)) {
    throw new AavError({ code: 'E_NONFINITE', path: '', message: 'manifest contains a non-finite number' });
  }
  return value;
}

/** Canonical manifest bytes: sorted keys, two-space indent, LF, UTF-8, trailing newline. */
export function canonicalJson(manifest: unknown): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(sortKeys(manifest), null, 2) + '\n');
}

export function referencedPaths(manifest: Manifest): Set<string> {
  const paths = new Set<string>([MANIFEST, PREVIEW]);
  for (const asset of Object.values(manifest.assets ?? {})) paths.add(asset.path);
  if (manifest.thumbnail) paths.add(manifest.thumbnail);
  return paths;
}

/** Validate the manifest and its consistency with the packaged files. */
export async function validatePackage(pkg: AavPackage, opts: { strict?: boolean; requirePreview?: boolean } = {}):
  Promise<Issue[]> {
  const issues = validateManifest(pkg.manifest);
  if (errorsOnly(issues).length) return issues;
  const { manifest, files } = pkg;
  const add = (code: string, path: string, message: string) => issues.push({ code, path, message });

  const imageOk = (path: string, expected: string | null): { width: number; height: number } | null => {
    const info = sniffImage(files.get(path)!);
    if (!info) {
      add('E_ASSET_TYPE', path, 'file is not a recognisable PNG, JPEG or WebP image');
      return null;
    }
    if (expected && info.mediaType !== expected) {
      add('E_ASSET_TYPE', path, `file content is ${info.mediaType} but ${expected} is declared`);
      return null;
    }
    if (info.width < 1 || info.height < 1 || info.width > IMG.max_dimension || info.height > IMG.max_dimension) {
      add('E_ASSET_DIMENSIONS', path,
        `image is ${info.width}x${info.height}; each side must be 1 to ${IMG.max_dimension} pixels`);
      return null;
    }
    return info;
  };

  if (!files.has(PREVIEW)) {
    if (opts.requirePreview !== false) add('E_ARCHIVE_MISSING', PREVIEW, 'static preview is missing');
  } else imageOk(PREVIEW, 'image/png');
  if (manifest.thumbnail) {
    if (!files.has(manifest.thumbnail)) add('E_ARCHIVE_MISSING', manifest.thumbnail, 'thumbnail is declared but missing');
    else imageOk(manifest.thumbnail, null);
  }

  let totalPixels = 0;
  for (const [aid, asset] of Object.entries(manifest.assets ?? {})) {
    const data = files.get(asset.path);
    if (!data) {
      add('E_ARCHIVE_MISSING', asset.path, `asset '${aid}' is missing from the archive`);
      continue;
    }
    const size = imageOk(asset.path, asset.media_type);
    if (!size) continue;
    totalPixels += size.width * size.height;
    if ((asset.width !== undefined && asset.width !== size.width) ||
      (asset.height !== undefined && asset.height !== size.height)) {
      add('E_ASSET_DIMENSIONS', `/assets/${aid}`, `declared size does not match the image (${size.width}x${size.height})`);
    }
    if (asset.sha256 !== undefined && asset.sha256 !== await sha256Hex(data)) {
      add('E_ASSET_HASH', `/assets/${aid}/sha256`, 'SHA-256 does not match the file');
    }
    if (asset.sha256 === undefined || asset.width === undefined || asset.height === undefined) {
      add(opts.strict ? 'E_ASSET_INCOMPLETE' : 'W_ASSET_INCOMPLETE', `/assets/${aid}`,
        'asset should declare sha256, width and height');
    }
  }
  if (totalPixels > IMG.max_total_pixels) add('E_LIMIT', '/assets', `assets decode to more than ${IMG.max_total_pixels} pixels`);

  const used = referencedPaths(manifest);
  for (const name of [...files.keys()].sort()) {
    if (!used.has(name)) {
      add(opts.strict ? 'E_UNREFERENCED' : 'W_UNREFERENCED', name, 'file is not referenced by the manifest');
    }
  }
  return issues;
}

/** Read the container with all archive safety checks, without validating the manifest. */
export function loadUnvalidated(data: Uint8Array): AavPackage {
  const files = readZip(data);
  const manifestBytes = files.get(MANIFEST);
  if (!manifestBytes) throw new AavError({ code: 'E_ARCHIVE_MISSING', path: MANIFEST, message: 'manifest.json is missing' });
  files.delete(MANIFEST);
  return { manifest: parseManifest(manifestBytes), files };
}

/** Read and fully validate an .aav file. Throws AavError on any error; returns warnings. */
export async function loadPackage(data: Uint8Array, opts: { strict?: boolean } = {}):
  Promise<{ pkg: AavPackage; warnings: Issue[] }> {
  const pkg = loadUnvalidated(data);
  const issues = await validatePackage(pkg, opts);
  if (errorsOnly(issues).length) throw new AavError(issues);
  return { pkg, warnings: issues };
}

/** Fill in sha256, width and height for every asset from the packaged bytes. */
export async function completeAssets(pkg: AavPackage): Promise<void> {
  for (const [aid, asset] of Object.entries(pkg.manifest.assets ?? {})) {
    const data = pkg.files.get(asset.path);
    if (!data) throw new AavError({ code: 'E_ARCHIVE_MISSING', path: asset.path, message: `asset '${aid}' has no file` });
    const info = sniffImage(data);
    if (!info) throw new AavError({ code: 'E_ASSET_TYPE', path: asset.path, message: 'file is not a PNG, JPEG or WebP image' });
    asset.sha256 = await sha256Hex(data);
    asset.width = info.width;
    asset.height = info.height;
  }
}

/** Validate and serialise deterministically. */
export async function savePackage(pkg: AavPackage, opts: { strict?: boolean } = {}): Promise<Uint8Array> {
  const issues = await validatePackage(pkg, { strict: opts.strict ?? true });
  if (errorsOnly(issues).length) throw new AavError(errorsOnly(issues));
  const files = new Map<string, Uint8Array>([[MANIFEST, canonicalJson(pkg.manifest)]]);
  for (const [name, data] of pkg.files) files.set(name, data);
  return writeZip(files);
}

export const clonePackage = (pkg: AavPackage): AavPackage => ({
  manifest: structuredClone(pkg.manifest),
  files: new Map(pkg.files),
});
