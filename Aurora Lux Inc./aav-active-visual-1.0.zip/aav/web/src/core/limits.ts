import limitsJson from './data/limits.json' with { type: 'json' };
import specsJson from './data/effect-specs.json' with { type: 'json' };
import type { ActionName, EffectType, Trigger } from './types';

export interface PropSpec {
  kind: 'number' | 'colour' | 'enum' | 'boolean';
  min?: number;
  max?: number;
  values?: string[];
  default: number | string | boolean | null;
  unit?: string;
}
export interface EffectSpec {
  stage: 'spatial' | 'colour' | 'alpha' | 'overlay';
  summary: string;
  props: Record<string, PropSpec>;
}

export const LIMITS = limitsJson;
export const FORMAT: string = limitsJson.format;
export const VERSION: string = limitsJson.version;
export const MEDIA_TYPE: string = limitsJson.provisional_media_type;
/** Fixed evaluation order of effect types within a region. */
export const PIPELINE = specsJson.pipeline as EffectType[];
export const EFFECT_TYPES = specsJson.types as unknown as Record<EffectType, EffectSpec>;

export const TRIGGERS: Trigger[] = ['pointer_enter', 'pointer_leave', 'activate', 'focus', 'blur'];
export const ACTIONS: ActionName[] = ['set_effect', 'toggle_layer', 'select_region', 'show_tooltip', 'open_panel',
  'navigate_document', 'open_link', 'play_animation', 'stop_animation', 'reset_view'];
/** Actions that leave the document; only valid in `activate` handlers. */
export const USER_GESTURE_ACTIONS: ActionName[] = ['open_link', 'navigate_document'];

export function isEffectType(value: unknown): value is EffectType {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(EFFECT_TYPES, value);
}

/** Own-property lookup that is safe for keys such as "constructor" or "__proto__". */
export function own<T>(map: Record<string, T> | undefined | null, key: unknown): T | undefined {
  return map != null && typeof key === 'string' && Object.prototype.hasOwnProperty.call(map, key)
    ? map[key] : undefined;
}
