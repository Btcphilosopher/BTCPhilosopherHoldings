/**
 * Reference pixel kernels. Plain typed-array code with no DOM dependency, so
 * the exact arithmetic is unit-testable under Node. The WebGL2 backend in
 * webgl.ts reproduces `colourChain`; everything else always runs here.
 *
 * All arithmetic is on 8-bit, gamma-encoded sRGB values with straight
 * (non-premultiplied) alpha, as delivered by getImageData. See SPEC section 8.
 */
import type { ResolvedEffect } from './state';

export interface PixelBuffer { data: Uint8ClampedArray; width: number; height: number }
export interface Rgb { r: number; g: number; b: number; a: number }

/** Parse #RRGGBB or #RRGGBBAA to 0-1 floats. */
export function parseColour(value: string): Rgb {
  const hex = value.slice(1);
  const n = (i: number) => parseInt(hex.slice(i, i + 2), 16) / 255;
  return { r: n(0), g: n(2), b: n(4), a: hex.length === 8 ? n(6) : 1 };
}

/** Parameters of the per-pixel colour stage, in its fixed order. */
export interface ColourChain {
  brightness: number;
  contrast: number;
  saturation: number;
  tint: { r: number; g: number; b: number; amount: number; mode: 0 | 1 | 2 } | null;
  spotlight: { x: number; y: number; radius: number; falloff: number; intensity: number; ambient: number;
               r: number; g: number; b: number } | null;
  opacity: number;
}

export const IDENTITY_CHAIN: ColourChain = { brightness: 1, contrast: 1, saturation: 1, tint: null, spotlight: null, opacity: 1 };

const num = (v: unknown, fallback: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);

/** Effective pixelation block size: the property rounded to a whole number of pixels, at least 1. */
export const blockSize = (value: unknown): number => Math.max(1, Math.round(num(value, 1)));

/**
 * Build the colour chain from resolved effects. `centre` is the region centre,
 * used when a spotlight has no explicit position; `pointer` replaces it while
 * follow_pointer is on and the region is hovered.
 */
export function buildChain(effects: ResolvedEffect[], centre: { x: number; y: number },
                           pointer: { x: number; y: number } | null): ColourChain {
  const chain: ColourChain = { ...IDENTITY_CHAIN };
  for (const e of effects) {
    const p = e.props;
    if (e.type === 'brightness') chain.brightness = num(p.amount, 1);
    else if (e.type === 'contrast') chain.contrast = num(p.amount, 1);
    else if (e.type === 'saturation') chain.saturation = num(p.amount, 1);
    else if (e.type === 'opacity') chain.opacity = num(p.amount, 1);
    else if (e.type === 'tint') {
      const c = parseColour(String(p.colour));
      const amount = num(p.amount, 0) * c.a;
      if (amount > 0) chain.tint = { r: c.r, g: c.g, b: c.b, amount, mode: p.mode === 'multiply' ? 1 : p.mode === 'screen' ? 2 : 0 };
    } else if (e.type === 'spotlight') {
      const c = parseColour(String(p.colour));
      const intensity = num(p.intensity, 0) * c.a, ambient = num(p.ambient, 1);
      if (intensity > 0 || ambient < 1) {
        const follow = p.follow_pointer === true && pointer !== null;
        chain.spotlight = {
          x: follow ? pointer!.x : num(p.x, centre.x), y: follow ? pointer!.y : num(p.y, centre.y),
          radius: Math.max(1, num(p.radius, 1)), falloff: num(p.falloff, 2), intensity, ambient, r: c.r, g: c.g, b: c.b,
        };
      }
    }
  }
  return chain;
}

export const isIdentityChain = (c: ColourChain): boolean =>
  c.brightness === 1 && c.contrast === 1 && c.saturation === 1 && !c.tint && !c.spotlight && c.opacity === 1;

/**
 * Colour stage, in place. Order: brightness, contrast, saturation, clamp, tint,
 * spotlight, clamp, opacity. (originX, originY) is the document position of
 * the buffer's top-left pixel; light distance is measured from pixel centres.
 */
export function colourChain(img: PixelBuffer, chain: ColourChain, originX: number, originY: number): void {
  const { data, width, height } = img;
  const { brightness, contrast, saturation, tint, spotlight, opacity } = chain;
  const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      if (data[i + 3] === 0) continue;
      let r = data[i] / 255, g = data[i + 1] / 255, b = data[i + 2] / 255;
      r *= brightness; g *= brightness; b *= brightness;
      r = (r - 0.5) * contrast + 0.5; g = (g - 0.5) * contrast + 0.5; b = (b - 0.5) * contrast + 0.5;
      const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      r = clamp01(luma + (r - luma) * saturation);
      g = clamp01(luma + (g - luma) * saturation);
      b = clamp01(luma + (b - luma) * saturation);
      if (tint) {
        const a = tint.amount;
        if (tint.mode === 0) {
          r += (tint.r - r) * a; g += (tint.g - g) * a; b += (tint.b - b) * a;
        } else if (tint.mode === 1) {
          r += (r * tint.r - r) * a; g += (g * tint.g - g) * a; b += (b * tint.b - b) * a;
        } else {
          r += (1 - (1 - r) * (1 - tint.r) - r) * a;
          g += (1 - (1 - g) * (1 - tint.g) - g) * a;
          b += (1 - (1 - b) * (1 - tint.b) - b) * a;
        }
      }
      if (spotlight) {
        const dx = originX + x + 0.5 - spotlight.x, dy = originY + y + 0.5 - spotlight.y;
        const d = Math.sqrt(dx * dx + dy * dy) / spotlight.radius;
        const light = d < 1 ? Math.pow(1 - d, spotlight.falloff) * spotlight.intensity : 0;
        r *= spotlight.ambient + light * spotlight.r;
        g *= spotlight.ambient + light * spotlight.g;
        b *= spotlight.ambient + light * spotlight.b;
      }
      data[i] = Math.round(clamp01(r) * 255);
      data[i + 1] = Math.round(clamp01(g) * 255);
      data[i + 2] = Math.round(clamp01(b) * 255);
      if (opacity !== 1) data[i + 3] = Math.round(data[i + 3] * clamp01(opacity));
    }
  }
}

/**
 * Mosaic, in place. Blocks are `block` document pixels square and aligned to
 * the document origin, so the pattern does not move when the region, the
 * view or the zoom changes. Each block takes the alpha-weighted mean colour
 * and the mean alpha of the pixels of the buffer that fall inside it.
 */
export function pixelate(img: PixelBuffer, block: number, originX: number, originY: number): void {
  if (block <= 1) return;
  const { data, width, height } = img;
  const firstBx = Math.floor(originX / block), firstBy = Math.floor(originY / block);
  for (let by = firstBy; by * block < originY + height; by++) {
    const y0 = Math.max(0, by * block - originY), y1 = Math.min(height, (by + 1) * block - originY);
    for (let bx = firstBx; bx * block < originX + width; bx++) {
      const x0 = Math.max(0, bx * block - originX), x1 = Math.min(width, (bx + 1) * block - originX);
      let r = 0, g = 0, b = 0, a = 0;
      for (let y = y0; y < y1; y++) {
        for (let x = x0, i = (y * width + x0) * 4; x < x1; x++, i += 4) {
          const alpha = data[i + 3];
          r += data[i] * alpha; g += data[i + 1] * alpha; b += data[i + 2] * alpha; a += alpha;
        }
      }
      const count = (x1 - x0) * (y1 - y0);
      if (count <= 0) continue;
      const outR = a ? Math.round(r / a) : 0, outG = a ? Math.round(g / a) : 0, outB = a ? Math.round(b / a) : 0;
      const outA = Math.round(a / count);
      for (let y = y0; y < y1; y++) {
        for (let x = x0, i = (y * width + x0) * 4; x < x1; x++, i += 4) {
          data[i] = outR; data[i + 1] = outG; data[i + 2] = outB; data[i + 3] = outA;
        }
      }
    }
  }
}

/** Box sizes whose three successive passes approximate a Gaussian of the given standard deviation. */
export function boxesForGauss(sigma: number): number[] {
  const ideal = Math.sqrt((12 * sigma * sigma) / 3 + 1);
  let lower = Math.floor(ideal);
  if (lower % 2 === 0) lower--;
  const upper = lower + 2;
  const m = Math.round((12 * sigma * sigma - 3 * lower * lower - 12 * lower - 9) / (-4 * lower - 4));
  return [0, 1, 2].map((i) => (i < m ? lower : upper));
}

function boxPass(src: Float32Array, dst: Float32Array, width: number, height: number, channels: number,
                 radius: number, horizontal: boolean): void {
  const lines = horizontal ? height : width, length = horizontal ? width : height;
  const stride = (horizontal ? 1 : width) * channels, lineStride = (horizontal ? width : 1) * channels;
  const window = 2 * radius + 1;
  for (let line = 0; line < lines; line++) {
    const base = line * lineStride;
    for (let c = 0; c < channels; c++) {
      let sum = 0;
      // Edges are extended (clamped), so blur does not darken at the borders of the surface.
      for (let k = -radius; k <= radius; k++) sum += src[base + Math.min(length - 1, Math.max(0, k)) * stride + c];
      for (let i = 0; i < length; i++) {
        dst[base + i * stride + c] = sum / window;
        const add = Math.min(length - 1, i + radius + 1), drop = Math.max(0, i - radius);
        sum += src[base + add * stride + c] - src[base + drop * stride + c];
      }
    }
  }
}

function gaussian(values: Float32Array, width: number, height: number, channels: number, sigma: number): Float32Array {
  let a = values, b = new Float32Array(values.length);
  for (const box of boxesForGauss(sigma)) {
    const radius = (box - 1) / 2;
    if (radius < 1) continue;
    boxPass(a, b, width, height, channels, radius, true);
    boxPass(b, a, width, height, channels, radius, false);
  }
  return a;
}

/** Standard deviation used for a `radius` in pixels: sigma = radius / 2 (the Canvas shadowBlur convention). */
export const sigmaFor = (radius: number): number => radius / 2;

/** How far a blur of `radius` reaches, in whole pixels; used to pad the area read from the surface. */
export const blurReach = (radius: number): number => (radius > 0 ? Math.ceil(radius * 1.5) + 2 : 0);

/** Gaussian-approximating blur, in place, computed on premultiplied values so transparent pixels do not bleed colour. */
export function blur(img: PixelBuffer, radius: number): void {
  if (radius <= 0) return;
  const { data, width, height } = img;
  const work = new Float32Array(data.length);
  for (let i = 0; i < data.length; i += 4) {
    const a = data[i + 3] / 255;
    work[i] = data[i] * a; work[i + 1] = data[i + 1] * a; work[i + 2] = data[i + 2] * a; work[i + 3] = data[i + 3];
  }
  const out = gaussian(work, width, height, 4, sigmaFor(radius));
  for (let i = 0; i < data.length; i += 4) {
    const a = out[i + 3];
    if (a <= 0.5) {
      data[i] = data[i + 1] = data[i + 2] = data[i + 3] = 0;
      continue;
    }
    const k = 255 / a;
    data[i] = Math.round(out[i] * k); data[i + 1] = Math.round(out[i + 1] * k); data[i + 2] = Math.round(out[i + 2] * k);
    data[i + 3] = Math.round(a);
  }
}

/** Blur a single-channel coverage map (0-255). Returns a new array. */
export function blurAlpha(alpha: Uint8ClampedArray | Uint8Array, width: number, height: number, radius: number): Float32Array {
  const work = Float32Array.from(alpha);
  return radius > 0 ? gaussian(work, width, height, 1, sigmaFor(radius)) : work;
}

/**
 * Outline band for mask regions: the pixels within roughly `width` outside the
 * mask edge. Approximate by construction (thresholded blur of the coverage).
 */
export function maskOutline(alpha: Uint8ClampedArray | Uint8Array, width: number, height: number, lineWidth: number): Uint8ClampedArray {
  const binary = new Uint8ClampedArray(alpha.length);
  for (let i = 0; i < alpha.length; i++) binary[i] = alpha[i] >= 128 ? 255 : 0;
  const spread = blurAlpha(binary, width, height, Math.max(1, lineWidth));
  const out = new Uint8ClampedArray(alpha.length);
  for (let i = 0; i < alpha.length; i++) out[i] = binary[i] === 0 && spread[i] > 16 ? 255 : 0;
  return out;
}
