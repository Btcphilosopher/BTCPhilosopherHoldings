/**
 * Manifest validation. A line-for-line port of python/src/aav/manifest.py:
 * same rules, same issue codes. conformance/manifests.json is run against both.
 */
import { documentHrefProblem, externalUrlProblem } from './links';
import { ACTIONS, EFFECT_TYPES, FORMAT, LIMITS, TRIGGERS, USER_GESTURE_ACTIONS, isEffectType, own } from './limits';
import type { PropSpec } from './limits';
import { textLinks } from './text';
import type { EffectDef, Issue, Shape } from './types';

const M = LIMITS.manifest;
const R = LIMITS.runtime;
const IMG = LIMITS.image;
const COORD = M.coordinate_limit;
const ID = new RegExp(M.id_pattern);
const COLOUR = new RegExp(M.colour_pattern);
const ASSET_PATH = new RegExp(M.asset_path_pattern);
const THUMB_PATH = new RegExp(M.thumbnail_path_pattern);
const LANG = /^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8})*$/;
const SHA = /^[0-9a-f]{64}$/;
const VERSION_RE = /^(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})$/;
export const MASK_MEDIA_TYPES = ['image/png', 'image/webp'];

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);
const has = (o: Obj, key: string): boolean => Object.prototype.hasOwnProperty.call(o, key);
const isNum = (v: unknown): v is number => typeof v === 'number';
/** Value of an own key, or `fallback` when the key is absent. An explicit null is returned as null. */
const opt = (o: Obj, key: string, fallback: unknown): unknown => (has(o, key) ? o[key] : fallback);

class Checker {
  issues: Issue[] = [];
  lenient = false;

  add(code: string, path: string, message: string): void {
    this.issues.push({ code, path, message });
  }
  unknown(path: string, message: string): void {
    this.add(this.lenient ? 'W_UNKNOWN' : 'E_UNKNOWN_PROPERTY', path, message);
  }
  obj(value: unknown, path: string, allowed: readonly string[], required: readonly string[] = []): value is Obj {
    if (!isObj(value)) {
      this.add('E_TYPE', path, 'expected an object');
      return false;
    }
    for (const key of Object.keys(value)) {
      if (!allowed.includes(key) && !key.startsWith('x-')) this.unknown(`${path}/${key}`, `unknown property '${key}'`);
    }
    for (const key of required) {
      if (!has(value, key)) this.add('E_REQUIRED', `${path}/${key}`, `missing required property '${key}'`);
    }
    return true;
  }
  string(value: unknown, path: string, maxLen: number, minLen = 0, pattern?: RegExp): value is string {
    if (typeof value !== 'string') {
      this.add('E_TYPE', path, 'expected a string');
      return false;
    }
    const length = [...value].length;
    if (length > maxLen || length < minLen) {
      this.add('E_RANGE', path, `length must be between ${minLen} and ${maxLen} characters`);
      return false;
    }
    if (pattern && !pattern.test(value)) {
      this.add('E_PATTERN', path, 'value has an invalid format');
      return false;
    }
    return true;
  }
  number(value: unknown, path: string, lo: number, hi: number,
         opts: { integer?: boolean; exclusiveMin?: boolean } = {}): value is number {
    if (!isNum(value)) {
      this.add('E_TYPE', path, 'expected a number');
      return false;
    }
    if (!Number.isFinite(value)) {
      this.add('E_NONFINITE', path, 'number must be finite');
      return false;
    }
    if (opts.integer && !Number.isInteger(value)) {
      this.add('E_TYPE', path, 'expected an integer');
      return false;
    }
    if (value > hi || value < lo || (opts.exclusiveMin && value <= lo)) {
      const bound = opts.exclusiveMin ? `greater than ${lo}` : `at least ${lo}`;
      this.add('E_RANGE', path, `must be ${bound} and at most ${hi}`);
      return false;
    }
    return true;
  }
  boolean(value: unknown, path: string): value is boolean {
    if (typeof value !== 'boolean') {
      this.add('E_TYPE', path, 'expected true or false');
      return false;
    }
    return true;
  }
  enum(value: unknown, path: string, values: readonly unknown[]): boolean {
    if (typeof value === 'boolean' || !values.includes(value)) {
      this.add('E_ENUM', path, 'must be one of: ' + values.join(', '));
      return false;
    }
    return true;
  }
  ident(value: unknown, path: string): value is string {
    if (typeof value !== 'string') {
      this.add('E_TYPE', path, 'expected an identifier string');
      return false;
    }
    if (!ID.test(value)) {
      this.add('E_PATTERN', path,
        'identifiers use 1-64 characters from A-Z a-z 0-9 . _ - and start with a letter or digit');
      return false;
    }
    return true;
  }
  colour(value: unknown, path: string): value is string {
    if (typeof value !== 'string') {
      this.add('E_TYPE', path, 'expected a colour string');
      return false;
    }
    if (!COLOUR.test(value)) {
      this.add('E_PATTERN', path, 'colours are written #RRGGBB or #RRGGBBAA');
      return false;
    }
    return true;
  }
  coord(value: unknown, path: string): value is number {
    return this.number(value, path, -COORD, COORD);
  }
  size(value: unknown, path: string): value is number {
    return this.number(value, path, 0, COORD, { exclusiveMin: true });
  }
  idMap(value: unknown, path: string, maxProps: number): Obj {
    if (!isObj(value)) {
      this.add('E_TYPE', path, 'expected an object keyed by identifier');
      return {};
    }
    const keys = Object.keys(value);
    if (keys.length > maxProps) this.add('E_LIMIT', path, `at most ${maxProps} entries are allowed`);
    for (const key of keys) this.ident(key, `${path}/${key}`);
    return value;
  }
  array(value: unknown, path: string, maxItems: number, minItems = 0): unknown[] {
    if (!Array.isArray(value)) {
      this.add('E_TYPE', path, 'expected an array');
      return [];
    }
    if (value.length > maxItems) {
      this.add('E_LIMIT', path, `at most ${maxItems} items are allowed`);
      return [];
    }
    if (value.length < minItems) this.add('E_RANGE', path, `at least ${minItems} item(s) are required`);
    return value;
  }
}

function checkPropValue(c: Checker, spec: PropSpec, value: unknown, path: string): boolean {
  if (spec.kind === 'number') return c.number(value, path, spec.min!, spec.max!);
  if (spec.kind === 'colour') return c.colour(value, path);
  if (spec.kind === 'enum') return c.enum(value, path, spec.values!);
  return c.boolean(value, path);
}

/** Problem with a single effect property value, or null. Used by the editor for live feedback. */
export function propValueProblem(spec: PropSpec, value: unknown): string | null {
  const c = new Checker();
  checkPropValue(c, spec, value, '');
  return c.issues.length ? c.issues[0].message : null;
}

export function polygonArea(points: [number, number][]): number {
  let total = 0;
  for (let i = 0; i < points.length; i++) {
    const [x1, y1] = points[i];
    const [x2, y2] = points[(i + 1) % points.length];
    total += x1 * y2 - x2 * y1;
  }
  return total / 2;
}

/** Bounding box in document pixels. Assumes a valid shape. */
export function shapeBounds(shape: Shape, docW: number, docH: number):
  { x: number; y: number; width: number; height: number } {
  if (shape.type === 'polygon') {
    const xs = shape.points.map((p) => p[0]);
    const ys = shape.points.map((p) => p[1]);
    const x = Math.min(...xs), y = Math.min(...ys);
    return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y };
  }
  if (shape.type === 'mask') {
    return { x: shape.x ?? 0, y: shape.y ?? 0, width: shape.width ?? docW, height: shape.height ?? docH };
  }
  return { x: shape.x, y: shape.y, width: shape.width, height: shape.height };
}

interface Refs {
  layers: Set<string>;
  regions: Map<string, Obj>;
  groups: Obj;
  panels: Obj;
  animations: Obj;
  assets: Obj;
}

/** The effect definition if it exists and has a known type. */
function refEffect(refs: Refs, regionId: string, effectId: unknown): EffectDef | null {
  const region = refs.regions.get(regionId);
  const effects = region && isObj(region.effects) ? region.effects : null;
  const effect = effects ? own(effects, effectId) : undefined;
  return isObj(effect) && isEffectType(effect.type) ? (effect as unknown as EffectDef) : null;
}

/** Validate a parsed manifest. Returns every issue found (errors and warnings). */
export function validateManifest(manifest: unknown): Issue[] {
  const c = new Checker();
  if (!isObj(manifest)) {
    c.add('E_TYPE', '', 'manifest must be a JSON object');
    return c.issues;
  }
  if (manifest.format !== FORMAT) {
    c.add('E_FORMAT', '/format', `format must be '${FORMAT}'`);
    return c.issues;
  }
  const version = manifest.version;
  const match = typeof version === 'string' ? VERSION_RE.exec(version) : null;
  if (!match) {
    c.add('E_VERSION', '/version', "version must be a 'MAJOR.MINOR' string");
    return c.issues;
  }
  const major = Number(match[1]), minor = Number(match[2]);
  if (major !== LIMITS.supported_major) {
    const hint = major < LIMITS.supported_major ? " (use 'aav migrate' for pre-release drafts)" : '';
    c.add('E_VERSION', '/version',
      `unsupported schema version ${version}; this implementation reads ${LIMITS.supported_major}.x${hint}`);
    return c.issues;
  }
  if (minor > LIMITS.supported_minor) {
    c.lenient = true;
    c.add('W_NEWER_MINOR', '/version', `document uses schema ${version}; features newer than ` +
      `${LIMITS.supported_major}.${LIMITS.supported_minor} are ignored`);
  }

  c.obj(manifest, '', ['format', 'version', 'document', 'metadata', 'settings', 'assets', 'layers', 'regions',
    'groups', 'panels', 'animations', 'events', 'default_state', 'preview', 'thumbnail', 'redaction'],
  ['document', 'layers', 'preview']);

  const [docW, docH] = checkDocument(c, manifest.document);
  checkMetadata(c, manifest);
  const assets = checkAssets(c, opt(manifest, 'assets', {}));
  const layerIds = checkLayers(c, opt(manifest, 'layers', []), assets);

  const regions = c.array(opt(manifest, 'regions', []), '/regions', M.max_regions);
  const regionMap = new Map<string, Obj>();
  regions.forEach((region, i) => {
    if (isObj(region) && typeof region.id === 'string') {
      if (regionMap.has(region.id)) c.add('E_DUPLICATE_ID', `/regions/${i}/id`, `duplicate region id '${region.id}'`);
      else regionMap.set(region.id, region);
    }
  });

  const groups = c.idMap(opt(manifest, 'groups', {}), '/groups', M.max_groups);
  const panels = c.idMap(opt(manifest, 'panels', {}), '/panels', M.max_panels);
  const animations = c.idMap(opt(manifest, 'animations', {}), '/animations', M.max_animations);
  const refs: Refs = { layers: layerIds, regions: regionMap, groups, panels, animations, assets };

  regions.forEach((region, i) => checkRegion(c, region, `/regions/${i}`, refs, docW, docH));

  for (const [gid, group] of Object.entries(groups)) {
    const path = `/groups/${gid}`;
    if (!c.obj(group, path, ['label', 'description', 'regions'], ['label', 'regions'])) continue;
    if (has(group, 'label')) c.string(group.label, `${path}/label`, M.max_label, 1);
    if (has(group, 'description')) c.string(group.description, `${path}/description`, M.max_description);
    const members = c.array(opt(group, 'regions', []), `${path}/regions`, M.max_regions, 1);
    const seen = new Set<string>();
    members.forEach((rid, j) => {
      if (!c.ident(rid, `${path}/regions/${j}`)) return;
      if (seen.has(rid)) c.add('E_DUPLICATE_ID', `${path}/regions/${j}`, `region '${rid}' is listed twice`);
      seen.add(rid);
      if (!regionMap.has(rid)) c.add('E_REF', `${path}/regions/${j}`, `unknown region '${rid}'`);
    });
  }

  for (const [pid, panel] of Object.entries(panels)) {
    const path = `/panels/${pid}`;
    if (!c.obj(panel, path, ['title', 'text'], ['title', 'text'])) continue;
    if (has(panel, 'title')) c.string(panel.title, `${path}/title`, M.max_title, 1);
    if (has(panel, 'text') && c.string(panel.text, `${path}/text`, M.max_panel_text)) {
      checkTextLinks(c, panel.text, `${path}/text`, refs);
    }
  }

  for (const [aid, anim] of Object.entries(animations)) checkAnimation(c, anim, `/animations/${aid}`, refs);

  const events = manifest.events;
  if (has(manifest, 'events') && c.obj(events, '/events', ['document_load'])) {
    checkActions(c, opt(events, 'document_load', []), '/events/document_load', 'document_load', null, refs);
  }

  if (has(manifest, 'default_state')) checkDefaultState(c, manifest.default_state, refs);

  if (has(manifest, 'preview') && manifest.preview !== 'preview.png') {
    c.add('E_ENUM', '/preview', "preview must be 'preview.png'");
  }
  if (has(manifest, 'thumbnail')) c.string(manifest.thumbnail, '/thumbnail', 200, 1, THUMB_PATH);

  const redaction = manifest.redaction;
  if (has(manifest, 'redaction') && c.obj(redaction, '/redaction', ['method', 'colour', 'regions', 'tool'],
    ['method', 'regions'])) {
    if (has(redaction, 'method')) c.enum(redaction.method, '/redaction/method', ['fill']);
    if (has(redaction, 'colour')) c.colour(redaction.colour, '/redaction/colour');
    if (has(redaction, 'tool')) c.string(redaction.tool, '/redaction/tool', 200);
    c.array(opt(redaction, 'regions', []), '/redaction/regions', M.max_regions).forEach((rid, j) => {
      if (c.ident(rid, `/redaction/regions/${j}`) && !regionMap.has(rid)) {
        c.add('E_REF', `/redaction/regions/${j}`, `unknown region '${rid}'`);
      }
    });
  }
  return c.issues;
}

function checkDocument(c: Checker, doc: unknown): [number, number] {
  if (!c.obj(doc, '/document', ['id', 'title', 'width', 'height', 'description', 'language', 'colour_space',
    'background'], ['id', 'title', 'width', 'height'])) return [Infinity, Infinity];
  if (has(doc, 'id')) c.ident(doc.id, '/document/id');
  if (has(doc, 'title')) c.string(doc.title, '/document/title', M.max_title, 1);
  const okW = has(doc, 'width') && c.number(doc.width, '/document/width', 1, M.max_dimension, { integer: true });
  const okH = has(doc, 'height') && c.number(doc.height, '/document/height', 1, M.max_dimension, { integer: true });
  if (okW && okH && (doc.width as number) * (doc.height as number) > M.max_document_pixels) {
    c.add('E_LIMIT', '/document', `document area exceeds ${M.max_document_pixels} pixels`);
  }
  if (has(doc, 'description')) c.string(doc.description, '/document/description', M.max_description);
  if (has(doc, 'language')) c.string(doc.language, '/document/language', 64, 2, LANG);
  if (has(doc, 'colour_space') && doc.colour_space !== 'srgb') {
    c.add('E_ENUM', '/document/colour_space', "only 'srgb' is defined in schema 1.0");
  }
  if (has(doc, 'background')) c.colour(doc.background, '/document/background');
  // With an invalid canvas size the "outside the document" warning is meaningless, so it is suppressed.
  return [okW ? (doc.width as number) : Infinity, okH ? (doc.height as number) : Infinity];
}

function checkMetadata(c: Checker, manifest: Obj): void {
  const meta = manifest.metadata;
  if (has(manifest, 'metadata') && c.obj(meta, '/metadata', ['author', 'licence', 'created', 'generator', 'source'])) {
    const limits: [string, number][] = [['author', 500], ['licence', 500], ['created', 64], ['generator', 200],
      ['source', 500]];
    for (const [key, limit] of limits) if (has(meta, key)) c.string(meta[key], `/metadata/${key}`, limit);
  }
  const settings = manifest.settings;
  if (has(manifest, 'settings') && c.obj(settings, '/settings', ['selection', 'default_highlight', 'pan_zoom',
    'image_rendering'])) {
    if (has(settings, 'selection')) c.enum(settings.selection, '/settings/selection', ['single', 'multiple', 'none']);
    if (has(settings, 'default_highlight')) c.boolean(settings.default_highlight, '/settings/default_highlight');
    if (has(settings, 'pan_zoom')) c.boolean(settings.pan_zoom, '/settings/pan_zoom');
    if (has(settings, 'image_rendering')) {
      c.enum(settings.image_rendering, '/settings/image_rendering', ['smooth', 'pixelated']);
    }
  }
}

function checkAssets(c: Checker, assetsRaw: unknown): Obj {
  const assets = c.idMap(assetsRaw, '/assets', M.max_assets);
  const paths = new Map<string, string>();
  for (const [aid, asset] of Object.entries(assets)) {
    const path = `/assets/${aid}`;
    if (!c.obj(asset, path, ['path', 'media_type', 'sha256', 'width', 'height'], ['path', 'media_type'])) continue;
    if (has(asset, 'path') && c.string(asset.path, `${path}/path`, 200, 1, ASSET_PATH)) {
      const key = asset.path.toLowerCase();
      if (paths.has(key)) c.add('E_DUPLICATE_PATH', `${path}/path`, `path is already used by asset '${paths.get(key)}'`);
      paths.set(key, aid);
    }
    if (has(asset, 'media_type')) c.enum(asset.media_type, `${path}/media_type`, IMG.media_types);
    if (has(asset, 'sha256')) c.string(asset.sha256, `${path}/sha256`, 64, 64, SHA);
    for (const key of ['width', 'height']) {
      if (has(asset, key)) c.number(asset[key], `${path}/${key}`, 1, IMG.max_dimension, { integer: true });
    }
  }
  return assets;
}

function checkLayers(c: Checker, layersRaw: unknown, assets: Obj): Set<string> {
  const ids = new Set<string>();
  c.array(layersRaw, '/layers', M.max_layers, 1).forEach((layer, i) => {
    const path = `/layers/${i}`;
    if (!isObj(layer)) {
      c.add('E_TYPE', path, 'expected an object');
      return;
    }
    const kind = layer.type;
    const common = ['id', 'type', 'name', 'visible', 'opacity', 'transform', 'clip'];
    if (kind === 'image') {
      c.obj(layer, path, [...common, 'asset', 'x', 'y', 'width', 'height'], ['id', 'type', 'asset']);
      if (has(layer, 'asset') && c.ident(layer.asset, `${path}/asset`) && own(assets, layer.asset) === undefined) {
        c.add('E_REF', `${path}/asset`, `unknown asset '${layer.asset}'`);
      }
    } else if (kind === 'text') {
      c.obj(layer, path, [...common, 'text', 'x', 'y', 'font_size', 'font_family', 'font_weight', 'colour', 'align',
        'background', 'padding', 'max_width', 'line_height'], ['id', 'type', 'text', 'x', 'y']);
      if (has(layer, 'text')) c.string(layer.text, `${path}/text`, M.max_layer_text, 1);
      if (has(layer, 'font_size')) c.number(layer.font_size, `${path}/font_size`, 4, 512);
      if (has(layer, 'font_family')) {
        c.enum(layer.font_family, `${path}/font_family`, ['sans-serif', 'serif', 'monospace']);
      }
      if (has(layer, 'font_weight')) c.enum(layer.font_weight, `${path}/font_weight`, [400, 700]);
      if (has(layer, 'align')) c.enum(layer.align, `${path}/align`, ['left', 'centre', 'right']);
      for (const key of ['colour', 'background']) if (has(layer, key)) c.colour(layer[key], `${path}/${key}`);
      if (has(layer, 'padding')) c.number(layer.padding, `${path}/padding`, 0, 64);
      if (has(layer, 'max_width')) c.size(layer.max_width, `${path}/max_width`);
      if (has(layer, 'line_height')) c.number(layer.line_height, `${path}/line_height`, 0.8, 3);
    } else {
      if (c.lenient && typeof kind === 'string') {
        c.add('W_UNKNOWN', `${path}/type`, `unknown layer type '${kind}' is ignored`);
      } else c.add('E_ENUM', `${path}/type`, "layer type must be 'image' or 'text'");
      return;
    }
    if (has(layer, 'id') && c.ident(layer.id, `${path}/id`)) {
      if (ids.has(layer.id)) c.add('E_DUPLICATE_ID', `${path}/id`, `duplicate layer id '${layer.id}'`);
      ids.add(layer.id);
    }
    if (has(layer, 'name')) c.string(layer.name, `${path}/name`, M.max_label);
    if (has(layer, 'visible')) c.boolean(layer.visible, `${path}/visible`);
    if (has(layer, 'opacity')) c.number(layer.opacity, `${path}/opacity`, 0, 1);
    for (const key of ['x', 'y']) if (has(layer, key)) c.coord(layer[key], `${path}/${key}`);
    if (kind === 'image') {
      for (const key of ['width', 'height']) if (has(layer, key)) c.size(layer[key], `${path}/${key}`);
    }
    const transform = layer.transform;
    if (has(layer, 'transform') && c.obj(transform, `${path}/transform`, ['translate_x', 'translate_y', 'scale_x',
      'scale_y', 'rotation', 'origin_x', 'origin_y'])) {
      for (const key of ['translate_x', 'translate_y', 'origin_x', 'origin_y']) {
        if (has(transform, key)) c.coord(transform[key], `${path}/transform/${key}`);
      }
      for (const key of ['scale_x', 'scale_y']) {
        if (has(transform, key) && c.number(transform[key], `${path}/transform/${key}`, -100, 100)
          && transform[key] === 0) {
          c.add('E_GEOMETRY', `${path}/transform/${key}`, 'scale must not be zero');
        }
      }
      if (has(transform, 'rotation')) c.number(transform.rotation, `${path}/transform/rotation`, -360, 360);
    }
    const clip = layer.clip;
    if (has(layer, 'clip') && c.obj(clip, `${path}/clip`, ['x', 'y', 'width', 'height'],
      ['x', 'y', 'width', 'height'])) {
      for (const key of ['x', 'y']) if (has(clip, key)) c.coord(clip[key], `${path}/clip/${key}`);
      for (const key of ['width', 'height']) if (has(clip, key)) c.size(clip[key], `${path}/clip/${key}`);
    }
  });
  return ids;
}

function checkShape(c: Checker, shape: unknown, path: string, refs: Refs): boolean {
  if (!isObj(shape)) {
    c.add('E_TYPE', path, 'expected an object');
    return false;
  }
  const before = c.issues.length;
  const kind = shape.type;
  if (kind === 'rect') {
    c.obj(shape, path, ['type', 'x', 'y', 'width', 'height'], ['type', 'x', 'y', 'width', 'height']);
    for (const key of ['x', 'y']) if (has(shape, key)) c.coord(shape[key], `${path}/${key}`);
    for (const key of ['width', 'height']) {
      const v = shape[key];
      if (has(shape, key) && isNum(v) && Number.isFinite(v) && v <= 0) {
        c.add('E_GEOMETRY', `${path}/${key}`, 'rectangle width and height must be greater than zero');
      } else if (has(shape, key)) c.size(v, `${path}/${key}`);
    }
  } else if (kind === 'polygon') {
    c.obj(shape, path, ['type', 'points'], ['type', 'points']);
    const points = shape.points;
    if (!Array.isArray(points)) {
      if (has(shape, 'points')) c.add('E_TYPE', `${path}/points`, 'expected an array of [x, y] pairs');
    } else if (points.length > M.max_polygon_points) {
      c.add('E_LIMIT', `${path}/points`, `at most ${M.max_polygon_points} points are allowed`);
    } else if (points.length < 3) {
      c.add('E_GEOMETRY', `${path}/points`, 'a polygon needs at least three points');
    } else {
      let good = true;
      points.forEach((point, j) => {
        if (!Array.isArray(point) || point.length !== 2) {
          c.add('E_TYPE', `${path}/points/${j}`, 'expected an [x, y] pair');
          good = false;
        } else {
          good = c.coord(point[0], `${path}/points/${j}/0`) && good;
          good = c.coord(point[1], `${path}/points/${j}/1`) && good;
        }
      });
      if (good && Math.abs(polygonArea(points as [number, number][])) < 1e-6) {
        c.add('E_GEOMETRY', `${path}/points`, 'polygon has no area');
      }
    }
  } else if (kind === 'mask') {
    c.obj(shape, path, ['type', 'asset', 'x', 'y', 'width', 'height', 'threshold', 'hit_test'], ['type', 'asset']);
    if (has(shape, 'asset') && c.ident(shape.asset, `${path}/asset`)) {
      const asset = own(refs.assets, shape.asset);
      if (asset === undefined) c.add('E_REF', `${path}/asset`, `unknown asset '${shape.asset}'`);
      else if (isObj(asset) && !MASK_MEDIA_TYPES.includes(asset.media_type as string)) {
        c.add('E_ASSET_TYPE', `${path}/asset`, 'mask assets must be PNG or WebP (an alpha channel is needed)');
      }
    }
    for (const key of ['x', 'y']) if (has(shape, key)) c.coord(shape[key], `${path}/${key}`);
    for (const key of ['width', 'height']) if (has(shape, key)) c.size(shape[key], `${path}/${key}`);
    if (has(shape, 'threshold')) c.number(shape.threshold, `${path}/threshold`, 0, 1, { exclusiveMin: true });
    if (has(shape, 'hit_test')) c.enum(shape.hit_test, `${path}/hit_test`, ['alpha', 'bounds']);
  } else {
    c.add('E_ENUM', `${path}/type`, "shape type must be 'rect', 'polygon' or 'mask'");
  }
  return c.issues.length === before;
}

function checkRegion(c: Checker, region: unknown, path: string, refs: Refs, docW: number, docH: number): void {
  if (!c.obj(region, path, ['id', 'label', 'description', 'shape', 'target_layer', 'z_index', 'interactive',
    'selectable', 'tooltip', 'effects', 'states', 'events'], ['id', 'label', 'shape'])) return;
  const rid = region.id;
  if (has(region, 'id')) c.ident(rid, `${path}/id`);
  if (has(region, 'label')) c.string(region.label, `${path}/label`, M.max_label, 1);
  if (has(region, 'description')) c.string(region.description, `${path}/description`, M.max_description);
  if (has(region, 'tooltip')) c.string(region.tooltip, `${path}/tooltip`, M.max_tooltip);
  if (has(region, 'shape') && checkShape(c, region.shape, `${path}/shape`, refs)) {
    const b = shapeBounds(region.shape as Shape, docW, docH);
    if (b.x >= docW || b.y >= docH || b.x + b.width <= 0 || b.y + b.height <= 0) {
      c.add('W_OUTSIDE', `${path}/shape`, 'region lies entirely outside the document');
    }
  }
  if (has(region, 'target_layer') && c.ident(region.target_layer, `${path}/target_layer`)
    && !refs.layers.has(region.target_layer)) {
    c.add('E_REF', `${path}/target_layer`, `unknown layer '${region.target_layer}'`);
  }
  if (has(region, 'z_index')) c.number(region.z_index, `${path}/z_index`, -1000, 1000, { integer: true });
  for (const key of ['interactive', 'selectable']) if (has(region, key)) c.boolean(region[key], `${path}/${key}`);

  const effects = c.idMap(opt(region, 'effects', {}), `${path}/effects`, Object.keys(EFFECT_TYPES).length);
  const seenTypes = new Map<string, string>();
  for (const [eid, effect] of Object.entries(effects)) {
    const epath = `${path}/effects/${eid}`;
    if (!isObj(effect)) {
      c.add('E_TYPE', epath, 'expected an object');
      continue;
    }
    const kind = effect.type;
    if (!isEffectType(kind)) {
      if (c.lenient && typeof kind === 'string') {
        c.add('W_UNKNOWN', `${epath}/type`, `unknown effect type '${kind}' is ignored`);
      } else {
        c.add('E_ENUM', `${epath}/type`, 'unknown effect type; expected one of: ' +
          Object.keys(EFFECT_TYPES).join(', '));
      }
      continue;
    }
    if (seenTypes.has(kind)) {
      c.add('E_EFFECT_DUPLICATE', epath, `region already has a '${kind}' effect ('${seenTypes.get(kind)}'); ` +
        'at most one effect of each type is allowed per region');
    }
    seenTypes.set(kind, eid);
    const props = EFFECT_TYPES[kind].props;
    for (const [key, value] of Object.entries(effect)) {
      if (key === 'type' || key.startsWith('x-')) continue;
      const spec = own(props, key);
      if (!spec) c.unknown(`${epath}/${key}`, `'${kind}' has no property '${key}'`);
      else checkPropValue(c, spec, value, `${epath}/${key}`);
    }
  }

  const states = region.states;
  if (has(region, 'states') && c.obj(states, `${path}/states`, ['hover', 'selected', 'focus'])) {
    for (const state of ['hover', 'selected', 'focus']) {
      if (!has(states, state)) continue;
      const overrides = states[state];
      const spath = `${path}/states/${state}`;
      if (!isObj(overrides)) {
        c.add('E_TYPE', spath, 'expected an object keyed by effect id');
        continue;
      }
      for (const [eid, values] of Object.entries(overrides)) {
        const effect = typeof rid === 'string' ? refEffect(refs, rid, eid) : null;
        if (!effect) {
          c.add('E_REF', `${spath}/${eid}`, `region has no effect '${eid}'`);
          continue;
        }
        if (!isObj(values)) {
          c.add('E_TYPE', `${spath}/${eid}`, 'expected an object of property overrides');
          continue;
        }
        const props = EFFECT_TYPES[effect.type].props;
        for (const [key, value] of Object.entries(values)) {
          const spec = own(props, key);
          if (!spec) c.add('E_EFFECT_PROPERTY', `${spath}/${eid}/${key}`, `'${effect.type}' has no property '${key}'`);
          else checkPropValue(c, spec, value, `${spath}/${eid}/${key}`);
        }
      }
    }
  }

  const events = region.events;
  if (has(region, 'events') && c.obj(events, `${path}/events`, TRIGGERS)) {
    for (const trigger of TRIGGERS) {
      if (has(events, trigger)) {
        checkActions(c, events[trigger], `${path}/events/${trigger}`, trigger, typeof rid === 'string' ? rid : null,
          refs);
      }
    }
  }
}

/** Resolve region/group/self targeting. Returns region ids, or null if invalid. */
function effectTargets(c: Checker, action: Obj, path: string, selfRegion: string | null, refs: Refs): string[] | null {
  const hasRegion = has(action, 'region'), hasGroup = has(action, 'group');
  if (hasRegion && hasGroup) {
    c.add('E_TARGET', path, "give either 'region' or 'group', not both");
    return null;
  }
  if (hasRegion) {
    if (!c.ident(action.region, `${path}/region`)) return null;
    if (!refs.regions.has(action.region)) {
      c.add('E_REF', `${path}/region`, `unknown region '${action.region}'`);
      return null;
    }
    return [action.region];
  }
  if (hasGroup) {
    if (!c.ident(action.group, `${path}/group`)) return null;
    const group = own(refs.groups, action.group);
    if (group === undefined) {
      c.add('E_REF', `${path}/group`, `unknown group '${action.group}'`);
      return null;
    }
    const members = isObj(group) ? group.regions : null;
    return Array.isArray(members)
      ? members.filter((m): m is string => typeof m === 'string' && refs.regions.has(m)) : [];
  }
  if (selfRegion === null) {
    c.add('E_TARGET', path, "this action needs an explicit 'region' or 'group' outside a region handler");
    return null;
  }
  return [selfRegion];
}

function checkActions(c: Checker, actions: unknown, path: string, trigger: string, selfRegion: string | null,
                      refs: Refs): void {
  c.array(actions, path, M.max_actions_per_handler).forEach((action, i) => {
    const apath = `${path}/${i}`;
    if (!isObj(action)) {
      c.add('E_TYPE', apath, 'expected an object');
      return;
    }
    const name = action.action;
    if (typeof name !== 'string' || !(ACTIONS as string[]).includes(name)) {
      if (c.lenient && typeof name === 'string') {
        c.add('W_UNKNOWN', `${apath}/action`, `unknown action '${name}' is ignored`);
      } else c.add('E_ENUM', `${apath}/action`, 'unknown action; expected one of: ' + ACTIONS.join(', '));
      return;
    }
    if ((USER_GESTURE_ACTIONS as string[]).includes(name) && trigger !== 'activate') {
      c.add('E_TRIGGER', apath, `'${name}' may only run from an 'activate' handler, never from '${trigger}'`);
    }
    if (name === 'set_effect') {
      c.obj(action, apath, ['action', 'effect', 'property', 'value', 'region', 'group', 'duration_ms', 'easing'],
        ['effect', 'property', 'value']);
      if (has(action, 'easing')) c.enum(action.easing, `${apath}/easing`, ['linear', 'ease-in-out']);
      const durationOk = !has(action, 'duration_ms') ||
        c.number(action.duration_ms, `${apath}/duration_ms`, 0, R.max_transition_ms);
      const targets = effectTargets(c, action, apath, selfRegion, refs);
      if (targets === null || !['effect', 'property', 'value'].every((k) => has(action, k))) return;
      if (!c.ident(action.effect, `${apath}/effect`)) return;
      const matched = targets.map((t) => refEffect(refs, t, action.effect)).filter((m): m is EffectDef => m !== null);
      if (!matched.length) {
        c.add('E_REF', `${apath}/effect`, `no targeted region has an effect '${action.effect}'`);
        return;
      }
      for (const effect of matched) {
        const spec = own(EFFECT_TYPES[effect.type].props, action.property);
        if (!spec) {
          c.add('E_EFFECT_PROPERTY', `${apath}/property`, `'${effect.type}' has no property '${action.property}'`);
          break;
        }
        if (!checkPropValue(c, spec, action.value, `${apath}/value`)) break;
        if (durationOk && ((action.duration_ms as number | undefined) ?? 0) > 0 && spec.kind !== 'number') {
          c.add('E_EFFECT_PROPERTY', `${apath}/duration_ms`, 'only numeric properties can be transitioned');
          break;
        }
      }
    } else if (name === 'toggle_layer') {
      c.obj(action, apath, ['action', 'layer', 'mode'], ['layer']);
      if (has(action, 'layer') && c.ident(action.layer, `${apath}/layer`) && !refs.layers.has(action.layer)) {
        c.add('E_REF', `${apath}/layer`, `unknown layer '${action.layer}'`);
      }
      if (has(action, 'mode')) c.enum(action.mode, `${apath}/mode`, ['show', 'hide', 'toggle']);
    } else if (name === 'select_region') {
      c.obj(action, apath, ['action', 'region', 'group', 'mode', 'reveal']);
      effectTargets(c, action, apath, selfRegion, refs);
      if (has(action, 'mode')) c.enum(action.mode, `${apath}/mode`, ['select', 'deselect', 'toggle']);
      if (has(action, 'reveal')) c.boolean(action.reveal, `${apath}/reveal`);
    } else if (name === 'show_tooltip') {
      c.obj(action, apath, ['action', 'text', 'region']);
      if (has(action, 'text')) c.string(action.text, `${apath}/text`, M.max_tooltip, 1);
      if (has(action, 'region')) {
        if (c.ident(action.region, `${apath}/region`) && !refs.regions.has(action.region)) {
          c.add('E_REF', `${apath}/region`, `unknown region '${action.region}'`);
        }
      } else if (selfRegion === null) {
        c.add('E_TARGET', apath, "show_tooltip needs a 'region' outside a region handler");
      }
    } else if (name === 'open_panel') {
      c.obj(action, apath, ['action', 'panel'], ['panel']);
      if (has(action, 'panel') && c.ident(action.panel, `${apath}/panel`)
        && own(refs.panels, action.panel) === undefined) {
        c.add('E_REF', `${apath}/panel`, `unknown panel '${action.panel}'`);
      }
    } else if (name === 'navigate_document') {
      c.obj(action, apath, ['action', 'href', 'label'], ['href']);
      if (has(action, 'href')) {
        const problem = documentHrefProblem(action.href);
        if (problem) c.add('E_LINK', `${apath}/href`, problem);
      }
      if (has(action, 'label')) c.string(action.label, `${apath}/label`, M.max_label);
    } else if (name === 'open_link') {
      c.obj(action, apath, ['action', 'url', 'label'], ['url']);
      if (has(action, 'url')) {
        const problem = externalUrlProblem(action.url);
        if (problem) c.add('E_LINK', `${apath}/url`, problem);
      }
      if (has(action, 'label')) c.string(action.label, `${apath}/label`, M.max_label);
    } else if (name === 'play_animation' || name === 'stop_animation') {
      c.obj(action, apath, ['action', 'animation'], name === 'play_animation' ? ['animation'] : []);
      if (has(action, 'animation') && c.ident(action.animation, `${apath}/animation`)
        && own(refs.animations, action.animation) === undefined) {
        c.add('E_REF', `${apath}/animation`, `unknown animation '${action.animation}'`);
      }
    } else if (name === 'reset_view') {
      c.obj(action, apath, ['action']);
    }
  });
}

function checkTextLinks(c: Checker, text: string, path: string, refs: Refs): void {
  for (const { target } of textLinks(text)) {
    if (target.startsWith('#region:')) {
      const id = target.slice('#region:'.length);
      if (!refs.regions.has(id)) c.add('E_REF', path, `text links to unknown region '${id}'`);
    } else if (target.startsWith('#panel:')) {
      const id = target.slice('#panel:'.length);
      if (own(refs.panels, id) === undefined) c.add('E_REF', path, `text links to unknown panel '${id}'`);
    } else {
      const problem = externalUrlProblem(target);
      if (problem) c.add('E_LINK', path, `link target '${target.slice(0, 80)}' is not allowed: ${problem}`);
    }
  }
}

function checkAnimation(c: Checker, anim: unknown, path: string, refs: Refs): void {
  if (!c.obj(anim, path, ['type', 'region', 'effect', 'property', 'from', 'to', 'duration_ms', 'iterations',
    'easing', 'end'], ['type', 'region', 'effect', 'property', 'from', 'to', 'duration_ms'])) return;
  if (has(anim, 'type')) c.enum(anim.type, `${path}/type`, ['fade', 'pulse']);
  if (has(anim, 'easing')) c.enum(anim.easing, `${path}/easing`, ['linear', 'ease-in-out']);
  if (has(anim, 'end')) c.enum(anim.end, `${path}/end`, ['hold', 'revert']);
  const durationOk = has(anim, 'duration_ms') &&
    c.number(anim.duration_ms, `${path}/duration_ms`, R.min_animation_ms, R.max_animation_ms);
  const iterationsOk = !has(anim, 'iterations') ||
    c.number(anim.iterations, `${path}/iterations`, 1, R.max_animation_iterations, { integer: true });
  if (durationOk && iterationsOk &&
    (anim.duration_ms as number) * ((anim.iterations as number | undefined) ?? 1) > R.max_animation_total_ms) {
    c.add('E_ANIMATION', path,
      `total running time (duration_ms x iterations) must not exceed ${R.max_animation_total_ms} ms`);
  }
  if (!(has(anim, 'region') && c.ident(anim.region, `${path}/region`))) return;
  if (!refs.regions.has(anim.region)) {
    c.add('E_REF', `${path}/region`, `unknown region '${anim.region}'`);
    return;
  }
  if (!(has(anim, 'effect') && c.ident(anim.effect, `${path}/effect`))) return;
  const effect = refEffect(refs, anim.region, anim.effect);
  if (!effect) {
    c.add('E_REF', `${path}/effect`, `region '${anim.region}' has no effect '${anim.effect}'`);
    return;
  }
  const spec = own(EFFECT_TYPES[effect.type].props, anim.property);
  if (!spec || spec.kind !== 'number') {
    c.add('E_EFFECT_PROPERTY', `${path}/property`, 'animations need a numeric property of the effect');
    return;
  }
  for (const key of ['from', 'to']) if (has(anim, key)) c.number(anim[key], `${path}/${key}`, spec.min!, spec.max!);
}

function checkDefaultState(c: Checker, state: unknown, refs: Refs): void {
  if (!c.obj(state, '/default_state', ['selected', 'panel', 'view'])) return;
  const seen = new Set<string>();
  c.array(opt(state, 'selected', []), '/default_state/selected', M.max_regions).forEach((rid, j) => {
    if (!c.ident(rid, `/default_state/selected/${j}`)) return;
    if (seen.has(rid)) c.add('E_DUPLICATE_ID', `/default_state/selected/${j}`, `region '${rid}' is listed twice`);
    seen.add(rid);
    if (!refs.regions.has(rid)) c.add('E_REF', `/default_state/selected/${j}`, `unknown region '${rid}'`);
  });
  const panel = state.panel;
  if (has(state, 'panel') && panel !== null && c.ident(panel, '/default_state/panel')
    && own(refs.panels, panel) === undefined) {
    c.add('E_REF', '/default_state/panel', `unknown panel '${panel}'`);
  }
  const view = state.view;
  if (has(state, 'view') && c.obj(view, '/default_state/view', ['zoom', 'centre_x', 'centre_y'])) {
    if (has(view, 'zoom') && view.zoom !== 'fit') c.number(view.zoom, '/default_state/view/zoom', R.min_zoom, R.max_zoom);
    for (const key of ['centre_x', 'centre_y']) if (has(view, key)) c.coord(view[key], `/default_state/view/${key}`);
  }
}
