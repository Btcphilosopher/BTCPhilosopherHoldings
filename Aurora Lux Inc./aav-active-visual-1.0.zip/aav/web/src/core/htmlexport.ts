/** Standalone HTML export: one file with the viewer, its styles and the document. Mirrors htmlexport.py. */
import type { AavPackage } from './types';
import { canonicalJson } from './package';
import { MANIFEST, PREVIEW, writeZip } from './zip';

export function base64Encode(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}

export function base64Decode(text: string): Uint8Array {
  const binary = atob(text.replace(/\s+/g, ''));
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

const escapeHtml = (s: string): string =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;');

export interface StandaloneParts { template: string; script: string; style: string }

export async function buildStandaloneHtml(parts: StandaloneParts, pkg: AavPackage): Promise<string> {
  const doc = pkg.manifest.document;
  const script = parts.script.replace(/<\/script/g, '<\\/script');
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(script)));
  const files = new Map<string, Uint8Array>([[MANIFEST, canonicalJson(pkg.manifest)]]);
  for (const [name, data] of pkg.files) files.set(name, data);
  const labels = (pkg.manifest.regions ?? []).filter((r) => r.interactive !== false).map((r) => r.label);
  const values: Record<string, string> = {
    LANG: escapeHtml(doc.language ?? 'en'),
    TITLE: escapeHtml(doc.title),
    DESCRIPTION: escapeHtml(doc.description ?? ''),
    SCRIPT_HASH: base64Encode(digest),
    STYLE: parts.style.replace(/<\/style/g, '<\\/style'),
    REGIONS: labels.map((label) => `<li>${escapeHtml(label)}</li>`).join(''),
    PREVIEW: base64Encode(pkg.files.get(PREVIEW) ?? new Uint8Array()),
    ARCHIVE: base64Encode(writeZip(files)),
    SCRIPT: script,
  };
  // Single pass, so text substituted for one placeholder is never scanned for another.
  return parts.template.replace(/\{\{([A-Z_]+)\}\}/g, (whole, name: string) => values[name] ?? whole);
}
