/**
 * Hit testing in document coordinates.
 *
 * Only regions take part: layers never intercept the pointer. Candidates are
 * the regions with interactive !== false whose shape contains the point. The
 * winner is the one with the highest z_index; ties go to the region that
 * appears later in the manifest (painted last). There is no bubbling.
 */
import { pointInPolygon } from './geometry';
import type { Manifest, Region } from './types';

/** Alpha channel (0-255) of a decoded mask asset, in the asset's own pixel grid. */
export interface MaskAlpha { width: number; height: number; data: Uint8Array | Uint8ClampedArray }

export function regionContains(region: Region, x: number, y: number, docW: number, docH: number,
                               masks: ReadonlyMap<string, MaskAlpha>): boolean {
  const shape = region.shape;
  if (shape.type === 'rect') {
    return x >= shape.x && x < shape.x + shape.width && y >= shape.y && y < shape.y + shape.height;
  }
  if (shape.type === 'polygon') return pointInPolygon(shape.points, x, y);
  const mx = shape.x ?? 0, my = shape.y ?? 0, mw = shape.width ?? docW, mh = shape.height ?? docH;
  if (x < mx || x >= mx + mw || y < my || y >= my + mh) return false;
  if (shape.hit_test === 'bounds') return true;
  const mask = masks.get(shape.asset);
  if (!mask) return false;
  const u = Math.min(mask.width - 1, Math.floor(((x - mx) / mw) * mask.width));
  const v = Math.min(mask.height - 1, Math.floor(((y - my) / mh) * mask.height));
  return mask.data[v * mask.width + u] >= (shape.threshold ?? 0.5) * 255;
}

/** Every interactive region under the point, topmost first. */
export function hitTestAll(manifest: Manifest, x: number, y: number, masks: ReadonlyMap<string, MaskAlpha>): Region[] {
  const { width, height } = manifest.document;
  if (!Number.isFinite(x) || !Number.isFinite(y)) return [];
  return (manifest.regions ?? [])
    .map((region, index) => ({ region, index }))
    .filter(({ region }) => region.interactive !== false && regionContains(region, x, y, width, height, masks))
    .sort((a, b) => (b.region.z_index ?? 0) - (a.region.z_index ?? 0) || b.index - a.index)
    .map(({ region }) => region);
}

export function hitTest(manifest: Manifest, x: number, y: number, masks: ReadonlyMap<string, MaskAlpha>): Region | null {
  return hitTestAll(manifest, x, y, masks)[0] ?? null;
}
