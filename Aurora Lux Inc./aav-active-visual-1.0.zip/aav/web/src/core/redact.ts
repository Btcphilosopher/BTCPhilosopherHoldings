/**
 * Permanent redaction export for the browser. Same contract as
 * python/src/aav/redact.py: the chosen regions are destroyed in every image
 * layer's source asset, all assets are re-encoded from raw pixels, unused and
 * unreferenced files are dropped, the preview is rebuilt, and the result is
 * verified before it is returned.
 *
 * Display effects (pixelate, blur) are NOT redaction; see SPEC section 12.
 */
import { imageMatrix, invert } from './geometry';
import { completeAssets, referencedPaths, sha256Hex, validatePackage } from './package';
import { blurAlpha, parseColour } from './pixels';
import { SceneRenderer, canvasToPng, decodeAssets, makeCanvas, makeThumbnail, renderPreviewPng } from './renderer';
import type { DecodedAsset } from './renderer';
import type { AavPackage, ImageLayer, Issue, Manifest } from './types';
import { AavError, errorsOnly } from './types';
import { PREVIEW } from './zip';

const ALLOWED_PNG_CHUNKS = new Set(['IHDR', 'PLTE', 'tRNS', 'IDAT', 'IEND', 'sRGB', 'gAMA', 'cHRM']);

/** Grow a binary coverage map by about `pixels` in every direction. */
function dilate(alpha: Uint8ClampedArray, width: number, height: number, pixels: number): Uint8ClampedArray {
  const spread = blurAlpha(alpha, width, height, Math.max(2, pixels * 2));
  const out = new Uint8ClampedArray(alpha.length);
  for (let i = 0; i < out.length; i++) out[i] = alpha[i] > 0 || spread[i] > 0.5 ? 255 : 0;
  return out;
}

function alphaCanvas(alpha: Uint8ClampedArray, width: number, height: number): HTMLCanvasElement {
  const { canvas, ctx } = makeCanvas(width, height);
  const img = ctx.createImageData(width, height);
  for (let i = 0; i < alpha.length; i++) {
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = 255;
    img.data[i * 4 + 3] = alpha[i];
  }
  ctx.putImageData(img, 0, 0);
  return canvas;
}

/** Conservative document-space coverage (0 or 255) of the union of the given regions. */
function unionMask(manifest: Manifest, assets: ReadonlyMap<string, DecodedAsset>, regionIds: string[]): Uint8ClampedArray {
  const { width, height } = manifest.document;
  const renderer = new SceneRenderer(manifest, assets, { backend: 'cpu' });
  const { ctx } = makeCanvas(width, height, true);
  const known = new Map((manifest.regions ?? []).map((r) => [r.id, r]));
  const missing = regionIds.filter((id) => !known.has(id));
  if (missing.length) {
    renderer.dispose();
    throw new AavError({ code: 'E_REF', path: '/redaction/regions', message: `unknown region(s): ${missing.join(', ')}` });
  }
  for (const id of regionIds) {
    const region = known.get(id)!;
    if (region.shape.type === 'mask' && region.shape.hit_test === 'bounds') {
      ctx.fillStyle = '#fff';
      ctx.fillRect(region.shape.x ?? 0, region.shape.y ?? 0, region.shape.width ?? width, region.shape.height ?? height);
    } else renderer.paintCoverage(ctx, region);
  }
  renderer.dispose();
  const rgba = ctx.getImageData(0, 0, width, height).data;
  const alpha = new Uint8ClampedArray(width * height);
  for (let i = 0; i < alpha.length; i++) alpha[i] = rgba[i * 4 + 3] > 0 ? 255 : 0;
  return dilate(alpha, width, height, 1);
}

/** Map the document-space mask into the pixel grid of an image layer's asset. */
function assetMask(docMask: Uint8ClampedArray, manifest: Manifest, layer: ImageLayer, assetW: number, assetH: number): Uint8ClampedArray {
  const { width, height } = manifest.document;
  const forward = imageMatrix(layer, assetW, assetH, width, height);
  const stretch = Math.max(Math.abs(forward[0]), Math.abs(forward[1]), Math.abs(forward[2]), Math.abs(forward[3]));
  const source = stretch > 1 ? dilate(docMask, width, height, Math.ceil(stretch)) : docMask;
  const { ctx } = makeCanvas(assetW, assetH, true);
  const m = invert(forward);
  ctx.setTransform(m[0], m[1], m[2], m[3], m[4], m[5]);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(alphaCanvas(source, width, height), 0, 0);
  const rgba = ctx.getImageData(0, 0, assetW, assetH).data;
  const alpha = new Uint8ClampedArray(assetW * assetH);
  for (let i = 0; i < alpha.length; i++) alpha[i] = rgba[i * 4 + 3] > 0 ? 255 : 0;
  return dilate(alpha, assetW, assetH, 1);
}

function assetUsage(manifest: Manifest): { layerAssets: Set<string>; maskAssets: Set<string> } {
  const layerAssets = new Set<string>(), maskAssets = new Set<string>();
  for (const layer of manifest.layers) if (layer.type === 'image') layerAssets.add(layer.asset);
  for (const region of manifest.regions ?? []) if (region.shape.type === 'mask') maskAssets.add(region.shape.asset);
  return { layerAssets, maskAssets };
}

function assetPixels(asset: DecodedAsset): { ctx: CanvasRenderingContext2D; canvas: HTMLCanvasElement; img: ImageData } {
  const { canvas, ctx } = makeCanvas(asset.width, asset.height, true);
  ctx.drawImage(asset.image, 0, 0);
  return { canvas, ctx, img: ctx.getImageData(0, 0, asset.width, asset.height) };
}

/** Return a new package with the given regions permanently removed. Throws if verification fails. */
export async function redactPackage(pkg: AavPackage, regionIds: string[], colour = '#000000'): Promise<AavPackage> {
  if (!regionIds.length) throw new AavError('redaction needs at least one region id');
  const issues = errorsOnly(await validatePackage(pkg));
  if (issues.length) throw new AavError(issues);
  const c = parseColour(colour);
  const fill = [Math.round(c.r * 255), Math.round(c.g * 255), Math.round(c.b * 255)];
  const manifest = structuredClone(pkg.manifest);
  const assets = await decodeAssets(pkg);
  const docMask = unionMask(manifest, assets, regionIds);
  const { layerAssets, maskAssets } = assetUsage(manifest);

  const masks = new Map<string, Uint8ClampedArray>();
  for (const layer of manifest.layers) {
    if (layer.type !== 'image') continue;
    const asset = assets.get(layer.asset)!;
    const mask = assetMask(docMask, manifest, layer, asset.width, asset.height);
    const previous = masks.get(layer.asset);
    if (previous) for (let i = 0; i < mask.length; i++) mask[i] = Math.max(mask[i], previous[i]);
    masks.set(layer.asset, mask);
  }

  const files = new Map<string, Uint8Array>();
  const newAssets: Manifest['assets'] = {};
  for (const [id, asset] of Object.entries(manifest.assets ?? {})) {
    if (!layerAssets.has(id) && !maskAssets.has(id)) continue; // unused: a possible hidden original
    const { canvas, ctx, img } = assetPixels(assets.get(id)!);
    if (layerAssets.has(id)) {
      const mask = masks.get(id)!;
      for (let i = 0; i < mask.length; i++) {
        if (!mask[i]) continue;
        img.data[i * 4] = fill[0]; img.data[i * 4 + 1] = fill[1]; img.data[i * 4 + 2] = fill[2]; img.data[i * 4 + 3] = 255;
      }
    } else {
      for (let i = 0; i < img.data.length; i += 4) img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
    }
    ctx.putImageData(img, 0, 0);
    const path = `${asset.path.split('/')[0]}/${id}.png`;
    files.set(path, await canvasToPng(canvas));
    newAssets[id] = { path, media_type: 'image/png' };
  }
  manifest.assets = newAssets;
  delete manifest.thumbnail;
  const hex = (n: number) => n.toString(16).padStart(2, '0').toUpperCase();
  manifest.redaction = { method: 'fill', colour: `#${hex(fill[0])}${hex(fill[1])}${hex(fill[2])}`, regions: [...regionIds],
    tool: 'aav-web 1.0.0' };
  const out: AavPackage = { manifest, files };
  await completeAssets(out);
  const preview = await renderPreviewPng(manifest, await decodeAssets(out));
  files.set(PREVIEW, preview);
  manifest.thumbnail = 'thumbnails/preview.png';
  files.set(manifest.thumbnail, await makeThumbnail(preview));

  const problems = await verifyRedaction(pkg, out);
  if (problems.length) throw new AavError(problems);
  return out;
}

function pngChunks(data: Uint8Array): string[] {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  const names: string[] = [];
  for (let pos = 8; pos + 8 <= data.length;) {
    names.push(String.fromCharCode(data[pos + 4], data[pos + 5], data[pos + 6], data[pos + 7]));
    pos += 12 + view.getUint32(pos);
  }
  return names;
}

/** Check that `redacted` carries no recoverable copy of the redacted areas of `original`. Empty result = pass. */
export async function verifyRedaction(original: AavPackage, redacted: AavPackage): Promise<Issue[]> {
  const issues = errorsOnly(await validatePackage(redacted, { strict: true }));
  const record = redacted.manifest.redaction;
  if (issues.length) return issues;
  if (!record || !record.regions.length) return [{ code: 'E_REDACTION', path: '/redaction', message: 'document has no redaction record' }];
  const add = (path: string, message: string) => issues.push({ code: 'E_REDACTION', path, message });
  const manifest = redacted.manifest;
  const c = parseColour(record.colour ?? '#000000');
  const fill = [Math.round(c.r * 255), Math.round(c.g * 255), Math.round(c.b * 255)];
  const { layerAssets, maskAssets } = assetUsage(manifest);

  for (const id of Object.keys(manifest.assets ?? {})) {
    if (!layerAssets.has(id) && !maskAssets.has(id)) add(`/assets/${id}`, 'asset is not used by any layer or mask');
  }
  const used = referencedPaths(manifest);
  for (const name of redacted.files.keys()) if (!used.has(name)) add(name, 'unreferenced file present');

  for (const [name, data] of redacted.files) {
    if (!(name.startsWith('assets/') || name.startsWith('masks/') || name === PREVIEW)) continue;
    if (data[0] !== 0x89 || data[1] !== 0x50) {
      add(name, 'redacted exports must contain PNG images only');
      continue;
    }
    const stray = [...new Set(pngChunks(data))].filter((chunk) => !ALLOWED_PNG_CHUNKS.has(chunk));
    if (stray.length) add(name, `PNG carries extra chunks: ${stray.join(', ')}`);
  }

  const differsFromFill = (img: ImageData, mask: Uint8ClampedArray): boolean => {
    for (let i = 0; i < mask.length; i++) {
      if (mask[i] && (img.data[i * 4] !== fill[0] || img.data[i * 4 + 1] !== fill[1] || img.data[i * 4 + 2] !== fill[2] ||
        img.data[i * 4 + 3] !== 255)) return true;
    }
    return false;
  };

  const assets = await decodeAssets(redacted);
  const docMask = unionMask(manifest, assets, record.regions);
  for (const layer of manifest.layers) {
    if (layer.type !== 'image') continue;
    const asset = assets.get(layer.asset)!;
    const mask = assetMask(docMask, manifest, layer, asset.width, asset.height);
    if (differsFromFill(assetPixels(asset).img, mask)) {
      add(`/layers/${layer.id}`, 'asset pixels inside a redacted region differ from the fill colour');
    }
  }

  // No byte-identical copy of an original file that showed redacted content may survive.
  const sensitive = new Map<string, string>();
  try {
    const originalAssets = await decodeAssets(original);
    const originalMask = unionMask(original.manifest, originalAssets, record.regions);
    for (const layer of original.manifest.layers) {
      if (layer.type !== 'image') continue;
      const asset = originalAssets.get(layer.asset)!;
      const mask = assetMask(originalMask, original.manifest, layer, asset.width, asset.height);
      if (differsFromFill(assetPixels(asset).img, mask)) {
        const path = original.manifest.assets![layer.asset].path;
        sensitive.set(await sha256Hex(original.files.get(path)!), path);
      }
    }
    if (sensitive.size) {
      const usedOriginal = referencedPaths(original.manifest);
      for (const [name, data] of original.files) {
        if (name === PREVIEW || name.startsWith('thumbnails/') || !usedOriginal.has(name)) sensitive.set(await sha256Hex(data), name);
      }
    }
  } catch {
    for (const [name, data] of original.files) sensitive.set(await sha256Hex(data), name);
  }
  for (const [name, data] of redacted.files) {
    const source = sensitive.get(await sha256Hex(data));
    if (source) add(name, `file is byte-identical to original '${source}', which shows redacted content`);
  }
  return issues;
}
