/**
 * AAV restricted text: the only rich-text format allowed in panels.
 *
 * Blocks are separated by blank lines. A block whose first line starts with
 * "# " is a heading; a block whose lines all start with "- " is a list; any
 * other block is a paragraph in which single newlines are line breaks.
 * Inline: **bold**, *italic*, `code`, [label](target) and backslash escapes.
 * There is no HTML. Consumers build DOM nodes from this tree with
 * textContent, never innerHTML.
 */
import { externalUrlProblem } from './links';

export type LinkTarget =
  | { kind: 'external'; url: string }
  | { kind: 'region'; id: string }
  | { kind: 'panel'; id: string };

export type Inline =
  | { type: 'text'; text: string }
  | { type: 'bold' | 'italic' | 'code'; text: string }
  | { type: 'break' }
  | { type: 'link'; text: string; target: LinkTarget };

export type Block =
  | { type: 'heading' | 'paragraph'; content: Inline[] }
  | { type: 'list'; items: Inline[][] };

/** Same token grammar as INLINE_TOKEN in python/src/aav/links.py. */
const INLINE_TOKEN = /(\\[\\*[\]`()])|(`[^`\n]+`)|(\*\*[^*\n]+\*\*)|(\*[^*\n]+\*)|(\[[^\]\n]*\]\([^)\s]*\))/g;
const LINK = /^\[([^\]\n]*)\]\(([^)\s]*)\)$/;

/** Classify a link target. Returns null for anything that must not become a link. */
export function classifyTarget(target: string): LinkTarget | null {
  if (target.startsWith('#region:')) return { kind: 'region', id: target.slice('#region:'.length) };
  if (target.startsWith('#panel:')) return { kind: 'panel', id: target.slice('#panel:'.length) };
  return externalUrlProblem(target) === null ? { kind: 'external', url: target } : null;
}

/** Raw (label, target) pairs of every link token; used by validation. */
export function textLinks(text: string): { label: string; target: string }[] {
  const out: { label: string; target: string }[] = [];
  for (const match of text.matchAll(INLINE_TOKEN)) {
    if (match[5]) {
      const parts = LINK.exec(match[5])!;
      out.push({ label: parts[1], target: parts[2] });
    }
  }
  return out;
}

function pushText(out: Inline[], text: string): void {
  if (!text) return;
  const last = out[out.length - 1];
  if (last && last.type === 'text') last.text += text;
  else out.push({ type: 'text', text });
}

export function parseInline(line: string): Inline[] {
  const out: Inline[] = [];
  let pos = 0;
  for (const match of line.matchAll(INLINE_TOKEN)) {
    pushText(out, line.slice(pos, match.index));
    pos = match.index + match[0].length;
    const token = match[0];
    if (match[1]) pushText(out, token[1]);
    else if (match[2]) out.push({ type: 'code', text: token.slice(1, -1) });
    else if (match[3]) out.push({ type: 'bold', text: token.slice(2, -2) });
    else if (match[4]) out.push({ type: 'italic', text: token.slice(1, -1) });
    else {
      const parts = LINK.exec(token)!;
      const target = classifyTarget(parts[2]);
      // Unsafe or unknown targets stay visible as plain text so nothing is hidden from the reader.
      if (target && parts[1]) out.push({ type: 'link', text: parts[1], target });
      else pushText(out, token);
    }
  }
  pushText(out, line.slice(pos));
  return out;
}

export function parseText(source: string): Block[] {
  const blocks: Block[] = [];
  for (const chunk of source.replace(/\r\n?/g, '\n').split(/\n[ \t]*\n+/)) {
    const lines = chunk.split('\n').filter((l) => l.trim() !== '');
    if (!lines.length) continue;
    if (lines[0].startsWith('# ')) {
      blocks.push({ type: 'heading', content: parseInline(lines[0].slice(2)) });
      lines.shift();
      if (!lines.length) continue;
    }
    if (lines.every((l) => l.startsWith('- '))) {
      blocks.push({ type: 'list', items: lines.map((l) => parseInline(l.slice(2))) });
      continue;
    }
    const content: Inline[] = [];
    lines.forEach((line, i) => {
      if (i) content.push({ type: 'break' });
      content.push(...parseInline(line));
    });
    blocks.push({ type: 'paragraph', content });
  }
  return blocks;
}

/** Plain-text rendering, used for accessible descriptions and static fallbacks. */
export function plainText(source: string): string {
  const inline = (nodes: Inline[]) => nodes.map((n) => (n.type === 'break' ? '\n' : n.text)).join('');
  return parseText(source)
    .map((b) => (b.type === 'list' ? b.items.map((i) => '- ' + inline(i)).join('\n') : inline(b.content)))
    .join('\n\n');
}
