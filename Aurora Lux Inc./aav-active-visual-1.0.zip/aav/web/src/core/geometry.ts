/**
 * Geometry in document coordinates, plus the view transform between document
 * and screen (CSS pixel) space. Matrices are [a, b, c, d, e, f] with the
 * Canvas 2D convention: x' = a*x + c*y + e, y' = b*x + d*y + f.
 */
import { LIMITS } from './limits';
import type { ImageLayer, Layer, Shape } from './types';

export type Matrix = [number, number, number, number, number, number];
export const IDENTITY: Matrix = [1, 0, 0, 1, 0, 0];
export interface Point { x: number; y: number }
export interface Rect { x: number; y: number; width: number; height: number }

/** m x n: apply n first, then m. */
export function multiply(m: Matrix, n: Matrix): Matrix {
  return [
    m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
    m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
    m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5],
  ];
}

export function invert(m: Matrix): Matrix {
  const det = m[0] * m[3] - m[1] * m[2];
  if (Math.abs(det) < 1e-12) throw new Error('matrix is not invertible');
  return [m[3] / det, -m[1] / det, -m[2] / det, m[0] / det,
    (m[2] * m[5] - m[3] * m[4]) / det, (m[1] * m[4] - m[0] * m[5]) / det];
}

export const applyMatrix = (m: Matrix, x: number, y: number): Point =>
  ({ x: m[0] * x + m[2] * y + m[4], y: m[1] * x + m[3] * y + m[5] });

/** Untransformed layer box. Image layers default to filling the document. */
export function layerBox(layer: Layer, docW: number, docH: number): Rect {
  if (layer.type === 'image') {
    return { x: layer.x ?? 0, y: layer.y ?? 0, width: layer.width ?? docW, height: layer.height ?? docH };
  }
  return { x: layer.x, y: layer.y, width: 0, height: 0 };
}

/** T = translate(t) . translate(o) . rotate(r) . scale(s) . translate(-o); rotation is clockwise degrees. */
export function layerTransform(layer: Layer, docW: number, docH: number): Matrix {
  const t = layer.transform;
  if (!t) return IDENTITY;
  const box = layerBox(layer, docW, docH);
  const ox = t.origin_x ?? box.x + box.width / 2, oy = t.origin_y ?? box.y + box.height / 2;
  const angle = ((t.rotation ?? 0) * Math.PI) / 180;
  const cos = Math.cos(angle), sin = Math.sin(angle);
  let m: Matrix = [1, 0, 0, 1, (t.translate_x ?? 0) + ox, (t.translate_y ?? 0) + oy];
  m = multiply(m, [cos, sin, -sin, cos, 0, 0]);
  m = multiply(m, [t.scale_x ?? 1, 0, 0, t.scale_y ?? 1, 0, 0]);
  return multiply(m, [1, 0, 0, 1, -ox, -oy]);
}

/** Map asset pixel coordinates to document coordinates for an image layer. */
export function imageMatrix(layer: ImageLayer, assetW: number, assetH: number, docW: number, docH: number): Matrix {
  const box = layerBox(layer, docW, docH);
  return multiply(layerTransform(layer, docW, docH), [box.width / assetW, 0, 0, box.height / assetH, box.x, box.y]);
}

/** Even-odd point-in-polygon test (ray casting). Points on the boundary are implementation-defined. */
export function pointInPolygon(points: [number, number][], x: number, y: number): boolean {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const [xi, yi] = points[i], [xj, yj] = points[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

export function shapeCentre(shape: Shape, docW: number, docH: number): Point {
  if (shape.type === 'polygon') {
    const xs = shape.points.map((p) => p[0]), ys = shape.points.map((p) => p[1]);
    return { x: (Math.min(...xs) + Math.max(...xs)) / 2, y: (Math.min(...ys) + Math.max(...ys)) / 2 };
  }
  const x = shape.x ?? 0, y = shape.y ?? 0;
  const w = shape.type === 'mask' ? shape.width ?? docW : shape.width;
  const h = shape.type === 'mask' ? shape.height ?? docH : shape.height;
  return { x: x + w / 2, y: y + h / 2 };
}

// ----------------------------------------------------------------------------- view

/** Document-to-screen mapping: screen = doc * scale + (tx, ty), in CSS pixels. */
export interface View { scale: number; tx: number; ty: number }

export const docToScreen = (v: View, x: number, y: number): Point => ({ x: x * v.scale + v.tx, y: y * v.scale + v.ty });
export const screenToDoc = (v: View, x: number, y: number): Point => ({ x: (x - v.tx) / v.scale, y: (y - v.ty) / v.scale });

export function clampScale(scale: number): number {
  return Math.min(LIMITS.runtime.max_zoom, Math.max(LIMITS.runtime.min_zoom, scale));
}

/** Largest view that shows the whole document, centred, with a margin in CSS pixels. */
export function fitView(docW: number, docH: number, viewW: number, viewH: number, margin = 0): View {
  const scale = clampScale(Math.min((viewW - 2 * margin) / docW, (viewH - 2 * margin) / docH) || 1);
  return { scale, tx: (viewW - docW * scale) / 2, ty: (viewH - docH * scale) / 2 };
}

/** View at a given scale with a document point at the centre of the viewport. */
export function centredView(scale: number, cx: number, cy: number, viewW: number, viewH: number): View {
  const s = clampScale(scale);
  return { scale: s, tx: viewW / 2 - cx * s, ty: viewH / 2 - cy * s };
}

/** Zoom by `factor` keeping the document point under screen position (sx, sy) fixed. */
export function zoomAt(v: View, factor: number, sx: number, sy: number): View {
  const scale = clampScale(v.scale * factor);
  const p = screenToDoc(v, sx, sy);
  return { scale, tx: sx - p.x * scale, ty: sy - p.y * scale };
}

export const panBy = (v: View, dx: number, dy: number): View => ({ scale: v.scale, tx: v.tx + dx, ty: v.ty + dy });

/** Integer pixel rectangle covering `r`, clamped to the document. Null if empty. */
export function clampRect(r: Rect, docW: number, docH: number, pad = 0): Rect | null {
  const x0 = Math.max(0, Math.floor(r.x - pad)), y0 = Math.max(0, Math.floor(r.y - pad));
  const x1 = Math.min(docW, Math.ceil(r.x + r.width + pad)), y1 = Math.min(docH, Math.ceil(r.y + r.height + pad));
  return x1 > x0 && y1 > y0 ? { x: x0, y: y0, width: x1 - x0, height: y1 - y0 } : null;
}
