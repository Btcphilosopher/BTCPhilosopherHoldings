/** Type definitions for AAV manifest schema 1.0. See docs/SPEC.md. */

export type EffectType =
  | 'pixelate' | 'blur' | 'brightness' | 'contrast' | 'saturation'
  | 'tint' | 'spotlight' | 'opacity' | 'glow' | 'outline';

export type PropValue = number | string | boolean;

export interface EffectDef {
  type: EffectType;
  [property: string]: PropValue;
}

export interface RectShape { type: 'rect'; x: number; y: number; width: number; height: number }
export interface PolygonShape { type: 'polygon'; points: [number, number][] }
export interface MaskShape {
  type: 'mask'; asset: string; x?: number; y?: number; width?: number; height?: number;
  threshold?: number; hit_test?: 'alpha' | 'bounds';
}
export type Shape = RectShape | PolygonShape | MaskShape;

export type Trigger = 'pointer_enter' | 'pointer_leave' | 'activate' | 'focus' | 'blur';
export type DocumentTrigger = 'document_load';
export type Easing = 'linear' | 'ease-in-out';

export type Action =
  | { action: 'set_effect'; effect: string; property: string; value: PropValue; region?: string; group?: string;
      duration_ms?: number; easing?: Easing }
  | { action: 'toggle_layer'; layer: string; mode?: 'show' | 'hide' | 'toggle' }
  | { action: 'select_region'; region?: string; group?: string; mode?: 'select' | 'deselect' | 'toggle';
      reveal?: boolean }
  | { action: 'show_tooltip'; text?: string; region?: string }
  | { action: 'open_panel'; panel: string }
  | { action: 'navigate_document'; href: string; label?: string }
  | { action: 'open_link'; url: string; label?: string }
  | { action: 'play_animation'; animation: string }
  | { action: 'stop_animation'; animation?: string }
  | { action: 'reset_view' };

export type ActionName = Action['action'];
export type StateName = 'hover' | 'selected' | 'focus';
export type StateOverrides = Record<string, Record<string, PropValue>>;

export interface Region {
  id: string;
  label: string;
  description?: string;
  shape: Shape;
  target_layer?: string;
  z_index?: number;
  interactive?: boolean;
  selectable?: boolean;
  tooltip?: string;
  effects?: Record<string, EffectDef>;
  states?: Partial<Record<StateName, StateOverrides>>;
  events?: Partial<Record<Trigger, Action[]>>;
}

export interface LayerTransform {
  translate_x?: number; translate_y?: number; scale_x?: number; scale_y?: number;
  rotation?: number; origin_x?: number; origin_y?: number;
}

interface LayerCommon {
  id: string;
  name?: string;
  visible?: boolean;
  opacity?: number;
  transform?: LayerTransform;
  clip?: { x: number; y: number; width: number; height: number };
}
export interface ImageLayer extends LayerCommon {
  type: 'image'; asset: string; x?: number; y?: number; width?: number; height?: number;
}
export interface TextLayer extends LayerCommon {
  type: 'text'; text: string; x: number; y: number; font_size?: number;
  font_family?: 'sans-serif' | 'serif' | 'monospace'; font_weight?: 400 | 700; colour?: string;
  align?: 'left' | 'centre' | 'right'; background?: string; padding?: number; max_width?: number;
  line_height?: number;
}
export type Layer = ImageLayer | TextLayer;

export interface Asset {
  path: string;
  media_type: 'image/png' | 'image/jpeg' | 'image/webp';
  sha256?: string;
  width?: number;
  height?: number;
}

export interface Animation {
  type: 'fade' | 'pulse';
  region: string;
  effect: string;
  property: string;
  from: number;
  to: number;
  duration_ms: number;
  iterations?: number;
  easing?: Easing;
  end?: 'hold' | 'revert';
}

export interface Manifest {
  format: string;
  version: string;
  document: {
    id: string; title: string; width: number; height: number; description?: string; language?: string;
    colour_space?: 'srgb'; background?: string;
  };
  metadata?: { author?: string; licence?: string; created?: string; generator?: string; source?: string };
  settings?: {
    selection?: 'single' | 'multiple' | 'none'; default_highlight?: boolean; pan_zoom?: boolean;
    image_rendering?: 'smooth' | 'pixelated';
  };
  assets?: Record<string, Asset>;
  layers: Layer[];
  regions?: Region[];
  groups?: Record<string, { label: string; description?: string; regions: string[] }>;
  panels?: Record<string, { title: string; text: string }>;
  animations?: Record<string, Animation>;
  events?: { document_load?: Action[] };
  default_state?: {
    selected?: string[]; panel?: string | null;
    view?: { zoom?: number | 'fit'; centre_x?: number; centre_y?: number };
  };
  preview: string;
  thumbnail?: string;
  redaction?: { method: 'fill'; colour?: string; regions: string[]; tool?: string };
}

/** One validation finding. Codes are shared with the Python validator. */
export interface Issue {
  code: string;
  path: string;
  message: string;
}

export const isError = (issue: Issue): boolean => !issue.code.startsWith('W_');
export const errorsOnly = (issues: Issue[]): Issue[] => issues.filter(isError);

export class AavError extends Error {
  issues: Issue[];
  constructor(issues: Issue[] | Issue | string) {
    const list = typeof issues === 'string' ? [{ code: 'E_INTERNAL', path: '', message: issues }]
      : Array.isArray(issues) ? issues : [issues];
    super(list.slice(0, 5).map((i) => `${i.code}${i.path ? ' at ' + i.path : ''}: ${i.message}`).join('; '));
    this.name = 'AavError';
    this.issues = list;
  }
}

/** A document in memory: manifest plus every other archive entry. */
export interface AavPackage {
  manifest: Manifest;
  files: Map<string, Uint8Array>;
}
