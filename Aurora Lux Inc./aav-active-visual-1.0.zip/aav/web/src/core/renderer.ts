/**
 * Scene renderer: composites a document at document resolution with Canvas 2D.
 *
 * The output of `render()` is the reference raster of the document in a given
 * interaction state. Viewers scale that raster to the screen; static export
 * writes it out unchanged. Render order (SPEC section 8):
 *
 *   for each visible layer, bottom to top:
 *     draw the layer (clip, transform; opacity applied when it is composited)
 *     for each region targeting it, in manifest order:
 *       pixel effects on the layer's pixels inside the region
 *     composite the layer
 *     for each region targeting it: overlay effects (glow, outline)
 *   for each region without a target layer, in manifest order:
 *     pixel effects on the composite, then overlay effects
 */
import { clampRect, layerBox, layerTransform, shapeCentre } from './geometry';
import type { Rect } from './geometry';
import type { MaskAlpha } from './hittest';
import { LIMITS } from './limits';
import { blockSize, blur, blurAlpha, blurReach, buildChain, isIdentityChain, maskOutline, parseColour, pixelate } from './pixels';
import type { PixelBuffer } from './pixels';
import { Machine } from './state';
import type { ResolvedEffect } from './state';
import type { AavPackage, Layer, Manifest, Region, Shape, TextLayer } from './types';
import { AavError } from './types';
import { shapeBounds } from './validate';
import { createBackend } from './webgl';
import type { ColourBackend } from './webgl';

export interface DecodedAsset { image: CanvasImageSource; width: number; height: number }

/** What the renderer needs to know about interaction state. `Machine` satisfies this. */
export interface RenderSource {
  effectsFor(regionId: string, t: number): ResolvedEffect[];
  isLayerVisible(layerId: string): boolean;
  pointer: { x: number; y: number } | null;
  hovered: string | null;
}

type Ctx = CanvasRenderingContext2D;

export function makeCanvas(width: number, height: number, readback = false): { canvas: HTMLCanvasElement; ctx: Ctx } {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(width));
  canvas.height = Math.max(1, Math.round(height));
  const ctx = canvas.getContext('2d', { willReadFrequently: readback });
  if (!ctx) throw new AavError('Canvas 2D is not available in this browser');
  return { canvas, ctx };
}

/** Decode every asset of a validated package. Embedded colour profiles are ignored (assets are treated as sRGB). */
export async function decodeAssets(pkg: AavPackage): Promise<Map<string, DecodedAsset>> {
  const out = new Map<string, DecodedAsset>();
  for (const [id, asset] of Object.entries(pkg.manifest.assets ?? {})) {
    const data = pkg.files.get(asset.path);
    if (!data) throw new AavError({ code: 'E_ARCHIVE_MISSING', path: asset.path, message: `asset '${id}' has no file` });
    try {
      const bitmap = await createImageBitmap(new Blob([data as Uint8Array<ArrayBuffer>], { type: asset.media_type }),
        { colorSpaceConversion: 'none' });
      if (bitmap.width > LIMITS.image.max_dimension || bitmap.height > LIMITS.image.max_dimension) {
        throw new Error('decoded image exceeds the size limit');
      }
      out.set(id, { image: bitmap, width: bitmap.width, height: bitmap.height });
    } catch (err) {
      throw new AavError({ code: 'E_ASSET_TYPE', path: asset.path, message: `asset '${id}' could not be decoded: ${(err as Error).message}` });
    }
  }
  return out;
}

/** Extract the alpha channel of each asset used as a region mask, for hit testing. */
export function extractMaskAlpha(manifest: Manifest, assets: ReadonlyMap<string, DecodedAsset>): Map<string, MaskAlpha> {
  const out = new Map<string, MaskAlpha>();
  for (const region of manifest.regions ?? []) {
    if (region.shape.type !== 'mask' || out.has(region.shape.asset)) continue;
    const asset = assets.get(region.shape.asset);
    if (!asset) continue;
    const { ctx } = makeCanvas(asset.width, asset.height, true);
    ctx.drawImage(asset.image, 0, 0);
    const rgba = ctx.getImageData(0, 0, asset.width, asset.height).data;
    const alpha = new Uint8Array(asset.width * asset.height);
    for (let i = 0; i < alpha.length; i++) alpha[i] = rgba[i * 4 + 3];
    out.set(region.shape.asset, { width: asset.width, height: asset.height, data: alpha });
  }
  return out;
}

/** Trace a rectangle or polygon as the current path, in document coordinates. Returns false for masks. */
export function tracePath(ctx: Ctx, shape: Shape): boolean {
  ctx.beginPath();
  if (shape.type === 'rect') ctx.rect(shape.x, shape.y, shape.width, shape.height);
  else if (shape.type === 'polygon') {
    shape.points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.closePath();
  } else return false;
  return true;
}

export interface TextLayout { lines: string[]; widths: number[]; width: number; height: number; left: number; top: number;
  lineHeight: number; fontSize: number }

/** Split on newlines, then greedy word-wrap to max_width. Same algorithm as text_lines in render.py. */
export function layoutText(layer: TextLayer, measure: (text: string) => number): TextLayout {
  const lines: string[] = [];
  for (const raw of layer.text.split('\n')) {
    if (layer.max_width === undefined) {
      lines.push(raw);
      continue;
    }
    let current = '';
    for (const word of raw.split(' ')) {
      const trial = current ? current + ' ' + word : word;
      if (current && measure(trial) > layer.max_width) {
        lines.push(current);
        current = word;
      } else current = trial;
    }
    lines.push(current);
  }
  const fontSize = layer.font_size ?? 24;
  const lineHeight = fontSize * (layer.line_height ?? 1.25);
  const widths = lines.map(measure);
  const width = Math.max(0, ...widths);
  const align = layer.align ?? 'left';
  const left = layer.x - (align === 'centre' ? width / 2 : align === 'right' ? width : 0);
  return { lines, widths, width, height: lineHeight * lines.length, left, top: layer.y, lineHeight, fontSize };
}

export const textFont = (layer: TextLayer): string =>
  `${layer.font_weight ?? 400} ${layer.font_size ?? 24}px ${layer.font_family ?? 'sans-serif'}`;

export function drawTextLayer(ctx: Ctx, layer: TextLayer): TextLayout {
  ctx.font = textFont(layer);
  ctx.textBaseline = 'top';
  ctx.textAlign = 'left';
  const layout = layoutText(layer, (s) => ctx.measureText(s).width);
  if (layer.background) {
    const pad = layer.padding ?? 6;
    ctx.fillStyle = layer.background;
    ctx.fillRect(layout.left - pad, layout.top - pad, layout.width + 2 * pad, layout.height + 2 * pad);
  }
  ctx.fillStyle = layer.colour ?? '#FFFFFF';
  const align = layer.align ?? 'left';
  layout.lines.forEach((line, i) => {
    const x = layout.left + (layout.width - layout.widths[i]) * (align === 'centre' ? 0.5 : align === 'right' ? 1 : 0);
    ctx.fillText(line, x, layout.top + i * layout.lineHeight + (layout.lineHeight - layout.fontSize) / 2);
  });
  return layout;
}

const rgbCss = (c: { r: number; g: number; b: number }): string =>
  `rgb(${Math.round(c.r * 255)}, ${Math.round(c.g * 255)}, ${Math.round(c.b * 255)})`;

export class SceneRenderer {
  manifest: Manifest;
  readonly assets: ReadonlyMap<string, DecodedAsset>;
  masks: Map<string, MaskAlpha>;
  readonly surface: HTMLCanvasElement;
  readonly backend: ColourBackend;
  private ctx: Ctx;
  private scratch: { canvas: HTMLCanvasElement; ctx: Ctx } | null = null;
  private work = makeCanvas(1, 1, true);
  private stampCanvas = makeCanvas(1, 1);
  private coverageCache = new Map<string, { rect: Rect; alpha: Uint8ClampedArray }>();
  private glowCache = new Map<string, { rect: Rect; alpha: Float32Array }>();
  private outlineCache = new Map<string, { rect: Rect; alpha: Uint8ClampedArray }>();

  constructor(manifest: Manifest, assets: ReadonlyMap<string, DecodedAsset>,
              options: { backend?: 'auto' | 'cpu' | 'webgl2' } = {}) {
    this.manifest = manifest;
    this.assets = assets;
    const made = makeCanvas(manifest.document.width, manifest.document.height, true);
    this.surface = made.canvas;
    this.ctx = made.ctx;
    this.backend = createBackend(options.backend ?? 'auto');
    this.masks = extractMaskAlpha(manifest, assets);
  }

  /** Swap in an edited manifest with the same assets (editor use). Drops geometry caches. */
  setManifest(manifest: Manifest): void {
    const { width, height } = manifest.document;
    if (width !== this.surface.width || height !== this.surface.height) {
      this.surface.width = width;
      this.surface.height = height;
      this.scratch = null;
    }
    this.manifest = manifest;
    this.masks = extractMaskAlpha(manifest, this.assets);
    this.clearCaches();
  }

  clearCaches(): void {
    this.coverageCache.clear();
    this.glowCache.clear();
    this.outlineCache.clear();
  }

  dispose(): void {
    this.backend.dispose();
    this.clearCaches();
  }

  private get docW(): number { return this.manifest.document.width; }
  private get docH(): number { return this.manifest.document.height; }

  /** Render the document in the given state at time `t` (ms). Returns the document-resolution surface. */
  render(source: RenderSource, t: number): HTMLCanvasElement {
    const { ctx, manifest } = this;
    const regions = manifest.regions ?? [];
    const resolved = new Map<string, ResolvedEffect[]>();
    for (const region of regions) resolved.set(region.id, source.effectsFor(region.id, t));
    const layerIds = new Set(manifest.layers.map((l) => l.id));

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, this.docW, this.docH);
    const background = manifest.document.background;
    if (background) {
      ctx.fillStyle = background;
      ctx.fillRect(0, 0, this.docW, this.docH);
    }

    for (const layer of manifest.layers) {
      if (!source.isLayerVisible(layer.id)) continue;
      const targeting = regions.filter((r) => r.target_layer === layer.id && resolved.get(r.id)!.length > 0);
      const needsPixels = targeting.some((r) => this.hasActivePixelEffects(r, resolved.get(r.id)!, source));
      const opacity = layer.opacity ?? 1;
      if (needsPixels) {
        const scratch = this.getScratch();
        scratch.ctx.setTransform(1, 0, 0, 1, 0, 0);
        scratch.ctx.clearRect(0, 0, this.docW, this.docH);
        this.drawLayer(scratch.ctx, layer);
        for (const region of targeting) this.applyPixelEffects(scratch.ctx, region, resolved.get(region.id)!, source);
        ctx.globalAlpha = opacity;
        ctx.drawImage(scratch.canvas, 0, 0);
        ctx.globalAlpha = 1;
      } else if (opacity >= 1) {
        this.drawLayer(ctx, layer);
      } else {
        // Group opacity: render the layer on its own, then fade it as a whole.
        const scratch = this.getScratch();
        scratch.ctx.setTransform(1, 0, 0, 1, 0, 0);
        scratch.ctx.clearRect(0, 0, this.docW, this.docH);
        this.drawLayer(scratch.ctx, layer);
        ctx.globalAlpha = opacity;
        ctx.drawImage(scratch.canvas, 0, 0);
        ctx.globalAlpha = 1;
      }
      for (const region of targeting) this.drawOverlayEffects(ctx, region, resolved.get(region.id)!);
    }

    for (const region of regions) {
      if (region.target_layer !== undefined && layerIds.has(region.target_layer)) continue;
      const effects = resolved.get(region.id)!;
      if (!effects.length) continue;
      this.applyPixelEffects(ctx, region, effects, source);
      this.drawOverlayEffects(ctx, region, effects);
    }
    return this.surface;
  }

  private getScratch(): { canvas: HTMLCanvasElement; ctx: Ctx } {
    this.scratch ??= makeCanvas(this.docW, this.docH, true);
    return this.scratch;
  }

  private drawLayer(ctx: Ctx, layer: Layer): void {
    ctx.save();
    if (layer.clip) {
      ctx.beginPath();
      ctx.rect(layer.clip.x, layer.clip.y, layer.clip.width, layer.clip.height);
      ctx.clip();
    }
    const m = layerTransform(layer, this.docW, this.docH);
    ctx.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
    if (layer.type === 'image') {
      const asset = this.assets.get(layer.asset);
      if (asset) {
        const box = layerBox(layer, this.docW, this.docH);
        ctx.imageSmoothingEnabled = this.manifest.settings?.image_rendering !== 'pixelated';
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(asset.image, box.x, box.y, box.width, box.height);
      }
    } else if (layer.type === 'text') {
      drawTextLayer(ctx, layer);
    }
    ctx.restore();
  }

  /** Paint the region's coverage (opaque where the region is) in document coordinates. */
  paintCoverage(ctx: Ctx, region: Region): void {
    const shape = region.shape;
    if (tracePath(ctx, shape)) {
      ctx.fillStyle = '#fff';
      ctx.fill('evenodd');
    } else if (shape.type === 'mask') {
      const asset = this.assets.get(shape.asset);
      if (asset) {
        ctx.imageSmoothingEnabled = true;
        ctx.drawImage(asset.image, shape.x ?? 0, shape.y ?? 0, shape.width ?? this.docW, shape.height ?? this.docH);
      }
    }
  }

  private pixelParams(region: Region, effects: ResolvedEffect[], source: RenderSource) {
    let block = 1, blurRadius = 0;
    for (const e of effects) {
      if (e.type === 'pixelate') block = blockSize(e.props.block_size);
      else if (e.type === 'blur') blurRadius = typeof e.props.radius === 'number' ? e.props.radius : 0;
    }
    const centre = shapeCentre(region.shape, this.docW, this.docH);
    const chain = buildChain(effects, centre, source.hovered === region.id ? source.pointer : null);
    return { block, blurRadius, chain };
  }

  private hasActivePixelEffects(region: Region, effects: ResolvedEffect[], source: RenderSource): boolean {
    const { block, blurRadius, chain } = this.pixelParams(region, effects, source);
    return block > 1 || blurRadius > 0 || !isIdentityChain(chain);
  }

  private applyPixelEffects(target: Ctx, region: Region, effects: ResolvedEffect[], source: RenderSource): void {
    const { block, blurRadius, chain } = this.pixelParams(region, effects, source);
    if (block <= 1 && blurRadius <= 0 && isIdentityChain(chain)) return;
    const bounds = shapeBounds(region.shape, this.docW, this.docH);
    let read = clampRect(bounds, this.docW, this.docH, blurReach(blurRadius));
    if (!read || !clampRect(bounds, this.docW, this.docH)) return;
    if (block > 1) {
      // Grow to whole blocks so block averages do not depend on where the region boundary falls.
      const x0 = Math.floor(read.x / block) * block, y0 = Math.floor(read.y / block) * block;
      const x1 = Math.min(this.docW, Math.ceil((read.x + read.width) / block) * block);
      const y1 = Math.min(this.docH, Math.ceil((read.y + read.height) / block) * block);
      read = { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
    }
    const img = target.getImageData(read.x, read.y, read.width, read.height);
    if (block > 1) pixelate(img as PixelBuffer, block, read.x, read.y);
    if (blurRadius > 0) blur(img as PixelBuffer, blurRadius);
    const work = this.work;
    work.canvas.width = read.width;
    work.canvas.height = read.height;
    if (isIdentityChain(chain)) work.ctx.putImageData(img, 0, 0);
    else this.backend.run(img, chain, read.x, read.y, work.ctx);
    // Keep only the part inside the region...
    work.ctx.save();
    work.ctx.globalCompositeOperation = 'destination-in';
    work.ctx.translate(-read.x, -read.y);
    this.paintCoverage(work.ctx, region);
    work.ctx.restore();
    // ...and swap it in for the original pixels: orig*(1-c) + effect*c for coverage c.
    target.save();
    target.setTransform(1, 0, 0, 1, 0, 0);
    target.globalAlpha = 1;
    target.globalCompositeOperation = 'destination-out';
    this.paintCoverage(target, region);
    target.globalCompositeOperation = 'lighter';
    target.drawImage(work.canvas, read.x, read.y);
    target.restore();
  }

  /** Region coverage rasterised at document resolution, padded by `pad` pixels. */
  coverage(region: Region, pad: number): { rect: Rect; alpha: Uint8ClampedArray } | null {
    const key = `${region.id}:${pad}`;
    const cached = this.coverageCache.get(key);
    if (cached) return cached;
    const rect = clampRect(shapeBounds(region.shape, this.docW, this.docH), this.docW, this.docH, pad);
    if (!rect) return null;
    const work = this.work;
    work.canvas.width = rect.width;
    work.canvas.height = rect.height;
    work.ctx.save();
    work.ctx.translate(-rect.x, -rect.y);
    this.paintCoverage(work.ctx, region);
    work.ctx.restore();
    const rgba = work.ctx.getImageData(0, 0, rect.width, rect.height).data;
    const alpha = new Uint8ClampedArray(rect.width * rect.height);
    for (let i = 0; i < alpha.length; i++) alpha[i] = rgba[i * 4 + 3];
    if (this.coverageCache.size > 256) this.coverageCache.clear();
    const entry = { rect, alpha };
    this.coverageCache.set(key, entry);
    return entry;
  }

  /** Put a single-colour image with the given alpha map on a canvas and return it. */
  stamp(rect: Rect, alpha: ArrayLike<number>, colour: { r: number; g: number; b: number }, gain: number): HTMLCanvasElement {
    const { canvas, ctx } = this.stampCanvas;
    canvas.width = rect.width;
    canvas.height = rect.height;
    const img = ctx.createImageData(rect.width, rect.height);
    const r = Math.round(colour.r * 255), g = Math.round(colour.g * 255), b = Math.round(colour.b * 255);
    for (let i = 0, j = 0; i < alpha.length; i++, j += 4) {
      img.data[j] = r; img.data[j + 1] = g; img.data[j + 2] = b; img.data[j + 3] = Math.min(255, alpha[i] * gain);
    }
    ctx.putImageData(img, 0, 0);
    return canvas;
  }

  /** Outline band of a mask region, `lineWidth` document pixels wide (approximate). */
  maskOutline(region: Region, lineWidth: number): { rect: Rect; alpha: Uint8ClampedArray } | null {
    const width = Math.max(1, Math.round(lineWidth));
    const key = `${region.id}:${width}`;
    const cached = this.outlineCache.get(key);
    if (cached) return cached;
    const cov = this.coverage(region, blurReach(width));
    if (!cov) return null;
    if (this.outlineCache.size > 64) this.outlineCache.clear();
    const entry = { rect: cov.rect, alpha: maskOutline(cov.alpha, cov.rect.width, cov.rect.height, width) };
    this.outlineCache.set(key, entry);
    return entry;
  }

  private drawOverlayEffects(ctx: Ctx, region: Region, effects: ResolvedEffect[]): void {
    for (const effect of effects) {
      const p = effect.props;
      if (effect.type === 'glow') {
        const colour = parseColour(String(p.colour));
        const intensity = (typeof p.intensity === 'number' ? p.intensity : 0) * colour.a;
        const radius = typeof p.radius === 'number' ? Math.round(p.radius * 2) / 2 : 0;
        if (intensity <= 0) continue;
        const key = `${region.id}:${radius}`;
        let glow = this.glowCache.get(key);
        if (!glow) {
          const cov = this.coverage(region, blurReach(radius));
          if (!cov) continue;
          if (this.glowCache.size > 64) this.glowCache.clear();
          glow = { rect: cov.rect, alpha: blurAlpha(cov.alpha, cov.rect.width, cov.rect.height, radius) };
          this.glowCache.set(key, glow);
        }
        const stamp = this.stamp(glow.rect, glow.alpha, colour, intensity);
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.drawImage(stamp, glow.rect.x, glow.rect.y);
        ctx.restore();
      } else if (effect.type === 'outline') {
        const colour = parseColour(String(p.colour));
        const width = typeof p.width === 'number' ? p.width : 0;
        const opacity = (typeof p.opacity === 'number' ? p.opacity : 1) * colour.a;
        if (width <= 0 || opacity <= 0) continue;
        ctx.save();
        ctx.globalAlpha = opacity;
        if (tracePath(ctx, region.shape)) {
          ctx.strokeStyle = rgbCss(colour);
          ctx.lineWidth = width;
          ctx.lineJoin = 'round';
          ctx.stroke();
        } else {
          const band = this.maskOutline(region, width);
          if (band) ctx.drawImage(this.stamp(band.rect, band.alpha, colour, 1), band.rect.x, band.rect.y);
        }
        ctx.restore();
      }
    }
  }
}

/** A machine in the document's saved default state with motion settled: the state static exports show. */
export function defaultStateMachine(manifest: Manifest): Machine {
  const machine = new Machine(manifest, { reducedMotion: true, now: () => 0 });
  machine.load();
  return machine;
}

export function canvasToPng(canvas: HTMLCanvasElement): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(async (blob) => {
      if (!blob) reject(new AavError('could not encode PNG'));
      else resolve(new Uint8Array(await blob.arrayBuffer()));
    }, 'image/png');
  });
}

/** Render the default state of a document to PNG bytes at document resolution. */
export async function renderPreviewPng(manifest: Manifest, assets: ReadonlyMap<string, DecodedAsset>,
                                       backend: 'auto' | 'cpu' | 'webgl2' = 'cpu'): Promise<Uint8Array> {
  const renderer = new SceneRenderer(manifest, assets, { backend });
  try {
    return await canvasToPng(renderer.render(defaultStateMachine(manifest), 0));
  } finally {
    renderer.dispose();
  }
}

/** Downscale PNG bytes to a thumbnail of at most `maxSide` pixels. */
export async function makeThumbnail(png: Uint8Array, maxSide = 256): Promise<Uint8Array> {
  const bitmap = await createImageBitmap(new Blob([png as Uint8Array<ArrayBuffer>], { type: 'image/png' }));
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const { canvas, ctx } = makeCanvas(Math.max(1, Math.round(bitmap.width * scale)), Math.max(1, Math.round(bitmap.height * scale)));
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvasToPng(canvas);
}
