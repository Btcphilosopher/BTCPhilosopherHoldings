import { defineConfig } from '@playwright/test';

// End-to-end tests run against the production build, served by `vite preview`.
export default defineConfig({
  testDir: 'e2e',
  timeout: 60_000,
  fullyParallel: true,
  reporter: [['list']],
  use: { baseURL: 'http://127.0.0.1:4179', viewport: { width: 1280, height: 800 }, trace: 'off' },
  webServer: {
    command: 'npx vite preview --port 4179 --strictPort --host 127.0.0.1',
    url: 'http://127.0.0.1:4179/viewer.html',
    reuseExistingServer: true,
    timeout: 60_000,
  },
});
