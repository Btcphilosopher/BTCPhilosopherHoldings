// Copy the standalone viewer bundle to the places that embed it:
//   web/public/standalone/   -> fetched by the editor for "Export HTML"
//   python/src/aav/data/     -> used by `aav export-html` and `aav render --engine browser`
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

const web = resolve(import.meta.dirname, '..');
const sources = {
  'aav-viewer.iife.js': resolve(web, 'dist-standalone', 'aav-viewer.iife.js'),
  'aav-viewer.css': resolve(web, 'dist-standalone', 'aav-viewer.css'),
  'standalone-template.html': resolve(web, 'src', 'core', 'standalone-template.html'),
  'render.mjs': resolve(web, 'scripts', 'render.mjs'),
};
const targets = [resolve(web, 'public', 'standalone'), resolve(web, '..', 'python', 'src', 'aav', 'data')];
for (const [name, from] of Object.entries(sources)) {
  if (!existsSync(from)) {
    console.error(`missing ${from}; run "vite build --config vite.standalone.config.ts" first`);
    process.exit(1);
  }
  for (const dir of targets) {
    if (name === 'render.mjs' && dir.includes('public')) continue;
    mkdirSync(dir, { recursive: true });
    copyFileSync(from, resolve(dir, name));
  }
}
console.log(`embedded viewer bundle into ${targets.length} locations`);
