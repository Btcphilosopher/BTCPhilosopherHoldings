import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { deflateSync } from 'node:zlib';
import type { Page } from '@playwright/test';
import { crc32, readZip, writeZip } from '../src/core/zip';

export const ROOT = resolve(import.meta.dirname, '..', '..');
export const example = (name: string) => resolve(ROOT, 'examples', `${name}.aav`);

/** Encode an RGBA PNG without any image library, so tests control every pixel. */
export function makePng(width: number, height: number, pixel: (x: number, y: number) => [number, number, number, number]): Buffer {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) raw.set(pixel(x, y), y * (width * 4 + 1) + 1 + x * 4);
  }
  const chunk = (type: string, data: Buffer) => {
    const body = Buffer.concat([Buffer.from(type, 'latin1'), data]);
    const out = Buffer.alloc(body.length + 8);
    out.writeUInt32BE(data.length, 0);
    body.copy(out, 4);
    out.writeUInt32BE(crc32(body), body.length + 4);
    return out;
  };
  const header = Buffer.alloc(13);
  header.writeUInt32BE(width, 0);
  header.writeUInt32BE(height, 4);
  header.set([8, 6, 0, 0, 0], 8);
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', header),
    chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

/** Rewrite the manifest of an existing .aav file. The result is NOT re-validated: that is the point of these tests. */
export function doctored(name: string, mutate: (manifest: any, files: Map<string, Uint8Array>) => void): Buffer { // eslint-disable-line @typescript-eslint/no-explicit-any
  const files = readZip(new Uint8Array(readFileSync(example(name))));
  const manifest = JSON.parse(new TextDecoder().decode(files.get('manifest.json')));
  mutate(manifest, files);
  files.set('manifest.json', new TextEncoder().encode(JSON.stringify(manifest)));
  return Buffer.from(writeZip(files));
}

export async function openExample(page: Page, name: string): Promise<void> {
  await page.goto(`/viewer.html?src=examples/${name}.aav`);
  await page.waitForSelector('[data-aav-ready]');
}

/** Client coordinates of a document point in the viewer, through its current view transform. */
export function viewerPoint(page: Page, x: number, y: number): Promise<{ x: number; y: number }> {
  return page.evaluate(([dx, dy]) => {
    const v = (window as any).__aavViewer; // eslint-disable-line @typescript-eslint/no-explicit-any
    const r = v.root.querySelector('.aav-stage').getBoundingClientRect();
    return { x: r.left + dx * v.view.scale + v.view.tx, y: r.top + dy * v.view.scale + v.view.ty };
  }, [x, y]);
}

/** A pixel of the document-resolution reference raster, after a synchronous render. */
export function surfacePixel(page: Page, x: number, y: number): Promise<number[]> {
  return page.evaluate(([dx, dy]) => {
    const v = (window as any).__aavViewer; // eslint-disable-line @typescript-eslint/no-explicit-any
    v.renderNow();
    return [...v.renderer.surface.getContext('2d').getImageData(dx, dy, 1, 1).data];
  }, [x, y]);
}

export const viewerState = (page: Page) => page.evaluate(() => {
  const m = (window as any).__aavViewer.machine; // eslint-disable-line @typescript-eslint/no-explicit-any
  return { hovered: m.hovered as string | null, focused: m.focused as string | null, selected: m.selected as string[],
    panel: m.panel as string | null, tooltip: m.tooltip?.text as string | undefined, animating: m.isAnimating() as boolean };
});

/** Client coordinates of a document point on the editor canvas, derived from the drawn document frame. */
export function editorPoint(page: Page, x: number, y: number): Promise<{ x: number; y: number }> {
  return page.evaluate(([dx, dy]) => {
    const frame = document.querySelector('.doc-frame')!.getBoundingClientRect();
    const manifest = (window as any).__aavEditor.manifest; // eslint-disable-line @typescript-eslint/no-explicit-any
    return { x: frame.left + (dx / manifest.document.width) * frame.width, y: frame.top + (dy / manifest.document.height) * frame.height };
  }, [x, y]);
}

export const editorManifest = (page: Page) => page.evaluate(() => (window as any).__aavEditor.manifest); // eslint-disable-line @typescript-eslint/no-explicit-any
export const editorInfo = (page: Page) => page.evaluate(() => {
  const e = (window as any).__aavEditor; // eslint-disable-line @typescript-eslint/no-explicit-any
  return { issues: e.issues as { code: string; path: string }[], dirty: e.dirty as boolean, undoDepth: e.undoDepth as number, redoDepth: e.redoDepth as number };
});

/** Run the Python CLI on a file. Returns null if Python or the aav package is not installed here. */
export function pythonAav(args: string[]): { status: number; output: string } | null {
  try {
    execFileSync('python3', ['-c', 'import aav'], { stdio: 'ignore' });
  } catch {
    return null;
  }
  try {
    return { status: 0, output: execFileSync('python3', ['-m', 'aav', ...args], { encoding: 'utf-8', stdio: ['ignore', 'pipe', 'pipe'] }) };
  } catch (error) {
    const e = error as { status?: number; stdout?: string; stderr?: string };
    return { status: e.status ?? 1, output: `${e.stdout ?? ''}${e.stderr ?? ''}` };
  }
}
