import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { expect, test } from '@playwright/test';
import type { Download, Page } from '@playwright/test';
import { sniffImage } from '../src/core/imageinfo';
import { readZip } from '../src/core/zip';
import { editorInfo, editorManifest, editorPoint, example, makePng, pythonAav, viewerPoint, viewerState } from './helpers';

/** A 400x300 test photo: a gradient with a magenta "sensitive" block at (100..200, 80..160). */
const photo = makePng(400, 300, (x, y) => (x >= 100 && x < 200 && y >= 80 && y < 160 ? [250, 10, 200, 255] : [x % 256, (y * 2) % 256, 60, 255]));
const upload = (name: string, buffer: Buffer) => ({ name, mimeType: 'application/octet-stream', buffer });

async function importPhoto(page: Page): Promise<void> {
  await page.goto('/editor.html');
  await page.setInputFiles('input[aria-label="Choose an image to import"]', upload('holiday photo.png', photo));
  await page.waitForSelector('[data-testid="stage"]');
}

async function drag(page: Page, from: [number, number], to: [number, number]): Promise<void> {
  const a = await editorPoint(page, ...from), b = await editorPoint(page, ...to);
  await page.mouse.move(a.x, a.y);
  await page.mouse.down();
  await page.mouse.move((a.x + b.x) / 2, (a.y + b.y) / 2, { steps: 3 });
  await page.mouse.move(b.x, b.y, { steps: 3 });
  await page.mouse.up();
}

async function drawRect(page: Page, from: [number, number], to: [number, number]): Promise<void> {
  await page.getByRole('button', { name: 'Rectangle', exact: true }).click();
  await drag(page, from, to);
  await page.waitForSelector('[data-testid="region-inspector"]');
}

async function saved(page: Page, trigger: () => Promise<void>, path: string): Promise<Download> {
  const [download] = await Promise.all([page.waitForEvent('download'), trigger()]);
  await download.saveAs(path);
  return download;
}

test.describe('editor', () => {
  test('core workflow: import, draw, highlight, panel, preview, save, reopen, export', async ({ page }, testInfo) => {
    // 1. Import an image.
    await importPhoto(page);
    let m = await editorManifest(page);
    expect(m.document).toMatchObject({ id: 'holiday-photo', title: 'holiday photo', width: 400, height: 300 });
    expect(m.layers).toEqual([{ id: 'background', type: 'image', asset: 'base', name: 'Background' }]);

    // 2. Draw a region.
    await drawRect(page, [100, 80], [200, 160]);
    m = await editorManifest(page);
    expect(m.regions).toHaveLength(1);
    expect(m.regions[0]).toMatchObject({ id: 'region-1', target_layer: 'background', shape: { type: 'rect', x: 100, y: 80, width: 100, height: 80 } });
    await page.getByLabel('Name (read by screen readers)').fill('Harbour');
    await page.getByLabel('Description (accessibility)').fill('The harbour entrance.');

    // 3. Assign a highlight.
    await page.getByRole('button', { name: 'Add highlight (outline + tint)' }).click();
    m = await editorManifest(page);
    expect(Object.keys(m.regions[0].effects)).toEqual(['edge', 'wash']);
    expect(m.regions[0].states.hover).toEqual({ edge: { opacity: 1 }, wash: { amount: 0.16 } });

    // 4. Create a panel and open it on activation.
    await page.getByRole('tab', { name: 'Panels' }).click();
    await page.getByRole('button', { name: '+ Panel' }).click();
    await page.getByLabel('Title').fill('Harbour notes');
    await page.getByLabel('Text', { exact: true }).fill('Built in **1887**. See the [guide](https://example.org/harbour).');
    await expect(page.locator('.text-preview strong')).toHaveText('1887');
    await page.getByRole('tab', { name: 'Selection' }).click();
    await page.locator('.list-main', { hasText: 'Harbour' }).click();
    const activate = page.locator('details.trigger', { hasText: 'Activate' });
    await activate.locator('summary').click();
    await activate.getByRole('button', { name: 'Add action' }).click();
    m = await editorManifest(page);
    expect(m.regions[0].events).toEqual({ activate: [{ action: 'open_panel', panel: 'panel-1' }] });
    expect((await editorInfo(page)).issues).toEqual([]);
    await expect(page.locator('.badge')).toHaveText('No problems');

    // 5. Preview the interaction with the real viewer.
    await page.getByRole('button', { name: 'Preview', exact: true }).click();
    await page.waitForSelector('[data-testid="preview"] [data-aav-ready]');
    const p = await viewerPoint(page, 150, 120);
    await page.mouse.move(p.x, p.y);
    expect(await viewerState(page)).toMatchObject({ hovered: 'region-1' });
    await page.mouse.click(p.x, p.y);
    expect(await viewerState(page)).toMatchObject({ selected: ['region-1'], panel: 'panel-1' });
    await expect(page.locator('.aav-panel-title')).toHaveText('Harbour notes');
    await page.getByRole('button', { name: 'Edit', exact: true }).click();
    m = await editorManifest(page);
    expect(m.default_state).toBeUndefined(); // previewing changed nothing in the document

    // 6. Save the .aav file.
    const path = testInfo.outputPath('holiday-photo.aav');
    const download = await saved(page, () => page.getByRole('button', { name: 'Save .aav' }).click(), path);
    expect(download.suggestedFilename()).toBe('holiday-photo.aav');
    expect((await editorInfo(page)).dirty).toBe(false);
    const files = readZip(new Uint8Array(readFileSync(path)));
    expect([...files.keys()]).toEqual(['manifest.json', 'preview.png', 'assets/base.png', 'thumbnails/preview.png']);
    expect(Buffer.from(files.get('assets/base.png')!).equals(photo)).toBe(true); // the imported bytes are stored untouched
    expect(sniffImage(files.get('preview.png')!)).toEqual({ mediaType: 'image/png', width: 400, height: 300 });
    const python = pythonAav(['validate', '--strict', path]);
    if (python) expect(python, python.output).toMatchObject({ status: 0 }); // the Python validator accepts browser-written files

    // 7. Reopen it: the document comes back exactly.
    const before = await editorManifest(page);
    await page.reload();
    await page.setInputFiles('input[aria-label="Choose an .aav file to open"]', path);
    await page.waitForSelector('[data-testid="stage"]');
    const after = await editorManifest(page);
    for (const key of ['document', 'layers', 'regions', 'panels']) expect(after[key], key).toEqual(before[key]);
    expect(after.assets.base).toMatchObject({ path: 'assets/base.png', media_type: 'image/png', width: 400, height: 300 });
    expect(after.assets.base.sha256).toMatch(/^[0-9a-f]{64}$/);

    // ...and saving the unchanged document again gives identical bytes.
    const again = testInfo.outputPath('again.aav');
    await saved(page, () => page.getByRole('button', { name: 'Save .aav' }).click(), again);
    expect(readFileSync(again).equals(readFileSync(path))).toBe(true);

    // 8. Export the static preview.
    const png = testInfo.outputPath('preview.png');
    const exported = await saved(page, () => page.getByRole('button', { name: 'Export PNG' }).click(), png);
    expect(exported.suggestedFilename()).toBe('holiday-photo.png');
    expect(sniffImage(new Uint8Array(readFileSync(png)))).toEqual({ mediaType: 'image/png', width: 400, height: 300 });
  });

  test('undo and redo, by button and by keyboard', async ({ page }) => {
    await importPhoto(page);
    await drawRect(page, [20, 20], [120, 90]);
    await drawRect(page, [200, 150], [300, 250]);
    expect((await editorManifest(page)).regions.map((r: { id: string }) => r.id)).toEqual(['region-1', 'region-2']);
    await page.getByRole('button', { name: 'Undo' }).click();
    expect((await editorManifest(page)).regions).toHaveLength(1);
    await page.locator('[data-testid="stage"]').focus();
    await page.keyboard.press('Control+z');
    expect((await editorManifest(page)).regions).toHaveLength(0);
    await expect(page.getByRole('button', { name: 'Undo' })).toBeDisabled();
    await page.keyboard.press('Control+Shift+z');
    await page.getByRole('button', { name: 'Redo' }).click();
    expect((await editorManifest(page)).regions.map((r: { id: string }) => r.id)).toEqual(['region-1', 'region-2']);
    await expect(page.getByRole('button', { name: 'Redo' })).toBeDisabled();
    // A whole drag is one undo step.
    await page.locator('.list-main', { hasText: 'Region 1' }).click();
    const depth = (await editorInfo(page)).undoDepth;
    await drag(page, [70, 55], [170, 105]);
    expect((await editorManifest(page)).regions[0].shape).toMatchObject({ x: 120, y: 70, width: 100, height: 70 });
    expect((await editorInfo(page)).undoDepth).toBe(depth + 1);
    await page.keyboard.press('Control+z');
    expect((await editorManifest(page)).regions[0].shape).toMatchObject({ x: 20, y: 20 });
  });

  test('geometry editing: handles, polygon points, numeric fields and keyboard nudging', async ({ page }) => {
    await importPhoto(page);
    await drawRect(page, [100, 100], [200, 180]);
    await drag(page, [200, 180], [240, 210]); // south-east handle
    expect((await editorManifest(page)).regions[0].shape).toEqual({ type: 'rect', x: 100, y: 100, width: 140, height: 110 });
    await page.getByLabel('Width').fill('60');
    expect((await editorManifest(page)).regions[0].shape.width).toBe(60);
    await page.locator('[data-testid="stage"]').focus();
    await page.keyboard.press('ArrowRight');
    await page.keyboard.press('Shift+ArrowDown');
    expect((await editorManifest(page)).regions[0].shape).toMatchObject({ x: 101, y: 110 });

    // Choosing a tool must not move or rescale the image: the footer hint changes, the canvas does not.
    const frame = () => page.locator('.doc-frame').evaluate((el) => { const r = el.getBoundingClientRect(); return [r.x, r.y, r.width, r.height]; });
    const before = await frame();
    await page.getByRole('button', { name: 'Polygon', exact: true }).click();
    await page.waitForTimeout(150);
    expect(await frame()).toEqual(before);
    for (const point of [[260, 40], [360, 40], [360, 120], [300, 150]] as [number, number][]) {
      const p = await editorPoint(page, ...point);
      await page.mouse.click(p.x, p.y);
    }
    await page.keyboard.press('Enter');
    let m = await editorManifest(page);
    expect(m.regions[1].shape).toEqual({ type: 'polygon', points: [[260, 40], [360, 40], [360, 120], [300, 150]] });
    await drag(page, [360, 40], [380, 20]); // move a vertex
    m = await editorManifest(page);
    expect(m.regions[1].shape.points[1]).toEqual([380, 20]);
    await drag(page, [330, 135], [330, 170]); // drag an edge midpoint to insert a vertex
    expect((await editorManifest(page)).regions[1].shape.points).toHaveLength(5);
    await page.keyboard.press('Delete');
    expect((await editorManifest(page)).regions).toHaveLength(1);
    expect((await editorInfo(page)).issues).toEqual([]);
  });

  test('effects, state overrides and live validation', async ({ page }) => {
    await importPhoto(page);
    await drawRect(page, [100, 80], [200, 160]);
    await page.getByLabel('Add an effect').selectOption('pixelate');
    await page.getByLabel('block_size value').fill('24');
    expect((await editorManifest(page)).regions[0].effects).toEqual({ pixelate: { type: 'pixelate', block_size: 24 } });
    await page.getByLabel('Add an effect').selectOption('tint');
    // Override the tint amount for the hover state only.
    await page.getByRole('tab', { name: 'Hover' }).click();
    await page.locator('.effect', { hasText: 'tint' }).getByLabel('Override amount').check();
    await page.locator('.effect', { hasText: 'tint' }).getByLabel('amount value').fill('0.6');
    let m = await editorManifest(page);
    expect(m.regions[0].states).toEqual({ hover: { tint: { amount: 0.6 } } });
    expect(m.regions[0].effects.tint.amount).toBe(0.25);
    await page.getByRole('tab', { name: 'Saved' }).click();
    // Each effect type can be used once per region, so the used ones are no longer offered.
    const options = await page.getByLabel('Add an effect').locator('option').allTextContents();
    expect(options.some((o) => o.startsWith('pixelate'))).toBe(false);
    expect(options.some((o) => o.startsWith('glow'))).toBe(true);

    // An invalid value is flagged at the field, listed under Problems, and blocks saving.
    await page.locator('.effect', { hasText: 'tint' }).getByLabel('colour', { exact: true }).fill('red');
    await expect(page.locator('.effect', { hasText: 'tint' }).locator('.fld-err')).toHaveText('Use #RRGGBB or #RRGGBBAA');
    await expect(page.locator('.badge')).toHaveText('1 error');
    await expect(page.getByRole('button', { name: 'Save .aav' })).toBeDisabled();
    await expect(page.getByRole('button', { name: 'Preview', exact: true })).toBeDisabled();
    await page.locator('.badge').click();
    await expect(page.locator('[data-testid="error-list"] .err')).toContainText('/regions/0/effects/tint/colour');
    await expect(page.locator('[data-testid="error-list"] .err')).toContainText('E_PATTERN');
    await page.locator('[data-testid="error-list"] .err button').click(); // jumps to the region
    await page.locator('.effect', { hasText: 'tint' }).getByLabel('colour', { exact: true }).fill('#FF8800');
    await expect(page.locator('.badge')).toHaveText('No problems');
    await expect(page.getByRole('button', { name: 'Save .aav' })).toBeEnabled();
  });

  test('dangling references and unsafe links are listed before export', async ({ page }) => {
    await page.goto('/editor.html');
    await page.setInputFiles('input[aria-label="Choose an .aav file to open"]', example('interactive-product'));
    await page.waitForSelector('[data-testid="stage"]');
    await expect(page.locator('.badge')).toHaveText('No problems');
    // Delete a panel that an action and another panel still point at.
    await page.getByRole('tab', { name: 'Panels' }).click();
    await page.locator('[data-testid="panels-editor"] .list-main', { hasText: 'About this camera' }).click();
    await page.getByRole('button', { name: 'Delete' }).click();
    const issues = (await editorInfo(page)).issues;
    expect(issues.length).toBeGreaterThan(5);
    expect([...new Set(issues.map((i) => i.code))]).toEqual(['E_REF']);
    await expect(page.getByRole('button', { name: 'Save .aav' })).toBeDisabled();
    await expect(page.getByRole('button', { name: 'Export HTML' })).toBeDisabled();
    await page.getByRole('button', { name: 'Undo' }).click();
    await expect(page.locator('.badge')).toHaveText('No problems');

    // Link editing: the address is validated as it is typed.
    await page.locator('.list-main', { hasText: 'Open the manual' }).click();
    const address = page.getByLabel('HTTPS address');
    for (const bad of ['javascript:alert(1)', 'http://example.org/', 'https://user:pw@example.org/', 'data:text/html,x']) {
      await address.fill(bad);
      await expect(page.locator('.action .fld-err')).toBeVisible();
      expect((await editorInfo(page)).issues.map((i) => i.code)).toEqual(['E_LINK']);
      await expect(page.getByRole('button', { name: 'Save .aav' })).toBeDisabled();
    }
    await address.fill('https://example.org/new-manual');
    await expect(page.locator('.badge')).toHaveText('No problems');
    // open_link is only offered for the activate trigger.
    const enter = page.locator('details.trigger', { hasText: 'Pointer enters' });
    await enter.locator('summary').click();
    await enter.getByRole('button', { name: 'Add action' }).click();
    const offered = await enter.getByLabel('Action 1').locator('option').allTextContents();
    expect(offered).not.toContain('Open external link');
    expect(offered).toContain('Show tooltip');
  });

  test('a failed import keeps the document being edited', async ({ page }) => {
    await importPhoto(page);
    await drawRect(page, [50, 50], [150, 150]);
    const before = JSON.stringify(await editorManifest(page));
    const depth = (await editorInfo(page)).undoDepth;
    for (const [selector, file] of [
      ['input[aria-label="Choose an .aav file to open"]', upload('junk.aav', Buffer.from('this is not an archive'))],
      ['input[aria-label="Choose an .aav file to open"]', upload('cut.aav', readFileSync(example('illuminated-building')).subarray(0, 3000))],
      ['input[aria-label="Choose an image to import"]', upload('notes.txt', Buffer.from('plain text, not an image'))],
    ] as [string, ReturnType<typeof upload>][]) {
      await page.setInputFiles(selector, file);
      await expect(page.locator('.notice-error')).toBeVisible();
      expect(JSON.stringify(await editorManifest(page))).toBe(before);
      expect((await editorInfo(page)).undoDepth).toBe(depth);
      await page.getByRole('button', { name: 'Dismiss' }).click();
    }
    await expect(page.locator('.list-main', { hasText: 'Region 1' })).toBeVisible();
  });

  test('layers, text labels and mask import', async ({ page }) => {
    await importPhoto(page);
    await page.getByRole('button', { name: '+ Text' }).click();
    await page.getByLabel('Text', { exact: true }).fill('Harbour view');
    let m = await editorManifest(page);
    expect(m.layers[1]).toMatchObject({ type: 'text', text: 'Harbour view', x: 200, y: 150 });
    await page.getByLabel('Show layer Text label').uncheck();
    expect((await editorManifest(page)).layers[1].visible).toBe(false);
    await page.setInputFiles('input[aria-label="Choose an image for a new layer"]',
      upload('badge.png', makePng(40, 40, (x, y) => [255, 200, 0, (x - 20) ** 2 + (y - 20) ** 2 < 380 ? 255 : 0])));
    await page.waitForSelector('[data-testid="layer-inspector"]');
    m = await editorManifest(page);
    expect(m.layers[2]).toMatchObject({ type: 'image', asset: 'badge', width: 40, height: 40 });
    expect(m.assets.badge).toEqual({ path: 'assets/badge.png', media_type: 'image/png' });
    await page.getByLabel('Move badge.png down').click();
    expect((await editorManifest(page)).layers.map((l: { id: string }) => l.id)).toEqual(['background', 'overlay-1', 'text-1']);

    await drawRect(page, [100, 80], [200, 160]);
    // An opaque black-and-white picture becomes an alpha mask (white = inside).
    await page.setInputFiles('input[aria-label="Choose a mask image"]', upload('shape.png', makePng(20, 16, (x) => (x < 10 ? [255, 255, 255, 255] : [0, 0, 0, 255]))));
    await expect(page.locator('[data-testid="region-inspector"] h3', { hasText: 'Geometry (mask)' })).toBeVisible();
    m = await editorManifest(page);
    expect(m.regions[0].shape).toEqual({ type: 'mask', asset: 'region-1-mask', x: 100, y: 80, width: 100, height: 80, threshold: 0.5, hit_test: 'alpha' });
    expect(m.assets['region-1-mask'].path).toBe('masks/region-1-mask.png');
    expect((await editorInfo(page)).issues).toEqual([]);
    // In preview, only the left (white) half of the mask responds.
    await page.getByRole('button', { name: 'Preview', exact: true }).click();
    await page.waitForSelector('[data-testid="preview"] [data-aav-ready]');
    const right = await viewerPoint(page, 180, 120), left = await viewerPoint(page, 120, 120);
    await page.mouse.click(right.x, right.y);
    expect((await viewerState(page)).selected).toEqual([]);
    await page.mouse.click(left.x, left.y);
    expect((await viewerState(page)).selected).toEqual(['region-1']);
  });

  test('preview state is saved only when deliberately captured', async ({ page }) => {
    await importPhoto(page);
    await drawRect(page, [100, 80], [200, 160]);
    await page.getByRole('button', { name: 'Preview', exact: true }).click();
    await page.waitForSelector('[data-testid="preview"] [data-aav-ready]');
    const p = await viewerPoint(page, 150, 120);
    await page.mouse.click(p.x, p.y);
    expect((await viewerState(page)).selected).toEqual(['region-1']);
    expect((await editorManifest(page)).default_state).toBeUndefined();
    expect((await editorInfo(page)).undoDepth).toBe(1); // interacting with the preview is not an edit
    await page.getByRole('tab', { name: 'Document' }).click();
    await page.getByRole('button', { name: 'Capture current preview state' }).click();
    expect((await editorManifest(page)).default_state).toEqual({ selected: ['region-1'], panel: null });
    await page.getByRole('button', { name: 'Clear', exact: true }).click();
    expect((await editorManifest(page)).default_state).toBeUndefined();
  });

  test('redacted copy: pixels are destroyed, the original and the open document are not', async ({ page }, testInfo) => {
    await importPhoto(page);
    await drawRect(page, [100, 80], [200, 160]);
    await page.getByLabel('Name (read by screen readers)').fill('Sensitive');
    await page.getByLabel('Add an effect').selectOption('pixelate');
    await drawRect(page, [300, 200], [380, 280]);

    // A normal save keeps the original pixels, pixelation effect or not: it is display only.
    const plain = testInfo.outputPath('plain.aav');
    await saved(page, () => page.getByRole('button', { name: 'Save .aav' }).click(), plain);
    expect(Buffer.from(readZip(new Uint8Array(readFileSync(plain))).get('assets/base.png')!).equals(photo)).toBe(true);

    await page.getByRole('button', { name: 'Redacted copy…' }).click();
    const dialog = page.locator('dialog.dialog');
    await expect(dialog).toContainText('Pixelation and blur effects only change how the image is displayed');
    await expect(dialog.getByRole('button', { name: 'Export redacted copy' })).toBeDisabled();
    await dialog.getByLabel('Sensitive').check();
    const path = testInfo.outputPath('redacted.aav');
    const download = await saved(page, () => dialog.getByRole('button', { name: 'Export redacted copy' }).click(), path);
    expect(download.suggestedFilename()).toBe('holiday-photo-redacted.aav');
    await expect(page.locator('.notice-info')).toContainText('permanently filled');

    const files = readZip(new Uint8Array(readFileSync(path)));
    const manifest = JSON.parse(new TextDecoder().decode(files.get('manifest.json')));
    expect(manifest.redaction).toMatchObject({ method: 'fill', colour: '#000000', regions: ['region-1'] });
    expect([...files.keys()].sort()).toEqual(['assets/base.png', 'manifest.json', 'preview.png', 'thumbnails/preview.png']);
    // Decode every image in the redacted file and look for the magenta block or anything like it.
    const scan = await page.evaluate(async (images: number[][]) => {
      const out: { magenta: number; insideNotBlack: number; outsideChanged: number }[] = [];
      for (const bytes of images) {
        const bitmap = await createImageBitmap(new Blob([new Uint8Array(bytes)], { type: 'image/png' }));
        const c = document.createElement('canvas'); c.width = bitmap.width; c.height = bitmap.height;
        const ctx = c.getContext('2d')!; ctx.drawImage(bitmap, 0, 0);
        const d = ctx.getImageData(0, 0, c.width, c.height).data;
        const sx = c.width / 400, sy = c.height / 300;
        let magenta = 0, insideNotBlack = 0, outsideChanged = 0;
        for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) {
          const i = (y * c.width + x) * 4;
          if (d[i] > 200 && d[i + 1] < 60 && d[i + 2] > 150) magenta++;
          const dx = x / sx, dy = y / sy;
          if (sx === 1 && dx >= 100 && dx < 200 && dy >= 80 && dy < 160 && (d[i] || d[i + 1] || d[i + 2] || d[i + 3] !== 255)) insideNotBlack++;
          if (sx === 1 && (dx < 96 || dx >= 204 || dy < 76 || dy >= 164) && (d[i] !== x % 256 || d[i + 1] !== (y * 2) % 256 || d[i + 2] !== 60)) outsideChanged++;
        }
        out.push({ magenta, insideNotBlack, outsideChanged });
      }
      return out;
    }, ['assets/base.png', 'preview.png', 'thumbnails/preview.png'].map((n) => [...files.get(n)!]));
    expect(scan.map((s) => s.magenta)).toEqual([0, 0, 0]);
    expect(scan[0]).toEqual({ magenta: 0, insideNotBlack: 0, outsideChanged: 0 }); // filled inside, untouched outside
    expect(Buffer.from(files.get('assets/base.png')!).equals(photo)).toBe(false);
    const python = pythonAav(['validate', '--strict', path]);
    if (python) expect(python, python.output).toMatchObject({ status: 0 });

    // The open document and its history are unchanged.
    const m = await editorManifest(page);
    expect(m.redaction).toBeUndefined();
    expect(m.regions).toHaveLength(2);
  });

  test('standalone HTML export works from disk with no network access', async ({ page, context }, testInfo) => {
    await page.goto('/editor.html');
    await page.setInputFiles('input[aria-label="Choose an .aav file to open"]', example('illuminated-building'));
    await page.waitForSelector('[data-testid="stage"]');
    const path = testInfo.outputPath('building.html');
    await saved(page, () => page.getByRole('button', { name: 'Export HTML' }).click(), path);
    const html = readFileSync(path, 'utf-8');
    expect(html).toContain("default-src 'none'");
    expect(html).toMatch(/script-src 'sha256-[A-Za-z0-9+/=]+'/);
    expect(html).not.toMatch(/<script[^>]+src=/);
    expect(html).not.toMatch(/<link[^>]+href=/);
    expect(html).toContain('<li>Entrance door</li>');

    const offline = await context.newPage();
    const requests: string[] = [];
    const errors: string[] = [];
    offline.on('request', (r) => requests.push(r.url()));
    offline.on('console', (msg) => { if (msg.type() === 'error') errors.push(msg.text()); });
    offline.on('pageerror', (e) => errors.push(e.message));
    await offline.goto(pathToFileURL(path).href);
    await offline.waitForSelector('[data-aav-ready]');
    await expect(offline.locator('.aav-side h1')).toHaveText('Illuminated Building');
    await expect(offline.locator('#aav-fallback')).toHaveCount(0);
    const p = await viewerPoint(offline, 690, 590);
    await offline.mouse.click(p.x, p.y);
    expect(await viewerState(offline)).toMatchObject({ selected: ['window-22'], panel: 'room-second' });
    expect(requests.filter((u) => !u.startsWith('file:') && !u.startsWith('blob:') && !u.startsWith('data:'))).toEqual([]);
    expect(errors).toEqual([]); // in particular, no Content-Security-Policy violations

    // Without JavaScript the page still shows the static image and the region names.
    const noScript = await (await context.browser()!.newContext({ javaScriptEnabled: false })).newPage();
    await noScript.goto(pathToFileURL(path).href);
    await expect(noScript.locator('#aav-fallback img')).toBeVisible();
    expect(await noScript.locator('#aav-fallback img').evaluate((img: HTMLImageElement) => [img.naturalWidth, img.alt.length > 20])).toEqual([1600, true]);
    await expect(noScript.locator('#aav-fallback li')).toHaveCount(16);
    await noScript.context().close();

    // The Python exporter produces the same page structure from the same template.
    const pythonPath = testInfo.outputPath('python.html');
    const python = pythonAav(['export-html', example('illuminated-building'), '--output', pythonPath]);
    if (python) {
      expect(python.status, python.output).toBe(0);
      await offline.goto(pathToFileURL(pythonPath).href);
      await offline.waitForSelector('[data-aav-ready]');
      await expect(offline.locator('.aav-region-item')).toHaveCount(16);
      expect(errors).toEqual([]);
    }
    writeFileSync(testInfo.outputPath('done'), '');
  });

  test('the editor is operable from the keyboard and labelled for assistive technology', async ({ page }) => {
    await importPhoto(page);
    await drawRect(page, [100, 80], [200, 160]);
    // Every form control in the inspector has an accessible name.
    const unnamed = await page.evaluate(() => [...document.querySelectorAll<HTMLElement>('input, select, textarea, button')]
      .filter((el) => el.offsetParent !== null || el.classList.contains('visually-hidden'))
      .filter((el) => {
        const id = el.getAttribute('id');
        const labelled = el.getAttribute('aria-label') || el.getAttribute('title') || (id && document.querySelector(`label[for="${CSS.escape(id)}"]`)) || el.closest('label');
        return !labelled && !(el.textContent ?? '').trim();
      }).map((el) => el.outerHTML.slice(0, 80)));
    expect(unnamed).toEqual([]);
    await expect(page.locator('[data-testid="stage"]')).toHaveAttribute('aria-label', /Editing canvas, 1 regions/);
    // Tools can be chosen and a region selected without a mouse.
    await page.getByRole('button', { name: 'Pan', exact: true }).focus();
    await page.keyboard.press('Enter');
    await expect(page.getByRole('button', { name: 'Pan', exact: true })).toHaveAttribute('aria-pressed', 'true');
    await page.locator('.list-main', { hasText: 'Region 1' }).focus();
    await page.keyboard.press('Enter');
    await expect(page.locator('[data-testid="region-inspector"]')).toBeVisible();
    const colours = await page.evaluate(() => {
      const css = getComputedStyle(document.documentElement);
      return [css.getPropertyValue('--aav-graphite-900'), css.getPropertyValue('--aav-ivory'), css.getPropertyValue('--aav-cyan'), css.getPropertyValue('--aav-violet')].map((c) => c.trim());
    });
    expect(colours).toEqual(['#15171a', '#f4f0e6', '#5ad8e6', '#a78bfa']);
  });
});
