import { readFileSync } from 'node:fs';
import { expect, test } from '@playwright/test';
import { doctored, example, openExample, surfacePixel, viewerPoint, viewerState } from './helpers';

test.describe('viewer', () => {
  test('opens a document without contacting any other origin', async ({ page }) => {
    const requests: string[] = [];
    page.on('request', (r) => requests.push(r.url()));
    await openExample(page, 'illuminated-building');
    await expect(page.locator('.aav-side h1')).toHaveText('Illuminated Building');
    await expect(page.locator('.aav-canvas')).toHaveAttribute('role', 'img');
    await expect(page.locator('.aav-region-item')).toHaveCount(16);
    expect(requests.length).toBeGreaterThan(2);
    expect(requests.filter((u) => !u.startsWith('http://127.0.0.1:4179/') && !u.startsWith('blob:'))).toEqual([]);
    expect(await viewerState(page)).toMatchObject({ selected: [], panel: null, hovered: null });
  });

  test('hover lights the window under the pointer only, and leaving restores it', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' }); // transitions become instant, so pixels can be compared exactly
    await openExample(page, 'illuminated-building');
    const inside: [number, number] = [660, 560], neighbour: [number, number] = [890, 560];
    const before = await surfacePixel(page, ...inside), other = await surfacePixel(page, ...neighbour);
    const p = await viewerPoint(page, 690, 590);
    await page.mouse.move(p.x, p.y);
    expect(await viewerState(page)).toMatchObject({ hovered: 'window-22', tooltip: 'Second-floor window 2' });
    await expect(page.locator('.aav-tooltip')).toBeVisible();
    const lit = await surfacePixel(page, ...inside);
    expect(lit[0]).toBeGreaterThan(before[0] + 60);
    expect(lit[1]).toBeGreaterThan(before[1] + 60);
    expect(await surfacePixel(page, ...neighbour)).toEqual(other); // the effect is confined to its region
    const away = await viewerPoint(page, 100, 100);
    await page.mouse.move(away.x, away.y);
    expect(await viewerState(page)).toMatchObject({ hovered: null });
    await expect(page.locator('.aav-tooltip')).toBeHidden();
    expect(await surfacePixel(page, ...inside)).toEqual(before);
  });

  test('keyboard: Tab reaches regions, Enter activates, Escape closes and focus returns', async ({ page }) => {
    await openExample(page, 'illuminated-building');
    await page.locator('.aav-stage').focus();
    await page.keyboard.press('Tab');
    const first = page.locator('.aav-proxy').first();
    await expect(first).toBeFocused();
    await expect(first).toHaveAttribute('aria-label', 'Third-floor window 1');
    expect(await viewerState(page)).toMatchObject({ focused: 'window-31', selected: [] });
    await page.keyboard.press('Tab');
    expect(await viewerState(page)).toMatchObject({ focused: 'window-32' });
    await page.keyboard.press('Enter');
    expect(await viewerState(page)).toMatchObject({ selected: ['window-32'], panel: 'room-third' });
    await expect(page.locator('.aav-panel')).toBeVisible();
    await expect(page.locator('.aav-panel-title')).toBeFocused();
    await expect(page.locator('.aav-proxy[data-region="window-32"]')).toHaveAttribute('aria-pressed', 'true');
    await expect(page.locator('.aav-live')).toHaveText(/Panel opened: Third-floor studio/);
    await page.keyboard.press('Escape');
    await expect(page.locator('.aav-panel')).toBeHidden();
    await expect(page.locator('.aav-proxy[data-region="window-32"]')).toBeFocused();
    await page.keyboard.press('Space');
    expect(await viewerState(page)).toMatchObject({ panel: 'room-third' });
    await expect(page.locator('.aav-panel-title')).toBeFocused();
    // Opening a panel must not pull focus back if the user has already moved on within the same frame.
    await page.keyboard.press('Escape');
    await page.evaluate(() => {
      const proxy = document.querySelector<HTMLElement>('.aav-proxy[data-region="window-32"]')!;
      proxy.click();                                                      // opens the panel; the focus move is pending
      document.querySelector<HTMLElement>('.aav-region-item')!.focus();   // the user goes elsewhere straight away
    });
    await expect(page.locator('.aav-panel')).toBeVisible();
    await page.waitForTimeout(100);
    await expect(page.locator('.aav-region-item').first()).toBeFocused();
    // The region list is one tab stop with arrow-key movement inside it.
    const items = page.locator('.aav-region-item');
    await items.first().focus();
    await page.keyboard.press('ArrowDown');
    await expect(items.nth(1)).toBeFocused();
    expect(await viewerState(page)).toMatchObject({ focused: 'window-32' });
    await page.keyboard.press('End');
    await expect(items.last()).toBeFocused();
    expect(await items.evaluateAll((els) => els.filter((e) => (e as HTMLElement).tabIndex === 0).length)).toBe(1);
  });

  test('keyboard zoom and pan change the view but never the hit target', async ({ page }) => {
    await openExample(page, 'illuminated-building');
    await page.locator('.aav-stage').focus();
    const scale = () => page.evaluate(() => (window as any).__aavViewer.view.scale); // eslint-disable-line @typescript-eslint/no-explicit-any
    const start = await scale();
    await page.keyboard.press('+');
    await page.keyboard.press('+');
    expect(await scale()).toBeCloseTo(start * 1.5625, 5);
    await page.keyboard.press('ArrowLeft');
    await page.keyboard.press('ArrowDown');
    const p = await viewerPoint(page, 920, 420); // third-floor window 3
    await page.mouse.click(p.x, p.y);
    expect(await viewerState(page)).toMatchObject({ selected: ['window-33'] });
    await page.keyboard.press('0');
    expect(await scale()).toBeCloseTo(start, 5);
  });

  test('high-DPI and wheel zoom keep hit testing exact', async ({ browser }) => {
    const context = await browser.newContext({ deviceScaleFactor: 2, viewport: { width: 900, height: 700 } });
    const page = await context.newPage();
    await openExample(page, 'illuminated-building');
    const backing = await page.evaluate(() => { const c = document.querySelector('.aav-canvas') as HTMLCanvasElement; return [c.width, c.clientWidth]; });
    expect(backing[0]).toBe(backing[1] * 2);
    const anchor = await viewerPoint(page, 1150, 760);
    await page.mouse.move(anchor.x, anchor.y);
    await page.mouse.wheel(0, -600);
    await page.mouse.wheel(0, -300);
    for (const [x, y, id] of [[1150, 760, 'window-14'], [1091, 691, 'window-14'], [1209, 829, 'window-14'], [1150, 590, 'window-24']] as [number, number, string][]) {
      const p = await viewerPoint(page, x, y);
      await page.mouse.click(p.x, p.y);
      expect((await viewerState(page)).selected, `${x},${y}`).toEqual([id]);
    }
    const outside = await viewerPoint(page, 1085, 760); // 5 px left of the window's edge (the window spans x 1090..1210)
    await page.mouse.click(outside.x, outside.y);
    expect((await viewerState(page)).selected).toEqual([]);
    await context.close();
  });

  test('overlapping regions: the top one wins, and Alt+click steps to the one beneath', async ({ page }) => {
    await page.goto('/viewer.html');
    // Add a large low-priority region under window-22 and a small high-priority one on top of it.
    const bytes = doctored('illuminated-building', (m) => {
      m.regions.push({ id: 'facade', label: 'Facade', shape: { type: 'rect', x: 320, y: 300, width: 960, height: 560 }, z_index: -5 });
      m.regions.unshift({ id: 'badge', label: 'Badge', shape: { type: 'rect', x: 680, y: 580, width: 20, height: 20 }, z_index: 3 });
    });
    await page.setInputFiles('#file', { name: 'overlap.aav', mimeType: 'application/octet-stream', buffer: bytes });
    await page.waitForSelector('[data-aav-ready]');
    const stack = (x: number, y: number) => page.evaluate(([dx, dy]) => {
      const v = (window as any).__aavViewer; // eslint-disable-line @typescript-eslint/no-explicit-any
      return v.renderer.masks instanceof Map ? (v as any).hitsAt(dx * v.view.scale + v.view.tx, dy * v.view.scale + v.view.ty).regions.map((r: { id: string }) => r.id) : []; // eslint-disable-line @typescript-eslint/no-explicit-any
    }, [x, y]);
    expect(await stack(690, 590)).toEqual(['badge', 'window-22', 'facade']); // z_index 3, then 0, then -5
    expect(await stack(640, 590)).toEqual(['window-22', 'facade']);
    expect(await stack(500, 320)).toEqual(['facade']);
    const p = await viewerPoint(page, 690, 590);
    await page.mouse.click(p.x, p.y);
    expect((await viewerState(page)).selected).toEqual(['badge']);
    await page.keyboard.down('Alt');
    await page.mouse.click(p.x, p.y);
    expect((await viewerState(page)).selected).toEqual(['window-22']);
    await page.mouse.click(p.x, p.y);
    expect((await viewerState(page)).selected).toEqual(['facade']);
    await page.mouse.click(p.x, p.y);
    expect((await viewerState(page)).selected).toEqual(['badge']); // wraps round
    await page.keyboard.up('Alt');
    // Every region, however deeply covered, is still reachable from the list.
    await page.locator('.aav-region-item', { hasText: 'Facade' }).click();
    expect((await viewerState(page)).selected).toEqual(['facade']);
  });

  test('mask regions ignore their transparent pixels', async ({ page }) => {
    await openExample(page, 'illuminated-building');
    const corner = await viewerPoint(page, 734, 704); // inside the door's box, outside the arch
    await page.mouse.click(corner.x, corner.y);
    expect((await viewerState(page)).selected).toEqual([]);
    const centre = await viewerPoint(page, 800, 790);
    await page.mouse.click(centre.x, centre.y);
    expect(await viewerState(page)).toMatchObject({ selected: ['door'], panel: 'door-info' });
  });

  test('touch: a tap enters and activates, so nothing depends on hover', async ({ browser }) => {
    const context = await browser.newContext({ hasTouch: true, viewport: { width: 800, height: 700 } });
    const page = await context.newPage();
    await openExample(page, 'illuminated-building');
    const p = await viewerPoint(page, 690, 590);
    await page.touchscreen.tap(p.x, p.y);
    expect(await viewerState(page)).toMatchObject({ hovered: 'window-22', selected: ['window-22'], panel: 'room-second', tooltip: 'Second-floor window 2' });
    const empty = await viewerPoint(page, 60, 60);
    await page.touchscreen.tap(empty.x, empty.y);
    expect(await viewerState(page)).toMatchObject({ hovered: null, selected: [] });
    for (const button of await page.locator('.aav-btn, .aav-region-item').all()) {
      const box = await button.boundingBox();
      if (box) expect(box.height).toBeGreaterThanOrEqual(30); // comfortable touch targets
    }
    await context.close();
  });

  test('external links show their destination and open only after confirmation', async ({ page }) => {
    await openExample(page, 'interactive-product');
    await page.evaluate(() => { (window as any).__opened = []; window.open = ((...args: unknown[]) => { (window as any).__opened.push(args); return null; }) as typeof window.open; }); // eslint-disable-line @typescript-eslint/no-explicit-any
    const opened = () => page.evaluate(() => (window as any).__opened); // eslint-disable-line @typescript-eslint/no-explicit-any
    const p = await viewerPoint(page, 1230, 820);
    await page.mouse.click(p.x, p.y);
    const dialog = page.locator('dialog.aav-confirm');
    await expect(dialog).toBeVisible();
    await expect(dialog.locator('.aav-confirm-url')).toHaveText('https://example.org/aav-demo/camera/manual');
    await expect(dialog.locator('.aav-confirm-url strong')).toHaveText('example.org');
    await expect(dialog.getByRole('button', { name: 'Cancel' })).toBeFocused(); // the safe choice is the default
    expect(await opened()).toEqual([]);
    await page.keyboard.press('Enter');
    await expect(dialog).toBeHidden();
    expect(await opened()).toEqual([]);
    await page.mouse.click(p.x, p.y);
    await dialog.getByRole('button', { name: 'Open link' }).click();
    expect(await opened()).toEqual([['https://example.org/aav-demo/camera/manual', '_blank', 'noopener,noreferrer']]);
    // Links inside panel text go through the same confirmation.
    const lens = await viewerPoint(page, 760, 512);
    await page.mouse.click(lens.x, lens.y);
    const link = page.locator('.aav-panel-body a.aav-link-external');
    await expect(link).toHaveAttribute('rel', 'noopener noreferrer');
    await expect(link.locator('.aav-link-host')).toHaveText('(example.org)');
    await link.click();
    await expect(dialog.locator('.aav-confirm-url')).toHaveText('https://example.org/aav-demo/camera/lens');
    await dialog.getByRole('button', { name: 'Cancel' }).click();
    expect((await opened()).length).toBe(1);
    expect(page.url()).toContain('/viewer.html');
  });

  test('document links load another AAV only after confirmation', async ({ page }) => {
    await openExample(page, 'interactive-product');
    const p = await viewerPoint(page, 170, 820);
    await page.mouse.click(p.x, p.y);
    const dialog = page.locator('dialog.aav-confirm');
    await expect(dialog.locator('.aav-confirm-url')).toHaveText('http://127.0.0.1:4179/examples/pixel-art-playground.aav');
    await expect(page.locator('.aav-side h1')).toHaveText('Interactive Product');
    await dialog.getByRole('button', { name: 'Open document' }).click();
    await expect(page.locator('.aav-side h1')).toHaveText('Pixel Art Playground');
  });

  test('panel text is rendered as text, with internal links working', async ({ page }) => {
    await page.goto('/viewer.html');
    const hostile = '<img src=x onerror="window.__xss=1"><script>window.__xss=1</script> **bold** [go](#region:roof) [bad](javascript:window.__xss=1)';
    // The javascript: link is caught by validation, so test rendering with the rest of the hostile text.
    const bytes = doctored('illuminated-building', (m) => { m.panels['roof-info'].text = hostile.replace(' [bad](javascript:window.__xss=1)', ''); });
    await page.setInputFiles('#file', { name: 'hostile.aav', mimeType: 'application/octet-stream', buffer: bytes });
    await page.waitForSelector('[data-aav-ready]');
    await page.locator('.aav-region-item', { hasText: 'Roof' }).click();
    const body = page.locator('.aav-panel-body');
    await expect(body).toContainText('<img src=x onerror="window.__xss=1"><script>window.__xss=1</script>');
    await expect(body.locator('img, script')).toHaveCount(0);
    await expect(body.locator('strong')).toHaveText('bold');
    expect(await page.evaluate(() => (window as any).__xss)).toBeUndefined(); // eslint-disable-line @typescript-eslint/no-explicit-any
    await page.locator('.aav-region-item', { hasText: 'Entrance door' }).click();
    await page.locator('.aav-panel-body .aav-link-internal', { hasText: 'Second-floor office' }).click();
    expect(await viewerState(page)).toMatchObject({ panel: 'room-second' });
  });

  test('unsafe or malformed files are refused, with the static preview kept where possible', async ({ page }) => {
    await page.goto('/viewer.html');
    const unsafe = doctored('interactive-product', (m) => { m.regions[6].events.activate[0].url = 'javascript:alert(document.domain)'; });
    await page.setInputFiles('#file', { name: 'unsafe.aav', mimeType: 'application/octet-stream', buffer: unsafe });
    const fallback = page.locator('.aav-fallback');
    await expect(fallback).toContainText('E_LINK');
    await expect(fallback).toContainText('Showing its static preview instead');
    await expect(fallback.locator('img')).toHaveAttribute('alt', 'Static preview of Interactive Product');
    expect(await fallback.locator('img').evaluate((img: HTMLImageElement) => img.naturalWidth)).toBe(1400);
    await expect(page.locator('.aav-viewer')).toHaveCount(0);

    const future = doctored('interactive-product', (m) => { m.version = '4.0'; });
    await page.setInputFiles('#file', { name: 'future.aav', mimeType: 'application/octet-stream', buffer: future });
    await expect(fallback).toContainText('unsupported schema version 4.0');
    await expect(fallback.locator('img')).toBeVisible();

    await page.setInputFiles('#file', { name: 'junk.aav', mimeType: 'application/octet-stream', buffer: Buffer.from('PK\u0003\u0004 definitely not a zip') });
    await expect(fallback).toContainText('E_ARCHIVE_FORMAT');
    await expect(fallback.locator('img')).toHaveCount(0);
  });

  test('a failed import leaves the open document untouched', async ({ page }) => {
    await openExample(page, 'pixel-art-playground');
    const p = await viewerPoint(page, 180, 500);
    await page.mouse.click(p.x, p.y); // "Blocks 20"
    for (const [name, buffer] of [['junk.aav', Buffer.from('not an archive')], ['truncated.aav', readFileSync(example('illuminated-building')).subarray(0, 5000)],
      ['dangling.aav', doctored('illuminated-building', (m) => { m.regions[0].target_layer = 'nowhere'; })]] as [string, Buffer][]) {
      await page.setInputFiles('#file', { name, mimeType: 'application/octet-stream', buffer });
      await expect(page.locator('#banner')).toContainText(name);
      await expect(page.locator('.aav-side h1')).toHaveText('Pixel Art Playground');
    }
    const block = await page.evaluate(() => (window as any).__aavViewer.machine.propValue('scene', 'mosaic', 'block_size')); // eslint-disable-line @typescript-eslint/no-explicit-any
    expect(block).toBe(20); // even the interaction state survived
  });

  test('pixelation uses document-pixel blocks that do not move with zoom or pan', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await openExample(page, 'pixel-art-playground');
    const sharp = [await surfacePixel(page, 5, 205), await surfacePixel(page, 35, 235)];
    expect(sharp[0]).not.toEqual(sharp[1]);
    const p = await viewerPoint(page, 300, 500); // "Blocks 40"
    await page.mouse.click(p.x, p.y);
    const sample = async () => Promise.all([[0, 200], [39, 239], [5, 205], [40, 200], [79, 239], [0, 240]].map(([x, y]) => surfacePixel(page, x, y)));
    const first = await sample();
    expect(first[0]).toEqual(first[1]); // one 40 px block is one colour
    expect(first[0]).toEqual(first[2]);
    expect(first[3]).toEqual(first[4]); // the next block along is uniform too
    expect(first[0]).not.toEqual(first[5]);
    await page.locator('.aav-stage').hover();
    await page.mouse.wheel(0, -500);
    await page.keyboard.press('ArrowRight');
    await page.locator('.aav-btn', { hasText: '+' }).click();
    expect(await sample()).toEqual(first); // identical after zooming and panning
    const controls = await surfacePixel(page, 5, 465);
    expect(controls.slice(0, 3)).toEqual([32, 36, 44]); // the control strip is outside the region and stays sharp
  });

  test('reduced motion: no animation runs, end states still apply', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await openExample(page, 'illuminated-building');
    await expect(page.locator('.aav-check input')).toBeChecked();
    const p = await viewerPoint(page, 1456, 806); // "All lights"
    await page.mouse.click(p.x, p.y);
    const state = await page.evaluate(() => { const m = (window as any).__aavViewer.machine; return { animating: m.isAnimating(), glow: m.propValue('window-11', 'illumination', 'intensity') }; }); // eslint-disable-line @typescript-eslint/no-explicit-any
    expect(state).toEqual({ animating: false, glow: 0.7 });
  });

  test('with motion allowed, animations run, are bounded, and can be switched off', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await openExample(page, 'illuminated-building');
    await expect(page.locator('.aav-check input')).not.toBeChecked();
    const p = await viewerPoint(page, 1456, 806);
    await page.mouse.click(p.x, p.y);
    expect((await viewerState(page)).animating).toBe(true);
    await page.locator('.aav-check input').check();
    expect((await viewerState(page)).animating).toBe(false);
  });

  test('WebGL2 and the CPU reference produce the same pixels', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await openExample(page, 'pixel-art-playground');
    for (const [x, y] of [[670, 500], [780, 500]]) { // "Vivid" (saturation + contrast), then "Dusk" (brightness + tint)
      const p = await viewerPoint(page, x, y);
      await page.mouse.click(p.x, p.y);
    }
    const result = await page.evaluate(() => {
      const v = (window as any).__aavViewer; // eslint-disable-line @typescript-eslint/no-explicit-any
      const Renderer = v.renderer.constructor;
      const read = (backend: string) => {
        const r = new Renderer(v.manifest, v.renderer.assets, { backend });
        const data = r.render(v.machine, 0).getContext('2d').getImageData(0, 0, 960, 540).data;
        const name = r.backend.name;
        r.dispose();
        return { data, name };
      };
      const cpu = read('cpu'), gpu = read('webgl2');
      let max = 0, changed = 0;
      const base = v.renderer.assets.get('base');
      const c = document.createElement('canvas'); c.width = 960; c.height = 540;
      const ctx = c.getContext('2d')!; ctx.drawImage(base.image, 0, 0);
      const original = ctx.getImageData(0, 0, 960, 540).data;
      for (let i = 0; i < cpu.data.length; i++) {
        max = Math.max(max, Math.abs(cpu.data[i] - gpu.data[i]));
        if (cpu.data[i] !== original[i]) changed++;
      }
      return { cpu: cpu.name, gpu: gpu.name, max, changed };
    });
    test.skip(result.gpu !== 'webgl2', 'WebGL2 is not available in this browser');
    expect(result.cpu).toBe('cpu');
    expect(result.changed).toBeGreaterThan(100000); // the effects really did something
    expect(result.max).toBeLessThanOrEqual(2);      // rounding differences only
  });

  test('default highlight and focus ring are drawn for unstyled regions', async ({ page }) => {
    await openExample(page, 'pixel-art-playground');
    const screenPixel = (x: number, y: number) => page.evaluate(([cx, cy]) => {
      const v = (window as any).__aavViewer; // eslint-disable-line @typescript-eslint/no-explicit-any
      v.renderNow();
      const canvas = document.querySelector('.aav-canvas') as HTMLCanvasElement;
      const r = canvas.getBoundingClientRect(), dpr = canvas.width / r.width;
      return [...canvas.getContext('2d')!.getImageData(Math.round((cx - r.left) * dpr), Math.round((cy - r.top) * dpr), 1, 1).data];
    }, [x, y]);
    const edge = await viewerPoint(page, 6, 500); // left edge of the first control region (x = 6)
    const before = await screenPixel(edge.x, edge.y);
    await page.locator('.aav-proxy[data-region="control-px-1"]').focus();
    const focused = await screenPixel(edge.x, edge.y);
    expect(focused).not.toEqual(before);
    await page.locator('.aav-stage').focus();
    expect(await screenPixel(edge.x, edge.y)).toEqual(before);
  });
});
