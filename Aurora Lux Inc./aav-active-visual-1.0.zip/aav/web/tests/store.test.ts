import { describe, expect, it } from 'vitest';
import { migrate, needsMigration } from '../src/core/migrate';
import type { Manifest } from '../src/core/types';
import { AavError, errorsOnly } from '../src/core/types';
import { validateManifest } from '../src/core/validate';
import { HISTORY_LIMIT, applyGlowPreset, applyHighlightPreset, defaultEffect, deleteRegion, documentIssues, initialState, issueTarget,
  newManifest, reducer, renameLayer, renamePanel, renameRegion, slugify, uniqueId } from '../src/editor/store';
import type { EditorDoc, EditorState } from '../src/editor/store';
import { baseManifest } from './helpers';

const docOf = (manifest: Manifest): EditorDoc => ({ manifest, files: new Map([['assets/base.png', new Uint8Array([1])]]) });
const fresh = (): EditorDoc => docOf(newManifest('My Photo', 640, 480, 'assets/base.png', 'image/png'));
const withTitle = (doc: EditorDoc, title: string): EditorDoc => ({ ...doc, manifest: { ...doc.manifest, document: { ...doc.manifest.document, title } } });
const load = (doc: EditorDoc): EditorState => reducer(initialState, { type: 'load', doc });

describe('editor history', () => {
  it('a new document from an image is valid', () => {
    const doc = fresh();
    expect(documentIssues(doc)).toEqual([]);
    expect(doc.manifest.document).toMatchObject({ id: 'my-photo', width: 640, height: 480 });
  });

  it('undo and redo walk the history and restore exact documents', () => {
    const a = fresh(), b = withTitle(a, 'B'), c = withTitle(a, 'C');
    let s = load(a);
    expect(s.dirty).toBe(false);
    s = reducer(s, { type: 'change', doc: b });
    s = reducer(s, { type: 'change', doc: c });
    expect([s.past.length, s.dirty]).toEqual([2, true]);
    s = reducer(s, { type: 'undo' });
    expect(s.doc).toBe(b);
    s = reducer(s, { type: 'undo' });
    expect(s.doc).toBe(a);
    s = reducer(s, { type: 'undo' });
    expect(s.doc).toBe(a);                                   // nothing further to undo
    s = reducer(s, { type: 'redo' });
    s = reducer(s, { type: 'redo' });
    expect(s.doc).toBe(c);
    s = reducer(s, { type: 'undo' });
    s = reducer(s, { type: 'change', doc: withTitle(a, 'D') });
    expect(s.future).toEqual([]);                            // a new edit discards the redo branch
    expect(reducer(s, { type: 'saved' }).dirty).toBe(false);
  });

  it('merges a drag or slider sweep into one undo step', () => {
    let s = load(fresh());
    const original = s.doc;
    for (let i = 0; i < 20; i++) s = reducer(s, { type: 'change', doc: withTitle(s.doc!, `step ${i}`), key: 'geometry:r1', time: 1000 + i * 16 });
    expect(s.past.length).toBe(1);
    s = reducer(s, { type: 'change', doc: withTitle(s.doc!, 'other'), key: 'label:r1', time: 1400 });
    s = reducer(s, { type: 'change', doc: withTitle(s.doc!, 'later'), key: 'label:r1', time: 5000 }); // too late to merge
    expect(s.past.length).toBe(3);
    s = reducer(reducer(reducer(s, { type: 'undo' }), { type: 'undo' }), { type: 'undo' });
    expect(s.doc).toBe(original);
  });

  it('bounds the history and survives loading nothing', () => {
    let s = load(fresh());
    for (let i = 0; i < HISTORY_LIMIT + 50; i++) s = reducer(s, { type: 'change', doc: withTitle(s.doc!, String(i)) });
    expect(s.past.length).toBe(HISTORY_LIMIT);
    expect(reducer(initialState, { type: 'change', doc: fresh() })).toBe(initialState);
    expect(reducer(initialState, { type: 'undo' })).toBe(initialState);
  });

  it('drops a selection whose target disappears', () => {
    const doc = docOf(baseManifest());
    let s = reducer(load(doc), { type: 'select', selection: { kind: 'region', id: 'room' } });
    expect(s.selection).toEqual({ kind: 'region', id: 'room' });
    const without = structuredClone(doc.manifest);
    deleteRegion(without, 'room');
    s = reducer(s, { type: 'change', doc: { ...doc, manifest: without } });
    expect(s.selection).toEqual({ kind: 'none' });
    expect(reducer(s, { type: 'undo' }).doc!.manifest.regions!.some((r) => r.id === 'room')).toBe(true);
    expect(reducer(s, { type: 'select', selection: { kind: 'layer', id: 'ghost' } }).selection).toEqual({ kind: 'none' });
  });
});

describe('manifest editing helpers', () => {
  it('renaming keeps every reference intact', () => {
    const m = baseManifest();
    renameRegion(m, 'window-01', 'front-window');
    renameLayer(m, 'overlay', 'sign');
    renamePanel(m, 'room-information', 'room');
    renamePanel(m, 'help', 'support');
    expect(errorsOnly(validateManifest(m))).toEqual([]);
    expect(m.groups!.windows.regions).toContain('front-window');
    expect(m.animations!['pulse-window'].region).toBe('front-window');
    expect(m.panels!.room.text).toContain('(#region:front-window)');
    expect(m.panels!.room.text).toContain('(#panel:support)');
    expect(JSON.stringify(m)).not.toMatch(/window-01|room-information/);
    // The layer id changed; the asset that happens to share the old name is a different namespace and is untouched.
    expect(m.layers.map((l) => l.id)).toEqual(['background', 'sign', 'label']);
    expect(m.layers[1]).toMatchObject({ asset: 'overlay' });
    expect(m.regions![0].events!.activate!.find((a) => a.action === 'toggle_layer')).toMatchObject({ layer: 'sign' });
  });

  it('deleting a region cleans up what it can and leaves the rest for the error list', () => {
    const m = baseManifest();
    deleteRegion(m, 'window-01');
    expect(m.groups!.windows.regions).toEqual(['masked']);
    expect(m.animations!['pulse-window']).toBeUndefined();
    const issues = errorsOnly(validateManifest(m));
    expect(issues.map((i) => i.code)).toEqual(['E_REF']);     // the panel text still links to it
    expect(issueTarget(m, issues[0].path)).toEqual({ kind: 'panel', id: 'room-information' });
    expect(issueTarget(m, '/regions/0/effects/px')).toEqual({ kind: 'region', id: 'room' });
    expect(issueTarget(m, '/layers/2/text')).toEqual({ kind: 'layer', id: 'label' });
    expect(issueTarget(m, '/document/title')).toEqual({ kind: 'none' });
  });

  it('presets and default effects produce valid documents', () => {
    const m = newManifest('P', 100, 100, 'assets/base.png', 'image/png');
    m.regions = [{ id: 'r', label: 'R', shape: { type: 'rect', x: 1, y: 1, width: 10, height: 10 }, target_layer: 'background' }];
    applyHighlightPreset(m.regions[0]);
    applyGlowPreset(m.regions[0]);
    applyGlowPreset(m.regions[0]);                            // applying twice must not duplicate actions
    expect(m.regions[0].events!.pointer_enter).toHaveLength(1);
    for (const type of ['pixelate', 'blur', 'brightness', 'contrast', 'saturation', 'spotlight', 'opacity'] as const) {
      m.regions[0].effects![type] = defaultEffect(type);
    }
    expect(validateManifest(m)).toEqual([]);
    expect(defaultEffect('spotlight')).not.toHaveProperty('x');  // optional centre is left unset
  });

  it('reports missing files alongside manifest problems', () => {
    const doc = fresh();
    doc.files.clear();
    expect(documentIssues(doc).map((i) => i.code)).toEqual(['E_ARCHIVE_MISSING']);
  });

  it('generates identifiers that satisfy the id rules', () => {
    expect(slugify('  Héllo, Wörld!  ')).toBe('h-llo-w-rld');
    expect(slugify('???')).toBe('document');
    expect(slugify('x'.repeat(200)).length).toBe(64);
    expect(uniqueId('region', ['region-1', 'region-2'])).toBe('region-3');
  });
});

describe('migration', () => {
  it('upgrades the pre-release draft and leaves current documents alone', () => {
    const old = { format: 'aureom-active-visual', version: '0.9', document: { id: 'd', title: 'D', size: [10, 20] },
      layers: [{ id: 't', type: 'text', text: 'x', x: 0, y: 0, color: '#FFFFFF' }],
      hotspots: [{ id: 'h', label: 'H', shape: { type: 'rect', x: 0, y: 0, width: 5, height: 5 }, effects: { g: { type: 'glow', color: '#FF0000' } } }],
      preview: 'preview.png' };
    expect(needsMigration(old)).toBe(true);
    expect(errorsOnly(validateManifest(old)).map((i) => i.code)).toEqual(['E_VERSION']);
    const { manifest, steps } = migrate(old);
    expect(steps).toEqual(['0.9 -> 1.0']);
    expect(validateManifest(manifest)).toEqual([]);
    expect(manifest).toMatchObject({ version: '1.0', document: { width: 10, height: 20 } });
    expect(old.version).toBe('0.9');                          // the input is not modified
    expect(needsMigration(manifest)).toBe(false);
    expect(migrate(manifest).steps).toEqual([]);
    expect(() => migrate({ format: 'aureom-active-visual', version: '7.0' })).toThrow(AavError);
    expect(() => migrate({ format: 'other' })).toThrow(AavError);
  });
});
