import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { deflateSync, zipSync } from 'fflate';
import { describe, expect, it } from 'vitest';
import { sniffImage } from '../src/core/imageinfo';
import { canonicalJson, loadPackage, loadUnvalidated, parseManifest, savePackage, sha256Hex, sha256Sync } from '../src/core/package';
import { AavError } from '../src/core/types';
import { crc32, entryPathProblem, readZip, writeZip } from '../src/core/zip';
import { ROOT } from './helpers';

const text = (s: string) => new TextEncoder().encode(s);
const EXAMPLES = resolve(ROOT, 'examples');
const example = (name: string) => new Uint8Array(readFileSync(resolve(EXAMPLES, name)));

function codesOf(fn: () => unknown): string[] {
  try {
    fn();
  } catch (error) {
    if (error instanceof AavError) return [...new Set(error.issues.map((i) => i.code))];
    throw error;
  }
  return [];
}

async function codesOfAsync(promise: Promise<unknown>): Promise<string[]> {
  try {
    await promise;
  } catch (error) {
    if (error instanceof AavError) return [...new Set(error.issues.map((i) => i.code))].sort();
    throw error;
  }
  return [];
}

/** Hand-built ZIP so tests can break the profile in specific ways. */
function rawZip(entries: [string | Uint8Array, Uint8Array][], opts: { method?: number; flags?: number; comment?: Uint8Array;
  prefix?: Uint8Array; lieUsize?: number; centralName?: Uint8Array } = {}): Uint8Array {
  const parts: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = opts.prefix?.length ?? 0;
  if (opts.prefix) parts.push(opts.prefix);
  for (const [name, payload] of entries) {
    const rawName = typeof name === 'string' ? text(name) : name;
    const data = opts.method === 8 ? deflateSync(payload, { level: 9 }) : payload;
    const header = (n: Uint8Array) => {
      const h = new DataView(new ArrayBuffer(26));
      h.setUint16(0, 20, true); h.setUint16(2, opts.flags ?? 0x0800, true); h.setUint16(4, opts.method ?? 0, true);
      h.setUint16(8, 0x21, true); h.setUint32(10, crc32(payload), true); h.setUint32(14, data.length, true);
      h.setUint32(18, opts.lieUsize ?? payload.length, true); h.setUint16(22, n.length, true);
      return new Uint8Array(h.buffer);
    };
    const local = new Uint8Array([0x50, 0x4b, 3, 4, ...header(rawName), ...rawName]);
    parts.push(local, data);
    const cname = opts.centralName ?? rawName;
    // Central record tail: comment length (2), disk (2), internal attrs (2), external attrs (4), local offset (4).
    const tail = new DataView(new ArrayBuffer(14));
    tail.setUint32(10, offset, true);
    central.push(new Uint8Array([0x50, 0x4b, 1, 2, 20, 0, ...header(cname), ...new Uint8Array(tail.buffer), ...cname]));
    offset += local.length + data.length;
  }
  const centralSize = central.reduce((n, c) => n + c.length, 0);
  const comment = opts.comment ?? new Uint8Array();
  const eocd = new DataView(new ArrayBuffer(22));
  eocd.setUint32(0, 0x06054b50, true); eocd.setUint16(8, entries.length, true); eocd.setUint16(10, entries.length, true);
  eocd.setUint32(12, centralSize, true); eocd.setUint32(16, offset, true); eocd.setUint16(20, comment.length, true);
  const all = [...parts, ...central, new Uint8Array(eocd.buffer), comment];
  const out = new Uint8Array(all.reduce((n, p) => n + p.length, 0));
  let pos = 0;
  for (const p of all) { out.set(p, pos); pos += p.length; }
  return out;
}

describe('zip container', () => {
  it('the hand-built test archives are themselves well formed', () => {
    // Guards the negative tests below: each must fail for its own reason, not because the helper is broken.
    const stored = readZip(rawZip([['manifest.json', text('{}')], ['assets/a.png', text('abc')]]));
    expect([...stored.keys()]).toEqual(['manifest.json', 'assets/a.png']);
    const deflated = readZip(rawZip([['assets/é.bin', new Uint8Array(3000).fill(9)]], { method: 8 }));
    expect(deflated.get('assets/é.bin')!.length).toBe(3000);
    expect(codesOf(() => readZip(rawZip([['manifest.json', text('{}')], ['assets/ok.png', text('x')]])))).toEqual([]);
  });

  it('round-trips files in a deterministic order', () => {
    const files = new Map([['thumbnails/t.png', text('t')], ['assets/b.png', text('b')], ['preview.png', text('p')],
      ['manifest.json', text('{}')], ['assets/a.png', text('a')]]);
    const a = writeZip(files), b = writeZip(new Map([...files].reverse()));
    expect(a).toEqual(b);
    expect([...readZip(a).keys()]).toEqual(['manifest.json', 'preview.png', 'assets/a.png', 'assets/b.png', 'thumbnails/t.png']);
    expect(new TextDecoder().decode(readZip(a).get('assets/a.png'))).toBe('a');
  });

  it('reads deflated archives written by other tools', () => {
    const data = zipSync({ 'manifest.json': text('{"a":1}'), 'assets/x.bin': new Uint8Array(5000).fill(7) }, { level: 6 });
    const files = readZip(data);
    expect(files.get('assets/x.bin')!.length).toBe(5000);
    expect(files.get('assets/x.bin')!.every((b) => b === 7)).toBe(true);
  });

  it.each(['../evil.png', 'assets/../../evil.png', '/etc/passwd', 'assets\\evil.png', 'C:/evil.png', 'assets//x.png',
    './manifest.json', 'a\u0000b', 'assets/x\n.png', 'e\u0301.png'])('rejects the unsafe entry name %j', (name) => {
    expect(entryPathProblem(name)).not.toBeNull();
    expect(codesOf(() => readZip(rawZip([['manifest.json', text('{}')], [name, text('x')]])))).toEqual(['E_ARCHIVE_PATH']);
  });

  it('rejects names that are not UTF-8, or not ASCII without the UTF-8 flag', () => {
    expect(codesOf(() => readZip(rawZip([[new Uint8Array([0xff, 0xfe, 0x2e]), text('x')]])))).toEqual(['E_ARCHIVE_PATH']);
    expect(codesOf(() => readZip(rawZip([['é.png', text('x')]], { flags: 0 })))).toEqual(['E_ARCHIVE_PATH']);
  });

  it.each([[['assets/a.png', 'assets/a.png']], [['assets/a.png', 'assets/A.PNG']], [['manifest.json', 'MANIFEST.JSON']]])(
    'rejects duplicate paths %j', (names) => {
      expect(codesOf(() => readZip(rawZip(names.map((n) => [n, text('x')] as [string, Uint8Array]))))).toEqual(['E_ARCHIVE_DUPLICATE']);
    });

  it('rejects zip bombs by ratio and by declared size', () => {
    expect(codesOf(() => readZip(rawZip([['assets/bomb.png', new Uint8Array(8 * 1024 * 1024)]], { method: 8 })))).toEqual(['E_ARCHIVE_RATIO']);
    expect(codesOf(() => readZip(rawZip([['assets/x.png', new Uint8Array(1_000_000).fill(65)]], { method: 8, lieUsize: 10 }))))
      .toEqual(['E_ARCHIVE_SIZE']);
    expect(codesOf(() => readZip(rawZip([['assets/x.png', new Uint8Array(0)]], { method: 8, lieUsize: 64 * 1024 * 1024 + 1 }))))
      .toEqual(['E_ARCHIVE_LIMIT']);
  });

  it('rejects structural violations', () => {
    const good = rawZip([['manifest.json', text('{}')]]);
    const cases: [string, Uint8Array, string][] = [
      ['prefix data', rawZip([['manifest.json', text('{}')]], { prefix: text('GIF89a junk') }), 'E_ARCHIVE_FORMAT'],
      ['archive comment', rawZip([['manifest.json', text('{}')]], { comment: text('hi') }), 'E_ARCHIVE_FORMAT'],
      ['trailing bytes', new Uint8Array([...good, 0, 0]), 'E_ARCHIVE_FORMAT'],
      ['truncation', good.slice(0, -10), 'E_ARCHIVE_FORMAT'],
      ['not a zip', text('this is not a zip file at all, just text'), 'E_ARCHIVE_FORMAT'],
      ['empty input', new Uint8Array(), 'E_ARCHIVE_FORMAT'],
      ['encryption flag', rawZip([['manifest.json', text('{}')]], { flags: 0x0801 }), 'E_ARCHIVE_ENCRYPTED'],
      ['unknown method', rawZip([['manifest.json', text('{}')]], { method: 12 }), 'E_ARCHIVE_METHOD'],
      ['local/central name mismatch', rawZip([['manifest.json', text('{}')]], { centralName: text('manifest.jso2') }), 'E_ARCHIVE_FORMAT'],
    ];
    for (const [label, data, code] of cases) expect(codesOf(() => readZip(data)), label).toEqual([code]);
    const badCrc = good.slice();
    badCrc[30 + 'manifest.json'.length] ^= 0xff;
    expect(codesOf(() => readZip(badCrc))).toEqual(['E_ARCHIVE_CRC']);
    const zip64 = good.slice();
    zip64.set([0xff, 0xff, 0xff, 0xff], zip64.length - 22 + 16);
    expect(codesOf(() => readZip(zip64))).toEqual(['E_ARCHIVE_FORMAT']);
  });

  it('refuses to write unsafe names', () => {
    expect(codesOf(() => writeZip(new Map([['../x', text('x')]])))).toEqual(['E_ARCHIVE_PATH']);
  });
});

describe('packages', () => {
  it('hashes with the fallback exactly like SubtleCrypto', async () => {
    for (const input of [new Uint8Array(), text('abc'), new Uint8Array(1000).map((_, i) => i * 7), new Uint8Array(119), new Uint8Array(120)]) {
      expect(sha256Sync(input)).toBe(await sha256Hex(input));
    }
    expect(sha256Sync(text('abc'))).toBe('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  });

  it('writes canonical JSON', () => {
    const a = new TextDecoder().decode(canonicalJson({ b: 1.0, a: [3, { z: 0.5, y: 2 }], 'é': 'ü' }));
    expect(a).toBe('{\n  "a": [\n    3,\n    {\n      "y": 2,\n      "z": 0.5\n    }\n  ],\n  "b": 1,\n  "é": "ü"\n}\n');
    expect(() => canonicalJson({ a: Number.NaN })).toThrow(AavError);
  });

  it('parses manifests strictly', () => {
    for (const bad of ['{"x": NaN}', '{"x": Infinity}', '[1]', '', '{"a":1,}', '"text"']) {
      expect(() => parseManifest(text(bad)), bad).toThrow(AavError);
    }
    expect(() => parseManifest(new Uint8Array([0xef, 0xbb, 0xbf, 0x7b, 0x7d]))).toThrow(AavError);
    expect(() => parseManifest(new Uint8Array([0x7b, 0x22, 0xff, 0x22, 0x3a, 0x31, 0x7d]))).toThrow(AavError);
    expect(() => parseManifest(new Uint8Array(5 * 1024 * 1024).fill(0x20))).toThrow(AavError);
  });

  const names = readdirSync(EXAMPLES).filter((n) => n.endsWith('.aav'));
  it('has the three example documents', () => expect(names.sort()).toEqual(['illuminated-building.aav', 'interactive-product.aav', 'pixel-art-playground.aav']));

  it.each(names)('loads the Python-built %s and re-saves it byte for byte', async (name) => {
    const bytes = example(name);
    const { pkg, warnings } = await loadPackage(bytes, { strict: true });
    expect(warnings).toEqual([]);
    expect(pkg.manifest.regions!.length).toBeGreaterThan(5);
    // Same container profile and canonical manifest in both implementations: the bytes must match.
    expect(await sha256Hex(await savePackage(pkg))).toBe(await sha256Hex(bytes));
  });

  it('detects tampered assets, wrong types and missing files', async () => {
    const mutate = async (fn: (files: Map<string, Uint8Array>, manifest: any) => void) => { // eslint-disable-line @typescript-eslint/no-explicit-any
      const files = readZip(example('pixel-art-playground.aav'));
      const manifest = JSON.parse(new TextDecoder().decode(files.get('manifest.json')));
      fn(files, manifest);
      files.set('manifest.json', text(JSON.stringify(manifest)));
      return codesOfAsync(loadPackage(writeZip(files)));
    };
    expect(await mutate((f) => { const b = f.get('assets/base.png')!.slice(); b[b.length - 20] ^= 1; f.set('assets/base.png', b); })).toEqual(['E_ASSET_HASH']);
    expect(await mutate((_f, m) => { m.assets.base.media_type = 'image/jpeg'; })).toEqual(['E_ASSET_TYPE']);
    expect(await mutate((_f, m) => { m.assets.base.width = 5; })).toEqual(['E_ASSET_DIMENSIONS']);
    expect(await mutate((f) => { f.delete('assets/base.png'); })).toEqual(['E_ARCHIVE_MISSING']);
    expect(await mutate((f) => { f.delete('preview.png'); })).toEqual(['E_ARCHIVE_MISSING']);
    expect(await mutate((f) => { f.set('assets/base.png', text('<svg onload="alert(1)"/>')); })).toEqual(['E_ASSET_TYPE']);
    expect(await mutate((_f, m) => { m.version = '2.0'; })).toEqual(['E_VERSION']);
    expect(await mutate((_f, m) => { m.regions[0].events = { activate: [{ action: 'open_link', url: 'javascript:alert(1)' }] }; })).toEqual(['E_LINK']);
  });

  it('rejects oversized image dimensions from the header alone', async () => {
    const files = readZip(example('pixel-art-playground.aav'));
    const manifest = JSON.parse(new TextDecoder().decode(files.get('manifest.json')));
    const huge = files.get('assets/base.png')!.slice();
    new DataView(huge.buffer).setUint32(16, 60000);
    expect(sniffImage(huge)).toMatchObject({ width: 60000 });
    files.set('assets/base.png', huge);
    for (const key of ['sha256', 'width', 'height']) delete manifest.assets.base[key];
    files.set('manifest.json', text(JSON.stringify(manifest)));
    expect(await codesOfAsync(loadPackage(writeZip(files)))).toContain('E_ASSET_DIMENSIONS');
  });

  it('keeps the container readable when only the manifest is unsupported', () => {
    const files = readZip(example('interactive-product.aav'));
    const manifest = JSON.parse(new TextDecoder().decode(files.get('manifest.json')));
    manifest.version = '3.1';
    files.set('manifest.json', text(JSON.stringify(manifest)));
    const pkg = loadUnvalidated(writeZip(files));
    expect(sniffImage(pkg.files.get('preview.png')!)?.mediaType).toBe('image/png');
  });
});
