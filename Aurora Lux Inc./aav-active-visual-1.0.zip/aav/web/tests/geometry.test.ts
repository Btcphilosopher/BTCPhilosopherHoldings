import { describe, expect, it } from 'vitest';
import { applyMatrix, centredView, clampRect, docToScreen, fitView, imageMatrix, invert, layerTransform, multiply, panBy,
  pointInPolygon, screenToDoc, zoomAt } from '../src/core/geometry';
import { hitTest, hitTestAll, regionContains } from '../src/core/hittest';
import type { MaskAlpha } from '../src/core/hittest';
import type { ImageLayer, Manifest, Region } from '../src/core/types';
import { shapeBounds } from '../src/core/validate';

const near = (a: { x: number; y: number }, b: { x: number; y: number }) => {
  expect(a.x).toBeCloseTo(b.x, 9);
  expect(a.y).toBeCloseTo(b.y, 9);
};

describe('view transform', () => {
  it('document and screen coordinates are inverse for any pan and zoom', () => {
    for (const view of [{ scale: 1, tx: 0, ty: 0 }, { scale: 0.37, tx: -120.5, ty: 44 }, { scale: 8, tx: 3000, ty: -9000 }]) {
      for (const [x, y] of [[0, 0], [1600, 1000], [-50, 12.25], [799.5, 0.5]]) {
        const s = docToScreen(view, x, y);
        near(screenToDoc(view, s.x, s.y), { x, y });
      }
    }
  });

  it('fit centres the whole document and respects the margin', () => {
    const v = fitView(1600, 1000, 800, 600, 10);
    expect(v.scale).toBeCloseTo(780 / 1600);
    near(docToScreen(v, 800, 500), { x: 400, y: 300 });
    expect(docToScreen(v, 0, 0).x).toBeCloseTo(10);
    const tall = fitView(100, 1000, 800, 600);
    expect(tall.scale).toBeCloseTo(0.6);
  });

  it('zooming keeps the point under the cursor fixed', () => {
    let v = fitView(1600, 1000, 800, 600);
    const anchor = { x: 613, y: 127 };
    const before = screenToDoc(v, anchor.x, anchor.y);
    for (const factor of [1.25, 2, 0.3, 5, 0.01]) {
      v = zoomAt(v, factor, anchor.x, anchor.y);
      near(screenToDoc(v, anchor.x, anchor.y), before);
    }
  });

  it('zoom is clamped to the documented range', () => {
    const v = { scale: 1, tx: 0, ty: 0 };
    expect(zoomAt(v, 1e9, 0, 0).scale).toBe(64);
    expect(zoomAt(v, 1e-9, 0, 0).scale).toBe(0.01);
    expect(centredView(500, 10, 10, 100, 100).scale).toBe(64);
  });

  it('panning moves screen positions and leaves the scale alone', () => {
    const v = panBy({ scale: 2, tx: 10, ty: 20 }, 5, -7);
    expect(v).toEqual({ scale: 2, tx: 15, ty: 13 });
  });

  it('hit testing is independent of device pixel ratio by construction', () => {
    // The mapping takes CSS pixels only; the backing-store scale never enters it.
    const view = fitView(1600, 1000, 640, 400);
    const css = docToScreen(view, 460, 300);
    for (const dpr of [1, 1.5, 2, 3]) {
      const devicePixel = { x: css.x * dpr, y: css.y * dpr };
      near(screenToDoc(view, devicePixel.x / dpr, devicePixel.y / dpr), { x: 460, y: 300 });
    }
  });

  it('clamps rectangles to the document', () => {
    expect(clampRect({ x: -10.5, y: 5.2, width: 30, height: 10 }, 100, 100)).toEqual({ x: 0, y: 5, width: 20, height: 11 });
    expect(clampRect({ x: 90, y: 90, width: 30, height: 30 }, 100, 100, 5)).toEqual({ x: 85, y: 85, width: 15, height: 15 });
    expect(clampRect({ x: 200, y: 0, width: 10, height: 10 }, 100, 100)).toBeNull();
  });
});

describe('layer transforms', () => {
  const layer: ImageLayer = { id: 'l', type: 'image', asset: 'a', x: 100, y: 50, width: 200, height: 100,
    transform: { translate_x: 10, translate_y: -5, scale_x: 1.5, scale_y: 0.5, rotation: 90, origin_x: 100, origin_y: 50 } };

  it('matches the Python implementation on the same layer', () => {
    const m = imageMatrix(layer, 20, 10, 800, 600);
    near(applyMatrix(m, 0, 0), { x: 110, y: 45 });
    near(applyMatrix(m, 1, 0), { x: 110, y: 60 }); // +x in the asset becomes +y after a clockwise quarter turn
    near(applyMatrix(m, 0, 1), { x: 105, y: 45 });
  });

  it('inverts', () => {
    const m = imageMatrix(layer, 20, 10, 800, 600);
    near(applyMatrix(multiply(invert(m), m), 7.25, -3.5), { x: 7.25, y: -3.5 });
    expect(() => invert([0, 0, 0, 0, 1, 1])).toThrow();
  });

  it('defaults: image layers fill the document and rotate about their centre', () => {
    const plain: ImageLayer = { id: 'p', type: 'image', asset: 'a' };
    expect(layerTransform(plain, 800, 600)).toEqual([1, 0, 0, 1, 0, 0]);
    near(applyMatrix(imageMatrix(plain, 400, 300, 800, 600), 400, 300), { x: 800, y: 600 });
    const turned: ImageLayer = { id: 't', type: 'image', asset: 'a', transform: { rotation: 180 } };
    near(applyMatrix(layerTransform(turned, 800, 600), 0, 0), { x: 800, y: 600 });
  });
});

describe('hit testing', () => {
  const rect = (id: string, x: number, y: number, w: number, h: number, extra: Partial<Region> = {}): Region =>
    ({ id, label: id, shape: { type: 'rect', x, y, width: w, height: h }, ...extra });
  const doc = (regions: Region[]): Manifest => ({ format: 'aureom-active-visual', version: '1.0',
    document: { id: 'd', title: 'd', width: 200, height: 100 }, layers: [{ id: 't', type: 'text', text: 'x', x: 0, y: 0 }], regions, preview: 'preview.png' });
  const none = new Map<string, MaskAlpha>();

  it('rectangles are half-open so neighbours never both claim an edge', () => {
    const a = rect('a', 0, 0, 50, 50), b = rect('b', 50, 0, 50, 50);
    expect(regionContains(a, 49.999, 10, 200, 100, none)).toBe(true);
    expect(regionContains(a, 50, 10, 200, 100, none)).toBe(false);
    expect(regionContains(b, 50, 10, 200, 100, none)).toBe(true);
    expect(hitTestAll(doc([a, b]), 50, 10, none).map((r) => r.id)).toEqual(['b']);
  });

  it('when regions overlap, the later one wins unless z_index says otherwise', () => {
    const lower = rect('lower', 0, 0, 100, 100), upper = rect('upper', 50, 0, 100, 100);
    expect(hitTest(doc([lower, upper]), 75, 50, none)!.id).toBe('upper');
    expect(hitTestAll(doc([lower, upper]), 75, 50, none).map((r) => r.id)).toEqual(['upper', 'lower']);
    expect(hitTest(doc([{ ...lower, z_index: 1 }, upper]), 75, 50, none)!.id).toBe('lower');
    expect(hitTest(doc([lower, { ...upper, z_index: -1 }]), 75, 50, none)!.id).toBe('lower');
    expect(hitTest(doc([lower, upper]), 25, 50, none)!.id).toBe('lower');
    expect(hitTest(doc([lower, upper]), 175, 50, none)).toBeNull();
  });

  it('non-interactive regions do not intercept the pointer', () => {
    const below = rect('below', 0, 0, 100, 100), decoration = rect('decoration', 0, 0, 100, 100, { interactive: false, z_index: 99 });
    expect(hitTest(doc([below, decoration]), 10, 10, none)!.id).toBe('below');
    expect(hitTest(doc([decoration]), 10, 10, none)).toBeNull();
  });

  it('polygons use the even-odd rule', () => {
    const triangle: [number, number][] = [[0, 0], [100, 0], [0, 100]];
    expect(pointInPolygon(triangle, 10, 10)).toBe(true);
    expect(pointInPolygon(triangle, 90, 90)).toBe(false);
    const bowTie: [number, number][] = [[0, 0], [100, 100], [100, 0], [0, 100]];
    expect(pointInPolygon(bowTie, 10, 50)).toBe(true);
    expect(pointInPolygon(bowTie, 50, 10)).toBe(false);
    const region: Region = { id: 'p', label: 'p', shape: { type: 'polygon', points: triangle } };
    expect(hitTest(doc([region]), 20, 20, none)!.id).toBe('p');
    expect(shapeBounds(region.shape, 200, 100)).toEqual({ x: 0, y: 0, width: 100, height: 100 });
  });

  it('masks are tested against their alpha, scaled to the placement', () => {
    // 4x2 mask: left half opaque, right half transparent, one half-transparent pixel.
    const mask: MaskAlpha = { width: 4, height: 2, data: new Uint8Array([255, 255, 0, 0, 255, 100, 0, 0]) };
    const masks = new Map([['m', mask]]);
    const region: Region = { id: 'm', label: 'm', shape: { type: 'mask', asset: 'm', x: 20, y: 10, width: 80, height: 40 } };
    expect(regionContains(region, 30, 15, 200, 100, masks)).toBe(true);    // opaque texel
    expect(regionContains(region, 90, 15, 200, 100, masks)).toBe(false);   // transparent texel inside the box
    expect(regionContains(region, 50, 40, 200, 100, masks)).toBe(false);   // alpha 100 is below the 0.5 threshold
    expect(regionContains({ ...region, shape: { ...region.shape, threshold: 0.3 } as Region['shape'] }, 50, 40, 200, 100, masks)).toBe(true);
    expect(regionContains(region, 10, 15, 200, 100, masks)).toBe(false);   // outside the box
    expect(regionContains({ ...region, shape: { ...region.shape, hit_test: 'bounds' } as Region['shape'] }, 90, 15, 200, 100, masks)).toBe(true);
    expect(regionContains(region, 30, 15, 200, 100, none)).toBe(false);    // mask not decoded: never a hit
    // A transparent part of a mask lets the region underneath receive the pointer.
    const under = rect('under', 0, 0, 200, 100);
    expect(hitTest(doc([under, region]), 90, 15, masks)!.id).toBe('under');
    expect(hitTest(doc([under, region]), 30, 15, masks)!.id).toBe('m');
  });

  it('ignores non-finite coordinates', () => {
    expect(hitTestAll(doc([rect('a', 0, 0, 10, 10)]), Number.NaN, 5, none)).toEqual([]);
  });
});
