import { describe, expect, it } from 'vitest';
import { LIMITS } from '../src/core/limits';
import { Machine, ease } from '../src/core/state';
import type { Action, Manifest, Region } from '../src/core/types';
import { errorsOnly } from '../src/core/types';
import { validateManifest } from '../src/core/validate';

function doc(overrides: Partial<Manifest> = {}): Manifest {
  const window1: Region = {
    id: 'w1', label: 'Window 1', tooltip: 'Tip', shape: { type: 'rect', x: 0, y: 0, width: 10, height: 10 }, target_layer: 'bg',
    effects: { glow: { type: 'glow', colour: '#FFD47A', intensity: 0, radius: 18 }, edge: { type: 'outline', opacity: 0 } },
    states: { selected: { glow: { intensity: 0.3 } }, hover: { glow: { intensity: 0.6 }, edge: { opacity: 1 } }, focus: { glow: { intensity: 0.9 } } },
    events: {
      pointer_enter: [{ action: 'show_tooltip' }],
      activate: [{ action: 'open_panel', panel: 'info' }],
    },
  };
  const window2: Region = {
    id: 'w2', label: 'Window 2', shape: { type: 'rect', x: 20, y: 0, width: 10, height: 10 }, target_layer: 'bg',
    effects: { glow: { type: 'glow', intensity: 0 }, px: { type: 'pixelate', block_size: 1 } },
  };
  const base: Manifest = {
    format: 'aureom-active-visual', version: '1.0', document: { id: 'd', title: 'D', width: 100, height: 50 },
    layers: [{ id: 'bg', type: 'text', text: 'x', x: 0, y: 0 }, { id: 'note', type: 'text', text: 'n', x: 0, y: 0, visible: false }],
    regions: [window1, window2],
    groups: { windows: { label: 'Windows', regions: ['w1', 'w2'] } },
    panels: { info: { title: 'Info', text: 'Text' }, other: { title: 'Other', text: 'More' } },
    animations: {
      pulse: { type: 'pulse', region: 'w2', effect: 'glow', property: 'intensity', from: 0.2, to: 1, duration_ms: 1000, iterations: 2, easing: 'linear' },
      fade: { type: 'fade', region: 'w2', effect: 'px', property: 'block_size', from: 1, to: 9, duration_ms: 400, easing: 'linear' },
    },
    preview: 'preview.png',
  };
  const merged = { ...base, ...overrides };
  expect(errorsOnly(validateManifest(merged)), 'test fixture must be a valid manifest').toEqual([]);
  return merged;
}

function clock() {
  let t = 0;
  return { now: () => t, set: (v: number) => { t = v; }, advance: (d: number) => { t += d; } };
}

const glow = (m: Machine, region = 'w1', t?: number) => m.propValue(region, 'glow', 'intensity', t);

describe('state priority', () => {
  it('resolves saved < set_effect < selected < hover < focus < animation', () => {
    const c = clock();
    const manifest = doc();
    manifest.regions![0].events!.focus = [{ action: 'set_effect', effect: 'glow', property: 'intensity', value: 0.1 }];
    manifest.animations!.w1 = { type: 'pulse', region: 'w1', effect: 'glow', property: 'intensity', from: 1.5, to: 2, duration_ms: 1000, easing: 'linear' };
    manifest.regions![0].events!.blur = [{ action: 'play_animation', animation: 'w1' }];
    const m = new Machine(manifest, { now: c.now });
    m.load();
    expect(glow(m)).toBe(0);                    // saved value
    m.focus('w1');                              // runs set_effect 0.1, and the focus state applies on top
    expect(glow(m)).toBe(0.9);
    m.focus(null);                              // blur starts the animation; set_effect value is underneath
    expect(glow(m)).toBe(1.5);                  // a running animation beats everything
    c.advance(2000);
    m.tick();
    expect(glow(m)).toBe(0.1);                  // pulse reverts: the set_effect override remains
    m.activate('w1');
    expect(glow(m)).toBe(0.3);                  // selected beats set_effect
    m.pointerMove('w1');
    expect(glow(m)).toBe(0.6);                  // hover beats selected
    m.focus('w1');
    expect(glow(m)).toBe(0.9);                  // focus beats hover
    m.pointerMove(null);
    m.focus(null);
    c.advance(5000);
    m.tick();
    expect(glow(m)).toBe(0.3);                  // still selected: selection persists
  });

  it('interaction state never leaks into the manifest', () => {
    const manifest = doc();
    const frozen = JSON.stringify(manifest);
    const m = new Machine(manifest);
    m.load();
    m.pointerMove('w1'); m.activate('w1'); m.focus('w2'); m.activate('w2'); m.reset();
    expect(JSON.stringify(manifest)).toBe(frozen);
  });

  it('returns effects in the fixed pipeline order regardless of how they are written', () => {
    const manifest = doc();
    manifest.regions![1].effects = { z: { type: 'outline' }, a: { type: 'glow' }, m: { type: 'opacity' }, b: { type: 'tint' },
      q: { type: 'blur' }, k: { type: 'spotlight' }, c: { type: 'saturation' }, d: { type: 'contrast' }, e: { type: 'brightness' }, f: { type: 'pixelate' } };
    manifest.animations = {};
    const m = new Machine(manifest);
    expect(m.effectsFor('w2').map((e) => e.type)).toEqual(LIMITS && ['pixelate', 'blur', 'brightness', 'contrast', 'saturation', 'tint',
      'spotlight', 'opacity', 'glow', 'outline']);
    expect(m.effectsFor('w2')[5].props).toMatchObject({ colour: '#5AD8E6', amount: 0.25, mode: 'normal' }); // documented defaults
    expect(m.effectsFor('nope')).toEqual([]);
  });
});

describe('triggers and actions', () => {
  it('pointer enter and leave fire once per transition', () => {
    const manifest = doc();
    const counter: Action = { action: 'toggle_layer', layer: 'note' };
    manifest.regions![0].events = { pointer_enter: [counter], pointer_leave: [counter] };
    const m = new Machine(manifest);
    m.load();
    m.pointerMove('w1'); m.pointerMove('w1', { x: 1, y: 1 }); m.pointerMove('w1', { x: 2, y: 2 });
    expect(m.isLayerVisible('note')).toBe(true);     // toggled exactly once
    m.pointerMove('w2');
    expect(m.isLayerVisible('note')).toBe(false);    // leave toggled it back
    m.pointerMove(null); m.pointerMove(null);
    expect(m.isLayerVisible('note')).toBe(false);
  });

  it('activation selects, then runs the handler; keyboard and pointer share one path', () => {
    const m = new Machine(doc());
    m.load();
    expect(m.activate('w1')).toEqual([]);
    expect(m.selected).toEqual(['w1']);
    expect(m.panel).toBe('info');
    m.activate('w2');
    expect(m.selected).toEqual(['w2']);              // single selection replaces
    m.activate(null);
    expect(m.selected).toEqual([]);                  // activating empty space clears
    expect(m.dismiss()).toBe('panel');
    expect(m.panel).toBeNull();
    expect(m.dismiss()).toBeNull();
  });

  it('supports multiple selection, no selection, and unselectable regions', () => {
    const multi = new Machine(doc({ settings: { selection: 'multiple' } }));
    multi.load();
    multi.activate('w1'); multi.activate('w2');
    expect(multi.selected).toEqual(['w1', 'w2']);
    multi.activate('w1');
    expect(multi.selected).toEqual(['w2']);          // toggles off
    multi.activate(null);
    expect(multi.selected).toEqual(['w2']);          // empty space does not clear a multi-selection

    const none = new Machine(doc({ settings: { selection: 'none' } }));
    none.load();
    none.activate('w1');
    expect(none.selected).toEqual([]);
    expect(none.panel).toBe('info');                 // actions still run

    const manifest = doc();
    manifest.regions![0].selectable = false;
    manifest.regions![1].interactive = false;
    const m = new Machine(manifest);
    m.load();
    m.activate('w1');
    expect(m.selected).toEqual([]);
    m.activate('w2');
    expect(m.selected).toEqual([]);
  });

  it('set_effect targets self, another region, or a group', () => {
    const manifest = doc();
    manifest.regions![0].events = { activate: [
      { action: 'set_effect', effect: 'glow', property: 'intensity', value: 0.5, group: 'windows' },
      { action: 'set_effect', effect: 'px', property: 'block_size', value: 12, region: 'w2' },
      { action: 'set_effect', effect: 'edge', property: 'colour', value: '#FF0000' },
      { action: 'set_effect', effect: 'px', property: 'block_size', value: 99, group: 'windows' }, // w1 has no px: skipped there
    ] };
    manifest.regions![0].states = {};
    manifest.regions![0].selectable = false;
    const m = new Machine(manifest);
    m.load();
    m.activate('w1');
    expect(glow(m, 'w1')).toBe(0.5);
    expect(glow(m, 'w2')).toBe(0.5);
    expect(m.propValue('w2', 'px', 'block_size')).toBe(99);
    expect(m.propValue('w1', 'edge', 'colour')).toBe('#FF0000');
    expect(m.propValue('w1', 'px', 'block_size')).toBeUndefined();
  });

  it('clamps runtime values to the declared range', () => {
    const manifest = doc();
    manifest.regions![0].events = { activate: [{ action: 'set_effect', effect: 'glow', property: 'intensity', value: 1e9 }] };
    manifest.regions![0].states = {};
    const m = new Machine(manifest); // deliberately not validated: the runtime must still hold the line
    m.load();
    m.activate('w1');
    expect(glow(m)).toBe(2);
  });

  it('tooltips belong to the region that showed them', () => {
    const m = new Machine(doc());
    m.load();
    m.pointerMove('w1');
    expect(m.tooltip).toEqual({ owner: 'w1', anchor: 'w1', text: 'Tip' });
    m.pointerMove('w2');
    expect(m.tooltip).toBeNull();
    m.pointerMove('w1');
    expect(m.dismiss()).toBe('tooltip');
    expect(m.tooltip).toBeNull();
  });

  it('links are requests to the host, never actions the machine performs', () => {
    const manifest = doc();
    manifest.regions![0].events = { activate: [
      { action: 'open_link', url: 'https://example.org/docs', label: 'Docs' },
      { action: 'navigate_document', href: 'other.aav' },
      { action: 'reset_view' },
      { action: 'select_region', region: 'w2', reveal: true },
    ] };
    const m = new Machine(manifest);
    expect(m.load()).toEqual([]);                    // nothing is requested merely by opening a document
    expect(m.pointerMove('w1')).toEqual([]);
    expect(m.focus('w1')).toEqual([]);
    expect(m.activate('w1')).toEqual([
      { type: 'open_link', url: 'https://example.org/docs', label: 'Docs', region: 'w1' },
      { type: 'navigate_document', href: 'other.aav', label: undefined, region: 'w1' },
      { type: 'reset_view' },
      { type: 'reveal', region: 'w2' },
    ]);
  });

  it('applies the default state and runs document_load', () => {
    const manifest = doc({
      default_state: { selected: ['w2', 'w1'], panel: 'other' },
      events: { document_load: [{ action: 'toggle_layer', layer: 'note', mode: 'show' }, { action: 'set_effect', region: 'w2', effect: 'px', property: 'block_size', value: 6 }] },
    });
    const m = new Machine(manifest);
    m.load();
    expect(m.selected).toEqual(['w2']);              // single-selection documents keep one
    expect(m.panel).toBe('other');
    expect(m.isLayerVisible('note')).toBe(true);
    expect(m.propValue('w2', 'px', 'block_size')).toBe(6);
    m.activate('w1'); m.closePanel();
    m.reset();
    expect(m.snapshot()).toEqual({ selected: ['w2'], panel: 'other' });
  });

  it('follows links from panel text', () => {
    const m = new Machine(doc());
    m.load();
    expect(m.followInternalLink({ kind: 'region', id: 'w2' })).toEqual([{ type: 'reveal', region: 'w2' }]);
    expect(m.selected).toEqual(['w2']);
    m.followInternalLink({ kind: 'panel', id: 'other' });
    expect(m.panel).toBe('other');
    m.followInternalLink({ kind: 'panel', id: 'missing' });
    expect(m.panel).toBe('other');
  });
});

describe('loop and work bounds', () => {
  it('actions cannot re-trigger handlers, so mutual references terminate', () => {
    const manifest = doc();
    // Each region's handler selects and reveals the other; if selection fired "activate" this would never end.
    manifest.regions![0].events = { activate: [{ action: 'select_region', region: 'w2' }], focus: [{ action: 'select_region', region: 'w2' }] };
    manifest.regions![1].events = { activate: [{ action: 'select_region', region: 'w1' }], focus: [{ action: 'select_region', region: 'w1' }] };
    const m = new Machine(manifest);
    m.load();
    m.activate('w1');
    expect(m.selected).toEqual(['w2']);
    expect(m.budgetExceeded).toBe(false);
  });

  it('enforces the per-event action budget even for manifests that skipped validation', () => {
    const manifest = doc();
    manifest.regions![0].events = { activate: Array.from({ length: 5000 }, (): Action => ({ action: 'toggle_layer', layer: 'note' })) };
    const m = new Machine(manifest);
    m.load();
    m.activate('w1');
    expect(m.budgetExceeded).toBe(true);
    // 256 toggles ran (an even number), so the layer is back where it started.
    expect(LIMITS.runtime.max_actions_per_dispatch).toBe(256);
    expect(m.isLayerVisible('note')).toBe(false);
    m.pointerMove('w1');
    expect(m.budgetExceeded).toBe(false);            // the budget is per event
  });

  it('limits how many animations run at once', () => {
    const manifest = doc();
    manifest.animations = Object.fromEntries(Array.from({ length: 40 }, (_, i) => [`a${i}`,
      { type: 'pulse', region: 'w2', effect: 'glow', property: 'intensity', from: 0, to: 1, duration_ms: 1000 }])) as Manifest['animations'];
    manifest.regions![0].events = { activate: Object.keys(manifest.animations!).slice(0, 32).map((animation): Action => ({ action: 'play_animation', animation })) };
    const m = new Machine(manifest);
    m.load();
    m.activate('w1');
    expect(m.runningAnimations().length).toBe(LIMITS.runtime.max_running_animations);
  });
});

describe('animation and transitions', () => {
  it('pulse rises and falls, repeats, then reverts', () => {
    const c = clock();
    const manifest = doc();
    manifest.regions![0].events = { activate: [{ action: 'play_animation', animation: 'pulse' }] };
    const m = new Machine(manifest, { now: c.now });
    m.load();
    m.activate('w1');
    const at = (t: number) => { c.set(t); m.tick(); return glow(m, 'w2'); };
    expect(at(0)).toBeCloseTo(0.2);
    expect(at(250)).toBeCloseTo(0.6);
    expect(at(500)).toBeCloseTo(1);
    expect(at(750)).toBeCloseTo(0.6);
    expect(at(1250)).toBeCloseTo(0.6);              // second iteration
    expect(m.isAnimating()).toBe(true);
    expect(at(2000)).toBe(0);                       // finished: reverts to the saved value
    expect(m.isAnimating()).toBe(false);
  });

  it('fade runs once and holds its end value; stop_animation cancels without holding', () => {
    const c = clock();
    const manifest = doc();
    manifest.regions![0].events = { activate: [{ action: 'play_animation', animation: 'fade' }], focus: [{ action: 'stop_animation' }] };
    const m = new Machine(manifest, { now: c.now });
    m.load();
    m.activate('w1');
    c.set(200);
    expect(m.propValue('w2', 'px', 'block_size')).toBeCloseTo(5);
    c.set(400); m.tick();
    expect(m.propValue('w2', 'px', 'block_size')).toBe(9);
    c.set(9999); m.tick();
    expect(m.propValue('w2', 'px', 'block_size')).toBe(9);   // held
    m.reset();
    m.activate('w1');
    c.advance(100);
    m.focus('w1');                                            // stop_animation
    expect(m.isAnimating()).toBe(false);
    expect(m.propValue('w2', 'px', 'block_size')).toBe(1);    // nothing held
  });

  it('set_effect transitions interpolate and can be retargeted mid-flight', () => {
    const c = clock();
    const manifest = doc();
    manifest.regions![0].states = {};
    manifest.regions![0].events = {
      pointer_enter: [{ action: 'set_effect', effect: 'glow', property: 'intensity', value: 0.8, duration_ms: 200, easing: 'linear' }],
      pointer_leave: [{ action: 'set_effect', effect: 'glow', property: 'intensity', value: 0, duration_ms: 200, easing: 'linear' }],
    };
    const m = new Machine(manifest, { now: c.now });
    m.load();
    m.pointerMove('w1');
    c.set(100);
    expect(glow(m)).toBeCloseTo(0.4);
    m.pointerMove(null);                                      // leaves half way: fades back from 0.4, no jump
    expect(glow(m)).toBeCloseTo(0.4);
    c.set(200);
    expect(glow(m)).toBeCloseTo(0.2);
    c.set(300); m.tick();
    expect(glow(m)).toBe(0);
    expect(m.isAnimating()).toBe(false);
  });

  it('reduced motion skips movement but keeps end states', () => {
    const c = clock();
    const manifest = doc();
    manifest.regions![0].states = {};
    manifest.regions![0].events = { activate: [{ action: 'play_animation', animation: 'pulse' }, { action: 'play_animation', animation: 'fade' },
      { action: 'set_effect', effect: 'glow', property: 'intensity', value: 0.7, duration_ms: 5000 }] };
    const m = new Machine(manifest, { now: c.now, reducedMotion: true });
    m.load();
    m.activate('w1');
    expect(m.isAnimating()).toBe(false);
    expect(glow(m, 'w2')).toBe(0);                            // the pulse is skipped entirely
    expect(m.propValue('w2', 'px', 'block_size')).toBe(9);    // the fade jumps to its end
    expect(glow(m, 'w1')).toBe(0.7);                          // transitions are instant

    const live = new Machine(manifest, { now: c.now });
    live.load();
    live.activate('w1');
    expect(live.isAnimating()).toBe(true);
    live.setReducedMotion(true);                              // switching it on settles what is moving
    expect(live.isAnimating()).toBe(false);
    expect(live.propValue('w2', 'px', 'block_size')).toBe(9);
  });

  it('easing is bounded and monotonic', () => {
    for (const name of ['linear', 'ease-in-out']) {
      expect(ease(name, 0)).toBeCloseTo(0);
      expect(ease(name, 1)).toBeCloseTo(1);
      let last = -1;
      for (let p = 0; p <= 1; p += 0.05) { const v = ease(name, p); expect(v).toBeGreaterThanOrEqual(last); last = v; }
    }
  });

  it('only a pointer-following light makes plain movement a state change', () => {
    const manifest = doc();
    manifest.regions![1].effects = { torch: { type: 'spotlight', follow_pointer: true } };
    manifest.animations = {};
    const m = new Machine(manifest);
    m.load();
    m.pointerMove('w1', { x: 1, y: 1 });
    const r1 = m.revision;
    m.pointerMove('w1', { x: 2, y: 2 });
    expect(m.revision).toBe(r1);                               // nothing to redraw
    m.pointerMove('w2', { x: 21, y: 1 });
    const r2 = m.revision;
    m.pointerMove('w2', { x: 22, y: 2 });
    expect(m.revision).toBeGreaterThan(r2);                    // the light moved
    expect(m.pointer).toEqual({ x: 22, y: 2 });
  });
});
