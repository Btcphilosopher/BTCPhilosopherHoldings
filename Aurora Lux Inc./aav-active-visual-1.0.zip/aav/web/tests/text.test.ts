import { describe, expect, it } from 'vitest';
import { documentHrefProblem, externalUrlProblem, isSafeExternalUrl } from '../src/core/links';
import { classifyTarget, parseInline, parseText, plainText, textLinks } from '../src/core/text';

const SAFE = ['https://example.org', 'https://example.org/', 'https://sub.example.org:8443/a/b?c=d&e=f#g', 'https://example.org/%E2%9C%93'];
const UNSAFE: unknown[] = ['http://example.org/', 'HTTPS://example.org/', 'javascript:alert(1)', 'JaVaScRiPt:alert(1)',
  'data:text/html,<script>alert(1)</script>', 'file:///etc/passwd', 'ftp://example.org/x', 'blob:https://x/y', 'vbscript:msgbox(1)',
  '//example.org/', '/relative', 'example.org', '', ' https://example.org/', 'https://example.org/a b', 'https://example.org/\n',
  'https://example.org/\t', 'https://', 'https:///path', 'https://user@example.org/', 'https://user:pw@example.org/',
  'https://example.org\\@evil.example/', 'https://example.org@evil.example/', 'https://[::1]/', 'https://example.org:99999/',
  'https://.example.org/', 'https://a..b/', 'https://example.org/' + 'a'.repeat(3000), 42, null, ['https://example.org/']];

describe('link safety (same vectors as the Python tests)', () => {
  it.each(SAFE)('accepts %s', (url) => expect(externalUrlProblem(url)).toBeNull());
  it.each(UNSAFE.map((u) => [u]))('rejects %j', (url) => {
    expect(externalUrlProblem(url)).not.toBeNull();
    expect(isSafeExternalUrl(url)).toBe(false);
  });
  it.each([['other.aav', true], ['rooms/first-floor.aav', true], ['https://example.org/a.aav', true], ['../other.aav', false],
    ['rooms/../other.aav', false], ['/abs.aav', false], ['./x.aav', false], ['file:///x.aav', false], ['javascript:x.aav', false],
    ['other.html', false], ['other.aav?x=1', false], ['a\\b.aav', false], ['http://example.org/a.aav', false], ['', false],
    ['a b.aav', false], ['x//y.aav', false]] as [string, boolean][])('document link %j -> %j', (href, ok) => {
    expect(documentHrefProblem(href) === null).toBe(ok);
  });
});

describe('restricted text', () => {
  it('parses blocks and inline formatting', () => {
    const blocks = parseText('# Title\n\nFirst **bold** and *italic* with `code`.\nSecond line.\n\n- one\n- two [link](https://example.org/x)');
    expect(blocks.map((b) => b.type)).toEqual(['heading', 'paragraph', 'list']);
    expect(blocks[1]).toEqual({ type: 'paragraph', content: [
      { type: 'text', text: 'First ' }, { type: 'bold', text: 'bold' }, { type: 'text', text: ' and ' }, { type: 'italic', text: 'italic' },
      { type: 'text', text: ' with ' }, { type: 'code', text: 'code' }, { type: 'text', text: '.' }, { type: 'break' },
      { type: 'text', text: 'Second line.' }] });
    expect(blocks[2].type === 'list' && blocks[2].items[1][1]).toEqual({ type: 'link', text: 'link', target: { kind: 'external', url: 'https://example.org/x' } });
  });

  it('never produces markup: HTML is ordinary text', () => {
    const hostile = '<script>alert(1)</script> <img src=x onerror=alert(1)> <a href="javascript:alert(1)">x</a> &lt;b&gt;';
    const blocks = parseText(hostile);
    expect(blocks).toEqual([{ type: 'paragraph', content: [{ type: 'text', text: hostile }] }]);
    expect(plainText(hostile)).toBe(hostile);
  });

  it('turns only safe targets into links; everything else stays visible as text', () => {
    for (const target of ['javascript:alert(1)', 'data:text/html,x', 'http://example.org/', 'file:///etc/passwd', '//example.org',
      'https://user@evil.example/', 'vbscript:x', '#unknown:thing', '']) {
      const nodes = parseInline(`Click [here](${target}) now`);
      expect(nodes.every((n) => n.type === 'text'), target).toBe(true);
      expect(nodes.map((n) => (n.type === 'text' ? n.text : '')).join('')).toBe(`Click [here](${target}) now`);
      expect(classifyTarget(target)).toBeNull();
    }
    expect(parseInline('[](https://example.org/)')[0].type).toBe('text'); // a link needs a visible label
    expect(classifyTarget('#region:window-01')).toEqual({ kind: 'region', id: 'window-01' });
    expect(classifyTarget('#panel:help')).toEqual({ kind: 'panel', id: 'help' });
  });

  it('honours escapes and keeps code spans literal', () => {
    expect(parseInline('\\*not italic\\* and \\[not a link](https://example.org/)')).toEqual([
      { type: 'text', text: '*not italic* and [not a link](https://example.org/)' }]);
    expect(parseInline('`[x](https://example.org/)`')).toEqual([{ type: 'code', text: '[x](https://example.org/)' }]);
  });

  it('lists the raw link targets for validation, as the Python implementation does', () => {
    const text = 'See [docs](https://example.org/a) and [room](#region:r1), not \\[this](javascript:x) or `[code](https://x.example/)`.';
    expect(textLinks(text)).toEqual([{ label: 'docs', target: 'https://example.org/a' }, { label: 'room', target: '#region:r1' }]);
    expect(textLinks('[bad](javascript:alert(1))')).toEqual([{ label: 'bad', target: 'javascript:alert(1' }]);
    expect(textLinks("<a href='javascript:alert(1)'>x</a>")).toEqual([]);
  });

  it('handles odd input without throwing', () => {
    for (const input of ['', '\n\n\n', '**', '*', '`', '[', '[]()', '- ', '# ', '\r\n\r\n- a\r\n- b', '*'.repeat(5000), '[x]('.repeat(2000)]) {
      expect(() => parseText(input)).not.toThrow();
    }
    expect(parseText('\r\n- a\r\n- b')).toEqual([{ type: 'list', items: [[{ type: 'text', text: 'a' }], [{ type: 'text', text: 'b' }]] }]);
  });
});
