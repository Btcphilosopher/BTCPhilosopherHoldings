import { describe, expect, it } from 'vitest';
import { IDENTITY_CHAIN, blockSize, blur, blurAlpha, blurReach, boxesForGauss, buildChain, colourChain, isIdentityChain, maskOutline,
  parseColour, pixelate } from '../src/core/pixels';
import type { ColourChain, PixelBuffer } from '../src/core/pixels';
import type { ResolvedEffect } from '../src/core/state';

function buffer(width: number, height: number, fill: (x: number, y: number) => [number, number, number, number]): PixelBuffer {
  const data = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) data.set(fill(x, y), (y * width + x) * 4);
  return { data, width, height };
}
const px = (img: PixelBuffer, x: number, y: number) => [...img.data.slice((y * img.width + x) * 4, (y * img.width + x) * 4 + 4)];
const flat = (rgba: [number, number, number, number], w = 4, h = 4) => buffer(w, h, () => rgba);
const chain = (partial: Partial<ColourChain>): ColourChain => ({ ...IDENTITY_CHAIN, ...partial });

describe('colour stage', () => {
  it('the identity chain changes nothing', () => {
    const img = buffer(8, 8, (x, y) => [x * 30, y * 30, 77, 200]);
    const before = [...img.data];
    colourChain(img, IDENTITY_CHAIN, 0, 0);
    expect([...img.data]).toEqual(before);
    expect(isIdentityChain(IDENTITY_CHAIN)).toBe(true);
  });

  it('each operation follows its documented formula', () => {
    const run = (c: Partial<ColourChain>, rgba: [number, number, number, number] = [100, 150, 200, 255]) => {
      const img = flat(rgba, 1, 1);
      colourChain(img, chain(c), 0, 0);
      return px(img, 0, 0);
    };
    expect(run({ brightness: 2 })).toEqual([200, 255, 255, 255]);                   // multiply, clamp
    expect(run({ brightness: 0 })).toEqual([0, 0, 0, 255]);
    expect(run({ contrast: 2 })).toEqual([73, 173, 255, 255]);                      // (c - 0.5) * 2 + 0.5
    expect(run({ contrast: 0 })).toEqual([128, 128, 128, 255]);
    const luma = Math.round(0.2126 * 100 + 0.7152 * 150 + 0.0722 * 200);
    expect(run({ saturation: 0 })).toEqual([luma, luma, luma, 255]);                // Rec. 709 luma
    expect(run({ opacity: 0.5 })).toEqual([100, 150, 200, 128]);                    // alpha only
    expect(run({ tint: { r: 1, g: 0, b: 0, amount: 0.5, mode: 0 } })).toEqual([178, 75, 100, 255]);
    expect(run({ tint: { r: 1, g: 0, b: 0, amount: 1, mode: 1 } })).toEqual([100, 0, 0, 255]);      // multiply
    expect(run({ tint: { r: 1, g: 0, b: 0, amount: 1, mode: 2 } })).toEqual([255, 150, 200, 255]);  // screen
    expect(run({ opacity: 0.5 }, [10, 20, 30, 0])).toEqual([10, 20, 30, 0]);        // fully transparent pixels are left alone
  });

  it('applies operations in the fixed order, which is observable', () => {
    // brightness before contrast: (0.4 * 2 - 0.5) * 2 + 0.5 = 1.1 -> 255. The other order gives 153.
    const img = flat([102, 102, 102, 255], 1, 1);
    colourChain(img, chain({ brightness: 2, contrast: 2 }), 0, 0);
    expect(px(img, 0, 0)[0]).toBe(255);
    // saturation before tint: grey first, then tinted. The other order would desaturate the tint.
    const img2 = flat([255, 0, 0, 255], 1, 1);
    colourChain(img2, chain({ saturation: 0, tint: { r: 0, g: 0, b: 1, amount: 0.5, mode: 0 } }), 0, 0);
    expect(px(img2, 0, 0)).toEqual([27, 27, 155, 255]);
    // tint before spotlight: the light dims the tinted colour.
    const img3 = flat([200, 200, 200, 255], 1, 1);
    colourChain(img3, chain({ tint: { r: 1, g: 1, b: 1, amount: 1, mode: 0 }, spotlight: { x: 999, y: 999, radius: 1, falloff: 1, intensity: 1, ambient: 0.5, r: 1, g: 1, b: 1 } }), 0, 0);
    expect(px(img3, 0, 0)).toEqual([128, 128, 128, 255]);
    // intermediate values are not clamped between brightness and contrast...
    const img4 = flat([200, 200, 200, 255], 1, 1);
    colourChain(img4, chain({ brightness: 2, contrast: 0.5 }), 0, 0);
    expect(px(img4, 0, 0)[0]).toBe(255); // (1.569 - 0.5) * 0.5 + 0.5 = 1.03, whereas clamping first would give 191
  });

  it('spotlight is a radial field in document coordinates', () => {
    const img = flat([100, 100, 100, 255], 21, 1);
    const light = { x: 110.5, y: 50.5, radius: 10, falloff: 1, intensity: 1, ambient: 0.5, r: 1, g: 0.5, b: 0 };
    colourChain(img, chain({ spotlight: light }), 100, 50); // buffer origin is (100, 50) in the document
    expect(px(img, 10, 0)).toEqual([150, 100, 50, 255]);    // centre: ambient + full light, tinted by its colour
    expect(px(img, 15, 0)).toEqual([100, 75, 50, 255]);     // half way out: linear falloff
    expect(px(img, 0, 0)).toEqual([50, 50, 50, 255]);       // at the radius: ambient only
    expect(px(img, 20, 0)).toEqual([50, 50, 50, 255]);
    const steep = flat([100, 100, 100, 255], 21, 1);
    colourChain(steep, chain({ spotlight: { ...light, falloff: 2, r: 1, g: 1, b: 1 } }), 100, 50);
    expect(px(steep, 15, 0)[0]).toBe(75);                   // (1 - 0.5)^2 = 0.25
  });

  it('builds the chain from resolved effects, with defaults and pointer following', () => {
    const effects: ResolvedEffect[] = [
      { id: 'a', type: 'brightness', props: { amount: 1.5 } },
      { id: 'b', type: 'tint', props: { colour: '#FF000080', amount: 0.5, mode: 'screen' } },
      { id: 'c', type: 'spotlight', props: { colour: '#FFFFFF', intensity: 1, radius: 50, falloff: 2, ambient: 1, follow_pointer: true } },
      { id: 'd', type: 'glow', props: { intensity: 1 } }, // not part of the colour stage
    ];
    const c = buildChain(effects, { x: 10, y: 20 }, null);
    expect(c.brightness).toBe(1.5);
    expect(c.tint).toMatchObject({ r: 1, g: 0, b: 0, mode: 2 });
    expect(c.tint!.amount).toBeCloseTo(0.5 * (128 / 255));          // colour alpha scales the amount
    expect(c.spotlight).toMatchObject({ x: 10, y: 20, radius: 50 });  // region centre by default
    expect(buildChain(effects, { x: 10, y: 20 }, { x: 77, y: 88 }).spotlight).toMatchObject({ x: 77, y: 88 });
    const off = buildChain([{ id: 't', type: 'tint', props: { colour: '#FF0000', amount: 0 } },
      { id: 's', type: 'spotlight', props: { colour: '#FFFFFF', intensity: 0, ambient: 1, radius: 5, falloff: 1 } }], { x: 0, y: 0 }, null);
    expect(isIdentityChain(off)).toBe(true);                         // effects at their neutral values cost nothing
    expect(parseColour('#102030')).toEqual({ r: 16 / 255, g: 32 / 255, b: 48 / 255, a: 1 });
  });
});

describe('pixelation', () => {
  const ramp = (w: number, h: number) => buffer(w, h, (x, y) => [x * 10, y * 10, 0, 255]);

  it('averages whole blocks', () => {
    const img = ramp(8, 4);
    pixelate(img, 4, 0, 0);
    expect(px(img, 0, 0)).toEqual([15, 15, 0, 255]); // mean of 0,10,20,30
    expect(px(img, 3, 3)).toEqual([15, 15, 0, 255]);
    expect(px(img, 4, 0)).toEqual([55, 15, 0, 255]);
  });

  it('block size 1 or less is the identity, and fractional sizes round', () => {
    const img = ramp(6, 6), before = [...img.data];
    pixelate(img, 1, 0, 0);
    expect([...img.data]).toEqual(before);
    expect([0, 0.4, 1, 1.4, 1.5, 7.6, Number.NaN].map(blockSize)).toEqual([1, 1, 1, 1, 2, 8, 1]);
  });

  it('blocks are anchored to the document origin, not to the buffer', () => {
    // The same document pixels read through two different windows must land in the same blocks.
    const whole = buffer(16, 8, (x, y) => [x * 13 % 256, y * 29 % 256, (x * y) % 256, 255]);
    const reference = { data: whole.data.slice(), width: 16, height: 8 };
    pixelate(reference, 4, 0, 0);
    // A window that starts on a block boundary reproduces the reference exactly.
    const aligned = buffer(8, 8, (x, y) => px(whole, x + 4, y) as [number, number, number, number]);
    pixelate(aligned, 4, 4, 0);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) expect(px(aligned, x, y)).toEqual(px(reference, x + 4, y));
    // A window offset by 3 pixels still breaks blocks at document x = 8 and 12, not at its own 4 and 8.
    const shifted = buffer(8, 8, (x, y) => px(whole, x + 7, y) as [number, number, number, number]);
    pixelate(shifted, 4, 7, 0);
    expect(px(shifted, 1, 0)).toEqual(px(reference, 8, 0));   // document x = 8..11 is a whole block inside the window
    expect(px(shifted, 4, 0)).toEqual(px(reference, 11, 0));
    expect(px(shifted, 1, 0)).toEqual(px(shifted, 4, 0));
    expect(px(shifted, 0, 0)).not.toEqual(px(shifted, 1, 0)); // document x = 7 belongs to the previous block
  });

  it('weights colour by alpha so transparent pixels do not darken a block', () => {
    const img = buffer(2, 1, (x) => (x === 0 ? [255, 0, 0, 255] : [0, 0, 0, 0]));
    pixelate(img, 2, 0, 0);
    expect(px(img, 0, 0)).toEqual([255, 0, 0, 128]);
    const empty = flat([9, 9, 9, 0], 2, 2);
    pixelate(empty, 2, 0, 0);
    expect(px(empty, 0, 0)).toEqual([0, 0, 0, 0]);
  });
});

describe('blur', () => {
  it('keeps flat areas flat and preserves total energy away from edges', () => {
    const img = flat([120, 60, 30, 255], 24, 24);
    blur(img, 6);
    expect(px(img, 0, 0)).toEqual([120, 60, 30, 255]); // clamped edges: no darkening at the border
    expect(px(img, 12, 12)).toEqual([120, 60, 30, 255]);
    const spike = buffer(41, 41, (x, y) => (x === 20 && y === 20 ? [255, 255, 255, 255] : [0, 0, 0, 255]));
    blur(spike, 4);
    expect(px(spike, 20, 20)[0]).toBeLessThan(60);
    expect(px(spike, 20, 20)[0]).toBeGreaterThan(px(spike, 23, 20)[0]);
    expect(px(spike, 17, 20)[0]).toBe(px(spike, 23, 20)[0]); // symmetric
    expect(px(spike, 20, 17)[0]).toBe(px(spike, 23, 20)[0]);
    expect(px(spike, 0, 0)[0]).toBe(0);
  });

  it('radius 0 is the identity', () => {
    const img = buffer(5, 5, (x, y) => [x * 50, y * 50, 0, 255]), before = [...img.data];
    blur(img, 0);
    expect([...img.data]).toEqual(before);
    expect(blurReach(0)).toBe(0);
    expect(blurReach(10)).toBeGreaterThanOrEqual(15);
  });

  it('does not bleed the colour of transparent pixels', () => {
    const img = buffer(9, 1, (x) => (x < 4 ? [255, 0, 0, 255] : [0, 255, 0, 0]));
    blur(img, 3);
    const edge = px(img, 4, 0);
    expect(edge[1]).toBe(0);                 // no green from the invisible pixels
    expect(edge[0]).toBe(255);
    expect(edge[3]).toBeGreaterThan(0);
    expect(edge[3]).toBeLessThan(255);
  });

  it('box sizes approximate the requested Gaussian', () => {
    for (const sigma of [1, 2.5, 8, 20]) {
      const boxes = boxesForGauss(sigma);
      expect(boxes.every((b) => b % 2 === 1 && b >= 1)).toBe(true);
      const variance = boxes.reduce((sum, b) => sum + (b * b - 1) / 12, 0);
      expect(Math.sqrt(variance)).toBeGreaterThan(sigma * 0.8);
      expect(Math.sqrt(variance)).toBeLessThan(sigma * 1.2);
    }
    const alpha = new Uint8ClampedArray(31 * 31);
    alpha[15 * 31 + 15] = 255;
    const out = blurAlpha(alpha, 31, 31, 6);
    expect(out.reduce((a, b) => a + b, 0)).toBeCloseTo(255, 0);
  });

  it('derives an outline band just outside a mask', () => {
    const size = 21, alpha = new Uint8ClampedArray(size * size);
    for (let y = 7; y < 14; y++) for (let x = 7; x < 14; x++) alpha[y * size + x] = 255;
    const band = maskOutline(alpha, size, size, 2);
    expect(band[10 * size + 10]).toBe(0);   // inside the mask
    expect(band[10 * size + 6]).toBe(255);  // just outside the edge
    expect(band[10 * size + 0]).toBe(0);    // far away
  });
});
