import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { Manifest } from '../src/core/types';

export const ROOT = resolve(__dirname, '..', '..');
export const CONFORMANCE = JSON.parse(readFileSync(resolve(ROOT, 'conformance', 'manifests.json'), 'utf-8')) as {
  base: Manifest;
  cases: ConformanceCase[];
};

export interface ConformanceCase {
  name: string;
  ops?: { op: 'set' | 'remove'; path: string; value?: unknown; repeat?: { count: number; value: unknown };
          repeat_string?: { count: number; value: string } }[];
  manifest?: unknown;
  codes: string[];
  schema: 'valid' | 'invalid' | 'skip';
}

/** Apply the conformance patch operations (see conformance/manifests.json). */
export function applyOps(base: unknown, ops: NonNullable<ConformanceCase['ops']>): unknown {
  const doc = structuredClone(base) as Record<string, unknown>;
  for (const op of ops) {
    const parts = op.path.split('/').slice(1);
    let node: any = doc; // eslint-disable-line @typescript-eslint/no-explicit-any
    for (const part of parts.slice(0, -1)) node = Array.isArray(node) ? node[Number(part)] : node[part];
    const last = parts[parts.length - 1];
    if (op.op === 'remove') {
      if (Array.isArray(node)) node.splice(Number(last), 1);
      else delete node[last];
      continue;
    }
    const value = op.repeat ? Array.from({ length: op.repeat.count }, () => structuredClone(op.repeat!.value))
      : op.repeat_string ? op.repeat_string.value.repeat(op.repeat_string.count)
        : structuredClone(op.value);
    if (Array.isArray(node)) {
      if (last === '-') node.push(value);
      else node[Number(last)] = value;
    } else node[last] = value;
  }
  return doc;
}

export const caseManifest = (c: ConformanceCase): unknown =>
  c.manifest !== undefined ? structuredClone(c.manifest) : applyOps(CONFORMANCE.base, c.ops ?? []);

export const baseManifest = (): Manifest => structuredClone(CONFORMANCE.base);
