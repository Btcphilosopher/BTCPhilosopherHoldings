import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import Ajv2020 from 'ajv/dist/2020';
import { describe, expect, it } from 'vitest';
import { errorsOnly } from '../src/core/types';
import { validateManifest } from '../src/core/validate';
import { CONFORMANCE, ROOT, caseManifest } from './helpers';

const schema = JSON.parse(readFileSync(resolve(ROOT, 'schema', 'aav-1.0.schema.json'), 'utf-8'));
const ajv = new Ajv2020({ allErrors: false, strict: false });
const validateSchema = ajv.compile(schema);

describe('manifest conformance vectors (shared with the Python validator)', () => {
  for (const c of CONFORMANCE.cases) {
    it(`codes: ${c.name}`, () => {
      const issues = validateManifest(caseManifest(c));
      expect([...new Set(issues.map((i) => i.code))].sort()).toEqual([...c.codes].sort());
    });
    if (c.schema !== 'skip') {
      it(`schema: ${c.name}`, () => {
        expect(validateSchema(caseManifest(c))).toBe(c.schema === 'valid');
      });
    }
  }

  it('rejects whatever the schema rejects', () => {
    for (const c of CONFORMANCE.cases) {
      if (c.schema === 'invalid') expect(errorsOnly(validateManifest(caseManifest(c))).length, c.name).toBeGreaterThan(0);
    }
  });

  it('shared data files are identical to the repository copies', () => {
    for (const name of ['limits.json', 'effect-specs.json']) {
      expect(readFileSync(resolve(ROOT, 'web', 'src', 'core', 'data', name), 'utf-8'))
        .toBe(readFileSync(resolve(ROOT, 'schema', name), 'utf-8'));
    }
  });

  it('does not crash on hostile shapes of input', () => {
    for (const value of [null, 42, 'x', [], { format: 'aureom-active-visual', version: '1.0', document: [], layers: {} },
      { format: 'aureom-active-visual', version: '1.0', regions: [null, 1, 'a', []], layers: [null] },
      JSON.parse('{"format":"aureom-active-visual","version":"1.0","__proto__":{"x":1},"regions":[{"id":"__proto__","effects":{"constructor":{"type":"toString"}}}]}')]) {
      expect(errorsOnly(validateManifest(value)).length).toBeGreaterThan(0);
    }
  });
});
