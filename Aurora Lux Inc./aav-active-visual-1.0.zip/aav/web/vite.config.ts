import { resolve } from 'node:path';

const __dirname = import.meta.dirname;
import react from '@vitejs/plugin-react';
import type { Plugin } from 'vite';
import { defineConfig } from 'vitest/config';

const CSP = "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; " +
  "connect-src 'self'; base-uri 'none'; form-action 'none'";

/** Adds a Content-Security-Policy to every built page. Not applied by the dev server, whose hot reload needs inline scripts. */
const cspPlugin = (): Plugin => ({
  name: 'aav-csp',
  apply: 'build',
  transformIndexHtml: (html) => html.replace('<meta charset="utf-8">',
    `<meta charset="utf-8">\n<meta http-equiv="Content-Security-Policy" content="${CSP}">`),
});

// Multi-page app: landing page, viewer and editor. Everything is static; there is no backend.
export default defineConfig({
  plugins: [react(), cspPlugin()],
  base: './',
  build: {
    target: 'es2022',
    outDir: 'dist',
    rollupOptions: {
      input: {
        index: resolve(__dirname, 'index.html'),
        viewer: resolve(__dirname, 'viewer.html'),
        editor: resolve(__dirname, 'editor.html'),
      },
    },
  },
  server: { port: 5173, strictPort: false, fs: { allow: ['..'] } },
  preview: { port: 4173 },
  test: { include: ['tests/**/*.test.ts'], environment: 'node' },
});
