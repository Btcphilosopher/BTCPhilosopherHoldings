import { resolve } from 'node:path';
import { defineConfig } from 'vite';

// Builds the single-file viewer used by standalone HTML export and headless rendering.
export default defineConfig({
  publicDir: false,
  build: {
    target: 'es2022',
    outDir: 'dist-standalone',
    emptyOutDir: true,
    cssCodeSplit: false,
    lib: {
      entry: resolve(import.meta.dirname, 'src/standalone.ts'),
      name: 'AAV',
      formats: ['iife'],
      fileName: () => 'aav-viewer.iife.js',
      cssFileName: 'aav-viewer',
    },
  },
});
