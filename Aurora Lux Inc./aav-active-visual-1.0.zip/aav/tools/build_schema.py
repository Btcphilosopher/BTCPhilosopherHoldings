#!/usr/bin/env python3
"""Generate schema/aav-1.0.schema.json from limits.json and effect-specs.json.

The limits and effect tables are the single source of truth shared by the
Python validator, the TypeScript validator and this JSON Schema. Run:

    python tools/build_schema.py          # rewrite the schema + package copies
    python tools/build_schema.py --check  # fail if anything is out of date
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCHEMA_DIR = ROOT / "schema"
PY_DATA = ROOT / "python" / "src" / "aav" / "data"
WEB_DATA = ROOT / "web" / "src" / "core" / "data"

LIMITS = json.loads((SCHEMA_DIR / "limits.json").read_text("utf-8"))
SPECS = json.loads((SCHEMA_DIR / "effect-specs.json").read_text("utf-8"))
M = LIMITS["manifest"]
R = LIMITS["runtime"]
COORD = M["coordinate_limit"]
EXT = {"^x-": {}}


def obj(props: dict, required: list[str] | None = None, **extra) -> dict:
    out = {"type": "object", "properties": props, "patternProperties": EXT,
           "additionalProperties": False}
    if required:
        out["required"] = required
    out.update(extra)
    return out


def text(max_len: int, min_len: int = 0) -> dict:
    out = {"type": "string", "maxLength": max_len}
    if min_len:
        out["minLength"] = min_len
    return out


def num(lo: float, hi: float, **extra) -> dict:
    return {"type": "number", "minimum": lo, "maximum": hi, **extra}


ID = {"$ref": "#/$defs/id"}
COLOUR = {"$ref": "#/$defs/colour"}
COORDINATE = {"$ref": "#/$defs/coordinate"}
SIZE = {"type": "number", "exclusiveMinimum": 0, "maximum": COORD}


def id_map(value: dict, max_props: int) -> dict:
    return {"type": "object", "propertyNames": {"$ref": "#/$defs/id"},
            "additionalProperties": value, "maxProperties": max_props}


def prop_schema(spec: dict) -> dict:
    kind = spec["kind"]
    if kind == "number":
        return num(spec["min"], spec["max"])
    if kind == "colour":
        return COLOUR
    if kind == "enum":
        return {"enum": spec["values"]}
    if kind == "boolean":
        return {"type": "boolean"}
    raise ValueError(kind)


def effect_schemas() -> list[dict]:
    out = []
    for name in SPECS["pipeline"]:
        spec = SPECS["types"][name]
        props = {"type": {"const": name}}
        props.update({k: prop_schema(v) for k, v in spec["props"].items()})
        out.append(obj(props, ["type"], title=name, description=spec["summary"]))
    return out


def action(name: str, props: dict, required: list[str] | None = None) -> dict:
    return obj({"action": {"const": name}, **props}, ["action", *(required or [])], title=name)


EASING = {"enum": ["linear", "ease-in-out"]}
ACTIONS = [
    action("set_effect", {
        "effect": ID, "property": text(64, 1),
        "value": {"type": ["number", "string", "boolean"]},
        "region": ID, "group": ID,
        "duration_ms": num(0, R["max_transition_ms"]), "easing": EASING,
    }, ["effect", "property", "value"]),
    action("toggle_layer", {"layer": ID, "mode": {"enum": ["show", "hide", "toggle"]}}, ["layer"]),
    action("select_region", {"region": ID, "group": ID,
                             "mode": {"enum": ["select", "deselect", "toggle"]},
                             "reveal": {"type": "boolean"}}),
    action("show_tooltip", {"text": text(M["max_tooltip"], 1), "region": ID}),
    action("open_panel", {"panel": ID}, ["panel"]),
    action("navigate_document", {"href": text(M["max_url"], 1), "label": text(M["max_label"])}, ["href"]),
    action("open_link", {"url": {"type": "string", "pattern": "^https://[^\\s]+$", "maxLength": M["max_url"]},
                         "label": text(M["max_label"])}, ["url"]),
    action("play_animation", {"animation": ID}, ["animation"]),
    action("stop_animation", {"animation": ID}),
    action("reset_view", {}),
]

ACTION_LIST = {"type": "array", "items": {"$ref": "#/$defs/action"},
               "maxItems": M["max_actions_per_handler"]}

RECT = obj({"type": {"const": "rect"}, "x": COORDINATE, "y": COORDINATE, "width": SIZE, "height": SIZE},
           ["type", "x", "y", "width", "height"], title="rect")
POLYGON = obj({"type": {"const": "polygon"},
               "points": {"type": "array", "minItems": 3, "maxItems": M["max_polygon_points"],
                          "items": {"type": "array", "prefixItems": [COORDINATE, COORDINATE],
                                    "minItems": 2, "maxItems": 2}}},
              ["type", "points"], title="polygon")
MASK = obj({"type": {"const": "mask"}, "asset": ID, "x": COORDINATE, "y": COORDINATE,
            "width": SIZE, "height": SIZE,
            "threshold": {"type": "number", "exclusiveMinimum": 0, "maximum": 1},
            "hit_test": {"enum": ["alpha", "bounds"]}},
           ["type", "asset"], title="mask")

TRANSFORM = obj({
    "translate_x": COORDINATE, "translate_y": COORDINATE,
    "scale_x": num(-100, 100), "scale_y": num(-100, 100),
    "rotation": num(-360, 360, description="Degrees, clockwise."),
    "origin_x": COORDINATE, "origin_y": COORDINATE,
})
CLIP = obj({"x": COORDINATE, "y": COORDINATE, "width": SIZE, "height": SIZE}, ["x", "y", "width", "height"])
LAYER_COMMON = {
    "id": ID, "name": text(M["max_label"]), "visible": {"type": "boolean"},
    "opacity": num(0, 1), "transform": TRANSFORM, "clip": CLIP,
}
IMAGE_LAYER = obj({**LAYER_COMMON, "type": {"const": "image"}, "asset": ID,
                   "x": COORDINATE, "y": COORDINATE, "width": SIZE, "height": SIZE},
                  ["id", "type", "asset"], title="image layer")
TEXT_LAYER = obj({**LAYER_COMMON, "type": {"const": "text"}, "text": text(M["max_layer_text"], 1),
                  "x": COORDINATE, "y": COORDINATE,
                  "font_size": num(4, 512), "font_family": {"enum": ["sans-serif", "serif", "monospace"]},
                  "font_weight": {"enum": [400, 700]}, "colour": COLOUR,
                  "align": {"enum": ["left", "centre", "right"]},
                  "background": COLOUR, "padding": num(0, 64),
                  "max_width": SIZE, "line_height": num(0.8, 3)},
                 ["id", "type", "text", "x", "y"], title="text layer")

STATE_OVERRIDES = id_map({"type": "object", "maxProperties": 16,
                          "additionalProperties": {"type": ["number", "string", "boolean"]}}, 10)

REGION = obj({
    "id": ID, "label": text(M["max_label"], 1), "description": text(M["max_description"]),
    "shape": {"oneOf": [RECT, POLYGON, MASK]},
    "target_layer": ID,
    "z_index": {"type": "integer", "minimum": -1000, "maximum": 1000},
    "interactive": {"type": "boolean"}, "selectable": {"type": "boolean"},
    "tooltip": text(M["max_tooltip"]),
    "effects": id_map({"$ref": "#/$defs/effect"}, len(SPECS["pipeline"])),
    "states": obj({"hover": STATE_OVERRIDES, "selected": STATE_OVERRIDES, "focus": STATE_OVERRIDES}),
    "events": obj({t: ACTION_LIST for t in ["pointer_enter", "pointer_leave", "activate", "focus", "blur"]}),
}, ["id", "label", "shape"])

ANIMATION = obj({
    "type": {"enum": ["fade", "pulse"]}, "region": ID, "effect": ID, "property": text(64, 1),
    "from": {"type": "number"}, "to": {"type": "number"},
    "duration_ms": num(R["min_animation_ms"], R["max_animation_ms"]),
    "iterations": {"type": "integer", "minimum": 1, "maximum": R["max_animation_iterations"]},
    "easing": EASING, "end": {"enum": ["hold", "revert"]},
}, ["type", "region", "effect", "property", "from", "to", "duration_ms"])

SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "urn:aureom:aav:schema:1.0",
    "title": "AAV (Active Visual) manifest, schema version 1.0",
    "description": "Structural schema for manifest.json inside an .aav container. Reference integrity, "
                   "link safety and cross-field rules are specified in docs/SPEC.md and enforced by the "
                   "validators, not by this schema. Generated by tools/build_schema.py; do not edit by hand.",
    **obj({
        "format": {"const": LIMITS["format"]},
        "version": {"type": "string", "pattern": "^1\\.[0-9]{1,3}$"},
        "document": obj({
            "id": ID, "title": text(M["max_title"], 1),
            "width": {"type": "integer", "minimum": 1, "maximum": M["max_dimension"]},
            "height": {"type": "integer", "minimum": 1, "maximum": M["max_dimension"]},
            "description": text(M["max_description"]),
            "language": {"type": "string", "pattern": "^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8})*$"},
            "colour_space": {"const": "srgb"},
            "background": COLOUR,
        }, ["id", "title", "width", "height"]),
        "metadata": obj({"author": text(500), "licence": text(500), "created": text(64),
                         "generator": text(200), "source": text(500)}),
        "settings": obj({
            "selection": {"enum": ["single", "multiple", "none"]},
            "default_highlight": {"type": "boolean"},
            "pan_zoom": {"type": "boolean"},
            "image_rendering": {"enum": ["smooth", "pixelated"]},
        }),
        "assets": id_map(obj({
            "path": {"type": "string", "pattern": M["asset_path_pattern"]},
            "media_type": {"enum": LIMITS["image"]["media_types"]},
            "sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
            "width": {"type": "integer", "minimum": 1, "maximum": LIMITS["image"]["max_dimension"]},
            "height": {"type": "integer", "minimum": 1, "maximum": LIMITS["image"]["max_dimension"]},
        }, ["path", "media_type"]), M["max_assets"]),
        "layers": {"type": "array", "minItems": 1, "maxItems": M["max_layers"],
                   "items": {"oneOf": [IMAGE_LAYER, TEXT_LAYER]}},
        "regions": {"type": "array", "maxItems": M["max_regions"], "items": REGION},
        "groups": id_map(obj({"label": text(M["max_label"], 1), "description": text(M["max_description"]),
                              "regions": {"type": "array", "items": ID, "minItems": 1,
                                          "maxItems": M["max_regions"], "uniqueItems": True}},
                             ["label", "regions"]), M["max_groups"]),
        "panels": id_map(obj({"title": text(M["max_title"], 1), "text": text(M["max_panel_text"])},
                             ["title", "text"]), M["max_panels"]),
        "animations": id_map(ANIMATION, M["max_animations"]),
        "events": obj({"document_load": ACTION_LIST}),
        "default_state": obj({
            "selected": {"type": "array", "items": ID, "uniqueItems": True, "maxItems": M["max_regions"]},
            "panel": {"oneOf": [ID, {"type": "null"}]},
            "view": obj({"zoom": {"oneOf": [{"const": "fit"}, num(R["min_zoom"], R["max_zoom"])]},
                         "centre_x": COORDINATE, "centre_y": COORDINATE}),
        }),
        "preview": {"const": "preview.png"},
        "thumbnail": {"type": "string", "pattern": M["thumbnail_path_pattern"]},
        "redaction": obj({"method": {"enum": ["fill"]}, "colour": COLOUR,
                          "regions": {"type": "array", "items": ID, "uniqueItems": True},
                          "tool": text(200)}, ["method", "regions"]),
    }, ["format", "version", "document", "layers", "preview"]),
    "$defs": {
        "id": {"type": "string", "pattern": M["id_pattern"]},
        "colour": {"type": "string", "pattern": M["colour_pattern"],
                   "description": "sRGB #RRGGBB or #RRGGBBAA."},
        "coordinate": {"type": "number", "minimum": -COORD, "maximum": COORD,
                       "description": "Document pixels."},
        "effect": {"oneOf": effect_schemas()},
        "action": {"oneOf": ACTIONS},
    },
}


def main() -> int:
    check = "--check" in sys.argv
    outputs = {
        SCHEMA_DIR / "aav-1.0.schema.json": json.dumps(SCHEMA, indent=2, ensure_ascii=False) + "\n",
    }
    for name in ("limits.json", "effect-specs.json", "aav-1.0.schema.json"):
        src = outputs.get(SCHEMA_DIR / name) or (SCHEMA_DIR / name).read_text("utf-8")
        outputs[PY_DATA / name] = src
        if name != "aav-1.0.schema.json":
            outputs[WEB_DATA / name] = src
    stale = []
    for path, content in outputs.items():
        if path.exists() and path.read_text("utf-8") == content:
            continue
        stale.append(path)
        if not check:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, "utf-8")
    if check and stale:
        print("out of date:", *[str(p.relative_to(ROOT)) for p in stale], sep="\n  ")
        return 1
    print("schema up to date" if check else f"wrote {len(stale)} file(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
