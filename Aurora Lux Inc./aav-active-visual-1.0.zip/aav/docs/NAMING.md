# Naming, identifiers and conflict check

AAV is a **proposed custom format**. Nothing here is registered or standardised, and nothing in
this project should be read as claiming otherwise. This note records the identifiers in use, what
was checked on 2026-11-24, and what still has to be checked before any wider claim is made.

## Identifiers in use

| Identifier | Value | Where it is defined |
|---|---|---|
| File extension | `.aav` | convention only |
| Format identifier | `aureom-active-visual` | `schema/limits.json` → `format` |
| Schema version | `1.0` | `schema/limits.json` → `version` |
| JSON Schema id | `urn:aureom:aav:schema:1.0` | `tools/build_schema.py` |
| Local media-type label | `application/x.aureom-active-visual+zip` | `schema/limits.json` → `provisional_media_type` |

### An inconsistency in the brief that needs a decision

The brief titles the format "AAV — **Aardvark** Active Visual" but its example manifest uses the
identifier `aureom-active-visual`, and the repository this was built alongside contains a folder
spelled "Aarkvark". All three were left exactly as given: the documentation uses "Aardvark Active
Visual", the manifest identifier is `aureom-active-visual`. **Pick one before publishing
anything**, because the identifier is written into every file.

Changing the identifier later means: edit `format` in `schema/limits.json`, run
`python tools/build_schema.py`, rebuild the examples, and update the literal string in
`conformance/manifests.json` and the tests that construct manifests by hand. Files already written
with the old identifier would need a migration.

## What was checked, and how well

Checks were made by web search on 2026-11-24. Several reference sites could not be opened directly
from the build environment (fileinfo.com, filext.com, file-extensions.org, iana.org, wikipedia.org
and rfc-editor.org were blocked), so some findings rest on search-result snippets or on mirrors.
Each item says which.

### The `.aav` extension — one existing use found

* **OccuRec**, an open-source Windows program by Hristo Pavlov for recording astronomical
  occultations, has a video format called AAV that uses the `.aav` extension.
  *Verified directly:* OccuRec's project file lists AAV components (`ucAAV.cs`, `AAVPlayer.cs`):
  <https://raw.githubusercontent.com/hpavlov/occurec/master/OccuRec/OccuRec.csproj>.
  *From search snippets only:* the file-extensions.org entry for `.aav`
  (<https://www.file-extensions.org/extension/aav>) and a British Astronomical Association guide
  (<https://britastro.org/wp-content/uploads/2016/11/24-Using-OccuRec.pdf>).
* It is a niche use (the repository's copyright notice reads 2013–2015), in an unrelated field.
  A file manager or operating system that already associates `.aav` with OccuRec or its companion
  tools would mis-handle these files.
* *Not verified:* fileinfo.com, filext.com and Wikipedia's list of filename extensions. Snippets
  showed no `.aav` entry, but the snippets were truncated, so absence is not established.

### Media types — nothing found, but the registry itself was not read

* *Not checked:* the IANA media-types registry itself (iana.org was unreachable).
* *Proxy checks, fetched directly:* the `jshttp/mime-db` database (2,601 types, 2,215 of them
  sourced from IANA) has no type containing `aav` or `active-visual` and no `aav` extension mapping
  (<https://raw.githubusercontent.com/jshttp/mime-db/master/db.json>); Apache's `mime.types` has no
  match either (<https://raw.githubusercontent.com/apache/httpd/trunk/docs/conf/mime.types>).
* These are good evidence, not proof. **Read the IANA registry directly before registering or
  publishing a media type.**

### Other meanings of "AAV" (search snippets)

* Adeno-associated virus — by far the dominant meaning; a search for "AAV file" or "AAV format"
  will mostly return gene-therapy results.
* Assault Amphibious Vehicle, air admittance valve, African American Vernacular English
  (<https://en.wikipedia.org/wiki/AAV_(disambiguation)>, seen via mirrors), autonomous aerial
  vehicle (<https://technav.ieee.org/topic/autonomous-aerial-vehicles/>).
* No codec, Android or automotive use of the acronym was found.
* "ACTIVE VISUAL SYSTEM" appears as a registered US trademark (Reg. 2920450) for
  facility-management software (<https://trademark.justia.com/765/38/active-visual-76538675.html>).
  Its current status and scope were not examined. No interactive-image product called "Active
  Visual" was found.

None of this is legal advice or a trademark clearance.

## The media-type label

No media type is registered for AAV. Tools in this project label files
`application/x.aureom-active-visual+zip` for local use (for example in `aav serve`).

Why that form:

* RFC 6838 section 3.4 defines an "unregistered `x.` tree" (section title confirmed from the RFC's
  table of contents via a search snippet; the RFC body could not be fetched).
* The wording available was from the current revision draft (`draft-ietf-mediaman-6838bis`,
  fetched directly from
  <https://raw.githubusercontent.com/ietf-wg-mediaman/6838bis/main/draft-ietf-mediaman-6838bis.md>):
  `x.` names are for "private, local environments", cannot be registered, and their use is
  "strongly discouraged"; names with the older `x-` prefix are "no longer considered to be members
  of this tree" (citing RFC 6648); the vendor tree `vnd.` is for "publicly available products" and
  is registered with IANA under expert review; `prs.` is for types "created experimentally".
* So the `x.` label is acceptable only as a private, local marker, which is how it is used here.
  It is **not** suitable for public distribution.
* The `+zip` structured-syntax suffix is used on the understanding that it is a registered suffix;
  this was not verified in this session.

## Before claiming standardisation or registering anything

1. Settle the name (see the inconsistency above).
2. Read the IANA media-types registry and the structured-syntax-suffix registry directly.
3. Decide whether sharing `.aav` with OccuRec is acceptable; if not, choose a more distinctive
   extension now, while only example files exist.
4. Have the name and acronym checked for trademark conflicts in the jurisdictions that matter.
5. For public use, register a vendor-tree type (for example
   `application/vnd.<owner>.active-visual+zip`) through IANA and publish the specification at a
   stable URL; replace the `urn:` schema id with that URL.
6. Only then describe the format as anything other than a proposal.
