# AAV — Active Visual: format specification

Schema version **1.0** · Status: **proposed custom format, not standardised**

AAV is a container for an *interactive image*: a picture plus selectable regions, highlights, lighting
effects, links, pixelation, annotations and controlled animation, described declaratively. An `.aav`
file is not an image file. It **requires a compatible viewer**; ordinary image viewers will not open
it and will never show its interactive behaviour. Every file carries a static PNG preview so the
picture itself remains available where interaction is not.

The key words MUST, MUST NOT, SHOULD and MAY are used as in RFC 2119.

Reference implementations: `python/` (validation, packaging, CLI) and `web/` (runtime, viewer,
editor). Where this text and the code disagree, that is a bug in one of them; the conformance
vectors in `conformance/manifests.json` are run against both validators.

---

## 1. Identifiers

| Item | Value | Notes |
|---|---|---|
| File extension | `.aav` | See `docs/NAMING.md` for the conflict check. |
| Format identifier | `aureom-active-visual` | The value of `format` in the manifest. |
| Display name | Aardvark Active Visual (AAV) | The brief names the format "Aardvark Active Visual" and uses the identifier `aureom-active-visual`. Both are kept as given; see NAMING.md. |
| Schema version | `1.0` | `MAJOR.MINOR` string in `version`. |
| JSON Schema `$id` | `urn:aureom:aav:schema:1.0` | `schema/aav-1.0.schema.json`. |
| Media type | *none registered* | For local use only, tools here label files `application/x.aureom-active-visual+zip` (the unregistered `x.` tree). It MUST NOT be presented as a registered type. |
| Signature | ZIP local header `PK\x03\x04` at byte 0 | Writers put `manifest.json` first and uncompressed, so `"format":` appears near the start of the file. |

## 2. Units and conventions

* **Lengths and positions** are in **document pixels** (`px`): the coordinate system of the
  document canvas, origin top-left, x to the right, y downwards. They are independent of the size
  at which a viewer shows the document.
* **Angles** are degrees, clockwise. **Times** are milliseconds. **Factors** and **ratios** are
  plain numbers (1 = unchanged for factors, 0–1 for ratios).
* **Colours** are `#RRGGBB` or `#RRGGBBAA`, sRGB.
* **Identifiers** match `^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`. They are stable: tools MUST NOT
  renumber them. Regions, layers, assets, groups, panels and animations each have their own
  namespace; effect ids are local to their region.
* Numbers MUST be finite. Coordinates are limited to ±65536.
* **Unknown properties are errors**, except properties whose name starts with `x-`, which are
  reserved for extensions and ignored. (For documents of a newer minor version, see section 13.)
* Every optional property has a documented default; a missing property and its default are
  equivalent. An explicit JSON `null` is *not* "missing" and is invalid, with the one exception of
  `default_state.panel`.

## 3. Container

An `.aav` file is a ZIP archive restricted to a small profile.

```
example.aav
├── manifest.json          required
├── preview.png            required: static fallback, PNG
├── assets/…               images used by layers
├── masks/…                images used as region masks
└── thumbnails/…           optional small preview (PNG or WebP)
```

### 3.1 ZIP profile (readers MUST enforce)

* The file begins with a local file header; the end-of-central-directory record is the last 22
  bytes. No prefix, no trailing bytes, no archive comment, single disk.
* No ZIP64, no encryption. Compression method is *stored* (0) or *deflate* (8) only.
* Entry names are UTF-8 (ASCII if the UTF-8 flag is clear), NFC-normalised, at most 255 bytes,
  relative, with `/` separators. Rejected: empty names or segments, `.` and `..` segments, a
  leading `/`, backslashes, colons, control characters.
* No two entries may have the same name **ignoring case**.
* The local and central names of an entry must be identical, entries must not overlap one another
  or the central directory, and the central directory must end exactly at the end record.
* Sizes are bounded *before* decompression and enforced *during* it (section 12). CRC-32 is checked.
* Directory entries are allowed if empty and are ignored.

### 3.2 Deterministic writing (writers SHOULD)

The reference writers produce identical bytes for identical content:

* entry order: `manifest.json`, `preview.png`, then all others sorted by name (code point order);
* every entry *stored* (images are already compressed; this also removes any dependence on the
  deflate implementation);
* timestamps fixed at 1980-01-01 00:00:00, version fields 20, no extra fields, UTF-8 flag set;
* `manifest.json` in canonical form: keys sorted, two-space indent, `\n` line ends, UTF-8 without
  BOM, trailing newline, integer-valued numbers written without a fraction.

The Python and TypeScript writers agree byte for byte on the shipped examples (tested). That
equality is not guaranteed for manifests containing non-integer numbers whose shortest decimal
form differs between the two languages (for example exponents such as `1e-7`).

### 3.3 Manifest encoding

`manifest.json` is UTF-8 JSON, at most 4 MiB, without a byte-order mark. `NaN`, `Infinity` and
duplicate object keys MUST NOT be written. The Python reader rejects duplicate keys; the browser
reader cannot detect them and uses the last occurrence, which is also what its runtime then uses.

## 4. Manifest

Top-level properties (`*` = required):

| Property | Type | Purpose |
|---|---|---|
| `format`* | string | `"aureom-active-visual"` |
| `version`* | string | `"1.0"` |
| `document`* | object | Canvas, title, accessibility description |
| `layers`* | array (1–256) | What is drawn, bottom first |
| `preview`* | string | Always `"preview.png"` |
| `assets` | map id → asset | Packaged images |
| `regions` | array (≤ 2000) | Interactive areas |
| `groups` | map id → group | Named sets of regions |
| `panels` | map id → panel | Information panels |
| `animations` | map id → animation | Bounded property animations |
| `events` | object | `document_load` handler |
| `settings` | object | Viewer behaviour |
| `default_state` | object | Saved starting state |
| `thumbnail` | string | `thumbnails/<name>.png` or `.webp` |
| `metadata` | object | `author`, `licence`, `created`, `generator`, `source` (all optional strings) |
| `redaction` | object | Record written by a permanent-redaction export (section 11) |

### 4.1 `document`

| Property | Default | Notes |
|---|---|---|
| `id`* | | Identifier |
| `title`* | | 1–200 characters; the accessible name of the image |
| `width`*, `height`* | | Integers, 1–8192 px each; `width × height` ≤ 16 777 216 |
| `description` | `""` | Up to 4000 characters. The text alternative for the whole picture |
| `language` | unset | BCP 47 tag for the document's text |
| `colour_space` | `"srgb"` | Only `srgb` is defined |
| `background` | transparent | Colour painted before any layer |

**Colour assumptions.** All colours and all image data are treated as 8-bit sRGB. Embedded colour
profiles in assets are ignored. All effect arithmetic is performed on gamma-encoded values, not in
linear light (section 8.4).

### 4.2 `assets`

```json
"base": { "path": "assets/base.webp", "media_type": "image/webp",
          "sha256": "…64 hex…", "width": 1600, "height": 1000 }
```

* `path`* matches `^(assets|masks)/[A-Za-z0-9][A-Za-z0-9._-]{0,127}$`; paths are unique ignoring case.
* `media_type`* is `image/png`, `image/jpeg` or `image/webp`. SVG and other scriptable or
  container formats are not allowed. The file's leading bytes MUST identify it as the declared type.
* `sha256`, `width`, `height` are optional in the schema so that hand-written manifests validate,
  but packers MUST write them (the reference tools always do) and readers MUST reject a mismatch.
  Strict validation requires them.
* Each image is at most 8192 px per side; all assets together decode to at most 67 108 864 pixels.
  Dimensions are read from the file header and checked **before** any pixel is decoded.

### 4.3 `settings`

| Property | Default | Meaning |
|---|---|---|
| `selection` | `"single"` | `single`, `multiple` (activation toggles) or `none` |
| `default_highlight` | `true` | Viewer-drawn hover/selection highlight for regions that define no `states` |
| `pan_zoom` | `true` | Whether the user may pan and zoom |
| `image_rendering` | `"smooth"` | `pixelated` keeps hard pixel edges when the image is enlarged |

### 4.4 `default_state`

`selected` (region ids, default none), `panel` (panel id or `null`), and `view`
(`zoom`: `"fit"` or a scale 0.01–64; `centre_x`, `centre_y` in document px). In a
single-selection document only the first selected id is used. This is the *only* place interaction
state is stored, and editors write it only on an explicit user action.

## 5. Layers

`layers` is ordered bottom to top. Common properties:

| Property | Default | Notes |
|---|---|---|
| `id`*, `type`* | | `type` is `image` or `text` |
| `name` | unset | Label for authoring tools |
| `visible` | `true` | Runtime visibility can be changed by `toggle_layer` |
| `opacity` | `1` | 0–1, applied to the layer as a whole |
| `transform` | identity | See 5.3 |
| `clip` | none | `{x, y, width, height}` in document px |

### 5.1 Image layers

`asset`* names an asset. `x`, `y` default to 0; `width`, `height` default to the document size, so
a layer with no placement stretches its image over the whole canvas. A "transparent overlay" is
simply an image layer whose asset has an alpha channel.

### 5.2 Text layers

`text`*, `x`*, `y`*; `font_size` (4–512, default 24 px); `font_family` (`sans-serif` default,
`serif`, `monospace`); `font_weight` (400 default, 700); `colour` (default `#FFFFFF`); `align`
(`left` default, `centre`, `right`); `background` (optional box colour); `padding` (0–64, default 6
when a background is set); `max_width` (optional wrap width); `line_height` (0.8–3, default 1.25).

Layout: the text is split at `\n`; if `max_width` is set, each line is wrapped greedily at spaces.
The block is as wide as its longest line. `(x, y)` is the top-left of the block for `left`, the
top-centre for `centre` and the top-right for `right`. Only generic font families exist, so glyph
shapes and exact line widths vary between platforms; text layers are labels, not typography.

### 5.3 Transforms, clipping, ordering

A layer transform has `translate_x`, `translate_y` (default 0), `scale_x`, `scale_y` (default 1,
non-zero, ±100), `rotation` (default 0) and `origin_x`, `origin_y` (default: the centre of an image
layer's box; `(x, y)` for a text layer). It is applied as

```
T = translate(translate_x, translate_y) · translate(origin) · rotate(rotation) · scale(scale_x, scale_y) · translate(−origin)
```

`clip` is in document coordinates and is **not** affected by the layer's transform. Layers are
composited with source-over blending in array order; there are no blend modes in 1.0.

**Layers never intercept the pointer.** Only regions do (section 6.3).

## 6. Regions

```json
{ "id": "window-01", "label": "First-floor window",
  "shape": { "type": "rect", "x": 400, "y": 220, "width": 120, "height": 160 },
  "target_layer": "background" }
```

| Property | Default | Notes |
|---|---|---|
| `id`*, `label`* | | `label` (1–200 chars) is the region's accessible name |
| `shape`* | | 6.1 |
| `description` | unset | Longer accessible description |
| `tooltip` | unset | Default text for `show_tooltip` |
| `target_layer` | the composite | What the region's effects act on (section 8.1) |
| `z_index` | `0` | Integer −1000…1000; hit-test priority |
| `interactive` | `true` | `false`: never hit, not focusable, not listed |
| `selectable` | `true` | Whether activation selects it |
| `effects`, `states`, `events` | none | Sections 8 and 9 |

### 6.1 Shapes

* `rect`: `x`, `y`, `width` > 0, `height` > 0.
* `polygon`: `points`, 3–2048 `[x, y]` pairs, with non-zero area. Filled and hit-tested with the
  **even-odd** rule.
* `mask`: `asset` (PNG or WebP), placed at `x`, `y` (default 0) with `width`, `height` (default:
  document size). The mask's **alpha channel** is the region's coverage; its colour is ignored.
  `threshold` (0 < t ≤ 1, default 0.5) and `hit_test` (`alpha` default, or `bounds`) control hit
  testing only.

Region geometry is always in document coordinates and is never transformed by a layer.

### 6.2 Groups

`groups` maps an id to `{ "label", "description"?, "regions": [ids…] }`. A group can be the target
of `set_effect` and `select_region`, and viewers use groups to organise the region list.

### 6.3 Hit testing, overlap and pointer interception

1. The viewer converts the pointer position to document coordinates through its view transform
   (section 10.1). Device pixel ratio never enters this calculation.
2. Candidates are the regions with `interactive` ≠ `false` whose shape contains the point:
   * `rect`: `x ≤ px < x + width` and `y ≤ py < y + height` (half-open, so adjacent rectangles never
     both claim an edge);
   * `polygon`: even-odd ray casting;
   * `mask`: inside the placement box and, unless `hit_test` is `bounds`, the nearest mask texel has
     alpha ≥ `threshold × 255`. Transparent parts of a mask therefore let the pointer through.
3. The candidate with the highest `z_index` wins; ties go to the region **later in the array**.
4. Only the winner receives the event. There is no bubbling. A non-interactive region is invisible
   to the pointer and does not block regions beneath it.

Every interactive region remains reachable by keyboard and through the region list regardless of
overlap. The reference viewer also lets Alt+click step down through the regions under the pointer.

## 7. Interaction state

A viewer keeps, per open document: hovered region, focused region, the ordered set of selected
regions, the open panel, the visible tooltip, runtime layer visibility, values set by `set_effect`,
running transitions and animations, and the view. **None of this is written to the manifest.**

Each region can be in any combination of three states: `hover`, `focus`, `selected`.

### 7.1 State styles

`states` gives per-state overrides of the region's own effect properties:

```json
"states": { "hover":    { "edge": { "opacity": 1 } },
            "selected": { "edge": { "opacity": 1, "colour": "#A78BFA" } } }
```

Keys are effect ids of the same region; values are property overrides valid for that effect type.

### 7.2 Priority

When several things set the same property of the same effect, the value is taken from the highest
of these that applies:

1. the value saved in `effects` (or the property's default);
2. the latest `set_effect` (while its transition runs, the interpolated value);
3. the `selected` state style;
4. the `hover` state style;
5. the `focus` state style;
6. a running animation on that property (if several, the most recently started).

Values are clamped to the property's range at the end.

### 7.3 Viewer highlights

If `settings.default_highlight` is not `false` and a region defines no `states`, the viewer draws
its own hover and selection highlight for it. Independently of the document, a viewer MUST draw a
visible focus indicator on the keyboard-focused region. These highlights are viewer chrome in
screen space; they are not part of the document raster and do not appear in static exports.

## 8. Effects

`effects` maps an id to an effect. **A region may have at most one effect of each type.**

| Type | Stage | Properties (range, default) |
|---|---|---|
| `pixelate` | spatial | `block_size` px (1–256, 8) |
| `blur` | spatial | `radius` px (0–64, 4) |
| `brightness` | colour | `amount` factor (0–4, 1) |
| `contrast` | colour | `amount` factor (0–4, 1) |
| `saturation` | colour | `amount` factor (0–4, 1) |
| `tint` | colour | `colour` (`#5AD8E6`), `amount` ratio (0–1, 0.25), `mode` `normal`/`multiply`/`screen` (`normal`) |
| `spotlight` | colour | `colour` (`#FFFFFF`), `intensity` (0–4, 1), `radius` px (1–8192, 120), `falloff` exponent (0.1–8, 2), `ambient` (0–1, 1), `x`, `y` px (region centre), `follow_pointer` (`false`) |
| `opacity` | alpha | `amount` ratio (0–1, 1) |
| `glow` | overlay | `colour` (`#FFFFFF`), `intensity` (0–2, 0.8), `radius` px (0–256, 16) |
| `outline` | overlay | `colour` (`#5AD8E6`), `width` px (0–64, 2), `opacity` (0–1, 1) |

The machine-readable form of this table is `schema/effect-specs.json`.

### 8.1 What an effect applies to

Effects never apply "to the whole image" by default. A region's effects act on its **target**,
inside its **coverage**:

* target = the pixels of `target_layer` (that layer alone, before it is composited), or, when
  `target_layer` is absent, the composite of all layers;
* coverage = the region's shape: the filled rectangle or polygon (anti-aliased), or the mask's
  alpha (so a soft mask gives a graded effect).

For coverage *c*, the result is `original × (1 − c) + processed × c`.

### 8.2 Order

Rendering produces a raster at document resolution:

```
paint document.background
for each visible layer, bottom to top:
    draw the layer (clip, transform)
    for each region targeting it, in array order:   apply spatial, colour and alpha stages
    composite the layer with its opacity
    for each region targeting it, in array order:   draw overlay stage
for each region with no target layer, in array order:
    apply spatial, colour and alpha stages to the composite, then draw its overlay stage
```

Within one region the order is fixed, whatever order the effects are written in:

`pixelate → blur → brightness → contrast → saturation → tint → spotlight → opacity → glow → outline`

Colour values are clamped to [0, 1] after `saturation` and again after `spotlight`; nowhere else.
Results of the spatial stage are rounded to 8 bits before the colour stage.

### 8.3 Definitions

With *c* an RGB value in 0–1:

* **pixelate** — blocks are `round(block_size)` document pixels square (minimum 1 = no effect) and
  are **aligned to the document origin**, not to the region or the screen. Each block takes the
  alpha-weighted mean colour and the mean alpha of the target pixels in it. Because the grid is
  fixed in document space and the effect is computed at document resolution, the pattern is
  identical at every zoom level and pan position, and does not shift if the region moves. Blocks
  cut by the region boundary are clipped by the coverage.
* **blur** — a Gaussian approximated by three box passes, standard deviation `radius / 2`, on
  premultiplied values, with edge pixels extended. Pixels just outside the region contribute.
* **brightness** — `c × amount`.
* **contrast** — `(c − 0.5) × amount + 0.5`.
* **saturation** — `L + (c − L) × amount` with `L = 0.2126 R + 0.7152 G + 0.0722 B`.
* **tint** — with `a = amount × colour alpha` and tint colour *t*:
  `normal`: `c + (t − c)a`; `multiply`: `c + (c·t − c)a`; `screen`: `c + (1 − (1−c)(1−t) − c)a`.
* **spotlight** — a radial light field. For a pixel centre at distance *d* from `(x, y)`:
  `light = (1 − d/radius)^falloff × intensity` inside the radius, 0 outside;
  `c × (ambient + light × colour)`. With `follow_pointer`, `(x, y)` is the pointer position while
  the region is hovered. **This is an image effect.** It brightens and darkens pixels; it does not
  relight the scene. Real relighting would need information an image does not contain (surface
  normals, depth, materials).
* **opacity** — multiplies the alpha of the target pixels, revealing whatever is beneath the target.
* **glow** — the region's coverage, blurred with standard deviation `radius / 2`, coloured, scaled
  by `intensity` (clamped to opaque), and combined with the *screen* blend directly above the target.
* **outline** — a stroke of the given width centred on the boundary of a rectangle or polygon. For
  a mask the outline is a band just outside the mask edge obtained by dilation; it is approximate.

### 8.4 Alpha and colour space

Effects read and write 8-bit, non-premultiplied, gamma-encoded sRGB. Colour-stage effects leave
alpha unchanged; fully transparent pixels are left untouched. Blur and pixelation weight colour by
alpha so that transparent pixels do not bleed. No linear-light conversion is performed.

### 8.5 Renderers

The reference renderer composites with Canvas 2D and runs the spatial stage and overlays on the
CPU. The **colour stage** (brightness … opacity) is behind a small backend interface with two
implementations: the CPU reference and an optional WebGL2 shader. They are tested to agree within
±2 of 255 per channel. Other implementations MAY render differently provided the result is
equivalent at document resolution.

## 9. Triggers and actions

Region `events` map a trigger to a list of at most 32 actions:

| Trigger | Fires when |
|---|---|
| `pointer_enter` | the region becomes the hit-test winner |
| `pointer_leave` | it stops being the winner |
| `activate` | click, tap, or Enter/Space while focused |
| `focus` / `blur` | keyboard or assistive-technology focus arrives / leaves |

The document-level `events.document_load` runs once when the document opens.

**Touch and keyboard are first-class.** A tap fires `pointer_enter` and then `activate`, and the
region stays "hovered" until the next tap elsewhere, so nothing is reachable only by hovering.
Keyboard activation is the same event as a click. Authors SHOULD mirror hover styling in `focus`.

### 9.1 Actions

| Action | Properties | Effect |
|---|---|---|
| `set_effect` | `effect`*, `property`*, `value`*, `region` \| `group`, `duration_ms` (0–10000, numeric properties only), `easing` | Sets a runtime value, optionally fading to it |
| `toggle_layer` | `layer`*, `mode` (`toggle`, `show`, `hide`) | Runtime layer visibility |
| `select_region` | `region` \| `group`, `mode` (`select`, `deselect`, `toggle`), `reveal` | Changes the selection; `reveal` brings it into view |
| `show_tooltip` | `text`, `region` | Shows a tooltip (text defaults to the region's `tooltip`, then `label`) |
| `open_panel` | `panel`* | Opens an information panel |
| `navigate_document` | `href`*, `label` | Asks to open another AAV document |
| `open_link` | `url`*, `label` | Asks to open an external HTTPS link |
| `play_animation` | `animation`* | Starts (or restarts) an animation |
| `stop_animation` | `animation` | Stops one, or all if omitted; nothing is held |
| `reset_view` | | Returns to the default view |

Where `region`/`group` are optional and both absent, the action targets the region whose handler it
is in; in `document_load` a target is required. At most one of the two may be given. In
`single`-selection documents, selecting a group leaves its last member selected.

### 9.2 The state machine

```
host event (pointer, key, focus, load)
   └─ update hovered / focused / selected
   └─ run the handler's actions in order, each changing runtime state
   └─ return "host requests" (open link?, open document?, reset view, reveal)
```

* **Actions do not fire triggers.** `select_region` does not cause `activate`; a finished animation
  causes nothing. One host event therefore runs a bounded number of handlers once each, and no
  action can cause another handler to run. Recursive loops cannot be expressed.
* As a second line of defence, a single host event processes at most **256 actions**.
* On activation the selection is updated first, then the `activate` handler runs.
* Activating empty space clears a single selection and any tooltip.
* A tooltip belongs to the region whose handler showed it and disappears when that region loses
  hover or focus, or on Escape. Escape closes the tooltip if one is open, otherwise the panel.
* `open_link` and `navigate_document` are **only valid in `activate` handlers**; a manifest that
  uses them elsewhere is invalid. The runtime never performs them itself: it hands a request to the
  host, which MUST show the destination and obtain confirmation (section 10.3).

There is no scripting. An AAV file MUST NOT contain JavaScript, executable code or HTML, and a
viewer MUST NOT evaluate any part of a document as code.

### 9.3 Animations

```json
"window-pulse": { "type": "pulse", "region": "window-01", "effect": "illumination",
                  "property": "intensity", "from": 0.2, "to": 1.0,
                  "duration_ms": 1200, "iterations": 3, "easing": "ease-in-out", "end": "revert" }
```

* `fade` runs `from → to` once per iteration; `pulse` runs `from → to → from`.
* Only numeric properties can be animated or transitioned.
* `duration_ms` 50–60 000; `iterations` 1–1000 (default 1); `duration_ms × iterations` ≤ 600 000.
  There are no infinite animations. At most 16 run at once; further requests are ignored.
* `easing`: `linear` or `ease-in-out` (default; `0.5 − 0.5·cos(πp)`).
* `end`: `hold` leaves the end value behind as if by `set_effect` (default for `fade`: `to`);
  `revert` leaves nothing (default for `pulse`).
* Animations start only from `play_animation`.
* **Reduced motion.** When the user prefers reduced motion (or switches it on in the viewer),
  transitions complete instantly, `pulse` animations do not run, and `fade` animations jump to
  their end state.

## 10. Viewing

### 10.1 View transform and high-DPI

A viewer maps document to screen with a uniform scale and a translation:
`screen = document × scale + (tx, ty)`, in CSS pixels, with scale limited to 0.01–64. The backing
store may be larger by the device pixel ratio; that factor affects drawing only. Hit testing uses
the inverse map on CSS-pixel pointer positions, so it is unaffected by resizing, panning, zooming
or pixel density. The reference viewer supports wheel and pinch zoom about the pointer, drag to
pan, `+`/`−`/`0` and arrow keys, and on-screen buttons.

The document raster is always produced at document resolution and then scaled. Text and outlines
therefore soften when enlarged far beyond 1:1; this is a deliberate trade for predictability.

### 10.2 Information panels and restricted text

`panels` maps an id to `{ "title", "text" }`. `text` (≤ 20 000 characters) is **AAV text**, the only
rich text in the format:

* blocks are separated by blank lines;
* a block starting with `# ` begins with a heading line;
* a block whose lines all start with `- ` is a list;
* otherwise a block is a paragraph, and single newlines are line breaks;
* inline: `**bold**`, `*italic*`, `` `code` ``, `[label](target)`, and backslash escapes for
  `\ * [ ] ( )` and the backtick. Inline constructs do not nest.

There is no HTML: `<` and `>` are ordinary characters and are displayed as written. Viewers MUST
build output from the parsed structure (text nodes), never by inserting the text as markup.

A link target is one of: an external URL (10.3), `#region:<id>` (selects and reveals a region),
or `#panel:<id>` (opens a panel). A link with any other target, or with an empty label, is not a
link: it is displayed as the literal text the author wrote. Validation additionally rejects
documents whose panel text contains a disallowed external target or a dangling internal one.

### 10.3 Links

An **external link** MUST:

* be at most 2048 characters, with no whitespace, control characters or backslashes;
* start with exactly `https://` (lower case);
* have a host made of letters, digits, dots and hyphens, optionally followed by `:port`; no
  credentials (`user@`) and no bracketed IPv6 literals; internationalised names in punycode.
  (Dotted IPv4 hosts fit this syntax and are accepted; the confirmation step shows them.)

Everything else is rejected, including `http:`, `javascript:`, `data:`, `file:`, `blob:` and
protocol-relative URLs.

A **document link** (`navigate_document.href`) is either an external link as above or a relative
path made of segments of `[A-Za-z0-9._~-]`, ending in `.aav`, with no `.` or `..` segments, no
leading `/`, no query or fragment.

Viewer obligations:

* Opening a document MUST NOT navigate, download, or request any external resource. An AAV file
  has no way to reference an external image, font, style sheet or script.
* Before following an external or document link the viewer MUST show the full destination and
  require an explicit confirmation; the non-destructive choice SHOULD be the default.
* External links open in a new browsing context with `noopener` and `noreferrer`.
* A relative document link is resolved against the location the current document was loaded from.
  If there is none (a file opened from disk, a standalone export), the viewer shows the target and
  explains that it must be opened manually.

### 10.4 Static fallback

`preview.png` MUST be a PNG no larger than 8192 px per side, showing the document in its default
state. Tools SHOULD regenerate it on every save. Viewers that cannot run a document (unsupported
version, invalid manifest, no canvas support) SHOULD still show the preview and the reason, as long
as the container itself is readable.

**Standalone HTML export** produces one `.html` file containing the viewer, its styles and the
document (base64). It includes the preview and the region names as ordinary markup for readers
without JavaScript, makes no network requests, and carries a Content-Security-Policy of
`default-src 'none'` with a hash for its single script. It opens directly from disk. A local web
server is needed only for the *separate* viewer page, which fetches `.aav` files by URL:
`aav serve <directory>` or any static server.

## 11. Privacy and redaction

**Display effects are reversible and are not redaction.** `pixelate`, `blur`, `opacity`, tints and
overlay layers change only what a viewer draws. The original image remains in the archive and can
be extracted with any ZIP tool. Tools and documentation MUST NOT describe these effects as secure,
and the reference editor says so wherever it offers them alongside export.

A **permanent-redaction export** writes a *new* document in which chosen regions are destroyed:

1. In every image layer — visible or hidden — the source asset's pixels under the region (mapped
   through the layer's placement and transform, grown by a pixel to cover anti-aliased edges) are
   replaced by an opaque solid colour.
2. Every asset is re-encoded as PNG from raw pixels, so no EXIF, ICC, text or other ancillary
   data from the originals survives.
3. Assets used only as masks keep their alpha and lose their colour channels.
4. Assets not used by any layer or mask, and files not referenced by the manifest, are dropped.
5. `preview.png` and the thumbnail are regenerated from the redacted content.
6. `redaction` records `{ "method": "fill", "colour", "regions", "tool" }`.
7. The result is verified, and the export fails if verification does: strict validation passes;
   no unused asset or unreferenced file exists; every asset is a PNG with no unexpected chunks;
   every asset pixel under a redacted region equals the fill colour; no file is byte-identical to
   an original file that showed redacted content (including the old preview and thumbnail).

Only solid fill is offered. Mosaic or blur "redaction" can leak the underlying content (pixelated
text in particular has been recovered in practice) and is deliberately not provided.

Limits of this guarantee: it concerns the files in the archive. It cannot remove information that
remains in text (labels, descriptions, panel text), in geometry (a region's outline may itself be
revealing), or in copies of the original file elsewhere. The source file is never modified.

## 12. Validation and resource limits

AAV files are untrusted input. A reader MUST validate before use and MUST enforce at least:

| Limit | Value |
|---|---|
| Archive entries | 1024 |
| Uncompressed size per entry / in total | 64 MiB / 256 MiB |
| Compression ratio (entries over 1 MiB) | 200 : 1 |
| Entry name | 255 bytes |
| Manifest | 4 MiB |
| Document | 8192 px per side, 16 777 216 px in total |
| Image asset | 8192 px per side; 67 108 864 px across all assets |
| Assets / layers / groups / panels | 256 each |
| Regions | 2000 |
| Polygon points | 2048 |
| Actions per handler / per host event | 32 / 256 |
| Animations defined / running | 64 / 16 |
| Animation cycle / total | 50–60 000 ms / 600 000 ms |
| Transition | 10 000 ms |
| Text | title, label 200; description 4000; tooltip 500; layer text 2000; panel text 20 000 |
| URL | 2048 characters |

The machine-readable form is `schema/limits.json`.

Validation has three layers:

1. **Container** (section 3.1). Any violation is fatal.
2. **Manifest**: structure (the JSON Schema covers this part), then rules the schema cannot
   express: unique ids, reference integrity (layers, assets, regions, groups, panels, animations,
   effects and their properties, links inside panel text), geometry (positive sizes, polygon area),
   one effect per type, link safety, trigger restrictions, animation totals, document area.
3. **Package**: every referenced file exists; content matches the declared type; dimensions and
   SHA-256 match; `preview.png` is a PNG; the asset pixel budget holds. Files not referenced by the
   manifest are a warning, or an error in strict mode.

Issue codes are shared by both implementations. Errors start `E_`, warnings `W_`:

`E_ARCHIVE_FORMAT`, `E_ARCHIVE_PATH`, `E_ARCHIVE_DUPLICATE`, `E_ARCHIVE_LIMIT`, `E_ARCHIVE_RATIO`,
`E_ARCHIVE_SIZE`, `E_ARCHIVE_CRC`, `E_ARCHIVE_ENCRYPTED`, `E_ARCHIVE_METHOD`, `E_ARCHIVE_OVERLAP`,
`E_ARCHIVE_MISSING`, `E_JSON`, `E_FORMAT`, `E_VERSION`, `E_TYPE`, `E_REQUIRED`,
`E_UNKNOWN_PROPERTY`, `E_RANGE`, `E_ENUM`, `E_PATTERN`, `E_NONFINITE`, `E_LIMIT`, `E_GEOMETRY`,
`E_DUPLICATE_ID`, `E_DUPLICATE_PATH`, `E_REF`, `E_TARGET`, `E_TRIGGER`, `E_LINK`, `E_ANIMATION`,
`E_EFFECT_DUPLICATE`, `E_EFFECT_PROPERTY`, `E_ASSET_TYPE`, `E_ASSET_HASH`, `E_ASSET_DIMENSIONS`,
`E_ASSET_INCOMPLETE`, `E_UNREFERENCED`, `E_REDACTION`; `W_NEWER_MINOR`, `W_UNKNOWN`, `W_OUTSIDE`,
`W_ASSET_INCOMPLETE`, `W_UNREFERENCED`.

An editor that fails to import a file MUST keep the document it already has open.

## 13. Versioning and migration

`version` is `MAJOR.MINOR`.

* **Same major, same or lower minor** — read normally.
* **Same major, higher minor** — read with warning `W_NEWER_MINOR`. Unknown properties, effect
  types, layer types and actions become warnings (`W_UNKNOWN`) and are ignored rather than
  rejected. Minor versions MUST therefore only *add* optional things whose absence degrades
  gracefully; they MUST NOT change the meaning of anything that exists.
* **Different major** — rejected with `E_VERSION`. The container can still be read, so a viewer
  can show `preview.png`.
* Writers always write the version they implement and SHOULD NOT silently rewrite a document of a
  newer minor version, since they would drop what they do not understand.

Migrations are explicit, one-step functions keyed by source version and chained until the current
version is reached; they never run implicitly in a viewer. `aav migrate old.aav -o new.aav` and the
editor's *Open* apply them.

1.0 is the first published version, so there is nothing real to migrate from. The single migration
shipped (`0.9 → 1.0`) upgrades an unpublished pre-release draft and exists to exercise the
mechanism: `hotspots → regions`, `document.size: [w, h] → width/height`, `color → colour`.

## 14. Accessibility requirements for viewers

A conforming viewer MUST:

* expose the document `title` and `description` as the accessible name and description of the image;
* expose every interactive region as a focusable control named by its `label` (and `description`),
  reachable in document order with Tab, activated with Enter and Space, reporting its selected state;
* draw a visible focus indicator that does not depend on the document's own styling;
* offer the regions as a list, so that none is reachable only by pointing;
* treat touch activation as equivalent to click, and never require hover;
* honour the user's reduced-motion preference and offer a control for it;
* announce panel openings and selection changes to assistive technology;
* move focus into a panel opened from the keyboard and return it when the panel closes.

Authors are responsible for meaningful `title`, `description`, `label` and panel text, and for
colour contrast inside their own images.

## 15. Refinements to the example manifest in the brief

The example in the project brief validates as schema 1.0 after one correction. Changes and
additions made while specifying the format:

* The example's `"colour": "` + "`#FFD47A`" + `"` contained literal backticks, taken to be a
  formatting artefact; colours are plain `#RRGGBB`.
* `preview` is fixed to `"preview.png"` rather than being a free path.
* Assets gained optional `sha256`, `width`, `height` (required from packers, verified by readers).
* Added: `settings`, `groups`, `animations`, `events.document_load`, `default_state`, `thumbnail`,
  `metadata`, `redaction`; on regions `description`, `tooltip`, `z_index`, `interactive`,
  `selectable`, `states`; on layers placement, `opacity`, `visible`, `transform`, `clip`, and the
  `text` layer type; the `polygon` and `mask` shapes.
* A region has at most one effect per type, which is what makes the fixed effect order well defined.
* `open_link` and `navigate_document` are valid only under `activate`.
* `x-` prefixed properties are reserved for extensions.

## 16. Not in version 1.0

Stated plainly, so nobody has to discover it:

* No scripting, no HTML, no embedded fonts, no audio or video, no external resources of any kind.
* No vector graphics layers, no ellipse or curved shapes (use a polygon or a mask), no blend modes.
* No colour management: sRGB only, embedded profiles ignored, no wide gamut or HDR.
* No physically based lighting; `spotlight` and `glow` are image effects.
* No per-layer effects without a region (cover the layer with a region instead).
* No colour or geometry animation; only numeric effect properties animate, for a bounded time.
* No timeline, sequencing or conditional logic; one event runs one flat list of actions.
* No signatures or encryption. SHA-256 values detect accidental or careless modification inside
  a package; they do not authenticate it.
* No ZIP64: a document is limited to 256 MiB uncompressed.
* The Python "basic" render engine draws layers only; full-fidelity static rendering goes through
  the browser renderer (see `README.md`).
