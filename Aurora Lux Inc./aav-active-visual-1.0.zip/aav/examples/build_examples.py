#!/usr/bin/env python3
"""Build the three demonstration documents.

All artwork is drawn procedurally here with Pillow, so the examples are
original and reproducible. Run from the repository root:

    python examples/build_examples.py [--engine auto|basic|browser]

Outputs examples/*.aav and copies them to web/public/examples/ for the viewer.
"""
from __future__ import annotations

import argparse
import io
import random
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

from aav import Document

HERE = Path(__file__).resolve().parent
WEB_EXAMPLES = HERE.parent / "web" / "public" / "examples"
LICENCE = "CC0-1.0"
AUTHOR = "AAV project (procedurally generated artwork)"
CYAN, VIOLET, WARM = "#5AD8E6", "#A78BFA", "#FFD47A"


def encode(image: Image.Image, fmt: str = "PNG") -> bytes:
    out = io.BytesIO()
    if fmt == "WEBP":
        image.save(out, "WEBP", lossless=True, method=4)
    else:
        image.save(out, "PNG", compress_level=9)
    return out.getvalue()


def vertical_gradient(size: tuple[int, int], top: tuple[int, int, int], bottom: tuple[int, int, int]) -> Image.Image:
    width, height = size
    column = Image.new("RGB", (1, height))
    column.putdata([tuple(round(top[i] + (bottom[i] - top[i]) * y / (height - 1)) for i in range(3))
                    for y in range(height)])
    return column.resize(size)


def hover_glow(base: float = 0.0) -> dict:
    return {"type": "glow", "colour": WARM, "intensity": base, "radius": 22}


# --------------------------------------------------------------------------- 1. building

def build_building(engine: str) -> Document:
    width, height = 1600, 1000
    rng = random.Random(7)
    image = vertical_gradient((width, height), (16, 22, 48), (58, 52, 92))
    draw = ImageDraw.Draw(image)
    for _ in range(170):
        x, y = rng.randrange(width), rng.randrange(520)
        shade = rng.randrange(150, 255)
        draw.point((x, y), fill=(shade, shade, min(255, shade + 20)))
    draw.ellipse([1290, 90, 1390, 190], fill=(232, 228, 205))
    draw.ellipse([1318, 80, 1408, 170], fill=(24, 30, 60))
    draw.rectangle([0, 860, width, height], fill=(26, 34, 40))
    draw.rectangle([0, 860, width, 868], fill=(38, 50, 56))
    # Facade.
    left, right, top, bottom = 320, 1280, 300, 860
    draw.rectangle([left, top, right, bottom], fill=(72, 66, 78))
    for y in range(top + 20, bottom, 28):
        draw.line([left, y, right, y], fill=(64, 58, 70), width=1)
    draw.rectangle([left - 14, top - 16, right + 14, top], fill=(96, 88, 100))
    roof = [(left - 40, top - 16), (800, 110), (right + 40, top - 16)]
    draw.polygon(roof, fill=(54, 40, 52))
    draw.line(roof + [roof[0]], fill=(92, 72, 84), width=4)
    draw.rectangle([1040, 150, 1100, 250], fill=(60, 50, 60))
    # Windows: three floors of four.
    windows = []
    floors = [(350, "Third"), (520, "Second"), (690, "First")]
    for floor_index, (wy, floor_name) in enumerate(floors):
        for column in range(4):
            wx = 400 + column * 230
            if floor_index == 2 and column in (1, 2):
                continue  # the entrance occupies the middle of the ground floor
            draw.rectangle([wx - 8, wy - 8, wx + 128, wy + 148], fill=(46, 42, 52))
            draw.rectangle([wx, wy, wx + 120, wy + 140], fill=(28, 36, 62))
            draw.line([wx + 60, wy, wx + 60, wy + 140], fill=(46, 42, 52), width=6)
            draw.line([wx, wy + 62, wx + 120, wy + 62], fill=(46, 42, 52), width=6)
            draw.rectangle([wx - 14, wy + 148, wx + 134, wy + 158], fill=(96, 88, 100))
            windows.append((f"window-{3 - floor_index}{column + 1}", f"{floor_name}-floor window {column + 1}",
                            wx, wy, floor_name))
    # Entrance with an arched door.
    draw.rectangle([640, 690, 960, 860], fill=(60, 54, 66))
    door_box = (730, 700, 870, 860)
    draw.pieslice([door_box[0], door_box[1], door_box[2], door_box[1] + 140], 180, 360, fill=(92, 58, 44))
    draw.rectangle([door_box[0], door_box[1] + 70, door_box[2], door_box[3]], fill=(92, 58, 44))
    draw.line([800, 706, 800, 860], fill=(66, 40, 30), width=4)
    draw.ellipse([812, 780, 824, 792], fill=(214, 180, 96))
    for step in range(3):
        draw.rectangle([700 - step * 18, 860 + step * 12, 900 + step * 18, 872 + step * 12], fill=(84, 78, 88))
    # Street lamp.
    draw.rectangle([196, 520, 206, 860], fill=(40, 44, 50))
    draw.polygon([(176, 520), (226, 520), (214, 480), (188, 480)], fill=(52, 56, 62))
    draw.ellipse([190, 488, 212, 510], fill=(250, 232, 170))

    doc = Document.new(width, height, title="Illuminated Building", doc_id="illuminated-building",
                       description="A night view of a three-storey building with ten windows, an arched entrance "
                                   "door, a pitched roof and a street lamp. Windows light up and open room notes.")
    doc.manifest["document"].update(language="en", background="#10162F")
    doc.manifest["metadata"].update(author=AUTHOR, licence=LICENCE, created="2026-11-24")
    doc.manifest["settings"] = {"selection": "single"}
    doc.add_asset("base", encode(image, "WEBP"), filename="base.webp")
    doc.add_image_layer("background", "base", name="Building at night")

    # Door mask: alpha follows the arched door, so hit testing ignores the corners.
    mask = Image.new("RGBA", (140, 160), (255, 255, 255, 0))
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.pieslice([0, 0, 140, 140], 180, 360, fill=(255, 255, 255, 255))
    mask_draw.rectangle([0, 70, 140, 160], fill=(255, 255, 255, 255))
    doc.add_asset("door-mask", encode(mask), folder="masks", filename="door.png")

    # A transparent overlay: warm light spilling from the lamp, toggled by the lamp region.
    spill = Image.new("RGBA", (420, 420), (0, 0, 0, 0))
    spill_draw = ImageDraw.Draw(spill)
    for radius in range(200, 0, -8):
        spill_draw.ellipse([210 - radius, 210 - radius, 210 + radius, 210 + radius],
                           fill=(255, 226, 150, round(46 * (1 - radius / 200) ** 1.5) + 2))
    doc.add_asset("lamp-light", encode(spill.filter(ImageFilter.GaussianBlur(10))), filename="lamp-light.png")
    doc.add_image_layer("lamp-light", "lamp-light", name="Lamp light (overlay)", x=-9, y=290, width=420, height=420,
                        visible=False)

    doc.add_text_layer("caption", "Hover a window to light it. Press Enter or click for the room notes.",
                       800, 936, font_size=26, align="centre", colour="#F4F0E6", background="#15171ACC", padding=10,
                       name="Caption")
    doc.add_text_layer("all-lights-label", "All lights", 1456, 792, font_size=24, align="centre", font_weight=700,
                       colour="#15171A", background=WARM, padding=12, name="Button: All lights")
    doc.add_text_layer("lights-off-label", "Lights off", 1456, 862, font_size=24, align="centre", font_weight=700,
                       colour="#F4F0E6", background="#3D434B", padding=12, name="Button: Lights off")

    rooms = {
        "Third": ("Third-floor studio", "A north-lit **studio** under the roof.\n\n- Ceiling height: 3.1 m\n"
                                        "- Two roof lights\n\nSee also the [roof](#region:roof)."),
        "Second": ("Second-floor office", "An open-plan *office* for six people.\n\nThe lighting on this floor is "
                                          "described in the [lighting notes](#panel:lighting)."),
        "First": ("First-floor reception", "Reception and waiting area beside the [entrance](#region:door).\n\n"
                                           "Opening hours are listed in the "
                                           "[visitor guide](https://example.org/aav-demo/visitor-guide)."),
    }
    for floor, (title, text) in rooms.items():
        doc.add_panel(f"room-{floor.lower()}", title, text)
    doc.add_panel("lighting", "Lighting notes",
                  "Each window carries a `glow` effect whose intensity is raised on hover and focus.\n\n"
                  "This is an image effect: the picture is brightened inside the window shape. It is not a "
                  "physical relighting of the scene.")
    doc.add_panel("door-info", "Entrance",
                  "# Main entrance\n\nThe door region uses a **raster mask**, so the corners outside the arch do not "
                  "respond to the pointer.\n\n- [Accessibility information](https://example.org/aav-demo/access)\n"
                  "- [Second-floor office](#panel:room-second)")
    doc.add_panel("roof-info", "Roof", "A pitched slate roof. Selecting it outlines the polygon boundary.")

    window_ids = []
    for region_id, label, wx, wy, floor in windows:
        window_ids.append(region_id)
        doc.add_region(
            region_id, label, Document.rect(wx, wy, 120, 140), target_layer="background", tooltip=label,
            description=f"A window on the {floor.lower()} floor. Activating it opens the room notes.",
            effects={"illumination": hover_glow(), "pane": {"type": "brightness", "amount": 1},
                     "edge": {"type": "outline", "colour": VIOLET, "width": 4, "opacity": 0}},
            states={"focus": {"illumination": {"intensity": 0.8}, "pane": {"amount": 1.9}},
                    "selected": {"edge": {"opacity": 1}, "illumination": {"intensity": 0.55}, "pane": {"amount": 1.6}}},
            events={
                "pointer_enter": [
                    {"action": "set_effect", "effect": "illumination", "property": "intensity", "value": 0.8,
                     "duration_ms": 180},
                    {"action": "set_effect", "effect": "pane", "property": "amount", "value": 1.9, "duration_ms": 180},
                    {"action": "show_tooltip"}],
                "pointer_leave": [
                    {"action": "set_effect", "effect": "illumination", "property": "intensity", "value": 0,
                     "duration_ms": 260},
                    {"action": "set_effect", "effect": "pane", "property": "amount", "value": 1, "duration_ms": 260}],
                "activate": [{"action": "open_panel", "panel": f"room-{floor.lower()}"}],
            })
    doc.add_group("windows", "Windows", window_ids, description="Every window on the facade.")

    doc.add_region("roof", "Roof", Document.polygon([(280, 284), (800, 110), (1320, 284)]), target_layer="background",
                   description="The pitched roof.",
                   effects={"edge": {"type": "outline", "colour": CYAN, "width": 5, "opacity": 0},
                            "wash": {"type": "tint", "colour": CYAN, "amount": 0}},
                   states={"hover": {"edge": {"opacity": 0.7}}, "focus": {"edge": {"opacity": 0.7}},
                           "selected": {"edge": {"opacity": 1}, "wash": {"amount": 0.18}}},
                   events={"activate": [{"action": "open_panel", "panel": "roof-info"}]})
    doc.add_region("door", "Entrance door", Document.mask("door-mask", x=730, y=700, width=140, height=160),
                   target_layer="background", description="The arched entrance door.", z_index=1,
                   effects={"edge": {"type": "outline", "colour": WARM, "width": 4, "opacity": 0},
                            "warm": {"type": "tint", "colour": WARM, "amount": 0, "mode": "screen"}},
                   states={"hover": {"edge": {"opacity": 1}, "warm": {"amount": 0.25}},
                           "focus": {"edge": {"opacity": 1}, "warm": {"amount": 0.25}},
                           "selected": {"edge": {"opacity": 1}, "warm": {"amount": 0.4}}},
                   events={"activate": [{"action": "open_panel", "panel": "door-info"}]})
    doc.add_region("lamp", "Street lamp", Document.rect(166, 470, 70, 400), target_layer="background",
                   description="Toggles a pool of light around the street lamp.", tooltip="Toggle the lamp light",
                   events={"activate": [{"action": "toggle_layer", "layer": "lamp-light"}],
                           "pointer_enter": [{"action": "show_tooltip"}], "focus": [{"action": "show_tooltip"}]})
    doc.add_region("garden", "Forecourt", Document.rect(0, 868, 1600, 132), target_layer="background",
                   description="The paved forecourt. A soft light follows the pointer here.",
                   selectable=False, z_index=-1,
                   effects={"torch": {"type": "spotlight", "colour": "#FFF2CC", "intensity": 0, "radius": 190,
                                      "falloff": 1.6, "ambient": 1, "follow_pointer": True}},
                   states={"hover": {"torch": {"intensity": 1.4}}})

    all_on = [{"action": "set_effect", "group": "windows", "effect": "illumination", "property": "intensity",
               "value": 0.7, "duration_ms": 500},
              {"action": "set_effect", "group": "windows", "effect": "pane", "property": "amount", "value": 1.8,
               "duration_ms": 500},
              {"action": "play_animation", "animation": "welcome-pulse"}]
    all_off = [{"action": "stop_animation"},
               {"action": "set_effect", "group": "windows", "effect": "illumination", "property": "intensity",
                "value": 0, "duration_ms": 500},
               {"action": "set_effect", "group": "windows", "effect": "pane", "property": "amount", "value": 1,
                "duration_ms": 500}]
    doc.add_region("all-lights", "Switch all lights on", Document.rect(1370, 780, 172, 54), selectable=False,
                   z_index=5, description="Lights every window.", events={"activate": all_on})
    doc.add_region("lights-off", "Switch all lights off", Document.rect(1370, 850, 172, 54), selectable=False,
                   z_index=5, description="Darkens every window.", events={"activate": all_off})
    doc.add_animation("welcome-pulse", type="pulse", region="window-32", effect="illumination", property="intensity",
                      **{"from": 0.3, "to": 1.2}, duration_ms=1400, iterations=3, easing="ease-in-out", end="revert")
    doc.save(HERE / "illuminated-building.aav", engine=engine)
    return doc


# --------------------------------------------------------------------------- 2. product

def build_product(engine: str) -> Document:
    width, height = 1400, 900
    image = vertical_gradient((width, height), (36, 40, 46), (22, 24, 28))
    draw = ImageDraw.Draw(image)
    draw.ellipse([260, 700, 1140, 800], fill=(18, 20, 23))
    # A fictional rangefinder-style camera, drawn from simple shapes.
    body = [330, 300, 1070, 720]
    draw.rounded_rectangle(body, radius=36, fill=(58, 62, 70))
    draw.rounded_rectangle([330, 300, 1070, 372], radius=30, fill=(176, 172, 162))
    draw.rectangle([330, 344, 1070, 372], fill=(176, 172, 162))
    draw.rounded_rectangle([330, 650, 1070, 720], radius=30, fill=(150, 146, 138))
    draw.rectangle([330, 650, 1070, 676], fill=(150, 146, 138))
    grip = [(330, 372), (470, 372), (490, 650), (330, 650)]
    draw.polygon(grip, fill=(40, 43, 49))
    for y in range(384, 644, 14):
        draw.line([342, y, 474, y], fill=(48, 52, 59), width=2)
    lens_centre, lens_radius = (760, 512), 150
    for radius, shade in ((150, (30, 32, 36)), (132, (92, 96, 104)), (116, (24, 26, 30)), (92, (38, 52, 78)),
                          (60, (20, 28, 46)), (26, (70, 96, 140))):
        draw.ellipse([lens_centre[0] - radius, lens_centre[1] - radius, lens_centre[0] + radius,
                      lens_centre[1] + radius], fill=shade)
    draw.ellipse([700, 450, 740, 480], fill=(150, 176, 214))
    draw.rounded_rectangle([900, 320, 1030, 362], radius=6, fill=(26, 30, 38))
    draw.rounded_rectangle([908, 326, 1022, 356], radius=4, fill=(60, 84, 120))
    draw.ellipse([400, 262, 470, 306], fill=(196, 60, 52))
    draw.rectangle([424, 296, 446, 306], fill=(140, 136, 128))
    draw.rounded_rectangle([540, 270, 660, 304], radius=8, fill=(112, 108, 100))
    for x in range(548, 656, 9):
        draw.line([x, 272, x, 302], fill=(84, 80, 74), width=2)
    draw.ellipse([1052, 380, 1092, 420], outline=(176, 172, 162), width=8)

    doc = Document.new(width, height, title="Interactive Product", doc_id="interactive-product",
                       description="A stylised camera on a dark studio background. Components can be highlighted, "
                                   "and each opens notes with a documentation link.")
    doc.manifest["document"]["language"] = "en"
    doc.manifest["metadata"].update(author=AUTHOR, licence=LICENCE, created="2026-11-24")
    doc.manifest["settings"] = {"selection": "multiple"}
    doc.add_asset("base", encode(image), filename="base.png")
    doc.add_image_layer("background", "base", name="Camera")

    lens_mask = Image.new("RGBA", (300, 300), (255, 255, 255, 0))
    ImageDraw.Draw(lens_mask).ellipse([0, 0, 299, 299], fill=(255, 255, 255, 255))
    doc.add_asset("lens-mask", encode(lens_mask), folder="masks", filename="lens.png")

    parts = [
        ("lens", "Lens", Document.mask("lens-mask", x=610, y=362, width=300, height=300),
         "A 40 mm lens. The region is a circular raster mask.", (960, 520), "lens"),
        ("shutter", "Shutter button", Document.rect(396, 258, 78, 52),
         "Half-press to focus, full press to expose.", (300, 210), "shutter-button"),
        ("dial", "Mode dial", Document.rect(536, 266, 128, 42),
         "Selects aperture priority, shutter priority or manual.", (600, 200), "mode-dial"),
        ("viewfinder", "Viewfinder", Document.rect(896, 316, 138, 50),
         "An optical viewfinder with frame lines.", (1090, 250), "viewfinder"),
        ("grip", "Hand grip", Document.polygon(grip), "A textured grip moulded into the body.", (150, 520), "grip"),
        ("lug", "Strap lug", Document.rect(1044, 372, 56, 56), "Attachment point for a neck strap.", (1180, 400),
         "strap-lug"),
    ]
    part_ids = []
    for region_id, label, shape, text, (lx, ly), slug in parts:
        part_ids.append(region_id)
        doc.add_text_layer(f"note-{region_id}", label, lx, ly, font_size=22, colour="#15171A", background=CYAN,
                           padding=8, align="centre", name=f"Annotation: {label}", visible=False)
        doc.add_panel(f"info-{region_id}", label,
                      f"{text}\n\n- Part reference: `{slug}`\n- [Documentation for the {label.lower()}]"
                      f"(https://example.org/aav-demo/camera/{slug})\n\nBack to the [overview](#panel:overview).")
        doc.add_region(
            region_id, label, shape, target_layer="background", description=text, tooltip=label,
            effects={"edge": {"type": "outline", "colour": CYAN, "width": 4, "opacity": 0},
                     "wash": {"type": "tint", "colour": CYAN, "amount": 0, "mode": "screen"},
                     "lift": {"type": "brightness", "amount": 1}},
            states={"hover": {"edge": {"opacity": 0.9}, "lift": {"amount": 1.25}},
                    "focus": {"edge": {"opacity": 0.9}, "lift": {"amount": 1.25}},
                    "selected": {"edge": {"opacity": 1, "colour": VIOLET}, "wash": {"amount": 0.22, "colour": VIOLET}}},
            events={"pointer_enter": [{"action": "show_tooltip"}],
                    "activate": [{"action": "toggle_layer", "layer": f"note-{region_id}", "mode": "show"},
                                 {"action": "open_panel", "panel": f"info-{region_id}"}]})
    doc.add_group("components", "Camera components", part_ids)
    doc.add_panel("overview", "About this camera",
                  "A fictional camera used to demonstrate component highlighting.\n\nSeveral parts can be selected "
                  "at once. Start with the [lens](#region:lens) or the [shutter button](#region:shutter).")

    doc.add_text_layer("manual-label", "Open the manual", 1230, 806, font_size=22, font_weight=700, align="centre",
                       colour="#15171A", background=VIOLET, padding=12, name="Button: manual")
    doc.add_text_layer("notes-label", "Hide annotations", 1230, 736, font_size=22, align="centre", colour="#F4F0E6",
                       background="#3D434B", padding=12, name="Button: hide annotations")
    doc.add_text_layer("next-label", "Next demo", 170, 806, font_size=22, align="centre", colour="#F4F0E6",
                       background="#3D434B", padding=12, name="Button: next demo")
    doc.add_region("manual", "Open the manual (external link)", Document.rect(1120, 794, 220, 52), selectable=False,
                   z_index=5, description="Opens the online manual after confirmation.",
                   events={"activate": [{"action": "open_link", "url": "https://example.org/aav-demo/camera/manual",
                                         "label": "Camera manual"}]})
    doc.add_region("hide-notes", "Hide all annotations", Document.rect(1120, 724, 220, 52), selectable=False,
                   z_index=5, description="Hides every annotation label and clears the selection.",
                   events={"activate": [{"action": "toggle_layer", "layer": f"note-{rid}", "mode": "hide"}
                                        for rid in part_ids] +
                                       [{"action": "select_region", "group": "components", "mode": "deselect"}]})
    doc.add_region("next-demo", "Open the Pixel Art Playground document", Document.rect(90, 794, 160, 52),
                   selectable=False, z_index=5, description="Opens another AAV document after confirmation.",
                   events={"activate": [{"action": "navigate_document", "href": "pixel-art-playground.aav",
                                         "label": "Pixel Art Playground"}]})
    doc.manifest["default_state"] = {"panel": "overview"}
    doc.save(HERE / "interactive-product.aav", engine=engine)
    return doc


# --------------------------------------------------------------------------- 3. pixel art

def build_pixel_art(engine: str) -> Document:
    scale, cols, rows = 10, 96, 54
    art = Image.new("RGB", (cols, rows), (108, 190, 232))
    px = art.load()
    for y in range(rows):
        for x in range(cols):
            if y < 30:
                px[x, y] = (108 - y, 190 - y * 2, 232 - y)
            elif y < 34:
                px[x, y] = (96, 160, 110) if (x + y) % 7 else (84, 148, 100)
            else:
                px[x, y] = (86, 170, 84) if (x * 3 + y * 5) % 11 else (70, 150, 72)
    draw = ImageDraw.Draw(art)
    draw.rectangle([74, 5, 83, 14], fill=(255, 220, 92))
    draw.rectangle([76, 3, 81, 16], fill=(255, 220, 92))
    draw.rectangle([72, 7, 85, 12], fill=(255, 220, 92))
    draw.rectangle([77, 8, 80, 11], fill=(255, 244, 170))
    for cx, cy in ((14, 8), (40, 5)):
        draw.rectangle([cx, cy, cx + 12, cy + 3], fill=(244, 248, 252))
        draw.rectangle([cx + 3, cy - 2, cx + 9, cy + 3], fill=(244, 248, 252))
    draw.polygon([(0, 30), (16, 16), (30, 30)], fill=(98, 110, 150))
    draw.polygon([(20, 30), (38, 12), (58, 30)], fill=(82, 94, 136))
    draw.polygon([(34, 16), (38, 12), (42, 16)], fill=(236, 240, 248))
    draw.rectangle([56, 26, 76, 40], fill=(206, 150, 104))
    draw.polygon([(53, 26), (66, 16), (79, 26)], fill=(168, 62, 58))
    draw.rectangle([64, 32, 68, 40], fill=(96, 60, 44))
    draw.rectangle([58, 29, 62, 33], fill=(150, 210, 240))
    draw.rectangle([70, 29, 74, 33], fill=(150, 210, 240))
    draw.rectangle([20, 34, 22, 44], fill=(104, 70, 46))
    draw.rectangle([15, 26, 27, 35], fill=(44, 132, 66))
    draw.rectangle([17, 23, 25, 37], fill=(44, 132, 66))
    draw.rectangle([19, 27, 21, 29], fill=(74, 164, 92))
    draw.rectangle([40, 38, 42, 43], fill=(60, 80, 170))   # a small figure
    draw.rectangle([40, 35, 42, 37], fill=(240, 200, 160))
    draw.rectangle([39, 34, 43, 34], fill=(120, 70, 40))
    draw.rectangle([0, 46, cols, rows], fill=(32, 36, 44))  # control strip
    image = art.resize((cols * scale, rows * scale), Image.Resampling.NEAREST)
    width, height = image.size

    doc = Document.new(width, height, title="Pixel Art Playground", doc_id="pixel-art-playground",
                       description="A small pixel-art landscape with a sun, mountains, a house, a tree and a figure. "
                                   "Controls below the scene change pixelation and colour.")
    doc.manifest["document"]["language"] = "en"
    doc.manifest["metadata"].update(author=AUTHOR, licence=LICENCE, created="2026-11-24")
    doc.manifest["settings"] = {"selection": "none", "image_rendering": "pixelated", "default_highlight": True}
    doc.add_asset("base", encode(image), filename="base.png")
    doc.add_image_layer("background", "base", name="Scene")

    scene_h = 46 * scale
    doc.add_region("scene", "Scene", Document.rect(0, 0, width, scene_h), target_layer="background",
                   interactive=False,
                   description="The whole landscape. Effects from the controls apply here.",
                   effects={"mosaic": {"type": "pixelate", "block_size": 1},
                            "sat": {"type": "saturation", "amount": 1},
                            "con": {"type": "contrast", "amount": 1},
                            "wash": {"type": "tint", "colour": "#2B1B5A", "amount": 0, "mode": "multiply"},
                            "light": {"type": "brightness", "amount": 1}})
    doc.add_region("sun", "Sun", Document.rect(72 * scale, 3 * scale, 14 * scale, 14 * scale),
                   target_layer="background", description="The sun. Activating it plays a short pulse.",
                   tooltip="Pulse the sun",
                   effects={"halo": {"type": "glow", "colour": "#FFE98A", "intensity": 0, "radius": 40}},
                   states={"hover": {"halo": {"intensity": 0.5}}, "focus": {"halo": {"intensity": 0.5}}},
                   events={"activate": [{"action": "play_animation", "animation": "sun-pulse"}],
                           "pointer_enter": [{"action": "show_tooltip"}]})
    doc.add_region("house", "House (reversible blur)", Document.rect(53 * scale, 16 * scale, 27 * scale, 25 * scale),
                   target_layer="background", tooltip="Toggle a display blur",
                   description="Toggles a display blur over the house. This is a reversible effect, not redaction: "
                               "the original pixels remain in the file.",
                   effects={"soft": {"type": "blur", "radius": 0}},
                   events={"activate": [{"action": "play_animation", "animation": "house-blur"}],
                           "pointer_enter": [{"action": "show_tooltip"}]})
    doc.add_animation("sun-pulse", type="pulse", region="sun", effect="halo", property="intensity",
                      **{"from": 0.2, "to": 1.4}, duration_ms=900, iterations=3)
    doc.add_animation("house-blur", type="pulse", region="house", effect="soft", property="radius",
                      **{"from": 0, "to": 14}, duration_ms=2400, iterations=1)
    doc.add_animation("dusk", type="fade", region="scene", effect="wash", property="amount",
                      **{"from": 0, "to": 0.55}, duration_ms=1500, end="hold")

    def set_scene(effect: str, prop: str, value, duration: int = 250) -> dict:
        return {"action": "set_effect", "region": "scene", "effect": effect, "property": prop, "value": value,
                "duration_ms": duration}

    reset = [{"action": "stop_animation"}, set_scene("mosaic", "block_size", 1), set_scene("sat", "amount", 1),
             set_scene("con", "amount", 1), set_scene("wash", "amount", 0), set_scene("light", "amount", 1)]
    controls = [
        ("px-1", "Sharp", "Pixelation off (block size 1)", [set_scene("mosaic", "block_size", 1)]),
        ("px-20", "Blocks 20", "Pixelation with 20 pixel blocks", [set_scene("mosaic", "block_size", 20)]),
        ("px-40", "Blocks 40", "Pixelation with 40 pixel blocks", [set_scene("mosaic", "block_size", 40)]),
        ("px-80", "Blocks 80", "Pixelation with 80 pixel blocks", [set_scene("mosaic", "block_size", 80)]),
        ("grey", "Greyscale", "Remove colour saturation", [set_scene("sat", "amount", 0, 400)]),
        ("vivid", "Vivid", "Boost saturation and contrast",
         [set_scene("sat", "amount", 1.8, 400), set_scene("con", "amount", 1.25, 400)]),
        ("dusk", "Dusk", "Fade to a dusk tint", [set_scene("light", "amount", 0.85, 1500),
                                                  {"action": "play_animation", "animation": "dusk"}]),
        ("reset", "Reset", "Restore the original scene", reset),
    ]
    slot = width / len(controls)
    for index, (region_id, text, description, actions) in enumerate(controls):
        cx = slot * index + slot / 2
        doc.add_text_layer(f"label-{region_id}", text, cx, scene_h + 26, font_size=20, align="centre",
                           colour="#15171A" if region_id != "reset" else "#F4F0E6",
                           background=(CYAN if index < 4 else VIOLET) if region_id != "reset" else "#3D434B",
                           padding=9, name=f"Control: {text}")
        doc.add_region(f"control-{region_id}", f"{text}: {description}",
                       Document.rect(cx - slot / 2 + 6, scene_h + 8, slot - 12, 64), description=description,
                       events={"activate": actions})
    doc.add_group("controls", "Controls", [f"control-{c[0]}" for c in controls])
    doc.save(HERE / "pixel-art-playground.aav", engine=engine)
    return doc


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--engine", choices=["auto", "basic", "browser"], default="auto")
    args = parser.parse_args()
    WEB_EXAMPLES.mkdir(parents=True, exist_ok=True)
    for build in (build_building, build_product, build_pixel_art):
        doc = build(args.engine)
        name = f"{doc.manifest['document']['id']}.aav"
        shutil.copyfile(HERE / name, WEB_EXAMPLES / name)
        print(f"built {name}: {len(doc.manifest['regions'])} regions, {len(doc.manifest['layers'])} layers, "
              f"{(HERE / name).stat().st_size} bytes")


if __name__ == "__main__":
    main()
