import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RadiometryPhysicsService } from '../../services/radiometry-physics.service';

@Component({
  selector: 'app-uncertainty-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">bar_chart</mat-icon>
            <span>Metrology Uncertainty Engine · ISO/IEC Guide 98-3 (GUM)</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Measurement Uncertainty Budget (T ± U₉₅)
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Treating measurement uncertainty as a first-class mathematical type. Propagates detector noise, calibration residual, surface emissivity, reflected temperature, and atmospheric transmission error.
          </p>
        </div>

        <div class="flex items-center gap-3 font-mono text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-emerald-400 font-bold">
            Expanded U₉₅ (k=2): <span class="text-white">±{{ uncertainty().expandedU95 }} °C</span>
          </div>
        </div>
      </div>

      <!-- Main Layout: Parameter Sensitivity Left (400px) + Pareto Budget Right (Flex-1) -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Parameter Sensitivity & Interactive Inputs -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <h2 class="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
            <mat-icon class="text-sm text-amber-400">tune</mat-icon>
            <span>Measurement Condition Inputs</span>
          </h2>

          <div class="space-y-3">
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Surface Temp (T):</span>
                <span class="text-white font-bold">{{ targetTempC() }} °C</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="250" 
                [value]="targetTempC()" 
                (input)="targetTempC.set(+($any($event.target).value))"
                aria-label="Surface Temperature Slider"
                class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Target Emissivity (ε):</span>
                <span class="text-cyan-400 font-bold">{{ emissivity().toFixed(2) }}</span>
              </div>
              <input 
                type="range" 
                min="0.50" 
                max="1.00" 
                step="0.01"
                [value]="emissivity()" 
                (input)="emissivity.set(+($any($event.target).value))"
                aria-label="Target Emissivity Slider"
                class="w-full accent-cyan-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Emissivity Uncertainty u(ε):</span>
                <span class="text-amber-400 font-bold">±{{ (emissivityUncertainty() * 100).toFixed(1) }}%</span>
              </div>
              <input 
                type="range" 
                min="0.005" 
                max="0.08" 
                step="0.005"
                [value]="emissivityUncertainty()" 
                (input)="emissivityUncertainty.set(+($any($event.target).value))"
                aria-label="Emissivity Uncertainty Slider"
                class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Detector NETD u₁:</span>
                <span class="text-white font-bold">{{ (netdC() * 1000).toFixed(0) }} mK</span>
              </div>
              <input 
                type="range" 
                min="0.010" 
                max="0.080" 
                step="0.005"
                [value]="netdC()" 
                (input)="netdC.set(+($any($event.target).value))"
                aria-label="Detector NETD Slider"
                class="w-full accent-white h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Reflected Temp Uncertainty u(T_refl):</span>
                <span class="text-slate-300 font-bold">±{{ reflTempUncertaintyC() }} °C</span>
              </div>
              <input 
                type="range" 
                min="0.5" 
                max="5.0" 
                step="0.1"
                [value]="reflTempUncertaintyC()" 
                (input)="reflTempUncertaintyC.set(+($any($event.target).value))"
                aria-label="Reflected Temperature Uncertainty Slider"
                class="w-full accent-slate-400 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>
          </div>
        </div>

        <!-- Pareto Uncertainty Contribution Chart (2 Cols) -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="font-bold text-white uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-cyan-400">stacked_bar_chart</mat-icon>
              <span>GUM Uncertainty Budget Breakdown (Pareto Analysis)</span>
            </span>
            <span class="text-emerald-400 font-bold">
              Combined u_c = ±{{ uncertainty().combinedU }} °C
            </span>
          </div>

          <!-- GUM Component List -->
          <div class="space-y-3">
            
            <!-- Component 1: Emissivity -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px]">
                <span class="text-slate-300 font-bold">u(ε) — Surface Emissivity Uncertainty</span>
                <span class="text-amber-400 font-bold">±{{ uncertainty().components.uEmissivity }} °C</span>
              </div>
              <div class="w-full bg-slate-950 h-2 rounded overflow-hidden border border-slate-800">
                <div 
                  class="bg-amber-500 h-full rounded transition-all"
                  [style.width.%]="(uncertainty().components.uEmissivity / uncertainty().combinedU) * 80">
                </div>
              </div>
            </div>

            <!-- Component 2: Reflected Temperature -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px]">
                <span class="text-slate-300 font-bold">u(T_refl) — Reflected Background Apparent Temp</span>
                <span class="text-cyan-400 font-bold">±{{ uncertainty().components.uReflectedTemp }} °C</span>
              </div>
              <div class="w-full bg-slate-950 h-2 rounded overflow-hidden border border-slate-800">
                <div 
                  class="bg-cyan-500 h-full rounded transition-all"
                  [style.width.%]="(uncertainty().components.uReflectedTemp / uncertainty().combinedU) * 80">
                </div>
              </div>
            </div>

            <!-- Component 3: Calibration Residual -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px]">
                <span class="text-slate-300 font-bold">u(CAL) — Blackbody Polynomial Residual Fit</span>
                <span class="text-emerald-400 font-bold">±{{ uncertainty().components.uCalibrationResidual }} °C</span>
              </div>
              <div class="w-full bg-slate-950 h-2 rounded overflow-hidden border border-slate-800">
                <div 
                  class="bg-emerald-500 h-full rounded transition-all"
                  [style.width.%]="(uncertainty().components.uCalibrationResidual / uncertainty().combinedU) * 80">
                </div>
              </div>
            </div>

            <!-- Component 4: Detector Noise NETD -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px]">
                <span class="text-slate-300 font-bold">u(NETD) — Detector Temporal Focal Plane Noise</span>
                <span class="text-slate-200 font-bold">±{{ uncertainty().components.uDetectorNoise }} °C</span>
              </div>
              <div class="w-full bg-slate-950 h-2 rounded overflow-hidden border border-slate-800">
                <div 
                  class="bg-slate-400 h-full rounded transition-all"
                  [style.width.%]="(uncertainty().components.uDetectorNoise / uncertainty().combinedU) * 80">
                </div>
              </div>
            </div>

            <!-- Component 5: Atmospheric Transmission -->
            <div class="space-y-1">
              <div class="flex justify-between text-[11px]">
                <span class="text-slate-300 font-bold">u(τ_atm) — Atmospheric Extinction Transmission</span>
                <span class="text-indigo-400 font-bold">±{{ uncertainty().components.uAtmospheric }} °C</span>
              </div>
              <div class="w-full bg-slate-950 h-2 rounded overflow-hidden border border-slate-800">
                <div 
                  class="bg-indigo-500 h-full rounded transition-all"
                  [style.width.%]="(uncertainty().components.uAtmospheric / uncertainty().combinedU) * 80">
                </div>
              </div>
            </div>

          </div>

          <!-- Mathematical Statement Box -->
          <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1 mt-4 text-[11px]">
            <div class="text-amber-400 font-bold">GUM Compliance Formal Statement:</div>
            <div class="text-white text-sm">
              T_true = {{ targetTempC() }} °C ± <span class="text-emerald-400 font-bold">{{ uncertainty().expandedU95 }} °C</span> (Coverage factor k = 2.00, approx. 95% level of confidence)
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class UncertaintyLabComponent {
  private readonly physics = inject(RadiometryPhysicsService);

  public readonly targetTempC = signal<number>(126.8);
  public readonly emissivity = signal<number>(0.94);
  public readonly emissivityUncertainty = signal<number>(0.03);
  public readonly netdC = signal<number>(0.035);
  public readonly reflTempUncertaintyC = signal<number>(1.5);

  public readonly uncertainty = computed(() => {
    return this.physics.calculateGUMUncertainty(
      this.targetTempC(),
      this.emissivity(),
      0.962,
      this.netdC(),
      0.038,
      this.emissivityUncertainty(),
      this.reflTempUncertaintyC(),
      0.02
    );
  });
}
