import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';
import { MaterialSpectralReference } from '../../models/infrared.models';

@Component({
  selector: 'app-hyperspectral',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">grid_view</mat-icon>
            <span>Aardvark Hyperspectral Infrared Engine</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Datacube Decomposition & Spectral Angle Mapping (SAM)
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Inspect continuous X × Y × λ infrared datacubes (8.0 to 14.0 µm). Extract chemical absorption and material emissivity signatures with automated Spectral Angle Mapper (SAM) classification.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-amber-400">
            Active Cube: <span class="text-white font-bold">128 × 96 × 13 Bands</span>
          </div>
        </div>
      </div>

      <!-- Main Layout: 3 Columns -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Column 1: Band Slices & PCA Explorer -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 class="text-sm font-semibold text-white flex items-center justify-between border-b border-slate-800 pb-2 font-mono">
            <span class="flex items-center gap-2">
              <mat-icon class="text-sm text-cyan-400">layers</mat-icon>
              <span>01. Wavelength Slices</span>
            </span>
            <span class="text-[11px] text-amber-400">{{ activeWavelengthUm() }} µm</span>
          </h2>

          <div class="space-y-3 text-xs font-mono">
            <div>
              <div class="text-slate-400 mb-1">Select Spectral Band λ:</div>
              <div class="grid grid-cols-4 gap-1.5 text-[10px]">
                @for (wl of wavelengths; track wl) {
                  <button 
                    (click)="activeWavelengthUm.set(wl)"
                    class="py-1.5 px-1 rounded border text-center transition-colors cursor-pointer"
                    [class.bg-slate-800]="activeWavelengthUm() === wl"
                    [class.border-amber-500]="activeWavelengthUm() === wl"
                    [class.text-amber-400]="activeWavelengthUm() === wl"
                    [class.bg-slate-950]="activeWavelengthUm() !== wl"
                    [class.border-slate-800]="activeWavelengthUm() !== wl"
                    [class.text-slate-400]="activeWavelengthUm() !== wl">
                    {{ wl }} µm
                  </button>
                }
              </div>
            </div>

            <!-- PCA Decomposition Selector -->
            <div class="pt-2 border-t border-slate-800">
              <div class="text-slate-400 mb-1.5">Principal Component Analysis (PCA):</div>
              <div class="grid grid-cols-3 gap-1 text-[11px]">
                <button 
                  (click)="activePcaComponent.set(1)"
                  class="p-2 rounded border text-center cursor-pointer"
                  [class.bg-slate-800]="activePcaComponent() === 1"
                  [class.border-cyan-500]="activePcaComponent() === 1">
                  <div class="font-bold text-white">PC-1</div>
                  <div class="text-[9px] text-slate-400">84.2% var</div>
                </button>
                <button 
                  (click)="activePcaComponent.set(2)"
                  class="p-2 rounded border text-center cursor-pointer"
                  [class.bg-slate-800]="activePcaComponent() === 2"
                  [class.border-amber-500]="activePcaComponent() === 2">
                  <div class="font-bold text-white">PC-2</div>
                  <div class="text-[9px] text-slate-400">11.6% var</div>
                </button>
                <button 
                  (click)="activePcaComponent.set(3)"
                  class="p-2 rounded border text-center cursor-pointer"
                  [class.bg-slate-800]="activePcaComponent() === 3"
                  [class.border-emerald-500]="activePcaComponent() === 3">
                  <div class="font-bold text-white">PC-3</div>
                  <div class="text-[9px] text-slate-400">3.8% var</div>
                </button>
              </div>
            </div>

            <!-- Cube Slice Visualizer -->
            <div class="aspect-[4/3] bg-black rounded-lg border border-slate-800 flex items-center justify-center relative overflow-hidden">
              <div class="absolute inset-0 bg-gradient-to-tr from-cyan-950/40 via-slate-900 to-amber-950/40"></div>
              <div class="relative z-10 text-center font-mono space-y-1">
                <div class="text-cyan-400 text-xs font-bold">BAND SLICE: {{ activeWavelengthUm() }} µm</div>
                <div class="text-slate-400 text-[10px]">Emissivity Channel Normalized</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Column 2: Probed Spectral Signature Curve -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 class="text-sm font-semibold text-white flex items-center justify-between border-b border-slate-800 pb-2 font-mono">
            <span class="flex items-center gap-2">
              <mat-icon class="text-sm text-amber-400">insights</mat-icon>
              <span>02. Probed Spectral Signature S(λ)</span>
            </span>
            <span class="text-[11px] text-cyan-400">Point [52, 47]</span>
          </h2>

          <div class="h-48 w-full bg-slate-950 rounded-lg border border-slate-800 p-2 relative flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 300 120" preserveAspectRatio="none">
              <!-- Probed curve -->
              <path 
                [attr.d]="probedCurveSvgPath()" 
                fill="none" 
                stroke="#f59e0b" 
                stroke-width="2.5" />
              
              <!-- Reference library curve comparison -->
              <path 
                [attr.d]="referenceCurveSvgPath()" 
                fill="none" 
                stroke="#06b6d4" 
                stroke-dasharray="3 2"
                stroke-width="1.8" />
            </svg>
          </div>

          <div class="flex items-center justify-between font-mono text-[10px] text-slate-400">
            <span class="flex items-center gap-1 text-amber-400">
              <span class="w-2 h-2 rounded-full bg-amber-400"></span>
              <span>Observed Spectrum</span>
            </span>
            <span class="flex items-center gap-1 text-cyan-400">
              <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
              <span>Reference Library Match</span>
            </span>
          </div>

          <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 font-mono text-[11px] space-y-1">
            <div class="text-slate-400">Spectral Angle: <span class="text-white font-bold">0.042 rad (2.4°)</span></div>
            <div class="text-slate-400">Spectral Correlation: <span class="text-emerald-400 font-bold">r = 0.988</span></div>
            <div class="text-slate-400">Confidence: <span class="text-emerald-400 font-bold">98.8% Match</span></div>
          </div>
        </div>

        <!-- Column 3: Material Identification Matrix -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 class="text-sm font-semibold text-white flex items-center justify-between border-b border-slate-800 pb-2 font-mono">
            <span class="flex items-center gap-2">
              <mat-icon class="text-sm text-emerald-400">science</mat-icon>
              <span>03. Material Classification</span>
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-950 border border-emerald-800 px-1.5 py-0.5 rounded">
              SAM CLASSIFIER
            </span>
          </h2>

          <div class="space-y-2 text-xs font-mono">
            @for (mat of library(); track mat.id) {
              <button 
                type="button"
                (click)="selectedMaterial.set(mat)"
                class="w-full text-left p-2.5 rounded-lg border cursor-pointer transition-colors"
                [class.bg-slate-800]="selectedMaterial()?.id === mat.id"
                [class.border-amber-500/60]="selectedMaterial()?.id === mat.id"
                [class.bg-slate-950]="selectedMaterial()?.id !== mat.id"
                [class.border-slate-800]="selectedMaterial()?.id !== mat.id">
                <div class="flex items-center justify-between font-bold text-white text-[11px]">
                  <span>{{ mat.materialName }}</span>
                  <span class="text-amber-400 font-normal">{{ mat.category }}</span>
                </div>
                <div class="grid grid-cols-2 gap-x-2 text-[10px] text-slate-400 mt-1">
                  <div>Nominal ε: <span class="text-slate-200">{{ mat.emissivityNominal }}</span></div>
                  <div>Conductivity: <span class="text-slate-200">{{ mat.thermalConductivityW_mK }} W/mK</span></div>
                  <div>Standard: <span class="text-slate-200 truncate">{{ mat.referenceStandard }}</span></div>
                  <div>Uncertainty: <span class="text-cyan-300">±{{ mat.uncertaintyPercent }}%</span></div>
                </div>
              </button>
            }
          </div>
        </div>

      </div>

    </div>
  `
})
export class HyperspectralComponent {
  private readonly dataService = inject(AardvarkDataService);

  public readonly library = this.dataService.materialLibrary;
  public readonly selectedMaterial = signal<MaterialSpectralReference | null>(null);

  public readonly wavelengths = [8.0, 8.5, 9.0, 9.5, 10.0, 10.5, 11.0, 11.5, 12.0, 12.5, 13.0, 13.5, 14.0];
  public readonly activeWavelengthUm = signal<number>(10.0);
  public readonly activePcaComponent = signal<number>(1);

  constructor() {
    const mats = this.library();
    if (mats && mats.length > 0) {
      this.selectedMaterial.set(mats[1]);
    }
  }

  public probedCurveSvgPath(): string {
    const vals = [0.85, 0.86, 0.87, 0.88, 0.89, 0.89, 0.90, 0.90, 0.91, 0.91, 0.92, 0.92, 0.93];
    return this.pointsToSvg(vals);
  }

  public referenceCurveSvgPath(): string {
    const mat = this.selectedMaterial();
    const vals = mat ? mat.spectralEmissivity : [0.86, 0.87, 0.87, 0.88, 0.88, 0.89, 0.89, 0.90, 0.90, 0.91, 0.91, 0.92, 0.92];
    return this.pointsToSvg(vals);
  }

  private pointsToSvg(values: number[]): string {
    const stepX = 280 / (values.length - 1);
    return values.reduce((acc, val, i) => {
      const x = 10 + i * stepX;
      const y = 110 - ((val - 0.7) / 0.3) * 95;
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }
}
