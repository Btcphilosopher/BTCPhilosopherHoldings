import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';

@Component({
  selector: 'app-fusion-registration',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">layers</mat-icon>
            <span>Multi-Modal Optical Fusion & Registration</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Sub-Pixel Thermal / RGB / LiDAR Homography Engine
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Rust-accelerated projective homography and feature alignment. Fuses uncooled/cryo radiometric infrared with ultra-high resolution visible imagery and spatial point-cloud geometry.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-emerald-400 font-bold">
            RMSE Residual: 0.24 px (Sub-pixel)
          </div>
        </div>
      </div>

      <!-- Main Layout: Dual View + Fusion Interactive Blend Viewport -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Left: Fusion Interactive Stage -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-white font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-amber-400">tune</mat-icon>
              <span>Fused Radiometric Viewport</span>
            </span>
            <span class="font-mono text-[11px] text-cyan-400">Blend: {{ (fusionAlpha() * 100).toFixed(0) }}% Thermal</span>
          </div>

          <!-- Fusion Canvas / Viewport Simulation -->
          <div class="aspect-[4/3] bg-black rounded-lg border border-slate-800 relative overflow-hidden flex items-center justify-center">
            <!-- Background Visual Image -->
            <img 
              [src]="activeVisualImage()" 
              alt="Visual Reference Asset" 
              referrerpolicy="no-referrer"
              class="absolute inset-0 w-full h-full object-cover" />
            
            <!-- Overlay Thermal False-Color Layer with Dynamic Opacity & Edge Blend -->
            <div 
              class="absolute inset-0 bg-gradient-to-tr from-amber-500/80 via-rose-600/70 to-indigo-950/60 mix-blend-screen transition-opacity"
              [style.opacity]="fusionAlpha()">
            </div>

            <!-- Alignment Crosshair Reticle -->
            <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div class="w-16 h-16 border border-amber-400/50 rounded-full flex items-center justify-center">
                <div class="w-2 h-2 bg-amber-400 rounded-full"></div>
              </div>
            </div>

            <div class="absolute bottom-3 left-3 bg-slate-950/80 backdrop-blur px-2 py-1 rounded font-mono text-[10px] text-amber-300 border border-slate-800">
              AFFINE HOMOGRAPHY WARP: ACTIVE
            </div>
          </div>

          <!-- Slider for Thermal / Visible Blend -->
          <div class="space-y-1.5 font-mono text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="flex justify-between text-[11px]">
              <span class="text-slate-400">100% High-Res Visible</span>
              <span class="text-amber-400 font-bold">Thermal Overlay Slider</span>
              <span class="text-slate-400">100% Radiometric LWIR</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="1.0" 
              step="0.01" 
              [value]="fusionAlpha()" 
              (input)="fusionAlpha.set(+($any($event.target).value))"
              aria-label="Thermal Overlay Slider"
              class="w-full accent-amber-500 h-1.5 bg-slate-800 rounded cursor-pointer" />
          </div>
        </div>

        <!-- Right: Registration Matrix & Algorithmic Parameters -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="font-bold text-white uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-emerald-400">matrix</mat-icon>
              <span>Projective Homography Matrix H (3×3)</span>
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded">
              CONVERGED
            </span>
          </div>

          <!-- 3x3 Matrix Grid -->
          <div class="grid grid-cols-3 gap-2 text-center text-[11px]">
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-white font-bold">+1.0428</div>
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-300">-0.0084</div>
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-amber-400">+14.220</div>

            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-300">+0.0061</div>
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-white font-bold">+1.0392</div>
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-amber-400">-8.6400</div>

            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-500">0.0000</div>
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-500">0.0000</div>
            <div class="bg-slate-950 p-2.5 rounded border border-slate-800 text-white font-bold">1.0000</div>
          </div>

          <!-- Quantitative Registration Statistics -->
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
            <div class="text-slate-400 text-[10px] uppercase tracking-wider">Registration Quality Metrics:</div>
            <div class="grid grid-cols-2 gap-2 text-[11px]">
              <div>Target Reg Error (TRE): <span class="text-emerald-400 font-bold">0.18 px</span></div>
              <div>Root Mean Square (RMSE): <span class="text-emerald-400 font-bold">0.24 px</span></div>
              <div>Mutual Information (MI): <span class="text-white font-bold">1.84 nats</span></div>
              <div>Matched Keypoints: <span class="text-white font-bold">384 pairs</span></div>
              <div>Parallax Compensation: <span class="text-emerald-400 font-bold">EPILINEAR</span></div>
              <div>Engine: <span class="text-amber-400 font-bold">Rust SIMD Rayon</span></div>
            </div>
          </div>

          <!-- Feature Matching Method -->
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1 text-slate-300 text-[11px]">
            <div class="text-amber-400 font-bold">Algorithm: Multi-Scale Dense SIFT + RANSAC</div>
            <p class="text-slate-400 text-[10px] leading-relaxed">
              Thermal edge orientation histograms are matched against visible gradient vectors, rejecting thermal gradient inversions caused by material emissivity transitions.
            </p>
          </div>
        </div>

      </div>

    </div>
  `
})
export class FusionRegistrationComponent {
  private readonly dataService = inject(AardvarkDataService);
  public readonly dataset = this.dataService.currentDataset;
  public readonly fusionAlpha = signal<number>(0.65);

  public activeVisualImage(): string {
    const d = this.dataset();
    if (d?.facility === 'Manchester Industrial Facility') {
      return '/assets/images/manchester_industrial_mill_1790928986004.jpg';
    }
    return '/assets/images/north_sea_energy_facility_1790928970079.jpg';
  }
}
