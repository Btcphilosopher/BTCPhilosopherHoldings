import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';

@Component({
  selector: 'app-digital-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">precision_manufacturing</mat-icon>
            <span>Aardvark Thermal Digital Twin · Spatial Residual Engine</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            {{ activeTwin().name }}
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Coupling finite-element Navier-Stokes thermodynamics with high-speed radiometric infrared observations. Identifies physical degradation through spatial residual heat maps (ΔT = Observed − Predicted).
          </p>
        </div>

        <!-- Facility Switcher -->
        <div class="flex items-center gap-2 font-mono text-xs">
          <button 
            (click)="selectFacility('North Sea Energy Facility')"
            class="px-3 py-1.5 rounded-lg border transition-colors cursor-pointer"
            [class.bg-slate-800]="activeFacility() === 'North Sea Energy Facility'"
            [class.border-amber-500]="activeFacility() === 'North Sea Energy Facility'"
            [class.text-amber-400]="activeFacility() === 'North Sea Energy Facility'"
            [class.bg-slate-900]="activeFacility() !== 'North Sea Energy Facility'"
            [class.border-slate-700]="activeFacility() !== 'North Sea Energy Facility'">
            North Sea Offshore Facility
          </button>
          <button 
            (click)="selectFacility('Manchester Industrial Facility')"
            class="px-3 py-1.5 rounded-lg border transition-colors cursor-pointer"
            [class.bg-slate-800]="activeFacility() === 'Manchester Industrial Facility'"
            [class.border-amber-500]="activeFacility() === 'Manchester Industrial Facility'"
            [class.text-amber-400]="activeFacility() === 'Manchester Industrial Facility'"
            [class.bg-slate-900]="activeFacility() !== 'Manchester Industrial Facility'"
            [class.border-slate-700]="activeFacility() !== 'Manchester Industrial Facility'">
            Manchester Industrial Facility
          </button>
        </div>
      </div>

      <!-- 3-Way Digital Twin Comparison: Predicted Physics vs Observed Radiometry vs Spatial Residual -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Panel 1: Physical Model Predicted Thermal Field -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-300 font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-cyan-400">memory</mat-icon>
              <span>01. Predicted Thermal Field</span>
            </span>
            <span class="text-[10px] font-mono text-cyan-400">OpenFOAM CHT Physics</span>
          </div>

          <div class="aspect-square bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-tr from-blue-950 via-slate-900 to-amber-950/30"></div>
            <!-- Turbine mesh lines -->
            <div class="absolute inset-8 rounded-full border border-cyan-500/20"></div>
            <div class="absolute inset-16 rounded-full border border-cyan-500/30"></div>
            <div class="relative z-10 text-center font-mono space-y-1">
              <div class="text-cyan-400 text-xs font-bold">NOMINAL BASELINE FIELD</div>
              <div class="text-slate-300 text-[11px]">Under {{ activeTwin().operatingConditions.loadPercent }}% Nominal Load</div>
              <div class="text-slate-400 text-[10px]">Predicted Peak: 92.4 °C</div>
            </div>
          </div>

          <div class="space-y-1 font-mono text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span>Operating Load:</span>
              <span class="text-white font-bold">{{ activeTwin().operatingConditions.loadPercent }}%</span>
            </div>
            <div class="flex justify-between">
              <span>Ambient Temp:</span>
              <span class="text-white">{{ activeTwin().operatingConditions.ambientTempC }} °C</span>
            </div>
            <div class="flex justify-between">
              <span>Coolant Flow:</span>
              <span class="text-white">{{ activeTwin().operatingConditions.coolantFlowRateL_min }} L/min</span>
            </div>
          </div>
        </div>

        <!-- Panel 2: Observed Radiometric Infrared Field -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-300 font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-emerald-400">videocam</mat-icon>
              <span>02. Observed Infrared Field</span>
            </span>
            <span class="text-[10px] font-mono text-emerald-400">LWIR 8-14µm Ingested</span>
          </div>

          <div class="aspect-square bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-tr from-slate-950 via-indigo-950 to-amber-950/60"></div>
            <!-- Hotspot highlight -->
            <div class="absolute w-12 h-12 rounded-full bg-rose-500/40 blur-md top-1/3 left-1/3 animate-pulse"></div>
            <div class="relative z-10 text-center font-mono space-y-1">
              <div class="text-emerald-400 text-xs font-bold">REAL-TIME THERMOGRAM</div>
              <div class="text-amber-300 text-[11px]">Observed Peak: 148.6 °C</div>
              <div class="text-rose-400 text-[10px] font-bold">ANOMALY LOCALIZED</div>
            </div>
          </div>

          <div class="space-y-1 font-mono text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span>Sensor Pitch:</span>
              <span class="text-white">12.0 µm VOx</span>
            </div>
            <div class="flex justify-between">
              <span>Integration:</span>
              <span class="text-white">1450 µs (60 FPS)</span>
            </div>
            <div class="flex justify-between">
              <span>Uncertainty U95:</span>
              <span class="text-cyan-300">±0.42 °C</span>
            </div>
          </div>
        </div>

        <!-- Panel 3: Spatial Residual Field (ΔT = Observed - Predicted) -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-300 font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-rose-400">warning</mat-icon>
              <span>03. Spatial Residual (ΔT)</span>
            </span>
            <span class="text-[10px] font-mono text-rose-400 font-bold">Peak ΔT: +{{ activeTwin().maxResidualC }} °C</span>
          </div>

          <div class="aspect-square bg-slate-950 rounded-lg border border-rose-900/40 flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-rose-950/50"></div>
            <!-- Residual hotspot alert ring -->
            <div class="absolute w-16 h-16 rounded-full border-2 border-rose-500 top-1/3 left-1/3 animate-ping opacity-60"></div>
            <div class="relative z-10 text-center font-mono space-y-1">
              <div class="text-rose-400 text-xs font-bold">RESIDUAL MATRIX ΔT(x, y)</div>
              <div class="text-white text-[11px]">Deviation: +56.2 °C</div>
              <div class="text-amber-300 text-[10px]">Bearing Thrust Collar #1</div>
            </div>
          </div>

          <div class="space-y-1 font-mono text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span>Max Residual:</span>
              <span class="text-rose-400 font-bold">+{{ activeTwin().maxResidualC }} °C</span>
            </div>
            <div class="flex justify-between">
              <span>Mean Background ΔT:</span>
              <span class="text-emerald-400 font-bold">{{ activeTwin().meanResidualC }} °C</span>
            </div>
            <div class="flex justify-between">
              <span>Physical State:</span>
              <span class="text-rose-400 font-bold">BOUNDARY LUBRICATION COLLAPSE</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Digital Twin Operating Conditions Tuner & Physics Diagnostics -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h2 class="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
          <mat-icon class="text-sm text-amber-400">tune</mat-icon>
          <span>Digital Twin Operating Parameter Sensitivity</span>
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Load Slider -->
          <div class="space-y-1 bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span class="text-slate-400">Turbine Electrical Load:</span>
              <span class="text-amber-400 font-bold">{{ currentLoad() }}%</span>
            </div>
            <input 
              type="range" 
              min="20" 
              max="110" 
              [value]="currentLoad()" 
              (input)="currentLoad.set(+($any($event.target).value))"
              aria-label="Turbine Electrical Load Slider"
              class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
          </div>

          <!-- Ambient Air Temp -->
          <div class="space-y-1 bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span class="text-slate-400">Ambient Temperature:</span>
              <span class="text-cyan-400 font-bold">{{ ambientTemp() }} °C</span>
            </div>
            <input 
              type="range" 
              min="-10" 
              max="40" 
              [value]="ambientTemp()" 
              (input)="ambientTemp.set(+($any($event.target).value))"
              aria-label="Ambient Temperature Slider"
              class="w-full accent-cyan-500 h-1 bg-slate-800 rounded cursor-pointer" />
          </div>

          <!-- Coolant Flow Rate -->
          <div class="space-y-1 bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span class="text-slate-400">Coolant Flow Rate:</span>
              <span class="text-emerald-400 font-bold">{{ coolantFlow() }} L/min</span>
            </div>
            <input 
              type="range" 
              min="200" 
              max="800" 
              [value]="coolantFlow()" 
              (input)="coolantFlow.set(+($any($event.target).value))"
              aria-label="Coolant Flow Rate Slider"
              class="w-full accent-emerald-500 h-1 bg-slate-800 rounded cursor-pointer" />
          </div>
        </div>

        <!-- Actionable Root-Cause Diagnostic Card -->
        <div class="p-4 bg-slate-950 rounded-lg border border-rose-900/60 flex flex-col md:flex-row items-start justify-between gap-4">
          <div class="space-y-1">
            <div class="text-rose-400 font-bold flex items-center gap-1.5 text-xs">
              <mat-icon class="text-sm">error</mat-icon>
              <span>PHYSICAL ROOT CAUSE DIAGNOSIS:</span>
            </div>
            <p class="text-slate-300 text-[11px] max-w-3xl leading-relaxed">
              Spatial temperature profile reveals severe localized shear heating (+56.2 °C delta against baseline CHT model). The thermal dissipation is consistent with hydrodynamic bearing oil-film breakdown under axial thrust load. Vibration signature corroborates high-frequency metal-on-metal micro-asperity friction.
            </p>
          </div>

          <button 
            (click)="dataService.activeTab.set('inspection-report')"
            class="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs whitespace-nowrap cursor-pointer transition-colors shrink-0">
            Generate Corrective Work Order
          </button>
        </div>
      </div>

    </div>
  `
})
export class DigitalTwinComponent {
  public readonly dataService = inject(AardvarkDataService);
  public readonly activeFacility = signal<'North Sea Energy Facility' | 'Manchester Industrial Facility'>('North Sea Energy Facility');

  public readonly currentLoad = signal<number>(84);
  public readonly ambientTemp = signal<number>(8.5);
  public readonly coolantFlow = signal<number>(450);

  public readonly activeTwin = computed(() => {
    const list = this.dataService.digitalTwins();
    return list.find(t => t.facilityName === this.activeFacility()) || list[0];
  });

  public selectFacility(name: 'North Sea Energy Facility' | 'Manchester Industrial Facility'): void {
    this.activeFacility.set(name);
  }
}
