import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';

@Component({
  selector: 'app-inspection-report',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1200px] mx-auto px-4 py-8 space-y-6 text-slate-900 bg-white min-h-screen font-sans">
      
      <!-- Top Action Bar (Print / Export) -->
      <div class="flex items-center justify-between pb-4 border-b border-slate-200 print:hidden">
        <div class="flex items-center gap-2 text-xs font-mono text-slate-600">
          <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span>OFFICIAL METROLOGY INSPECTION RECORD</span>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="printReport()"
            class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 cursor-pointer shadow">
            <mat-icon class="text-sm">print</mat-icon>
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      <!-- Formal Engineering Header -->
      <div class="flex flex-col md:flex-row justify-between items-start gap-4 pb-6 border-b-2 border-slate-900">
        <div>
          <div class="text-xs font-bold font-mono tracking-widest text-slate-500 uppercase">
            AARDVARK IMAGING · INDUSTRIAL METROLOGY DIVISION
          </div>
          <h1 class="text-2xl font-bold text-slate-950 font-['Space_Grotesk'] mt-1">
            Thermal Radiometric Metrology & Digital Twin Audit
          </h1>
          <div class="text-xs text-slate-600 font-mono mt-1">
            Report Ref: <span class="font-bold text-slate-900">AARD-IR-2026-{{ dataset().id.slice(-6) }}</span> · ISO 18434-1 Level 3 Audit
          </div>
        </div>

        <!-- Facility Badge -->
        <div class="text-right font-mono text-xs">
          <div class="text-slate-500 text-[10px]">INSPECTION FACILITY:</div>
          <div class="text-base font-bold text-slate-900">{{ dataset().facility }}</div>
          <div class="text-slate-600 text-[11px]">{{ dataset().acquisitionTimestamp }}</div>
        </div>
      </div>

      <!-- Section 1: Acquisition & Environmental Conditions -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
        <div class="bg-slate-50 p-3 rounded border border-slate-200">
          <span class="text-slate-500 block text-[10px]">Sensor FPA:</span>
          <span class="font-bold text-slate-900">{{ dataset().detectorType }} ({{ dataset().bandType }})</span>
        </div>
        <div class="bg-slate-50 p-3 rounded border border-slate-200">
          <span class="text-slate-500 block text-[10px]">Optics & Pitch:</span>
          <span class="font-bold text-slate-900">{{ dataset().lensConfiguration }} ({{ dataset().pixelPitchUm }}µm)</span>
        </div>
        <div class="bg-slate-50 p-3 rounded border border-slate-200">
          <span class="text-slate-500 block text-[10px]">Atmospheric τ / Dist:</span>
          <span class="font-bold text-slate-900">τ = {{ dataset().atmospheric.transmissionTau }} ({{ dataset().atmospheric.distanceMeters }}m)</span>
        </div>
        <div class="bg-slate-50 p-3 rounded border border-slate-200">
          <span class="text-slate-500 block text-[10px]">GUM Uncertainty (U₉₅):</span>
          <span class="font-bold text-emerald-700">±{{ dataset().uncertainty.expandedUncertaintyU95C }} °C (k=2)</span>
        </div>
      </div>

      <!-- Section 2: Radiometric Inspection & Digital Twin Residual -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
        
        <!-- Left: Calibrated Thermogram -->
        <div class="space-y-2">
          <div class="flex items-center justify-between text-xs font-mono font-bold text-slate-800">
            <span>Fig 1. Calibrated Thermal Field (Ironbow)</span>
            <span class="text-slate-500 font-normal">Peak: 148.6 °C</span>
          </div>

          <div class="aspect-[4/3] bg-slate-950 rounded-lg border border-slate-300 relative overflow-hidden flex items-center justify-center">
            <div class="absolute inset-0 bg-gradient-to-tr from-slate-950 via-indigo-950 to-amber-950/70"></div>
            <div class="relative z-10 text-center font-mono text-white space-y-1">
              <div class="text-amber-400 font-bold text-sm">RADIOMETRIC THERMOGRAM</div>
              <div class="text-xs text-slate-300">HP Turbine Thrust Bearing Hotspot</div>
              <div class="text-rose-400 text-xs font-bold">148.6 °C (ΔT = +56.2 °C)</div>
            </div>
          </div>
        </div>

        <!-- Right: Digital Twin Spatial Residual -->
        <div class="space-y-2">
          <div class="flex items-center justify-between text-xs font-mono font-bold text-slate-800">
            <span>Fig 2. Digital Twin Residual Map ΔT(x, y)</span>
            <span class="text-rose-700 font-bold">Max Residual: +56.2 °C</span>
          </div>

          <div class="aspect-[4/3] bg-slate-950 rounded-lg border border-slate-300 relative overflow-hidden flex items-center justify-center">
            <div class="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-rose-950/60"></div>
            <div class="relative z-10 text-center font-mono text-white space-y-1">
              <div class="text-rose-400 font-bold text-sm">SPATIAL RESIDUAL FIELD</div>
              <div class="text-xs text-slate-300">Observed − Predicted CHT Model</div>
              <div class="text-amber-300 text-xs">Exceeds ISO 18434-1 Threshold</div>
            </div>
          </div>
        </div>

      </div>

      <!-- Section 3: Quantitative ROI Metrology Summary -->
      <div class="space-y-2 pt-2">
        <h2 class="text-xs font-bold font-mono text-slate-900 uppercase">Table 1: Quantitative Region-of-Interest (ROI) Metrology</h2>
        <div class="overflow-x-auto border border-slate-200 rounded-lg">
          <table class="w-full text-left font-mono text-xs">
            <thead class="bg-slate-100 text-slate-600 text-[10px] uppercase border-b border-slate-200">
              <tr>
                <th class="p-2.5">ROI Identifier / Location</th>
                <th class="p-2.5">Emissivity ε</th>
                <th class="p-2.5">Max Temp (°C)</th>
                <th class="p-2.5">Mean Temp (°C)</th>
                <th class="p-2.5">Std Dev σ</th>
                <th class="p-2.5">ΔT Ambient</th>
                <th class="p-2.5">GUM U₉₅ (k=2)</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
              @for (roi of dataset().rois; track roi.id) {
                <tr>
                  <td class="p-2.5 font-bold text-slate-900">{{ roi.label }}</td>
                  <td class="p-2.5">{{ roi.emissivity }}</td>
                  <td class="p-2.5 font-bold text-rose-700">{{ roi.maxTempC }} °C</td>
                  <td class="p-2.5">{{ roi.meanTempC }} °C</td>
                  <td class="p-2.5">±{{ roi.stdDevTempC }} °C</td>
                  <td class="p-2.5 font-bold text-amber-700">+{{ roi.deltaAmbientC }} °C</td>
                  <td class="p-2.5 text-emerald-800 font-bold">±{{ roi.uncertaintyU95C }} °C</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Section 4: Engineering Diagnosis & Corrective Actions -->
      <div class="p-4 bg-rose-50 rounded-lg border border-rose-200 space-y-2 text-xs">
        <div class="font-bold text-rose-900 flex items-center gap-1.5 font-mono">
          <mat-icon class="text-sm">error</mat-icon>
          <span>CRITICAL FAULT IDENTIFIED — ISO 18434-1 CATEGORY IV (IMMEDIATE ACTION)</span>
        </div>
        <p class="text-slate-800 leading-relaxed">
          High-pressure turbine thrust bearing #1 exhibits severe boundary lubrication collapse (observed 148.6 °C vs modeled 92.4 °C baseline). Spatial thermal gradient dT/dx exceeds 12.4 °C/cm. Recommend immediate load reduction to prevent catastrophic journal wiping and Babbitt metal liquefaction.
        </p>
      </div>

      <!-- Formal Metrology Signature & Provenance Seal -->
      <div class="pt-6 border-t-2 border-slate-900 flex flex-col md:flex-row justify-between items-start md:items-end gap-4 font-mono text-xs">
        <div class="space-y-1 text-slate-600">
          <div>Calibration Standard: <span class="text-slate-900 font-bold">{{ dataset().calibration.standardReference }}</span></div>
          <div>Calibration Certificate: <span class="text-slate-900 font-bold">{{ dataset().calibration.calibrationId }} (v{{ dataset().calibration.version }})</span></div>
          <div class="text-[10px] text-slate-400">Provenance Hash: sha256:7f8a91b2c3d4e5f67a8b9c0d1e2f3a4b...</div>
        </div>

        <div class="text-right space-y-1">
          <div class="text-[10px] text-slate-400">CERTIFIED METROLOGY ENGINEER:</div>
          <div class="font-bold text-slate-950 font-serif italic text-base">Dr. Alistair Vance, CEng FInstP</div>
          <div class="text-[10px] text-slate-500">Chief Radiometrician · Aardvark Metrology Laboratory</div>
        </div>
      </div>

    </div>
  `
})
export class InspectionReportComponent {
  private readonly dataService = inject(AardvarkDataService);
  public readonly dataset = this.dataService.currentDataset;

  public printReport(): void {
    window.print();
  }
}
