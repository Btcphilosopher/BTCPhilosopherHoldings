import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';
import { ThermalAnomaly } from '../../models/infrared.models';

@Component({
  selector: 'app-anomaly-engine',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">warning</mat-icon>
            <span>Industrial Anomaly Detection & Diagnostic Engine</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Explainable Physical Defect Classification (ISO 18434-1 / IEEE 738)
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Hierarchy: Raw Radiometric Measurement → Statistical Outlier Detection (Z-Score) → Thermodynamic Physics Rule → Explainable Root Cause.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <div class="bg-rose-950/80 border border-rose-800 text-rose-300 px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-bold">
            <span class="w-2 h-2 rounded-full bg-rose-400 animate-ping"></span>
            <span>2 ACTIVE CRITICAL ANOMALIES</span>
          </div>
        </div>
      </div>

      <!-- Anomaly Cards Grid -->
      <div class="space-y-4">
        @for (anom of currentAnomalies(); track anom.id) {
          <div 
            class="bg-slate-900/90 border rounded-xl p-5 space-y-4 shadow-lg transition-all"
            [class.border-rose-700]="anom.severity === 'CRITICAL_OVERHEAT'"
            [class.border-amber-700]="anom.severity === 'SEVERE_FAULT'"
            [class.border-slate-800]="anom.severity !== 'CRITICAL_OVERHEAT' && anom.severity !== 'SEVERE_FAULT'">
            
            <!-- Top Banner -->
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
              <div class="flex items-center gap-3">
                <span 
                  class="px-2.5 py-1 rounded font-mono text-xs font-bold uppercase tracking-wider"
                  [class.bg-rose-600]="anom.severity === 'CRITICAL_OVERHEAT'"
                  [class.text-white]="anom.severity === 'CRITICAL_OVERHEAT'"
                  [class.bg-amber-600]="anom.severity === 'SEVERE_FAULT'"
                  [class.text-slate-950]="anom.severity === 'SEVERE_FAULT'">
                  {{ anom.severity }}
                </span>
                <div>
                  <h2 class="text-base font-bold text-white">{{ anom.component }}</h2>
                  <div class="text-xs font-mono text-slate-400">{{ anom.assetLocation }}</div>
                </div>
              </div>

              <div class="flex items-center gap-3 font-mono text-xs">
                <div class="text-right">
                  <div class="text-slate-400 text-[10px]">DELTA-T THRESHOLD:</div>
                  <div class="text-rose-400 font-bold text-sm tabular-nums">+{{ anom.deltaTempC }} °C (Limit: {{ anom.thresholdC }} °C)</div>
                </div>
                <div class="text-right pl-3 border-l border-slate-800">
                  <div class="text-slate-400 text-[10px]">CONFIDENCE:</div>
                  <div class="text-emerald-400 font-bold text-sm">{{ (anom.confidenceScore * 100).toFixed(1) }}%</div>
                </div>
              </div>
            </div>

            <!-- Middle: Physical Cause & ISO Compliance -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div class="space-y-1">
                <div class="text-slate-400 font-mono uppercase text-[10px] tracking-wider">Physical Failure Mechanism:</div>
                <p class="text-slate-200 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800">
                  {{ anom.physicalCause }}
                </p>
              </div>

              <div class="space-y-1">
                <div class="text-slate-400 font-mono uppercase text-[10px] tracking-wider">Corrective Engineering Recommendation:</div>
                <p class="text-amber-200/90 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800">
                  {{ anom.recommendation }}
                </p>
              </div>
            </div>

            <!-- Bottom: Empirical Evidence Provenance Chain -->
            <div class="pt-2 border-t border-slate-800/80 space-y-2">
              <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <mat-icon class="text-xs text-amber-400">verified</mat-icon>
                <span>Empirical Evidence Chain (Anti-Hallucination Classification):</span>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-3 gap-2 font-mono text-[11px]">
                @for (ev of anom.evidence; track $index) {
                  <div class="p-2 bg-slate-950 rounded border border-slate-800/80 space-y-1">
                    <span 
                      class="text-[9px] font-bold px-1.5 py-0.5 rounded uppercase"
                      [class.bg-emerald-950]="ev.type === 'MEASURED'"
                      [class.text-emerald-400]="ev.type === 'MEASURED'"
                      [class.bg-cyan-950]="ev.type === 'MODELLED'"
                      [class.text-cyan-400]="ev.type === 'MODELLED'"
                      [class.bg-amber-950]="ev.type === 'CALCULATED'"
                      [class.text-amber-400]="ev.type === 'CALCULATED'">
                      {{ ev.type }}
                    </span>
                    <p class="text-slate-300 text-[10px] leading-tight">{{ ev.description }}</p>
                  </div>
                }
              </div>
            </div>

          </div>
        }
      </div>

    </div>
  `
})
export class AnomalyEngineComponent {
  private readonly dataService = inject(AardvarkDataService);
  public readonly dataset = this.dataService.currentDataset;

  public currentAnomalies(): ThermalAnomaly[] {
    const d = this.dataset();
    return d && d.anomalies ? d.anomalies : [];
  }
}
