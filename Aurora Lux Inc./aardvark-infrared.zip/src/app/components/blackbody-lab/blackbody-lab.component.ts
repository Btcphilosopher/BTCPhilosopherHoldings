import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RadiometryPhysicsService } from '../../services/radiometry-physics.service';

@Component({
  selector: 'app-blackbody-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">insights</mat-icon>
            <span>Aardvark Radiometry & Quantum Physics Lab</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Planck Radiance, Wien's Peak & Stefan-Boltzmann Simulator
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Interactive spectral radiance integration, thermodynamic emission modeling, quantum photon rate calculations, and bandpass transmission convolution.
          </p>
        </div>

        <!-- Metric Badges -->
        <div class="flex items-center gap-2 font-mono text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-amber-400">
            λ_max: <span class="text-white font-bold">{{ wienPeakUm().toFixed(2) }} µm</span>
          </div>
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-cyan-400">
            M_total: <span class="text-white font-bold">{{ (totalExitanceWm2() / 1000).toFixed(2) }} kW/m²</span>
          </div>
        </div>
      </div>

      <!-- Main Layout: Controls Left (320px) + Interactive Spectral Curve Canvas (Flex-1) -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Controls Column -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-5">
          <h2 class="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2 font-mono">
            <mat-icon class="text-sm text-amber-400">tune</mat-icon>
            <span>Thermodynamic Parameters</span>
          </h2>

          <div class="space-y-4 text-xs font-mono">
            
            <!-- Temperature Slider -->
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Emitter Temperature (T):</span>
                <span class="text-amber-400 font-bold text-sm">{{ tempC() }} °C / {{ tempK().toFixed(1) }} K</span>
              </div>
              <input 
                type="range" 
                min="-40" 
                max="1200" 
                step="5"
                [value]="tempC()" 
                (input)="tempC.set(+($any($event.target).value))"
                aria-label="Emitter Temperature Slider"
                class="w-full accent-amber-500 h-1.5 bg-slate-800 rounded cursor-pointer" />
              <div class="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>-40°C (Cryo)</span>
                <span>300°C (Steam)</span>
                <span>1200°C (Furnace)</span>
              </div>
            </div>

            <!-- Surface Emissivity Slider -->
            <div>
              <div class="flex justify-between text-[11px] mb-1">
                <span class="text-slate-400">Surface Emissivity (ε):</span>
                <span class="text-cyan-400 font-bold text-sm">{{ emissivity().toFixed(2) }}</span>
              </div>
              <input 
                type="range" 
                min="0.10" 
                max="1.00" 
                step="0.01"
                [value]="emissivity()" 
                (input)="emissivity.set(+($any($event.target).value))"
                aria-label="Surface Emissivity Slider"
                class="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded cursor-pointer" />
              <div class="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>0.10 (Polished Metal)</span>
                <span>0.95 (Blackbody / Brick)</span>
              </div>
            </div>

            <!-- Pre-defined Sensor Bandpass Selector -->
            <div>
              <div class="text-slate-400 text-[11px] mb-1.5">Sensor Bandpass Region:</div>
              <div class="grid grid-cols-3 gap-1 text-[10px]">
                <button 
                  (click)="setBandpass(1.4, 3.0, 'SWIR')"
                  class="p-2 rounded border text-center transition-colors cursor-pointer"
                  [class.bg-slate-800]="selectedBandpassName() === 'SWIR'"
                  [class.border-cyan-500]="selectedBandpassName() === 'SWIR'">
                  <div class="font-bold text-white">SWIR</div>
                  <div class="text-[9px] text-slate-400">1.4 - 3.0 µm</div>
                </button>
                <button 
                  (click)="setBandpass(3.0, 5.0, 'MWIR')"
                  class="p-2 rounded border text-center transition-colors cursor-pointer"
                  [class.bg-slate-800]="selectedBandpassName() === 'MWIR'"
                  [class.border-amber-500]="selectedBandpassName() === 'MWIR'">
                  <div class="font-bold text-white">MWIR</div>
                  <div class="text-[9px] text-slate-400">3.0 - 5.0 µm</div>
                </button>
                <button 
                  (click)="setBandpass(8.0, 14.0, 'LWIR')"
                  class="p-2 rounded border text-center transition-colors cursor-pointer"
                  [class.bg-slate-800]="selectedBandpassName() === 'LWIR'"
                  [class.border-rose-500]="selectedBandpassName() === 'LWIR'">
                  <div class="font-bold text-white">LWIR</div>
                  <div class="text-[9px] text-slate-400">8.0 - 14.0 µm</div>
                </button>
              </div>
            </div>

            <!-- Integrated Radiance readout in selected band -->
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5">
              <div class="text-slate-400 text-[10px] uppercase tracking-wider">Integrated Band Radiance ({{ selectedBandpassName() }}):</div>
              <div class="text-xl font-bold text-emerald-400 tabular-nums">
                {{ integratedBandRadiance().toFixed(3) }} <span class="text-xs text-slate-400 font-normal">W/(m²·sr)</span>
              </div>
              <div class="text-[10px] text-slate-500">
                Fraction of total blackbody power: <span class="text-slate-300 font-bold">{{ (bandFraction() * 100).toFixed(1) }}%</span>
              </div>
            </div>

          </div>
        </div>

        <!-- Spectral Radiance Curve Display (2 Cols) -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col space-y-4">
          
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-white font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-cyan-400">show_chart</mat-icon>
              <span>Planck Spectral Radiance L_λ(λ, T) [W / (m² · sr · µm)]</span>
            </span>
            <span class="font-mono text-[11px] text-amber-400">
              Peak: {{ peakRadianceVal().toFixed(2) }} W/(m²·sr·µm)
            </span>
          </div>

          <!-- SVG Planck Plot Canvas -->
          <div class="h-64 w-full bg-slate-950 rounded-lg border border-slate-800 p-3 relative flex items-center justify-center overflow-hidden">
            <svg class="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
              
              <!-- Grid lines -->
              <line x1="40" y1="40" x2="480" y2="40" stroke="#1e293b" stroke-dasharray="2 2" />
              <line x1="40" y1="90" x2="480" y2="90" stroke="#1e293b" stroke-dasharray="2 2" />
              <line x1="40" y1="140" x2="480" y2="140" stroke="#1e293b" stroke-dasharray="2 2" />
              
              <!-- Shaded Bandpass Area -->
              <rect 
                [attr.x]="bandpassStartX()" 
                y="20" 
                [attr.width]="bandpassWidthX()" 
                height="160" 
                fill="#f59e0b" 
                fill-opacity="0.12" 
                stroke="#f59e0b" 
                stroke-dasharray="2 2" 
                stroke-width="1" />

              <!-- Planck Curve Path -->
              <path 
                [attr.d]="planckCurveSvgPath()" 
                fill="none" 
                stroke="#06b6d4" 
                stroke-width="2.5" 
                stroke-linecap="round" />

              <!-- Wien's Peak Dot Marker -->
              <circle 
                [attr.cx]="wienPeakX()" 
                [attr.cy]="wienPeakY()" 
                r="5" 
                fill="#f59e0b" 
                stroke="#fff" 
                stroke-width="1.5" />
            </svg>
          </div>

          <!-- Bottom Axis Legend & Mathematical Equations -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
            <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
              <div class="text-amber-400 font-bold text-[11px]">Wien's Displacement Law:</div>
              <div class="text-slate-300 text-[10px]">λ_max = b / T = 2897.77 / {{ tempK().toFixed(1) }} K = <span class="text-white font-bold">{{ wienPeakUm().toFixed(2) }} µm</span></div>
            </div>
            <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
              <div class="text-cyan-400 font-bold text-[11px]">Stefan-Boltzmann Law:</div>
              <div class="text-slate-300 text-[10px]">M = ε·σ·T⁴ = {{ emissivity().toFixed(2) }} × 5.67e-8 × ({{ tempK().toFixed(0) }}⁴) = <span class="text-white font-bold">{{ (totalExitanceWm2() / 1000).toFixed(2) }} kW/m²</span></div>
            </div>
          </div>

        </div>

      </div>

    </div>
  `
})
export class BlackbodyLabComponent {
  private readonly physics = inject(RadiometryPhysicsService);

  public readonly tempC = signal<number>(115);
  public readonly emissivity = signal<number>(0.94);
  public readonly lambdaMin = signal<number>(8.0);
  public readonly lambdaMax = signal<number>(14.0);
  public readonly selectedBandpassName = signal<string>('LWIR');

  public readonly tempK = computed(() => this.tempC() + 273.15);

  public readonly wienPeakUm = computed(() => {
    return this.physics.wienPeakWavelengthUm(this.tempK());
  });

  public readonly totalExitanceWm2 = computed(() => {
    return this.physics.stefanBoltzmannExitance(this.tempK(), this.emissivity());
  });

  public readonly integratedBandRadiance = computed(() => {
    return this.physics.integrateBandpassRadiance(
      this.lambdaMin(),
      this.lambdaMax(),
      this.tempK(),
      this.emissivity()
    );
  });

  public readonly bandFraction = computed(() => {
    const totalPi = (this.totalExitanceWm2() / Math.PI);
    return Math.min(1.0, this.integratedBandRadiance() / Math.max(0.01, totalPi));
  });

  public readonly peakRadianceVal = computed(() => {
    const peakUm = this.wienPeakUm();
    return this.physics.planckSpectralRadiance(peakUm, this.tempK()) * this.emissivity();
  });

  public setBandpass(min: number, max: number, name: string): void {
    this.lambdaMin.set(min);
    this.lambdaMax.set(max);
    this.selectedBandpassName.set(name);
  }

  public planckCurveSvgPath(): string {
    const tk = this.tempK();
    const eps = this.emissivity();
    const maxRad = Math.max(0.1, this.peakRadianceVal() * 1.15);

    const points: string[] = [];
    const minLambda = 0.5;
    const maxLambda = 20.0;
    const steps = 80;

    for (let i = 0; i <= steps; i++) {
      const lambda = minLambda + (i / steps) * (maxLambda - minLambda);
      const rad = this.physics.planckSpectralRadiance(lambda, tk) * eps;
      const x = 40 + (i / steps) * 440;
      const y = 180 - (rad / maxRad) * 150;
      points.push(`${i === 0 ? 'M' : 'L'} ${x} ${Math.max(20, Math.min(185, y))}`);
    }
    return points.join(' ');
  }

  public bandpassStartX(): number {
    const minLambda = 0.5;
    const maxLambda = 20.0;
    return 40 + ((this.lambdaMin() - minLambda) / (maxLambda - minLambda)) * 440;
  }

  public bandpassWidthX(): number {
    const maxLambda = 20.0 - 0.5;
    return ((this.lambdaMax() - this.lambdaMin()) / maxLambda) * 440;
  }

  public wienPeakX(): number {
    const peak = this.wienPeakUm();
    const minLambda = 0.5;
    const maxLambda = 20.0;
    return Math.max(40, Math.min(480, 40 + ((peak - minLambda) / (maxLambda - minLambda)) * 440));
  }

  public wienPeakY(): number {
    return 30;
  }
}
