import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';
import { SpectralBand, DetectorType } from '../../models/infrared.models';

@Component({
  selector: 'app-sensor-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header Section -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">videocam</mat-icon>
            <span>Aardvark Sensor Lab · Physical Simulator</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Computational Infrared Sensor Synthesizer
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Configure physically grounded focal plane arrays (FPA), cryocooler optics, noise models, and quantum efficiency. Generates deterministic synthetic radiometric datasets tagged with immutable SIMULATION_METADATA.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="generateSyntheticScene()"
            class="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-2 shadow-lg shadow-amber-500/10 transition-all cursor-pointer">
            <mat-icon class="text-sm">play_arrow</mat-icon>
            <span>Synthesize & Load Dataset</span>
          </button>
        </div>
      </div>

      <!-- Simulator Configuration Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Column 1: Optical & Spectral Bandpass -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 class="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2 font-mono">
            <mat-icon class="text-sm text-cyan-400">optical_audio</mat-icon>
            <span>01. Optics & Spectral Band</span>
          </h2>

          <div class="space-y-3 text-xs">
            <!-- Spectral Band Selection -->
            <div>
              <div class="text-slate-400 font-mono mb-1">Spectral Band:</div>
              <div class="grid grid-cols-3 gap-1.5 font-mono text-[11px]">
                @for (band of bands; track band) {
                  <button 
                    (click)="selectedBand.set(band)"
                    class="py-1.5 px-2 rounded border text-center transition-colors cursor-pointer"
                    [class.bg-amber-500/15]="selectedBand() === band"
                    [class.border-amber-500/60]="selectedBand() === band"
                    [class.text-amber-300]="selectedBand() === band"
                    [class.bg-slate-950]="selectedBand() !== band"
                    [class.border-slate-800]="selectedBand() !== band"
                    [class.text-slate-400]="selectedBand() !== band">
                    {{ band }}
                  </button>
                }
              </div>
            </div>

            <!-- Detector Technology -->
            <div>
              <div class="text-slate-400 font-mono mb-1">Detector FPA Architecture:</div>
              <select 
                [value]="selectedDetector()"
                (change)="onDetectorChange($event)"
                aria-label="Detector Architecture"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:border-amber-500 focus:outline-none cursor-pointer">
                @for (det of detectors; track det) {
                  <option [value]="det">{{ det }}</option>
                }
              </select>
            </div>

            <!-- FPA Resolution -->
            <div>
              <div class="text-slate-400 font-mono mb-1">Focal Plane Array Resolution:</div>
              <div class="grid grid-cols-2 gap-2 font-mono text-xs">
                <button 
                  (click)="setResolution(128, 96)"
                  class="p-2 rounded border text-left cursor-pointer transition-colors"
                  [class.bg-slate-800]="width() === 128"
                  [class.border-amber-500/50]="width() === 128">
                  <div class="text-white font-bold">128 × 96</div>
                  <div class="text-[10px] text-slate-400">Micro-bolometer array</div>
                </button>
                <button 
                  (click)="setResolution(320, 240)"
                  class="p-2 rounded border text-left cursor-pointer transition-colors"
                  [class.bg-slate-800]="width() === 320"
                  [class.border-amber-500/50]="width() === 320">
                  <div class="text-white font-bold">320 × 240</div>
                  <div class="text-[10px] text-slate-400">Standard Industrial</div>
                </button>
              </div>
            </div>

            <!-- Pixel Pitch -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Pixel Pitch:</span>
                <span class="text-white font-bold">{{ pixelPitchUm() }} µm</span>
              </div>
              <input 
                type="range" 
                min="10" 
                max="25" 
                [value]="pixelPitchUm()" 
                (input)="pixelPitchUm.set(+($any($event.target).value))"
                aria-label="Pixel Pitch Slider"
                class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <!-- Integration Time -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Integration Time:</span>
                <span class="text-white font-bold">{{ integrationTimeUs() }} µs</span>
              </div>
              <input 
                type="range" 
                min="200" 
                max="4000" 
                step="50"
                [value]="integrationTimeUs()" 
                (input)="integrationTimeUs.set(+($any($event.target).value))"
                aria-label="Integration Time Slider"
                class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>
          </div>
        </div>

        <!-- Column 2: Noise Physics & Cryo Conditions -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 class="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2 font-mono">
            <mat-icon class="text-sm text-amber-400">tune</mat-icon>
            <span>02. Noise Physics & NETD</span>
          </h2>

          <div class="space-y-3 text-xs">
            <!-- NETD -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Detector NETD (Noise Equivalent Delta-T):</span>
                <span class="text-amber-400 font-bold">{{ netdMk() }} mK</span>
              </div>
              <input 
                type="range" 
                min="10" 
                max="80" 
                [value]="netdMk()" 
                (input)="netdMk.set(+($any($event.target).value))"
                aria-label="NETD Slider"
                class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
              <div class="text-[10px] text-slate-500 mt-1">Lower NETD yields crisp thermal sensitivity for subtle gradient detection.</div>
            </div>

            <!-- FPA Cryo Temperature -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">FPA Operating Temperature:</span>
                <span class="text-cyan-400 font-bold">{{ fpaTempK() }} K</span>
              </div>
              <input 
                type="range" 
                min="77" 
                max="310" 
                [value]="fpaTempK()" 
                (input)="fpaTempK.set(+($any($event.target).value))"
                aria-label="FPA Operating Temperature Slider"
                class="w-full accent-cyan-500 h-1 bg-slate-800 rounded cursor-pointer" />
              <div class="text-[10px] text-slate-500 mt-1">77K = Liquid Nitrogen Stirling Cooler, 298K = Uncooled Microbolometer.</div>
            </div>

            <!-- Bad Pixel Defect Rate -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Defective / Blind Pixels Rate:</span>
                <span class="text-rose-400 font-bold">{{ badPixelRate() }} %</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="2.0" 
                step="0.05"
                [value]="badPixelRate()" 
                (input)="badPixelRate.set(+($any($event.target).value))"
                aria-label="Bad Pixel Rate Slider"
                class="w-full accent-rose-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <!-- Non-Uniformity PRNU -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Spatial Non-Uniformity (PRNU):</span>
                <span class="text-white font-bold">{{ prnuPercent() }} %</span>
              </div>
              <input 
                type="range" 
                min="0.02" 
                max="0.5" 
                step="0.01"
                [value]="prnuPercent()" 
                (input)="prnuPercent.set(+($any($event.target).value))"
                aria-label="PRNU Non-Uniformity Slider"
                class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>
          </div>
        </div>

        <!-- Column 3: Thermal Scene Ingestion & Fault Injection -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 class="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2 font-mono">
            <mat-icon class="text-sm text-emerald-400">local_fire_department</mat-icon>
            <span>03. Scene Physics & Faults</span>
          </h2>

          <div class="space-y-3 text-xs">
            <!-- Target Base Temperature -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Target Object Base Temp:</span>
                <span class="text-white font-bold">{{ targetTempC() }} °C</span>
              </div>
              <input 
                type="range" 
                min="20" 
                max="250" 
                [value]="targetTempC()" 
                (input)="targetTempC.set(+($any($event.target).value))"
                aria-label="Target Base Temperature Slider"
                class="w-full accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <!-- Injected Fault Hotspot Delta-T -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Injected Fault Hotspot ΔT:</span>
                <span class="text-rose-400 font-bold">+{{ hotspotDeltaC() }} °C</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="100" 
                [value]="hotspotDeltaC()" 
                (input)="hotspotDeltaC.set(+($any($event.target).value))"
                aria-label="Injected Fault Hotspot Slider"
                class="w-full accent-rose-500 h-1 bg-slate-800 rounded cursor-pointer" />
              <div class="text-[10px] text-slate-500 mt-1">Simulates bearing lubrication loss or electrical phase imbalance.</div>
            </div>

            <!-- Ambient Temperature -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Ambient Background Temp:</span>
                <span class="text-cyan-400 font-bold">{{ ambientTempC() }} °C</span>
              </div>
              <input 
                type="range" 
                min="-10" 
                max="40" 
                [value]="ambientTempC()" 
                (input)="ambientTempC.set(+($any($event.target).value))"
                aria-label="Ambient Background Temperature Slider"
                class="w-full accent-cyan-500 h-1 bg-slate-800 rounded cursor-pointer" />
            </div>

            <!-- Summary Meta Box -->
            <div class="p-3 bg-slate-950 rounded-lg border border-slate-800 font-mono text-[11px] space-y-1">
              <div class="text-amber-400 font-bold">SIMULATION METADATA EMBEDDED:</div>
              <div class="text-slate-400">Model: Monte-Carlo Photon + Planck</div>
              <div class="text-slate-400">Engine: Rust SIMD Core v4.2.0</div>
              <div class="text-emerald-400">Synthetic Provenance Tagged: TRUE</div>
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class SensorLabComponent {
  private readonly dataService = inject(AardvarkDataService);

  public readonly bands: SpectralBand[] = ['LWIR', 'MWIR', 'SWIR', 'NIR', 'MULTISPECTRAL'];
  public readonly detectors: DetectorType[] = [
    'VOx_Microbolometer',
    'aSi_Microbolometer',
    'InSb_Stirling_Cooled',
    'MCT_Stirling_Cooled',
    'InGaAs_Peltier_Cooled'
  ];

  public readonly selectedBand = signal<SpectralBand>('LWIR');
  public readonly selectedDetector = signal<DetectorType>('VOx_Microbolometer');
  public readonly width = signal<number>(128);
  public readonly height = signal<number>(96);
  public readonly pixelPitchUm = signal<number>(12.0);
  public readonly integrationTimeUs = signal<number>(1400);

  public readonly netdMk = signal<number>(35);
  public readonly fpaTempK = signal<number>(298);
  public readonly badPixelRate = signal<number>(0.15);
  public readonly prnuPercent = signal<number>(0.09);

  public readonly targetTempC = signal<number>(95);
  public readonly hotspotDeltaC = signal<number>(45);
  public readonly ambientTempC = signal<number>(18);

  public onDetectorChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    if (target) {
      this.selectedDetector.set(target.value as DetectorType);
    }
  }

  public setResolution(w: number, h: number): void {
    this.width.set(w);
    this.height.set(h);
  }

  public generateSyntheticScene(): void {
    this.dataService.generateSyntheticSensorData({
      band: this.selectedBand(),
      detector: this.selectedDetector(),
      width: this.width(),
      height: this.height(),
      targetTempC: this.targetTempC(),
      ambientTempC: this.ambientTempC(),
      netdMk: this.netdMk(),
      fpaTempK: this.fpaTempK(),
      hotspotDeltaC: this.hotspotDeltaC(),
      badPixelRatePercent: this.badPixelRate()
    });

    this.dataService.activeTab.set('workstation');
  }
}
