import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ImagingAssistantService } from '../../services/imaging-assistant.service';
import { AardvarkDataService } from '../../services/aardvark-data.service';

@Component({
  selector: 'app-imaging-assistant',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">psychology</mat-icon>
            <span>Aardvark Imaging Intelligence · Scientific AI</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Empirical Physical Advisor & Script Synthesizer
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Physical diagnostic intelligence backed by Google Gemini. Every statement is strictly tagged by empirical provenance (MEASURED, CALCULATED, MODELLED, INFERRED, SIMULATED, AI INTERPRETATION).
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-3 py-1.5 rounded-lg">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>GEMINI SERVER-SIDE ACTIVE</span>
        </div>
      </div>

      <!-- Quick Scientific Prompt Buttons -->
      <div class="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none font-mono text-xs">
        <span class="text-slate-500 text-[11px] shrink-0">Quick Queries:</span>
        <button 
          (click)="sendQuickQuery('Analyze the North Sea high-pressure turbine bearing hotspot at 148.6°C and evaluate lubrication failure risk under ISO 18434-1.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 rounded-lg whitespace-nowrap cursor-pointer transition-colors">
          Turbine Bearing Anomaly
        </button>
        <button 
          (click)="sendQuickQuery('Generate a high-performance Python script to compute 2D spatial thermal gradients dT/dx using SciPy and detect boundary lubrication collapse.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 rounded-lg whitespace-nowrap cursor-pointer transition-colors">
          Python Thermal Gradient Script
        </button>
        <button 
          (click)="sendQuickQuery('Calculate the GUM expanded uncertainty budget for an InSb MWIR sensor measuring 250°C blackbody cavity with emissivity uncertainty ±2%.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 rounded-lg whitespace-nowrap cursor-pointer transition-colors">
          GUM U95 Uncertainty Calculation
        </button>
        <button 
          (click)="sendQuickQuery('Explain the building envelope thermal bridging loss across the Manchester Victorian mill concrete lintel.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 rounded-lg whitespace-nowrap cursor-pointer transition-colors">
          Manchester Building Heat Loss
        </button>
      </div>

      <!-- Chat History Stream -->
      <div class="space-y-4">
        @for (msg of assistant.messages(); track msg.id) {
          <div 
            class="p-5 rounded-xl border space-y-3 transition-all"
            [class.bg-slate-900]="msg.sender === 'assistant'"
            [class.border-slate-800]="msg.sender === 'assistant'"
            [class.bg-slate-950]="msg.sender === 'user'"
            [class.border-amber-500/40]="msg.sender === 'user'">
            
            <div class="flex items-center justify-between font-mono text-xs">
              <span 
                class="font-bold uppercase tracking-wider flex items-center gap-1.5"
                [class.text-amber-400]="msg.sender === 'assistant'"
                [class.text-slate-300]="msg.sender === 'user'">
                <mat-icon class="text-sm">{{ msg.sender === 'assistant' ? 'psychology' : 'person' }}</mat-icon>
                <span>{{ msg.sender === 'assistant' ? 'Aardvark Imaging Intelligence' : 'Operator Query' }}</span>
              </span>
              <span class="text-slate-500 text-[10px]">{{ msg.timestamp | date:'shortTime' }}</span>
            </div>

            <!-- Loading Spinner -->
            @if (msg.isLoading) {
              <div class="flex items-center gap-3 py-3 text-amber-400 font-mono text-xs">
                <mat-icon class="animate-spin text-base">sync</mat-icon>
                <span>Evaluating physical radiometry & synthesizing empirical evidence...</span>
              </div>
            } @else {
              <!-- Message Prose Text -->
              <p class="text-slate-200 text-xs md:text-sm leading-relaxed whitespace-pre-wrap">
                {{ msg.text }}
              </p>

              <!-- Structured Evidence Facts (Anti-Hallucination Framework) -->
              @if (msg.structuredFacts && msg.structuredFacts.length > 0) {
                <div class="pt-3 border-t border-slate-800/80 space-y-2">
                  <div class="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <mat-icon class="text-xs text-amber-400">verified</mat-icon>
                    <span>Empirical Evidence Verification:</span>
                  </div>

                  <div class="grid grid-cols-1 md:grid-cols-3 gap-2 font-mono text-xs">
                    @for (fact of msg.structuredFacts; track $index) {
                      <div class="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                        <span 
                          class="text-[9px] font-bold px-1.5 py-0.5 rounded uppercase"
                          [class.bg-emerald-950]="fact.category === 'MEASURED'"
                          [class.text-emerald-400]="fact.category === 'MEASURED'"
                          [class.bg-cyan-950]="fact.category === 'MODELLED'"
                          [class.text-cyan-400]="fact.category === 'MODELLED'"
                          [class.bg-amber-950]="fact.category === 'CALCULATED'"
                          [class.text-amber-400]="fact.category === 'CALCULATED'"
                          [class.bg-purple-950]="fact.category === 'SIMULATED'"
                          [class.text-purple-400]="fact.category === 'SIMULATED'"
                          [class.bg-slate-800]="fact.category === 'INFERRED' || fact.category === 'AI_INTERPRETATION'"
                          [class.text-slate-300]="fact.category === 'INFERRED' || fact.category === 'AI_INTERPRETATION'">
                          {{ fact.category }}
                        </span>
                        <div class="text-white font-bold text-[11px]">{{ fact.title }}</div>
                        <div class="text-slate-400 text-[10px] leading-tight">{{ fact.detail }}</div>
                      </div>
                    }
                  </div>
                </div>
              }

              <!-- Generated Production Code Block -->
              @if (msg.generatedCode; as code) {
                <div class="mt-3 bg-slate-950 rounded-lg border border-slate-800 overflow-hidden font-mono text-xs">
                  <div class="px-3 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-[11px]">
                    <span class="text-amber-400 font-bold flex items-center gap-1">
                      <mat-icon class="text-xs">code</mat-icon>
                      <span>{{ code.filename }} ({{ code.language | uppercase }})</span>
                    </span>
                    <button 
                      (click)="copyCode(code.code)"
                      class="text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer">
                      <mat-icon class="text-xs">content_copy</mat-icon>
                      <span>Copy Code</span>
                    </button>
                  </div>
                  <pre class="p-3 text-slate-300 overflow-x-auto text-[11px] leading-relaxed"><code>{{ code.code }}</code></pre>
                </div>
              }
            }

          </div>
        }
      </div>

      <!-- User Query Input Bar -->
      <div class="sticky bottom-4 bg-slate-950/95 backdrop-blur p-2.5 rounded-xl border border-slate-800 shadow-2xl flex items-center gap-2">
        <input 
          #promptInput
          type="text" 
          placeholder="Ask Aardvark Intelligence (e.g. 'Analyze bearing thermal gradient', 'Check ISO 18434-1 severity', 'Synthesize Rust SIMD kernel')..."
          (keydown.enter)="onSend(promptInput.value); promptInput.value = ''"
          aria-label="Aardvark Intelligence Query Input"
          class="flex-1 bg-transparent px-3 py-2 text-xs md:text-sm text-white placeholder:text-slate-600 focus:outline-none font-mono" />
        
        <button 
          (click)="onSend(promptInput.value); promptInput.value = ''"
          [disabled]="assistant.isQuerying()"
          class="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 cursor-pointer transition-colors shrink-0">
          <mat-icon class="text-sm">send</mat-icon>
          <span class="hidden sm:inline">Inquire</span>
        </button>
      </div>

    </div>
  `
})
export class ImagingAssistantComponent {
  public readonly assistant = inject(ImagingAssistantService);
  private readonly dataService = inject(AardvarkDataService);

  public onSend(prompt: string): void {
    if (!prompt.trim()) return;
    const currentDataset = this.dataService.currentDataset();
    const currentTwin = this.dataService.currentDigitalTwin();

    this.assistant.sendQuery(prompt, {
      dataset: {
        id: currentDataset.id,
        facility: currentDataset.facility,
        band: currentDataset.bandType,
        detector: currentDataset.detectorType,
        calibration: currentDataset.calibration,
        rois: currentDataset.rois,
        anomalies: currentDataset.anomalies,
        uncertaintyU95: currentDataset.uncertainty.expandedUncertaintyU95C
      },
      digitalTwin: {
        name: currentTwin?.name,
        operatingConditions: currentTwin?.operatingConditions,
        maxResidualC: currentTwin?.maxResidualC
      }
    });
  }

  public sendQuickQuery(query: string): void {
    this.onSend(query);
  }

  public copyCode(code: string): void {
    navigator.clipboard.writeText(code);
  }
}
