import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  ViewChild, 
  inject, 
  signal, 
  computed, 
  effect, 
  AfterViewInit,
  OnDestroy
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';
import { ColormapsService, ColormapName } from '../../services/colormaps.service';
import { RadiometryPhysicsService } from '../../services/radiometry-physics.service';

@Component({
  selector: 'app-workstation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-200">
      
      <!-- Top Telemetry & Control Ribbon -->
      <div class="bg-slate-900/90 border-b border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        <!-- Left: Dataset Status & Sensor Optics -->
        <div class="flex items-center gap-3 font-mono">
          <div class="flex items-center gap-1.5 text-slate-300">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span class="font-bold text-white uppercase">{{ dataset().bandType }}</span>
            <span class="text-slate-500">·</span>
            <span>{{ dataset().width }}×{{ dataset().height }} px</span>
            <span class="text-slate-500">·</span>
            <span>{{ dataset().pixelPitchUm }}µm pitch</span>
            <span class="text-slate-500">·</span>
            <span>{{ dataset().detectorType }}</span>
          </div>

          <div class="hidden xl:flex items-center gap-2 text-slate-400 border-l border-slate-700 pl-3">
            <span>Lens: {{ dataset().lensConfiguration }}</span>
            <span class="text-slate-600">·</span>
            <span>FPA Temp: {{ dataset().detectorTemperatureK }} K</span>
            <span class="text-slate-600">·</span>
            <span class="text-amber-400">CAL: {{ dataset().calibration.calibrationId }} ({{ dataset().calibration.version }})</span>
          </div>
        </div>

        <!-- Center/Right: Colormap, AGC and Display Tools -->
        <div class="flex items-center gap-2 flex-wrap">
          <!-- Colormap Selector -->
          <div class="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-lg px-2 py-1">
            <span class="text-slate-400 text-[11px] font-mono">LUT:</span>
            <select 
              [value]="selectedColormap()" 
              (change)="onColormapChange($event)"
              class="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs">
              @for (cm of colormapService.availableColormaps; track cm.name) {
                <option [value]="cm.name" class="bg-slate-900 text-slate-100">{{ cm.name }}</option>
              }
            </select>
          </div>

          <!-- AGC Mode -->
          <div class="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-lg p-0.5">
            <button 
              (click)="agcMode.set('auto')"
              class="px-2 py-0.5 rounded text-[11px] font-mono transition-colors cursor-pointer"
              [class.bg-slate-800]="agcMode() === 'auto'"
              [class.text-amber-400]="agcMode() === 'auto'"
              [class.text-slate-400]="agcMode() !== 'auto'">
              AUTO SPAN
            </button>
            <button 
              (click)="agcMode.set('clahe')"
              class="px-2 py-0.5 rounded text-[11px] font-mono transition-colors cursor-pointer"
              [class.bg-slate-800]="agcMode() === 'clahe'"
              [class.text-amber-400]="agcMode() === 'clahe'"
              [class.text-slate-400]="agcMode() !== 'clahe'">
              CLAHE
            </button>
            <button 
              (click)="agcMode.set('manual')"
              class="px-2 py-0.5 rounded text-[11px] font-mono transition-colors cursor-pointer"
              [class.bg-slate-800]="agcMode() === 'manual'"
              [class.text-amber-400]="agcMode() === 'manual'"
              [class.text-slate-400]="agcMode() !== 'manual'">
              MANUAL
            </button>
          </div>

          <!-- ROI Draw Tool Selection -->
          <div class="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-lg p-0.5">
            <button 
              (click)="activeRoiTool.set('inspect')"
              title="Pixel Inspector Crosshair"
              class="p-1 rounded text-slate-300 hover:text-white cursor-pointer"
              [class.bg-slate-800]="activeRoiTool() === 'inspect'"
              [class.text-amber-400]="activeRoiTool() === 'inspect'">
              <mat-icon class="text-sm">crosshair</mat-icon>
            </button>
            <button 
              (click)="activeRoiTool.set('box')"
              title="Box Region of Interest"
              class="p-1 rounded text-slate-300 hover:text-white cursor-pointer"
              [class.bg-slate-800]="activeRoiTool() === 'box'"
              [class.text-amber-400]="activeRoiTool() === 'box'">
              <mat-icon class="text-sm">crop_square</mat-icon>
            </button>
            <button 
              (click)="activeRoiTool.set('line')"
              title="Line Profile Transect"
              class="p-1 rounded text-slate-300 hover:text-white cursor-pointer"
              [class.bg-slate-800]="activeRoiTool() === 'line'"
              [class.text-amber-400]="activeRoiTool() === 'line'">
              <mat-icon class="text-sm">show_chart</mat-icon>
            </button>
          </div>

          <!-- Video Playback / Stream Toggle -->
          <button 
            (click)="togglePlayback()"
            class="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-lg font-mono text-[11px] cursor-pointer">
            <mat-icon class="text-sm">{{ isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
            <span>{{ isPlaying() ? 'PAUSE STREAM' : 'PLAY 60 FPS' }}</span>
          </button>
        </div>
      </div>

      <!-- Main Workstation Layout: Left Viewport (Flex-1) + Right Scientific Inspector Panel (380px) -->
      <div class="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        <!-- Left: Radiometric Imaging Canvas Stage -->
        <div class="flex-1 flex flex-col bg-slate-950 p-3 relative overflow-hidden">
          
          <!-- Canvas Container with Crosshair readout HUD -->
          <div class="flex-1 relative flex items-center justify-center bg-black rounded-lg border border-slate-800/80 overflow-hidden shadow-inner">
            
            <canvas 
              #radiometricCanvas 
              (mousemove)="onCanvasMouseMove($event)"
              (mouseleave)="onCanvasMouseLeave()"
              class="max-w-full max-h-full object-contain cursor-crosshair image-rendering-pixelated">
            </canvas>

            <!-- Live Crosshair HUD Overlay (Top-Left) -->
            <div class="absolute top-3 left-3 bg-slate-900/90 backdrop-blur border border-slate-700/80 rounded-lg p-2.5 font-mono text-xs shadow-xl pointer-events-none">
              <div class="text-[10px] text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                <span>Radiometric Probe Readout</span>
              </div>
              @if (cursorPixel(); as p) {
                <div class="grid grid-cols-2 gap-x-4 gap-y-1">
                  <div class="text-slate-400">Pixel Coord (X, Y):</div>
                  <div class="text-white font-bold tabular-nums">[{{ p.x }}, {{ p.y }}]</div>
                  <div class="text-slate-400">RAW Detector DN:</div>
                  <div class="text-amber-300 font-bold tabular-nums">{{ p.rawDn }} DN (14-bit)</div>
                  <div class="text-slate-400">Calibrated Radiance:</div>
                  <div class="text-cyan-300 font-bold tabular-nums">{{ p.radiance }} W/(m²·sr·µm)</div>
                  <div class="text-slate-400">Apparent Temp:</div>
                  <div class="text-emerald-400 font-bold text-sm tabular-nums">{{ p.tempC }} °C / {{ (p.tempC + 273.15).toFixed(1) }} K</div>
                  <div class="text-slate-400">GUM Uncertainty (U95):</div>
                  <div class="text-slate-300 tabular-nums">±{{ dataset().uncertainty.expandedUncertaintyU95C }} °C (k=2)</div>
                </div>
              } @else {
                <div class="text-slate-400 italic text-[11px]">Hover over canvas to probe radiometric pixels</div>
              }
            </div>

            <!-- Colormap Thermal Scale Bar HUD (Right side) -->
            <div class="absolute right-3 top-3 bottom-3 w-10 bg-slate-900/85 backdrop-blur border border-slate-700/80 rounded-lg p-1.5 flex flex-col items-center justify-between font-mono text-[10px] shadow-xl">
              <div class="text-amber-400 font-bold tabular-nums">{{ maxTempSpan() }}°C</div>
              <div 
                class="w-3 flex-1 my-1 rounded-sm border border-slate-700" 
                [style.background]="activeColormapGradient()">
              </div>
              <div class="text-cyan-400 font-bold tabular-nums">{{ minTempSpan() }}°C</div>
            </div>

            <!-- Bottom Frame Timestamp & Simulation Watermark -->
            <div class="absolute bottom-3 left-3 flex items-center gap-2 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded border border-slate-800 text-[11px] font-mono text-slate-400">
              <span>ACQ: {{ dataset().acquisitionTimestamp }}</span>
              <span class="text-slate-600">·</span>
              <span class="text-amber-400">FRAME #{{ currentFrameIndex() }}</span>
              <span class="text-slate-600">·</span>
              <span class="text-emerald-400">PROVENANCE: IMMUTABLE</span>
            </div>
          </div>

          <!-- Bottom Timeline / Thermal Trajectory Scrubber -->
          <div class="mt-2 bg-slate-900/80 border border-slate-800 rounded-lg p-2 flex items-center gap-3 text-xs">
            <button 
              (click)="togglePlayback()"
              class="w-7 h-7 rounded bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-100 cursor-pointer shrink-0">
              <mat-icon class="text-sm">{{ isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
            </button>
            <span class="text-slate-400 font-mono text-[11px] shrink-0">t = {{ (currentFrameIndex() * 0.0166).toFixed(2) }}s</span>
            
            <input 
              type="range" 
              min="0" 
              max="120" 
              [value]="currentFrameIndex()" 
              (input)="onTimelineScrub($event)"
              aria-label="Temporal Frame Timeline"
              class="flex-1 accent-amber-500 h-1 bg-slate-700 rounded-lg cursor-pointer" />

            <div class="flex items-center gap-2 font-mono text-[11px] text-slate-400 shrink-0">
              <span>NETD: {{ dataset().calibration.temporalNetd }} mK</span>
              <span class="text-slate-600">·</span>
              <span class="text-emerald-400">dT/dt = +0.14 °C/s</span>
            </div>
          </div>
        </div>

        <!-- Right: Scientific Metrology Inspector & ROI Statistics (380px fixed width) -->
        <aside class="w-full lg:w-96 bg-slate-900/95 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col overflow-y-auto">
          
          <!-- Header: Inspector Mode Tabs -->
          <div class="p-3 border-b border-slate-800 bg-slate-950/60">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono flex items-center gap-1.5">
                <mat-icon class="text-sm text-amber-400">analytics</mat-icon>
                <span>Radiometric Inspection</span>
              </span>
              <span class="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                CALIBRATED
              </span>
            </div>
          </div>

          <div class="p-4 space-y-4 text-xs">
            
            <!-- Section 1: Dynamic Range Span & AGC Controls -->
            <div class="bg-slate-950 border border-slate-800/80 rounded-lg p-3 space-y-2">
              <div class="flex items-center justify-between text-slate-300 font-medium">
                <span class="flex items-center gap-1">
                  <mat-icon class="text-xs text-amber-400">tune</mat-icon>
                  <span>Thermal Span & Level</span>
                </span>
                <span class="font-mono text-[11px] text-slate-400">
                  Range: {{ (maxTempSpan() - minTempSpan()).toFixed(1) }} °C
                </span>
              </div>

              <div class="space-y-1.5 font-mono text-[11px]">
                <div class="flex items-center justify-between">
                  <span class="text-slate-400">Min Temp: {{ minTempSpan() }} °C</span>
                  <input 
                    type="range" 
                    [min]="-20" 
                    [max]="80" 
                    [value]="minTempSpan()" 
                    (input)="onMinTempChange($event)"
                    aria-label="Minimum Temperature Span"
                    class="w-28 accent-cyan-500 h-1 bg-slate-800 rounded cursor-pointer" />
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-slate-400">Max Temp: {{ maxTempSpan() }} °C</span>
                  <input 
                    type="range" 
                    [min]="50" 
                    [max]="250" 
                    [value]="maxTempSpan()" 
                    (input)="onMaxTempChange($event)"
                    aria-label="Maximum Temperature Span"
                    class="w-28 accent-amber-500 h-1 bg-slate-800 rounded cursor-pointer" />
                </div>
                <div class="flex items-center justify-between pt-1 border-t border-slate-800/60">
                  <span class="text-slate-400">Isotherm Alert Threshold:</span>
                  <span class="text-rose-400 font-bold">{{ isothermThresholdC() }} °C</span>
                </div>
              </div>
            </div>

            <!-- Section 2: Thermal Histogram (64-bin) -->
            <div class="bg-slate-950 border border-slate-800/80 rounded-lg p-3 space-y-2">
              <div class="flex items-center justify-between text-slate-300 font-medium">
                <span class="flex items-center gap-1">
                  <mat-icon class="text-xs text-cyan-400">bar_chart</mat-icon>
                  <span>Thermal Field Histogram</span>
                </span>
                <span class="font-mono text-[10px] text-slate-400">{{ dataset().width * dataset().height }} pixels</span>
              </div>

              <!-- Mini SVG Histogram Bars -->
              <div class="h-16 w-full flex items-end gap-[1px] bg-slate-900/50 p-1 rounded border border-slate-800">
                @for (bin of histogramBins(); track $index) {
                  <div 
                    class="flex-1 bg-amber-500/70 hover:bg-amber-400 transition-colors rounded-t-[1px]"
                    [style.height.%]="bin.percent"
                    [title]="bin.tempLabel + ': ' + bin.count + ' pixels'">
                  </div>
                }
              </div>
              <div class="flex items-center justify-between font-mono text-[10px] text-slate-500">
                <span>{{ minTempSpan() }}°C</span>
                <span>Mean: {{ meanFieldTemp() }}°C</span>
                <span>{{ maxTempSpan() }}°C</span>
              </div>
            </div>

            <!-- Section 3: Line Profile Transect (dT/dx) -->
            @if (activeLineProfile(); as lp) {
              <div class="bg-slate-950 border border-slate-800/80 rounded-lg p-3 space-y-2">
                <div class="flex items-center justify-between text-slate-300 font-medium">
                  <span class="flex items-center gap-1 text-cyan-400">
                    <mat-icon class="text-xs">show_chart</mat-icon>
                    <span>Line Transect (dT/dx)</span>
                  </span>
                  <span class="font-mono text-[11px] text-rose-400">
                    Max Grad: 12.4 °C/cm
                  </span>
                </div>

                <!-- SVG Line Chart -->
                <div class="h-20 w-full bg-slate-900/60 rounded border border-slate-800 p-1 relative">
                  <svg class="w-full h-full" viewBox="0 0 200 60" preserveAspectRatio="none">
                    <path 
                      [attr.d]="lineProfileSvgPath(lp.profileValues || [])" 
                      fill="none" 
                      stroke="#06b6d4" 
                      stroke-width="2" 
                      stroke-linecap="round" />
                  </svg>
                </div>
                <div class="flex items-center justify-between font-mono text-[10px] text-slate-400">
                  <span>Start (35, 47)</span>
                  <span class="text-amber-300">Peak: {{ lp.maxTempC }} °C</span>
                  <span>End (90, 47)</span>
                </div>
              </div>
            }

            <!-- Section 4: Quantitative ROI Metrology Table -->
            <div class="bg-slate-950 border border-slate-800/80 rounded-lg p-3 space-y-2">
              <div class="flex items-center justify-between text-slate-300 font-medium">
                <span class="flex items-center gap-1">
                  <mat-icon class="text-xs text-amber-400">filter_center_focus</mat-icon>
                  <span>Active ROI Metrology</span>
                </span>
                <span class="font-mono text-[10px] text-slate-400">{{ dataset().rois.length }} ROIs</span>
              </div>

              <div class="space-y-2">
                @for (roi of dataset().rois; track roi.id) {
                  <div class="p-2 bg-slate-900/80 rounded border border-slate-800 font-mono text-[11px] space-y-1">
                    <div class="flex items-center justify-between font-bold" [style.color]="roi.color">
                      <span>{{ roi.label }}</span>
                      <span>{{ roi.maxTempC }} °C</span>
                    </div>
                    <div class="grid grid-cols-2 gap-x-2 text-[10px] text-slate-400">
                      <div>Mean: <span class="text-slate-200">{{ roi.meanTempC }} °C</span></div>
                      <div>Min: <span class="text-slate-200">{{ roi.minTempC }} °C</span></div>
                      <div>Std Dev σ: <span class="text-slate-200">±{{ roi.stdDevTempC }} °C</span></div>
                      <div>U95 (k=2): <span class="text-cyan-300">±{{ roi.uncertaintyU95C }} °C</span></div>
                      <div>ΔT Ambient: <span class="text-amber-400">+{{ roi.deltaAmbientC }} °C</span></div>
                      <div>Pixels: <span class="text-slate-200">{{ roi.pixelCount }} px</span></div>
                    </div>
                  </div>
                } @empty {
                  <div class="text-slate-500 italic text-center py-2">No ROI drawn yet. Use ROI tools above.</div>
                }
              </div>
            </div>

            <!-- Section 5: Atmospheric & Emissivity Correction -->
            <div class="bg-slate-950 border border-slate-800/80 rounded-lg p-3 space-y-2">
              <div class="flex items-center justify-between text-slate-300 font-medium">
                <span class="flex items-center gap-1">
                  <mat-icon class="text-xs text-slate-400">cloud_queue</mat-icon>
                  <span>Radiometric Parameters</span>
                </span>
                <span class="font-mono text-[10px] text-emerald-400">MODTRAN Appr.</span>
              </div>

              <div class="grid grid-cols-2 gap-2 font-mono text-[10px]">
                <div class="bg-slate-900 p-1.5 rounded border border-slate-800">
                  <div class="text-slate-500">Target Emissivity ε:</div>
                  <div class="text-white font-bold">{{ dataset().atmospheric.emissivity }}</div>
                </div>
                <div class="bg-slate-900 p-1.5 rounded border border-slate-800">
                  <div class="text-slate-500">Atm Transmission τ:</div>
                  <div class="text-white font-bold">{{ dataset().atmospheric.transmissionTau }}</div>
                </div>
                <div class="bg-slate-900 p-1.5 rounded border border-slate-800">
                  <div class="text-slate-500">Distance d:</div>
                  <div class="text-white font-bold">{{ dataset().atmospheric.distanceMeters }} m</div>
                </div>
                <div class="bg-slate-900 p-1.5 rounded border border-slate-800">
                  <div class="text-slate-500">Rel. Humidity RH:</div>
                  <div class="text-white font-bold">{{ dataset().atmospheric.relativeHumidityPercent }} %</div>
                </div>
              </div>
            </div>

          </div>
        </aside>
      </div>

    </div>
  `
})
export class WorkstationComponent implements AfterViewInit, OnDestroy {
  @ViewChild('radiometricCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  public readonly dataService = inject(AardvarkDataService);
  public readonly colormapService = inject(ColormapsService);
  public readonly physicsService = inject(RadiometryPhysicsService);

  public readonly dataset = this.dataService.currentDataset;
  public readonly selectedColormap = signal<ColormapName>('Ironbow');
  public readonly agcMode = signal<'auto' | 'clahe' | 'manual'>('auto');
  public readonly activeRoiTool = signal<'inspect' | 'box' | 'line'>('inspect');

  public readonly minTempSpan = signal<number>(5.0);
  public readonly maxTempSpan = signal<number>(155.0);
  public readonly isPlaying = signal<boolean>(false);
  public readonly currentFrameIndex = signal<number>(0);

  public readonly cursorPixel = signal<{
    x: number;
    y: number;
    rawDn: number;
    radiance: number;
    tempC: number;
  } | null>(null);

  private animationFrameId: number | null = null;

  public readonly isothermThresholdC = computed(() => {
    return Math.round(this.minTempSpan() + (this.maxTempSpan() - this.minTempSpan()) * 0.85);
  });

  public readonly activeColormapGradient = computed(() => {
    const cm = this.colormapService.availableColormaps.find(c => c.name === this.selectedColormap());
    return cm ? cm.previewGradient : 'linear-gradient(to right, #000, #fff)';
  });

  public readonly activeLineProfile = computed(() => {
    const d = this.dataset();
    if (!d || !d.rois) return null;
    return d.rois.find(r => r.type === 'line') || null;
  });

  public readonly meanFieldTemp = computed(() => {
    const d = this.dataset();
    if (!d || !d.calibratedMatrix || d.calibratedMatrix.length === 0) return 0;
    let sum = 0;
    let count = 0;
    for (const row of d.calibratedMatrix) {
      for (const val of row) {
        sum += val;
        count++;
      }
    }
    return Math.round((sum / count) * 10) / 10;
  });

  public readonly histogramBins = computed(() => {
    const d = this.dataset();
    if (!d || !d.calibratedMatrix) return [];
    const min = this.minTempSpan();
    const max = this.maxTempSpan();
    const binCount = 32;
    const bins = new Array(binCount).fill(0);
    const range = Math.max(0.1, max - min);

    let maxBinCount = 1;
    for (const row of d.calibratedMatrix) {
      for (const temp of row) {
        const idx = Math.min(binCount - 1, Math.max(0, Math.floor(((temp - min) / range) * binCount)));
        bins[idx]++;
        if (bins[idx] > maxBinCount) maxBinCount = bins[idx];
      }
    }

    return bins.map((count, i) => ({
      count,
      percent: Math.max(4, Math.round((count / maxBinCount) * 100)),
      tempLabel: `${Math.round(min + (i / binCount) * range)}°C`
    }));
  });

  constructor() {
    effect(() => {
      this.dataset();
      this.selectedColormap();
      this.minTempSpan();
      this.maxTempSpan();
      this.renderCanvas();
    });
  }

  public ngAfterViewInit(): void {
    this.renderCanvas();
  }

  public ngOnDestroy(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  public onColormapChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    if (target) {
      this.selectedColormap.set(target.value as ColormapName);
    }
  }

  public onMinTempChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    if (target) {
      this.minTempSpan.set(parseFloat(target.value));
    }
  }

  public onMaxTempChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    if (target) {
      this.maxTempSpan.set(parseFloat(target.value));
    }
  }

  public onTimelineScrub(event: Event): void {
    const target = event.target as HTMLInputElement;
    if (target) {
      this.currentFrameIndex.set(parseInt(target.value, 10));
      this.renderCanvas();
    }
  }

  public togglePlayback(): void {
    this.isPlaying.update(p => !p);
    if (this.isPlaying()) {
      this.runPlaybackLoop();
    }
  }

  private runPlaybackLoop(): void {
    if (!this.isPlaying()) return;
    this.currentFrameIndex.update(idx => (idx + 1) % 120);
    this.renderCanvas();
    this.animationFrameId = requestAnimationFrame(() => {
      setTimeout(() => this.runPlaybackLoop(), 33);
    });
  }

  public onCanvasMouseMove(event: MouseEvent): void {
    const canvas = this.canvasRef?.nativeElement;
    const d = this.dataset();
    if (!canvas || !d || !d.calibratedMatrix) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const px = Math.floor((event.clientX - rect.left) * scaleX);
    const py = Math.floor((event.clientY - rect.top) * scaleY);

    if (px >= 0 && px < d.width && py >= 0 && py < d.height) {
      const tempC = d.calibratedMatrix[py][px];
      const rawDn = d.rawDnMatrix[py][px];
      const radiance = d.radianceMatrix[py][px];

      this.cursorPixel.set({
        x: px,
        y: py,
        rawDn,
        radiance,
        tempC
      });
    }
  }

  public onCanvasMouseLeave(): void {
    this.cursorPixel.set(null);
  }

  public lineProfileSvgPath(values: number[]): string {
    if (!values || values.length === 0) return '';
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = Math.max(0.1, max - min);
    const stepX = 200 / (values.length - 1);

    return values.reduce((acc, val, i) => {
      const x = i * stepX;
      const y = 55 - ((val - min) / range) * 50;
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }

  private renderCanvas(): void {
    const canvas = this.canvasRef?.nativeElement;
    const d = this.dataset();
    if (!canvas || !d || !d.calibratedMatrix || d.calibratedMatrix.length === 0) return;

    canvas.width = d.width;
    canvas.height = d.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imgData = this.colormapService.renderMatrixToImageData(
      d.calibratedMatrix,
      this.minTempSpan(),
      this.maxTempSpan(),
      this.selectedColormap(),
      0.85
    );

    ctx.putImageData(imgData, 0, 0);

    if (d.rois) {
      for (const roi of d.rois) {
        ctx.strokeStyle = roi.color;
        ctx.lineWidth = 1.5;
        if (roi.type === 'box' && roi.width && roi.height) {
          ctx.strokeRect(roi.x, roi.y, roi.width, roi.height);
          ctx.fillStyle = roi.color;
          ctx.font = '7px monospace';
          ctx.fillText(roi.label.slice(0, 14), roi.x, Math.max(8, roi.y - 2));
        } else if (roi.type === 'line' && roi.x2 !== undefined && roi.y2 !== undefined) {
          ctx.beginPath();
          ctx.moveTo(roi.x, roi.y);
          ctx.lineTo(roi.x2, roi.y2);
          ctx.stroke();
          ctx.fillStyle = '#06b6d4';
          ctx.fillRect(roi.x - 1, roi.y - 1, 3, 3);
          ctx.fillRect(roi.x2 - 1, roi.y2 - 1, 3, 3);
        }
      }
    }
  }
}
