import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';

type ActiveNavTab = 
  | 'workstation' 
  | 'sensor-lab' 
  | 'calibration-lab' 
  | 'blackbody-lab' 
  | 'hyperspectral' 
  | 'digital-twin' 
  | 'anomaly-engine' 
  | 'fusion-registration' 
  | 'uncertainty-lab' 
  | 'pipeline-graph' 
  | 'benchmark-lab' 
  | 'imaging-assistant' 
  | 'code-repository' 
  | 'inspection-report';

@Component({
  selector: 'app-top-nav',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-slate-950 border-b border-slate-800/80 sticky top-0 z-50 text-slate-100">
      <!-- Zone 1, 2, 3 Main Top Bar Contract -->
      <div class="max-w-[1600px] mx-auto px-4 h-14 flex items-center justify-between gap-4">
        
        <!-- Zone 1: Single text element Brand Mark -->
        <div class="flex items-center gap-3 shrink-0">
          <button 
            (click)="dataService.activeTab.set('workstation')"
            class="flex items-center gap-2 group text-left cursor-pointer focus:outline-none">
            <div class="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:bg-amber-500/20 group-hover:border-amber-500/50 transition-colors">
              <mat-icon class="text-base leading-none">flare</mat-icon>
            </div>
            <div class="flex flex-col">
              <span class="text-base font-bold tracking-tight text-white font-['Space_Grotesk'] group-hover:text-amber-300 transition-colors">
                Aardvark Infrared
              </span>
            </div>
          </button>
          
          <div class="hidden sm:flex items-center gap-2 pl-3 border-l border-slate-800 text-xs text-slate-400 font-mono">
            <span class="text-emerald-400 flex items-center gap-1 font-semibold">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              RUST SIMD CORE
            </span>
            <span class="text-slate-600">·</span>
            <span>PYTHON SCIENTIFIC</span>
            <span class="text-slate-600">·</span>
            <span>R METROLOGY</span>
          </div>
        </div>

        <!-- Zone 2: Navigation Links (Clean Segmented / Tab Controls) -->
        <nav class="hidden lg:flex items-center gap-1 overflow-x-auto py-1 text-xs font-medium">
          @for (tab of navTabs; track tab.id) {
            <button 
              (click)="dataService.activeTab.set(tab.id)"
              class="px-2.5 py-1.5 rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 cursor-pointer"
              [class.bg-slate-800]="dataService.activeTab() === tab.id"
              [class.text-amber-400]="dataService.activeTab() === tab.id"
              [class.text-slate-300]="dataService.activeTab() !== tab.id"
              [class.hover:text-white]="dataService.activeTab() !== tab.id"
              [class.hover:bg-slate-900]="dataService.activeTab() !== tab.id">
              <mat-icon class="text-sm leading-none opacity-80">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </nav>

        <!-- Zone 3: Primary Actions & Dataset Selector -->
        <div class="flex items-center gap-2 shrink-0">
          <!-- Active Dataset Selector -->
          <div class="relative flex items-center">
            <mat-icon class="absolute left-2.5 text-slate-400 text-sm pointer-events-none">memory</mat-icon>
            <select 
              [value]="dataService.selectedDatasetId()"
              (change)="onDatasetChange($event)"
              aria-label="Active Radiometric Dataset"
              class="pl-8 pr-8 py-1.5 bg-slate-900 border border-slate-700/80 rounded-lg text-xs font-mono text-slate-200 hover:border-slate-600 focus:border-amber-500 focus:outline-none cursor-pointer appearance-none">
              @for (d of dataService.datasets(); track d.id) {
                <option [value]="d.id">
                  [{{ d.bandType }}] {{ d.name }}
                </option>
              }
            </select>
            <mat-icon class="absolute right-2 text-slate-400 text-xs pointer-events-none">arrow_drop_down</mat-icon>
          </div>

          <!-- Quick Simulation Lab Trigger -->
          <button 
            (click)="dataService.activeTab.set('sensor-lab')"
            class="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap">
            <mat-icon class="text-sm">tune</mat-icon>
            <span>Sensor Lab</span>
          </button>

          <!-- Report Generator -->
          <button 
            (click)="dataService.activeTab.set('inspection-report')"
            class="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap">
            <mat-icon class="text-sm">description</mat-icon>
            <span class="hidden md:inline">Generate Report</span>
          </button>
        </div>
      </div>

      <!-- Mobile/Tablet Secondary Nav Bar -->
      <div class="lg:hidden flex items-center gap-1 overflow-x-auto px-4 py-2 border-t border-slate-900 bg-slate-950/90 text-xs scrollbar-none">
        @for (tab of navTabs; track tab.id) {
          <button 
            (click)="dataService.activeTab.set(tab.id)"
            class="px-2 py-1 rounded whitespace-nowrap shrink-0 flex items-center gap-1 text-[11px]"
            [class.bg-slate-800]="dataService.activeTab() === tab.id"
            [class.text-amber-400]="dataService.activeTab() === tab.id"
            [class.text-slate-400]="dataService.activeTab() !== tab.id">
            <mat-icon class="text-xs leading-none">{{ tab.icon }}</mat-icon>
            <span>{{ tab.label }}</span>
          </button>
        }
      </div>
    </header>
  `
})
export class TopNavComponent {
  public readonly dataService = inject(AardvarkDataService);

  public readonly navTabs: { id: ActiveNavTab; label: string; icon: string }[] = [
    { id: 'workstation', label: 'Workstation', icon: 'visibility' },
    { id: 'sensor-lab', label: 'Sensor Lab', icon: 'videocam' },
    { id: 'calibration-lab', label: 'Calibration NUC', icon: 'calculate' },
    { id: 'blackbody-lab', label: 'Planck Radiometry', icon: 'insights' },
    { id: 'hyperspectral', label: 'Hyperspectral', icon: 'grid_view' },
    { id: 'digital-twin', label: 'Digital Twin', icon: 'precision_manufacturing' },
    { id: 'anomaly-engine', label: 'Anomalies', icon: 'warning' },
    { id: 'fusion-registration', label: 'Fusion & Reg', icon: 'layers' },
    { id: 'uncertainty-lab', label: 'GUM Uncertainty', icon: 'bar_chart' },
    { id: 'pipeline-graph', label: 'DAG Pipeline', icon: 'account_tree' },
    { id: 'benchmark-lab', label: 'Benchmarks', icon: 'speed' },
    { id: 'imaging-assistant', label: 'Imaging Intelligence', icon: 'psychology' },
    { id: 'code-repository', label: 'Code & Architecture', icon: 'code' }
  ];

  public onDatasetChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    if (target && target.value) {
      this.dataService.selectedDatasetId.set(target.value);
    }
  }
}
