import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';
import { ProcessingHistoryNode } from '../../models/infrared.models';

@Component({
  selector: 'app-pipeline-graph',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">account_tree</mat-icon>
            <span>Computational Processing Graph · Immutable Provenance</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            Aardvark Node-Based Computational Image Pipeline
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Complete provenance tracking: Every photon measurement is recorded from raw detector analog-to-digital units (DN) through Rust SIMD kernels, Python scientific solvers, R uncertainty models, to the final engineering report.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-emerald-400 font-bold">
            Pipeline Runtime: 4.85 ms (206 FPS)
          </div>
        </div>
      </div>

      <!-- Main Layout: Visual DAG Left (Flex-1) + Selected Node Inspector Right (380px) -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Node DAG Visual Stage (2 Cols) -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-white font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-cyan-400">hub</mat-icon>
              <span>Execution Directed Acyclic Graph (DAG)</span>
            </span>
            <span class="font-mono text-[10px] text-slate-400">Click any node to inspect parameters</span>
          </div>

          <!-- DAG Node Flow List -->
          <div class="space-y-3 font-mono text-xs">
            @for (node of pipelineNodes; track node.id; let idx = $index) {
              <button 
                type="button"
                (click)="selectedNode.set(node)"
                class="w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 shadow-md"
                [class.bg-slate-800]="selectedNode().id === node.id"
                [class.border-amber-500]="selectedNode().id === node.id"
                [class.bg-slate-950]="selectedNode().id !== node.id"
                [class.border-slate-800]="selectedNode().id !== node.id">
                
                <div class="flex items-center gap-3">
                  <div 
                    class="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs"
                    [class.bg-emerald-950]="node.engine === 'Rust_Core'"
                    [class.text-emerald-400]="node.engine === 'Rust_Core'"
                    [class.border]="true"
                    [class.border-emerald-800]="node.engine === 'Rust_Core'"
                    [class.bg-cyan-950]="node.engine === 'Python_Scientific'"
                    [class.text-cyan-400]="node.engine === 'Python_Scientific'"
                    [class.border-cyan-800]="node.engine === 'Python_Scientific'"
                    [class.bg-indigo-950]="node.engine === 'R_Statistical'"
                    [class.text-indigo-400]="node.engine === 'R_Statistical'"
                    [class.border-indigo-800]="node.engine === 'R_Statistical'">
                    {{ idx + 1 }}
                  </div>

                  <div>
                    <div class="font-bold text-white text-xs">{{ node.stageName }}</div>
                    <div class="text-[11px] text-slate-400">{{ node.algorithm }}</div>
                  </div>
                </div>

                <div class="flex items-center gap-3 text-[11px]">
                  <span 
                    class="px-2 py-0.5 rounded text-[10px] font-bold uppercase"
                    [class.bg-emerald-950]="node.engine === 'Rust_Core'"
                    [class.text-emerald-400]="node.engine === 'Rust_Core'"
                    [class.bg-cyan-950]="node.engine === 'Python_Scientific'"
                    [class.text-cyan-400]="node.engine === 'Python_Scientific'"
                    [class.bg-indigo-950]="node.engine === 'R_Statistical'"
                    [class.text-indigo-400]="node.engine === 'R_Statistical'">
                    {{ node.engine }}
                  </span>
                  <span class="text-amber-400 tabular-nums font-bold">{{ node.runtimeMs }} ms</span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Right: Node Parameter Inspector -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="font-bold text-white uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-amber-400">info</mat-icon>
              <span>Node Inspector</span>
            </span>
            <span class="text-emerald-400 font-bold">{{ selectedNode().engine }}</span>
          </div>

          <div class="space-y-3">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
              <div class="text-slate-400 text-[10px]">STAGE NAME:</div>
              <div class="text-white font-bold text-sm">{{ selectedNode().stageName }}</div>
              <div class="text-amber-400 text-[11px]">{{ selectedNode().algorithm }}</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
              <div class="text-slate-400 text-[10px] uppercase">Engine Execution Parameters:</div>
              <div class="space-y-1 text-[11px]">
                @for (entry of getParamEntries(selectedNode().parameters); track entry.key) {
                  <div class="flex justify-between border-b border-slate-900 pb-1">
                    <span class="text-slate-400">{{ entry.key }}:</span>
                    <span class="text-white font-bold">{{ entry.value }}</span>
                  </div>
                }
              </div>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1 text-[10px]">
              <div class="text-slate-400 uppercase">Cryptographic Hashes:</div>
              <div>Input: <span class="text-slate-300">{{ selectedNode().inputChecksum }}</span></div>
              <div>Output: <span class="text-slate-300">{{ selectedNode().outputChecksum }}</span></div>
              <div>Timestamp: <span class="text-emerald-400">{{ selectedNode().timestamp }}</span></div>
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class PipelineGraphComponent {
  private readonly dataService = inject(AardvarkDataService);

  public readonly pipelineNodes: ProcessingHistoryNode[] = [
    {
      id: 'node-01',
      stageName: 'RAW Detector Frame Ingestion',
      algorithm: 'AardvarkStreamDecoders::unpack_14bit_packed',
      engine: 'Rust_Core',
      version: '1.4.2',
      runtimeMs: 0.42,
      inputChecksum: 'sha256:7f8a91b2c3...',
      outputChecksum: 'sha256:4d8e72f1a0...',
      parameters: { gain: 'High', pixel_pitch_um: 12.0, endianness: 'little' },
      timestamp: '2026-10-01T14:22:18.421Z'
    },
    {
      id: 'node-02',
      stageName: 'Non-Uniformity Correction (NUC) & BPM',
      algorithm: 'AardvarkSimd::apply_multipoint_nuc_avx2',
      engine: 'Rust_Core',
      version: '2.1.0',
      runtimeMs: 0.28,
      inputChecksum: 'sha256:4d8e72f1a0...',
      outputChecksum: 'sha256:9a0b1c2d3e...',
      parameters: { cal_id: 'CAL-2026-NUC-094', bad_pixel_interp: 'median_3x3', simd_lanes: 8 },
      timestamp: '2026-10-01T14:22:18.422Z'
    },
    {
      id: 'node-03',
      stageName: 'Sub-Pixel Homography Registration',
      algorithm: 'AardvarkRegistration::warp_projective_simd',
      engine: 'Rust_Core',
      version: '3.0.0',
      runtimeMs: 0.95,
      inputChecksum: 'sha256:9a0b1c2d3e...',
      outputChecksum: 'sha256:bb33cc44dd...',
      parameters: { transform: '3x3_Homography', interpolation: 'bicubic_spline' },
      timestamp: '2026-10-01T14:22:18.423Z'
    },
    {
      id: 'node-04',
      stageName: 'Planck Inversion & Atmospheric Radiometry',
      algorithm: 'aardvark.radiometry.solve_object_temperature',
      engine: 'Python_Scientific',
      version: '3.8.4',
      runtimeMs: 1.15,
      inputChecksum: 'sha256:bb33cc44dd...',
      outputChecksum: 'sha256:e5f6a7b8c9...',
      parameters: { emissivity: 0.94, distance_m: 6.5, rh_percent: 82.0, solver: 'modtran_fast' },
      timestamp: '2026-10-01T14:22:18.424Z'
    },
    {
      id: 'node-05',
      stageName: 'Digital Twin Spatial Residual Synthesis',
      algorithm: 'aardvark.digital_twin.compute_spatial_residual',
      engine: 'Python_Scientific',
      version: '2.2.0',
      runtimeMs: 1.40,
      inputChecksum: 'sha256:e5f6a7b8c9...',
      outputChecksum: 'sha256:1122334455...',
      parameters: { twin_asset_id: 'twin-northsea-turbine-01', tolerance_c: 15.0 },
      timestamp: '2026-10-01T14:22:18.426Z'
    },
    {
      id: 'node-06',
      stageName: 'GUM Uncertainty & ANOVA Analysis',
      algorithm: 'aardvark_uncertainty_gum_monte_carlo',
      engine: 'R_Statistical',
      version: '4.4.1',
      runtimeMs: 0.65,
      inputChecksum: 'sha256:1122334455...',
      outputChecksum: 'sha256:9988776655...',
      parameters: { iterations: 10000, confidence_level: 0.95, arrow_ipc: true },
      timestamp: '2026-10-01T14:22:18.428Z'
    }
  ];

  public readonly selectedNode = signal<ProcessingHistoryNode>(this.pipelineNodes[1]);

  public getParamEntries(params: Record<string, string | number | boolean>): { key: string; value: string | number | boolean }[] {
    return Object.entries(params).map(([key, value]) => ({ key, value }));
  }
}
