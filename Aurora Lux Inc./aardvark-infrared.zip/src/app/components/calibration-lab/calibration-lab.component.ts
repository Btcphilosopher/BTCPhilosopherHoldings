import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from '../../services/aardvark-data.service';

@Component({
  selector: 'app-calibration-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-[1440px] mx-auto px-4 py-6 space-y-6 text-slate-200">
      
      <!-- Header -->
      <div class="border-b border-slate-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
            <mat-icon class="text-sm">calculate</mat-icon>
            <span>Radiometric Calibration & Metrology Lab</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-white font-['Space_Grotesk']">
            NUC Calibration, Bad Pixel Mapping & Polynomial Fit
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-2xl">
            Multi-point non-uniformity correction (NUC), dark-frame subtraction, FPA gain/offset normalization, and high-order polynomial blackbody calibration.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <div class="bg-slate-900 border border-slate-700 px-3 py-1.5 rounded-lg font-mono text-xs text-amber-400">
            CERT: {{ dataset().calibration.calibrationId }} (v{{ dataset().calibration.version }})
          </div>
        </div>
      </div>

      <!-- 3-Panel Side-by-Side Comparison: RAW -> CALIBRATED -> RESIDUAL -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Panel 1: RAW Uncorrected Frame -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col space-y-3 shadow-lg">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-300 font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-rose-400">grid_off</mat-icon>
              <span>01. RAW Detector DN</span>
            </span>
            <span class="text-[10px] font-mono text-slate-500">Uncorrected 14-bit</span>
          </div>

          <!-- Synthetic RAW canvas preview -->
          <div class="aspect-[4/3] bg-black rounded-lg border border-slate-800 flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-black opacity-90"></div>
            <!-- Vignetting + Noise simulation -->
            <div class="absolute inset-4 rounded-full border border-slate-700/30 opacity-40"></div>
            <div class="absolute inset-10 rounded-full border border-slate-700/20 opacity-30"></div>
            <div class="relative z-10 text-center font-mono space-y-1">
              <div class="text-amber-300 text-xs font-bold">RAW DN MATRIX</div>
              <div class="text-slate-500 text-[11px]">{{ dataset().width }} × {{ dataset().height }}</div>
              <div class="text-rose-400 text-[10px]">+{{ dataset().calibration.badPixelsCount }} Bad Pixels Detected</div>
            </div>
          </div>

          <div class="space-y-1 font-mono text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span>Dark Offset:</span>
              <span class="text-white">{{ dataset().analogOffsetDn }} DN</span>
            </div>
            <div class="flex justify-between">
              <span>Raw Vignetting:</span>
              <span class="text-rose-400">14.2% cos⁴(θ)</span>
            </div>
            <div class="flex justify-between">
              <span>PRNU (Raw):</span>
              <span class="text-rose-400">1.45%</span>
            </div>
          </div>
        </div>

        <!-- Panel 2: Radiometrically Calibrated Frame -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col space-y-3 shadow-lg">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-300 font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-emerald-400">done_all</mat-icon>
              <span>02. Calibrated Thermal</span>
            </span>
            <span class="text-[10px] font-mono text-emerald-400">NUC + BPM Applied</span>
          </div>

          <div class="aspect-[4/3] bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-tr from-indigo-950 via-slate-900 to-amber-950/40"></div>
            <div class="relative z-10 text-center font-mono space-y-1">
              <div class="text-emerald-400 text-xs font-bold">APPARENT TEMPERATURE</div>
              <div class="text-slate-300 text-[11px]">Ironbow Radiometric Field</div>
              <div class="text-emerald-300 text-[10px]">NETD: {{ dataset().calibration.temporalNetd }} mK (σ = 0.032 K)</div>
            </div>
          </div>

          <div class="space-y-1 font-mono text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span>NUC Model:</span>
              <span class="text-white">{{ dataset().calibration.nucType }}</span>
            </div>
            <div class="flex justify-between">
              <span>Poly Order:</span>
              <span class="text-white">{{ dataset().calibration.polynomialOrder }} (Cubic Spline)</span>
            </div>
            <div class="flex justify-between">
              <span>PRNU (Corrected):</span>
              <span class="text-emerald-400">{{ dataset().calibration.spatialNonUniformityPrnu }}%</span>
            </div>
          </div>
        </div>

        <!-- Panel 3: Calibration Residual Error -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col space-y-3 shadow-lg">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-300 font-mono uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-cyan-400">query_stats</mat-icon>
              <span>03. Residual Error (K)</span>
            </span>
            <span class="text-[10px] font-mono text-cyan-400">RMS: {{ dataset().calibration.residualRmsError }} K</span>
          </div>

          <div class="aspect-[4/3] bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-center relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-r from-blue-950/40 via-slate-900 to-cyan-950/40"></div>
            <div class="relative z-10 text-center font-mono space-y-1">
              <div class="text-cyan-400 text-xs font-bold">RESIDUAL MAP ΔT</div>
              <div class="text-slate-400 text-[11px]">Measured vs Mikron M390 Standard</div>
              <div class="text-cyan-300 text-[10px]">R² Coefficient = 0.99984</div>
            </div>
          </div>

          <div class="space-y-1 font-mono text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <div class="flex justify-between">
              <span>Mean Bias:</span>
              <span class="text-white">+0.004 K</span>
            </div>
            <div class="flex justify-between">
              <span>Peak Deviation:</span>
              <span class="text-amber-400">±0.062 K</span>
            </div>
            <div class="flex justify-between">
              <span>Standard Dev:</span>
              <span class="text-emerald-400">0.038 K</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Bottom Calibration Details & Metrology Traceability -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Left: Polynomial Calibration Curve Graph -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="font-mono text-xs font-bold text-white uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-amber-400">show_chart</mat-icon>
              <span>Blackbody Transfer Characteristic: DN → Radiance</span>
            </span>
            <span class="font-mono text-[11px] text-slate-400">Order 3 Polynomial</span>
          </div>

          <!-- SVG Calibration Fit Curve -->
          <div class="h-44 w-full bg-slate-950 rounded-lg border border-slate-800 p-3 relative flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 400 140" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="40" y1="20" x2="380" y2="20" stroke="#1e293b" stroke-dasharray="2 2" />
              <line x1="40" y1="60" x2="380" y2="60" stroke="#1e293b" stroke-dasharray="2 2" />
              <line x1="40" y1="100" x2="380" y2="100" stroke="#1e293b" stroke-dasharray="2 2" />
              <!-- Calibration Curve -->
              <path d="M 50 120 Q 180 80 370 25" fill="none" stroke="#f59e0b" stroke-width="2.5" />
              <!-- Blackbody Reference Points -->
              <circle cx="50" cy="120" r="4" fill="#06b6d4" />
              <circle cx="120" cy="102" r="4" fill="#06b6d4" />
              <circle cx="210" cy="74" r="4" fill="#06b6d4" />
              <circle cx="300" cy="46" r="4" fill="#06b6d4" />
              <circle cx="370" cy="25" r="4" fill="#06b6d4" />
            </svg>
          </div>

          <div class="flex items-center justify-between font-mono text-[10px] text-slate-400">
            <span class="flex items-center gap-1 text-cyan-400">
              <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
              <span>NIST/NPL Reference Blackbody Points (20°C, 50°C, 100°C, 150°C, 250°C)</span>
            </span>
            <span class="text-amber-400">f(DN) = a₀ + a₁·DN + a₂·DN² + a₃·DN³</span>
          </div>
        </div>

        <!-- Right: Metrology Certificate -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="font-bold text-white uppercase flex items-center gap-1.5">
              <mat-icon class="text-sm text-emerald-400">verified</mat-icon>
              <span>Metrology Calibration Certificate</span>
            </span>
            <span class="text-[10px] text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded">
              VALIDATED
            </span>
          </div>

          <div class="space-y-2 text-slate-300 text-[11px]">
            <div class="grid grid-cols-2 gap-2">
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 block text-[10px]">Laboratory:</span>
                <span class="font-bold text-white">{{ dataset().calibration.laboratory }}</span>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-800">
                <span class="text-slate-500 block text-[10px]">Traceability Standard:</span>
                <span class="font-bold text-white">{{ dataset().calibration.standardReference }}</span>
              </div>
            </div>

            <div class="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-400">Certificate ID:</span>
                <span class="text-amber-400 font-bold">{{ dataset().calibration.calibrationId }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Calibration Date:</span>
                <span class="text-white">{{ dataset().calibration.calibrationDate }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Calibrated Temp Range:</span>
                <span class="text-white">{{ dataset().calibration.temperatureRange[0] }} °C to {{ dataset().calibration.temperatureRange[1] }} °C</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Residual RMS Uncertainty:</span>
                <span class="text-emerald-400 font-bold">±{{ dataset().calibration.residualRmsError }} K</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Cryptographic Seal:</span>
                <span class="text-slate-500 text-[10px]">sha256:8f4c2e1b99a0d...</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class CalibrationLabComponent {
  private readonly dataService = inject(AardvarkDataService);
  public readonly dataset = this.dataService.currentDataset;
}
