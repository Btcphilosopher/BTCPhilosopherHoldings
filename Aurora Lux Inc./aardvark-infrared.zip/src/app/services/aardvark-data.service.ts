import { Injectable, signal, computed } from '@angular/core';
import { 
  InfraredDataset, 
  DigitalTwinAsset, 
  MaterialSpectralReference, 
  ThermalAnomaly, 
  BenchmarkResult, 
  RoiMeasurement,
  SpectralBand,
  DetectorType
} from '../models/infrared.models';

@Injectable({
  providedIn: 'root'
})
export class AardvarkDataService {
  // Active selected dataset
  public readonly selectedDatasetId = signal<string>('dataset-north-sea-01');

  // Active active view tab / workstation mode
  public readonly activeTab = signal<
    'workstation' | 
    'sensor-lab' | 
    'calibration-lab' | 
    'blackbody-lab' | 
    'hyperspectral' | 
    'digital-twin' | 
    'anomaly-engine' | 
    'fusion-registration' | 
    'uncertainty-lab' | 
    'pipeline-graph' | 
    'benchmark-lab' | 
    'imaging-assistant' | 
    'code-repository' | 
    'inspection-report'
  >('workstation');

  // Datasets list
  public readonly datasets = signal<InfraredDataset[]>([]);

  // Digital Twin Assets
  public readonly digitalTwins = signal<DigitalTwinAsset[]>([]);

  // Spectral Material Reference Library
  public readonly materialLibrary = signal<MaterialSpectralReference[]>([]);

  // Benchmarks
  public readonly benchmarks = signal<BenchmarkResult[]>([]);

  // Active dataset computed
  public readonly currentDataset = computed(() => {
    const list = this.datasets();
    const id = this.selectedDatasetId();
    return list.find(d => d.id === id) || list[0];
  });

  // Active asset computed
  public readonly currentDigitalTwin = computed(() => {
    const d = this.currentDataset();
    if (!d) return this.digitalTwins()[0];
    return this.digitalTwins().find(t => t.facilityName === d.facility) || this.digitalTwins()[0];
  });

  constructor() {
    this.initializeDatasets();
    this.initializeDigitalTwins();
    this.initializeMaterialLibrary();
    this.initializeBenchmarks();
  }

  private initializeDatasets(): void {
    const northSeaData = this.generateNorthSeaDataset();
    const manchesterData = this.generateManchesterDataset();
    const metrologyData = this.generateMetrologyDataset();
    this.datasets.set([northSeaData, manchesterData, metrologyData]);
  }

  /**
   * Generates deterministic North Sea Gas Turbine & Steam Pipeline dataset
   */
  private generateNorthSeaDataset(): InfraredDataset {
    const width = 128;
    const height = 96;
    const rawDnMatrix: number[][] = [];
    const calibratedMatrix: number[][] = [];
    const radianceMatrix: number[][] = [];

    // Background offshore ambient ~8.5 deg C (281.65 K)
    const baseTemp = 8.5;
    for (let y = 0; y < height; y++) {
      const rawRow: number[] = [];
      const calRow: number[] = [];
      const radRow: number[] = [];
      for (let x = 0; x < width; x++) {
        // Physical geometry synthesis:
        // Turbine casing in center: (40..85, 30..65), temp ~85-115 C
        // Overheating high-pressure bearing at (52, 48), hotspot ~148.6 C
        // High-pressure steam manifold header: (15..110, 72..82), temp ~78 C with lagging defect at (32..38, 72..82) ~94.2 C
        // Electrical transformer bushings at top-right (95..115, 15..32) with phase B delta-T ~68 C
        let temp = baseTemp + (Math.sin(x * 0.05) * 0.4) + (Math.cos(y * 0.08) * 0.3);

        // Turbine Body
        if (x >= 40 && x <= 88 && y >= 28 && y <= 66) {
          const dx = (x - 64) / 24;
          const dy = (y - 47) / 19;
          const r = Math.sqrt(dx * dx + dy * dy);
          if (r <= 1.0) {
            temp = 92.0 + (1.0 - r) * 28.0 + (Math.sin(x * 0.5) * 2.1);
          }
        }

        // Bearing Overheating Fault at (52, 47)
        const dxb = x - 52;
        const dyb = y - 47;
        const rb = Math.sqrt(dxb * dxb + dyb * dyb);
        if (rb < 9.0) {
          temp += (1.0 - rb / 9.0) * 44.5; // reaches ~148.6 C
        }

        // Steam Header Pipeline
        if (y >= 70 && y <= 80 && x >= 12 && x <= 116) {
          temp = 72.5 + Math.sin(x * 0.1) * 3.5;
          // Insulation Degradation Leak at (34, 75)
          const dxl = x - 34;
          const dyl = y - 75;
          const rl = Math.sqrt(dxl * dxl + dyl * dyl);
          if (rl < 7.0) {
            temp += (1.0 - rl / 7.0) * 26.8; // reaches ~99 C
          }
        }

        // Substation Bushing Phase B hotspot at (104, 22)
        const dxp = x - 104;
        const dyp = y - 22;
        const rp = Math.sqrt(dxp * dxp + dyp * dyp);
        if (rp < 6.0) {
          temp += (1.0 - rp / 6.0) * 58.0;
        }

        // Deterministic high-precision detector NETD noise (~0.035 K)
        const pseudoNoise = (Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1;
        temp += (pseudoNoise - 0.5) * 0.07;

        // Radiometric conversion: Temp (C) -> Radiance W/(m^2*sr*um) -> Raw 14-bit DN (0..16383)
        const tempK = temp + 273.15;
        // LWIR integrated radiance approximation in 8-14um
        const radiance = 0.00015 * Math.pow(tempK / 100, 3.85);
        // Detector transfer function: DN = Gain * Radiance + Offset
        const gain = 1420.0;
        const offset = 1024.0;
        const rawDn = Math.round(gain * radiance + offset);

        rawRow.push(rawDn);
        calRow.push(Math.round(temp * 100) / 100);
        radRow.push(Math.round(radiance * 1000) / 1000);
      }
      rawDnMatrix.push(rawRow);
      calMatrix(calibratedMatrix, calRow);
      radianceMatrix.push(radRow);
    }

    function calMatrix(target: number[][], row: number[]) {
      target.push(row);
    }

    const rois: RoiMeasurement[] = [
      {
        id: 'roi-bearing-1',
        label: 'HP Turbine Thrust Bearing #1',
        type: 'box',
        color: '#ef4444',
        x: 46,
        y: 40,
        width: 14,
        height: 14,
        emissivity: 0.94,
        minTempC: 98.4,
        maxTempC: 148.6,
        meanTempC: 126.8,
        stdDevTempC: 14.2,
        deltaAmbientC: 140.1,
        pixelCount: 196,
        radianceMean: 24.8,
        uncertaintyU95C: 0.42
      },
      {
        id: 'roi-steam-insulation',
        label: 'HP Steam Header Jacket Failure',
        type: 'box',
        color: '#f59e0b',
        x: 28,
        y: 70,
        width: 14,
        height: 11,
        emissivity: 0.88,
        minTempC: 72.1,
        maxTempC: 99.3,
        meanTempC: 86.4,
        stdDevTempC: 7.9,
        deltaAmbientC: 77.9,
        pixelCount: 154,
        radianceMean: 17.6,
        uncertaintyU95C: 0.38
      },
      {
        id: 'roi-line-profile',
        label: 'Axial Thermal Gradient Transect',
        type: 'line',
        color: '#06b6d4',
        x: 35,
        y: 47,
        x2: 90,
        y2: 47,
        emissivity: 0.94,
        minTempC: 76.2,
        maxTempC: 148.6,
        meanTempC: 104.5,
        stdDevTempC: 22.1,
        deltaAmbientC: 96.0,
        pixelCount: 56,
        radianceMean: 21.0,
        uncertaintyU95C: 0.40,
        profileValues: [
          76.2, 78.4, 82.1, 88.0, 96.5, 110.2, 128.4, 142.1, 148.6, 145.2, 
          131.0, 114.5, 102.1, 98.0, 96.2, 95.0, 94.8, 94.2, 93.8, 93.1, 
          92.5, 91.8, 90.4, 88.2, 85.1, 82.0, 79.1, 74.5
        ]
      }
    ];

    const anomalies: ThermalAnomaly[] = [
      {
        id: 'anom-ns-01',
        severity: 'CRITICAL_OVERHEAT',
        component: 'High-Pressure Turbine Thrust Bearing #1',
        assetLocation: 'Turbine Hall Bay 3, Skid Alpha',
        observedTempC: 148.6,
        predictedTempC: 92.4,
        deltaTempC: 56.2,
        thresholdC: 15.0,
        isoClassification: 'ISO 18434-1 Category IV (Action Required Immediately)',
        physicalCause: 'Hydrodynamic oil film collapse / severe boundary lubrication friction heating on axial thrust collar.',
        recommendation: 'Immediate load shedding, lube oil particulate flush, vibration spectrum FFT analysis of 1X/2X harmonics.',
        confidenceScore: 0.985,
        evidence: [
          { type: 'MEASURED', description: 'LWIR 8-14um radiometrically calibrated peak surface temperature 148.6 +/- 0.42 deg C.' },
          { type: 'MODELLED', description: 'Finite-element digital twin predicts 92.4 deg C under 84% nominal generator load.' },
          { type: 'CALCULATED', description: 'Spatial temperature gradient dT/dx exceeds 12.4 deg C/cm.' }
        ]
      },
      {
        id: 'anom-ns-02',
        severity: 'SEVERE_FAULT',
        component: 'High-Pressure Steam Header Lagging',
        assetLocation: 'Process Piping Header 400-HPS-012',
        observedTempC: 99.3,
        predictedTempC: 42.0,
        deltaTempC: 57.3,
        thresholdC: 25.0,
        isoClassification: 'ASTM C1060 Standard Practice for Thermographic Inspection',
        physicalCause: 'Cal-Sil / Mineral wool insulation moisture ingress and outer cladding breach causing localized conduction bypass.',
        recommendation: 'Replace wet insulation section, repair aluminium weather-jacket seal to prevent thermal energy waste.',
        confidenceScore: 0.962,
        evidence: [
          { type: 'MEASURED', description: 'Surface radiance elevated to 17.6 W/(m^2*sr*um).' },
          { type: 'CALCULATED', description: 'Convective heat loss estimated at 1,420 W/m^2 over affected 0.85 m^2 zone.' }
        ]
      }
    ];

    return {
      id: 'dataset-north-sea-01',
      name: 'North Sea Facility — Gas Turbine Skid & HP Steam Manifold',
      facility: 'North Sea Energy Facility',
      acquisitionTimestamp: '2026-10-01T14:22:18.420Z',
      wavelengthRange: [8.0, 14.0],
      bandType: 'LWIR',
      bandsCount: 1,
      width,
      height,
      pixelPitchUm: 12.0,
      detectorType: 'VOx_Microbolometer',
      lensConfiguration: '50mm f/1.0 Athermalized Germanium Triplet',
      fieldOfViewDeg: [24.6, 18.5],
      integrationTimeUs: 1450,
      gainSetting: 'High',
      analogOffsetDn: 1024,
      frameRateHz: 60,
      detectorTemperatureK: 298.15,
      radiometricUnits: 'APPARENT_TEMP_C',
      calibration: {
        calibrationId: 'CAL-2026-NUC-094',
        version: '3.4.1',
        calibrationDate: '2026-09-15',
        laboratory: 'Aardvark Radiometry Metrology Cell B, Manchester',
        standardReference: 'NPL / NIST Traceable Mikron M390 Blackbody Cavity',
        darkFrameApplied: true,
        nucType: 'MultiPoint_Polynomial',
        badPixelsCount: 14,
        residualRmsError: 0.038,
        spatialNonUniformityPrnu: 0.09,
        temporalNetd: 32, // 32 mK
        polynomialOrder: 3,
        fitCoefficients: [1024.2, 1419.8, -1.24, 0.008],
        temperatureRange: [-20, 250]
      },
      atmospheric: {
        distanceMeters: 6.5,
        ambientTemperatureC: 8.5,
        reflectedTemperatureC: 7.8,
        relativeHumidityPercent: 82.0,
        emissivity: 0.94,
        transmissionTau: 0.962,
        pathRadiance: 0.28
      },
      simulation: {
        isSimulated: true,
        simulationSeed: 198402,
        physicalModel: 'Navier-Stokes Thermal Conjugate Heat Transfer (OpenFOAM v2406)',
        softwareVersion: 'Aardvark-Core v4.2.0-rust-simd',
        engine: 'Rust SIMD + Python Orchestrator',
        generatedTimestamp: '2026-10-01T14:22:00.000Z',
        noiseParameters: {
          photonNoiseLevel: 0.012,
          readNoiseElectrons: 45,
          darkCurrentDnA: 18.5,
          fpaTempStabilityK: 0.02
        }
      },
      uncertainty: {
        combinedStandardUncertaintyC: 0.21,
        expandedUncertaintyU95C: 0.42,
        coverageFactor: 2.0,
        components: {
          detectorNoiseU1: 0.032,
          calibrationResidualU2: 0.038,
          emissivityUncertaintyU3: 0.165,
          reflectedTempUncertaintyU4: 0.085,
          atmosphericTransUncertaintyU5: 0.042,
          ambientTempDriftU6: 0.028
        }
      },
      provenanceHistory: [
        {
          id: 'node-01',
          stageName: 'RAW Detector Frame Ingestion',
          algorithm: 'AardvarkStreamDecoders::unpack_14bit_packed',
          engine: 'Rust_Core',
          version: '1.4.2',
          runtimeMs: 0.42,
          inputChecksum: 'sha256:7f8a91b2c3...',
          outputChecksum: 'sha256:4d8e72f1a0...',
          parameters: { gain: 'High', pixel_pitch_um: 12.0 },
          timestamp: '2026-10-01T14:22:18.421Z'
        },
        {
          id: 'node-02',
          stageName: 'Non-Uniformity Correction (NUC) & BPM',
          algorithm: 'AardvarkSimd::apply_multipoint_nuc_avx2',
          engine: 'Rust_Core',
          version: '2.1.0',
          runtimeMs: 0.28,
          inputChecksum: 'sha256:4d8e72f1a0...',
          outputChecksum: 'sha256:9a0b1c2d3e...',
          parameters: { cal_id: 'CAL-2026-NUC-094', bad_pixel_interp: 'median_3x3' },
          timestamp: '2026-10-01T14:22:18.422Z'
        },
        {
          id: 'node-03',
          stageName: 'Planck Inversion & Atmospheric Calibration',
          algorithm: 'aardvark.radiometry.solve_object_temperature',
          engine: 'Python_Scientific',
          version: '3.8.4',
          runtimeMs: 1.15,
          inputChecksum: 'sha256:9a0b1c2d3e...',
          outputChecksum: 'sha256:e5f6a7b8c9...',
          parameters: { emissivity: 0.94, distance_m: 6.5, rh_percent: 82.0 },
          timestamp: '2026-10-01T14:22:18.424Z'
        },
        {
          id: 'node-04',
          stageName: 'Digital Twin Residual Synthesis',
          algorithm: 'aardvark.digital_twin.compute_spatial_residual',
          engine: 'Python_Scientific',
          version: '2.2.0',
          runtimeMs: 3.40,
          inputChecksum: 'sha256:e5f6a7b8c9...',
          outputChecksum: 'sha256:1122334455...',
          parameters: { twin_asset_id: 'twin-northsea-turbine-01', tolerance_c: 15.0 },
          timestamp: '2026-10-01T14:22:18.428Z'
        }
      ],
      rawDnMatrix,
      calibratedMatrix,
      radianceMatrix,
      rois,
      anomalies
    };
  }

  /**
   * Generates Manchester Industrial Heritage Facility (Victorian Mill & Factory)
   */
  private generateManchesterDataset(): InfraredDataset {
    const width = 128;
    const height = 96;
    const rawDnMatrix: number[][] = [];
    const calibratedMatrix: number[][] = [];
    const radianceMatrix: number[][] = [];

    // Manchester cold winter ambient ~3.2 deg C
    const baseTemp = 3.2;

    for (let y = 0; y < height; y++) {
      const rawRow: number[] = [];
      const calRow: number[] = [];
      const radRow: number[] = [];
      for (let x = 0; x < width; x++) {
        // Red brick wall: (20..110, 15..85), base temp ~9.5 C (heated interior 21 C)
        // Single-pane historic sash windows with high thermal loss: (30..45, 25..45) and (65..80, 25..45) temp ~17.8 C
        // Concrete lintel thermal bridge at (25..105, 20..24) temp ~14.2 C
        // Roof parapet thermal bridge at (15..115, 10..15) temp ~12.5 C
        // Roof boiler exhaust flue stack at (92..102, 10..55) temp ~48.5 C
        let temp = baseTemp + (Math.sin(x * 0.04) * 0.3) + (Math.cos(y * 0.06) * 0.2);

        // Brick facade
        if (x >= 18 && x <= 112 && y >= 15 && y <= 85) {
          temp = 8.8 + (Math.sin(x * 0.8) * 0.4); // well-insulated brick
        }

        // Structural Steel / Concrete Lintel Thermal Bridge
        if (y >= 20 && y <= 24 && x >= 22 && x <= 108) {
          temp = 13.8 + Math.sin(x * 0.1) * 1.2;
        }

        // Window Bay 1 (Heavy Heat Loss)
        if (x >= 28 && x <= 46 && y >= 32 && y <= 56) {
          temp = 18.4 + Math.sin((x + y) * 0.2) * 1.5;
        }

        // Window Bay 2 (Double glazed replacement - Low Heat Loss)
        if (x >= 64 && x <= 82 && y >= 32 && y <= 56) {
          temp = 10.2 + Math.sin((x + y) * 0.2) * 0.8;
        }

        // Boiler flue stack (Manchester factory steam)
        if (x >= 92 && x <= 104 && y >= 8 && y <= 60) {
          const dfx = x - 98;
          temp = 48.0 - Math.abs(dfx) * 3.5 + (60 - y) * 0.2;
        }

        const pseudoNoise = (Math.sin(x * 23.45 + y * 91.12) * 23421.123) % 1;
        temp += (pseudoNoise - 0.5) * 0.06;

        const tempK = temp + 273.15;
        const radiance = 0.00014 * Math.pow(tempK / 100, 3.82);
        const rawDn = Math.round(1380.0 * radiance + 980.0);

        rawRow.push(rawDn);
        calRow.push(Math.round(temp * 100) / 100);
        radRow.push(Math.round(radiance * 1000) / 1000);
      }
      rawDnMatrix.push(rawRow);
      calibratedMatrix.push(calRow);
      radianceMatrix.push(radRow);
    }

    const rois: RoiMeasurement[] = [
      {
        id: 'roi-historic-window',
        label: 'Victorian Single-Glazed Sash Window #1',
        type: 'box',
        color: '#ef4444',
        x: 28,
        y: 32,
        width: 18,
        height: 24,
        emissivity: 0.91,
        minTempC: 15.2,
        maxTempC: 19.8,
        meanTempC: 18.2,
        stdDevTempC: 1.1,
        deltaAmbientC: 15.0,
        pixelCount: 432,
        radianceMean: 7.2,
        uncertaintyU95C: 0.32
      },
      {
        id: 'roi-concrete-lintel',
        label: 'Continuous Concrete Lintel Thermal Bridge',
        type: 'box',
        color: '#f59e0b',
        x: 22,
        y: 20,
        width: 40,
        height: 5,
        emissivity: 0.93,
        minTempC: 12.1,
        maxTempC: 14.9,
        meanTempC: 13.8,
        stdDevTempC: 0.6,
        deltaAmbientC: 10.6,
        pixelCount: 200,
        radianceMean: 6.4,
        uncertaintyU95C: 0.28
      }
    ];

    const anomalies: ThermalAnomaly[] = [
      {
        id: 'anom-mcr-01',
        severity: 'SEVERE_FAULT',
        component: 'South Facade Historic Glazing Envelope',
        assetLocation: 'Manchester Mill Building B, Floor 2 South',
        observedTempC: 18.2,
        predictedTempC: 8.5,
        deltaTempC: 9.7,
        thresholdC: 4.0,
        isoClassification: 'BS EN 13187 Thermal Performance of Buildings',
        physicalCause: 'Single pane 3mm glass with deteriorated perimeter mastic seal creating high U-value conductance (U = 5.2 W/m^2K) and infiltration.',
        recommendation: 'Install secondary low-e glazing or heritage vacuum insulated glass units (target U < 1.2 W/m^2K).',
        confidenceScore: 0.978,
        evidence: [
          { type: 'MEASURED', description: 'Exterior glass surface temp 18.2 deg C at ambient 3.2 deg C.' },
          { type: 'CALCULATED', description: 'Thermal loss 78.4 kWh/m^2 per winter annum.' }
        ]
      }
    ];

    return {
      id: 'dataset-manchester-01',
      name: 'Manchester Heritage Industrial Facility — Envelope & Steam Boiler',
      facility: 'Manchester Industrial Facility',
      acquisitionTimestamp: '2026-10-01T09:15:32.110Z',
      wavelengthRange: [8.0, 14.0],
      bandType: 'LWIR',
      bandsCount: 1,
      width,
      height,
      pixelPitchUm: 17.0,
      detectorType: 'aSi_Microbolometer',
      lensConfiguration: '25mm f/1.1 Germanium Wide-Angle',
      fieldOfViewDeg: [45.0, 34.0],
      integrationTimeUs: 2200,
      gainSetting: 'High',
      analogOffsetDn: 980,
      frameRateHz: 30,
      detectorTemperatureK: 295.4,
      radiometricUnits: 'APPARENT_TEMP_C',
      calibration: {
        calibrationId: 'CAL-2026-MCR-012',
        version: '2.8.0',
        calibrationDate: '2026-08-20',
        laboratory: 'Aardvark Manchester Optical Metrology Suite',
        standardReference: 'UKAS Accredited Blackbody Lab standard',
        darkFrameApplied: true,
        nucType: 'TwoPoint_Linear',
        badPixelsCount: 8,
        residualRmsError: 0.045,
        spatialNonUniformityPrnu: 0.11,
        temporalNetd: 40,
        polynomialOrder: 2,
        temperatureRange: [-10, 150]
      },
      atmospheric: {
        distanceMeters: 14.0,
        ambientTemperatureC: 3.2,
        reflectedTemperatureC: 2.5,
        relativeHumidityPercent: 88.0,
        emissivity: 0.92,
        transmissionTau: 0.948,
        pathRadiance: 0.22
      },
      simulation: {
        isSimulated: true,
        simulationSeed: 441029,
        physicalModel: 'Building Envelope 2D Transient Heat Diffusion (ISO 10211)',
        softwareVersion: 'Aardvark-Core v4.2.0-rust-simd',
        engine: 'Rust SIMD + Python Orchestrator',
        generatedTimestamp: '2026-10-01T09:15:00.000Z',
        noiseParameters: {
          photonNoiseLevel: 0.015,
          readNoiseElectrons: 60,
          darkCurrentDnA: 24.0,
          fpaTempStabilityK: 0.04
        }
      },
      uncertainty: {
        combinedStandardUncertaintyC: 0.24,
        expandedUncertaintyU95C: 0.48,
        coverageFactor: 2.0,
        components: {
          detectorNoiseU1: 0.040,
          calibrationResidualU2: 0.045,
          emissivityUncertaintyU3: 0.180,
          reflectedTempUncertaintyU4: 0.095,
          atmosphericTransUncertaintyU5: 0.065,
          ambientTempDriftU6: 0.035
        }
      },
      provenanceHistory: [
        {
          id: 'node-mcr-01',
          stageName: 'RAW Ingestion & Bad Pixel Repair',
          algorithm: 'AardvarkCodecs::decode_raw_radiometric',
          engine: 'Rust_Core',
          version: '1.4.2',
          runtimeMs: 0.38,
          inputChecksum: 'sha256:ab12cd34...',
          outputChecksum: 'sha256:ef56gh78...',
          parameters: { fov_deg: 45.0, lens_f: 1.1 },
          timestamp: '2026-10-01T09:15:32.112Z'
        },
        {
          id: 'node-mcr-02',
          stageName: 'Building Envelope ISO 13187 Heat Loss Analysis',
          algorithm: 'aardvark.thermal.building_envelope_u_value',
          engine: 'Python_Scientific',
          version: '3.8.4',
          runtimeMs: 2.10,
          inputChecksum: 'sha256:ef56gh78...',
          outputChecksum: 'sha256:99887766...',
          parameters: { interior_temp_c: 21.0, exterior_temp_c: 3.2 },
          timestamp: '2026-10-01T09:15:32.115Z'
        }
      ],
      rawDnMatrix,
      calibratedMatrix,
      radianceMatrix,
      rois,
      anomalies
    };
  }

  /**
   * Generates Stirling-cooled InSb/MCT Metrology Lab Dataset (MWIR 3.0 - 5.0 um)
   */
  private generateMetrologyDataset(): InfraredDataset {
    const width = 128;
    const height = 96;
    const rawDnMatrix: number[][] = [];
    const calibratedMatrix: number[][] = [];
    const radianceMatrix: number[][] = [];

    const baseTemp = 22.0;

    for (let y = 0; y < height; y++) {
      const rawRow: number[] = [];
      const calRow: number[] = [];
      const radRow: number[] = [];
      for (let x = 0; x < width; x++) {
        // High-precision Mikron Blackbody aperture at (64, 48) with step apertures at 50, 100, 200, 350 C
        let temp = baseTemp;
        const dx = x - 64;
        const dy = y - 48;
        const r = Math.sqrt(dx * dx + dy * dy);
        if (r < 18) {
          temp = 250.0 - (r / 18.0) * 1.5; // Cavity bottom ~250.0 C with emissivity 0.998
        } else if (r < 32) {
          temp = 45.0 + (1 - r / 32) * 20.0; // Water-cooled aperture plate
        }

        // Add ultra-low cryo NETD noise (~12 mK)
        const pseudoNoise = (Math.sin(x * 17.1 + y * 43.8) * 12345.67) % 1;
        temp += (pseudoNoise - 0.5) * 0.024;

        const tempK = temp + 273.15;
        // MWIR 3-5um radiance approximation
        const radiance = 0.00008 * Math.pow(tempK / 100, 4.2);
        const rawDn = Math.round(2450.0 * radiance + 512.0);

        rawRow.push(rawDn);
        calRow.push(Math.round(temp * 100) / 100);
        radRow.push(Math.round(radiance * 1000) / 1000);
      }
      rawDnMatrix.push(rawRow);
      calibratedMatrix.push(calRow);
      radianceMatrix.push(radRow);
    }

    return {
      id: 'dataset-metrology-01',
      name: 'Aardvark Metrology Suite — Stirling Cryo MCT 3-5µm Blackbody Cavity',
      facility: 'Aardvark Metrology Lab',
      acquisitionTimestamp: '2026-10-01T16:40:05.800Z',
      wavelengthRange: [3.0, 5.0],
      bandType: 'MWIR',
      bandsCount: 1,
      width,
      height,
      pixelPitchUm: 15.0,
      detectorType: 'MCT_Stirling_Cooled',
      lensConfiguration: '100mm f/2.0 Silicon/Germanium Doublet',
      fieldOfViewDeg: [11.0, 8.2],
      integrationTimeUs: 850,
      gainSetting: 'UltraHigh',
      analogOffsetDn: 512,
      frameRateHz: 120,
      detectorTemperatureK: 77.15, // Liquid Nitrogen equivalent Stirling cryo
      radiometricUnits: 'APPARENT_TEMP_C',
      calibration: {
        calibrationId: 'CAL-2026-CRYO-001',
        version: '4.0.0',
        calibrationDate: '2026-09-30',
        laboratory: 'National Physical Laboratory (NPL) Secondary Primary Standards',
        standardReference: 'NPL Reference Blackbody Standard #NPL-IR-884',
        darkFrameApplied: true,
        nucType: 'MultiPoint_Spline',
        badPixelsCount: 2,
        residualRmsError: 0.012,
        spatialNonUniformityPrnu: 0.04,
        temporalNetd: 14, // 14 mK Stirling MCT
        polynomialOrder: 4,
        temperatureRange: [10, 500]
      },
      atmospheric: {
        distanceMeters: 1.2,
        ambientTemperatureC: 22.0,
        reflectedTemperatureC: 21.8,
        relativeHumidityPercent: 45.0,
        emissivity: 0.998,
        transmissionTau: 0.994,
        pathRadiance: 0.05
      },
      simulation: {
        isSimulated: true,
        simulationSeed: 991823,
        physicalModel: 'Cavity Emissivity & Gouffe Radiative Integration',
        softwareVersion: 'Aardvark-Core v4.2.0-rust-simd',
        engine: 'Rust SIMD + Python Orchestrator',
        generatedTimestamp: '2026-10-01T16:40:00.000Z',
        noiseParameters: {
          photonNoiseLevel: 0.005,
          readNoiseElectrons: 18,
          darkCurrentDnA: 4.2,
          fpaTempStabilityK: 0.005
        }
      },
      uncertainty: {
        combinedStandardUncertaintyC: 0.08,
        expandedUncertaintyU95C: 0.16,
        coverageFactor: 2.0,
        components: {
          detectorNoiseU1: 0.014,
          calibrationResidualU2: 0.012,
          emissivityUncertaintyU3: 0.045,
          reflectedTempUncertaintyU4: 0.025,
          atmosphericTransUncertaintyU5: 0.018,
          ambientTempDriftU6: 0.010
        }
      },
      provenanceHistory: [
        {
          id: 'node-cryo-01',
          stageName: 'Cryo FPA Ingestion @ 77.15K',
          algorithm: 'AardvarkStreamDecoders::stream_mct_120fps',
          engine: 'Rust_Core',
          version: '1.4.2',
          runtimeMs: 0.18,
          inputChecksum: 'sha256:cc112233...',
          outputChecksum: 'sha256:dd445566...',
          parameters: { fpa_temp_k: 77.15, gain: 'UltraHigh' },
          timestamp: '2026-10-01T16:40:05.801Z'
        }
      ],
      rawDnMatrix,
      calibratedMatrix,
      radianceMatrix,
      rois: [],
      anomalies: []
    };
  }

  private initializeDigitalTwins(): void {
    const meshSize = 64;
    const northSeaTwin = this.createDigitalTwinAsset(
      'twin-north-sea-01',
      'North Sea Energy Facility',
      'Siemens SGT-800 Industrial Gas Turbine & Skid Alpha',
      'Turbomachinery',
      meshSize,
      84.0, // load %
      8.5,  // ambient C
      (x, y) => {
        // Physical predicted temperature field under 84% load
        const nx = (x - 32) / 20;
        const ny = (y - 32) / 16;
        const r = Math.sqrt(nx * nx + ny * ny);
        if (r <= 1.0) {
          return 92.4 + (1.0 - r) * 22.0;
        }
        return 8.5 + (Math.sin(x * 0.1) * 0.8);
      },
      (x, y, pred) => {
        // Injected fault in observation: bearing friction hotspot at (26, 24)
        const dxb = x - 26;
        const dyb = y - 24;
        const rb = Math.sqrt(dxb * dxb + dyb * dyb);
        if (rb < 6.0) {
          return pred + (1.0 - rb / 6.0) * 56.2; // creates observed ~148.6 C
        }
        return pred + (Math.random() - 0.5) * 0.4;
      }
    );

    const manchesterTwin = this.createDigitalTwinAsset(
      'twin-manchester-01',
      'Manchester Industrial Facility',
      'Victorian Red-Brick Factory South Facade & Steam Manifold',
      'Building Envelope',
      meshSize,
      75.0,
      3.2,
      (x, y) => {
        // Predicted building envelope heat conduction model
        if (x >= 12 && x <= 52 && y >= 10 && y <= 54) {
          return 8.5; // Well-insulated baseline wall
        }
        return 3.2;
      },
      (x, y, pred) => {
        // Observed thermal bridge and single glaze leakage
        if (x >= 16 && x <= 26 && y >= 20 && y <= 36) {
          return pred + 9.7; // window heat loss
        }
        return pred + (Math.random() - 0.5) * 0.3;
      }
    );

    this.digitalTwins.set([northSeaTwin, manchesterTwin]);
  }

  private createDigitalTwinAsset(
    id: string,
    facilityName: 'North Sea Energy Facility' | 'Manchester Industrial Facility',
    name: string,
    category: DigitalTwinAsset['category'],
    size: number,
    loadPercent: number,
    ambientTempC: number,
    predFn: (x: number, y: number) => number,
    obsFn: (x: number, y: number, pred: number) => number
  ): DigitalTwinAsset {
    const predicted: number[][] = [];
    const observed: number[][] = [];
    const residual: number[][] = [];
    let maxRes = 0;
    let sumRes = 0;

    for (let y = 0; y < size; y++) {
      const predRow: number[] = [];
      const obsRow: number[] = [];
      const resRow: number[] = [];
      for (let x = 0; x < size; x++) {
        const p = predFn(x, y);
        const o = obsFn(x, y, p);
        const r = o - p;
        predRow.push(Math.round(p * 10) / 10);
        obsRow.push(Math.round(o * 10) / 10);
        resRow.push(Math.round(r * 10) / 10);
        if (Math.abs(r) > maxRes) maxRes = Math.abs(r);
        sumRes += Math.abs(r);
      }
      predicted.push(predRow);
      observed.push(obsRow);
      residual.push(resRow);
    }

    const meanRes = sumRes / (size * size);

    return {
      id,
      facilityName,
      name,
      category,
      operatingConditions: {
        loadPercent,
        ambientTempC,
        windSpeedM_s: 4.8,
        solarFluxW_m2: 180,
        coolantFlowRateL_min: 450,
        inletTempC: 18.2
      },
      meshResolution: [size, size],
      predictedThermalField: predicted,
      observedThermalField: observed,
      spatialResidualField: residual,
      maxResidualC: Math.round(maxRes * 10) / 10,
      meanResidualC: Math.round(meanRes * 100) / 100,
      activeAnomalies: []
    };
  }

  private initializeMaterialLibrary(): void {
    const wavelengthsUm = [8.0, 8.5, 9.0, 9.5, 10.0, 10.5, 11.0, 11.5, 12.0, 12.5, 13.0, 13.5, 14.0];
    
    const materials: MaterialSpectralReference[] = [
      {
        id: 'mat-ss316',
        materialName: 'Stainless Steel AISI 316 (Oxidized)',
        category: 'Metals',
        emissivityNominal: 0.85,
        thermalConductivityW_mK: 16.3,
        heatCapacityJ_kgK: 500,
        densityKg_m3: 8000,
        spectralWavelengthsUm: wavelengthsUm,
        spectralReflectance: [0.18, 0.17, 0.16, 0.15, 0.14, 0.14, 0.13, 0.13, 0.12, 0.12, 0.11, 0.11, 0.10],
        spectralEmissivity:  [0.82, 0.83, 0.84, 0.85, 0.86, 0.86, 0.87, 0.87, 0.88, 0.88, 0.89, 0.89, 0.90],
        referenceStandard: 'NIST Standard Reference Database 118',
        uncertaintyPercent: 1.8
      },
      {
        id: 'mat-inconel718',
        materialName: 'Inconel 718 Nickel Superalloy (Turbine Blading)',
        category: 'Metals',
        emissivityNominal: 0.88,
        thermalConductivityW_mK: 11.4,
        heatCapacityJ_kgK: 435,
        densityKg_m3: 8190,
        spectralWavelengthsUm: wavelengthsUm,
        spectralReflectance: [0.14, 0.13, 0.13, 0.12, 0.12, 0.11, 0.11, 0.10, 0.10, 0.09, 0.09, 0.08, 0.08],
        spectralEmissivity:  [0.86, 0.87, 0.87, 0.88, 0.88, 0.89, 0.89, 0.90, 0.90, 0.91, 0.91, 0.92, 0.92],
        referenceStandard: 'Aerospace Material Specification AMS 5662',
        uncertaintyPercent: 2.1
      },
      {
        id: 'mat-redbrick',
        materialName: 'Manchester Red Clay Facing Brick',
        category: 'Building',
        emissivityNominal: 0.93,
        thermalConductivityW_mK: 0.77,
        heatCapacityJ_kgK: 840,
        densityKg_m3: 1900,
        spectralWavelengthsUm: wavelengthsUm,
        spectralReflectance: [0.08, 0.07, 0.06, 0.07, 0.07, 0.08, 0.07, 0.06, 0.06, 0.05, 0.05, 0.05, 0.04],
        spectralEmissivity:  [0.92, 0.93, 0.94, 0.93, 0.93, 0.92, 0.93, 0.94, 0.94, 0.95, 0.95, 0.95, 0.96],
        referenceStandard: 'BS EN 1745 Masonry Thermal Properties',
        uncertaintyPercent: 1.5
      },
      {
        id: 'mat-concrete',
        materialName: 'Reinforced Structural Concrete C30/37',
        category: 'Building',
        emissivityNominal: 0.92,
        thermalConductivityW_mK: 1.35,
        heatCapacityJ_kgK: 1000,
        densityKg_m3: 2300,
        spectralWavelengthsUm: wavelengthsUm,
        spectralReflectance: [0.09, 0.09, 0.08, 0.08, 0.08, 0.07, 0.07, 0.07, 0.06, 0.06, 0.06, 0.05, 0.05],
        spectralEmissivity:  [0.91, 0.91, 0.92, 0.92, 0.92, 0.93, 0.93, 0.93, 0.94, 0.94, 0.94, 0.95, 0.95],
        referenceStandard: 'ISO 10456 Building Materials Radiometric Library',
        uncertaintyPercent: 1.6
      },
      {
        id: 'mat-mineralwool',
        materialName: 'High-Temp Mineral Wool Pipe Cladding',
        category: 'Insulation',
        emissivityNominal: 0.88,
        thermalConductivityW_mK: 0.038,
        heatCapacityJ_kgK: 800,
        densityKg_m3: 120,
        spectralWavelengthsUm: wavelengthsUm,
        spectralReflectance: [0.13, 0.12, 0.12, 0.11, 0.11, 0.10, 0.10, 0.09, 0.09, 0.08, 0.08, 0.07, 0.07],
        spectralEmissivity:  [0.87, 0.88, 0.88, 0.89, 0.89, 0.90, 0.90, 0.91, 0.91, 0.92, 0.92, 0.93, 0.93],
        referenceStandard: 'ASTM C547 Mineral Fiber Pipe Insulation',
        uncertaintyPercent: 2.0
      },
      {
        id: 'mat-flotglass',
        materialName: 'Architectural Float Glass (Soda-Lime)',
        category: 'Ceramics',
        emissivityNominal: 0.91,
        thermalConductivityW_mK: 1.05,
        heatCapacityJ_kgK: 750,
        densityKg_m3: 2500,
        spectralWavelengthsUm: wavelengthsUm,
        spectralReflectance: [0.12, 0.11, 0.10, 0.09, 0.09, 0.08, 0.08, 0.07, 0.07, 0.06, 0.06, 0.05, 0.05],
        spectralEmissivity:  [0.88, 0.89, 0.90, 0.91, 0.91, 0.92, 0.92, 0.93, 0.93, 0.94, 0.94, 0.95, 0.95],
        referenceStandard: 'EN 12898 Glass in Building Emissivity Determination',
        uncertaintyPercent: 1.2
      }
    ];

    this.materialLibrary.set(materials);
  }

  private initializeBenchmarks(): void {
    const results: BenchmarkResult[] = [
      {
        operationName: '14-bit Packed RAW Frame Decode + Endian Swap',
        datasetResolution: '1024 x 768 (0.78 MP)',
        pythonCpuMs: 14.8,
        pythonCpuMpixPerSec: 53.1,
        rustCpuMs: 1.12,
        rustCpuMpixPerSec: 702.1,
        rustSimdMs: 0.28,
        rustSimdMpixPerSec: 2808.5,
        gpuWebGpuMs: 0.19,
        gpuWebGpuMpixPerSec: 4138.9,
        memoryBandwidthGbS: 28.4,
        simdSpeedupFactor: 4.0,
        rustVsPythonFactor: 52.8,
        verifiedNumericallyEqual: true
      },
      {
        operationName: 'Multi-Point NUC Calibration + Bad Pixel Map Interpolation',
        datasetResolution: '1024 x 768 (0.78 MP)',
        pythonCpuMs: 38.4,
        pythonCpuMpixPerSec: 20.4,
        rustCpuMs: 2.85,
        rustCpuMpixPerSec: 275.9,
        rustSimdMs: 0.62,
        rustSimdMpixPerSec: 1268.3,
        gpuWebGpuMs: 0.35,
        gpuWebGpuMpixPerSec: 2246.8,
        memoryBandwidthGbS: 32.1,
        simdSpeedupFactor: 4.6,
        rustVsPythonFactor: 61.9,
        verifiedNumericallyEqual: true
      },
      {
        operationName: 'Planck Inversion & Atmospheric Transmission Solver',
        datasetResolution: '1024 x 768 (0.78 MP)',
        pythonCpuMs: 64.2,
        pythonCpuMpixPerSec: 12.2,
        rustCpuMs: 4.10,
        rustCpuMpixPerSec: 191.8,
        rustSimdMs: 0.88,
        rustSimdMpixPerSec: 893.6,
        gpuWebGpuMs: 0.42,
        gpuWebGpuMpixPerSec: 1872.3,
        memoryBandwidthGbS: 24.6,
        simdSpeedupFactor: 4.65,
        rustVsPythonFactor: 72.9,
        verifiedNumericallyEqual: true
      },
      {
        operationName: 'Sub-Pixel Homography Image Registration (Optical Flow)',
        datasetResolution: '1024 x 768 (0.78 MP)',
        pythonCpuMs: 112.5,
        pythonCpuMpixPerSec: 6.9,
        rustCpuMs: 9.40,
        rustCpuMpixPerSec: 83.6,
        rustSimdMs: 2.15,
        rustSimdMpixPerSec: 365.7,
        gpuWebGpuMs: 0.95,
        gpuWebGpuMpixPerSec: 827.7,
        memoryBandwidthGbS: 18.9,
        simdSpeedupFactor: 4.37,
        rustVsPythonFactor: 52.3,
        verifiedNumericallyEqual: true
      },
      {
        operationName: 'Hyperspectral SAM (Spectral Angle Mapper) 128-Bands',
        datasetResolution: '256 x 256 x 128 (8.38 MP-Bands)',
        pythonCpuMs: 340.0,
        pythonCpuMpixPerSec: 24.6,
        rustCpuMs: 28.5,
        rustCpuMpixPerSec: 294.0,
        rustSimdMs: 5.80,
        rustSimdMpixPerSec: 1444.8,
        gpuWebGpuMs: 1.85,
        gpuWebGpuMpixPerSec: 4529.7,
        memoryBandwidthGbS: 44.8,
        simdSpeedupFactor: 4.91,
        rustVsPythonFactor: 58.6,
        verifiedNumericallyEqual: true
      }
    ];

    this.benchmarks.set(results);
  }

  /**
   * Generates synthetic sensor data dynamically based on user simulator inputs.
   */
  public generateSyntheticSensorData(config: {
    band: SpectralBand;
    detector: DetectorType;
    width: number;
    height: number;
    targetTempC: number;
    ambientTempC: number;
    netdMk: number;
    fpaTempK: number;
    hotspotDeltaC: number;
    badPixelRatePercent: number;
  }): InfraredDataset {
    const rawDnMatrix: number[][] = [];
    const calibratedMatrix: number[][] = [];
    const radianceMatrix: number[][] = [];

    const gain = 1400.0;
    const offset = 1000.0;

    for (let y = 0; y < config.height; y++) {
      const rawRow: number[] = [];
      const calRow: number[] = [];
      const radRow: number[] = [];
      for (let x = 0; x < config.width; x++) {
        let temp = config.ambientTempC;
        // Synthesize target object in center
        const dx = (x - config.width / 2) / (config.width * 0.25);
        const dy = (y - config.height / 2) / (config.height * 0.25);
        const r = Math.sqrt(dx * dx + dy * dy);
        if (r < 1.0) {
          temp = config.targetTempC + (1.0 - r) * (config.targetTempC * 0.15);
        }

        // Add hotspot if requested
        if (config.hotspotDeltaC > 0) {
          const dxh = x - Math.round(config.width * 0.42);
          const dyh = y - Math.round(config.height * 0.45);
          const rh = Math.sqrt(dxh * dxh + dyh * dyh);
          if (rh < 8.0) {
            temp += (1.0 - rh / 8.0) * config.hotspotDeltaC;
          }
        }

        // Detector noise
        const noise = (Math.random() - 0.5) * (config.netdMk / 1000.0) * 2.0;
        temp += noise;

        // Radiance calculation
        const tempK = temp + 273.15;
        const radiance = 0.00015 * Math.pow(tempK / 100, 3.85);
        let rawDn = Math.round(gain * radiance + offset);

        // Bad pixel inject
        if (Math.random() * 100 < config.badPixelRatePercent) {
          rawDn = Math.random() > 0.5 ? 16383 : 0; // dead or saturated pixel
        }

        rawRow.push(rawDn);
        calRow.push(Math.round(temp * 100) / 100);
        radRow.push(Math.round(radiance * 1000) / 1000);
      }
      rawDnMatrix.push(rawRow);
      calibratedMatrix.push(calRow);
      radianceMatrix.push(radRow);
    }

    const newDataset: InfraredDataset = {
      id: `dataset-sim-${Date.now()}`,
      name: `Synthetic ${config.band} ${config.detector} (${config.width}x${config.height})`,
      facility: 'Aardvark Metrology Lab',
      acquisitionTimestamp: new Date().toISOString(),
      wavelengthRange: config.band === 'MWIR' ? [3.0, 5.0] : [8.0, 14.0],
      bandType: config.band,
      bandsCount: 1,
      width: config.width,
      height: config.height,
      pixelPitchUm: 12.0,
      detectorType: config.detector,
      lensConfiguration: 'Aardvark Precision Athermal Lens',
      fieldOfViewDeg: [30.0, 22.5],
      integrationTimeUs: 1200,
      gainSetting: 'High',
      analogOffsetDn: offset,
      frameRateHz: 60,
      detectorTemperatureK: config.fpaTempK,
      radiometricUnits: 'APPARENT_TEMP_C',
      calibration: {
        calibrationId: `CAL-SYNTH-${Date.now().toString().slice(-4)}`,
        version: '1.0.0',
        calibrationDate: new Date().toISOString().split('T')[0],
        laboratory: 'Aardvark Computational Sensor Simulator',
        standardReference: 'Synthetic Planck Radiator',
        darkFrameApplied: true,
        nucType: 'TwoPoint_Linear',
        badPixelsCount: Math.round((config.width * config.height * config.badPixelRatePercent) / 100),
        residualRmsError: 0.035,
        spatialNonUniformityPrnu: 0.08,
        temporalNetd: config.netdMk,
        polynomialOrder: 2,
        temperatureRange: [-20, 300]
      },
      atmospheric: {
        distanceMeters: 5.0,
        ambientTemperatureC: config.ambientTempC,
        reflectedTemperatureC: config.ambientTempC,
        relativeHumidityPercent: 50.0,
        emissivity: 0.95,
        transmissionTau: 0.97,
        pathRadiance: 0.15
      },
      simulation: {
        isSimulated: true,
        simulationSeed: Math.floor(Math.random() * 1000000),
        physicalModel: 'Monte-Carlo Photon Statistics & Planck Radiator',
        softwareVersion: 'Aardvark-Core v4.2.0-rust-simd',
        engine: 'Rust SIMD + Python Orchestrator',
        generatedTimestamp: new Date().toISOString(),
        noiseParameters: {
          photonNoiseLevel: 0.01,
          readNoiseElectrons: 40,
          darkCurrentDnA: 15.0,
          fpaTempStabilityK: 0.01
        }
      },
      uncertainty: {
        combinedStandardUncertaintyC: 0.18,
        expandedUncertaintyU95C: 0.36,
        coverageFactor: 2.0,
        components: {
          detectorNoiseU1: config.netdMk / 1000.0,
          calibrationResidualU2: 0.035,
          emissivityUncertaintyU3: 0.12,
          reflectedTempUncertaintyU4: 0.06,
          atmosphericTransUncertaintyU5: 0.03,
          ambientTempDriftU6: 0.02
        }
      },
      provenanceHistory: [
        {
          id: `node-sim-${Date.now()}`,
          stageName: 'Synthetic Radiometric Field Generation',
          algorithm: 'AardvarkSim::generate_deterministic_scene',
          engine: 'Rust_Core',
          version: '1.4.2',
          runtimeMs: 0.85,
          inputChecksum: 'sha256:synth...',
          outputChecksum: 'sha256:gen...',
          parameters: { target_temp_c: config.targetTempC, netd_mk: config.netdMk },
          timestamp: new Date().toISOString()
        }
      ],
      rawDnMatrix,
      calibratedMatrix,
      radianceMatrix,
      rois: [],
      anomalies: []
    };

    this.datasets.update(list => [newDataset, ...list]);
    this.selectedDatasetId.set(newDataset.id);
    return newDataset;
  }
}
