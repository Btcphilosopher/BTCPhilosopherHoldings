import { Injectable } from '@angular/core';

export type ColormapName = 
  | 'Ironbow' 
  | 'Inferno' 
  | 'Turbo' 
  | 'White Hot' 
  | 'Black Hot' 
  | 'Rainbow' 
  | 'Medical Lava' 
  | 'Isotherm Alert';

export interface ColormapDefinition {
  name: ColormapName;
  description: string;
  category: 'Radiometric' | 'Perceptually Uniform' | 'High Contrast' | 'Specialty';
  previewGradient: string;
}

@Injectable({
  providedIn: 'root'
})
export class ColormapsService {
  public readonly availableColormaps: ColormapDefinition[] = [
    {
      name: 'Ironbow',
      description: 'Standard industrial thermography colormap with enhanced mid-range contrast',
      category: 'Radiometric',
      previewGradient: 'linear-gradient(to right, #000020, #400080, #8000a0, #c02060, #f06020, #ffd020, #ffffff)'
    },
    {
      name: 'Inferno',
      description: 'Perceptually uniform sequential colormap optimal for scientific thermal fields',
      category: 'Perceptually Uniform',
      previewGradient: 'linear-gradient(to right, #000004, #320a5e, #781c6d, #bb3754, #ed6925, #fcb519, #fcffa4)'
    },
    {
      name: 'Turbo',
      description: 'Smooth, high-distinction rainbow colormap without false gradient artifacts',
      category: 'Perceptually Uniform',
      previewGradient: 'linear-gradient(to right, #30123b, #4582f4, #28bbec, #39e38f, #a2fc3c, #f7d526, #f35817, #7a0403)'
    },
    {
      name: 'White Hot',
      description: 'Linear grayscale radiometric standard (low temp = black, high temp = white)',
      category: 'Radiometric',
      previewGradient: 'linear-gradient(to right, #000000, #555555, #aaaaaa, #ffffff)'
    },
    {
      name: 'Black Hot',
      description: 'Inverted grayscale radiometric scale (low temp = white, high temp = black)',
      category: 'Radiometric',
      previewGradient: 'linear-gradient(to right, #ffffff, #aaaaaa, #555555, #000000)'
    },
    {
      name: 'Rainbow',
      description: 'High-contrast multi-hue thermal palette for subtle delta-T segmentation',
      category: 'High Contrast',
      previewGradient: 'linear-gradient(to right, #0000ff, #00ffff, #00ff00, #ffff00, #ff0000, #ffffff)'
    },
    {
      name: 'Medical Lava',
      description: 'Biomedical temperature scale optimized for human physiology and fever screening',
      category: 'Specialty',
      previewGradient: 'linear-gradient(to right, #0a0e2a, #381347, #851c36, #cf3c2b, #f68524, #fde482, #ffffff)'
    },
    {
      name: 'Isotherm Alert',
      description: 'Grayscale base with high-temperature alert threshold highlighted in vibrant orange-red',
      category: 'Specialty',
      previewGradient: 'linear-gradient(to right, #111827, #64748b, #cbd5e1, #ef4444, #f97316, #fde047)'
    }
  ];

  // Precomputed 256-step RGB LUTs
  private readonly luts = new Map<ColormapName, Uint8ClampedArray>();

  constructor() {
    this.initializeLuts();
  }

  private initializeLuts(): void {
    for (const cm of this.availableColormaps) {
      const lut = new Uint8ClampedArray(256 * 3);
      for (let i = 0; i < 256; i++) {
        const t = i / 255.0;
        const [r, g, b] = this.sampleColormap(cm.name, t);
        lut[i * 3 + 0] = r;
        lut[i * 3 + 1] = g;
        lut[i * 3 + 2] = b;
      }
      this.luts.set(cm.name, lut);
    }
  }

  /**
   * Sample RGB [0..255] for a normalized position t in [0.0, 1.0].
   */
  public sampleColormap(name: ColormapName, t: number, isothermThreshold = 0.85): [number, number, number] {
    const clampedT = Math.max(0.0, Math.min(1.0, t));

    switch (name) {
      case 'White Hot': {
        const v = Math.round(clampedT * 255);
        return [v, v, v];
      }
      case 'Black Hot': {
        const v = Math.round((1.0 - clampedT) * 255);
        return [v, v, v];
      }
      case 'Ironbow': {
        if (clampedT < 0.2) {
          const s = clampedT / 0.2;
          return [Math.round(s * 60), 0, Math.round(40 + s * 90)];
        } else if (clampedT < 0.45) {
          const s = (clampedT - 0.2) / 0.25;
          return [Math.round(60 + s * 120), Math.round(s * 20), Math.round(130 - s * 50)];
        } else if (clampedT < 0.7) {
          const s = (clampedT - 0.45) / 0.25;
          return [Math.round(180 + s * 55), Math.round(20 + s * 110), Math.round(80 - s * 80)];
        } else if (clampedT < 0.9) {
          const s = (clampedT - 0.7) / 0.2;
          return [255, Math.round(130 + s * 105), Math.round(s * 50)];
        } else {
          const s = (clampedT - 0.9) / 0.1;
          return [255, 255, Math.round(50 + s * 205)];
        }
      }
      case 'Inferno': {
        const r = Math.max(0, Math.min(255, Math.round(255 * (clampedT * 1.5 - 0.1))));
        const g = Math.max(0, Math.min(255, Math.round(255 * (Math.pow(clampedT, 2.2) * 1.2))));
        const b = Math.max(0, Math.min(255, Math.round(255 * (Math.sin(clampedT * Math.PI) * 0.8 + (clampedT > 0.8 ? (clampedT - 0.8) * 4 : 0)))));
        return [r, g, b];
      }
      case 'Turbo': {
        const x = clampedT;
        const r = 34.61 + x * (1172.0 + x * (-1079.0 + x * (-3330.0 + x * (4713.0 - x * 1524.0))));
        const g = 23.31 + x * (557.3 + x * (1065.0 + x * (-3535.0 + x * (1260.0 + x * 639.0))));
        const b = 27.2 + x * (3211.0 + x * (-15328.0 + x * (27680.0 + x * (-21183.0 + x * 5808.0))));
        return [
          Math.max(0, Math.min(255, Math.round(r))),
          Math.max(0, Math.min(255, Math.round(g))),
          Math.max(0, Math.min(255, Math.round(b)))
        ];
      }
      case 'Rainbow': {
        const hue = (1.0 - clampedT) * 240.0;
        return this.hsvToRgb(hue, 1.0, 0.95);
      }
      case 'Medical Lava': {
        if (clampedT < 0.3) {
          const s = clampedT / 0.3;
          return [Math.round(20 + s * 80), Math.round(10 + s * 10), Math.round(50 + s * 40)];
        } else if (clampedT < 0.6) {
          const s = (clampedT - 0.3) / 0.3;
          return [Math.round(100 + s * 120), Math.round(20 + s * 50), Math.round(90 - s * 70)];
        } else if (clampedT < 0.85) {
          const s = (clampedT - 0.6) / 0.25;
          return [Math.round(220 + s * 35), Math.round(70 + s * 120), Math.round(20)];
        } else {
          const s = (clampedT - 0.85) / 0.15;
          return [255, Math.round(190 + s * 65), Math.round(20 + s * 235)];
        }
      }
      case 'Isotherm Alert': {
        if (clampedT >= isothermThreshold) {
          const s = (clampedT - isothermThreshold) / (1.0 - isothermThreshold);
          return [255, Math.round(60 + s * 160), Math.round(s * 40)];
        } else {
          const v = Math.round((clampedT / isothermThreshold) * 200);
          return [Math.round(v * 0.9), Math.round(v * 0.95), Math.round(v * 1.05)];
        }
      }
      default:
        return [Math.round(clampedT * 255), Math.round(clampedT * 255), Math.round(clampedT * 255)];
    }
  }

  private hsvToRgb(h: number, s: number, v: number): [number, number, number] {
    const c = v * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = v - c;
    let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
  }

  /**
   * Fast rendering of a 2D temperature matrix into an ImageData pixel buffer.
   */
  public renderMatrixToImageData(
    matrix: number[][], 
    minVal: number, 
    maxVal: number, 
    colormap: ColormapName, 
    isothermThreshold = 0.85
  ): ImageData {
    const height = matrix.length;
    const width = matrix[0].length;
    const imgData = new ImageData(width, height);
    const data = imgData.data;
    const range = Math.max(0.001, maxVal - minVal);

    for (let y = 0; y < height; y++) {
      const row = matrix[y];
      for (let x = 0; x < width; x++) {
        const val = row[x];
        const t = (val - minVal) / range;
        const [r, g, b] = this.sampleColormap(colormap, t, isothermThreshold);
        const idx = (y * width + x) * 4;
        data[idx + 0] = r;
        data[idx + 1] = g;
        data[idx + 2] = b;
        data[idx + 3] = 255;
      }
    }
    return imgData;
  }
}
