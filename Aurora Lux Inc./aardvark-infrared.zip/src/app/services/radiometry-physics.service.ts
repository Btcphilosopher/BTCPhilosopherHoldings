import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RadiometryPhysicsService {
  // Physical constants (CODATA 2018 / SI Units)
  public readonly SPEED_OF_LIGHT = 299792458; // c [m/s]
  public readonly PLANCK_CONSTANT = 6.62607015e-34; // h [J·s]
  public readonly BOLTZMANN_CONSTANT = 1.380649e-23; // k_B [J/K]
  public readonly STEFAN_BOLTZMANN = 5.670374419e-8; // sigma [W/(m^2·K^4)]
  public readonly WIEN_DISPLACEMENT_CONSTANT = 2.897771955e-3; // b [m·K] = 2897.77 um·K

  // First and second radiation constants
  // c1 = 2 * pi * h * c^2 = 3.741771852e-16 W·m^2
  // c1L = 2 * h * c^2 = 1.191042972e-16 W·m^2/sr
  public readonly C1_SPECTRAL = 1.191042972e-16; // 2 * h * c^2 in W·m^2 / sr
  public readonly C2_SPECTRAL = 1.438776877e-2; // (h * c) / k_B in m·K = 14387.77 um·K

  /**
   * Calculates Planck Spectral Radiance L_lambda(lambda, T) in W / (m^2 · sr · um).
   * @param wavelengthUm Wavelength in micrometers [um] (e.g. 10.0 for LWIR)
   * @param tempKelvin Absolute temperature in Kelvin [K] (e.g. 300.0 K)
   */
  public planckSpectralRadiance(wavelengthUm: number, tempKelvin: number): number {
    if (wavelengthUm <= 0 || tempKelvin <= 0) return 0;
    const lambdaM = wavelengthUm * 1e-6;
    const expTerm = Math.exp((this.PLANCK_CONSTANT * this.SPEED_OF_LIGHT) / (lambdaM * this.BOLTZMANN_CONSTANT * tempKelvin));
    if (!isFinite(expTerm) || expTerm <= 1) return 0;
    
    // Radiance per meter: W / (m^2 * sr * m)
    const L_m = (2 * this.PLANCK_CONSTANT * Math.pow(this.SPEED_OF_LIGHT, 2)) / (Math.pow(lambdaM, 5) * (expTerm - 1));
    // Convert to W / (m^2 * sr * um) by multiplying with 1e-6
    return L_m * 1e-6;
  }

  /**
   * Calculates peak wavelength lambda_max in micrometers [um] via Wien's Law.
   */
  public wienPeakWavelengthUm(tempKelvin: number): number {
    if (tempKelvin <= 0) return 0;
    return (this.WIEN_DISPLACEMENT_CONSTANT * 1e6) / tempKelvin;
  }

  /**
   * Calculates total Stefan-Boltzmann radiant exitance M = epsilon * sigma * T^4 [W/m^2].
   */
  public stefanBoltzmannExitance(tempKelvin: number, emissivity = 1.0): number {
    if (tempKelvin <= 0) return 0;
    return emissivity * this.STEFAN_BOLTZMANN * Math.pow(tempKelvin, 4);
  }

  /**
   * Integrates bandpass radiance over [lambda_min, lambda_max] using Simpson's 1/3 rule.
   */
  public integrateBandpassRadiance(
    lambdaMinUm: number, 
    lambdaMaxUm: number, 
    tempKelvin: number, 
    emissivity = 1.0, 
    steps = 64
  ): number {
    if (steps % 2 !== 0) steps++;
    const h = (lambdaMaxUm - lambdaMinUm) / steps;
    let sum = this.planckSpectralRadiance(lambdaMinUm, tempKelvin) + 
              this.planckSpectralRadiance(lambdaMaxUm, tempKelvin);

    for (let i = 1; i < steps; i++) {
      const lambda = lambdaMinUm + i * h;
      const weight = (i % 2 === 0) ? 2 : 4;
      sum += weight * this.planckSpectralRadiance(lambda, tempKelvin);
    }
    const integratedRadiance = (h / 3) * sum; // W / (m^2 * sr)
    return emissivity * integratedRadiance;
  }

  /**
   * Atmospheric transmission model (MODTRAN approximation for thermal infrared).
   * Models water vapor absorption and aerosol scattering.
   */
  public calculateAtmosphericTransmission(
    distanceMeters: number, 
    relativeHumidityPercent: number, 
    ambientTempC: number
  ): number {
    const dKm = distanceMeters / 1000.0;
    const tempK = ambientTempC + 273.15;
    // Saturated vapor pressure (Tetens formula in hPa)
    const eSat = 6.1078 * Math.pow(10, (7.5 * ambientTempC) / (237.3 + ambientTempC));
    const actualVaporPressure = (relativeHumidityPercent / 100.0) * eSat;
    // Absolute humidity in g/m^3
    const absHumidity = (216.7 * actualVaporPressure) / tempK;
    
    // LWIR 8-14um extinction coefficient estimate
    const alphaH2O = 0.016 * Math.sqrt(absHumidity + 0.1);
    const alphaScat = 0.008;
    const totalExtinction = alphaH2O + alphaScat;
    
    const tau = Math.exp(-Math.sqrt(dKm) * totalExtinction);
    return Math.max(0.05, Math.min(1.0, tau));
  }

  /**
   * Full Radiometric Equation (Standard Thermographic Measurement Equation):
   * W_tot = epsilon * tau_atm * W_obj(T_obj) + (1 - epsilon) * tau_atm * W_refl(T_refl) + (1 - tau_atm) * W_atm(T_atm)
   * Solves for true object temperature T_obj from observed sensor signal.
   */
  public solveObjectTemperature(
    apparentTempC: number,
    emissivity: number,
    distanceMeters: number,
    ambientTempC: number,
    reflectedTempC: number,
    humidityPercent: number
  ): { trueTempC: number; tauAtm: number; radObj: number; deltaCorrectionC: number } {
    const tauAtm = this.calculateAtmosphericTransmission(distanceMeters, humidityPercent, ambientTempC);
    const T_app_K = apparentTempC + 273.15;
    const T_refl_K = reflectedTempC + 273.15;
    const T_atm_K = ambientTempC + 273.15;

    // Power approximations in LWIR (power law n ~= 4.0 for standard bolometer)
    const n = 3.98;
    const W_tot = Math.pow(T_app_K, n);
    const W_refl = Math.pow(T_refl_K, n);
    const W_atm = Math.pow(T_atm_K, n);

    // W_tot = eps * tau * W_obj + (1-eps) * tau * W_refl + (1-tau) * W_atm
    // => W_obj = [ W_tot - (1-eps)*tau*W_refl - (1-tau)*W_atm ] / (eps * tau)
    const numerator = W_tot - (1.0 - emissivity) * tauAtm * W_refl - (1.0 - tauAtm) * W_atm;
    const denominator = Math.max(0.001, emissivity * tauAtm);
    const W_obj = Math.max(1.0, numerator / denominator);

    const T_obj_K = Math.pow(W_obj, 1.0 / n);
    const trueTempC = T_obj_K - 273.15;
    const deltaCorrectionC = trueTempC - apparentTempC;

    return {
      trueTempC: Math.round(trueTempC * 100) / 100,
      tauAtm: Math.round(tauAtm * 1000) / 1000,
      radObj: Math.round(W_obj * 10) / 10,
      deltaCorrectionC: Math.round(deltaCorrectionC * 100) / 100
    };
  }

  /**
   * Propagate GUM measurement uncertainty budget (Guide to Expression of Uncertainty in Measurement, ISO/IEC Guide 98-3).
   */
  public calculateGUMUncertainty(
    tempC: number,
    emissivity: number,
    tauAtm: number,
    netdC = 0.035, // 35 mK detector noise
    calibResidualC = 0.08,
    emissivityUncertainty = 0.03, // +/- 3%
    reflTempUncertaintyC = 1.5,
    atmUncertaintyPercent = 0.02
  ): {
    combinedU: number;
    expandedU95: number;
    components: {
      uDetectorNoise: number;
      uCalibrationResidual: number;
      uEmissivity: number;
      uReflectedTemp: number;
      uAtmospheric: number;
    };
  } {
    // Sensitivity coefficients (partial derivatives)
    const T_K = tempC + 273.15;
    const cEmissivity = (0.25 * T_K / Math.max(0.1, emissivity)) * emissivityUncertainty;
    const cRefl = (1 - emissivity) * 0.15 * reflTempUncertaintyC;
    const cAtm = (0.25 * T_K * (1 - tauAtm) / Math.max(0.1, tauAtm)) * atmUncertaintyPercent;

    const u1 = netdC;
    const u2 = calibResidualC;
    const u3 = Math.abs(cEmissivity);
    const u4 = Math.abs(cRefl);
    const u5 = Math.abs(cAtm);

    const combinedU = Math.sqrt(u1 * u1 + u2 * u2 + u3 * u3 + u4 * u4 + u5 * u5);
    const expandedU95 = combinedU * 2.0; // k = 2 for ~95% confidence level

    return {
      combinedU: Math.round(combinedU * 1000) / 1000,
      expandedU95: Math.round(expandedU95 * 1000) / 1000,
      components: {
        uDetectorNoise: Math.round(u1 * 1000) / 1000,
        uCalibrationResidual: Math.round(u2 * 1000) / 1000,
        uEmissivity: Math.round(u3 * 1000) / 1000,
        uReflectedTemp: Math.round(u4 * 1000) / 1000,
        uAtmospheric: Math.round(u5 * 1000) / 1000
      }
    };
  }
}
