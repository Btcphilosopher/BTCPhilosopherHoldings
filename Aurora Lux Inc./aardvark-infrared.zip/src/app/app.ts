import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AardvarkDataService } from './services/aardvark-data.service';

import { TopNavComponent } from './components/top-nav/top-nav.component';
import { WorkstationComponent } from './components/workstation/workstation.component';
import { SensorLabComponent } from './components/sensor-lab/sensor-lab.component';
import { CalibrationLabComponent } from './components/calibration-lab/calibration-lab.component';
import { BlackbodyLabComponent } from './components/blackbody-lab/blackbody-lab.component';
import { HyperspectralComponent } from './components/hyperspectral/hyperspectral.component';
import { DigitalTwinComponent } from './components/digital-twin/digital-twin.component';
import { AnomalyEngineComponent } from './components/anomaly-engine/anomaly-engine.component';
import { FusionRegistrationComponent } from './components/fusion-registration/fusion-registration.component';
import { UncertaintyLabComponent } from './components/uncertainty-lab/uncertainty-lab.component';
import { PipelineGraphComponent } from './components/pipeline-graph/pipeline-graph.component';
import { BenchmarkLabComponent } from './components/benchmark-lab/benchmark-lab.component';
import { ImagingAssistantComponent } from './components/imaging-assistant/imaging-assistant.component';
import { CodeRepositoryComponent } from './components/code-repository/code-repository.component';
import { InspectionReportComponent } from './components/inspection-report/inspection-report.component';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    TopNavComponent,
    WorkstationComponent,
    SensorLabComponent,
    CalibrationLabComponent,
    BlackbodyLabComponent,
    HyperspectralComponent,
    DigitalTwinComponent,
    AnomalyEngineComponent,
    FusionRegistrationComponent,
    UncertaintyLabComponent,
    PipelineGraphComponent,
    BenchmarkLabComponent,
    ImagingAssistantComponent,
    CodeRepositoryComponent,
    InspectionReportComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public readonly dataService = inject(AardvarkDataService);
}
