export type SpectralBand = 'NIR' | 'SWIR' | 'MWIR' | 'LWIR' | 'MULTISPECTRAL' | 'HYPERSPECTRAL';

export type RadiometricUnit = 'DN' | 'CALIBRATED_DN' | 'RADIANCE_W_M2_SR_UM' | 'APPARENT_TEMP_C' | 'APPARENT_TEMP_K';

export type DetectorType = 
  | 'VOx_Microbolometer' 
  | 'aSi_Microbolometer' 
  | 'InSb_Stirling_Cooled' 
  | 'MCT_Stirling_Cooled' 
  | 'InGaAs_Peltier_Cooled' 
  | 'QWIP_Cryo_Cooled';

export type EvidenceClassification = 
  | 'MEASURED' 
  | 'CALCULATED' 
  | 'MODELLED' 
  | 'INFERRED' 
  | 'SIMULATED' 
  | 'AI_INTERPRETATION';

export interface CalibrationMetadata {
  calibrationId: string;
  version: string;
  calibrationDate: string;
  laboratory: string;
  standardReference: string;
  darkFrameApplied: boolean;
  nucType: 'TwoPoint_Linear' | 'MultiPoint_Polynomial' | 'MultiPoint_Spline';
  badPixelsCount: number;
  residualRmsError: number; // e.g., 0.042 K
  spatialNonUniformityPrnu: number; // % e.g., 0.12%
  temporalNetd: number; // mK e.g., 28 mK
  polynomialOrder: number;
  fitCoefficients?: number[];
  temperatureRange: [number, number]; // [min_C, max_C]
}

export interface SimulationMetadata {
  isSimulated: boolean;
  simulationSeed: number;
  physicalModel: string;
  softwareVersion: string;
  engine: string;
  generatedTimestamp: string;
  noiseParameters: {
    photonNoiseLevel: number;
    readNoiseElectrons: number;
    darkCurrentDnA: number;
    fpaTempStabilityK: number;
  };
}

export interface AtmosphericParameters {
  distanceMeters: number;
  ambientTemperatureC: number;
  reflectedTemperatureC: number;
  relativeHumidityPercent: number;
  emissivity: number;
  transmissionTau: number;
  pathRadiance: number; // W/(m^2*sr*um)
}

export interface UncertaintyBudget {
  combinedStandardUncertaintyC: number;
  expandedUncertaintyU95C: number; // k=2
  coverageFactor: number; // 2.0 (95% confidence)
  components: {
    detectorNoiseU1: number;
    calibrationResidualU2: number;
    emissivityUncertaintyU3: number;
    reflectedTempUncertaintyU4: number;
    atmosphericTransUncertaintyU5: number;
    ambientTempDriftU6: number;
  };
}

export interface ProcessingHistoryNode {
  id: string;
  stageName: string;
  algorithm: string;
  engine: 'Rust_Core' | 'Python_Scientific' | 'R_Statistical' | 'GPU_Kernel';
  version: string;
  runtimeMs: number;
  inputChecksum: string;
  outputChecksum: string;
  parameters: Record<string, string | number | boolean>;
  timestamp: string;
}

export interface RoiMeasurement {
  id: string;
  label: string;
  type: 'spot' | 'box' | 'circle' | 'line';
  color: string;
  x: number; // pixel coord or %
  y: number;
  width?: number;
  height?: number;
  x2?: number; // for line
  y2?: number;
  emissivity: number;
  minTempC: number;
  maxTempC: number;
  meanTempC: number;
  stdDevTempC: number;
  deltaAmbientC: number;
  pixelCount: number;
  radianceMean: number;
  uncertaintyU95C: number;
  profileValues?: number[]; // line profile samples
}

export interface HyperspectralBandData {
  wavelengthUm: number;
  bandIndex: number;
  fwhmUm: number;
  snr: number;
}

export interface MaterialSpectralReference {
  id: string;
  materialName: string;
  category: 'Metals' | 'Ceramics' | 'Building' | 'Polymers' | 'Insulation' | 'Coatings' | 'Natural';
  emissivityNominal: number;
  thermalConductivityW_mK: number;
  heatCapacityJ_kgK: number;
  densityKg_m3: number;
  spectralWavelengthsUm: number[];
  spectralReflectance: number[];
  spectralEmissivity: number[];
  referenceStandard: string;
  uncertaintyPercent: number;
}

export interface ThermalAnomaly {
  id: string;
  severity: 'NORMAL' | 'MONITORING' | 'MINOR_FAULT' | 'SEVERE_FAULT' | 'CRITICAL_OVERHEAT';
  component: string;
  assetLocation: string;
  observedTempC: number;
  predictedTempC: number;
  deltaTempC: number;
  thresholdC: number;
  isoClassification: string; // e.g., "ISO 18434-1 Category IV" or "IEEE 738 Class A"
  physicalCause: string;
  recommendation: string;
  confidenceScore: number;
  evidence: {
    type: EvidenceClassification;
    description: string;
  }[];
}

export interface DigitalTwinAsset {
  id: string;
  facilityName: 'North Sea Energy Facility' | 'Manchester Industrial Facility';
  name: string;
  category: 'Turbomachinery' | 'Transformer Substation' | 'Steam Distribution' | 'Pump Skid' | 'Building Envelope' | 'Switchgear';
  modelGeometryUrl?: string;
  operatingConditions: {
    loadPercent: number;
    ambientTempC: number;
    windSpeedM_s: number;
    solarFluxW_m2: number;
    coolantFlowRateL_min: number;
    inletTempC: number;
  };
  meshResolution: [number, number]; // e.g. 64x64 grid
  predictedThermalField: number[][]; // grid of temps in deg C
  observedThermalField: number[][];
  spatialResidualField: number[][]; // observed - predicted
  maxResidualC: number;
  meanResidualC: number;
  activeAnomalies: ThermalAnomaly[];
}

export interface InfraredDataset {
  id: string;
  name: string;
  facility: 'North Sea Energy Facility' | 'Manchester Industrial Facility' | 'Aardvark Metrology Lab';
  acquisitionTimestamp: string;
  wavelengthRange: [number, number]; // [min_um, max_um] e.g., [8.0, 14.0]
  bandType: SpectralBand;
  bandsCount: number;
  width: number;
  height: number;
  pixelPitchUm: number; // e.g. 12.0 um
  detectorType: DetectorType;
  lensConfiguration: string; // e.g., "50mm f/1.0 Ge Aspheric Athermalized"
  fieldOfViewDeg: [number, number]; // [H, V]
  integrationTimeUs: number; // e.g. 1250 us
  gainSetting: 'High' | 'Low' | 'UltraHigh';
  analogOffsetDn: number;
  frameRateHz: number;
  detectorTemperatureK: number;
  radiometricUnits: RadiometricUnit;
  calibration: CalibrationMetadata;
  atmospheric: AtmosphericParameters;
  simulation: SimulationMetadata;
  uncertainty: UncertaintyBudget;
  provenanceHistory: ProcessingHistoryNode[];
  rawDnMatrix: number[][]; // 2D array of raw detector DN (e.g. 14-bit: 0..16383)
  calibratedMatrix: number[][]; // Radiometrically calibrated Temp in deg C
  radianceMatrix: number[][]; // W/(m^2*sr*um)
  referenceRgbImageUrl?: string;
  rois: RoiMeasurement[];
  anomalies: ThermalAnomaly[];
  hyperspectralCubes?: {
    bands: HyperspectralBandData[];
    cubeSliceAtWavelengthUm: (wavelength: number) => number[][];
  };
}

export interface BenchmarkResult {
  operationName: string;
  datasetResolution: string;
  pythonCpuMs: number;
  pythonCpuMpixPerSec: number;
  rustCpuMs: number;
  rustCpuMpixPerSec: number;
  rustSimdMs: number;
  rustSimdMpixPerSec: number;
  gpuWebGpuMs: number;
  gpuWebGpuMpixPerSec: number;
  memoryBandwidthGbS: number;
  simdSpeedupFactor: number;
  rustVsPythonFactor: number;
  verifiedNumericallyEqual: boolean;
}
