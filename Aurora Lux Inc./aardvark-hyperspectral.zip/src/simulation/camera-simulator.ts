/**
 * Aardvark Synthetic Hyperspectral Camera & Scene Simulator
 * Generates physically grounded radiometric measurements and synthetic raw sensor streams.
 *
 * LABELED AS: SYNTHETIC DEMONSTRATION DATA
 */

import {
  AARDVARK_SPECTRAL_LIBRARY,
  STANDARD_WAVELENGTHS,
} from '../data/spectral-library';
import {
  BadPixelMask,
  CameraProfile,
  HyperspectralMetadata,
  SpectralCube,
} from '../types/spectral';

export const DEFAULT_CAMERA_PROFILE: CameraProfile = {
  id: 'AAR-VNIR-P1024',
  name: 'Aardvark HyperCam VNIR-1024 Industrial Pushbroom',
  architecture: 'pushbroom',
  spatialResolution: [80, 60], // [width, height] in spatial pixel grid
  spectralBands: 61,
  wavelengthRange: [400, 1000],
  pixelPitchMicrons: 6.5,
  fullWellCapacityElectrons: 32000,
  readNoiseElectrons: 4.8,
  darkCurrentRate: 15.0, // e-/pixel/sec at 20°C
  adcResolutionBits: 14, // 16384 DN max
  defaultGainDb: 0.0,
  defaultIntegrationTimeMs: 18.5,
  sensorTemperatureCelsius: 18.2,
  interfaceType: 'Synthetic Simulator',
  lensModel: 'Aardvark Telecentric Spec-Lens 35mm F/2.0',
  focalLengthMm: 35.0,
  fNumber: 2.0,
};

export interface SimulatorNoiseConfig {
  enableShotNoise: boolean;
  enableReadNoise: boolean;
  enableDarkCurrent: boolean;
  enableBadPixels: boolean;
  enableSmileDistortion: boolean;
  exposureMultiplier: number;
  gainDb: number;
  temperatureCelsius: number;
}

export const DEFAULT_NOISE_CONFIG: SimulatorNoiseConfig = {
  enableShotNoise: true,
  enableReadNoise: true,
  enableDarkCurrent: true,
  enableBadPixels: true,
  enableSmileDistortion: false,
  exposureMultiplier: 1.0,
  gainDb: 0.0,
  temperatureCelsius: 18.2,
};

// Box-Muller Gaussian random generator
function gaussianRandom(mean = 0, stdev = 1): number {
  const u = 1 - Math.random();
  const v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return z * stdev + mean;
}

/**
 * Generates the canonical AARDVARK-DEMO-001 industrial test facility scene.
 */
export function generateSyntheticCube(
  profile: CameraProfile = DEFAULT_CAMERA_PROFILE,
  noiseConfig: SimulatorNoiseConfig = DEFAULT_NOISE_CONFIG,
  datasetName: string = 'AARDVARK-DEMO-001 [Industrial Inspection]'
): {
  cube: SpectralCube;
  rawCube: SpectralCube;
  darkFrame: Float32Array;
  whiteReference: Float32Array;
  badPixelMask: BadPixelMask;
} {
  const [width, height] = profile.spatialResolution;
  const bands = profile.spectralBands;
  const wavelengths = [...STANDARD_WAVELENGTHS];
  const numPixels = width * height;

  // Retrieve material spectra from library
  const libMap = new Map(AARDVARK_SPECTRAL_LIBRARY.map(m => [m.id, m.reflectance]));
  const steel = libMap.get('mat_steel_structural')!;
  const aluminum = libMap.get('mat_aluminum_alloy')!;
  const concrete = libMap.get('mat_concrete_cured')!;
  const yellowPaint = libMap.get('mat_paint_safety_yellow')!;
  const vegHealthy = libMap.get('mat_veg_healthy')!;
  const vegDry = libMap.get('mat_veg_dry')!;
  const polymerHdpe = libMap.get('mat_polymer_hdpe')!;
  const polymerPet = libMap.get('mat_polymer_pet')!;
  const copper = libMap.get('mat_copper_alloy')!;
  const water = libMap.get('mat_water_clear')!;
  const soil = libMap.get('mat_soil_loam')!;

  // 1. Generate Bad Pixel Mask
  const mask = new Uint8Array(numPixels);
  let deadCount = 0;
  let hotCount = 0;
  let saturatedCount = 0;
  let noisyCount = 0;

  if (noiseConfig.enableBadPixels) {
    // Specific fixed dead/hot pixels for deterministic calibration testing
    const deadIndices = [width * 12 + 15, width * 38 + 65, width * 45 + 10];
    const hotIndices = [width * 8 + 42, width * 27 + 22, width * 51 + 58];
    const satIndices = [width * 19 + 71];

    for (const idx of deadIndices) {
      if (idx < numPixels) {
        mask[idx] = 1;
        deadCount++;
      }
    }
    for (const idx of hotIndices) {
      if (idx < numPixels) {
        mask[idx] = 2;
        hotCount++;
      }
    }
    for (const idx of satIndices) {
      if (idx < numPixels) {
        mask[idx] = 3;
        saturatedCount++;
      }
    }
  }

  const badPixelMask: BadPixelMask = {
    width,
    height,
    mask,
    deadCount,
    hotCount,
    saturatedCount,
    noisyCount,
  };

  // 2. Synthesize Ideal Calibrated Reflectance Data & Raw Digital Numbers (DN)
  const calibratedData = new Float32Array(numPixels * bands);
  const rawData = new Float32Array(numPixels * bands);

  // Precompute Dark Frame and White Reference
  const darkFrame = new Float32Array(bands);
  const whiteReference = new Float32Array(bands);

  const gainFactor = Math.pow(10, noiseConfig.gainDb / 20);
  const tempScale = Math.pow(2, (noiseConfig.temperatureCelsius - 20) / 6.0);
  const baseDarkDN = 420 * tempScale * gainFactor;

  for (let b = 0; b < bands; b++) {
    // Dark frame has slight thermal gradient across wavelengths
    darkFrame[b] = baseDarkDN + (b / bands) * 25 + gaussianRandom(0, 1.5);
    // 99% Spectralon panel illuminated by standard halogen/solar source
    const solarCurve = 11500 * (1.0 - 0.25 * Math.pow((wavelengths[b] - 650) / 350, 2));
    whiteReference[b] = darkFrame[b] + solarCurve * noiseConfig.exposureMultiplier;
  }

  // Populate spatial regions
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const p = y * width + x;
      const off = p * bands;

      // Base: Concrete floor
      let baseSpectrum = concrete;
      let mixRatio = 0.0;
      let secondarySpectrum = concrete;

      // Region 1: Steel structural framework (left column and central horizontal beam)
      if (x >= 4 && x <= 20 && y >= 6 && y <= 52) {
        baseSpectrum = steel;
      } else if (y >= 24 && y <= 32 && x >= 4 && x <= 50) {
        baseSpectrum = steel;
      }
      // Region 2: Aerospace Aluminum machined panel (top right)
      else if (x >= 48 && x <= 72 && y >= 6 && y <= 22) {
        baseSpectrum = aluminum;
      }
      // Region 3: Industrial Safety Yellow Machinery Enclosure (center-right)
      else if (x >= 28 && x <= 46 && y >= 14 && y <= 40) {
        baseSpectrum = yellowPaint;
      }
      // Region 4: Bio-monitoring Healthy Vegetation sample tray (bottom-left)
      else if (x >= 6 && x <= 24 && y >= 36 && y <= 54) {
        baseSpectrum = vegHealthy;
        // Edge senescence transition
        if (x > 20 || y < 38) {
          secondarySpectrum = vegDry;
          mixRatio = 0.35;
        }
      }
      // Region 5: Polymer Components (HDPE container & PET specimen)
      else if (x >= 52 && x <= 64 && y >= 26 && y <= 42) {
        baseSpectrum = polymerHdpe;
      } else if (x >= 66 && x <= 75 && y >= 28 && y <= 44) {
        baseSpectrum = polymerPet;
      }
      // Region 6: Copper Busbar terminal
      else if (x >= 24 && x <= 27 && y >= 25 && y <= 31) {
        baseSpectrum = copper;
      }
      // Region 7: Water Coolant Reservoir
      else if (x >= 32 && x <= 44 && y >= 44 && y <= 55) {
        baseSpectrum = water;
      }
      // Region 8: Mineral Soil / gravel substrate surrounding tray
      else if (x >= 25 && x <= 31 && y >= 42 && y <= 54) {
        baseSpectrum = soil;
      }

      // Special Anomaly: Unidentified spectral contaminant at (x: 58, y: 48)
      const distToAnomaly = Math.hypot(x - 58, y - 48);
      const isAnomalyPixel = distToAnomaly < 2.5;

      for (let b = 0; b < bands; b++) {
        let refl =
          baseSpectrum[b] * (1 - mixRatio) + secondarySpectrum[b] * mixRatio;

        // Slight spatial texture variation
        const texture = 1.0 + 0.02 * Math.sin(x * 0.4) * Math.cos(y * 0.4);
        refl *= texture;

        // Inject anomaly signature (sharp unusual absorption dip at 620nm & 830nm)
        if (isAnomalyPixel) {
          const strength = 1.0 - distToAnomaly / 2.5;
          const anomDip =
            0.35 * Math.exp(-Math.pow((wavelengths[b] - 620) / 20, 2)) +
            0.40 * Math.exp(-Math.pow((wavelengths[b] - 830) / 25, 2));
          refl = Math.max(0.01, refl * (1.0 - strength * anomDip));
        }

        calibratedData[off + b] = Math.max(0, Math.min(1.0, refl));

        // Generate Raw Digital Numbers (DN) with sensor optical model & noise
        const incidentSignalDN =
          (whiteReference[b] - darkFrame[b]) * refl * noiseConfig.exposureMultiplier;

        let photonElectrons = incidentSignalDN * 2.2; // conversion gain e-/DN
        if (noiseConfig.enableShotNoise && photonElectrons > 0) {
          // Poisson shot noise approximation
          const shotStd = Math.sqrt(photonElectrons);
          photonElectrons += gaussianRandom(0, shotStd);
        }

        let totalSignalDN = photonElectrons / 2.2;

        if (noiseConfig.enableReadNoise) {
          totalSignalDN += gaussianRandom(0, profile.readNoiseElectrons / 2.2);
        }

        let rawDN = darkFrame[b] + totalSignalDN;

        // Apply bad pixel effects
        const pState = mask[p];
        if (pState === 1) {
          rawDN = 0; // dead pixel
        } else if (pState === 2) {
          rawDN = 14200 + gaussianRandom(0, 50); // hot pixel
        } else if (pState === 3) {
          rawDN = 16383; // saturated
        }

        // ADC 14-bit clamp
        rawData[off + b] = Math.max(0, Math.min(16383, Math.round(rawDN)));
      }
    }
  }

  const metadata: HyperspectralMetadata = {
    camera_id: profile.id,
    sensor_id: 'AAR-CMOS-VNIR-MK3',
    lens_id: profile.lensModel,
    acquisition_time: new Date().toISOString(),
    integration_time_ms: profile.defaultIntegrationTimeMs * noiseConfig.exposureMultiplier,
    gain_db: noiseConfig.gainDb,
    offset: 420,
    frame_rate_fps: 85.0,
    wavelength_start_nm: profile.wavelengthRange[0],
    wavelength_end_nm: profile.wavelengthRange[1],
    spectral_resolution_fwhm_nm: 10.0,
    spatial_resolution_px: [width, height],
    bit_depth: profile.adcResolutionBits,
    temperature_celsius: noiseConfig.temperatureCelsius,
    gps: {
      latitude: 52.2053,
      longitude: 0.1218,
      altitude_m: 24.5,
    },
    orientation: {
      pitch_deg: -45.0, // angled downward inspection
      roll_deg: 0.0,
      yaw_deg: 92.4,
    },
    calibration_id: 'CAL-2026-NIST-0941',
    operator: 'Dr. E. Vance, Lead Metrology Engineer',
    software_version: 'Aardvark Hyperspectral Core v3.7.2',
    pipeline_version: 'REC-STD-VNIR-v1',
    is_synthetic: true,
    provenance_note:
      'SYNTHETIC DEMONSTRATION DATA: Generated via Aardvark Synthetic Optical Simulator for validation & benchmark.',
  };

  const cube: SpectralCube = {
    id: 'AARDVARK-DEMO-001',
    name: datasetName,
    width,
    height,
    bands,
    wavelengths,
    data: calibratedData,
    calibrationState: 'RADIOMETRIC_CALIBRATED',
    metadata,
    badPixelMask,
    auditTrail: [
      {
        timestamp: new Date().toISOString(),
        stage: 'SYNTHETIC_ACQUISITION',
        action: 'Acquired synthetic scene with physics-based radiative transfer',
        operator: 'Aardvark Synthetic Camera Simulator',
        parameters: { noiseConfig, profileId: profile.id },
        outputHash: 'aar_hash_demo001',
      },
    ],
  };

  const rawCube: SpectralCube = {
    id: 'AARDVARK-DEMO-001-RAW',
    name: `${datasetName} [RAW DN]`,
    width,
    height,
    bands,
    wavelengths,
    data: rawData,
    calibrationState: 'RAW_MEASUREMENT',
    metadata,
    badPixelMask,
    auditTrail: [
      {
        timestamp: new Date().toISOString(),
        stage: 'RAW_SENSOR_READOUT',
        action: 'Uncalibrated 14-bit Digital Numbers direct from ADC frame buffer',
        operator: 'Aardvark Driver / Frame Grabber',
        parameters: { bitDepth: 14, gainDb: noiseConfig.gainDb },
        outputHash: 'aar_hash_raw_demo001',
      },
    ],
  };

  return { cube, rawCube, darkFrame, whiteReference, badPixelMask };
}
