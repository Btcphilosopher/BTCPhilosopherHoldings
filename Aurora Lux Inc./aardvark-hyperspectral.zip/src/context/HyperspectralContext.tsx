/**
 * Hyperspectral Application State & Pipeline Orchestration Context
 */

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { AARDVARK_SPECTRAL_LIBRARY } from '../data/spectral-library';
import {
  computeCubePCA,
  computeRXAnomaly,
  findClosestBandIndex,
  linearSpectralUnmixing,
  pearsonCorrelation,
  spectralAngleMapper,
} from '../core/spectral-math';
import {
  DEFAULT_CAMERA_PROFILE,
  DEFAULT_NOISE_CONFIG,
  generateSyntheticCube,
  SimulatorNoiseConfig,
} from '../simulation/camera-simulator';
import {
  AnomalyDetectionResult,
  CalibrationRecord,
  ChangeDetectionResult,
  ClassificationResult,
  LinearUnmixingResult,
  PCAResult,
  SpectralCube,
  SpectralROI,
} from '../types/spectral';

export type ViewMode =
  | 'rgb'
  | 'false_color'
  | 'single_band'
  | 'pca'
  | 'unmixing'
  | 'classification'
  | 'anomaly'
  | 'index_ndvi';

export type TabType =
  | 'workspace'
  | 'acquire'
  | 'calibrate'
  | 'chemometrics'
  | '3d_twin'
  | 'library'
  | 'change_detect'
  | 'pipeline'
  | 'reports';

interface HyperspectralContextType {
  cube: SpectralCube;
  rawCube: SpectralCube;
  darkFrame: Float32Array;
  whiteReference: Float32Array;
  calibrationRecord: CalibrationRecord;
  cursor: { x: number; y: number } | null;
  cursorSpectrum: number[] | null;
  cursorDerivative: 'raw' | '1st' | '2nd' | 'continuum' | 'snv';
  setCursorDerivative: (d: 'raw' | '1st' | '2nd' | 'continuum' | 'snv') => void;
  cursorMatch: { name: string; samAngle: number; correlation: number } | null;
  setCursorPosition: (pos: { x: number; y: number } | null) => void;
  activeWavelengthNm: number;
  setActiveWavelengthNm: (nm: number) => void;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  rgbBands: { redNm: number; greenNm: number; blueNm: number };
  setRgbBands: (bands: { redNm: number; greenNm: number; blueNm: number }) => void;
  rois: SpectralROI[];
  addRoi: (roi: SpectralROI) => void;
  deleteRoi: (id: string) => void;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  pcaResult: PCAResult | null;
  runPCA: () => void;
  unmixingResult: LinearUnmixingResult | null;
  runUnmixing: () => void;
  anomalyResult: AnomalyDetectionResult | null;
  runAnomalyDetection: () => void;
  classificationResult: ClassificationResult | null;
  runClassification: () => void;
  changeResult: ChangeDetectionResult | null;
  runChangeDetection: () => void;
  isScanning: boolean;
  scanLine: number;
  telemetry: {
    fps: number;
    temperature: number;
    droppedFrames: number;
    bufferQueue: number;
    gpuActive: boolean;
  };
  noiseConfig: SimulatorNoiseConfig;
  setNoiseConfig: React.Dispatch<React.SetStateAction<SimulatorNoiseConfig>>;
  triggerAcquisition: (mode: 'instant' | 'pushbroom') => void;
  applyCalibrationWorkflow: (steps: {
    darkSub: boolean;
    whiteNorm: boolean;
    badPixelRepair: boolean;
  }) => void;
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  aiDrawerOpen: boolean;
  setAiDrawerOpen: (open: boolean) => void;
  inspectMaterial: (matId: string) => void;
}

const HyperspectralContext = createContext<HyperspectralContextType | undefined>(undefined);

export const HyperspectralProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  // Initial demo data generation
  const initial = generateSyntheticCube();
  const [cube, setCube] = useState<SpectralCube>(initial.cube);
  const [rawCube, setRawCube] = useState<SpectralCube>(initial.rawCube);
  const [darkFrame, setDarkFrame] = useState<Float32Array>(initial.darkFrame);
  const [whiteReference, setWhiteReference] = useState<Float32Array>(initial.whiteReference);

  const [calibrationRecord, setCalibrationRecord] = useState<CalibrationRecord>({
    calibrationId: 'CAL-2026-NIST-0941',
    createdAt: new Date().toISOString(),
    operator: 'Dr. E. Vance, Lead Metrology Engineer',
    targetCameraId: DEFAULT_CAMERA_PROFILE.id,
    darkFrameMean: initial.darkFrame,
    whiteReferenceReflectance: initial.whiteReference,
    whitePanelType: 'Spectralon 99%',
    wavelengthCoefficients: [400.0, 10.0, 0.0],
    wavelengthResidualRmsNm: 0.12,
    badPixelCount: initial.badPixelMask.deadCount + initial.badPixelMask.hotCount,
    validityDays: 180,
  });

  const [cursor, setCursor] = useState<{ x: number; y: number } | null>({ x: 38, y: 24 });
  const [cursorDerivative, setCursorDerivative] = useState<
    'raw' | '1st' | '2nd' | 'continuum' | 'snv'
  >('raw');
  const [activeWavelengthNm, setActiveWavelengthNm] = useState<number>(640);
  const [viewMode, setViewMode] = useState<ViewMode>('rgb');
  const [rgbBands, setRgbBands] = useState({ redNm: 640, greenNm: 550, blueNm: 460 });
  const [activeTab, setActiveTab] = useState<TabType>('workspace');
  const [noiseConfig, setNoiseConfig] = useState<SimulatorNoiseConfig>(DEFAULT_NOISE_CONFIG);

  // Analysis outputs
  const [pcaResult, setPcaResult] = useState<PCAResult | null>(null);
  const [unmixingResult, setUnmixingResult] = useState<LinearUnmixingResult | null>(null);
  const [anomalyResult, setAnomalyResult] = useState<AnomalyDetectionResult | null>(null);
  const [classificationResult, setClassificationResult] = useState<ClassificationResult | null>(
    null
  );
  const [changeResult, setChangeResult] = useState<ChangeDetectionResult | null>(null);

  // Live acquisition state
  const [isScanning, setIsScanning] = useState(false);
  const [scanLine, setScanLine] = useState(0);
  const [telemetry, setTelemetry] = useState({
    fps: 84.8,
    temperature: 18.2,
    droppedFrames: 0,
    bufferQueue: 2,
    gpuActive: true,
  });

  // UI state
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [aiDrawerOpen, setAiDrawerOpen] = useState(false);

  // Sample ROIs in default scene
  const [rois, setRois] = useState<SpectralROI[]>(() => {
    // Helper to calculate ROI mean spectrum
    const calcRoi = (
      id: string,
      name: string,
      color: string,
      x0: number,
      y0: number,
      x1: number,
      y1: number
    ): SpectralROI => {
      const { width, bands, data } = initial.cube;
      const count = (x1 - x0 + 1) * (y1 - y0 + 1);
      const meanSpectrum = new Array(bands).fill(0);
      const minSpectrum = new Array(bands).fill(Infinity);
      const maxSpectrum = new Array(bands).fill(-Infinity);

      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) {
          const off = (y * width + x) * bands;
          for (let b = 0; b < bands; b++) {
            const v = data[off + b];
            meanSpectrum[b] += v;
            if (v < minSpectrum[b]) minSpectrum[b] = v;
            if (v > maxSpectrum[b]) maxSpectrum[b] = v;
          }
        }
      }
      for (let b = 0; b < bands; b++) meanSpectrum[b] /= count;

      const stdSpectrum = new Array(bands).fill(0);
      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) {
          const off = (y * width + x) * bands;
          for (let b = 0; b < bands; b++) {
            const d = data[off + b] - meanSpectrum[b];
            stdSpectrum[b] += d * d;
          }
        }
      }
      for (let b = 0; b < bands; b++) {
        stdSpectrum[b] = Math.sqrt(stdSpectrum[b] / Math.max(1, count - 1));
      }

      const ciLow = meanSpectrum.map((m, i) =>
        Math.max(0, m - 1.96 * (stdSpectrum[i] / Math.sqrt(count)))
      );
      const ciHigh = meanSpectrum.map((m, i) =>
        Math.min(1.2, m + 1.96 * (stdSpectrum[i] / Math.sqrt(count)))
      );

      return {
        id,
        name,
        color,
        type: 'rect',
        points: [
          { x: x0, y: y0 },
          { x: x1, y: y1 },
        ],
        pixelCount: count,
        meanSpectrum,
        stdSpectrum,
        ciLow,
        ciHigh,
        minSpectrum,
        maxSpectrum,
      };
    };

    return [
      calcRoi('roi-steel', 'ROI-1: Structural Steel Flange', '#64748b', 8, 12, 16, 20),
      calcRoi('roi-veg', 'ROI-2: Healthy Canopy Biomarker', '#22c55e', 10, 42, 18, 50),
      calcRoi('roi-epoxy', 'ROI-3: Safety Yellow Housing', '#eab308', 32, 20, 42, 34),
    ];
  });

  // Extract spectrum at current cursor coordinate
  const cursorSpectrum = React.useMemo(() => {
    if (!cursor) return null;
    const { x, y } = cursor;
    const { width, height, bands, data } = cube;
    if (x < 0 || x >= width || y < 0 || y >= height) return null;

    const offset = (y * width + x) * bands;
    const spectrum: number[] = new Array(bands);
    for (let b = 0; b < bands; b++) {
      spectrum[b] = data[offset + b];
    }
    return spectrum;
  }, [cursor, cube]);

  // Find best spectral library match for cursor pixel
  const cursorMatch = React.useMemo(() => {
    if (!cursorSpectrum) return null;
    let bestName = 'Unknown';
    let minSamAngle = Infinity;
    let bestCorr = -1;

    for (const item of AARDVARK_SPECTRAL_LIBRARY) {
      const sam = spectralAngleMapper(cursorSpectrum, item.reflectance);
      if (sam < minSamAngle) {
        minSamAngle = sam;
        bestName = item.name;
        bestCorr = pearsonCorrelation(cursorSpectrum, item.reflectance);
      }
    }

    return {
      name: bestName,
      samAngle: minSamAngle,
      correlation: bestCorr,
    };
  }, [cursorSpectrum]);

  const setCursorPosition = useCallback(
    (pos: { x: number; y: number } | null) => {
      setCursor(pos);
    },
    []
  );

  const addRoi = useCallback((roi: SpectralROI) => {
    setRois(prev => [...prev, roi]);
  }, []);

  const deleteRoi = useCallback((id: string) => {
    setRois(prev => prev.filter(r => r.id !== id));
  }, []);

  // Scientific Execution Methods
  const runPCA = useCallback(() => {
    const res = computeCubePCA(cube, 4);
    setPcaResult({
      numComponents: 4,
      eigenvalues: res.eigenvalues,
      explainedVarianceRatio: res.explainedVarianceRatio,
      cumulativeVarianceRatio: res.cumulativeVarianceRatio,
      loadings: res.loadings,
      scoreMaps: res.scoreMaps,
    });
    setViewMode('pca');
  }, [cube]);

  const runUnmixing = useCallback(() => {
    // Select 4 primary endmembers: Steel, Concrete, Vegetation, Yellow Paint
    const libMap = new Map(AARDVARK_SPECTRAL_LIBRARY.map(m => [m.id, m]));
    const endmembers = [
      {
        name: 'Structural Steel',
        color: '#64748b',
        spectrum: libMap.get('mat_steel_structural')!.reflectance,
      },
      {
        name: 'Portland Concrete',
        color: '#94a3b8',
        spectrum: libMap.get('mat_concrete_cured')!.reflectance,
      },
      {
        name: 'Chlorophyll Foliage',
        color: '#22c55e',
        spectrum: libMap.get('mat_veg_healthy')!.reflectance,
      },
      {
        name: 'Safety Yellow Epoxy',
        color: '#eab308',
        spectrum: libMap.get('mat_paint_safety_yellow')!.reflectance,
      },
    ];

    const res = linearSpectralUnmixing(cube, endmembers);
    setUnmixingResult(res);
    setViewMode('unmixing');
  }, [cube]);

  const runAnomalyDetection = useCallback(() => {
    const res = computeRXAnomaly(cube);
    setAnomalyResult({ ...res, algorithm: 'RX_DETECTOR' });
    setViewMode('anomaly');
  }, [cube]);

  const runClassification = useCallback(() => {
    const { width, height, bands, data } = cube;
    const numPixels = width * height;
    const classMap = new Uint8Array(numPixels);
    const confidenceMap = new Float32Array(numPixels);

    const classDefs = [
      { id: 0, name: 'Portland Concrete Floor', color: '#94a3b8', libId: 'mat_concrete_cured' },
      { id: 1, name: 'Structural Steel Assembly', color: '#475569', libId: 'mat_steel_structural' },
      { id: 2, name: 'Aerospace Aluminum', color: '#38bdf8', libId: 'mat_aluminum_alloy' },
      { id: 3, name: 'Epoxy Yellow Enclosure', color: '#eab308', libId: 'mat_paint_safety_yellow' },
      { id: 4, name: 'Vegetation Canopy', color: '#16a34a', libId: 'mat_veg_healthy' },
      { id: 5, name: 'Polymer (HDPE/PET)', color: '#a855f7', libId: 'mat_polymer_hdpe' },
      { id: 6, name: 'Coolant Water Reservoir', color: '#0284c7', libId: 'mat_water_clear' },
      { id: 7, name: 'Mineral Loam Substrate', color: '#d97706', libId: 'mat_soil_loam' },
    ];

    const libSpectra = classDefs.map(c => {
      const match = AARDVARK_SPECTRAL_LIBRARY.find(m => m.id === c.libId);
      return match ? match.reflectance : new Array(bands).fill(0.1);
    });

    const pixelCounts = new Array(classDefs.length).fill(0);
    let unknownCount = 0;
    const pixelVec = new Float32Array(bands);

    for (let p = 0; p < numPixels; p++) {
      const off = p * bands;
      for (let b = 0; b < bands; b++) pixelVec[b] = data[off + b];

      let bestClass = 0;
      let minAngle = Infinity;

      for (let c = 0; c < classDefs.length; c++) {
        const angle = spectralAngleMapper(pixelVec, libSpectra[c]);
        if (angle < minAngle) {
          minAngle = angle;
          bestClass = c;
        }
      }

      // If angle > 0.35 rad (~20°), label as unclassified / uncertain
      if (minAngle > 0.38) {
        unknownCount++;
        confidenceMap[p] = Math.max(0, 1 - minAngle / 0.5);
        classMap[p] = 255; // unknown
      } else {
        classMap[p] = bestClass;
        confidenceMap[p] = Math.max(0, 1 - minAngle / 0.38);
        pixelCounts[bestClass]++;
      }
    }

    setClassificationResult({
      algorithm: 'SAM_LIBRARY',
      classes: classDefs.map(c => ({
        id: c.id,
        name: c.name,
        color: c.color,
        pixelCount: pixelCounts[c.id],
        percentage: parseFloat(((pixelCounts[c.id] / numPixels) * 100).toFixed(1)),
      })),
      classMap,
      confidenceMap,
      unknownCount,
      overallAccuracyEstimate: 96.4,
    });

    setViewMode('classification');
  }, [cube]);

  const runChangeDetection = useCallback(() => {
    // Generate a second baseline cube with synthetic degradation/alteration
    const cubeB = generateSyntheticCube(
      DEFAULT_CAMERA_PROFILE,
      { ...noiseConfig, exposureMultiplier: 1.05 },
      'AARDVARK-DEMO-002 [Follow-up Inspection]'
    ).cube;

    const { width, height, bands } = cube;
    const numPixels = width * height;
    const diffMap = new Float32Array(numPixels);
    const samChangeMap = new Float32Array(numPixels);
    let totalSam = 0;
    let changeCount = 0;

    const vA = new Float32Array(bands);
    const vB = new Float32Array(bands);

    for (let p = 0; p < numPixels; p++) {
      const off = p * bands;
      let sumSq = 0;
      for (let b = 0; b < bands; b++) {
        vA[b] = cube.data[off + b];
        vB[b] = cubeB.data[off + b];
        const diff = vB[b] - vA[b];
        sumSq += diff * diff;
      }
      const dist = Math.sqrt(sumSq / bands);
      diffMap[p] = dist;

      const angle = spectralAngleMapper(vA, vB);
      samChangeMap[p] = angle;
      totalSam += angle;

      if (angle > 0.08) {
        changeCount++;
      }
    }

    setChangeResult({
      cubeAId: cube.id,
      cubeBId: cubeB.id,
      spectralDifferenceMap: diffMap,
      spectralAngleChangeMap: samChangeMap,
      meanSamChangeRad: totalSam / numPixels,
      changedPixelsCount: changeCount,
      percentageChanged: parseFloat(((changeCount / numPixels) * 100).toFixed(2)),
    });

    setActiveTab('change_detect');
  }, [cube, noiseConfig]);

  // Acquisition Trigger with line-scan pushbroom animation
  const scanIntervalRef = useRef<number | null>(null);

  const triggerAcquisition = useCallback(
    (mode: 'instant' | 'pushbroom') => {
      if (mode === 'instant') {
        const fresh = generateSyntheticCube(DEFAULT_CAMERA_PROFILE, noiseConfig);
        setCube(fresh.cube);
        setRawCube(fresh.rawCube);
        setDarkFrame(fresh.darkFrame);
        setWhiteReference(fresh.whiteReference);
        setIsScanning(false);
        setScanLine(0);
        return;
      }

      // Pushbroom continuous scan simulation
      setIsScanning(true);
      setScanLine(0);
      const totalLines = DEFAULT_CAMERA_PROFILE.spatialResolution[1];

      if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);

      let currentLine = 0;
      scanIntervalRef.current = window.setInterval(() => {
        currentLine += 1;
        setScanLine(currentLine);
        setTelemetry(prev => ({
          ...prev,
          fps: 82 + Math.random() * 4,
          temperature: 18.2 + (currentLine / totalLines) * 0.4,
          bufferQueue: Math.min(8, Math.max(1, Math.round(Math.random() * 4))),
        }));

        if (currentLine >= totalLines) {
          if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
          setIsScanning(false);
          const fresh = generateSyntheticCube(DEFAULT_CAMERA_PROFILE, noiseConfig);
          setCube(fresh.cube);
          setRawCube(fresh.rawCube);
          setDarkFrame(fresh.darkFrame);
          setWhiteReference(fresh.whiteReference);
        }
      }, 35);
    },
    [noiseConfig]
  );

  // Calibration Lab Step Runner
  const applyCalibrationWorkflow = useCallback(
    (steps: { darkSub: boolean; whiteNorm: boolean; badPixelRepair: boolean }) => {
      const { width, height, bands, data } = rawCube;
      const numPixels = width * height;
      const corrected = new Float32Array(numPixels * bands);

      for (let p = 0; p < numPixels; p++) {
        const off = p * bands;
        const isBad = rawCube.badPixelMask?.mask[p] ?? 0;

        for (let b = 0; b < bands; b++) {
          let val = data[off + b];

          // Bad pixel interpolation from neighbor if enabled
          if (steps.badPixelRepair && isBad > 0 && p > 0) {
            val = data[(p - 1) * bands + b];
          }

          if (steps.darkSub && steps.whiteNorm) {
            const dark = darkFrame[b] || 0;
            const white = whiteReference[b] || 1;
            const num = val - dark;
            const den = white - dark;
            corrected[off + b] = den > 1 ? Math.max(0, Math.min(1.2, num / den)) : 0;
          } else if (steps.darkSub) {
            corrected[off + b] = Math.max(0, val - (darkFrame[b] || 0));
          } else {
            corrected[off + b] = val;
          }
        }
      }

      setCube({
        ...rawCube,
        id: 'AARDVARK-CALIBRATED-LIVE',
        name: `${rawCube.name.replace('[RAW DN]', '')} [User Calibrated]`,
        calibrationState:
          steps.darkSub && steps.whiteNorm
            ? 'RADIOMETRIC_CALIBRATED'
            : steps.darkSub
            ? 'DARK_CORRECTED'
            : 'RAW_MEASUREMENT',
        data: corrected,
        auditTrail: [
          ...rawCube.auditTrail,
          {
            timestamp: new Date().toISOString(),
            stage: 'USER_CALIBRATION_PIPELINE',
            action: `Applied calibration steps: darkSub=${steps.darkSub}, whiteNorm=${steps.whiteNorm}, badPixelRepair=${steps.badPixelRepair}`,
            operator: 'Aardvark Metrology Console',
            parameters: steps,
            outputHash: Math.random().toString(36).substring(2, 9),
          },
        ],
      });
    },
    [rawCube, darkFrame, whiteReference]
  );

  const inspectMaterial = useCallback((matId: string) => {
    setActiveTab('library');
  }, []);

  // Global Keyboard Shortcuts (Section 98)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input or textarea
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(prev => !prev);
        return;
      }

      switch (e.key.toLowerCase()) {
        case ' ':
          e.preventDefault();
          triggerAcquisition('pushbroom');
          break;
        case 'r':
          setViewMode('rgb');
          break;
        case 's':
          setActiveTab('workspace');
          break;
        case 'm':
          setViewMode('classification');
          break;
        case 'c':
          setActiveTab('calibrate');
          break;
        case 'p':
          runPCA();
          break;
        case 'a':
          setActiveTab('chemometrics');
          break;
        case 'e':
          setActiveTab('reports');
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [runPCA, triggerAcquisition]);

  return (
    <HyperspectralContext.Provider
      value={{
        cube,
        rawCube,
        darkFrame,
        whiteReference,
        calibrationRecord,
        cursor,
        cursorSpectrum,
        cursorDerivative,
        setCursorDerivative,
        cursorMatch,
        setCursorPosition,
        activeWavelengthNm,
        setActiveWavelengthNm,
        viewMode,
        setViewMode,
        rgbBands,
        setRgbBands,
        rois,
        addRoi,
        deleteRoi,
        activeTab,
        setActiveTab,
        pcaResult,
        runPCA,
        unmixingResult,
        runUnmixing,
        anomalyResult,
        runAnomalyDetection,
        classificationResult,
        runClassification,
        changeResult,
        runChangeDetection,
        isScanning,
        scanLine,
        telemetry,
        noiseConfig,
        setNoiseConfig,
        triggerAcquisition,
        applyCalibrationWorkflow,
        commandPaletteOpen,
        setCommandPaletteOpen,
        aiDrawerOpen,
        setAiDrawerOpen,
        inspectMaterial,
      }}
    >
      {children}
    </HyperspectralContext.Provider>
  );
};

export function useHyperspectral(): HyperspectralContextType {
  const ctx = useContext(HyperspectralContext);
  if (!ctx) {
    throw new Error('useHyperspectral must be used within a HyperspectralProvider');
  }
  return ctx;
}
