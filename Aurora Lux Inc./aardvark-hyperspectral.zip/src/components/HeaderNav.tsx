/**
 * Aardvark Hyperspectral Navigation & Top Header Bar
 */

import React from 'react';
import {
  Activity,
  Layers,
  Camera,
  Sliders,
  Sparkles,
  Box,
  BookOpen,
  GitCompare,
  GitFork,
  FileText,
  Search,
  Bot,
  AlertTriangle,
  Radio,
  Cpu,
} from 'lucide-react';
import { TabType, useHyperspectral } from '../context/HyperspectralContext';

export const HeaderNav: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    cube,
    telemetry,
    isScanning,
    setCommandPaletteOpen,
    aiDrawerOpen,
    setAiDrawerOpen,
  } = useHyperspectral();

  const navItems: { id: TabType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'workspace', label: 'Cube Workspace', icon: Layers },
    { id: 'acquire', label: 'Acquisition', icon: Camera },
    { id: 'calibrate', label: 'Calibration Lab', icon: Sliders },
    { id: 'chemometrics', label: 'Analysis & PCA', icon: Activity },
    { id: '3d_twin', label: '3D Digital Twin', icon: Box },
    { id: 'library', label: 'Spectral Library', icon: BookOpen },
    { id: 'change_detect', label: 'Change Detection', icon: GitCompare },
    { id: 'pipeline', label: 'Pipeline Graph', icon: GitFork },
    { id: 'reports', label: 'Reports & Export', icon: FileText },
  ];

  return (
    <header className="bg-slate-950 text-slate-100 border-b border-slate-800 select-none sticky top-0 z-40">
      {/* Top Banner: Brand, Telemetry, and System Status */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-900 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-sky-500/20 border border-sky-400 flex items-center justify-center font-mono font-bold text-sky-400 text-xs">
              A
            </div>
            <span className="font-semibold tracking-wider text-slate-100 uppercase text-sm">
              Aardvark Hyperspectral
            </span>
          </div>
          <span className="text-slate-600">/</span>
          <span className="text-slate-400 font-mono tracking-tight text-[11px]">
            VNIR-1024 SPEC-CORE v3.7.2
          </span>
          <span className="text-slate-600">/</span>
          <div className="flex items-center gap-1.5 text-amber-400/90 font-mono text-[11px] bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/50">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>SYNTHETIC DEMONSTRATION DATA</span>
          </div>
        </div>

        {/* Real-time Telemetry strip */}
        <div className="flex items-center gap-4 text-slate-400 font-mono text-[11px]">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">STATE:</span>
            <span
              className={`font-semibold ${
                cube.calibrationState === 'RADIOMETRIC_CALIBRATED'
                  ? 'text-emerald-400'
                  : cube.calibrationState === 'RAW_MEASUREMENT'
                  ? 'text-amber-400'
                  : 'text-sky-400'
              }`}
            >
              {cube.calibrationState}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <Radio className={`w-3.5 h-3.5 ${isScanning ? 'text-amber-400 animate-pulse' : 'text-slate-500'}`} />
            <span>{isScanning ? 'SCANNING' : 'STANDBY'}</span>
            <span className="text-slate-300 font-semibold">{telemetry.fps.toFixed(1)} FPS</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">TEMP:</span>
            <span className="text-slate-300">{telemetry.temperature.toFixed(1)}°C</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-emerald-400">GPU ACCEL</span>
          </div>

          <div className="flex items-center gap-2 border-l border-slate-800 pl-3">
            <button
              onClick={() => setCommandPaletteOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-slate-100 transition-colors"
              title="Command Palette (⌘K)"
            >
              <Search className="w-3 h-3 text-slate-400" />
              <span>⌘K</span>
            </button>

            <button
              onClick={() => setAiDrawerOpen(!aiDrawerOpen)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition-colors ${
                aiDrawerOpen
                  ? 'bg-sky-950/80 border-sky-600 text-sky-200'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-300 hover:text-slate-100'
              }`}
            >
              <Bot className="w-3.5 h-3.5 text-sky-400" />
              <span>AI Assistant</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="flex items-center px-2 bg-slate-950 overflow-x-auto scrollbar-none">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium border-b-2 transition-all whitespace-nowrap ${
                isActive
                  ? 'border-sky-400 text-sky-300 bg-slate-900/60'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/30'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-sky-400' : 'text-slate-500'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
