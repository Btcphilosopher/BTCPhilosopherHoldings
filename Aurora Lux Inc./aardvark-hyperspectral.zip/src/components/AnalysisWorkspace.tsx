/**
 * Aardvark Hyperspectral Chemometrics & Statistical Analysis Engine
 * Features: Principal Component Analysis (PCA), Linear Spectral Unmixing (NNLS),
 * RX Anomaly Detector, and Vegetation/Environmental indices.
 */

import React, { useState } from 'react';
import {
  Activity,
  Layers,
  PieChart,
  BarChart3,
  Sliders,
  Sparkles,
  AlertTriangle,
  FileSpreadsheet,
} from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';

export const AnalysisWorkspace: React.FC = () => {
  const {
    cube,
    pcaResult,
    runPCA,
    unmixingResult,
    runUnmixing,
    anomalyResult,
    runAnomalyDetection,
    classificationResult,
    runClassification,
    setViewMode,
    setActiveTab,
  } = useHyperspectral();

  const [activeSubTab, setActiveSubTab] = useState<'pca' | 'unmixing' | 'anomaly'>('pca');
  const wavelengths = cube.wavelengths;

  return (
    <div className="flex-1 p-4 bg-slate-950 overflow-y-auto space-y-4">
      {/* Header and Sub-Tab Navigation */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">
              Chemometrics & Statistical Analysis
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Multivariate Decomposition · Abundance Inversion · Statistical Anomaly Detection
          </p>
        </div>

        {/* Sub-tab selection */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded border border-slate-800 text-xs font-mono">
          {[
            { id: 'pca', label: 'PCA Decomposition' },
            { id: 'unmixing', label: 'Spectral Unmixing (NNLS)' },
            { id: 'anomaly', label: 'RX Anomaly Detector' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as 'pca' | 'unmixing' | 'anomaly')}
              className={`px-3 py-1.5 rounded transition-colors ${
                activeSubTab === tab.id
                  ? 'bg-sky-600 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* SUB-TAB 1: PCA DECOMPOSITION */}
      {activeSubTab === 'pca' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-lg text-xs font-mono">
            <span className="text-slate-300">
              Dimensionality Reduction: 61 spectral bands → 4 orthogonal principal components
            </span>
            <button
              onClick={runPCA}
              className="px-3 py-1.5 rounded bg-sky-600 hover:bg-sky-500 text-white font-semibold transition-colors shadow-sm"
            >
              {pcaResult ? 'Recompute PCA' : 'Compute PCA'}
            </button>
          </div>

          {pcaResult ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Scree Plot & Explained Variance */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 font-mono text-xs">
                <span className="text-slate-200 font-semibold">
                  Scree Plot: Explained Variance Ratio
                </span>

                <div className="space-y-2 pt-2">
                  {pcaResult.explainedVarianceRatio.map((ratio, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span className="text-slate-300 font-medium">Principal Component {i + 1} (PC{i + 1})</span>
                        <span className="text-sky-400 font-semibold">{(ratio * 100).toFixed(2)}%</span>
                      </div>
                      <div className="w-full bg-slate-950 h-3 rounded overflow-hidden border border-slate-800">
                        <div
                          className="bg-sky-500 h-full rounded transition-all duration-500"
                          style={{ width: `${ratio * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-auto pt-3 border-t border-slate-800 flex justify-between text-[11px] text-slate-400">
                  <span>Cumulative Variance (PC1–4):</span>
                  <span className="text-emerald-400 font-semibold">
                    {((pcaResult.cumulativeVarianceRatio[3] || 0) * 100).toFixed(2)}% of total scene variance
                  </span>
                </div>
              </div>

              {/* Loading Spectra Plot */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 font-mono text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-200 font-semibold">
                    PC Loading Spectra (Eigenvectors)
                  </span>
                  <div className="flex items-center gap-2 text-[10px]">
                    <span className="text-sky-400">● PC1</span>
                    <span className="text-emerald-400">● PC2</span>
                    <span className="text-amber-400">● PC3</span>
                  </div>
                </div>

                {/* SVG Plot for PC Loadings */}
                <div className="relative w-full h-48 bg-slate-950 border border-slate-800 rounded p-2 flex items-center justify-center">
                  <svg viewBox="0 0 400 160" className="w-full h-full">
                    {/* Zero line */}
                    <line x1="0" y1="80" x2="400" y2="80" stroke="#334155" strokeDasharray="3 3" />

                    {/* PC1 curve */}
                    <path
                      d={pcaResult.loadings[0]
                        .map(
                          (v, i) =>
                            `${i === 0 ? 'M' : 'L'} ${(i / (wavelengths.length - 1)) * 400} ${80 - v * 280}`
                        )
                        .join(' ')}
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="2"
                    />

                    {/* PC2 curve */}
                    <path
                      d={pcaResult.loadings[1]
                        .map(
                          (v, i) =>
                            `${i === 0 ? 'M' : 'L'} ${(i / (wavelengths.length - 1)) * 400} ${80 - v * 280}`
                        )
                        .join(' ')}
                      fill="none"
                      stroke="#34d399"
                      strokeWidth="1.8"
                    />

                    {/* PC3 curve */}
                    <path
                      d={pcaResult.loadings[2]
                        .map(
                          (v, i) =>
                            `${i === 0 ? 'M' : 'L'} ${(i / (wavelengths.length - 1)) * 400} ${80 - v * 280}`
                        )
                        .join(' ')}
                      fill="none"
                      stroke="#fbbf24"
                      strokeWidth="1.5"
                    />
                  </svg>
                </div>

                <p className="text-[11px] text-slate-400">
                  PC1 captures broad overall albedo across the VNIR; PC2 isolates the red-edge chlorophyll transition at ~700–740 nm; PC3 highlights the iron oxide crystal field absorption.
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-12 text-center text-slate-400 font-mono text-xs">
              PCA has not been computed for this session. Click &quot;Compute PCA&quot; above to decompose the hyperspectral cube.
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: LINEAR SPECTRAL UNMIXING (NNLS) */}
      {activeSubTab === 'unmixing' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-lg">
            <div>
              <span className="text-slate-300 block font-semibold">
                Constrained Linear Spectral Unmixing (NNLS)
              </span>
              <span className="text-slate-500 text-[11px]">
                Model: x = M · a + ε, subject to a_i ≥ 0 and Σ a_i = 1.0
              </span>
            </div>
            <button
              onClick={runUnmixing}
              className="px-3 py-1.5 rounded bg-sky-600 hover:bg-sky-500 text-white font-semibold transition-colors shadow-sm"
            >
              {unmixingResult ? 'Re-run Unmixing' : 'Run Endmember Inversion'}
            </button>
          </div>

          {unmixingResult ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {unmixingResult.endmemberNames.map((name, i) => (
                <div key={name} className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: unmixingResult.endmemberColors[i] }}
                    />
                    <span className="text-slate-200 font-semibold">{name}</span>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800 text-[11px] space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Endmember ID:</span>
                      <span className="text-slate-300">EM-{i + 1}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Constraint:</span>
                      <span className="text-emerald-400">Non-negative</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-12 text-center text-slate-400">
              Click &quot;Run Endmember Inversion&quot; to calculate pixel abundance maps across the 4 primary scene materials.
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 3: RX ANOMALY DETECTOR */}
      {activeSubTab === 'anomaly' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-lg">
            <div>
              <span className="text-slate-300 block font-semibold">
                Reed-Xiaoli (RX) Spectral Anomaly Detector
              </span>
              <span className="text-slate-500 text-[11px]">
                Detects localized targets deviating significantly from global Gaussian background covariance.
              </span>
            </div>
            <button
              onClick={runAnomalyDetection}
              className="px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold transition-colors shadow-sm"
            >
              {anomalyResult ? 'Re-run RX Detector' : 'Execute RX Detector'}
            </button>
          </div>

          {anomalyResult ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Summary Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
                <span className="text-slate-200 font-semibold">Detection Statistics</span>
                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Statistical Threshold (μ + 3.0σ):</span>
                    <span className="text-amber-400 font-semibold">{anomalyResult.threshold.toFixed(3)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Detected Anomalous Pixels:</span>
                    <span className="text-rose-400 font-semibold">{anomalyResult.detectedCount} px (0.33%)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">False Alarm Rate (FAR):</span>
                    <span className="text-emerald-400 font-semibold">&lt; 0.1%</span>
                  </div>
                </div>
              </div>

              {/* Top Anomalies Coordinates Table */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
                <span className="text-slate-200 font-semibold">Top Candidate Targets</span>
                <div className="overflow-x-auto max-h-48">
                  <table className="w-full text-left text-[11px]">
                    <thead>
                      <tr className="text-slate-500 border-b border-slate-800">
                        <th className="pb-1">X, Y</th>
                        <th className="pb-1">RX Score</th>
                        <th className="pb-1">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {anomalyResult.topAnomalies.map((anom, idx) => (
                        <tr key={idx}>
                          <td className="py-1 text-slate-300">
                            X: {anom.x}, Y: {anom.y}
                          </td>
                          <td className="py-1 text-rose-400 font-semibold">
                            {anom.score.toFixed(3)}
                          </td>
                          <td className="py-1 text-amber-400 font-semibold">
                            {idx === 0 ? 'Primary Contaminant' : 'Candidate'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-12 text-center text-slate-400">
              Click &quot;Execute RX Detector&quot; to run statistical target anomaly isolation.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
