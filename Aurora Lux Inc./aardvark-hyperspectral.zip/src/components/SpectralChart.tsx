/**
 * High-Precision Hyperspectral Scientific Plotting Component
 * Supports continuum removal, 1st/2nd derivatives, SNV, ROI envelopes, and absorption markers.
 */

import React, { useMemo, useState } from 'react';
import {
  continuumRemoval,
  detectAbsorptionFeatures,
  firstDerivative,
  secondDerivative,
  standardNormalVariate,
} from '../core/spectral-math';
import { useHyperspectral } from '../context/HyperspectralContext';

interface SpectralChartProps {
  customSpectrum?: number[];
  customLabel?: string;
  height?: number;
  showRois?: boolean;
}

export const SpectralChart: React.FC<SpectralChartProps> = ({
  customSpectrum,
  customLabel,
  height = 240,
  showRois = true,
}) => {
  const {
    cube,
    cursor,
    cursorSpectrum,
    cursorDerivative,
    setCursorDerivative,
    rois,
    activeWavelengthNm,
    setActiveWavelengthNm,
  } = useHyperspectral();

  const [hoverBand, setHoverBand] = useState<{
    wavelength: number;
    value: number;
    x: number;
    y: number;
  } | null>(null);

  const wavelengths = cube.wavelengths;
  const activeSpectrum = customSpectrum || cursorSpectrum;

  // Process spectrum based on selected derivative/preprocessing mode
  const processedData = useMemo(() => {
    if (!activeSpectrum || activeSpectrum.length === 0) return null;

    let displayValues: number[] = [...activeSpectrum];
    let continuumValues: number[] | null = null;

    if (cursorDerivative === '1st') {
      displayValues = firstDerivative(activeSpectrum, wavelengths);
    } else if (cursorDerivative === '2nd') {
      displayValues = secondDerivative(activeSpectrum, wavelengths);
    } else if (cursorDerivative === 'snv') {
      displayValues = standardNormalVariate(activeSpectrum);
    } else if (cursorDerivative === 'continuum') {
      const cr = continuumRemoval(activeSpectrum, wavelengths);
      displayValues = cr.removed;
      continuumValues = cr.continuum;
    }

    const absorptionFeatures =
      cursorDerivative === 'raw' || cursorDerivative === 'continuum'
        ? detectAbsorptionFeatures(wavelengths, activeSpectrum)
        : [];

    return {
      displayValues,
      continuumValues,
      absorptionFeatures,
    };
  }, [activeSpectrum, cursorDerivative, wavelengths]);

  // Determine Y-axis min/max
  const { yMin, yMax } = useMemo(() => {
    if (!processedData) return { yMin: 0, yMax: 1 };
    const vals = processedData.displayValues;

    if (cursorDerivative === 'raw' || cursorDerivative === 'continuum') {
      return { yMin: 0.0, yMax: 1.05 };
    }

    let min = Infinity;
    let max = -Infinity;
    for (const v of vals) {
      if (v < min) min = v;
      if (v > max) max = v;
    }
    const pad = (max - min) * 0.1 || 0.1;
    return {
      yMin: parseFloat((min - pad).toFixed(3)),
      yMax: parseFloat((max + pad).toFixed(3)),
    };
  }, [processedData, cursorDerivative]);

  // Chart dimensions & scaling
  const padding = { top: 20, right: 30, bottom: 35, left: 55 };
  const chartWidth = 600;
  const chartHeight = height;
  const plotWidth = chartWidth - padding.left - padding.right;
  const plotHeight = chartHeight - padding.top - padding.bottom;

  const wMin = wavelengths[0] || 400;
  const wMax = wavelengths[wavelengths.length - 1] || 1000;

  const getX = (w: number) => padding.left + ((w - wMin) / (wMax - wMin)) * plotWidth;
  const getY = (v: number) =>
    padding.top + plotHeight - ((v - yMin) / (yMax - yMin || 1)) * plotHeight;

  // Build SVG path strings
  const cursorPath = useMemo(() => {
    if (!processedData) return '';
    return processedData.displayValues
      .map((v, i) => `${i === 0 ? 'M' : 'L'} ${getX(wavelengths[i])} ${getY(v)}`)
      .join(' ');
  }, [processedData, wavelengths, yMin, yMax]);

  const continuumPath = useMemo(() => {
    if (!processedData?.continuumValues) return '';
    return processedData.continuumValues
      .map((v, i) => `${i === 0 ? 'M' : 'L'} ${getX(wavelengths[i])} ${getY(v)}`)
      .join(' ');
  }, [processedData, wavelengths, yMin, yMax]);

  // ROI paths
  const roiPaths = useMemo(() => {
    if (!showRois || cursorDerivative !== 'raw') return [];
    return rois.map(roi => {
      const linePath = roi.meanSpectrum
        .map((v, i) => `${i === 0 ? 'M' : 'L'} ${getX(wavelengths[i])} ${getY(v)}`)
        .join(' ');

      // Envelope path (top curve then reversed bottom curve)
      const topPoints = roi.ciHigh.map((v, i) => `${getX(wavelengths[i])},${getY(v)}`);
      const bottomPoints = roi.ciLow
        .slice()
        .reverse()
        .map((v, idx) => {
          const origIdx = roi.ciLow.length - 1 - idx;
          return `${getX(wavelengths[origIdx])},${getY(v)}`;
        });
      const areaPath = `M ${topPoints.join(' L ')} L ${bottomPoints.join(' L ')} Z`;

      return {
        id: roi.id,
        name: roi.name,
        color: roi.color,
        linePath,
        areaPath,
      };
    });
  }, [rois, showRois, cursorDerivative, wavelengths, yMin, yMax]);

  // Handle mouse move on plot
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!processedData) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const svgX = (e.clientX - rect.left) * (chartWidth / rect.width);
    const plotX = svgX - padding.left;

    if (plotX < 0 || plotX > plotWidth) {
      setHoverBand(null);
      return;
    }

    const targetW = wMin + (plotX / plotWidth) * (wMax - wMin);
    // Find closest band
    let closestIdx = 0;
    let minD = Infinity;
    for (let i = 0; i < wavelengths.length; i++) {
      const d = Math.abs(wavelengths[i] - targetW);
      if (d < minD) {
        minD = d;
        closestIdx = i;
      }
    }

    const w = wavelengths[closestIdx];
    const val = processedData.displayValues[closestIdx];
    setHoverBand({
      wavelength: w,
      value: val,
      x: getX(w),
      y: getY(val),
    });
  };

  const handlePlotClick = () => {
    if (hoverBand) {
      setActiveWavelengthNm(hoverBand.wavelength);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 select-none flex flex-col gap-2">
      {/* Chart Header & Preprocessing Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-mono font-semibold text-slate-200">
            {customLabel || (cursor ? `Pixel (${cursor.x}, ${cursor.y})` : 'Spectral Profile')}
          </span>
          <span className="text-slate-500">·</span>
          <span className="text-slate-400 font-mono text-[11px]">
            {cursorDerivative === 'raw'
              ? cube.calibrationState === 'RADIOMETRIC_CALIBRATED'
                ? 'Reflectance [0..1]'
                : 'Raw Digital Numbers (DN)'
              : cursorDerivative === 'continuum'
              ? 'Continuum Removed [R/C]'
              : cursorDerivative === 'snv'
              ? 'Standard Normal Variate'
              : `${cursorDerivative} Derivative`}
          </span>
        </div>

        {/* Derivative & Preprocessing segmented buttons */}
        <div className="flex items-center gap-1 p-0.5 bg-slate-950 rounded border border-slate-800 text-[11px] font-mono">
          {(['raw', '1st', '2nd', 'continuum', 'snv'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => setCursorDerivative(mode)}
              className={`px-2 py-0.5 rounded transition-colors ${
                cursorDerivative === mode
                  ? 'bg-sky-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {mode.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Main SVG Plot */}
      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          className="w-full h-auto cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHoverBand(null)}
          onClick={handlePlotClick}
        >
          {/* Background Grid */}
          <rect
            x={padding.left}
            y={padding.top}
            width={plotWidth}
            height={plotHeight}
            fill="#090d16"
            stroke="#1e293b"
            strokeWidth="1"
          />

          {/* Vertical Wavelength Grid Lines (every 50nm) */}
          {Array.from({ length: 13 }).map((_, i) => {
            const w = 400 + i * 50;
            const x = getX(w);
            return (
              <g key={w}>
                <line
                  x1={x}
                  y1={padding.top}
                  x2={x}
                  y2={padding.top + plotHeight}
                  stroke="#1e293b"
                  strokeDasharray="2 3"
                />
                <text
                  x={x}
                  y={padding.top + plotHeight + 16}
                  fill="#64748b"
                  fontSize="10"
                  fontFamily="monospace"
                  textAnchor="middle"
                >
                  {w}
                </text>
              </g>
            );
          })}

          {/* Horizontal Value Grid Lines */}
          {[0, 0.25, 0.5, 0.75, 1.0].map(frac => {
            const val = yMin + frac * (yMax - yMin);
            const y = getY(val);
            return (
              <g key={frac}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={padding.left + plotWidth}
                  y2={y}
                  stroke="#1e293b"
                  strokeDasharray="2 3"
                />
                <text
                  x={padding.left - 8}
                  y={y + 3.5}
                  fill="#64748b"
                  fontSize="10"
                  fontFamily="monospace"
                  textAnchor="end"
                >
                  {val.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Active Wavelength Indicator Marker */}
          {activeWavelengthNm && (
            <line
              x1={getX(activeWavelengthNm)}
              y1={padding.top}
              x2={getX(activeWavelengthNm)}
              y2={padding.top + plotHeight}
              stroke="#0284c7"
              strokeWidth="1.5"
              strokeDasharray="4 2"
            />
          )}

          {/* ROI Envelopes and Curves */}
          {roiPaths.map(r => (
            <g key={r.id}>
              <path d={r.areaPath} fill={r.color} fillOpacity="0.12" />
              <path
                d={r.linePath}
                fill="none"
                stroke={r.color}
                strokeWidth="1.5"
                strokeDasharray="3 2"
              />
            </g>
          ))}

          {/* Continuum Curve in Continuum Mode */}
          {continuumPath && (
            <path
              d={continuumPath}
              fill="none"
              stroke="#64748b"
              strokeWidth="1"
              strokeDasharray="3 3"
            />
          )}

          {/* Active Cursor Spectrum Curve */}
          {cursorPath && (
            <path
              d={cursorPath}
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2.2"
              strokeLinejoin="round"
            />
          )}

          {/* Absorption Feature Center Markers */}
          {processedData?.absorptionFeatures.map((feat, idx) => {
            const fx = getX(feat.centerNm);
            const fy = getY(
              cursorDerivative === 'continuum' ? 1 - feat.depth : activeSpectrum ? activeSpectrum[wavelengths.indexOf(feat.centerNm)] || 0.5 : 0.5
            );
            return (
              <g key={idx}>
                <circle cx={fx} cy={fy} r="3.5" fill="#f43f5e" stroke="#ffffff" strokeWidth="1" />
                <line
                  x1={fx}
                  y1={fy - 6}
                  x2={fx}
                  y2={fy - 14}
                  stroke="#f43f5e"
                  strokeWidth="1"
                />
                <text
                  x={fx}
                  y={fy - 16}
                  fill="#f43f5e"
                  fontSize="8.5"
                  fontFamily="monospace"
                  textAnchor="middle"
                  fontWeight="bold"
                >
                  {Math.round(feat.centerNm)} nm
                </text>
              </g>
            );
          })}

          {/* Interactive Hover Probe */}
          {hoverBand && (
            <g>
              <line
                x1={hoverBand.x}
                y1={padding.top}
                x2={hoverBand.x}
                y2={padding.top + plotHeight}
                stroke="#f59e0b"
                strokeWidth="1"
              />
              <circle
                cx={hoverBand.x}
                cy={hoverBand.y}
                r="4.5"
                fill="#f59e0b"
                stroke="#ffffff"
                strokeWidth="1.5"
              />
            </g>
          )}

          {/* Axis Labels */}
          <text
            x={padding.left + plotWidth / 2}
            y={chartHeight - 4}
            fill="#94a3b8"
            fontSize="10"
            fontFamily="monospace"
            textAnchor="middle"
          >
            Wavelength λ (nm)
          </text>
          <text
            transform={`rotate(-90 ${16} ${padding.top + plotHeight / 2})`}
            x={16}
            y={padding.top + plotHeight / 2}
            fill="#94a3b8"
            fontSize="10"
            fontFamily="monospace"
            textAnchor="middle"
          >
            {cursorDerivative === 'raw' ? 'Reflectance' : 'Amplitude'}
          </text>
        </svg>

        {/* Hover Readout Tooltip */}
        {hoverBand && (
          <div
            className="absolute top-2 right-4 px-2 py-1 rounded bg-slate-950/90 border border-slate-700 text-slate-200 text-xs font-mono shadow-md flex items-center gap-3"
          >
            <div>
              <span className="text-slate-500">λ: </span>
              <span className="text-amber-400 font-semibold">{hoverBand.wavelength.toFixed(1)} nm</span>
            </div>
            <div>
              <span className="text-slate-500">Val: </span>
              <span className="text-sky-300 font-semibold">{hoverBand.value.toFixed(4)}</span>
            </div>
            <span className="text-[10px] text-slate-500">(Click to select band)</span>
          </div>
        )}
      </div>

      {/* ROI Legends */}
      {showRois && rois.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 pt-1 border-t border-slate-800 text-[11px] font-mono text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-sky-400 inline-block" />
            <span className="text-slate-200">Cursor (x: {cursor?.x}, y: {cursor?.y})</span>
          </div>
          {rois.map(roi => (
            <div key={roi.id} className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 inline-block" style={{ backgroundColor: roi.color }} />
              <span style={{ color: roi.color }}>{roi.name}</span>
              <span className="text-slate-600">({roi.pixelCount} px, ±1σ)</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
