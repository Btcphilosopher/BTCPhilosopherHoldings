/**
 * Aardvark Hyperspectral Reference Spectral Library Workspace
 * Browsing, category filtering, multi-signature overlay, and pairwise SAM distance calculation.
 */

import React, { useState } from 'react';
import { BookOpen, Search, Filter, AlertTriangle, Layers, Activity } from 'lucide-react';
import {
  AARDVARK_SPECTRAL_LIBRARY,
  STANDARD_WAVELENGTHS,
} from '../data/spectral-library';
import { spectralAngleMapper, pearsonCorrelation } from '../core/spectral-math';
import { SpectralLibraryItem } from '../types/spectral';

export const LibraryWorkspace: React.FC = () => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedIds, setSelectedIds] = useState<string[]>([
    'mat_steel_structural',
    'mat_veg_healthy',
    'mat_paint_safety_yellow',
  ]);

  const categories = ['All', 'Vegetation', 'Metal / Alloy', 'Polymer / Plastic', 'Building / Surface', 'Liquid', 'Mineral / Rock'];

  const filtered = AARDVARK_SPECTRAL_LIBRARY.filter(item => {
    const matchesCat = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      (item.chemicalFormula && item.chemicalFormula.toLowerCase().includes(search.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const toggleSelect = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id)
        ? prev.filter(x => x !== id)
        : prev.length < 5
        ? [...prev, id]
        : prev
    );
  };

  const selectedItems = AARDVARK_SPECTRAL_LIBRARY.filter(m => selectedIds.includes(m.id));

  // Color palette for overlaid library items
  const colors = ['#38bdf8', '#22c55e', '#eab308', '#f43f5e', '#a855f7'];

  return (
    <div className="flex-1 p-4 bg-slate-950 overflow-y-auto space-y-4">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">
              Aardvark Reference Spectral Library
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            {AARDVARK_SPECTRAL_LIBRARY.length} Calibrated Material Profiles · 400 nm to 1000 nm Range
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-amber-950/40 border border-amber-800/50 text-amber-400 font-mono text-xs">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>SYNTHETIC DEMONSTRATION DATA (RADIATIVE TRANSFER DERIVED)</span>
        </div>
      </div>

      {/* Main Grid: Multi-Plot Overlay & Catalog List */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Column 1 & 2: Overlaid Spectra Comparison Chart */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-slate-200 font-semibold">
              Simultaneous Multi-Spectrum Comparison ({selectedItems.length}/5)
            </span>
            <span className="text-slate-400 text-[11px]">Normalized Reflectance</span>
          </div>

          {/* SVG Multi-Line Chart */}
          <div className="relative w-full h-64 bg-slate-950 border border-slate-800 rounded p-3">
            <svg viewBox="0 0 540 220" className="w-full h-full">
              {/* Grid lines */}
              {[400, 500, 600, 700, 800, 900, 1000].map(w => {
                const x = 40 + ((w - 400) / 600) * 480;
                return (
                  <g key={w}>
                    <line x1={x} y1={20} x2={x} y2={190} stroke="#1e293b" strokeDasharray="2 3" />
                    <text x={x} y={206} fill="#64748b" fontSize="9" textAnchor="middle">
                      {w}
                    </text>
                  </g>
                );
              })}

              {[0, 0.25, 0.5, 0.75, 1.0].map(v => {
                const y = 190 - v * 170;
                return (
                  <g key={v}>
                    <line x1={40} y1={y} x2={520} y2={y} stroke="#1e293b" strokeDasharray="2 3" />
                    <text x={34} y={y + 3} fill="#64748b" fontSize="9" textAnchor="end">
                      {v.toFixed(2)}
                    </text>
                  </g>
                );
              })}

              {/* Render each selected item curve */}
              {selectedItems.map((item, idx) => {
                const color = colors[idx % colors.length];
                const d = item.reflectance
                  .map((v, i) => {
                    const x = 40 + (i / (STANDARD_WAVELENGTHS.length - 1)) * 480;
                    const y = 190 - Math.min(1.0, v) * 170;
                    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                  })
                  .join(' ');

                return (
                  <path
                    key={item.id}
                    d={d}
                    fill="none"
                    stroke={color}
                    strokeWidth="2.2"
                    strokeLinejoin="round"
                  />
                );
              })}
            </svg>
          </div>

          {/* Overlaid Legend Badges */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            {selectedItems.map((item, idx) => (
              <div key={item.id} className="flex items-center gap-1.5 text-[11px]">
                <span
                  className="w-3 h-1 rounded inline-block"
                  style={{ backgroundColor: colors[idx % colors.length] }}
                />
                <span className="text-slate-200">{item.name}</span>
              </div>
            ))}
          </div>

          {/* Pairwise SAM Distance Matrix Table */}
          {selectedItems.length >= 2 && (
            <div className="mt-2 pt-3 border-t border-slate-800">
              <span className="text-slate-400 block text-[11px] uppercase mb-2">
                Pairwise Spectral Angle Mapper (SAM) Separation Matrix (radians):
              </span>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[11px]">
                  <thead>
                    <tr className="text-slate-500 border-b border-slate-800">
                      <th className="pb-1">Material</th>
                      {selectedItems.map((s, i) => (
                        <th key={s.id} className="pb-1 truncate max-w-[90px]">
                          {s.name.split(' ')[0]}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {selectedItems.map((rowItem, r) => (
                      <tr key={rowItem.id}>
                        <td className="py-1 text-slate-300 font-medium truncate max-w-[140px]">
                          {rowItem.name.split(' ')[0]}
                        </td>
                        {selectedItems.map((colItem, c) => {
                          const sam = spectralAngleMapper(rowItem.reflectance, colItem.reflectance);
                          const isDiagonal = r === c;
                          return (
                            <td
                              key={colItem.id}
                              className={`py-1 font-semibold ${
                                isDiagonal
                                  ? 'text-slate-600'
                                  : sam < 0.2
                                  ? 'text-rose-400'
                                  : 'text-sky-300'
                              }`}
                            >
                              {sam.toFixed(3)}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Column 3: Material Catalog List & Category Filters */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 font-mono text-xs">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search library materials..."
              className="w-full bg-slate-950 border border-slate-800 rounded pl-9 pr-3 py-1.5 text-slate-200 placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500"
            />
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
                  selectedCategory === cat
                    ? 'bg-sky-600 text-white font-semibold'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Material Cards List */}
          <div className="space-y-2 overflow-y-auto max-h-[440px] pr-1">
            {filtered.map(item => {
              const isSelected = selectedIds.includes(item.id);
              return (
                <div
                  key={item.id}
                  onClick={() => toggleSelect(item.id)}
                  className={`p-2.5 rounded border cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-sky-950/40 border-sky-600 text-slate-100'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">{item.name}</span>
                    <input
                      type="checkbox"
                      checked={isSelected}
                      readOnly
                      className="accent-sky-500 rounded pointer-events-none"
                    />
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    <span>{item.category}</span>
                    {item.chemicalFormula && (
                      <span> · Formula: {item.chemicalFormula}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
