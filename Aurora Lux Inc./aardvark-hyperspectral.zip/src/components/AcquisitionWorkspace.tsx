/**
 * Aardvark Hyperspectral Camera Hardware & Acquisition Engine
 * Simulates pushbroom line-scan, snapshot sensor, noise parameters, and live telemetry.
 */

import React from 'react';
import {
  Camera,
  Play,
  RotateCcw,
  Sliders,
  Radio,
  Cpu,
  AlertTriangle,
  Zap,
  Activity,
  Gauge,
  Thermometer,
} from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';
import { DEFAULT_CAMERA_PROFILE } from '../simulation/camera-simulator';

export const AcquisitionWorkspace: React.FC = () => {
  const {
    cube,
    rawCube,
    isScanning,
    scanLine,
    telemetry,
    noiseConfig,
    setNoiseConfig,
    triggerAcquisition,
  } = useHyperspectral();

  const [width, height] = DEFAULT_CAMERA_PROFILE.spatialResolution;

  return (
    <div className="flex-1 p-4 bg-slate-950 overflow-y-auto space-y-4">
      {/* Top Header & Instrument Status */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">
              {DEFAULT_CAMERA_PROFILE.name}
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Architecture: <span className="text-slate-200">Pushbroom VNIR (Spatial X × Spectral λ + Motion)</span> · 
            Interface: <span className="text-emerald-400">CoaXPress CXP-12 v2.1 (Emulated)</span>
          </p>
        </div>

        {/* Action Trigger Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerAcquisition('pushbroom')}
            disabled={isScanning}
            className={`flex items-center gap-2 px-4 py-2 rounded font-mono text-xs font-semibold transition-all ${
              isScanning
                ? 'bg-amber-600 text-white animate-pulse'
                : 'bg-sky-600 hover:bg-sky-500 text-white shadow-lg shadow-sky-950'
            }`}
          >
            <Play className="w-4 h-4" />
            <span>{isScanning ? `Scanning Line ${scanLine}/${height}...` : 'Start Pushbroom Acquisition'}</span>
          </button>

          <button
            onClick={() => triggerAcquisition('instant')}
            disabled={isScanning}
            className="flex items-center gap-2 px-3 py-2 rounded font-mono text-xs border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Instant Frame Grab</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Live Scanner & Telemetry + Noise Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Column 1 & 2: Pushbroom Visualizer & Live Detector Feed */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-sky-400" />
              <span className="text-slate-200 font-semibold">Live Pushbroom Focal Plane Array (FPA)</span>
            </div>
            <span className="text-slate-400">
              Sensor Matrix: 80 Spatial Pixels × 61 Spectral Channels
            </span>
          </div>

          {/* Scanning Animation Stage */}
          <div className="relative bg-slate-950 border border-slate-800 rounded-lg p-6 flex flex-col items-center justify-center min-h-[320px] overflow-hidden">
            {/* Target Conveyor / Stage */}
            <div className="relative w-full max-w-md h-52 bg-slate-900 border border-slate-700 rounded overflow-hidden">
              {/* Target Image under scan */}
              <div className="absolute inset-0 opacity-80 flex items-center justify-center text-slate-600 font-mono text-xs">
                <span>[Target Industrial Test Specimen Area]</span>
              </div>

              {/* Progress of scanned lines */}
              <div
                className="absolute top-0 left-0 right-0 bg-sky-950/40 border-b border-sky-400/50 transition-all duration-75"
                style={{ height: `${(scanLine / height) * 100}%` }}
              />

              {/* Pushbroom Scan Line Laser Beam */}
              {isScanning && (
                <div
                  className="absolute left-0 right-0 h-1 bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.9)] transition-all duration-75"
                  style={{ top: `${(scanLine / height) * 100}%` }}
                >
                  <div className="absolute -right-24 -top-3 px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-mono text-[10px] border border-amber-600">
                    LINE {scanLine}
                  </div>
                </div>
              )}
            </div>

            {/* Status Text under Scanner */}
            <div className="mt-4 flex items-center justify-between w-full max-w-md text-xs font-mono text-slate-400">
              <span>Scan Progress: {Math.round((scanLine / height) * 100)}%</span>
              <span>Buffer Utilization: {telemetry.bufferQueue}/64 Frames</span>
            </div>
          </div>

          {/* Telemetry Readout Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">READOUT SPEED</span>
              <span className="text-slate-200 font-semibold">{telemetry.fps.toFixed(1)} FPS</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">SENSOR TEMP</span>
              <span className="text-emerald-400 font-semibold">{telemetry.temperature.toFixed(1)} °C</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">PEAK SNR</span>
              <span className="text-sky-300 font-semibold">240:1 @ 650 nm</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">DROPPED FRAMES</span>
              <span className="text-slate-200 font-semibold">{telemetry.droppedFrames}</span>
            </div>
          </div>
        </div>

        {/* Column 3: Optical & Sensor Noise Model Controls (Section 70, 80, 81) */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-4 text-xs font-mono">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
            <Sliders className="w-4 h-4 text-sky-400" />
            <span className="text-slate-200 font-semibold">Sensor Physics & Noise Model</span>
          </div>

          {/* Exposure Time Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Integration Time:</span>
              <span className="text-amber-400 font-semibold">
                {(DEFAULT_CAMERA_PROFILE.defaultIntegrationTimeMs * noiseConfig.exposureMultiplier).toFixed(1)} ms
              </span>
            </div>
            <input
              type="range"
              min={0.2}
              max={3.0}
              step={0.1}
              value={noiseConfig.exposureMultiplier}
              onChange={e =>
                setNoiseConfig(prev => ({
                  ...prev,
                  exposureMultiplier: parseFloat(e.target.value),
                }))
              }
              className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>3.7 ms (Fast)</span>
              <span>55.5 ms (Long)</span>
            </div>
          </div>

          {/* Analog Gain Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Analog Gain:</span>
              <span className="text-amber-400 font-semibold">{noiseConfig.gainDb.toFixed(1)} dB</span>
            </div>
            <input
              type="range"
              min={0}
              max={18}
              step={1}
              value={noiseConfig.gainDb}
              onChange={e =>
                setNoiseConfig(prev => ({
                  ...prev,
                  gainDb: parseFloat(e.target.value),
                }))
              }
              className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>0 dB (Unity)</span>
              <span>+18 dB (High Sensitivity)</span>
            </div>
          </div>

          {/* Sensor Temperature Simulation */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-300">
              <span>Detector Temperature:</span>
              <span className="text-emerald-400 font-semibold">
                {noiseConfig.temperatureCelsius.toFixed(1)} °C
              </span>
            </div>
            <input
              type="range"
              min={-10}
              max={45}
              step={1}
              value={noiseConfig.temperatureCelsius}
              onChange={e =>
                setNoiseConfig(prev => ({
                  ...prev,
                  temperatureCelsius: parseFloat(e.target.value),
                }))
              }
              className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>-10°C (Peltier Chilled)</span>
              <span>+45°C (Thermal Stress)</span>
            </div>
          </div>

          {/* Noise Component Toggles (Section 70) */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <span className="text-slate-400 block text-[11px] uppercase">
              Stochastic Noise Sources:
            </span>

            {[
              {
                id: 'enableShotNoise',
                label: 'Photon Shot Noise (Poisson)',
                desc: 'Statistical arrival of photons on detector',
              },
              {
                id: 'enableReadNoise',
                label: 'Read Noise (Gaussian 4.8 e-)',
                desc: 'ADC amplifier & output circuit noise',
              },
              {
                id: 'enableDarkCurrent',
                label: 'Thermal Dark Current',
                desc: 'Doubles every ~6°C thermal rise',
              },
              {
                id: 'enableBadPixels',
                label: 'Dead / Hot Pixels Injection',
                desc: 'Simulate defective silicon photodiode cells',
              },
            ].map(item => (
              <label
                key={item.id}
                className="flex items-start gap-2.5 cursor-pointer p-1.5 rounded hover:bg-slate-800/50"
              >
                <input
                  type="checkbox"
                  checked={Boolean(noiseConfig[item.id as keyof typeof noiseConfig])}
                  onChange={e =>
                    setNoiseConfig(prev => ({
                      ...prev,
                      [item.id]: e.target.checked,
                    }))
                  }
                  className="mt-0.5 accent-sky-500 rounded"
                />
                <div>
                  <div className="text-slate-200 font-medium">{item.label}</div>
                  <div className="text-[10px] text-slate-500">{item.desc}</div>
                </div>
              </label>
            ))}
          </div>

          {/* Hardware Safety Interlock Badge (Section 81) */}
          <div className="mt-auto p-2 rounded bg-slate-950 border border-slate-800 flex items-center gap-2 text-[11px] text-emerald-400">
            <Gauge className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Hardware Safety: Thermal, Exposure, and Buffer Bounds Nominal</span>
          </div>
        </div>
      </div>
    </div>
  );
};
