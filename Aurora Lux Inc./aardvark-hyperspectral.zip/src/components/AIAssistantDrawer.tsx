/**
 * Grounded Hyperspectral Analytical Assistant Drawer
 * Backed by Gemini 3.8 Flash via server-side proxy endpoint.
 * Strictly adheres to empirical dataset grounding and cites physical wavelengths.
 */

import React, { useState } from 'react';
import { Bot, X, Send, Sparkles, AlertCircle, Loader2 } from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';

export const AIAssistantDrawer: React.FC = () => {
  const {
    aiDrawerOpen,
    setAiDrawerOpen,
    cube,
    cursor,
    cursorSpectrum,
    cursorMatch,
    rois,
  } = useHyperspectral();

  const [messages, setMessages] = useState<
    { role: 'user' | 'assistant'; text: string; timestamp: string }[]
  >([
    {
      role: 'assistant',
      text: `Hello. I am the Aardvark Hyperspectral Analytical Assistant.
I evaluate spectral signatures strictly using the current dataset (${cube.name}), calibrated reflectance curves, and physical spectroscopic absorption bands.

How may I assist your analysis today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const predefinedPrompts = [
    'Explain key absorption dips in this cursor spectrum',
    'Verify red-edge inflection and NDVI validity',
    'Evaluate oxidation state from 870nm Fe3+ dip',
    'Explain why this material was matched by SAM',
  ];

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg = {
      role: 'user' as const,
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!queryText) setInput('');
    setLoading(true);

    try {
      // Prepare sample points for grounded context
      const samplePoints: Record<string, number> = {};
      if (cursorSpectrum) {
        [450, 550, 670, 700, 740, 800, 870, 930, 960].forEach(w => {
          const idx = cube.wavelengths.indexOf(w);
          if (idx !== -1) {
            samplePoints[`${w}nm`] = parseFloat(cursorSpectrum[idx].toFixed(4));
          }
        });
      }

      const activeRoi = rois[0];
      const roiStats = activeRoi
        ? {
            mean: activeRoi.meanSpectrum[25],
            std: activeRoi.stdSpectrum[25],
            min: activeRoi.minSpectrum[25],
            max: activeRoi.maxSpectrum[25],
          }
        : undefined;

      const payload = {
        question: textToSend,
        spectrumContext: {
          coords: cursor,
          samplePoints,
        },
        materialMatch: cursorMatch,
        roiStats,
        cubeMetadata: {
          name: cube.name,
          sensorType: cube.metadata.camera_id,
          wavelengthStart: cube.metadata.wavelength_start_nm,
          wavelengthEnd: cube.metadata.wavelength_end_nm,
          bands: cube.bands,
          calibrationState: cube.calibrationState,
        },
      };

      const res = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}: ${res.statusText}`);
      }

      const data = await res.json();
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: data.analysis || 'Analysis completed with no remarks.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err: unknown) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          text: `⚠️ Analysis query error: ${err instanceof Error ? err.message : 'Failed to reach analytical service.'}\n\nPlease verify network connection or server endpoint status.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  if (!aiDrawerOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col font-sans">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-950">
        <div className="flex items-center gap-2">
          <Bot className="w-4 h-4 text-sky-400" />
          <span className="font-semibold text-xs text-slate-100 uppercase tracking-wider">
            Grounded Analytical Assistant
          </span>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800">
            Gemini 3.8
          </span>
        </div>
        <button
          onClick={() => setAiDrawerOpen(false)}
          className="text-slate-400 hover:text-slate-200"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono text-xs">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`flex flex-col gap-1 ${
              m.role === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            <div className="text-[10px] text-slate-500">
              {m.role === 'user' ? 'Scientist' : 'Aardvark Assistant'} · {m.timestamp}
            </div>
            <div
              className={`p-3 rounded-lg leading-relaxed max-w-[90%] whitespace-pre-line text-[11px] ${
                m.role === 'user'
                  ? 'bg-sky-600 text-white rounded-br-none'
                  : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-bl-none'
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-slate-400 text-xs font-mono py-2">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-400" />
            <span>Consulting radiative transfer models and spectral library...</span>
          </div>
        )}
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-950 flex flex-wrap gap-1.5 text-[10px] font-mono">
        {predefinedPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(p)}
            className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-left truncate max-w-full transition-colors"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Input box */}
      <div className="p-3 border-t border-slate-800 bg-slate-950 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Ask analytical question regarding current spectrum..."
          className="flex-1 bg-slate-900 border border-slate-800 rounded px-3 py-2 text-slate-200 placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500 font-mono"
        />
        <button
          onClick={() => handleSend()}
          disabled={loading || !input.trim()}
          className="p-2 rounded bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white transition-colors"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
