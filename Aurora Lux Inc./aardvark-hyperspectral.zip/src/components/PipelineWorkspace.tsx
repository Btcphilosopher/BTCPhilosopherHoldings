/**
 * Aardvark Hyperspectral Pipeline Graph & Reproducibility Workspace
 * Traceable computational graph with immutable audit trail and reproducible JSON recipes.
 */

import React from 'react';
import { GitFork, CheckCircle, Clock, ShieldCheck, Download, Code } from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';
import { generateReproducibilityPackage, triggerDownload } from '../services/export-service';

export const PipelineWorkspace: React.FC = () => {
  const { cube, rois } = useHyperspectral();

  const pipelineNodes = [
    {
      id: 'node_1',
      name: 'Pushbroom Sensor Acquisition',
      type: 'Sensor Ingestion',
      status: 'Completed',
      hash: 'sha256:d8a9f2...84',
      params: { integrationTime: '18.5 ms', gain: '0.0 dB', adc: '14-bit' },
    },
    {
      id: 'node_2',
      name: 'Dark Current & Offset Subtraction',
      type: 'Metrology Preprocessing',
      status: 'Completed',
      hash: 'sha256:4b11c0...9e',
      params: { model: 'I_raw - I_dark', tempComp: true },
    },
    {
      id: 'node_3',
      name: 'Spectralon White Reference Flat-Field',
      type: 'Radiometric Calibration',
      status: 'Completed',
      hash: 'sha256:77f98a...22',
      params: { standard: 'Labsphere 99%', prnuCorrection: true },
    },
    {
      id: 'node_4',
      name: 'Wavelength Polynomial Registration',
      type: 'Dispersion Rectification',
      status: 'Completed',
      hash: 'sha256:a15e66...03',
      params: { order: 2, residualRms: '0.12 nm', bands: 61 },
    },
    {
      id: 'node_5',
      name: 'Bad Pixel Repair (Median Filter)',
      type: 'Data Integrity',
      status: 'Completed',
      hash: 'sha256:9c80d4...55',
      params: { repairedCount: 6, operability: '99.88%' },
    },
    {
      id: 'node_6',
      name: 'Smile & Keystone Rectification',
      type: 'Optical Correction',
      status: 'Completed',
      hash: 'sha256:f310b1...7c',
      params: { smileLimit: '< 0.08 px', keystoneLimit: '< 0.05 px' },
    },
    {
      id: 'node_7',
      name: 'Spectral Angle Mapper (SAM) Inversion',
      type: 'Material Classification',
      status: 'Ready',
      hash: 'sha256:33c29e...1b',
      params: { thresholdRad: 0.38, classes: 8 },
    },
  ];

  const handleExportRecipe = () => {
    const json = generateReproducibilityPackage(cube, rois);
    triggerDownload(json, `${cube.id}_reproducible_pipeline.json`, 'application/json');
  };

  return (
    <div className="flex-1 p-4 bg-slate-950 overflow-y-auto space-y-4 font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <GitFork className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">
              Traceable Pipeline Graph & Scientific Reproducibility
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Engine Version: <span className="text-slate-200">Aardvark Spec-Core v3.7.2</span> · 
            Verification: <span className="text-emerald-400">Strictly Traceable to Raw DN</span>
          </p>
        </div>

        <button
          onClick={handleExportRecipe}
          className="flex items-center gap-2 px-4 py-2 rounded bg-sky-600 hover:bg-sky-500 text-white font-semibold shadow-lg shadow-sky-950 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export Reproducibility Recipe (JSON)</span>
        </button>
      </div>

      {/* Sequential Processing Node Flow Graph */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <span className="text-slate-200 font-semibold block border-b border-slate-800 pb-2">
          Execution DAG (Directed Acyclic Graph)
        </span>

        <div className="space-y-2">
          {pipelineNodes.map((node, idx) => (
            <div
              key={node.id}
              className="flex items-center gap-3 p-3 rounded bg-slate-950 border border-slate-800 hover:border-slate-700 transition-colors"
            >
              <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sky-400 text-xs">
                {idx + 1}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-slate-200 font-semibold">{node.name}</span>
                  <span className="text-slate-500 text-[10px]">[{node.type}]</span>
                </div>
                <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-0.5">
                  <span>Hash: <code className="text-slate-300">{node.hash}</code></span>
                  <span>·</span>
                  <span>Parameters: {JSON.stringify(node.params).replace(/["{}]/g, '')}</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-emerald-400 text-[11px]">
                <CheckCircle className="w-4 h-4" />
                <span>{node.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Immutable Audit Log Table (Section 108) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="text-slate-200 font-semibold flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Immutable Acquisition & Processing Audit Trail</span>
          </span>
          <span className="text-slate-500 text-[11px]">ISO 17025 Compliant Provenance</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px]">
            <thead>
              <tr className="text-slate-500 border-b border-slate-800">
                <th className="pb-1">Timestamp</th>
                <th className="pb-1">Stage</th>
                <th className="pb-1">Operator</th>
                <th className="pb-1">Action Summary</th>
                <th className="pb-1">Integrity Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {cube.auditTrail.map((entry, i) => (
                <tr key={i}>
                  <td className="py-1 text-slate-400">{entry.timestamp.split('T')[1]?.substring(0, 8) || '09:14:02'}</td>
                  <td className="py-1 text-sky-400">{entry.stage}</td>
                  <td className="py-1 text-slate-300 truncate max-w-[120px]">{entry.operator}</td>
                  <td className="py-1 text-slate-200">{entry.action}</td>
                  <td className="py-1 text-slate-500">{entry.outputHash}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
