/**
 * Aardvark Hyperspectral Calibration Laboratory
 * Complete metrology workflows: Dark subtraction, Spectralon white reference,
 * wavelength polynomial fitting, smile/keystone rectification, and bad pixel detection.
 */

import React, { useState } from 'react';
import {
  Sliders,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Cpu,
  Layers,
  Sparkles,
  Zap,
} from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';

export const CalibrationLab: React.FC = () => {
  const {
    cube,
    rawCube,
    darkFrame,
    whiteReference,
    calibrationRecord,
    applyCalibrationWorkflow,
    setActiveTab,
  } = useHyperspectral();

  const [applyDark, setApplyDark] = useState(true);
  const [applyWhite, setApplyWhite] = useState(true);
  const [applyBadPixel, setApplyBadPixel] = useState(true);
  const [calibratedSuccess, setCalibratedSuccess] = useState(false);

  const wavelengths = cube.wavelengths;

  const handleApply = () => {
    applyCalibrationWorkflow({
      darkSub: applyDark,
      whiteNorm: applyWhite,
      badPixelRepair: applyBadPixel,
    });
    setCalibratedSuccess(true);
    setTimeout(() => setCalibratedSuccess(false), 3000);
  };

  // Known Hg-Ar calibration lines for demonstration
  const spectralLines = [
    { name: 'Hg I', trueNm: 404.66, pixelEst: 0.46, residualNm: 0.08 },
    { name: 'Hg I', trueNm: 435.83, pixelEst: 3.58, residualNm: -0.05 },
    { name: 'Hg I', trueNm: 546.07, pixelEst: 14.61, residualNm: 0.03 },
    { name: 'Ar I', trueNm: 706.72, pixelEst: 30.68, residualNm: -0.07 },
    { name: 'Ar I', trueNm: 811.53, pixelEst: 41.14, residualNm: 0.11 },
    { name: 'Ar I', trueNm: 912.30, pixelEst: 51.22, residualNm: -0.02 },
  ];

  return (
    <div className="flex-1 p-4 bg-slate-950 overflow-y-auto space-y-4">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">
              Calibration Laboratory & Metrology
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Calibration Record: <span className="text-slate-200">{calibrationRecord.calibrationId}</span> · 
            Traceability: <span className="text-emerald-400">NIST Reflectance Standard #SRM-2036</span>
          </p>
        </div>

        <div className="flex items-center gap-3">
          {calibratedSuccess && (
            <span className="flex items-center gap-1.5 text-xs font-mono text-emerald-400 bg-emerald-950/60 px-3 py-1 rounded border border-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
              <span>Calibration Successfully Applied!</span>
            </span>
          )}

          <button
            onClick={handleApply}
            className="flex items-center gap-2 px-4 py-2 rounded bg-sky-600 hover:bg-sky-500 text-white font-mono text-xs font-semibold shadow-lg shadow-sky-950 transition-colors"
          >
            <Zap className="w-4 h-4" />
            <span>Apply Calibration Pipeline</span>
          </button>
        </div>
      </div>

      {/* 4-Step Metrology Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Step 1: Dark Current & Offset Subtraction */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 text-xs font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-slate-200 font-semibold flex items-center gap-2">
              <span className="w-4 h-4 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-[10px]">
                1
              </span>
              <span>Dark Frame Calibration</span>
            </span>
            <label className="flex items-center gap-2 cursor-pointer text-slate-400">
              <input
                type="checkbox"
                checked={applyDark}
                onChange={e => setApplyDark(e.target.checked)}
                className="accent-sky-500 rounded"
              />
              <span>Enabled</span>
            </label>
          </div>

          <p className="text-slate-400 text-[11px]">
            Model: <code className="text-amber-400 font-mono">I_corr = I_raw - I_dark(T, t_int)</code>
            <br />
            Removes fixed-pattern dark signal non-uniformity (DSNU) and thermal offset.
          </p>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-500">Mean Dark Level:</span>
              <span className="text-slate-200">{Math.round(darkFrame[0])} DN (14-bit)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Thermal Gradient:</span>
              <span className="text-slate-200">+0.42 DN/°C</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Temporal Noise:</span>
              <span className="text-slate-200">1.8 DN RMS</span>
            </div>
          </div>
        </div>

        {/* Step 2: White Reference Panel Normalization */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 text-xs font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-slate-200 font-semibold flex items-center gap-2">
              <span className="w-4 h-4 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-[10px]">
                2
              </span>
              <span>White Reference (Spectralon 99%)</span>
            </span>
            <label className="flex items-center gap-2 cursor-pointer text-slate-400">
              <input
                type="checkbox"
                checked={applyWhite}
                onChange={e => setApplyWhite(e.target.checked)}
                className="accent-sky-500 rounded"
              />
              <span>Enabled</span>
            </label>
          </div>

          <p className="text-slate-400 text-[11px]">
            Reflectance: <code className="text-amber-400 font-mono">R(λ) = (I_raw - I_dark) / (I_white - I_dark)</code>
            <br />
            Corrects for non-uniform illumination spectra and pixel photo-response non-uniformity (PRNU).
          </p>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-500">Reference Standard:</span>
              <span className="text-slate-200">Labsphere Spectralon PTFE (99.1% diffuse)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Peak Incident Signal:</span>
              <span className="text-slate-200">{Math.round(whiteReference[25])} DN @ 650 nm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">PRNU Variation:</span>
              <span className="text-emerald-400">1.2% across detector array</span>
            </div>
          </div>
        </div>

        {/* Step 3: Wavelength Calibration & Emission Lines */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 text-xs font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-slate-200 font-semibold flex items-center gap-2">
              <span className="w-4 h-4 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-[10px]">
                3
              </span>
              <span>Wavelength Calibration (Hg-Ar Lines)</span>
            </span>
            <span className="text-emerald-400 text-[11px]">RMS Error: 0.12 nm</span>
          </div>

          <p className="text-slate-400 text-[11px]">
            Polynomial Fit: <code className="text-amber-400 font-mono">λ(p) = 400.00 + 10.00 × p + 0.00 × p²</code>
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px]">
              <thead>
                <tr className="text-slate-500 border-b border-slate-800">
                  <th className="pb-1">Line</th>
                  <th className="pb-1">Reference λ</th>
                  <th className="pb-1">FPA Pixel</th>
                  <th className="pb-1">Residual</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {spectralLines.map((ln, idx) => (
                  <tr key={idx}>
                    <td className="py-1 text-slate-300">{ln.name}</td>
                    <td className="py-1 text-sky-400">{ln.trueNm.toFixed(2)} nm</td>
                    <td className="py-1 text-slate-400">{ln.pixelEst.toFixed(2)}</td>
                    <td className="py-1 text-emerald-400">{ln.residualNm > 0 ? `+${ln.residualNm}` : ln.residualNm} nm</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Step 4: Bad Pixel Detection & Masking */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 text-xs font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-slate-200 font-semibold flex items-center gap-2">
              <span className="w-4 h-4 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-[10px]">
                4
              </span>
              <span>Bad Pixel Masking (Dead & Hot)</span>
            </span>
            <label className="flex items-center gap-2 cursor-pointer text-slate-400">
              <input
                type="checkbox"
                checked={applyBadPixel}
                onChange={e => setApplyBadPixel(e.target.checked)}
                className="accent-sky-500 rounded"
              />
              <span>Repair</span>
            </label>
          </div>

          <p className="text-slate-400 text-[11px]">
            Silicon Photodiode Defects: Flags non-responsive and hyper-responsive sensor elements.
            Replaces flagged elements using 2D median spatial interpolation.
          </p>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-500">Dead Pixels (0 DN response):</span>
              <span className="text-rose-400 font-semibold">
                {rawCube.badPixelMask?.deadCount ?? 3} cells (0.06%)
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Hot Pixels (Excessive leakage):</span>
              <span className="text-amber-400 font-semibold">
                {rawCube.badPixelMask?.hotCount ?? 3} cells (0.06%)
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Operability Rate:</span>
              <span className="text-emerald-400 font-semibold">99.88% (Exceeds ISO 12233)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Optical Smile & Keystone Aberration Analysis (Sections 24-26) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-xs font-mono flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="text-slate-200 font-semibold">
            Geometric Smile & Keystone Chromatic Aberration Model
          </span>
          <span className="text-sky-400 text-[11px]">Smile &lt; 0.08 px · Keystone &lt; 0.05 px</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] text-slate-400">
          <div>
            <span className="text-slate-200 block font-semibold mb-1">
              Spectral Smile λ = f(x, detector_position):
            </span>
            <p>
              In pushbroom slit spectrometers, the central wavelength can shift slightly from center to edge of the field of view. Aardvark telecentric optics constrain smile below 0.08 spatial pixels (&lt;0.8 nm), automatically rectified via sub-pixel resampling.
            </p>
          </div>
          <div>
            <span className="text-slate-200 block font-semibold mb-1">
              Spatial Keystone Δx = f(λ):
            </span>
            <p>
              Chromatic magnification distortion can cause spatial features to appear displaced between 400 nm and 1000 nm. The keystone map corrects spatial alignment across all 61 bands to within 0.05 pixels.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
