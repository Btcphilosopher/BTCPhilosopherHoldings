/**
 * Aardvark Hyperspectral Time-Series & Change Detection Workspace
 * Multi-temporal cube comparison, spectral angle deviation, and material evolution tracking.
 */

import React, { useEffect, useRef } from 'react';
import { GitCompare, Clock, ArrowRight, Activity, AlertTriangle } from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';

export const TimeSeriesWorkspace: React.FC = () => {
  const { cube, changeResult, runChangeDetection } = useHyperspectral();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!changeResult) {
      runChangeDetection();
    }
  }, [changeResult, runChangeDetection]);

  // Render Change Heatmap
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !changeResult) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = cube;
    const numPixels = width * height;
    const imgData = ctx.createImageData(width, height);
    const samMap = changeResult.spectralAngleChangeMap;

    for (let p = 0; p < numPixels; p++) {
      const angle = samMap[p]; // radians, typically 0 to 0.4
      const pixelIdx = p * 4;

      if (angle > 0.1) {
        // High change: bright red/orange
        const intensity = Math.min(255, (angle / 0.3) * 255);
        imgData.data[pixelIdx] = 255;
        imgData.data[pixelIdx + 1] = Math.max(0, 255 - intensity * 0.8);
        imgData.data[pixelIdx + 2] = 20;
      } else {
        // Baseline calm: dark slate
        imgData.data[pixelIdx] = 20;
        imgData.data[pixelIdx + 1] = 30 + angle * 200;
        imgData.data[pixelIdx + 2] = 45;
      }
      imgData.data[pixelIdx + 3] = 255;
    }

    ctx.putImageData(imgData, 0, 0);
  }, [changeResult, cube]);

  return (
    <div className="flex-1 p-4 bg-slate-950 overflow-y-auto space-y-4 font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-sky-400" />
            <h2 className="text-base font-semibold text-slate-100">
              Multi-Temporal Change Detection & Time-Series
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Differential Spectral Angle Mapping · Spatial Registration Invariant
          </p>
        </div>

        <button
          onClick={runChangeDetection}
          className="px-4 py-2 rounded bg-sky-600 hover:bg-sky-500 text-white font-semibold shadow-lg shadow-sky-950 transition-colors"
        >
          Re-evaluate Change Map
        </button>
      </div>

      {/* Temporal Comparison Header: Cube A vs Cube B */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-1">
          <span className="text-slate-500 block text-[10px]">BASELINE ACQUISITION (T0)</span>
          <span className="text-slate-200 font-semibold text-sm">{changeResult?.cubeAId || cube.id}</span>
          <p className="text-slate-400 text-[11px]">
            Acquired: {cube.metadata.acquisition_time} · Reference Standard
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-1">
          <span className="text-slate-500 block text-[10px]">FOLLOW-UP RE-ACQUISITION (T1)</span>
          <span className="text-sky-300 font-semibold text-sm">
            {changeResult?.cubeBId || 'AARDVARK-DEMO-002'}
          </span>
          <p className="text-slate-400 text-[11px]">
            Simulated Repeat Inspection with Thermal Degradation & Micro-Surface Shift
          </p>
        </div>
      </div>

      {/* Change Map Heatmap & Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Canvas Heatmap */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col items-center justify-center gap-3">
          <div className="flex items-center justify-between w-full border-b border-slate-800 pb-2">
            <span className="text-slate-200 font-semibold">
              Spectral Angle Deviation Heatmap: θ(T0, T1)
            </span>
            <div className="flex items-center gap-3 text-[10px]">
              <span className="text-slate-500">■ Baseline Nominal</span>
              <span className="text-amber-400">■ Mild Variation</span>
              <span className="text-rose-500">■ Significant Degradation</span>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800 shadow-xl">
            <canvas
              ref={canvasRef}
              width={cube.width}
              height={cube.height}
              className="w-[480px] h-[360px] block image-rendering-pixelated"
            />
          </div>
        </div>

        {/* Change Statistics Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
          <span className="text-slate-200 font-semibold">Change Metrics & Statistics</span>

          {changeResult ? (
            <div className="space-y-3">
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-500 block text-[10px]">MEAN SAM SHIFT</span>
                <span className="text-sky-300 font-semibold text-sm">
                  {changeResult.meanSamChangeRad.toFixed(4)} radians ({(changeResult.meanSamChangeRad * (180 / Math.PI)).toFixed(2)}°)
                </span>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-500 block text-[10px]">ALTERED PIXELS (θ &gt; 0.08 rad)</span>
                <span className="text-rose-400 font-semibold text-sm">
                  {changeResult.changedPixelsCount} pixels ({changeResult.percentageChanged}%)
                </span>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-500 block text-[10px]">SPATIAL REGISTRATION ERROR</span>
                <span className="text-emerald-400 font-semibold text-sm">&lt; 0.15 pixels (Sub-pixel affine)</span>
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed pt-2">
                Significant changes correspond primarily to vegetative biological growth and sensor thermal fluctuation in the uncooled detector model.
              </p>
            </div>
          ) : (
            <div className="text-slate-500 text-center py-8">Evaluating change metrics...</div>
          )}
        </div>
      </div>
    </div>
  );
};
