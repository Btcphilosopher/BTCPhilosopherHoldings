/**
 * Aardvark Hyperspectral 3D Digital Twin & Point Cloud Workspace
 * WebGL / Three.js rendering of physical test facility, optical camera frustum,
 * 3D point cloud with embedded spectra, and raycast material interrogation.
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Box, Layers, Eye, RotateCw, Sparkles, Crosshair } from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';
import { SpectralChart } from './SpectralChart';

export const ThreeDDigitalTwin: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);

  const { cube, cursor, setCursorPosition, cursorSpectrum, cursorMatch } = useHyperspectral();

  const [renderMode, setRenderMode] = useState<'mesh' | 'points'>('mesh');
  const [selected3DPoint, setSelected3DPoint] = useState<{
    x: number;
    y: number;
    z: number;
    gridX: number;
    gridY: number;
    material: string;
  } | null>({
    x: 0.5,
    y: 0.2,
    z: -0.3,
    gridX: 38,
    gridY: 24,
    material: 'Safety Yellow Epoxy Housing',
  });

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x060911);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(2.5, 3.2, 4.0);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(4, 8, 3);
    scene.add(dirLight);

    // 3. Grid Helper & Ground Plane (Concrete floor)
    const gridHelper = new THREE.GridHelper(6, 24, 0x1e293b, 0x0f172a);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // 4. Construct 3D Scene Geometry for AARDVARK-DEMO-001
    const objectsGroup = new THREE.Group();
    scene.add(objectsGroup);

    // Concrete Base Slab
    const slabGeo = new THREE.BoxGeometry(4.0, 0.1, 3.0);
    const slabMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.85 });
    const slab = new THREE.Mesh(slabGeo, slabMat);
    slab.position.y = -0.05;
    slab.userData = { material: 'Portland Concrete Floor', gridX: 20, gridY: 10 };
    objectsGroup.add(slab);

    // Structural Steel Beam & Frame (left)
    const steelGeo = new THREE.BoxGeometry(0.3, 1.2, 2.2);
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.3 });
    const steelCol = new THREE.Mesh(steelGeo, steelMat);
    steelCol.position.set(-1.2, 0.6, 0);
    steelCol.userData = { material: 'Structural Steel Assembly (Fe3+)', gridX: 12, gridY: 28 };
    objectsGroup.add(steelCol);

    // Aerospace Aluminum Machined Panel (top right)
    const alGeo = new THREE.BoxGeometry(1.0, 0.3, 0.8);
    const alMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95, roughness: 0.2 });
    const alBlock = new THREE.Mesh(alGeo, alMat);
    alBlock.position.set(0.9, 0.15, -0.6);
    alBlock.userData = { material: 'Aerospace Aluminum 6061-T6', gridX: 60, gridY: 14 };
    objectsGroup.add(alBlock);

    // Safety Yellow Machinery Enclosure (center)
    const yellowGeo = new THREE.BoxGeometry(0.8, 0.7, 0.9);
    const yellowMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.4 });
    const yellowBox = new THREE.Mesh(yellowGeo, yellowMat);
    yellowBox.position.set(0.2, 0.35, 0.2);
    yellowBox.userData = { material: 'Safety Yellow Epoxy Housing', gridX: 38, gridY: 24 };
    objectsGroup.add(yellowBox);

    // Healthy Vegetation Sample Tray (bottom-left)
    const vegGeo = new THREE.BoxGeometry(0.9, 0.18, 0.8);
    const vegMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.9 });
    const vegBox = new THREE.Mesh(vegGeo, vegMat);
    vegBox.position.set(-0.6, 0.09, 0.8);
    vegBox.userData = { material: 'Vegetation Canopy (Healthy Chlorophyll)', gridX: 15, gridY: 45 };
    objectsGroup.add(vegBox);

    // Camera Sensor Rig & Optical Frustum Pyramid
    const camRigGeo = new THREE.BoxGeometry(0.3, 0.2, 0.2);
    const camRigMat = new THREE.MeshBasicMaterial({ color: 0x0284c7, wireframe: true });
    const camRig = new THREE.Mesh(camRigGeo, camRigMat);
    camRig.position.set(0, 2.5, 0);
    scene.add(camRig);

    // Frustum Lines from camera to target
    const frustumPts = [
      new THREE.Vector3(0, 2.5, 0), new THREE.Vector3(-1.8, 0, -1.3),
      new THREE.Vector3(0, 2.5, 0), new THREE.Vector3(1.8, 0, -1.3),
      new THREE.Vector3(0, 2.5, 0), new THREE.Vector3(1.8, 0, 1.3),
      new THREE.Vector3(0, 2.5, 0), new THREE.Vector3(-1.8, 0, 1.3),
      new THREE.Vector3(-1.8, 0, -1.3), new THREE.Vector3(1.8, 0, -1.3),
      new THREE.Vector3(1.8, 0, -1.3), new THREE.Vector3(1.8, 0, 1.3),
      new THREE.Vector3(1.8, 0, 1.3), new THREE.Vector3(-1.8, 0, 1.3),
      new THREE.Vector3(-1.8, 0, 1.3), new THREE.Vector3(-1.8, 0, -1.3),
    ];
    const frustumGeo = new THREE.BufferGeometry().setFromPoints(frustumPts);
    const frustumMat = new THREE.LineBasicMaterial({ color: 0x0284c7, transparent: true, opacity: 0.35 });
    const frustumLine = new THREE.LineSegments(frustumGeo, frustumMat);
    scene.add(frustumLine);

    // 5. Point Cloud Generator (Section 66)
    const pointCount = 3600;
    const positions = new Float32Array(pointCount * 3);
    const colors = new Float32Array(pointCount * 3);

    for (let i = 0; i < pointCount; i++) {
      const px = (Math.random() - 0.5) * 3.6;
      const pz = (Math.random() - 0.5) * 2.6;
      let py = 0.02;

      // Sample height based on underlying geometries
      let r = 0.4, g = 0.4, b = 0.5;
      if (px < -0.8 && px > -1.5 && Math.abs(pz) < 1.1) {
        py = Math.random() * 1.2;
        r = 0.3; g = 0.35; b = 0.45;
      } else if (px > 0.4 && px < 1.4 && pz < -0.2 && pz > -1.0) {
        py = 0.3;
        r = 0.6; g = 0.7; b = 0.8;
      } else if (Math.abs(px - 0.2) < 0.4 && Math.abs(pz - 0.2) < 0.45) {
        py = Math.random() * 0.7;
        r = 0.9; g = 0.75; b = 0.1;
      } else if (px < -0.1 && px > -1.0 && pz > 0.4 && pz < 1.2) {
        py = 0.15;
        r = 0.1; g = 0.7; b = 0.25;
      }

      positions[i * 3] = px;
      positions[i * 3 + 1] = py;
      positions[i * 3 + 2] = pz;

      colors[i * 3] = r;
      colors[i * 3 + 1] = g;
      colors[i * 3 + 2] = b;
    }

    const pointsGeo = new THREE.BufferGeometry();
    pointsGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    pointsGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const pointsMat = new THREE.PointsMaterial({
      size: 0.04,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
    });
    const pointCloud = new THREE.Points(pointsGeo, pointsMat);
    pointCloud.visible = renderMode === 'points';
    scene.add(pointCloud);

    // 6. Mouse Interaction: Orbit rotation & Raycasting
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let angleAzimuth = 0.7;
    let angleElevation = 0.6;
    let distance = 5.2;

    const updateCameraPos = () => {
      camera.position.x = distance * Math.cos(angleElevation) * Math.sin(angleAzimuth);
      camera.position.y = distance * Math.sin(angleElevation);
      camera.position.z = distance * Math.cos(angleElevation) * Math.cos(angleAzimuth);
      camera.lookAt(0, 0.3, 0);
    };
    updateCameraPos();

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - prevMouseX;
      const dy = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      angleAzimuth -= dx * 0.008;
      angleElevation = Math.max(0.1, Math.min(Math.PI / 2 - 0.1, angleElevation + dy * 0.008));
      updateCameraPos();
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      distance = Math.max(2.0, Math.min(10.0, distance + e.deltaY * 0.005));
      updateCameraPos();
    };

    const raycaster = new THREE.Raycaster();
    const mouseVector = new THREE.Vector2();

    const onClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouseVector.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseVector.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouseVector, camera);
      const intersects = raycaster.intersectObjects(objectsGroup.children, true);

      if (intersects.length > 0) {
        const hit = intersects[0];
        const mat = hit.object.userData.material || 'Surface Material';
        const gx = hit.object.userData.gridX || 38;
        const gy = hit.object.userData.gridY || 24;

        setSelected3DPoint({
          x: parseFloat(hit.point.x.toFixed(3)),
          y: parseFloat(hit.point.y.toFixed(3)),
          z: parseFloat(hit.point.z.toFixed(3)),
          gridX: gx,
          gridY: gy,
          material: mat,
        });

        setCursorPosition({ x: gx, y: gy });
      }
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel, { passive: false });
    dom.addEventListener('click', onClick);

    // 7. Animation Loop
    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    // Resize listener
    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(animId);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      dom.removeEventListener('click', onClick);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
    };
  }, [renderMode, setCursorPosition]);

  return (
    <div className="flex-1 p-4 bg-slate-950 flex flex-col xl:flex-row gap-4 overflow-hidden">
      {/* 3D WebGL Viewport */}
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        {/* Top Controls */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2">
            <Box className="w-4 h-4 text-sky-400" />
            <span className="text-slate-100 font-semibold">
              3D Digital Twin & Hyperspectral Spatial Registration
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-500">Mode:</span>
            <div className="flex items-center p-0.5 bg-slate-950 rounded border border-slate-800">
              <button
                onClick={() => setRenderMode('mesh')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  renderMode === 'mesh'
                    ? 'bg-sky-600 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Textured Geometry
              </button>
              <button
                onClick={() => setRenderMode('points')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  renderMode === 'points'
                    ? 'bg-sky-600 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Spectral Point Cloud
              </button>
            </div>
          </div>
        </div>

        {/* Canvas Mount Container */}
        <div
          ref={containerRef}
          className="flex-1 relative bg-slate-950 border border-slate-800 rounded-lg min-h-[460px] cursor-grab active:cursor-grabbing overflow-hidden"
        >
          {/* Overlay Navigation Hint */}
          <div className="absolute top-3 left-3 px-3 py-1.5 rounded bg-slate-900/80 backdrop-blur border border-slate-800 text-[11px] font-mono text-slate-400 pointer-events-none">
            Click surface to interrogate spectra · Drag to rotate · Scroll to zoom
          </div>
        </div>
      </div>

      {/* Interrogation Details & Associated Spectrum Card */}
      <div className="w-full xl:w-[440px] flex flex-col gap-3">
        {selected3DPoint ? (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-xs font-mono flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-200 font-semibold">3D Surface Interrogation</span>
              <span className="text-emerald-400 text-[11px]">Spatially Registered</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">3D WORLD POS</span>
                <span className="text-slate-200 font-semibold">
                  [{selected3DPoint.x}, {selected3DPoint.y}, {selected3DPoint.z}] m
                </span>
              </div>
              <div className="bg-slate-950 p-2 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">CUBE PIXEL (X, Y)</span>
                <span className="text-sky-300 font-semibold">
                  [{selected3DPoint.gridX}, {selected3DPoint.gridY}]
                </span>
              </div>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-slate-500 block text-[10px]">MATERIAL IDENTIFICATION</span>
              <span className="text-amber-400 font-semibold text-xs">
                {selected3DPoint.material}
              </span>
            </div>

            {/* Embedded Spectral Signature */}
            <div className="pt-2">
              <span className="text-slate-400 block text-[11px] mb-1">
                Hyperspectral Curve at 3D Vertex:
              </span>
              <SpectralChart height={180} showRois={false} />
            </div>
          </div>
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-8 text-center text-slate-500 font-mono text-xs">
            Click on any 3D object in the scene to inspect its hyperspectral signature.
          </div>
        )}
      </div>
    </div>
  );
};
