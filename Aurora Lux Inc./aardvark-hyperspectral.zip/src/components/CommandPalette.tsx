/**
 * Command Palette for Aardvark Hyperspectral
 * Rapid action switcher and keyboard shortcuts modal
 */

import React, { useState, useEffect } from 'react';
import {
  Search,
  Activity,
  Camera,
  Sliders,
  Layers,
  Box,
  BookOpen,
  FileText,
  RotateCcw,
  Sparkles,
  X,
  Compass,
} from 'lucide-react';
import { useHyperspectral } from '../context/HyperspectralContext';

interface CommandItem {
  id: string;
  category: string;
  label: string;
  shortcut?: string;
  icon: React.ComponentType<{ className?: string }>;
  action: () => void;
}

export const CommandPalette: React.FC = () => {
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    setActiveTab,
    setViewMode,
    runPCA,
    runUnmixing,
    runAnomalyDetection,
    runClassification,
    triggerAcquisition,
    setAiDrawerOpen,
  } = useHyperspectral();

  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const commands: CommandItem[] = [
    {
      id: 'ws_rgb',
      category: 'Workspace View',
      label: 'Switch to True Color (RGB: 640/550/460 nm)',
      shortcut: 'R',
      icon: Layers,
      action: () => {
        setActiveTab('workspace');
        setViewMode('rgb');
      },
    },
    {
      id: 'ws_false_color',
      category: 'Workspace View',
      label: 'Switch to False Color (NIR: 850/650/550 nm)',
      icon: Layers,
      action: () => {
        setActiveTab('workspace');
        setViewMode('false_color');
      },
    },
    {
      id: 'ws_single_band',
      category: 'Workspace View',
      label: 'Switch to Single Band Wavelength Slider',
      icon: Layers,
      action: () => {
        setActiveTab('workspace');
        setViewMode('single_band');
      },
    },
    {
      id: 'ws_classify',
      category: 'Analysis & Chemometrics',
      label: 'Run SAM Material Classification Map',
      shortcut: 'M',
      icon: Activity,
      action: () => {
        setActiveTab('workspace');
        runClassification();
      },
    },
    {
      id: 'ws_pca',
      category: 'Analysis & Chemometrics',
      label: 'Compute Principal Component Analysis (PCA)',
      shortcut: 'P',
      icon: Activity,
      action: () => {
        setActiveTab('chemometrics');
        runPCA();
      },
    },
    {
      id: 'ws_unmix',
      category: 'Analysis & Chemometrics',
      label: 'Run Linear Spectral Unmixing (NNLS Abundances)',
      icon: Activity,
      action: () => {
        setActiveTab('chemometrics');
        runUnmixing();
      },
    },
    {
      id: 'ws_rx_anomaly',
      category: 'Analysis & Chemometrics',
      label: 'Execute RX Spectral Anomaly Detector',
      icon: Activity,
      action: () => {
        setActiveTab('chemometrics');
        runAnomalyDetection();
      },
    },
    {
      id: 'nav_acquire',
      category: 'Instrument Control',
      label: 'Trigger Pushbroom Hyperspectral Acquisition',
      shortcut: 'Space',
      icon: Camera,
      action: () => {
        setActiveTab('acquire');
        triggerAcquisition('pushbroom');
      },
    },
    {
      id: 'nav_cal',
      category: 'Instrument Control',
      label: 'Open Calibration Lab (Dark/White/Wavelength/Smile)',
      shortcut: 'C',
      icon: Sliders,
      action: () => {
        setActiveTab('calibrate');
      },
    },
    {
      id: 'nav_3d',
      category: '3D Spatial',
      label: 'Open 3D Digital Twin & Hyperspectral Point Cloud',
      icon: Box,
      action: () => {
        setActiveTab('3d_twin');
      },
    },
    {
      id: 'nav_library',
      category: 'Reference',
      label: 'Browse Aardvark Spectral Library',
      icon: BookOpen,
      action: () => {
        setActiveTab('library');
      },
    },
    {
      id: 'nav_reports',
      category: 'Documentation',
      label: 'Generate Scientific Report & Export Data',
      shortcut: 'E',
      icon: FileText,
      action: () => {
        setActiveTab('reports');
      },
    },
    {
      id: 'ai_assistant',
      category: 'Grounded Assistant',
      label: 'Open AI Analytical Assistant (Gemini 3.8)',
      icon: Sparkles,
      action: () => {
        setAiDrawerOpen(true);
      },
    },
  ];

  const filtered = commands.filter(c =>
    c.label.toLowerCase().includes(query.toLowerCase()) ||
    c.category.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!commandPaletteOpen) return;

      if (e.key === 'Escape') {
        setCommandPaletteOpen(false);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % Math.max(1, filtered.length));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + filtered.length) % Math.max(1, filtered.length));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filtered[selectedIndex]) {
          filtered[selectedIndex].action();
          setCommandPaletteOpen(false);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [commandPaletteOpen, filtered, selectedIndex, setCommandPaletteOpen]);

  if (!commandPaletteOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-100">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-lg shadow-2xl overflow-hidden font-sans">
        {/* Search input header */}
        <div className="flex items-center px-4 py-3 border-b border-slate-800 gap-3">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Type a command or search action (e.g. PCA, classify, calibrate)..."
            className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-sm focus:outline-none"
          />
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command list */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-6 text-center text-slate-500 text-xs font-mono">
              No matching commands found.
            </div>
          ) : (
            filtered.map((cmd, idx) => {
              const Icon = cmd.icon;
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={cmd.id}
                  onClick={() => {
                    cmd.action();
                    setCommandPaletteOpen(false);
                  }}
                  className={`flex items-center justify-between px-3 py-2 rounded text-xs cursor-pointer transition-colors ${
                    isSelected ? 'bg-sky-600 text-white' : 'text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                    <div>
                      <div className="font-medium">{cmd.label}</div>
                      <div className={`text-[10px] ${isSelected ? 'text-sky-200' : 'text-slate-500'}`}>
                        {cmd.category}
                      </div>
                    </div>
                  </div>
                  {cmd.shortcut && (
                    <kbd
                      className={`font-mono px-1.5 py-0.5 rounded text-[10px] uppercase ${
                        isSelected ? 'bg-sky-700 text-sky-100' : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {cmd.shortcut}
                    </kbd>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer shortcuts hint */}
        <div className="flex items-center justify-between px-4 py-2 border-t border-slate-800 bg-slate-950 text-[11px] text-slate-500 font-mono">
          <span>↑↓ Navigate</span>
          <span>↵ Execute</span>
          <span>Esc Close</span>
        </div>
      </div>
    </div>
  );
};
