/**
 * Central Hyperspectral Cube Workspace
 * High-performance canvas renderer, spectral cursor, false color band assigner,
 * multi-ROI tools, and physical metadata inspector.
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  Layers,
  Crosshair,
  Sliders,
  Sparkles,
  Tag,
  Maximize2,
  Minimize2,
  Trash2,
  Plus,
  Compass,
  Info,
  ShieldCheck,
} from 'lucide-react';
import {
  findClosestBandIndex,
  detectAbsorptionFeatures,
  calculateNDVI,
} from '../core/spectral-math';
import { useHyperspectral, ViewMode } from '../context/HyperspectralContext';
import { SpectralChart } from './SpectralChart';

export const CubeWorkspace: React.FC = () => {
  const {
    cube,
    rawCube,
    cursor,
    setCursorPosition,
    cursorSpectrum,
    cursorMatch,
    activeWavelengthNm,
    setActiveWavelengthNm,
    viewMode,
    setViewMode,
    rgbBands,
    setRgbBands,
    rois,
    addRoi,
    deleteRoi,
    pcaResult,
    unmixingResult,
    classificationResult,
    anomalyResult,
    runPCA,
    runClassification,
    runAnomalyDetection,
    setActiveTab,
  } = useHyperspectral();

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [zoom, setZoom] = useState(1);
  const [isDrawingRoi, setIsDrawingRoi] = useState(false);
  const [roiStart, setRoiStart] = useState<{ x: number; y: number } | null>(null);
  const [roiCurrent, setRoiCurrent] = useState<{ x: number; y: number } | null>(null);

  const { width, height, bands, wavelengths, data } = cube;

  // Render Image Canvas based on active viewMode
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imgData = ctx.createImageData(width, height);
    const numPixels = width * height;

    if (viewMode === 'rgb' || viewMode === 'false_color') {
      const redW = viewMode === 'rgb' ? rgbBands.redNm : 850;
      const greenW = viewMode === 'rgb' ? rgbBands.greenNm : 650;
      const blueW = viewMode === 'rgb' ? rgbBands.blueNm : 550;

      const rIdx = findClosestBandIndex(wavelengths, redW);
      const gIdx = findClosestBandIndex(wavelengths, greenW);
      const bIdx = findClosestBandIndex(wavelengths, blueW);

      for (let p = 0; p < numPixels; p++) {
        const off = p * bands;
        const rVal = Math.min(255, Math.max(0, data[off + rIdx] * 255 * 1.6));
        const gVal = Math.min(255, Math.max(0, data[off + gIdx] * 255 * 1.6));
        const bVal = Math.min(255, Math.max(0, data[off + bIdx] * 255 * 1.6));

        const pixelIdx = p * 4;
        imgData.data[pixelIdx] = rVal;
        imgData.data[pixelIdx + 1] = gVal;
        imgData.data[pixelIdx + 2] = bVal;
        imgData.data[pixelIdx + 3] = 255;
      }
    } else if (viewMode === 'single_band') {
      const bIdx = findClosestBandIndex(wavelengths, activeWavelengthNm);
      for (let p = 0; p < numPixels; p++) {
        const val = Math.min(255, Math.max(0, data[p * bands + bIdx] * 255 * 1.8));
        const pixelIdx = p * 4;
        imgData.data[pixelIdx] = val;
        imgData.data[pixelIdx + 1] = val;
        imgData.data[pixelIdx + 2] = val;
        imgData.data[pixelIdx + 3] = 255;
      }
    } else if (viewMode === 'pca' && pcaResult && pcaResult.scoreMaps.length >= 3) {
      const s1 = pcaResult.scoreMaps[0];
      const s2 = pcaResult.scoreMaps[1];
      const s3 = pcaResult.scoreMaps[2];

      const getMinMax = (arr: Float32Array) => {
        let min = Infinity,
          max = -Infinity;
        for (let i = 0; i < arr.length; i++) {
          if (arr[i] < min) min = arr[i];
          if (arr[i] > max) max = arr[i];
        }
        return { min, max };
      };

      const mm1 = getMinMax(s1);
      const mm2 = getMinMax(s2);
      const mm3 = getMinMax(s3);

      for (let p = 0; p < numPixels; p++) {
        const r = ((s1[p] - mm1.min) / (mm1.max - mm1.min || 1)) * 255;
        const g = ((s2[p] - mm2.min) / (mm2.max - mm2.min || 1)) * 255;
        const b = ((s3[p] - mm3.min) / (mm3.max - mm3.min || 1)) * 255;

        const pixelIdx = p * 4;
        imgData.data[pixelIdx] = r;
        imgData.data[pixelIdx + 1] = g;
        imgData.data[pixelIdx + 2] = b;
        imgData.data[pixelIdx + 3] = 255;
      }
    } else if (viewMode === 'classification' && classificationResult) {
      const { classMap, confidenceMap, classes } = classificationResult;
      const colorMap = new Map(classes.map(c => [c.id, c.color]));

      // Parse hex color to rgb
      const hexToRgb = (hex: string) => {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result
          ? [parseInt(result[1], 16), parseInt(result[2], 16), parseInt(result[3], 16)]
          : [100, 100, 100];
      };

      for (let p = 0; p < numPixels; p++) {
        const clsId = classMap[p];
        const conf = confidenceMap[p];
        const pixelIdx = p * 4;

        if (clsId === 255) {
          // Unknown / low confidence
          imgData.data[pixelIdx] = 50;
          imgData.data[pixelIdx + 1] = 50;
          imgData.data[pixelIdx + 2] = 50;
          imgData.data[pixelIdx + 3] = 255;
        } else {
          const colorHex = colorMap.get(clsId) || '#64748b';
          const [cr, cg, cb] = hexToRgb(colorHex);
          // Modulate brightness by confidence
          const factor = 0.4 + 0.6 * conf;
          imgData.data[pixelIdx] = cr * factor;
          imgData.data[pixelIdx + 1] = cg * factor;
          imgData.data[pixelIdx + 2] = cb * factor;
          imgData.data[pixelIdx + 3] = 255;
        }
      }
    } else if (viewMode === 'anomaly' && anomalyResult) {
      const { scoreMap, threshold } = anomalyResult;
      let maxScore = threshold * 1.5;

      for (let p = 0; p < numPixels; p++) {
        const score = scoreMap[p];
        const pixelIdx = p * 4;
        if (score > threshold) {
          // Bright red/hot anomaly highlight
          imgData.data[pixelIdx] = 255;
          imgData.data[pixelIdx + 1] = 40;
          imgData.data[pixelIdx + 2] = 70;
          imgData.data[pixelIdx + 3] = 255;
        } else {
          const intensity = Math.min(255, (score / threshold) * 140);
          imgData.data[pixelIdx] = intensity * 0.4;
          imgData.data[pixelIdx + 1] = intensity * 0.5;
          imgData.data[pixelIdx + 2] = intensity * 0.8;
          imgData.data[pixelIdx + 3] = 255;
        }
      }
    } else if (viewMode === 'index_ndvi') {
      const ndvi = calculateNDVI(cube);
      for (let p = 0; p < numPixels; p++) {
        const val = ndvi[p]; // range -1 to 1
        const pixelIdx = p * 4;
        if (val > 0.2) {
          // Vegetation green colormap
          const green = Math.min(255, (val / 0.8) * 255);
          imgData.data[pixelIdx] = 20;
          imgData.data[pixelIdx + 1] = green;
          imgData.data[pixelIdx + 2] = 30;
        } else {
          // Soil / non-veg grayscale
          const gray = Math.min(255, Math.max(0, (val + 0.2) * 200));
          imgData.data[pixelIdx] = gray;
          imgData.data[pixelIdx + 1] = gray;
          imgData.data[pixelIdx + 2] = gray;
        }
        imgData.data[pixelIdx + 3] = 255;
      }
    } else if (viewMode === 'unmixing' && unmixingResult && unmixingResult.abundanceMaps.length >= 3) {
      // Map 3 endmembers to R, G, B
      const a0 = unmixingResult.abundanceMaps[0];
      const a1 = unmixingResult.abundanceMaps[1];
      const a2 = unmixingResult.abundanceMaps[2];
      for (let p = 0; p < numPixels; p++) {
        const pixelIdx = p * 4;
        imgData.data[pixelIdx] = Math.min(255, a0[p] * 255);
        imgData.data[pixelIdx + 1] = Math.min(255, a1[p] * 255);
        imgData.data[pixelIdx + 2] = Math.min(255, a2[p] * 255);
        imgData.data[pixelIdx + 3] = 255;
      }
    }

    ctx.putImageData(imgData, 0, 0);

    // Draw bad pixel markers if present in raw mode
    if (cube.calibrationState === 'RAW_MEASUREMENT' && rawCube.badPixelMask) {
      const mask = rawCube.badPixelMask.mask;
      ctx.fillStyle = '#ef4444';
      for (let p = 0; p < numPixels; p++) {
        if (mask[p] > 0) {
          const px = p % width;
          const py = Math.floor(p / width);
          ctx.fillRect(px, py, 1, 1);
        }
      }
    }
  }, [
    cube,
    rawCube,
    viewMode,
    rgbBands,
    activeWavelengthNm,
    pcaResult,
    classificationResult,
    anomalyResult,
    unmixingResult,
    width,
    height,
    bands,
    wavelengths,
    data,
  ]);

  // Handle canvas mouse interaction
  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = width / rect.width;
    const scaleY = height / rect.height;

    const x = Math.floor((e.clientX - rect.left) * scaleX);
    const y = Math.floor((e.clientY - rect.top) * scaleY);

    if (x >= 0 && x < width && y >= 0 && y < height) {
      if (isDrawingRoi && roiStart) {
        setRoiCurrent({ x, y });
      } else if (!isDrawingRoi) {
        setCursorPosition({ x, y });
      }
    }
  };

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = width / rect.width;
    const scaleY = height / rect.height;
    const x = Math.floor((e.clientX - rect.left) * scaleX);
    const y = Math.floor((e.clientY - rect.top) * scaleY);

    if (isDrawingRoi) {
      setRoiStart({ x, y });
      setRoiCurrent({ x, y });
    } else {
      setCursorPosition({ x, y });
    }
  };

  const handleCanvasMouseUp = () => {
    if (isDrawingRoi && roiStart && roiCurrent) {
      const x0 = Math.min(roiStart.x, roiCurrent.x);
      const x1 = Math.max(roiStart.x, roiCurrent.x);
      const y0 = Math.min(roiStart.y, roiCurrent.y);
      const y1 = Math.max(roiStart.y, roiCurrent.y);

      const count = (x1 - x0 + 1) * (y1 - y0 + 1);
      if (count > 1) {
        const meanSpectrum = new Array(bands).fill(0);
        const minSpectrum = new Array(bands).fill(Infinity);
        const maxSpectrum = new Array(bands).fill(-Infinity);

        for (let y = y0; y <= y1; y++) {
          for (let x = x0; x <= x1; x++) {
            const off = (y * width + x) * bands;
            for (let b = 0; b < bands; b++) {
              const v = data[off + b];
              meanSpectrum[b] += v;
              if (v < minSpectrum[b]) minSpectrum[b] = v;
              if (v > maxSpectrum[b]) maxSpectrum[b] = v;
            }
          }
        }
        for (let b = 0; b < bands; b++) meanSpectrum[b] /= count;

        const stdSpectrum = new Array(bands).fill(0);
        for (let y = y0; y <= y1; y++) {
          for (let x = x0; x <= x1; x++) {
            const off = (y * width + x) * bands;
            for (let b = 0; b < bands; b++) {
              const d = data[off + b] - meanSpectrum[b];
              stdSpectrum[b] += d * d;
            }
          }
        }
        for (let b = 0; b < bands; b++) {
          stdSpectrum[b] = Math.sqrt(stdSpectrum[b] / Math.max(1, count - 1));
        }

        const colors = ['#f59e0b', '#ec4899', '#8b5cf6', '#10b981', '#06b6d4'];
        const roiColor = colors[rois.length % colors.length];

        addRoi({
          id: `roi-user-${Date.now()}`,
          name: `ROI-${rois.length + 1}: Custom Region`,
          color: roiColor,
          type: 'rect',
          points: [
            { x: x0, y: y0 },
            { x: x1, y: y1 },
          ],
          pixelCount: count,
          meanSpectrum,
          stdSpectrum,
          ciLow: meanSpectrum.map((m, i) => Math.max(0, m - 1.96 * (stdSpectrum[i] / Math.sqrt(count)))),
          ciHigh: meanSpectrum.map((m, i) => Math.min(1.2, m + 1.96 * (stdSpectrum[i] / Math.sqrt(count)))),
          minSpectrum,
          maxSpectrum,
        });
      }

      setIsDrawingRoi(false);
      setRoiStart(null);
      setRoiCurrent(null);
    }
  };

  // Diagnostic absorption features at current cursor pixel
  const absorptionFeatures = React.useMemo(() => {
    if (!cursorSpectrum) return [];
    return detectAbsorptionFeatures(wavelengths, cursorSpectrum);
  }, [cursorSpectrum, wavelengths]);

  return (
    <div className="flex-1 flex flex-col xl:flex-row gap-3 p-4 bg-slate-950 overflow-y-auto">
      {/* LEFT COLUMN: Main Image Canvas & Spatial Controls */}
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        {/* Render View Mode Selector Bar */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-slate-500 font-mono text-[11px] uppercase mr-1">Renderer:</span>
            {[
              { id: 'rgb', label: 'True Color RGB' },
              { id: 'false_color', label: 'False Color NIR' },
              { id: 'single_band', label: 'Single Band λ' },
              { id: 'pca', label: 'PCA Scores' },
              { id: 'classification', label: 'SAM Classes' },
              { id: 'anomaly', label: 'RX Anomaly' },
              { id: 'unmixing', label: 'Abundance' },
              { id: 'index_ndvi', label: 'NDVI Index' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  if (tab.id === 'pca' && !pcaResult) runPCA();
                  else if (tab.id === 'classification' && !classificationResult) runClassification();
                  else if (tab.id === 'anomaly' && !anomalyResult) runAnomalyDetection();
                  setViewMode(tab.id as ViewMode);
                }}
                className={`px-2.5 py-1 rounded text-xs font-mono transition-colors ${
                  viewMode === tab.id
                    ? 'bg-sky-600 text-white font-medium shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* ROI drawing toggle & Zoom */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsDrawingRoi(!isDrawingRoi)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono transition-colors border ${
                isDrawingRoi
                  ? 'bg-amber-600/30 border-amber-500 text-amber-300'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isDrawingRoi ? 'Cancel ROI' : 'Draw Rect ROI'}</span>
            </button>
          </div>
        </div>

        {/* Dynamic Parameter Ribbon for Active View Mode */}
        {viewMode === 'single_band' && (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex items-center gap-4 text-xs font-mono">
            <span className="text-slate-400 whitespace-nowrap">Wavelength λ:</span>
            <input
              type="range"
              min={400}
              max={1000}
              step={10}
              value={activeWavelengthNm}
              onChange={e => setActiveWavelengthNm(parseFloat(e.target.value))}
              className="w-full accent-sky-400 h-1.5 bg-slate-800 rounded cursor-pointer"
            />
            <span className="text-amber-400 font-semibold w-20 text-right">
              {activeWavelengthNm.toFixed(1)} nm
            </span>
          </div>
        )}

        {viewMode === 'false_color' && (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Color Infrared Composite:</span>
            <div className="flex items-center gap-3">
              <span className="text-red-400">Red: 850 nm (NIR)</span>
              <span className="text-green-400">Green: 650 nm (Red)</span>
              <span className="text-blue-400">Blue: 550 nm (Green)</span>
            </div>
          </div>
        )}

        {/* Main Canvas Viewport with Crosshair Overlay */}
        <div className="relative bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex items-center justify-center p-4">
          <div className="relative border border-slate-700/80 shadow-2xl rounded">
            <canvas
              ref={canvasRef}
              width={width}
              height={height}
              onMouseMove={handleCanvasMouseMove}
              onMouseDown={handleCanvasMouseDown}
              onMouseUp={handleCanvasMouseUp}
              className="cursor-crosshair w-[520px] h-[390px] block image-rendering-pixelated"
            />

            {/* Cursor Crosshair Graphic */}
            {cursor && (
              <div
                className="absolute pointer-events-none transform -translate-x-1/2 -translate-y-1/2"
                style={{
                  left: `${(cursor.x / width) * 100}%`,
                  top: `${(cursor.y / height) * 100}%`,
                }}
              >
                <div className="w-5 h-5 border border-sky-400 rounded-full flex items-center justify-center">
                  <div className="w-1 h-1 bg-sky-400 rounded-full" />
                </div>
              </div>
            )}

            {/* Render Existing ROIs Over Canvas */}
            {rois.map(r => {
              if (r.type === 'rect' && r.points.length >= 2) {
                const p0 = r.points[0];
                const p1 = r.points[1];
                const rx = (Math.min(p0.x, p1.x) / width) * 100;
                const ry = (Math.min(p0.y, p1.y) / height) * 100;
                const rw = ((Math.abs(p1.x - p0.x) + 1) / width) * 100;
                const rh = ((Math.abs(p1.y - p0.y) + 1) / height) * 100;

                return (
                  <div
                    key={r.id}
                    className="absolute pointer-events-none border-2 border-dashed"
                    style={{
                      left: `${rx}%`,
                      top: `${ry}%`,
                      width: `${rw}%`,
                      height: `${rh}%`,
                      borderColor: r.color,
                      backgroundColor: `${r.color}22`,
                    }}
                  >
                    <span
                      className="absolute -top-4 left-0 text-[10px] font-mono px-1 py-0.2 rounded"
                      style={{ backgroundColor: r.color, color: '#0f172a' }}
                    >
                      {r.name.split(':')[0]}
                    </span>
                  </div>
                );
              }
              return null;
            })}

            {/* Active Drawing ROI Box */}
            {isDrawingRoi && roiStart && roiCurrent && (
              <div
                className="absolute pointer-events-none border-2 border-amber-400 bg-amber-400/20"
                style={{
                  left: `${(Math.min(roiStart.x, roiCurrent.x) / width) * 100}%`,
                  top: `${(Math.min(roiStart.y, roiCurrent.y) / height) * 100}%`,
                  width: `${((Math.abs(roiCurrent.x - roiStart.x) + 1) / width) * 100}%`,
                  height: `${((Math.abs(roiCurrent.y - roiStart.y) + 1) / height) * 100}%`,
                }}
              />
            )}
          </div>
        </div>

        {/* Cursor Coordinates & Real-time Spatial Readout */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div>
            <span className="text-slate-500 block text-[11px]">COORDINATES</span>
            <span className="text-slate-200 font-semibold">
              X: {cursor?.x ?? '--'} , Y: {cursor?.y ?? '--'}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">ACTIVE BAND</span>
            <span className="text-amber-400 font-semibold">
              {activeWavelengthNm.toFixed(1)} nm
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">AMPLITUDE</span>
            <span className="text-sky-300 font-semibold">
              {cursorSpectrum
                ? cursorSpectrum[findClosestBandIndex(wavelengths, activeWavelengthNm)]?.toFixed(4)
                : '--'}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">UNCERTAINTY (k=2)</span>
            <span className="text-emerald-400 font-semibold">± 0.015 (1.5%)</span>
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Spectral Signature Plot & Analytical Metrology */}
      <div className="w-full xl:w-[480px] flex flex-col gap-3">
        {/* Main High-Precision Spectral Chart */}
        <SpectralChart />

        {/* Closest Spectral Library Match Card */}
        {cursorMatch && (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 font-mono text-[11px] uppercase">
                Algorithmic Library Match (SAM)
              </span>
              <button
                onClick={() => setActiveTab('library')}
                className="text-[11px] text-sky-400 hover:text-sky-300 font-mono underline"
              >
                Inspect in Library →
              </button>
            </div>
            <div className="text-sm font-semibold text-slate-100 flex items-center justify-between">
              <span>{cursorMatch.name}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1 border-t border-slate-800">
              <div>
                <span className="text-slate-500 block text-[10px]">SPECTRAL ANGLE (θ)</span>
                <span className="text-sky-300 font-medium">
                  {cursorMatch.samAngle.toFixed(3)} rad ({(cursorMatch.samAngle * (180 / Math.PI)).toFixed(1)}°)
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">CORRELATION (R)</span>
                <span className="text-emerald-400 font-medium">
                  {(cursorMatch.correlation * 100).toFixed(1)} %
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Diagnostic Absorption Bands Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-mono text-[11px] uppercase">
              Diagnostic Absorption Bands
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Continuum Removed</span>
          </div>

          {absorptionFeatures.length === 0 ? (
            <div className="py-3 text-center text-slate-500 text-xs font-mono">
              No prominent absorption dips identified at current threshold.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-[11px]">
                <thead>
                  <tr className="text-slate-500 border-b border-slate-800">
                    <th className="pb-1">Center λ</th>
                    <th className="pb-1">Depth</th>
                    <th className="pb-1">FWHM</th>
                    <th className="pb-1">Feature Mechanism</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {absorptionFeatures.map((feat, i) => (
                    <tr key={i} className="hover:bg-slate-800/40">
                      <td className="py-1 text-rose-400 font-semibold">
                        {Math.round(feat.centerNm)} nm
                      </td>
                      <td className="py-1 text-slate-300">
                        {(feat.depth * 100).toFixed(1)}%
                      </td>
                      <td className="py-1 text-slate-400">{feat.widthNm} nm</td>
                      <td className="py-1 text-slate-300 truncate max-w-[140px]">
                        {feat.label}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Active Regions of Interest (ROIs) List */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 font-mono text-[11px] uppercase">
              Active Regions of Interest ({rois.length})
            </span>
            <button
              onClick={() => setIsDrawingRoi(true)}
              className="text-[11px] text-sky-400 hover:text-sky-300 font-mono"
            >
              + Add ROI
            </button>
          </div>

          <div className="space-y-1.5 max-h-40 overflow-y-auto">
            {rois.map(roi => (
              <div
                key={roi.id}
                className="flex items-center justify-between px-2.5 py-1.5 rounded bg-slate-950 border border-slate-800 font-mono text-[11px]"
              >
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full inline-block"
                    style={{ backgroundColor: roi.color }}
                  />
                  <span className="text-slate-200 font-medium">{roi.name}</span>
                  <span className="text-slate-500">({roi.pixelCount} px)</span>
                </div>
                <button
                  onClick={() => deleteRoi(roi.id)}
                  className="text-slate-500 hover:text-rose-400"
                  title="Remove ROI"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Instrument Metadata & Provenance Audit */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs flex flex-col gap-2 font-mono">
          <div className="flex items-center gap-1.5 text-slate-400 text-[11px] uppercase border-b border-slate-800 pb-1">
            <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
            <span>Traceable Calibration Lineage</span>
          </div>
          <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[11px]">
            <div>
              <span className="text-slate-500">Camera: </span>
              <span className="text-slate-300">{cube.metadata.camera_id}</span>
            </div>
            <div>
              <span className="text-slate-500">Calibration ID: </span>
              <span className="text-slate-300">{cube.metadata.calibration_id}</span>
            </div>
            <div>
              <span className="text-slate-500">Integration: </span>
              <span className="text-slate-300">{cube.metadata.integration_time_ms.toFixed(1)} ms</span>
            </div>
            <div>
              <span className="text-slate-500">Analog Gain: </span>
              <span className="text-slate-300">{cube.metadata.gain_db.toFixed(1)} dB</span>
            </div>
            <div>
              <span className="text-slate-500">Operator: </span>
              <span className="text-slate-300 truncate">{cube.metadata.operator.split(',')[0]}</span>
            </div>
            <div>
              <span className="text-slate-500">Bit Depth: </span>
              <span className="text-slate-300">{cube.metadata.bit_depth}-bit ADC</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
