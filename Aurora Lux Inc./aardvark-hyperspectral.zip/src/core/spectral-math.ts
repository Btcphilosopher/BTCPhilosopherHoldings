/**
 * Aardvark Hyperspectral Scientific Mathematical Core
 * High-precision numerical routines for hyperspectral cube operations,
 * chemometrics, spectral matching, unmixing, and radiometric conversions.
 */

import { SpectralAbsorptionFeature, SpectralCube } from '../types/spectral';

/**
 * Calculates Spectral Angle Mapper (SAM) angle in radians between two spectra.
 * theta = acos( (s1 . s2) / (|s1| * |s2|) )
 */
export function spectralAngleMapper(
  s1: ArrayLike<number>,
  s2: ArrayLike<number>
): number {
  const len = Math.min(s1.length, s2.length);
  if (len === 0) return 0;

  let dot = 0;
  let norm1Sq = 0;
  let norm2Sq = 0;

  for (let i = 0; i < len; i++) {
    const v1 = s1[i];
    const v2 = s2[i];
    dot += v1 * v2;
    norm1Sq += v1 * v1;
    norm2Sq += v2 * v2;
  }

  const denom = Math.sqrt(norm1Sq) * Math.sqrt(norm2Sq);
  if (denom < 1e-9) return Math.PI / 2;

  let cosTheta = dot / denom;
  // Clamp for numerical stability
  if (cosTheta > 1) cosTheta = 1;
  if (cosTheta < -1) cosTheta = -1;

  return Math.acos(cosTheta);
}

/**
 * Calculates Pearson correlation coefficient between two spectra.
 */
export function pearsonCorrelation(
  s1: ArrayLike<number>,
  s2: ArrayLike<number>
): number {
  const n = Math.min(s1.length, s2.length);
  if (n < 2) return 0;

  let sum1 = 0;
  let sum2 = 0;
  for (let i = 0; i < n; i++) {
    sum1 += s1[i];
    sum2 += s2[i];
  }
  const mean1 = sum1 / n;
  const mean2 = sum2 / n;

  let numer = 0;
  let d1Sq = 0;
  let d2Sq = 0;

  for (let i = 0; i < n; i++) {
    const d1 = s1[i] - mean1;
    const d2 = s2[i] - mean2;
    numer += d1 * d2;
    d1Sq += d1 * d1;
    d2Sq += d2 * d2;
  }

  const denom = Math.sqrt(d1Sq * d2Sq);
  return denom < 1e-9 ? 0 : numer / denom;
}

/**
 * Calculates Euclidean distance between two spectra.
 */
export function euclideanDistance(
  s1: ArrayLike<number>,
  s2: ArrayLike<number>
): number {
  const n = Math.min(s1.length, s2.length);
  let sumSq = 0;
  for (let i = 0; i < n; i++) {
    const diff = s1[i] - s2[i];
    sumSq += diff * diff;
  }
  return Math.sqrt(sumSq);
}

/**
 * Standard Normal Variate (SNV) transformation.
 * Removes scatter effects: s_snv = (s - mean) / stdDev
 */
export function standardNormalVariate(spectrum: ArrayLike<number>): number[] {
  const n = spectrum.length;
  if (n === 0) return [];

  let sum = 0;
  for (let i = 0; i < n; i++) sum += spectrum[i];
  const mean = sum / n;

  let sumSq = 0;
  for (let i = 0; i < n; i++) {
    const diff = spectrum[i] - mean;
    sumSq += diff * diff;
  }
  const std = Math.sqrt(sumSq / Math.max(1, n - 1)) || 1e-6;

  const result = new Array(n);
  for (let i = 0; i < n; i++) {
    result[i] = (spectrum[i] - mean) / std;
  }
  return result;
}

/**
 * Savitzky-Golay 7-point quadratic/cubic smoothing filter.
 */
export function savitzkyGolaySmooth(spectrum: ArrayLike<number>): number[] {
  const n = spectrum.length;
  const out = new Array(n);
  if (n < 7) {
    for (let i = 0; i < n; i++) out[i] = spectrum[i];
    return out;
  }

  // 7-point SG coefficients: [-2, 3, 6, 7, 6, 3, -2] / 21
  const coeffs = [-2, 3, 6, 7, 6, 3, -2];
  const norm = 21;

  for (let i = 0; i < 3; i++) out[i] = spectrum[i];
  for (let i = n - 3; i < n; i++) out[i] = spectrum[i];

  for (let i = 3; i < n - 3; i++) {
    let sum = 0;
    for (let k = -3; k <= 3; k++) {
      sum += spectrum[i + k] * coeffs[k + 3];
    }
    out[i] = sum / norm;
  }
  return out;
}

/**
 * Computes first derivative of spectrum using central differences.
 */
export function firstDerivative(
  spectrum: ArrayLike<number>,
  wavelengths?: number[]
): number[] {
  const n = spectrum.length;
  const out = new Array(n);
  if (n < 2) return new Array(n).fill(0);

  const dw = (i: number) =>
    wavelengths && i < wavelengths.length - 1 ? wavelengths[i + 1] - wavelengths[i] : 1;

  out[0] = (spectrum[1] - spectrum[0]) / dw(0);
  out[n - 1] = (spectrum[n - 1] - spectrum[n - 2]) / dw(n - 2);

  for (let i = 1; i < n - 1; i++) {
    const deltaW =
      wavelengths && i < wavelengths.length - 1
        ? wavelengths[i + 1] - wavelengths[i - 1]
        : 2;
    out[i] = (spectrum[i + 1] - spectrum[i - 1]) / Math.max(1e-5, deltaW);
  }
  return out;
}

/**
 * Computes second derivative of spectrum.
 */
export function secondDerivative(
  spectrum: ArrayLike<number>,
  wavelengths?: number[]
): number[] {
  const d1 = firstDerivative(spectrum, wavelengths);
  return firstDerivative(d1, wavelengths);
}

/**
 * Continuum Removal via upper convex hull envelope.
 * Used in spectroscopic identification of absorption bands.
 */
export function continuumRemoval(
  spectrum: ArrayLike<number>,
  wavelengths: number[]
): { continuum: number[]; removed: number[] } {
  const n = Math.min(spectrum.length, wavelengths.length);
  const continuum = new Array(n).fill(0);
  const removed = new Array(n).fill(1);

  if (n < 3) {
    for (let i = 0; i < n; i++) continuum[i] = spectrum[i];
    return { continuum, removed };
  }

  // Compute upper convex hull of points (wavelength, reflectance)
  // Gift wrapping / Monotone chain on top boundary
  const points: { x: number; y: number; index: number }[] = [];
  for (let i = 0; i < n; i++) {
    points.push({ x: wavelengths[i], y: Math.max(1e-5, spectrum[i]), index: i });
  }

  // Upper hull construction
  const hull: { x: number; y: number; index: number }[] = [];
  hull.push(points[0]);

  for (let i = 1; i < n; i++) {
    while (hull.length >= 2) {
      const p1 = hull[hull.length - 2];
      const p2 = hull[hull.length - 1];
      const p3 = points[i];
      // Cross product (p2.x - p1.x)*(p3.y - p1.y) - (p2.y - p1.y)*(p3.x - p1.x)
      const cross = (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
      if (cross >= 0) {
        hull.pop();
      } else {
        break;
      }
    }
    hull.push(points[i]);
  }

  // Interpolate continuum linearly between hull vertices
  for (let h = 0; h < hull.length - 1; h++) {
    const pStart = hull[h];
    const pEnd = hull[h + 1];
    const dx = pEnd.x - pStart.x;
    const dy = pEnd.y - pStart.y;

    for (let i = pStart.index; i <= pEnd.index; i++) {
      const t = dx === 0 ? 0 : (points[i].x - pStart.x) / dx;
      continuum[i] = pStart.y + t * dy;
      removed[i] = Math.min(1.0, points[i].y / Math.max(1e-5, continuum[i]));
    }
  }

  return { continuum, removed };
}

/**
 * Automatically extracts absorption features (center λ, depth, FWHM, area)
 * from a continuum-removed spectrum.
 */
export function detectAbsorptionFeatures(
  wavelengths: number[],
  spectrum: ArrayLike<number>
): SpectralAbsorptionFeature[] {
  const { removed } = continuumRemoval(spectrum, wavelengths);
  const n = wavelengths.length;
  const features: SpectralAbsorptionFeature[] = [];

  // Find local minima where removed < 0.95 (meaning depth > 5%)
  for (let i = 2; i < n - 2; i++) {
    if (
      removed[i] < removed[i - 1] &&
      removed[i] < removed[i + 1] &&
      removed[i] < 0.96
    ) {
      const depth = 1 - removed[i];
      const centerNm = wavelengths[i];

      // Measure FWHM (half depth = 1 - depth/2)
      const halfLevel = 1 - depth / 2;
      let leftIdx = i;
      while (leftIdx > 0 && removed[leftIdx] < halfLevel) leftIdx--;

      let rightIdx = i;
      while (rightIdx < n - 1 && removed[rightIdx] < halfLevel) rightIdx++;

      const widthNm = Math.max(5, wavelengths[rightIdx] - wavelengths[leftIdx]);
      const area = depth * widthNm * 0.8; // approximate Gaussian integral

      let label = `Absorption @ ${Math.round(centerNm)} nm`;
      if (centerNm >= 660 && centerNm <= 690) label = 'Chlorophyll a absorption band';
      else if (centerNm >= 740 && centerNm <= 770) label = 'O2 atmospheric / Weak Water overtone';
      else if (centerNm >= 930 && centerNm <= 980) label = 'H2O liquid absorption overtone';
      else if (centerNm >= 850 && centerNm <= 920) label = 'Iron oxide Fe3+ crystal field dip';
      else if (centerNm >= 480 && centerNm <= 510) label = 'Carotenoid / Pigment band';

      features.push({
        centerNm,
        depth: parseFloat(depth.toFixed(3)),
        widthNm: parseFloat(widthNm.toFixed(1)),
        area: parseFloat(area.toFixed(2)),
        label,
      });
    }
  }

  return features;
}

/**
 * Finds the index of the closest wavelength in the cube.
 */
export function findClosestBandIndex(wavelengths: number[], targetNm: number): number {
  let closestIdx = 0;
  let minDiff = Infinity;
  for (let i = 0; i < wavelengths.length; i++) {
    const diff = Math.abs(wavelengths[i] - targetNm);
    if (diff < minDiff) {
      minDiff = diff;
      closestIdx = i;
    }
  }
  return closestIdx;
}

/**
 * Calculates Normalized Difference Vegetation Index (NDVI)
 * NDVI = (NIR - Red) / (NIR + Red)
 * Typical: NIR = 800nm, Red = 670nm
 */
export function calculateNDVI(cube: SpectralCube): Float32Array {
  const { width, height, bands, wavelengths, data } = cube;
  const redIdx = findClosestBandIndex(wavelengths, 670);
  const nirIdx = findClosestBandIndex(wavelengths, 800);

  const numPixels = width * height;
  const result = new Float32Array(numPixels);

  for (let p = 0; p < numPixels; p++) {
    const red = data[p * bands + redIdx];
    const nir = data[p * bands + nirIdx];
    const denom = nir + red;
    result[p] = Math.abs(denom) > 1e-5 ? (nir - red) / denom : 0;
  }
  return result;
}

/**
 * Calculates Red-Edge Vegetation Index (NDRE)
 * NDRE = (NIR_790 - RedEdge_720) / (NIR_790 + RedEdge_720)
 */
export function calculateNDRE(cube: SpectralCube): Float32Array {
  const { width, height, bands, wavelengths, data } = cube;
  const reIdx = findClosestBandIndex(wavelengths, 720);
  const nirIdx = findClosestBandIndex(wavelengths, 790);

  const numPixels = width * height;
  const result = new Float32Array(numPixels);

  for (let p = 0; p < numPixels; p++) {
    const re = data[p * bands + reIdx];
    const nir = data[p * bands + nirIdx];
    const denom = nir + re;
    result[p] = Math.abs(denom) > 1e-5 ? (nir - re) / denom : 0;
  }
  return result;
}

/**
 * Computes Principal Component Analysis (PCA) on the spectral cube.
 * Returns top N components, eigenvalues, explained variance, loadings, and score maps.
 */
export function computeCubePCA(
  cube: SpectralCube,
  numComponents: number = 4
): {
  eigenvalues: number[];
  explainedVarianceRatio: number[];
  cumulativeVarianceRatio: number[];
  loadings: number[][];
  scoreMaps: Float32Array[];
} {
  const { width, height, bands, data } = cube;
  const numPixels = width * height;
  const K = Math.min(numComponents, bands);

  // 1. Calculate band means
  const meanVector = new Float64Array(bands);
  for (let p = 0; p < numPixels; p++) {
    const offset = p * bands;
    for (let b = 0; b < bands; b++) {
      meanVector[b] += data[offset + b];
    }
  }
  for (let b = 0; b < bands; b++) {
    meanVector[b] /= numPixels;
  }

  // 2. Sample covariance matrix (using sub-sampling if cube is very large for responsiveness)
  const step = numPixels > 15000 ? Math.ceil(numPixels / 10000) : 1;
  const sampleCount = Math.floor(numPixels / step);

  const cov = new Float64Array(bands * bands);
  for (let p = 0; p < numPixels; p += step) {
    const offset = p * bands;
    for (let i = 0; i < bands; i++) {
      const vi = data[offset + i] - meanVector[i];
      for (let j = i; j < bands; j++) {
        const vj = data[offset + j] - meanVector[j];
        cov[i * bands + j] += vi * vj;
      }
    }
  }

  // Symmetrize and scale
  for (let i = 0; i < bands; i++) {
    for (let j = i; j < bands; j++) {
      cov[i * bands + j] /= sampleCount - 1;
      cov[j * bands + i] = cov[i * bands + j];
    }
  }

  // 3. Power iteration with deflation to extract top K eigenvectors
  const eigenvectors: number[][] = [];
  const eigenvalues: number[] = [];
  const A = new Float64Array(cov);

  for (let c = 0; c < K; c++) {
    let v = new Float64Array(bands);
    // Initialize with normalized random/deterministic vector
    for (let i = 0; i < bands; i++) v[i] = Math.sin((i + 1) * (c + 1));
    let norm = Math.hypot(...v);
    for (let i = 0; i < bands; i++) v[i] /= norm || 1;

    let lambda = 0;
    for (let iter = 0; iter < 40; iter++) {
      const vNext = new Float64Array(bands);
      for (let i = 0; i < bands; i++) {
        let sum = 0;
        const rowOff = i * bands;
        for (let j = 0; j < bands; j++) {
          sum += A[rowOff + j] * v[j];
        }
        vNext[i] = sum;
      }
      norm = Math.hypot(...vNext);
      lambda = norm;
      if (norm < 1e-12) break;
      for (let i = 0; i < bands; i++) v[i] = vNext[i] / norm;
    }

    eigenvalues.push(lambda);
    eigenvectors.push(Array.from(v));

    // Deflate matrix: A = A - lambda * (v * v^T)
    for (let i = 0; i < bands; i++) {
      for (let j = 0; j < bands; j++) {
        A[i * bands + j] -= lambda * v[i] * v[j];
      }
    }
  }

  // Calculate explained variance
  const totalVariance = eigenvalues.reduce((a, b) => a + b, 0) || 1;
  const explainedVarianceRatio = eigenvalues.map(e => e / totalVariance);
  const cumulativeVarianceRatio: number[] = [];
  let cum = 0;
  for (const ev of explainedVarianceRatio) {
    cum += ev;
    cumulativeVarianceRatio.push(cum);
  }

  // 4. Project pixels onto eigenvectors to generate score maps
  const scoreMaps: Float32Array[] = [];
  for (let c = 0; c < K; c++) {
    const map = new Float32Array(numPixels);
    const eig = eigenvectors[c];
    for (let p = 0; p < numPixels; p++) {
      let score = 0;
      const offset = p * bands;
      for (let b = 0; b < bands; b++) {
        score += (data[offset + b] - meanVector[b]) * eig[b];
      }
      map[p] = score;
    }
    scoreMaps.push(map);
  }

  return {
    eigenvalues,
    explainedVarianceRatio,
    cumulativeVarianceRatio,
    loadings: eigenvectors,
    scoreMaps,
  };
}

/**
 * Linear Spectral Unmixing using Non-Negative Least Squares (NNLS) with Sum-to-One constraint.
 * x = M * a + error, subject to a_k >= 0 and sum(a_k) = 1
 */
export function linearSpectralUnmixing(
  cube: SpectralCube,
  endmembers: { name: string; spectrum: number[]; color: string }[]
): {
  endmemberNames: string[];
  endmemberColors: string[];
  abundanceMaps: Float32Array[];
  residualRmsMap: Float32Array;
  meanResidualError: number;
} {
  const { width, height, bands, data } = cube;
  const numPixels = width * height;
  const M = endmembers.length;

  const abundanceMaps: Float32Array[] = endmembers.map(() => new Float32Array(numPixels));
  const residualRmsMap = new Float32Array(numPixels);
  let totalResidualSum = 0;

  // Precompute Gram matrix G = E^T * E (where E is bands x M)
  const G = new Float64Array(M * M);
  for (let i = 0; i < M; i++) {
    for (let j = 0; j < M; j++) {
      let dot = 0;
      for (let b = 0; b < bands; b++) {
        dot += endmembers[i].spectrum[b] * endmembers[j].spectrum[b];
      }
      G[i * M + j] = dot;
    }
  }

  // Solve projected gradient descent for each pixel
  for (let p = 0; p < numPixels; p++) {
    const offset = p * bands;
    // rhs: b_i = E_i^T * x
    const rhs = new Float64Array(M);
    for (let i = 0; i < M; i++) {
      let dot = 0;
      for (let b = 0; b < bands; b++) {
        dot += endmembers[i].spectrum[b] * data[offset + b];
      }
      rhs[i] = dot;
    }

    // Initial equal abundance
    const a = new Float64Array(M).fill(1 / M);

    // Iterative projected gradient steps
    const stepSize = 0.05;
    for (let iter = 0; iter < 18; iter++) {
      for (let i = 0; i < M; i++) {
        let grad = 0;
        for (let j = 0; j < M; j++) {
          grad += G[i * M + j] * a[j];
        }
        grad -= rhs[i];
        a[i] = Math.max(0, a[i] - stepSize * grad);
      }
      // Project onto simplex (sum = 1)
      let sum = 0;
      for (let i = 0; i < M; i++) sum += a[i];
      if (sum > 1e-6) {
        for (let i = 0; i < M; i++) a[i] /= sum;
      }
    }

    // Compute residual error: || x - M * a ||
    let resSq = 0;
    for (let b = 0; b < bands; b++) {
      let reconstructed = 0;
      for (let i = 0; i < M; i++) {
        reconstructed += endmembers[i].spectrum[b] * a[i];
      }
      const diff = data[offset + b] - reconstructed;
      resSq += diff * diff;
    }
    const rms = Math.sqrt(resSq / bands);
    residualRmsMap[p] = rms;
    totalResidualSum += rms;

    for (let i = 0; i < M; i++) {
      abundanceMaps[i][p] = a[i];
    }
  }

  return {
    endmemberNames: endmembers.map(e => e.name),
    endmemberColors: endmembers.map(e => e.color),
    abundanceMaps,
    residualRmsMap,
    meanResidualError: totalResidualSum / numPixels,
  };
}

/**
 * RX Anomaly Detector (Reed-Xiaoli algorithm)
 * Detects spectral anomalies that deviate statistically from the global background.
 * RX(r) = (r - mu)^T * Sigma^{-1} * (r - mu)
 */
export function computeRXAnomaly(
  cube: SpectralCube
): {
  scoreMap: Float32Array;
  threshold: number;
  detectedCount: number;
  topAnomalies: { x: number; y: number; score: number }[];
} {
  const { width, height, bands, data } = cube;
  const numPixels = width * height;

  // Background mean
  const mean = new Float64Array(bands);
  for (let p = 0; p < numPixels; p++) {
    const off = p * bands;
    for (let b = 0; b < bands; b++) mean[b] += data[off + b];
  }
  for (let b = 0; b < bands; b++) mean[b] /= numPixels;

  // Subsampled covariance diagonal / pseudo-Mahalanobis for efficiency & stability
  const varDiag = new Float64Array(bands);
  for (let p = 0; p < numPixels; p++) {
    const off = p * bands;
    for (let b = 0; b < bands; b++) {
      const d = data[off + b] - mean[b];
      varDiag[b] += d * d;
    }
  }
  for (let b = 0; b < bands; b++) {
    varDiag[b] = Math.max(1e-6, varDiag[b] / (numPixels - 1));
  }

  const scoreMap = new Float32Array(numPixels);
  let maxScore = 0;
  let sumScore = 0;

  for (let p = 0; p < numPixels; p++) {
    const off = p * bands;
    let distSq = 0;
    for (let b = 0; b < bands; b++) {
      const diff = data[off + b] - mean[b];
      distSq += (diff * diff) / varDiag[b];
    }
    const score = Math.sqrt(distSq / bands);
    scoreMap[p] = score;
    sumScore += score;
    if (score > maxScore) maxScore = score;
  }

  const meanScore = sumScore / numPixels;
  // Dynamic threshold at mean + 3.0 standard deviations
  let variance = 0;
  for (let p = 0; p < numPixels; p++) {
    const diff = scoreMap[p] - meanScore;
    variance += diff * diff;
  }
  const stdScore = Math.sqrt(variance / numPixels);
  const threshold = meanScore + 3.0 * stdScore;

  const topAnomalies: { x: number; y: number; score: number }[] = [];
  let detectedCount = 0;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const p = y * width + x;
      const score = scoreMap[p];
      if (score > threshold) {
        detectedCount++;
        if (topAnomalies.length < 15) {
          topAnomalies.push({ x, y, score });
        }
      }
    }
  }

  topAnomalies.sort((a, b) => b.score - a.score);

  return {
    scoreMap,
    threshold,
    detectedCount,
    topAnomalies,
  };
}

/**
 * Performs calibrated reflectance calculation:
 * R(lambda) = (I_sample - I_dark) / (I_reference - I_dark)
 */
export function applyRadiometricCalibration(
  rawCube: SpectralCube,
  darkFrame: Float32Array,
  whiteReference: Float32Array
): SpectralCube {
  const { width, height, bands, wavelengths, data } = rawCube;
  const numPixels = width * height;
  const calibratedData = new Float32Array(numPixels * bands);

  for (let p = 0; p < numPixels; p++) {
    const off = p * bands;
    for (let b = 0; b < bands; b++) {
      const rawVal = data[off + b];
      const darkVal = darkFrame[b] || 0;
      const whiteVal = whiteReference[b] || 1;

      const num = rawVal - darkVal;
      const den = whiteVal - darkVal;

      if (Math.abs(den) < 1e-4) {
        calibratedData[off + b] = 0;
      } else {
        const refl = num / den;
        // Physically valid reflectance range [0, 1.2] to allow for slight specular highlights
        calibratedData[off + b] = Math.max(0, Math.min(1.2, refl));
      }
    }
  }

  return {
    ...rawCube,
    id: `${rawCube.id}-calibrated`,
    name: `${rawCube.name} [Calibrated Reflectance]`,
    calibrationState: 'RADIOMETRIC_CALIBRATED',
    data: calibratedData,
    auditTrail: [
      ...rawCube.auditTrail,
      {
        timestamp: new Date().toISOString(),
        stage: 'RADIOMETRIC_CALIBRATION',
        action: 'Standard Dark Subtraction & Spectralon Panel Normalization',
        operator: 'Aardvark System Calibrator',
        parameters: { formula: 'R = (I_raw - I_dark) / (I_white - I_dark)' },
        outputHash: Math.random().toString(36).substring(2, 10),
      },
    ],
  };
}
