/**
 * Aardvark Hyperspectral Reference Spectral Library
 *
 * IMPORTANT SCIENTIFIC NOTICE:
 * Every spectrum in this file is SYNTHETIC DEMONSTRATION DATA modeled from
 * spectroscopic literature and radiative transfer equations for industrial and remote sensing materials.
 * It is provided for calibration testing, unmixing benchmarks, and software validation.
 * NEVER REPRESENT AS LABORATORY NIST/USGS MEASUREMENTS WITHOUT PHYSICAL TRACEABILITY.
 */

import { SpectralLibraryItem } from '../types/spectral';

export const STANDARD_WAVELENGTHS: number[] = Array.from(
  { length: 61 },
  (_, i) => 400 + i * 10
); // 400 nm to 1000 nm in 10 nm increments

function buildSpectrum(formulaFn: (w: number) => number): number[] {
  return STANDARD_WAVELENGTHS.map(w => {
    const val = formulaFn(w);
    return Math.max(0.001, Math.min(1.0, parseFloat(val.toFixed(4))));
  });
}

export const AARDVARK_SPECTRAL_LIBRARY: SpectralLibraryItem[] = [
  {
    id: 'mat_veg_healthy',
    name: 'Vegetation (Healthy Chlorophyll-rich Canopy)',
    category: 'Vegetation',
    chemicalFormula: 'C55H72MgN4O5 (Chlorophyll a) + H2O',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Blue absorption (400-480nm) ~ 0.05
      // Green reflectance peak (550nm) ~ 0.14
      // Red absorption dip (660-680nm) ~ 0.04
      // Red edge transition (690-750nm): rises from 0.05 to 0.58
      // NIR plateau (750-900nm) ~ 0.58
      // Water absorption dip at 970nm
      if (w < 500) return 0.04 + 0.02 * Math.sin(((w - 400) / 100) * Math.PI);
      if (w <= 670) {
        const greenPeak = 0.14 * Math.exp(-Math.pow((w - 550) / 45, 2));
        return Math.max(0.035, greenPeak);
      }
      if (w <= 760) {
        // Sigmoidal red-edge transition
        const t = (w - 700) / 25;
        return 0.05 + 0.52 / (1 + Math.exp(-t));
      }
      // NIR plateau with liquid water absorption dip at 960nm
      const waterDip = 0.08 * Math.exp(-Math.pow((w - 960) / 35, 2));
      return 0.57 - waterDip;
    }),
    absorptionFeatures: [
      { centerNm: 450, depth: 0.88, widthNm: 45, area: 39.6, label: 'Chlorophyll b blue absorption' },
      { centerNm: 670, depth: 0.92, widthNm: 35, area: 32.2, label: 'Chlorophyll a red absorption' },
      { centerNm: 960, depth: 0.14, widthNm: 40, area: 5.6, label: 'Liquid water overtone band' },
    ],
    uncertaintyEstimate: 0.015,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_veg_dry',
    name: 'Vegetation (Dry / Senescent Foliage)',
    category: 'Vegetation',
    chemicalFormula: 'Lignin / Cellulose (C6H10O5)n',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Degraded chlorophyll, steady rise, prominent cellulose features
      const base = 0.12 + 0.32 * ((w - 400) / 600);
      const dip = 0.04 * Math.exp(-Math.pow((w - 980) / 40, 2));
      return base - dip;
    }),
    absorptionFeatures: [
      { centerNm: 980, depth: 0.09, widthNm: 45, area: 4.0, label: 'Cellulose / Residual Moisture' },
    ],
    uncertaintyEstimate: 0.02,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_water_clear',
    name: 'Water (Clear Fresh Water)',
    category: 'Liquid',
    chemicalFormula: 'H2O',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // High transmission / slight blue backscatter, near zero in NIR
      if (w < 580) return 0.06 - 0.03 * ((w - 400) / 180);
      if (w < 720) return 0.03 * Math.exp(-(w - 580) / 80);
      return 0.005; // NIR absorption is intense
    }),
    absorptionFeatures: [
      { centerNm: 760, depth: 0.85, widthNm: 80, area: 68.0, label: 'O-H vibrational fundamental onset' },
    ],
    uncertaintyEstimate: 0.008,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_steel_structural',
    name: 'Structural Steel (Oxidized Iron Fe3+)',
    category: 'Metal / Alloy',
    chemicalFormula: 'Fe2O3 + Fe3O4 / Carbon Steel',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Low overall reflectance, gradual rise with hematite Fe3+ absorption trough near 860nm
      const baseline = 0.10 + 0.12 * ((w - 400) / 600);
      const ironDip = 0.05 * Math.exp(-Math.pow((w - 870) / 70, 2));
      return baseline - ironDip;
    }),
    absorptionFeatures: [
      { centerNm: 870, depth: 0.28, widthNm: 110, area: 30.8, label: 'Fe3+ crystal field transition' },
    ],
    uncertaintyEstimate: 0.018,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_aluminum_alloy',
    name: 'Aerospace Aluminum (6061-T6)',
    category: 'Metal / Alloy',
    chemicalFormula: 'Al (97.9%) + Mg + Si',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // High specular/diffuse metal reflectance across whole spectrum, broad Al2O3 dip near 800nm
      const base = 0.76 + 0.08 * ((w - 400) / 600);
      const oxideDip = 0.06 * Math.exp(-Math.pow((w - 810) / 60, 2));
      return base - oxideDip;
    }),
    absorptionFeatures: [
      { centerNm: 810, depth: 0.08, widthNm: 90, area: 7.2, label: 'Interband Al electron transition' },
    ],
    uncertaintyEstimate: 0.015,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_copper_alloy',
    name: 'Copper Alloy (C11000 Pure ETP)',
    category: 'Metal / Alloy',
    chemicalFormula: 'Cu (99.9%)',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Strong d-band interband absorption below 560nm (~0.12), sharp rise into red and NIR reaching ~0.82
      if (w < 550) return 0.12 + 0.04 * ((w - 400) / 150);
      const edge = 0.16 + 0.65 / (1 + Math.exp(-(w - 600) / 25));
      return Math.min(0.85, edge);
    }),
    absorptionFeatures: [
      { centerNm: 480, depth: 0.82, widthNm: 120, area: 98.4, label: 'Cu d-band to Fermi surface threshold' },
    ],
    uncertaintyEstimate: 0.012,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_concrete_cured',
    name: 'Portland Concrete (Cured C30/37)',
    category: 'Building / Surface',
    chemicalFormula: 'CaO-SiO2-H2O Hydrates + Aggregates',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Gray monotonic increase from 0.18 to 0.38, slight water hydrate feature near 950nm
      const base = 0.18 + 0.20 * ((w - 400) / 600);
      const hydrateDip = 0.025 * Math.exp(-Math.pow((w - 950) / 45, 2));
      return base - hydrateDip;
    }),
    absorptionFeatures: [
      { centerNm: 950, depth: 0.07, widthNm: 60, area: 4.2, label: 'Silicate bound hydroxyl overtone' },
    ],
    uncertaintyEstimate: 0.014,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_soil_loam',
    name: 'Mineral-Rich Agricultural Soil (Loam)',
    category: 'Mineral / Rock',
    chemicalFormula: 'Clay / Silt / Humic Substances',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Convex upward ramp from 0.08 to 0.28, moisture dip near 940nm
      const base = 0.08 + 0.22 * Math.sqrt((w - 400) / 600);
      const moistDip = 0.03 * Math.exp(-Math.pow((w - 940) / 50, 2));
      return base - moistDip;
    }),
    absorptionFeatures: [
      { centerNm: 940, depth: 0.12, widthNm: 70, area: 8.4, label: 'Soil moisture overtone' },
    ],
    uncertaintyEstimate: 0.02,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_polymer_hdpe',
    name: 'Polymer HDPE (High-Density Polyethylene)',
    category: 'Polymer / Plastic',
    chemicalFormula: '(C2H4)n',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // White/translucent plastic, steady high reflectance (~0.65), distinct C-H stretch 3rd overtone at 920-930nm
      const base = 0.62 + 0.06 * ((w - 400) / 600);
      const chDip = 0.11 * Math.exp(-Math.pow((w - 928) / 18, 2));
      return base - chDip;
    }),
    absorptionFeatures: [
      { centerNm: 928, depth: 0.17, widthNm: 32, area: 5.4, label: 'Aliphatic C-H stretch 3rd overtone' },
    ],
    uncertaintyEstimate: 0.016,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_polymer_pet',
    name: 'Polymer PET (Polyethylene Terephthalate)',
    category: 'Polymer / Plastic',
    chemicalFormula: '(C10H8O4)n',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      const base = 0.48 + 0.08 * ((w - 400) / 600);
      const aromaticDip = 0.08 * Math.exp(-Math.pow((w - 875) / 22, 2));
      const esterDip = 0.09 * Math.exp(-Math.pow((w - 935) / 20, 2));
      return base - aromaticDip - esterDip;
    }),
    absorptionFeatures: [
      { centerNm: 875, depth: 0.15, widthNm: 36, area: 5.4, label: 'Aromatic C-H vibrational band' },
      { centerNm: 935, depth: 0.16, widthNm: 32, area: 5.1, label: 'Carbonyl overtone combination' },
    ],
    uncertaintyEstimate: 0.018,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_paint_safety_yellow',
    name: 'Industrial Epoxy Primer (Safety Yellow)',
    category: 'Building / Surface',
    chemicalFormula: 'Pigment Yellow 83 + Bisphenol A Epoxy',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Cutoff filter profile: low blue (<490nm ~0.08), sharp step to high yellow/red/NIR (~0.72)
      if (w < 480) return 0.07 + 0.03 * ((w - 400) / 80);
      const step = 0.09 + 0.65 / (1 + Math.exp(-(w - 515) / 14));
      return Math.min(0.74, step);
    }),
    absorptionFeatures: [
      { centerNm: 440, depth: 0.88, widthNm: 75, area: 66.0, label: 'Azo pigment chromophore absorption' },
    ],
    uncertaintyEstimate: 0.015,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_glass_float',
    name: 'Optical Float Glass (Soda-Lime)',
    category: 'Building / Surface',
    chemicalFormula: 'SiO2 (73%) + Na2O + CaO',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      // Fresnel surface reflectance ~ 4% across visible with Fe2+ absorption in NIR
      const base = 0.042;
      const feDip = 0.012 * Math.exp(-Math.pow((w - 950) / 100, 2));
      return Math.max(0.015, base - feDip);
    }),
    absorptionFeatures: [
      { centerNm: 950, depth: 0.30, widthNm: 160, area: 48.0, label: 'Fe2+ residual contaminant broad band' },
    ],
    uncertaintyEstimate: 0.005,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_rubber_epdm',
    name: 'Black EPDM Industrial Elastomer',
    category: 'Polymer / Plastic',
    chemicalFormula: 'Ethylene Propylene Diene + Carbon Black',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(() => 0.035 + 0.005 * Math.random()),
    absorptionFeatures: [],
    uncertaintyEstimate: 0.008,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
  {
    id: 'mat_wood_pine',
    name: 'Pine Hardwood (Raw Sawn)',
    category: 'Building / Surface',
    chemicalFormula: 'Pinus sylvestris (Cellulose + Lignin)',
    wavelengthRange: [400, 1000],
    wavelengths: STANDARD_WAVELENGTHS,
    reflectance: buildSpectrum(w => {
      const base = 0.15 + 0.40 * ((w - 400) / 600);
      const lignDip = 0.03 * Math.exp(-Math.pow((w - 930) / 40, 2));
      return base - lignDip;
    }),
    absorptionFeatures: [
      { centerNm: 930, depth: 0.07, widthNm: 50, area: 3.5, label: 'Lignin hydroxyl overtone' },
    ],
    uncertaintyEstimate: 0.02,
    referenceSource: 'Aardvark Synthetic Optical Model v3.7 (SYNTHETIC DEMONSTRATION DATA)',
    isSynthetic: true,
  },
];
