/**
 * AARDVARK HYPERSPECTRAL
 * Computational Hyperspectral Imaging & Spectral Analysis Platform
 */

import React from 'react';
import { HyperspectralProvider, useHyperspectral } from './context/HyperspectralContext';
import { HeaderNav } from './components/HeaderNav';
import { CubeWorkspace } from './components/CubeWorkspace';
import { AcquisitionWorkspace } from './components/AcquisitionWorkspace';
import { CalibrationLab } from './components/CalibrationLab';
import { AnalysisWorkspace } from './components/AnalysisWorkspace';
import { ThreeDDigitalTwin } from './components/ThreeDDigitalTwin';
import { LibraryWorkspace } from './components/LibraryWorkspace';
import { TimeSeriesWorkspace } from './components/TimeSeriesWorkspace';
import { PipelineWorkspace } from './components/PipelineWorkspace';
import { ReportGenerator } from './components/ReportGenerator';
import { CommandPalette } from './components/CommandPalette';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';

const MainContent: React.FC = () => {
  const { activeTab } = useHyperspectral();

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-slate-950 overflow-hidden">
      {activeTab === 'workspace' && <CubeWorkspace />}
      {activeTab === 'acquire' && <AcquisitionWorkspace />}
      {activeTab === 'calibrate' && <CalibrationLab />}
      {activeTab === 'chemometrics' && <AnalysisWorkspace />}
      {activeTab === '3d_twin' && <ThreeDDigitalTwin />}
      {activeTab === 'library' && <LibraryWorkspace />}
      {activeTab === 'change_detect' && <TimeSeriesWorkspace />}
      {activeTab === 'pipeline' && <PipelineWorkspace />}
      {activeTab === 'reports' && <ReportGenerator />}
    </div>
  );
};

const FooterShortcuts: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 px-4 py-1.5 flex items-center justify-between text-[11px] font-mono text-slate-500 select-none">
      <div className="flex items-center gap-3">
        <span>Keyboard Shortcuts:</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">Space</kbd> Scan</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">R</kbd> RGB</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">S</kbd> Workspace</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">M</kbd> Classify</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">C</kbd> Calibration</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">P</kbd> PCA</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">A</kbd> Analysis</span>
        <span><kbd className="text-slate-400 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">E</kbd> Export</span>
      </div>
      <div>
        <span>Aardvark Imaging Inc. · Proprietary Metrology Stack</span>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <HyperspectralProvider>
      <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-100 antialiased overflow-hidden font-sans">
        <HeaderNav />
        <MainContent />
        <FooterShortcuts />
        <CommandPalette />
        <AIAssistantDrawer />
      </div>
    </HyperspectralProvider>
  );
}
