/**
 * Aardvark Hyperspectral Export Services
 * Supports ENVI standard headers (.hdr), CSV spectral matrices, GeoJSON spatial extents, and scientific reports.
 */

import { SpectralCube, SpectralROI } from '../types/spectral';

/**
 * Generates ENVI standard header format (.hdr)
 */
export function generateENVIHeader(cube: SpectralCube): string {
  const { width, height, bands, wavelengths, metadata } = cube;
  return `ENVI
description = {
  Aardvark Hyperspectral Cube: ${cube.name}
  Calibration: ${cube.calibrationState}
  Operator: ${metadata.operator}
  Acquired: ${metadata.acquisition_time}
  NOTE: ${metadata.provenance_note}
}
samples = ${width}
lines   = ${height}
bands   = ${bands}
header offset = 0
file type = ENVI Standard
data type = 4
interleave = bip
sensor type = ${metadata.camera_id}
byte order = 0
wavelength units = Nanometers
wavelength = {
  ${wavelengths.join(', ')}
}
fwhm = {
  ${new Array(bands).fill(metadata.spectral_resolution_fwhm_nm.toFixed(2)).join(', ')}
}
data gain values = {
  ${new Array(bands).fill('1.000000').join(', ')}
}
`;
}

/**
 * Generates CSV string of spectral data for export to R / Python / Chemometrics packages.
 */
export function generateSpectralCSV(
  wavelengths: number[],
  spectra: { label: string; values: number[] }[]
): string {
  const headers = ['Wavelength_nm', ...spectra.map(s => `"${s.label}"`)].join(',');
  const rows: string[] = [headers];

  for (let i = 0; i < wavelengths.length; i++) {
    const row = [wavelengths[i].toFixed(1), ...spectra.map(s => (s.values[i] ?? 0).toFixed(5))];
    rows.push(row.join(','));
  }

  return rows.join('\n');
}

/**
 * Generates JSON package for full reproducible pipeline reconstruction.
 */
export function generateReproducibilityPackage(cube: SpectralCube, rois: SpectralROI[]): string {
  return JSON.stringify(
    {
      aardvarkPackageVersion: '3.7.0',
      exportedAt: new Date().toISOString(),
      datasetId: cube.id,
      name: cube.name,
      dimensions: {
        width: cube.width,
        height: cube.height,
        bands: cube.bands,
      },
      wavelengths: cube.wavelengths,
      metadata: cube.metadata,
      auditTrail: cube.auditTrail,
      rois: rois.map(r => ({
        id: r.id,
        name: r.name,
        type: r.type,
        pixelCount: r.pixelCount,
        meanSpectrum: r.meanSpectrum,
      })),
    },
    null,
    2
  );
}

/**
 * Triggers a browser download of a text/blob payload.
 */
export function triggerDownload(content: string, filename: string, mimeType = 'text/plain') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
