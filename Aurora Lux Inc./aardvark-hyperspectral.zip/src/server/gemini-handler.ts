import { GoogleGenAI } from '@google/genai';
import type { IncomingMessage, ServerResponse } from 'http';

export function setupGeminiApiRoutes(req: IncomingMessage, res: ServerResponse): boolean {
  if (req.url === '/api/gemini/analyze' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
    });

    req.on('end', async () => {
      res.setHeader('Content-Type', 'application/json');

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        res.statusCode = 500;
        res.end(JSON.stringify({ error: 'GEMINI_API_KEY is not configured on the server.' }));
        return;
      }

      try {
        const payload = JSON.parse(body || '{}');
        const { question, spectrumContext, materialMatch, roiStats, cubeMetadata } = payload;

        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const systemPrompt = `You are the Aardvark Hyperspectral Analytical Assistant, a computational imaging scientist and chemometrics specialist.
You must adhere strictly to these scientific rules:
1. Every answer must be strictly grounded in the provided hyperspectral data (wavelengths in nanometers, reflectance/radiance values, SAM angles, PCA eigenvalues).
2. Clearly distinguish between:
   - RAW SENSOR MEASUREMENT
   - CALIBRATED REFLECTANCE
   - ALGORITHMIC MATCH (e.g., SAM or library correlation)
   - MODEL INFERENCE
3. Never fabricate spectral bands, chemical absorption lines, or certainty. If signal-to-noise is low or band coverage is insufficient, explicitly state the physical limitations and uncertainty.
4. Keep answers concise, highly technical, and formatted with clean Markdown headers and bullet points.`;

        const userPrompt = `Hyperspectral Analysis Query:
User Question: ${question || 'Analyze this spectral signature and identify diagnostic features.'}

Current Dataset Context:
- Dataset: ${cubeMetadata?.name || 'AARDVARK-DEMO-001 (Synthetic Test Scene)'}
- Sensor: ${cubeMetadata?.sensorType || 'Pushbroom VNIR'} (${cubeMetadata?.wavelengthStart || 400}nm - ${cubeMetadata?.wavelengthEnd || 1000}nm, ${cubeMetadata?.bands || 61} spectral bands)
- Calibration State: ${cubeMetadata?.calibrationState || 'Calibrated Reflectance (Dark + Spectralon White)'}
- Pixel / ROI Coordinates: ${spectrumContext?.coords ? `X=${spectrumContext.coords.x}, Y=${spectrumContext.coords.y}` : 'Selected ROI'}
- Nearest Library Match: ${materialMatch?.name || 'Unknown'} (SAM Angle: ${materialMatch?.samAngle ? materialMatch.samAngle.toFixed(3) + ' rad' : 'N/A'}, Correlation: ${materialMatch?.correlation ? (materialMatch.correlation * 100).toFixed(1) + '%' : 'N/A'})
- Key Absorption / Reflectance Profile:
${spectrumContext?.samplePoints ? JSON.stringify(spectrumContext.samplePoints, null, 2) : 'Full spectrum attached in vector'}
${roiStats ? `- ROI Statistics: Mean Refl=${roiStats.mean?.toFixed(3)}, StdDev=${roiStats.std?.toFixed(3)}, Min=${roiStats.min?.toFixed(3)}, Max=${roiStats.max?.toFixed(3)}` : ''}

Provide a rigorous scientific analysis: identify key absorption dips (e.g., chlorophyll red-edge, water absorption bands, polymer C-H stretch overtones, iron oxide crystal field absorption), discuss physical mechanisms, confidence level, and recommend any verification steps.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: userPrompt,
          config: {
            systemInstruction: systemPrompt,
            temperature: 0.2,
          },
        });

        const textOutput = response.text || 'No response generated from analysis model.';
        res.statusCode = 200;
        res.end(JSON.stringify({ analysis: textOutput, timestamp: new Date().toISOString() }));
      } catch (err: unknown) {
        console.error('Gemini API Error:', err);
        const message = err instanceof Error ? err.message : 'Unknown server error';
        res.statusCode = 500;
        res.end(JSON.stringify({ error: message }));
      }
    });

    return true;
  }

  return false;
}
