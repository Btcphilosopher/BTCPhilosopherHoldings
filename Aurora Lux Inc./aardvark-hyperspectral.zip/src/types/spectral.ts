/**
 * Aardvark Hyperspectral Core Data Models and Scientific Type Definitions
 * Traceable, physically registered spectral data structures.
 */

export type SensorArchitecture = 'pushbroom' | 'snapshot' | 'tunable_filter' | 'line_scan';

export type CalibrationState =
  | 'RAW_MEASUREMENT'
  | 'DARK_CORRECTED'
  | 'RADIOMETRIC_CALIBRATED'
  | 'GEOMETRIC_RECTIFIED'
  | 'ANALYSIS_DERIVED';

export interface CameraProfile {
  id: string;
  name: string;
  architecture: SensorArchitecture;
  spatialResolution: [number, number]; // [width, height]
  spectralBands: number;
  wavelengthRange: [number, number]; // [start_nm, end_nm]
  pixelPitchMicrons: number;
  fullWellCapacityElectrons: number;
  readNoiseElectrons: number;
  darkCurrentRate: number; // e-/pixel/s at 20°C
  adcResolutionBits: number;
  defaultGainDb: number;
  defaultIntegrationTimeMs: number;
  sensorTemperatureCelsius: number;
  interfaceType: 'USB3 Vision' | 'GigE Vision' | 'Camera Link' | 'CoaXPress' | 'Synthetic Simulator';
  lensModel: string;
  focalLengthMm: number;
  fNumber: number;
}

export interface HyperspectralMetadata {
  camera_id: string;
  sensor_id: string;
  lens_id: string;
  acquisition_time: string;
  integration_time_ms: number;
  gain_db: number;
  offset: number;
  frame_rate_fps: number;
  wavelength_start_nm: number;
  wavelength_end_nm: number;
  spectral_resolution_fwhm_nm: number;
  spatial_resolution_px: [number, number];
  bit_depth: number;
  temperature_celsius: number;
  gps: {
    latitude: number;
    longitude: number;
    altitude_m: number;
  };
  orientation: {
    pitch_deg: number;
    roll_deg: number;
    yaw_deg: number;
  };
  calibration_id: string;
  operator: string;
  software_version: string;
  pipeline_version: string;
  is_synthetic: boolean;
  provenance_note: string;
}

export interface BadPixelMask {
  width: number;
  height: number;
  // 0 = Normal, 1 = Dead, 2 = Hot, 3 = Saturated, 4 = Noisy
  mask: Uint8Array;
  deadCount: number;
  hotCount: number;
  saturatedCount: number;
  noisyCount: number;
}

export interface CalibrationRecord {
  calibrationId: string;
  createdAt: string;
  operator: string;
  targetCameraId: string;
  darkFrameMean: Float32Array; // [bands] or [height, width]
  whiteReferenceReflectance: Float32Array; // [bands]
  whitePanelType: 'Spectralon 99%' | 'Labsphere Zenith' | 'Factory NIST Standard';
  wavelengthCoefficients: [number, number, number]; // polynomial λ = c0 + c1*p + c2*p^2
  wavelengthResidualRmsNm: number;
  smileCorrectionMap?: Float32Array; // spatial smile shift
  keystoneCorrectionMap?: Float32Array; // chromatic keystone shift
  badPixelCount: number;
  validityDays: number;
}

export interface SpectralAbsorptionFeature {
  centerNm: number;
  depth: number;
  widthNm: number;
  area: number;
  label: string;
}

export interface SpectralLibraryItem {
  id: string;
  name: string;
  category: 'Vegetation' | 'Mineral / Rock' | 'Metal / Alloy' | 'Polymer / Plastic' | 'Building / Surface' | 'Liquid';
  chemicalFormula?: string;
  wavelengthRange: [number, number];
  wavelengths: number[];
  reflectance: number[];
  absorptionFeatures: SpectralAbsorptionFeature[];
  uncertaintyEstimate: number; // e.g. 0.015 (1.5%)
  referenceSource: string;
  isSynthetic: boolean;
}

export interface SpectralROI {
  id: string;
  name: string;
  color: string;
  type: 'point' | 'rect' | 'polygon';
  points: { x: number; y: number }[];
  pixelCount: number;
  meanSpectrum: number[];
  stdSpectrum: number[];
  ciLow: number[];
  ciHigh: number[];
  minSpectrum: number[];
  maxSpectrum: number[];
}

export interface SpectralCube {
  id: string;
  name: string;
  width: number;
  height: number;
  bands: number;
  wavelengths: number[]; // wavelength for each band in nm
  // Data layout: flat Float32Array of size width * height * bands
  // Stored in BIP (Band Interleaved by Pixel) format: index = (y * width + x) * bands + b
  data: Float32Array;
  calibrationState: CalibrationState;
  metadata: HyperspectralMetadata;
  badPixelMask?: BadPixelMask;
  auditTrail: AuditTrailEntry[];
}

export interface AuditTrailEntry {
  timestamp: string;
  stage: string;
  action: string;
  operator: string;
  parameters: Record<string, unknown>;
  outputHash: string;
}

export interface PCAResult {
  numComponents: number;
  eigenvalues: number[];
  explainedVarianceRatio: number[];
  cumulativeVarianceRatio: number[];
  loadings: number[][]; // [component][band]
  scoreMaps: Float32Array[]; // [component] -> width * height
}

export interface LinearUnmixingResult {
  endmemberNames: string[];
  endmemberColors: string[];
  abundanceMaps: Float32Array[]; // [endmember] -> width * height
  residualRmsMap: Float32Array; // width * height
  meanResidualError: number;
}

export interface SAMResult {
  referenceName: string;
  angleMap: Float32Array; // radians, width * height
  meanAngleRad: number;
  thresholdRad: number;
  matchMask: Uint8Array; // 1 = match within threshold
}

export interface AnomalyDetectionResult {
  algorithm: 'RX_DETECTOR' | 'MAHALANOBIS' | 'PCA_RESIDUAL';
  scoreMap: Float32Array; // width * height
  threshold: number;
  detectedCount: number;
  topAnomalies: { x: number; y: number; score: number }[];
}

export interface ClassificationResult {
  algorithm: 'SAM_LIBRARY' | 'SPECTRAL_DISTANCE' | 'PCA_KMEANS';
  classes: {
    id: number;
    name: string;
    color: string;
    pixelCount: number;
    percentage: number;
  }[];
  classMap: Uint8Array; // width * height
  confidenceMap: Float32Array; // width * height, [0..1]
  unknownCount: number;
  overallAccuracyEstimate: number;
}

export interface ChangeDetectionResult {
  cubeAId: string;
  cubeBId: string;
  spectralDifferenceMap: Float32Array; // Euclidean distance, width * height
  spectralAngleChangeMap: Float32Array; // SAM angle in rad, width * height
  meanSamChangeRad: number;
  changedPixelsCount: number;
  percentageChanged: number;
}

export interface PipelineStep {
  id: string;
  name: string;
  type:
    | 'acquire'
    | 'dark_correct'
    | 'white_correct'
    | 'wavelength_cal'
    | 'radiometric_cal'
    | 'keystone_smile_rect'
    | 'denoise_sg'
    | 'unmixing'
    | 'classification'
    | 'export';
  status: 'pending' | 'running' | 'completed' | 'failed' | 'disabled';
  parameters: Record<string, string | number | boolean>;
  executionTimeMs?: number;
  summary?: string;
}
