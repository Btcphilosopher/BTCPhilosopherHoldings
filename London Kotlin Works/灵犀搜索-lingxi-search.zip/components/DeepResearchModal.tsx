'use client';

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  X, 
  CheckCircle2, 
  Loader2, 
  FileText, 
  Database, 
  ShieldAlert, 
  BarChart3,
  ExternalLink,
  Download,
  Share2
} from 'lucide-react';
import { DeepResearchStep } from '@/lib/types';

interface DeepResearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  query: string;
}

export default function DeepResearchModal({
  isOpen,
  onClose,
  query,
}: DeepResearchModalProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isGenerating, setIsGenerating] = useState(true);

  const steps: DeepResearchStep[] = [
    {
      id: 1,
      title: '意图拆解与多维命题构建',
      description: '对查询进行语义依存树解析，解构为政策准入、产能爬坡、出海渠道与壁垒四个子研报模块。',
      status: currentStepIndex > 0 ? 'completed' : currentStepIndex === 0 ? 'in_progress' : 'pending',
      sourcesFound: 24,
      insights: ['已锁定中汽协、海关总署及4家海外证券研究机构数据库']
    },
    {
      id: 2,
      title: '权威数据库深度穿透检索',
      description: '跨海关提单、上市公司海外工厂备案（ODI）、欧盟碳关税细则进行结构化数据抓取。',
      status: currentStepIndex > 1 ? 'completed' : currentStepIndex === 1 ? 'in_progress' : 'pending',
      sourcesFound: 86,
      insights: ['提取出比亚迪匈牙利/巴西基地、奇瑞拉美供应链的真实达产参数']
    },
    {
      id: 3,
      title: '多源证据交叉检验与冲突裁决',
      description: '对比悲观与乐观关税模型，剔除贴牌代工干扰项，建立蒙特卡洛销量预测回归区间。',
      status: currentStepIndex > 2 ? 'completed' : currentStepIndex === 2 ? 'in_progress' : 'pending',
      sourcesFound: 142,
      insights: ['裁决欧盟反补贴税争议：本土总装车型预计在2027年规避80%直接税负']
    },
    {
      id: 4,
      title: '生成万字级结构化研报与战略建议',
      description: '汇总结论摘要、核心企业竞争力矩阵、潜在地缘风险与对策清单。',
      status: currentStepIndex >= 3 ? 'completed' : 'pending',
      sourcesFound: 168,
      insights: ['已完成全篇事实核验，生成置信度等级评定：AAA级']
    }
  ];

  useEffect(() => {
    if (!isOpen) return;

    const timer0 = setTimeout(() => {
      setCurrentStepIndex(0);
      setIsGenerating(true);
    }, 0);
    const timer1 = setTimeout(() => setCurrentStepIndex(1), 1200);
    const timer2 = setTimeout(() => setCurrentStepIndex(2), 2400);
    const timer3 = setTimeout(() => {
      setCurrentStepIndex(3);
      setIsGenerating(false);
    }, 3800);

    return () => {
      clearTimeout(timer0);
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-slate-200 flex flex-col">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-linear-to-r from-slate-900 via-blue-950 to-indigo-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-cyan-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  灵犀深度研究智能体 (Deep Research)
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-400/30">
                  多智能体自治推理系统
                </span>
              </div>
              <p className="text-xs text-slate-300 truncate max-w-xl">
                研究课题：{query || '2027年中国新能源汽车出口格局与品牌竞争'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Progress Steps Timeline */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {steps.map((st, i) => (
              <div 
                key={st.id}
                className={`p-3.5 rounded-2xl border transition-all ${
                  st.status === 'completed'
                    ? 'bg-blue-50/70 border-blue-200 text-blue-900'
                    : st.status === 'in_progress'
                      ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-400/30 text-amber-900'
                      : 'bg-slate-50 border-slate-200 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-mono font-bold">第 0{st.id} 阶段</span>
                  {st.status === 'completed' ? (
                    <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  ) : st.status === 'in_progress' ? (
                    <Loader2 className="w-4 h-4 text-amber-600 animate-spin" />
                  ) : (
                    <div className="w-3.5 h-3.5 rounded-full border border-slate-300" />
                  )}
                </div>
                <div className="text-xs font-bold leading-tight line-clamp-1">{st.title}</div>
                <div className="text-[10px] opacity-75 mt-1 line-clamp-2">{st.description}</div>
              </div>
            ))}
          </div>

          {/* Real-time Agent Log / Synthesized Report Preview */}
          <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-bold text-slate-800">
                  深度研究报告成果预览 (灵犀智能研报系统)
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md font-medium text-[11px]">
                  置信度：98.4% · 原始文献链全量溯源
                </span>
              </div>
            </div>

            {/* Generated Report Content */}
            <div className="prose prose-sm max-w-none text-xs text-slate-700 space-y-3.5">
              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 text-sm mb-1">
                  一、执行摘要 (Executive Summary)
                </div>
                <p className="leading-relaxed">
                  2027年中国新能源汽车出海将由以整车直口为主的“1.0贸易时代”彻底跃升为以全产业链深度扎根的“2.0本土化制造时代”。预计比亚迪、奇瑞、吉利、上汽名爵与长安汽车五家头部自主品牌将占据全行业海外出口总增量的74.2%。核心增量蓝海由传统西欧向东盟自贸区（RCEP免关税红利）、中东（海湾六国主权基金能源转型合作）及南美（巴西资源互换协同）扩散。
                </p>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 text-sm mb-1">
                  二、竞争格局预测及五大品牌海外核心支撑要素
                </div>
                <ul className="list-disc pl-4 space-y-1">
                  <li><strong>比亚迪 (BYD)：</strong>预计2027海外销量冲刺100万辆。依托自建8艘7000车位双燃料滚装船队平抑海运成本，匈牙利与巴西两座百万级整车基地全面投产，规避区域反补贴关税风险。</li>
                  <li><strong>奇瑞汽车 (Chery)：</strong>深耕拉美与欧亚大陆20余年，海外经销商触达率最高，PHEV长续航SUV切入欠发达充电基础设施国家形成独家错位竞争优势。</li>
                  <li><strong>吉利汽车 (Geely)：</strong>SEA浩瀚架构全球化认可度高，极氪与领克深耕欧洲高端主流细分市场，沃尔沃全球安全声誉形成降维协同效应。</li>
                  <li><strong>上汽名爵 (SAIC MG)：</strong>在英国及西欧拥有悠久品牌认同认知，纯电小钢炮在欧洲紧凑级市场保有量领先。</li>
                  <li><strong>长安汽车 (深蓝/阿维塔)：</strong>携手华为智能座舱出海，以泰国罗勇右舵车基地辐射澳新与东南亚市场。</li>
                </ul>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 text-sm mb-1">
                  三、风险研判与中国车企战略防御建议
                </div>
                <p className="leading-relaxed">
                  需高度警惕地缘贸易保护主义升级、欧盟《新电池法》碳足迹全生命周期核算合规要求，以及当地劳工保护政策差异。建议企业加速推行“技术输出+本地合资+全生命周期电池回收网络”一体化出海战略。
                </p>
              </div>
            </div>

          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="px-6 py-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            报告编码：<span className="font-mono text-slate-700">LX-RESEARCH-202610-0982</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => alert('已生成完整格式化PDF研究白皮书并开始下载')}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>导出完整研报 (PDF)</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-300 hover:bg-slate-200 text-slate-700 text-xs font-medium transition-colors"
            >
              关闭
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
