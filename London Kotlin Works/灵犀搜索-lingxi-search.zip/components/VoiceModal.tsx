'use client';

import React, { useState, useEffect } from 'react';
import { Mic, MicOff, X, ArrowRight, Volume2, Sparkles } from 'lucide-react';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSearch: (spokenQuery: string) => void;
}

export default function VoiceModal({
  isOpen,
  onClose,
  onSearch,
}: VoiceModalProps) {
  const [isListening, setIsListening] = useState(true);
  const [transcript, setTranscript] = useState('');

  const sampleVoiceQuery = '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。';

  useEffect(() => {
    if (!isOpen) return;

    const timer0 = setTimeout(() => {
      setTranscript('');
      setIsListening(true);
    }, 0);

    // Simulate progressive speech recognition
    let currentIdx = 0;
    const interval = setInterval(() => {
      if (currentIdx <= sampleVoiceQuery.length) {
        setTranscript(sampleVoiceQuery.slice(0, currentIdx));
        currentIdx += 2;
      } else {
        clearInterval(interval);
        setIsListening(false);
      }
    }, 120);

    return () => {
      clearTimeout(timer0);
      clearInterval(interval);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 text-center relative overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold mb-4 border border-blue-200/60">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>灵犀中文语音大模型 · 实时流式识别</span>
        </div>

        {/* Dynamic Waveform Visualizer */}
        <div className="my-6 flex items-center justify-center gap-1.5 h-20">
          {[40, 70, 95, 55, 80, 100, 65, 85, 45, 90, 75, 50].map((h, i) => (
            <div
              key={i}
              className={`w-1.5 rounded-full transition-all duration-300 ${
                isListening
                  ? 'bg-linear-to-t from-blue-600 to-cyan-400 animate-pulse'
                  : 'bg-slate-300'
              }`}
              style={{
                height: isListening ? `${h}%` : '20%',
                animationDelay: `${i * 80}ms`,
              }}
            />
          ))}
        </div>

        {/* Status text */}
        <div className="text-xs font-semibold tracking-wider text-slate-400 uppercase mb-2">
          {isListening ? '正在聆听您的普通话语音...' : '语音录入完成'}
        </div>

        {/* Live Recognized Transcription */}
        <div className="min-h-[70px] p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-sm font-medium text-slate-800 leading-relaxed">
          {transcript || '请直接对麦克风清晰说话...'}
        </div>

        {/* Quick alternative suggestions */}
        <div className="mt-4 text-xs text-slate-400 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => setTranscript('上海最好的粤菜餐厅')}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-600 transition-colors"
          >
            “上海最好的粤菜餐厅”
          </button>
          <button
            onClick={() => setTranscript('苹果最新手机')}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-600 transition-colors"
          >
            “苹果最新手机”
          </button>
        </div>

        {/* Action Button */}
        <div className="mt-6 flex items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => {
              if (transcript) {
                onSearch(transcript);
                onClose();
              }
            }}
            disabled={!transcript}
            className="w-full py-3 px-6 rounded-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-sm shadow-md hover:shadow-blue-500/25 flex items-center justify-center gap-2 transition-all"
          >
            <span>搜索该语音内容</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
