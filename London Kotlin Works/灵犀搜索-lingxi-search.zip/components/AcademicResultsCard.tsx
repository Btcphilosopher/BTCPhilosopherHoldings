'use client';

import React from 'react';
import { 
  GraduationCap, 
  FileText, 
  Download, 
  ExternalLink, 
  BookOpen, 
  Award,
  CheckCircle2
} from 'lucide-react';
import { AcademicPaper } from '@/lib/types';
import { ACADEMIC_PAPERS } from '@/lib/mock-data';

interface AcademicResultsCardProps {
  papers?: AcademicPaper[];
  query?: string;
}

export default function AcademicResultsCard({
  papers = ACADEMIC_PAPERS,
  query = '新能源汽车'
}: AcademicResultsCardProps) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden mb-6">
      
      {/* Top Header */}
      <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center">
            <GraduationCap className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              灵犀学术 · 中文核心期刊与国家专利文献库
            </h3>
            <p className="text-[11px] text-slate-500">
              索引中国知网 (CNKI)、万方数据、国家知识产权局 (CNIPA) 及顶级SCI期刊
            </p>
          </div>
        </div>

        <span className="text-xs text-teal-600 font-medium hover:underline cursor-pointer flex items-center gap-1">
          <span>进入专业学术模式</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </span>
      </div>

      {/* Papers List */}
      <div className="divide-y divide-slate-100">
        {papers.map((paper) => (
          <div key={paper.id} className="p-5 hover:bg-slate-50/70 transition-colors">
            
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[11px] font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-sm border border-teal-200/60">
                    {paper.journal}
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-slate-500 font-medium">{paper.publishYear}年</span>
                  {paper.isOpenAccess && (
                    <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-xs border border-emerald-200">
                      开放获取 (OA)
                    </span>
                  )}
                </div>

                <h4 className="text-base font-bold text-slate-900 hover:text-teal-600 cursor-pointer transition-colors leading-snug">
                  {paper.title}
                </h4>

                <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-1.5">
                  <span className="font-medium text-slate-700">{paper.authors.join('，')}</span>
                  <span className="text-slate-300">|</span>
                  <span className="text-slate-400 font-mono text-[11px]">DOI: {paper.doi}</span>
                  <span className="text-slate-300">|</span>
                  <span className="text-amber-700 font-medium bg-amber-50 px-1.5 py-0.2 rounded-xs">被引频次: {paper.citationCount}</span>
                </div>
              </div>

              {/* Action */}
              <div className="flex items-center gap-2 shrink-0">
                {paper.pdfAvailable && (
                  <button
                    type="button"
                    onClick={() => alert(`已为学者开启「${paper.title}」的高清PDF直读与双语翻译`)}
                    className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>下载全文</span>
                  </button>
                )}
              </div>
            </div>

            {/* Abstract */}
            <p className="text-xs text-slate-600 mt-2.5 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200/60">
              <span className="font-semibold text-slate-700 mr-1.5">摘要：</span>
              {paper.abstract}
            </p>

            {/* Keywords */}
            <div className="mt-3 flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400">关键词:</span>
              {paper.keywords.map((kw, i) => (
                <span 
                  key={i}
                  className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-normal hover:bg-teal-50 hover:text-teal-700 cursor-pointer transition-colors"
                >
                  {kw}
                </span>
              ))}
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
