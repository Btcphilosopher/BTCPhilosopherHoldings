'use client';

import React, { useState } from 'react';
import { 
  CloudSun, 
  Grid, 
  ShieldCheck, 
  User, 
  Clock, 
  Settings, 
  SlidersHorizontal,
  ChevronDown,
  Sparkles
} from 'lucide-react';
import { SearchTab, BackgroundTheme } from '@/lib/types';

interface HeaderProps {
  currentTab: SearchTab;
  onTabChange: (tab: SearchTab) => void;
  bgTheme: BackgroundTheme;
  onBgThemeChange: (theme: BackgroundTheme) => void;
  onOpenPrivacy: () => void;
  onOpenWeather: () => void;
  onOpenApps: () => void;
  onOpenHistory: () => void;
  onGoHome: () => void;
  isCompact?: boolean;
}

export default function Header({
  currentTab,
  onTabChange,
  bgTheme,
  onBgThemeChange,
  onOpenPrivacy,
  onOpenWeather,
  onOpenApps,
  onOpenHistory,
  onGoHome,
  isCompact = false,
}: HeaderProps) {
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const [showMoreTabs, setShowMoreTabs] = useState(false);

  const mainTabs: { id: SearchTab; label: string }[] = [
    { id: 'web', label: '网页' },
    { id: 'ai', label: 'AI回答' },
    { id: 'deep_research', label: '深度研究' },
    { id: 'image', label: '图片' },
    { id: 'video', label: '视频' },
    { id: 'academic', label: '学术' },
    { id: 'news', label: '新闻' },
    { id: 'maps', label: '地图' },
    { id: 'shopping', label: '购物' },
  ];

  const themeOptions: { id: BackgroundTheme; label: string; desc: string }[] = [
    { id: 'shanshui', label: '山水画境', desc: '国风高铁与晨曦天际' },
    { id: 'city', label: '现代城际', desc: '超现代摩天光影夜色' },
    { id: 'white', label: '极简纯白', desc: '纯净视界，高效聚焦' },
    { id: 'dark', label: '深色暗夜', desc: '低眩光深邃沉浸质感' },
    { id: 'ambient', label: '动态流光', desc: '柔和渐变环境氛围' },
  ];

  return (
    <header className={`w-full z-30 transition-all duration-300 ${
      isCompact 
        ? 'sticky top-0 bg-white/90 backdrop-blur-md border-b border-slate-200/80 shadow-xs' 
        : 'relative bg-transparent text-white'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
        
        {/* Zone 1: Brand Wordmark (Single text element / logo mark) */}
        <div className="flex items-center gap-6">
          <button 
            onClick={onGoHome}
            className="flex items-center gap-2.5 text-left group focus:outline-hidden focus-visible:ring-2 focus-visible:ring-blue-500 rounded-lg py-1 px-1.5 -ml-1.5 transition-transform active:scale-98"
          >
            {/* Dynamic Chinese Swirl Logo Orb */}
            <div className="relative w-8 h-8 rounded-full bg-linear-to-tr from-blue-700 via-sky-500 to-cyan-300 p-0.5 shadow-md flex items-center justify-center shrink-0">
              <div className="w-full h-full rounded-full bg-slate-950/20 backdrop-blur-xs flex items-center justify-center">
                <span className="text-white text-xs font-bold tracking-tighter">灵</span>
              </div>
              <div className="absolute inset-0 rounded-full border border-white/40 pointer-events-none animate-pulse" />
            </div>

            <div className="flex items-baseline gap-1.5">
              <span className={`text-lg font-bold tracking-tight transition-colors ${
                isCompact ? 'text-slate-900 group-hover:text-blue-600' : 'text-white group-hover:text-blue-200 drop-shadow-xs'
              }`}>
                灵犀搜索
              </span>
              <span className={`text-[10px] tracking-wider uppercase font-medium px-1.5 py-0.2 rounded-sm border ${
                isCompact 
                  ? 'text-blue-700 bg-blue-50 border-blue-200' 
                  : 'text-white/90 bg-white/15 border-white/25 backdrop-blur-xs'
              }`}>
                NEXT-GEN
              </span>
            </div>
          </button>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            {mainTabs.slice(0, 7).map((tab) => {
              const isActive = currentTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`relative px-3 py-1.5 text-sm font-medium transition-all rounded-md whitespace-nowrap ${
                    isActive 
                      ? isCompact
                        ? 'text-blue-600 font-semibold bg-blue-50/80'
                        : 'text-white font-semibold bg-white/20 backdrop-blur-xs shadow-xs'
                      : isCompact
                        ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                        : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {tab.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-blue-500 rounded-full" />
                  )}
                </button>
              );
            })}

            {/* Dropdown for More Tabs */}
            <div className="relative">
              <button
                onClick={() => setShowMoreTabs(!showMoreTabs)}
                className={`flex items-center gap-1 px-2.5 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  isCompact 
                    ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70' 
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                <span>更多</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </button>

              {showMoreTabs && (
                <div 
                  className="absolute left-0 mt-1.5 w-36 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setShowMoreTabs(false)}
                >
                  {mainTabs.slice(7).map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => {
                        onTabChange(tab.id);
                        setShowMoreTabs(false);
                      }}
                      className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-colors flex items-center justify-between"
                    >
                      {tab.label}
                      {currentTab === tab.id && <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />}
                    </button>
                  ))}
                  <div className="border-t border-slate-100 my-1" />
                  <button
                    onClick={() => {
                      onTabChange('explore');
                      setShowMoreTabs(false);
                    }}
                    className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-colors flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span>全景探索</span>
                  </button>
                </div>
              )}
            </div>
          </nav>
        </div>

        {/* Zone 3: Primary Actions (Weather, Theme Switcher, App Grid, Privacy, Profile) */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Weather Widget */}
          <button
            onClick={onOpenWeather}
            title="查看全国气象与空气质量"
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
              isCompact 
                ? 'text-slate-700 hover:bg-slate-100 border border-slate-200/80' 
                : 'text-white/95 bg-black/20 hover:bg-black/35 backdrop-blur-md border border-white/20'
            }`}
          >
            <CloudSun className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="hidden sm:inline">北京</span>
            <span className="tabular-nums font-semibold">12°C</span>
            <span className="hidden sm:inline text-[11px] opacity-80">晴 · 优</span>
          </button>

          {/* Background Theme Selector */}
          <div className="relative">
            <button
              onClick={() => setShowThemeMenu(!showThemeMenu)}
              title="切换界面背景与氛围"
              className={`p-1.5 rounded-lg transition-colors flex items-center gap-1 text-xs font-medium ${
                isCompact
                  ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  : 'text-white/90 hover:text-white hover:bg-white/15'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="hidden lg:inline">视界</span>
            </button>

            {showThemeMenu && (
              <div 
                className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 text-slate-800 animate-in fade-in duration-150"
                onMouseLeave={() => setShowThemeMenu(false)}
              >
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 border-b border-slate-100">
                  背景与视界风格
                </div>
                {themeOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => {
                      onBgThemeChange(opt.id);
                      setShowThemeMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs transition-colors flex items-center justify-between ${
                      bgTheme === opt.id ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div>
                      <div className="font-medium">{opt.label}</div>
                      <div className="text-[10px] text-slate-400">{opt.desc}</div>
                    </div>
                    {bgTheme === opt.id && <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Privacy Security Shield */}
          <button
            onClick={onOpenPrivacy}
            title="隐私保护仪表盘 · 无痕安全检索"
            className={`p-1.5 rounded-lg transition-colors ${
              isCompact
                ? 'text-slate-600 hover:text-blue-600 hover:bg-slate-100'
                : 'text-white/90 hover:text-white hover:bg-white/15'
            }`}
          >
            <ShieldCheck className="w-4.5 h-4.5 text-emerald-500" />
          </button>

          {/* 9-Dots App Ecosystem Grid Launcher */}
          <button
            onClick={onOpenApps}
            title="灵犀生态服务矩阵"
            className={`p-1.5 rounded-lg transition-colors ${
              isCompact
                ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                : 'text-white/90 hover:text-white hover:bg-white/15'
            }`}
          >
            <Grid className="w-4.5 h-4.5" />
          </button>

          {/* User History & Avatar */}
          <button
            onClick={onOpenHistory}
            title="个人检索历史与收藏"
            className="flex items-center gap-1.5 p-1 rounded-full border border-white/30 hover:border-blue-400 transition-all focus:outline-hidden"
          >
            <div className="w-7 h-7 rounded-full bg-linear-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white text-xs font-bold shadow-xs">
              <User className="w-4 h-4" />
            </div>
          </button>

        </div>
      </div>
    </header>
  );
}
