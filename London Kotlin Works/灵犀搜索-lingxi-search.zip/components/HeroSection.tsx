'use client';

import React from 'react';
import Image from 'next/image';
import { 
  Sparkles, 
  Image as ImageIcon, 
  Video, 
  GraduationCap, 
  MapPin, 
  ShoppingBag, 
  ArrowRight,
  Flame,
  Star,
  Zap
} from 'lucide-react';
import SearchBox from './SearchBox';
import { SearchTab } from '@/lib/types';

interface HeroSectionProps {
  query: string;
  onQueryChange: (q: string) => void;
  onSearch: (q?: string) => void;
  onSelectTab: (tab: SearchTab) => void;
  onVoiceClick: () => void;
  onCameraClick: () => void;
  onOpenModelModal: () => void;
}

export default function HeroSection({
  query,
  onQueryChange,
  onSearch,
  onSelectTab,
  onVoiceClick,
  onCameraClick,
  onOpenModelModal,
}: HeroSectionProps) {
  const hotTags = [
    { text: '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。', label: '★ 中国新能源汽车产业出口趋势', isStar: true },
    { text: '中秋节与国庆出游高铁路网热门目的地推荐及客流', label: '♨ 中秋节旅游推荐', isFlame: true },
    { text: '国产人工智能大模型与具身智能最新突破与应用', label: '♨ AI大模型最新进展', isFlame: true },
    { text: '全球气候变化综合科学评估报告关键指标解读', label: '★ 全球气候变化报告', isStar: true },
  ];

  const featureTiles: {
    tab: SearchTab;
    title: string;
    subtitle: string;
    icon: React.ReactNode;
  }[] = [
    {
      tab: 'ai',
      title: 'AI智能问答',
      subtitle: '更聪明的搜索体验',
      icon: <Sparkles className="w-5 h-5 text-sky-400" />,
    },
    {
      tab: 'image',
      title: '图片搜索',
      subtitle: '海量高清图片',
      icon: <ImageIcon className="w-5 h-5 text-cyan-400" />,
    },
    {
      tab: 'video',
      title: '视频搜索',
      subtitle: '发现精彩内容',
      icon: <Video className="w-5 h-5 text-indigo-400" />,
    },
    {
      tab: 'academic',
      title: '学术搜索',
      subtitle: '权威文献来源',
      icon: <GraduationCap className="w-5 h-5 text-teal-400" />,
    },
    {
      tab: 'maps',
      title: '地图服务',
      subtitle: '精准位置导航',
      icon: <MapPin className="w-5 h-5 text-emerald-400" />,
    },
    {
      tab: 'shopping',
      title: '生活助手',
      subtitle: '便捷生活服务',
      icon: <ShoppingBag className="w-5 h-5 text-amber-400" />,
    },
  ];

  return (
    <div className="relative z-10 flex flex-col justify-between min-h-[calc(100vh-3.5rem)] pb-6 px-4">
      {/* Center Hero Block */}
      <div className="flex-1 flex flex-col items-center justify-center pt-8 pb-12 text-center">
        
        {/* Brand Logo & Name */}
        <div className="flex flex-col items-center mb-8">
          {/* Dynamic 3D Swirl Orb */}
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 mb-3 rounded-full bg-linear-to-tr from-blue-700 via-sky-500 to-cyan-300 p-1 shadow-2xl flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-slate-950/20 backdrop-blur-xs flex items-center justify-center">
              <span className="text-white text-3xl sm:text-4xl font-extrabold tracking-tighter drop-shadow-md">
                灵
              </span>
            </div>
            {/* Ethereal Glow Ring */}
            <div className="absolute -inset-1 rounded-full bg-blue-500/30 blur-lg pointer-events-none -z-10 animate-pulse" />
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white drop-shadow-md">
            灵犀搜索
          </h1>

          <p className="mt-2 text-sm sm:text-base font-light tracking-[0.35em] text-white/90 drop-shadow-xs">
            连 接 世 界 · 发 现 更 多
          </p>
        </div>

        {/* Big Search Input */}
        <div className="w-full mb-6">
          <SearchBox
            query={query}
            onChange={onQueryChange}
            onSearch={onSearch}
            onVoiceClick={onVoiceClick}
            onCameraClick={onCameraClick}
            size="large"
            autoFocus
          />
        </div>

        {/* Hot Trending Pill Links */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 max-w-4xl px-2">
          {hotTags.map((tag, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                onQueryChange(tag.text);
                onSearch(tag.text);
              }}
              className="px-3.5 py-1.5 rounded-full text-xs font-medium text-white/95 bg-black/25 hover:bg-black/45 backdrop-blur-md border border-white/20 transition-all hover:border-white/50 hover:scale-102 flex items-center gap-1.5 shadow-xs"
            >
              {tag.isFlame && <Flame className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
              {tag.isStar && <Star className="w-3.5 h-3.5 text-amber-300 shrink-0 fill-amber-300/30" />}
              <span className="drop-shadow-xs">{tag.label.replace(/^[★♨]\s*/, '')}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Feature Tiles Bar + AI Foundation Model Card */}
      <div className="w-full max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4 items-stretch">
          
          {/* Left: 6 Feature Tiles (Glass translucent style) */}
          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 sm:gap-2.5 p-3 rounded-2xl bg-black/35 backdrop-blur-xl border border-white/20 shadow-2xl">
            {featureTiles.map((tile) => (
              <button
                key={tile.tab}
                type="button"
                onClick={() => onSelectTab(tile.tab)}
                className="flex flex-col items-center justify-center p-3 rounded-xl hover:bg-white/15 transition-all text-center group border border-transparent hover:border-white/20"
              >
                <div className="w-10 h-10 rounded-full bg-white/10 group-hover:bg-white/20 flex items-center justify-center mb-2 transition-transform group-hover:scale-110">
                  {tile.icon}
                </div>
                <div className="text-xs font-semibold text-white drop-shadow-xs group-hover:text-cyan-300 transition-colors">
                  {tile.title}
                </div>
                <div className="text-[10px] text-white/70 mt-0.5 line-clamp-1">
                  {tile.subtitle}
                </div>
              </button>
            ))}
          </div>

          {/* Right: Featured AI Model Card (灵犀智脑 5.0) */}
          <div className="lg:col-span-4 relative rounded-2xl overflow-hidden bg-linear-to-r from-slate-900/90 via-blue-950/85 to-indigo-950/90 backdrop-blur-xl border border-blue-400/30 shadow-2xl p-4 flex items-center justify-between group">
            <div className="relative z-10 max-w-[65%]">
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-blue-500/25 border border-blue-400/40 text-[10px] font-semibold text-blue-200 mb-1.5">
                <Zap className="w-3 h-3 text-cyan-300" />
                <span>灵犀智脑 5.0</span>
              </div>
              <h2 className="text-sm font-bold text-white tracking-wide">
                更强的理解 · 更好的创造
              </h2>
              <p className="text-[11px] text-blue-200/80 mt-1 line-clamp-1">
                万亿多模态基座大模型 · 秒级深度推理
              </p>

              <button
                type="button"
                onClick={onOpenModelModal}
                className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded-lg shadow-sm transition-colors"
              >
                <span>了解更多</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Visual 3D Chip Tower Artwork */}
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 shrink-0 rounded-xl overflow-hidden border border-white/20 shadow-md">
              <Image
                src="/images/lingxi_ai_chip_tower.jpg"
                alt="灵犀智脑 5.0 神经算力核心"
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-linear-to-t from-slate-950/60 to-transparent pointer-events-none" />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
