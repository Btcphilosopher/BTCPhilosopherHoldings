'use client';

import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Tag, 
  TrendingDown, 
  ShieldCheck, 
  Star, 
  ExternalLink,
  Sliders,
  Check,
  Scale
} from 'lucide-react';
import { ShoppingProduct } from '@/lib/types';
import { SHOPPING_PRODUCTS } from '@/lib/mock-data';

interface ShoppingCompareCardProps {
  products?: ShoppingProduct[];
  query?: string;
}

export default function ShoppingCompareCard({
  products = SHOPPING_PRODUCTS,
  query = '国产旗舰电视'
}: ShoppingCompareCardProps) {
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [filterBrand, setFilterBrand] = useState<string>('all');

  const selectedProduct = products.find(p => p.id === selectedProductId) || products[0];

  const brands = ['all', ...Array.from(new Set(products.map(p => p.brand)))];

  const filteredProducts = filterBrand === 'all' 
    ? products 
    : products.filter(p => p.brand === filterBrand);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden mb-6">
      
      {/* Top Header */}
      <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
            <Scale className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              灵犀智能比价 · 全网电商参数与行情决策
            </h3>
            <p className="text-[11px] text-slate-500">
              真实采集京东自营、天猫旗舰及官方商城官方标定参数 · 历史价格追踪
            </p>
          </div>
        </div>

        {/* Brand Filter */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200 text-xs">
          <span className="text-slate-400 px-1.5 text-[11px]">品牌:</span>
          {brands.map(b => (
            <button
              key={b}
              onClick={() => setFilterBrand(b)}
              className={`px-2 py-0.5 rounded-md transition-colors ${
                filterBrand === b ? 'bg-blue-600 text-white font-medium' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {b === 'all' ? '全部' : b}
            </button>
          ))}
        </div>
      </div>

      {/* Products Row Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-200">
        {filteredProducts.map((prod) => {
          const isSelected = prod.id === selectedProduct.id;
          return (
            <div
              key={prod.id}
              onClick={() => setSelectedProductId(prod.id)}
              className={`p-4 flex flex-col justify-between cursor-pointer transition-all ${
                isSelected ? 'bg-amber-50/20 ring-2 ring-inset ring-blue-500/30' : 'hover:bg-slate-50/80'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[11px] font-semibold text-slate-500 px-1.5 py-0.5 rounded-sm bg-slate-100">
                    {prod.brand}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-amber-500 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{prod.score}</span>
                    <span className="text-[10px] text-slate-400 font-normal">({prod.reviewsCount})</span>
                  </div>
                </div>

                <h4 className="text-sm font-bold text-slate-900 mt-2 line-clamp-2 leading-snug">
                  {prod.name}
                </h4>

                {/* Price block */}
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-xl font-extrabold text-rose-600 tabular-nums">
                    ¥{prod.price.toLocaleString()}
                  </span>
                  {prod.originalPrice && (
                    <span className="text-xs text-slate-400 line-through tabular-nums">
                      ¥{prod.originalPrice.toLocaleString()}
                    </span>
                  )}
                  {prod.historicalLow && (
                    <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-sm flex items-center gap-0.5">
                      <TrendingDown className="w-3 h-3" />
                      史低 ¥{prod.historicalLow}
                    </span>
                  )}
                </div>

                {/* Seller & Warranty */}
                <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span className="truncate">{prod.seller}</span>
                </div>

                {/* Highlights tags */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {prod.highlights.map((h, i) => (
                    <span 
                      key={i} 
                      className="px-1.5 py-0.5 rounded-sm bg-blue-50 text-[10px] font-medium text-blue-700"
                    >
                      {h}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">{prod.warranty}</span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    alert(`正通过灵犀安全网关跳转至「${prod.seller}」官方验证购买通道...`);
                  }}
                  className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  <span>查底价</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Detailed Side-by-Side Specs Comparison Table */}
      <div className="border-t border-slate-200 p-5 bg-slate-50/50">
        <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
          核心硬件技术规格横评（严禁虚构）
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-200 rounded-lg overflow-hidden bg-white">
            <thead className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="p-2.5 w-1/4">参数指标</th>
                {filteredProducts.map(p => (
                  <th key={p.id} className="p-2.5 font-bold text-slate-900">
                    {p.brand} {p.name.split(' ')[1] || p.name.slice(0, 10)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {['屏幕尺寸', '背光技术', '峰值亮度', '刷新率', '音响配置'].map((specKey) => (
                <tr key={specKey} className="hover:bg-slate-50/60">
                  <td className="p-2.5 font-medium text-slate-500 bg-slate-50/50">{specKey}</td>
                  {filteredProducts.map(p => (
                    <td key={p.id} className="p-2.5 text-slate-900 font-medium">
                      {p.specs[specKey] || '—'}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
