'use client';

import React from 'react';
import Image from 'next/image';
import { 
  Zap, 
  Cpu, 
  ShieldCheck, 
  X, 
  Layers, 
  Award, 
  CheckCircle2, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface ModelInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTryModel: () => void;
}

export default function ModelInfoModal({
  isOpen,
  onClose,
  onTryModel,
}: ModelInfoModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 text-slate-800 relative max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Banner */}
        <div className="relative rounded-2xl overflow-hidden bg-linear-to-br from-slate-950 via-blue-950 to-indigo-950 text-white p-6 mb-5">
          <div className="relative z-10 max-w-md">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/20 border border-blue-400/40 text-blue-200 text-xs font-semibold mb-2">
              <Zap className="w-3.5 h-3.5 text-cyan-300" />
              <span>灵犀智脑 5.0 全新发布</span>
            </div>
            <h3 className="text-2xl font-black tracking-tight">
              下一代自主混合专家认知大模型
            </h3>
            <p className="text-xs text-blue-200/90 mt-1.5 leading-relaxed">
              专为中文互联网信息复杂语义、多维知识图谱推理与万亿异构数据检索打造。
            </p>
          </div>

          <div className="absolute right-0 bottom-0 top-0 w-1/3 opacity-40 pointer-events-none">
            <Image
              src="/images/lingxi_ai_chip_tower.jpg"
              alt="灵犀智脑架构"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Specifications Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-5">
          {[
            { label: '上下文窗口', val: '2,000,000 Tokens', sub: '超长公文与长视频' },
            { label: '混合专家 MoE', val: '32 专家动态路由', sub: '极致算力能效比' },
            { label: '事实核验准确率', val: '99.4%', sub: '消除模型幻觉' },
            { label: '响应初字延迟', val: '≤ 120ms', sub: '秒级端到端流式' },
          ].map((item, idx) => (
            <div key={idx} className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-center">
              <div className="text-[10px] text-slate-400 font-medium">{item.label}</div>
              <div className="text-sm font-extrabold text-blue-600 mt-1 tabular-nums">{item.val}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">{item.sub}</div>
            </div>
          ))}
        </div>

        {/* Architecture Highlights */}
        <div className="space-y-3 text-xs text-slate-600">
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-blue-50/50 border border-blue-100">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-900">中文常识与法律经贸深度微调</div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                深度融汇中国现行法律法规、各部委统计公报、全国高校学术期刊以及各地方言俚语习惯，实现原生中文语义零损耗理解。
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-purple-50/50 border border-purple-100">
            <Cpu className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-900">端到端神经检索与知识图谱协同 (Neuro-Symbolic)</div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                将大语言模型概率生成与十亿级实体结构化确定性知识图谱结合，让每一条结论皆有可溯源、可点击核验的原始权威出处。
              </p>
            </div>
          </div>
        </div>

        {/* Action */}
        <div className="mt-6 pt-4 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-400">国家大模型算法备案编号：LX-LLM-2026-0819</span>
          <button
            type="button"
            onClick={() => {
              onClose();
              onTryModel();
            }}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <span>立即体验智能问答</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
