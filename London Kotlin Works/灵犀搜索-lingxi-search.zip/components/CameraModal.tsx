'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { 
  Camera, 
  Upload, 
  X, 
  Sparkles, 
  Search, 
  Scan, 
  CheckCircle2,
  ArrowRight
} from 'lucide-react';

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSearch: (detectedQuery: string) => void;
}

export default function CameraModal({
  isOpen,
  onClose,
  onSearch,
}: CameraModalProps) {
  const [selectedSample, setSelectedSample] = useState<{
    id: string;
    title: string;
    category: string;
    query: string;
    imgUrl: string;
  }>({
    id: 's1',
    title: '中国新能源豪华纯电汽车 (仰望/比亚迪)',
    category: '智能汽车识别',
    query: '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。',
    imgUrl: 'https://picsum.photos/seed/evcar/600/400',
  });

  const [isScanning, setIsScanning] = useState(false);

  const samples = [
    {
      id: 's1',
      title: '中国新能源电动车 (仰望U8/比亚迪)',
      category: '整车与工业识别',
      query: '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。',
      imgUrl: 'https://picsum.photos/seed/evcar/600/400',
    },
    {
      id: 's2',
      title: '江南传统楼阁与古建筑古塔',
      category: '人文建筑与旅游',
      query: '中秋国庆中国古典园林与江南古建旅游景点推荐',
      imgUrl: 'https://picsum.photos/seed/pagoda/600/400',
    },
    {
      id: 's3',
      title: '超高清Mini LED旗舰智能电视',
      category: '数码比价与参数',
      query: '最好的国产Mini LED高刷电视对比与国补政策',
      imgUrl: 'https://picsum.photos/seed/smarttv/600/400',
    },
  ];

  const handleScanAndSearch = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      onSearch(selectedSample.query);
      onClose();
    }, 1200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 relative overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors z-20"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
            <Camera className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">
              灵犀多模态视觉识图搜索 (Visual Search)
            </h3>
            <p className="text-xs text-slate-500">
              支持万物识别、商品比价、同款查找、文字OCR与图搜图
            </p>
          </div>
        </div>

        {/* Image Preview with Scanning Animation */}
        <div className="relative w-full h-56 rounded-2xl overflow-hidden bg-slate-900 border border-slate-200 mb-4 flex items-center justify-center group">
          <Image
            src={selectedSample.imgUrl}
            alt={selectedSample.title}
            fill
            className="object-cover transition-transform group-hover:scale-102"
            referrerPolicy="no-referrer"
          />

          {/* Scanning Line overlay */}
          {isScanning && (
            <div className="absolute inset-0 bg-linear-to-b from-blue-500/20 via-cyan-400/40 to-transparent animate-pulse pointer-events-none border-b-2 border-cyan-400" />
          )}

          {/* Recognition HUD overlay */}
          <div className="absolute top-3 left-3 bg-slate-950/75 backdrop-blur-md px-3 py-1.5 rounded-xl text-white text-xs border border-white/20">
            <div className="text-[10px] text-cyan-300 font-mono">灵犀视觉目标检测已就绪</div>
            <div className="font-bold">{selectedSample.title}</div>
          </div>

          <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-lg text-slate-800 text-xs font-medium border border-slate-200">
            {selectedSample.category}
          </div>
        </div>

        {/* Sample Selection */}
        <div className="mb-5">
          <div className="text-xs font-semibold text-slate-500 mb-2">
            选择典型场景样图体验视觉智能识别：
          </div>
          <div className="grid grid-cols-3 gap-2">
            {samples.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setSelectedSample(s)}
                className={`p-2 rounded-xl text-left border transition-all ${
                  selectedSample.id === s.id
                    ? 'border-blue-600 bg-blue-50 text-blue-900 font-semibold ring-2 ring-blue-500/20'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="text-[11px] truncate font-medium">{s.title}</div>
                <div className="text-[9px] text-slate-400 mt-0.5">{s.category}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Upload or Search button */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => alert('已支持拖拽本地图片或剪贴板粘贴（JPG/PNG/WEBP最大支持50MB）')}
            className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            <span>上传本地图片</span>
          </button>

          <button
            type="button"
            onClick={handleScanAndSearch}
            disabled={isScanning}
            className="flex-1 py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            {isScanning ? (
              <span>智能特征提取中...</span>
            ) : (
              <>
                <Scan className="w-4 h-4" />
                <span>精准识别并搜索</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
}
