'use client';

import React from 'react';
import { 
  Building2, 
  ExternalLink, 
  CheckCircle2, 
  TrendingUp, 
  Share2, 
  Bookmark, 
  Clock, 
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';
import { KnowledgeEntity } from '@/lib/types';

interface KnowledgePanelProps {
  entity: KnowledgeEntity;
  onExploreRelated?: (entityName: string) => void;
  onTriggerDeepResearch?: (entityName: string) => void;
}

export default function KnowledgePanel({
  entity,
  onExploreRelated,
  onTriggerDeepResearch,
}: KnowledgePanelProps) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden text-slate-800">
      
      {/* Top Header Card */}
      <div className="p-5 bg-linear-to-br from-slate-900 via-slate-800 to-blue-950 text-white relative">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-sm bg-blue-500/25 border border-blue-400/30 text-blue-200">
                {entity.category}
              </span>
              <span className="flex items-center gap-1 text-[11px] text-emerald-300 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                国家知识图谱认证
              </span>
            </div>

            <h3 className="text-xl font-bold tracking-tight text-white">
              {entity.name}
            </h3>
            <p className="text-xs text-slate-300 mt-1 line-clamp-1">
              {entity.subtitle}
            </p>
          </div>

          <div className="flex items-center gap-1 text-slate-300">
            <button 
              type="button" 
              title="分享实体词条"
              className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button 
              type="button" 
              title="收藏到个人知识库"
              className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            >
              <Bookmark className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stock Widget (if applicable) */}
        {entity.stockInfo && (
          <div className="mt-4 pt-3 border-t border-white/15 flex items-center justify-between text-xs">
            <div className="flex items-baseline gap-2">
              <span className="font-semibold text-white/90">{entity.stockInfo.market}</span>
              <span className="font-mono text-slate-300 text-[11px]">{entity.stockInfo.symbol}</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-base font-bold font-mono text-white tabular-nums">
                {entity.stockInfo.price}
              </span>
              <span className="font-semibold font-mono text-emerald-400 tabular-nums">
                {entity.stockInfo.change}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Description */}
      <div className="p-5 border-b border-slate-100">
        <p className="text-xs leading-relaxed text-slate-600">
          {entity.description}
        </p>
      </div>

      {/* Key Quantitative Stats */}
      {entity.keyStats && entity.keyStats.length > 0 && (
        <div className="p-5 border-b border-slate-100 bg-slate-50/50">
          <div className="text-[11px] font-semibold text-slate-400 mb-3 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
            <span>核心发展指标</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {entity.keyStats.map((st, i) => (
              <div key={i} className="p-2.5 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
                <div className="text-[10px] text-slate-500 font-medium">{st.label}</div>
                <div className="text-sm font-bold text-slate-900 mt-1 tabular-nums">{st.value}</div>
                {st.trend && (
                  <div className="text-[10px] text-emerald-600 font-medium mt-0.5 truncate">{st.trend}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Attributes List */}
      <div className="p-5 border-b border-slate-100 divide-y divide-slate-100">
        <div className="text-[11px] font-semibold text-slate-400 pb-2 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-blue-600" />
          <span>实体核心属性</span>
        </div>
        {entity.attributes.map((attr, idx) => (
          <div key={idx} className="py-2 text-xs flex items-baseline justify-between gap-4">
            <span className="text-slate-400 shrink-0 font-medium">{attr.label}</span>
            <span className="text-slate-800 text-right font-normal">{attr.value}</span>
          </div>
        ))}
      </div>

      {/* Timeline Milestones */}
      {entity.timeline && entity.timeline.length > 0 && (
        <div className="p-5 border-b border-slate-100">
          <div className="text-[11px] font-semibold text-slate-400 mb-3 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            <span>历史与演进里程碑</span>
          </div>

          <div className="space-y-3 relative pl-3.5 border-l-2 border-blue-100">
            {entity.timeline.map((item, idx) => (
              <div key={idx} className="relative text-xs">
                <div className="absolute -left-[1.3rem] top-1 w-2 h-2 rounded-full bg-blue-600 ring-4 ring-white" />
                <div className="font-semibold text-slate-900 tabular-nums">{item.year}</div>
                <div className="text-slate-600 text-[11px] mt-0.5 leading-normal">{item.event}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Related Entities Graph */}
      {entity.relatedEntities && entity.relatedEntities.length > 0 && (
        <div className="p-5 border-b border-slate-100">
          <div className="text-[11px] font-semibold text-slate-400 mb-2.5">
            关联图谱节点
          </div>
          <div className="flex flex-wrap gap-1.5">
            {entity.relatedEntities.map((rel, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => onExploreRelated?.(rel.name)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-600 transition-colors text-xs text-left group border border-slate-200/60"
              >
                <div className="font-medium text-slate-800 group-hover:text-blue-600">{rel.name}</div>
                <div className="text-[10px] text-slate-400">{rel.relation}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Official Verification Sources */}
      {entity.officialSources && (
        <div className="p-4 bg-slate-50/70 text-xs">
          <div className="text-[11px] text-slate-400 mb-2">权威信源索引</div>
          <div className="space-y-1">
            {entity.officialSources.map((src, idx) => (
              <a
                key={idx}
                href={src.link}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between text-slate-600 hover:text-blue-600 py-1 transition-colors group"
              >
                <span className="truncate pr-2">{src.title}</span>
                <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-blue-600 shrink-0" />
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Deep Research CTA button */}
      <div className="p-4 border-t border-slate-100 bg-white">
        <button
          type="button"
          onClick={() => onTriggerDeepResearch?.(entity.name)}
          className="w-full py-2 px-3 rounded-xl bg-blue-50 hover:bg-blue-100/80 text-blue-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>针对“{entity.name}”发起深度研究</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

    </div>
  );
}
