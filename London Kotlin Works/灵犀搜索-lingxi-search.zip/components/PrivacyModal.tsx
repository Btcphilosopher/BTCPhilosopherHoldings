'use client';

import React, { useState } from 'react';
import { 
  ShieldCheck, 
  X, 
  Lock, 
  EyeOff, 
  Trash2, 
  Cpu, 
  Sliders, 
  CheckCircle2, 
  Download
} from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  isIncognito: boolean;
  onToggleIncognito: () => void;
  onClearHistory: () => void;
}

export default function PrivacyModal({
  isOpen,
  onClose,
  isIncognito,
  onToggleIncognito,
  onClearHistory,
}: PrivacyModalProps) {
  const [personalization, setPersonalization] = useState(false);
  const [aiDataIsolation, setAiDataIsolation] = useState(true);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 text-slate-800 relative max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-5">
          <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              灵犀隐私与数据主权中心
            </h3>
            <p className="text-xs text-slate-500">
              隐私是默认权利 · 零强制追踪 · 端到端查询加密
            </p>
          </div>
        </div>

        {/* Feature Switches */}
        <div className="space-y-3.5 divide-y divide-slate-100 text-xs">
          
          {/* Private Search Toggle */}
          <div className="pt-2 flex items-center justify-between">
            <div className="pr-4">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <EyeOff className="w-4 h-4 text-blue-600" />
                <span>无痕纯净搜索模式</span>
              </div>
              <p className="text-slate-500 mt-0.5">
                关闭所有本地与云端搜索历史沉淀，会话结束后自动销毁全部检索痕迹。
              </p>
            </div>
            <button
              type="button"
              onClick={onToggleIncognito}
              className={`w-12 h-6 rounded-full transition-colors relative shrink-0 p-0.5 ${
                isIncognito ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                isIncognito ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>

          {/* AI Training Isolation */}
          <div className="pt-3.5 flex items-center justify-between">
            <div className="pr-4">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-purple-600" />
                <span>大模型查询数据物理隔离</span>
              </div>
              <p className="text-slate-500 mt-0.5">
                您的任何搜索提问均不进入大模型公网无监督训练集，保障商业机密与个人隐私。
              </p>
            </div>
            <button
              type="button"
              onClick={() => setAiDataIsolation(!aiDataIsolation)}
              className={`w-12 h-6 rounded-full transition-colors relative shrink-0 p-0.5 ${
                aiDataIsolation ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                aiDataIsolation ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>

          {/* Personalization Recommendation Toggle */}
          <div className="pt-3.5 flex items-center justify-between">
            <div className="pr-4">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-amber-600" />
                <span>个性化算法分发开关</span>
              </div>
              <p className="text-slate-500 mt-0.5">
                开启后基于兴趣推荐相关热搜；关闭后严格按客观时间与国家权威标准中立排序。
              </p>
            </div>
            <button
              type="button"
              onClick={() => setPersonalization(!personalization)}
              className={`w-12 h-6 rounded-full transition-colors relative shrink-0 p-0.5 ${
                personalization ? 'bg-blue-600' : 'bg-slate-300'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                personalization ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>

        </div>

        {/* Security Invariants Box */}
        <div className="mt-5 p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-emerald-900 mb-1">
            <Lock className="w-4 h-4 text-emerald-700" />
            <span>国家商用密码标准 (SM4/SM2) 全链路安全合规</span>
          </div>
          <p className="text-emerald-800/80 leading-relaxed text-[11px]">
            灵犀搜索严格遵守《中华人民共和国数据安全法》与《个人信息保护法》，搜索通道全程启用国产商用密码传输加密，杜绝第三方探针植入与数字指纹跨域追踪。
          </p>
        </div>

        {/* Action Buttons: Clear History & Export */}
        <div className="mt-5 pt-4 border-t border-slate-200 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => {
              onClearHistory();
              alert('已彻底清空当前设备的所有本地检索历史');
            }}
            className="px-3.5 py-2 rounded-xl text-rose-700 hover:bg-rose-50 border border-rose-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>清空所有搜索记录</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors"
          >
            保存并返回
          </button>
        </div>

      </div>
    </div>
  );
}
