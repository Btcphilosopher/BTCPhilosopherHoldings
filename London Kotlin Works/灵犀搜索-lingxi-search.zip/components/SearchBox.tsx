'use client';

import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, 
  Mic, 
  Camera, 
  X, 
  Sparkles, 
  ArrowRight,
  TrendingUp,
  Building2,
  Apple
} from 'lucide-react';

interface SearchBoxProps {
  query: string;
  onChange: (value: string) => void;
  onSearch: (customQuery?: string) => void;
  onVoiceClick: () => void;
  onCameraClick: () => void;
  size?: 'large' | 'compact';
  autoFocus?: boolean;
}

export default function SearchBox({
  query,
  onChange,
  onSearch,
  onVoiceClick,
  onCameraClick,
  size = 'large',
  autoFocus = false,
}: SearchBoxProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close suggestions when clicking outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Contextual smart suggestions
  const getSuggestions = () => {
    const q = query.trim().toLowerCase();
    if (!q) {
      return [
        { text: '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。', tag: 'AI深度分析', type: 'ai' },
        { text: '上海最好的粤菜餐厅推荐及特色招牌菜', tag: '本地生活', type: 'local' },
        { text: '最好的国产Mini LED高刷电视对比与国补政策', tag: '数码比价', type: 'shopping' },
        { text: '苹果最新手机', tag: '多义词消歧', type: 'disambiguation' },
      ];
    }

    if (q.includes('苹果')) {
      return [
        { text: '苹果最新手机与iOS全场景生态评测', tag: '科技硬件 · Apple Inc.', type: 'tech' },
        { text: '苹果 (水果) 烟台红富士与陕西洛川苹果营养功效', tag: '植物林果 · 农产品', type: 'nature' },
        { text: '苹果产业链国内供应商最新财报与市场份额', tag: '财经研报', type: 'finance' },
      ];
    }

    if (q.includes('汽车') || q.includes('新能源') || q.includes('出口')) {
      return [
        { text: '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。', tag: 'AI深度报告', type: 'ai' },
        { text: '比亚迪与奇瑞2026-2027海外本土建厂规划进展', tag: '整车出海', type: 'industry' },
        { text: '中国新能源汽车800V高压超充基础设施密度对比', tag: '补能基建', type: 'tech' },
      ];
    }

    return [
      { text: `${query} 最新权威政策与行业标准解读`, tag: '官方规范', type: 'gov' },
      { text: `${query} 核心数据统计与市场规模预测`, tag: '深度研报', type: 'industry' },
      { text: `${query} 知乎与专业技术社区讨论精选`, tag: '网民讨论', type: 'community' },
    ];
  };

  const suggestions = getSuggestions();

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      setShowSuggestions(false);
      onSearch();
    }
  };

  const handleSelectSuggestion = (text: string) => {
    onChange(text);
    setShowSuggestions(false);
    onSearch(text);
  };

  const isLarge = size === 'large';

  return (
    <div ref={containerRef} className="relative w-full max-w-3xl mx-auto">
      <div 
        className={`relative flex items-center transition-all duration-300 rounded-full ${
          isLarge 
            ? 'h-14 sm:h-15 px-4 sm:px-5 bg-white/95 backdrop-blur-md shadow-2xl border border-white/60 focus-within:ring-4 focus-within:ring-blue-500/20 focus-within:border-blue-500'
            : 'h-11 px-3.5 bg-white shadow-md border border-slate-200 focus-within:ring-3 focus-within:ring-blue-500/20 focus-within:border-blue-500'
        }`}
      >
        {/* Left Search Icon */}
        <Search className={`shrink-0 transition-colors ${
          isLarge ? 'w-5 h-5 text-slate-400 group-hover:text-blue-500' : 'w-4 h-4 text-slate-400'
        }`} />

        {/* Search Input */}
        <input
          ref={inputRef}
          type="text"
          value={query}
          autoFocus={autoFocus}
          onChange={(e) => {
            onChange(e.target.value);
            setShowSuggestions(true);
          }}
          onFocus={() => {
            setIsFocused(true);
            setShowSuggestions(true);
          }}
          onKeyDown={handleKeyDown}
          placeholder="搜索你想了解的内容..."
          className={`w-full bg-transparent border-none outline-hidden px-3 text-slate-900 placeholder-slate-400 font-normal ${
            isLarge ? 'text-base sm:text-lg' : 'text-sm'
          }`}
        />

        {/* Clear Button */}
        {query && (
          <button
            type="button"
            onClick={() => {
              onChange('');
              inputRef.current?.focus();
            }}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors mr-1"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Action icons: Mic (Voice) and Camera (Image) */}
        <div className="flex items-center gap-1.5 sm:gap-2 text-slate-400 shrink-0 pr-1">
          <button
            type="button"
            onClick={onVoiceClick}
            title="语音输入检索"
            className="p-1.5 rounded-full hover:text-blue-600 hover:bg-blue-50 transition-colors"
          >
            <Mic className={`${isLarge ? 'w-5 h-5' : 'w-4 h-4'}`} />
          </button>

          <button
            type="button"
            onClick={onCameraClick}
            title="拍照或上传图片检索"
            className="p-1.5 rounded-full hover:text-blue-600 hover:bg-blue-50 transition-colors"
          >
            <Camera className={`${isLarge ? 'w-5 h-5' : 'w-4 h-4'}`} />
          </button>
        </div>

        {/* Primary Blue Search Button */}
        <button
          type="button"
          onClick={() => {
            setShowSuggestions(false);
            onSearch();
          }}
          className={`shrink-0 font-medium text-white transition-all duration-200 active:scale-95 flex items-center justify-center rounded-full bg-blue-600 hover:bg-blue-700 shadow-md hover:shadow-blue-500/25 ${
            isLarge 
              ? 'px-6 py-2.5 text-base ml-1 sm:ml-2 font-semibold' 
              : 'px-4 py-1.5 text-sm ml-1 font-medium'
          }`}
        >
          <span>搜索</span>
        </button>
      </div>

      {/* Real-time Suggestions Dropdown */}
      {showSuggestions && isFocused && (
        <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200/90 py-2.5 z-40 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="px-4 py-1 flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>智能语义联想与实体消歧</span>
            <span className="text-[11px] text-blue-600">灵犀语义中枢</span>
          </div>

          <div className="mt-1 divide-y divide-slate-100">
            {suggestions.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelectSuggestion(item.text)}
                className="w-full text-left px-4 py-2.5 hover:bg-blue-50/70 transition-colors flex items-center justify-between group"
              >
                <div className="flex items-center gap-2.5 min-w-0 pr-3">
                  {item.type === 'ai' ? (
                    <Sparkles className="w-4 h-4 text-blue-500 shrink-0" />
                  ) : item.type === 'disambiguation' ? (
                    <Apple className="w-4 h-4 text-emerald-500 shrink-0" />
                  ) : item.type === 'industry' ? (
                    <Building2 className="w-4 h-4 text-purple-500 shrink-0" />
                  ) : (
                    <TrendingUp className="w-4 h-4 text-slate-400 group-hover:text-blue-500 shrink-0" />
                  )}
                  <span className="text-sm text-slate-800 group-hover:text-blue-600 truncate font-normal">
                    {item.text}
                  </span>
                </div>
                
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[11px] text-slate-500 font-medium px-2 py-0.5 rounded-md bg-slate-100 group-hover:bg-blue-100/60 group-hover:text-blue-700 transition-colors">
                    {item.tag}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-all -translate-x-1 group-hover:translate-x-0" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
