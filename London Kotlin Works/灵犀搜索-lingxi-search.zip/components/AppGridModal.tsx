'use client';

import React from 'react';
import { 
  FileText, 
  Cloud, 
  Map, 
  Languages, 
  BookMarked, 
  GraduationCap, 
  Cpu, 
  HeartPulse, 
  Code,
  X,
  ExternalLink
} from 'lucide-react';

interface AppGridModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectApp: (appName: string) => void;
}

export default function AppGridModal({
  isOpen,
  onClose,
  onSelectApp,
}: AppGridModalProps) {
  if (!isOpen) return null;

  const apps = [
    { name: '灵犀文库', desc: '10亿专业研报与公文模版', icon: <FileText className="w-6 h-6 text-blue-600" />, bg: 'bg-blue-50' },
    { name: '灵犀网盘', desc: '全速秒传与跨端私有云', icon: <Cloud className="w-6 h-6 text-sky-600" />, bg: 'bg-sky-50' },
    { name: '灵犀地图', desc: '车道级高精导航与路况', icon: <Map className="w-6 h-6 text-emerald-600" />, bg: 'bg-emerald-50' },
    { name: '灵犀翻译', desc: '多语言神经同传与专业术语', icon: <Languages className="w-6 h-6 text-purple-600" />, bg: 'bg-purple-50' },
    { name: '灵犀百科', desc: '国家级实体权威知识库', icon: <BookMarked className="w-6 h-6 text-amber-600" />, bg: 'bg-amber-50' },
    { name: '灵犀学术', desc: '全球核心科技期刊枢纽', icon: <GraduationCap className="w-6 h-6 text-teal-600" />, bg: 'bg-teal-50' },
    { name: '灵犀智脑', desc: '万亿参数大模型开发平台', icon: <Cpu className="w-6 h-6 text-indigo-600" />, bg: 'bg-indigo-50' },
    { name: '灵犀健康', desc: '三甲医院权威医学图谱', icon: <HeartPulse className="w-6 h-6 text-rose-600" />, bg: 'bg-rose-50' },
    { name: '灵犀代码', desc: '全栈开源语义代码检索', icon: <Code className="w-6 h-6 text-slate-700" />, bg: 'bg-slate-100' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 text-slate-800 relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-5">
          <h3 className="text-base font-bold text-slate-900">
            灵犀数字生态服务矩阵
          </h3>
          <p className="text-xs text-slate-500">
            一站式打通中文互联网全场景知识、办公、出行与科研能力
          </p>
        </div>

        {/* 3x3 App Matrix */}
        <div className="grid grid-cols-3 gap-3">
          {apps.map((app, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                onSelectApp(app.name);
                onClose();
              }}
              className="p-3.5 rounded-2xl border border-slate-200/80 hover:border-blue-400 hover:shadow-md transition-all text-left flex flex-col items-center sm:items-start group bg-white hover:bg-blue-50/20"
            >
              <div className={`w-11 h-11 rounded-xl ${app.bg} flex items-center justify-center mb-2.5 transition-transform group-hover:scale-105`}>
                {app.icon}
              </div>
              <div className="font-bold text-xs text-slate-900 group-hover:text-blue-600 transition-colors">
                {app.name}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                {app.desc}
              </div>
            </button>
          ))}
        </div>

        {/* Open Platform Footer */}
        <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>开发者合作 · 灵犀开放平台</span>
          <button
            onClick={() => {
              alert('已开启灵犀开放平台开发者控制台');
              onClose();
            }}
            className="text-blue-600 font-semibold hover:underline flex items-center gap-1"
          >
            <span>申请API接入</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>

      </div>
    </div>
  );
}
