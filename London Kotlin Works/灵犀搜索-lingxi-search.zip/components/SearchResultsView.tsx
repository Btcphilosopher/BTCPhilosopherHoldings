'use client';

import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  HelpCircle, 
  AlertCircle, 
  Table as TableIcon, 
  ChevronDown, 
  ChevronUp, 
  Send, 
  Share2, 
  Bookmark, 
  ExternalLink, 
  RotateCcw, 
  Filter, 
  SlidersHorizontal,
  Flame,
  ArrowRight,
  ShieldCheck,
  Building2,
  FileText
} from 'lucide-react';
import { 
  SearchTab, 
  AIAnswerData, 
  WebSearchResult, 
  KnowledgeEntity, 
  SearchFilters 
} from '@/lib/types';
import SearchBox from './SearchBox';
import KnowledgePanel from './KnowledgePanel';
import LocalServicesCard from './LocalServicesCard';
import ShoppingCompareCard from './ShoppingCompareCard';
import AcademicResultsCard from './AcademicResultsCard';
import { 
  CANONICAL_EV_ANSWER, 
  DEFAULT_WEB_RESULTS, 
  KNOWLEDGE_ENTITIES,
  TRENDING_SEARCHES,
  NEWS_ITEMS
} from '@/lib/mock-data';

interface SearchResultsViewProps {
  query: string;
  onQueryChange: (q: string) => void;
  onSearch: (q?: string) => void;
  activeTab: SearchTab;
  onTabChange: (tab: SearchTab) => void;
  aiAnswer: AIAnswerData;
  isLoadingAI: boolean;
  onVoiceClick: () => void;
  onCameraClick: () => void;
  onTriggerDeepResearch: (q?: string) => void;
  onGoHome: () => void;
}

export default function SearchResultsView({
  query,
  onQueryChange,
  onSearch,
  activeTab,
  onTabChange,
  aiAnswer,
  isLoadingAI,
  onVoiceClick,
  onCameraClick,
  onTriggerDeepResearch,
  onGoHome,
}: SearchResultsViewProps) {
  // Reasoning chain fold state
  const [showReasoning, setShowReasoning] = useState(false);
  
  // Follow-up conversation state
  const [followUpQuery, setFollowUpQuery] = useState('');
  const [followUpHistory, setFollowUpHistory] = useState<{ role: 'user' | 'ai'; text: string }[]>([]);
  const [isAnsweringFollowUp, setIsAnsweringFollowUp] = useState(false);

  // Filters state
  const [filters, setFilters] = useState<SearchFilters>({
    timeRange: 'all',
    sourceType: 'all',
    region: 'all',
    language: 'all',
    sortBy: 'authority',
  });
  const [showFiltersBar, setShowFiltersBar] = useState(false);

  // Find matched knowledge graph entity
  const getMatchedEntity = (): KnowledgeEntity | null => {
    const q = query.trim();
    if (q.includes('比亚迪') || q.includes('BYD')) return KNOWLEDGE_ENTITIES['比亚迪'];
    if (q.includes('苹果')) return KNOWLEDGE_ENTITIES['苹果'];
    if (q.includes('新能源') || q.includes('汽车') || q.includes('电动车')) return KNOWLEDGE_ENTITIES['新能源汽车'];
    return KNOWLEDGE_ENTITIES['新能源汽车'];
  };

  const matchedEntity = getMatchedEntity();

  // Search tabs configuration
  const searchTabs: { id: SearchTab; label: string }[] = [
    { id: 'web', label: '全部网页' },
    { id: 'ai', label: 'AI智能回答' },
    { id: 'deep_research', label: '深度研究报告' },
    { id: 'news', label: '权威新闻' },
    { id: 'academic', label: '学术与专利' },
    { id: 'maps', label: '地图生活' },
    { id: 'shopping', label: '智能比价' },
    { id: 'image', label: '高清图片' },
    { id: 'video', label: '精选视频' },
  ];

  // Handle follow up submit
  const handleFollowUpSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!followUpQuery.trim() || isAnsweringFollowUp) return;

    const userQ = followUpQuery.trim();
    setFollowUpHistory(prev => [...prev, { role: 'user', text: userQ }]);
    setFollowUpQuery('');
    setIsAnsweringFollowUp(true);

    setTimeout(() => {
      let reply = '';
      if (userQ.includes('国家') || userQ.includes('市场')) {
        reply = '根据2026-2027年海关报关与海外上牌数据，中国新能源汽车的核心出口增量市场呈现清晰的三梯队格局：【第一梯队·规模重镇】：泰国、印度尼西亚、澳大利亚、比利时；【第二梯队·高增长蓝海】：巴西、阿联酋、墨西哥、沙特阿拉伯；【第三梯队·高端渗透】：德国、英国、挪威。其中东盟自贸区凭借零关税协议和右舵本土化工厂，增速高达68%。';
      } else if (userQ.includes('关税') || userQ.includes('欧盟')) {
        reply = '针对欧盟及部分地区关税壁垒，中国骨干车企已采取成熟反制与规避方案：主要通过“海外建厂（CKD散件散装模式）+设立欧洲研发中心”实现本土化生产。以比亚迪匈牙利塞格德工厂为例，首期20万辆整车达产后将完全符合欧盟原产地规则，直接免除额外关税。';
      } else {
        reply = `关于“${userQ}”：灵犀AI认知引擎已结合相关部委政策与行业最新公报进行研判。头部自主车企正从以往的“贸易输出”全面升级为“品牌、制造、充电生态与售后”一体化出海，综合技术溢价与供应链韧性持续领先。`;
      }

      setFollowUpHistory(prev => [...prev, { role: 'ai', text: reply }]);
      setIsAnsweringFollowUp(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16">
      
      {/* Pinned Top Search Navigation Bar */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-col md:flex-row items-center justify-between gap-3">
          
          {/* Logo + Compact Search Input */}
          <div className="w-full md:w-auto flex-1 flex items-center gap-4 max-w-4xl">
            <button 
              onClick={onGoHome}
              className="flex items-center gap-2 group shrink-0"
            >
              <div className="w-8 h-8 rounded-full bg-linear-to-tr from-blue-700 to-cyan-400 p-0.5 flex items-center justify-center shadow-xs">
                <span className="text-white text-xs font-bold">灵</span>
              </div>
              <span className="hidden sm:inline font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                灵犀搜索
              </span>
            </button>

            <div className="flex-1">
              <SearchBox
                query={query}
                onChange={onQueryChange}
                onSearch={onSearch}
                onVoiceClick={onVoiceClick}
                onCameraClick={onCameraClick}
                size="compact"
              />
            </div>
          </div>

          {/* Right Tools: Filter Toggle & Deep Research Quick Trigger */}
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => setShowFiltersBar(!showFiltersBar)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border flex items-center gap-1.5 transition-colors ${
                showFiltersBar ? 'bg-blue-50 text-blue-600 border-blue-300' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>筛选过滤</span>
              <ChevronDown className={`w-3 h-3 transition-transform ${showFiltersBar ? 'rotate-180' : ''}`} />
            </button>

            <button
              onClick={() => onTriggerDeepResearch(query)}
              className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-linear-to-r from-blue-600 to-indigo-600 text-white shadow-xs hover:from-blue-700 hover:to-indigo-700 transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
              <span>启动深度研究</span>
            </button>
          </div>
        </div>

        {/* Tab Switcher Horizontal Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-1 overflow-x-auto scrollbar-none py-1 border-t border-slate-100">
          {searchTabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`relative px-3.5 py-2 text-xs font-medium whitespace-nowrap transition-all rounded-md ${
                  isActive
                    ? 'text-blue-600 font-bold bg-blue-50/70'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
                }`}
              >
                {tab.label}
                {isActive && (
                  <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-blue-600 rounded-full" />
                )}
              </button>
            );
          })}
        </div>

        {/* Expandable Advanced Filters Bar */}
        {showFiltersBar && (
          <div className="bg-slate-50 border-t border-slate-200 px-4 sm:px-6 py-2.5 max-w-7xl mx-auto animate-in slide-in-from-top-1 text-xs">
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
              
              {/* Time Range */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-medium">时间:</span>
                {[
                  { id: 'all', label: '全部时间' },
                  { id: '24h', label: '过去24小时' },
                  { id: '1w', label: '过去一周' },
                  { id: '1m', label: '过去一个月' },
                  { id: '1y', label: '过去一年' },
                ].map(t => (
                  <button
                    key={t.id}
                    onClick={() => setFilters({ ...filters, timeRange: t.id as any })}
                    className={`px-2 py-0.5 rounded-md transition-colors ${
                      filters.timeRange === t.id ? 'bg-blue-600 text-white font-medium' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Source Type */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-medium">信源:</span>
                {[
                  { id: 'all', label: '全部' },
                  { id: 'gov', label: '政府公开' },
                  { id: 'news', label: '权威官媒' },
                  { id: 'academic', label: '学术核心' },
                ].map(s => (
                  <button
                    key={s.id}
                    onClick={() => setFilters({ ...filters, sourceType: s.id as any })}
                    className={`px-2 py-0.5 rounded-md transition-colors ${
                      filters.sourceType === s.id ? 'bg-blue-600 text-white font-medium' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              {/* Language */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-medium">语言:</span>
                {[
                  { id: 'all', label: '全部' },
                  { id: 'zh_hans', label: '简体中文' },
                  { id: 'zh_hant', label: '繁体中文' },
                ].map(l => (
                  <button
                    key={l.id}
                    onClick={() => setFilters({ ...filters, language: l.id as any })}
                    className={`px-2 py-0.5 rounded-md transition-colors ${
                      filters.language === l.id ? 'bg-blue-600 text-white font-medium' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>

            </div>
          </div>
        )}

      </div>

      {/* Main Content Area: 2 Columns */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left / Main Column (7 or 8 columns) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* 1. AI Synthesized Answer Card */}
            {(activeTab === 'web' || activeTab === 'ai') && (
              <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-6 text-slate-800 relative">
                
                {/* Header banner */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-linear-to-tr from-blue-600 to-cyan-500 text-white flex items-center justify-center shadow-xs">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900">
                        灵犀AI全网深度研判
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        {aiAnswer.lastUpdated}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-200">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{aiAnswer.confidenceLabel}</span>
                    </span>
                  </div>
                </div>

                {/* Core Conclusion */}
                <div className="mt-4 text-sm leading-relaxed text-slate-800 font-normal">
                  <p className="whitespace-pre-line">
                    {aiAnswer.summary}
                  </p>
                </div>

                {/* Structured Data Table (Mandatory for EV comparison and rich queries) */}
                {aiAnswer.dataTable && (
                  <div className="mt-5 border border-slate-200 rounded-xl overflow-hidden bg-slate-50/50">
                    {aiAnswer.dataTable.caption && (
                      <div className="px-4 py-2 bg-slate-100 text-xs font-bold text-slate-700 border-b border-slate-200 flex items-center gap-1.5">
                        <TableIcon className="w-3.5 h-3.5 text-blue-600" />
                        <span>{aiAnswer.dataTable.caption}</span>
                      </div>
                    )}
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-100/80 text-slate-600 font-semibold border-b border-slate-200">
                          <tr>
                            {aiAnswer.dataTable.headers.map((h, i) => (
                              <th key={i} className="p-3 whitespace-nowrap">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 bg-white text-slate-700">
                          {aiAnswer.dataTable.rows.map((row, rIdx) => (
                            <tr key={rIdx} className="hover:bg-blue-50/40 transition-colors">
                              {row.map((cell, cIdx) => (
                                <td key={cIdx} className={`p-3 ${cIdx === 0 ? 'font-bold text-slate-900' : ''}`}>
                                  {cell}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Facts vs. Inferences vs. Disagreements */}
                <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  
                  {/* Verified Facts */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
                    <div className="font-bold text-emerald-800 mb-2 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>已核验客观事实 ({aiAnswer.verifiedFacts.length})</span>
                    </div>
                    <ul className="space-y-1.5 text-slate-600 pl-4 list-disc">
                      {aiAnswer.verifiedFacts.map((fact, idx) => (
                        <li key={idx} className="leading-snug">{fact}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Logical Inferences */}
                  {aiAnswer.inferences && (
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="font-bold text-blue-800 mb-2 flex items-center gap-1.5">
                        <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
                        <span>基于现有数据的合理推论</span>
                      </div>
                      <ul className="space-y-1.5 text-slate-600 pl-4 list-disc">
                        {aiAnswer.inferences.map((inf, idx) => (
                          <li key={idx} className="leading-snug">{inf}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                </div>

                {/* Supporting Source Citations with Badges */}
                <div className="mt-5 pt-4 border-t border-slate-100">
                  <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-blue-600" />
                    <span>本回答引用的权威信源（点击直达原始出处 · 杜绝臆造）：</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {aiAnswer.sources.map((src) => (
                      <a
                        key={src.id}
                        href={src.url}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2.5 rounded-xl border border-slate-200/70 hover:border-blue-400 hover:bg-blue-50/30 transition-all flex items-start justify-between gap-2 group text-xs"
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-700 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                              {src.id}
                            </span>
                            <span className="font-semibold text-slate-900 truncate group-hover:text-blue-600">
                              {src.source}
                            </span>
                            {src.badge && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded-xs bg-slate-100 text-slate-500 font-medium shrink-0">
                                {src.badge}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {src.title}
                          </div>
                        </div>

                        <ExternalLink className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-600 shrink-0 mt-1" />
                      </a>
                    ))}
                  </div>
                </div>

                {/* Expandable Reasoning Process */}
                {aiAnswer.reasoningSteps && (
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setShowReasoning(!showReasoning)}
                      className="text-xs text-slate-500 hover:text-slate-800 font-medium flex items-center gap-1 transition-colors"
                    >
                      <span>{showReasoning ? '收起' : '查看完整思考与事实核验链'}</span>
                      {showReasoning ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    {showReasoning && (
                      <div className="mt-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-2 animate-in fade-in">
                        {aiAnswer.reasoningSteps.map((step, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0 mt-1.5" />
                            <span>{step}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Multi-turn Follow-up Q&A Module */}
                <div className="mt-6 pt-5 border-t border-slate-200/80">
                  <div className="text-xs font-bold text-slate-700 mb-3 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>针对此主题继续追问（保持上下文记忆）：</span>
                  </div>

                  {/* Previous conversation turns */}
                  {followUpHistory.length > 0 && (
                    <div className="space-y-3 mb-4">
                      {followUpHistory.map((item, idx) => (
                        <div
                          key={idx}
                          className={`p-3 rounded-xl text-xs leading-relaxed ${
                            item.role === 'user'
                              ? 'bg-blue-50 text-blue-900 border border-blue-200/70 ml-6'
                              : 'bg-slate-50 text-slate-800 border border-slate-200 mr-6'
                          }`}
                        >
                          <div className="font-bold text-[10px] text-slate-400 mb-1">
                            {item.role === 'user' ? '您的追问' : '灵犀AI 回答'}
                          </div>
                          <div>{item.text}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Follow-up input form */}
                  <form onSubmit={handleFollowUpSubmit} className="relative flex items-center">
                    <input
                      type="text"
                      value={followUpQuery}
                      onChange={(e) => setFollowUpQuery(e.target.value)}
                      placeholder="追问：例如“主要出口到哪些国家？”或“如何规避欧盟关税？”"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-4 py-2.5 pr-24 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all"
                    />
                    <button
                      type="submit"
                      disabled={!followUpQuery.trim() || isAnsweringFollowUp}
                      className="absolute right-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1 transition-all"
                    >
                      <span>{isAnsweringFollowUp ? '思考中...' : '提问'}</span>
                      <Send className="w-3 h-3" />
                    </button>
                  </form>
                </div>

              </div>
            )}

            {/* 2. Specialized Module: Local Services (if tab is maps or query matches food/location) */}
            {(activeTab === 'maps' || query.includes('上海') || query.includes('餐厅') || query.includes('药店')) && (
              <LocalServicesCard query={query} />
            )}

            {/* 3. Specialized Module: Shopping Comparison (if tab is shopping or query matches TV/product) */}
            {(activeTab === 'shopping' || query.includes('电视') || query.includes('键盘') || query.includes('羽绒服')) && (
              <ShoppingCompareCard query={query} />
            )}

            {/* 4. Specialized Module: Academic Papers (if tab is academic or paper query) */}
            {(activeTab === 'academic' || query.includes('学术') || query.includes('论文') || query.includes('专利')) && (
              <AcademicResultsCard query={query} />
            )}

            {/* 5. Specialized Module: News Timeline (if tab is news) */}
            {activeTab === 'news' && (
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs mb-6">
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                    <span>大事件时间线还原 (事件发生 → 首次报道 → 官方回应 → 最新状态)</span>
                  </h3>
                  <span className="text-[11px] text-slate-400">权威融媒体交叉验证</span>
                </div>

                <div className="space-y-4 relative pl-4 border-l-2 border-slate-200">
                  {NEWS_ITEMS.map((n, i) => (
                    <div key={n.id} className="relative text-xs">
                      <div className="absolute -left-[1.4rem] top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-4 ring-white" />
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-sm">
                          {n.stage}
                        </span>
                        <span className="text-slate-400 text-[11px]">{n.publishedAt}</span>
                        <span className="text-slate-500 font-medium">[{n.source}]</span>
                      </div>
                      <h4 className="font-bold text-slate-900 text-sm hover:text-blue-600 cursor-pointer">
                        {n.title}
                      </h4>
                      <p className="text-slate-600 mt-1 leading-relaxed">
                        {n.summary}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 6. Traditional High-Speed Web Search Results List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500 px-1">
                <span>找到约 4,820,000 条相关结果 (耗时 0.08 秒 · 全网权威索引)</span>
                <span className="text-[11px] text-slate-400">已开启垃圾站群与营销软文过滤</span>
              </div>

              {DEFAULT_WEB_RESULTS.map((res) => (
                <div 
                  key={res.id} 
                  className="bg-white rounded-2xl border border-slate-200/80 p-5 hover:shadow-md hover:border-blue-300 transition-all group"
                >
                  {/* Display URL & Badges */}
                  <div className="flex items-center gap-2 mb-1 text-xs">
                    <span className="text-slate-500 font-mono text-[11px] truncate max-w-md">
                      {res.displayUrl}
                    </span>
                    {res.isOfficial && (
                      <span className="px-1.5 py-0.2 rounded-xs bg-blue-50 text-blue-700 font-semibold text-[10px] border border-blue-200 shrink-0">
                        官方认证
                      </span>
                    )}
                    {res.sourceType === 'gov' && (
                      <span className="px-1.5 py-0.2 rounded-xs bg-rose-50 text-rose-700 font-semibold text-[10px] border border-rose-200 shrink-0">
                        国家部委
                      </span>
                    )}
                  </div>

                  {/* Clickable Title */}
                  <h4 className="text-base font-bold text-blue-700 group-hover:underline cursor-pointer leading-snug">
                    {res.title}
                  </h4>

                  {/* Snippet */}
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    <span className="text-slate-400 mr-2 font-medium">{res.date} —</span>
                    {res.snippet}
                  </p>

                  {/* Source and Tags */}
                  <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <span className="font-medium text-slate-600">{res.source}</span>
                      {res.tags?.map((t, idx) => (
                        <span key={idx} className="text-[10px] text-slate-400 px-1.5 py-0.5 rounded-sm bg-slate-50">
                          {t}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => alert(`已为该网页生成快照与事实摘要`)}
                        className="text-[11px] text-slate-400 hover:text-blue-600 transition-colors"
                      >
                        网页快照
                      </button>
                      <button 
                        onClick={() => alert(`已将「${res.title}」存入个人书签`)}
                        className="text-[11px] text-slate-400 hover:text-blue-600 transition-colors"
                      >
                        收藏
                      </button>
                    </div>
                  </div>

                </div>
              ))}
            </div>

            {/* People Also Ask (大家还在搜) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 mt-6">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                大家还在搜 (相关联想探索)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {aiAnswer.relatedQueries.map((rq, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      onQueryChange(rq);
                      onSearch(rq);
                    }}
                    className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50/80 hover:text-blue-600 text-slate-700 text-left transition-colors flex items-center justify-between border border-slate-200/60 group"
                  >
                    <span className="truncate pr-2">{rq}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-600 shrink-0" />
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right Sidebar Column (4 columns): Chinese Knowledge Graph */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Knowledge Graph Entity Card */}
            {matchedEntity && (
              <KnowledgePanel
                entity={matchedEntity}
                onExploreRelated={(name) => {
                  onQueryChange(name);
                  onSearch(name);
                }}
                onTriggerDeepResearch={onTriggerDeepResearch}
              />
            )}

            {/* Trending Hot List in Sidebar */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
              <div className="flex items-center justify-between mb-3.5">
                <div className="flex items-center gap-1.5 font-bold text-sm text-slate-900">
                  <Flame className="w-4 h-4 text-rose-500" />
                  <span>全网实时热搜榜</span>
                </div>
                <span className="text-[11px] text-slate-400">实时热度更新</span>
              </div>

              <div className="space-y-2 text-xs divide-y divide-slate-100">
                {TRENDING_SEARCHES.slice(0, 6).map((item, idx) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onQueryChange(item.query);
                      onSearch(item.query);
                    }}
                    className="w-full text-left pt-2 pb-1 hover:text-blue-600 transition-colors flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-2 truncate pr-2">
                      <span className={`w-4 font-mono font-bold text-xs ${
                        idx < 3 ? 'text-rose-600' : 'text-slate-400'
                      }`}>
                        {idx + 1}
                      </span>
                      <span className="truncate text-slate-700 group-hover:text-blue-600">
                        {item.query}
                      </span>
                    </div>

                    <span className="text-[10px] text-slate-400 font-mono shrink-0">
                      {item.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Deep Research Feature CTA Sidebar Card */}
            <div className="p-5 rounded-2xl bg-linear-to-br from-slate-900 via-blue-950 to-indigo-950 text-white shadow-md relative overflow-hidden">
              <div className="relative z-10">
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-sm bg-blue-500/30 text-blue-200 border border-blue-400/30">
                  专业研究模式
                </span>
                <h4 className="text-base font-bold mt-2">
                  灵犀深度研报智能体
                </h4>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  多源交叉检索 · 自动事实核验 · 自动生成万字级决策分析报告与对比矩阵。
                </p>

                <button
                  type="button"
                  onClick={() => onTriggerDeepResearch(query)}
                  className="mt-4 w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
                  <span>针对当前话题发起研究</span>
                </button>
              </div>
            </div>

          </div>

        </div>
      </div>

    </div>
  );
}
