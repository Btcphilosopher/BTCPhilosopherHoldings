'use client';

import React from 'react';
import { 
  Clock, 
  Trash2, 
  X, 
  ArrowRight, 
  Bookmark, 
  Search,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  history: string[];
  onSelectQuery: (q: string) => void;
  onClearHistory: () => void;
}

export default function HistoryDrawer({
  isOpen,
  onClose,
  history,
  onSelectQuery,
  onClearHistory,
}: HistoryDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white h-full shadow-2xl p-6 flex flex-col text-slate-800 animate-in slide-in-from-right duration-250">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <h3 className="text-base font-bold text-slate-900">
              检索历史与知识资产
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4">
          
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>最近查询历史 ({history.length})</span>
            {history.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="text-rose-600 hover:underline flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>清空</span>
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              <Clock className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <span>暂无搜索记录或当前处于无痕浏览状态</span>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {history.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    onSelectQuery(item);
                    onClose();
                  }}
                  className="py-3 px-2 hover:bg-blue-50/70 rounded-xl cursor-pointer transition-colors flex items-center justify-between group text-xs"
                >
                  <div className="flex items-center gap-2.5 truncate pr-2">
                    <Search className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 shrink-0" />
                    <span className="text-slate-800 group-hover:text-blue-600 truncate font-normal">
                      {item}
                    </span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                </div>
              ))}
            </div>
          )}

          {/* Quick Curated Bookmarks */}
          <div className="pt-4 border-t border-slate-100">
            <div className="text-xs text-slate-400 font-medium mb-2.5 flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5 text-amber-500" />
              <span>灵犀推荐精选专题</span>
            </div>
            <div className="space-y-1.5 text-xs">
              {[
                '中国新能源汽车2027年全球出口竞争力分析',
                '海关总署最新进出口机动车辆权威公报',
                '中国超导与量子科技关键路线图解读'
              ].map((rec, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    onSelectQuery(rec);
                    onClose();
                  }}
                  className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors flex items-center justify-between"
                >
                  <span className="truncate pr-2">{rec}</span>
                  <ExternalLink className="w-3 h-3 text-slate-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>端侧数据加密存储</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-900 text-white font-medium text-xs hover:bg-slate-800 transition-colors"
          >
            完成
          </button>
        </div>

      </div>
    </div>
  );
}
