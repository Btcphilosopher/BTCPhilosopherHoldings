'use client';

import React, { useState } from 'react';
import { 
  MapPin, 
  Star, 
  Navigation, 
  Phone, 
  Clock, 
  Compass, 
  ExternalLink,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { LocalPlace } from '@/lib/types';
import { LOCAL_PLACES } from '@/lib/mock-data';

interface LocalServicesCardProps {
  places?: LocalPlace[];
  query?: string;
}

export default function LocalServicesCard({
  places = LOCAL_PLACES,
  query = '上海粤菜餐厅'
}: LocalServicesCardProps) {
  const [selectedPlaceId, setSelectedPlaceId] = useState<string>(places[0]?.id || '');
  const [navAlert, setNavAlert] = useState<string | null>(null);

  const selectedPlace = places.find(p => p.id === selectedPlaceId) || places[0];

  const handleStartNavigation = (name: string) => {
    setNavAlert(`已唤起灵犀高精地图，正规划前往「${name}」最优路线（避开拥堵）`);
    setTimeout(() => setNavAlert(null), 4000);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden mb-6">
      
      {/* Top Header */}
      <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              灵犀地图 · 本地生活与位置服务
            </h3>
            <p className="text-[11px] text-slate-500">
              综合大众点评、黑珍珠餐厅指南与高精地理网格数据
            </p>
          </div>
        </div>

        <span className="text-xs text-blue-600 font-medium hover:underline cursor-pointer flex items-center gap-0.5">
          <span>全屏地图</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </span>
      </div>

      {navAlert && (
        <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-2 text-xs text-emerald-800 flex items-center gap-2 animate-in fade-in">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{navAlert}</span>
        </div>
      )}

      {/* Main Container: Left Places List & Right Map Simulation */}
      <div className="grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-slate-200">
        
        {/* Left: Place Cards List */}
        <div className="md:col-span-7 divide-y divide-slate-100 max-h-[460px] overflow-y-auto">
          {places.map((place) => {
            const isSelected = place.id === selectedPlace.id;
            return (
              <div
                key={place.id}
                onClick={() => setSelectedPlaceId(place.id)}
                className={`p-4 transition-colors cursor-pointer ${
                  isSelected ? 'bg-blue-50/50' : 'hover:bg-slate-50'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 truncate">
                        {place.name}
                      </h4>
                      {isSelected && (
                        <span className="px-1.5 py-0.2 rounded-xs bg-blue-600 text-white text-[10px] font-medium shrink-0">
                          当前选中
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2.5 mt-1 text-xs">
                      <div className="flex items-center gap-1 text-amber-500 font-bold">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span>{place.rating.toFixed(1)}</span>
                      </div>
                      <span className="text-slate-400">·</span>
                      <span className="text-slate-600">{place.reviewsCount}条精选评价</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-slate-900 font-semibold">{place.pricePerPerson}</span>
                    </div>

                    <div className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{place.address}</span>
                    </div>

                    <div className="text-[11px] text-emerald-600 mt-0.5 font-medium">
                      {place.distance}
                    </div>

                    {/* Features Tags */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {place.features.map((feat, idx) => (
                        <span 
                          key={idx}
                          className="px-2 py-0.5 rounded-md bg-slate-100 text-[11px] text-slate-600 font-normal"
                        >
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-col gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStartNavigation(place.name);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium flex items-center gap-1 shadow-xs transition-colors"
                    >
                      <Navigation className="w-3 h-3" />
                      <span>导航</span>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        alert(`已为您拨打电话：${place.phone}`);
                      }}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-medium flex items-center gap-1 transition-colors"
                    >
                      <Phone className="w-3 h-3 text-slate-500" />
                      <span>订座</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Map Vector Visual View */}
        <div className="md:col-span-5 bg-slate-100 relative min-h-[300px] flex flex-col items-center justify-center p-4 overflow-hidden">
          
          {/* Subtle stylized map grid pattern */}
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px]" />
          
          {/* Map roads simulation graphic */}
          <svg className="absolute inset-0 w-full h-full stroke-slate-300" strokeWidth="2" fill="none">
            <line x1="0" y1="40%" x2="100%" y2="45%" strokeWidth="4" stroke="#cbd5e1" />
            <line x1="30%" y1="0" x2="40%" y2="100%" strokeWidth="5" stroke="#cbd5e1" />
            <line x1="10%" y1="90%" x2="90%" y2="20%" strokeWidth="3" stroke="#e2e8f0" />
            <path d="M 50 150 Q 150 80 280 200 T 400 120" stroke="#93c5fd" strokeWidth="3" strokeDasharray="4 4" />
          </svg>

          {/* Location Pin Marker for Selected Place */}
          <div className="relative z-10 flex flex-col items-center animate-bounce duration-1000">
            <div className="px-3 py-1 rounded-full bg-slate-900 text-white text-[11px] font-semibold shadow-xl border border-white/40 mb-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>{selectedPlace.name.split('(')[0]}</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg ring-4 ring-blue-300/60">
              <MapPin className="w-4 h-4 fill-white" />
            </div>
          </div>

          {/* Compass & Scale overlay */}
          <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs px-2 py-1 rounded-md text-[10px] text-slate-500 font-mono border border-slate-200">
            比例尺 1:5000 · 北 ↗
          </div>

          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-md text-[11px] text-slate-700 font-medium border border-slate-200 flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>实时路况：畅通</span>
          </div>
        </div>

      </div>

    </div>
  );
}
