'use client';

import React, { useState } from 'react';
import { 
  CloudSun, 
  Wind, 
  Droplets, 
  Sun, 
  X, 
  MapPin, 
  CheckCircle2, 
  ChevronRight,
  ShieldAlert
} from 'lucide-react';

interface WeatherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function WeatherModal({ isOpen, onClose }: WeatherModalProps) {
  const [selectedCity, setSelectedCity] = useState('北京');

  const citiesData: Record<string, {
    temp: string;
    weather: string;
    range: string;
    aqi: number;
    aqiLevel: string;
    humidity: string;
    wind: string;
    forecast: { day: string; weather: string; temp: string }[];
  }> = {
    '北京': {
      temp: '12°C',
      weather: '晴朗无云',
      range: '6°C ~ 18°C',
      aqi: 32,
      aqiLevel: '优',
      humidity: '42%',
      wind: '北风 2级 · 7km/h',
      forecast: [
        { day: '今天', weather: '晴', temp: '18°C / 6°C' },
        { day: '明天', weather: '晴间多云', temp: '19°C / 8°C' },
        { day: '周三', weather: '多云', temp: '17°C / 7°C' },
        { day: '周四', weather: '晴', temp: '20°C / 9°C' },
        { day: '周五', weather: '微风晴朗', temp: '21°C / 10°C' },
      ]
    },
    '上海': {
      temp: '19°C',
      weather: '多云舒适',
      range: '14°C ~ 23°C',
      aqi: 45,
      aqiLevel: '优',
      humidity: '65%',
      wind: '东风 3级 · 12km/h',
      forecast: [
        { day: '今天', weather: '多云', temp: '23°C / 14°C' },
        { day: '明天', weather: '晴', temp: '24°C / 15°C' },
        { day: '周三', weather: '局部阵雨', temp: '21°C / 16°C' },
        { day: '周四', weather: '阴转晴', temp: '22°C / 15°C' },
        { day: '周五', weather: '晴朗', temp: '23°C / 16°C' },
      ]
    },
    '深圳': {
      temp: '26°C',
      weather: '晴好温润',
      range: '22°C ~ 29°C',
      aqi: 28,
      aqiLevel: '优',
      humidity: '72%',
      wind: '微风 · 6km/h',
      forecast: [
        { day: '今天', weather: '晴', temp: '29°C / 22°C' },
        { day: '明天', weather: '晴间多云', temp: '30°C / 23°C' },
        { day: '周三', weather: '晴', temp: '29°C / 22°C' },
        { day: '周四', weather: '多云', temp: '28°C / 23°C' },
        { day: '周五', weather: '雷阵雨', temp: '27°C / 21°C' },
      ]
    }
  };

  const current = citiesData[selectedCity] || citiesData['北京'];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 text-slate-800 relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* City selector tabs */}
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="w-4 h-4 text-blue-600" />
          <div className="flex gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            {Object.keys(citiesData).map(city => (
              <button
                key={city}
                onClick={() => setSelectedCity(city)}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  selectedCity === city 
                    ? 'bg-white text-blue-600 shadow-2xs font-bold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {city}
              </button>
            ))}
          </div>
        </div>

        {/* Current Weather Card */}
        <div className="p-5 rounded-2xl bg-linear-to-tr from-blue-600 via-sky-500 to-cyan-400 text-white shadow-lg relative overflow-hidden mb-4">
          <div className="relative z-10 flex items-center justify-between">
            <div>
              <div className="text-4xl font-extrabold tracking-tight tabular-nums">
                {current.temp}
              </div>
              <div className="text-sm font-semibold mt-1">
                {current.weather} · {current.range}
              </div>
              <div className="text-xs text-white/80 mt-2 flex items-center gap-2">
                <span>空气质量指数 (AQI): {current.aqi}</span>
                <span className="px-1.5 py-0.2 rounded-sm bg-white/25 text-white font-bold text-[10px]">
                  {current.aqiLevel}
                </span>
              </div>
            </div>

            <CloudSun className="w-16 h-16 text-amber-300 drop-shadow-md" />
          </div>

          <div className="relative z-10 mt-4 pt-3 border-t border-white/20 grid grid-cols-2 gap-2 text-xs text-white/90">
            <div className="flex items-center gap-1.5">
              <Droplets className="w-3.5 h-3.5" />
              <span>湿度: {current.humidity}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Wind className="w-3.5 h-3.5" />
              <span>{current.wind}</span>
            </div>
          </div>
        </div>

        {/* 5-Day Forecast */}
        <div className="space-y-2">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            中央气象台权威预报
          </div>
          <div className="divide-y divide-slate-100 text-xs">
            {current.forecast.map((f, i) => (
              <div key={i} className="py-2 flex items-center justify-between text-slate-700">
                <span className="font-semibold text-slate-900 w-16">{f.day}</span>
                <span className="text-slate-600">{f.weather}</span>
                <span className="font-mono tabular-nums text-slate-500">{f.temp}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
          <span>数据源：中国气象局国家气象中心</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-900 text-white font-medium text-xs hover:bg-slate-800 transition-colors"
          >
            完成
          </button>
        </div>

      </div>
    </div>
  );
}
