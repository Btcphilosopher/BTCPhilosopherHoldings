export type SearchTab = 
  | 'web' 
  | 'ai' 
  | 'deep_research' 
  | 'image' 
  | 'video' 
  | 'news' 
  | 'maps' 
  | 'academic' 
  | 'shopping' 
  | 'explore';

export type BackgroundTheme = 'shanshui' | 'city' | 'white' | 'dark' | 'ambient';

export interface SourceCitation {
  id: number;
  title: string;
  source: string;
  url: string;
  date: string;
  badge?: string; // e.g. "官方机构", "权威媒体", "学术期刊"
  isAuthoritative?: boolean;
}

export interface AIAnswerData {
  summary: string;
  confidence: 'high' | 'medium' | 'verified';
  confidenceLabel: string;
  verifiedFacts: string[];
  inferences?: string[];
  conflictingInfo?: string[];
  dataTable?: {
    headers: string[];
    rows: (string | number)[][];
    caption?: string;
  };
  sources: SourceCitation[];
  reasoningSteps?: string[];
  relatedQueries: string[];
  lastUpdated: string;
}

export interface WebSearchResult {
  id: string;
  title: string;
  url: string;
  displayUrl: string;
  snippet: string;
  date: string;
  source: string;
  sourceType: 'gov' | 'official' | 'news' | 'academic' | 'general';
  isOfficial?: boolean;
  score?: number;
  tags?: string[];
  extraData?: {
    type?: 'timeline' | 'table' | 'quote';
    timelineItems?: { date: string; title: string; desc: string }[];
  };
}

export interface KnowledgeEntity {
  id: string;
  name: string;
  category: string; // "中国新能源车企", "科技企业", "中国城市", "学术概念", etc.
  subtitle: string;
  description: string;
  avatar?: string;
  coverImage?: string;
  attributes: { label: string; value: string }[];
  timeline?: { year: string; event: string }[];
  keyStats?: { label: string; value: string; trend?: string }[];
  relatedEntities?: { name: string; relation: string; category: string }[];
  officialSources?: { title: string; link: string }[];
  stockInfo?: { symbol: string; market: string; price: string; change: string };
}

export interface LocalPlace {
  id: string;
  name: string;
  category: string;
  address: string;
  distance: string;
  rating: number;
  reviewsCount: number;
  pricePerPerson: string;
  openingHours: string;
  tags: string[];
  phone: string;
  features: string[];
  image: string;
}

export interface ShoppingProduct {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  originalPrice?: number;
  historicalLow?: number;
  score: number;
  reviewsCount: string;
  seller: string;
  specs: { [key: string]: string };
  highlights: string[];
  image: string;
  inStock: boolean;
  warranty: string;
}

export interface AcademicPaper {
  id: string;
  title: string;
  authors: string[];
  journal: string;
  publishYear: number;
  doi: string;
  abstract: string;
  citationCount: number;
  isOpenAccess: boolean;
  keywords: string[];
  pdfAvailable: boolean;
}

export interface NewsItem {
  id: string;
  title: string;
  source: string;
  publishedAt: string;
  summary: string;
  stage: '事件发生' | '首次报道' | '官方回应' | '深度分析' | '最新进展';
  credibilityLevel: '高信源官方' | '主流媒体' | '行业观察' | '待进一步证实';
  tags: string[];
}

export interface DeepResearchStep {
  id: number;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed';
  sourcesFound?: number;
  insights?: string[];
}

export interface SearchFilters {
  timeRange: 'all' | '24h' | '1w' | '1m' | '1y';
  sourceType: 'all' | 'gov' | 'news' | 'academic' | 'industry';
  region: 'all' | 'mainland' | 'hk_mo_tw' | 'global';
  language: 'all' | 'zh_hans' | 'zh_hant' | 'bilingual';
  sortBy: 'relevance' | 'date' | 'authority';
}
