import { 
  KnowledgeEntity, 
  LocalPlace, 
  ShoppingProduct, 
  AcademicPaper, 
  NewsItem, 
  AIAnswerData, 
  WebSearchResult 
} from './types';

// Hot Trending Queries with category and volume
export const TRENDING_SEARCHES = [
  { id: 1, query: '中国新能源汽车产业出口规模与主要市场', tag: '热搜', count: '482.9万', category: '产业' },
  { id: 2, query: '探月工程嫦娥八号国际载荷最新进展', tag: '新', count: '391.2万', category: '科技' },
  { id: 3, query: '2026宏观经济第三季度运行数据权威发布', tag: '官方', count: '345.0万', category: '财经' },
  { id: 4, query: '国产全自主算力集群与大模型开源生态', tag: '精选', count: '310.8万', category: '技术' },
  { id: 5, query: '中秋国庆假期长三角高铁出游车票预售', tag: '生活', count: '289.4万', category: '出行' },
  { id: 6, query: '全国主要城市超充补能网络密度对比', tag: '民生', count: '241.7万', category: '汽车' },
  { id: 7, query: '世界顶尖科学家论坛前沿科研成果解读', tag: '学术', count: '215.3万', category: '学术' },
  { id: 8, query: '北京秋季赏银杏枫叶路线推荐及气温', tag: '文旅', count: '198.6万', category: '旅游' },
];

// Pre-built authentic answers for canonical queries
export const CANONICAL_EV_ANSWER: AIAnswerData = {
  summary: '综合中国汽车工业协会（CAAM）、海关总署及前沿智库2026-2027年预测数据：中国新能源汽车出口正由“单纯贸易出海”迈向“全产业链全球化建厂与本土化运营”。预计2027年出口增速位列前五的自主品牌分别为：**比亚迪（BYD）、奇瑞汽车（Chery）、吉利汽车（Geely）、上汽名爵（MG）、长安深蓝/阿维塔（Changan）**。主要增量市场集中于东南亚、欧洲、中东自贸区及拉美核心国家。',
  confidence: 'verified',
  confidenceLabel: '高可信度 · 商务部/中汽协统计模型校准',
  verifiedFacts: [
    '2026年中国汽车出口总量保持全球首位，其中新能源乘用车渗透率与海外市占率持续提升。',
    '比亚迪在泰国、巴西、匈牙利三大整车制造基地相继达产，海外本土化交付比例将在2027年超过35%。',
    '奇瑞依靠长期深耕拉美、中东及欧亚大陆多元渠道，保持燃油+混动+纯电双轮驱动高速出口。',
    '吉利依托极氪、领克及沃尔沃全球协同平台，在西欧和北欧主流细分市场构筑高端品牌壁垒。'
  ],
  inferences: [
    '受关税政策调整与本土化建厂要求驱动，未来出口增速将更多体现在“CKD散件组装+海外工厂总装”模式。',
    '智能化座舱（多语言大模型）与超快充生态出海将成为2027年品牌间拉开溢价差距的关键要素。'
  ],
  conflictingInfo: [
    '各券商对欧盟市场2027年反补贴关税长期影响评估存在分歧，悲观预测增速受抑15%-20%，乐观模型认为本土建厂可完全规避。'
  ],
  dataTable: {
    caption: '2027年中国新能源汽车出口增速预测前五品牌综合对比',
    headers: ['品牌', '2027预计出口量 (万辆)', '预期复合年增速 (CAGR)', '主要战略市场', '核心竞争壁垒'],
    rows: [
      ['比亚迪 (BYD)', '85 - 100', '+48.5%', '东南亚(泰/印尼)、欧洲(德/英/法)、拉美(巴西)', '垂直整合刀片电池、整车智电架构、自建滚装船队'],
      ['奇瑞汽车 (Chery)', '65 - 75', '+38.2%', '独联体、中东(阿联酋/沙特)、拉美(墨/智利)', '20年海外渠道沉淀、混动长续航越野、本地化供应链'],
      ['吉利集团 (Geely/极氪)', '45 - 55', '+42.0%', '西欧、东南亚、大洋洲(澳/新)', 'SEA浩瀚架构全球化认可、欧洲安全五星标杆'],
      ['上汽名爵 (SAIC MG)', '50 - 60', '+32.4%', '英国、欧洲大陆、澳新、墨西哥', '百年英伦血统认同、欧洲成熟经销商网络、纯电小钢炮定位'],
      ['长安汽车 (深蓝/阿维塔)', '30 - 38', '+55.0%', '东南亚(泰国右舵枢纽)、中东、中南美', '央企体系出海、数智新汽车定位、华为乾崑智驾赋能']
    ]
  },
  sources: [
    { id: 1, title: '中国汽车工业协会(CAAM) 汽车工业产销与海外市场发展白皮书', source: '中国汽车工业协会', url: 'http://www.caam.org.cn/reports', date: '2026-09-18', badge: '国家行业协会', isAuthoritative: true },
    { id: 2, title: '海关总署商品出口分类月度统计公报 (8703类机动车辆)', source: '中华人民共和国海关总署', url: 'http://customs.gov.cn/statistics', date: '2026-09-10', badge: '政府权威统计', isAuthoritative: true },
    { id: 3, title: '中国新能源汽车全球化战略洞察：从产品出海到生态扎根', source: '中国汽车工程学会 / 战略前沿', url: 'https://sae-china.org/insight', date: '2026-08-25', badge: '学术学术机构', isAuthoritative: true },
    { id: 4, title: '全球主要地区新能源乘用车准入法规与碳足迹门槛深度评估', source: '中国电动汽车百人会论坛', url: 'https://chinaev100.org/global', date: '2026-08-12', badge: '国家高端智库', isAuthoritative: true }
  ],
  reasoningSteps: [
    '第一步：检索海关总署及乘联会各品牌历年实际出口基数与国别分布数据。',
    '第二步：剔除特斯拉上海超级工厂代工数据，聚焦中国本土自主产权乘用车品牌。',
    '第三步：综合考量海外在建工厂（泰国罗勇、匈牙利塞格德、巴西卡马萨里等）达产爬坡时间表。',
    '第四步：交叉比对欧盟碳足迹标准、东南亚右舵车自贸区税率及地缘贸易政策变量，拟合增速置信区间。'
  ],
  relatedQueries: [
    '2027年中国车企海外本土化工厂产能分布图',
    '欧盟对华电动汽车关税最新税率及应对方案',
    '比亚迪自建滚装船船队运营规模与海运成本优势',
    '深蓝和阿维塔在东南亚右舵车市场布局'
  ],
  lastUpdated: '2026-10-01 08:30 (基于实时经贸数据动态校验)'
};

// Chinese Knowledge Graph Entities
export const KNOWLEDGE_ENTITIES: Record<string, KnowledgeEntity> = {
  '新能源汽车': {
    id: 'ev_industry',
    name: '中国新能源汽车产业',
    category: '国家战略性新兴产业',
    subtitle: 'China New Energy Vehicle Industry · 全球最大生产与消费市场',
    description: '中国新能源汽车产业指以纯电动汽车（BEV）、插电式混合动力（PHEV）及燃料电池汽车（FCEV）为核心的战略性新兴产业。中国自2015年起连续多年保持全球产销第一，构建了全球最完整的三电系统（电池、电机、电控）与智能化产业链供应链。',
    attributes: [
      { label: '主管部门', value: '国家发改委 · 工业和信息化部 · 商务部' },
      { label: '全球产销量占比', value: '超过 62%（全球领跑）' },
      { label: '核心代表企业', value: '比亚迪、宁德时代、吉利、长安、上汽、蔚小理' },
      { label: '出口规模', value: '超200万辆/年（跃居全球第一出口动力）' },
      { label: '技术方向', value: '超充800V/1000V高压平台、固态电池、智能端到端智驾' }
    ],
    timeline: [
      { year: '2009年', event: '启动“十城千辆”节能与新能源汽车示范推广工程' },
      { year: '2015年', event: '产销量首超33万辆，跃居全球第一大新能源汽车市场' },
      { year: '2020年', event: '国务院发布《新能源汽车产业发展规划（2021—2035年）》' },
      { year: '2024年', event: '全国单月新能源乘用车零售渗透率首次跨越50%临界点' },
      { year: '2026年', event: '全产业链出海加速，全球电池专利与整车智能技术领航' }
    ],
    keyStats: [
      { label: '国内单月渗透率', value: '54.2%', trend: '+8.4% 同比' },
      { label: '公共充电桩总数', value: '380万根', trend: '车桩比全球领先' },
      { label: '动力电池全球份额', value: '71.5%', trend: '宁德时代/比亚迪主导' }
    ],
    relatedEntities: [
      { name: '比亚迪股份有限公司', relation: '整车销量冠军', category: '整车制造' },
      { name: '宁德时代新能源科技', relation: '动力电池核心供应商', category: '核心零部件' },
      { name: '华为数字能源与车BU', relation: '智能网联与高压超充赋能', category: '智能化技术' },
      { name: '工业和信息化部', relation: '产业标准与准入监管', category: '国家部委' }
    ],
    officialSources: [
      { title: '工信部：新能源汽车产业发展工作进展与规划', link: 'https://miit.gov.cn' },
      { title: '中国汽车工业协会官方统计数据库', link: 'http://caam.org.cn' }
    ]
  },
  '比亚迪': {
    id: 'byd_company',
    name: '比亚迪股份有限公司 (BYD)',
    category: '高新技术制造企业',
    subtitle: 'Build Your Dreams · 股票代码: 002594.SZ / 1211.HK',
    description: '比亚迪创立于1995年2月，总部位于广东深圳，业务横跨汽车、轨道交通、新能源和电子四大产业。在汽车领域，比亚迪是全球首家全面停产燃油车并专注于新能源汽车的整车制造商，掌握刀片电池、DM-i超级混动、e平台3.0、云辇智能车身控制及天神之眼高阶智驾等全栈自研核心技术。',
    attributes: [
      { label: '创立时间', value: '1995年2月10日' },
      { label: '创始人 / 董事长', value: '王传福' },
      { label: '全球总部', value: '中国广东省深圳市坪山区比亚迪路3009号' },
      { label: '员工规模', value: '超过 900,000 人（工程师超11万人）' },
      { label: '核心品牌矩阵', value: '比亚迪(王朝/海洋)、腾势、方程豹、仰望' }
    ],
    stockInfo: {
      symbol: '002594.SZ',
      market: '深交所A股',
      price: '¥298.60',
      change: '+2.85%'
    },
    timeline: [
      { year: '2003年', event: '收购西安秦川汽车，正式进入汽车制造行业' },
      { year: '2008年', event: '巴菲特旗下伯克希尔哈撒韦战略投资比亚迪' },
      { year: '2020年', event: '正式发布高安全“刀片电池”，重新定义电动车安全标准' },
      { year: '2022年', event: '宣布停止燃油汽车整车生产，成为全球首个停产燃油车传统车企' },
      { year: '2024年', event: '发布第五代DM超级混动技术，百公里油耗迈入2时代' }
    ],
    keyStats: [
      { label: '全球新能源汽车累计交付', value: '超 1000 万辆', trend: '全球首创里程碑' },
      { label: '海外出口月销', value: '4.8万+ 辆', trend: '泰国/巴西/欧洲领跑' },
      { label: '年研发投入', value: '超 400 亿元', trend: '研发人员居国内榜首' }
    ],
    relatedEntities: [
      { name: '王传福', relation: '创始人兼董事长', category: '企业家' },
      { name: '仰望汽车', relation: '高端豪华新能源品牌', category: '子品牌' },
      { name: '宁德时代', relation: '行业龙头同行', category: '动力电池' },
      { name: '深圳证券交易所', relation: 'A股上市交易所', category: '金融机构' }
    ],
    officialSources: [
      { title: '比亚迪官方网站', link: 'https://byd.com' },
      { title: '巨潮资讯网：比亚迪历年定期财务报告', link: 'http://cninfo.com.cn' }
    ]
  },
  '苹果': {
    id: 'apple_disambiguation',
    name: '苹果 (Apple)',
    category: '多义实体词消歧',
    subtitle: '科技巨头 Apple Inc. / 蔷薇科苹果属落叶乔木果实',
    description: '“苹果”在现代中文语境中通常指代美国跨国科技公司 Apple Inc.（苹果公司）或其推出的 iPhone/Mac 等产品；亦可指蔷薇科落叶乔木的传统水果苹果（Malus domestica）。在当前科技语境中，通常自动关联苹果最新科技硬件与系统生态。',
    attributes: [
      { label: '科技实体', value: '苹果公司 (Apple Inc.，纳斯达克: AAPL，现任CEO: 蒂姆·库克)' },
      { label: '代表产品', value: 'iPhone系列、MacBook、iPad、Apple Vision Pro、iOS' },
      { label: '农业植物实体', value: '双子叶植物纲·蔷薇科·苹果属，中国山东烟台/陕西洛川为著名产区' }
    ],
    keyStats: [
      { label: '苹果公司市值', value: '$3.4 万亿美元', trend: '全球市值领先' },
      { label: '中国优质苹果产量', value: '4,500万吨/年', trend: '全球第一大生产国' }
    ],
    relatedEntities: [
      { name: 'iPhone 18 Pro Max', relation: '旗舰智能手机', category: '消费电子' },
      { name: '蒂姆·库克 (Tim Cook)', relation: '现任CEO', category: '商界领袖' },
      { name: '烟台红富士', relation: '著名地理标志保护果品', category: '农产品' }
    ]
  }
};

// Rich Web Search Results
export const DEFAULT_WEB_RESULTS: WebSearchResult[] = [
  {
    id: 'w1',
    title: '中国汽车工业协会：2026年中国汽车对外贸易形势分析与2027年预测',
    url: 'http://www.caam.org.cn/article/export-2026-2027-analysis.html',
    displayUrl: 'caam.org.cn › 统计与政策 › 国际贸易',
    snippet: '【权威发布】中汽协数据显示，我国新能源乘用车对外出口增速保持40%以上高位增长，东南亚已成首要规模市场，欧洲进入本土化建厂替代直接整车出口的关键转型期。比亚迪、奇瑞、吉利、上汽名爵持续领跑海外交付榜...',
    date: '2026年9月25日',
    source: '中国汽车工业协会官方网',
    sourceType: 'official',
    isOfficial: true,
    tags: ['官方公报', '产业数据', '权威核验']
  },
  {
    id: 'w2',
    title: '中华人民共和国商务部：关于支持新能源汽车产业链健康有序出海的政策解读',
    url: 'http://www.mofcom.gov.cn/article/policy/202609/ev-global-supply.html',
    displayUrl: 'mofcom.gov.cn › 政策发布 › 对外贸易司',
    snippet: '国务院常务会议审议通过加快推进中国新能源汽车供应链全球化布局指导意见。支持骨干整车及零部件企业在共建“一带一路”国家、拉美和中东建设研发试验中心与合资总装厂，推动标准互认与碳足迹核算衔接...',
    date: '2026年9月20日',
    source: '中华人民共和国商务部',
    sourceType: 'gov',
    isOfficial: true,
    tags: ['国家部委', '政策解读', '权威源']
  },
  {
    id: 'w3',
    title: '新华社深度：中国车企闯世界——从“产品卖全球”到“工厂造全球”的历史跨越',
    url: 'http://www.news.cn/auto/20260928/ev-world-expansion.htm',
    displayUrl: 'xinhuanet.com › 汽车要闻 › 财经深度',
    snippet: '在匈牙利塞格德，比亚迪欧洲首个新能源乘用车整车基地的施工车辆昼夜穿梭；在泰国罗勇府，奇瑞与吉利右舵车生产线高效运转。中国新能源汽车出口版图正在经历从沿海港口滚装发运，到深度扎根海外主流消费市场的战略升级...',
    date: '2026年9月28日',
    source: '新华通讯社',
    sourceType: 'news',
    tags: ['央媒特稿', '全球视野']
  },
  {
    id: 'w4',
    title: '清华大学智能产业研究院 (AIR)：中国智能网联汽车出海技术竞争力研究报告',
    url: 'https://air.tsinghua.edu.cn/publications/autonomous-driving-export.pdf',
    displayUrl: 'air.tsinghua.edu.cn › 学术研究 › 智库专报',
    snippet: '报告指出，中国新能源汽车之所以能在海外中高端市场建立溢价优势，不仅依靠三电系统成本效率，更在于智能座舱算力架构、云端协同地图服务及端到端大模型智驾系统的代际领先...',
    date: '2026年8月30日',
    source: '清华大学智能产业研究院',
    sourceType: 'academic',
    tags: ['高校智库', '学术文献', '同行评审']
  },
  {
    id: 'w5',
    title: '海关总署统计月报：2026年1-8月机动车辆主要国别出口明细数据表',
    url: 'http://customs.gov.cn/customs/analysis/monthly-data/202608.html',
    displayUrl: 'customs.gov.cn › 海关统计 › 进出口数据查询',
    snippet: '据海关总署最新统计，2026年前8个月中国汽车出口金额突破860亿美元，同比上升28.3%。其中比利时、英国、泰国、阿联酋、澳大利亚为单国出口量前五名。纯电乘用车与插电混动乘用车合计占比升至46.8%...',
    date: '2026年9月10日',
    source: '中华人民共和国海关总署',
    sourceType: 'gov',
    isOfficial: true,
    tags: ['海关权威', '原始报表']
  }
];

// Local Places for Local Search
export const LOCAL_PLACES: LocalPlace[] = [
  {
    id: 'p1',
    name: '新荣记 (上海南京西路恒隆广场店)',
    category: '台州菜 · 粤菜臻品 · 黑珍珠三钻 · 米其林三星',
    address: '上海市静安区南京西路1266号恒隆广场5楼501室',
    distance: '距您 1.8km · 静安寺商圈',
    rating: 4.9,
    reviewsCount: 3840,
    pricePerPerson: '¥1,280 / 人',
    openingHours: '11:30 - 14:00, 17:30 - 21:30',
    tags: ['包厢预约', '商务宴请', '必吃榜', '私密性极佳'],
    phone: '021-62888899',
    features: ['招牌野生大黄鱼', '脆皮乳鸽', '沙蒜豆面', '专业侍酒服务'],
    image: 'https://picsum.photos/seed/restaurant1/600/400'
  },
  {
    id: 'p2',
    name: '御宝轩 (上海益丰外滩源店)',
    category: '经典正宗粤菜 · 米其林二星 · 外滩核心景观',
    address: '上海市黄浦区北京东路99号益丰外滩源4楼402-403室',
    distance: '距您 3.2km · 外滩沿线',
    rating: 4.8,
    reviewsCount: 5120,
    pricePerPerson: '¥680 / 人',
    openingHours: '11:00 - 14:30, 17:00 - 22:00',
    tags: ['外滩江景', '传统早茶点心', '米其林精选', '老牌粤菜'],
    phone: '021-53081188',
    features: ['金牌流沙包', '蜜汁叉烧', '原只鲍鱼烧卖', '老火炖靓汤'],
    image: 'https://picsum.photos/seed/restaurant2/600/400'
  },
  {
    id: 'p3',
    name: '利苑酒家 (上海环贸iapm店)',
    category: '传统高级粤菜 · 餐饮名店 · 黑珍珠一钻',
    address: '上海市徐汇区淮海中路999号环贸iapm商场3楼L3-301',
    distance: '距您 2.5km · 淮海中路商圈',
    rating: 4.7,
    reviewsCount: 4290,
    pricePerPerson: '¥520 / 人',
    openingHours: '11:30 - 14:30, 17:30 - 21:30',
    tags: ['杨枝甘露发源地', '家庭聚餐', '经典烧腊'],
    phone: '021-54252288',
    features: ['冰烧三层肉', '杨枝甘露', '龙虾汤泡饭', '老火汤'],
    image: 'https://picsum.photos/seed/restaurant3/600/400'
  }
];

// Shopping Product Comparison
export const SHOPPING_PRODUCTS: ShoppingProduct[] = [
  {
    id: 'sp1',
    name: '海信 (Hisense) 75E8N Ultra 75英寸 原生Mini LED 4K 144Hz 旗舰电视',
    brand: '海信',
    category: '智能电视 / Mini LED',
    price: 8999,
    originalPrice: 9999,
    historicalLow: 8799,
    score: 4.9,
    reviewsCount: '5万+ 评价',
    seller: '京东自营官方旗舰店 · 当日达',
    specs: {
      '屏幕尺寸': '75英寸',
      '背光技术': '信芯AI感知芯片 · 5376背光分区',
      '峰值亮度': '5800 nits XDR',
      '刷新率': '144Hz 原生超高刷',
      '音响配置': '2.1.2 杜比全景声 帝瓦雷调音'
    },
    highlights: ['国补立减20%', '全金属超薄机身', '无开机广告', '广色域98% DCI-P3'],
    image: 'https://picsum.photos/seed/tv1/600/450',
    inStock: true,
    warranty: '整机包修1年，主要部件包修3年'
  },
  {
    id: 'sp2',
    name: 'TCL 75Q10K 75英寸 Mini LED 4K高端旗舰QD-Mini液晶电视',
    brand: 'TCL',
    category: '智能电视 / Mini LED',
    price: 8499,
    originalPrice: 9499,
    historicalLow: 8299,
    score: 4.8,
    reviewsCount: '8万+ 评价',
    seller: '天猫官方旗舰店 · 送装一体',
    specs: {
      '屏幕尺寸': '75英寸',
      '背光技术': '六晶方芯Mini LED · 2160背光分区',
      '峰值亮度': '3800 nits XDR',
      '刷新率': '144Hz 高刷低延时',
      '音响配置': '安桥2.1.2 Hi-Fi专业音响'
    },
    highlights: ['蝶翼星曜屏', '全通道4K 144Hz', '灵控桌面无广告', '超薄挂墙体验'],
    image: 'https://picsum.photos/seed/tv2/600/450',
    inStock: true,
    warranty: '官方全国联保，整机3年质保'
  },
  {
    id: 'sp3',
    name: '华为智慧屏 V5 Pro 75英寸 鸿鹄SuperMiniLED 灵犀指向遥控电视',
    brand: '华为',
    category: '智能电视 / 智慧屏',
    price: 11999,
    originalPrice: 12999,
    historicalLow: 11499,
    score: 4.9,
    reviewsCount: '3万+ 评价',
    seller: '华为商城官方直营 · 免费上门安装',
    specs: {
      '屏幕尺寸': '75英寸',
      '背光技术': '鸿鹄计算画质 · SuperMiniLED',
      '峰值亮度': '2000 nits 广视角低反射',
      '交互创新': '华为灵犀指向遥控（巨幕手机体验）',
      '系统生态': 'HarmonyOS 5.0 全场景智慧互联'
    },
    highlights: ['隔空滑动操控', '双摄AI景深感知', '鸿蒙全家桶流转', '超窄微边框'],
    image: 'https://picsum.photos/seed/tv3/600/450',
    inStock: true,
    warranty: '华为官方服务中心联保'
  }
];

// Academic Papers
export const ACADEMIC_PAPERS: AcademicPaper[] = [
  {
    id: 'ap1',
    title: '中国新能源汽车产业链韧性与全球价值链重构实证研究',
    authors: ['陈晓明', '张建国', '王立峰'],
    journal: '《中国工业经济》',
    publishYear: 2026,
    doi: '10.19581/j.cnki.ciejournal.2026.08.004',
    abstract: '本文基于2015-2025年中国与全球42个主要贸易伙伴的新能源汽车多区域投入产出模型（MRIO），系统测度了三电系统垂直整合对产业抗外部冲击韧性的边际贡献。研究表明，中国整车企业的本土化供应链网络使产业链综合抗风险指数提升37.4%，并在东南亚与南美形成了正向知识外溢溢价。',
    citationCount: 48,
    isOpenAccess: true,
    keywords: ['新能源汽车', '全球价值链', '产业链韧性', '三电系统', '投入产出模型'],
    pdfAvailable: true
  },
  {
    id: 'ap2',
    title: '全固态锂金属电池界面阻抗调控机制与大容量软包电芯研制',
    authors: ['李云飞', '郭瑞华', '刘培'],
    journal: '《中国科学：化学》 (Science China Chemistry)',
    publishYear: 2026,
    doi: '10.1007/s11426-026-2189-x',
    abstract: '固态电解质与锂金属负极的高固-固接触阻抗是限制全固态电池快充及低温性能的核心瓶颈。本研究通过原位自组装氟化有机-无机复合界面层，将界面离子电导率提升至5.2×10⁻³ S/cm，在20Ah大容量电芯中实现了-20℃至60℃宽温域下1200次循环容量保持率>91.2%。',
    citationCount: 112,
    isOpenAccess: true,
    keywords: ['全固态电池', '锂金属负极', '固体电解质', '界面调控', '能量密度'],
    pdfAvailable: true
  }
];

// News Items Timeline for News Mode
export const NEWS_ITEMS: NewsItem[] = [
  {
    id: 'n1',
    title: '中国新能源乘用车前三季度累计海外出口突破180万辆大关',
    source: '新华社客户端',
    publishedAt: '2小时前 · 权威发布',
    summary: '根据海关总署最新汇总数据，今年前三季度我国新能源乘用车出海保持稳中有进势头，欧洲、东南亚及拉美成为三大支柱海外市场。',
    stage: '最新进展',
    credibilityLevel: '高信源官方',
    tags: ['宏观外贸', '新能源汽车', '经贸动态']
  },
  {
    id: 'n2',
    title: '比亚迪匈牙利整车制造基地主体结构封顶，预计2026下半年首期投产',
    source: '中国证券报',
    publishedAt: '5小时前 · 深度报道',
    summary: '比亚迪欧洲乘用车本土制造取得关键里程碑。该基地将为欧洲消费者提供本地组装的纯电动与DM-i插电混动车型，规避整车跨洋海运周期。',
    stage: '深度分析',
    credibilityLevel: '主流媒体',
    tags: ['企业出海', '欧洲制造']
  },
  {
    id: 'n3',
    title: '商务部新闻发言人就相关地区汽车进口关税政策答记者问',
    source: '商务部新闻办公室',
    publishedAt: '昨天 16:30 · 官方发布',
    summary: '中方始终主张通过对话协商妥善解决贸易分歧。中方支持两国汽车产业界秉持市场化原则开展供应链深度合作，共同维护全球绿色低碳转型大局。',
    stage: '官方回应',
    credibilityLevel: '高信源官方',
    tags: ['多边贸易', '政策声明']
  }
];
