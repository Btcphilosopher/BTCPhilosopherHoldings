import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '灵犀搜索 · 连接世界 发现更多 | 下一代全场景AI搜索引擎',
  description: '灵犀搜索 (Lingxi Search) - 下一代智能搜索引擎。支持秒级全网检索、生成式AI精准问答、深度研究智能体、知识图谱与生活/学术/购物/新闻/地图全生态服务。',
  openGraph: {
    title: '灵犀搜索 · 连接世界 发现更多',
    description: '下一代全场景AI搜索引擎，连接世界，发现更多。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '灵犀搜索 · 连接世界 发现更多',
    description: '下一代全场景AI搜索引擎，连接世界，发现更多。',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="zh-CN">
      <body suppressHydrationWarning className="antialiased min-h-screen text-slate-900 bg-slate-50 selection:bg-blue-600 selection:text-white">
        {children}
      </body>
    </html>
  );
}
