'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import SearchResultsView from '@/components/SearchResultsView';
import DeepResearchModal from '@/components/DeepResearchModal';
import VoiceModal from '@/components/VoiceModal';
import CameraModal from '@/components/CameraModal';
import PrivacyModal from '@/components/PrivacyModal';
import WeatherModal from '@/components/WeatherModal';
import AppGridModal from '@/components/AppGridModal';
import HistoryDrawer from '@/components/HistoryDrawer';
import ModelInfoModal from '@/components/ModelInfoModal';
import { SearchTab, BackgroundTheme, AIAnswerData } from '@/lib/types';
import { CANONICAL_EV_ANSWER } from '@/lib/mock-data';

export default function HomePage() {
  // Navigation & Search State
  const [view, setView] = useState<'home' | 'results'>('home');
  const [currentTab, setCurrentTab] = useState<SearchTab>('web');
  const [query, setQuery] = useState('');
  const [searchedQuery, setSearchedQuery] = useState('');
  
  // Theme Background state
  const [bgTheme, setBgTheme] = useState<BackgroundTheme>('shanshui');

  // AI Answer data
  const [aiAnswer, setAiAnswer] = useState<AIAnswerData>(CANONICAL_EV_ANSWER);
  const [isLoadingAI, setIsLoadingAI] = useState(false);

  // Search History & Privacy
  const [history, setHistory] = useState<string[]>([
    '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。',
    '上海最好的粤菜餐厅推荐',
    '最好的国产Mini LED高刷电视对比与国补政策',
    '苹果最新手机'
  ]);
  const [isIncognito, setIsIncognito] = useState(false);

  // Interactive Modals State
  const [showDeepResearch, setShowDeepResearch] = useState(false);
  const [deepResearchQuery, setDeepResearchQuery] = useState('');
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showWeatherModal, setShowWeatherModal] = useState(false);
  const [showAppGridModal, setShowAppGridModal] = useState(false);
  const [showHistoryDrawer, setShowHistoryDrawer] = useState(false);
  const [showModelModal, setShowModelModal] = useState(false);

  // Execute Search
  const handlePerformSearch = async (targetQuery?: string) => {
    const q = (targetQuery !== undefined ? targetQuery : query).trim();
    if (!q) return;

    setSearchedQuery(q);
    setView('results');

    // Save to history unless in incognito
    if (!isIncognito) {
      setHistory(prev => [q, ...prev.filter(item => item !== q)].slice(0, 30));
    }

    // Call server-side search API
    setIsLoadingAI(true);
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, mode: currentTab }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.data) {
          setAiAnswer(data.data);
        }
      }
    } catch (err) {
      console.warn('Using client-side fallback answer', err);
    } finally {
      setIsLoadingAI(false);
    }
  };

  const handleTabChange = (tab: SearchTab) => {
    setCurrentTab(tab);
    if (tab === 'deep_research') {
      setDeepResearchQuery(searchedQuery || query || '2027年中国新能源汽车出口格局与品牌竞争');
      setShowDeepResearch(true);
    } else if (view === 'home') {
      // If clicking tab from homepage, run search or switch to results
      const defaultQ = query || '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。';
      setQuery(defaultQ);
      handlePerformSearch(defaultQ);
    }
  };

  const handleTriggerDeepResearch = (q?: string) => {
    setDeepResearchQuery(q || searchedQuery || query || '2027年中国新能源汽车出口格局与品牌竞争');
    setShowDeepResearch(true);
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  return (
    <main className="relative min-h-screen font-sans selection:bg-blue-600 selection:text-white overflow-x-hidden">
      
      {/* Background Layer for Homepage */}
      {view === 'home' && (
        <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none transition-opacity duration-700">
          {bgTheme === 'shanshui' && (
            <div className="relative w-full h-full">
              <Image
                src="/images/lingxi_hero_landscape.jpg"
                alt="灵犀搜索国风壮丽山水与现代天际"
                fill
                priority
                className="object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-linear-to-b from-slate-950/40 via-slate-900/25 to-slate-950/70" />
            </div>
          )}

          {bgTheme === 'city' && (
            <div className="relative w-full h-full">
              <Image
                src="/images/lingxi_city_skyline.jpg"
                alt="超现代中国城市天际线"
                fill
                priority
                className="object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-linear-to-b from-slate-950/50 via-slate-900/30 to-slate-950/75" />
            </div>
          )}

          {bgTheme === 'white' && (
            <div className="w-full h-full bg-slate-100" />
          )}

          {bgTheme === 'dark' && (
            <div className="w-full h-full bg-slate-950" />
          )}

          {bgTheme === 'ambient' && (
            <div className="w-full h-full bg-linear-to-br from-blue-900 via-indigo-950 to-slate-950 animate-pulse duration-1000" />
          )}
        </div>
      )}

      {/* Incognito Warning Toast Bar (if active) */}
      {isIncognito && (
        <div className="bg-emerald-700 text-white text-xs px-4 py-1.5 text-center font-medium flex items-center justify-center gap-2">
          <span>当前已开启「无痕纯净搜索」：所有搜索记录与点击轨迹均不作任何沉淀</span>
        </div>
      )}

      {/* Homepage View */}
      {view === 'home' ? (
        <div className="flex flex-col min-h-screen justify-between">
          <Header
            currentTab={currentTab}
            onTabChange={handleTabChange}
            bgTheme={bgTheme}
            onBgThemeChange={setBgTheme}
            onOpenPrivacy={() => setShowPrivacyModal(true)}
            onOpenWeather={() => setShowWeatherModal(true)}
            onOpenApps={() => setShowAppGridModal(true)}
            onOpenHistory={() => setShowHistoryDrawer(true)}
            onGoHome={() => setView('home')}
            isCompact={false}
          />

          <HeroSection
            query={query}
            onQueryChange={setQuery}
            onSearch={handlePerformSearch}
            onSelectTab={handleTabChange}
            onVoiceClick={() => setShowVoiceModal(true)}
            onCameraClick={() => setShowCameraModal(true)}
            onOpenModelModal={() => setShowModelModal(true)}
          />

          {/* Minimalist Footnote (anti-slop clean) */}
          <footer className="w-full py-3 px-4 text-center text-xs text-white/70 drop-shadow-xs relative z-10 flex flex-wrap items-center justify-center gap-4">
            <span>© 2026 灵犀搜索 · 中华人民共和国互联网信息服务备案</span>
            <button 
              onClick={() => setShowPrivacyModal(true)}
              className="hover:text-white transition-colors underline underline-offset-2"
            >
              隐私保护承诺
            </button>
            <button 
              onClick={() => handlePerformSearch('帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。')}
              className="hover:text-white transition-colors"
            >
              体验示范检索
            </button>
          </footer>
        </div>
      ) : (
        /* Results View */
        <SearchResultsView
          query={searchedQuery || query}
          onQueryChange={(q) => {
            setQuery(q);
            setSearchedQuery(q);
          }}
          onSearch={handlePerformSearch}
          activeTab={currentTab}
          onTabChange={handleTabChange}
          aiAnswer={aiAnswer}
          isLoadingAI={isLoadingAI}
          onVoiceClick={() => setShowVoiceModal(true)}
          onCameraClick={() => setShowCameraModal(true)}
          onTriggerDeepResearch={handleTriggerDeepResearch}
          onGoHome={() => setView('home')}
        />
      )}

      {/* Global Interactive Modals */}
      <DeepResearchModal
        isOpen={showDeepResearch}
        onClose={() => setShowDeepResearch(false)}
        query={deepResearchQuery}
      />

      <VoiceModal
        isOpen={showVoiceModal}
        onClose={() => setShowVoiceModal(false)}
        onSearch={(spokenText) => {
          setQuery(spokenText);
          handlePerformSearch(spokenText);
        }}
      />

      <CameraModal
        isOpen={showCameraModal}
        onClose={() => setShowCameraModal(false)}
        onSearch={(detectedText) => {
          setQuery(detectedText);
          handlePerformSearch(detectedText);
        }}
      />

      <PrivacyModal
        isOpen={showPrivacyModal}
        onClose={() => setShowPrivacyModal(false)}
        isIncognito={isIncognito}
        onToggleIncognito={() => setIsIncognito(!isIncognito)}
        onClearHistory={handleClearHistory}
      />

      <WeatherModal
        isOpen={showWeatherModal}
        onClose={() => setShowWeatherModal(false)}
      />

      <AppGridModal
        isOpen={showAppGridModal}
        onClose={() => setShowAppGridModal(false)}
        onSelectApp={(appName) => {
          setQuery(`关于${appName}的官方功能介绍与使用指南`);
          handlePerformSearch(`关于${appName}的官方功能介绍与使用指南`);
        }}
      />

      <HistoryDrawer
        isOpen={showHistoryDrawer}
        onClose={() => setShowHistoryDrawer(false)}
        history={history}
        onSelectQuery={(q) => {
          setQuery(q);
          handlePerformSearch(q);
        }}
        onClearHistory={handleClearHistory}
      />

      <ModelInfoModal
        isOpen={showModelModal}
        onClose={() => setShowModelModal(false)}
        onTryModel={() => {
          const defaultQ = '帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。';
          setQuery(defaultQ);
          handlePerformSearch(defaultQ);
        }}
      />

    </main>
  );
}
