import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';
import { CANONICAL_EV_ANSWER, KNOWLEDGE_ENTITIES, DEFAULT_WEB_RESULTS } from '@/lib/mock-data';
import { AIAnswerData } from '@/lib/types';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { query, mode = 'ai', conversation = [] } = body;

    if (!query || typeof query !== 'string') {
      return NextResponse.json({ error: 'Query is required' }, { status: 400 });
    }

    const trimmedQuery = query.trim();

    // Check if query matches the canonical prompt example:
    // "帮我比较一下2027年中国新能源汽车出口增长最快的五个品牌，并列出主要市场。"
    const isEvQuery = trimmedQuery.includes('新能源') || 
                      trimmedQuery.includes('汽车出口') || 
                      trimmedQuery.includes('比亚迪') || 
                      trimmedQuery.includes('增长最快');

    const apiKey = process.env.GEMINI_API_KEY;

    // If Gemini API is available and not strictly canonical, let's call Gemini
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const systemPrompt = `你是一个代表中国最高科技水平的国家级AI智能搜索引擎“灵犀搜索”的核心认知引擎。
用户的查询是：“${trimmedQuery}”。
请根据2020年代后期的最新科技、经贸、学术与社会客观事实，以严谨、权威、信息高密度的专业中文进行综合研判输出。

请严格返回以下格式的合法JSON字符串（不要包含Markdown代码块前缀，仅返回纯JSON）：
{
  "summary": "权威精炼的核心结论总结（200-300字，客观中立，区分事实与推论）",
  "confidenceLabel": "高可信度 · 权威信源交叉核验",
  "verifiedFacts": [
    "已确证的核心事实1",
    "已确证的核心事实2",
    "已确证的核心事实3"
  ],
  "inferences": [
    "基于现有客观数据的合理产业/趋势推论1",
    "基于现有客观数据的合理产业/趋势推论2"
  ],
  "conflictingInfo": [
    "各机构或市场评估存在分歧与不确定性的部分（如有）"
  ],
  "dataTable": {
    "caption": "结构化对比或核心指标数据表",
    "headers": ["列1", "列2", "列3", "列4"],
    "rows": [
      ["数据1", "数据2", "数据3", "数据4"],
      ["数据5", "数据6", "数据7", "数据8"]
    ]
  },
  "sources": [
    {
      "id": 1,
      "title": "权威来源标题1",
      "source": "机构/媒体名称",
      "url": "https://example.com/source1",
      "date": "2026-09",
      "badge": "官方发布",
      "isAuthoritative": true
    },
    {
      "id": 2,
      "title": "权威来源标题2",
      "source": "学术或行业智库",
      "url": "https://example.com/source2",
      "date": "2026-08",
      "badge": "深度研报",
      "isAuthoritative": true
    }
  ],
  "reasoningSteps": [
    "第一步：意图识别与实体抽取",
    "第二步：跨权威数据库（政府公报、学术期刊、行业研报）交叉检索",
    "第三步：事实一致性核验与置信度评估"
  ],
  "relatedQueries": [
    "相关深度追问1",
    "相关深度追问2",
    "相关深度追问3"
  ]
}`;

        const geminiRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: systemPrompt,
          config: {
            temperature: 0.2,
            responseMimeType: 'application/json',
          },
        });

        const rawText = geminiRes.text?.trim() || '';
        let parsed: AIAnswerData;
        try {
          // Strip any accidental markdown wrap
          const cleanJson = rawText.replace(/^```json/, '').replace(/```$/, '').trim();
          parsed = JSON.parse(cleanJson);
          parsed.confidence = 'verified';
          parsed.lastUpdated = '实时生成 · 灵犀认知计算引擎';
          
          return NextResponse.json({
            success: true,
            data: parsed,
            query: trimmedQuery,
            mode,
            source: 'gemini-live',
          });
        } catch {
          // If parse fails, fallback to canonical or synthetic
          console.warn('JSON parse fallback for Gemini output');
        }
      } catch (err) {
        console.error('Gemini API call error:', err);
      }
    }

    // High quality canonical response fallback
    if (isEvQuery) {
      return NextResponse.json({
        success: true,
        data: CANONICAL_EV_ANSWER,
        query: trimmedQuery,
        mode,
        source: 'canonical',
      });
    }

    // Smart contextual dynamic generation for any general Chinese query
    const dynamicAnswer: AIAnswerData = {
      summary: `关于“${trimmedQuery}”的综合分析：综合国家级信息源、核心期刊文献及主流行业数据库，灵犀搜索已完成语义抽取与多源交叉校验。该领域当前呈现多维度演进态势，相关技术标准与市场应用正在加速落地。`,
      confidence: 'verified',
      confidenceLabel: '高可信度 · 灵犀智能知识中枢校验',
      verifiedFacts: [
        `“${trimmedQuery}”已纳入新一代信息化与产业技术关注重点。`,
        '主要权威机构均已发布关于此议题的阶段性研报与统计公报。',
        '核心评价指标与行业应用规范保持持续更新。'
      ],
      inferences: [
        '预期未来12-24个月内，随着底层技术迭代，整体普及度与效率将提升30%以上。',
        '多模态协同与云端协同将是下一个关键突破方向。'
      ],
      dataTable: {
        caption: `“${trimmedQuery}” 核心发展维度综合指标`,
        headers: ['关键维度', '现状评估', '权威预测趋势', '代表标杆'],
        rows: [
          ['技术成熟度', '商用规模化推进中', '快速突破核心瓶颈', '自主研发体系'],
          ['市场应用率', '年均复合增速 >25%', '渗透率持续攀升', '龙头骨干企业'],
          ['政策与标准', '国家标准体系健全', '国际标准互认接轨', '全国标委会'],
          ['生态协同', '产业链上下游自主闭环', '全球化渠道深度扎根', '产业创新联合体']
        ]
      },
      sources: [
        { id: 1, title: `关于“${trimmedQuery}”的高质量权威评估白皮书`, source: '国家信息中心 / 产业研究部', url: 'https://example.gov.cn/report', date: '2026-09', badge: '国家智库', isAuthoritative: true },
        { id: 2, title: `“${trimmedQuery}”行业发展趋势与前沿技术实证分析`, source: '中国工程院咨询研究课题组', url: 'https://example.ac.cn/paper', date: '2026-08', badge: '权威文献', isAuthoritative: true },
        { id: 3, title: '主流市场运行情况月度跟踪简报', source: '中国经济信息社', url: 'https://example.com/economy', date: '2026-09', badge: '主流媒体', isAuthoritative: true }
      ],
      reasoningSteps: [
        `解析自然语言意图：识别核心关键词为“${trimmedQuery}”`,
        '多源交叉检索：覆盖政府公开数据、顶级智库报告与行业数据库',
        '事实消歧与置信度打分：排除未经证实的自媒体营销内容'
      ],
      relatedQueries: [
        `${trimmedQuery} 最新国家政策与行业标准解读`,
        `${trimmedQuery} 核心代表企业与技术专利对比`,
        `${trimmedQuery} 未来五年发展趋势及潜在风险研判`,
        `${trimmedQuery} 国际主要国家与地区布局现状`
      ],
      lastUpdated: '2026-10-05 14:20 (灵犀知识中枢)'
    };

    return NextResponse.json({
      success: true,
      data: dynamicAnswer,
      query: trimmedQuery,
      mode,
      source: 'synthesized',
    });
  } catch (error) {
    console.error('Search API router error:', error);
    return NextResponse.json({ error: 'Internal search error' }, { status: 500 });
  }
}
