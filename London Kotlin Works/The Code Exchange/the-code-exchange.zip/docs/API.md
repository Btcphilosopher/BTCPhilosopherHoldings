# The Code Exchange — REST API Documentation

All prices are represented in integer minor units (**GBP pence**), inclusive of 20% UK VAT unless noted (`itemsNetPence` vs `taxPence`).

## Health & Readiness
- `GET /api/health` (Next.js) / `GET /healthz`, `GET /readyz` (FastAPI) — Service and database connectivity status.

## Catalogue & Licensing
- `GET /api/catalogue` — Search & filter products (`q`, `category`, `platform`, `language`, `format`, `source`, `licence`, `maxPrice`, `sort`, `page`, `pageSize`).
- `GET /api/catalogue/{slug}` — Full product specification, editions, per-store stock, published release artefacts, and related products.
- `GET /api/licences/{id}` — Full versioned legal licence text.

## Basket, Checkout & Payments
- `GET /api/basket` — Returns server-calculated basket snapshot (`itemsNetPence`, `discountPence`, `taxPence`, `deliveryPence`, `totalPence`).
- `POST /api/basket` — Add product edition (`itemType: "edition"`) or reserve 15-minute workshop seat hold (`itemType: "workshop"`).
- `PATCH /api/basket` — Update quantity, Click & Collect store selection, or promotional code (`CODE10`, `WELCOME5`, `WORKSHOP20`).
- `DELETE /api/basket?itemId=...` — Remove item and release any active workshop hold.
- `POST /api/checkout` — Revalidates prices, stock, holds, UK shipping address (only if physical delivery selected), Terms, and UK Consumer Contracts Reg 37 digital waiver; atomically reserves stock and creates an idempotent `PaymentIntent` via `idempotencyKey`.
- `POST /api/payments/simulate` — Invokes the payment provider simulator (`succeeded`, `cancelled`, `failed`, or duplicate callback replay).
- `POST /api/payments/webhook` — HMAC-SHA256 verified (`x-cx-signature`) and `eventId`-deduplicated payment webhook handler. Triggers `fulfilment_jobs` on success or releases stock reservations on failure/cancellation.

## Orders, Customer Library & Downloads
- `GET /api/orders` — Authenticated customer order history.
- `GET /api/orders/{orderNumber}` — Detailed receipt, accepted licence versions, separate line-item fulfilment statuses, and background jobs.
- `POST /api/orders/{orderNumber}` — `{ "action": "retry_fulfilment" }` retries `failed_retryable` fulfilment jobs.
- `GET /api/library` — Customer entitlements, activation keys, published artefacts, SHA-256 checksums, documentation, and download history.
- `POST /api/library` — Issues a 10-minute HMAC-signed download URL only after verifying active entitlement ownership and `published` quarantine status.
- `GET /api/downloads/file?token=...` — Streams the verified `.zip` archive with `X-Checksum-Sha256` and logs the retrieval.

## Workshops, Stores & Support
- `GET /api/workshops` & `GET /api/workshops/{slug}` — Workshop sessions formatted in `Europe/London` (accurately distinguishing GMT vs BST) with real-time capacity minus active holds.
- `POST /api/workshops/{slug}` — Join workshop waiting list when full.
- `GET /api/stores` & `GET /api/stores/{slug}` — UK store directory, opening hours, collection instructions, and live per-store stock.
- `GET /api/support` & `POST /api/support` — Customer support ticket submission and lookup.

## Staff Administration Console (RBAC + TOTP MFA)
- `GET /api/auth/staff` & `POST /api/auth/staff` — First-run admin claim (generates TOTP secret) or staff sign-in (`ADMIN_PASSCODE` or password + TOTP MFA).
- `GET /api/admin/overview` — Aggregated orders, stock ledger, quarantined/published releases, entitlements, workshops, support queue, jobs, CMS, and audit logs.
- `POST /api/admin/actions` — Role-checked mutations:
  - `physical_action` (`pick`, `pack`, `ready_for_collection`, `collect`, `dispatch`, `return`)
  - `adjust_stock`
  - `issue_refund` (partial/full refund + entitlement revocation + VAT reversal audit)
  - `toggle_entitlement`
  - `publish_artefact` (promotes from `quarantined` to `published`)
  - `checkin_workshop`
  - `update_support_ticket`
  - `update_cms_homepage`
  - `run_workers` (releases expired holds & retries failed fulfilment jobs)
