import Link from 'next/link';
import { Code2 } from 'lucide-react';

export function SiteFooter() {
  return (
    <footer className="bg-[#111318] text-white/80 border-t border-white/10">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-white/10">
          <div className="space-y-3">
            <Link href="/" className="flex items-center gap-2 text-white font-display font-bold">
              <Code2 className="w-5 h-5 text-[#e90d7b]" aria-hidden="true" />
              <span>THE CODE EXCHANGE</span>
            </Link>
            <p className="text-sm text-white/65 leading-relaxed">
              Independent British retailer for creative software, source-code packages, coding starter kits, and in-store workshops.
            </p>
            <p className="text-xs text-white/50">
              Demonstration storefront: illustrative catalogue listings, sample pricing in GBP (VAT inclusive), and original sample archives.
            </p>
          </div>

          <div className="space-y-2.5">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-white">Shop</h2>
            <ul className="space-y-2 text-sm">
              <li><Link href="/catalogue" className="hover:text-white transition-colors">All software</Link></li>
              <li><Link href="/catalogue?source=1" className="hover:text-white transition-colors">Source-code editions</Link></li>
              <li><Link href="/catalogue?category=Learning" className="hover:text-white transition-colors">Coding starter kits</Link></li>
              <li><Link href="/workshops" className="hover:text-white transition-colors">Hands-on workshops</Link></li>
              <li><Link href="/stores" className="hover:text-white transition-colors">UK store directory</Link></li>
            </ul>
          </div>

          <div className="space-y-2.5">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-white">Customer Care</h2>
            <ul className="space-y-2 text-sm">
              <li><Link href="/library" className="hover:text-white transition-colors">My software & downloads</Link></li>
              <li><Link href="/account" className="hover:text-white transition-colors">Account & orders</Link></li>
              <li><Link href="/support" className="hover:text-white transition-colors">Support & helpdesk</Link></li>
              <li><Link href="/admin" className="hover:text-white transition-colors">Staff administration console</Link></li>
            </ul>
          </div>

          <div className="space-y-2.5">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-white">Policies & Licences</h2>
            <ul className="space-y-2 text-sm">
              <li><Link href="/policies/delivery" className="hover:text-white transition-colors">UK delivery & Click & Collect</Link></li>
              <li><Link href="/policies/returns" className="hover:text-white transition-colors">Returns & digital waivers</Link></li>
              <li><Link href="/policies/privacy" className="hover:text-white transition-colors">Privacy & UK GDPR</Link></li>
              <li><Link href="/policies/terms" className="hover:text-white transition-colors">Terms of sale</Link></li>
              <li><Link href="/licences/lic-personal-std" className="hover:text-white transition-colors">Standard workstation licence</Link></li>
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-white/55">
          <p>© {new Date().getFullYear()} The Code Exchange Ltd (Demonstration Retail Storefront). Prices in GBP inclusive of 20% UK VAT.</p>
          <p>Clerkenwell · Manchester · Edinburgh</p>
        </div>
      </div>
    </footer>
  );
}
