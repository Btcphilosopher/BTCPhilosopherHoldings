'use client';

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: string;
  mfaEnabled: boolean;
  mfaVerified: boolean;
}

export interface BasketItemView {
  id: string;
  itemType: 'edition' | 'workshop';
  editionId: string | null;
  workshopId: string | null;
  productSlug: string | null;
  workshopSlug: string | null;
  title: string;
  editionName: string;
  sku: string;
  imageUrl: string;
  fulfilmentChoice: 'digital' | 'delivery' | 'collect' | 'workshop';
  storeId: string | null;
  storeName: string | null;
  requiresShipping: boolean;
  quantity: number;
  unitPricePence: number;
  lineTotalPence: number;
  licenceId: string | null;
  licenceCode: string | null;
  licenceVersion: string | null;
  licenceTitle: string | null;
  holdId: string | null;
  holdExpiresAt: string | null;
  workshopTime: {
    dateLabel: string;
    timeLabel: string;
    tzAbbrev: string;
    fullLabel: string;
  } | null;
}

export interface BasketSnapshotView {
  basketId: string;
  items: BasketItemView[];
  totals: {
    itemsGrossPence: number;
    itemsNetPence: number;
    discountPence: number;
    taxPence: number;
    deliveryPence: number;
    totalPence: number;
    currency: 'GBP';
    appliedDiscountCode: string | null;
    requiresShippingAddress: boolean;
    hasDigitalItems: boolean;
    freeDeliveryThresholdPence: number;
  };
}

interface StoreContextValue {
  user: SessionUser | null;
  basket: BasketSnapshotView | null;
  toast: string | null;
  setToast: (msg: string | null) => void;
  refreshUser: () => Promise<void>;
  refreshBasket: () => Promise<void>;
  addEditionToBasket: (
    editionId: string,
    quantity?: number,
    fulfilmentChoice?: 'digital' | 'delivery' | 'collect',
    storeId?: string | null
  ) => Promise<boolean>;
  reserveWorkshopSeat: (workshopId: string, seats?: number) => Promise<boolean>;
  updateBasketItem: (payload: Record<string, unknown>) => Promise<boolean>;
  removeBasketItem: (itemId: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const StoreContext = createContext<StoreContextValue | undefined>(undefined);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [basket, setBasket] = useState<BasketSnapshotView | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast((curr) => (curr === msg ? null : curr));
    }, 4500);
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/session', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user || null);
      }
    } catch {
      // ignore
    }
  }, []);

  const refreshBasket = useCallback(async () => {
    try {
      const res = await fetch('/api/basket', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        setBasket(data);
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/auth/session', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setUser(data.user || null);
      })
      .catch(() => {});
    fetch('/api/basket', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data) setBasket(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  const addEditionToBasket = useCallback(
    async (
      editionId: string,
      quantity = 1,
      fulfilmentChoice?: 'digital' | 'delivery' | 'collect',
      storeId?: string | null
    ) => {
      const res = await fetch('/api/basket', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({
          itemType: 'edition',
          editionId,
          quantity,
          fulfilmentChoice,
          storeId,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || 'Could not add item to basket.');
        return false;
      }
      setBasket(data);
      showToast('Added to your basket.');
      return true;
    },
    [showToast]
  );

  const reserveWorkshopSeat = useCallback(
    async (workshopId: string, seats = 1) => {
      const res = await fetch('/api/basket', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({
          itemType: 'workshop',
          workshopId,
          seats,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || 'Could not reserve workshop seat.');
        return false;
      }
      setBasket(data);
      showToast('Workshop place held for 15 minutes in your basket.');
      return true;
    },
    [showToast]
  );

  const updateBasketItem = useCallback(
    async (payload: Record<string, unknown>) => {
      const res = await fetch('/api/basket', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || 'Could not update basket.');
        return false;
      }
      setBasket(data);
      return true;
    },
    [showToast]
  );

  const removeBasketItem = useCallback(async (itemId: string) => {
    const res = await fetch(`/api/basket?itemId=${encodeURIComponent(itemId)}`, {
      method: 'DELETE',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
    });
    if (res.ok) {
      const data = await res.json();
      setBasket(data);
    }
  }, []);

  const signOut = useCallback(async () => {
    await fetch('/api/auth/session', {
      method: 'DELETE',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
    });
    setUser(null);
    showToast('Signed out.');
  }, [showToast]);

  return (
    <StoreContext.Provider
      value={{
        user,
        basket,
        toast,
        setToast,
        refreshUser,
        refreshBasket,
        addEditionToBasket,
        reserveWorkshopSeat,
        updateBasketItem,
        removeBasketItem,
        signOut,
      }}
    >
      {children}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 max-w-sm rounded-lg bg-[#111318] text-white px-4 py-3 text-sm font-medium shadow-xl border border-white/15 flex items-center justify-between gap-4"
        >
          <span>{toast}</span>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="text-xs text-white/70 hover:text-white underline shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
