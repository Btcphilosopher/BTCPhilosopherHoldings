'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Code2, Search, User, ShoppingBag, Menu, X } from 'lucide-react';
import { useStore } from './StoreProvider';

export function SiteHeader() {
  const router = useRouter();
  const { user, basket } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);

  const itemCount =
    basket?.items.reduce((sum, item) => sum + (item.quantity || 1), 0) || 0;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchTerm.trim();
    router.push(q ? `/catalogue?q=${encodeURIComponent(q)}` : '/catalogue');
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#111318] text-white border-b border-white/10">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <Link
          href="/"
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#e90d7b] rounded-sm"
        >
          <Code2 className="w-6 h-6 text-[#e90d7b] shrink-0" aria-hidden="true" />
          <span className="font-display font-extrabold tracking-tight text-base sm:text-lg text-white">
            THE CODE EXCHANGE
          </span>
        </Link>

        {/* Zone 2: Navigation Links (5 concise single-line links) */}
        <nav
          aria-label="Primary navigation"
          className="hidden lg:flex items-center gap-6 text-sm font-medium text-white/85"
        >
          <Link
            href="/catalogue"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#e90d7b]"
          >
            Software
          </Link>
          <Link
            href="/catalogue?source=1"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#e90d7b]"
          >
            Source Code
          </Link>
          <Link
            href="/catalogue?category=Learning"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#e90d7b]"
          >
            Starter Kits
          </Link>
          <Link
            href="/workshops"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#e90d7b]"
          >
            Learn
          </Link>
          <Link
            href="/stores"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#e90d7b]"
          >
            Our Stores
          </Link>
        </nav>

        {/* Zone 3: Search, Account & Basket Controls */}
        <div className="flex items-center gap-3 shrink-0">
          <form onSubmit={handleSearch} className="hidden md:flex items-center relative">
            <label htmlFor="header-search" className="sr-only">
              Find your next project
            </label>
            <Search
              className="w-4 h-4 text-[#4e535e] absolute left-3 pointer-events-none"
              aria-hidden="true"
            />
            <input
              id="header-search"
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Find your next project"
              className="w-52 xl:w-64 h-9 pl-9 pr-3 rounded-md bg-white text-sm text-[#14161b] placeholder:text-[#666b76] focus:outline-none focus:ring-2 focus:ring-[#e90d7b]"
            />
          </form>

          <Link
            href={user ? '/library' : '/account'}
            aria-label={user ? `Signed in as ${user.name}` : 'Account and sign in'}
            className="h-10 px-2.5 flex items-center gap-2 rounded-md text-white/90 hover:text-white hover:bg-white/10 transition-colors whitespace-nowrap shrink-0"
          >
            <User className="w-5 h-5" aria-hidden="true" />
            <span className="hidden xl:inline text-xs font-medium max-w-[110px] truncate">
              {user ? user.name.split(' ')[0] : 'Account'}
            </span>
          </Link>

          <Link
            href="/basket"
            aria-label={`Basket with ${itemCount} item${itemCount === 1 ? '' : 's'}`}
            className="h-10 px-2.5 flex items-center gap-1.5 rounded-md text-white/90 hover:text-white hover:bg-white/10 transition-colors whitespace-nowrap shrink-0 relative"
          >
            <ShoppingBag className="w-5 h-5" aria-hidden="true" />
            <span className="tabular-nums text-xs font-semibold px-1.5 py-0.5 rounded bg-[#d4006c] text-white min-w-[20px] text-center">
              {itemCount}
            </span>
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((o) => !o)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            className="lg:hidden h-10 w-10 flex items-center justify-center rounded-md text-white hover:bg-white/10"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#151820] px-4 py-4 space-y-4">
          <form onSubmit={handleSearch} className="flex items-center gap-2">
            <label htmlFor="mobile-search" className="sr-only">
              Find your next project
            </label>
            <input
              id="mobile-search"
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Find your next project"
              className="flex-1 h-11 px-3 rounded-md bg-white text-sm text-[#14161b] placeholder:text-[#666b76]"
            />
            <button
              type="submit"
              className="h-11 px-4 rounded-md bg-[#d4006c] text-white text-sm font-semibold"
            >
              Search
            </button>
          </form>
          <nav aria-label="Mobile navigation" className="grid grid-cols-2 gap-2 text-sm">
            <Link
              href="/catalogue"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-md bg-white/5 hover:bg-white/10"
            >
              Software
            </Link>
            <Link
              href="/catalogue?source=1"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-md bg-white/5 hover:bg-white/10"
            >
              Source Code
            </Link>
            <Link
              href="/catalogue?category=Learning"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-md bg-white/5 hover:bg-white/10"
            >
              Starter Kits
            </Link>
            <Link
              href="/workshops"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-md bg-white/5 hover:bg-white/10"
            >
              Learn & Workshops
            </Link>
            <Link
              href="/stores"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-md bg-white/5 hover:bg-white/10"
            >
              Our Stores
            </Link>
            <Link
              href="/library"
              onClick={() => setMobileOpen(false)}
              className="px-3 py-2.5 rounded-md bg-white/5 hover:bg-white/10"
            >
              My Library
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
