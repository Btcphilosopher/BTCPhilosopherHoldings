'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'motion/react';
import { ChevronRight, FileCheck2, Code2, Store } from 'lucide-react';
import { formatGBP } from '@/lib/format';

export interface HomeProductCard {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  category: string;
  imageUrl: string;
  minPricePence: number;
  sourceIncluded: boolean;
}

export interface HomepageCms {
  heroHeadlineTop: string;
  heroHeadlineAccent: string;
  heroSubheading: string;
  workshopHeadline: string;
  workshopSubheading: string;
  featuredTitle: string;
  demoNotice: string;
}

const CATEGORY_TABS = ['All', 'Creative', 'Developer tools', 'Business', 'Learning'] as const;

export function HomeShowcase({
  products,
  cms,
}: {
  products: HomeProductCard[];
  cms: HomepageCms;
}) {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const filtered =
    activeCategory === 'All'
      ? products.slice(0, 4)
      : products.filter((p) => p.category.toLowerCase() === activeCategory.toLowerCase());

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-[#111318] text-white overflow-hidden">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 relative min-h-[380px] lg:min-h-[420px] flex items-center">
          {/* Background Stage Image on Desktop */}
          <div className="hidden lg:block absolute right-0 top-0 bottom-0 w-[64%] pointer-events-none">
            <Image
              src="/images/hero-stage.png"
              alt="Aureom Animate 3D, London Cipher, StudioWorks, Starter Kits boxes and Aureom USB Edition"
              fill
              priority
              sizes="(min-width: 1024px) 64vw, 100vw"
              className="object-cover object-right"
              referrerPolicy="no-referrer"
            />
            <div
              aria-hidden="true"
              className="absolute inset-0 bg-gradient-to-r from-[#111318] via-[#111318]/45 to-transparent"
            />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="relative z-10 py-12 lg:py-16 max-w-xl space-y-5"
          >
            <h1 className="font-display font-extrabold tracking-tight leading-[1.02] text-4xl sm:text-5xl lg:text-[54px] text-balance">
              <span className="block text-white">{cms.heroHeadlineTop}</span>
              <span className="block text-[#e90d7b]">{cms.heroHeadlineAccent}</span>
            </h1>

            <p className="text-base sm:text-lg text-white/90 max-w-md leading-relaxed">
              {cms.heroSubheading}
            </p>

            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <Link
                href="/catalogue"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white font-semibold text-sm transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-white"
              >
                <span>Explore software</span>
                <ChevronRight className="w-4 h-4" aria-hidden="true" />
              </Link>
              <Link
                href="/workshops"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-white/40 hover:bg-white/10 text-white font-semibold text-sm transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#e90d7b]"
              >
                <span>Find a workshop</span>
                <ChevronRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            </div>

            {/* Mobile Hero Visual */}
            <div className="lg:hidden relative mt-6 h-48 sm:h-60 rounded-lg overflow-hidden border border-white/10">
              <Image
                src="/images/hero-stage.png"
                alt="The Code Exchange boxed editions and USB collector drive"
                fill
                sizes="100vw"
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
        </div>

        {/* Trust Strip */}
        <div className="bg-[#171a21] border-t border-white/10">
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-3.5 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-0 text-sm text-white/90">
            <div className="flex items-center sm:justify-center gap-2.5 sm:border-r sm:border-white/10">
              <FileCheck2 className="w-4 h-4 text-[#e90d7b] shrink-0" aria-hidden="true" />
              <span>Clear licence terms</span>
            </div>
            <div className="flex items-center sm:justify-center gap-2.5 sm:border-r sm:border-white/10">
              <Code2 className="w-4 h-4 text-[#e90d7b] shrink-0" aria-hidden="true" />
              <span>Source included where listed</span>
            </div>
            <div className="flex items-center sm:justify-center gap-2.5">
              <Store className="w-4 h-4 text-[#e90d7b] shrink-0" aria-hidden="true" />
              <span>Online &amp; in store</span>
            </div>
          </div>
        </div>
      </section>

      {/* Warm Ivory Featured Catalogue Shelf */}
      <section className="bg-[#f6f2ec] py-10 sm:py-12">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h2 className="font-display font-bold text-2xl sm:text-[32px] tracking-tight text-[#14161b]">
                {cms.featuredTitle}
              </h2>
              <p className="text-xs text-[#4e535e] mt-1">{cms.demoNotice}</p>
            </div>

            <div
              role="tablist"
              aria-label="Filter featured software by category"
              className="flex flex-wrap items-center gap-2"
            >
              {CATEGORY_TABS.map((tab) => {
                const isActive = activeCategory === tab;
                return (
                  <button
                    key={tab}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setActiveCategory(tab)}
                    className={`px-4 py-2 rounded-md text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      isActive
                        ? 'bg-[#d4006c] text-white'
                        : 'bg-[#ebe6de] text-[#14161b] hover:bg-[#e1dbd0]'
                    }`}
                  >
                    {tab}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
            {filtered.map((item) => (
              <Link
                key={item.id}
                href={`/products/${item.slug}`}
                className="group bg-white border border-[#e4ded4] rounded-lg p-4 flex items-center gap-4 hover:-translate-y-0.5 hover:shadow-md transition-all focus-visible:outline-2 focus-visible:outline-[#d4006c]"
              >
                <div className="relative w-24 h-28 sm:w-28 sm:h-32 shrink-0 rounded bg-[#faf8f5] overflow-hidden">
                  <Image
                    src={item.imageUrl}
                    alt={`${item.title} boxed software edition`}
                    fill
                    sizes="120px"
                    className="object-contain p-1"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="min-w-0 flex-1 flex flex-col justify-between h-full py-0.5">
                  <div>
                    <h3 className="font-display font-bold text-base text-[#14161b] group-hover:text-[#d4006c] transition-colors leading-snug">
                      {item.title}
                    </h3>
                    <p className="text-xs text-[#4e535e] mt-1.5 line-clamp-3 leading-relaxed">
                      {item.subtitle}
                    </p>
                  </div>
                  <div className="mt-3 pt-2 flex flex-col gap-1">
                    <span className="font-display font-extrabold text-xl text-[#14161b] tabular-nums">
                      {formatGBP(item.minPricePence)}
                    </span>
                    <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-[#c80064] group-hover:underline">
                      <span>View details</span>
                      <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="flex justify-end">
            <Link
              href="/catalogue"
              className="inline-flex items-center gap-1 text-sm font-semibold text-[#14161b] hover:text-[#d4006c] transition-colors"
            >
              <span>Browse full catalogue &amp; filters</span>
              <ChevronRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      {/* Bottom Workshop Banner */}
      <section className="bg-[#141925] text-white border-t border-white/10">
        <div className="max-w-[1280px] mx-auto grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-6 relative min-h-[200px] sm:min-h-[240px]">
            <Image
              src="/images/workshop-banner.png"
              alt="Instructor leading a live FastAPI coding workshop at The Code Exchange"
              fill
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="lg:col-span-6 px-6 sm:px-10 py-8 sm:py-10 flex flex-col justify-center space-y-4">
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl tracking-tight leading-tight text-balance">
              {cms.workshopHeadline.includes('FIRST APP') ? (
                <>
                  <span>{cms.workshopHeadline.replace('FIRST APP', '')}</span>
                  <span className="text-[#e90d7b]">FIRST APP</span>
                </>
              ) : (
                cms.workshopHeadline
              )}
            </h2>
            <p className="text-sm sm:text-base text-white/85 max-w-lg leading-relaxed">
              {cms.workshopSubheading}
            </p>
            <div>
              <Link
                href="/workshops"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white font-semibold text-sm transition-colors whitespace-nowrap"
              >
                <span>Discover workshops</span>
                <ChevronRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
