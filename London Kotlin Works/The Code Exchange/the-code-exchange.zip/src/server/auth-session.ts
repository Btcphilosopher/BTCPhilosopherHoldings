import crypto from 'node:crypto';
import type { NextRequest } from 'next/server';
import type { DatabaseSync } from 'node:sqlite';
import { getDb } from './db.ts';
import {
  BASKET_COOKIE_NAME,
  SESSION_COOKIE_NAME,
  generateOpaqueToken,
  generateTotpCode,
  generateTotpSecret,
  hashPassword,
  hashToken,
  verifyPassword,
  verifyTotpCode,
} from './security.ts';

export type StaffRole =
  | 'customer'
  | 'catalogue_editor'
  | 'warehouse_staff'
  | 'workshop_organiser'
  | 'support'
  | 'finance'
  | 'admin';

export const STAFF_ROLES: StaffRole[] = [
  'catalogue_editor',
  'warehouse_staff',
  'workshop_organiser',
  'support',
  'finance',
  'admin',
];

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: StaffRole;
  mfaEnabled: boolean;
  mfaVerified: boolean;
}

export function getSessionFromRequest(req: NextRequest): AuthUser | null {
  const db = getDb();
  let rawToken = '';

  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    rawToken = authHeader.slice(7).trim();
  }
  if (!rawToken) {
    rawToken = req.cookies.get(SESSION_COOKIE_NAME)?.value || '';
    if (rawToken) {
      try {
        rawToken = decodeURIComponent(rawToken);
      } catch {
        // ignore
      }
    }
  }
  if (!rawToken) return null;

  const tokenHash = hashToken(rawToken);
  const nowIso = new Date().toISOString();
  const row = db
    .prepare(
      `SELECT s.user_id, s.role, s.mfa_verified, s.expires_at, u.email, u.name, u.mfa_enabled
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ? AND s.expires_at > ?`
    )
    .get(tokenHash, nowIso) as
    | {
        user_id: string;
        role: StaffRole;
        mfa_verified: number;
        expires_at: string;
        email: string;
        name: string;
        mfa_enabled: number;
      }
    | undefined;

  if (!row) return null;
  return {
    id: row.user_id,
    email: row.email,
    name: row.name,
    role: row.role,
    mfaEnabled: Boolean(row.mfa_enabled),
    mfaVerified: Boolean(row.mfa_verified),
  };
}

export function createSessionForUser(
  db: DatabaseSync,
  userId: string,
  role: StaffRole,
  mfaVerified: boolean
): string {
  const rawToken = generateOpaqueToken();
  const tokenHash = hashToken(rawToken);
  const now = new Date();
  const expires = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString();

  db.prepare(
    `INSERT INTO sessions (token_hash, user_id, role, mfa_verified, expires_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(tokenHash, userId, role, mfaVerified ? 1 : 0, expires, now.toISOString());

  return rawToken;
}

export function deleteSessionByRequest(req: NextRequest) {
  const db = getDb();
  let rawToken = req.cookies.get(SESSION_COOKIE_NAME)?.value || '';
  const authHeader = req.headers.get('authorization');
  if (authHeader?.startsWith('Bearer ')) {
    rawToken = authHeader.slice(7).trim();
  }
  if (!rawToken) return;
  try {
    rawToken = decodeURIComponent(rawToken);
  } catch {
    // ignore
  }
  const tokenHash = hashToken(rawToken);
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
}

export function getOrCreateBasketId(req: NextRequest): { basketId: string; isNew: boolean } {
  const db = getDb();
  const existingCookie = req.cookies.get(BASKET_COOKIE_NAME)?.value;
  if (existingCookie) {
    const found = db.prepare('SELECT id FROM baskets WHERE id = ?').get(existingCookie) as
      | { id: string }
      | undefined;
    if (found) {
      return { basketId: found.id, isNew: false };
    }
  }
  const basketId = `bsk-${crypto.randomUUID()}`;
  const now = new Date().toISOString();
  const user = getSessionFromRequest(req);
  db.prepare(
    `INSERT INTO baskets (id, user_id, discount_code, created_at, updated_at)
     VALUES (?, ?, NULL, ?, ?)`
  ).run(basketId, user?.id || null, now, now);
  return { basketId, isNew: true };
}

export function isStaffConfigured(db: DatabaseSync): {
  envPasscodeConfigured: boolean;
  claimedAdminExists: boolean;
} {
  const envPasscodeConfigured = Boolean(
    process.env.ADMIN_PASSCODE && process.env.ADMIN_PASSCODE.trim().length > 0
  );
  const adminRow = db
    .prepare(`SELECT id FROM users WHERE role = 'admin' LIMIT 1`)
    .get() as { id: string } | undefined;
  return {
    envPasscodeConfigured,
    claimedAdminExists: Boolean(adminRow),
  };
}

export function bootstrapFirstAdmin(
  db: DatabaseSync,
  email: string,
  name: string,
  password: string
): {
  userId: string;
  totpSecret: string;
  currentTotpCode: string;
} {
  const status = isStaffConfigured(db);
  if (status.envPasscodeConfigured || status.claimedAdminExists) {
    throw new Error('Staff administrator is already configured.');
  }
  if (password.length < 8) {
    throw new Error('Administrator password must be at least 8 characters.');
  }
  const now = new Date().toISOString();
  const userId = `user-admin-${crypto.randomUUID().slice(0, 8)}`;
  const totpSecret = generateTotpSecret();

  db.prepare(
    `INSERT INTO users (id, email, name, password_hash, role, mfa_secret, mfa_enabled, created_at)
     VALUES (?, ?, ?, ?, 'admin', ?, 1, ?)`
  ).run(userId, email.toLowerCase().trim(), name.trim(), hashPassword(password), totpSecret, now);

  db.prepare(
    `INSERT INTO audit_logs (id, actor_id, actor_email, actor_role, action, target_type, target_id, details_json, created_at)
     VALUES (?, ?, ?, 'admin', 'staff.admin_claimed', 'user', ?, ?, ?)`
  ).run(
    `aud-${crypto.randomUUID().slice(0, 8)}`,
    userId,
    email.toLowerCase().trim(),
    userId,
    JSON.stringify({ mfaEnabled: true }),
    now
  );

  return {
    userId,
    totpSecret,
    currentTotpCode: generateTotpCode(totpSecret),
  };
}

export function verifyStaffCredentials(
  db: DatabaseSync,
  email: string,
  password: string,
  totpCode?: string
): {
  user: { id: string; email: string; name: string; role: StaffRole; mfaEnabled: boolean };
  mfaVerified: boolean;
} {
  const envPass = process.env.ADMIN_PASSCODE?.trim();
  const cleanEmail = email.toLowerCase().trim();
  const userRow = db
    .prepare(
      `SELECT id, email, name, password_hash, role, mfa_secret, mfa_enabled
       FROM users WHERE email = ?`
    )
    .get(cleanEmail) as
    | {
        id: string;
        email: string;
        name: string;
        password_hash: string;
        role: StaffRole;
        mfa_secret: string | null;
        mfa_enabled: number;
      }
    | undefined;

  if (envPass) {
    // Timing-safe comparison against configured ADMIN_PASSCODE
    const a = Buffer.from(password);
    const b = Buffer.from(envPass);
    const match = a.length === b.length && crypto.timingSafeEqual(a, b);
    if (match) {
      if (!userRow) {
        const now = new Date().toISOString();
        const newId = `user-env-admin-${crypto.randomUUID().slice(0, 8)}`;
        const totpSecret = generateTotpSecret();
        db.prepare(
          `INSERT INTO users (id, email, name, password_hash, role, mfa_secret, mfa_enabled, created_at)
           VALUES (?, ?, ?, ?, 'admin', ?, 0, ?)`
        ).run(newId, cleanEmail || 'admin@codeexchange.co.uk', 'Store Administrator', hashPassword(envPass), totpSecret, now);
        return {
          user: {
            id: newId,
            email: cleanEmail || 'admin@codeexchange.co.uk',
            name: 'Store Administrator',
            role: 'admin',
            mfaEnabled: false,
          },
          mfaVerified: true,
        };
      }
      return {
        user: {
          id: userRow.id,
          email: userRow.email,
          name: userRow.name,
          role: userRow.role === 'customer' ? 'admin' : userRow.role,
          mfaEnabled: Boolean(userRow.mfa_enabled),
        },
        mfaVerified: true,
      };
    }
  }

  if (!userRow || !STAFF_ROLES.includes(userRow.role)) {
    throw new Error('Invalid staff credentials.');
  }
  if (!verifyPassword(password, userRow.password_hash)) {
    throw new Error('Invalid staff credentials.');
  }

  let mfaVerified = !userRow.mfa_enabled;
  if (userRow.mfa_enabled && userRow.mfa_secret) {
    if (!totpCode || !verifyTotpCode(userRow.mfa_secret, totpCode)) {
      throw new Error('Valid 6-digit MFA authenticator code is required.');
    }
    mfaVerified = true;
  }

  return {
    user: {
      id: userRow.id,
      email: userRow.email,
      name: userRow.name,
      role: userRow.role,
      mfaEnabled: Boolean(userRow.mfa_enabled),
    },
    mfaVerified,
  };
}

export function requireStaffRole(
  user: AuthUser | null,
  allowedRoles: StaffRole[]
): asserts user is AuthUser {
  if (!user) {
    throw new Error('UNAUTHORIZED');
  }
  if (user.role === 'admin' && user.mfaVerified) {
    return;
  }
  if (!allowedRoles.includes(user.role)) {
    throw new Error('FORBIDDEN');
  }
  if (user.mfaEnabled && !user.mfaVerified) {
    throw new Error('MFA_REQUIRED');
  }
}
