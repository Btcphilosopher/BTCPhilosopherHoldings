import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import type { DatabaseSync } from 'node:sqlite';

const require = createRequire(import.meta.url);

export function getDataDir(): string {
  const dir = process.env.DATA_DIR || '/tmp/code-exchange-data';
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function getArtefactStorageDir(): string {
  const dir = path.join(getDataDir(), 'artefacts');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

const globalForDb = globalThis as unknown as {
  __cxDb?: DatabaseSync;
  __cxSeeded?: boolean;
};

export function initSchema(db: DatabaseSync) {
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'customer',
      mfa_secret TEXT,
      mfa_enabled INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role TEXT NOT NULL,
      mfa_verified INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS stores (
      id TEXT PRIMARY KEY,
      slug TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      address_line TEXT NOT NULL,
      city TEXT NOT NULL,
      postcode TEXT NOT NULL,
      phone TEXT NOT NULL,
      opening_hours_json TEXT NOT NULL,
      collection_instructions TEXT NOT NULL,
      stock_updated_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS licences (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL,
      title TEXT NOT NULL,
      version TEXT NOT NULL,
      summary TEXT NOT NULL,
      full_text TEXT NOT NULL,
      redistributable_source INTEGER NOT NULL DEFAULT 0,
      commercial_use INTEGER NOT NULL DEFAULT 1,
      seat_limit INTEGER NOT NULL DEFAULT 1,
      effective_date TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      slug TEXT NOT NULL UNIQUE,
      sku_prefix TEXT NOT NULL,
      title TEXT NOT NULL,
      subtitle TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL,
      publisher TEXT NOT NULL,
      platforms_json TEXT NOT NULL,
      languages_json TEXT NOT NULL,
      requirements_json TEXT NOT NULL,
      release_version TEXT NOT NULL,
      source_included INTEGER NOT NULL DEFAULT 0,
      update_entitlement TEXT NOT NULL,
      third_party_notices TEXT NOT NULL,
      documentation_markdown TEXT NOT NULL,
      image_url TEXT NOT NULL,
      screenshots_json TEXT NOT NULL,
      related_slugs_json TEXT NOT NULL,
      featured_order INTEGER NOT NULL DEFAULT 99,
      is_demo_listing INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS editions (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      sku TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      edition_type TEXT NOT NULL,
      delivery_method TEXT NOT NULL,
      price_pence INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'GBP',
      vat_rate_bps INTEGER NOT NULL DEFAULT 2000,
      licence_id TEXT NOT NULL REFERENCES licences(id),
      includes_json TEXT NOT NULL,
      physical_contents_note TEXT NOT NULL,
      requires_shipping INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS release_artefacts (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      edition_id TEXT REFERENCES editions(id) ON DELETE SET NULL,
      version TEXT NOT NULL,
      filename TEXT NOT NULL,
      platform TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      sha256 TEXT NOT NULL,
      release_notes TEXT NOT NULL,
      quarantine_status TEXT NOT NULL DEFAULT 'quarantined',
      scan_report TEXT NOT NULL DEFAULT '',
      storage_key TEXT NOT NULL,
      published_at TEXT
    );

    CREATE TABLE IF NOT EXISTS stock_locations (
      id TEXT PRIMARY KEY,
      edition_id TEXT NOT NULL REFERENCES editions(id) ON DELETE CASCADE,
      store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
      on_hand INTEGER NOT NULL DEFAULT 0,
      reserved INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL,
      UNIQUE(edition_id, store_id)
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
      id TEXT PRIMARY KEY,
      edition_id TEXT NOT NULL REFERENCES editions(id) ON DELETE CASCADE,
      store_id TEXT REFERENCES stores(id) ON DELETE SET NULL,
      delta INTEGER NOT NULL,
      reason TEXT NOT NULL,
      reference_id TEXT,
      actor_id TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workshops (
      id TEXT PRIMARY KEY,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      subtitle TEXT NOT NULL,
      description TEXT NOT NULL,
      instructor TEXT NOT NULL,
      level TEXT NOT NULL,
      prerequisites TEXT NOT NULL,
      format TEXT NOT NULL,
      store_id TEXT REFERENCES stores(id) ON DELETE SET NULL,
      venue_label TEXT NOT NULL,
      starts_at_utc TEXT NOT NULL,
      ends_at_utc TEXT NOT NULL,
      display_timezone TEXT NOT NULL DEFAULT 'Europe/London',
      capacity INTEGER NOT NULL,
      price_pence INTEGER NOT NULL,
      required_equipment TEXT NOT NULL,
      accessibility_info TEXT NOT NULL,
      cancellation_terms TEXT NOT NULL,
      image_url TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workshop_holds (
      id TEXT PRIMARY KEY,
      workshop_id TEXT NOT NULL REFERENCES workshops(id) ON DELETE CASCADE,
      basket_id TEXT NOT NULL,
      user_id TEXT,
      seats INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'active',
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workshop_bookings (
      id TEXT PRIMARY KEY,
      workshop_id TEXT NOT NULL REFERENCES workshops(id) ON DELETE CASCADE,
      order_id TEXT NOT NULL,
      user_id TEXT,
      attendee_name TEXT NOT NULL,
      attendee_email TEXT NOT NULL,
      seats INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'confirmed',
      checked_in_at TEXT,
      notification_status TEXT NOT NULL DEFAULT 'queued',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workshop_waitlist (
      id TEXT PRIMARY KEY,
      workshop_id TEXT NOT NULL REFERENCES workshops(id) ON DELETE CASCADE,
      email TEXT NOT NULL,
      name TEXT NOT NULL,
      seats INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS baskets (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      discount_code TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS basket_items (
      id TEXT PRIMARY KEY,
      basket_id TEXT NOT NULL REFERENCES baskets(id) ON DELETE CASCADE,
      item_type TEXT NOT NULL,
      edition_id TEXT REFERENCES editions(id) ON DELETE CASCADE,
      workshop_id TEXT REFERENCES workshops(id) ON DELETE CASCADE,
      fulfilment_choice TEXT NOT NULL,
      store_id TEXT REFERENCES stores(id) ON DELETE SET NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      hold_id TEXT REFERENCES workshop_holds(id) ON DELETE SET NULL,
      unit_price_pence INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      order_number TEXT NOT NULL UNIQUE,
      user_id TEXT,
      customer_email TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      status TEXT NOT NULL,
      subtotal_net_pence INTEGER NOT NULL,
      discount_pence INTEGER NOT NULL DEFAULT 0,
      vat_pence INTEGER NOT NULL,
      delivery_pence INTEGER NOT NULL DEFAULT 0,
      total_pence INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'GBP',
      shipping_address_json TEXT,
      terms_accepted_at TEXT NOT NULL,
      digital_waiver_accepted_at TEXT,
      accepted_licence_versions_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      item_type TEXT NOT NULL,
      edition_id TEXT REFERENCES editions(id) ON DELETE SET NULL,
      workshop_id TEXT REFERENCES workshops(id) ON DELETE SET NULL,
      title TEXT NOT NULL,
      edition_name TEXT NOT NULL,
      sku TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_price_pence INTEGER NOT NULL,
      line_total_pence INTEGER NOT NULL,
      fulfilment_method TEXT NOT NULL,
      fulfilment_status TEXT NOT NULL,
      store_id TEXT REFERENCES stores(id) ON DELETE SET NULL,
      licence_id TEXT,
      licence_version TEXT,
      refunded_quantity INTEGER NOT NULL DEFAULT 0,
      refunded_pence INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS payment_intents (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      idempotency_key TEXT NOT NULL UNIQUE,
      provider TEXT NOT NULL,
      provider_ref TEXT NOT NULL,
      amount_pence INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'GBP',
      status TEXT NOT NULL,
      webhook_event_ids_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS entitlements (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      customer_email TEXT NOT NULL,
      order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      order_item_id TEXT NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
      product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      edition_id TEXT NOT NULL REFERENCES editions(id) ON DELETE CASCADE,
      licence_id TEXT NOT NULL REFERENCES licences(id),
      licence_version TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      activation_key TEXT NOT NULL,
      granted_at TEXT NOT NULL,
      revoked_at TEXT
    );

    CREATE TABLE IF NOT EXISTS download_logs (
      id TEXT PRIMARY KEY,
      entitlement_id TEXT NOT NULL REFERENCES entitlements(id) ON DELETE CASCADE,
      artefact_id TEXT NOT NULL REFERENCES release_artefacts(id) ON DELETE CASCADE,
      user_id TEXT,
      downloaded_at TEXT NOT NULL,
      ip_hint TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS fulfilment_jobs (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      job_type TEXT NOT NULL,
      status TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      simulate_fail_once INTEGER NOT NULL DEFAULT 0,
      last_error TEXT,
      payload_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS email_outbox (
      id TEXT PRIMARY KEY,
      recipient TEXT NOT NULL,
      subject TEXT NOT NULL,
      template TEXT NOT NULL,
      status TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS refunds (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      order_item_id TEXT REFERENCES order_items(id) ON DELETE SET NULL,
      amount_pence INTEGER NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL,
      actor_id TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS support_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      email TEXT NOT NULL,
      name TEXT NOT NULL,
      order_number TEXT,
      topic TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      staff_notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cms_blocks (
      key TEXT PRIMARY KEY,
      value_json TEXT NOT NULL,
      updated_by TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT,
      actor_email TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      details_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);
}

export function getDb(customPath?: string): DatabaseSync {
  if (customPath) {
    const { DatabaseSync } = require('node:sqlite') as typeof import('node:sqlite');
    const db = new DatabaseSync(customPath);
    initSchema(db);
    return db;
  }

  if (!globalForDb.__cxDb) {
    const { DatabaseSync } = require('node:sqlite') as typeof import('node:sqlite');
    const dbPath = path.join(getDataDir(), 'code-exchange.db');
    const db = new DatabaseSync(dbPath);
    initSchema(db);
    globalForDb.__cxDb = db;
  }

  if (!globalForDb.__cxSeeded) {
    // Lazy import to avoid circularity during test DB setup
    const { seedDatabaseIfEmpty } = require('./seed.ts') as typeof import('./seed');
    seedDatabaseIfEmpty(globalForDb.__cxDb);
    globalForDb.__cxSeeded = true;
  }

  return globalForDb.__cxDb;
}
