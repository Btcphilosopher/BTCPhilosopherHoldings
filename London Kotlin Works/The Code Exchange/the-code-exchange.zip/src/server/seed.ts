import fs from 'node:fs';
import path from 'node:path';
import type { DatabaseSync } from 'node:sqlite';
import { getArtefactStorageDir } from './db.ts';
import { buildDeterministicZip } from './zip.ts';
import { hashPassword } from './security.ts';

function writeArtefactZip(storageKey: string, entries: { path: string; content: string }[]) {
  const { buffer, sha256, sizeBytes } = buildDeterministicZip(entries);
  const fullPath = path.resolve(getArtefactStorageDir(), storageKey);
  const baseDir = path.resolve(getArtefactStorageDir());
  if (!fullPath.startsWith(baseDir + path.sep)) {
    throw new Error('Invalid artefact storage path');
  }
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, buffer);
  return { sha256, sizeBytes };
}

export function seedDatabaseIfEmpty(db: DatabaseSync) {
  const countRow = db.prepare('SELECT COUNT(*) as c FROM products').get() as { c: number } | undefined;
  if (countRow && countRow.c > 0) {
    return;
  }

  const now = new Date().toISOString();

  // 1. Seed Licences
  const licences = [
    {
      id: 'lic-personal-std',
      code: 'CX-PERSONAL-1.2',
      title: 'The Code Exchange Personal & Commercial Workstation Licence',
      version: '1.2.0',
      summary:
        'Single named user across up to 2 workstations. Commercial output permitted. Binary redistribution prohibited.',
      full_text: `THE CODE EXCHANGE WORKSTATION LICENCE v1.2.0 (UK)

1. Grant of Licence: Upon confirmed payment, The Code Exchange Ltd grants the named Licensee a non-exclusive, perpetual licence to install and execute the Software on up to two (2) workstations owned or controlled by the Licensee.
2. Commercial Output: Creative works, compiled binaries, and exported assets produced using the Software may be used for personal or commercial projects without additional royalties.
3. Restrictions: You may not redistribute, sublicense, rent, lease, or publish the Software installer or activation keys. Technical download controls do not prevent copying after download; compliance remains a binding legal obligation.
4. Updates & Support: Includes 12 months of minor version updates and security patches from purchase date.
5. Statutory Rights: Nothing in this licence affects your statutory rights under the Consumer Rights Act 2015 (UK).`,
      redistributable_source: 0,
      commercial_use: 1,
      seat_limit: 1,
      effective_date: '2026-01-01',
    },
    {
      id: 'lic-source-eval',
      code: 'CX-SOURCE-1.4',
      title: 'The Code Exchange Source-Code Access & Custom Build Licence',
      version: '1.4.0',
      summary:
        'Includes readable source code for learning, auditing, and internal custom builds. No unrestricted redistribution or IP transfer.',
      full_text: `THE CODE EXCHANGE SOURCE-CODE ACCESS LICENCE v1.4.0 (UK)

1. Distinction of Deliverables: This edition provides access to demonstration or application source files alongside documentation and build scripts. Purchasing source access does NOT transfer ownership of copyright, trademarks, or underlying intellectual property.
2. Permitted Use: You may inspect, compile, modify, and deploy builds derived from the source package for your own internal projects or client bespoke deliveries as explicitly documented per product.
3. Non-Redistribution: You may NOT publish the raw source archive, mirror the repository publicly, or resell the source package as a competing toolkit or template.
4. Third-Party Notices: Included open-source dependencies retain their respective upstream licences (see THIRD_PARTY_NOTICES.txt inside the archive).`,
      redistributable_source: 0,
      commercial_use: 1,
      seat_limit: 5,
      effective_date: '2026-02-01',
    },
    {
      id: 'lic-starter-mit',
      code: 'CX-STARTER-1.0',
      title: 'The Code Exchange Starter Kit & Educational Licence',
      version: '1.0.0',
      summary:
        'Starter exercise templates are MIT-licensed for your projects; printed/PDF curriculum guides remain copyright The Code Exchange.',
      full_text: `THE CODE EXCHANGE STARTER KIT LICENCE v1.0.0 (UK)

1. Exercise Code Templates: All Python and web starter templates included in /templates are licensed under the permissive MIT Licence so you can build, share, and publish your own projects freely.
2. Curriculum & Reference Guides: Written handbooks, diagrams, and printed quick-reference cards are copyright © The Code Exchange Ltd and licensed for personal educational use only.
3. Classroom Use: For schools or team workshops, please purchase one seat or kit per learner.`,
      redistributable_source: 1,
      commercial_use: 1,
      seat_limit: 1,
      effective_date: '2026-01-15',
    },
  ];

  const insertLicence = db.prepare(`
    INSERT INTO licences (id, code, title, version, summary, full_text, redistributable_source, commercial_use, seat_limit, effective_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const lic of licences) {
    insertLicence.run(
      lic.id,
      lic.code,
      lic.title,
      lic.version,
      lic.summary,
      lic.full_text,
      lic.redistributable_source,
      lic.commercial_use,
      lic.seat_limit,
      lic.effective_date
    );
  }

  // 2. Seed UK Stores
  const stores = [
    {
      id: 'store-london',
      slug: 'london-clerkenwell',
      name: 'London — Clerkenwell Flagship',
      address_line: '42 St John Street, Clerkenwell',
      city: 'London',
      postcode: 'EC1M 4DL',
      phone: '+44 20 7946 0821',
      opening_hours_json: JSON.stringify({
        'Mon–Fri': '09:30 – 19:00',
        Saturday: '10:00 – 18:00',
        Sunday: '11:00 – 16:30',
      }),
      collection_instructions:
        'Bring your order number and photo ID to the Ground Floor Collections Desk (3 minutes from Barbican Underground). Click & Collect orders are held for 7 calendar days.',
      stock_updated_at: now,
    },
    {
      id: 'store-manchester',
      slug: 'manchester-northern-quarter',
      name: 'Manchester — Northern Quarter',
      address_line: '18 Tariff Street',
      city: 'Manchester',
      postcode: 'M1 2FF',
      phone: '+44 161 496 0412',
      opening_hours_json: JSON.stringify({
        'Mon–Fri': '10:00 – 18:30',
        Saturday: '10:00 – 18:00',
        Sunday: 'Closed',
      }),
      collection_instructions:
        'Collect from the Workshop & Boxed Counter at the rear of the shop (6 minutes from Manchester Piccadilly).',
      stock_updated_at: now,
    },
    {
      id: 'store-edinburgh',
      slug: 'edinburgh-new-town',
      name: 'Edinburgh — New Town',
      address_line: '91 George Street',
      city: 'Edinburgh',
      postcode: 'EH2 3ES',
      phone: '+44 131 496 0755',
      opening_hours_json: JSON.stringify({
        'Mon–Sat': '10:00 – 18:00',
        Sunday: '11:30 – 16:00',
      }),
      collection_instructions:
        'Present your confirmation QR/order code at the main George Street desk. Step-free lift access available to the Studio Classroom.',
      stock_updated_at: now,
    },
  ];

  const insertStore = db.prepare(`
    INSERT INTO stores (id, slug, name, address_line, city, postcode, phone, opening_hours_json, collection_instructions, stock_updated_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const s of stores) {
    insertStore.run(
      s.id,
      s.slug,
      s.name,
      s.address_line,
      s.city,
      s.postcode,
      s.phone,
      s.opening_hours_json,
      s.collection_instructions,
      s.stock_updated_at,
      now
    );
  }

  // 3. Seed Products & Editions
  const products = [
    {
      id: 'prod-aureom',
      slug: 'aureom-animate-3d',
      sku_prefix: 'AUR-3D',
      title: 'Aureom Animate 3D',
      subtitle: 'Professional 3D animation and motion design for creatives and developers.',
      description:
        'Illustrative demonstration catalogue listing for Aureom Animate 3D — a timeline-driven 3D motion, rigging, and Python-scriptable shader suite. Includes non-destructive scene graphs, USD/glTF interchange, and offline collector media options.',
      category: 'Creative',
      publisher: 'Aureom Studio Software Ltd (London)',
      platforms_json: JSON.stringify(['macOS', 'Windows', 'Linux']),
      languages_json: JSON.stringify(['Python', 'GLSL', 'C++']),
      requirements_json: JSON.stringify({
        OS: 'macOS 14+, Windows 11 64-bit, or Ubuntu 24.04 LTS',
        Memory: '16 GB RAM recommended (8 GB minimum)',
        Graphics: 'Vulkan 1.3 or Metal 3 compatible GPU with 4 GB VRAM',
        Storage: '3.2 GB free disk space',
      }),
      release_version: '2026.2.1-demo',
      source_included: 1,
      update_entitlement: '12 months of minor releases & security updates included',
      third_party_notices:
        'Demonstration bundle references open standards: glTF 2.0 schema (Apache-2.0), Python 3.12 C-API headers (PSF-2.0). Full attribution included inside THIRD_PARTY_NOTICES.txt.',
      documentation_markdown: `# Aureom Animate 3D — Demonstration Package Guide

> **Notice**: This is an illustrative retail catalogue demonstration package containing original sample scene-graph Python code and documentation—not a full commercial 3D suite binary.

## What is inside the demonstration archive
- \`README.md\` — Quick-start instructions and edition overview
- \`sample_scene_rig.py\` — Original procedural keyframe curve generator in Python
- \`shader_preset.glsl\` — Sample magenta/graphite studio rim-lighting fragment shader
- \`THIRD_PARTY_NOTICES.txt\` — Dependency licences and attribution

## Running the sample script
\`\`\`bash
python3 sample_scene_rig.py
\`\`\``,
      image_url: '/images/box-aureom.png',
      screenshots_json: JSON.stringify(['/images/box-aureom.png', '/images/usb-aureom.png']),
      related_slugs_json: JSON.stringify(['studioworks', 'camber-ui-kit']),
      featured_order: 1,
    },
    {
      id: 'prod-london-cipher',
      slug: 'london-cipher',
      sku_prefix: 'LON-CIP',
      title: 'London Cipher',
      subtitle: 'Secure development tools and a modern codebase for real-world applications.',
      description:
        'Illustrative demonstration listing for London Cipher — a developer security toolkit covering envelope encryption, deterministic audit trails, secret scanning, and verifiable release signing for Python and TypeScript services.',
      category: 'Developer tools',
      publisher: 'Thames Security Engineering Ltd',
      platforms_json: JSON.stringify(['macOS', 'Linux', 'Windows']),
      languages_json: JSON.stringify(['Python', 'TypeScript']),
      requirements_json: JSON.stringify({
        OS: 'macOS 13+, Linux x86_64/arm64, Windows 11 + WSL2',
        Runtime: 'Python 3.11+ or Node.js 20+',
        Memory: '2 GB RAM',
        Storage: '250 MB free disk space',
      }),
      release_version: '3.4.0-demo',
      source_included: 1,
      update_entitlement: '12 months of CVE advisory feeds & point releases',
      third_party_notices:
        'Demonstration sample uses standard-library cryptography primitives only (Python hashlib/hmac, Node crypto).',
      documentation_markdown: `# London Cipher — Demonstration Toolkit

> **Notice**: Illustrative catalogue demonstration download containing original sample HMAC verification and audit-log helpers.

## Contents
- \`cipher_verify.py\` — Original Python module demonstrating SHA-256 artefact verification and timing-safe HMAC checks
- \`LICENSE.txt\` — Copy of CX-SOURCE-1.4 terms
- \`THIRD_PARTY_NOTICES.txt\` — Attribution notice`,
      image_url: '/images/box-london-cipher.png',
      screenshots_json: JSON.stringify(['/images/box-london-cipher.png']),
      related_slugs_json: JSON.stringify(['thames-ledger', 'python-starter-kit']),
      featured_order: 2,
    },
    {
      id: 'prod-studioworks',
      slug: 'studioworks',
      sku_prefix: 'STW-PRO',
      title: 'StudioWorks',
      subtitle: 'A creative suite for design, code and media production in one powerful package.',
      description:
        'Illustrative demonstration listing for StudioWorks — combining vector layout, audio/timeline trimming, and programmable export pipelines in a unified desktop workspace.',
      category: 'Creative',
      publisher: 'StudioWorks Collective UK',
      platforms_json: JSON.stringify(['macOS', 'Windows']),
      languages_json: JSON.stringify(['JavaScript', 'Python']),
      requirements_json: JSON.stringify({
        OS: 'macOS 14+ or Windows 11',
        Memory: '8 GB RAM (16 GB for 4K export)',
        Display: '1920x1080 minimum',
        Storage: '1.8 GB free disk space',
      }),
      release_version: '4.1.0-demo',
      source_included: 0,
      update_entitlement: '12 months of StudioWorks 4.x updates',
      third_party_notices:
        'Sample export plugin uses standard JSON manifest schemas; no third-party binaries bundled.',
      documentation_markdown: `# StudioWorks — Demonstration Suite Guide

> **Notice**: Illustrative demonstration download containing original project-pipeline configuration examples and export plugin code.

## Contents
- \`pipeline_manifest.json\` — Sample multi-format export graph
- \`batch_export_demo.py\` — Original Python batch-renaming helper
- \`THIRD_PARTY_NOTICES.txt\` — Dependency notice`,
      image_url: '/images/box-studioworks.png',
      screenshots_json: JSON.stringify(['/images/box-studioworks.png']),
      related_slugs_json: JSON.stringify(['aureom-animate-3d', 'camber-ui-kit']),
      featured_order: 3,
    },
    {
      id: 'prod-python-kit',
      slug: 'python-starter-kit',
      sku_prefix: 'PY-KIT',
      title: 'Python Starter Kit',
      subtitle: 'Everything you need to start coding with Python — software, project files and a guided learning path.',
      description:
        'Illustrative demonstration listing for our flagship beginner starter kit. Pairs structured exercise projects, FastAPI mini-apps, and cheat-sheet cards with an optional boxed physical edition for gifting or classroom study.',
      category: 'Learning',
      publisher: 'The Code Exchange Press',
      platforms_json: JSON.stringify(['macOS', 'Windows', 'Linux']),
      languages_json: JSON.stringify(['Python']),
      requirements_json: JSON.stringify({
        OS: 'Any Windows 10/11, macOS 12+, or modern Linux distro',
        Runtime: 'Python 3.11 or newer',
        Storage: '120 MB free disk space',
      }),
      release_version: '2.0.0-demo',
      source_included: 1,
      update_entitlement: 'Lifetime access to v2.x exercise pack updates',
      third_party_notices:
        'Exercise templates are MIT licensed. Handbook prose is © The Code Exchange Ltd.',
      documentation_markdown: `# Python Starter Kit — Demonstration Exercise Pack

> **Notice**: Illustrative starter kit download containing working original beginner Python exercises and project templates.

## Included Modules
- \`01_hello_exchange.py\` — Interactive CLI currency & VAT calculator
- \`02_mini_api_demo.py\` — Minimal Python HTTP server example using stdlib \`http.server\`
- \`HANDBOOK_EXCERPT.md\` — Guided learning checklist`,
      image_url: '/images/box-python-kit.png',
      screenshots_json: JSON.stringify(['/images/box-python-kit.png']),
      related_slugs_json: JSON.stringify(['london-cipher', 'thames-ledger']),
      featured_order: 4,
    },
    {
      id: 'prod-thames-ledger',
      slug: 'thames-ledger',
      sku_prefix: 'THM-LDG',
      title: 'Thames Ledger',
      subtitle: 'Double-entry accounting and UK VAT calculation engine for small studios and makers.',
      description:
        'Illustrative demonstration listing for Thames Ledger — deterministic integer-pence accounting, UK VAT 20% splitting, CSV reconciliation, and optional FastAPI service source code.',
      category: 'Business',
      publisher: 'Fleet Street Financial Tools Ltd',
      platforms_json: JSON.stringify(['Linux', 'macOS', 'Windows']),
      languages_json: JSON.stringify(['Python', 'SQL']),
      requirements_json: JSON.stringify({
        Runtime: 'Python 3.11+ & PostgreSQL 15+ (or SQLite for local mode)',
        Memory: '1 GB RAM',
      }),
      release_version: '1.8.2-demo',
      source_included: 1,
      update_entitlement: 'Includes 2026/27 UK tax-year table updates',
      third_party_notices: 'Zero external runtime dependencies in the demonstration core.',
      documentation_markdown: `# Thames Ledger — Demonstration Core

> **Notice**: Illustrative demonstration download showing integer-pence double-entry posting rules in Python.`,
      image_url: '/images/box-london-cipher.png',
      screenshots_json: JSON.stringify(['/images/box-london-cipher.png']),
      related_slugs_json: JSON.stringify(['london-cipher', 'python-starter-kit']),
      featured_order: 5,
    },
    {
      id: 'prod-camber-ui',
      slug: 'camber-ui-kit',
      sku_prefix: 'CMB-UI',
      title: 'Camber UI Kit',
      subtitle: 'Accessible TypeScript & Tailwind retail components with documented source code.',
      description:
        'Illustrative demonstration listing for Camber UI Kit — keyboard-navigable product cards, checkout forms, and tabular order ledgers engineered for British e-commerce teams.',
      category: 'Developer tools',
      publisher: 'Camberwell Design Systems',
      platforms_json: JSON.stringify(['Web', 'macOS', 'Windows', 'Linux']),
      languages_json: JSON.stringify(['TypeScript']),
      requirements_json: JSON.stringify({
        Runtime: 'Node.js 20+, React 19+, Tailwind CSS 4+',
      }),
      release_version: '1.3.0-demo',
      source_included: 1,
      update_entitlement: '12 months of component updates',
      third_party_notices: 'Peer dependency: lucide-react (ISC Licence).',
      documentation_markdown: `# Camber UI Kit — Demonstration Source Package

> **Notice**: Illustrative source-code package containing an accessible TypeScript price formatter and keyboard-friendly stepper primitive.`,
      image_url: '/images/box-studioworks.png',
      screenshots_json: JSON.stringify(['/images/box-studioworks.png']),
      related_slugs_json: JSON.stringify(['aureom-animate-3d', 'studioworks']),
      featured_order: 6,
    },
  ];

  const insertProduct = db.prepare(`
    INSERT INTO products (
      id, slug, sku_prefix, title, subtitle, description, category, publisher,
      platforms_json, languages_json, requirements_json, release_version,
      source_included, update_entitlement, third_party_notices, documentation_markdown,
      image_url, screenshots_json, related_slugs_json, featured_order, is_demo_listing
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);
  for (const p of products) {
    insertProduct.run(
      p.id,
      p.slug,
      p.sku_prefix,
      p.title,
      p.subtitle,
      p.description,
      p.category,
      p.publisher,
      p.platforms_json,
      p.languages_json,
      p.requirements_json,
      p.release_version,
      p.source_included,
      p.update_entitlement,
      p.third_party_notices,
      p.documentation_markdown,
      p.image_url,
      p.screenshots_json,
      p.related_slugs_json,
      p.featured_order
    );
  }

  // 4. Seed Editions
  const editions = [
    // Aureom Animate 3D
    {
      id: 'ed-aureom-digital',
      product_id: 'prod-aureom',
      sku: 'AUR-3D-DIG',
      name: 'Digital Download',
      edition_type: 'digital_download',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 14900,
      licence_id: 'lic-personal-std',
      includes_json: JSON.stringify([
        'Demonstration ZIP archive & SHA-256 manifest',
        'Sample Python scene-rig & GLSL shader files',
        'Workstation activation key',
        'PDF Quick-Start & Documentation',
      ]),
      physical_contents_note: 'Digital delivery only — no physical parcel is shipped.',
      requires_shipping: 0,
    },
    {
      id: 'ed-aureom-boxed',
      product_id: 'prod-aureom',
      sku: 'AUR-3D-BOX',
      name: 'Boxed Download-Key Edition',
      edition_type: 'boxed_key',
      delivery_method: 'UK Tracked Delivery or Click & Collect',
      price_pence: 15900,
      licence_id: 'lic-personal-std',
      includes_json: JSON.stringify([
        'Presentation retail slipcase with printed activation card',
        'Printed 32-page shortcut & shader guide',
        'Instant backup access in My Software Library upon dispatch/collection',
      ]),
      physical_contents_note:
        'Contains a printed activation key card and manual inside the collector box (no optical DVD disc inside; software is retrieved via your online library).',
      requires_shipping: 1,
    },
    {
      id: 'ed-aureom-usb',
      product_id: 'prod-aureom',
      sku: 'AUR-3D-USB',
      name: 'USB Collector Edition',
      edition_type: 'usb_edition',
      delivery_method: 'UK Tracked Delivery or Click & Collect',
      price_pence: 17900,
      licence_id: 'lic-personal-std',
      includes_json: JSON.stringify([
        'Brushed-steel 64GB USB-C / USB-A collector drive pre-loaded with offline files',
        'Printed serialised certificate & activation key',
        'Digital library access included',
      ]),
      physical_contents_note:
        'Includes physical brushed-metal USB Collector Drive with pre-loaded offline archive plus digital library backup.',
      requires_shipping: 1,
    },
    {
      id: 'ed-aureom-source',
      product_id: 'prod-aureom',
      sku: 'AUR-3D-SRC',
      name: 'Source-Code Edition',
      edition_type: 'source_package',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 29900,
      licence_id: 'lic-source-eval',
      includes_json: JSON.stringify([
        'Original sample Python/GLSL source archive & build scripts',
        'Architecture notes & dependency licence manifests',
        'Internal custom build rights (non-redistributable IP)',
      ]),
      physical_contents_note:
        'Digital source archive delivery. Source access does not grant redistribution or underlying IP ownership.',
      requires_shipping: 0,
    },
    // London Cipher
    {
      id: 'ed-cipher-digital',
      product_id: 'prod-london-cipher',
      sku: 'LON-CIP-DIG',
      name: 'Digital Download',
      edition_type: 'digital_download',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 5900,
      licence_id: 'lic-personal-std',
      includes_json: JSON.stringify([
        'Demonstration ZIP package & checksums',
        'Python verification sample & CLI scripts',
        'Activation key',
      ]),
      physical_contents_note: 'Digital delivery only.',
      requires_shipping: 0,
    },
    {
      id: 'ed-cipher-source',
      product_id: 'prod-london-cipher',
      sku: 'LON-CIP-SRC',
      name: 'Source-Code Edition',
      edition_type: 'source_package',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 11900,
      licence_id: 'lic-source-eval',
      includes_json: JSON.stringify([
        'Readable source archive & cryptographic test vectors',
        'Internal audit & build rights under CX-SOURCE-1.4',
      ]),
      physical_contents_note: 'Digital source archive only. No redistribution rights.',
      requires_shipping: 0,
    },
    // StudioWorks
    {
      id: 'ed-studioworks-digital',
      product_id: 'prod-studioworks',
      sku: 'STW-PRO-DIG',
      name: 'Digital Download',
      edition_type: 'digital_download',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 7900,
      licence_id: 'lic-personal-std',
      includes_json: JSON.stringify([
        'Demonstration ZIP package & pipeline samples',
        'Workstation licence key',
      ]),
      physical_contents_note: 'Digital delivery only.',
      requires_shipping: 0,
    },
    {
      id: 'ed-studioworks-usb',
      product_id: 'prod-studioworks',
      sku: 'STW-PRO-USB',
      name: 'USB Collector Edition',
      edition_type: 'usb_edition',
      delivery_method: 'UK Tracked Delivery or Click & Collect',
      price_pence: 9900,
      licence_id: 'lic-personal-std',
      includes_json: JSON.stringify([
        'Anodised USB collector drive + slipcase',
        'Digital library backup & licence key',
      ]),
      physical_contents_note: 'Physical USB collector edition — no optical disc included.',
      requires_shipping: 1,
    },
    // Python Starter Kit
    {
      id: 'ed-pykit-digital',
      product_id: 'prod-python-kit',
      sku: 'PY-KIT-DIG',
      name: 'Digital Starter Pack',
      edition_type: 'digital_download',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 2900,
      licence_id: 'lic-starter-mit',
      includes_json: JSON.stringify([
        '12 guided Python project exercises (MIT sample code)',
        'Digital handbook & FastAPI mini-app starter',
      ]),
      physical_contents_note: 'Digital delivery only.',
      requires_shipping: 0,
    },
    {
      id: 'ed-pykit-boxed',
      product_id: 'prod-python-kit',
      sku: 'PY-KIT-BOX',
      name: 'Physical Boxed Starter Kit',
      edition_type: 'starter_kit',
      delivery_method: 'UK Tracked Delivery or Click & Collect',
      price_pence: 3900,
      licence_id: 'lic-starter-mit',
      includes_json: JSON.stringify([
        'Collector box with laminated Python quick-reference cards',
        'USB card containing offline sample code & digital library voucher',
      ]),
      physical_contents_note:
        'Boxed learning kit includes printed cards and USB card (no DVD disc). Digital library access included.',
      requires_shipping: 1,
    },
    // Thames Ledger
    {
      id: 'ed-ledger-digital',
      product_id: 'prod-thames-ledger',
      sku: 'THM-LDG-DIG',
      name: 'Digital Download',
      edition_type: 'digital_download',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 8900,
      licence_id: 'lic-personal-std',
      includes_json: JSON.stringify([
        'Demonstration accounting package & VAT test suite',
        'Workstation licence key',
      ]),
      physical_contents_note: 'Digital delivery only.',
      requires_shipping: 0,
    },
    {
      id: 'ed-ledger-source',
      product_id: 'prod-thames-ledger',
      sku: 'THM-LDG-SRC',
      name: 'Source-Code Edition',
      edition_type: 'source_package',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 14900,
      licence_id: 'lic-source-eval',
      includes_json: JSON.stringify([
        'Full demonstration Python/SQL ledger source archive',
        'Internal modification & deployment licence',
      ]),
      physical_contents_note: 'Digital source package only.',
      requires_shipping: 0,
    },
    // Camber UI Kit
    {
      id: 'ed-camber-source',
      product_id: 'prod-camber-ui',
      sku: 'CMB-UI-SRC',
      name: 'Source-Code Package',
      edition_type: 'source_package',
      delivery_method: 'Instant Digital Library Download',
      price_pence: 4500,
      licence_id: 'lic-source-eval',
      includes_json: JSON.stringify([
        'Accessible TypeScript component source files & Storybook examples',
        'Documentation & dependency notice file',
      ]),
      physical_contents_note: 'Digital source archive only.',
      requires_shipping: 0,
    },
  ];

  const insertEdition = db.prepare(`
    INSERT INTO editions (
      id, product_id, sku, name, edition_type, delivery_method, price_pence,
      currency, vat_rate_bps, licence_id, includes_json, physical_contents_note, requires_shipping, is_active
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'GBP', 2000, ?, ?, ?, ?, 1)
  `);
  for (const e of editions) {
    insertEdition.run(
      e.id,
      e.product_id,
      e.sku,
      e.name,
      e.edition_type,
      e.delivery_method,
      e.price_pence,
      e.licence_id,
      e.includes_json,
      e.physical_contents_note,
      e.requires_shipping
    );
  }

  // 5. Generate real deterministic demonstration ZIP artefacts & seed release_artefacts
  const artefactSpecs = [
    {
      id: 'art-aureom-2026',
      product_id: 'prod-aureom',
      edition_id: 'ed-aureom-digital',
      version: '2026.2.1-demo',
      filename: 'aureom-animate-3d-demo-2026.2.1.zip',
      platform: 'Cross-Platform (macOS / Windows / Linux)',
      release_notes:
        'Illustrative demonstration bundle with procedural Python curve sampler, GLSL rim shader, and documentation.',
      storage_key: 'aureom-animate-3d/aureom-animate-3d-demo-2026.2.1.zip',
      files: [
        {
          path: 'README.md',
          content:
            '# Aureom Animate 3D — Demonstration Package (v2026.2.1-demo)\n\nThis archive is an illustrative retail sample from The Code Exchange containing original sample scripts and documentation.\nIt is not the full commercial binary suite.\n',
        },
        {
          path: 'sample_scene_rig.py',
          content:
            '"""Original sample procedural keyframe generator for Aureom Animate 3D demonstration."""\nimport math\n\ndef wave_keyframes(frames: int = 24, amplitude: float = 1.5) -> list[dict]:\n    return [{"frame": f, "y": round(math.sin(f * 0.25) * amplitude, 4)} for f in range(frames)]\n\nif __name__ == "__main__":\n    for kf in wave_keyframes(8):\n        print(kf)\n',
        },
        {
          path: 'shader_preset.glsl',
          content:
            '// Sample Magenta/Graphite Studio Rim Shader\n#version 330 core\nin vec3 vNormal;\nout vec4 FragColor;\nvoid main() {\n  float rim = 1.0 - max(dot(normalize(vNormal), vec3(0.0, 0.0, 1.0)), 0.0);\n  vec3 col = mix(vec3(0.07, 0.08, 0.10), vec3(0.83, 0.00, 0.42), pow(rim, 2.2));\n  FragColor = vec4(col, 1.0);\n}\n',
        },
        {
          path: 'THIRD_PARTY_NOTICES.txt',
          content:
            'No third-party binaries are bundled in this demonstration archive. Original code © The Code Exchange demonstration catalogue.\n',
        },
      ],
    },
    {
      id: 'art-aureom-source',
      product_id: 'prod-aureom',
      edition_id: 'ed-aureom-source',
      version: '2026.2.1-src-demo',
      filename: 'aureom-animate-3d-source-demo.zip',
      platform: 'Source Archive (Python / GLSL)',
      release_notes: 'Sample source archive edition with build manifest and CX-SOURCE-1.4 licence.',
      storage_key: 'aureom-animate-3d/aureom-animate-3d-source-demo.zip',
      files: [
        {
          path: 'README.md',
          content:
            '# Aureom Animate 3D — Source-Code Demonstration Edition\n\nLicensed under CX-SOURCE-1.4. Internal modification allowed; redistribution prohibited.\n',
        },
        {
          path: 'src/scene_graph.py',
          content:
            'class Node:\n    def __init__(self, name: str, tx: float = 0.0, ty: float = 0.0):\n        self.name = name\n        self.tx = tx\n        self.ty = ty\n',
        },
        {
          path: 'THIRD_PARTY_NOTICES.txt',
          content: 'Original demonstration source files © The Code Exchange Ltd.\n',
        },
      ],
    },
    {
      id: 'art-cipher-340',
      product_id: 'prod-london-cipher',
      edition_id: 'ed-cipher-digital',
      version: '3.4.0-demo',
      filename: 'london-cipher-demo-3.4.0.zip',
      platform: 'Cross-Platform (Python 3.11+)',
      release_notes: 'Includes original SHA-256 artefact verifier and HMAC signing sample.',
      storage_key: 'london-cipher/london-cipher-demo-3.4.0.zip',
      files: [
        {
          path: 'README.md',
          content:
            '# London Cipher — Demonstration Package (v3.4.0-demo)\n\nIllustrative sample toolkit from The Code Exchange.\n',
        },
        {
          path: 'cipher_verify.py',
          content:
            'import hashlib, hmac\n\ndef verify_hmac(payload: bytes, key: bytes, expected_hex: str) -> bool:\n    digest = hmac.new(key, payload, hashlib.sha256).hexdigest()\n    return hmac.compare_digest(digest, expected_hex)\n',
        },
        {
          path: 'THIRD_PARTY_NOTICES.txt',
          content: 'Uses Python standard library only.\n',
        },
      ],
    },
    {
      id: 'art-studioworks-410',
      product_id: 'prod-studioworks',
      edition_id: 'ed-studioworks-digital',
      version: '4.1.0-demo',
      filename: 'studioworks-demo-4.1.0.zip',
      platform: 'macOS / Windows',
      release_notes: 'Sample pipeline manifest and batch export script.',
      storage_key: 'studioworks/studioworks-demo-4.1.0.zip',
      files: [
        {
          path: 'README.md',
          content: '# StudioWorks — Demonstration Package (v4.1.0-demo)\n\nIllustrative export pipeline sample.\n',
        },
        {
          path: 'pipeline_manifest.json',
          content: JSON.stringify({ format: 'webp', quality: 90, colourProfile: 'sRGB' }, null, 2),
        },
      ],
    },
    {
      id: 'art-pykit-200',
      product_id: 'prod-python-kit',
      edition_id: 'ed-pykit-digital',
      version: '2.0.0-demo',
      filename: 'python-starter-kit-demo-2.0.0.zip',
      platform: 'Cross-Platform (Python 3.11+)',
      release_notes: 'Original beginner Python exercises, UK VAT helper, and handbook excerpt.',
      storage_key: 'python-starter-kit/python-starter-kit-demo-2.0.0.zip',
      files: [
        {
          path: 'README.md',
          content:
            '# Python Starter Kit — Demonstration Exercise Pack\n\nRun `python3 templates/01_hello_exchange.py` to try the first exercise.\n',
        },
        {
          path: 'templates/01_hello_exchange.py',
          content:
            '"""Exercise 01: UK VAT calculator in minor units (MIT Licence)."""\n\ndef split_vat_pence(gross_pence: int) -> tuple[int, int]:\n    vat = (gross_pence * 2000 + 6000) // 12000\n    return gross_pence - vat, vat\n\nif __name__ == "__main__":\n    net, vat = split_vat_pence(2900)\n    print(f"£29.00 gross = £{net/100:.2f} net + £{vat/100:.2f} VAT")\n',
        },
        {
          path: 'THIRD_PARTY_NOTICES.txt',
          content: 'Exercise templates in /templates are MIT licensed. Handbook © The Code Exchange Ltd.\n',
        },
      ],
    },
    {
      id: 'art-ledger-182',
      product_id: 'prod-thames-ledger',
      edition_id: 'ed-ledger-digital',
      version: '1.8.2-demo',
      filename: 'thames-ledger-demo-1.8.2.zip',
      platform: 'Linux / macOS / Windows',
      release_notes: 'Original double-entry posting sample in Python.',
      storage_key: 'thames-ledger/thames-ledger-demo-1.8.2.zip',
      files: [
        {
          path: 'README.md',
          content: '# Thames Ledger — Demonstration Core\n\nInteger-pence double-entry ledger sample.\n',
        },
        {
          path: 'ledger_core.py',
          content:
            'def validate_balanced(entries: list[tuple[str, int]]) -> bool:\n    return sum(amount for _, amount in entries) == 0\n',
        },
      ],
    },
    {
      id: 'art-camber-130',
      product_id: 'prod-camber-ui',
      edition_id: 'ed-camber-source',
      version: '1.3.0-demo',
      filename: 'camber-ui-kit-demo-1.3.0.zip',
      platform: 'TypeScript / React 19',
      release_notes: 'Accessible GBP formatter and stepper primitive sample.',
      storage_key: 'camber-ui-kit/camber-ui-kit-demo-1.3.0.zip',
      files: [
        {
          path: 'README.md',
          content: '# Camber UI Kit — Demonstration Source Package\n\nAccessible TypeScript helpers.\n',
        },
        {
          path: 'src/formatGbp.ts',
          content:
            'export function formatGbp(pence: number): string {\n  return `£${(pence / 100).toFixed(2)}`;\n}\n',
        },
      ],
    },
  ];

  const insertArtefact = db.prepare(`
    INSERT INTO release_artefacts (
      id, product_id, edition_id, version, filename, platform, size_bytes, sha256,
      release_notes, quarantine_status, scan_report, storage_key, published_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', 'SHA-256 verified; static scan passed (0 issues)', ?, ?)
  `);

  for (const spec of artefactSpecs) {
    const { sha256, sizeBytes } = writeArtefactZip(spec.storage_key, spec.files);
    insertArtefact.run(
      spec.id,
      spec.product_id,
      spec.edition_id,
      spec.version,
      spec.filename,
      spec.platform,
      sizeBytes,
      sha256,
      spec.release_notes,
      spec.storage_key,
      now
    );
  }

  // Also seed one quarantined staging artefact so admin quarantine->scan->publish flow is immediately visible!
  const stagingZip = writeArtefactZip('aureom-animate-3d/aureom-animate-3d-2026.3.0-rc1.zip', [
    {
      path: 'README.md',
      content: '# Aureom Animate 3D Release Candidate 2026.3.0-rc1\n\nPending release verification.\n',
    },
  ]);
  db.prepare(`
    INSERT INTO release_artefacts (
      id, product_id, edition_id, version, filename, platform, size_bytes, sha256,
      release_notes, quarantine_status, scan_report, storage_key, published_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'quarantined', 'Awaiting security & checksum validation', ?, NULL)
  `).run(
    'art-aureom-rc1',
    'prod-aureom',
    'ed-aureom-digital',
    '2026.3.0-rc1',
    'aureom-animate-3d-2026.3.0-rc1.zip',
    'Cross-Platform (macOS / Windows / Linux)',
    stagingZip.sizeBytes,
    stagingZip.sha256,
    'Release candidate awaiting quarantine scan before customer library publication.',
    'aureom-animate-3d/aureom-animate-3d-2026.3.0-rc1.zip'
  );

  // 6. Seed Physical Stock by Location (warehouse = NULL store_id)
  // Notice ed-aureom-usb at store-london has ONLY 1 unit so competing last-item purchase can be demonstrated!
  const stockRows = [
    { id: 'stk-aur-box-wh', edition_id: 'ed-aureom-boxed', store_id: null, on_hand: 14 },
    { id: 'stk-aur-box-lon', edition_id: 'ed-aureom-boxed', store_id: 'store-london', on_hand: 5 },
    { id: 'stk-aur-box-man', edition_id: 'ed-aureom-boxed', store_id: 'store-manchester', on_hand: 3 },
    { id: 'stk-aur-box-edi', edition_id: 'ed-aureom-boxed', store_id: 'store-edinburgh', on_hand: 2 },

    { id: 'stk-aur-usb-wh', edition_id: 'ed-aureom-usb', store_id: null, on_hand: 4 },
    { id: 'stk-aur-usb-lon', edition_id: 'ed-aureom-usb', store_id: 'store-london', on_hand: 1 }, // Last item in London!
    { id: 'stk-aur-usb-man', edition_id: 'ed-aureom-usb', store_id: 'store-manchester', on_hand: 2 },
    { id: 'stk-aur-usb-edi', edition_id: 'ed-aureom-usb', store_id: 'store-edinburgh', on_hand: 0 },

    { id: 'stk-stw-usb-wh', edition_id: 'ed-studioworks-usb', store_id: null, on_hand: 9 },
    { id: 'stk-stw-usb-lon', edition_id: 'ed-studioworks-usb', store_id: 'store-london', on_hand: 4 },
    { id: 'stk-stw-usb-man', edition_id: 'ed-studioworks-usb', store_id: 'store-manchester', on_hand: 2 },

    { id: 'stk-pyk-box-wh', edition_id: 'ed-pykit-boxed', store_id: null, on_hand: 22 },
    { id: 'stk-pyk-box-lon', edition_id: 'ed-pykit-boxed', store_id: 'store-london', on_hand: 8 },
    { id: 'stk-pyk-box-man', edition_id: 'ed-pykit-boxed', store_id: 'store-manchester', on_hand: 6 },
    { id: 'stk-pyk-box-edi', edition_id: 'ed-pykit-boxed', store_id: 'store-edinburgh', on_hand: 5 },
  ];

  const insertStock = db.prepare(`
    INSERT INTO stock_locations (id, edition_id, store_id, on_hand, reserved, updated_at)
    VALUES (?, ?, ?, ?, 0, ?)
  `);
  const insertMove = db.prepare(`
    INSERT INTO stock_movements (id, edition_id, store_id, delta, reason, reference_id, actor_id, created_at)
    VALUES (?, ?, ?, ?, 'initial_seed', 'seed', 'system', ?)
  `);
  for (const row of stockRows) {
    insertStock.run(row.id, row.edition_id, row.store_id, row.on_hand, now);
    if (row.on_hand > 0) {
      insertMove.run(`mov-${row.id}`, row.edition_id, row.store_id, row.on_hand, now);
    }
  }

  // 7. Seed Workshops (modelling BST in summer and GMT in winter via Europe/London!)
  const workshops = [
    {
      id: 'ws-python-basics',
      slug: 'python-basics-first-line',
      title: 'Python Basics: From First Line to First App',
      subtitle: 'Build a clean UK VAT calculator and CLI tool in one evening session.',
      description:
        'Designed for complete beginners and creatives moving into code. Guided step-by-step in our Clerkenwell studio classroom with small-group support.',
      instructor: 'Dr Hannah Pritchard (Lead Educator)',
      level: 'Beginner',
      prerequisites: 'None — no prior programming experience required.',
      format: 'In Store',
      store_id: 'store-london',
      venue_label: 'London — Clerkenwell Studio Classroom',
      starts_at_utc: '2026-07-14T17:30:00Z', // 18:30 BST!
      ends_at_utc: '2026-07-14T20:00:00Z',   // 21:00 BST!
      display_timezone: 'Europe/London',
      capacity: 12,
      price_pence: 4500,
      required_equipment: 'Bring a laptop (macOS, Windows, or Linux); loaner laptops available on request.',
      accessibility_info: 'Step-free street access, induction hearing loop, and caption screen available.',
      cancellation_terms: 'Full refund up to 48 hours before start time; free transfer to another date up to 24 hours prior.',
      image_url: '/images/workshop-banner.png',
    },
    {
      id: 'ws-fastapi-web',
      slug: 'building-first-web-app',
      title: 'Building Your First FastAPI & React Web App',
      subtitle: 'Connect a Python API to a responsive storefront interface live online.',
      description:
        'Hands-on online workshop covering REST endpoints, integer pricing rules, and accessible frontend forms.',
      instructor: 'Callum Fraser (Principal Engineer)',
      level: 'Beginner / Intermediate',
      prerequisites: 'Basic familiarity with Python variables and functions.',
      format: 'Online Live',
      store_id: null,
      venue_label: 'Online Live Stream (Interactive Q&A)',
      starts_at_utc: '2026-12-03T18:00:00Z', // 18:00 GMT!
      ends_at_utc: '2026-12-03T20:30:00Z',
      display_timezone: 'Europe/London',
      capacity: 20,
      price_pence: 5500,
      required_equipment: 'Laptop with Python 3.11+ and Node.js 20+ installed (setup check sent 48h before).',
      accessibility_info: 'Live human-reviewed captions and full session recording provided for 90 days.',
      cancellation_terms: 'Full refund up to 48 hours before start time.',
      image_url: '/images/workshop-banner.png',
    },
    {
      id: 'ws-source-code',
      slug: 'working-with-source-code',
      title: 'Working With Production Source Code',
      subtitle: 'Reading, verifying, and extending commercial-grade Python & TypeScript codebases.',
      description:
        'Learn how to audit dependencies, verify checksums, run tests, and safely customise source-code packages.',
      instructor: 'Priya Nair (Security & Systems Architect)',
      level: 'Intermediate',
      prerequisites: 'Comfortable with Git and at least one language (Python or TypeScript).',
      format: 'In Store',
      store_id: 'store-manchester',
      venue_label: 'Manchester — Northern Quarter Lab',
      starts_at_utc: '2026-08-19T17:00:00Z', // 18:00 BST!
      ends_at_utc: '2026-08-19T20:00:00Z',
      display_timezone: 'Europe/London',
      capacity: 2, // Low capacity to test last seat & waitlist!
      price_pence: 7500,
      required_equipment: 'Laptop with Git and VS Code or terminal editor.',
      accessibility_info: 'Ground-floor studio access with quiet breakout room.',
      cancellation_terms: 'Full refund up to 48 hours before start time.',
      image_url: '/images/workshop-banner.png',
    },
    {
      id: 'ws-aureom-shaders',
      slug: 'creative-3d-shaders-edinburgh',
      title: 'Aureom 3D & Shaders Intensive',
      subtitle: 'Script procedural 3D motion and custom GLSL lighting in Edinburgh.',
      description:
        'Creative coding afternoon exploring keyframe curves, custom surface shaders, and asset export.',
      instructor: 'Ewan MacLeod (Graphics Technical Director)',
      level: 'Intermediate',
      prerequisites: 'Basic trigonometry or creative coding curiosity.',
      format: 'In Store',
      store_id: 'store-edinburgh',
      venue_label: 'Edinburgh — New Town Studio',
      starts_at_utc: '2026-09-12T13:00:00Z', // 14:00 BST!
      ends_at_utc: '2026-09-12T16:30:00Z',
      display_timezone: 'Europe/London',
      capacity: 10,
      price_pence: 8500,
      required_equipment: 'Laptop with dedicated or Apple Silicon GPU.',
      accessibility_info: 'Lift access to first-floor studio; adjustable desks.',
      cancellation_terms: 'Full refund up to 48 hours before start time.',
      image_url: '/images/workshop-banner.png',
    },
  ];

  const insertWorkshop = db.prepare(`
    INSERT INTO workshops (
      id, slug, title, subtitle, description, instructor, level, prerequisites,
      format, store_id, venue_label, starts_at_utc, ends_at_utc, display_timezone,
      capacity, price_pence, required_equipment, accessibility_info, cancellation_terms, image_url
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const w of workshops) {
    insertWorkshop.run(
      w.id,
      w.slug,
      w.title,
      w.subtitle,
      w.description,
      w.instructor,
      w.level,
      w.prerequisites,
      w.format,
      w.store_id,
      w.venue_label,
      w.starts_at_utc,
      w.ends_at_utc,
      w.display_timezone,
      w.capacity,
      w.price_pence,
      w.required_equipment,
      w.accessibility_info,
      w.cancellation_terms,
      w.image_url
    );
  }

  // 8. Seed Demo Customer & Historical Order so Customer Library works out-of-the-box for demo sign-in
  const demoCustomerId = 'user-demo-customer';
  // Demo user has an unreachable random hash for password login; passwordless demo sign-in route issues a session ONLY for this non-privileged demo customer account.
  db.prepare(`
    INSERT INTO users (id, email, name, password_hash, role, mfa_enabled, created_at)
    VALUES (?, 'customer@codeexchange.co.uk', 'Oliver Bennett', ?, 'customer', 0, ?)
  `).run(demoCustomerId, hashPassword('demo-customer-preview-only-2026'), now);

  // Seed 1 confirmed seat on ws-source-code so only 1 seat remains!
  db.prepare(`
    INSERT INTO orders (
      id, order_number, user_id, customer_email, customer_name, status,
      subtotal_net_pence, discount_pence, vat_pence, delivery_pence, total_pence,
      currency, shipping_address_json, terms_accepted_at, digital_waiver_accepted_at,
      accepted_licence_versions_json, created_at
    ) VALUES (?, 'CX-2026-1001', ?, 'customer@codeexchange.co.uk', 'Oliver Bennett', 'confirmed',
      6250, 0, 1250, 0, 7500, 'GBP', NULL, ?, NULL, '[]', ?)
  `).run('ord-seed-1001', demoCustomerId, now, now);

  db.prepare(`
    INSERT INTO order_items (
      id, order_id, item_type, workshop_id, title, edition_name, sku,
      quantity, unit_price_pence, line_total_pence, fulfilment_method, fulfilment_status,
      store_id
    ) VALUES ('oi-seed-1001', 'ord-seed-1001', 'workshop', 'ws-source-code',
      'Working With Production Source Code', 'Workshop Seat (In Store)', 'WS-SRC-01',
      1, 7500, 7500, 'workshop', 'confirmed', 'store-manchester')
  `).run();

  db.prepare(`
    INSERT INTO workshop_bookings (
      id, workshop_id, order_id, user_id, attendee_name, attendee_email, seats, status, notification_status, created_at
    ) VALUES ('wb-seed-1001', 'ws-source-code', 'ord-seed-1001', ?, 'Oliver Bennett', 'customer@codeexchange.co.uk', 1, 'confirmed', 'sent', ?)
  `).run(demoCustomerId, now);

  // Also seed a digital Python Starter Kit order & entitlement for Oliver Bennett so My Library has an immediate item
  db.prepare(`
    INSERT INTO orders (
      id, order_number, user_id, customer_email, customer_name, status,
      subtotal_net_pence, discount_pence, vat_pence, delivery_pence, total_pence,
      currency, shipping_address_json, terms_accepted_at, digital_waiver_accepted_at,
      accepted_licence_versions_json, created_at
    ) VALUES ('ord-seed-1002', 'CX-2026-1002', ?, 'customer@codeexchange.co.uk', 'Oliver Bennett', 'fulfilled',
      2417, 0, 483, 0, 2900, 'GBP', NULL, ?, ?, ?, ?)
  `).run(
    demoCustomerId,
    now,
    now,
    JSON.stringify([{ licence_id: 'lic-starter-mit', code: 'CX-STARTER-1.0', version: '1.0.0' }]),
    now
  );

  db.prepare(`
    INSERT INTO order_items (
      id, order_id, item_type, edition_id, title, edition_name, sku,
      quantity, unit_price_pence, line_total_pence, fulfilment_method, fulfilment_status,
      licence_id, licence_version
    ) VALUES ('oi-seed-1002', 'ord-seed-1002', 'edition', 'ed-pykit-digital',
      'Python Starter Kit', 'Digital Starter Pack', 'PY-KIT-DIG',
      1, 2900, 2900, 'digital', 'fulfilled', 'lic-starter-mit', '1.0.0')
  `).run();

  db.prepare(`
    INSERT INTO entitlements (
      id, user_id, customer_email, order_id, order_item_id, product_id, edition_id,
      licence_id, licence_version, status, activation_key, granted_at
    ) VALUES ('ent-seed-1002', ?, 'customer@codeexchange.co.uk', 'ord-seed-1002', 'oi-seed-1002',
      'prod-python-kit', 'ed-pykit-digital', 'lic-starter-mit', '1.0.0', 'active', 'CXPK-2026-DEMO-8842', ?)
  `).run(demoCustomerId, now);

  // 9. Seed Homepage CMS Content
  db.prepare(`
    INSERT INTO cms_blocks (key, value_json, updated_by, updated_at)
    VALUES ('homepage', ?, 'system', ?)
  `).run(
    JSON.stringify({
      heroHeadlineTop: 'BUILD SOMETHING',
      heroHeadlineAccent: 'BRILLIANT.',
      heroSubheading: 'Software, source code and the skills to make it yours.',
      workshopHeadline: 'FROM FIRST LINE TO FIRST APP',
      workshopSubheading:
        'Practical, hands-on coding workshops in-store and online, from complete beginners to full project builds.',
      featuredTitle: 'Your next great project starts here',
      demoNotice:
        'Demonstration catalogue: illustrative sample products, pricing, and original sample download archives.',
    }),
    now
  );

  // 10. Seed initial audit entry
  db.prepare(`
    INSERT INTO audit_logs (id, actor_id, actor_email, actor_role, action, target_type, target_id, details_json, created_at)
    VALUES ('aud-seed-1', 'system', 'system@codeexchange.co.uk', 'admin', 'catalogue.seeded', 'system', 'initial', ?, ?)
  `).run(JSON.stringify({ products: 6, editions: editions.length, workshops: 4, stores: 3 }), now);
}
