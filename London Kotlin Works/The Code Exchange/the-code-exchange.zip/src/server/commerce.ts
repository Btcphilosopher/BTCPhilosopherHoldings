import crypto from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { calculateBasketTotals, splitVatFromGrossPence, type BasketPricingLine } from './money.ts';
import { logStructured, signDownloadPayload, signWebhookPayload } from './security.ts';

export interface ShippingAddress {
  line1: string;
  line2?: string;
  city: string;
  postcode: string;
  country: string;
}

export function formatWorkshopTimeUK(utcIso: string, timezone = 'Europe/London'): {
  dateLabel: string;
  timeLabel: string;
  tzAbbrev: string;
  fullLabel: string;
} {
  const dt = new Date(utcIso);
  const dateLabel = new Intl.DateTimeFormat('en-GB', {
    timeZone: timezone,
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(dt);

  const timeParts = new Intl.DateTimeFormat('en-GB', {
    timeZone: timezone,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZoneName: 'short',
  }).formatToParts(dt);

  const hour = timeParts.find((p) => p.type === 'hour')?.value || '00';
  const minute = timeParts.find((p) => p.type === 'minute')?.value || '00';
  const tzAbbrev = timeParts.find((p) => p.type === 'timeZoneName')?.value || 'GMT';
  const timeLabel = `${hour}:${minute} ${tzAbbrev}`;
  return {
    dateLabel,
    timeLabel,
    tzAbbrev,
    fullLabel: `${dateLabel} at ${timeLabel}`,
  };
}

export function recordAudit(
  db: DatabaseSync,
  actor: { id?: string | null; email: string; role: string },
  action: string,
  targetType: string,
  targetId: string,
  details: Record<string, unknown>
) {
  db.prepare(
    `INSERT INTO audit_logs (id, actor_id, actor_email, actor_role, action, target_type, target_id, details_json, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    `aud-${crypto.randomUUID().slice(0, 12)}`,
    actor.id || null,
    actor.email,
    actor.role,
    action,
    targetType,
    targetId,
    JSON.stringify(details),
    new Date().toISOString()
  );
}

export function expireStaleWorkshopHolds(db: DatabaseSync): number {
  const nowIso = new Date().toISOString();
  const expiredRows = db
    .prepare(`SELECT id FROM workshop_holds WHERE status = 'active' AND expires_at <= ?`)
    .all(nowIso) as { id: string }[];
  if (expiredRows.length === 0) return 0;

  db.prepare(`UPDATE workshop_holds SET status = 'expired' WHERE status = 'active' AND expires_at <= ?`).run(
    nowIso
  );
  // Also remove stale expired workshop basket items so customer sees clear expiry
  db.prepare(
    `DELETE FROM basket_items WHERE hold_id IN (SELECT id FROM workshop_holds WHERE status = 'expired')`
  ).run();
  return expiredRows.length;
}

export function getWorkshopAvailability(db: DatabaseSync, workshopId: string) {
  expireStaleWorkshopHolds(db);
  const ws = db.prepare('SELECT capacity FROM workshops WHERE id = ?').get(workshopId) as
    | { capacity: number }
    | undefined;
  if (!ws) return null;

  const bookedRow = db
    .prepare(
      `SELECT COALESCE(SUM(seats), 0) as total FROM workshop_bookings
       WHERE workshop_id = ? AND status IN ('confirmed', 'checked_in')`
    )
    .get(workshopId) as { total: number };

  const heldRow = db
    .prepare(
      `SELECT COALESCE(SUM(seats), 0) as total FROM workshop_holds
       WHERE workshop_id = ? AND status = 'active'`
    )
    .get(workshopId) as { total: number };

  const waitlistRow = db
    .prepare(`SELECT COUNT(*) as total FROM workshop_waitlist WHERE workshop_id = ?`)
    .get(workshopId) as { total: number };

  const remaining = Math.max(0, ws.capacity - bookedRow.total - heldRow.total);
  return {
    capacity: ws.capacity,
    booked: bookedRow.total,
    held: heldRow.total,
    remaining,
    waitlistCount: waitlistRow.total,
  };
}

export function getEditionStockSummary(db: DatabaseSync, editionId: string) {
  const rows = db
    .prepare(
      `SELECT sl.id, sl.store_id, sl.on_hand, sl.reserved, sl.updated_at,
              COALESCE(s.name, 'Central Warehouse (UK Delivery)') as location_name,
              s.slug as store_slug, s.city as city
       FROM stock_locations sl
       LEFT JOIN stores s ON s.id = sl.store_id
       WHERE sl.edition_id = ?
       ORDER BY sl.store_id IS NOT NULL, s.name`
    )
    .all(editionId) as {
    id: string;
    store_id: string | null;
    on_hand: number;
    reserved: number;
    updated_at: string;
    location_name: string;
    store_slug: string | null;
    city: string | null;
  }[];

  return rows.map((r) => ({
    ...r,
    available: Math.max(0, r.on_hand - r.reserved),
  }));
}

export function getBasketSnapshot(db: DatabaseSync, basketId: string) {
  expireStaleWorkshopHolds(db);
  const basket = db.prepare('SELECT * FROM baskets WHERE id = ?').get(basketId) as
    | { id: string; user_id: string | null; discount_code: string | null }
    | undefined;

  if (!basket) {
    return {
      basketId,
      items: [],
      totals: calculateBasketTotals([], null),
    };
  }

  const rawItems = db
    .prepare(
      `SELECT bi.*,
              p.title as product_title, p.slug as product_slug, p.image_url as product_image,
              e.name as edition_name, e.sku as edition_sku, e.edition_type, e.price_pence as current_edition_price,
              e.requires_shipping, e.vat_rate_bps, e.licence_id,
              l.code as licence_code, l.version as licence_version, l.title as licence_title,
              w.title as workshop_title, w.slug as workshop_slug, w.price_pence as current_workshop_price,
              w.starts_at_utc, w.display_timezone, w.venue_label,
              wh.expires_at as hold_expires_at,
              s.name as store_name
       FROM basket_items bi
       LEFT JOIN editions e ON e.id = bi.edition_id
       LEFT JOIN products p ON p.id = e.product_id
       LEFT JOIN licences l ON l.id = e.licence_id
       LEFT JOIN workshops w ON w.id = bi.workshop_id
       LEFT JOIN workshop_holds wh ON wh.id = bi.hold_id
       LEFT JOIN stores s ON s.id = bi.store_id
       WHERE bi.basket_id = ?`
    )
    .all(basketId) as Record<string, unknown>[];

  const pricingLines: BasketPricingLine[] = [];
  const items = rawItems.map((row) => {
    const itemType = row.item_type as 'edition' | 'workshop';
    const unitPricePence =
      itemType === 'edition'
        ? (row.current_edition_price as number)
        : (row.current_workshop_price as number);
    const title =
      itemType === 'edition' ? (row.product_title as string) : (row.workshop_title as string);
    const editionName =
      itemType === 'edition'
        ? (row.edition_name as string)
        : `Workshop Seat (${row.venue_label as string})`;
    const fulfilmentChoice = row.fulfilment_choice as 'digital' | 'delivery' | 'collect' | 'workshop';
    const requiresDelivery = itemType === 'edition' && Boolean(row.requires_shipping);
    const qty = Number(row.quantity) || 1;

    pricingLines.push({
      id: row.id as string,
      itemType,
      title,
      editionName,
      unitPricePence,
      quantity: qty,
      requiresDelivery,
      fulfilmentChoice,
      vatRateBps: Number(row.vat_rate_bps || 2000),
    });

    return {
      id: row.id as string,
      itemType,
      editionId: row.edition_id as string | null,
      workshopId: row.workshop_id as string | null,
      productSlug: row.product_slug as string | null,
      workshopSlug: row.workshop_slug as string | null,
      title,
      editionName,
      sku: (row.edition_sku as string) || `WS-${String(row.workshop_id || '').slice(-4).toUpperCase()}`,
      imageUrl: (row.product_image as string) || '/images/workshop-banner.png',
      fulfilmentChoice,
      storeId: row.store_id as string | null,
      storeName: row.store_name as string | null,
      requiresShipping: requiresDelivery,
      quantity: qty,
      unitPricePence,
      lineTotalPence: unitPricePence * qty,
      licenceId: row.licence_id as string | null,
      licenceCode: row.licence_code as string | null,
      licenceVersion: row.licence_version as string | null,
      licenceTitle: row.licence_title as string | null,
      holdId: row.hold_id as string | null,
      holdExpiresAt: row.hold_expires_at as string | null,
      workshopTime:
        itemType === 'workshop' && row.starts_at_utc
          ? formatWorkshopTimeUK(row.starts_at_utc as string, (row.display_timezone as string) || 'Europe/London')
          : null,
    };
  });

  const totals = calculateBasketTotals(pricingLines, basket.discount_code);
  return {
    basketId,
    items,
    totals,
  };
}

export function createWorkshopHold(
  db: DatabaseSync,
  workshopId: string,
  basketId: string,
  userId: string | null,
  seats = 1,
  ttlSeconds = 900
): { holdId: string; expiresAt: string } {
  db.exec('BEGIN IMMEDIATE');
  try {
    expireStaleWorkshopHolds(db);
    const ws = db.prepare('SELECT id, capacity FROM workshops WHERE id = ?').get(workshopId) as
      | { id: string; capacity: number }
      | undefined;
    if (!ws) throw new Error('Workshop not found.');

    const bookedRow = db
      .prepare(
        `SELECT COALESCE(SUM(seats), 0) as total FROM workshop_bookings
         WHERE workshop_id = ? AND status IN ('confirmed', 'checked_in')`
      )
      .get(workshopId) as { total: number };
    const heldRow = db
      .prepare(
        `SELECT COALESCE(SUM(seats), 0) as total FROM workshop_holds
         WHERE workshop_id = ? AND status = 'active'`
      )
      .get(workshopId) as { total: number };

    const remaining = ws.capacity - bookedRow.total - heldRow.total;
    if (remaining < seats) {
      throw new Error('Not enough workshop places remaining. Join the waiting list instead.');
    }

    const holdId = `hold-${crypto.randomUUID().slice(0, 12)}`;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + ttlSeconds * 1000).toISOString();

    db.prepare(
      `INSERT INTO workshop_holds (id, workshop_id, basket_id, user_id, seats, status, expires_at, created_at)
       VALUES (?, ?, ?, ?, ?, 'active', ?, ?)`
    ).run(holdId, workshopId, basketId, userId, seats, expiresAt, now.toISOString());

    db.exec('COMMIT');
    return { holdId, expiresAt };
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

export function createOrderFromBasket(
  db: DatabaseSync,
  params: {
    basketId: string;
    userId: string | null;
    customerEmail: string;
    customerName: string;
    shippingAddress: ShippingAddress | null;
    termsAccepted: boolean;
    digitalWaiverAccepted: boolean;
    idempotencyKey: string;
    provider?: 'simulated' | 'stripe_sandbox';
    simulateFulfilmentFailOnce?: boolean;
  }
) {
  if (!params.termsAccepted) {
    throw new Error('You must accept the Terms of Sale and applicable Licence versions.');
  }

  // Idempotency short-circuit BEFORE touching inventory
  const existingPi = db
    .prepare('SELECT * FROM payment_intents WHERE idempotency_key = ?')
    .get(params.idempotencyKey) as
    | { id: string; order_id: string; status: string; provider_ref: string; amount_pence: number }
    | undefined;
  if (existingPi) {
    const existingOrder = db
      .prepare('SELECT * FROM orders WHERE id = ?')
      .get(existingPi.order_id) as Record<string, unknown>;
    return {
      order: existingOrder,
      paymentIntent: existingPi,
      idempotentReplay: true,
    };
  }

  const snapshot = getBasketSnapshot(db, params.basketId);
  if (snapshot.items.length === 0) {
    throw new Error('Your basket is empty (or a workshop reservation hold expired).');
  }

  if (snapshot.totals.hasDigitalItems && !params.digitalWaiverAccepted) {
    throw new Error(
      'Under UK Consumer Contracts Regulations, please confirm immediate digital access and acknowledge the cancellation waiver.'
    );
  }

  if (snapshot.totals.requiresShippingAddress) {
    if (
      !params.shippingAddress ||
      !params.shippingAddress.line1?.trim() ||
      !params.shippingAddress.city?.trim() ||
      !params.shippingAddress.postcode?.trim()
    ) {
      throw new Error('A UK delivery address is required for physical delivery items.');
    }
  }

  const now = new Date().toISOString();
  const orderId = `ord-${crypto.randomUUID().slice(0, 12)}`;
  const orderNumber = `CX-${new Date().getFullYear()}-${String(Math.floor(100000 + Math.random() * 899999))}`;
  const piId = `pi-${crypto.randomUUID().slice(0, 12)}`;
  const providerRef = `sim_pi_${crypto.randomBytes(8).toString('hex')}`;

  db.exec('BEGIN IMMEDIATE');
  try {
    expireStaleWorkshopHolds(db);

    const acceptedLicences: { licence_id: string; code: string; version: string }[] = [];

    for (const item of snapshot.items) {
      if (item.itemType === 'edition' && item.editionId) {
        if (item.fulfilmentChoice === 'delivery' || item.fulfilmentChoice === 'collect') {
          const targetStoreId = item.fulfilmentChoice === 'collect' ? item.storeId : null;
          const stockRow = db
            .prepare(
              targetStoreId
                ? `SELECT id, on_hand, reserved FROM stock_locations WHERE edition_id = ? AND store_id = ?`
                : `SELECT id, on_hand, reserved FROM stock_locations WHERE edition_id = ? AND store_id IS NULL`
            )
            .get(...(targetStoreId ? [item.editionId, targetStoreId] : [item.editionId])) as
            | { id: string; on_hand: number; reserved: number }
            | undefined;

          const available = stockRow ? stockRow.on_hand - stockRow.reserved : 0;
          if (!stockRow || available < item.quantity) {
            throw new Error(
              `Insufficient stock for ${item.title} (${item.editionName}) at selected location (${available} available).`
            );
          }

          db.prepare(
            `UPDATE stock_locations SET reserved = reserved + ?, updated_at = ? WHERE id = ?`
          ).run(item.quantity, now, stockRow.id);

          db.prepare(
            `INSERT INTO stock_movements (id, edition_id, store_id, delta, reason, reference_id, actor_id, created_at)
             VALUES (?, ?, ?, ?, 'checkout_reservation', ?, ?, ?)`
          ).run(
            `mov-${crypto.randomUUID().slice(0, 10)}`,
            item.editionId,
            targetStoreId,
            -item.quantity,
            orderId,
            params.userId || params.customerEmail,
            now
          );
        }

        if (item.licenceId && item.licenceCode && item.licenceVersion) {
          acceptedLicences.push({
            licence_id: item.licenceId,
            code: item.licenceCode,
            version: item.licenceVersion,
          });
        }
      } else if (item.itemType === 'workshop' && item.workshopId) {
        // Verify active hold still exists & isn't expired
        if (!item.holdId) {
          throw new Error(`Workshop hold missing for ${item.title}. Please re-reserve your seat.`);
        }
        const holdRow = db
          .prepare(`SELECT id, status, expires_at FROM workshop_holds WHERE id = ?`)
          .get(item.holdId) as { id: string; status: string; expires_at: string } | undefined;
        if (!holdRow || holdRow.status !== 'active' || holdRow.expires_at <= now) {
          throw new Error(`Your 15-minute reservation hold for ${item.title} has expired.`);
        }
      }
    }

    db.prepare(
      `INSERT INTO orders (
        id, order_number, user_id, customer_email, customer_name, status,
        subtotal_net_pence, discount_pence, vat_pence, delivery_pence, total_pence,
        currency, shipping_address_json, terms_accepted_at, digital_waiver_accepted_at,
        accepted_licence_versions_json, created_at
      ) VALUES (?, ?, ?, ?, ?, 'awaiting_payment', ?, ?, ?, ?, ?, 'GBP', ?, ?, ?, ?, ?)`
    ).run(
      orderId,
      orderNumber,
      params.userId,
      params.customerEmail.toLowerCase().trim(),
      params.customerName.trim(),
      snapshot.totals.itemsNetPence,
      snapshot.totals.discountPence,
      snapshot.totals.taxPence,
      snapshot.totals.deliveryPence,
      snapshot.totals.totalPence,
      params.shippingAddress ? JSON.stringify(params.shippingAddress) : null,
      now,
      snapshot.totals.hasDigitalItems ? now : null,
      JSON.stringify(acceptedLicences),
      now
    );

    const insertOrderItem = db.prepare(
      `INSERT INTO order_items (
        id, order_id, item_type, edition_id, workshop_id, title, edition_name, sku,
        quantity, unit_price_pence, line_total_pence, fulfilment_method, fulfilment_status,
        store_id, licence_id, licence_version
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_payment', ?, ?, ?)`
    );

    for (const item of snapshot.items) {
      insertOrderItem.run(
        `oi-${crypto.randomUUID().slice(0, 12)}`,
        orderId,
        item.itemType,
        item.editionId,
        item.workshopId,
        item.title,
        item.editionName,
        item.sku,
        item.quantity,
        item.unitPricePence,
        item.lineTotalPence,
        item.fulfilmentChoice,
        item.storeId,
        item.licenceId,
        item.licenceVersion
      );
    }

    db.prepare(
      `INSERT INTO payment_intents (
        id, order_id, idempotency_key, provider, provider_ref, amount_pence,
        currency, status, webhook_event_ids_json, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'GBP', 'requires_confirmation', '[]', ?, ?)`
    ).run(
      piId,
      orderId,
      params.idempotencyKey,
      params.provider || 'simulated',
      providerRef,
      snapshot.totals.totalPence,
      now,
      now
    );

    if (params.simulateFulfilmentFailOnce) {
      // Flag stored in audit/job metadata when payment succeeds
      recordAudit(
        db,
        { id: params.userId, email: params.customerEmail, role: 'customer' },
        'checkout.fail_once_flagged',
        'order',
        orderId,
        { orderNumber }
      );
    }

    db.exec('COMMIT');
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as Record<string, unknown>;
    const pi = db.prepare('SELECT * FROM payment_intents WHERE id = ?').get(piId) as Record<string, unknown>;
    return { order, paymentIntent: pi, idempotentReplay: false };
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

function releaseOrderReservations(db: DatabaseSync, orderId: string, reason: string) {
  const now = new Date().toISOString();
  const items = db
    .prepare('SELECT * FROM order_items WHERE order_id = ?')
    .all(orderId) as Record<string, unknown>[];

  for (const item of items) {
    if (
      item.item_type === 'edition' &&
      item.edition_id &&
      (item.fulfilment_method === 'delivery' || item.fulfilment_method === 'collect')
    ) {
      const storeId = item.fulfilment_method === 'collect' ? (item.store_id as string | null) : null;
      const stockRow = db
        .prepare(
          storeId
            ? `SELECT id, reserved FROM stock_locations WHERE edition_id = ? AND store_id = ?`
            : `SELECT id, reserved FROM stock_locations WHERE edition_id = ? AND store_id IS NULL`
        )
        .get(...(storeId ? [item.edition_id, storeId] : [item.edition_id])) as
        | { id: string; reserved: number }
        | undefined;

      if (stockRow) {
        const releaseQty = Math.min(stockRow.reserved, Number(item.quantity));
        if (releaseQty > 0) {
          db.prepare(
            `UPDATE stock_locations SET reserved = reserved - ?, updated_at = ? WHERE id = ?`
          ).run(releaseQty, now, stockRow.id);
          db.prepare(
            `INSERT INTO stock_movements (id, edition_id, store_id, delta, reason, reference_id, actor_id, created_at)
             VALUES (?, ?, ?, ?, ?, ?, 'system', ?)`
          ).run(
            `mov-${crypto.randomUUID().slice(0, 10)}`,
            item.edition_id,
            storeId,
            releaseQty,
            reason,
            orderId,
            now
          );
        }
      }
    }
  }
}

export function applyPaymentWebhookEvent(
  db: DatabaseSync,
  params: {
    eventId: string;
    paymentIntentId: string;
    outcome: 'succeeded' | 'cancelled' | 'failed';
    basketIdToClear?: string | null;
    simulateFulfilmentFailOnce?: boolean;
  }
) {
  const now = new Date().toISOString();
  db.exec('BEGIN IMMEDIATE');
  try {
    const pi = db
      .prepare('SELECT * FROM payment_intents WHERE id = ?')
      .get(params.paymentIntentId) as
      | {
          id: string;
          order_id: string;
          status: string;
          webhook_event_ids_json: string;
        }
      | undefined;
    if (!pi) {
      throw new Error('PaymentIntent not found.');
    }

    const seenEvents: string[] = JSON.parse(pi.webhook_event_ids_json || '[]');
    if (seenEvents.includes(params.eventId)) {
      db.exec('COMMIT');
      logStructured('info', 'webhook.duplicate_ignored', {
        eventId: params.eventId,
        paymentIntentId: params.paymentIntentId,
      });
      return { duplicate: true, status: pi.status, orderId: pi.order_id };
    }

    seenEvents.push(params.eventId);

    if (params.outcome === 'succeeded') {
      if (pi.status === 'succeeded') {
        db.prepare(
          `UPDATE payment_intents SET webhook_event_ids_json = ?, updated_at = ? WHERE id = ?`
        ).run(JSON.stringify(seenEvents), now, pi.id);
        db.exec('COMMIT');
        return { duplicate: true, status: 'succeeded', orderId: pi.order_id };
      }

      db.prepare(
        `UPDATE payment_intents SET status = 'succeeded', webhook_event_ids_json = ?, updated_at = ? WHERE id = ?`
      ).run(JSON.stringify(seenEvents), now, pi.id);

      db.prepare(`UPDATE orders SET status = 'paid_fulfilling' WHERE id = ?`).run(pi.order_id);

      // Enqueue fulfilment job
      const jobId = `job-${crypto.randomUUID().slice(0, 12)}`;
      db.prepare(
        `INSERT INTO fulfilment_jobs (id, order_id, job_type, status, attempts, simulate_fail_once, payload_json, created_at, updated_at)
         VALUES (?, ?, 'order_fulfilment', 'queued', 0, ?, ?, ?, ?)`
      ).run(
        jobId,
        pi.order_id,
        params.simulateFulfilmentFailOnce ? 1 : 0,
        JSON.stringify({ basketIdToClear: params.basketIdToClear || null }),
        now,
        now
      );

      if (params.basketIdToClear) {
        db.prepare(
          `UPDATE workshop_holds SET status = 'converted'
           WHERE basket_id = ? AND status = 'active'`
        ).run(params.basketIdToClear);
        db.prepare('DELETE FROM basket_items WHERE basket_id = ?').run(params.basketIdToClear);
        db.prepare('UPDATE baskets SET discount_code = NULL, updated_at = ? WHERE id = ?').run(
          now,
          params.basketIdToClear
        );
      }

      db.exec('COMMIT');
      // Run worker synchronously (unless simulateFulfilmentFailOnce causes attempt 1 to enter failed_retryable)
      runFulfilmentJobs(db, pi.order_id);
      return { duplicate: false, status: 'succeeded', orderId: pi.order_id };
    }

    // Cancelled or failed payment
    const nextStatus = params.outcome === 'cancelled' ? 'cancelled' : 'failed';
    db.prepare(
      `UPDATE payment_intents SET status = ?, webhook_event_ids_json = ?, updated_at = ? WHERE id = ?`
    ).run(nextStatus, JSON.stringify(seenEvents), now, pi.id);

    db.prepare(`UPDATE orders SET status = ? WHERE id = ?`).run(nextStatus, pi.order_id);
    db.prepare(`UPDATE order_items SET fulfilment_status = ? WHERE order_id = ?`).run(
      nextStatus,
      pi.order_id
    );
    releaseOrderReservations(db, pi.order_id, `payment_${nextStatus}`);

    db.exec('COMMIT');
    return { duplicate: false, status: nextStatus, orderId: pi.order_id };
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

export function runFulfilmentJobs(db: DatabaseSync, filterOrderId?: string) {
  const jobs = db
    .prepare(
      filterOrderId
        ? `SELECT * FROM fulfilment_jobs WHERE order_id = ? AND status IN ('queued', 'failed_retryable')`
        : `SELECT * FROM fulfilment_jobs WHERE status IN ('queued', 'failed_retryable')`
    )
    .all(...(filterOrderId ? [filterOrderId] : [])) as Record<string, unknown>[];

  const results: { jobId: string; orderId: string; status: string; error?: string }[] = [];

  for (const job of jobs) {
    const now = new Date().toISOString();
    const jobId = job.id as string;
    const orderId = job.order_id as string;
    const attempts = Number(job.attempts || 0) + 1;

    if (Number(job.simulate_fail_once) === 1 && attempts === 1) {
      db.prepare(
        `UPDATE fulfilment_jobs
         SET status = 'failed_retryable', attempts = ?, simulate_fail_once = 0,
             last_error = 'Simulated downstream S3/printer timeout on attempt 1 (safe to retry)', updated_at = ?
         WHERE id = ?`
      ).run(attempts, now, jobId);

      db.prepare(`UPDATE orders SET status = 'fulfilment_attention' WHERE id = ?`).run(orderId);
      results.push({
        jobId,
        orderId,
        status: 'failed_retryable',
        error: 'Simulated transient timeout on attempt 1',
      });
      continue;
    }

    db.exec('BEGIN IMMEDIATE');
    try {
      const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as Record<string, unknown>;
      const items = db
        .prepare(
          `SELECT oi.*, e.product_id, e.edition_type
           FROM order_items oi
           LEFT JOIN editions e ON e.id = oi.edition_id
           WHERE oi.order_id = ?`
        )
        .all(orderId) as Record<string, unknown>[];

      let allInstantFulfilled = true;

      for (const item of items) {
        if (item.item_type === 'edition') {
          const editionType = item.edition_type as string;
          const method = item.fulfilment_method as string;

          // Grant digital entitlement for digital downloads, source packages, and physical editions with library backup
          const existingEnt = db
            .prepare('SELECT id FROM entitlements WHERE order_item_id = ?')
            .get(item.id as string);

          if (!existingEnt && item.product_id && item.edition_id && item.licence_id) {
            const activationKey = `CX-${String(item.sku || 'KEY').slice(0, 4)}-${crypto
              .randomBytes(4)
              .toString('hex')
              .toUpperCase()}`;
            db.prepare(
              `INSERT INTO entitlements (
                id, user_id, customer_email, order_id, order_item_id, product_id, edition_id,
                licence_id, licence_version, status, activation_key, granted_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)`
            ).run(
              `ent-${crypto.randomUUID().slice(0, 12)}`,
              order.user_id || null,
              order.customer_email as string,
              orderId,
              item.id as string,
              item.product_id as string,
              item.edition_id as string,
              item.licence_id as string,
              (item.licence_version as string) || '1.0.0',
              activationKey,
              now
            );
          }

          if (method === 'digital' || editionType === 'digital_download' || editionType === 'source_package') {
            db.prepare(`UPDATE order_items SET fulfilment_status = 'fulfilled' WHERE id = ?`).run(item.id as string);
          } else if (method === 'collect') {
            allInstantFulfilled = false;
            db.prepare(`UPDATE order_items SET fulfilment_status = 'awaiting_picking' WHERE id = ?`).run(item.id as string);
          } else {
            allInstantFulfilled = false;
            db.prepare(`UPDATE order_items SET fulfilment_status = 'awaiting_picking' WHERE id = ?`).run(item.id as string);
          }
        } else if (item.item_type === 'workshop' && item.workshop_id) {
          const existingBooking = db
            .prepare('SELECT id FROM workshop_bookings WHERE order_id = ? AND workshop_id = ?')
            .get(orderId, item.workshop_id as string);
          if (!existingBooking) {
            db.prepare(
              `INSERT INTO workshop_bookings (
                id, workshop_id, order_id, user_id, attendee_name, attendee_email, seats,
                status, notification_status, created_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, 'confirmed', 'queued', ?)`
            ).run(
              `wb-${crypto.randomUUID().slice(0, 12)}`,
              item.workshop_id as string,
              orderId,
              order.user_id || null,
              order.customer_name as string,
              order.customer_email as string,
              Number(item.quantity || 1),
              now
            );
          }
          db.prepare(`UPDATE order_items SET fulfilment_status = 'confirmed' WHERE id = ?`).run(item.id as string);
        }
      }

      db.prepare(`UPDATE orders SET status = ? WHERE id = ?`).run(
        allInstantFulfilled ? 'fulfilled' : 'partially_fulfilled',
        orderId
      );

      db.prepare(
        `UPDATE fulfilment_jobs SET status = 'completed', attempts = ?, last_error = NULL, updated_at = ? WHERE id = ?`
      ).run(attempts, now, jobId);

      // Queue confirmation email (kept distinct from booking confirmation state!)
      db.prepare(
        `INSERT INTO email_outbox (id, recipient, subject, template, status, payload_json, created_at)
         VALUES (?, ?, ?, 'order_confirmation', 'sent', ?, ?)`
      ).run(
        `eml-${crypto.randomUUID().slice(0, 10)}`,
        order.customer_email as string,
        `Your Code Exchange order ${order.order_number as string} is confirmed`,
        JSON.stringify({ orderNumber: order.order_number, totalPence: order.total_pence }),
        now
      );

      db.prepare(
        `UPDATE workshop_bookings SET notification_status = 'sent' WHERE order_id = ?`
      ).run(orderId);

      db.exec('COMMIT');
      results.push({ jobId, orderId, status: 'completed' });
    } catch (err) {
      db.exec('ROLLBACK');
      db.prepare(
        `UPDATE fulfilment_jobs SET status = 'failed_retryable', attempts = ?, last_error = ?, updated_at = ? WHERE id = ?`
      ).run(attempts, (err as Error).message, new Date().toISOString(), jobId);
      results.push({ jobId, orderId, status: 'failed_retryable', error: (err as Error).message });
    }
  }

  return results;
}

export function triggerSignedPaymentSimulation(
  db: DatabaseSync,
  params: {
    paymentIntentId: string;
    outcome: 'succeeded' | 'cancelled' | 'failed';
    eventId?: string;
    basketIdToClear?: string | null;
    simulateFulfilmentFailOnce?: boolean;
  }
) {
  const eventId = params.eventId || `evt_${crypto.randomBytes(6).toString('hex')}`;
  const rawBody = JSON.stringify({
    eventId,
    paymentIntentId: params.paymentIntentId,
    outcome: params.outcome,
  });
  // Sign internally using same HMAC verifier helper so simulator matches real webhook contract
  const signature = signWebhookPayload(rawBody);
  return {
    eventId,
    signature,
    result: applyPaymentWebhookEvent(db, {
      eventId,
      paymentIntentId: params.paymentIntentId,
      outcome: params.outcome,
      basketIdToClear: params.basketIdToClear,
      simulateFulfilmentFailOnce: params.simulateFulfilmentFailOnce,
    }),
  };
}

export function createSignedDownloadUrlForEntitlement(
  db: DatabaseSync,
  params: {
    entitlementId: string;
    artefactId: string;
    userId: string;
    userEmail: string;
  }
): { downloadUrl: string; expiresAt: string; sha256: string; filename: string } {
  const ent = db
    .prepare(
      `SELECT e.*, p.id as prod_id FROM entitlements e
       JOIN products p ON p.id = e.product_id
       WHERE e.id = ?`
    )
    .get(params.entitlementId) as
    | {
        id: string;
        user_id: string | null;
        customer_email: string;
        product_id: string;
        status: string;
      }
    | undefined;

  if (!ent) throw new Error('Entitlement not found.');
  if (ent.status !== 'active') {
    throw new Error('This entitlement is currently revoked or refunded.');
  }
  if (
    ent.user_id !== params.userId &&
    ent.customer_email.toLowerCase() !== params.userEmail.toLowerCase()
  ) {
    throw new Error('You do not have permission to download this item.');
  }

  const artefact = db
    .prepare(
      `SELECT * FROM release_artefacts
       WHERE id = ? AND product_id = ?`
    )
    .get(params.artefactId, ent.product_id) as
    | {
        id: string;
        quarantine_status: string;
        sha256: string;
        filename: string;
      }
    | undefined;

  if (!artefact) throw new Error('Release artefact not found.');
  if (artefact.quarantine_status !== 'published') {
    throw new Error('This release artefact is still quarantined and not yet published.');
  }

  const expiresAtUnix = Math.floor(Date.now() / 1000) + 600; // 10 minutes
  const token = signDownloadPayload({
    entitlementId: ent.id,
    artefactId: artefact.id,
    userId: params.userId,
    expiresAtUnix,
  });

  return {
    downloadUrl: `/api/downloads/file?token=${encodeURIComponent(token)}`,
    expiresAt: new Date(expiresAtUnix * 1000).toISOString(),
    sha256: artefact.sha256,
    filename: artefact.filename,
  };
}

export function advancePhysicalFulfilment(
  db: DatabaseSync,
  params: {
    orderItemId: string;
    action: 'pick' | 'pack' | 'dispatch' | 'ready_for_collection' | 'collect' | 'return';
    actor: { id?: string | null; email: string; role: string };
  }
) {
  const now = new Date().toISOString();
  db.exec('BEGIN IMMEDIATE');
  try {
    const item = db
      .prepare('SELECT * FROM order_items WHERE id = ?')
      .get(params.orderItemId) as Record<string, unknown> | undefined;
    if (!item) throw new Error('Order item not found.');
    if (item.item_type !== 'edition') throw new Error('Only physical editions use warehouse fulfilment.');

    const storeId = item.fulfilment_method === 'collect' ? (item.store_id as string | null) : null;
    const qty = Number(item.quantity || 1);

    const statusMap: Record<string, string> = {
      pick: 'picking',
      pack: 'packed',
      dispatch: 'dispatched',
      ready_for_collection: 'ready_for_collection',
      collect: 'collected',
      return: 'returned',
    };
    const nextStatus = statusMap[params.action];

    if (params.action === 'dispatch' || params.action === 'collect') {
      const stockRow = db
        .prepare(
          storeId
            ? `SELECT id, on_hand, reserved FROM stock_locations WHERE edition_id = ? AND store_id = ?`
            : `SELECT id, on_hand, reserved FROM stock_locations WHERE edition_id = ? AND store_id IS NULL`
        )
        .get(...(storeId ? [item.edition_id, storeId] : [item.edition_id])) as
        | { id: string; on_hand: number; reserved: number }
        | undefined;

      if (stockRow && item.fulfilment_status !== 'dispatched' && item.fulfilment_status !== 'collected') {
        const deductReserved = Math.min(stockRow.reserved, qty);
        const deductOnHand = Math.min(stockRow.on_hand, qty);
        db.prepare(
          `UPDATE stock_locations SET on_hand = on_hand - ?, reserved = reserved - ?, updated_at = ? WHERE id = ?`
        ).run(deductOnHand, deductReserved, now, stockRow.id);

        db.prepare(
          `INSERT INTO stock_movements (id, edition_id, store_id, delta, reason, reference_id, actor_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          `mov-${crypto.randomUUID().slice(0, 10)}`,
          item.edition_id,
          storeId,
          -deductOnHand,
          `physical_${params.action}`,
          item.order_id,
          params.actor.email,
          now
        );
      }
    } else if (params.action === 'return') {
      const stockRow = db
        .prepare(
          storeId
            ? `SELECT id FROM stock_locations WHERE edition_id = ? AND store_id = ?`
            : `SELECT id FROM stock_locations WHERE edition_id = ? AND store_id IS NULL`
        )
        .get(...(storeId ? [item.edition_id, storeId] : [item.edition_id])) as
        | { id: string }
        | undefined;

      if (stockRow) {
        db.prepare(
          `UPDATE stock_locations SET on_hand = on_hand + ?, updated_at = ? WHERE id = ?`
        ).run(qty, now, stockRow.id);
        db.prepare(
          `INSERT INTO stock_movements (id, edition_id, store_id, delta, reason, reference_id, actor_id, created_at)
           VALUES (?, ?, ?, ?, 'physical_return', ?, ?, ?)`
        ).run(
          `mov-${crypto.randomUUID().slice(0, 10)}`,
          item.edition_id,
          storeId,
          qty,
          item.order_id,
          params.actor.email,
          now
        );
      }

      // Policy: returning a physical boxed/USB edition revokes its associated digital activation backup
      db.prepare(
        `UPDATE entitlements SET status = 'revoked', revoked_at = ? WHERE order_item_id = ?`
      ).run(now, item.id as string);
    }

    db.prepare(`UPDATE order_items SET fulfilment_status = ? WHERE id = ?`).run(
      nextStatus,
      item.id as string
    );

    // Recompute overall order status
    const allItems = db
      .prepare('SELECT fulfilment_status FROM order_items WHERE order_id = ?')
      .all(item.order_id as string) as { fulfilment_status: string }[];
    const doneStates = new Set(['fulfilled', 'dispatched', 'collected', 'confirmed']);
    const allDone = allItems.every((i) => doneStates.has(i.fulfilment_status));
    if (allDone) {
      db.prepare(`UPDATE orders SET status = 'fulfilled' WHERE id = ?`).run(item.order_id as string);
    }

    recordAudit(db, params.actor, `fulfilment.${params.action}`, 'order_item', item.id as string, {
      orderId: item.order_id,
      nextStatus,
    });

    db.exec('COMMIT');
    return { orderItemId: item.id as string, fulfilmentStatus: nextStatus };
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

export function processOrderItemRefund(
  db: DatabaseSync,
  params: {
    orderId: string;
    orderItemId: string;
    quantity: number;
    reason: string;
    actor: { id?: string | null; email: string; role: string };
  }
) {
  const now = new Date().toISOString();
  db.exec('BEGIN IMMEDIATE');
  try {
    const item = db
      .prepare('SELECT * FROM order_items WHERE id = ? AND order_id = ?')
      .get(params.orderItemId, params.orderId) as Record<string, unknown> | undefined;
    if (!item) throw new Error('Order item not found.');

    const maxRemainingQty = Number(item.quantity) - Number(item.refunded_quantity || 0);
    if (params.quantity <= 0 || params.quantity > maxRemainingQty) {
      throw new Error(`Refund quantity must be between 1 and ${maxRemainingQty}.`);
    }

    const amountPence = Number(item.unit_price_pence) * params.quantity;
    const refundId = `ref-${crypto.randomUUID().slice(0, 12)}`;

    db.prepare(
      `INSERT INTO refunds (id, order_id, order_item_id, amount_pence, reason, status, actor_id, created_at)
       VALUES (?, ?, ?, ?, ?, 'succeeded', ?, ?)`
    ).run(refundId, params.orderId, params.orderItemId, amountPence, params.reason, params.actor.email, now);

    const newRefundedQty = Number(item.refunded_quantity || 0) + params.quantity;
    const newRefundedPence = Number(item.refunded_pence || 0) + amountPence;
    const fullyRefunded = newRefundedQty >= Number(item.quantity);

    db.prepare(
      `UPDATE order_items
       SET refunded_quantity = ?, refunded_pence = ?,
           fulfilment_status = CASE WHEN ? = 1 THEN 'refunded' ELSE fulfilment_status END
       WHERE id = ?`
    ).run(newRefundedQty, newRefundedPence, fullyRefunded ? 1 : 0, params.orderItemId);

    // Revoke digital entitlement if fully refunded
    if (fullyRefunded && item.item_type === 'edition') {
      db.prepare(
        `UPDATE entitlements SET status = 'revoked', revoked_at = ? WHERE order_item_id = ?`
      ).run(now, params.orderItemId);
    }

    // Cancel workshop booking if workshop refunded
    if (fullyRefunded && item.item_type === 'workshop' && item.workshop_id) {
      db.prepare(
        `UPDATE workshop_bookings SET status = 'cancelled' WHERE order_id = ? AND workshop_id = ?`
      ).run(params.orderId, item.workshop_id as string);
    }

    // Release physical reserved stock if unshipped
    if (
      item.item_type === 'edition' &&
      item.edition_id &&
      (item.fulfilment_status === 'awaiting_picking' || item.fulfilment_status === 'picking' || item.fulfilment_status === 'packed')
    ) {
      const storeId = item.fulfilment_method === 'collect' ? (item.store_id as string | null) : null;
      const stockRow = db
        .prepare(
          storeId
            ? `SELECT id, reserved FROM stock_locations WHERE edition_id = ? AND store_id = ?`
            : `SELECT id, reserved FROM stock_locations WHERE edition_id = ? AND store_id IS NULL`
        )
        .get(...(storeId ? [item.edition_id, storeId] : [item.edition_id])) as
        | { id: string; reserved: number }
        | undefined;
      if (stockRow && stockRow.reserved >= params.quantity) {
        db.prepare(
          `UPDATE stock_locations SET reserved = reserved - ?, updated_at = ? WHERE id = ?`
        ).run(params.quantity, now, stockRow.id);
      }
    }

    const orderItems = db
      .prepare('SELECT quantity, refunded_quantity FROM order_items WHERE order_id = ?')
      .all(params.orderId) as { quantity: number; refunded_quantity: number }[];
    const allItemsRefunded = orderItems.every((i) => i.refunded_quantity >= i.quantity);

    db.prepare(`UPDATE orders SET status = ? WHERE id = ?`).run(
      allItemsRefunded ? 'refunded' : 'partially_refunded',
      params.orderId
    );

    const vatSplit = splitVatFromGrossPence(amountPence, 2000);
    recordAudit(db, params.actor, 'order.refund_issued', 'order', params.orderId, {
      refundId,
      orderItemId: params.orderItemId,
      quantity: params.quantity,
      amountPence,
      vatReversedPence: vatSplit.vatPence,
      reason: params.reason,
    });

    db.exec('COMMIT');
    return {
      refundId,
      amountPence,
      orderStatus: allItemsRefunded ? 'refunded' : 'partially_refunded',
    };
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
