export interface BasketPricingLine {
  id: string;
  itemType: 'edition' | 'workshop';
  title: string;
  editionName: string;
  unitPricePence: number;
  quantity: number;
  requiresDelivery: boolean;
  fulfilmentChoice: 'digital' | 'delivery' | 'collect' | 'workshop';
  vatRateBps: number; // e.g. 2000 = 20.00%
}

export interface BasketTotals {
  itemsGrossPence: number;
  itemsNetPence: number;
  discountPence: number;
  taxPence: number;
  deliveryPence: number;
  totalPence: number;
  currency: 'GBP';
  appliedDiscountCode: string | null;
  requiresShippingAddress: boolean;
  hasDigitalItems: boolean;
  freeDeliveryThresholdPence: number;
}

export const FREE_DELIVERY_THRESHOLD_PENCE = 10000; // £100.00
export const STANDARD_UK_DELIVERY_PENCE = 495; // £4.95 (VAT-inclusive UK Royal Mail Tracked 48)

export function formatGBP(pence: number): string {
  const sign = pence < 0 ? '-' : '';
  const abs = Math.abs(Math.round(pence));
  const pounds = Math.floor(abs / 100);
  const rem = abs % 100;
  if (rem === 0 && abs >= 100) {
    return `${sign}£${pounds.toLocaleString('en-GB')}`;
  }
  return `${sign}£${(abs / 100).toFixed(2)}`;
}

export function formatGBPPrecise(pence: number): string {
  const sign = pence < 0 ? '-' : '';
  const abs = Math.abs(Math.round(pence));
  return `${sign}£${(abs / 100).toFixed(2)}`;
}

/**
 * Splits a VAT-inclusive gross amount in minor units (pence) into net + VAT.
 * Uses integer arithmetic with round-half-up:
 *   vat = round(gross * vatRateBps / (10000 + vatRateBps))
 *   net = gross - vat
 */
export function splitVatFromGrossPence(grossPence: number, vatRateBps = 2000): {
  netPence: number;
  vatPence: number;
} {
  if (grossPence <= 0 || vatRateBps <= 0) {
    return { netPence: Math.max(0, grossPence), vatPence: 0 };
  }
  const denominator = 10000 + vatRateBps;
  const vatPence = Math.floor((grossPence * vatRateBps + Math.floor(denominator / 2)) / denominator);
  return {
    netPence: grossPence - vatPence,
    vatPence,
  };
}

export function evaluateDiscountPence(
  code: string | null | undefined,
  itemsGrossPence: number
): { discountPence: number; normalizedCode: string | null; label: string | null } {
  const normalized = (code || '').trim().toUpperCase();
  if (!normalized || itemsGrossPence <= 0) {
    return { discountPence: 0, normalizedCode: null, label: null };
  }
  if (normalized === 'CODE10') {
    // 10% off items gross, rounded half-up to nearest penny
    const discountPence = Math.floor((itemsGrossPence * 10 + 50) / 100);
    return { discountPence, normalizedCode: 'CODE10', label: '10% community code' };
  }
  if (normalized === 'WELCOME5') {
    const discountPence = Math.min(500, itemsGrossPence);
    return { discountPence, normalizedCode: 'WELCOME5', label: '£5 welcome credit' };
  }
  if (normalized === 'WORKSHOP20' && itemsGrossPence >= 10000) {
    return { discountPence: 2000, normalizedCode: 'WORKSHOP20', label: '£20 off orders £100+' };
  }
  return { discountPence: 0, normalizedCode: null, label: null };
}

export function calculateBasketTotals(
  lines: BasketPricingLine[],
  discountCode?: string | null
): BasketTotals {
  let itemsGrossPence = 0;
  let deliveryEligibleGrossPence = 0;
  let requiresShippingAddress = false;
  let hasDigitalItems = false;

  for (const line of lines) {
    const qty = Math.max(0, Math.floor(line.quantity));
    const lineGross = line.unitPricePence * qty;
    itemsGrossPence += lineGross;

    if (line.fulfilmentChoice === 'delivery' && line.requiresDelivery) {
      requiresShippingAddress = true;
      deliveryEligibleGrossPence += lineGross;
    }
    if (line.fulfilmentChoice === 'digital') {
      hasDigitalItems = true;
    }
  }

  const { discountPence, normalizedCode } = evaluateDiscountPence(discountCode, itemsGrossPence);
  const discountedItemsGross = Math.max(0, itemsGrossPence - discountPence);

  const deliveryPence =
    requiresShippingAddress && deliveryEligibleGrossPence < FREE_DELIVERY_THRESHOLD_PENCE
      ? STANDARD_UK_DELIVERY_PENCE
      : 0;

  const totalPence = discountedItemsGross + deliveryPence;

  // UK VAT applies to both goods/digital services and delivery at 20% standard rate
  const itemsSplit = splitVatFromGrossPence(discountedItemsGross, 2000);
  const deliverySplit = splitVatFromGrossPence(deliveryPence, 2000);

  return {
    itemsGrossPence,
    itemsNetPence: itemsSplit.netPence,
    discountPence,
    taxPence: itemsSplit.vatPence + deliverySplit.vatPence,
    deliveryPence,
    totalPence,
    currency: 'GBP',
    appliedDiscountCode: normalizedCode,
    requiresShippingAddress,
    hasDigitalItems,
    freeDeliveryThresholdPence: FREE_DELIVERY_THRESHOLD_PENCE,
  };
}
