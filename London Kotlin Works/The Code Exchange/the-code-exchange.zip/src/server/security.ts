import crypto from 'node:crypto';
import type { NextRequest, NextResponse } from 'next/server';

const globalForSecrets = globalThis as unknown as {
  __cxEphemeralSessionSecret?: string;
  __cxEphemeralDownloadSecret?: string;
  __cxEphemeralWebhookSecret?: string;
  __cxRateLimits?: Map<string, number[]>;
};

export function getSessionSecret(): string {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.trim().length >= 16) {
    return process.env.SESSION_SECRET.trim();
  }
  if (!globalForSecrets.__cxEphemeralSessionSecret) {
    globalForSecrets.__cxEphemeralSessionSecret = crypto.randomBytes(32).toString('hex');
  }
  return globalForSecrets.__cxEphemeralSessionSecret;
}

export function getDownloadSigningSecret(): string {
  if (
    process.env.DOWNLOAD_SIGNING_SECRET &&
    process.env.DOWNLOAD_SIGNING_SECRET.trim().length >= 16
  ) {
    return process.env.DOWNLOAD_SIGNING_SECRET.trim();
  }
  if (!globalForSecrets.__cxEphemeralDownloadSecret) {
    globalForSecrets.__cxEphemeralDownloadSecret = crypto.randomBytes(32).toString('hex');
  }
  return globalForSecrets.__cxEphemeralDownloadSecret;
}

export function getWebhookSecret(): string {
  if (
    process.env.PAYMENT_WEBHOOK_SECRET &&
    process.env.PAYMENT_WEBHOOK_SECRET.trim().length >= 16
  ) {
    return process.env.PAYMENT_WEBHOOK_SECRET.trim();
  }
  if (!globalForSecrets.__cxEphemeralWebhookSecret) {
    globalForSecrets.__cxEphemeralWebhookSecret = crypto.randomBytes(32).toString('hex');
  }
  return globalForSecrets.__cxEphemeralWebhookSecret;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const [, salt, expectedHex] = parts;
  if (!salt || !expectedHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, 'hex');
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

export function hashToken(rawToken: string): string {
  return crypto.createHmac('sha256', getSessionSecret()).update(rawToken).digest('hex');
}

export function generateOpaqueToken(): string {
  return crypto.randomBytes(32).toString('base64url');
}

export function signDownloadPayload(payload: {
  entitlementId: string;
  artefactId: string;
  userId: string;
  expiresAtUnix: number;
}): string {
  const data = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getDownloadSigningSecret())
    .update(data)
    .digest('base64url');
  return `${data}.${sig}`;
}

export function verifyDownloadToken(token: string): {
  entitlementId: string;
  artefactId: string;
  userId: string;
  expiresAtUnix: number;
} | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [data, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getDownloadSigningSecret())
    .update(data)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length) return null;
  if (!crypto.timingSafeEqual(sigBuf, expectedBuf)) return null;

  try {
    const parsed = JSON.parse(Buffer.from(data, 'base64url').toString('utf8'));
    if (
      typeof parsed.entitlementId !== 'string' ||
      typeof parsed.artefactId !== 'string' ||
      typeof parsed.userId !== 'string' ||
      typeof parsed.expiresAtUnix !== 'number'
    ) {
      return null;
    }
    if (Math.floor(Date.now() / 1000) > parsed.expiresAtUnix) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function signWebhookPayload(rawBody: string): string {
  return crypto.createHmac('sha256', getWebhookSecret()).update(rawBody).digest('hex');
}

export function verifyWebhookSignature(rawBody: string, providedSig: string | null): boolean {
  if (!providedSig) return false;
  const expected = signWebhookPayload(rawBody);
  const a = Buffer.from(providedSig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// RFC 6238 TOTP (Base32) for Staff MFA
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function generateTotpSecret(): string {
  const bytes = crypto.randomBytes(20);
  let bits = 0;
  let value = 0;
  let output = '';
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }
  return output;
}

function decodeBase32(secret: string): Buffer {
  const clean = secret.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let value = 0;
  const bytes: number[] = [];
  for (const ch of clean) {
    const idx = BASE32_ALPHABET.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}

export function generateTotpCode(secret: string, timeStepOffset = 0): string {
  const key = decodeBase32(secret);
  const counter = Math.floor(Date.now() / 1000 / 30) + timeStepOffset;
  const buf = Buffer.alloc(8);
  buf.writeBigInt64BE(BigInt(counter));
  const hmac = crypto.createHmac('sha1', key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    (((hmac[offset] & 0x7f) << 24) |
      ((hmac[offset + 1] & 0xff) << 16) |
      ((hmac[offset + 2] & 0xff) << 8) |
      (hmac[offset + 3] & 0xff)) %
    1000000;
  return String(code).padStart(6, '0');
}

export function verifyTotpCode(secret: string, code: string): boolean {
  const normalized = code.replace(/\s+/g, '');
  if (!/^\d{6}$/.test(normalized)) return false;
  for (const delta of [-1, 0, 1]) {
    const expected = generateTotpCode(secret, delta);
    if (crypto.timingSafeEqual(Buffer.from(normalized), Buffer.from(expected))) {
      return true;
    }
  }
  return false;
}

export const SESSION_COOKIE_NAME = 'cx_session';
export const BASKET_COOKIE_NAME = 'cx_basket';

export function setSecureSessionCookie(res: NextResponse, name: string, value: string, maxAgeSeconds = 60 * 60 * 24 * 7) {
  const parts = [
    `${name}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    'Secure',
    'SameSite=None',
    'Partitioned',
    `Max-Age=${maxAgeSeconds}`,
  ];
  res.headers.append('Set-Cookie', parts.join('; '));
}

export function clearSecureCookie(res: NextResponse, name: string) {
  const parts = [
    `${name}=`,
    'Path=/',
    'HttpOnly',
    'Secure',
    'SameSite=None',
    'Partitioned',
    'Max-Age=0',
  ];
  res.headers.append('Set-Cookie', parts.join('; '));
}

export function verifyMutationOrigin(req: NextRequest): boolean {
  const method = req.method.toUpperCase();
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') return true;
  if (req.headers.get('x-requested-with') === 'XMLHttpRequest') return true;
  if (req.headers.get('authorization')?.startsWith('Bearer ')) return true;

  const origin = req.headers.get('origin');
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
  if (!origin || !host) return true; // non-browser API client or same-origin fetch
  try {
    const parsedOrigin = new URL(origin);
    return parsedOrigin.host === host;
  } catch {
    return false;
  }
}

export function checkRateLimit(key: string, maxRequests: number, windowMs: number): boolean {
  if (!globalForSecrets.__cxRateLimits) {
    globalForSecrets.__cxRateLimits = new Map();
  }
  const now = Date.now();
  const existing = globalForSecrets.__cxRateLimits.get(key) || [];
  const valid = existing.filter((ts) => now - ts < windowMs);
  if (valid.length >= maxRequests) {
    globalForSecrets.__cxRateLimits.set(key, valid);
    return false;
  }
  valid.push(now);
  globalForSecrets.__cxRateLimits.set(key, valid);
  return true;
}

const REDACTED_KEYS = new Set([
  'password',
  'password_hash',
  'secret',
  'token',
  'authorization',
  'cookie',
  'card',
  'cvv',
  'mfa_secret',
  'download_url',
  'activation_key',
]);

function redactObject(input: unknown): unknown {
  if (input === null || input === undefined) return input;
  if (Array.isArray(input)) return input.map(redactObject);
  if (typeof input === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(input as Record<string, unknown>)) {
      if (REDACTED_KEYS.has(k.toLowerCase())) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = redactObject(v);
      }
    }
    return out;
  }
  return input;
}

export function logStructured(level: 'info' | 'warn' | 'error', event: string, meta?: Record<string, unknown>) {
  const payload = {
    ts: new Date().toISOString(),
    level,
    event,
    ...(meta ? (redactObject(meta) as Record<string, unknown>) : {}),
  };
  if (level === 'error') {
    console.error(JSON.stringify(payload));
  } else {
    console.log(JSON.stringify(payload));
  }
}
