# The Code Exchange

**The Code Exchange** is a British e-commerce storefront and operations platform for downloadable software, source-code packages, coding starter kits, physical collector editions, and in-store/online coding workshops.

> **Demonstration Notice**: Catalogue listings (`Aureom Animate 3D — £149`, `London Cipher — £59`, `StudioWorks — £79`, `Python Starter Kit — £29`, `Thames Ledger — £89`, `Camber UI Kit — £45`) are illustrative retail entries backed by small, original demonstration `.zip` archives with real SHA-256 checksums and documentation.

---

## Architecture

- **Storefront & Administration UI**: Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS v4 (`/app`, `/components`, `/lib`).
- **Standalone Live Runtime Engine**: Transactional SQLite (`node:sqlite`) server engine in `/src/server/` powering all Next.js `/api/*` routes out-of-the-box on port 3000 (no external setup required for preview).
- **Python + FastAPI + PostgreSQL Production Stack**: Modular monolith in `/backend/` with SQLAlchemy 2.0, Alembic migrations, S3/MinIO object storage adapter with quarantine promotion, background worker (`backend/app/worker.py`), and replaceable `PaymentProvider` adapter (`SimulatedPaymentProvider` + `StripeSandboxProvider`).
- **Local Orchestration**: `docker-compose.yml` running `postgres`, `minio`, `backend`, `worker`, and `frontend`.

---

## Quick Start (Standalone Storefront)

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

### Running Tests

```bash
# TypeScript / Node integration & concurrency tests
node --experimental-strip-types --test tests/commerce.test.ts

# Python monetary, TOTP, storage & webhook unit tests
python3 -m unittest discover -s backend/tests -p "test_*.py"
```

---

## Full Docker Compose Stack (PostgreSQL + FastAPI + MinIO + Worker + Next.js)

```bash
cp .env.example .env
# Set strong POSTGRES_PASSWORD, SESSION_SECRET, PAYMENT_WEBHOOK_SECRET, DOWNLOAD_SIGNING_SECRET
docker compose up --build
```

Services:
- Storefront & Admin UI: `http://localhost:3000`
- FastAPI OpenAPI Docs: `http://localhost:8000/docs`
- MinIO Console: `http://localhost:9001`

---

## Acceptance & Verification Flows

1. **Catalogue & Product Detail**: Browse `/catalogue` with shareable filter URLs, inspect `/products/aureom-animate-3d`, switch between Digital Download, Boxed Download-Key (explicitly no disc), USB Collector Edition, and Source-Code Edition, and read versioned licence terms (`/licences/lic-personal-std`).
2. **Mixed Basket & UK Checkout**: Add digital + physical items, reserve a 15-minute workshop seat at `/workshops/python-basics-first-line` (formatted in `Europe/London` GMT/BST), confirm UK Consumer Contracts Regulations 2013 (Reg 37) digital waiver on `/checkout`, and complete simulated payment.
3. **Digital Library**: Sign in via `/account` (or click *Continue as Demo Customer*) and open `/library` to generate 10-minute signed download URLs, verify SHA-256 checksums, read documentation, and inspect download logs.
4. **Staff Administration Console (`/admin`)**: Claim the initial Staff Admin + TOTP MFA secret on first visit, process Click & Collect (`pick` → `pack` → `ready_for_collection` → `collect`), check in workshop attendees, promote quarantined releases, issue partial refunds, retry failed fulfilment jobs, and review the immutable Audit Log.
