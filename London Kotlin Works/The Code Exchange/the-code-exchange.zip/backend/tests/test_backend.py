import pathlib
import tempfile
import unittest

from app.money import calculate_basket_totals, PricingLine, split_vat_from_gross_pence
from app.payments import SimulatedPaymentProvider
from app.security import hash_password, redact_dict, verify_password
from app.storage import LocalFilesystemStorageAdapter


class BackendCoreTests(unittest.TestCase):
    def test_uk_vat_and_basket_totals(self):
        net, vat = split_vat_from_gross_pence(14900, 2000)
        self.assertEqual(net + vat, 14900)
        self.assertEqual(vat, 2483)

        totals = calculate_basket_totals(
            [
                PricingLine(unit_price_pence=5900, quantity=1, requires_delivery=False, fulfilment_choice="digital"),
                PricingLine(unit_price_pence=3900, quantity=1, requires_delivery=True, fulfilment_choice="delivery"),
            ],
            discount_code="CODE10",
        )
        self.assertEqual(totals.items_gross_pence, 9800)
        self.assertEqual(totals.discount_pence, 980)
        self.assertEqual(totals.delivery_pence, 495)
        self.assertEqual(totals.total_pence, 9315)
        self.assertTrue(totals.requires_shipping_address)
        self.assertTrue(totals.has_digital_items)

    def test_payment_webhook_hmac_verification(self):
        provider = SimulatedPaymentProvider("super_secret_webhook_key")
        body = b'{"eventId":"evt_1","paymentIntentId":"pi_1","outcome":"succeeded"}'
        sig = provider.sign_webhook(body)
        self.assertTrue(provider.verify_webhook(body, sig))
        self.assertFalse(provider.verify_webhook(body, "tampered"))

    def test_storage_quarantine_promotion_and_path_traversal_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            storage = LocalFilesystemStorageAdapter(pathlib.Path(tmp))
            digest, size = storage.put_quarantined_object("demo/test.zip", b"PK-demo-bytes")
            self.assertEqual(size, 13)
            self.assertEqual(len(digest), 64)
            storage.promote_to_published("demo/test.zip", "demo/test.zip")
            self.assertTrue((pathlib.Path(tmp) / "releases" / "demo" / "test.zip").exists())

            with self.assertRaises(ValueError):
                storage.put_quarantined_object("../../etc/passwd", b"bad")

    def test_password_hashing_and_log_redaction(self):
        hashed = hash_password("LondonExchange2026!")
        self.assertTrue(verify_password("LondonExchange2026!", hashed))
        self.assertFalse(verify_password("WrongPass", hashed))

        redacted = redact_dict({"email": "a@b.co.uk", "password": "secret", "mfa_secret": "JBSWY3DPEHPK3PXP"})
        self.assertEqual(redacted["password"], "[REDACTED]")
        self.assertEqual(redacted["mfa_secret"], "[REDACTED]")
        self.assertEqual(redacted["email"], "a@b.co.uk")


if __name__ == "__main__":
    unittest.main()
