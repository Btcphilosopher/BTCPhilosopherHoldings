"""Initial PostgreSQL schema for The Code Exchange

Revision ID: 0001_initial
Revises:
Create Date: 2026-11-25 11:00:00
"""

from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("password_hash", sa.Text(), nullable=False),
        sa.Column("role", sa.String(32), nullable=False, server_default="customer"),
        sa.Column("mfa_secret", sa.String(128), nullable=True),
        sa.Column("mfa_enabled", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "stores",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("slug", sa.String(128), nullable=False, unique=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("address_line", sa.String(255), nullable=False),
        sa.Column("city", sa.String(128), nullable=False),
        sa.Column("postcode", sa.String(32), nullable=False),
        sa.Column("phone", sa.String(64), nullable=False),
        sa.Column("opening_hours_json", sa.Text(), nullable=False),
        sa.Column("collection_instructions", sa.Text(), nullable=False),
        sa.Column("stock_updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "licences",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("code", sa.String(64), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("version", sa.String(32), nullable=False),
        sa.Column("summary", sa.Text(), nullable=False),
        sa.Column("full_text", sa.Text(), nullable=False),
        sa.Column("redistributable_source", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("commercial_use", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("seat_limit", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("effective_date", sa.String(32), nullable=False),
    )
    op.create_table(
        "products",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("slug", sa.String(128), nullable=False, unique=True),
        sa.Column("sku_prefix", sa.String(32), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("subtitle", sa.Text(), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("category", sa.String(64), nullable=False),
        sa.Column("publisher", sa.String(255), nullable=False),
        sa.Column("platforms_json", sa.Text(), nullable=False),
        sa.Column("languages_json", sa.Text(), nullable=False),
        sa.Column("requirements_json", sa.Text(), nullable=False),
        sa.Column("release_version", sa.String(64), nullable=False),
        sa.Column("source_included", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("update_entitlement", sa.Text(), nullable=False),
        sa.Column("third_party_notices", sa.Text(), nullable=False),
        sa.Column("documentation_markdown", sa.Text(), nullable=False),
        sa.Column("image_url", sa.Text(), nullable=False),
        sa.Column("is_demo_listing", sa.Boolean(), nullable=False, server_default=sa.true()),
    )
    op.create_table(
        "editions",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("product_id", sa.String(64), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sku", sa.String(64), nullable=False, unique=True),
        sa.Column("name", sa.String(128), nullable=False),
        sa.Column("edition_type", sa.String(64), nullable=False),
        sa.Column("delivery_method", sa.String(255), nullable=False),
        sa.Column("price_pence", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="GBP"),
        sa.Column("vat_rate_bps", sa.Integer(), nullable=False, server_default="2000"),
        sa.Column("licence_id", sa.String(64), sa.ForeignKey("licences.id"), nullable=False),
        sa.Column("includes_json", sa.Text(), nullable=False),
        sa.Column("physical_contents_note", sa.Text(), nullable=False),
        sa.Column("requires_shipping", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
    )
    op.create_table(
        "stock_locations",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("edition_id", sa.String(64), sa.ForeignKey("editions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("store_id", sa.String(64), sa.ForeignKey("stores.id", ondelete="CASCADE"), nullable=True),
        sa.Column("on_hand", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("reserved", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("edition_id", "store_id", name="uq_edition_store"),
    )
    op.create_table(
        "workshops",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("slug", sa.String(128), nullable=False, unique=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("instructor", sa.String(255), nullable=False),
        sa.Column("level", sa.String(64), nullable=False),
        sa.Column("format", sa.String(64), nullable=False),
        sa.Column("store_id", sa.String(64), sa.ForeignKey("stores.id"), nullable=True),
        sa.Column("starts_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("ends_at_utc", sa.DateTime(timezone=True), nullable=False),
        sa.Column("display_timezone", sa.String(64), nullable=False, server_default="Europe/London"),
        sa.Column("capacity", sa.Integer(), nullable=False),
        sa.Column("price_pence", sa.Integer(), nullable=False),
    )
    op.create_table(
        "orders",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("order_number", sa.String(64), nullable=False, unique=True),
        sa.Column("user_id", sa.String(64), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("customer_email", sa.String(255), nullable=False),
        sa.Column("customer_name", sa.String(255), nullable=False),
        sa.Column("status", sa.String(64), nullable=False),
        sa.Column("subtotal_net_pence", sa.Integer(), nullable=False),
        sa.Column("discount_pence", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("vat_pence", sa.Integer(), nullable=False),
        sa.Column("delivery_pence", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("total_pence", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="GBP"),
        sa.Column("terms_accepted_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("digital_waiver_accepted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "payment_intents",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("order_id", sa.String(64), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("idempotency_key", sa.String(128), nullable=False, unique=True),
        sa.Column("provider", sa.String(64), nullable=False),
        sa.Column("provider_ref", sa.String(128), nullable=False),
        sa.Column("amount_pence", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="GBP"),
        sa.Column("status", sa.String(64), nullable=False),
        sa.Column("webhook_event_ids_json", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "fulfilment_jobs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("order_id", sa.String(64), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("job_type", sa.String(64), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "audit_logs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("actor_email", sa.String(255), nullable=False),
        sa.Column("actor_role", sa.String(32), nullable=False),
        sa.Column("action", sa.String(128), nullable=False),
        sa.Column("target_type", sa.String(64), nullable=False),
        sa.Column("target_id", sa.String(64), nullable=False),
        sa.Column("details_json", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )


def downgrade() -> None:
    for tbl in [
        "audit_logs",
        "fulfilment_jobs",
        "payment_intents",
        "orders",
        "workshops",
        "stock_locations",
        "editions",
        "products",
        "licences",
        "stores",
        "users",
    ]:
        op.drop_table(tbl)
