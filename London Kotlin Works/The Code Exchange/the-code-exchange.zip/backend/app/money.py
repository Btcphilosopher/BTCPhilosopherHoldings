from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from typing import Iterable

FREE_DELIVERY_THRESHOLD_PENCE = 10000
STANDARD_UK_DELIVERY_PENCE = 495


@dataclass(frozen=True)
class PricingLine:
    unit_price_pence: int
    quantity: int
    requires_delivery: bool
    fulfilment_choice: str  # digital | delivery | collect | workshop
    vat_rate_bps: int = 2000


@dataclass(frozen=True)
class BasketTotals:
    items_gross_pence: int
    items_net_pence: int
    discount_pence: int
    tax_pence: int
    delivery_pence: int
    total_pence: int
    currency: str
    applied_discount_code: str | None
    requires_shipping_address: bool
    has_digital_items: bool


def split_vat_from_gross_pence(gross_pence: int, vat_rate_bps: int = 2000) -> tuple[int, int]:
    if gross_pence <= 0 or vat_rate_bps <= 0:
        return max(0, gross_pence), 0
    gross = Decimal(gross_pence)
    rate = Decimal(vat_rate_bps)
    denom = Decimal(10000) + rate
    vat = int(((gross * rate) / denom).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return gross_pence - vat, vat


def evaluate_discount_pence(code: str | None, items_gross_pence: int) -> tuple[int, str | None]:
    normalized = (code or "").strip().upper()
    if not normalized or items_gross_pence <= 0:
        return 0, None
    if normalized == "CODE10":
        disc = int((Decimal(items_gross_pence) * Decimal("0.10")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        return disc, "CODE10"
    if normalized == "WELCOME5":
        return min(500, items_gross_pence), "WELCOME5"
    if normalized == "WORKSHOP20" and items_gross_pence >= 10000:
        return 2000, "WORKSHOP20"
    return 0, None


def calculate_basket_totals(
    lines: Iterable[PricingLine],
    discount_code: str | None = None,
) -> BasketTotals:
    items_gross = 0
    delivery_eligible_gross = 0
    requires_shipping = False
    has_digital = False

    for line in lines:
        qty = max(0, int(line.quantity))
        line_gross = int(line.unit_price_pence) * qty
        items_gross += line_gross
        if line.fulfilment_choice == "delivery" and line.requires_delivery:
            requires_shipping = True
            delivery_eligible_gross += line_gross
        if line.fulfilment_choice == "digital":
            has_digital = True

    discount_pence, applied_code = evaluate_discount_pence(discount_code, items_gross)
    discounted_items = max(0, items_gross - discount_pence)
    delivery_pence = (
        STANDARD_UK_DELIVERY_PENCE
        if requires_shipping and delivery_eligible_gross < FREE_DELIVERY_THRESHOLD_PENCE
        else 0
    )
    total_pence = discounted_items + delivery_pence

    items_net, items_vat = split_vat_from_gross_pence(discounted_items, 2000)
    _, delivery_vat = split_vat_from_gross_pence(delivery_pence, 2000)

    return BasketTotals(
        items_gross_pence=items_gross,
        items_net_pence=items_net,
        discount_pence=discount_pence,
        tax_pence=items_vat + delivery_vat,
        delivery_pence=delivery_pence,
        total_pence=total_pence,
        currency="GBP",
        applied_discount_code=applied_code,
        requires_shipping_address=requires_shipping,
        has_digital_items=has_digital,
    )
