import os
import secrets
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "The Code Exchange API"
    database_url: str = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg://codeexchange:codeexchange@localhost:5432/codeexchange",
    )
    s3_endpoint: str = os.getenv("S3_ENDPOINT", "http://localhost:9000")
    s3_bucket: str = os.getenv("S3_BUCKET", "code-exchange-releases")
    s3_access_key: str = os.getenv("S3_ACCESS_KEY", "")
    s3_secret_key: str = os.getenv("S3_SECRET_KEY", "")
    s3_region: str = os.getenv("S3_REGION", "eu-west-2")

    session_secret: str = os.getenv("SESSION_SECRET") or secrets.token_hex(32)
    payment_webhook_secret: str = os.getenv("PAYMENT_WEBHOOK_SECRET") or secrets.token_hex(32)
    download_signing_secret: str = os.getenv("DOWNLOAD_SIGNING_SECRET") or secrets.token_hex(32)
    admin_passcode: str = os.getenv("ADMIN_PASSCODE", "")
    stripe_secret_key: str = os.getenv("STRIPE_SECRET_KEY", "")


settings = Settings()
