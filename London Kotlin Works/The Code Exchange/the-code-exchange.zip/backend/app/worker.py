import time
from datetime import datetime, timezone
from sqlalchemy import select
from .db import SessionLocal
from .models import FulfilmentJob, Order
from .security import log_structured


def process_pending_jobs_once() -> int:
    processed = 0
    with SessionLocal() as db:
        jobs = (
            db.execute(
                select(FulfilmentJob)
                .where(FulfilmentJob.status.in_(["queued", "failed_retryable"]))
                .with_for_update(skip_locked=True)
            )
            .scalars()
            .all()
        )
        for job in jobs:
            try:
                order = db.get(Order, job.order_id)
                if order and order.status == "paid_fulfilling":
                    order.status = "fulfilled"
                job.status = "completed"
                job.attempts += 1
                job.last_error = None
                job.updated_at = datetime.now(timezone.utc)
                processed += 1
            except Exception as exc:
                job.attempts += 1
                job.status = "failed_retryable"
                job.last_error = str(exc)
                job.updated_at = datetime.now(timezone.utc)
        db.commit()
    if processed:
        log_structured("info", "worker.jobs_processed", count=processed)
    return processed


def main() -> None:
    log_structured("info", "worker.started")
    while True:
        try:
            process_pending_jobs_once()
        except Exception as exc:
            log_structured("error", "worker.loop_error", error=str(exc))
        time.sleep(5)


if __name__ == "__main__":
    main()
