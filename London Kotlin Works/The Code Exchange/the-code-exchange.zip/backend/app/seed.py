from datetime import datetime, timezone
import json
from sqlalchemy import select
from .db import SessionLocal
from .models import Edition, Licence, Product, StockLocation, Store, Workshop


def seed_postgres() -> None:
    now = datetime.now(timezone.utc)
    with SessionLocal() as db:
        if db.execute(select(Product).limit(1)).first():
            return

        lic = Licence(
            id="lic-personal-std",
            code="CX-PERSONAL-1.2",
            title="The Code Exchange Personal & Commercial Workstation Licence",
            version="1.2.0",
            summary="Single named user across up to 2 workstations.",
            full_text="Full UK licence terms.",
            redistributable_source=False,
            commercial_use=True,
            seat_limit=1,
            effective_date="2026-01-01",
        )
        db.add(lic)

        london = Store(
            id="store-london",
            slug="london-clerkenwell",
            name="London — Clerkenwell Flagship",
            address_line="42 St John Street, Clerkenwell",
            city="London",
            postcode="EC1M 4DL",
            phone="+44 20 7946 0821",
            opening_hours_json=json.dumps({"Mon-Fri": "09:30 - 19:00"}),
            collection_instructions="Ground Floor Collections Desk",
            stock_updated_at=now,
        )
        db.add(london)

        aureom = Product(
            id="prod-aureom",
            slug="aureom-animate-3d",
            sku_prefix="AUR-3D",
            title="Aureom Animate 3D",
            subtitle="Professional 3D animation and motion design for creatives and developers.",
            description="Illustrative demonstration catalogue listing for Aureom Animate 3D.",
            category="Creative",
            publisher="Aureom Studio Software Ltd",
            platforms_json=json.dumps(["macOS", "Windows", "Linux"]),
            languages_json=json.dumps(["Python", "GLSL"]),
            requirements_json=json.dumps({"Memory": "16 GB RAM"}),
            release_version="2026.2.1-demo",
            source_included=True,
            update_entitlement="12 months updates",
            third_party_notices="Apache-2.0 / PSF-2.0 references",
            documentation_markdown="# Aureom Animate 3D",
            image_url="/images/box-aureom.png",
            is_demo_listing=True,
        )
        db.add(aureom)

        db.add(
            Edition(
                id="ed-aureom-digital",
                product_id="prod-aureom",
                sku="AUR-3D-DIG",
                name="Digital Download",
                edition_type="digital_download",
                delivery_method="Instant Digital Library Download",
                price_pence=14900,
                licence_id="lic-personal-std",
                includes_json=json.dumps(["Demonstration ZIP archive"]),
                physical_contents_note="Digital only",
                requires_shipping=False,
            )
        )
        db.add(
            Edition(
                id="ed-aureom-usb",
                product_id="prod-aureom",
                sku="AUR-3D-USB",
                name="USB Collector Edition",
                edition_type="usb_edition",
                delivery_method="UK Tracked Delivery or Click & Collect",
                price_pence=17900,
                licence_id="lic-personal-std",
                includes_json=json.dumps(["Brushed steel USB drive"]),
                physical_contents_note="Physical USB collector edition",
                requires_shipping=True,
            )
        )
        db.add(
            StockLocation(
                id="stk-aur-usb-lon",
                edition_id="ed-aureom-usb",
                store_id="store-london",
                on_hand=1,
                reserved=0,
                updated_at=now,
            )
        )
        db.add(
            Workshop(
                id="ws-python-basics",
                slug="python-basics-first-line",
                title="Python Basics: From First Line to First App",
                instructor="Dr Hannah Pritchard",
                level="Beginner",
                format="In Store",
                store_id="store-london",
                starts_at_utc=datetime(2026, 7, 14, 17, 30, tzinfo=timezone.utc),
                ends_at_utc=datetime(2026, 7, 14, 20, 0, tzinfo=timezone.utc),
                display_timezone="Europe/London",
                capacity=12,
                price_pence=4500,
            )
        )
        db.commit()


if __name__ == "__main__":
    seed_postgres()
