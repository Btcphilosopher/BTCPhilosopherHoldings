from datetime import datetime, timezone
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from sqlalchemy import select, text
from sqlalchemy.orm import Session

from .config import settings
from .db import get_db
from .models import Edition, Order, PaymentIntent, Product, Store, Workshop
from .money import PricingLine, calculate_basket_totals
from .payments import SimulatedPaymentProvider
from .security import log_structured

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description="Modular monolith REST API for The Code Exchange UK software retail platform.",
)

payment_provider = SimulatedPaymentProvider(settings.payment_webhook_secret)


@app.get("/healthz")
def healthz():
    return {"status": "ok", "service": "code-exchange-api"}


@app.get("/readyz")
def readyz(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ready", "database": "postgresql"}


@app.get("/api/catalogue")
def list_catalogue(q: str | None = None, category: str | None = None, db: Session = Depends(get_db)):
    stmt = select(Product)
    if category and category.lower() != "all":
        stmt = stmt.where(Product.category == category)
    products = db.execute(stmt).scalars().all()
    if q:
        ql = q.lower()
        products = [p for p in products if ql in p.title.lower() or ql in p.description.lower()]
    return {"items": [{"id": p.id, "slug": p.slug, "title": p.title, "category": p.category} for p in products]}


@app.post("/api/pricing/quote")
def quote_basket(payload: dict, db: Session = Depends(get_db)):
    lines: list[PricingLine] = []
    for item in payload.get("items", []):
        ed = db.get(Edition, item.get("edition_id"))
        if not ed:
            raise HTTPException(status_code=404, detail="Edition not found")
        lines.append(
            PricingLine(
                unit_price_pence=ed.price_pence,
                quantity=int(item.get("quantity", 1)),
                requires_delivery=ed.requires_shipping,
                fulfilment_choice=item.get("fulfilment_choice", "digital"),
                vat_rate_bps=ed.vat_rate_bps,
            )
        )
    totals = calculate_basket_totals(lines, payload.get("discount_code"))
    return totals.__dict__


@app.post("/api/payments/webhook")
async def payment_webhook(
    request: Request,
    x_cx_signature: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    raw_body = await request.body()
    if not payment_provider.verify_webhook(raw_body, x_cx_signature):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    body = await request.json()
    pi = db.get(PaymentIntent, body.get("paymentIntentId"))
    if not pi:
        raise HTTPException(status_code=404, detail="PaymentIntent not found")

    import json

    seen = json.loads(pi.webhook_event_ids_json or "[]")
    event_id = str(body.get("eventId"))
    if event_id in seen:
        return {"received": True, "duplicate": True, "status": pi.status}

    seen.append(event_id)
    pi.webhook_event_ids_json = json.dumps(seen)
    pi.status = "succeeded" if body.get("outcome") == "succeeded" else str(body.get("outcome"))
    pi.updated_at = datetime.now(timezone.utc)
    order = db.get(Order, pi.order_id)
    if order and pi.status == "succeeded":
        order.status = "paid_fulfilling"
    db.commit()
    log_structured("info", "webhook.processed", payment_intent_id=pi.id, outcome=pi.status)
    return {"received": True, "duplicate": False, "status": pi.status}


@app.get("/api/stores")
def list_stores(db: Session = Depends(get_db)):
    stores = db.execute(select(Store)).scalars().all()
    return {"stores": [{"id": s.id, "slug": s.slug, "name": s.name, "postcode": s.postcode} for s in stores]}


@app.get("/api/workshops")
def list_workshops(db: Session = Depends(get_db)):
    workshops = db.execute(select(Workshop)).scalars().all()
    return {
        "workshops": [
            {
                "id": w.id,
                "slug": w.slug,
                "title": w.title,
                "display_timezone": w.display_timezone,
                "starts_at_utc": w.starts_at_utc.isoformat(),
                "price_pence": w.price_pence,
            }
            for w in workshops
        ]
    }
