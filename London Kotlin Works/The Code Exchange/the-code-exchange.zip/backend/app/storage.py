import hashlib
from pathlib import Path
from typing import Protocol


class ObjectStorageAdapter(Protocol):
    def put_quarantined_object(self, key: str, data: bytes) -> tuple[str, int]:
        ...

    def promote_to_published(self, quarantine_key: str, release_key: str) -> None:
        ...

    def generate_download_url(self, release_key: str, expires_seconds: int = 600) -> str:
        ...


class S3ObjectStorageAdapter:
    """S3-compatible (MinIO / AWS S3) adapter for product images and protected release downloads."""

    def __init__(self, endpoint: str, bucket: str, access_key: str, secret_key: str, region: str) -> None:
        self.endpoint = endpoint
        self.bucket = bucket
        self.access_key = access_key
        self.secret_key = secret_key
        self.region = region

    def _client(self):
        import boto3  # type: ignore

        return boto3.client(
            "s3",
            endpoint_url=self.endpoint,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            region_name=self.region,
        )

    def put_quarantined_object(self, key: str, data: bytes) -> tuple[str, int]:
        digest = hashlib.sha256(data).hexdigest()
        quarantine_key = f"quarantine/{key.lstrip('/')}"
        self._client().put_object(Bucket=self.bucket, Key=quarantine_key, Body=data)
        return digest, len(data)

    def promote_to_published(self, quarantine_key: str, release_key: str) -> None:
        client = self._client()
        client.copy_object(
            Bucket=self.bucket,
            CopySource={"Bucket": self.bucket, "Key": quarantine_key},
            Key=f"releases/{release_key.lstrip('/')}",
        )
        client.delete_object(Bucket=self.bucket, Key=quarantine_key)

    def generate_download_url(self, release_key: str, expires_seconds: int = 600) -> str:
        return self._client().generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket, "Key": f"releases/{release_key.lstrip('/')}"},
            ExpiresIn=expires_seconds,
        )


class LocalFilesystemStorageAdapter:
    """Hermetic local adapter for tests and development without MinIO."""

    def __init__(self, root_dir: Path) -> None:
        self.root_dir = root_dir.resolve()
        (self.root_dir / "quarantine").mkdir(parents=True, exist_ok=True)
        (self.root_dir / "releases").mkdir(parents=True, exist_ok=True)

    def _safe_path(self, bucket_prefix: str, key: str) -> Path:
        base = (self.root_dir / bucket_prefix).resolve()
        target = (base / key.lstrip("/")).resolve()
        if not str(target).startswith(str(base) + "/"):
            raise ValueError("Path traversal rejected")
        target.parent.mkdir(parents=True, exist_ok=True)
        return target

    def put_quarantined_object(self, key: str, data: bytes) -> tuple[str, int]:
        digest = hashlib.sha256(data).hexdigest()
        dest = self._safe_path("quarantine", key)
        dest.write_bytes(data)
        return digest, len(data)

    def promote_to_published(self, quarantine_key: str, release_key: str) -> None:
        src = self._safe_path("quarantine", quarantine_key)
        dst = self._safe_path("releases", release_key)
        dst.write_bytes(src.read_bytes())
        src.unlink(missing_ok=True)

    def generate_download_url(self, release_key: str, expires_seconds: int = 600) -> str:
        return f"/api/downloads/file?key={release_key}"
