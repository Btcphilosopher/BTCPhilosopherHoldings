from abc import ABC, abstractmethod
from dataclasses import dataclass
import hashlib
import hmac
import secrets


@dataclass(frozen=True)
class PaymentIntentResult:
    provider: str
    provider_ref: str
    status: str


class PaymentProvider(ABC):
    @abstractmethod
    def create_intent(self, order_id: str, amount_pence: int, currency: str, idempotency_key: str) -> PaymentIntentResult:
        ...

    @abstractmethod
    def refund(self, provider_ref: str, amount_pence: int, reason: str) -> str:
        ...

    @abstractmethod
    def verify_webhook(self, raw_body: bytes, signature_header: str | None) -> bool:
        ...


class SimulatedPaymentProvider(PaymentProvider):
    def __init__(self, webhook_secret: str) -> None:
        self._secret = webhook_secret.encode("utf-8")

    def create_intent(self, order_id: str, amount_pence: int, currency: str, idempotency_key: str) -> PaymentIntentResult:
        ref = f"sim_pi_{secrets.token_hex(8)}"
        return PaymentIntentResult(provider="simulated", provider_ref=ref, status="requires_confirmation")

    def refund(self, provider_ref: str, amount_pence: int, reason: str) -> str:
        return f"sim_re_{secrets.token_hex(8)}"

    def sign_webhook(self, raw_body: bytes) -> str:
        return hmac.new(self._secret, raw_body, hashlib.sha256).hexdigest()

    def verify_webhook(self, raw_body: bytes, signature_header: str | None) -> bool:
        if not signature_header:
            return False
        expected = self.sign_webhook(raw_body)
        return hmac.compare_digest(expected, signature_header)


class StripeSandboxProvider(PaymentProvider):
    """Replaceable Stripe sandbox adapter skeleton following the exact PaymentProvider contract."""

    def __init__(self, api_key: str, webhook_secret: str) -> None:
        self._api_key = api_key
        self._webhook_secret = webhook_secret

    def create_intent(self, order_id: str, amount_pence: int, currency: str, idempotency_key: str) -> PaymentIntentResult:
        if not self._api_key:
            raise RuntimeError("STRIPE_SECRET_KEY is not configured")
        return PaymentIntentResult(
            provider="stripe_sandbox",
            provider_ref=f"pi_sandbox_{secrets.token_hex(8)}",
            status="requires_confirmation",
        )

    def refund(self, provider_ref: str, amount_pence: int, reason: str) -> str:
        return f"re_sandbox_{secrets.token_hex(8)}"

    def verify_webhook(self, raw_body: bytes, signature_header: str | None) -> bool:
        if not signature_header or not self._webhook_secret:
            return False
        expected = hmac.new(self._webhook_secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature_header)
