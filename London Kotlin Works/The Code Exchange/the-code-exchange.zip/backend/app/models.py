from datetime import datetime
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    password_hash: Mapped[str] = mapped_column(Text)
    role: Mapped[str] = mapped_column(String(32), default="customer")
    mfa_secret: Mapped[str | None] = mapped_column(String(128), nullable=True)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Store(Base):
    __tablename__ = "stores"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    slug: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    address_line: Mapped[str] = mapped_column(String(255))
    city: Mapped[str] = mapped_column(String(128))
    postcode: Mapped[str] = mapped_column(String(32))
    phone: Mapped[str] = mapped_column(String(64))
    opening_hours_json: Mapped[str] = mapped_column(Text)
    collection_instructions: Mapped[str] = mapped_column(Text)
    stock_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Licence(Base):
    __tablename__ = "licences"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    code: Mapped[str] = mapped_column(String(64), index=True)
    title: Mapped[str] = mapped_column(String(255))
    version: Mapped[str] = mapped_column(String(32))
    summary: Mapped[str] = mapped_column(Text)
    full_text: Mapped[str] = mapped_column(Text)
    redistributable_source: Mapped[bool] = mapped_column(Boolean, default=False)
    commercial_use: Mapped[bool] = mapped_column(Boolean, default=True)
    seat_limit: Mapped[int] = mapped_column(Integer, default=1)
    effective_date: Mapped[str] = mapped_column(String(32))


class Product(Base):
    __tablename__ = "products"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    slug: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    sku_prefix: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(255))
    subtitle: Mapped[str] = mapped_column(Text)
    description: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(64), index=True)
    publisher: Mapped[str] = mapped_column(String(255))
    platforms_json: Mapped[str] = mapped_column(Text)
    languages_json: Mapped[str] = mapped_column(Text)
    requirements_json: Mapped[str] = mapped_column(Text)
    release_version: Mapped[str] = mapped_column(String(64))
    source_included: Mapped[bool] = mapped_column(Boolean, default=False)
    update_entitlement: Mapped[str] = mapped_column(Text)
    third_party_notices: Mapped[str] = mapped_column(Text)
    documentation_markdown: Mapped[str] = mapped_column(Text)
    image_url: Mapped[str] = mapped_column(Text)
    is_demo_listing: Mapped[bool] = mapped_column(Boolean, default=True)


class Edition(Base):
    __tablename__ = "editions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    product_id: Mapped[str] = mapped_column(ForeignKey("products.id", ondelete="CASCADE"))
    sku: Mapped[str] = mapped_column(String(64), unique=True)
    name: Mapped[str] = mapped_column(String(128))
    edition_type: Mapped[str] = mapped_column(String(64))
    delivery_method: Mapped[str] = mapped_column(String(255))
    price_pence: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    vat_rate_bps: Mapped[int] = mapped_column(Integer, default=2000)
    licence_id: Mapped[str] = mapped_column(ForeignKey("licences.id"))
    includes_json: Mapped[str] = mapped_column(Text)
    physical_contents_note: Mapped[str] = mapped_column(Text)
    requires_shipping: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class StockLocation(Base):
    __tablename__ = "stock_locations"
    __table_args__ = (UniqueConstraint("edition_id", "store_id", name="uq_edition_store"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    edition_id: Mapped[str] = mapped_column(ForeignKey("editions.id", ondelete="CASCADE"))
    store_id: Mapped[str | None] = mapped_column(ForeignKey("stores.id", ondelete="CASCADE"), nullable=True)
    on_hand: Mapped[int] = mapped_column(Integer, default=0)
    reserved: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Workshop(Base):
    __tablename__ = "workshops"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    slug: Mapped[str] = mapped_column(String(128), unique=True)
    title: Mapped[str] = mapped_column(String(255))
    instructor: Mapped[str] = mapped_column(String(255))
    level: Mapped[str] = mapped_column(String(64))
    format: Mapped[str] = mapped_column(String(64))
    store_id: Mapped[str | None] = mapped_column(ForeignKey("stores.id"), nullable=True)
    starts_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    ends_at_utc: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    display_timezone: Mapped[str] = mapped_column(String(64), default="Europe/London")
    capacity: Mapped[int] = mapped_column(Integer)
    price_pence: Mapped[int] = mapped_column(Integer)


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_number: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    customer_email: Mapped[str] = mapped_column(String(255))
    customer_name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(64))
    subtotal_net_pence: Mapped[int] = mapped_column(Integer)
    discount_pence: Mapped[int] = mapped_column(Integer, default=0)
    vat_pence: Mapped[int] = mapped_column(Integer)
    delivery_pence: Mapped[int] = mapped_column(Integer, default=0)
    total_pence: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    terms_accepted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    digital_waiver_accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class PaymentIntent(Base):
    __tablename__ = "payment_intents"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_id: Mapped[str] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"))
    idempotency_key: Mapped[str] = mapped_column(String(128), unique=True)
    provider: Mapped[str] = mapped_column(String(64))
    provider_ref: Mapped[str] = mapped_column(String(128))
    amount_pence: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="GBP")
    status: Mapped[str] = mapped_column(String(64))
    webhook_event_ids_json: Mapped[str] = mapped_column(Text, default="[]")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class FulfilmentJob(Base):
    __tablename__ = "fulfilment_jobs"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_id: Mapped[str] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"))
    job_type: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32), index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    actor_email: Mapped[str] = mapped_column(String(255))
    actor_role: Mapped[str] = mapped_column(String(32))
    action: Mapped[str] = mapped_column(String(128))
    target_type: Mapped[str] = mapped_column(String(64))
    target_id: Mapped[str] = mapped_column(String(64))
    details_json: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
