import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
import struct
import time
from typing import Any

REDACTED_KEYS = {"password", "password_hash", "secret", "token", "authorization", "cookie", "card", "cvv", "mfa_secret"}


def redact_dict(data: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in data.items():
        if k.lower() in REDACTED_KEYS:
            out[k] = "[REDACTED]"
        elif isinstance(v, dict):
            out[k] = redact_dict(v)
        else:
            out[k] = v
    return out


def log_structured(level: str, event: str, **meta: Any) -> None:
    payload = {"event": event, "level": level, **redact_dict(meta)}
    logging.getLogger("codeexchange").info(json.dumps(payload))


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    derived = hashlib.scrypt(password.encode("utf-8"), salt=salt.encode("utf-8"), n=16384, r=8, p=1, dklen=64)
    return f"scrypt${salt}${derived.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    parts = stored_hash.split("$")
    if len(parts) != 3 or parts[0] != "scrypt":
        return False
    _, salt, expected_hex = parts
    derived = hashlib.scrypt(password.encode("utf-8"), salt=salt.encode("utf-8"), n=16384, r=8, p=1, dklen=64)
    expected = bytes.fromhex(expected_hex)
    return hmac.compare_digest(derived, expected)


def verify_totp(secret_b32: str, code: str, window: int = 1) -> bool:
    clean_code = code.strip()
    if len(clean_code) != 6 or not clean_code.isdigit():
        return False
    padded = secret_b32.upper().replace(" ", "")
    padded += "=" * ((8 - len(padded) % 8) % 8)
    key = base64.b32decode(padded)
    counter = int(time.time() // 30)
    for delta in range(-window, window + 1):
        msg = struct.pack(">Q", counter + delta)
        digest = hmac.new(key, msg, hashlib.sha1).digest()
        offset = digest[-1] & 0x0F
        num = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
        if hmac.compare_digest(f"{num % 1000000:06d}", clean_code):
            return True
    return False
