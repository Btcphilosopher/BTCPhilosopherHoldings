import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import {
  calculateBasketTotals,
  splitVatFromGrossPence,
} from '../src/server/money.ts';
import {
  bootstrapFirstAdmin,
  requireStaffRole,
} from '../src/server/auth-session.ts';
import {
  advancePhysicalFulfilment,
  applyPaymentWebhookEvent,
  createOrderFromBasket,
  createSignedDownloadUrlForEntitlement,
  createWorkshopHold,
  expireStaleWorkshopHolds,
  formatWorkshopTimeUK,
  getWorkshopAvailability,
  processOrderItemRefund,
  runFulfilmentJobs,
  triggerSignedPaymentSimulation,
} from '../src/server/commerce.ts';
import { getDb } from '../src/server/db.ts';
import { seedDatabaseIfEmpty } from '../src/server/seed.ts';
import { generateTotpCode, verifyDownloadToken, verifyTotpCode } from '../src/server/security.ts';

function createFreshTestDb() {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cx-test-'));
  process.env.DATA_DIR = tmpDir;
  const dbPath = path.join(tmpDir, 'test.db');
  const db = getDb(dbPath);
  seedDatabaseIfEmpty(db);
  return { db, tmpDir };
}

test('Monetary calculations: integer minor units, UK VAT 20%, discounts, and delivery threshold', () => {
  const split = splitVatFromGrossPence(14900, 2000);
  assert.equal(split.netPence + split.vatPence, 14900);
  assert.equal(split.vatPence, 2483);
  assert.equal(split.netPence, 12417);

  // Physical order under £100 incurs £4.95 delivery
  const under100 = calculateBasketTotals([
    {
      id: '1',
      itemType: 'edition',
      title: 'Python Starter Kit',
      editionName: 'Physical Boxed',
      unitPricePence: 3900,
      quantity: 1,
      requiresDelivery: true,
      fulfilmentChoice: 'delivery',
      vatRateBps: 2000,
    },
  ]);
  assert.equal(under100.deliveryPence, 495);
  assert.equal(under100.totalPence, 4395);

  // Mixed order with CODE10 discount and Click & Collect (free delivery)
  const mixed = calculateBasketTotals(
    [
      {
        id: '1',
        itemType: 'edition',
        title: 'Aureom Animate 3D',
        editionName: 'Digital',
        unitPricePence: 14900,
        quantity: 1,
        requiresDelivery: false,
        fulfilmentChoice: 'digital',
        vatRateBps: 2000,
      },
      {
        id: '2',
        itemType: 'edition',
        title: 'Python Starter Kit',
        editionName: 'Boxed',
        unitPricePence: 3900,
        quantity: 1,
        requiresDelivery: true,
        fulfilmentChoice: 'collect',
        vatRateBps: 2000,
      },
    ],
    'CODE10'
  );
  assert.equal(mixed.itemsGrossPence, 18800);
  assert.equal(mixed.discountPence, 1880);
  assert.equal(mixed.deliveryPence, 0);
  assert.equal(mixed.totalPence, 16920);
  assert.equal(mixed.itemsNetPence + mixed.taxPence, mixed.totalPence);
});

test('Workshop BST vs GMT timezone formatting in Europe/London', () => {
  const summer = formatWorkshopTimeUK('2026-07-14T17:30:00Z', 'Europe/London');
  assert.equal(summer.tzAbbrev, 'BST');
  assert.equal(summer.timeLabel, '18:30 BST');

  const winter = formatWorkshopTimeUK('2026-12-03T18:00:00Z', 'Europe/London');
  assert.equal(winter.tzAbbrev, 'GMT');
  assert.equal(winter.timeLabel, '18:00 GMT');
});

test('Competing purchases of the last physical item in London store', () => {
  const { db } = createFreshTestDb();
  const now = new Date().toISOString();

  // Create two baskets each requesting 1 × Aureom USB Collector Edition (Click & Collect London where on_hand=1)
  db.prepare(`INSERT INTO baskets (id, created_at, updated_at) VALUES ('bsk-a', ?, ?)`).run(now, now);
  db.prepare(`INSERT INTO baskets (id, created_at, updated_at) VALUES ('bsk-b', ?, ?)`).run(now, now);

  db.prepare(
    `INSERT INTO basket_items (id, basket_id, item_type, edition_id, fulfilment_choice, store_id, quantity, unit_price_pence)
     VALUES ('bi-a', 'bsk-a', 'edition', 'ed-aureom-usb', 'collect', 'store-london', 1, 17900)`
  ).run();
  db.prepare(
    `INSERT INTO basket_items (id, basket_id, item_type, edition_id, fulfilment_choice, store_id, quantity, unit_price_pence)
     VALUES ('bi-b', 'bsk-b', 'edition', 'ed-aureom-usb', 'collect', 'store-london', 1, 17900)`
  ).run();

  const first = createOrderFromBasket(db, {
    basketId: 'bsk-a',
    userId: null,
    customerEmail: 'buyer1@example.co.uk',
    customerName: 'Buyer One',
    shippingAddress: null,
    termsAccepted: true,
    digitalWaiverAccepted: false,
    idempotencyKey: 'idem-comp-1',
  });
  assert.equal(first.order.status, 'awaiting_payment');

  // Second competing buyer MUST fail atomically with insufficient stock
  assert.throws(
    () =>
      createOrderFromBasket(db, {
        basketId: 'bsk-b',
        userId: null,
        customerEmail: 'buyer2@example.co.uk',
        customerName: 'Buyer Two',
        shippingAddress: null,
        termsAccepted: true,
        digitalWaiverAccepted: false,
        idempotencyKey: 'idem-comp-2',
      }),
    /Insufficient stock/
  );

  // If Buyer One cancels payment, reservation releases and Buyer Two can now purchase!
  applyPaymentWebhookEvent(db, {
    eventId: 'evt-cancel-1',
    paymentIntentId: first.paymentIntent.id as string,
    outcome: 'cancelled',
  });

  const secondAfterCancel = createOrderFromBasket(db, {
    basketId: 'bsk-b',
    userId: null,
    customerEmail: 'buyer2@example.co.uk',
    customerName: 'Buyer Two',
    shippingAddress: null,
    termsAccepted: true,
    digitalWaiverAccepted: false,
    idempotencyKey: 'idem-comp-3',
  });
  assert.equal(secondAfterCancel.order.status, 'awaiting_payment');
});

test('Workshop capacity holds & expired hold release', () => {
  const { db } = createFreshTestDb();
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO baskets (id, created_at, updated_at) VALUES ('bsk-ws', ?, ?)`).run(now, now);

  // ws-source-code has capacity 2 with 1 seeded booking -> 1 seat remaining
  const availBefore = getWorkshopAvailability(db, 'ws-source-code');
  assert.equal(availBefore?.remaining, 1);

  // Hold the last seat with -10s TTL (already expired)
  const { holdId } = createWorkshopHold(db, 'ws-source-code', 'bsk-ws', null, 1, -10);
  assert.ok(holdId);

  // Expiry cleanup releases the hold immediately
  const expiredCount = expireStaleWorkshopHolds(db);
  assert.equal(expiredCount, 1);
  const availAfter = getWorkshopAvailability(db, 'ws-source-code');
  assert.equal(availAfter?.remaining, 1);
});

test('Idempotency, duplicate webhook safety, failed fulfilment recovery, entitlement enforcement & refunds', () => {
  const { db } = createFreshTestDb();
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO baskets (id, created_at, updated_at) VALUES ('bsk-e2e', ?, ?)`).run(now, now);
  db.prepare(
    `INSERT INTO basket_items (id, basket_id, item_type, edition_id, fulfilment_choice, quantity, unit_price_pence)
     VALUES ('bi-e2e', 'bsk-e2e', 'edition', 'ed-aureom-digital', 'digital', 1, 14900)`
  ).run();

  const checkout1 = createOrderFromBasket(db, {
    basketId: 'bsk-e2e',
    userId: 'user-demo-customer',
    customerEmail: 'customer@codeexchange.co.uk',
    customerName: 'Oliver Bennett',
    shippingAddress: null,
    termsAccepted: true,
    digitalWaiverAccepted: true,
    idempotencyKey: 'idem-e2e-1',
    simulateFulfilmentFailOnce: true,
  });

  // Duplicate checkout submission with same idempotencyKey replays without double-ordering
  const checkoutReplay = createOrderFromBasket(db, {
    basketId: 'bsk-e2e',
    userId: 'user-demo-customer',
    customerEmail: 'customer@codeexchange.co.uk',
    customerName: 'Oliver Bennett',
    shippingAddress: null,
    termsAccepted: true,
    digitalWaiverAccepted: true,
    idempotencyKey: 'idem-e2e-1',
  });
  assert.equal(checkoutReplay.idempotentReplay, true);
  assert.equal(checkoutReplay.order.id, checkout1.order.id);

  // Payment succeeds via signed webhook, but job fails on attempt 1
  const sim = triggerSignedPaymentSimulation(db, {
    paymentIntentId: checkout1.paymentIntent.id as string,
    outcome: 'succeeded',
    eventId: 'evt-unique-1',
    basketIdToClear: 'bsk-e2e',
    simulateFulfilmentFailOnce: true,
  });
  assert.equal(sim.result.duplicate, false);

  const orderAfterFail = db
    .prepare('SELECT status FROM orders WHERE id = ?')
    .get(checkout1.order.id as string) as { status: string };
  assert.equal(orderAfterFail.status, 'fulfilment_attention');

  // Duplicate webhook callback with same eventId is safely ignored
  const dup = triggerSignedPaymentSimulation(db, {
    paymentIntentId: checkout1.paymentIntent.id as string,
    outcome: 'succeeded',
    eventId: 'evt-unique-1',
  });
  assert.equal(dup.result.duplicate, true);

  // Retry failed fulfilment job -> recovers cleanly!
  const retryRes = runFulfilmentJobs(db, checkout1.order.id as string);
  assert.equal(retryRes[0].status, 'completed');

  const ent = db
    .prepare('SELECT id, status FROM entitlements WHERE order_id = ?')
    .get(checkout1.order.id as string) as { id: string; status: string };
  assert.equal(ent.status, 'active');

  // Cannot download quarantined rc1 artefact
  assert.throws(
    () =>
      createSignedDownloadUrlForEntitlement(db, {
        entitlementId: ent.id,
        artefactId: 'art-aureom-rc1',
        userId: 'user-demo-customer',
        userEmail: 'customer@codeexchange.co.uk',
      }),
    /quarantined/
  );

  // Can download published artefact with verified short-lived token
  const signed = createSignedDownloadUrlForEntitlement(db, {
    entitlementId: ent.id,
    artefactId: 'art-aureom-2026',
    userId: 'user-demo-customer',
    userEmail: 'customer@codeexchange.co.uk',
  });
  const tokenParam = new URL(`http://localhost${signed.downloadUrl}`).searchParams.get('token')!;
  const decoded = verifyDownloadToken(tokenParam);
  assert.equal(decoded?.entitlementId, ent.id);

  // Another user cannot download this entitlement
  assert.throws(
    () =>
      createSignedDownloadUrlForEntitlement(db, {
        entitlementId: ent.id,
        artefactId: 'art-aureom-2026',
        userId: 'other-user',
        userEmail: 'intruder@example.co.uk',
      }),
    /permission/
  );

  // Refund revokes digital entitlement
  const orderItem = db
    .prepare('SELECT id FROM order_items WHERE order_id = ?')
    .get(checkout1.order.id as string) as { id: string };
  const refundRes = processOrderItemRefund(db, {
    orderId: checkout1.order.id as string,
    orderItemId: orderItem.id,
    quantity: 1,
    reason: 'Customer requested refund',
    actor: { id: 'admin-1', email: 'admin@codeexchange.co.uk', role: 'finance' },
  });
  assert.equal(refundRes.orderStatus, 'refunded');

  const revokedEnt = db
    .prepare('SELECT status FROM entitlements WHERE id = ?')
    .get(ent.id) as { status: string };
  assert.equal(revokedEnt.status, 'revoked');

  assert.throws(
    () =>
      createSignedDownloadUrlForEntitlement(db, {
        entitlementId: ent.id,
        artefactId: 'art-aureom-2026',
        userId: 'user-demo-customer',
        userEmail: 'customer@codeexchange.co.uk',
      }),
    /revoked/
  );
});

test('Staff RBAC, TOTP MFA verification, and physical click-and-collect lifecycle', () => {
  const { db } = createFreshTestDb();
  const claimed = bootstrapFirstAdmin(db, 'admin@codeexchange.co.uk', 'Ada Lovelace', 'StrongPass2026!');
  assert.equal(verifyTotpCode(claimed.totpSecret, generateTotpCode(claimed.totpSecret)), true);

  assert.throws(() => requireStaffRole(null, ['admin']), /UNAUTHORIZED/);
  assert.throws(
    () =>
      requireStaffRole(
        {
          id: 'u1',
          email: 'c@example.com',
          name: 'C',
          role: 'customer',
          mfaEnabled: false,
          mfaVerified: false,
        },
        ['warehouse_staff']
      ),
    /FORBIDDEN/
  );

  // Physical order collection & return policy
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO baskets (id, created_at, updated_at) VALUES ('bsk-col', ?, ?)`).run(now, now);
  db.prepare(
    `INSERT INTO basket_items (id, basket_id, item_type, edition_id, fulfilment_choice, store_id, quantity, unit_price_pence)
     VALUES ('bi-col', 'bsk-col', 'edition', 'ed-aureom-usb', 'collect', 'store-london', 1, 17900)`
  ).run();

  const ord = createOrderFromBasket(db, {
    basketId: 'bsk-col',
    userId: 'user-demo-customer',
    customerEmail: 'customer@codeexchange.co.uk',
    customerName: 'Oliver Bennett',
    shippingAddress: null,
    termsAccepted: true,
    digitalWaiverAccepted: false,
    idempotencyKey: 'idem-col-1',
  });
  triggerSignedPaymentSimulation(db, {
    paymentIntentId: ord.paymentIntent.id as string,
    outcome: 'succeeded',
    basketIdToClear: 'bsk-col',
  });

  const oi = db
    .prepare('SELECT id FROM order_items WHERE order_id = ?')
    .get(ord.order.id as string) as { id: string };

  const actor = { id: claimed.userId, email: 'admin@codeexchange.co.uk', role: 'warehouse_staff' };
  advancePhysicalFulfilment(db, { orderItemId: oi.id, action: 'pick', actor });
  advancePhysicalFulfilment(db, { orderItemId: oi.id, action: 'pack', actor });
  advancePhysicalFulfilment(db, { orderItemId: oi.id, action: 'ready_for_collection', actor });
  const collected = advancePhysicalFulfilment(db, { orderItemId: oi.id, action: 'collect', actor });
  assert.equal(collected.fulfilmentStatus, 'collected');

  const stockAfterCollect = db
    .prepare(`SELECT on_hand, reserved FROM stock_locations WHERE edition_id = 'ed-aureom-usb' AND store_id = 'store-london'`)
    .get() as { on_hand: number; reserved: number };
  assert.equal(stockAfterCollect.on_hand, 0);
  assert.equal(stockAfterCollect.reserved, 0);

  // Returning physical USB edition restores on_hand and revokes backup digital entitlement
  advancePhysicalFulfilment(db, { orderItemId: oi.id, action: 'return', actor });
  const entAfterReturn = db
    .prepare('SELECT status FROM entitlements WHERE order_item_id = ?')
    .get(oi.id) as { status: string };
  assert.equal(entAfterReturn.status, 'revoked');
});
