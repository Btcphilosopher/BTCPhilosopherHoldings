export function formatGBP(pence: number): string {
  const sign = pence < 0 ? '-' : '';
  const abs = Math.abs(Math.round(pence));
  const pounds = Math.floor(abs / 100);
  const rem = abs % 100;
  if (rem === 0 && abs >= 100) {
    return `${sign}£${pounds.toLocaleString('en-GB')}`;
  }
  return `${sign}£${(abs / 100).toFixed(2)}`;
}

export function formatGBPPrecise(pence: number): string {
  const sign = pence < 0 ? '-' : '';
  const abs = Math.abs(Math.round(pence));
  return `${sign}£${(abs / 100).toFixed(2)}`;
}

export function formatWorkshopUK(utcIso: string, tz = 'Europe/London'): string {
  const dt = new Date(utcIso);
  const datePart = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz,
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(dt);
  const timePart = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZoneName: 'short',
  }).format(dt);
  return `${datePart}, ${timePart}`;
}
