import Link from 'next/link';
import { getDb } from '@/src/server/db';

export const dynamic = 'force-dynamic';

export default async function LicencePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM licences WHERE id = ? OR code = ?')
    .get(id, id) as Record<string, unknown> | undefined;

  if (!row) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 space-y-4">
        <h1 className="font-display font-bold text-2xl">Licence version not found</h1>
        <Link href="/catalogue" className="text-[#c80064] font-semibold underline">
          Return to catalogue
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-6">
        <Link href="/catalogue" className="text-xs font-semibold text-[#c80064] hover:underline">
          ← Back to catalogue
        </Link>

        <div className="bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 space-y-5">
          <div className="space-y-1 border-b border-[#efe9df] pb-4">
            <p className="font-mono text-xs text-[#c80064] font-semibold">
              {row.code as string} · Version {row.version as string} · Effective{' '}
              {row.effective_date as string}
            </p>
            <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-[#14161b]">
              {row.title as string}
            </h1>
            <p className="text-sm text-[#4e535e]">{row.summary as string}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs bg-[#faf8f5] p-4 rounded-md border border-[#e4ded4]">
            <div>
              <span className="text-[#4e535e] block">Commercial use</span>
              <strong className="text-[#14161b]">
                {row.commercial_use ? 'Permitted' : 'Non-commercial only'}
              </strong>
            </div>
            <div>
              <span className="text-[#4e535e] block">Source redistribution</span>
              <strong className="text-[#14161b]">
                {row.redistributable_source ? 'Templates MIT' : 'Prohibited'}
              </strong>
            </div>
            <div>
              <span className="text-[#4e535e] block">Seat allocation</span>
              <strong className="text-[#14161b] tabular-nums">
                Up to {Number(row.seat_limit)} named seat(s)
              </strong>
            </div>
          </div>

          <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-[#14161b] bg-[#faf8f5] p-5 rounded-md border border-[#e4ded4]">
            {row.full_text as string}
          </pre>
        </div>
      </div>
    </div>
  );
}
