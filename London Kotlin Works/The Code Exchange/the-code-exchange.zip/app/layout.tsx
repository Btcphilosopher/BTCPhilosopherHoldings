import type { Metadata } from 'next';
import { Plus_Jakarta_Sans, DM_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';
import { StoreProvider } from '@/components/StoreProvider';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['500', '600', '700', '800'],
  variable: '--font-display',
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-body',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'The Code Exchange — Software, Source Code & Coding Workshops',
  description:
    'British retail storefront for software, source-code packages, coding starter kits, collector editions, and hands-on coding workshops.',
  openGraph: {
    title: 'The Code Exchange — Software, Source Code & Coding Workshops',
    description:
      'Software, source code and the skills to make it yours. Clear licence terms, online & in store across the UK.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The Code Exchange',
    description:
      'Software, source code and the skills to make it yours.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en-GB"
      className={`${plusJakarta.variable} ${dmSans.variable} ${jetbrainsMono.variable}`}
    >
      <body suppressHydrationWarning className="min-h-screen flex flex-col bg-[#f6f2ec] text-[#14161b]">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:px-4 focus:py-2 focus:bg-[#d4006c] focus:text-white focus:rounded-md focus:font-semibold"
        >
          Skip to main content
        </a>
        <StoreProvider>
          <SiteHeader />
          <main id="main-content" className="flex-1">
            {children}
          </main>
          <SiteFooter />
        </StoreProvider>
      </body>
    </html>
  );
}
