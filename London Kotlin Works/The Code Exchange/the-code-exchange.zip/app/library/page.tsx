'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Download, FileText, ShieldCheck, KeyRound, History, Calendar } from 'lucide-react';
import { useStore } from '@/components/StoreProvider';
import { formatWorkshopUK } from '@/lib/format';

interface ArtefactItem {
  id: string;
  version: string;
  filename: string;
  platform: string;
  size_bytes: number;
  sha256: string;
  release_notes: string;
  published_at: string;
}

interface LibraryEntitlement {
  id: string;
  product_id: string;
  product_title: string;
  product_slug: string;
  image_url: string;
  edition_name: string;
  sku: string;
  status: string;
  activation_key: string;
  licence_id: string;
  licence_code: string;
  licence_version: string;
  licence_title: string;
  licence_summary: string;
  order_number: string;
  order_date: string;
  update_entitlement: string;
  third_party_notices: string;
  documentation_markdown: string;
  artefacts: ArtefactItem[];
  downloadHistory: { id: string; downloaded_at: string; filename: string; version: string }[];
}

interface WorkshopBooking {
  id: string;
  workshop_title: string;
  workshop_slug: string;
  starts_at_utc: string;
  display_timezone: string;
  venue_label: string;
  format: string;
  seats: number;
  status: string;
  order_number: string;
}

export default function LibraryPage() {
  const { user, setToast } = useStore();
  const [library, setLibrary] = useState<LibraryEntitlement[]>([]);
  const [bookings, setBookings] = useState<WorkshopBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDocsId, setOpenDocsId] = useState<string | null>(null);

  const loadLibrary = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/library', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        setLibrary(data.library || []);
        setBookings(data.workshopBookings || []);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    fetch('/api/library', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : { library: [], workshopBookings: [] }))
      .then((data) => {
        if (!cancelled) {
          setLibrary(data.library || []);
          setBookings(data.workshopBookings || []);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  const handleDownload = async (entitlementId: string, artefactId: string) => {
    const res = await fetch('/api/library', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: JSON.stringify({ entitlementId, artefactId }),
    });
    const data = await res.json();
    if (!res.ok) {
      setToast(data.error || 'Unable to generate download link.');
      return;
    }
    // Trigger browser download via short-lived signed URL
    const anchor = document.createElement('a');
    anchor.href = data.downloadUrl;
    anchor.download = data.filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setToast(`Downloading ${data.filename} (SHA-256 verified).`);
    setTimeout(() => void loadLibrary(), 700);
  };

  if (!user) {
    return (
      <div className="bg-[#f6f2ec] min-h-screen py-14">
        <div className="max-w-lg mx-auto px-4 bg-white border border-[#e4ded4] rounded-lg p-8 text-center space-y-4">
          <h1 className="font-display font-extrabold text-2xl text-[#14161b]">
            My Software &amp; Downloads
          </h1>
          <p className="text-sm text-[#4e535e]">
            Sign in to view your entitled downloads, SHA-256 checksums, documentation, and workshop bookings.
          </p>
          <Link
            href="/account"
            className="inline-block px-5 py-2.5 rounded-md bg-[#d4006c] text-white text-sm font-semibold"
          >
            Sign in to account
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 space-y-8">
        <div className="border-b border-[#e4ded4] pb-5 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="font-display font-extrabold text-3xl text-[#14161b]">
              My Software &amp; Downloads
            </h1>
            <p className="text-sm text-[#4e535e] mt-1">
              Signed in as {user.name} ({user.email}). Short-lived authorised download links expire after 10 minutes.
            </p>
          </div>
          <p className="text-xs text-[#4e535e] max-w-sm">
            Honest notice: download authorisation controls verify entitlement at retrieval time and cannot prevent copying once you have obtained a file locally.
          </p>
        </div>

        {loading ? (
          <p className="text-sm text-[#4e535e]">Loading your library...</p>
        ) : library.length === 0 ? (
          <div className="bg-white border border-[#e4ded4] rounded-lg p-10 text-center space-y-3">
            <h2 className="font-display font-bold text-xl">No software entitlements yet</h2>
            <p className="text-sm text-[#4e535e]">
              Once an order payment webhook is confirmed, your software editions and documentation appear here automatically.
            </p>
            <Link
              href="/catalogue"
              className="inline-block px-5 py-2.5 rounded-md bg-[#d4006c] text-white text-sm font-semibold"
            >
              Explore software
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {library.map((ent) => (
              <div
                key={ent.id}
                className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-5"
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-[#efe9df] pb-5">
                  <div className="flex gap-4">
                    <div className="relative w-20 h-24 shrink-0 rounded bg-[#faf8f5] overflow-hidden">
                      <Image
                        src={ent.image_url}
                        alt={ent.product_title}
                        fill
                        sizes="80px"
                        className="object-contain p-1"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span
                          className={`font-bold uppercase ${
                            ent.status === 'active' ? 'text-[#c80064]' : 'text-[#4e535e]'
                          }`}
                        >
                          Entitlement: {ent.status}
                        </span>
                        <span aria-hidden="true">·</span>
                        <Link
                          href={`/orders/${encodeURIComponent(ent.order_number)}`}
                          className="text-[#4e535e] hover:underline tabular-nums"
                        >
                          Order {ent.order_number}
                        </Link>
                      </div>
                      <h2 className="font-display font-bold text-xl text-[#14161b]">
                        {ent.product_title} — {ent.edition_name}
                      </h2>
                      <p className="text-xs text-[#4e535e]">{ent.update_entitlement}</p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:items-end gap-2">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded bg-[#faf8f5] border border-[#e4ded4] text-xs font-mono">
                      <KeyRound className="w-3.5 h-3.5 text-[#d4006c]" aria-hidden="true" />
                      <span>{ent.activation_key}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs">
                      <Link
                        href={`/licences/${ent.licence_id}`}
                        className="inline-flex items-center gap-1 font-semibold text-[#c80064] hover:underline"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>
                          {ent.licence_code} v{ent.licence_version}
                        </span>
                      </Link>
                      <button
                        type="button"
                        onClick={() =>
                          setOpenDocsId((curr) => (curr === ent.id ? null : ent.id))
                        }
                        className="inline-flex items-center gap-1 font-semibold text-[#14161b] hover:text-[#c80064] cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{openDocsId === ent.id ? 'Hide documentation' : 'Documentation'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {openDocsId === ent.id && (
                  <div className="space-y-3">
                    <pre className="text-xs font-mono bg-[#111318] text-white/90 p-4 rounded-md overflow-x-auto whitespace-pre-wrap">
                      {ent.documentation_markdown}
                    </pre>
                    <p className="text-xs text-[#4e535e]">
                      <strong>Third-party notices:</strong> {ent.third_party_notices}
                    </p>
                  </div>
                )}

                <div className="space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#4e535e]">
                    Published Releases &amp; Checksums
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {ent.artefacts.map((art) => (
                      <div
                        key={art.id}
                        className="p-4 rounded-md border border-[#e4ded4] bg-[#faf8f5] flex flex-col justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono text-xs font-semibold text-[#14161b]">
                              {art.filename}
                            </span>
                            <span className="text-xs text-[#4e535e] tabular-nums">
                              {(art.size_bytes / 1024).toFixed(1)} KB
                            </span>
                          </div>
                          <p className="text-xs text-[#4e535e]">
                            v{art.version} · {art.platform}
                          </p>
                          <p className="text-xs text-[#4e535e]">{art.release_notes}</p>
                          <p className="font-mono text-[11px] text-[#4e535e] break-all pt-1">
                            SHA-256: {art.sha256}
                          </p>
                        </div>

                        <button
                          type="button"
                          disabled={ent.status !== 'active'}
                          onClick={() => void handleDownload(ent.id, art.id)}
                          className="h-10 px-4 rounded-md bg-[#d4006c] hover:bg-[#b8005d] disabled:bg-[#b9b0a2] text-white text-xs font-semibold inline-flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
                        >
                          <Download className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>
                            {ent.status === 'active'
                              ? 'Authorise & Download ZIP'
                              : 'Entitlement Revoked'}
                          </span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {ent.downloadHistory.length > 0 && (
                  <div className="pt-3 border-t border-[#efe9df] space-y-1.5">
                    <p className="text-xs font-semibold text-[#4e535e] flex items-center gap-1.5">
                      <History className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Recent download log</span>
                    </p>
                    <ul className="text-xs text-[#4e535e] space-y-1">
                      {ent.downloadHistory.map((h) => (
                        <li key={h.id} className="tabular-nums">
                          {new Date(h.downloaded_at).toLocaleString('en-GB')} — {h.filename} (v
                          {h.version})
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {bookings.length > 0 && (
          <section className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
            <h2 className="font-display font-bold text-xl text-[#14161b] flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#d4006c]" aria-hidden="true" />
              <span>My Workshop Bookings</span>
            </h2>
            <div className="divide-y divide-[#efe9df]">
              {bookings.map((bk) => (
                <div
                  key={bk.id}
                  className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div>
                    <Link
                      href={`/workshops/${bk.workshop_slug}`}
                      className="font-display font-bold text-base text-[#14161b] hover:text-[#c80064]"
                    >
                      {bk.workshop_title}
                    </Link>
                    <p className="text-xs text-[#4e535e]">
                      {bk.venue_label} · {formatWorkshopUK(bk.starts_at_utc, bk.display_timezone)} ·{' '}
                      {bk.seats} place{bk.seats === 1 ? '' : 's'}
                    </p>
                  </div>
                  <div className="text-xs font-semibold text-[#c80064] capitalize">
                    Status: {bk.status.replace(/_/g, ' ')} ({bk.order_number})
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
