import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getOrCreateBasketId } from '@/src/server/auth-session';
import { triggerSignedPaymentSimulation } from '@/src/server/commerce';
import { verifyMutationOrigin } from '@/src/server/security';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }

  const db = getDb();
  const { basketId } = getOrCreateBasketId(req);
  const body = await req.json();

  const paymentIntentId = String(body.paymentIntentId || '');
  const outcome = body.outcome as 'succeeded' | 'cancelled' | 'failed';
  if (!paymentIntentId || !['succeeded', 'cancelled', 'failed'].includes(outcome)) {
    return NextResponse.json({ error: 'Invalid simulation parameters.' }, { status: 400 });
  }

  try {
    const sim = triggerSignedPaymentSimulation(db, {
      paymentIntentId,
      outcome,
      eventId: body.eventId ? String(body.eventId) : undefined,
      basketIdToClear: outcome === 'succeeded' ? basketId : null,
      simulateFulfilmentFailOnce: Boolean(body.simulateFulfilmentFailOnce),
    });

    const order = db
      .prepare('SELECT order_number, status FROM orders WHERE id = ?')
      .get(sim.result.orderId) as { order_number: string; status: string };

    return NextResponse.json({
      eventId: sim.eventId,
      duplicate: sim.result.duplicate,
      paymentStatus: sim.result.status,
      orderId: sim.result.orderId,
      orderNumber: order.order_number,
      orderStatus: order.status,
    });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
