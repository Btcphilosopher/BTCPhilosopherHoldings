import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { applyPaymentWebhookEvent } from '@/src/server/commerce';
import { verifyWebhookSignature } from '@/src/server/security';

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const sig = req.headers.get('x-cx-signature');
  if (!verifyWebhookSignature(rawBody, sig)) {
    return NextResponse.json({ error: 'Invalid webhook signature.' }, { status: 401 });
  }

  try {
    const body = JSON.parse(rawBody);
    const db = getDb();
    const res = applyPaymentWebhookEvent(db, {
      eventId: String(body.eventId),
      paymentIntentId: String(body.paymentIntentId),
      outcome: body.outcome,
    });
    return NextResponse.json({ received: true, ...res });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 400 });
  }
}
