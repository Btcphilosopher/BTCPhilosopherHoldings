import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';

export async function GET(req: NextRequest) {
  const db = getDb();
  const url = new URL(req.url);
  const q = (url.searchParams.get('q') || '').trim().toLowerCase();
  const category = (url.searchParams.get('category') || '').trim();
  const platform = (url.searchParams.get('platform') || '').trim().toLowerCase();
  const language = (url.searchParams.get('language') || '').trim().toLowerCase();
  const format = (url.searchParams.get('format') || '').trim();
  const source = url.searchParams.get('source'); // '1' or 'true'
  const licence = (url.searchParams.get('licence') || '').trim();
  const maxPricePounds = Number(url.searchParams.get('maxPrice') || '0');
  const sort = url.searchParams.get('sort') || 'featured';
  const page = Math.max(1, Number(url.searchParams.get('page') || '1'));
  const pageSize = Math.min(24, Math.max(1, Number(url.searchParams.get('pageSize') || '12')));

  const products = db
    .prepare('SELECT * FROM products ORDER BY featured_order ASC, title ASC')
    .all() as Record<string, unknown>[];

  const editions = db
    .prepare(
      `SELECT e.*, l.code as licence_code, l.title as licence_title, l.version as licence_version
       FROM editions e
       JOIN licences l ON l.id = e.licence_id
       WHERE e.is_active = 1
       ORDER BY e.price_pence ASC`
    )
    .all() as Record<string, unknown>[];

  const editionsByProduct = new Map<string, Record<string, unknown>[]>();
  for (const ed of editions) {
    const pid = ed.product_id as string;
    if (!editionsByProduct.has(pid)) editionsByProduct.set(pid, []);
    editionsByProduct.get(pid)!.push(ed);
  }

  let items = products.map((p) => {
    const prodEditions = editionsByProduct.get(p.id as string) || [];
    const platforms: string[] = JSON.parse((p.platforms_json as string) || '[]');
    const languages: string[] = JSON.parse((p.languages_json as string) || '[]');
    const minPricePence =
      prodEditions.length > 0 ? Math.min(...prodEditions.map((e) => Number(e.price_pence))) : 0;
    const formats = Array.from(new Set(prodEditions.map((e) => e.edition_type as string)));
    const licenceCodes = Array.from(new Set(prodEditions.map((e) => e.licence_code as string)));

    return {
      id: p.id as string,
      slug: p.slug as string,
      skuPrefix: p.sku_prefix as string,
      title: p.title as string,
      subtitle: p.subtitle as string,
      description: p.description as string,
      category: p.category as string,
      publisher: p.publisher as string,
      platforms,
      languages,
      releaseVersion: p.release_version as string,
      sourceIncluded: Boolean(p.source_included),
      imageUrl: p.image_url as string,
      featuredOrder: Number(p.featured_order),
      isDemoListing: Boolean(p.is_demo_listing),
      minPricePence,
      formats,
      licenceCodes,
      editions: prodEditions.map((e) => ({
        id: e.id as string,
        sku: e.sku as string,
        name: e.name as string,
        editionType: e.edition_type as string,
        pricePence: Number(e.price_pence),
        licenceCode: e.licence_code as string,
        licenceVersion: e.licence_version as string,
        requiresShipping: Boolean(e.requires_shipping),
      })),
    };
  });

  if (q) {
    items = items.filter((item) => {
      const hay = [
        item.title,
        item.subtitle,
        item.description,
        item.category,
        item.publisher,
        ...item.platforms,
        ...item.languages,
      ]
        .join(' ')
        .toLowerCase();
      return hay.includes(q);
    });
  }

  if (category && category.toLowerCase() !== 'all') {
    items = items.filter((i) => i.category.toLowerCase() === category.toLowerCase());
  }
  if (platform) {
    items = items.filter((i) => i.platforms.some((pl) => pl.toLowerCase() === platform));
  }
  if (language) {
    items = items.filter((i) => i.languages.some((lg) => lg.toLowerCase() === language));
  }
  if (format) {
    items = items.filter((i) => i.formats.includes(format));
  }
  if (source === '1' || source === 'true') {
    items = items.filter((i) => i.sourceIncluded || i.formats.includes('source_package'));
  }
  if (licence) {
    items = items.filter((i) => i.licenceCodes.includes(licence));
  }
  if (maxPricePounds > 0) {
    items = items.filter((i) => i.minPricePence <= maxPricePounds * 100);
  }

  if (sort === 'price_asc') {
    items.sort((a, b) => a.minPricePence - b.minPricePence);
  } else if (sort === 'price_desc') {
    items.sort((a, b) => b.minPricePence - a.minPricePence);
  } else if (sort === 'title_asc') {
    items.sort((a, b) => a.title.localeCompare(b.title));
  }

  const total = items.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * pageSize;
  const paged = items.slice(start, start + pageSize);

  return NextResponse.json({
    items: paged,
    pagination: {
      total,
      page: safePage,
      pageSize,
      totalPages,
    },
    facets: {
      categories: ['Creative', 'Developer tools', 'Business', 'Learning'],
      platforms: ['macOS', 'Windows', 'Linux', 'Web'],
      languages: ['Python', 'TypeScript', 'JavaScript', 'GLSL', 'SQL', 'C++'],
      formats: [
        { value: 'digital_download', label: 'Digital download' },
        { value: 'boxed_key', label: 'Boxed download-key' },
        { value: 'usb_edition', label: 'USB collector edition' },
        { value: 'source_package', label: 'Source-code package' },
        { value: 'starter_kit', label: 'Starter kit' },
      ],
      licences: [
        { value: 'CX-PERSONAL-1.2', label: 'Workstation Licence (CX-PERSONAL-1.2)' },
        { value: 'CX-SOURCE-1.4', label: 'Source Access Licence (CX-SOURCE-1.4)' },
        { value: 'CX-STARTER-1.0', label: 'Starter Kit Licence (CX-STARTER-1.0)' },
      ],
    },
  });
}
