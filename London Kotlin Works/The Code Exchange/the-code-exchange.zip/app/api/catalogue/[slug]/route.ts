import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getEditionStockSummary } from '@/src/server/commerce';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ slug: string }> }
) {
  const { slug } = await context.params;
  const db = getDb();

  const product = db
    .prepare('SELECT * FROM products WHERE slug = ?')
    .get(slug) as Record<string, unknown> | undefined;

  if (!product) {
    return NextResponse.json({ error: 'Product not found.' }, { status: 404 });
  }

  const rawEditions = db
    .prepare(
      `SELECT e.*, l.code as licence_code, l.title as licence_title, l.version as licence_version,
              l.summary as licence_summary, l.full_text as licence_full_text,
              l.redistributable_source, l.commercial_use, l.seat_limit
       FROM editions e
       JOIN licences l ON l.id = e.licence_id
       WHERE e.product_id = ? AND e.is_active = 1
       ORDER BY e.price_pence ASC`
    )
    .all(product.id as string) as Record<string, unknown>[];

  const editions = rawEditions.map((e) => ({
    id: e.id as string,
    sku: e.sku as string,
    name: e.name as string,
    editionType: e.edition_type as string,
    deliveryMethod: e.delivery_method as string,
    pricePence: Number(e.price_pence),
    currency: e.currency as string,
    vatRateBps: Number(e.vat_rate_bps),
    includes: JSON.parse((e.includes_json as string) || '[]') as string[],
    physicalContentsNote: e.physical_contents_note as string,
    requiresShipping: Boolean(e.requires_shipping),
    licence: {
      id: e.licence_id as string,
      code: e.licence_code as string,
      title: e.licence_title as string,
      version: e.licence_version as string,
      summary: e.licence_summary as string,
      fullText: e.licence_full_text as string,
      redistributableSource: Boolean(e.redistributable_source),
      commercialUse: Boolean(e.commercial_use),
      seatLimit: Number(e.seat_limit),
    },
    stockLocations: Boolean(e.requires_shipping)
      ? getEditionStockSummary(db, e.id as string)
      : [],
  }));

  const artefacts = db
    .prepare(
      `SELECT id, edition_id, version, filename, platform, size_bytes, sha256, release_notes, published_at
       FROM release_artefacts
       WHERE product_id = ? AND quarantine_status = 'published'
       ORDER BY published_at DESC`
    )
    .all(product.id as string) as Record<string, unknown>[];

  const relatedSlugs: string[] = JSON.parse((product.related_slugs_json as string) || '[]');
  const relatedProducts = relatedSlugs
    .map((rSlug) => {
      const rp = db
        .prepare(
          `SELECT p.id, p.slug, p.title, p.subtitle, p.category, p.image_url,
                  (SELECT MIN(price_pence) FROM editions WHERE product_id = p.id AND is_active = 1) as min_price_pence
           FROM products p WHERE p.slug = ?`
        )
        .get(rSlug) as Record<string, unknown> | undefined;
      if (!rp) return null;
      return {
        id: rp.id as string,
        slug: rp.slug as string,
        title: rp.title as string,
        subtitle: rp.subtitle as string,
        category: rp.category as string,
        imageUrl: rp.image_url as string,
        minPricePence: Number(rp.min_price_pence || 0),
      };
    })
    .filter(Boolean);

  return NextResponse.json({
    product: {
      id: product.id as string,
      slug: product.slug as string,
      skuPrefix: product.sku_prefix as string,
      title: product.title as string,
      subtitle: product.subtitle as string,
      description: product.description as string,
      category: product.category as string,
      publisher: product.publisher as string,
      platforms: JSON.parse((product.platforms_json as string) || '[]'),
      languages: JSON.parse((product.languages_json as string) || '[]'),
      requirements: JSON.parse((product.requirements_json as string) || '{}'),
      releaseVersion: product.release_version as string,
      sourceIncluded: Boolean(product.source_included),
      updateEntitlement: product.update_entitlement as string,
      thirdPartyNotices: product.third_party_notices as string,
      documentationMarkdown: product.documentation_markdown as string,
      imageUrl: product.image_url as string,
      screenshots: JSON.parse((product.screenshots_json as string) || '[]'),
      isDemoListing: Boolean(product.is_demo_listing),
    },
    editions,
    artefacts,
    relatedProducts,
  });
}
