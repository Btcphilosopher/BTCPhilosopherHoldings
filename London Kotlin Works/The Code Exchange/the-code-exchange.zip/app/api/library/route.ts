import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getSessionFromRequest } from '@/src/server/auth-session';
import { createSignedDownloadUrlForEntitlement } from '@/src/server/commerce';
import { checkRateLimit, verifyMutationOrigin } from '@/src/server/security';

export async function GET(req: NextRequest) {
  const user = getSessionFromRequest(req);
  if (!user) {
    return NextResponse.json({ error: 'Please sign in to access My Software Library.' }, { status: 401 });
  }

  const db = getDb();
  const entitlements = db
    .prepare(
      `SELECT ent.*, p.title as product_title, p.slug as product_slug, p.image_url,
              p.documentation_markdown, p.update_entitlement, p.third_party_notices,
              e.name as edition_name, e.sku,
              l.code as licence_code, l.title as licence_title, l.summary as licence_summary,
              o.order_number, o.created_at as order_date
       FROM entitlements ent
       JOIN products p ON p.id = ent.product_id
       JOIN editions e ON e.id = ent.edition_id
       JOIN licences l ON l.id = ent.licence_id
       JOIN orders o ON o.id = ent.order_id
       WHERE ent.user_id = ? OR lower(ent.customer_email) = lower(?)
       ORDER BY ent.granted_at DESC`
    )
    .all(user.id, user.email) as Record<string, unknown>[];

  const artefactStmt = db.prepare(
    `SELECT id, edition_id, version, filename, platform, size_bytes, sha256, release_notes, published_at
     FROM release_artefacts
     WHERE product_id = ? AND quarantine_status = 'published'
     ORDER BY published_at DESC`
  );

  const historyStmt = db.prepare(
    `SELECT dl.id, dl.downloaded_at, ra.filename, ra.version
     FROM download_logs dl
     JOIN release_artefacts ra ON ra.id = dl.artefact_id
     WHERE dl.entitlement_id = ?
     ORDER BY dl.downloaded_at DESC
     LIMIT 10`
  );

  const library = entitlements.map((ent) => ({
    ...ent,
    artefacts: artefactStmt.all(ent.product_id as string),
    downloadHistory: historyStmt.all(ent.id as string),
  }));

  const workshopBookings = db
    .prepare(
      `SELECT wb.*, w.title as workshop_title, w.slug as workshop_slug, w.starts_at_utc,
              w.ends_at_utc, w.display_timezone, w.venue_label, w.format, o.order_number
       FROM workshop_bookings wb
       JOIN workshops w ON w.id = wb.workshop_id
       JOIN orders o ON o.id = wb.order_id
       WHERE wb.user_id = ? OR lower(wb.attendee_email) = lower(?)
       ORDER BY wb.created_at DESC`
    )
    .all(user.id, user.email);

  return NextResponse.json({ library, workshopBookings });
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const user = getSessionFromRequest(req);
  if (!user) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }
  if (!checkRateLimit(`dl_sign:${user.id}`, 40, 60_000)) {
    return NextResponse.json({ error: 'Too many download link requests.' }, { status: 429 });
  }

  const db = getDb();
  const body = await req.json();
  try {
    const signed = createSignedDownloadUrlForEntitlement(db, {
      entitlementId: String(body.entitlementId || ''),
      artefactId: String(body.artefactId || ''),
      userId: user.id,
      userEmail: user.email,
    });
    return NextResponse.json(signed);
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 403 });
  }
}
