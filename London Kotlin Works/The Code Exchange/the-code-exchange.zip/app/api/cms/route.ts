import { NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';

export async function GET() {
  const db = getDb();
  const row = db.prepare(`SELECT value_json, updated_at FROM cms_blocks WHERE key = 'homepage'`).get() as
    | { value_json: string; updated_at: string }
    | undefined;
  return NextResponse.json({
    homepage: row ? JSON.parse(row.value_json) : null,
    updatedAt: row?.updated_at || null,
  });
}
