import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { formatWorkshopTimeUK, getWorkshopAvailability } from '@/src/server/commerce';
import { verifyMutationOrigin } from '@/src/server/security';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ slug: string }> }
) {
  const { slug } = await context.params;
  const db = getDb();
  const w = db.prepare('SELECT * FROM workshops WHERE slug = ?').get(slug) as
    | Record<string, unknown>
    | undefined;
  if (!w) {
    return NextResponse.json({ error: 'Workshop not found.' }, { status: 404 });
  }

  const availability = getWorkshopAvailability(db, w.id as string);
  return NextResponse.json({
    workshop: {
      id: w.id,
      slug: w.slug,
      title: w.title,
      subtitle: w.subtitle,
      description: w.description,
      instructor: w.instructor,
      level: w.level,
      prerequisites: w.prerequisites,
      format: w.format,
      storeId: w.store_id,
      venueLabel: w.venue_label,
      startsAtUtc: w.starts_at_utc,
      endsAtUtc: w.ends_at_utc,
      displayTimezone: w.display_timezone,
      startFormatted: formatWorkshopTimeUK(w.starts_at_utc as string, w.display_timezone as string),
      endFormatted: formatWorkshopTimeUK(w.ends_at_utc as string, w.display_timezone as string),
      pricePence: Number(w.price_pence),
      requiredEquipment: w.required_equipment,
      accessibilityInfo: w.accessibility_info,
      cancellationTerms: w.cancellation_terms,
      imageUrl: w.image_url,
      availability,
    },
  });
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ slug: string }> }
) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const { slug } = await context.params;
  const db = getDb();
  const w = db.prepare('SELECT id FROM workshops WHERE slug = ?').get(slug) as
    | { id: string }
    | undefined;
  if (!w) {
    return NextResponse.json({ error: 'Workshop not found.' }, { status: 404 });
  }

  const body = await req.json();
  const email = String(body.email || '').trim().toLowerCase();
  const name = String(body.name || '').trim();
  const seats = Math.max(1, Math.min(4, Number(body.seats || 1)));
  if (!email || !email.includes('@') || !name) {
    return NextResponse.json({ error: 'Name and valid email required for waiting list.' }, { status: 400 });
  }

  db.prepare(
    `INSERT INTO workshop_waitlist (id, workshop_id, email, name, seats, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(`wl-${crypto.randomUUID().slice(0, 10)}`, w.id, email, name, seats, new Date().toISOString());

  return NextResponse.json({
    joined: true,
    availability: getWorkshopAvailability(db, w.id),
  });
}
