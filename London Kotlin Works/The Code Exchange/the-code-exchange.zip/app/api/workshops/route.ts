import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { formatWorkshopTimeUK, getWorkshopAvailability } from '@/src/server/commerce';

export async function GET(req: NextRequest) {
  const db = getDb();
  const url = new URL(req.url);
  const formatFilter = (url.searchParams.get('format') || '').trim();
  const levelFilter = (url.searchParams.get('level') || '').trim();

  const rows = db
    .prepare('SELECT * FROM workshops ORDER BY starts_at_utc ASC')
    .all() as Record<string, unknown>[];

  const workshops = rows
    .map((w) => {
      const availability = getWorkshopAvailability(db, w.id as string);
      const startTime = formatWorkshopTimeUK(
        w.starts_at_utc as string,
        (w.display_timezone as string) || 'Europe/London'
      );
      const endTime = formatWorkshopTimeUK(
        w.ends_at_utc as string,
        (w.display_timezone as string) || 'Europe/London'
      );
      return {
        id: w.id as string,
        slug: w.slug as string,
        title: w.title as string,
        subtitle: w.subtitle as string,
        description: w.description as string,
        instructor: w.instructor as string,
        level: w.level as string,
        prerequisites: w.prerequisites as string,
        format: w.format as string,
        storeId: w.store_id as string | null,
        venueLabel: w.venue_label as string,
        startsAtUtc: w.starts_at_utc as string,
        endsAtUtc: w.ends_at_utc as string,
        displayTimezone: w.display_timezone as string,
        startFormatted: startTime,
        endFormatted: endTime,
        pricePence: Number(w.price_pence),
        requiredEquipment: w.required_equipment as string,
        accessibilityInfo: w.accessibility_info as string,
        cancellationTerms: w.cancellation_terms as string,
        imageUrl: w.image_url as string,
        availability,
      };
    })
    .filter((w) => {
      if (formatFilter && formatFilter !== 'all' && w.format.toLowerCase() !== formatFilter.toLowerCase()) {
        return false;
      }
      if (levelFilter && levelFilter !== 'all' && !w.level.toLowerCase().includes(levelFilter.toLowerCase())) {
        return false;
      }
      return true;
    });

  return NextResponse.json({ workshops });
}
