import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM licences WHERE id = ? OR code = ?')
    .get(id, id) as Record<string, unknown> | undefined;

  if (!row) {
    return NextResponse.json({ error: 'Licence version not found.' }, { status: 404 });
  }
  return NextResponse.json({
    licence: {
      id: row.id,
      code: row.code,
      title: row.title,
      version: row.version,
      summary: row.summary,
      fullText: row.full_text,
      redistributableSource: Boolean(row.redistributable_source),
      commercialUse: Boolean(row.commercial_use),
      seatLimit: Number(row.seat_limit),
      effectiveDate: row.effective_date,
    },
  });
}
