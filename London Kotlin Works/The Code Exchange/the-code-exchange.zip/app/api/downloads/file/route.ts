import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { NextRequest, NextResponse } from 'next/server';
import { getArtefactStorageDir, getDb } from '@/src/server/db';
import { verifyDownloadToken } from '@/src/server/security';

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const token = url.searchParams.get('token') || '';
  const payload = verifyDownloadToken(token);
  if (!payload) {
    return NextResponse.json(
      { error: 'Download link is invalid or has expired. Generate a fresh link from My Software Library.' },
      { status: 403 }
    );
  }

  const db = getDb();
  const ent = db
    .prepare('SELECT id, status, user_id FROM entitlements WHERE id = ?')
    .get(payload.entitlementId) as { id: string; status: string; user_id: string | null } | undefined;

  if (!ent || ent.status !== 'active') {
    return NextResponse.json({ error: 'Entitlement is no longer active.' }, { status: 403 });
  }

  const artefact = db
    .prepare('SELECT * FROM release_artefacts WHERE id = ? AND quarantine_status = ?')
    .get(payload.artefactId, 'published') as
    | { id: string; filename: string; storage_key: string; sha256: string }
    | undefined;

  if (!artefact) {
    return NextResponse.json({ error: 'Published artefact not found.' }, { status: 404 });
  }

  const baseDir = path.resolve(getArtefactStorageDir());
  const resolved = path.resolve(baseDir, artefact.storage_key);
  if (!resolved.startsWith(baseDir + path.sep) || !fs.existsSync(resolved)) {
    return NextResponse.json({ error: 'Artefact file missing from storage.' }, { status: 404 });
  }

  const fileBytes = fs.readFileSync(resolved);
  db.prepare(
    `INSERT INTO download_logs (id, entitlement_id, artefact_id, user_id, downloaded_at, ip_hint)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(
    `dl-${crypto.randomUUID().slice(0, 12)}`,
    ent.id,
    artefact.id,
    payload.userId,
    new Date().toISOString(),
    (req.headers.get('x-forwarded-for') || 'local').slice(0, 32)
  );

  return new NextResponse(fileBytes, {
    status: 200,
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${artefact.filename.replace(/[^a-zA-Z0-9._-]/g, '_')}"`,
      'X-Content-Type-Options': 'nosniff',
      'X-Checksum-Sha256': artefact.sha256,
      'Cache-Control': 'no-store',
    },
  });
}
