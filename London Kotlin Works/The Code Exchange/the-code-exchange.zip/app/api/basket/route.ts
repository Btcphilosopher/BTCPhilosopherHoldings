import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getOrCreateBasketId, getSessionFromRequest } from '@/src/server/auth-session';
import { createWorkshopHold, getBasketSnapshot } from '@/src/server/commerce';
import { evaluateDiscountPence } from '@/src/server/money';
import { BASKET_COOKIE_NAME, setSecureSessionCookie, verifyMutationOrigin } from '@/src/server/security';

export async function GET(req: NextRequest) {
  const db = getDb();
  const { basketId, isNew } = getOrCreateBasketId(req);
  const snapshot = getBasketSnapshot(db, basketId);
  const res = NextResponse.json(snapshot);
  if (isNew) {
    setSecureSessionCookie(res, BASKET_COOKIE_NAME, basketId, 60 * 60 * 24 * 14);
  }
  return res;
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const db = getDb();
  const user = getSessionFromRequest(req);
  const { basketId, isNew } = getOrCreateBasketId(req);
  const body = await req.json();

  try {
    if (body.itemType === 'workshop') {
      const workshopId = String(body.workshopId || '');
      const seats = Math.max(1, Math.min(10, Number(body.seats || 1)));
      const ws = db.prepare('SELECT id, price_pence FROM workshops WHERE id = ?').get(workshopId) as
        | { id: string; price_pence: number }
        | undefined;
      if (!ws) {
        return NextResponse.json({ error: 'Workshop not found.' }, { status: 404 });
      }
      const { holdId } = createWorkshopHold(db, workshopId, basketId, user?.id || null, seats, 900);
      db.prepare(
        `INSERT INTO basket_items (
          id, basket_id, item_type, workshop_id, fulfilment_choice, quantity, hold_id, unit_price_pence
        ) VALUES (?, ?, 'workshop', ?, 'workshop', ?, ?, ?)`
      ).run(`bi-${crypto.randomUUID().slice(0, 10)}`, basketId, workshopId, seats, holdId, ws.price_pence);
    } else {
      const editionId = String(body.editionId || '');
      const quantity = Math.max(1, Math.min(20, Number(body.quantity || 1)));
      const ed = db
        .prepare('SELECT id, price_pence, requires_shipping FROM editions WHERE id = ? AND is_active = 1')
        .get(editionId) as { id: string; price_pence: number; requires_shipping: number } | undefined;
      if (!ed) {
        return NextResponse.json({ error: 'Product edition not found.' }, { status: 404 });
      }

      let fulfilmentChoice: 'digital' | 'delivery' | 'collect' = ed.requires_shipping ? 'delivery' : 'digital';
      let storeId: string | null = null;
      if (ed.requires_shipping && body.fulfilmentChoice === 'collect') {
        fulfilmentChoice = 'collect';
        storeId = body.storeId ? String(body.storeId) : 'store-london';
      }

      // Check stock if physical
      if (fulfilmentChoice === 'delivery' || fulfilmentChoice === 'collect') {
        const stockRow = db
          .prepare(
            storeId
              ? `SELECT on_hand, reserved FROM stock_locations WHERE edition_id = ? AND store_id = ?`
              : `SELECT on_hand, reserved FROM stock_locations WHERE edition_id = ? AND store_id IS NULL`
          )
          .get(...(storeId ? [editionId, storeId] : [editionId])) as
          | { on_hand: number; reserved: number }
          | undefined;
        const available = stockRow ? stockRow.on_hand - stockRow.reserved : 0;
        if (available < quantity) {
          return NextResponse.json(
            { error: `Only ${available} unit(s) available at the selected location.` },
            { status: 409 }
          );
        }
      }

      // Merge into existing matching basket line if present
      const existing = db
        .prepare(
          `SELECT id, quantity FROM basket_items
           WHERE basket_id = ? AND item_type = 'edition' AND edition_id = ? AND fulfilment_choice = ? AND COALESCE(store_id, '') = COALESCE(?, '')`
        )
        .get(basketId, editionId, fulfilmentChoice, storeId) as
        | { id: string; quantity: number }
        | undefined;

      if (existing) {
        db.prepare('UPDATE basket_items SET quantity = ? WHERE id = ?').run(
          existing.quantity + quantity,
          existing.id
        );
      } else {
        db.prepare(
          `INSERT INTO basket_items (
            id, basket_id, item_type, edition_id, fulfilment_choice, store_id, quantity, unit_price_pence
          ) VALUES (?, ?, 'edition', ?, ?, ?, ?, ?)`
        ).run(
          `bi-${crypto.randomUUID().slice(0, 10)}`,
          basketId,
          editionId,
          fulfilmentChoice,
          storeId,
          quantity,
          ed.price_pence
        );
      }
    }

    db.prepare('UPDATE baskets SET updated_at = ? WHERE id = ?').run(
      new Date().toISOString(),
      basketId
    );
    const snapshot = getBasketSnapshot(db, basketId);
    const res = NextResponse.json(snapshot);
    if (isNew) {
      setSecureSessionCookie(res, BASKET_COOKIE_NAME, basketId, 60 * 60 * 24 * 14);
    }
    return res;
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 409 });
  }
}

export async function PATCH(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const db = getDb();
  const { basketId } = getOrCreateBasketId(req);
  const body = await req.json();

  if (typeof body.discountCode === 'string') {
    const code = body.discountCode.trim().toUpperCase();
    if (!code) {
      db.prepare('UPDATE baskets SET discount_code = NULL, updated_at = ? WHERE id = ?').run(
        new Date().toISOString(),
        basketId
      );
      return NextResponse.json(getBasketSnapshot(db, basketId));
    }
    const current = getBasketSnapshot(db, basketId);
    const evalRes = evaluateDiscountPence(code, current.totals.itemsGrossPence);
    if (!evalRes.normalizedCode) {
      return NextResponse.json(
        { error: 'Invalid or ineligible discount code. Try CODE10, WELCOME5, or WORKSHOP20 (orders £100+).' },
        { status: 400 }
      );
    }
    db.prepare('UPDATE baskets SET discount_code = ?, updated_at = ? WHERE id = ?').run(
      evalRes.normalizedCode,
      new Date().toISOString(),
      basketId
    );
    return NextResponse.json(getBasketSnapshot(db, basketId));
  }

  const itemId = String(body.itemId || '');
  const item = db
    .prepare('SELECT * FROM basket_items WHERE id = ? AND basket_id = ?')
    .get(itemId, basketId) as Record<string, unknown> | undefined;
  if (!item) {
    return NextResponse.json({ error: 'Basket item not found.' }, { status: 404 });
  }

  if (typeof body.quantity === 'number') {
    const qty = Math.floor(body.quantity);
    if (qty <= 0) {
      if (item.hold_id) {
        db.prepare(`UPDATE workshop_holds SET status = 'released' WHERE id = ?`).run(
          item.hold_id as string
        );
      }
      db.prepare('DELETE FROM basket_items WHERE id = ?').run(itemId);
    } else if (item.item_type === 'edition') {
      db.prepare('UPDATE basket_items SET quantity = ? WHERE id = ?').run(
        Math.min(20, qty),
        itemId
      );
    }
  }

  if (typeof body.fulfilmentChoice === 'string' && item.item_type === 'edition') {
    const choice = body.fulfilmentChoice === 'collect' ? 'collect' : 'delivery';
    const storeId = choice === 'collect' ? String(body.storeId || 'store-london') : null;
    db.prepare('UPDATE basket_items SET fulfilment_choice = ?, store_id = ? WHERE id = ?').run(
      choice,
      storeId,
      itemId
    );
  }

  db.prepare('UPDATE baskets SET updated_at = ? WHERE id = ?').run(
    new Date().toISOString(),
    basketId
  );
  return NextResponse.json(getBasketSnapshot(db, basketId));
}

export async function DELETE(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const db = getDb();
  const { basketId } = getOrCreateBasketId(req);
  const url = new URL(req.url);
  const itemId = url.searchParams.get('itemId');

  if (itemId) {
    const item = db
      .prepare('SELECT hold_id FROM basket_items WHERE id = ? AND basket_id = ?')
      .get(itemId, basketId) as { hold_id: string | null } | undefined;
    if (item?.hold_id) {
      db.prepare(`UPDATE workshop_holds SET status = 'released' WHERE id = ?`).run(item.hold_id);
    }
    db.prepare('DELETE FROM basket_items WHERE id = ? AND basket_id = ?').run(itemId, basketId);
  } else {
    db.prepare(
      `UPDATE workshop_holds SET status = 'released'
       WHERE basket_id = ? AND status = 'active'`
    ).run(basketId);
    db.prepare('DELETE FROM basket_items WHERE basket_id = ?').run(basketId);
  }

  return NextResponse.json(getBasketSnapshot(db, basketId));
}
