import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getSessionFromRequest, STAFF_ROLES } from '@/src/server/auth-session';
import { formatWorkshopTimeUK, getWorkshopAvailability } from '@/src/server/commerce';

export async function GET(req: NextRequest) {
  const user = getSessionFromRequest(req);
  if (!user || !STAFF_ROLES.includes(user.role)) {
    return NextResponse.json({ error: 'Staff sign-in required.' }, { status: 401 });
  }
  if (user.mfaEnabled && !user.mfaVerified) {
    return NextResponse.json({ error: 'MFA verification required.' }, { status: 403 });
  }

  const db = getDb();

  const orders = db
    .prepare(
      `SELECT o.*,
              (SELECT status FROM payment_intents pi WHERE pi.order_id = o.id LIMIT 1) as payment_status
       FROM orders o
       ORDER BY o.created_at DESC
       LIMIT 40`
    )
    .all() as Record<string, unknown>[];

  const orderItemsStmt = db.prepare(
    `SELECT oi.*, s.name as store_name FROM order_items oi LEFT JOIN stores s ON s.id = oi.store_id WHERE oi.order_id = ?`
  );
  const enrichedOrders = orders.map((o) => ({
    ...o,
    items: orderItemsStmt.all(o.id as string),
  }));

  const stock = db
    .prepare(
      `SELECT sl.*, e.sku, e.name as edition_name, p.title as product_title,
              COALESCE(s.name, 'Central Warehouse') as location_name
       FROM stock_locations sl
       JOIN editions e ON e.id = sl.edition_id
       JOIN products p ON p.id = e.product_id
       LEFT JOIN stores s ON s.id = sl.store_id
       ORDER BY p.featured_order ASC, sl.store_id IS NOT NULL, s.name`
    )
    .all();

  const artefacts = db
    .prepare(
      `SELECT ra.*, p.title as product_title
       FROM release_artefacts ra
       JOIN products p ON p.id = ra.product_id
       ORDER BY ra.quarantine_status ASC, ra.version DESC`
    )
    .all();

  const entitlements = db
    .prepare(
      `SELECT ent.*, p.title as product_title, e.name as edition_name, l.code as licence_code, o.order_number
       FROM entitlements ent
       JOIN products p ON p.id = ent.product_id
       JOIN editions e ON e.id = ent.edition_id
       JOIN licences l ON l.id = ent.licence_id
       JOIN orders o ON o.id = ent.order_id
       ORDER BY ent.granted_at DESC
       LIMIT 40`
    )
    .all();

  const workshops = db
    .prepare('SELECT * FROM workshops ORDER BY starts_at_utc ASC')
    .all()
    .map((w) => ({
      ...w,
      availability: getWorkshopAvailability(db, w.id as string),
      startFormatted: formatWorkshopTimeUK(w.starts_at_utc as string, w.display_timezone as string),
      bookings: db
        .prepare('SELECT * FROM workshop_bookings WHERE workshop_id = ? ORDER BY created_at DESC')
        .all(w.id as string),
    }));

  const products = db
    .prepare(
      `SELECT p.*, e.id as edition_id, e.sku, e.name as edition_name, e.price_pence, e.edition_type
       FROM products p
       JOIN editions e ON e.product_id = p.id
       ORDER BY p.featured_order ASC, e.price_pence ASC`
    )
    .all();

  const licences = db.prepare('SELECT * FROM licences ORDER BY code ASC').all();
  const stores = db.prepare('SELECT * FROM stores ORDER BY name ASC').all();
  const supportTickets = db
    .prepare('SELECT * FROM support_requests ORDER BY created_at DESC LIMIT 40')
    .all();
  const jobs = db
    .prepare(
      `SELECT fj.*, o.order_number FROM fulfilment_jobs fj
       JOIN orders o ON o.id = fj.order_id
       ORDER BY fj.created_at DESC LIMIT 30`
    )
    .all();
  const emails = db
    .prepare('SELECT * FROM email_outbox ORDER BY created_at DESC LIMIT 20')
    .all();
  const cmsRow = db.prepare(`SELECT value_json, updated_at FROM cms_blocks WHERE key = 'homepage'`).get() as
    | { value_json: string; updated_at: string }
    | undefined;
  const auditLogs = db
    .prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 60')
    .all();

  return NextResponse.json({
    staffUser: user,
    orders: enrichedOrders,
    stock,
    artefacts,
    entitlements,
    workshops,
    products,
    licences,
    stores,
    supportTickets,
    jobs,
    emails,
    homepageCms: cmsRow ? JSON.parse(cmsRow.value_json) : null,
    auditLogs,
  });
}
