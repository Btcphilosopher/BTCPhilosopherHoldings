import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getSessionFromRequest, requireStaffRole } from '@/src/server/auth-session';
import {
  advancePhysicalFulfilment,
  expireStaleWorkshopHolds,
  processOrderItemRefund,
  recordAudit,
  runFulfilmentJobs,
} from '@/src/server/commerce';
import { verifyMutationOrigin } from '@/src/server/security';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }

  const user = getSessionFromRequest(req);
  const db = getDb();
  const body = await req.json();
  const action = String(body.action || '');
  const now = new Date().toISOString();

  try {
    if (action === 'physical_action') {
      requireStaffRole(user, ['warehouse_staff', 'admin']);
      const res = advancePhysicalFulfilment(db, {
        orderItemId: String(body.orderItemId),
        action: body.physicalAction,
        actor: { id: user.id, email: user.email, role: user.role },
      });
      return NextResponse.json({ ok: true, result: res });
    }

    if (action === 'adjust_stock') {
      requireStaffRole(user, ['warehouse_staff', 'admin']);
      const stockId = String(body.stockId || '');
      const delta = Math.trunc(Number(body.delta || 0));
      const row = db.prepare('SELECT * FROM stock_locations WHERE id = ?').get(stockId) as
        | { id: string; edition_id: string; store_id: string | null; on_hand: number; reserved: number }
        | undefined;
      if (!row) return NextResponse.json({ error: 'Stock row not found.' }, { status: 404 });
      const nextOnHand = Math.max(row.reserved, row.on_hand + delta);
      const actualDelta = nextOnHand - row.on_hand;
      db.prepare('UPDATE stock_locations SET on_hand = ?, updated_at = ? WHERE id = ?').run(
        nextOnHand,
        now,
        stockId
      );
      db.prepare(
        `INSERT INTO stock_movements (id, edition_id, store_id, delta, reason, reference_id, actor_id, created_at)
         VALUES (?, ?, ?, ?, 'staff_adjustment', ?, ?, ?)`
      ).run(
        `mov-${crypto.randomUUID().slice(0, 10)}`,
        row.edition_id,
        row.store_id,
        actualDelta,
        String(body.reason || 'Manual stock check'),
        user.email,
        now
      );
      recordAudit(db, user, 'stock.adjusted', 'stock_location', stockId, {
        delta: actualDelta,
        newOnHand: nextOnHand,
      });
      return NextResponse.json({ ok: true, onHand: nextOnHand });
    }

    if (action === 'issue_refund') {
      requireStaffRole(user, ['finance', 'support', 'admin']);
      const res = processOrderItemRefund(db, {
        orderId: String(body.orderId),
        orderItemId: String(body.orderItemId),
        quantity: Number(body.quantity || 1),
        reason: String(body.reason || 'Customer refund request'),
        actor: user,
      });
      return NextResponse.json({ ok: true, result: res });
    }

    if (action === 'toggle_entitlement') {
      requireStaffRole(user, ['support', 'finance', 'admin']);
      const entId = String(body.entitlementId || '');
      const nextStatus = body.status === 'active' ? 'active' : 'revoked';
      db.prepare(
        `UPDATE entitlements SET status = ?, revoked_at = ? WHERE id = ?`
      ).run(nextStatus, nextStatus === 'revoked' ? now : null, entId);
      recordAudit(db, user, `entitlement.${nextStatus}`, 'entitlement', entId, {
        reason: body.reason || 'Staff console update',
      });
      return NextResponse.json({ ok: true, status: nextStatus });
    }

    if (action === 'publish_artefact') {
      requireStaffRole(user, ['catalogue_editor', 'admin']);
      const artefactId = String(body.artefactId || '');
      const art = db.prepare('SELECT * FROM release_artefacts WHERE id = ?').get(artefactId) as
        | Record<string, unknown>
        | undefined;
      if (!art) return NextResponse.json({ error: 'Artefact not found.' }, { status: 404 });
      db.prepare(
        `UPDATE release_artefacts
         SET quarantine_status = 'published',
             scan_report = 'SHA-256 verified; malware & licence header check passed',
             published_at = ?
         WHERE id = ?`
      ).run(now, artefactId);
      recordAudit(db, user, 'release.published', 'release_artefact', artefactId, {
        version: art.version,
        filename: art.filename,
        sha256: art.sha256,
      });
      return NextResponse.json({ ok: true });
    }

    if (action === 'update_edition_price') {
      requireStaffRole(user, ['catalogue_editor', 'finance', 'admin']);
      const editionId = String(body.editionId || '');
      const pricePence = Math.max(100, Math.round(Number(body.pricePence || 0)));
      db.prepare('UPDATE editions SET price_pence = ? WHERE id = ?').run(pricePence, editionId);
      recordAudit(db, user, 'catalogue.price_updated', 'edition', editionId, { pricePence });
      return NextResponse.json({ ok: true, pricePence });
    }

    if (action === 'checkin_workshop') {
      requireStaffRole(user, ['workshop_organiser', 'admin']);
      const bookingId = String(body.bookingId || '');
      db.prepare(
        `UPDATE workshop_bookings SET status = 'checked_in', checked_in_at = ? WHERE id = ?`
      ).run(now, bookingId);
      recordAudit(db, user, 'workshop.attendee_checked_in', 'workshop_booking', bookingId, {});
      return NextResponse.json({ ok: true });
    }

    if (action === 'update_support_ticket') {
      requireStaffRole(user, ['support', 'admin']);
      const ticketId = String(body.ticketId || '');
      const status = ['open', 'in_progress', 'resolved'].includes(String(body.status))
        ? String(body.status)
        : 'in_progress';
      const staffNotes = String(body.staffNotes || '');
      db.prepare(
        `UPDATE support_requests SET status = ?, staff_notes = ?, updated_at = ? WHERE id = ?`
      ).run(status, staffNotes, now, ticketId);
      recordAudit(db, user, 'support.ticket_updated', 'support_request', ticketId, { status });
      return NextResponse.json({ ok: true });
    }

    if (action === 'update_cms_homepage') {
      requireStaffRole(user, ['catalogue_editor', 'admin']);
      const payload = {
        heroHeadlineTop: String(body.heroHeadlineTop || 'BUILD SOMETHING'),
        heroHeadlineAccent: String(body.heroHeadlineAccent || 'BRILLIANT.'),
        heroSubheading: String(
          body.heroSubheading || 'Software, source code and the skills to make it yours.'
        ),
        workshopHeadline: String(body.workshopHeadline || 'FROM FIRST LINE TO FIRST APP'),
        workshopSubheading: String(
          body.workshopSubheading ||
            'Practical, hands-on coding workshops in-store and online, from complete beginners to full project builds.'
        ),
        featuredTitle: String(body.featuredTitle || 'Your next great project starts here'),
        demoNotice: String(
          body.demoNotice ||
            'Demonstration catalogue: illustrative sample products, pricing, and original sample download archives.'
        ),
      };
      db.prepare(
        `INSERT INTO cms_blocks (key, value_json, updated_by, updated_at)
         VALUES ('homepage', ?, ?, ?)
         ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_by = excluded.updated_by, updated_at = excluded.updated_at`
      ).run(JSON.stringify(payload), user.email, now);
      recordAudit(db, user, 'cms.homepage_updated', 'cms_block', 'homepage', payload);
      return NextResponse.json({ ok: true });
    }

    if (action === 'run_workers') {
      requireStaffRole(user, ['admin', 'warehouse_staff', 'finance']);
      const expired = expireStaleWorkshopHolds(db);
      const jobResults = runFulfilmentJobs(db);
      recordAudit(db, user, 'worker.reconcile_executed', 'system', 'workers', {
        expiredHoldsReleased: expired,
        jobsProcessed: jobResults.length,
      });
      return NextResponse.json({ ok: true, expired, jobResults });
    }

    return NextResponse.json({ error: 'Unknown admin action.' }, { status: 400 });
  } catch (err) {
    const msg = (err as Error).message;
    if (msg === 'UNAUTHORIZED') {
      return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
    }
    if (msg === 'FORBIDDEN' || msg === 'MFA_REQUIRED') {
      return NextResponse.json({ error: 'Insufficient role or MFA verification required.' }, { status: 403 });
    }
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
