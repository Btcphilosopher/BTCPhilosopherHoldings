import { NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';

export async function GET() {
  const db = getDb();
  const rows = db.prepare('SELECT * FROM stores ORDER BY name ASC').all() as Record<string, unknown>[];
  const stores = rows.map((s) => ({
    id: s.id,
    slug: s.slug,
    name: s.name,
    addressLine: s.address_line,
    city: s.city,
    postcode: s.postcode,
    phone: s.phone,
    openingHours: JSON.parse((s.opening_hours_json as string) || '{}'),
    collectionInstructions: s.collection_instructions,
    stockUpdatedAt: s.stock_updated_at,
  }));
  return NextResponse.json({ stores });
}
