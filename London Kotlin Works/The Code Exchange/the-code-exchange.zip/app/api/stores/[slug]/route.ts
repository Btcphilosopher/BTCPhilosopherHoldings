import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { formatWorkshopTimeUK } from '@/src/server/commerce';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ slug: string }> }
) {
  const { slug } = await context.params;
  const db = getDb();
  const s = db.prepare('SELECT * FROM stores WHERE slug = ?').get(slug) as
    | Record<string, unknown>
    | undefined;
  if (!s) {
    return NextResponse.json({ error: 'Store not found.' }, { status: 404 });
  }

  const stock = db
    .prepare(
      `SELECT sl.on_hand, sl.reserved, sl.updated_at,
              e.id as edition_id, e.sku, e.name as edition_name, e.price_pence,
              p.title as product_title, p.slug as product_slug, p.image_url
       FROM stock_locations sl
       JOIN editions e ON e.id = sl.edition_id
       JOIN products p ON p.id = e.product_id
       WHERE sl.store_id = ?
       ORDER BY p.featured_order ASC, e.price_pence ASC`
    )
    .all(s.id as string)
    .map((r) => ({
      ...r,
      available: Math.max(0, Number(r.on_hand) - Number(r.reserved)),
    }));

  const workshops = db
    .prepare('SELECT id, slug, title, starts_at_utc, display_timezone, price_pence FROM workshops WHERE store_id = ? ORDER BY starts_at_utc ASC')
    .all(s.id as string)
    .map((w) => ({
      ...w,
      startFormatted: formatWorkshopTimeUK(w.starts_at_utc as string, w.display_timezone as string),
    }));

  return NextResponse.json({
    store: {
      id: s.id,
      slug: s.slug,
      name: s.name,
      addressLine: s.address_line,
      city: s.city,
      postcode: s.postcode,
      phone: s.phone,
      openingHours: JSON.parse((s.opening_hours_json as string) || '{}'),
      collectionInstructions: s.collection_instructions,
      stockUpdatedAt: s.stock_updated_at,
    },
    stock,
    workshops,
  });
}
