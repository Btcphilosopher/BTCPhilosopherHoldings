import { NextResponse } from 'next/server';
import { getDb, getArtefactStorageDir } from '@/src/server/db';
import fs from 'node:fs';

export async function GET() {
  try {
    const db = getDb();
    const row = db.prepare('SELECT COUNT(*) as products FROM products').get() as { products: number };
    const storageExists = fs.existsSync(getArtefactStorageDir());
    return NextResponse.json({
      status: 'ok',
      service: 'the-code-exchange-storefront',
      database: 'connected',
      productsSeeded: row.products,
      storageReady: storageExists,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    return NextResponse.json(
      { status: 'error', message: (err as Error).message },
      { status: 500 }
    );
  }
}
