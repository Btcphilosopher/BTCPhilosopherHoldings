import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import {
  createSessionForUser,
  deleteSessionByRequest,
  getSessionFromRequest,
} from '@/src/server/auth-session';
import {
  SESSION_COOKIE_NAME,
  checkRateLimit,
  clearSecureCookie,
  hashPassword,
  logStructured,
  setSecureSessionCookie,
  verifyMutationOrigin,
  verifyPassword,
} from '@/src/server/security';

export async function GET(req: NextRequest) {
  const user = getSessionFromRequest(req);
  return NextResponse.json({ user });
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const clientIp = req.headers.get('x-forwarded-for') || 'local';
  if (!checkRateLimit(`auth:${clientIp}`, 30, 60_000)) {
    return NextResponse.json({ error: 'Too many authentication attempts.' }, { status: 429 });
  }

  const db = getDb();
  const body = await req.json();
  const action = String(body.action || 'login');

  if (action === 'demo_customer') {
    const demo = db
      .prepare(`SELECT id, email, name, role FROM users WHERE email = 'customer@codeexchange.co.uk'`)
      .get() as { id: string; email: string; name: string; role: 'customer' } | undefined;
    if (!demo) {
      return NextResponse.json({ error: 'Demo customer account unavailable.' }, { status: 404 });
    }
    const token = createSessionForUser(db, demo.id, 'customer', false);
    const res = NextResponse.json({
      user: {
        id: demo.id,
        email: demo.email,
        name: demo.name,
        role: 'customer',
        mfaEnabled: false,
        mfaVerified: false,
      },
      token,
    });
    setSecureSessionCookie(res, SESSION_COOKIE_NAME, token);
    logStructured('info', 'auth.demo_customer_signed_in', { userId: demo.id });
    return res;
  }

  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');

  if (!email || !email.includes('@')) {
    return NextResponse.json({ error: 'Please enter a valid email address.' }, { status: 400 });
  }

  if (action === 'register') {
    const name = String(body.name || '').trim();
    if (!name || password.length < 8) {
      return NextResponse.json(
        { error: 'Name and a password of at least 8 characters are required.' },
        { status: 400 }
      );
    }
    const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (exists) {
      return NextResponse.json({ error: 'An account with that email already exists.' }, { status: 409 });
    }
    const userId = `user-${crypto.randomUUID().slice(0, 12)}`;
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO users (id, email, name, password_hash, role, mfa_enabled, created_at)
       VALUES (?, ?, ?, ?, 'customer', 0, ?)`
    ).run(userId, email, name, hashPassword(password), now);

    // Attach any historical guest orders with matching email
    db.prepare(`UPDATE orders SET user_id = ? WHERE lower(customer_email) = ? AND user_id IS NULL`).run(
      userId,
      email
    );
    db.prepare(`UPDATE entitlements SET user_id = ? WHERE lower(customer_email) = ? AND user_id IS NULL`).run(
      userId,
      email
    );

    const token = createSessionForUser(db, userId, 'customer', false);
    const res = NextResponse.json({
      user: {
        id: userId,
        email,
        name,
        role: 'customer',
        mfaEnabled: false,
        mfaVerified: false,
      },
      token,
    });
    setSecureSessionCookie(res, SESSION_COOKIE_NAME, token);
    return res;
  }

  // Standard customer login
  const userRow = db
    .prepare('SELECT id, email, name, password_hash, role, mfa_enabled FROM users WHERE email = ?')
    .get(email) as
    | {
        id: string;
        email: string;
        name: string;
        password_hash: string;
        role: 'customer';
        mfa_enabled: number;
      }
    | undefined;

  if (!userRow || !verifyPassword(password, userRow.password_hash)) {
    return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });
  }
  if (userRow.role !== 'customer') {
    return NextResponse.json(
      { error: 'Staff accounts must sign in via the Administration Console with MFA.' },
      { status: 403 }
    );
  }

  const token = createSessionForUser(db, userRow.id, 'customer', false);
  const res = NextResponse.json({
    user: {
      id: userRow.id,
      email: userRow.email,
      name: userRow.name,
      role: userRow.role,
      mfaEnabled: false,
      mfaVerified: false,
    },
    token,
  });
  setSecureSessionCookie(res, SESSION_COOKIE_NAME, token);
  return res;
}

export async function DELETE(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  deleteSessionByRequest(req);
  const res = NextResponse.json({ signedOut: true });
  clearSecureCookie(res, SESSION_COOKIE_NAME);
  return res;
}
