import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import {
  bootstrapFirstAdmin,
  createSessionForUser,
  getSessionFromRequest,
  isStaffConfigured,
  STAFF_ROLES,
  verifyStaffCredentials,
  type StaffRole,
} from '@/src/server/auth-session';
import {
  SESSION_COOKIE_NAME,
  checkRateLimit,
  generateTotpCode,
  hashPassword,
  setSecureSessionCookie,
  verifyMutationOrigin,
} from '@/src/server/security';
import crypto from 'node:crypto';

export async function GET(req: NextRequest) {
  const db = getDb();
  const user = getSessionFromRequest(req);
  const config = isStaffConfigured(db);
  return NextResponse.json({
    user,
    staffConfigured: config.envPasscodeConfigured || config.claimedAdminExists,
    envPasscodeConfigured: config.envPasscodeConfigured,
    claimedAdminExists: config.claimedAdminExists,
  });
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const clientIp = req.headers.get('x-forwarded-for') || 'local';
  if (!checkRateLimit(`staff_auth:${clientIp}`, 20, 60_000)) {
    return NextResponse.json({ error: 'Too many staff sign-in attempts.' }, { status: 429 });
  }

  const db = getDb();
  const body = await req.json();
  const action = String(body.action || 'login');

  if (action === 'claim_admin') {
    try {
      const email = String(body.email || '').trim();
      const name = String(body.name || '').trim() || 'Store Administrator';
      const password = String(body.password || '');
      if (!email || !email.includes('@')) {
        return NextResponse.json({ error: 'Valid staff email is required.' }, { status: 400 });
      }
      const created = bootstrapFirstAdmin(db, email, name, password);
      const token = createSessionForUser(db, created.userId, 'admin', true);
      const res = NextResponse.json({
        claimed: true,
        totpSecret: created.totpSecret,
        currentTotpCode: created.currentTotpCode,
        user: {
          id: created.userId,
          email: email.toLowerCase(),
          name,
          role: 'admin',
          mfaEnabled: true,
          mfaVerified: true,
        },
        token,
      });
      setSecureSessionCookie(res, SESSION_COOKIE_NAME, token);
      return res;
    } catch (err) {
      return NextResponse.json({ error: (err as Error).message }, { status: 400 });
    }
  }

  if (action === 'login') {
    try {
      const email = String(body.email || '').trim();
      const password = String(body.password || '');
      const totpCode = body.totpCode ? String(body.totpCode) : undefined;
      const result = verifyStaffCredentials(db, email, password, totpCode);
      const token = createSessionForUser(
        db,
        result.user.id,
        result.user.role,
        result.mfaVerified
      );
      const res = NextResponse.json({
        user: {
          ...result.user,
          mfaVerified: result.mfaVerified,
        },
        token,
      });
      setSecureSessionCookie(res, SESSION_COOKIE_NAME, token);
      return res;
    } catch (err) {
      return NextResponse.json({ error: (err as Error).message }, { status: 401 });
    }
  }

  // Admin can issue/view current TOTP preview or create departmental staff accounts (catalogue_editor, warehouse_staff, etc.)
  if (action === 'create_staff_member') {
    const current = getSessionFromRequest(req);
    if (!current || current.role !== 'admin' || !current.mfaVerified) {
      return NextResponse.json({ error: 'Verified administrator access required.' }, { status: 403 });
    }
    const email = String(body.email || '').trim().toLowerCase();
    const name = String(body.name || '').trim();
    const role = String(body.role || '') as StaffRole;
    const password = String(body.password || '');
    if (!email || !name || !STAFF_ROLES.includes(role) || password.length < 8) {
      return NextResponse.json({ error: 'Valid email, name, staff role, and 8+ char password required.' }, { status: 400 });
    }
    const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (exists) {
      return NextResponse.json({ error: 'Staff email already exists.' }, { status: 409 });
    }
    const staffId = `user-staff-${crypto.randomUUID().slice(0, 8)}`;
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO users (id, email, name, password_hash, role, mfa_enabled, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?)`
    ).run(staffId, email, name, hashPassword(password), role, now);

    return NextResponse.json({
      created: true,
      staff: { id: staffId, email, name, role },
    });
  }

  if (action === 'get_totp_helper') {
    const current = getSessionFromRequest(req);
    if (!current || !STAFF_ROLES.includes(current.role)) {
      return NextResponse.json({ error: 'Staff session required.' }, { status: 403 });
    }
    const row = db.prepare('SELECT mfa_secret FROM users WHERE id = ?').get(current.id) as
      | { mfa_secret: string | null }
      | undefined;
    if (!row?.mfa_secret) {
      return NextResponse.json({ mfaSecret: null, currentCode: null });
    }
    return NextResponse.json({
      mfaSecret: row.mfa_secret,
      currentCode: generateTotpCode(row.mfa_secret),
    });
  }

  return NextResponse.json({ error: 'Unsupported staff action.' }, { status: 400 });
}
