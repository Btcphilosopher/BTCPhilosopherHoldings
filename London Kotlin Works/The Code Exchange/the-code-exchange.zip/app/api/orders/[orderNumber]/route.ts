import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { runFulfilmentJobs } from '@/src/server/commerce';
import { verifyMutationOrigin } from '@/src/server/security';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ orderNumber: string }> }
) {
  const { orderNumber } = await context.params;
  const db = getDb();

  const order = db
    .prepare('SELECT * FROM orders WHERE order_number = ?')
    .get(orderNumber) as Record<string, unknown> | undefined;

  if (!order) {
    return NextResponse.json({ error: 'Order not found.' }, { status: 404 });
  }

  const items = db
    .prepare(
      `SELECT oi.*, s.name as store_name, s.address_line as store_address, s.postcode as store_postcode, s.collection_instructions,
              p.slug as product_slug, w.slug as workshop_slug, w.starts_at_utc, w.display_timezone, w.venue_label
       FROM order_items oi
       LEFT JOIN stores s ON s.id = oi.store_id
       LEFT JOIN editions e ON e.id = oi.edition_id
       LEFT JOIN products p ON p.id = e.product_id
       LEFT JOIN workshops w ON w.id = oi.workshop_id
       WHERE oi.order_id = ?`
    )
    .all(order.id as string);

  const paymentIntents = db
    .prepare('SELECT id, provider, provider_ref, amount_pence, status, webhook_event_ids_json, updated_at FROM payment_intents WHERE order_id = ?')
    .all(order.id as string);

  const jobs = db
    .prepare('SELECT id, job_type, status, attempts, last_error, updated_at FROM fulfilment_jobs WHERE order_id = ?')
    .all(order.id as string);

  const refunds = db
    .prepare('SELECT id, order_item_id, amount_pence, reason, status, created_at FROM refunds WHERE order_id = ?')
    .all(order.id as string);

  return NextResponse.json({
    order: {
      id: order.id,
      orderNumber: order.order_number,
      customerEmail: order.customer_email,
      customerName: order.customer_name,
      status: order.status,
      subtotalNetPence: Number(order.subtotal_net_pence),
      discountPence: Number(order.discount_pence),
      vatPence: Number(order.vat_pence),
      deliveryPence: Number(order.delivery_pence),
      totalPence: Number(order.total_pence),
      currency: order.currency,
      shippingAddress: order.shipping_address_json
        ? JSON.parse(order.shipping_address_json as string)
        : null,
      termsAcceptedAt: order.terms_accepted_at,
      digitalWaiverAcceptedAt: order.digital_waiver_accepted_at,
      acceptedLicences: JSON.parse((order.accepted_licence_versions_json as string) || '[]'),
      createdAt: order.created_at,
    },
    items,
    paymentIntents,
    jobs,
    refunds,
  });
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ orderNumber: string }> }
) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const { orderNumber } = await context.params;
  const db = getDb();
  const order = db
    .prepare('SELECT id FROM orders WHERE order_number = ?')
    .get(orderNumber) as { id: string } | undefined;
  if (!order) {
    return NextResponse.json({ error: 'Order not found.' }, { status: 404 });
  }
  const body = await req.json();
  if (body.action === 'retry_fulfilment') {
    const results = runFulfilmentJobs(db, order.id);
    return NextResponse.json({ retried: true, results });
  }
  return NextResponse.json({ error: 'Unsupported action.' }, { status: 400 });
}
