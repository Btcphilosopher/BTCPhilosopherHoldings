import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getSessionFromRequest } from '@/src/server/auth-session';

export async function GET(req: NextRequest) {
  const user = getSessionFromRequest(req);
  if (!user) {
    return NextResponse.json({ error: 'Please sign in to view your orders.' }, { status: 401 });
  }

  const db = getDb();
  const orders = db
    .prepare(
      `SELECT id, order_number, status, total_pence, vat_pence, delivery_pence, discount_pence, currency, created_at
       FROM orders
       WHERE user_id = ? OR lower(customer_email) = lower(?)
       ORDER BY created_at DESC`
    )
    .all(user.id, user.email) as Record<string, unknown>[];

  const itemsStmt = db.prepare('SELECT * FROM order_items WHERE order_id = ?');
  const enriched = orders.map((o) => ({
    ...o,
    items: itemsStmt.all(o.id as string),
  }));

  return NextResponse.json({ orders: enriched });
}
