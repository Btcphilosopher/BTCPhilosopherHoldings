import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getSessionFromRequest } from '@/src/server/auth-session';
import { verifyMutationOrigin } from '@/src/server/security';

export async function GET(req: NextRequest) {
  const user = getSessionFromRequest(req);
  if (!user) {
    return NextResponse.json({ tickets: [] });
  }
  const db = getDb();
  const tickets = db
    .prepare(
      `SELECT id, topic, order_number, message, status, staff_notes, created_at, updated_at
       FROM support_requests
       WHERE user_id = ? OR lower(email) = lower(?)
       ORDER BY created_at DESC`
    )
    .all(user.id, user.email);
  return NextResponse.json({ tickets });
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const db = getDb();
  const user = getSessionFromRequest(req);
  const body = await req.json();

  const email = String(body.email || user?.email || '').trim().toLowerCase();
  const name = String(body.name || user?.name || '').trim();
  const topic = String(body.topic || 'General enquiry').trim();
  const message = String(body.message || '').trim();
  const orderNumber = body.orderNumber ? String(body.orderNumber).trim() : null;

  if (!email || !email.includes('@') || !name || message.length < 10) {
    return NextResponse.json(
      { error: 'Please provide your name, email, and a message (at least 10 characters).' },
      { status: 400 }
    );
  }

  const now = new Date().toISOString();
  const ticketId = `SUP-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  db.prepare(
    `INSERT INTO support_requests (id, user_id, email, name, order_number, topic, message, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?, ?)`
  ).run(ticketId, user?.id || null, email, name, orderNumber, topic, message, now, now);

  return NextResponse.json({ ticketId, status: 'open', createdAt: now });
}
