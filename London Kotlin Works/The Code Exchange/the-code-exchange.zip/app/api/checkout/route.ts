import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/src/server/db';
import { getOrCreateBasketId, getSessionFromRequest } from '@/src/server/auth-session';
import { createOrderFromBasket } from '@/src/server/commerce';
import { checkRateLimit, verifyMutationOrigin } from '@/src/server/security';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }
  const clientIp = req.headers.get('x-forwarded-for') || 'local';
  if (!checkRateLimit(`checkout:${clientIp}`, 25, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded for checkout.' }, { status: 429 });
  }

  const db = getDb();
  const user = getSessionFromRequest(req);
  const { basketId } = getOrCreateBasketId(req);
  const body = await req.json();

  const customerEmail = String(body.customerEmail || user?.email || '').trim();
  const customerName = String(body.customerName || user?.name || '').trim();
  const idempotencyKey = String(body.idempotencyKey || '').trim();

  if (!customerEmail || !customerEmail.includes('@') || !customerName) {
    return NextResponse.json(
      { error: 'Please provide your full name and a valid email address.' },
      { status: 400 }
    );
  }
  if (!idempotencyKey) {
    return NextResponse.json({ error: 'Missing idempotencyKey.' }, { status: 400 });
  }

  try {
    const result = createOrderFromBasket(db, {
      basketId,
      userId: user?.id || null,
      customerEmail,
      customerName,
      shippingAddress: body.shippingAddress || null,
      termsAccepted: Boolean(body.termsAccepted),
      digitalWaiverAccepted: Boolean(body.digitalWaiverAccepted),
      idempotencyKey,
      provider: body.provider === 'stripe_sandbox' ? 'stripe_sandbox' : 'simulated',
      simulateFulfilmentFailOnce: Boolean(body.simulateFulfilmentFailOnce),
    });

    return NextResponse.json({
      orderNumber: result.order.order_number,
      orderId: result.order.id,
      orderStatus: result.order.status,
      totalPence: result.order.total_pence,
      paymentIntentId: result.paymentIntent.id,
      paymentStatus: result.paymentIntent.status,
      idempotentReplay: result.idempotentReplay,
    });
  } catch (err) {
    const msg = (err as Error).message;
    const status = msg.includes('Insufficient stock') || msg.includes('expired') ? 409 : 400;
    return NextResponse.json({ error: msg }, { status });
  }
}
