'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { User, LogOut, Download, ChevronRight } from 'lucide-react';
import { useStore } from '@/components/StoreProvider';
import { formatGBPPrecise } from '@/lib/format';

interface OrderSummary {
  id: string;
  order_number: string;
  status: string;
  total_pence: number;
  created_at: string;
  items: { id: string; title: string; edition_name: string; fulfilment_status: string }[];
}

export default function AccountPage() {
  const { user, refreshUser, signOut } = useStore();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [orders, setOrders] = useState<OrderSummary[]>([]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    fetch('/api/orders', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : { orders: [] }))
      .then((d) => {
        if (!cancelled) setOrders(d.orders || []);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [user]);

  const visibleOrders = user ? orders : [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({ action: mode, email, name, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Authentication failed.');
        return;
      }
      await refreshUser();
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoCustomer = async () => {
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({ action: 'demo_customer' }),
      });
      if (res.ok) {
        await refreshUser();
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 space-y-8">
        {!user ? (
          <div className="max-w-lg mx-auto bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 space-y-6">
            <div className="space-y-1">
              <h1 className="font-display font-extrabold text-2xl text-[#14161b]">
                {mode === 'login' ? 'Sign in to your account' : 'Create a customer account'}
              </h1>
              <p className="text-sm text-[#4e535e]">
                Access your purchased software downloads, licence keys, receipts, and workshop bookings.
              </p>
            </div>

            <div className="flex gap-2 p-1 bg-[#f6f2ec] rounded-md">
              <button
                type="button"
                onClick={() => setMode('login')}
                className={`flex-1 py-2 text-xs font-semibold rounded cursor-pointer ${
                  mode === 'login' ? 'bg-white text-[#14161b] shadow-sm' : 'text-[#4e535e]'
                }`}
              >
                Sign in
              </button>
              <button
                type="button"
                onClick={() => setMode('register')}
                className={`flex-1 py-2 text-xs font-semibold rounded cursor-pointer ${
                  mode === 'register' ? 'bg-white text-[#14161b] shadow-sm' : 'text-[#4e535e]'
                }`}
              >
                Register
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <div>
                  <label htmlFor="acc-name" className="block text-xs font-semibold text-[#4e535e] mb-1">
                    Full name
                  </label>
                  <input
                    id="acc-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                  />
                </div>
              )}
              <div>
                <label htmlFor="acc-email" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  Email address
                </label>
                <input
                  id="acc-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                />
              </div>
              <div>
                <label htmlFor="acc-pass" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  Password (8+ characters)
                </label>
                <input
                  id="acc-pass"
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                />
              </div>

              {error && <p className="text-xs font-semibold text-[#9d004f]">{error}</p>}

              <button
                type="submit"
                disabled={submitting}
                className="w-full h-11 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold cursor-pointer"
              >
                {submitting ? 'Please wait...' : mode === 'login' ? 'Sign in' : 'Create account'}
              </button>
            </form>

            <div className="pt-4 border-t border-[#efe9df] space-y-2.5">
              <p className="text-xs text-[#4e535e]">
                Evaluating the storefront? Sign in instantly as our seeded demo customer (Oliver Bennett) with an existing library item and workshop seat:
              </p>
              <button
                type="button"
                disabled={submitting}
                onClick={() => void handleDemoCustomer()}
                className="w-full h-10 rounded-md border border-[#111318] text-[#111318] hover:bg-[#faf8f5] text-xs font-semibold cursor-pointer"
              >
                Continue as Demo Customer (Oliver Bennett)
              </button>
              <p className="text-xs text-[#4e535e] pt-1">
                Staff member?{' '}
                <Link href="/admin" className="text-[#c80064] font-semibold hover:underline">
                  Open Staff Administration Console
                </Link>
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-md bg-[#111318] text-white flex items-center justify-center">
                  <User className="w-6 h-6 text-[#e90d7b]" aria-hidden="true" />
                </div>
                <div>
                  <h1 className="font-display font-extrabold text-2xl text-[#14161b]">{user.name}</h1>
                  <p className="text-sm text-[#4e535e]">
                    {user.email} · Role: {user.role}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <Link
                  href="/library"
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#d4006c] text-white text-sm font-semibold"
                >
                  <Download className="w-4 h-4" aria-hidden="true" />
                  <span>My software &amp; downloads</span>
                </Link>
                <button
                  type="button"
                  onClick={() => void signOut()}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-md border border-[#d5cec3] text-sm font-semibold hover:bg-[#faf8f5] cursor-pointer"
                >
                  <LogOut className="w-4 h-4" aria-hidden="true" />
                  <span>Sign out</span>
                </button>
              </div>
            </div>

            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
              <h2 className="font-display font-bold text-xl text-[#14161b]">Order History</h2>
              {visibleOrders.length === 0 ? (
                <p className="text-sm text-[#4e535e]">You have not placed any orders yet.</p>
              ) : (
                <div className="divide-y divide-[#efe9df]">
                  {visibleOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <p className="font-display font-bold text-base text-[#14161b] tabular-nums">
                          {ord.order_number}
                        </p>
                        <p className="text-xs text-[#4e535e]">
                          {new Date(ord.created_at).toLocaleString('en-GB')} ·{' '}
                          {ord.items.map((i) => `${i.title} (${i.edition_name})`).join(', ')}
                        </p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="font-bold text-sm tabular-nums">
                            {formatGBPPrecise(ord.total_pence)}
                          </p>
                          <p className="text-xs text-[#c80064] capitalize">
                            {ord.status.replace(/_/g, ' ')}
                          </p>
                        </div>
                        <Link
                          href={`/orders/${encodeURIComponent(ord.order_number)}`}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#14161b] hover:text-[#c80064]"
                        >
                          <span>Receipt &amp; tracking</span>
                          <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
