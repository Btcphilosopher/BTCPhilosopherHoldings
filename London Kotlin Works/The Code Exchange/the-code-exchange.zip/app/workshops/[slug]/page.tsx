'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { Calendar, MapPin, Users, Laptop, Accessibility, ShieldAlert } from 'lucide-react';
import { useStore } from '@/components/StoreProvider';
import { formatGBP } from '@/lib/format';

interface WorkshopDetail {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  description: string;
  instructor: string;
  level: string;
  prerequisites: string;
  format: string;
  venueLabel: string;
  displayTimezone: string;
  startFormatted: { dateLabel: string; timeLabel: string; tzAbbrev: string; fullLabel: string };
  endFormatted: { timeLabel: string };
  pricePence: number;
  requiredEquipment: string;
  accessibilityInfo: string;
  cancellationTerms: string;
  availability: { capacity: number; booked: number; held: number; remaining: number; waitlistCount: number };
}

export default function WorkshopDetailPage() {
  const params = useParams<{ slug: string }>();
  const router = useRouter();
  const { reserveWorkshopSeat, setToast } = useStore();

  const [ws, setWs] = useState<WorkshopDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [seats, setSeats] = useState(1);
  const [reserving, setReserving] = useState(false);

  const [waitName, setWaitName] = useState('');
  const [waitEmail, setWaitEmail] = useState('');
  const [waitJoined, setWaitJoined] = useState(false);

  const loadWorkshop = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/workshops/${encodeURIComponent(params.slug)}`, {
        cache: 'no-store',
      });
      if (res.ok) {
        const d = await res.json();
        setWs(d.workshop);
      }
    } finally {
      setLoading(false);
    }
  }, [params.slug]);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/workshops/${encodeURIComponent(params.slug)}`, { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((d) => {
        if (!cancelled && d?.workshop) setWs(d.workshop);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [params.slug]);

  const handleReserve = async () => {
    if (!ws) return;
    setReserving(true);
    try {
      const ok = await reserveWorkshopSeat(ws.id, seats);
      if (ok) {
        router.push('/basket');
      } else {
        await loadWorkshop();
      }
    } finally {
      setReserving(false);
    }
  };

  const handleWaitlist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ws) return;
    const res = await fetch(`/api/workshops/${encodeURIComponent(ws.slug)}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: JSON.stringify({ name: waitName, email: waitEmail, seats: 1 }),
    });
    if (res.ok) {
      setWaitJoined(true);
      setToast('Added to the workshop waiting list.');
      await loadWorkshop();
    }
  };

  if (loading) {
    return (
      <div className="max-w-[1100px] mx-auto px-6 py-16 text-sm text-[#4e535e]">
        Loading workshop session...
      </div>
    );
  }

  if (!ws) {
    return (
      <div className="max-w-[1100px] mx-auto px-6 py-16 space-y-3">
        <h1 className="font-display font-bold text-2xl">Workshop not found</h1>
        <Link href="/workshops" className="text-[#c80064] font-semibold underline">
          View all workshops
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 space-y-8">
        <Link href="/workshops" className="text-xs font-semibold text-[#c80064] hover:underline">
          ← All workshops
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 space-y-6">
            <div className="space-y-2 border-b border-[#efe9df] pb-5">
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#4e535e]">
                <span className="font-semibold text-[#c80064]">{ws.format}</span>
                <span aria-hidden="true">·</span>
                <span>{ws.level}</span>
                <span aria-hidden="true">·</span>
                <span>{ws.displayTimezone}</span>
              </div>
              <h1 className="font-display font-extrabold text-3xl text-[#14161b]">{ws.title}</h1>
              <p className="text-base text-[#4e535e]">{ws.subtitle}</p>
            </div>

            <p className="text-sm text-[#14161b] leading-relaxed">{ws.description}</p>

            <dl className="space-y-4 text-sm border-t border-[#efe9df] pt-5">
              <div className="flex gap-3">
                <Calendar className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <dt className="font-semibold text-[#14161b]">Date &amp; UK Local Time</dt>
                  <dd className="text-[#4e535e]">
                    {ws.startFormatted.dateLabel}, {ws.startFormatted.timeLabel} –{' '}
                    {ws.endFormatted.timeLabel} ({ws.displayTimezone})
                  </dd>
                </div>
              </div>
              <div className="flex gap-3">
                <MapPin className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <dt className="font-semibold text-[#14161b]">Venue &amp; Instructor</dt>
                  <dd className="text-[#4e535e]">
                    {ws.venueLabel} · Led by {ws.instructor}
                  </dd>
                </div>
              </div>
              <div className="flex gap-3">
                <Laptop className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <dt className="font-semibold text-[#14161b]">Prerequisites &amp; Equipment</dt>
                  <dd className="text-[#4e535e]">
                    {ws.prerequisites} {ws.requiredEquipment}
                  </dd>
                </div>
              </div>
              <div className="flex gap-3">
                <Accessibility className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <dt className="font-semibold text-[#14161b]">Accessibility</dt>
                  <dd className="text-[#4e535e]">{ws.accessibilityInfo}</dd>
                </div>
              </div>
              <div className="flex gap-3">
                <ShieldAlert className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <dt className="font-semibold text-[#14161b]">Cancellation Terms</dt>
                  <dd className="text-[#4e535e]">{ws.cancellationTerms}</dd>
                </div>
              </div>
            </dl>
          </div>

          {/* Booking / Hold Box */}
          <aside className="lg:col-span-5 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-5">
            <div className="flex items-baseline justify-between border-b border-[#efe9df] pb-4">
              <div>
                <p className="font-display font-extrabold text-3xl text-[#14161b] tabular-nums">
                  {formatGBP(ws.pricePence)}
                </p>
                <p className="text-xs text-[#4e535e]">Per place · inc. 20% UK VAT</p>
              </div>
              <div className="text-right text-xs text-[#4e535e] tabular-nums">
                <span className="inline-flex items-center gap-1 font-semibold text-[#14161b]">
                  <Users className="w-3.5 h-3.5 text-[#d4006c]" aria-hidden="true" />
                  {ws.availability.remaining} / {ws.availability.capacity} available
                </span>
                {ws.availability.held > 0 && (
                  <p className="text-[11px] text-[#c80064]">
                    {ws.availability.held} place(s) temporarily held in checkout
                  </p>
                )}
              </div>
            </div>

            {ws.availability.remaining > 0 ? (
              <div className="space-y-4">
                <div>
                  <label htmlFor="ws-seats" className="block text-xs font-semibold text-[#4e535e] mb-1">
                    Number of places
                  </label>
                  <select
                    id="ws-seats"
                    value={seats}
                    onChange={(e) => setSeats(Number(e.target.value))}
                    className="w-full h-11 px-3 rounded-md border border-[#d5cec3] bg-white text-sm font-semibold tabular-nums"
                  >
                    {Array.from(
                      { length: Math.min(4, ws.availability.remaining) },
                      (_, i) => i + 1
                    ).map((n) => (
                      <option key={n} value={n}>
                        {n} place{n === 1 ? '' : 's'}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  disabled={reserving}
                  onClick={() => void handleReserve()}
                  className="w-full h-12 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white font-semibold text-sm cursor-pointer"
                >
                  {reserving ? 'Holding seat...' : 'Reserve place (15-minute hold)'}
                </button>
                <p className="text-xs text-[#4e535e]">
                  Reserving places holds capacity in your basket for 15 minutes while you complete checkout. Booking confirmation is recorded separately from email notifications.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm font-semibold text-[#14161b]">
                  This session is currently full ({ws.availability.waitlistCount} waiting).
                </p>
                {waitJoined ? (
                  <p className="text-sm text-[#c80064] font-semibold">
                    You are on the waiting list. We will email you if a hold expires or a place opens.
                  </p>
                ) : (
                  <form onSubmit={handleWaitlist} className="space-y-3">
                    <input
                      type="text"
                      required
                      value={waitName}
                      onChange={(e) => setWaitName(e.target.value)}
                      placeholder="Your name"
                      className="w-full h-10 px-3 rounded-md border border-[#d5cec3] text-sm"
                    />
                    <input
                      type="email"
                      required
                      value={waitEmail}
                      onChange={(e) => setWaitEmail(e.target.value)}
                      placeholder="you@example.co.uk"
                      className="w-full h-10 px-3 rounded-md border border-[#d5cec3] text-sm"
                    />
                    <button
                      type="submit"
                      className="w-full h-11 rounded-md bg-[#111318] text-white text-sm font-semibold cursor-pointer"
                    >
                      Join waiting list
                    </button>
                  </form>
                )}
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  );
}
