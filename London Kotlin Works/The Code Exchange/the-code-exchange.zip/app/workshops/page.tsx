'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Calendar, MapPin, Users, ChevronRight } from 'lucide-react';
import { formatGBP } from '@/lib/format';

interface WorkshopItem {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  instructor: string;
  level: string;
  format: string;
  venueLabel: string;
  startFormatted: { dateLabel: string; timeLabel: string; tzAbbrev: string; fullLabel: string };
  endFormatted: { timeLabel: string };
  pricePence: number;
  imageUrl: string;
  availability: { capacity: number; booked: number; held: number; remaining: number; waitlistCount: number };
}

export default function WorkshopsPage() {
  const [workshops, setWorkshops] = useState<WorkshopItem[]>([]);
  const [formatFilter, setFormatFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/workshops?format=${encodeURIComponent(formatFilter)}`, { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setWorkshops(d.workshops || []);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [formatFilter]);

  return (
    <div className="bg-[#f6f2ec] min-h-screen">
      {/* Dark Workshop Hero */}
      <section className="bg-[#141925] text-white border-b border-white/10">
        <div className="max-w-[1280px] mx-auto grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-6 relative min-h-[220px]">
            <Image
              src="/images/workshop-banner.png"
              alt="Coding workshop classroom at The Code Exchange"
              fill
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="lg:col-span-6 px-6 sm:px-10 py-10 flex flex-col justify-center space-y-3">
            <h1 className="font-display font-extrabold text-3xl sm:text-4xl tracking-tight">
              FROM FIRST LINE TO <span className="text-[#e90d7b]">FIRST APP</span>
            </h1>
            <p className="text-sm sm:text-base text-white/85 max-w-lg leading-relaxed">
              Practical, hands-on coding workshops in-store and online, from complete beginners to production source-code walkthroughs. All UK sessions automatically display GMT or BST accurately.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-10 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#e4ded4] pb-4">
          <p className="text-sm text-[#4e535e]">
            {loading ? 'Loading sessions...' : `${workshops.length} upcoming workshop session(s)`}
          </p>
          <div className="flex items-center gap-2">
            {['all', 'In Store', 'Online Live'].map((fmt) => (
              <button
                key={fmt}
                type="button"
                onClick={() => setFormatFilter(fmt)}
                className={`px-4 py-2 rounded-md text-xs font-semibold cursor-pointer ${
                  formatFilter === fmt
                    ? 'bg-[#d4006c] text-white'
                    : 'bg-white border border-[#e4ded4] text-[#14161b] hover:bg-[#ebe6de]'
                }`}
              >
                {fmt === 'all' ? 'All formats' : fmt}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {workshops.map((ws) => (
            <Link
              key={ws.id}
              href={`/workshops/${ws.slug}`}
              className="group bg-white border border-[#e4ded4] rounded-lg p-6 flex flex-col justify-between space-y-4 hover:-translate-y-0.5 hover:shadow-md transition-all"
            >
              <div className="space-y-2.5">
                <div className="flex flex-wrap items-center gap-2 text-xs text-[#4e535e]">
                  <span className="font-semibold text-[#c80064]">{ws.format}</span>
                  <span aria-hidden="true">·</span>
                  <span>{ws.level}</span>
                  <span aria-hidden="true">·</span>
                  <span>{ws.instructor}</span>
                </div>
                <h2 className="font-display font-bold text-xl text-[#14161b] group-hover:text-[#d4006c]">
                  {ws.title}
                </h2>
                <p className="text-sm text-[#4e535e] leading-relaxed">{ws.subtitle}</p>
              </div>

              <div className="space-y-3 pt-3 border-t border-[#efe9df] text-xs text-[#4e535e]">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#d4006c] shrink-0" aria-hidden="true" />
                  <span>
                    {ws.startFormatted.dateLabel} · {ws.startFormatted.timeLabel} –{' '}
                    {ws.endFormatted.timeLabel}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#d4006c] shrink-0" aria-hidden="true" />
                  <span>{ws.venueLabel}</span>
                </div>
                <div className="flex items-center justify-between pt-2">
                  <span className="inline-flex items-center gap-1.5 font-semibold text-[#14161b] tabular-nums">
                    <Users className="w-4 h-4 text-[#4e535e]" aria-hidden="true" />
                    {ws.availability.remaining > 0
                      ? `${ws.availability.remaining} of ${ws.availability.capacity} places left`
                      : `Full (${ws.availability.waitlistCount} on waiting list)`}
                  </span>
                  <span className="inline-flex items-center gap-1 font-display font-extrabold text-lg text-[#14161b] tabular-nums">
                    <span>{formatGBP(ws.pricePence)}</span>
                    <ChevronRight className="w-4 h-4 text-[#c80064]" aria-hidden="true" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
