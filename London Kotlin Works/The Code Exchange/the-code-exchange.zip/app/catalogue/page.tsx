'use client';

import React, { Suspense, useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter, useSearchParams } from 'next/navigation';
import { Search, SlidersHorizontal, ChevronRight, RotateCcw } from 'lucide-react';
import { formatGBP } from '@/lib/format';

interface CatalogueItem {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  category: string;
  publisher: string;
  platforms: string[];
  languages: string[];
  releaseVersion: string;
  sourceIncluded: boolean;
  imageUrl: string;
  minPricePence: number;
  formats: string[];
  licenceCodes: string[];
}

interface Facets {
  categories: string[];
  platforms: string[];
  languages: string[];
  formats: { value: string; label: string }[];
  licences: { value: string; label: string }[];
}

function CatalogueContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const currentQs = searchParams.toString();
  const urlQ = searchParams.get('q') || '';
  const category = searchParams.get('category') || 'All';
  const platform = searchParams.get('platform') || '';
  const language = searchParams.get('language') || '';
  const format = searchParams.get('format') || '';
  const licence = searchParams.get('licence') || '';
  const sourceOnly = searchParams.get('source') === '1';
  const maxPrice = searchParams.get('maxPrice') || '';
  const sort = searchParams.get('sort') || 'featured';
  const page = Number(searchParams.get('page') || '1');

  const [qOverride, setQOverride] = useState<{ qs: string; value: string } | null>(null);
  const q = qOverride && qOverride.qs === currentQs ? qOverride.value : urlQ;
  const setQ = (value: string) => setQOverride({ qs: currentQs, value });

  const [resultState, setResultState] = useState<{
    qs: string | null;
    items: CatalogueItem[];
    facets: Facets | null;
    total: number;
    totalPages: number;
  }>({
    qs: null,
    items: [],
    facets: null,
    total: 0,
    totalPages: 1,
  });

  const loading = resultState.qs !== currentQs;
  const { items, facets, total, totalPages } = resultState;

  const syncUrlAndFetch = useCallback(
    (overrides?: Record<string, string | number | boolean>) => {
      const next = {
        q: overrides?.q !== undefined ? String(overrides.q) : q,
        category: overrides?.category !== undefined ? String(overrides.category) : category,
        platform: overrides?.platform !== undefined ? String(overrides.platform) : platform,
        language: overrides?.language !== undefined ? String(overrides.language) : language,
        format: overrides?.format !== undefined ? String(overrides.format) : format,
        licence: overrides?.licence !== undefined ? String(overrides.licence) : licence,
        sourceOnly:
          overrides?.sourceOnly !== undefined ? Boolean(overrides.sourceOnly) : sourceOnly,
        maxPrice: overrides?.maxPrice !== undefined ? String(overrides.maxPrice) : maxPrice,
        sort: overrides?.sort !== undefined ? String(overrides.sort) : sort,
        page: overrides?.page !== undefined ? Number(overrides.page) : page,
      };

      const params = new URLSearchParams();
      if (next.q.trim()) params.set('q', next.q.trim());
      if (next.category && next.category !== 'All') params.set('category', next.category);
      if (next.platform) params.set('platform', next.platform);
      if (next.language) params.set('language', next.language);
      if (next.format) params.set('format', next.format);
      if (next.licence) params.set('licence', next.licence);
      if (next.sourceOnly) params.set('source', '1');
      if (next.maxPrice) params.set('maxPrice', next.maxPrice);
      if (next.sort && next.sort !== 'featured') params.set('sort', next.sort);
      if (next.page > 1) params.set('page', String(next.page));

      const qs = params.toString();
      router.replace(qs ? `/catalogue?${qs}` : '/catalogue', { scroll: false });
    },
    [q, category, platform, language, format, licence, sourceOnly, maxPrice, sort, page, router]
  );

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/catalogue${currentQs ? `?${currentQs}` : ''}`, { cache: 'no-store' })
      .then((r) => r.json())
      .then((data) => {
        if (cancelled) return;
        setResultState({
          qs: currentQs,
          items: data.items || [],
          facets: data.facets || null,
          total: data.pagination?.total || 0,
          totalPages: data.pagination?.totalPages || 1,
        });
      })
      .catch(() => {
        if (!cancelled) {
          setResultState((prev) => ({ ...prev, qs: currentQs }));
        }
      });
    return () => {
      cancelled = true;
    };
  }, [currentQs]);

  const resetAll = () => {
    setQOverride(null);
    router.replace('/catalogue', { scroll: false });
  };

  return (
    <div className="bg-[#f6f2ec] min-h-screen">
      {/* Dark Sub-header */}
      <div className="bg-[#111318] text-white border-b border-white/10">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="font-display font-extrabold text-3xl sm:text-4xl tracking-tight">
              Software &amp; Source Catalogue
            </h1>
            <p className="text-sm text-white/75 mt-2 max-w-2xl">
              Browse downloadable software, source-code packages, coding starter kits, and physical collector editions. All prices shown in GBP inclusive of UK VAT.
            </p>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              syncUrlAndFetch({ q, page: 1 });
            }}
            className="flex items-center gap-2 w-full md:w-96"
          >
            <label htmlFor="cat-search" className="sr-only">
              Search catalogue
            </label>
            <div className="relative flex-1">
              <Search
                className="w-4 h-4 text-[#4e535e] absolute left-3 top-1/2 -translate-y-1/2"
                aria-hidden="true"
              />
              <input
                id="cat-search"
                type="search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search title, Python, Linux..."
                className="w-full h-11 pl-9 pr-3 rounded-md bg-white text-sm text-[#14161b] placeholder:text-[#666b76]"
              />
            </div>
            <button
              type="submit"
              className="h-11 px-4 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold whitespace-nowrap cursor-pointer"
            >
              Search
            </button>
          </form>
        </div>
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Filters */}
        <aside className="lg:col-span-3 space-y-6">
          <div className="bg-white border border-[#e4ded4] rounded-lg p-5 space-y-5">
            <div className="flex items-center justify-between border-b border-[#e4ded4] pb-3">
              <h2 className="font-display font-bold text-base flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
                <span>Filters</span>
              </h2>
              <button
                type="button"
                onClick={resetAll}
                className="text-xs font-semibold text-[#c80064] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" aria-hidden="true" />
                <span>Reset</span>
              </button>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="filter-category" className="block text-xs font-semibold text-[#4e535e]">
                Category
              </label>
              <select
                id="filter-category"
                value={category}
                onChange={(e) => {
                  syncUrlAndFetch({ category: e.target.value, page: 1 });
                }}
                className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
              >
                <option value="All">All categories</option>
                {(facets?.categories || ['Creative', 'Developer tools', 'Business', 'Learning']).map(
                  (c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  )
                )}
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="filter-platform" className="block text-xs font-semibold text-[#4e535e]">
                Platform
              </label>
              <select
                id="filter-platform"
                value={platform}
                onChange={(e) => {
                  syncUrlAndFetch({ platform: e.target.value, page: 1 });
                }}
                className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
              >
                <option value="">Any platform</option>
                {(facets?.platforms || ['macOS', 'Windows', 'Linux', 'Web']).map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="filter-language" className="block text-xs font-semibold text-[#4e535e]">
                Programming language
              </label>
              <select
                id="filter-language"
                value={language}
                onChange={(e) => {
                  syncUrlAndFetch({ language: e.target.value, page: 1 });
                }}
                className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
              >
                <option value="">Any language</option>
                {(facets?.languages || ['Python', 'TypeScript', 'JavaScript', 'GLSL', 'SQL']).map(
                  (l) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  )
                )}
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="filter-format" className="block text-xs font-semibold text-[#4e535e]">
                Delivery format
              </label>
              <select
                id="filter-format"
                value={format}
                onChange={(e) => {
                  syncUrlAndFetch({ format: e.target.value, page: 1 });
                }}
                className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
              >
                <option value="">All formats</option>
                {(facets?.formats || []).map((f) => (
                  <option key={f.value} value={f.value}>
                    {f.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="filter-licence" className="block text-xs font-semibold text-[#4e535e]">
                Licence type
              </label>
              <select
                id="filter-licence"
                value={licence}
                onChange={(e) => {
                  syncUrlAndFetch({ licence: e.target.value, page: 1 });
                }}
                className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
              >
                <option value="">All licences</option>
                {(facets?.licences || []).map((l) => (
                  <option key={l.value} value={l.value}>
                    {l.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="filter-price" className="block text-xs font-semibold text-[#4e535e]">
                Maximum starting price
              </label>
              <select
                id="filter-price"
                value={maxPrice}
                onChange={(e) => {
                  syncUrlAndFetch({ maxPrice: e.target.value, page: 1 });
                }}
                className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
              >
                <option value="">No maximum</option>
                <option value="50">Up to £50</option>
                <option value="80">Up to £80</option>
                <option value="150">Up to £150</option>
              </select>
            </div>

            <label className="flex items-center gap-2.5 text-sm font-medium text-[#14161b] pt-1 cursor-pointer">
              <input
                type="checkbox"
                checked={sourceOnly}
                onChange={(e) => {
                  syncUrlAndFetch({ sourceOnly: e.target.checked, page: 1 });
                }}
                className="w-4 h-4 accent-[#d4006c]"
              />
              <span>Source code included only</span>
            </label>
          </div>
        </aside>

        {/* Results Area */}
        <div className="lg:col-span-9 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#e4ded4]">
            <p className="text-sm text-[#4e535e] tabular-nums">
              {loading ? 'Loading catalogue...' : `${total} demonstration product${total === 1 ? '' : 's'} found`}
            </p>
            <div className="flex items-center gap-2">
              <label htmlFor="sort-select" className="text-xs font-semibold text-[#4e535e]">
                Sort by
              </label>
              <select
                id="sort-select"
                value={sort}
                onChange={(e) => {
                  syncUrlAndFetch({ sort: e.target.value, page: 1 });
                }}
                className="h-9 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
              >
                <option value="featured">Featured</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="title_asc">Title A–Z</option>
              </select>
            </div>
          </div>

          {!loading && items.length === 0 ? (
            <div className="bg-white border border-[#e4ded4] rounded-lg p-10 text-center space-y-4">
              <h2 className="font-display font-bold text-xl text-[#14161b]">
                No matching software or kits found
              </h2>
              <p className="text-sm text-[#4e535e] max-w-md mx-auto">
                Try clearing one of your active filters or searching for broader terms like Python, Creative, or USB.
              </p>
              <button
                type="button"
                onClick={resetAll}
                className="px-5 py-2.5 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold cursor-pointer"
              >
                Reset all filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {items.map((item) => (
                <Link
                  key={item.id}
                  href={`/products/${item.slug}`}
                  className="group bg-white border border-[#e4ded4] rounded-lg p-5 flex gap-5 hover:-translate-y-0.5 hover:shadow-md transition-all"
                >
                  <div className="relative w-28 h-36 shrink-0 rounded bg-[#faf8f5] overflow-hidden">
                    <Image
                      src={item.imageUrl}
                      alt={`${item.title} software edition`}
                      fill
                      sizes="112px"
                      className="object-contain p-1.5"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="min-w-0 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-[#4e535e]">
                        <span>{item.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>v{item.releaseVersion}</span>
                        {item.sourceIncluded && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-[#c80064] font-medium">Source option</span>
                          </>
                        )}
                      </div>
                      <h2 className="font-display font-bold text-lg text-[#14161b] group-hover:text-[#d4006c] mt-1">
                        {item.title}
                      </h2>
                      <p className="text-sm text-[#4e535e] mt-1.5 line-clamp-2 leading-relaxed">
                        {item.subtitle}
                      </p>
                      <p className="text-xs text-[#4e535e] mt-2">
                        {item.platforms.join(' / ')}
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-[#efe9df] flex items-center justify-between">
                      <span className="font-display font-extrabold text-xl text-[#14161b] tabular-nums">
                        From {formatGBP(item.minPricePence)}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#c80064] group-hover:underline">
                        <span>Choose edition</span>
                        <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 pt-4">
              {Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pNum) => (
                <button
                  key={pNum}
                  type="button"
                  onClick={() => {
                    syncUrlAndFetch({ page: pNum });
                  }}
                  className={`h-9 min-w-[36px] px-3 rounded-md text-sm font-semibold tabular-nums cursor-pointer ${
                    pNum === page
                      ? 'bg-[#d4006c] text-white'
                      : 'bg-white border border-[#e4ded4] text-[#14161b] hover:bg-[#ebe6de]'
                  }`}
                >
                  {pNum}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function CataloguePage() {
  return (
    <Suspense
      fallback={
        <div className="max-w-[1280px] mx-auto px-6 py-16 text-sm text-[#4e535e]">
          Loading catalogue...
        </div>
      }
    >
      <CatalogueContent />
    </Suspense>
  );
}
