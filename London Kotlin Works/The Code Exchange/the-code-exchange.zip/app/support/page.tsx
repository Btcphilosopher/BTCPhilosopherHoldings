'use client';

import React, { useEffect, useState } from 'react';
import { LifeBuoy, CheckCircle2 } from 'lucide-react';
import { useStore } from '@/components/StoreProvider';

interface SupportTicket {
  id: string;
  topic: string;
  order_number: string | null;
  message: string;
  status: string;
  staff_notes: string;
  created_at: string;
}

export default function SupportPage() {
  const { user } = useStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [orderNumber, setOrderNumber] = useState('');
  const [topic, setTopic] = useState('Downloads & licences');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);

  const effectiveName = name || user?.name || '';
  const effectiveEmail = email || user?.email || '';

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    fetch('/api/support', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setTickets(d.tickets || []);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/support', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({
          name: effectiveName,
          email: effectiveEmail,
          orderNumber,
          topic,
          message,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not submit request.');
        return;
      }
      setCreatedId(data.ticketId);
      setMessage('');
      if (user) {
        const listRes = await fetch('/api/support', { cache: 'no-store' });
        if (listRes.ok) {
          const d = await listRes.json();
          setTickets(d.tickets || []);
        }
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1000px] mx-auto px-4 sm:px-6 space-y-8">
        <div className="border-b border-[#e4ded4] pb-5">
          <h1 className="font-display font-extrabold text-3xl text-[#14161b] flex items-center gap-3">
            <LifeBuoy className="w-7 h-7 text-[#d4006c]" aria-hidden="true" />
            <span>Customer Support &amp; Helpdesk</span>
          </h1>
          <p className="text-sm text-[#4e535e] mt-1">
            Questions about software licences, checksum verification, store Click &amp; Collect, or workshop transfers?
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <form
            onSubmit={handleSubmit}
            className="lg:col-span-7 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4"
          >
            <h2 className="font-display font-bold text-xl text-[#14161b]">Open a support request</h2>

            {createdId && (
              <div className="p-4 rounded-md bg-[#faf8f5] border border-[#d4006c]/30 text-sm flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                <span>
                  Support ticket <strong>{createdId}</strong> logged. Our London support team will respond in your account and by email.
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="sup-name" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  Name
                </label>
                <input
                  id="sup-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-[#d5cec3] text-sm"
                />
              </div>
              <div>
                <label htmlFor="sup-email" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  Email
                </label>
                <input
                  id="sup-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-[#d5cec3] text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="sup-topic" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  Topic
                </label>
                <select
                  id="sup-topic"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
                >
                  <option>Downloads &amp; licences</option>
                  <option>Physical delivery / Click &amp; Collect</option>
                  <option>Workshop booking or transfer</option>
                  <option>Refund or billing</option>
                </select>
              </div>
              <div>
                <label htmlFor="sup-order" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  Order number (optional)
                </label>
                <input
                  id="sup-order"
                  type="text"
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  placeholder="CX-2026-..."
                  className="w-full h-10 px-3 rounded-md border border-[#d5cec3] text-sm font-mono"
                />
              </div>
            </div>

            <div>
              <label htmlFor="sup-msg" className="block text-xs font-semibold text-[#4e535e] mb-1">
                How can we help?
              </label>
              <textarea
                id="sup-msg"
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full p-3 rounded-md border border-[#d5cec3] text-sm"
              />
            </div>

            {error && <p className="text-xs font-semibold text-[#9d004f]">{error}</p>}

            <button
              type="submit"
              disabled={submitting}
              className="h-11 px-6 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold cursor-pointer"
            >
              {submitting ? 'Sending...' : 'Submit support request'}
            </button>
          </form>

          <aside className="lg:col-span-5 space-y-4">
            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-3 text-sm">
              <h2 className="font-display font-bold text-lg text-[#14161b]">Quick Answers</h2>
              <div className="space-y-2 text-xs text-[#4e535e] leading-relaxed">
                <p>
                  <strong className="text-[#14161b]">Download links expired?</strong> Signed links last 10 minutes for security. Click Authorise &amp; Download again in My Software Library to issue a fresh link.
                </p>
                <p>
                  <strong className="text-[#14161b]">Does a boxed edition include a disc?</strong> Boxed Download-Key editions contain a printed key card and guide. Only USB Collector Editions include physical storage media.
                </p>
              </div>
            </div>

            {tickets.length > 0 && (
              <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-3">
                <h2 className="font-display font-bold text-lg text-[#14161b]">Your Recent Tickets</h2>
                <div className="divide-y divide-[#efe9df]">
                  {tickets.map((t) => (
                    <div key={t.id} className="py-3 space-y-1 text-xs">
                      <div className="flex justify-between font-semibold">
                        <span className="font-mono">{t.id}</span>
                        <span className="text-[#c80064] capitalize">{t.status.replace(/_/g, ' ')}</span>
                      </div>
                      <p className="text-[#4e535e]">{t.topic}</p>
                      <p className="text-[#14161b]">{t.message}</p>
                      {t.staff_notes && (
                        <p className="text-[#4e535e] italic">Staff note: {t.staff_notes}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  );
}
