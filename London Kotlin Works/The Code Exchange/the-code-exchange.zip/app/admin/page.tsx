'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Shield,
  PackageCheck,
  Boxes,
  FileArchive,
  CalendarCheck,
  LifeBuoy,
  ScrollText,
  RefreshCw,
} from 'lucide-react';
import { useStore } from '@/components/StoreProvider';
import { formatGBPPrecise } from '@/lib/format';

interface AdminOverviewData {
  staffUser: { id: string; email: string; name: string; role: string; mfaVerified: boolean };
  orders: {
    id: string;
    order_number: string;
    customer_name: string;
    customer_email: string;
    status: string;
    payment_status: string;
    total_pence: number;
    created_at: string;
    items: {
      id: string;
      item_type: string;
      title: string;
      edition_name: string;
      quantity: number;
      refunded_quantity: number;
      fulfilment_method: string;
      fulfilment_status: string;
      store_name: string | null;
    }[];
  }[];
  stock: {
    id: string;
    sku: string;
    product_title: string;
    edition_name: string;
    location_name: string;
    on_hand: number;
    reserved: number;
    updated_at: string;
  }[];
  artefacts: {
    id: string;
    product_title: string;
    version: string;
    filename: string;
    quarantine_status: string;
    scan_report: string;
    sha256: string;
  }[];
  entitlements: {
    id: string;
    customer_email: string;
    product_title: string;
    edition_name: string;
    licence_code: string;
    order_number: string;
    status: string;
    activation_key: string;
  }[];
  workshops: {
    id: string;
    title: string;
    venue_label: string;
    startFormatted: { fullLabel: string };
    availability: { capacity: number; booked: number; held: number; remaining: number };
    bookings: {
      id: string;
      attendee_name: string;
      attendee_email: string;
      seats: number;
      status: string;
      notification_status: string;
    }[];
  }[];
  products: {
    edition_id: string;
    sku: string;
    title: string;
    edition_name: string;
    price_pence: number;
  }[];
  supportTickets: {
    id: string;
    email: string;
    topic: string;
    message: string;
    status: string;
    staff_notes: string;
  }[];
  jobs: {
    id: string;
    order_number: string;
    job_type: string;
    status: string;
    attempts: number;
    last_error: string | null;
  }[];
  emails: { id: string; recipient: string; subject: string; status: string; created_at: string }[];
  homepageCms: {
    heroHeadlineTop: string;
    heroHeadlineAccent: string;
    heroSubheading: string;
    workshopHeadline: string;
    workshopSubheading: string;
    featuredTitle: string;
    demoNotice: string;
  };
  auditLogs: {
    id: string;
    actor_email: string;
    actor_role: string;
    action: string;
    target_type: string;
    target_id: string;
    details_json: string;
    created_at: string;
  }[];
}

type AdminTab = 'orders' | 'stock' | 'releases' | 'workshops' | 'support' | 'audit';

export default function AdminConsolePage() {
  const { refreshUser, setToast } = useStore();
  const [staffConfigured, setStaffConfigured] = useState<boolean | null>(null);
  const [overview, setOverview] = useState<AdminOverviewData | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [authError, setAuthError] = useState<string | null>(null);
  const [claimReceipt, setClaimReceipt] = useState<{
    totpSecret: string;
    currentTotpCode: string;
  } | null>(null);

  // Auth form fields
  const [email, setEmail] = useState('admin@codeexchange.co.uk');
  const [name, setName] = useState('Store Administrator');
  const [password, setPassword] = useState('');
  const [totpCode, setTotpCode] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // CMS edit fields
  const [cmsHeadlineTop, setCmsHeadlineTop] = useState('');
  const [cmsHeadlineAccent, setCmsHeadlineAccent] = useState('');
  const [cmsSubheading, setCmsSubheading] = useState('');

  const loadAdminState = useCallback(async () => {
    const statusRes = await fetch('/api/auth/staff', { cache: 'no-store' });
    const statusData = await statusRes.json();
    setStaffConfigured(Boolean(statusData.staffConfigured));

    const ovRes = await fetch('/api/admin/overview', { cache: 'no-store' });
    if (ovRes.ok) {
      const ov = (await ovRes.json()) as AdminOverviewData;
      setOverview(ov);
      if (ov.homepageCms) {
        setCmsHeadlineTop(ov.homepageCms.heroHeadlineTop);
        setCmsHeadlineAccent(ov.homepageCms.heroHeadlineAccent);
        setCmsSubheading(ov.homepageCms.heroSubheading);
      }
    } else {
      setOverview(null);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      fetch('/api/auth/staff', { cache: 'no-store' }).then((r) => r.json()),
      fetch('/api/admin/overview', { cache: 'no-store' }).then(async (r) =>
        r.ok ? ((await r.json()) as AdminOverviewData) : null
      ),
    ])
      .then(([statusData, ov]) => {
        if (cancelled) return;
        setStaffConfigured(Boolean(statusData.staffConfigured));
        setOverview(ov);
        if (ov?.homepageCms) {
          setCmsHeadlineTop(ov.homepageCms.heroHeadlineTop);
          setCmsHeadlineAccent(ov.homepageCms.heroHeadlineAccent);
          setCmsSubheading(ov.homepageCms.heroSubheading);
        }
      })
      .catch(() => {
        if (!cancelled) setStaffConfigured(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleClaimAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/staff', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({ action: 'claim_admin', email, name, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Could not claim staff admin.');
        return;
      }
      setClaimReceipt({
        totpSecret: data.totpSecret,
        currentTotpCode: data.currentTotpCode,
      });
      await refreshUser();
      await loadAdminState();
    } finally {
      setSubmitting(false);
    }
  };

  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/staff', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({ action: 'login', email, password, totpCode }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Staff sign-in failed.');
        return;
      }
      await refreshUser();
      await loadAdminState();
    } finally {
      setSubmitting(false);
    }
  };

  const runAdminAction = async (payload: Record<string, unknown>, successMsg: string) => {
    const res = await fetch('/api/admin/actions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      setToast(data.error || 'Action failed.');
      return;
    }
    setToast(successMsg);
    await loadAdminState();
  };

  if (staffConfigured === null) {
    return (
      <div className="max-w-[1200px] mx-auto px-6 py-16 text-sm text-[#4e535e]">
        Checking staff authentication status...
      </div>
    );
  }

  if (!overview) {
    return (
      <div className="bg-[#f6f2ec] min-h-screen py-12">
        <div className="max-w-lg mx-auto px-4 bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-3 border-b border-[#efe9df] pb-4">
            <Shield className="w-6 h-6 text-[#d4006c]" aria-hidden="true" />
            <div>
              <h1 className="font-display font-extrabold text-2xl text-[#14161b]">
                {staffConfigured ? 'Staff Administration Sign-In' : 'First-Run Staff Admin Setup'}
              </h1>
              <p className="text-xs text-[#4e535e]">
                {staffConfigured
                  ? 'Protected by role-based access control and TOTP MFA.'
                  : 'Claim the initial administrator account and generate your TOTP MFA authenticator secret.'}
              </p>
            </div>
          </div>

          <form
            onSubmit={staffConfigured ? handleStaffLogin : handleClaimAdmin}
            className="space-y-4"
          >
            <div>
              <label htmlFor="stf-email" className="block text-xs font-semibold text-[#4e535e] mb-1">
                Staff email
              </label>
              <input
                id="stf-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
              />
            </div>

            {!staffConfigured && (
              <div>
                <label htmlFor="stf-name" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  Administrator name
                </label>
                <input
                  id="stf-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                />
              </div>
            )}

            <div>
              <label htmlFor="stf-pass" className="block text-xs font-semibold text-[#4e535e] mb-1">
                {staffConfigured ? 'Staff password or ADMIN_PASSCODE' : 'Choose administrator password (8+ chars)'}
              </label>
              <input
                id="stf-pass"
                type="password"
                required
                minLength={staffConfigured ? 1 : 8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
              />
            </div>

            {staffConfigured && (
              <div>
                <label htmlFor="stf-mfa" className="block text-xs font-semibold text-[#4e535e] mb-1">
                  6-digit MFA code (if MFA enabled on account)
                </label>
                <input
                  id="stf-mfa"
                  type="text"
                  inputMode="numeric"
                  value={totpCode}
                  onChange={(e) => setTotpCode(e.target.value)}
                  placeholder="123456"
                  className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm font-mono"
                />
              </div>
            )}

            {authError && <p className="text-xs font-semibold text-[#9d004f]">{authError}</p>}

            <button
              type="submit"
              disabled={submitting}
              className="w-full h-11 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold cursor-pointer"
            >
              {submitting
                ? 'Authenticating...'
                : staffConfigured
                  ? 'Sign in to Admin Console'
                  : 'Claim Staff Administrator & Enable MFA'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  const tabs: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
    { id: 'orders', label: 'Orders & Refunds', icon: <PackageCheck className="w-4 h-4" /> },
    { id: 'stock', label: 'Stock & Stores', icon: <Boxes className="w-4 h-4" /> },
    { id: 'releases', label: 'Releases & Licences', icon: <FileArchive className="w-4 h-4" /> },
    { id: 'workshops', label: 'Workshops & Check-In', icon: <CalendarCheck className="w-4 h-4" /> },
    { id: 'support', label: 'Support & CMS', icon: <LifeBuoy className="w-4 h-4" /> },
    { id: 'audit', label: 'Workers & Audit Log', icon: <ScrollText className="w-4 h-4" /> },
  ];

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-8">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-6">
        {/* Top Bar */}
        <div className="bg-[#111318] text-white rounded-lg p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-[#e90d7b] uppercase tracking-wider">
              The Code Exchange Operations · Role: {overview.staffUser.role}
            </p>
            <h1 className="font-display font-extrabold text-2xl sm:text-3xl mt-1">
              Staff Administration Console
            </h1>
            <p className="text-xs text-white/70 mt-1">
              Signed in as {overview.staffUser.email}
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              void runAdminAction({ action: 'run_workers' }, 'Background workers & hold reconciliation executed.')
            }
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-xs font-semibold cursor-pointer shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Run fulfilment &amp; hold reconciliation</span>
          </button>
        </div>

        {claimReceipt && (
          <div className="bg-white border border-[#d4006c] rounded-lg p-5 space-y-2 text-sm">
            <p className="font-display font-bold text-[#14161b]">
              Save your Staff TOTP MFA Authenticator Details
            </p>
            <p className="text-xs text-[#4e535e]">
              Base32 Secret: <code className="font-mono bg-[#faf8f5] px-2 py-0.5">{claimReceipt.totpSecret}</code>{' '}
              · Current verification code:{' '}
              <code className="font-mono font-bold text-[#c80064]">{claimReceipt.currentTotpCode}</code>
            </p>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id)}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-md text-xs font-semibold cursor-pointer ${
                activeTab === t.id
                  ? 'bg-[#111318] text-white'
                  : 'bg-white border border-[#e4ded4] text-[#14161b] hover:bg-[#ebe6de]'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* Orders & Refunds Tab */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            {overview.orders.map((ord) => (
              <div key={ord.id} className="bg-white border border-[#e4ded4] rounded-lg p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#efe9df] pb-3">
                  <div>
                    <Link
                      href={`/orders/${encodeURIComponent(ord.order_number)}`}
                      className="font-display font-bold text-lg text-[#14161b] hover:text-[#c80064] tabular-nums"
                    >
                      {ord.order_number}
                    </Link>
                    <p className="text-xs text-[#4e535e]">
                      {ord.customer_name} ({ord.customer_email}) · {new Date(ord.created_at).toLocaleString('en-GB')}
                    </p>
                  </div>
                  <div className="text-right text-xs">
                    <p className="font-display font-extrabold text-base tabular-nums">
                      {formatGBPPrecise(ord.total_pence)}
                    </p>
                    <p className="text-[#c80064] font-semibold capitalize">
                      Order: {ord.status.replace(/_/g, ' ')} · Pay: {ord.payment_status || 'none'}
                    </p>
                  </div>
                </div>

                <div className="divide-y divide-[#efe9df]">
                  {ord.items.map((item) => {
                    const refundableQty = item.quantity - (item.refunded_quantity || 0);
                    return (
                      <div
                        key={item.id}
                        className="py-3 flex flex-col lg:flex-row lg:items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <p className="font-semibold text-sm text-[#14161b]">
                            {item.title} — {item.edition_name} × {item.quantity}
                          </p>
                          <p className="text-[#4e535e]">
                            Method: {item.fulfilment_method}
                            {item.store_name ? ` (${item.store_name})` : ''} · Status:{' '}
                            <strong className="text-[#14161b]">{item.fulfilment_status}</strong>
                          </p>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {item.item_type === 'edition' &&
                            (item.fulfilment_method === 'delivery' ||
                              item.fulfilment_method === 'collect') && (
                              <>
                                {['pick', 'pack', 'ready_for_collection', 'collect', 'dispatch', 'return'].map(
                                  (act) => (
                                    <button
                                      key={act}
                                      type="button"
                                      onClick={() =>
                                        void runAdminAction(
                                          {
                                            action: 'physical_action',
                                            orderItemId: item.id,
                                            physicalAction: act,
                                          },
                                          `Physical fulfilment updated (${act}).`
                                        )
                                      }
                                      className="px-2.5 py-1.5 rounded border border-[#d5cec3] hover:bg-[#faf8f5] font-semibold capitalize cursor-pointer"
                                    >
                                      {act.replace(/_/g, ' ')}
                                    </button>
                                  )
                                )}
                              </>
                            )}

                          {refundableQty > 0 && (
                            <button
                              type="button"
                              onClick={() =>
                                void runAdminAction(
                                  {
                                    action: 'issue_refund',
                                    orderId: ord.id,
                                    orderItemId: item.id,
                                    quantity: 1,
                                    reason: 'Staff console refund (1 unit)',
                                  },
                                  `Refund issued for 1 × ${item.title}.`
                                )
                              }
                              className="px-2.5 py-1.5 rounded bg-[#111318] text-white font-semibold cursor-pointer"
                            >
                              Refund 1 unit
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Stock & Stores Tab */}
        {activeTab === 'stock' && (
          <div className="bg-white border border-[#e4ded4] rounded-lg p-6 overflow-x-auto">
            <h2 className="font-display font-bold text-xl mb-4">
              Transactional Stock Ledger by Location
            </h2>
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-[#e4ded4] text-xs text-[#4e535e]">
                  <th className="py-2 pr-4">Product &amp; Edition</th>
                  <th className="py-2 pr-4">SKU</th>
                  <th className="py-2 pr-4">Location</th>
                  <th className="py-2 pr-4 text-right">On Hand</th>
                  <th className="py-2 pr-4 text-right">Reserved</th>
                  <th className="py-2 pr-4 text-right">Available</th>
                  <th className="py-2 text-right">Adjust</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#efe9df]">
                {overview.stock.map((s) => (
                  <tr key={s.id}>
                    <td className="py-3 pr-4 font-medium">
                      {s.product_title} — {s.edition_name}
                    </td>
                    <td className="py-3 pr-4 font-mono text-xs">{s.sku}</td>
                    <td className="py-3 pr-4 text-xs text-[#4e535e]">{s.location_name}</td>
                    <td className="py-3 pr-4 text-right tabular-nums">{s.on_hand}</td>
                    <td className="py-3 pr-4 text-right tabular-nums">{s.reserved}</td>
                    <td className="py-3 pr-4 text-right font-bold tabular-nums">
                      {Math.max(0, s.on_hand - s.reserved)}
                    </td>
                    <td className="py-3 text-right space-x-2">
                      <button
                        type="button"
                        onClick={() =>
                          void runAdminAction(
                            { action: 'adjust_stock', stockId: s.id, delta: 1, reason: 'Restock +1' },
                            'Stock incremented by 1.'
                          )
                        }
                        className="px-2.5 py-1 rounded border border-[#d5cec3] text-xs font-semibold cursor-pointer"
                      >
                        +1
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          void runAdminAction(
                            { action: 'adjust_stock', stockId: s.id, delta: -1, reason: 'Count -1' },
                            'Stock decremented by 1.'
                          )
                        }
                        className="px-2.5 py-1 rounded border border-[#d5cec3] text-xs font-semibold cursor-pointer"
                      >
                        -1
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Releases, Quarantine & Entitlements Tab */}
        {activeTab === 'releases' && (
          <div className="space-y-6">
            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
              <h2 className="font-display font-bold text-xl">
                Release Artefacts &amp; Quarantine Gate
              </h2>
              <div className="divide-y divide-[#efe9df]">
                {overview.artefacts.map((art) => (
                  <div
                    key={art.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-0.5">
                      <p className="font-semibold text-sm text-[#14161b]">
                        {art.product_title} · <span className="font-mono">{art.filename}</span> (v
                        {art.version})
                      </p>
                      <p className="text-[#4e535e]">
                        Status: <strong className="text-[#c80064]">{art.quarantine_status}</strong> ·{' '}
                        {art.scan_report}
                      </p>
                      <p className="font-mono text-[11px] text-[#4e535e] break-all">
                        SHA-256: {art.sha256}
                      </p>
                    </div>
                    {art.quarantine_status !== 'published' && (
                      <button
                        type="button"
                        onClick={() =>
                          void runAdminAction(
                            { action: 'publish_artefact', artefactId: art.id },
                            `${art.filename} scanned and published to customer library.`
                          )
                        }
                        className="px-4 py-2 rounded-md bg-[#d4006c] text-white font-semibold shrink-0 cursor-pointer"
                      >
                        Scan &amp; Publish Release
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
              <h2 className="font-display font-bold text-xl">Customer Digital Entitlements</h2>
              <div className="divide-y divide-[#efe9df]">
                {overview.entitlements.map((ent) => (
                  <div
                    key={ent.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <p className="font-semibold text-sm text-[#14161b]">
                        {ent.product_title} ({ent.edition_name}) — {ent.customer_email}
                      </p>
                      <p className="text-[#4e535e] font-mono">
                        {ent.activation_key} · Order {ent.order_number} · Status: {ent.status}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        void runAdminAction(
                          {
                            action: 'toggle_entitlement',
                            entitlementId: ent.id,
                            status: ent.status === 'active' ? 'revoked' : 'active',
                          },
                          `Entitlement ${ent.status === 'active' ? 'revoked' : 're-activated'}.`
                        )
                      }
                      className="px-3.5 py-1.5 rounded border border-[#d5cec3] font-semibold cursor-pointer"
                    >
                      {ent.status === 'active' ? 'Revoke entitlement' : 'Restore entitlement'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Workshops & Check-in Tab */}
        {activeTab === 'workshops' && (
          <div className="space-y-4">
            {overview.workshops.map((ws) => (
              <div key={ws.id} className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#efe9df] pb-3">
                  <div>
                    <h2 className="font-display font-bold text-lg">{ws.title}</h2>
                    <p className="text-xs text-[#4e535e]">
                      {ws.venue_label} · {ws.startFormatted.fullLabel}
                    </p>
                  </div>
                  <p className="text-xs font-semibold tabular-nums">
                    Booked: {ws.availability.booked} · Held: {ws.availability.held} · Remaining:{' '}
                    {ws.availability.remaining} / {ws.availability.capacity}
                  </p>
                </div>

                {ws.bookings.length === 0 ? (
                  <p className="text-xs text-[#4e535e]">No confirmed attendees yet.</p>
                ) : (
                  <div className="divide-y divide-[#efe9df]">
                    {ws.bookings.map((bk) => (
                      <div
                        key={bk.id}
                        className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                      >
                        <div>
                          <p className="font-semibold text-sm">{bk.attendee_name}</p>
                          <p className="text-[#4e535e]">
                            {bk.attendee_email} · {bk.seats} place(s) · Status: {bk.status} · Notification:{' '}
                            {bk.notification_status}
                          </p>
                        </div>
                        {bk.status === 'confirmed' && (
                          <button
                            type="button"
                            onClick={() =>
                              void runAdminAction(
                                { action: 'checkin_workshop', bookingId: bk.id },
                                `${bk.attendee_name} checked in.`
                              )
                            }
                            className="px-3.5 py-1.5 rounded bg-[#d4006c] text-white font-semibold cursor-pointer"
                          >
                            Check in attendee
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Support & CMS Tab */}
        {activeTab === 'support' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
              <h2 className="font-display font-bold text-xl">Homepage CMS Content</h2>
              <div className="space-y-3 text-sm">
                <div>
                  <label className="block text-xs font-semibold text-[#4e535e] mb-1">
                    Hero headline top
                  </label>
                  <input
                    type="text"
                    value={cmsHeadlineTop}
                    onChange={(e) => setCmsHeadlineTop(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-[#d5cec3]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4e535e] mb-1">
                    Hero headline accent
                  </label>
                  <input
                    type="text"
                    value={cmsHeadlineAccent}
                    onChange={(e) => setCmsHeadlineAccent(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-[#d5cec3]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4e535e] mb-1">
                    Hero subheading
                  </label>
                  <input
                    type="text"
                    value={cmsSubheading}
                    onChange={(e) => setCmsSubheading(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-[#d5cec3]"
                  />
                </div>
                <button
                  type="button"
                  onClick={() =>
                    void runAdminAction(
                      {
                        action: 'update_cms_homepage',
                        ...overview.homepageCms,
                        heroHeadlineTop: cmsHeadlineTop,
                        heroHeadlineAccent: cmsHeadlineAccent,
                        heroSubheading: cmsSubheading,
                      },
                      'Homepage CMS updated.'
                    )
                  }
                  className="px-4 py-2.5 rounded-md bg-[#d4006c] text-white text-xs font-semibold cursor-pointer"
                >
                  Save homepage content
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
              <h2 className="font-display font-bold text-xl">Support Queue</h2>
              {overview.supportTickets.length === 0 ? (
                <p className="text-xs text-[#4e535e]">No support tickets logged yet.</p>
              ) : (
                <div className="divide-y divide-[#efe9df]">
                  {overview.supportTickets.map((t) => (
                    <div key={t.id} className="py-3 space-y-2 text-xs">
                      <div className="flex justify-between font-semibold">
                        <span>
                          {t.id} · {t.email}
                        </span>
                        <span className="text-[#c80064]">{t.status}</span>
                      </div>
                      <p>{t.message}</p>
                      <button
                        type="button"
                        onClick={() =>
                          void runAdminAction(
                            {
                              action: 'update_support_ticket',
                              ticketId: t.id,
                              status: 'resolved',
                              staffNotes: 'Resolved by London Support Desk.',
                            },
                            `Ticket ${t.id} marked resolved.`
                          )
                        }
                        className="px-3 py-1 rounded border border-[#d5cec3] font-semibold cursor-pointer"
                      >
                        Mark resolved
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Workers & Audit Log Tab */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-3">
              <h2 className="font-display font-bold text-xl">Background Fulfilment Jobs</h2>
              <div className="divide-y divide-[#efe9df] text-xs">
                {overview.jobs.map((j) => (
                  <div key={j.id} className="py-2.5 flex justify-between gap-4">
                    <span>
                      <strong className="font-mono">{j.order_number}</strong> · {j.job_type} (attempts:{' '}
                      {j.attempts})
                    </span>
                    <span className="font-semibold text-[#c80064]">{j.status}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-3">
              <h2 className="font-display font-bold text-xl">Immutable Staff &amp; System Audit Log</h2>
              <div className="divide-y divide-[#efe9df] text-xs">
                {overview.auditLogs.map((log) => (
                  <div key={log.id} className="py-2.5 space-y-0.5">
                    <div className="flex flex-wrap justify-between gap-2">
                      <span className="font-semibold text-[#14161b]">
                        {log.action} · {log.target_type}:{log.target_id}
                      </span>
                      <span className="text-[#4e535e] tabular-nums">
                        {new Date(log.created_at).toLocaleString('en-GB')}
                      </span>
                    </div>
                    <p className="text-[#4e535e]">
                      Actor: {log.actor_email} ({log.actor_role}) ·{' '}
                      <span className="font-mono">{log.details_json}</span>
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
