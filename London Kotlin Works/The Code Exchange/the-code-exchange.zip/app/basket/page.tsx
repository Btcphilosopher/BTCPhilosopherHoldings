'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Trash2, Clock, ChevronRight, Tag, ShoppingBag } from 'lucide-react';
import { useStore } from '@/components/StoreProvider';
import { formatGBPPrecise } from '@/lib/format';

interface StoreOption {
  id: string;
  name: string;
}

export default function BasketPage() {
  const { basket, updateBasketItem, removeBasketItem, refreshBasket } = useStore();
  const [discountInput, setDiscountInput] = useState('');
  const [stores, setStores] = useState<StoreOption[]>([]);
  const [applyingCode, setApplyingCode] = useState(false);

  useEffect(() => {
    void refreshBasket();
    fetch('/api/stores')
      .then((r) => r.json())
      .then((d) => setStores(d.stores || []))
      .catch(() => {});
  }, [refreshBasket]);

  const items = basket?.items || [];
  const totals = basket?.totals;

  const handleApplyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setApplyingCode(true);
    try {
      await updateBasketItem({ discountCode: discountInput });
    } finally {
      setApplyingCode(false);
    }
  };

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 border-b border-[#e4ded4] pb-5">
          <div>
            <h1 className="font-display font-extrabold text-3xl text-[#14161b] tracking-tight">
              Your Basket
            </h1>
            <p className="text-sm text-[#4e535e] mt-1">
              Mix digital downloads, physical editions, and workshop reservations in one checkout.
            </p>
          </div>
          <Link href="/catalogue" className="text-sm font-semibold text-[#c80064] hover:underline">
            Continue browsing software
          </Link>
        </div>

        {items.length === 0 ? (
          <div className="bg-white border border-[#e4ded4] rounded-lg p-12 text-center space-y-4">
            <ShoppingBag className="w-10 h-10 text-[#4e535e] mx-auto" aria-hidden="true" />
            <h2 className="font-display font-bold text-xl text-[#14161b]">Your basket is empty</h2>
            <p className="text-sm text-[#4e535e] max-w-md mx-auto">
              Explore our software editions, source-code packages, starter kits, or upcoming coding workshops.
            </p>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <Link
                href="/catalogue"
                className="px-5 py-2.5 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold"
              >
                Explore software
              </Link>
              <Link
                href="/workshops"
                className="px-5 py-2.5 rounded-md border border-[#d5cec3] bg-white hover:bg-[#faf8f5] text-sm font-semibold text-[#14161b]"
              >
                Browse workshops
              </Link>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Items List */}
            <div className="lg:col-span-8 space-y-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="bg-white border border-[#e4ded4] rounded-lg p-5 flex flex-col sm:flex-row gap-5"
                >
                  <div className="relative w-24 h-24 shrink-0 rounded bg-[#faf8f5] overflow-hidden">
                    <Image
                      src={item.imageUrl}
                      alt={item.title}
                      fill
                      sizes="96px"
                      className="object-contain p-1.5"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h2 className="font-display font-bold text-lg text-[#14161b]">
                          {item.title}
                        </h2>
                        <p className="text-sm text-[#4e535e]">
                          {item.editionName} · <span className="font-mono text-xs">{item.sku}</span>
                        </p>
                      </div>
                      <p className="font-display font-extrabold text-lg text-[#14161b] tabular-nums shrink-0">
                        {formatGBPPrecise(item.lineTotalPence)}
                      </p>
                    </div>

                    {item.itemType === 'workshop' && item.workshopTime && (
                      <div className="text-xs text-[#4e535e] flex flex-wrap items-center gap-2">
                        <span>{item.workshopTime.fullLabel}</span>
                        {item.holdExpiresAt && (
                          <span className="inline-flex items-center gap-1 text-[#c80064] font-semibold">
                            <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>
                              Seat held until{' '}
                              {new Date(item.holdExpiresAt).toLocaleTimeString('en-GB', {
                                hour: '2-digit',
                                minute: '2-digit',
                                timeZone: 'Europe/London',
                              })}
                            </span>
                          </span>
                        )}
                      </div>
                    )}

                    {item.itemType === 'edition' && item.requiresShipping && (
                      <div className="flex flex-wrap items-center gap-3 pt-1">
                        <select
                          aria-label={`Fulfilment choice for ${item.title}`}
                          value={item.fulfilmentChoice}
                          onChange={(e) =>
                            void updateBasketItem({
                              itemId: item.id,
                              fulfilmentChoice: e.target.value,
                              storeId: item.storeId || 'store-london',
                            })
                          }
                          className="h-9 px-2.5 rounded-md border border-[#d5cec3] bg-white text-xs font-medium"
                        >
                          <option value="delivery">UK Tracked Delivery</option>
                          <option value="collect">Click &amp; Collect in store (Free)</option>
                        </select>

                        {item.fulfilmentChoice === 'collect' && stores.length > 0 && (
                          <select
                            aria-label={`Collection store for ${item.title}`}
                            value={item.storeId || 'store-london'}
                            onChange={(e) =>
                              void updateBasketItem({
                                itemId: item.id,
                                fulfilmentChoice: 'collect',
                                storeId: e.target.value,
                              })
                            }
                            className="h-9 px-2.5 rounded-md border border-[#d5cec3] bg-white text-xs font-medium"
                          >
                            {stores.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name}
                              </option>
                            ))}
                          </select>
                        )}
                      </div>
                    )}

                    {item.licenceCode && (
                      <p className="text-xs text-[#4e535e]">
                        Licence: {item.licenceCode} (v{item.licenceVersion})
                      </p>
                    )}

                    <div className="flex items-center justify-between pt-2">
                      {item.itemType === 'edition' ? (
                        <div className="inline-flex items-center border border-[#d5cec3] rounded-md">
                          <button
                            type="button"
                            aria-label={`Decrease quantity for ${item.title}`}
                            onClick={() =>
                              void updateBasketItem({
                                itemId: item.id,
                                quantity: item.quantity - 1,
                              })
                            }
                            className="w-8 h-8 flex items-center justify-center text-sm font-bold hover:bg-[#faf8f5] cursor-pointer"
                          >
                            -
                          </button>
                          <span className="w-9 text-center text-sm font-semibold tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            aria-label={`Increase quantity for ${item.title}`}
                            onClick={() =>
                              void updateBasketItem({
                                itemId: item.id,
                                quantity: item.quantity + 1,
                              })
                            }
                            className="w-8 h-8 flex items-center justify-center text-sm font-bold hover:bg-[#faf8f5] cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-[#4e535e] tabular-nums">
                          {item.quantity} workshop place{item.quantity === 1 ? '' : 's'}
                        </span>
                      )}

                      <button
                        type="button"
                        onClick={() => void removeBasketItem(item.id)}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#4e535e] hover:text-[#c80064] cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary Column */}
            <aside className="lg:col-span-4 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-5">
              <h2 className="font-display font-bold text-xl text-[#14161b]">Order Summary</h2>

              <form onSubmit={handleApplyCode} className="space-y-2">
                <label htmlFor="discount-code" className="block text-xs font-semibold text-[#4e535e]">
                  Promotional code (try <span className="font-mono">CODE10</span> or{' '}
                  <span className="font-mono">WELCOME5</span>)
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag
                      className="w-3.5 h-3.5 text-[#4e535e] absolute left-3 top-1/2 -translate-y-1/2"
                      aria-hidden="true"
                    />
                    <input
                      id="discount-code"
                      type="text"
                      value={discountInput}
                      onChange={(e) => setDiscountInput(e.target.value)}
                      placeholder="CODE10"
                      className="w-full h-10 pl-8 pr-3 rounded-md border border-[#d5cec3] text-sm uppercase"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={applyingCode}
                    className="h-10 px-4 rounded-md bg-[#111318] text-white text-xs font-semibold cursor-pointer"
                  >
                    Apply
                  </button>
                </div>
                {totals?.appliedDiscountCode && (
                  <div className="flex items-center justify-between text-xs text-[#c80064] font-semibold">
                    <span>Applied: {totals.appliedDiscountCode}</span>
                    <button
                      type="button"
                      onClick={() => void updateBasketItem({ discountCode: '' })}
                      className="underline cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                )}
              </form>

              {totals && (
                <dl className="space-y-2.5 text-sm border-t border-[#efe9df] pt-4">
                  <div className="flex justify-between">
                    <dt className="text-[#4e535e]">Items (ex. VAT)</dt>
                    <dd className="tabular-nums font-medium">{formatGBPPrecise(totals.itemsNetPence)}</dd>
                  </div>
                  {totals.discountPence > 0 && (
                    <div className="flex justify-between text-[#c80064]">
                      <dt>Discount ({totals.appliedDiscountCode})</dt>
                      <dd className="tabular-nums font-semibold">
                        -{formatGBPPrecise(totals.discountPence)}
                      </dd>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <dt className="text-[#4e535e]">UK VAT (20%)</dt>
                    <dd className="tabular-nums font-medium">{formatGBPPrecise(totals.taxPence)}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-[#4e535e]">Delivery</dt>
                    <dd className="tabular-nums font-medium">
                      {totals.deliveryPence === 0
                        ? 'Free'
                        : formatGBPPrecise(totals.deliveryPence)}
                    </dd>
                  </div>
                  <div className="flex justify-between border-t border-[#e4ded4] pt-3 text-base font-display font-extrabold text-[#14161b]">
                    <dt>Total (GBP)</dt>
                    <dd className="tabular-nums">{formatGBPPrecise(totals.totalPence)}</dd>
                  </div>
                </dl>
              )}

              <Link
                href="/checkout"
                className="w-full h-12 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <span>Proceed to checkout</span>
                <ChevronRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
