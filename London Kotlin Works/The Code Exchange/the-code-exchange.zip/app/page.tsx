import { getDb } from '@/src/server/db';
import { HomeShowcase, type HomeProductCard, type HomepageCms } from '@/components/HomeShowcase';

export const dynamic = 'force-dynamic';

export default function HomePage() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT p.id, p.slug, p.title, p.subtitle, p.category, p.image_url, p.source_included,
              (SELECT MIN(price_pence) FROM editions WHERE product_id = p.id AND is_active = 1) as min_price_pence
       FROM products p
       ORDER BY p.featured_order ASC`
    )
    .all() as Record<string, unknown>[];

  const products: HomeProductCard[] = rows.map((r) => ({
    id: r.id as string,
    slug: r.slug as string,
    title: r.title as string,
    subtitle: r.subtitle as string,
    category: r.category as string,
    imageUrl: r.image_url as string,
    minPricePence: Number(r.min_price_pence || 0),
    sourceIncluded: Boolean(r.source_included),
  }));

  const cmsRow = db
    .prepare(`SELECT value_json FROM cms_blocks WHERE key = 'homepage'`)
    .get() as { value_json: string } | undefined;

  const cms: HomepageCms = cmsRow
    ? JSON.parse(cmsRow.value_json)
    : {
        heroHeadlineTop: 'BUILD SOMETHING',
        heroHeadlineAccent: 'BRILLIANT.',
        heroSubheading: 'Software, source code and the skills to make it yours.',
        workshopHeadline: 'FROM FIRST LINE TO FIRST APP',
        workshopSubheading:
          'Practical, hands-on coding workshops in-store and online, from complete beginners to full project builds.',
        featuredTitle: 'Your next great project starts here',
        demoNotice:
          'Demonstration catalogue: illustrative sample products, pricing, and original sample download archives.',
      };

  return <HomeShowcase products={products} cms={cms} />;
}
