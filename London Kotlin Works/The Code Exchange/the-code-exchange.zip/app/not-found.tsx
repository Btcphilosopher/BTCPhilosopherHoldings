import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="bg-[#f6f2ec] min-h-[60vh] flex items-center justify-center px-4 py-16">
      <div className="max-w-md w-full bg-white border border-[#e4ded4] rounded-lg p-8 text-center space-y-4">
        <h1 className="font-display font-extrabold text-2xl text-[#14161b]">Page not found</h1>
        <p className="text-sm text-[#4e535e]">
          The software listing, store, or order page you requested could not be found.
        </p>
        <div className="flex justify-center gap-3 pt-2">
          <Link
            href="/catalogue"
            className="px-5 py-2.5 rounded-md bg-[#d4006c] text-white text-sm font-semibold"
          >
            Browse software
          </Link>
          <Link
            href="/"
            className="px-5 py-2.5 rounded-md border border-[#d5cec3] text-sm font-semibold text-[#14161b]"
          >
            Home
          </Link>
        </div>
      </div>
    </div>
  );
}
