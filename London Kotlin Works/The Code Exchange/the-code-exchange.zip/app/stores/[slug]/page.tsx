import Link from 'next/link';
import Image from 'next/image';
import { MapPin, Clock, Phone, Store } from 'lucide-react';
import { getDb } from '@/src/server/db';
import { formatWorkshopTimeUK } from '@/src/server/commerce';
import { formatGBP } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function StoreDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const db = getDb();
  const s = db.prepare('SELECT * FROM stores WHERE slug = ?').get(slug) as
    | Record<string, unknown>
    | undefined;

  if (!s) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-16 space-y-3">
        <h1 className="font-display font-bold text-2xl">Store not found</h1>
        <Link href="/stores" className="text-[#c80064] font-semibold underline">
          Back to UK stores
        </Link>
      </div>
    );
  }

  const hours = JSON.parse((s.opening_hours_json as string) || '{}') as Record<string, string>;
  const stockRows = db
    .prepare(
      `SELECT sl.on_hand, sl.reserved, sl.updated_at,
              e.sku, e.name as edition_name, e.price_pence,
              p.title as product_title, p.slug as product_slug, p.image_url
       FROM stock_locations sl
       JOIN editions e ON e.id = sl.edition_id
       JOIN products p ON p.id = e.product_id
       WHERE sl.store_id = ?
       ORDER BY p.featured_order ASC`
    )
    .all(s.id as string) as Record<string, unknown>[];

  const workshops = db
    .prepare('SELECT * FROM workshops WHERE store_id = ? ORDER BY starts_at_utc ASC')
    .all(s.id as string) as Record<string, unknown>[];

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 space-y-8">
        <Link href="/stores" className="text-xs font-semibold text-[#c80064] hover:underline">
          ← All UK stores
        </Link>

        <div className="bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 space-y-4">
            <h1 className="font-display font-extrabold text-3xl text-[#14161b]">
              {s.name as string}
            </h1>
            <div className="space-y-2 text-sm text-[#4e535e]">
              <p className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
                <span>
                  {s.address_line as string}, {s.city as string} {s.postcode as string}
                </span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
                <span className="tabular-nums">{s.phone as string}</span>
              </p>
            </div>
            <div className="p-4 rounded-md bg-[#faf8f5] border border-[#e4ded4] space-y-1 text-sm">
              <p className="font-semibold text-[#14161b] flex items-center gap-2">
                <Store className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
                <span>Click &amp; Collect Instructions</span>
              </p>
              <p className="text-xs text-[#4e535e] leading-relaxed">
                {s.collection_instructions as string}
              </p>
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#faf8f5] border border-[#e4ded4] rounded-lg p-5 space-y-3">
            <h2 className="font-display font-bold text-base text-[#14161b] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
              <span>Opening Hours</span>
            </h2>
            <dl className="divide-y divide-[#e4ded4] text-sm">
              {Object.entries(hours).map(([d, t]) => (
                <div key={d} className="py-2 flex justify-between">
                  <dt className="text-[#4e535e]">{d}</dt>
                  <dd className="font-medium tabular-nums">{t}</dd>
                </div>
              ))}
            </dl>
            <p className="text-[11px] text-[#4e535e]">
              Availability freshness: verified {new Date(s.stock_updated_at as string).toLocaleString('en-GB')}
            </p>
          </div>
        </div>

        {/* Live Store Stock */}
        <section className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h2 className="font-display font-bold text-xl text-[#14161b]">
              In-Store Stock &amp; Click &amp; Collect Availability
            </h2>
            <span className="text-xs text-[#4e535e]">
              Live transactional inventory (reserved units excluded)
            </span>
          </div>

          <div className="divide-y divide-[#efe9df]">
            {stockRows.map((row) => {
              const available = Math.max(0, Number(row.on_hand) - Number(row.reserved));
              return (
                <div
                  key={row.sku as string}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="relative w-14 h-16 shrink-0 bg-[#faf8f5] rounded overflow-hidden">
                      <Image
                        src={row.image_url as string}
                        alt={row.product_title as string}
                        fill
                        sizes="56px"
                        className="object-contain p-1"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <Link
                        href={`/products/${row.product_slug as string}`}
                        className="font-display font-bold text-base text-[#14161b] hover:text-[#c80064]"
                      >
                        {row.product_title as string} — {row.edition_name as string}
                      </Link>
                      <p className="text-xs text-[#4e535e] font-mono">
                        SKU {row.sku as string} · Updated{' '}
                        {new Date(row.updated_at as string).toLocaleTimeString('en-GB')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-bold text-base tabular-nums">
                      {formatGBP(Number(row.price_pence))}
                    </span>
                    <span
                      className={`text-xs font-semibold tabular-nums ${
                        available > 0 ? 'text-[#14161b]' : 'text-[#9d004f]'
                      }`}
                    >
                      {available > 0 ? `${available} available` : 'Out of stock'}
                    </span>
                    <Link
                      href={`/products/${row.product_slug as string}`}
                      className="px-3.5 py-2 rounded-md bg-[#d4006c] text-white text-xs font-semibold whitespace-nowrap"
                    >
                      Reserve &amp; collect
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {workshops.length > 0 && (
          <section className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
            <h2 className="font-display font-bold text-xl text-[#14161b]">
              Upcoming Workshops at {s.city as string}
            </h2>
            <div className="divide-y divide-[#efe9df]">
              {workshops.map((w) => {
                const start = formatWorkshopTimeUK(
                  w.starts_at_utc as string,
                  w.display_timezone as string
                );
                return (
                  <div key={w.id as string} className="py-3 flex items-center justify-between gap-4">
                    <div>
                      <Link
                        href={`/workshops/${w.slug as string}`}
                        className="font-display font-bold text-base text-[#14161b] hover:text-[#c80064]"
                      >
                        {w.title as string}
                      </Link>
                      <p className="text-xs text-[#4e535e]">{start.fullLabel}</p>
                    </div>
                    <Link
                      href={`/workshops/${w.slug as string}`}
                      className="text-xs font-semibold text-[#c80064] hover:underline"
                    >
                      View workshop
                    </Link>
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
