import Link from 'next/link';
import { MapPin, Clock, Phone, ChevronRight } from 'lucide-react';
import { getDb } from '@/src/server/db';

export const dynamic = 'force-dynamic';

export default function StoresPage() {
  const db = getDb();
  const stores = db.prepare('SELECT * FROM stores ORDER BY name ASC').all() as Record<
    string,
    unknown
  >[];

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-8">
        <div className="border-b border-[#e4ded4] pb-5 space-y-2">
          <h1 className="font-display font-extrabold text-3xl sm:text-4xl text-[#14161b]">
            Our UK Stores &amp; Classrooms
          </h1>
          <p className="text-sm text-[#4e535e] max-w-2xl">
            Collect boxed download-key editions, USB collector drives, and starter kits in person, or attend an evening coding workshop in London, Manchester, or Edinburgh.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stores.map((s) => {
            const hours = JSON.parse((s.opening_hours_json as string) || '{}') as Record<
              string,
              string
            >;
            return (
              <Link
                key={s.id as string}
                href={`/stores/${s.slug as string}`}
                className="group bg-white border border-[#e4ded4] rounded-lg p-6 flex flex-col justify-between space-y-5 hover:-translate-y-0.5 hover:shadow-md transition-all"
              >
                <div className="space-y-3">
                  <h2 className="font-display font-bold text-xl text-[#14161b] group-hover:text-[#d4006c]">
                    {s.name as string}
                  </h2>
                  <div className="text-sm text-[#4e535e] space-y-2">
                    <p className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                      <span>
                        {s.address_line as string}, {s.city as string} {s.postcode as string}
                      </span>
                    </p>
                    <p className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-[#d4006c] shrink-0" aria-hidden="true" />
                      <span className="tabular-nums">{s.phone as string}</span>
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#efe9df] space-y-1 text-xs text-[#4e535e]">
                    <p className="font-semibold text-[#14161b] flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#d4006c]" aria-hidden="true" />
                      <span>Opening hours</span>
                    </p>
                    {Object.entries(hours).map(([day, time]) => (
                      <div key={day} className="flex justify-between">
                        <span>{day}</span>
                        <span className="tabular-nums">{time}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-[#efe9df] flex items-center justify-between text-xs">
                  <span className="text-[#4e535e]">
                    Stock updated {new Date(s.stock_updated_at as string).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <span className="inline-flex items-center gap-0.5 font-semibold text-[#c80064]">
                    <span>View store stock</span>
                    <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
