import Link from 'next/link';

const POLICIES: Record<
  string,
  { title: string; updated: string; sections: { heading: string; body: string }[] }
> = {
  delivery: {
    title: 'UK Delivery & Click & Collect Policy',
    updated: 'November 2026',
    sections: [
      {
        heading: 'Digital Downloads & Source Packages',
        body: 'Instant access is granted to your My Software Library immediately after our server receives a verified payment confirmation webhook. No shipping fee applies.',
      },
      {
        heading: 'UK Tracked Delivery',
        body: 'Physical boxed download-key editions, USB collector editions, and starter kits ship from our UK Central Warehouse via Royal Mail Tracked 48 for £4.95 (free on physical delivery orders of £100 or more).',
      },
      {
        heading: 'Click & Collect in Store',
        body: 'Free collection from our London (Clerkenwell), Manchester (Northern Quarter), or Edinburgh (New Town) stores. Reservations are held for 7 calendar days.',
      },
    ],
  },
  returns: {
    title: 'Returns, Refunds & Digital Cancellation Policy',
    updated: 'November 2026',
    sections: [
      {
        heading: 'Physical Boxed & USB Editions',
        body: 'Unopened physical editions may be returned within 30 days of delivery or store collection. In line with our activation reconciliation policy, refunding a physical edition also revokes any associated digital library activation key.',
      },
      {
        heading: 'Digital Content Waiver (UK Consumer Contracts Regulations 2013)',
        body: 'Under Regulation 37, by requesting immediate digital download access at checkout and acknowledging the statutory waiver, your 14-day cooling-off right ends once digital supply begins. Your statutory rights for faulty files under the Consumer Rights Act 2015 remain unaffected.',
      },
      {
        heading: 'Workshops',
        body: 'Workshop places may be cancelled for a full refund up to 48 hours before the scheduled start time (displayed in Europe/London GMT/BST), or transferred up to 24 hours prior.',
      },
    ],
  },
  privacy: {
    title: 'Privacy Notice (UK GDPR)',
    updated: 'November 2026',
    sections: [
      {
        heading: 'Data Minimisation & Payment Security',
        body: 'We collect only the details necessary to fulfil your order, issue software entitlements, and manage workshop attendance. Delivery addresses are requested only when physical shipping is selected. Raw payment card numbers are never stored by The Code Exchange.',
      },
      {
        heading: 'Download & Audit Records',
        body: 'Authorised download requests and staff administrative actions are logged with timestamps for security, licensing verification, and refund reconciliation.',
      },
    ],
  },
  terms: {
    title: 'Terms of Sale & Software Licensing',
    updated: 'November 2026',
    sections: [
      {
        heading: 'Pricing & UK VAT',
        body: 'All prices are quoted in Pounds Sterling (GBP) and include 20% UK VAT unless otherwise stated. VAT, discounts, and delivery are itemised prior to checkout.',
      },
      {
        heading: 'Source-Code Editions & Intellectual Property',
        body: 'Where an edition includes source code, you receive the exact rights specified in the versioned licence accepted at checkout (stored alongside your order). Purchasing source access does not transfer underlying intellectual property or authorise unrestricted redistribution.',
      },
      {
        heading: 'Demonstration Storefront Notice',
        body: 'This application operates with illustrative demonstration products, sample pricing, and original small demonstration code archives.',
      },
    ],
  },
};

export default async function PolicyPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const policy = POLICIES[slug] || POLICIES.terms;

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex flex-wrap gap-3 text-xs font-semibold">
          {Object.entries(POLICIES).map(([key, item]) => (
            <Link
              key={key}
              href={`/policies/${key}`}
              className={`px-3 py-1.5 rounded-md ${
                key === slug
                  ? 'bg-[#d4006c] text-white'
                  : 'bg-white border border-[#e4ded4] text-[#14161b]'
              }`}
            >
              {item.title.split(' ')[0]}
            </Link>
          ))}
        </div>

        <article className="bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 space-y-6">
          <div className="border-b border-[#efe9df] pb-4">
            <p className="text-xs text-[#4e535e]">Last updated: {policy.updated}</p>
            <h1 className="font-display font-extrabold text-3xl text-[#14161b] mt-1">
              {policy.title}
            </h1>
          </div>
          <div className="space-y-5">
            {policy.sections.map((sec) => (
              <section key={sec.heading} className="space-y-1.5">
                <h2 className="font-display font-bold text-lg text-[#14161b]">{sec.heading}</h2>
                <p className="text-sm text-[#4e535e] leading-relaxed">{sec.body}</p>
              </section>
            ))}
          </div>
        </article>
      </div>
    </div>
  );
}
