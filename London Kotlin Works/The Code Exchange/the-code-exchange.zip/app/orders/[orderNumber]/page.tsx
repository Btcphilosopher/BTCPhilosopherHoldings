'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { CheckCircle2, Clock, RefreshCw, AlertTriangle, Download } from 'lucide-react';
import { formatGBPPrecise, formatWorkshopUK } from '@/lib/format';

interface OrderDetailResponse {
  order: {
    id: string;
    orderNumber: string;
    customerEmail: string;
    customerName: string;
    status: string;
    subtotalNetPence: number;
    discountPence: number;
    vatPence: number;
    deliveryPence: number;
    totalPence: number;
    currency: string;
    shippingAddress: {
      line1: string;
      line2?: string;
      city: string;
      postcode: string;
      country: string;
    } | null;
    termsAcceptedAt: string;
    digitalWaiverAcceptedAt: string | null;
    acceptedLicences: { licence_id: string; code: string; version: string }[];
    createdAt: string;
  };
  items: {
    id: string;
    item_type: string;
    title: string;
    edition_name: string;
    sku: string;
    quantity: number;
    line_total_pence: number;
    fulfilment_method: string;
    fulfilment_status: string;
    store_name: string | null;
    store_address: string | null;
    store_postcode: string | null;
    collection_instructions: string | null;
    licence_id: string | null;
    licence_version: string | null;
    refunded_quantity: number;
    refunded_pence: number;
    starts_at_utc: string | null;
    display_timezone: string | null;
    venue_label: string | null;
  }[];
  paymentIntents: {
    id: string;
    provider: string;
    provider_ref: string;
    amount_pence: number;
    status: string;
    webhook_event_ids_json: string;
  }[];
  jobs: {
    id: string;
    job_type: string;
    status: string;
    attempts: number;
    last_error: string | null;
  }[];
  refunds: {
    id: string;
    amount_pence: number;
    reason: string;
    status: string;
    created_at: string;
  }[];
}

export default function OrderStatusPage() {
  const params = useParams<{ orderNumber: string }>();
  const [data, setData] = useState<OrderDetailResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [retrying, setRetrying] = useState(false);

  const loadOrder = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(params.orderNumber)}`, {
        cache: 'no-store',
      });
      if (res.ok) {
        setData(await res.json());
      }
    } finally {
      setLoading(false);
    }
  }, [params.orderNumber]);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/orders/${encodeURIComponent(params.orderNumber)}`, { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((json) => {
        if (!cancelled && json) setData(json);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [params.orderNumber]);

  const handleRetryFulfilment = async () => {
    setRetrying(true);
    try {
      await fetch(`/api/orders/${encodeURIComponent(params.orderNumber)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({ action: 'retry_fulfilment' }),
      });
      await loadOrder();
    } finally {
      setRetrying(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-[1100px] mx-auto px-6 py-16 text-sm text-[#4e535e]">
        Loading order status...
      </div>
    );
  }

  if (!data) {
    return (
      <div className="max-w-[1100px] mx-auto px-6 py-16 space-y-3">
        <h1 className="font-display font-bold text-2xl">Order not found</h1>
        <Link href="/account" className="text-[#c80064] font-semibold underline">
          View your account
        </Link>
      </div>
    );
  }

  const { order, items, paymentIntents, jobs, refunds } = data;
  const hasFailedJob = jobs.some((j) => j.status === 'failed_retryable');

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 space-y-8">
        <div className="bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm font-semibold text-[#c80064]">
              {hasFailedJob ? (
                <AlertTriangle className="w-4 h-4" aria-hidden="true" />
              ) : (
                <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
              )}
              <span className="uppercase tracking-wider text-xs">
                Order status: {order.status.replace(/_/g, ' ')}
              </span>
            </div>
            <h1 className="font-display font-extrabold text-3xl text-[#14161b] tabular-nums">
              Order {order.orderNumber}
            </h1>
            <p className="text-sm text-[#4e535e]">
              Placed on {new Date(order.createdAt).toLocaleString('en-GB')} for {order.customerName} ({order.customerEmail})
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Link
              href="/library"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold"
            >
              <Download className="w-4 h-4" aria-hidden="true" />
              <span>My software &amp; downloads</span>
            </Link>
          </div>
        </div>

        {hasFailedJob && (
          <div className="bg-[#fef2f6] border border-[#d4006c]/30 rounded-lg p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="font-display font-bold text-base text-[#14161b]">
                Fulfilment worker encountered a transient error
              </p>
              <p className="text-xs text-[#4e535e]">
                {jobs.find((j) => j.status === 'failed_retryable')?.last_error}
              </p>
            </div>
            <button
              type="button"
              disabled={retrying}
              onClick={() => void handleRetryFulfilment()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#111318] text-white text-xs font-semibold cursor-pointer shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{retrying ? 'Retrying...' : 'Retry fulfilment job'}</span>
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 space-y-4">
            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
              <h2 className="font-display font-bold text-xl text-[#14161b]">
                Itemised Fulfilment Breakdown
              </h2>
              <div className="divide-y divide-[#efe9df]">
                {items.map((item) => (
                  <div key={item.id} className="py-4 space-y-2">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-display font-bold text-base text-[#14161b]">
                          {item.title} × {item.quantity}
                        </h3>
                        <p className="text-xs text-[#4e535e]">
                          {item.edition_name} · <span className="font-mono">{item.sku}</span>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-base tabular-nums">
                          {formatGBPPrecise(item.line_total_pence)}
                        </p>
                        <p className="text-xs font-semibold text-[#c80064] capitalize">
                          {item.fulfilment_status.replace(/_/g, ' ')}
                        </p>
                      </div>
                    </div>

                    {item.fulfilment_method === 'collect' && item.store_name && (
                      <div className="p-3 rounded bg-[#faf8f5] border border-[#e4ded4] text-xs text-[#4e535e] space-y-1">
                        <p className="font-semibold text-[#14161b]">
                          Click &amp; Collect at {item.store_name} ({item.store_postcode})
                        </p>
                        <p>{item.collection_instructions}</p>
                      </div>
                    )}

                    {item.item_type === 'workshop' && item.starts_at_utc && (
                      <div className="text-xs text-[#4e535e] flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#d4006c]" aria-hidden="true" />
                        <span>
                          {item.venue_label} ·{' '}
                          {formatWorkshopUK(item.starts_at_utc, item.display_timezone || 'Europe/London')}
                        </span>
                      </div>
                    )}

                    {item.refunded_pence > 0 && (
                      <p className="text-xs font-semibold text-[#9d004f]">
                        Refunded: {formatGBPPrecise(item.refunded_pence)} ({item.refunded_quantity} unit)
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {refunds.length > 0 && (
              <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-3">
                <h2 className="font-display font-bold text-lg text-[#14161b]">Refunds Issued</h2>
                {refunds.map((rf) => (
                  <div key={rf.id} className="flex justify-between text-sm border-t border-[#efe9df] pt-2">
                    <span className="text-[#4e535e]">{rf.reason}</span>
                    <span className="font-semibold tabular-nums">
                      -{formatGBPPrecise(rf.amount_pence)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Receipt & Payment Ledger */}
          <aside className="lg:col-span-4 space-y-4">
            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
              <h2 className="font-display font-bold text-lg text-[#14161b]">UK VAT Receipt</h2>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-[#4e535e]">Net (ex. VAT)</dt>
                  <dd className="tabular-nums">{formatGBPPrecise(order.subtotalNetPence)}</dd>
                </div>
                {order.discountPence > 0 && (
                  <div className="flex justify-between text-[#c80064]">
                    <dt>Discount</dt>
                    <dd className="tabular-nums">-{formatGBPPrecise(order.discountPence)}</dd>
                  </div>
                )}
                <div className="flex justify-between">
                  <dt className="text-[#4e535e]">VAT (20%)</dt>
                  <dd className="tabular-nums">{formatGBPPrecise(order.vatPence)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[#4e535e]">Delivery</dt>
                  <dd className="tabular-nums">
                    {order.deliveryPence === 0 ? 'Free' : formatGBPPrecise(order.deliveryPence)}
                  </dd>
                </div>
                <div className="flex justify-between border-t border-[#e4ded4] pt-2.5 font-display font-extrabold text-base">
                  <dt>Total paid</dt>
                  <dd className="tabular-nums">{formatGBPPrecise(order.totalPence)}</dd>
                </div>
              </dl>

              {order.shippingAddress && (
                <div className="border-t border-[#efe9df] pt-3 text-xs text-[#4e535e] space-y-0.5">
                  <p className="font-semibold text-[#14161b]">Delivery address</p>
                  <p>{order.shippingAddress.line1}</p>
                  <p>
                    {order.shippingAddress.city}, {order.shippingAddress.postcode}
                  </p>
                </div>
              )}

              {order.acceptedLicences.length > 0 && (
                <div className="border-t border-[#efe9df] pt-3 text-xs text-[#4e535e] space-y-1">
                  <p className="font-semibold text-[#14161b]">Accepted Licences</p>
                  {order.acceptedLicences.map((lic, i) => (
                    <div key={`${lic.licence_id}-${i}`}>
                      <Link href={`/licences/${lic.licence_id}`} className="text-[#c80064] hover:underline">
                        {lic.code} v{lic.version}
                      </Link>
                    </div>
                  ))}
                </div>
              )}

              {paymentIntents.map((pi) => (
                <div key={pi.id} className="border-t border-[#efe9df] pt-3 text-xs text-[#4e535e] space-y-1">
                  <p className="font-semibold text-[#14161b]">Payment Record</p>
                  <p>Status: {pi.status} ({pi.provider})</p>
                  <p className="font-mono text-[11px] break-all">Ref: {pi.provider_ref}</p>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
