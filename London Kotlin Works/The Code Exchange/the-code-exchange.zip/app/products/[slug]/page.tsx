'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useParams, useRouter } from 'next/navigation';
import {
  Check,
  ChevronRight,
  Download,
  Package,
  Usb,
  Code2,
  ShieldCheck,
  Store,
  Truck,
  AlertCircle,
} from 'lucide-react';
import { useStore } from '@/components/StoreProvider';
import { formatGBP, formatGBPPrecise } from '@/lib/format';

interface StockLoc {
  id: string;
  store_id: string | null;
  location_name: string;
  store_slug: string | null;
  available: number;
  updated_at: string;
}

interface EditionDetail {
  id: string;
  sku: string;
  name: string;
  editionType: string;
  deliveryMethod: string;
  pricePence: number;
  includes: string[];
  physicalContentsNote: string;
  requiresShipping: boolean;
  licence: {
    id: string;
    code: string;
    title: string;
    version: string;
    summary: string;
    redistributableSource: boolean;
    commercialUse: boolean;
    seatLimit: number;
  };
  stockLocations: StockLoc[];
}

interface ProductDetailPayload {
  product: {
    id: string;
    slug: string;
    skuPrefix: string;
    title: string;
    subtitle: string;
    description: string;
    category: string;
    publisher: string;
    platforms: string[];
    languages: string[];
    requirements: Record<string, string>;
    releaseVersion: string;
    sourceIncluded: boolean;
    updateEntitlement: string;
    thirdPartyNotices: string;
    documentationMarkdown: string;
    imageUrl: string;
    screenshots: string[];
    isDemoListing: boolean;
  };
  editions: EditionDetail[];
  artefacts: {
    id: string;
    version: string;
    filename: string;
    platform: string;
    size_bytes: number;
    sha256: string;
    release_notes: string;
  }[];
  relatedProducts: {
    id: string;
    slug: string;
    title: string;
    subtitle: string;
    category: string;
    imageUrl: string;
    minPricePence: number;
  }[];
}

export default function ProductDetailPage() {
  const params = useParams<{ slug: string }>();
  const router = useRouter();
  const { addEditionToBasket } = useStore();

  const [data, setData] = useState<ProductDetailPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedEditionId, setSelectedEditionId] = useState<string>('');
  const [activeImage, setActiveImage] = useState<string>('');
  const [fulfilmentChoice, setFulfilmentChoice] = useState<'delivery' | 'collect'>('delivery');
  const [selectedStoreId, setSelectedStoreId] = useState<string>('store-london');
  const [quantity, setQuantity] = useState(1);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/catalogue/${encodeURIComponent(params.slug)}`, { cache: 'no-store' })
      .then(async (res) => {
        if (!res.ok) throw new Error('Product not found');
        return (await res.json()) as ProductDetailPayload;
      })
      .then((payload) => {
        if (cancelled) return;
        setData(payload);
        if (payload.editions.length > 0) {
          setSelectedEditionId(payload.editions[0].id);
        }
        setActiveImage(payload.product.imageUrl);
      })
      .catch((e) => {
        if (!cancelled) setError((e as Error).message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [params.slug]);

  if (loading) {
    return (
      <div className="max-w-[1280px] mx-auto px-6 py-16 text-sm text-[#4e535e]">
        Loading product specification...
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-[1280px] mx-auto px-6 py-16 space-y-4">
        <h1 className="font-display font-bold text-2xl">Product not found</h1>
        <Link href="/catalogue" className="text-[#c80064] font-semibold underline">
          Return to catalogue
        </Link>
      </div>
    );
  }

  const { product, editions, artefacts, relatedProducts } = data;
  const selectedEdition = editions.find((e) => e.id === selectedEditionId) || editions[0];

  const warehouseStock = selectedEdition.stockLocations.find((s) => s.store_id === null);
  const storeStocks = selectedEdition.stockLocations.filter((s) => s.store_id !== null);
  const activeStoreStock = storeStocks.find((s) => s.store_id === selectedStoreId) || storeStocks[0];

  const availableAtSelection = !selectedEdition.requiresShipping
    ? 999
    : fulfilmentChoice === 'delivery'
      ? warehouseStock?.available || 0
      : activeStoreStock?.available || 0;

  const editionIcon = (type: string) => {
    if (type === 'usb_edition') return <Usb className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />;
    if (type === 'boxed_key' || type === 'starter_kit')
      return <Package className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />;
    if (type === 'source_package')
      return <Code2 className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />;
    return <Download className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />;
  };

  const handleAdd = async () => {
    setSubmitting(true);
    try {
      const ok = await addEditionToBasket(
        selectedEdition.id,
        quantity,
        selectedEdition.requiresShipping ? fulfilmentChoice : 'digital',
        selectedEdition.requiresShipping && fulfilmentChoice === 'collect'
          ? activeStoreStock?.store_id || selectedStoreId
          : null
      );
      if (ok) {
        router.push('/basket');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-[#f6f2ec] py-8 sm:py-10">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-12">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-[#4e535e]">
          <Link href="/" className="hover:text-[#14161b]">Home</Link>
          <span aria-hidden="true">/</span>
          <Link href="/catalogue" className="hover:text-[#14161b]">Catalogue</Link>
          <span aria-hidden="true">/</span>
          <span className="text-[#14161b] font-medium">{product.title}</span>
        </nav>

        {/* Main Split Module */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Gallery */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white border border-[#e4ded4] rounded-lg p-6 flex items-center justify-center relative aspect-[4/3]">
              <Image
                src={
                  selectedEdition.editionType === 'usb_edition' &&
                  product.screenshots.includes('/images/usb-aureom.png')
                    ? '/images/usb-aureom.png'
                    : activeImage || product.imageUrl
                }
                alt={`${product.title} — ${selectedEdition.name}`}
                fill
                sizes="(min-width: 1024px) 40vw, 100vw"
                className="object-contain p-6"
                referrerPolicy="no-referrer"
              />
            </div>

            {product.screenshots.length > 1 && (
              <div className="flex items-center gap-3">
                {product.screenshots.map((shot) => (
                  <button
                    key={shot}
                    type="button"
                    onClick={() => setActiveImage(shot)}
                    className={`relative w-24 h-16 rounded-md border bg-white overflow-hidden cursor-pointer ${
                      activeImage === shot ? 'border-[#d4006c] ring-2 ring-[#d4006c]/25' : 'border-[#e4ded4]'
                    }`}
                  >
                    <Image
                      src={shot}
                      alt={`${product.title} view`}
                      fill
                      sizes="96px"
                      className="object-contain p-1.5"
                      referrerPolicy="no-referrer"
                    />
                  </button>
                ))}
              </div>
            )}

            <div className="bg-white border border-[#e4ded4] rounded-lg p-5 space-y-2 text-xs text-[#4e535e]">
              <p className="font-semibold text-[#14161b]">Illustrative Demonstration Catalogue Entry</p>
              <p className="leading-relaxed">
                This listing demonstrates full retail packaging, licensing, physical inventory, and digital fulfilment. Downloadable files contain original sample code and documentation rather than full commercial binaries.
              </p>
            </div>
          </div>

          {/* Right Contiguous Purchase Module */}
          <div className="lg:col-span-7 bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 space-y-6">
            <div className="space-y-2 border-b border-[#efe9df] pb-5">
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#4e535e]">
                <span>{product.category}</span>
                <span aria-hidden="true">·</span>
                <span>{product.publisher}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">SKU {selectedEdition.sku}</span>
                <span aria-hidden="true">·</span>
                <span>v{product.releaseVersion}</span>
              </div>
              <h1 className="font-display font-extrabold text-3xl sm:text-4xl text-[#14161b] tracking-tight">
                {product.title}
              </h1>
              <p className="text-base text-[#4e535e] leading-relaxed">{product.description}</p>
            </div>

            {/* Edition Selector */}
            <div className="space-y-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-[#4e535e]">
                Select Edition
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {editions.map((ed) => {
                  const active = ed.id === selectedEdition.id;
                  return (
                    <button
                      key={ed.id}
                      type="button"
                      onClick={() => setSelectedEditionId(ed.id)}
                      className={`text-left p-4 rounded-lg border transition-all cursor-pointer ${
                        active
                          ? 'border-[#d4006c] bg-[#fdf5f9] ring-1 ring-[#d4006c]'
                          : 'border-[#e4ded4] bg-white hover:border-[#b9b0a2]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-2 font-display font-bold text-sm text-[#14161b]">
                          {editionIcon(ed.editionType)}
                          <span>{ed.name}</span>
                        </span>
                        <span className="font-display font-extrabold text-base text-[#14161b] tabular-nums">
                          {formatGBP(ed.pricePence)}
                        </span>
                      </div>
                      <p className="text-xs text-[#4e535e] mt-1.5">{ed.deliveryMethod}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Explicit Contents & Physical vs Digital distinction */}
            <div className="bg-[#faf8f5] border border-[#e4ded4] rounded-lg p-4 space-y-3">
              <div className="flex items-start gap-2.5 text-sm text-[#14161b]">
                <AlertCircle className="w-4 h-4 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <p className="font-semibold">What is in this edition</p>
                  <p className="text-xs text-[#4e535e] mt-0.5">
                    {selectedEdition.physicalContentsNote}
                  </p>
                </div>
              </div>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#14161b]">
                {selectedEdition.includes.map((inc) => (
                  <li key={inc} className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-[#d4006c] mt-0.5 shrink-0" aria-hidden="true" />
                    <span>{inc}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Physical Delivery vs Click & Collect Selector */}
            {selectedEdition.requiresShipping && (
              <div className="space-y-3 border-t border-[#efe9df] pt-5">
                <h2 className="text-xs font-bold uppercase tracking-wider text-[#4e535e]">
                  Delivery or Store Collection
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFulfilmentChoice('delivery')}
                    className={`p-3.5 rounded-lg border text-left cursor-pointer ${
                      fulfilmentChoice === 'delivery'
                        ? 'border-[#d4006c] bg-[#fdf5f9]'
                        : 'border-[#e4ded4]'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-semibold text-sm">
                      <Truck className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
                      <span>UK Tracked Delivery</span>
                    </div>
                    <p className="text-xs text-[#4e535e] mt-1 tabular-nums">
                      Central warehouse stock: {warehouseStock?.available ?? 0} available (£4.95, free over £100)
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFulfilmentChoice('collect')}
                    className={`p-3.5 rounded-lg border text-left cursor-pointer ${
                      fulfilmentChoice === 'collect'
                        ? 'border-[#d4006c] bg-[#fdf5f9]'
                        : 'border-[#e4ded4]'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-semibold text-sm">
                      <Store className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
                      <span>Click &amp; Collect (Free)</span>
                    </div>
                    <p className="text-xs text-[#4e535e] mt-1">
                      Reserve store stock for collection in London, Manchester, or Edinburgh
                    </p>
                  </button>
                </div>

                {fulfilmentChoice === 'collect' && storeStocks.length > 0 && (
                  <div className="space-y-2">
                    <label htmlFor="store-pick" className="block text-xs font-semibold text-[#4e535e]">
                      Choose collection store (live stock)
                    </label>
                    <select
                      id="store-pick"
                      value={selectedStoreId}
                      onChange={(e) => setSelectedStoreId(e.target.value)}
                      className="w-full h-10 px-3 rounded-md border border-[#d5cec3] bg-white text-sm"
                    >
                      {storeStocks.map((st) => (
                        <option key={st.id} value={st.store_id || ''}>
                          {st.location_name} — {st.available} in stock
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}

            {/* Licence Preview */}
            <div className="border-t border-[#efe9df] pt-5 space-y-2">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#14161b]">
                  <ShieldCheck className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
                  <span>
                    Licence: {selectedEdition.licence.code} (v{selectedEdition.licence.version})
                  </span>
                </div>
                <Link
                  href={`/licences/${selectedEdition.licence.id}`}
                  className="text-xs font-semibold text-[#c80064] hover:underline whitespace-nowrap"
                >
                  Read full licence
                </Link>
              </div>
              <p className="text-xs text-[#4e535e] leading-relaxed">
                {selectedEdition.licence.summary}
                {selectedEdition.editionType === 'source_package' &&
                  ' Purchasing source access does not transfer IP ownership or allow unrestricted redistribution.'}
              </p>
            </div>

            {/* Price & Add to Basket */}
            <div className="border-t border-[#efe9df] pt-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="font-display font-extrabold text-3xl text-[#14161b] tabular-nums">
                  {formatGBPPrecise(selectedEdition.pricePence)}
                </p>
                <p className="text-xs text-[#4e535e]">
                  Inc. 20% UK VAT · {product.updateEntitlement}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <label htmlFor="pdp-qty" className="sr-only">
                  Quantity
                </label>
                <select
                  id="pdp-qty"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="h-12 px-3 rounded-md border border-[#d5cec3] bg-white text-sm font-semibold tabular-nums"
                >
                  {[1, 2, 3, 4, 5].map((n) => (
                    <option key={n} value={n}>
                      Qty {n}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  disabled={submitting || availableAtSelection < quantity}
                  onClick={handleAdd}
                  className="h-12 px-6 rounded-md bg-[#d4006c] hover:bg-[#b8005d] disabled:bg-[#b9b0a2] text-white font-semibold text-sm transition-colors whitespace-nowrap cursor-pointer disabled:cursor-not-allowed"
                >
                  {availableAtSelection < quantity
                    ? 'Out of stock at location'
                    : submitting
                      ? 'Adding...'
                      : 'Add to basket'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Specifications, Files & Documentation */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-6 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
            <h2 className="font-display font-bold text-xl text-[#14161b]">
              System Requirements &amp; Supported Platforms
            </h2>
            <p className="text-sm text-[#4e535e]">
              Platforms: <strong className="text-[#14161b]">{product.platforms.join(', ')}</strong> · Languages:{' '}
              <strong className="text-[#14161b]">{product.languages.join(', ')}</strong>
            </p>
            <dl className="divide-y divide-[#efe9df] text-sm">
              {Object.entries(product.requirements).map(([k, v]) => (
                <div key={k} className="py-2.5 flex justify-between gap-4">
                  <dt className="font-medium text-[#4e535e]">{k}</dt>
                  <dd className="text-right text-[#14161b]">{v}</dd>
                </div>
              ))}
            </dl>
            <div className="pt-2 border-t border-[#efe9df] text-xs text-[#4e535e] space-y-1">
              <p className="font-semibold text-[#14161b]">Third-party dependencies &amp; notices</p>
              <p>{product.thirdPartyNotices}</p>
            </div>
          </div>

          <div className="lg:col-span-6 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
            <h2 className="font-display font-bold text-xl text-[#14161b]">
              Published Release Artefacts &amp; Checksums
            </h2>
            <p className="text-xs text-[#4e535e]">
              Available immediately in My Software Library after confirmed payment. Technical download controls cannot prevent copying once a file is obtained.
            </p>
            <div className="space-y-3">
              {artefacts.map((art) => (
                <div key={art.id} className="p-3.5 rounded-md border border-[#e4ded4] bg-[#faf8f5] space-y-1">
                  <div className="flex items-center justify-between gap-2 text-sm font-semibold text-[#14161b]">
                    <span className="font-mono text-xs">{art.filename}</span>
                    <span className="tabular-nums text-xs text-[#4e535e]">
                      {(art.size_bytes / 1024).toFixed(1)} KB
                    </span>
                  </div>
                  <p className="text-xs text-[#4e535e]">{art.platform} · v{art.version}</p>
                  <p className="font-mono text-[11px] text-[#4e535e] break-all">
                    SHA-256: {art.sha256}
                  </p>
                </div>
              ))}
            </div>
            <div className="pt-2 border-t border-[#efe9df]">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#4e535e] mb-2">
                Documentation Preview
              </h3>
              <pre className="text-xs font-mono bg-[#111318] text-white/90 p-4 rounded-md overflow-x-auto whitespace-pre-wrap">
                {product.documentationMarkdown}
              </pre>
            </div>
          </div>
        </div>

        {/* Related Catalogue Items */}
        {relatedProducts.length > 0 && (
          <section className="space-y-4 pt-4">
            <h2 className="font-display font-bold text-2xl text-[#14161b]">
              Compatible &amp; Related Catalogue Titles
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {relatedProducts.map((rp) => (
                <Link
                  key={rp.id}
                  href={`/products/${rp.slug}`}
                  className="bg-white border border-[#e4ded4] rounded-lg p-4 flex items-center gap-4 hover:shadow-md transition-shadow"
                >
                  <div className="relative w-20 h-24 shrink-0 bg-[#faf8f5] rounded overflow-hidden">
                    <Image
                      src={rp.imageUrl}
                      alt={rp.title}
                      fill
                      sizes="80px"
                      className="object-contain p-1"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-[#4e535e]">{rp.category}</p>
                    <h3 className="font-display font-bold text-base text-[#14161b]">{rp.title}</h3>
                    <p className="text-xs text-[#4e535e] line-clamp-2 mt-1">{rp.subtitle}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="font-bold text-sm tabular-nums">From {formatGBP(rp.minPricePence)}</span>
                      <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-[#c80064]">
                        View <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
