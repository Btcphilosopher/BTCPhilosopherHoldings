'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ShieldCheck, Lock, AlertTriangle, CheckCircle2, XCircle, RefreshCw } from 'lucide-react';
import { useStore } from '@/components/StoreProvider';
import { formatGBPPrecise } from '@/lib/format';

export default function CheckoutPage() {
  const router = useRouter();
  const { user, basket, refreshBasket } = useStore();

  const [customerNameInput, setCustomerNameInput] = useState<string | null>(null);
  const [customerEmailInput, setCustomerEmailInput] = useState<string | null>(null);
  const [line1, setLine1] = useState('');
  const [line2, setLine2] = useState('');
  const [city, setCity] = useState('London');
  const [postcode, setPostcode] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [digitalWaiverAccepted, setDigitalWaiverAccepted] = useState(false);
  const [simulateFailOnce, setSimulateFailOnce] = useState(false);

  const customerName = customerNameInput ?? user?.name ?? '';
  const customerEmail = customerEmailInput ?? user?.email ?? '';

  const [idempotencyKey] = useState(() =>
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? `chk-${crypto.randomUUID()}`
      : `chk-${Date.now()}`
  );

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Payment Simulator State after Order/PaymentIntent creation
  const [createdOrder, setCreatedOrder] = useState<{
    orderNumber: string;
    orderId: string;
    totalPence: number;
    paymentIntentId: string;
    paymentStatus: string;
    idempotentReplay: boolean;
  } | null>(null);
  const [lastWebhookEventId, setLastWebhookEventId] = useState<string | null>(null);
  const [simMessage, setSimMessage] = useState<string | null>(null);
  const [simRunning, setSimRunning] = useState(false);

  useEffect(() => {
    void refreshBasket();
  }, [refreshBasket]);

  const items = basket?.items || [];
  const totals = basket?.totals;

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({
          customerName,
          customerEmail,
          shippingAddress: totals?.requiresShippingAddress
            ? { line1, line2, city, postcode, country: 'United Kingdom' }
            : null,
          termsAccepted,
          digitalWaiverAccepted,
          idempotencyKey,
          provider: 'simulated',
          simulateFulfilmentFailOnce: simulateFailOnce,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Checkout validation failed.');
        return;
      }
      setCreatedOrder(data);
    } finally {
      setSubmitting(false);
    }
  };

  const runPaymentOutcome = async (
    outcome: 'succeeded' | 'cancelled' | 'failed',
    replayLastEvent = false
  ) => {
    if (!createdOrder) return;
    setSimRunning(true);
    setSimMessage(null);
    try {
      const res = await fetch('/api/payments/simulate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({
          paymentIntentId: createdOrder.paymentIntentId,
          outcome,
          eventId: replayLastEvent && lastWebhookEventId ? lastWebhookEventId : undefined,
          simulateFulfilmentFailOnce: simulateFailOnce,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setSimMessage(data.error || 'Simulation error.');
        return;
      }
      setLastWebhookEventId(data.eventId);
      await refreshBasket();

      if (data.duplicate) {
        setSimMessage(
          `Duplicate webhook ${data.eventId} safely ignored (idempotent). Order ${data.orderNumber} remains ${data.orderStatus}.`
        );
      } else if (outcome === 'succeeded') {
        router.push(`/orders/${encodeURIComponent(data.orderNumber)}`);
      } else {
        setSimMessage(
          `Payment ${data.paymentStatus}. Physical stock reservations were released cleanly.`
        );
      }
    } finally {
      setSimRunning(false);
    }
  };

  if (!createdOrder && items.length === 0) {
    return (
      <div className="bg-[#f6f2ec] min-h-screen py-16">
        <div className="max-w-xl mx-auto px-4 bg-white border border-[#e4ded4] rounded-lg p-8 text-center space-y-4">
          <h1 className="font-display font-bold text-2xl">Nothing to check out yet</h1>
          <p className="text-sm text-[#4e535e]">
            Your basket is empty or a workshop hold has expired.
          </p>
          <Link
            href="/catalogue"
            className="inline-block px-5 py-2.5 rounded-md bg-[#d4006c] text-white text-sm font-semibold"
          >
            Browse catalogue
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#f6f2ec] min-h-screen py-10">
      <div className="max-w-[1160px] mx-auto px-4 sm:px-6 space-y-8">
        <div className="border-b border-[#e4ded4] pb-4 flex items-center justify-between">
          <div>
            <h1 className="font-display font-extrabold text-3xl text-[#14161b]">Checkout</h1>
            <p className="text-sm text-[#4e535e] mt-1">
              Server-validated UK VAT pricing, licence version capture, and verified webhook fulfilment.
            </p>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-xs text-[#4e535e]">
            <Lock className="w-4 h-4 text-[#d4006c]" aria-hidden="true" />
            <span>No raw card data stored on storefront</span>
          </div>
        </div>

        {createdOrder ? (
          /* Payment Simulator Panel */
          <div className="max-w-2xl mx-auto bg-white border border-[#e4ded4] rounded-lg p-6 sm:p-8 space-y-6">
            <div className="space-y-2 border-b border-[#efe9df] pb-4">
              <p className="text-xs font-semibold text-[#c80064]">
                Order {createdOrder.orderNumber} reserved · Awaiting Payment Confirmation
              </p>
              <h2 className="font-display font-extrabold text-2xl text-[#14161b]">
                Payment Provider Simulator ({formatGBPPrecise(createdOrder.totalPence)})
              </h2>
              <p className="text-sm text-[#4e535e]">
                PaymentIntent <span className="font-mono text-xs">{createdOrder.paymentIntentId}</span>.
                Digital entitlements and bookings are granted strictly by verified payment webhooks, never by browser redirects.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                disabled={simRunning}
                onClick={() => void runPaymentOutcome('succeeded')}
                className="h-12 px-4 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                <span>Authorise &amp; Pay {formatGBPPrecise(createdOrder.totalPence)}</span>
              </button>

              <button
                type="button"
                disabled={simRunning}
                onClick={() => void runPaymentOutcome('cancelled')}
                className="h-12 px-4 rounded-md border border-[#d5cec3] hover:bg-[#faf8f5] text-[#14161b] text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                <XCircle className="w-4 h-4" aria-hidden="true" />
                <span>Cancel payment (release holds)</span>
              </button>

              <button
                type="button"
                disabled={simRunning}
                onClick={() => void runPaymentOutcome('failed')}
                className="h-11 px-4 rounded-md border border-[#d5cec3] hover:bg-[#faf8f5] text-xs font-semibold text-[#4e535e] cursor-pointer"
              >
                Simulate card decline / failure
              </button>

              {lastWebhookEventId && (
                <button
                  type="button"
                  disabled={simRunning}
                  onClick={() => void runPaymentOutcome('succeeded', true)}
                  className="h-11 px-4 rounded-md border border-[#d5cec3] hover:bg-[#faf8f5] text-xs font-semibold text-[#4e535e] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Replay duplicate webhook</span>
                </button>
              )}
            </div>

            {simMessage && (
              <div className="p-4 rounded-md bg-[#faf8f5] border border-[#e4ded4] text-sm text-[#14161b]">
                {simMessage}
              </div>
            )}

            <div className="pt-2 border-t border-[#efe9df] flex items-center justify-between text-xs text-[#4e535e]">
              <span>Provider mode: Simulated UK Adapter (Stripe-compatible contract)</span>
              <Link
                href={`/orders/${encodeURIComponent(createdOrder.orderNumber)}`}
                className="font-semibold text-[#c80064] hover:underline"
              >
                View order status
              </Link>
            </div>
          </div>
        ) : (
          <form onSubmit={handleCreateOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 space-y-6">
              {/* Customer Details */}
              <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
                <h2 className="font-display font-bold text-lg text-[#14161b]">1. Customer Details</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="chk-name" className="block text-xs font-semibold text-[#4e535e] mb-1">
                      Full name
                    </label>
                    <input
                      id="chk-name"
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerNameInput(e.target.value)}
                      placeholder="Oliver Bennett"
                      className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                    />
                  </div>
                  <div>
                    <label htmlFor="chk-email" className="block text-xs font-semibold text-[#4e535e] mb-1">
                      Email address (for receipts &amp; library access)
                    </label>
                    <input
                      id="chk-email"
                      type="email"
                      required
                      value={customerEmail}
                      onChange={(e) => setCustomerEmailInput(e.target.value)}
                      placeholder="oliver@example.co.uk"
                      className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Conditional Shipping Details */}
              {totals?.requiresShippingAddress && (
                <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
                  <h2 className="font-display font-bold text-lg text-[#14161b]">
                    2. UK Delivery Address
                  </h2>
                  <p className="text-xs text-[#4e535e]">
                    Collected only because your basket includes physical delivery items.
                  </p>
                  <div className="space-y-3">
                    <div>
                      <label htmlFor="ship-l1" className="block text-xs font-semibold text-[#4e535e] mb-1">
                        Address line 1
                      </label>
                      <input
                        id="ship-l1"
                        type="text"
                        required
                        value={line1}
                        onChange={(e) => setLine1(e.target.value)}
                        placeholder="14 Redchurch Street"
                        className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                      />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label htmlFor="ship-l2" className="block text-xs font-semibold text-[#4e535e] mb-1">
                          Line 2 (optional)
                        </label>
                        <input
                          id="ship-l2"
                          type="text"
                          value={line2}
                          onChange={(e) => setLine2(e.target.value)}
                          className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                        />
                      </div>
                      <div>
                        <label htmlFor="ship-city" className="block text-xs font-semibold text-[#4e535e] mb-1">
                          Town / City
                        </label>
                        <input
                          id="ship-city"
                          type="text"
                          required
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm"
                        />
                      </div>
                      <div>
                        <label htmlFor="ship-pc" className="block text-xs font-semibold text-[#4e535e] mb-1">
                          UK Postcode
                        </label>
                        <input
                          id="ship-pc"
                          type="text"
                          required
                          value={postcode}
                          onChange={(e) => setPostcode(e.target.value)}
                          placeholder="E2 7DP"
                          className="w-full h-11 px-3 rounded-md border border-[#d5cec3] text-sm uppercase"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Legal & UK Consumer Contracts Compliance */}
              <div className="bg-white border border-[#e4ded4] rounded-lg p-6 space-y-4">
                <h2 className="font-display font-bold text-lg text-[#14161b] flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#d4006c]" aria-hidden="true" />
                  <span>Licences &amp; UK Statutory Acknowledgements</span>
                </h2>

                <div className="space-y-3 text-sm">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={termsAccepted}
                      onChange={(e) => setTermsAccepted(e.target.checked)}
                      className="mt-1 w-4 h-4 accent-[#d4006c]"
                    />
                    <span className="text-[#14161b] leading-relaxed">
                      I accept The Code Exchange{' '}
                      <Link href="/policies/terms" className="text-[#c80064] underline">
                        Terms of Sale
                      </Link>{' '}
                      and the specific software/source licence versions listed in my basket.
                    </span>
                  </label>

                  {totals?.hasDigitalItems && (
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={digitalWaiverAccepted}
                        onChange={(e) => setDigitalWaiverAccepted(e.target.checked)}
                        className="mt-1 w-4 h-4 accent-[#d4006c]"
                      />
                      <span className="text-[#14161b] leading-relaxed">
                        <strong>Digital content waiver (UK Consumer Contracts Regulations 2013, Reg 37):</strong>{' '}
                        I request immediate supply of my digital downloads/licence keys and acknowledge that I lose my 14-day statutory right to cancel once download access is granted.
                      </span>
                    </label>
                  )}

                  <label className="flex items-start gap-3 pt-2 border-t border-[#efe9df] text-xs text-[#4e535e] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={simulateFailOnce}
                      onChange={(e) => setSimulateFailOnce(e.target.checked)}
                      className="mt-0.5 w-4 h-4 accent-[#d4006c]"
                    />
                    <span>
                      Testing option: simulate a transient fulfilment worker failure on attempt 1 (verifies safe retry &amp; recovery on order page).
                    </span>
                  </label>
                </div>

                {error && (
                  <div
                    role="alert"
                    className="p-3.5 rounded-md bg-[#fef2f6] border border-[#d4006c]/30 text-sm text-[#9d004f] flex items-start gap-2"
                  >
                    <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" aria-hidden="true" />
                    <span>{error}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full h-12 rounded-md bg-[#d4006c] hover:bg-[#b8005d] text-white font-semibold text-sm transition-colors cursor-pointer"
                >
                  {submitting ? 'Validating stock & reserving order...' : 'Continue to payment simulator'}
                </button>
              </div>
            </div>

            {/* Right Fulfilment & Totals Breakdown */}
            <aside className="lg:col-span-5 bg-white border border-[#e4ded4] rounded-lg p-6 space-y-5">
              <h2 className="font-display font-bold text-lg text-[#14161b]">
                Items &amp; Fulfilment Expectations
              </h2>

              <ul className="divide-y divide-[#efe9df]">
                {items.map((item) => (
                  <li key={item.id} className="py-3 space-y-1 text-sm">
                    <div className="flex justify-between gap-2 font-semibold text-[#14161b]">
                      <span>
                        {item.title} × {item.quantity}
                      </span>
                      <span className="tabular-nums">{formatGBPPrecise(item.lineTotalPence)}</span>
                    </div>
                    <p className="text-xs text-[#4e535e]">{item.editionName}</p>
                    <p className="text-xs text-[#c80064] font-medium">
                      {item.fulfilmentChoice === 'digital' &&
                        'Fulfilment: Instant My Software Library entitlement upon payment webhook'}
                      {item.fulfilmentChoice === 'delivery' &&
                        'Fulfilment: UK Tracked 48 dispatch from Central Warehouse (1–2 working days)'}
                      {item.fulfilmentChoice === 'collect' &&
                        `Fulfilment: Click & Collect at ${item.storeName || 'selected store'} (ready within 2 hours)`}
                      {item.fulfilmentChoice === 'workshop' &&
                        `Fulfilment: Confirmed seat (${item.workshopTime?.fullLabel || 'Scheduled'})`}
                    </p>
                    {item.licenceCode && (
                      <p className="text-[11px] text-[#4e535e]">
                        Licence version recorded: {item.licenceCode} v{item.licenceVersion}
                      </p>
                    )}
                  </li>
                ))}
              </ul>

              {totals && (
                <dl className="space-y-2 text-sm border-t border-[#e4ded4] pt-4">
                  <div className="flex justify-between">
                    <dt className="text-[#4e535e]">Items (ex. VAT)</dt>
                    <dd className="tabular-nums">{formatGBPPrecise(totals.itemsNetPence)}</dd>
                  </div>
                  {totals.discountPence > 0 && (
                    <div className="flex justify-between text-[#c80064]">
                      <dt>Discount</dt>
                      <dd className="tabular-nums">-{formatGBPPrecise(totals.discountPence)}</dd>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <dt className="text-[#4e535e]">UK VAT (20%)</dt>
                    <dd className="tabular-nums">{formatGBPPrecise(totals.taxPence)}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-[#4e535e]">Delivery</dt>
                    <dd className="tabular-nums">
                      {totals.deliveryPence === 0 ? 'Free' : formatGBPPrecise(totals.deliveryPence)}
                    </dd>
                  </div>
                  <div className="flex justify-between border-t border-[#e4ded4] pt-3 text-lg font-display font-extrabold text-[#14161b]">
                    <dt>Total to pay</dt>
                    <dd className="tabular-nums">{formatGBPPrecise(totals.totalPence)}</dd>
                  </div>
                </dl>
              )}
            </aside>
          </form>
        )}
      </div>
    </div>
  );
}
