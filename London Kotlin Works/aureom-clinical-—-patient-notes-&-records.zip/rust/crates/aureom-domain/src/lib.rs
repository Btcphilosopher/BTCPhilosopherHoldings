use chrono::{DateTime, NaiveDate, Utc};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use thiserror::Error;
use uuid::Uuid;

type HmacSha256 = Hmac<Sha256>;

#[derive(Debug, Error)]
pub enum DomainError {
    #[error("Permission denied: {0}")]
    PermissionDenied(String),
    #[error("Optimistic concurrency conflict: expected v{expected}, server at v{actual}")]
    VersionConflict { expected: i32, actual: i32 },
    #[error("Note is immutable in status {0:?}")]
    ImmutableNote(NoteStatus),
    #[error("Patient identity confirmation is required before signing")]
    PatientConfirmationRequired,
    #[error("Invalid clinical transition: {0}")]
    InvalidTransition(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum UserRole {
    Consultant,
    Registrar,
    ClinicalNurse,
    Pharmacist,
    Admin,
    IGLead,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NhsVerificationStatus {
    VerifiedPds,
    Unverified,
    TracePending,
    NotProvided,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AllergyAssertionStatus {
    AssessedWithAllergies,
    NoKnownAllergies,
    NotAssessed,
    Unavailable,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ClinicalPresenceState {
    Known,
    Unknown,
    NotAssessed,
    Absent,
    Unavailable,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NoteTemplateType {
    Consultation,
    Admission,
    WardRound,
    Progress,
    Procedure,
    Discharge,
    Handover,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NoteStatus {
    Draft,
    Signed,
    Amended,
    EnteredInError,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResultStatus {
    Preliminary,
    Final,
    Corrected,
    Cancelled,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResultReviewState {
    Available,
    Viewed,
    Acknowledged,
    FollowUpAssigned,
    FollowUpCompleted,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MedicationConcept {
    Prescribing,
    Dispensing,
    Administration,
    PatientReported,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NoteSection {
    pub key: String,
    pub label: String,
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Patient {
    pub id: Uuid,
    pub internal_mrn: String,
    pub family_name: String,
    pub given_names: String,
    pub dob: NaiveDate,
    pub nhs_number: Option<String>,
    pub nhs_verification_status: NhsVerificationStatus,
    pub allergy_assertion_status: AllergyAssertionStatus,
    pub organisation_id: Uuid,
    pub merged_into_patient_id: Option<Uuid>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClinicalNote {
    pub id: Uuid,
    pub patient_id: Uuid,
    pub encounter_id: Option<Uuid>,
    pub template_type: NoteTemplateType,
    pub title: String,
    pub status: NoteStatus,
    pub sections: Vec<NoteSection>,
    pub free_text: String,
    pub version: i32,
    pub author_id: Uuid,
    pub signed_by: Option<Uuid>,
    pub signed_at: Option<DateTime<Utc>>,
    pub attestation_statement: Option<String>,
    pub cryptographic_signature_hex: Option<String>,
    pub idempotency_key: Option<String>,
}

impl ClinicalNote {
    pub fn apply_draft_update(
        &mut self,
        expected_version: i32,
        title: String,
        sections: Vec<NoteSection>,
        free_text: String,
    ) -> Result<(), DomainError> {
        if self.status != NoteStatus::Draft {
            return Err(DomainError::ImmutableNote(self.status));
        }
        if self.version != expected_version {
            return Err(DomainError::VersionConflict {
                expected: expected_version,
                actual: self.version,
            });
        }
        self.title = title;
        self.sections = sections;
        self.free_text = free_text;
        self.version += 1;
        Ok(())
    }

    pub fn sign_atomically(
        &mut self,
        clinician_id: Uuid,
        clinician_reg: &str,
        expected_version: i32,
        patient_confirmed: bool,
        idempotency_key: &str,
        hmac_secret: &[u8],
        now: DateTime<Utc>,
    ) -> Result<bool, DomainError> {
        if !patient_confirmed {
            return Err(DomainError::PatientConfirmationRequired);
        }
        if self.idempotency_key.as_deref() == Some(idempotency_key)
            && matches!(self.status, NoteStatus::Signed | NoteStatus::Amended)
        {
            // Idempotent retry: return false indicating no new signature created
            return Ok(false);
        }
        if self.status != NoteStatus::Draft {
            return Err(DomainError::ImmutableNote(self.status));
        }
        if self.version != expected_version {
            return Err(DomainError::VersionConflict {
                expected: expected_version,
                actual: self.version,
            });
        }
        self.version += 1;
        self.status = NoteStatus::Signed;
        self.signed_by = Some(clinician_id);
        self.signed_at = Some(now);
        self.idempotency_key = Some(idempotency_key.to_string());
        self.attestation_statement = Some(format!(
            "Clinical Attestation: Clinician {} ({}) confirmed patient identity and attested at {}.",
            clinician_id,
            clinician_reg,
            now.to_rfc3339()
        ));

        let payload = format!(
            "{}|v{}|{}|{}|{}",
            self.id,
            self.version,
            clinician_id,
            serde_json::to_string(&self.sections).unwrap_or_default(),
            now.to_rfc3339()
        );
        let mut mac = HmacSha256::new_from_slice(hmac_secret).expect("valid HMAC key");
        mac.update(payload.as_bytes());
        self.cryptographic_signature_hex = Some(hex::encode(mac.finalize().into_bytes()));
        Ok(true)
    }
}

pub fn compute_audit_event_hash(
    event_id: Uuid,
    event_time: DateTime<Utc>,
    actor_id: &str,
    action: &str,
    resource_id: &str,
    outcome: &str,
    prev_hash: &str,
) -> String {
    let mut hasher = Sha256::new();
    let line = format!(
        "{}|{}|{}|{}|{}|{}|{}",
        event_id,
        event_time.to_rfc3339(),
        actor_id,
        action,
        resource_id,
        outcome,
        prev_hash
    );
    hasher.update(line.as_bytes());
    hex::encode(hasher.finalize())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn signed_note_is_immutable_and_retries_are_idempotent() {
        let mut note = ClinicalNote {
            id: Uuid::new_v4(),
            patient_id: Uuid::new_v4(),
            encounter_id: None,
            template_type: NoteTemplateType::Consultation,
            title: "Cardiology Review".into(),
            status: NoteStatus::Draft,
            sections: vec![NoteSection {
                key: "plan".into(),
                label: "Plan".into(),
                content: "Continue bisoprolol".into(),
            }],
            free_text: String::new(),
            version: 1,
            author_id: Uuid::new_v4(),
            signed_by: None,
            signed_at: None,
            attestation_statement: None,
            cryptographic_signature_hex: None,
            idempotency_key: None,
        };

        let clinician = Uuid::new_v4();
        let now = Utc::now();
        let first = note
            .sign_atomically(clinician, "GMC-7041928", 1, true, "idem-123", b"secret", now)
            .unwrap();
        assert!(first);
        assert_eq!(note.status, NoteStatus::Signed);
        assert_eq!(note.version, 2);

        // Retry with same idempotency key does NOT fail and does NOT bump version
        let retry = note
            .sign_atomically(clinician, "GMC-7041928", 1, true, "idem-123", b"secret", now)
            .unwrap();
        assert!(!retry);
        assert_eq!(note.version, 2);

        // Attempting to overwrite signed note fails
        let edit_err = note.apply_draft_update(2, "Tamper".into(), vec![], "Tamper".into());
        assert!(matches!(edit_err, Err(DomainError::ImmutableNote(NoteStatus::Signed))));
    }
}
