use leptos::prelude::*;

#[component]
pub fn PatientIdentificationBanner(
    family_name: String,
    given_names: String,
    dob: String,
    nhs_number: Option<String>,
    verification_label: String,
    allergy_assertion: String,
) -> impl IntoView {
    view! {
        <section
            aria-label="Active Patient Identification Banner"
            class="bg-white border-b border-slate-300 px-6 py-3"
        >
            <div class="flex flex-wrap items-baseline gap-3">
                <h2 class="text-lg font-bold text-[#003087]">
                    {format!("{}, {}", family_name.to_uppercase(), given_names)}
                </h2>
                <span class="text-xs text-slate-600 tabular-nums">{format!("Born {dob}")}</span>
                <span class="text-xs font-mono font-semibold text-slate-900 tabular-nums">
                    {format!("NHS {}", nhs_number.unwrap_or_else(|| "Not Provided".into()))}
                </span>
                <span class="text-xs text-slate-700">{format!("({verification_label})")}</span>
            </div>
            <div class="text-xs font-semibold text-red-700 mt-1">{allergy_assertion}</div>
        </section>
    }
}

#[component]
pub fn ClinicalWorkspaceShell() -> impl IntoView {
    let (active_nav, set_active_nav) = signal("today".to_string());
    let (draft_dirty, set_draft_dirty) = signal(false);

    view! {
        <div class="min-h-screen flex bg-[#F0F4F5] text-slate-900">
            <aside class="w-64 bg-[#003087] text-white p-4 space-y-4">
                <div class="font-bold text-lg">"AUREOM CLINICAL"</div>
                <div class="text-xs text-blue-100">"Independent Prototype · Synthetic Data"</div>
                <nav class="space-y-1 text-sm">
                    <button on:click=move |_| set_active_nav.set("today".into()) class="block w-full text-left px-3 py-2 rounded">"Today"</button>
                    <button on:click=move |_| set_active_nav.set("patients".into()) class="block w-full text-left px-3 py-2 rounded">"Patients"</button>
                    <button on:click=move |_| set_active_nav.set("notes".into()) class="block w-full text-left px-3 py-2 rounded">"Notes"</button>
                    <button on:click=move |_| set_active_nav.set("results".into()) class="block w-full text-left px-3 py-2 rounded">"Results"</button>
                    <button on:click=move |_| set_active_nav.set("medications".into()) class="block w-full text-left px-3 py-2 rounded">"Medications"</button>
                    <button on:click=move |_| set_active_nav.set("tasks".into()) class="block w-full text-left px-3 py-2 rounded">"Tasks"</button>
                    <button on:click=move |_| set_active_nav.set("admin".into()) class="block w-full text-left px-3 py-2 rounded">"Administration"</button>
                </nav>
            </aside>
            <main class="flex-1 p-6">
                <p class="text-xs text-slate-600">
                    {move || format!("Active section: {} | Unsaved draft guard: {}", active_nav.get(), draft_dirty.get())}
                </p>
                <button
                    class="mt-3 px-3 py-1.5 bg-[#005EB8] text-white text-xs rounded"
                    on:click=move |_| set_draft_dirty.update(|d| *d = !*d)
                >
                    "Toggle Draft Guard State"
                </button>
            </main>
        </div>
    }
}
