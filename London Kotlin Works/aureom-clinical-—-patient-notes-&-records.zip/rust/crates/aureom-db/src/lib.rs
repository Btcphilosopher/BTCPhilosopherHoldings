use aureom_domain::{compute_audit_event_hash, DomainError, NoteSection, NoteStatus};
use chrono::Utc;
use sqlx::{PgPool, Row};
use uuid::Uuid;

#[derive(Debug, thiserror::Error)]
pub enum DbError {
    #[error("Domain error: {0}")]
    Domain(#[from] DomainError),
    #[error("Database error: {0}")]
    Sqlx(#[from] sqlx::Error),
    #[error("Record not found")]
    NotFound,
}

pub struct ClinicalRepository {
    pub pool: PgPool,
    pub hmac_secret: Vec<u8>,
}

impl ClinicalRepository {
    pub fn new(pool: PgPool, hmac_secret: Vec<u8>) -> Self {
        Self { pool, hmac_secret }
    }

    pub async fn save_draft_with_optimistic_lock(
        &self,
        note_id: Uuid,
        actor_id: Uuid,
        actor_role: &str,
        org_id: Uuid,
        expected_version: i32,
        title: &str,
        sections: &[NoteSection],
        free_text: &str,
    ) -> Result<i32, DbError> {
        let mut tx = self.pool.begin().await?;

        let row = sqlx::query(
            "SELECT patient_id, status, version FROM clinical_notes WHERE id = $1 FOR UPDATE",
        )
        .bind(note_id)
        .fetch_optional(&mut *tx)
        .await?
        .ok_or(DbError::NotFound)?;

        let patient_id: Uuid = row.get("patient_id");
        let status: String = row.get("status");
        let current_version: i32 = row.get("version");

        if status != "draft" {
            return Err(DomainError::ImmutableNote(NoteStatus::Signed).into());
        }
        if current_version != expected_version {
            return Err(DomainError::VersionConflict {
                expected: expected_version,
                actual: current_version,
            }
            .into());
        }

        let new_version = current_version + 1;
        let sections_val = serde_json::to_value(sections).unwrap_or_default();

        sqlx::query(
            "UPDATE clinical_notes SET title = $1, sections = $2, free_text = $3, version = $4, updated_at = NOW()
             WHERE id = $5 AND version = $6",
        )
        .bind(title)
        .bind(&sections_val)
        .bind(free_text)
        .bind(new_version)
        .bind(note_id)
        .bind(current_version)
        .execute(&mut *tx)
        .await?;

        Self::append_audit_tx(
            &mut tx,
            &actor_id.to_string(),
            actor_role,
            org_id,
            "note.draft_saved",
            "ClinicalNote",
            &note_id.to_string(),
            Some(patient_id),
            "allow",
            None,
        )
        .await?;

        tx.commit().await?;
        Ok(new_version)
    }

    pub async fn sign_note_atomically(
        &self,
        note_id: Uuid,
        clinician_id: Uuid,
        clinician_role: &str,
        org_id: Uuid,
        expected_version: i32,
        patient_confirmed: bool,
        idempotency_key: &str,
    ) -> Result<i32, DbError> {
        if !patient_confirmed {
            return Err(DomainError::PatientConfirmationRequired.into());
        }

        let mut tx = self.pool.begin().await?;
        let row = sqlx::query(
            "SELECT patient_id, status, version, idempotency_key FROM clinical_notes WHERE id = $1 FOR UPDATE",
        )
        .bind(note_id)
        .fetch_optional(&mut *tx)
        .await?
        .ok_or(DbError::NotFound)?;

        let existing_idem: Option<String> = row.get("idempotency_key");
        let status: String = row.get("status");
        let current_version: i32 = row.get("version");
        let patient_id: Uuid = row.get("patient_id");

        if existing_idem.as_deref() == Some(idempotency_key)
            && (status == "signed" || status == "amended")
        {
            tx.commit().await?;
            return Ok(current_version);
        }

        if status != "draft" {
            return Err(DomainError::ImmutableNote(NoteStatus::Signed).into());
        }
        if current_version != expected_version {
            return Err(DomainError::VersionConflict {
                expected: expected_version,
                actual: current_version,
            }
            .into());
        }

        let new_version = current_version + 1;
        let now = Utc::now();
        let attestation = format!(
            "Clinical Attestation: {} confirmed patient identity and signed at {}",
            clinician_id,
            now.to_rfc3339()
        );

        sqlx::query(
            "UPDATE clinical_notes
             SET status = 'signed', version = $1, signed_by = $2, signed_at = $3,
                 attestation_statement = $4, idempotency_key = $5, updated_at = $3
             WHERE id = $6",
        )
        .bind(new_version)
        .bind(clinician_id)
        .bind(now)
        .bind(&attestation)
        .bind(idempotency_key)
        .bind(note_id)
        .execute(&mut *tx)
        .await?;

        Self::append_audit_tx(
            &mut tx,
            &clinician_id.to_string(),
            clinician_role,
            org_id,
            "note.signed",
            "ClinicalNote",
            &note_id.to_string(),
            Some(patient_id),
            "allow",
            Some("Atomic clinical attestation"),
        )
        .await?;

        sqlx::query(
            "INSERT INTO outbox_events (id, aggregate_type, aggregate_id, event_type, payload, status)
             VALUES ($1, 'ClinicalNote', $2, 'fhir.document_reference.signed', $3, 'pending')",
        )
        .bind(Uuid::new_v4())
        .bind(note_id)
        .bind(serde_json::json!({ "noteId": note_id, "patientId": patient_id, "version": new_version }))
        .execute(&mut *tx)
        .await?;

        tx.commit().await?;
        Ok(new_version)
    }

    async fn append_audit_tx(
        tx: &mut sqlx::Transaction<'_, sqlx::Postgres>,
        actor_id: &str,
        actor_role: &str,
        org_id: Uuid,
        action: &str,
        resource_type: &str,
        resource_id: &str,
        patient_id: Option<Uuid>,
        outcome: &str,
        reason: Option<&str>,
    ) -> Result<(), sqlx::Error> {
        let prev_row = sqlx::query("SELECT event_hash FROM audit_events ORDER BY seq_id DESC LIMIT 1")
            .fetch_optional(&mut **tx)
            .await?;
        let prev_hash = prev_row
            .map(|r| r.get::<String, _>("event_hash"))
            .unwrap_or_else(|| "0".repeat(64));

        let event_id = Uuid::new_v4();
        let now = Utc::now();
        let event_hash = compute_audit_event_hash(
            event_id,
            now,
            actor_id,
            action,
            resource_id,
            outcome,
            &prev_hash,
        );

        sqlx::query(
            "INSERT INTO audit_events (id, event_time, actor_id, actor_role, organisation_id, action, resource_type, resource_id, patient_id, outcome, reason, prev_hash, event_hash)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)",
        )
        .bind(event_id)
        .bind(now)
        .bind(actor_id)
        .bind(actor_role)
        .bind(org_id)
        .bind(action)
        .bind(resource_type)
        .bind(resource_id)
        .bind(patient_id)
        .bind(outcome)
        .bind(reason)
        .bind(&prev_hash)
        .bind(&event_hash)
        .execute(&mut **tx)
        .await?;

        Ok(())
    }
}
