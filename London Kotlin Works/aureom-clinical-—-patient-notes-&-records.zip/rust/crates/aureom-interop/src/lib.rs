use aureom_domain::{NhsVerificationStatus, Patient};
use chrono::Utc;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuthoritativeSourceMapping {
    pub domain: &'static str,
    pub fhir_uk_core_profile: &'static str,
    pub authoritative_system: &'static str,
    pub local_mirror_behavior: &'static str,
}

pub fn uk_core_authoritative_matrix() -> Vec<AuthoritativeSourceMapping> {
    vec![
        AuthoritativeSourceMapping {
            domain: "Patient Demographics & NHS Number",
            fhir_uk_core_profile: "https://fhir.hl7.org.uk/StructureDefinition/UKCore-Patient",
            authoritative_system: "NHS Personal Demographics Service (PDS) via Spine FHIR API",
            local_mirror_behavior: "Local PAS MRN stored alongside PDS trace status; never auto-merged",
        },
        AuthoritativeSourceMapping {
            domain: "Diagnostic Results",
            fhir_uk_core_profile: "https://fhir.hl7.org.uk/StructureDefinition/UKCore-DiagnosticReport",
            authoritative_system: "Performing Pathology / Radiology LIMS",
            local_mirror_behavior: "Preserves preliminary/final/corrected chain; local EPR tracks review state",
        },
        AuthoritativeSourceMapping {
            domain: "Allergies & Medications",
            fhir_uk_core_profile: "https://fhir.hl7.org.uk/StructureDefinition/UKCore-AllergyIntolerance",
            authoritative_system: "Shared GP Connect / Hospital ePMA (Concept-specific)",
            local_mirror_behavior: "Keeps prescribing, dispensing, administration, and patient-reported separate",
        },
    ]
}

pub fn patient_to_uk_core_fhir(patient: &Patient) -> Value {
    let ver_code = match patient.nhs_verification_status {
        NhsVerificationStatus::VerifiedPds => "01",
        NhsVerificationStatus::TracePending => "02",
        NhsVerificationStatus::Unverified => "03",
        NhsVerificationStatus::NotProvided => "08",
    };

    json!({
        "resourceType": "Patient",
        "id": patient.id,
        "meta": {
            "profile": ["https://fhir.hl7.org.uk/StructureDefinition/UKCore-Patient"],
            "lastUpdated": Utc::now().to_rfc3339()
        },
        "identifier": [
            {
                "system": "https://fhir.nhs.uk/Id/nhs-number",
                "value": patient.nhs_number,
                "extension": [{
                    "url": "https://fhir.hl7.org.uk/StructureDefinition/Extension-UKCore-NHSNumberVerificationStatus",
                    "valueCodeableConcept": {
                        "coding": [{ "code": ver_code }]
                    }
                }]
            },
            {
                "system": "urn:aureom:mrn",
                "value": patient.internal_mrn
            }
        ],
        "name": [{
            "family": patient.family_name,
            "given": [patient.given_names]
        }],
        "birthDate": patient.dob.to_string()
    })
}
