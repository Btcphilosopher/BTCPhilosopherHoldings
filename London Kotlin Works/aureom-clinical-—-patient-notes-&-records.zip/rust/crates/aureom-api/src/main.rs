use std::sync::Arc;
use aureom_db::{ClinicalRepository, DbError};
use aureom_domain::{DomainError, NoteSection, UserRole};
use aureom_interop::uk_core_authoritative_matrix;
use axum::{
    extract::{Path, State},
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    routing::{get, post, put},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use sqlx::postgres::PgPoolOptions;
use tower_http::trace::TraceLayer;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};
use uuid::Uuid;

#[derive(Clone)]
pub struct AppState {
    pub repo: Arc<ClinicalRepository>,
    pub ai_adapter_enabled: bool,
}

#[derive(Debug, Clone)]
pub struct AuthContext {
    pub clinician_id: Uuid,
    pub role: UserRole,
    pub organisation_id: Uuid,
    pub break_glass_patient_id: Option<Uuid>,
}

pub enum ApiRejection {
    Unauthorized(&'static str),
    Forbidden(String),
    Conflict(String),
    BadRequest(String),
    NotFound,
    Internal,
}

impl IntoResponse for ApiRejection {
    fn into_response(self) -> Response {
        let (status, code, msg) = match self {
            ApiRejection::Unauthorized(m) => (StatusCode::UNAUTHORIZED, "UNAUTHENTICATED", m.to_string()),
            ApiRejection::Forbidden(m) => (StatusCode::FORBIDDEN, "PERMISSION_DENIED", m),
            ApiRejection::Conflict(m) => (StatusCode::CONFLICT, "VERSION_OR_STATE_CONFLICT", m),
            ApiRejection::BadRequest(m) => (StatusCode::BAD_REQUEST, "BAD_REQUEST", m),
            ApiRejection::NotFound => (StatusCode::NOT_FOUND, "NOT_FOUND", "Resource not found".into()),
            ApiRejection::Internal => (StatusCode::INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "Internal error".into()),
        };
        (status, Json(serde_json::json!({ "error": { "code": code, "message": msg } }))).into_response()
    }
}

impl From<DbError> for ApiRejection {
    fn from(err: DbError) -> Self {
        match err {
            DbError::NotFound => ApiRejection::NotFound,
            DbError::Domain(DomainError::VersionConflict { expected, actual }) => {
                ApiRejection::Conflict(format!("Optimistic concurrency conflict: expected v{expected}, server at v{actual}"))
            }
            DbError::Domain(DomainError::ImmutableNote(st)) => {
                ApiRejection::Conflict(format!("Note is immutable in status {st:?}"))
            }
            DbError::Domain(DomainError::PatientConfirmationRequired) => {
                ApiRejection::BadRequest("Patient identity confirmation is required before signing".into())
            }
            DbError::Domain(DomainError::PermissionDenied(m)) => ApiRejection::Forbidden(m),
            DbError::Domain(DomainError::InvalidTransition(m)) => ApiRejection::BadRequest(m),
            DbError::Sqlx(_) => ApiRejection::Internal,
        }
    }
}

#[derive(Deserialize)]
struct SaveDraftRequest {
    expected_version: i32,
    title: String,
    sections: Vec<NoteSection>,
    free_text: String,
}

#[derive(Deserialize)]
struct SignNoteRequest {
    expected_version: i32,
    patient_confirmed: bool,
    idempotency_key: String,
}

#[derive(Serialize)]
struct NoteMutationResponse {
    note_id: Uuid,
    version: i32,
    status: &'static str,
}

fn verify_patient_isolation(
    ctx: &AuthContext,
    patient_org_id: Uuid,
    patient_id: Uuid,
    write_clinical: bool,
) -> Result<(), ApiRejection> {
    if write_clinical && ctx.role == UserRole::IGLead {
        return Err(ApiRejection::Forbidden("IGLead role is read-only for clinical charting".into()));
    }
    if ctx.organisation_id != patient_org_id && ctx.break_glass_patient_id != Some(patient_id) {
        return Err(ApiRejection::Forbidden(
            "Cross-organisation access denied without active care relationship or break-glass".into(),
        ));
    }
    Ok(())
}

fn extract_auth_from_headers(headers: &HeaderMap) -> Result<AuthContext, ApiRejection> {
    // Prototype adapter: validates OIDC bearer token / signed session header in production
    let bearer = headers
        .get(axum::http::header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.strip_prefix("Bearer "));
    if bearer.is_none() {
        return Err(ApiRejection::Unauthorized("Missing Bearer token"));
    }
    Ok(AuthContext {
        clinician_id: Uuid::parse_str("aaaa1111-1111-4111-8111-111111111111").unwrap(),
        role: UserRole::Consultant,
        organisation_id: Uuid::parse_str("11111111-1111-4111-8111-111111111111").unwrap(),
        break_glass_patient_id: None,
    })
}

async fn health() -> impl IntoResponse {
    Json(serde_json::json!({ "status": "ok", "service": "aureom-api-rust" }))
}

async fn interop_matrix() -> impl IntoResponse {
    Json(uk_core_authoritative_matrix())
}

async fn save_draft(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(note_id): Path<Uuid>,
    Json(body): Json<SaveDraftRequest>,
) -> Result<Json<NoteMutationResponse>, ApiRejection> {
    let ctx = extract_auth_from_headers(&headers)?;
    // Privacy-safe operational tracing: log IDs & action only — never note text!
    tracing::info!(actor_id = %ctx.clinician_id, note_id = %note_id, action = "note.save_draft");
    let version = state
        .repo
        .save_draft_with_optimistic_lock(
            note_id,
            ctx.clinician_id,
            "Consultant",
            ctx.organisation_id,
            body.expected_version,
            &body.title,
            &body.sections,
            &body.free_text,
        )
        .await?;
    Ok(Json(NoteMutationResponse { note_id, version, status: "draft" }))
}

async fn sign_note(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(note_id): Path<Uuid>,
    Json(body): Json<SignNoteRequest>,
) -> Result<Json<NoteMutationResponse>, ApiRejection> {
    let ctx = extract_auth_from_headers(&headers)?;
    tracing::info!(actor_id = %ctx.clinician_id, note_id = %note_id, action = "note.sign");
    let version = state
        .repo
        .sign_note_atomically(
            note_id,
            ctx.clinician_id,
            "Consultant",
            ctx.organisation_id,
            body.expected_version,
            body.patient_confirmed,
            &body.idempotency_key,
        )
        .await?;
    Ok(Json(NoteMutationResponse { note_id, version, status: "signed" }))
}

pub fn build_router(state: AppState) -> Router {
    Router::new()
        .route("/api/health", get(health))
        .route("/api/interop/authoritative-matrix", get(interop_matrix))
        .route("/api/notes/{note_id}/draft", put(save_draft))
        .route("/api/notes/{note_id}/sign", post(sign_note))
        .layer(TraceLayer::new_for_http())
        .with_state(state)
}

#[tokio::main]
async fn main() {
    tracing_subscriber::registry()
        .with(tracing_subscriber::fmt::layer().json())
        .init();

    let db_url = std::env::var("DATABASE_URL")
        .unwrap_or_else(|_| "postgres://aureom:aureom@localhost:5432/aureom_clinical".into());
    let hmac_secret = std::env::var("SIGNING_HMAC_SECRET")
        .unwrap_or_else(|_| "dev-ephemeral-hmac-secret".into())
        .into_bytes();
    let ai_enabled = std::env::var("AI_ADAPTER_ENABLED").as_deref() == Ok("true");

    let pool = PgPoolOptions::new()
        .max_connections(10)
        .connect(&db_url)
        .await
        .expect("Failed to connect to PostgreSQL");

    sqlx::migrate!("../../migrations")
        .run(&pool)
        .await
        .expect("Failed to run SQLx migrations");

    let state = AppState {
        repo: Arc::new(ClinicalRepository::new(pool, hmac_secret)),
        ai_adapter_enabled: ai_enabled,
    };

    let addr = std::env::var("BIND_ADDR").unwrap_or_else(|_| "0.0.0.0:8080".into());
    let listener = tokio::net::TcpListener::bind(&addr).await.unwrap();
    tracing::info!(bind_addr = %addr, ai_adapter_enabled = ai_enabled, "Aureom Rust API listening");
    axum::serve(listener, build_router(state)).await.unwrap();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cross_org_isolation_blocks_without_break_glass() {
        let org_a = Uuid::new_v4();
        let org_b = Uuid::new_v4();
        let pat_b = Uuid::new_v4();
        let ctx = AuthContext {
            clinician_id: Uuid::new_v4(),
            role: UserRole::Consultant,
            organisation_id: org_a,
            break_glass_patient_id: None,
        };
        assert!(verify_patient_isolation(&ctx, org_b, pat_b, false).is_err());

        let ctx_bg = AuthContext {
            break_glass_patient_id: Some(pat_b),
            ..ctx
        };
        assert!(verify_patient_isolation(&ctx_bg, org_b, pat_b, false).is_ok());
    }
}
