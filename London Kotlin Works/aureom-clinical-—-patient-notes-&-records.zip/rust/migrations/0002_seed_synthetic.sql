-- Aureom Clinical — Synthetic Clinic Seed Fixture (100% Synthetic 999 Test NHS Numbers)

INSERT INTO organisations (id, ods_code, name, trust_type) VALUES
    ('11111111-1111-4111-8111-111111111111', 'RXX', 'Aureom NHS Foundation Trust (Prototype)', 'Acute & Specialist Trust'),
    ('22222222-2222-4222-8222-222222222222', 'RYY', 'Westbridge Community Health Trust (Prototype)', 'Community Trust')
ON CONFLICT DO NOTHING;

INSERT INTO clinicians (id, oidc_subject, display_name, role, specialty, gmc_or_nmc_number, organisation_id, email) VALUES
    ('aaaa1111-1111-4111-8111-111111111111', 'oidc|rxx|a.vance', 'Dr. Alistair Vance', 'Consultant', 'Cardiology', 'GMC-7041928', '11111111-1111-4111-8111-111111111111', 'alistair.vance@prototype.nhs.example'),
    ('bbbb2222-2222-4222-8222-222222222222', 'oidc|ryy|m.thorne', 'Dr. Marcus Thorne', 'Consultant', 'Community Geriatrics', 'GMC-6102944', '22222222-2222-4222-8222-222222222222', 'marcus.thorne@westbridge.nhs.example')
ON CONFLICT DO NOTHING;

INSERT INTO patients (
    id, internal_mrn, family_name, given_names, preferred_name, dob, sex_at_birth,
    nhs_number, nhs_verification_status, contact, gp_practice, allergy_assertion_status, organisation_id
) VALUES
    (
        '33333333-3333-4333-8333-333333333331',
        'MRN-100482', 'Pendelton', 'Arthur George', 'Arthur', '1954-04-12', 'Male',
        '999 412 8831', 'verified_pds',
        '{"phone":"07700 900412","addressLine1":"28 Station Road","postcode":"MB4 2QT"}'::jsonb,
        '{"odsCode":"G82019","practiceName":"Meadowbank Health Centre"}'::jsonb,
        'assessed_with_allergies',
        '11111111-1111-4111-8111-111111111111'
    ),
    (
        '44444444-4444-4444-8444-444444444442',
        'MRN-EXT-3310', 'Holloway', 'Beatrice Anne', NULL, '1943-01-19', 'Female',
        '999 881 0043', 'verified_pds',
        '{"phone":"07700 900881","addressLine1":"5 St Jude Close","postcode":"WB2 4DD"}'::jsonb,
        '{"odsCode":"G91008","practiceName":"Westbridge Village Medical"}'::jsonb,
        'no_known_allergies',
        '22222222-2222-4222-8222-222222222222'
    )
ON CONFLICT DO NOTHING;
