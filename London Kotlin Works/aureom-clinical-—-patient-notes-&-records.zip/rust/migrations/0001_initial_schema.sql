-- Aureom Clinical — PostgreSQL Initial Schema (SQLx Migration 0001)
-- All timestamps stored in UTC (TIMESTAMPTZ). Clinical content excluded from operational logs.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE organisations (
    id UUID PRIMARY KEY,
    ods_code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    trust_type TEXT NOT NULL
);

CREATE TABLE clinicians (
    id UUID PRIMARY KEY,
    oidc_subject TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('Consultant','Registrar','ClinicalNurse','Pharmacist','Admin','IGLead')),
    specialty TEXT NOT NULL,
    gmc_or_nmc_number TEXT NOT NULL,
    organisation_id UUID NOT NULL REFERENCES organisations(id),
    email TEXT NOT NULL
);

CREATE TABLE sessions (
    token_hash TEXT PRIMARY KEY,
    clinician_id UUID NOT NULL REFERENCES clinicians(id),
    oidc_issuer TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    break_glass_patient_id UUID,
    break_glass_expires_at TIMESTAMPTZ,
    break_glass_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE patients (
    id UUID PRIMARY KEY,
    internal_mrn TEXT NOT NULL UNIQUE,
    family_name TEXT NOT NULL,
    given_names TEXT NOT NULL,
    preferred_name TEXT,
    dob DATE NOT NULL,
    sex_at_birth TEXT NOT NULL,
    gender_identity TEXT,
    nhs_number TEXT,
    nhs_verification_status TEXT NOT NULL CHECK (nhs_verification_status IN ('verified_pds','unverified','trace_pending','not_provided')),
    demographic_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    contact JSONB NOT NULL,
    gp_practice JSONB NOT NULL,
    allergy_assertion_status TEXT NOT NULL CHECK (allergy_assertion_status IN ('assessed_with_allergies','no_known_allergies','not_assessed','unavailable')),
    merged_into_patient_id UUID REFERENCES patients(id),
    organisation_id UUID NOT NULL REFERENCES organisations(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE patient_identifiers (
    id UUID PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id),
    system TEXT NOT NULL,
    value TEXT NOT NULL,
    authority TEXT NOT NULL,
    verification_status TEXT NOT NULL,
    provenance TEXT NOT NULL,
    is_primary BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE care_team_associations (
    id UUID PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id),
    clinician_id UUID NOT NULL REFERENCES clinicians(id),
    role TEXT NOT NULL,
    relationship_type TEXT NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE encounters (
    id UUID PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id),
    organisation_id UUID NOT NULL REFERENCES organisations(id),
    encounter_type TEXT NOT NULL,
    location TEXT NOT NULL,
    ward_or_clinic TEXT NOT NULL,
    responsible_clinician_id UUID NOT NULL REFERENCES clinicians(id),
    status TEXT NOT NULL,
    presenting_concern TEXT NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL,
    documented_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE clinical_notes (
    id UUID PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    template_type TEXT NOT NULL CHECK (template_type IN ('consultation','admission','ward_round','progress','procedure','discharge','handover')),
    title TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft','signed','amended','entered_in_error')),
    sections JSONB NOT NULL,
    free_text TEXT NOT NULL DEFAULT '',
    copied_citations JSONB NOT NULL DEFAULT '[]'::jsonb,
    version INTEGER NOT NULL DEFAULT 1,
    author_id UUID NOT NULL REFERENCES clinicians(id),
    signed_by UUID REFERENCES clinicians(id),
    signed_at TIMESTAMPTZ,
    attestation_statement TEXT,
    cryptographic_signature_hex TEXT,
    entered_in_error_reason TEXT,
    entered_in_error_by UUID REFERENCES clinicians(id),
    entered_in_error_at TIMESTAMPTZ,
    idempotency_key TEXT UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE note_revisions (
    id UUID PRIMARY KEY,
    note_id UUID NOT NULL REFERENCES clinical_notes(id),
    version INTEGER NOT NULL,
    action TEXT NOT NULL,
    sections JSONB NOT NULL,
    free_text TEXT NOT NULL,
    actor_id UUID NOT NULL REFERENCES clinicians(id),
    reason TEXT,
    content_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE note_amendments (
    id UUID PRIMARY KEY,
    note_id UUID NOT NULL REFERENCES clinical_notes(id),
    addendum_text TEXT NOT NULL,
    reason TEXT NOT NULL,
    author_id UUID NOT NULL REFERENCES clinicians(id),
    attestation_statement TEXT NOT NULL,
    cryptographic_signature_hex TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE diagnostic_results (
    id UUID PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    request_id TEXT NOT NULL,
    order_name TEXT NOT NULL,
    code TEXT NOT NULL,
    terminology_system TEXT NOT NULL,
    value_text TEXT NOT NULL,
    unit TEXT NOT NULL,
    reference_interval TEXT NOT NULL,
    abnormal_flag TEXT NOT NULL,
    result_status TEXT NOT NULL CHECK (result_status IN ('preliminary','final','corrected','cancelled')),
    review_state TEXT NOT NULL CHECK (review_state IN ('available','viewed','acknowledged','follow_up_assigned','follow_up_completed')),
    supersedes_result_id UUID REFERENCES diagnostic_results(id),
    correction_reason TEXT,
    observed_at TIMESTAMPTZ NOT NULL,
    reported_at TIMESTAMPTZ NOT NULL,
    performing_lab TEXT NOT NULL,
    viewed_by UUID REFERENCES clinicians(id),
    viewed_at TIMESTAMPTZ,
    acknowledged_by UUID REFERENCES clinicians(id),
    acknowledged_at TIMESTAMPTZ,
    follow_up_task_id UUID
);

CREATE TABLE tasks (
    id UUID PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    task_type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    owner_id UUID NOT NULL REFERENCES clinicians(id),
    assigned_team TEXT NOT NULL,
    priority TEXT NOT NULL,
    status TEXT NOT NULL,
    due_at TIMESTAMPTZ NOT NULL,
    completion_evidence TEXT,
    created_by UUID NOT NULL REFERENCES clinicians(id),
    accepted_by UUID REFERENCES clinicians(id),
    accepted_at TIMESTAMPTZ,
    completed_by UUID REFERENCES clinicians(id),
    completed_at TIMESTAMPTZ,
    patient_summary_text TEXT,
    patient_summary_approved_by UUID REFERENCES clinicians(id),
    patient_summary_approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE attachments (
    id UUID PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id),
    encounter_id UUID REFERENCES encounters(id),
    filename TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes BIGINT NOT NULL,
    sha256_hex TEXT NOT NULL,
    classification TEXT NOT NULL,
    object_storage_key TEXT NOT NULL,
    uploaded_by UUID NOT NULL REFERENCES clinicians(id),
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Restricted append-only audit log with hash chaining.
-- Note: A database table alone is NOT tamper-proof; production requires restricted DB role permissions
-- (REVOKE UPDATE, DELETE) and continuous external WORM replication.
CREATE TABLE audit_events (
    seq_id BIGSERIAL PRIMARY KEY,
    id UUID NOT NULL UNIQUE,
    event_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    actor_id TEXT NOT NULL,
    actor_role TEXT NOT NULL,
    organisation_id UUID NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    patient_id UUID,
    outcome TEXT NOT NULL CHECK (outcome IN ('allow','deny')),
    reason TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    prev_hash TEXT NOT NULL,
    event_hash TEXT NOT NULL
);

CREATE TABLE outbox_events (
    id UUID PRIMARY KEY,
    aggregate_type TEXT NOT NULL,
    aggregate_id UUID NOT NULL,
    event_type TEXT NOT NULL,
    payload JSONB NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending','delivered','failed','dead_letter')),
    attempts INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMPTZ,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    delivered_at TIMESTAMPTZ
);
