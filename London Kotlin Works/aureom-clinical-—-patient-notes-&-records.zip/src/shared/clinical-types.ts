export type UserRole =
  | 'Consultant'
  | 'Registrar'
  | 'ClinicalNurse'
  | 'Pharmacist'
  | 'Admin'
  | 'IGLead';

export type NhsVerificationStatus =
  | 'verified_pds'
  | 'unverified'
  | 'trace_pending'
  | 'not_provided';

export type AllergyAssertionStatus =
  | 'assessed_with_allergies'
  | 'no_known_allergies'
  | 'not_assessed'
  | 'unavailable';

export type NoteTemplateType =
  | 'consultation'
  | 'admission'
  | 'ward_round'
  | 'progress'
  | 'procedure'
  | 'discharge'
  | 'handover';

export type NoteStatus = 'draft' | 'signed' | 'amended' | 'entered_in_error';

export type ResultStatus = 'preliminary' | 'final' | 'corrected' | 'cancelled';

export type ResultReviewState =
  | 'available'
  | 'viewed'
  | 'acknowledged'
  | 'follow_up_assigned'
  | 'follow_up_completed';

export type MedicationConceptType =
  | 'prescribing'
  | 'dispensing'
  | 'administration'
  | 'patient_reported';

export type TaskType =
  | 'follow_up'
  | 'results_review'
  | 'referral_prep'
  | 'handover'
  | 'discharge_prep'
  | 'patient_info';

export type TaskStatus =
  | 'created'
  | 'delivered'
  | 'accepted'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export interface Organisation {
  id: string;
  odsCode: string;
  name: string;
  trustType: string;
}

export interface Clinician {
  id: string;
  oidcSubject: string;
  displayName: string;
  role: UserRole;
  specialty: string;
  gmcOrNmcNumber: string;
  organisationId: string;
  organisationName: string;
  email: string;
}

export interface AuthSession {
  token: string;
  clinician: Clinician;
  expiresAt: string;
  breakGlassPatientId: string | null;
  breakGlassExpiresAt: string | null;
  breakGlassReason: string | null;
  oidcIssuer: string;
}

export interface PatientIdentifier {
  id: string;
  patientId: string;
  system: string;
  value: string;
  authority: string;
  verificationStatus: NhsVerificationStatus;
  provenance: string;
  isPrimary: boolean;
}

export interface DemographicHistoryEntry {
  recordedAt: string;
  field: string;
  previousValue: string;
  newValue: string;
  source: string;
}

export interface PatientContact {
  phone: string;
  email: string;
  addressLine1: string;
  city: string;
  postcode: string;
  preferredMethod: string;
}

export interface GpPracticeInfo {
  odsCode: string;
  practiceName: string;
  gpName: string;
  phone: string;
}

export interface Patient {
  id: string;
  internalMrn: string;
  familyName: string;
  givenNames: string;
  preferredName: string | null;
  dob: string;
  sexAtBirth: string;
  genderIdentity: string | null;
  nhsNumber: string | null;
  nhsVerificationStatus: NhsVerificationStatus;
  demographicHistory: DemographicHistoryEntry[];
  contact: PatientContact;
  gpPractice: GpPracticeInfo;
  allergyAssertionStatus: AllergyAssertionStatus;
  mergedIntoPatientId: string | null;
  organisationId: string;
  createdAt: string;
  updatedAt: string;
  identifiers?: PatientIdentifier[];
}

export interface DuplicateCandidate {
  candidatePatient: Patient;
  matchBasis: string;
  confidenceLabel: 'Demographic Match Only — Unverified';
  warningMessage: string;
}

export interface Encounter {
  id: string;
  patientId: string;
  organisationId: string;
  encounterType: 'outpatient' | 'inpatient' | 'day_case' | 'telehealth' | 'emergency';
  location: string;
  wardOrClinic: string;
  responsibleClinicianId: string;
  responsibleClinicianName: string;
  status: 'planned' | 'arrived' | 'in_progress' | 'finished' | 'cancelled';
  presentingConcern: string;
  occurredAt: string;
  documentedAt: string;
}

export interface Problem {
  id: string;
  patientId: string;
  encounterId: string | null;
  code: string;
  codeSystem: string;
  display: string;
  clinicalStatus: 'active' | 'resolved' | 'inactive' | 'unknown';
  verificationStatus: 'confirmed' | 'provisional' | 'refuted' | 'entered_in_error';
  onsetAt: string | null;
  documentedAt: string;
  authorId: string;
  authorName: string;
  sourceProvenance: string;
  conflictGroupId: string | null;
  conflictNote: string | null;
}

export interface Allergy {
  id: string;
  patientId: string;
  substance: string;
  code: string;
  reaction: string;
  severity: 'mild' | 'moderate' | 'severe' | 'life_threatening' | 'unknown';
  verificationStatus: 'confirmed' | 'unconfirmed' | 'refuted' | 'entered_in_error';
  clinicalStatus: 'active' | 'inactive' | 'resolved';
  provenance: string;
  recordedAt: string;
  authorId: string;
  authorName: string;
}

export interface MedicationEntry {
  id: string;
  patientId: string;
  encounterId: string | null;
  conceptType: MedicationConceptType;
  drugName: string;
  dmdCode: string;
  strength: string;
  dose: string;
  route: string;
  frequency: string;
  startDate: string;
  endDate: string | null;
  status: 'active' | 'completed' | 'stopped' | 'on_hold' | 'unknown';
  source: string;
  reconciliationStatus: 'verified' | 'discrepancy' | 'unreconciled';
  conflictGroupId: string | null;
  authorId: string;
  authorName: string;
  documentedAt: string;
}

export interface Observation {
  id: string;
  patientId: string;
  encounterId: string | null;
  code: string;
  terminologySystem: string;
  display: string;
  valueNum: number | null;
  valueText: string;
  unit: string;
  referenceLow: number | null;
  referenceHigh: number | null;
  interpretation: 'normal' | 'high' | 'low' | 'critical' | 'not_assessed' | 'unavailable';
  observedAt: string;
  documentedAt: string;
  recordingSource: string;
  attribution: string;
  verificationStatus: 'preliminary' | 'final' | 'amended' | 'entered_in_error' | 'unavailable';
}

export interface DiagnosticResult {
  id: string;
  patientId: string;
  encounterId: string | null;
  requestId: string;
  orderName: string;
  code: string;
  terminologySystem: string;
  valueText: string;
  unit: string;
  referenceInterval: string;
  abnormalFlag: 'normal' | 'high' | 'low' | 'critical' | 'none';
  resultStatus: ResultStatus;
  reviewState: ResultReviewState;
  supersedesResultId: string | null;
  correctionReason: string | null;
  observedAt: string;
  reportedAt: string;
  performingLab: string;
  viewedBy: string | null;
  viewedAt: string | null;
  acknowledgedBy: string | null;
  acknowledgedAt: string | null;
  followUpTaskId: string | null;
}

export interface NoteSection {
  key: string;
  label: string;
  content: string;
}

export interface CopiedCitation {
  sourceType: string;
  sourceId: string;
  sourceAuthor: string;
  sourceDate: string;
  excerpt: string;
}

export interface NoteAmendment {
  id: string;
  noteId: string;
  addendumText: string;
  reason: string;
  authorId: string;
  authorName: string;
  attestationStatement: string;
  cryptographicSignatureHex: string;
  createdAt: string;
}

export interface NoteRevision {
  id: string;
  noteId: string;
  version: number;
  action: 'draft_created' | 'autosave' | 'conflict_resolved' | 'signed' | 'amended' | 'entered_in_error';
  sections: NoteSection[];
  freeText: string;
  actorId: string;
  actorName: string;
  reason: string | null;
  contentHash: string;
  createdAt: string;
}

export interface ClinicalNote {
  id: string;
  patientId: string;
  encounterId: string | null;
  templateType: NoteTemplateType;
  title: string;
  status: NoteStatus;
  sections: NoteSection[];
  freeText: string;
  copiedCitations: CopiedCitation[];
  version: number;
  authorId: string;
  authorName: string;
  signedBy: string | null;
  signedByName: string | null;
  signedAt: string | null;
  attestationStatement: string | null;
  cryptographicSignatureHex: string | null;
  enteredInErrorReason: string | null;
  enteredInErrorBy: string | null;
  enteredInErrorAt: string | null;
  idempotencyKey: string | null;
  createdAt: string;
  updatedAt: string;
  amendments?: NoteAmendment[];
  revisions?: NoteRevision[];
}

export interface CarePlan {
  id: string;
  patientId: string;
  title: string;
  category: string;
  status: 'active' | 'completed' | 'on_hold';
  goals: { description: string; targetDate: string; status: string }[];
  interventions: { action: string; frequency: string; owner: string }[];
  reviewDate: string;
  authorId: string;
  authorName: string;
  updatedAt: string;
}

export interface ClinicalTask {
  id: string;
  patientId: string;
  patientName?: string;
  encounterId: string | null;
  taskType: TaskType;
  title: string;
  description: string;
  ownerId: string;
  ownerName: string;
  assignedTeam: string;
  priority: 'routine' | 'urgent' | 'stat';
  status: TaskStatus;
  dueAt: string;
  completionEvidence: string | null;
  createdBy: string;
  acceptedBy: string | null;
  acceptedAt: string | null;
  completedBy: string | null;
  completedAt: string | null;
  patientSummaryText: string | null;
  patientSummaryApprovedBy: string | null;
  patientSummaryApprovedAt: string | null;
  createdAt: string;
}

export interface ClinicalAttachment {
  id: string;
  patientId: string;
  encounterId: string | null;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  sha256Hex: string;
  classification: 'clinical_letter' | 'ecg_trace' | 'consent_form' | 'referral';
  uploadedBy: string;
  uploadedByName: string;
  uploadedAt: string;
}

export interface AuditEvent {
  seqId: number;
  id: string;
  eventTime: string;
  actorId: string;
  actorName: string;
  actorRole: string;
  organisationId: string;
  action: string;
  resourceType: string;
  resourceId: string;
  patientId: string | null;
  outcome: 'allow' | 'deny';
  reason: string | null;
  metadata: Record<string, unknown>;
  prevHash: string;
  eventHash: string;
}

export interface OutboxEvent {
  id: string;
  aggregateType: string;
  aggregateId: string;
  eventType: string;
  payload: Record<string, unknown>;
  status: 'pending' | 'delivered' | 'failed' | 'dead_letter';
  attempts: number;
  nextRetryAt: string | null;
  lastError: string | null;
  createdAt: string;
  deliveredAt: string | null;
}

export interface PatientOverview {
  patient: Patient;
  encounters: Encounter[];
  activeEncounter: Encounter | null;
  problems: Problem[];
  allergies: Allergy[];
  medications: MedicationEntry[];
  observations: Observation[];
  results: DiagnosticResult[];
  notes: ClinicalNote[];
  carePlans: CarePlan[];
  tasks: ClinicalTask[];
  attachments: ClinicalAttachment[];
  duplicateCandidates: DuplicateCandidate[];
  conflicts: {
    type: 'problem' | 'medication' | 'identity';
    summary: string;
    recordIds: string[];
  }[];
}

export interface WorklistResponse {
  clinician: Clinician;
  serverTimeUtc: string;
  scheduledPatients: {
    patient: Patient;
    encounter: Encounter;
    pendingResultsCount: number;
    openTasksCount: number;
    draftNotesCount: number;
  }[];
  pendingResultsToAcknowledge: (DiagnosticResult & { patientName: string; nhsNumber: string | null })[];
  openTasks: ClinicalTask[];
}
