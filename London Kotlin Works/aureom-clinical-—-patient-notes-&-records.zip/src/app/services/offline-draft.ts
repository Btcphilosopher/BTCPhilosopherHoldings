import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import type { NoteSection } from '../../shared/clinical-types';

export interface EncryptedOfflineDraft {
  draftKey: string;
  patientId: string;
  noteId: string | null;
  baseVersion: number;
  savedAt: string;
  ivBase64: string;
  ciphertextBase64: string;
}

export interface DecryptedOfflineDraft {
  draftKey: string;
  patientId: string;
  noteId: string | null;
  baseVersion: number;
  savedAt: string;
  title: string;
  sections: NoteSection[];
  freeText: string;
}

@Injectable({ providedIn: 'root' })
export class OfflineDraftService {
  private platformId = inject(PLATFORM_ID);
  private dbName = 'aureom_clinical_encrypted_drafts';
  private storeName = 'drafts';
  private sessionAesKey: CryptoKey | null = null;

  private async getOrCreateSessionKey(): Promise<CryptoKey | null> {
    if (!isPlatformBrowser(this.platformId) || !window.crypto?.subtle) {
      return null;
    }
    if (this.sessionAesKey) return this.sessionAesKey;
    // Derive an ephemeral in-memory AES-GCM 256-bit key for encrypting cached local drafts
    this.sessionAesKey = await window.crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
    return this.sessionAesKey;
  }

  private openIdb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(this.dbName, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName, { keyPath: 'draftKey' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async saveEncryptedDraft(draft: Omit<DecryptedOfflineDraft, 'savedAt'>): Promise<string | null> {
    const key = await this.getOrCreateSessionKey();
    if (!key) return null;

    const savedAt = new Date().toISOString();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const plaintext = new TextEncoder().encode(
      JSON.stringify({
        title: draft.title,
        sections: draft.sections,
        freeText: draft.freeText,
      })
    );
    const encrypted = await window.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);

    const record: EncryptedOfflineDraft = {
      draftKey: draft.draftKey,
      patientId: draft.patientId,
      noteId: draft.noteId,
      baseVersion: draft.baseVersion,
      savedAt,
      ivBase64: btoa(String.fromCharCode(...iv)),
      ciphertextBase64: btoa(String.fromCharCode(...new Uint8Array(encrypted))),
    };

    const db = await this.openIdb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readwrite');
      tx.objectStore(this.storeName).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    return savedAt;
  }

  async listEncryptedMetadata(): Promise<EncryptedOfflineDraft[]> {
    if (!isPlatformBrowser(this.platformId) || typeof indexedDB === 'undefined') return [];
    const db = await this.openIdb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readonly');
      const req = tx.objectStore(this.storeName).getAll();
      req.onsuccess = () => resolve((req.result as EncryptedOfflineDraft[]) ?? []);
      req.onerror = () => reject(req.error);
    });
  }

  async decryptDraft(record: EncryptedOfflineDraft): Promise<DecryptedOfflineDraft | null> {
    const key = await this.getOrCreateSessionKey();
    if (!key) return null;
    try {
      const iv = Uint8Array.from(atob(record.ivBase64), (c) => c.charCodeAt(0));
      const ct = Uint8Array.from(atob(record.ciphertextBase64), (c) => c.charCodeAt(0));
      const plainBuf = await window.crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ct);
      const parsed = JSON.parse(new TextDecoder().decode(plainBuf)) as {
        title: string;
        sections: NoteSection[];
        freeText: string;
      };
      return {
        draftKey: record.draftKey,
        patientId: record.patientId,
        noteId: record.noteId,
        baseVersion: record.baseVersion,
        savedAt: record.savedAt,
        title: parsed.title,
        sections: parsed.sections,
        freeText: parsed.freeText,
      };
    } catch {
      return null;
    }
  }

  async deleteDraft(draftKey: string): Promise<void> {
    if (!isPlatformBrowser(this.platformId) || typeof indexedDB === 'undefined') return;
    const db = await this.openIdb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readwrite');
      tx.objectStore(this.storeName).delete(draftKey);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}
