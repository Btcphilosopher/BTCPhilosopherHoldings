import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { OfflineDraftService, type EncryptedOfflineDraft } from './offline-draft';
import type {
  Allergy,
  AllergyAssertionStatus,
  AuditEvent,
  AuthSession,
  ClinicalNote,
  ClinicalTask,
  Clinician,
  DiagnosticResult,
  DuplicateCandidate,
  Encounter,
  MedicationConceptType,
  MedicationEntry,
  NoteSection,
  NoteTemplateType,
  Observation,
  OutboxEvent,
  Patient,
  PatientOverview,
  ResultReviewState,
  TaskStatus,
  TaskType,
  WorklistResponse,
} from '../../shared/clinical-types';

export type NavSection =
  | 'today'
  | 'patients'
  | 'consultations'
  | 'notes'
  | 'observations'
  | 'results'
  | 'medications'
  | 'care-plans'
  | 'tasks'
  | 'documents'
  | 'admin';

export type SidePanelMode = 'closed' | 'results' | 'medications' | 'previous_notes';

export interface PendingNavGuard {
  targetNav: NavSection;
  targetPatientId?: string;
}

@Injectable({ providedIn: 'root' })
export class ClinicalStore {
  private http = inject(HttpClient);
  private doc = inject(DOCUMENT);
  private platformId = inject(PLATFORM_ID);
  private offlineDrafts = inject(OfflineDraftService);

  // Authentication kept strictly in JS memory
  readonly session = signal<AuthSession | null>(null);
  readonly clinicians = signal<Clinician[]>([]);
  readonly oidcInfo = signal<{ adapter: string; issuer: string } | null>(null);

  // Navigation & Workspace State
  readonly activeNav = signal<NavSection>('today');
  readonly sidePanelMode = signal<SidePanelMode>('closed');
  readonly mobileSidebarOpen = signal<boolean>(false);

  // Clinical Data Signals
  readonly worklist = signal<WorklistResponse | null>(null);
  readonly searchResults = signal<{ patients: Patient[]; crossOrgCount: number }>({
    patients: [],
    crossOrgCount: 0,
  });
  readonly selectedPatientId = signal<string | null>(null);
  readonly patientOverview = signal<PatientOverview | null>(null);
  readonly highlightedRecordId = signal<string | null>(null);

  // Status & Reliability Signals
  readonly loading = signal<boolean>(false);
  readonly errorState = signal<{ code: string; message: string; deniedPatientId?: string } | null>(null);
  readonly toastMessage = signal<string | null>(null);
  readonly isOfflineSimulated = signal<boolean>(false);
  readonly lastSyncedAt = signal<string | null>(null);
  readonly cachedDraftRecords = signal<EncryptedOfflineDraft[]>([]);

  // Accessibility & Timezone Controls
  readonly timezoneMode = signal<'Europe/London' | 'UTC'>('Europe/London');
  readonly textScale = signal<'standard' | 'comfortable' | 'large'>('comfortable');

  // Unsaved Draft Guard (prevents clinical content leaking across patients!)
  readonly dirtyDraft = signal<{ isDirty: boolean; noteId: string | null; title: string }>({
    isDirty: false,
    noteId: null,
    title: '',
  });
  readonly pendingNavGuard = signal<PendingNavGuard | null>(null);

  // Admin & Interop Signals
  readonly auditData = signal<{
    events: AuditEvent[];
    chainVerified: boolean;
    verifiedCount: number;
    brokenAtSeqId: number | null;
  } | null>(null);
  readonly outboxEvents = signal<OutboxEvent[]>([]);
  readonly settings = signal<Record<string, unknown>>({});

  readonly activePatient = computed(() => this.patientOverview()?.patient ?? null);
  readonly activeEncounter = computed(() => this.patientOverview()?.activeEncounter ?? null);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.applyTextScale('comfortable');
      void this.refreshCachedDraftMetadata();
    }
  }

  private authHeaders(): HttpHeaders {
    const token = this.session()?.token;
    return token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders();
  }

  private showToast(msg: string): void {
    this.toastMessage.set(msg);
    setTimeout(() => {
      if (this.toastMessage() === msg) {
        this.toastMessage.set(null);
      }
    }, 4500);
  }

  private handleError(err: unknown, contextPatientId?: string): never {
    if (err instanceof HttpErrorResponse) {
      const apiErr = err.error?.error;
      const code = apiErr?.code ?? `HTTP_${err.status}`;
      const message = apiErr?.message ?? err.message ?? 'Request failed';
      if (err.status === 401) {
        this.session.set(null);
      }
      this.errorState.set({
        code,
        message,
        deniedPatientId: err.status === 403 ? contextPatientId : undefined,
      });
    } else {
      this.errorState.set({ code: 'NETWORK_ERROR', message: 'Unable to reach clinical API server' });
    }
    throw err;
  }

  formatDateTime(iso: string | null | undefined): string {
    if (!iso) return 'Not recorded';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    const tz = this.timezoneMode();
    return (
      new Intl.DateTimeFormat('en-GB', {
        timeZone: tz,
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      }).format(d) + (tz === 'UTC' ? ' UTC' : ' UK')
    );
  }

  applyTextScale(scale: 'standard' | 'comfortable' | 'large'): void {
    this.textScale.set(scale);
    const html = this.doc.documentElement;
    html.classList.remove('text-scale-standard', 'text-scale-comfortable', 'text-scale-large');
    html.classList.add(`text-scale-${scale}`);
  }

  async loadAuthProviders(): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.get<{ oidcAdapter: string; issuer: string; clinicians: Clinician[] }>('/api/auth/providers')
      );
      this.clinicians.set(res.clinicians);
      this.oidcInfo.set({ adapter: res.oidcAdapter, issuer: res.issuer });
    } catch (err) {
      this.handleError(err);
    }
  }

  async signIn(clinicianId: string): Promise<void> {
    this.loading.set(true);
    this.errorState.set(null);
    try {
      const session = await firstValueFrom(
        this.http.post<AuthSession>('/api/auth/login', { clinicianId })
      );
      this.session.set(session);
      this.selectedPatientId.set(null);
      this.patientOverview.set(null);
      this.activeNav.set('today');
      await this.loadWorklist();
      await this.loadPatients('');
      await this.loadSettings();
    } catch (err) {
      this.handleError(err);
    } finally {
      this.loading.set(false);
    }
  }

  async signOut(): Promise<void> {
    const token = this.session()?.token;
    if (token) {
      try {
        await firstValueFrom(
          this.http.post('/api/auth/logout', {}, { headers: this.authHeaders() })
        );
      } catch {
        // Ignore on signout
      }
    }
    this.session.set(null);
    this.selectedPatientId.set(null);
    this.patientOverview.set(null);
    this.worklist.set(null);
    this.dirtyDraft.set({ isDirty: false, noteId: null, title: '' });
  }

  async requestBreakGlass(patientId: string, reason: string): Promise<void> {
    this.loading.set(true);
    this.errorState.set(null);
    try {
      const updated = await firstValueFrom(
        this.http.post<AuthSession>(
          '/api/auth/break-glass',
          { patientId, reason },
          { headers: this.authHeaders() }
        )
      );
      this.session.set(updated);
      this.showToast('Emergency break-glass access granted for 30 minutes and logged for IG review.');
      await this.openPatient(patientId, 'today', true);
    } catch (err) {
      this.handleError(err, patientId);
    } finally {
      this.loading.set(false);
    }
  }

  navigate(targetNav: NavSection, targetPatientId?: string): void {
    const switchingPatient =
      targetPatientId !== undefined &&
      this.selectedPatientId() !== null &&
      targetPatientId !== this.selectedPatientId();

    if (this.dirtyDraft().isDirty && switchingPatient) {
      this.pendingNavGuard.set({ targetNav, targetPatientId });
      return;
    }

    this.mobileSidebarOpen.set(false);
    if (targetPatientId) {
      void this.openPatient(targetPatientId, targetNav);
    } else {
      this.activeNav.set(targetNav);
      if (targetNav === 'today') void this.loadWorklist();
      if (targetNav === 'admin') {
        void this.loadAuditEvents();
        void this.loadOutbox();
        void this.loadSettings();
      }
    }
  }

  confirmDiscardAndNavigate(): void {
    const pending = this.pendingNavGuard();
    this.dirtyDraft.set({ isDirty: false, noteId: null, title: '' });
    this.pendingNavGuard.set(null);
    if (!pending) return;
    if (pending.targetPatientId) {
      void this.openPatient(pending.targetPatientId, pending.targetNav, true);
    } else {
      this.activeNav.set(pending.targetNav);
    }
  }

  cancelPendingNavigation(): void {
    this.pendingNavGuard.set(null);
  }

  async loadWorklist(): Promise<void> {
    if (!this.session() || this.isOfflineSimulated()) return;
    this.loading.set(true);
    this.errorState.set(null);
    try {
      const wl = await firstValueFrom(
        this.http.get<WorklistResponse>('/api/worklist', { headers: this.authHeaders() })
      );
      this.worklist.set(wl);
      this.lastSyncedAt.set(new Date().toISOString());
    } catch (err) {
      this.handleError(err);
    } finally {
      this.loading.set(false);
    }
  }

  async loadPatients(query: string): Promise<void> {
    if (!this.session() || this.isOfflineSimulated()) return;
    try {
      const res = await firstValueFrom(
        this.http.get<{ patients: Patient[]; crossOrgCount: number }>('/api/patients', {
          headers: this.authHeaders(),
          params: { q: query },
        })
      );
      this.searchResults.set(res);
    } catch (err) {
      this.handleError(err);
    }
  }

  async openPatient(patientId: string, nav: NavSection = 'today', bypassGuard = false): Promise<void> {
    if (!bypassGuard && this.dirtyDraft().isDirty && this.selectedPatientId() && this.selectedPatientId() !== patientId) {
      this.pendingNavGuard.set({ targetNav: nav, targetPatientId: patientId });
      return;
    }
    this.loading.set(true);
    this.errorState.set(null);
    try {
      const overview = await firstValueFrom(
        this.http.get<PatientOverview>(`/api/patients/${patientId}/overview`, {
          headers: this.authHeaders(),
        })
      );
      this.selectedPatientId.set(patientId);
      this.patientOverview.set(overview);
      this.activeNav.set(nav);
      this.lastSyncedAt.set(new Date().toISOString());
    } catch (err) {
      this.handleError(err, patientId);
    } finally {
      this.loading.set(false);
    }
  }

  openSourceRecord(nav: NavSection, recordId: string): void {
    this.highlightedRecordId.set(recordId);
    this.activeNav.set(nav);
  }

  async registerPatient(payload: Record<string, unknown>): Promise<{ patient: Patient; duplicateWarnings: DuplicateCandidate[] }> {
    const res = await firstValueFrom(
      this.http.post<{ patient: Patient; duplicateWarnings: DuplicateCandidate[] }>(
        '/api/patients',
        payload,
        { headers: this.authHeaders() }
      )
    );
    await this.loadPatients('');
    this.showToast(`Registered ${res.patient.givenNames} ${res.patient.familyName} (${res.patient.internalMrn})`);
    return res;
  }

  async mergePatients(sourcePatientId: string, targetPatientId: string, justification: string): Promise<void> {
    const overview = await firstValueFrom(
      this.http.post<PatientOverview>(
        '/api/patients/merge',
        { sourcePatientId, targetPatientId, justification },
        { headers: this.authHeaders() }
      )
    );
    this.patientOverview.set(overview);
    await this.loadPatients('');
    this.showToast('Authorised patient merge completed; identifiers and audit provenance preserved.');
  }

  async createEncounter(
    patientId: string,
    payload: {
      encounterType: Encounter['encounterType'];
      location: string;
      wardOrClinic: string;
      presentingConcern: string;
    }
  ): Promise<void> {
    await firstValueFrom(
      this.http.post<Encounter>(`/api/patients/${patientId}/encounters`, payload, {
        headers: this.authHeaders(),
      })
    );
    await this.openPatient(patientId, 'consultations');
    this.showToast('Encounter confirmed and linked to active patient banner.');
  }

  async createDraftNote(
    patientId: string,
    payload: {
      encounterId: string | null;
      templateType: NoteTemplateType;
      title: string;
      sections: NoteSection[];
      freeText: string;
      copiedCitations?: ClinicalNote['copiedCitations'];
    }
  ): Promise<ClinicalNote> {
    const note = await firstValueFrom(
      this.http.post<ClinicalNote>(`/api/patients/${patientId}/notes`, payload, {
        headers: this.authHeaders(),
      })
    );
    await this.openPatient(patientId, 'notes');
    this.showToast('Draft note created.');
    return note;
  }

  async saveDraftNote(
    noteId: string,
    payload: {
      expectedVersion: number;
      title: string;
      sections: NoteSection[];
      freeText: string;
      copiedCitations?: ClinicalNote['copiedCitations'];
      forceConflictResolution?: boolean;
    }
  ): Promise<{ note?: ClinicalNote; conflictServerNote?: ClinicalNote; savedOffline?: boolean }> {
    const patientId = this.selectedPatientId();
    if (this.isOfflineSimulated() && patientId) {
      await this.offlineDrafts.saveEncryptedDraft({
        draftKey: `note:${noteId}`,
        patientId,
        noteId,
        baseVersion: payload.expectedVersion,
        title: payload.title,
        sections: payload.sections,
        freeText: payload.freeText,
      });
      await this.refreshCachedDraftMetadata();
      this.showToast('Offline mode active: draft encrypted locally in browser IndexedDB.');
      return { savedOffline: true };
    }

    try {
      const note = await firstValueFrom(
        this.http.put<ClinicalNote>(`/api/notes/${noteId}/draft`, payload, {
          headers: this.authHeaders(),
        })
      );
      this.dirtyDraft.set({ isDirty: false, noteId, title: note.title });
      this.lastSyncedAt.set(new Date().toISOString());
      if (patientId) await this.openPatient(patientId, 'notes');
      return { note };
    } catch (err) {
      if (err instanceof HttpErrorResponse && err.status === 409 && err.error?.error?.code === 'DRAFT_VERSION_CONFLICT') {
        const serverNote = err.error.error.details?.serverNote as ClinicalNote | undefined;
        return { conflictServerNote: serverNote };
      }
      throw err;
    }
  }

  async signNote(
    noteId: string,
    expectedVersion: number,
    patientConfirmed: boolean,
    idempotencyKey: string
  ): Promise<ClinicalNote> {
    if (this.isOfflineSimulated()) {
      throw new Error('Server validation required before signing. Disable simulated offline mode to sign.');
    }
    const note = await firstValueFrom(
      this.http.post<ClinicalNote>(
        `/api/notes/${noteId}/sign`,
        { expectedVersion, patientConfirmed, idempotencyKey },
        { headers: this.authHeaders() }
      )
    );
    this.dirtyDraft.set({ isDirty: false, noteId, title: note.title });
    const pid = this.selectedPatientId();
    if (pid) await this.openPatient(pid, 'notes');
    this.showToast('Clinical note atomically signed and locked.');
    return note;
  }

  async addNoteAmendment(noteId: string, addendumText: string, reason: string): Promise<ClinicalNote> {
    const note = await firstValueFrom(
      this.http.post<ClinicalNote>(
        `/api/notes/${noteId}/amendments`,
        { addendumText, reason },
        { headers: this.authHeaders() }
      )
    );
    const pid = this.selectedPatientId();
    if (pid) await this.openPatient(pid, 'notes');
    this.showToast('Linked addendum signed and attached to original note.');
    return note;
  }

  async markNoteEnteredInError(noteId: string, reason: string): Promise<void> {
    await firstValueFrom(
      this.http.post<ClinicalNote>(
        `/api/notes/${noteId}/entered-in-error`,
        { reason },
        { headers: this.authHeaders() }
      )
    );
    const pid = this.selectedPatientId();
    if (pid) await this.openPatient(pid, 'notes');
    this.showToast('Note marked Entered-in-Error with original record preserved.');
  }

  async recordObservation(patientId: string, payload: Record<string, unknown>): Promise<void> {
    await firstValueFrom(
      this.http.post<Observation>(`/api/patients/${patientId}/observations`, payload, {
        headers: this.authHeaders(),
      })
    );
    await this.openPatient(patientId, 'observations');
    this.showToast('Clinical observation recorded.');
  }

  async transitionResultState(
    resultId: string,
    nextState: ResultReviewState,
    followUpTitle?: string
  ): Promise<void> {
    await firstValueFrom(
      this.http.post<DiagnosticResult>(
        `/api/results/${resultId}/state`,
        { nextState, followUpTitle },
        { headers: this.authHeaders() }
      )
    );
    const pid = this.selectedPatientId();
    if (pid) await this.openPatient(pid, 'results');
    await this.loadWorklist();
    this.showToast(`Result state updated to ${nextState.replaceAll('_', ' ')}.`);
  }

  async simulateCorrectedResult(
    supersedesResultId: string,
    newValueText: string,
    abnormalFlag: DiagnosticResult['abnormalFlag'],
    correctionReason: string
  ): Promise<void> {
    await firstValueFrom(
      this.http.post<DiagnosticResult>(
        `/api/results/${supersedesResultId}/simulate-correction`,
        { newValueText, abnormalFlag, correctionReason },
        { headers: this.authHeaders() }
      )
    );
    const pid = this.selectedPatientId();
    if (pid) await this.openPatient(pid, 'results');
    await this.loadWorklist();
    this.showToast('Corrected diagnostic result ingested, linked to prior version, and review task triggered.');
  }

  async addMedication(
    patientId: string,
    payload: {
      encounterId: string | null;
      conceptType: MedicationConceptType;
      drugName: string;
      dmdCode: string;
      strength: string;
      dose: string;
      route: string;
      frequency: string;
      source: string;
      requestSimulatedPrescription: boolean;
    }
  ): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{ medication: MedicationEntry; simulationNotice: string | null }>(
        `/api/patients/${patientId}/medications`,
        payload,
        { headers: this.authHeaders() }
      )
    );
    await this.openPatient(patientId, 'medications');
    this.showToast(res.simulationNotice ?? 'Medication record documented.');
  }

  async updateAllergyAssertion(
    patientId: string,
    status: AllergyAssertionStatus,
    newAllergy?: {
      substance: string;
      code: string;
      reaction: string;
      severity: Allergy['severity'];
      verificationStatus: Allergy['verificationStatus'];
      provenance: string;
    }
  ): Promise<void> {
    await firstValueFrom(
      this.http.post(
        `/api/patients/${patientId}/allergy-assertion`,
        { status, newAllergy },
        { headers: this.authHeaders() }
      )
    );
    await this.openPatient(patientId, 'medications');
    this.showToast(`Allergy assertion updated: ${status.replaceAll('_', ' ')}.`);
  }

  async createTask(
    patientId: string,
    payload: {
      encounterId: string | null;
      taskType: TaskType;
      title: string;
      description: string;
      assignedTeam: string;
      priority: ClinicalTask['priority'];
      dueAt: string;
      patientSummaryText?: string;
    }
  ): Promise<void> {
    await firstValueFrom(
      this.http.post<ClinicalTask>(`/api/patients/${patientId}/tasks`, payload, {
        headers: this.authHeaders(),
      })
    );
    await this.openPatient(patientId, 'tasks');
    await this.loadWorklist();
    this.showToast('Follow-up / coordination task created.');
  }

  async transitionTask(
    taskId: string,
    nextStatus: TaskStatus,
    completionEvidence?: string,
    approvePatientSummary?: string
  ): Promise<void> {
    await firstValueFrom(
      this.http.post<ClinicalTask>(
        `/api/tasks/${taskId}/transition`,
        { nextStatus, completionEvidence, approvePatientSummary },
        { headers: this.authHeaders() }
      )
    );
    const pid = this.selectedPatientId();
    if (pid) await this.openPatient(pid, 'tasks');
    await this.loadWorklist();
    this.showToast(`Task updated to ${nextStatus}.`);
  }

  async fetchAttachmentContent(attachmentId: string): Promise<{ filename: string; contentText: string; sha256Hex: string }> {
    const res = await firstValueFrom(
      this.http.get<{ attachment: { filename: string; sha256Hex: string }; contentText: string }>(
        `/api/attachments/${attachmentId}/download`,
        { headers: this.authHeaders() }
      )
    );
    this.showToast('Protected attachment accessed and recorded in audit trail.');
    return {
      filename: res.attachment.filename,
      contentText: res.contentText,
      sha256Hex: res.attachment.sha256Hex,
    };
  }

  async loadAuditEvents(patientId?: string): Promise<void> {
    if (!this.session()) return;
    const res = await firstValueFrom(
      this.http.get<{
        events: AuditEvent[];
        chainVerified: boolean;
        verifiedCount: number;
        brokenAtSeqId: number | null;
      }>('/api/admin/audit', {
        headers: this.authHeaders(),
        params: patientId ? { patientId } : {},
      })
    );
    this.auditData.set(res);
  }

  async loadOutbox(): Promise<void> {
    if (!this.session()) return;
    const res = await firstValueFrom(
      this.http.get<OutboxEvent[]>('/api/admin/outbox', { headers: this.authHeaders() })
    );
    this.outboxEvents.set(res);
  }

  async retryOutbox(outboxId: string, simulateFailure = false): Promise<void> {
    await firstValueFrom(
      this.http.post<OutboxEvent>(
        `/api/admin/outbox/${outboxId}/retry`,
        { simulateFailure },
        { headers: this.authHeaders() }
      )
    );
    await this.loadOutbox();
    this.showToast(simulateFailure ? 'Outbox retry simulated failure recorded.' : 'Outbox event delivered.');
  }

  async loadSettings(): Promise<void> {
    if (!this.session()) return;
    const res = await firstValueFrom(
      this.http.get<Record<string, unknown>>('/api/admin/settings', { headers: this.authHeaders() })
    );
    this.settings.set(res);
  }

  async toggleAiAdapter(enabled: boolean): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<Record<string, unknown>>(
        '/api/admin/settings/ai-adapter',
        { enabled },
        { headers: this.authHeaders() }
      )
    );
    this.settings.set(res);
    this.showToast(`Optional AI drafting adapter ${enabled ? 'enabled' : 'disabled'}.`);
  }

  async generateAiDraftSummary(patientId: string): Promise<{
    draftText: string;
    uncertaintyNotes: string[];
    sourceLinks: { type: string; id: string; label: string }[];
  }> {
    return firstValueFrom(
      this.http.post<{
        draftText: string;
        uncertaintyNotes: string[];
        sourceLinks: { type: string; id: string; label: string }[];
      }>('/api/ai/draft-summary', { patientId }, { headers: this.authHeaders() })
    );
  }

  async fetchFhirBundle(patientId: string): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.get<Record<string, unknown>>(`/api/interop/fhir/Patient/${patientId}/$everything`, {
        headers: this.authHeaders(),
      })
    );
  }

  async exportBackupSnapshot(): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.get<Record<string, unknown>>('/api/admin/backup', {
        headers: this.authHeaders(),
      })
    );
  }

  async refreshCachedDraftMetadata(): Promise<void> {
    const list = await this.offlineDrafts.listEncryptedMetadata();
    this.cachedDraftRecords.set(list);
  }

  async loadAndDecryptOfflineDraft(record: EncryptedOfflineDraft) {
    return this.offlineDrafts.decryptDraft(record);
  }

  async removeOfflineDraft(draftKey: string): Promise<void> {
    await this.offlineDrafts.deleteDraft(draftKey);
    await this.refreshCachedDraftMetadata();
  }
}
