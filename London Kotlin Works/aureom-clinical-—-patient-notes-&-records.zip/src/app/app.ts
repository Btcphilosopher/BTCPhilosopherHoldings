import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore, type NavSection } from './services/clinical-store';
import { SignInComponent } from './components/sign-in';
import { PatientBannerComponent } from './components/patient-banner';
import { WorklistViewComponent } from './components/worklist-view';
import { OverviewViewComponent } from './components/overview-view';
import { PatientsViewComponent } from './components/patients-view';
import { NotesWorkspaceComponent } from './components/notes-workspace';
import { ResultsObsViewComponent } from './components/results-obs-view';
import { MedsAllergiesViewComponent } from './components/meds-allergies-view';
import { TasksDocsViewComponent } from './components/tasks-docs-view';
import { AdminViewComponent } from './components/admin-view';

interface NavItem {
  id: NavSection;
  label: string;
  icon: string;
  requiresPatient?: boolean;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    MatIconModule,
    SignInComponent,
    PatientBannerComponent,
    WorklistViewComponent,
    OverviewViewComponent,
    PatientsViewComponent,
    NotesWorkspaceComponent,
    ResultsObsViewComponent,
    MedsAllergiesViewComponent,
    TasksDocsViewComponent,
    AdminViewComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  host: {
    '(window:keydown)': 'onGlobalKeydown($event)',
  },
})
export class App {
  store = inject(ClinicalStore);

  readonly navItems: NavItem[] = [
    { id: 'today', label: 'Today', icon: 'today' },
    { id: 'patients', label: 'Patients', icon: 'people' },
    { id: 'consultations', label: 'Consultations', icon: 'medical_services', requiresPatient: true },
    { id: 'notes', label: 'Notes', icon: 'edit_note', requiresPatient: true },
    { id: 'observations', label: 'Observations', icon: 'monitor_heart', requiresPatient: true },
    { id: 'results', label: 'Results', icon: 'biotech', requiresPatient: true },
    { id: 'medications', label: 'Medications', icon: 'medication', requiresPatient: true },
    { id: 'care-plans', label: 'Care Plans', icon: 'fact_check', requiresPatient: true },
    { id: 'tasks', label: 'Tasks', icon: 'task_alt', requiresPatient: true },
    { id: 'documents', label: 'Documents', icon: 'description', requiresPatient: true },
    { id: 'admin', label: 'Administration', icon: 'admin_panel_settings' },
  ];

  onGlobalKeydown(event: KeyboardEvent): void {
    if (!this.store.session()) return;
    if (event.altKey && event.key >= '1' && event.key <= '9') {
      const idx = Number(event.key) - 1;
      const item = this.navItems[idx];
      if (item && (!item.requiresPatient || this.store.selectedPatientId())) {
        event.preventDefault();
        this.store.navigate(item.id);
      }
    }
  }
}
