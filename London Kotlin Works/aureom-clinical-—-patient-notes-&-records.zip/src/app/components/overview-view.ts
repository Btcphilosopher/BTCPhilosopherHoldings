import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';

@Component({
  selector: 'app-overview-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (store.patientOverview(); as ov) {
      <div class="space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 class="font-display text-2xl font-bold text-slate-900">Patient Clinical Overview</h1>
            <p class="text-xs text-slate-600 mt-0.5">
              Select any summary entry to inspect its authoritative source record. Conflicting assertions are surfaced explicitly.
            </p>
          </div>
          <div class="flex flex-wrap items-center gap-2">
            <button
              type="button"
              (click)="store.navigate('notes')"
              class="min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
            >
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">edit_note</mat-icon>
              <span>Open Consultation Note</span>
            </button>
          </div>
        </div>

        <!-- Explicit Conflicts & Identity Warnings (never silently merged!) -->
        @if (ov.conflicts.length > 0 || ov.duplicateCandidates.length > 0) {
          <section
            aria-label="Explicit Clinical and Identity Conflicts"
            class="bg-amber-50/70 border border-amber-300 rounded-xl p-5 space-y-3"
          >
            <div class="flex items-center gap-2 text-amber-900">
              <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">report_problem</mat-icon>
              <h2 class="font-display text-sm font-bold">
                Explicit Record Discrepancies &amp; Identity Warnings ({{ ov.conflicts.length }})
              </h2>
            </div>
            <div class="divide-y divide-amber-200/80">
              @for (conf of ov.conflicts; track conf.summary) {
                <div class="py-2.5 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div class="text-amber-950">
                    <span class="font-semibold uppercase tracking-wide mr-2">[{{ conf.type }}]</span>
                    <span>{{ conf.summary }}</span>
                  </div>
                  <button
                    type="button"
                    (click)="openConflictSource(conf.type, conf.recordIds[0])"
                    class="px-3 py-1.5 bg-white border border-amber-300 hover:bg-amber-100 text-amber-950 font-semibold rounded-md whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Inspect Source
                  </button>
                </div>
              }
            </div>
          </section>
        }

        <!-- Presenting Concern & Demographics Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <section class="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <h2 class="font-display text-base font-semibold text-slate-900">Presenting Concern &amp; Active Encounter</h2>
              @if (ov.activeEncounter; as enc) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('consultations', enc.id)"
                  class="text-xs font-semibold text-[#005EB8] hover:underline cursor-pointer"
                >
                  Open Encounter
                </button>
              }
            </div>
            @if (ov.activeEncounter; as enc) {
              <p class="text-sm text-slate-900 leading-relaxed">{{ enc.presentingConcern }}</p>
              <div class="text-xs text-slate-600 flex flex-wrap gap-x-3 gap-y-1 tabular-nums">
                <span>Type: <strong class="text-slate-800">{{ enc.encounterType }}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Clinic: <strong class="text-slate-800">{{ enc.wardOrClinic }}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Occurred: {{ store.formatDateTime(enc.occurredAt) }}</span>
              </div>
            } @else {
              <p class="text-sm text-slate-500">No active encounter on record.</p>
            }
          </section>

          <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <h2 class="font-display text-base font-semibold text-slate-900">GP &amp; Identity Provenance</h2>
              <button
                type="button"
                (click)="store.navigate('patients')"
                class="text-xs font-semibold text-[#005EB8] hover:underline cursor-pointer"
              >
                Identity Details
              </button>
            </div>
            <dl class="space-y-2 text-xs">
              <div class="flex justify-between gap-3">
                <dt class="text-slate-500">GP Practice</dt>
                <dd class="text-slate-900 font-medium text-right">{{ ov.patient.gpPractice.practiceName }}</dd>
              </div>
              <div class="flex justify-between gap-3">
                <dt class="text-slate-500">Named GP</dt>
                <dd class="text-slate-900 text-right">{{ ov.patient.gpPractice.gpName }} ({{ ov.patient.gpPractice.odsCode }})</dd>
              </div>
              <div class="flex justify-between gap-3">
                <dt class="text-slate-500">Address</dt>
                <dd class="text-slate-900 text-right">{{ ov.patient.contact.addressLine1 }}, {{ ov.patient.contact.postcode }}</dd>
              </div>
              <div class="flex justify-between gap-3">
                <dt class="text-slate-500">Telephone</dt>
                <dd class="text-slate-900 font-mono tabular-nums text-right">{{ ov.patient.contact.phone }}</dd>
              </div>
            </dl>
          </section>
        </div>

        <!-- Core Clinical Summary Columns -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Active Problems & Relevant History -->
          <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 class="font-display text-base font-semibold text-slate-900">
                Active Problems &amp; Diagnoses ({{ ov.problems.length }})
              </h2>
            </div>
            @if (ov.problems.length === 0) {
              <p class="text-sm text-slate-500">No problems recorded.</p>
            } @else {
              <div class="divide-y divide-slate-100">
                @for (prob of ov.problems; track prob.id) {
                  <button
                    type="button"
                    (click)="store.openSourceRecord('notes', prob.id)"
                    class="w-full text-left py-2.5 first:pt-0 last:pb-0 hover:bg-slate-50 rounded-md px-1 -mx-1 transition-colors cursor-pointer"
                  >
                    <div class="flex items-baseline justify-between gap-2">
                      <span class="text-sm font-medium text-slate-900">{{ prob.display }}</span>
                      <span class="text-xs font-mono text-slate-500 shrink-0">{{ prob.code }}</span>
                    </div>
                    <div class="text-xs text-slate-600 mt-0.5 flex flex-wrap gap-x-2">
                      <span [class]="prob.verificationStatus === 'provisional' ? 'text-[#B45309] font-semibold' : 'text-[#007F3B] font-medium'">
                        {{ prob.verificationStatus }}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{{ prob.sourceProvenance }}</span>
                    </div>
                    @if (prob.conflictNote) {
                      <div class="text-xs text-[#B45309] mt-1 font-medium">
                        Conflict note: {{ prob.conflictNote }}
                      </div>
                    }
                  </button>
                }
              </div>
            }
          </section>

          <!-- Allergies & Medications -->
          <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 class="font-display text-base font-semibold text-slate-900">Allergies &amp; Medications</h2>
              <button
                type="button"
                (click)="store.navigate('medications')"
                class="text-xs font-semibold text-[#005EB8] hover:underline cursor-pointer"
              >
                Manage &amp; Reconcile
              </button>
            </div>

            <div class="p-3 rounded-lg border"
              [class]="ov.patient.allergyAssertionStatus === 'assessed_with_allergies' ? 'bg-red-50/70 border-red-200' : ov.patient.allergyAssertionStatus === 'no_known_allergies' ? 'bg-emerald-50/70 border-emerald-200' : 'bg-amber-50/70 border-amber-200'">
              <div class="text-xs font-bold text-slate-900">
                @if (ov.patient.allergyAssertionStatus === 'no_known_allergies') {
                  No Known Allergies (Explicitly Documented Assertion)
                } @else if (ov.patient.allergyAssertionStatus === 'not_assessed') {
                  Allergies: Not Assessed — Explicit clinical assessment required
                } @else if (ov.patient.allergyAssertionStatus === 'unavailable') {
                  Allergy History Unavailable
                } @else {
                  Documented Allergies ({{ ov.allergies.length }})
                }
              </div>
              @for (alg of ov.allergies; track alg.id) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('medications', alg.id)"
                  class="mt-1.5 block w-full text-left text-xs text-red-950 hover:underline cursor-pointer"
                >
                  <strong>{{ alg.substance }}</strong> — {{ alg.reaction }} ({{ alg.severity }}, {{ alg.verificationStatus }})
                </button>
              }
            </div>

            <div class="divide-y divide-slate-100">
              @for (med of ov.medications; track med.id) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('medications', med.id)"
                  class="w-full text-left py-2 first:pt-0 last:pb-0 hover:bg-slate-50 rounded-md px-1 -mx-1 cursor-pointer"
                >
                  <div class="flex items-baseline justify-between gap-2">
                    <span class="text-sm font-medium text-slate-900">{{ med.drugName }} {{ med.dose }}</span>
                    <span class="text-xs font-medium"
                      [class]="med.reconciliationStatus === 'discrepancy' ? 'text-[#B45309]' : 'text-slate-600'">
                      {{ med.conceptType.replace('_', ' ') }}
                    </span>
                  </div>
                  <div class="text-xs text-slate-600">
                    {{ med.route }} · {{ med.frequency }} · Source: {{ med.source }}
                  </div>
                </button>
              }
            </div>
          </section>

          <!-- Recent Observations & Diagnostic Results -->
          <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 class="font-display text-base font-semibold text-slate-900">Recent Observations &amp; Results</h2>
              <button
                type="button"
                (click)="store.navigate('results')"
                class="text-xs font-semibold text-[#005EB8] hover:underline cursor-pointer"
              >
                Review All Results
              </button>
            </div>
            <div class="divide-y divide-slate-100">
              @for (res of ov.results; track res.id) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('results', res.id)"
                  class="w-full text-left py-2.5 hover:bg-slate-50 rounded-md px-1 -mx-1 cursor-pointer"
                >
                  <div class="flex items-baseline justify-between gap-2">
                    <span class="text-sm font-medium text-slate-900">{{ res.orderName }}</span>
                    <span class="text-sm font-mono font-bold tabular-nums"
                      [class]="res.abnormalFlag === 'critical' ? 'text-[#B91C1C]' : res.abnormalFlag === 'high' ? 'text-[#B45309]' : 'text-slate-900'">
                      {{ res.valueText }} {{ res.unit }}
                    </span>
                  </div>
                  <div class="text-xs text-slate-600">
                    Status: <strong>{{ res.resultStatus }}</strong> · Review: <strong>{{ res.reviewState }}</strong> · Ref: {{ res.referenceInterval }}
                  </div>
                </button>
              }
              @for (obs of ov.observations.slice(0, 4); track obs.id) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('observations', obs.id)"
                  class="w-full text-left py-2 hover:bg-slate-50 rounded-md px-1 -mx-1 cursor-pointer"
                >
                  <div class="flex items-baseline justify-between gap-2 text-xs">
                    <span class="font-medium text-slate-800">{{ obs.display }}</span>
                    <span class="font-mono tabular-nums text-slate-900 font-semibold">{{ obs.valueText }} {{ obs.unit }}</span>
                  </div>
                  <div class="text-xs text-slate-500 tabular-nums">
                    Observed {{ store.formatDateTime(obs.observedAt) }} · {{ obs.attribution }}
                  </div>
                </button>
              }
            </div>
          </section>

          <!-- Latest Notes, Care Plans & Outstanding Actions -->
          <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 class="font-display text-base font-semibold text-slate-900">Notes, Care Plans &amp; Actions</h2>
              <button
                type="button"
                (click)="store.navigate('tasks')"
                class="text-xs font-semibold text-[#005EB8] hover:underline cursor-pointer"
              >
                All Tasks
              </button>
            </div>

            <div class="space-y-2">
              <h3 class="text-xs font-semibold text-slate-500 uppercase tracking-wide">Latest Clinical Notes</h3>
              @for (note of ov.notes.slice(0, 3); track note.id) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('notes', note.id)"
                  class="w-full text-left p-2.5 border border-slate-200 hover:border-[#005EB8] rounded-lg transition-colors cursor-pointer"
                >
                  <div class="flex items-baseline justify-between gap-2">
                    <span class="text-sm font-semibold text-slate-900">{{ note.title }}</span>
                    <span class="text-xs font-semibold"
                      [class]="note.status === 'signed' || note.status === 'amended' ? 'text-[#007F3B]' : note.status === 'draft' ? 'text-[#B45309]' : 'text-red-700'">
                      {{ note.status }} (v{{ note.version }})
                    </span>
                  </div>
                  <div class="text-xs text-slate-600 mt-0.5 tabular-nums">
                    {{ note.templateType }} · {{ note.authorName }} · Updated {{ store.formatDateTime(note.updatedAt) }}
                  </div>
                </button>
              }
            </div>

            <div class="space-y-2">
              <h3 class="text-xs font-semibold text-slate-500 uppercase tracking-wide">Active Care Plans &amp; Tasks</h3>
              @for (cp of ov.carePlans; track cp.id) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('care-plans', cp.id)"
                  class="w-full text-left text-xs p-2.5 bg-slate-50 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  <div class="font-semibold text-slate-900">{{ cp.title }}</div>
                  <div class="text-slate-600 mt-0.5">Review due {{ cp.reviewDate }} · {{ cp.goals.length }} goal(s)</div>
                </button>
              }
              @for (task of ov.tasks; track task.id) {
                <button
                  type="button"
                  (click)="store.openSourceRecord('tasks', task.id)"
                  class="w-full text-left text-xs p-2 border border-slate-200 hover:border-[#005EB8] rounded-lg cursor-pointer flex items-center justify-between gap-2"
                >
                  <span class="font-medium text-slate-900 truncate">{{ task.title }}</span>
                  <span class="text-slate-600 shrink-0">{{ task.status }}</span>
                </button>
              }
            </div>
          </section>
        </div>
      </div>
    } @else {
      <div class="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
        <h2 class="font-display text-lg font-semibold text-slate-900">No Patient Selected</h2>
        <p class="text-sm text-slate-600">Select a patient from Today's Worklist or Patients search to review their clinical record.</p>
        <button
          type="button"
          (click)="store.navigate('patients')"
          class="min-h-[40px] px-4 py-2 bg-[#005EB8] text-white text-xs font-semibold rounded-lg cursor-pointer"
        >
          Browse Patients
        </button>
      </div>
    }
  `,
})
export class OverviewViewComponent {
  store = inject(ClinicalStore);

  openConflictSource(type: 'problem' | 'medication' | 'identity', recordId: string): void {
    if (type === 'medication') this.store.openSourceRecord('medications', recordId);
    else if (type === 'identity') this.store.openSourceRecord('patients', recordId);
    else this.store.openSourceRecord('notes', recordId);
  }
}
