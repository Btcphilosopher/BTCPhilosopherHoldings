import { ChangeDetectionStrategy, Component, OnDestroy, effect, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';
import type { ClinicalNote, CopiedCitation, NoteSection, NoteTemplateType } from '../../shared/clinical-types';

const TEMPLATE_SECTIONS: Record<NoteTemplateType, { key: string; label: string }[]> = {
  consultation: [
    { key: 'presenting', label: 'Presenting Concern & History' },
    { key: 'examination', label: 'Examination & Observations' },
    { key: 'assessment', label: 'Clinical Impression' },
    { key: 'plan', label: 'Management & Follow-up Plan' },
  ],
  admission: [
    { key: 'hpc', label: 'History of Presenting Complaint' },
    { key: 'pmh', label: 'Past Medical & Drug History' },
    { key: 'exam', label: 'Admission Examination' },
    { key: 'plan', label: 'Initial Management & Escalation Plan' },
  ],
  ward_round: [
    { key: 'interval', label: '24-Hour Interval Events' },
    { key: 'review', label: 'Observations, Fluids & Pathology Review' },
    { key: 'plan', label: 'Daily Ward Plan & Discharge Readiness' },
  ],
  progress: [
    { key: 'update', label: 'Clinical Progress Update' },
    { key: 'plan', label: 'Ongoing Plan' },
  ],
  procedure: [
    { key: 'indication', label: 'Indication & Consent' },
    { key: 'technique', label: 'Procedure Details & Findings' },
    { key: 'postop', label: 'Post-Procedure Instructions' },
  ],
  discharge: [
    { key: 'diagnosis', label: 'Primary & Secondary Diagnoses' },
    { key: 'summary', label: 'Hospital Course Summary' },
    { key: 'gp_actions', label: 'GP Actions & Medication Changes' },
  ],
  handover: [
    { key: 'situation', label: 'Situation & Background' },
    { key: 'assessment', label: 'Assessment & Pending Risks' },
    { key: 'recommendation', label: 'Specific Handover Actions' },
  ],
};

@Component({
  selector: 'app-notes-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.patientOverview(); as ov) {
      <div class="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <!-- Left Note List & New Note Template Picker -->
        <aside class="xl:col-span-4 bg-white border border-slate-200 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <h2 class="font-display text-base font-semibold text-slate-900">Clinical Notes ({{ ov.notes.length }})</h2>
          </div>

          <form [formGroup]="newNoteForm" (ngSubmit)="createNote()" class="space-y-2.5 bg-slate-50 border border-slate-200 rounded-lg p-3">
            <label for="template-select" class="block text-xs font-semibold text-slate-700">New Note Template</label>
            <select
              id="template-select"
              formControlName="templateType"
              class="w-full min-h-[38px] px-2.5 border border-slate-300 rounded-lg text-xs bg-white"
            >
              <option value="consultation">Consultation Note</option>
              <option value="admission">Admission Clerking</option>
              <option value="ward_round">Ward Round Note</option>
              <option value="progress">Progress Note</option>
              <option value="procedure">Procedure Note</option>
              <option value="discharge">Discharge Summary</option>
              <option value="handover">Clinical Handover</option>
            </select>
            <button
              type="submit"
              class="w-full min-h-[38px] px-3 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">add</mat-icon>
              <span>Create Draft Note</span>
            </button>
          </form>

          <div class="divide-y divide-slate-100">
            @for (n of ov.notes; track n.id) {
              <button
                type="button"
                (click)="selectNote(n)"
                class="w-full text-left p-3 rounded-lg transition-colors cursor-pointer"
                [class]="selectedNote()?.id === n.id ? 'bg-[#005EB8]/8 border border-[#005EB8]/40' : 'hover:bg-slate-50'"
              >
                <div class="flex items-baseline justify-between gap-2">
                  <span class="text-xs font-semibold text-slate-900 truncate">{{ n.title }}</span>
                  <span class="text-[11px] font-semibold shrink-0"
                    [class]="n.status === 'signed' || n.status === 'amended' ? 'text-[#007F3B]' : n.status === 'draft' ? 'text-[#B45309]' : 'text-red-700'">
                    {{ n.status }}
                  </span>
                </div>
                <div class="text-[11px] text-slate-500 mt-1 tabular-nums">
                  v{{ n.version }} · {{ n.templateType }} · {{ store.formatDateTime(n.updatedAt) }}
                </div>
              </button>
            }
          </div>
        </aside>

        <!-- Main Note Editor / Viewer -->
        <section class="xl:col-span-8 bg-white border border-slate-200 rounded-xl p-5 space-y-5">
          @if (selectedNote(); as note) {
            <!-- Header & Status -->
            <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-slate-200 pb-4">
              <div class="space-y-1">
                <div class="flex flex-wrap items-center gap-2 text-xs">
                  <span class="font-semibold text-[#005EB8]">{{ note.templateType.replace('_', ' ').toUpperCase() }}</span>
                  <span class="text-slate-400">·</span>
                  <span class="font-mono tabular-nums text-slate-700">Version {{ note.version }}</span>
                  <span class="text-slate-400">·</span>
                  <span class="font-semibold"
                    [class]="note.status === 'signed' || note.status === 'amended' ? 'text-[#007F3B]' : note.status === 'draft' ? 'text-[#B45309]' : 'text-red-700'">
                    Status: {{ note.status.replaceAll('_', ' ') }}
                  </span>
                </div>
                <h2 class="font-display text-xl font-bold text-slate-900">{{ note.title }}</h2>
                <p class="text-xs text-slate-600 tabular-nums">
                  Author: {{ note.authorName }} · Last saved: {{ lastAutosaveLabel() ?? store.formatDateTime(note.updatedAt) }}
                </p>
              </div>

              <div class="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  (click)="showHistoryDrawer.set(!showHistoryDrawer())"
                  class="min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">history</mat-icon>
                  <span>History ({{ note.revisions?.length ?? 0 }})</span>
                </button>
              </div>
            </div>

            <!-- Optimistic Concurrency Conflict Resolution Panel -->
            @if (conflictServerNote(); as serverNote) {
              <div role="alert" class="bg-amber-50 border border-amber-400 rounded-xl p-4 space-y-3">
                <div class="flex items-center gap-2 text-amber-950 font-display font-bold text-sm">
                  <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">sync_problem</mat-icon>
                  <span>Concurrent Edit Conflict Detected (Optimistic Concurrency Control)</span>
                </div>
                <p class="text-xs text-amber-900">
                  Another clinician or session updated this draft to <strong>v{{ serverNote.version }}</strong> while your editor held <strong>v{{ note.version }}</strong>. Aureom Clinical never silently overwrites another clinician's work.
                </p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div class="bg-white border border-amber-200 rounded-lg p-3 space-y-1">
                    <div class="font-semibold text-slate-900">Server Version (v{{ serverNote.version }} · {{ serverNote.authorName }})</div>
                    <p class="text-slate-700 whitespace-pre-wrap">{{ serverNote.freeText || serverNote.sections[0]?.content }}</p>
                  </div>
                  <div class="bg-white border border-amber-200 rounded-lg p-3 space-y-1">
                    <div class="font-semibold text-slate-900">Your Unsaved Local Draft (based on v{{ note.version }})</div>
                    <p class="text-slate-700 whitespace-pre-wrap">{{ draftForm.controls.freeText.value || sectionValues()[0]?.content }}</p>
                  </div>
                </div>
                <div class="flex flex-wrap gap-2">
                  <button
                    type="button"
                    (click)="acceptServerVersion(serverNote)"
                    class="min-h-[38px] px-3.5 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-900 text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    Accept Server Version (Discard Mine)
                  </button>
                  <button
                    type="button"
                    (click)="mergeAndSaveConflict(serverNote)"
                    class="min-h-[38px] px-3.5 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    Append My Edits Onto Server Version &amp; Save
                  </button>
                </div>
              </div>
            }

            <!-- DRAFT MODE EDITOR -->
            @if (note.status === 'draft') {
              <div class="space-y-4">
                <!-- Draft Action Toolbar -->
                <div class="flex flex-wrap items-center justify-between gap-2 bg-slate-50 border border-slate-200 rounded-lg p-3">
                  <div class="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      (click)="saveDraft(false)"
                      class="min-h-[38px] px-3.5 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-900 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">save</mat-icon>
                      <span>Save Draft</span>
                    </button>
                    <button
                      type="button"
                      (click)="citeLatestResult()"
                      class="min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 text-xs font-medium rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">format_quote</mat-icon>
                      <span>Cite Corrected Result</span>
                    </button>
                    <button
                      type="button"
                      (click)="simulateConcurrentEdit()"
                      class="min-h-[38px] px-3 py-1.5 bg-white border border-amber-300 hover:bg-amber-50 text-amber-900 text-xs font-medium rounded-lg cursor-pointer"
                    >
                      Simulate Concurrent Edit Conflict
                    </button>
                  </div>

                  <div class="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      (click)="requestAiSummary()"
                      class="min-h-[38px] px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-medium rounded-lg cursor-pointer"
                    >
                      Optional AI Draft Assist
                    </button>
                    <button
                      type="button"
                      (click)="openSignPreview()"
                      class="min-h-[38px] px-4 py-1.5 bg-[#007F3B] hover:bg-[#00632E] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">verified</mat-icon>
                      <span>Preview &amp; Sign</span>
                    </button>
                  </div>
                </div>

                @if (aiDraftBox(); as aiBox) {
                  <div class="bg-slate-50 border border-[#005EB8]/40 rounded-xl p-4 space-y-2.5">
                    <div class="flex items-center justify-between">
                      <span class="text-xs font-bold text-[#003087]">Optional AI Draft Suggestion (Unaccepted — Separate From Record)</span>
                      <button type="button" (click)="aiDraftBox.set(null)" class="text-xs text-slate-600 hover:underline cursor-pointer">Dismiss</button>
                    </div>
                    <pre class="text-xs text-slate-800 whitespace-pre-wrap font-sans">{{ aiBox.draftText }}</pre>
                    <div class="text-[11px] text-amber-900 space-y-0.5">
                      @for (u of aiBox.uncertaintyNotes; track u) {
                        <div>• {{ u }}</div>
                      }
                    </div>
                    <button
                      type="button"
                      (click)="acceptAiDraftIntoFreeText(aiBox.draftText)"
                      class="min-h-[36px] px-3 py-1.5 bg-[#005EB8] text-white text-xs font-semibold rounded-lg cursor-pointer"
                    >
                      Accept Suggestion Into Draft (Review Required)
                    </button>
                  </div>
                }

                @if (aiErrorNotice()) {
                  <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                    {{ aiErrorNotice() }}
                  </div>
                }

                <form [formGroup]="draftForm" class="space-y-4">
                  <div>
                    <label for="note-title-input" class="block text-xs font-semibold text-slate-700 mb-1">Note Title</label>
                    <input
                      id="note-title-input"
                      formControlName="title"
                      (input)="markDirty()"
                      class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm font-medium"
                    />
                  </div>

                  @for (sec of sectionValues(); track sec.key; let idx = $index) {
                    <div>
                      <label [attr.for]="'note-sec-' + sec.key" class="block text-xs font-semibold text-slate-700 mb-1">{{ sec.label }}</label>
                      <textarea
                        [id]="'note-sec-' + sec.key"
                        rows="3"
                        [value]="sec.content"
                        (input)="updateSection(idx, $any($event.target).value)"
                        class="w-full p-3 border border-slate-300 rounded-lg text-sm text-slate-900 leading-relaxed focus:border-[#005EB8] focus:outline-none"
                      ></textarea>
                    </div>
                  }

                  <div>
                    <label for="note-freetext-input" class="block text-xs font-semibold text-slate-700 mb-1">Additional Free-Text Narrative</label>
                    <textarea
                      id="note-freetext-input"
                      rows="3"
                      formControlName="freeText"
                      (input)="markDirty()"
                      class="w-full p-3 border border-slate-300 rounded-lg text-sm text-slate-900 leading-relaxed focus:border-[#005EB8] focus:outline-none"
                    ></textarea>
                  </div>
                </form>

                <!-- Copied Citations Attribution -->
                @if (copiedCitations().length > 0) {
                  <div class="bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-1.5">
                    <div class="text-xs font-semibold text-slate-700">Attributed Copied Material</div>
                    @for (c of copiedCitations(); track c.sourceId) {
                      <div class="text-xs text-slate-600">
                        [{{ c.sourceType }} · {{ c.sourceAuthor }} · {{ store.formatDateTime(c.sourceDate) }}] — "{{ c.excerpt }}"
                      </div>
                    }
                  </div>
                }
              </div>
            } @else {
              <!-- IMMUTABLE SIGNED / AMENDED / ENTERED-IN-ERROR VIEW -->
              <div class="space-y-4">
                @if (note.status === 'entered_in_error') {
                  <div role="alert" class="p-4 bg-red-50 border border-red-300 rounded-lg text-xs text-red-950 space-y-1">
                    <div class="font-bold">ENTERED IN ERROR — Original Content Preserved for Audit</div>
                    <div>Reason: {{ note.enteredInErrorReason }}</div>
                    <div>Recorded at: {{ store.formatDateTime(note.enteredInErrorAt) }}</div>
                  </div>
                }

                <div class="space-y-3 border border-slate-200 rounded-lg p-4 bg-slate-50/50">
                  @for (sec of note.sections; track sec.key) {
                    <div>
                      <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wide">{{ sec.label }}</h3>
                      <p class="text-sm text-slate-900 mt-1 whitespace-pre-wrap">{{ sec.content }}</p>
                    </div>
                  }
                  @if (note.freeText) {
                    <div>
                      <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wide">Additional Narrative</h3>
                      <p class="text-sm text-slate-900 mt-1 whitespace-pre-wrap">{{ note.freeText }}</p>
                    </div>
                  }
                </div>

                @if (note.attestationStatement) {
                  <div class="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-lg text-xs text-emerald-950 space-y-1">
                    <div class="font-semibold">Clinical Attestation (Separate from Cryptographic Signature)</div>
                    <div>{{ note.attestationStatement }}</div>
                    <div class="font-mono text-[11px] text-emerald-900">
                      HMAC-SHA256 Signature: {{ note.cryptographicSignatureHex?.slice(0, 32) }}...
                    </div>
                  </div>
                }

                <!-- Linked Amendments -->
                @if ((note.amendments?.length ?? 0) > 0) {
                  <div class="space-y-2">
                    <h3 class="font-display text-sm font-bold text-slate-900">Linked Addenda &amp; Amendments</h3>
                    @for (am of note.amendments ?? []; track am.id) {
                      <div class="p-3.5 bg-white border border-slate-300 rounded-lg text-xs space-y-1">
                        <div class="flex flex-wrap justify-between gap-2 font-semibold text-slate-900">
                          <span>Addendum by {{ am.authorName }}</span>
                          <span class="tabular-nums text-slate-600">{{ store.formatDateTime(am.createdAt) }}</span>
                        </div>
                        <div class="text-slate-600">Reason: {{ am.reason }}</div>
                        <p class="text-sm text-slate-900 pt-1">{{ am.addendumText }}</p>
                      </div>
                    }
                  </div>
                }

                <!-- Add Linked Addendum Form -->
                @if (note.status === 'signed' || note.status === 'amended') {
                  <form [formGroup]="amendmentForm" (ngSubmit)="submitAmendment(note.id)" class="border border-slate-200 rounded-xl p-4 space-y-3">
                    <h3 class="font-display text-sm font-semibold text-slate-900">Add Linked Amendment / Addendum</h3>
                    <input
                      formControlName="reason"
                      placeholder="Clinical reason for addendum (e.g. Correlated with corrected Troponin T)"
                      class="w-full min-h-[38px] px-3 border border-slate-300 rounded-lg text-xs"
                    />
                    <textarea
                      rows="2"
                      formControlName="addendumText"
                      placeholder="Enter attributed addendum text (original signed note remains immutable)..."
                      class="w-full p-3 border border-slate-300 rounded-lg text-sm"
                    ></textarea>
                    <div class="flex flex-wrap items-center justify-between gap-2">
                      <button
                        type="submit"
                        [disabled]="amendmentForm.invalid"
                        class="min-h-[38px] px-4 py-1.5 bg-[#005EB8] hover:bg-[#003087] disabled:opacity-50 text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Sign &amp; Link Addendum
                      </button>

                      <button
                        type="button"
                        (click)="showErrorModal.set(true)"
                        class="min-h-[38px] px-3 py-1.5 bg-white border border-red-300 hover:bg-red-50 text-red-800 text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Mark Entered-in-Error
                      </button>
                    </div>
                  </form>
                }
              </div>
            }

            <!-- Preview & Atomic Sign Modal -->
            @if (showSignModal()) {
              <div class="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label="Preview and Sign Clinical Note">
                <div class="bg-white border border-slate-300 rounded-xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
                  <h3 class="font-display text-lg font-bold text-[#003087]">Preview Before Clinical Signing</h3>
                  <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 space-y-1">
                    <div><strong>Patient:</strong> {{ ov.patient.familyName.toUpperCase() }}, {{ ov.patient.givenNames }} · NHS {{ ov.patient.nhsNumber ?? 'Unverified' }}</div>
                    <div><strong>Encounter:</strong> {{ ov.activeEncounter?.wardOrClinic ?? 'None' }}</div>
                    <div><strong>Note Version:</strong> v{{ note.version }} · Idempotency Key: <span class="font-mono">{{ pendingIdempotencyKey() }}</span></div>
                  </div>
                  <div class="border border-slate-200 rounded-lg p-4 space-y-2 max-h-56 overflow-y-auto text-xs">
                    @for (sec of sectionValues(); track sec.key) {
                      <div>
                        <strong class="text-slate-700">{{ sec.label }}:</strong>
                        <p class="text-slate-900 whitespace-pre-wrap">{{ sec.content }}</p>
                      </div>
                    }
                    @if (draftForm.controls.freeText.value) {
                      <div>
                        <strong class="text-slate-700">Narrative:</strong>
                        <p class="text-slate-900 whitespace-pre-wrap">{{ draftForm.controls.freeText.value }}</p>
                      </div>
                    }
                  </div>
                  <form [formGroup]="signConfirmForm" class="space-y-3">
                    <label class="flex items-start gap-2.5 text-xs text-slate-900 cursor-pointer">
                      <input type="checkbox" formControlName="patientConfirmed" class="mt-0.5 w-4 h-4 accent-[#005EB8]" />
                      <span>
                        I confirm this record is for <strong>{{ ov.patient.familyName.toUpperCase() }}, {{ ov.patient.givenNames }}</strong> (DOB {{ ov.patient.dob }}) and attest to its clinical accuracy. Signed notes become immutable.
                      </span>
                    </label>
                  </form>
                  @if (signError()) {
                    <div class="text-xs text-red-700 font-medium">{{ signError() }}</div>
                  }
                  <div class="flex flex-wrap justify-end gap-2 pt-2 border-t border-slate-200">
                    <button
                      type="button"
                      (click)="showSignModal.set(false)"
                      class="min-h-[40px] px-4 py-2 bg-white border border-slate-300 text-slate-800 text-xs font-semibold rounded-lg cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      [disabled]="signConfirmForm.invalid"
                      (click)="executeSign(note.id)"
                      class="min-h-[40px] px-4 py-2 bg-[#007F3B] hover:bg-[#00632E] disabled:opacity-50 text-white text-xs font-semibold rounded-lg cursor-pointer"
                    >
                      Attest &amp; Atomically Sign
                    </button>
                  </div>
                </div>
              </div>
            }

            <!-- Entered-in-Error Modal -->
            @if (showErrorModal()) {
              <div class="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
                <div class="bg-white border border-slate-300 rounded-xl max-w-md w-full p-5 space-y-4">
                  <h3 class="font-display text-base font-bold text-red-900">Mark Note Entered-in-Error</h3>
                  <p class="text-xs text-slate-600">
                    Original record content is permanently preserved in the database and revision history. Only Consultant or IG Lead roles may perform this action.
                  </p>
                  <form [formGroup]="enteredInErrorForm" (ngSubmit)="submitEnteredInError(note.id)" class="space-y-3">
                    <textarea
                      rows="3"
                      formControlName="reason"
                      placeholder="Mandatory reason (e.g. Wrong patient chart selected during clinic)"
                      class="w-full p-2.5 border border-slate-300 rounded-lg text-xs"
                    ></textarea>
                    <div class="flex justify-end gap-2">
                      <button type="button" (click)="showErrorModal.set(false)" class="px-3 py-1.5 border border-slate-300 rounded-lg text-xs cursor-pointer">Cancel</button>
                      <button type="submit" [disabled]="enteredInErrorForm.invalid" class="px-3 py-1.5 bg-red-700 text-white rounded-lg text-xs font-semibold cursor-pointer">Confirm</button>
                    </div>
                  </form>
                </div>
              </div>
            }

            <!-- Revision History Drawer -->
            @if (showHistoryDrawer()) {
              <div class="border-t border-slate-200 pt-4 space-y-2">
                <h3 class="font-display text-sm font-bold text-slate-900">Full Version History</h3>
                <div class="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                  @for (rev of note.revisions ?? []; track rev.id) {
                    <div class="p-3 text-xs space-y-1">
                      <div class="flex flex-wrap justify-between gap-2">
                        <span class="font-semibold text-slate-900">v{{ rev.version }} — {{ rev.action }}</span>
                        <span class="font-mono text-slate-500 tabular-nums">{{ store.formatDateTime(rev.createdAt) }}</span>
                      </div>
                      <div class="text-slate-600">Actor: {{ rev.actorName }} · SHA-256: <span class="font-mono">{{ rev.contentHash.slice(0, 16) }}</span></div>
                      @if (rev.reason) {
                        <div class="text-slate-700">Reason: {{ rev.reason }}</div>
                      }
                    </div>
                  }
                </div>
              </div>
            }
          } @else {
            <div class="py-12 text-center text-sm text-slate-500">
              Select a clinical note on the left or create a new draft from a template.
            </div>
          }
        </section>
      </div>
    }
  `,
})
export class NotesWorkspaceComponent implements OnDestroy {
  store = inject(ClinicalStore);

  selectedNote = signal<ClinicalNote | null>(null);
  sectionValues = signal<NoteSection[]>([]);
  copiedCitations = signal<CopiedCitation[]>([]);
  conflictServerNote = signal<ClinicalNote | null>(null);
  lastAutosaveLabel = signal<string | null>(null);
  showSignModal = signal(false);
  showErrorModal = signal(false);
  showHistoryDrawer = signal(false);
  pendingIdempotencyKey = signal('');
  signError = signal<string | null>(null);
  aiDraftBox = signal<{ draftText: string; uncertaintyNotes: string[] } | null>(null);
  aiErrorNotice = signal<string | null>(null);

  newNoteForm = new FormGroup({
    templateType: new FormControl<NoteTemplateType>('consultation', { nonNullable: true }),
  });

  draftForm = new FormGroup({
    title: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    freeText: new FormControl('', { nonNullable: true }),
  });

  signConfirmForm = new FormGroup({
    patientConfirmed: new FormControl(false, { nonNullable: true, validators: [Validators.requiredTrue] }),
  });

  amendmentForm = new FormGroup({
    reason: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    addendumText: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });

  enteredInErrorForm = new FormGroup({
    reason: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(8)] }),
  });

  private autosaveTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    effect(() => {
      const ov = this.store.patientOverview();
      if (!ov) {
        this.selectedNote.set(null);
        return;
      }
      const highlight = this.store.highlightedRecordId();
      const target =
        (highlight ? ov.notes.find((n) => n.id === highlight) : undefined) ??
        (this.selectedNote() ? ov.notes.find((n) => n.id === this.selectedNote()!.id) : undefined) ??
        ov.notes[0] ??
        null;
      if (target) {
        this.loadNoteIntoEditor(target);
      }
    });

    this.autosaveTimer = setInterval(() => {
      if (this.store.dirtyDraft().isDirty && this.selectedNote()?.status === 'draft') {
        void this.saveDraft(true);
      }
    }, 5000);
  }

  ngOnDestroy(): void {
    if (this.autosaveTimer) clearInterval(this.autosaveTimer);
  }

  selectNote(n: ClinicalNote): void {
    this.conflictServerNote.set(null);
    this.loadNoteIntoEditor(n);
  }

  private loadNoteIntoEditor(n: ClinicalNote): void {
    this.selectedNote.set(n);
    this.sectionValues.set(n.sections.map((s) => ({ ...s })));
    this.copiedCitations.set([...n.copiedCitations]);
    this.draftForm.patchValue({ title: n.title, freeText: n.freeText }, { emitEvent: false });
    this.store.dirtyDraft.set({ isDirty: false, noteId: n.id, title: n.title });
  }

  markDirty(): void {
    const n = this.selectedNote();
    if (!n) return;
    this.store.dirtyDraft.set({ isDirty: true, noteId: n.id, title: this.draftForm.controls.title.value });
  }

  updateSection(index: number, value: string): void {
    this.sectionValues.update((list) => list.map((s, i) => (i === index ? { ...s, content: value } : s)));
    this.markDirty();
  }

  async createNote(): Promise<void> {
    const ov = this.store.patientOverview();
    if (!ov) return;
    const tpl = this.newNoteForm.controls.templateType.value;
    const sections = TEMPLATE_SECTIONS[tpl].map((s) => ({ key: s.key, label: s.label, content: '' }));
    const note = await this.store.createDraftNote(ov.patient.id, {
      encounterId: ov.activeEncounter?.id ?? null,
      templateType: tpl,
      title: `${tpl.replace('_', ' ').toUpperCase()} — ${new Date().toISOString().slice(0, 10)}`,
      sections,
      freeText: '',
    });
    this.loadNoteIntoEditor(note);
  }

  async saveDraft(isAutosave: boolean): Promise<void> {
    const note = this.selectedNote();
    if (!note || note.status !== 'draft') return;
    const res = await this.store.saveDraftNote(note.id, {
      expectedVersion: note.version,
      title: this.draftForm.controls.title.value,
      sections: this.sectionValues(),
      freeText: this.draftForm.controls.freeText.value,
      copiedCitations: this.copiedCitations(),
    });
    if (res.conflictServerNote) {
      this.conflictServerNote.set(res.conflictServerNote);
      return;
    }
    if (res.note) {
      this.selectedNote.set(res.note);
      this.lastAutosaveLabel.set(isAutosave ? 'Autosaved just now' : 'Saved manually');
    } else if (res.savedOffline) {
      this.lastAutosaveLabel.set('Encrypted locally (Offline)');
    }
  }

  async simulateConcurrentEdit(): Promise<void> {
    const note = this.selectedNote();
    if (!note || note.status !== 'draft') return;
    // Save once quietly via server with force flag or current version to bump server version,
    // while keeping local note version stale so next save triggers 409 conflict!
    const staleVersion = note.version;
    await this.store.saveDraftNote(note.id, {
      expectedVersion: staleVersion,
      title: note.title,
      sections: note.sections,
      freeText: (note.freeText ? note.freeText + '\n' : '') + '[Concurrent Registrar note: ECG reviewed, AF rate 96 bpm.]',
      copiedCitations: note.copiedCitations,
    });
    // Now force local editor back to stale version with local unsaved edits and attempt save -> triggers 409!
    const res = await this.store.saveDraftNote(note.id, {
      expectedVersion: staleVersion,
      title: this.draftForm.controls.title.value,
      sections: this.sectionValues(),
      freeText: this.draftForm.controls.freeText.value + ' [Local unsaved addendum]',
      copiedCitations: this.copiedCitations(),
    });
    if (res.conflictServerNote) {
      this.conflictServerNote.set(res.conflictServerNote);
    }
  }

  acceptServerVersion(serverNote: ClinicalNote): void {
    this.conflictServerNote.set(null);
    this.loadNoteIntoEditor(serverNote);
  }

  async mergeAndSaveConflict(serverNote: ClinicalNote): Promise<void> {
    const combinedFreeText = [
      serverNote.freeText,
      '--- Merged Local Clinician Text ---',
      this.draftForm.controls.freeText.value,
    ]
      .filter(Boolean)
      .join('\n');
    const res = await this.store.saveDraftNote(serverNote.id, {
      expectedVersion: serverNote.version,
      title: this.draftForm.controls.title.value,
      sections: this.sectionValues(),
      freeText: combinedFreeText,
      copiedCitations: this.copiedCitations(),
      forceConflictResolution: true,
    });
    if (res.note) {
      this.conflictServerNote.set(null);
      this.loadNoteIntoEditor(res.note);
    }
  }

  citeLatestResult(): void {
    const ov = this.store.patientOverview();
    if (!ov || ov.results.length === 0) return;
    const latest = ov.results[0];
    this.copiedCitations.update((list) => [
      ...list.filter((c) => c.sourceId !== latest.id),
      {
        sourceType: 'Diagnostic Result',
        sourceId: latest.id,
        sourceAuthor: latest.performingLab,
        sourceDate: latest.reportedAt,
        excerpt: `${latest.orderName}: ${latest.valueText} ${latest.unit} (${latest.resultStatus})`,
      },
    ]);
    this.markDirty();
  }

  openSignPreview(): void {
    this.signError.set(null);
    this.signConfirmForm.reset({ patientConfirmed: false });
    this.pendingIdempotencyKey.set(`sign-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
    this.showSignModal.set(true);
  }

  async executeSign(noteId: string): Promise<void> {
    const note = this.selectedNote();
    if (!note || this.signConfirmForm.invalid) return;
    try {
      if (this.store.dirtyDraft().isDirty) {
        await this.saveDraft(false);
      }
      const updated = this.selectedNote()!;
      const signed = await this.store.signNote(
        noteId,
        updated.version,
        this.signConfirmForm.controls.patientConfirmed.value,
        this.pendingIdempotencyKey()
      );
      this.showSignModal.set(false);
      this.loadNoteIntoEditor(signed);
    } catch (e) {
      this.signError.set(e instanceof Error ? e.message : 'Unable to sign note');
    }
  }

  async submitAmendment(noteId: string): Promise<void> {
    if (this.amendmentForm.invalid) return;
    const updated = await this.store.addNoteAmendment(
      noteId,
      this.amendmentForm.controls.addendumText.value,
      this.amendmentForm.controls.reason.value
    );
    this.amendmentForm.reset();
    this.loadNoteIntoEditor(updated);
  }

  async submitEnteredInError(noteId: string): Promise<void> {
    if (this.enteredInErrorForm.invalid) return;
    await this.store.markNoteEnteredInError(noteId, this.enteredInErrorForm.controls.reason.value);
    this.showErrorModal.set(false);
    this.enteredInErrorForm.reset();
  }

  async requestAiSummary(): Promise<void> {
    const ov = this.store.patientOverview();
    if (!ov) return;
    this.aiErrorNotice.set(null);
    try {
      const res = await this.store.generateAiDraftSummary(ov.patient.id);
      this.aiDraftBox.set({ draftText: res.draftText, uncertaintyNotes: res.uncertaintyNotes });
    } catch {
      this.aiErrorNotice.set(
        'Optional AI Draft Assist is disabled by default. Enable it in Administration to test clinician-reviewed draft generation.'
      );
    }
  }

  acceptAiDraftIntoFreeText(text: string): void {
    const current = this.draftForm.controls.freeText.value;
    this.draftForm.controls.freeText.setValue((current ? current + '\n\n' : '') + text);
    this.markDirty();
    this.aiDraftBox.set(null);
  }
}
