import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';

@Component({
  selector: 'app-patient-banner',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (store.patientOverview(); as ov) {
      <section
        aria-label="Active Patient Identification Banner"
        class="bg-white border-b border-slate-300 px-4 lg:px-6 py-3 sticky top-0 z-20"
      >
        <div class="flex flex-col xl:flex-row xl:items-center justify-between gap-3">
          <div class="space-y-1 min-w-0">
            <div class="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h2 class="font-display text-lg font-bold text-[#003087] tracking-tight">
                {{ ov.patient.familyName.toUpperCase() }}, {{ ov.patient.givenNames }}
              </h2>
              <span class="text-xs text-slate-600 tabular-nums">
                Born {{ ov.patient.dob }} ({{ ageYears() }}y)
              </span>
              <span class="text-xs text-slate-400" aria-hidden="true">·</span>
              <span class="text-xs text-slate-700">{{ ov.patient.sexAtBirth }}</span>
              <span class="text-xs text-slate-400" aria-hidden="true">·</span>
              <span class="text-xs font-mono font-semibold text-slate-900 tabular-nums">
                NHS {{ ov.patient.nhsNumber ?? 'Not Provided' }}
              </span>
              <span class="text-xs font-medium"
                [class]="ov.patient.nhsVerificationStatus === 'verified_pds' ? 'text-[#007F3B]' : 'text-[#B45309]'">
                ({{ verificationLabel() }})
              </span>
              <span class="text-xs text-slate-400" aria-hidden="true">·</span>
              <span class="text-xs font-mono text-slate-600 tabular-nums">{{ ov.patient.internalMrn }}</span>
            </div>

            <div class="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
              <button
                type="button"
                (click)="store.navigate('medications')"
                class="inline-flex items-center gap-1.5 font-semibold cursor-pointer hover:underline"
                [class]="allergyTextClass()"
              >
                <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">warning_amber</mat-icon>
                <span>{{ allergySummary() }}</span>
              </button>

              <span class="text-slate-300" aria-hidden="true">|</span>

              @if (ov.activeEncounter; as enc) {
                <button
                  type="button"
                  (click)="store.navigate('consultations')"
                  class="inline-flex items-center gap-1.5 text-slate-700 hover:text-[#005EB8] cursor-pointer"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-[#005EB8]">medical_services</mat-icon>
                  <span class="font-medium">{{ enc.wardOrClinic }}</span>
                  <span class="text-slate-400">·</span>
                  <span>{{ enc.responsibleClinicianName }}</span>
                  <span class="text-slate-400">·</span>
                  <span class="font-medium text-[#005EB8]">{{ enc.status.replace('_', ' ') }}</span>
                </button>
              } @else {
                <span class="text-slate-500">No active encounter selected</span>
              }

              @if (store.session()?.breakGlassPatientId === ov.patient.id) {
                <span class="text-red-700 font-semibold">
                  · Emergency Break-Glass Active
                </span>
              }
            </div>
          </div>

          <div class="flex flex-wrap items-center gap-2 shrink-0">
            <div class="inline-flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200" role="group" aria-label="Reference Side Panel">
              <button
                type="button"
                (click)="toggleSidePanel('results')"
                class="min-h-[34px] px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
                [class]="store.sidePanelMode() === 'results' ? 'bg-white text-[#003087] shadow-xs' : 'text-slate-600 hover:text-slate-900'"
              >
                Results ({{ ov.results.length }})
              </button>
              <button
                type="button"
                (click)="toggleSidePanel('medications')"
                class="min-h-[34px] px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
                [class]="store.sidePanelMode() === 'medications' ? 'bg-white text-[#003087] shadow-xs' : 'text-slate-600 hover:text-slate-900'"
              >
                Meds ({{ ov.medications.length }})
              </button>
              <button
                type="button"
                (click)="toggleSidePanel('previous_notes')"
                class="min-h-[34px] px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
                [class]="store.sidePanelMode() === 'previous_notes' ? 'bg-white text-[#003087] shadow-xs' : 'text-slate-600 hover:text-slate-900'"
              >
                Notes ({{ ov.notes.length }})
              </button>
            </div>
          </div>
        </div>
      </section>
    }
  `,
})
export class PatientBannerComponent {
  store = inject(ClinicalStore);

  ageYears = computed(() => {
    const dob = this.store.activePatient()?.dob;
    if (!dob) return '--';
    const birth = new Date(dob);
    const ref = new Date('2026-11-22');
    let age = ref.getUTCFullYear() - birth.getUTCFullYear();
    const m = ref.getUTCMonth() - birth.getUTCMonth();
    if (m < 0 || (m === 0 && ref.getUTCDate() < birth.getUTCDate())) age--;
    return age;
  });

  verificationLabel = computed(() => {
    const s = this.store.activePatient()?.nhsVerificationStatus;
    if (s === 'verified_pds') return 'Verified PDS';
    if (s === 'trace_pending') return 'PDS Trace Pending';
    if (s === 'unverified') return 'Unverified Match';
    return 'Not Provided';
  });

  allergySummary = computed(() => {
    const ov = this.store.patientOverview();
    if (!ov) return '';
    const status = ov.patient.allergyAssertionStatus;
    if (status === 'no_known_allergies') return 'Allergies: No Known Allergies (Documented)';
    if (status === 'not_assessed') return 'Allergies: Not Assessed — Review Required';
    if (status === 'unavailable') return 'Allergies: History Unavailable';
    const active = ov.allergies.filter((a) => a.clinicalStatus === 'active');
    if (active.length === 0) return 'Allergies: Assessed (0 active entries)';
    return `Allergies (${active.length}): ${active.map((a) => `${a.substance} [${a.severity}]`).join('; ')}`;
  });

  allergyTextClass = computed(() => {
    const status = this.store.activePatient()?.allergyAssertionStatus;
    if (status === 'assessed_with_allergies') return 'text-[#B91C1C]';
    if (status === 'not_assessed' || status === 'unavailable') return 'text-[#B45309]';
    return 'text-[#007F3B]';
  });

  toggleSidePanel(mode: 'results' | 'medications' | 'previous_notes'): void {
    this.store.sidePanelMode.set(this.store.sidePanelMode() === mode ? 'closed' : mode);
  }
}
