import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';
import type { Observation } from '../../shared/clinical-types';

@Component({
  selector: 'app-results-obs-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.patientOverview(); as ov) {
      @if (store.activeNav() === 'observations') {
        <div class="space-y-6">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 class="font-display text-2xl font-bold text-slate-900">Clinical Observations</h1>
              <p class="text-xs text-slate-600 mt-0.5">
                Observation time is recorded separately from documentation time, with device/clinician attribution and explicit unavailable states.
              </p>
            </div>
            <button
              type="button"
              (click)="showObsForm.set(!showObsForm())"
              class="min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer self-start"
            >
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">add</mat-icon>
              <span>{{ showObsForm() ? 'Close Form' : 'Record Observation' }}</span>
            </button>
          </div>

          @if (showObsForm()) {
            <form [formGroup]="obsForm" (ngSubmit)="submitObservation(ov.patient.id)" class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div>
                  <label for="obs-preset" class="block font-medium text-slate-700 mb-1">Measurement</label>
                  <select id="obs-preset" formControlName="preset" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg bg-white text-sm">
                    <option value="bp_sys">Systolic Blood Pressure (LOINC 8480-6, mmHg)</option>
                    <option value="hr">Heart Rate (LOINC 8867-4, bpm)</option>
                    <option value="spo2">SpO2 (LOINC 2708-6, %)</option>
                    <option value="temp">Body Temperature (LOINC 8310-5, °C)</option>
                  </select>
                </div>
                <div>
                  <label for="obs-value" class="block font-medium text-slate-700 mb-1">Measured Value</label>
                  <input id="obs-value" type="number" step="0.1" formControlName="valueNum" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm font-mono" />
                </div>
                <div>
                  <label for="obs-source" class="block font-medium text-slate-700 mb-1">Recording Source / Device</label>
                  <input id="obs-source" formControlName="recordingSource" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm" />
                </div>
              </div>
              <div class="flex justify-end">
                <button type="submit" [disabled]="obsForm.invalid" class="min-h-[40px] px-4 py-2 bg-[#005EB8] text-white text-xs font-semibold rounded-lg cursor-pointer">
                  Save Observation
                </button>
              </div>
            </form>
          }

          <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div class="overflow-x-auto">
              <table class="w-full text-left border-collapse text-xs">
                <thead>
                  <tr class="border-b border-slate-200 bg-slate-50 text-slate-600">
                    <th class="py-3 px-4 font-semibold">Measurement &amp; Code</th>
                    <th class="py-3 px-4 font-semibold">Value</th>
                    <th class="py-3 px-4 font-semibold">Source Reference</th>
                    <th class="py-3 px-4 font-semibold">Observed vs Documented</th>
                    <th class="py-3 px-4 font-semibold">Attribution &amp; Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                  @for (obs of ov.observations; track obs.id) {
                    <tr [class]="store.highlightedRecordId() === obs.id ? 'bg-[#005EB8]/5' : 'hover:bg-slate-50'">
                      <td class="py-3 px-4">
                        <div class="font-semibold text-slate-900">{{ obs.display }}</div>
                        <div class="font-mono text-slate-500">{{ obs.terminologySystem }} {{ obs.code }}</div>
                      </td>
                      <td class="py-3 px-4 font-mono tabular-nums font-bold"
                        [class]="obs.interpretation === 'high' || obs.interpretation === 'critical' ? 'text-[#B45309]' : obs.interpretation === 'unavailable' ? 'text-slate-500 font-normal' : 'text-slate-900'">
                        {{ obs.valueText }} {{ obs.unit }}
                        <div class="text-[11px] font-sans font-medium">{{ obs.interpretation }}</div>
                      </td>
                      <td class="py-3 px-4 font-mono tabular-nums text-slate-600">
                        @if (obs.referenceLow !== null && obs.referenceHigh !== null) {
                          {{ obs.referenceLow }} - {{ obs.referenceHigh }} {{ obs.unit }}
                        } @else {
                          Not supplied
                        }
                      </td>
                      <td class="py-3 px-4 tabular-nums text-slate-600">
                        <div>Obs: {{ store.formatDateTime(obs.observedAt) }}</div>
                        <div>Doc: {{ store.formatDateTime(obs.documentedAt) }}</div>
                      </td>
                      <td class="py-3 px-4 text-slate-700">
                        <div>{{ obs.attribution }}</div>
                        <div class="text-slate-500">{{ obs.recordingSource }} · {{ obs.verificationStatus }}</div>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </section>
        </div>
      } @else {
        <!-- DIAGNOSTIC RESULTS -->
        <div class="space-y-6">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 class="font-display text-2xl font-bold text-slate-900">Diagnostic Results &amp; Review Workflow</h1>
              <p class="text-xs text-slate-600 mt-0.5">
                Preserves preliminary, final, corrected, and cancelled states using source-provided reference intervals.
              </p>
            </div>
          </div>

          <div class="space-y-4">
            @for (res of ov.results; track res.id) {
              <article
                class="bg-white border rounded-xl p-5 space-y-3"
                [class]="store.highlightedRecordId() === res.id ? 'border-[#005EB8] ring-2 ring-[#005EB8]/15' : 'border-slate-200'"
              >
                <div class="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                  <div class="space-y-1">
                    <div class="flex flex-wrap items-center gap-2 text-xs">
                      <span class="font-mono text-slate-500">{{ res.requestId }}</span>
                      <span class="text-slate-400">·</span>
                      <span class="font-semibold uppercase"
                        [class]="res.resultStatus === 'corrected' ? 'text-[#B91C1C]' : res.resultStatus === 'preliminary' ? 'text-[#B45309]' : 'text-[#007F3B]'">
                        {{ res.resultStatus }}
                      </span>
                      <span class="text-slate-400">·</span>
                      <span class="font-medium text-slate-700">Review State: {{ res.reviewState.replaceAll('_', ' ') }}</span>
                    </div>
                    <h2 class="font-display text-base font-bold text-slate-900">{{ res.orderName }}</h2>
                    <div class="text-xs text-slate-600 tabular-nums">
                      {{ res.terminologySystem }} {{ res.code }} · Lab: {{ res.performingLab }} · Reported {{ store.formatDateTime(res.reportedAt) }}
                    </div>
                  </div>

                  <div class="text-left lg:text-right shrink-0">
                    <div class="text-xl font-mono font-bold tabular-nums"
                      [class]="res.abnormalFlag === 'critical' ? 'text-[#B91C1C]' : res.abnormalFlag === 'high' ? 'text-[#B45309]' : 'text-slate-900'">
                      {{ res.valueText }} <span class="text-sm font-normal">{{ res.unit }}</span>
                    </div>
                    <div class="text-xs text-slate-600">
                      Source Ref: {{ res.referenceInterval }} · Flag: <strong>{{ res.abnormalFlag }}</strong>
                    </div>
                  </div>
                </div>

                @if (res.supersedesResultId) {
                  <div class="p-3 bg-red-50/70 border border-red-200 rounded-lg text-xs text-red-950 space-y-1">
                    <div>
                      <strong>Linked Correction:</strong> Supersedes prior result <span class="font-mono">{{ res.supersedesResultId }}</span>
                    </div>
                    <div>Correction Reason: {{ res.correctionReason }}</div>
                  </div>
                }

                <div class="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
                  <div class="text-xs text-slate-500 tabular-nums">
                    @if (res.acknowledgedAt) {
                      Acknowledged {{ store.formatDateTime(res.acknowledgedAt) }}
                    } @else if (res.viewedAt) {
                      Viewed {{ store.formatDateTime(res.viewedAt) }} (Awaiting acknowledgement)
                    } @else {
                      Not yet viewed by clinician
                    }
                  </div>

                  <div class="flex flex-wrap items-center gap-2">
                    @if (res.reviewState === 'available') {
                      <button
                        type="button"
                        (click)="store.transitionResultState(res.id, 'viewed')"
                        class="min-h-[36px] px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Mark Viewed
                      </button>
                    }
                    @if (res.reviewState === 'available' || res.reviewState === 'viewed') {
                      <button
                        type="button"
                        (click)="store.transitionResultState(res.id, 'acknowledged')"
                        class="min-h-[36px] px-3 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Acknowledge Result
                      </button>
                    }
                    @if (res.reviewState !== 'follow_up_assigned' && res.reviewState !== 'follow_up_completed') {
                      <button
                        type="button"
                        (click)="store.transitionResultState(res.id, 'follow_up_assigned')"
                        class="min-h-[36px] px-3 py-1.5 bg-white border border-[#005EB8] text-[#005EB8] hover:bg-[#005EB8]/5 text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Assign Follow-up Task
                      </button>
                    }
                    @if (res.reviewState === 'follow_up_assigned') {
                      <button
                        type="button"
                        (click)="store.transitionResultState(res.id, 'follow_up_completed')"
                        class="min-h-[36px] px-3 py-1.5 bg-[#007F3B] hover:bg-[#00632E] text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Complete Follow-up
                      </button>
                    }
                    @if (res.resultStatus !== 'corrected') {
                      <button
                        type="button"
                        (click)="openCorrectionPrompt(res.id)"
                        class="min-h-[36px] px-3 py-1.5 bg-white border border-amber-300 hover:bg-amber-50 text-amber-900 text-xs font-medium rounded-lg cursor-pointer"
                      >
                        Simulate Lab Correction
                      </button>
                    }
                  </div>
                </div>
              </article>
            }
          </div>

          @if (correctingResultId(); as targetId) {
            <form [formGroup]="correctionForm" (ngSubmit)="submitCorrection(targetId)" class="bg-amber-50 border border-amber-300 rounded-xl p-5 space-y-3">
              <h3 class="font-display text-sm font-bold text-amber-950">Simulate Corrected Result Ingestion ({{ targetId }})</h3>
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <input formControlName="newValueText" placeholder="Corrected Value (e.g. 74)" class="min-h-[38px] px-3 border border-amber-300 bg-white rounded-lg" />
                <select formControlName="abnormalFlag" class="min-h-[38px] px-3 border border-amber-300 bg-white rounded-lg">
                  <option value="critical">critical</option>
                  <option value="high">high</option>
                  <option value="normal">normal</option>
                  <option value="low">low</option>
                </select>
                <input formControlName="correctionReason" placeholder="Reason for lab correction" class="min-h-[38px] px-3 border border-amber-300 bg-white rounded-lg" />
              </div>
              <div class="flex justify-end gap-2">
                <button type="button" (click)="correctingResultId.set(null)" class="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs cursor-pointer">Cancel</button>
                <button type="submit" [disabled]="correctionForm.invalid" class="px-3 py-1.5 bg-[#005EB8] text-white rounded-lg text-xs font-semibold cursor-pointer">Ingest Correction</button>
              </div>
            </form>
          }
        </div>
      }
    }
  `,
})
export class ResultsObsViewComponent {
  store = inject(ClinicalStore);
  showObsForm = signal(false);
  correctingResultId = signal<string | null>(null);

  obsForm = new FormGroup({
    preset: new FormControl<'bp_sys' | 'hr' | 'spo2' | 'temp'>('bp_sys', { nonNullable: true }),
    valueNum: new FormControl<number>(138, { nonNullable: true, validators: [Validators.required] }),
    recordingSource: new FormControl('Welch Allyn Vital Signs Monitor #B4', { nonNullable: true }),
  });

  correctionForm = new FormGroup({
    newValueText: new FormControl('1580', { nonNullable: true, validators: [Validators.required] }),
    abnormalFlag: new FormControl<'normal' | 'high' | 'low' | 'critical'>('critical', { nonNullable: true }),
    correctionReason: new FormControl('Laboratory repeat dilution confirmed elevated value', { nonNullable: true, validators: [Validators.required] }),
  });

  async submitObservation(patientId: string): Promise<void> {
    if (this.obsForm.invalid) return;
    const presetMap: Record<string, { code: string; display: string; unit: string; low: number; high: number }> = {
      bp_sys: { code: '8480-6', display: 'Systolic Blood Pressure', unit: 'mmHg', low: 90, high: 140 },
      hr: { code: '8867-4', display: 'Heart Rate', unit: 'bpm', low: 60, high: 100 },
      spo2: { code: '2708-6', display: 'Oxygen Saturation (SpO2)', unit: '%', low: 94, high: 100 },
      temp: { code: '8310-5', display: 'Body Temperature', unit: '°C', low: 36.1, high: 37.8 },
    };
    const meta = presetMap[this.obsForm.controls.preset.value];
    const val = Number(this.obsForm.controls.valueNum.value);
    const interp: Observation['interpretation'] = val > meta.high ? 'high' : val < meta.low ? 'low' : 'normal';

    await this.store.recordObservation(patientId, {
      encounterId: this.store.activeEncounter()?.id ?? null,
      code: meta.code,
      terminologySystem: 'LOINC',
      display: meta.display,
      valueNum: val,
      valueText: String(val),
      unit: meta.unit,
      referenceLow: meta.low,
      referenceHigh: meta.high,
      interpretation: interp,
      observedAt: new Date().toISOString(),
      recordingSource: this.obsForm.controls.recordingSource.value,
      verificationStatus: 'final',
    });
    this.showObsForm.set(false);
  }

  openCorrectionPrompt(resultId: string): void {
    this.correctingResultId.set(resultId);
  }

  async submitCorrection(resultId: string): Promise<void> {
    if (this.correctionForm.invalid) return;
    await this.store.simulateCorrectedResult(
      resultId,
      this.correctionForm.controls.newValueText.value,
      this.correctionForm.controls.abnormalFlag.value,
      this.correctionForm.controls.correctionReason.value
    );
    this.correctingResultId.set(null);
  }
}
