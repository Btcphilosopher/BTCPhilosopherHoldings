import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';

@Component({
  selector: 'app-worklist-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-slate-900">Today's Clinical Worklist</h1>
          <p class="text-sm text-slate-600 mt-0.5">
            Active encounters, unacknowledged diagnostic results, and patient coordination tasks for {{ store.session()?.clinician?.organisationName }}.
          </p>
        </div>
        <button
          type="button"
          (click)="store.loadWorklist()"
          class="min-h-[40px] px-4 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs font-semibold rounded-lg inline-flex items-center gap-2 cursor-pointer self-start"
        >
          <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">refresh</mat-icon>
          <span>Refresh Worklist</span>
        </button>
      </div>

      @if (store.loading() && !store.worklist()) {
        <div class="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
          Loading clinical worklist...
        </div>
      } @else if (store.worklist(); as wl) {
        <!-- Scheduled Clinic / Ward Patients -->
        <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
            <h2 class="font-display text-base font-semibold text-slate-900">
              Active Encounters ({{ wl.scheduledPatients.length }})
            </h2>
            <span class="text-xs text-slate-500 tabular-nums">
              Updated {{ store.formatDateTime(wl.serverTimeUtc) }}
            </span>
          </div>

          @if (wl.scheduledPatients.length === 0) {
            <div class="p-8 text-center text-sm text-slate-600">
              No active encounters scheduled for your organisation today.
            </div>
          } @else {
            <div class="divide-y divide-slate-200">
              @for (item of wl.scheduledPatients; track item.encounter.id) {
                <div class="p-4 lg:px-5 hover:bg-slate-50/80 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div class="space-y-1 min-w-0">
                    <div class="flex flex-wrap items-baseline gap-x-2.5 gap-y-1">
                      <span class="font-display font-bold text-slate-900 text-sm">
                        {{ item.patient.familyName.toUpperCase() }}, {{ item.patient.givenNames }}
                      </span>
                      <span class="text-xs font-mono text-slate-600 tabular-nums">
                        NHS {{ item.patient.nhsNumber ?? 'Unverified' }}
                      </span>
                      <span class="text-xs text-slate-400" aria-hidden="true">·</span>
                      <span class="text-xs text-slate-600 tabular-nums">DOB {{ item.patient.dob }}</span>
                    </div>
                    <div class="text-xs text-slate-700">
                      <span class="font-medium text-[#005EB8]">{{ item.encounter.wardOrClinic }}</span>
                      <span class="text-slate-400 mx-1.5">·</span>
                      <span>{{ item.encounter.presentingConcern }}</span>
                    </div>
                    <div class="text-xs text-slate-500 flex flex-wrap items-center gap-x-3 gap-y-1 tabular-nums">
                      <span>Pending results: <strong class="text-slate-800">{{ item.pendingResultsCount }}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Open tasks: <strong class="text-slate-800">{{ item.openTasksCount }}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Draft notes: <strong class="text-slate-800">{{ item.draftNotesCount }}</strong></span>
                    </div>
                  </div>

                  <div class="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      (click)="store.openPatient(item.patient.id, 'today')"
                      class="min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <mat-icon class="!text-[17px] !w-[17px] !h-[17px]">folder_open</mat-icon>
                      <span>Open Record</span>
                    </button>
                    <button
                      type="button"
                      (click)="store.openPatient(item.patient.id, 'notes')"
                      class="min-h-[40px] px-3.5 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <mat-icon class="!text-[17px] !w-[17px] !h-[17px]">edit_note</mat-icon>
                      <span>Document Note</span>
                    </button>
                  </div>
                </div>
              }
            </div>
          }
        </section>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Unacknowledged Results -->
          <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div class="px-5 py-4 border-b border-slate-200">
              <h2 class="font-display text-base font-semibold text-slate-900">
                Results Awaiting Acknowledgement ({{ wl.pendingResultsToAcknowledge.length }})
              </h2>
            </div>
            @if (wl.pendingResultsToAcknowledge.length === 0) {
              <div class="p-6 text-sm text-slate-500">All available results have been acknowledged.</div>
            } @else {
              <div class="divide-y divide-slate-200">
                @for (res of wl.pendingResultsToAcknowledge; track res.id) {
                  <div class="p-4 flex items-start justify-between gap-3">
                    <div class="space-y-1">
                      <div class="flex flex-wrap items-center gap-2 text-xs">
                        <span class="font-semibold text-slate-900">{{ res.patientName }}</span>
                        <span class="text-slate-400">·</span>
                        <span class="font-mono text-slate-600 tabular-nums">{{ res.nhsNumber ?? 'Unverified' }}</span>
                      </div>
                      <div class="text-sm font-medium text-slate-900">
                        {{ res.orderName }}:
                        <span class="font-mono tabular-nums font-bold"
                          [class]="res.abnormalFlag === 'critical' ? 'text-[#B91C1C]' : res.abnormalFlag === 'high' ? 'text-[#B45309]' : 'text-slate-900'">
                          {{ res.valueText }} {{ res.unit }}
                        </span>
                      </div>
                      <div class="text-xs text-slate-500">
                        Status: {{ res.resultStatus }} · Review: {{ res.reviewState }} · Reported {{ store.formatDateTime(res.reportedAt) }}
                      </div>
                    </div>
                    <button
                      type="button"
                      (click)="store.openPatient(res.patientId, 'results')"
                      class="min-h-[38px] px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Review
                    </button>
                  </div>
                }
              </div>
            }
          </section>

          <!-- Open Tasks -->
          <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div class="px-5 py-4 border-b border-slate-200">
              <h2 class="font-display text-base font-semibold text-slate-900">
                Open Coordination Tasks ({{ wl.openTasks.length }})
              </h2>
            </div>
            @if (wl.openTasks.length === 0) {
              <div class="p-6 text-sm text-slate-500">No open clinical tasks.</div>
            } @else {
              <div class="divide-y divide-slate-200">
                @for (task of wl.openTasks; track task.id) {
                  <div class="p-4 flex items-start justify-between gap-3">
                    <div class="space-y-1">
                      <div class="flex flex-wrap items-center gap-2 text-xs">
                        <span class="font-semibold"
                          [class]="task.priority === 'stat' ? 'text-[#B91C1C]' : task.priority === 'urgent' ? 'text-[#B45309]' : 'text-[#005EB8]'">
                          {{ task.priority.toUpperCase() }}
                        </span>
                        <span class="text-slate-400">·</span>
                        <span class="font-medium text-slate-800">{{ task.patientName }}</span>
                      </div>
                      <div class="text-sm font-medium text-slate-900">{{ task.title }}</div>
                      <div class="text-xs text-slate-500 tabular-nums">
                        Status: {{ task.status }} · Due {{ store.formatDateTime(task.dueAt) }}
                      </div>
                    </div>
                    <button
                      type="button"
                      (click)="store.openPatient(task.patientId, 'tasks')"
                      class="min-h-[38px] px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Open Task
                    </button>
                  </div>
                }
              </div>
            }
          </section>
        </div>
      }
    </div>
  `,
})
export class WorklistViewComponent {
  store = inject(ClinicalStore);
}
