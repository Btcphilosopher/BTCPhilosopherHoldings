import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';

@Component({
  selector: 'app-admin-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <div>
        <h1 class="font-display text-2xl font-bold text-slate-900">Administration, Audit &amp; Interoperability</h1>
        <p class="text-xs text-slate-600 mt-0.5">
          Hash-chained append-only audit log, integration outbox, FHIR R4 UK Core mock bundle, encrypted offline cache, AI adapter policy, and NHS regulatory readiness.
        </p>
      </div>

      <!-- Controls Strip: Offline Simulation, AI Adapter, Backup Export -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
          <h2 class="font-display text-sm font-bold text-slate-900">Offline Draft Cache (AES-GCM)</h2>
          <p class="text-xs text-slate-600">
            Cached encrypted drafts in browser IndexedDB: <strong class="tabular-nums">{{ store.cachedDraftRecords().length }}</strong>
          </p>
          <button
            type="button"
            (click)="store.isOfflineSimulated.set(!store.isOfflineSimulated())"
            class="min-h-[38px] w-full px-3 py-1.5 text-xs font-semibold rounded-lg border cursor-pointer"
            [class]="store.isOfflineSimulated() ? 'bg-amber-50 border-amber-400 text-amber-950' : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'"
          >
            {{ store.isOfflineSimulated() ? 'Disable Simulated Offline Mode' : 'Simulate Offline Network Loss' }}
          </button>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
          <h2 class="font-display text-sm font-bold text-slate-900">Optional AI Drafting Adapter</h2>
          <p class="text-xs text-slate-600">
            Disabled by default. Requires source links &amp; explicit clinician review; never signs or prescribes.
          </p>
          <button
            type="button"
            (click)="toggleAi()"
            class="min-h-[38px] w-full px-3 py-1.5 text-xs font-semibold rounded-lg border cursor-pointer"
            [class]="isAiEnabled() ? 'bg-[#005EB8] border-[#005EB8] text-white' : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-50'"
          >
            {{ isAiEnabled() ? 'Disable AI Draft Assist' : 'Enable Optional AI Draft Assist' }}
          </button>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
          <h2 class="font-display text-sm font-bold text-slate-900">Protected Backup &amp; FHIR Export</h2>
          <p class="text-xs text-slate-600">
            Export verified JSON snapshot or inspect FHIR R4 UK Core collection bundle.
          </p>
          <div class="flex gap-2">
            <button
              type="button"
              (click)="runBackup()"
              class="min-h-[38px] flex-1 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold rounded-lg cursor-pointer"
            >
              Export Backup
            </button>
            <button
              type="button"
              (click)="inspectFhir()"
              class="min-h-[38px] flex-1 px-3 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              FHIR Bundle
            </button>
          </div>
        </div>
      </div>

      @if (jsonPreview(); as preview) {
        <section class="bg-white border border-slate-300 rounded-xl p-4 space-y-2">
          <div class="flex items-center justify-between">
            <h3 class="font-display text-sm font-bold text-slate-900">{{ preview.title }}</h3>
            <button type="button" (click)="jsonPreview.set(null)" class="text-xs text-slate-600 hover:underline cursor-pointer">Close</button>
          </div>
          <pre class="p-3 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-mono max-h-72 overflow-auto">{{ preview.json }}</pre>
        </section>
      }

      <!-- Append-Only Audit Log with SHA-256 Hash-Chain Verification -->
      <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 class="font-display text-base font-bold text-slate-900">Access &amp; Clinical Audit Trail</h2>
            @if (store.auditData(); as aud) {
              <p class="text-xs mt-0.5" [class]="aud.chainVerified ? 'text-[#007F3B] font-semibold' : 'text-red-700 font-semibold'">
                {{ aud.chainVerified
                  ? 'SHA-256 Hash Chain Verified (' + aud.verifiedCount + ' sequential records intact; note: DB append-only requires external WORM shipping in production)'
                  : 'Hash Chain Mismatch at seqId ' + aud.brokenAtSeqId }}
              </p>
            }
          </div>
          <button
            type="button"
            (click)="store.loadAuditEvents()"
            class="min-h-[36px] px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer self-start"
          >
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">verified_user</mat-icon>
            <span>Re-verify Hash Chain</span>
          </button>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-slate-200 bg-slate-50 text-slate-600">
                <th class="py-2.5 px-3 font-semibold">Seq</th>
                <th class="py-2.5 px-3 font-semibold">Timestamp</th>
                <th class="py-2.5 px-3 font-semibold">Actor &amp; Role</th>
                <th class="py-2.5 px-3 font-semibold">Action &amp; Resource</th>
                <th class="py-2.5 px-3 font-semibold">Outcome</th>
                <th class="py-2.5 px-3 font-semibold">Event Hash</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (ev of store.auditData()?.events ?? []; track ev.id) {
                <tr [class]="ev.outcome === 'deny' ? 'bg-red-50/60' : 'hover:bg-slate-50'">
                  <td class="py-2.5 px-3 font-mono tabular-nums text-slate-500">#{{ ev.seqId }}</td>
                  <td class="py-2.5 px-3 font-mono tabular-nums text-slate-600">{{ store.formatDateTime(ev.eventTime) }}</td>
                  <td class="py-2.5 px-3">
                    <div class="font-medium text-slate-900">{{ ev.actorName }}</div>
                    <div class="text-slate-500">{{ ev.actorRole }} · {{ ev.organisationId }}</div>
                  </td>
                  <td class="py-2.5 px-3">
                    <div class="font-mono text-slate-900">{{ ev.action }}</div>
                    <div class="text-slate-600">{{ ev.resourceType }} {{ ev.resourceId }} {{ ev.reason ? '· ' + ev.reason : '' }}</div>
                  </td>
                  <td class="py-2.5 px-3 font-semibold" [class]="ev.outcome === 'deny' ? 'text-[#B91C1C]' : 'text-[#007F3B]'">
                    {{ ev.outcome }}
                  </td>
                  <td class="py-2.5 px-3 font-mono text-slate-500">{{ ev.eventHash.slice(0, 12) }}...</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>

      <!-- Durable Integration Outbox -->
      <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 class="font-display text-base font-bold text-slate-900">Durable Integration Outbox ({{ store.outboxEvents().length }})</h2>
        </div>
        <div class="divide-y divide-slate-200">
          @for (ob of store.outboxEvents(); track ob.id) {
            <div class="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div class="space-y-1">
                <div class="font-mono font-semibold text-slate-900">{{ ob.eventType }}</div>
                <div class="text-slate-600">
                  {{ ob.aggregateType }} {{ ob.aggregateId }} · Status: <strong>{{ ob.status }}</strong> · Attempts: {{ ob.attempts }}
                </div>
                @if (ob.lastError) {
                  <div class="text-red-700">{{ ob.lastError }}</div>
                }
              </div>
              <div class="flex gap-2 shrink-0">
                <button
                  type="button"
                  (click)="store.retryOutbox(ob.id, true)"
                  class="px-3 py-1.5 bg-white border border-amber-300 text-amber-900 font-medium rounded-lg cursor-pointer"
                >
                  Simulate Retry Failure
                </button>
                <button
                  type="button"
                  (click)="store.retryOutbox(ob.id, false)"
                  class="px-3 py-1.5 bg-[#005EB8] text-white font-semibold rounded-lg cursor-pointer"
                >
                  Deliver Now
                </button>
              </div>
            </div>
          }
        </div>
      </section>

      <!-- NHS Clinical Safety & IG Deployment Readiness -->
      <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
        <h2 class="font-display text-base font-bold text-slate-900">NHS Deployment Governance &amp; Control Boundaries</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-700 leading-relaxed">
          <div class="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <div class="font-bold text-slate-900">Clinical Safety (DCB0129 &amp; DCB0160)</div>
            <p>
              Implemented in prototype: atomic signing, immutable signed notes, explicit allergy assertions, unmerged duplicates, and corrected-result review gates. Required prior to clinical deployment: qualified Clinical Safety Officer (CSO) appointment, formal Hazard Log, and signed DCB0129/DCB0160 Clinical Safety Case Reports.
            </p>
          </div>
          <div class="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
            <div class="font-bold text-slate-900">Information Governance &amp; Interoperability (DSPT / DTAC / DAPB4020)</div>
            <p>
              Implemented in prototype: local OIDC adapter, patient-level RBAC, break-glass audit, SHA-256 audit chain, and UK Core FHIR R4 mock bundles. Required for live NHS connectivity: NHS CIS2 onboarding, PDS FHIR API accreditation, WORM audit export, DSPT publication, and DTAC assessment.
            </p>
          </div>
        </div>
      </section>
    </div>
  `,
})
export class AdminViewComponent implements OnInit {
  store = inject(ClinicalStore);
  jsonPreview = signal<{ title: string; json: string } | null>(null);

  ngOnInit(): void {
    void this.store.loadAuditEvents();
    void this.store.loadOutbox();
    void this.store.loadSettings();
  }

  isAiEnabled(): boolean {
    const ai = this.store.settings()['ai_drafting_adapter'] as { enabled?: boolean } | undefined;
    return Boolean(ai?.enabled);
  }

  async toggleAi(): Promise<void> {
    await this.store.toggleAiAdapter(!this.isAiEnabled());
  }

  async runBackup(): Promise<void> {
    const snap = await this.store.exportBackupSnapshot();
    this.jsonPreview.set({
      title: 'Protected Database Backup Snapshot (JSON)',
      json: JSON.stringify(snap, null, 2),
    });
  }

  async inspectFhir(): Promise<void> {
    const pid = this.store.selectedPatientId() ?? 'pat-arthur';
    const bundle = await this.store.fetchFhirBundle(pid);
    this.jsonPreview.set({
      title: `FHIR R4 UK Core Mock Collection Bundle (${pid})`,
      json: JSON.stringify(bundle, null, 2),
    });
  }
}
