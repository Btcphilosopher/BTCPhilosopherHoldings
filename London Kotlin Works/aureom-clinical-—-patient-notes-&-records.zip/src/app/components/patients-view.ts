import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';
import type { DuplicateCandidate, Patient } from '../../shared/clinical-types';

@Component({
  selector: 'app-patients-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 class="font-display text-2xl font-bold text-slate-900">Patients &amp; Identity Management</h1>
          <p class="text-xs text-slate-600 mt-0.5">
            Demographic matches are separated from PDS-verified identity. Duplicate records are never auto-merged.
          </p>
        </div>
        <button
          type="button"
          (click)="showRegisterForm.set(!showRegisterForm())"
          class="min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer self-start"
        >
          <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">person_add</mat-icon>
          <span>{{ showRegisterForm() ? 'Close Registration' : 'Register Synthetic Patient' }}</span>
        </button>
      </div>

      <!-- Search Bar -->
      <form [formGroup]="searchForm" (ngSubmit)="onSearch()" class="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row gap-3">
        <div class="flex-1">
          <label for="patient-search-input" class="sr-only">Search by patient name, MRN, or NHS number</label>
          <input
            id="patient-search-input"
            type="text"
            formControlName="query"
            placeholder="Search by surname, given name, MRN, or synthetic NHS number (e.g. Holloway or 999)..."
            class="w-full min-h-[42px] px-3.5 py-2 border border-slate-300 rounded-lg text-sm text-slate-900 focus:border-[#005EB8] focus:outline-none"
          />
        </div>
        <button
          type="submit"
          class="min-h-[42px] px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg inline-flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
        >
          <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">search</mat-icon>
          <span>Search Directory</span>
        </button>
      </form>

      <!-- Duplicate Warning Banner after Registration -->
      @if (registrationWarnings().length > 0) {
        <div role="alert" class="bg-amber-50 border border-amber-300 rounded-xl p-4 space-y-2">
          <div class="font-display text-sm font-bold text-amber-950">
            Demographic Match Warning — Record Created Separately (Not Auto-Merged)
          </div>
          @for (dup of registrationWarnings(); track dup.candidatePatient.id) {
            <p class="text-xs text-amber-900">
              Matched existing record: <strong>{{ dup.candidatePatient.familyName.toUpperCase() }}, {{ dup.candidatePatient.givenNames }}</strong>
              ({{ dup.candidatePatient.internalMrn }} · DOB {{ dup.candidatePatient.dob }}) — {{ dup.warningMessage }}
            </p>
          }
        </div>
      }

      <!-- New Synthetic Patient Registration Form -->
      @if (showRegisterForm()) {
        <form [formGroup]="registerForm" (ngSubmit)="onRegister()" class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <h2 class="font-display text-base font-semibold text-slate-900 border-b border-slate-100 pb-3">
            Register New Synthetic Patient
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label for="reg-family-name" class="block font-medium text-slate-700 mb-1">Family Name *</label>
              <input id="reg-family-name" formControlName="familyName" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm" />
            </div>
            <div>
              <label for="reg-given-names" class="block font-medium text-slate-700 mb-1">Given Names *</label>
              <input id="reg-given-names" formControlName="givenNames" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm" />
            </div>
            <div>
              <label for="reg-dob" class="block font-medium text-slate-700 mb-1">Date of Birth *</label>
              <input id="reg-dob" type="date" formControlName="dob" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm" />
            </div>
            <div>
              <label for="reg-sex" class="block font-medium text-slate-700 mb-1">Sex at Birth</label>
              <select id="reg-sex" formControlName="sexAtBirth" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm bg-white">
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Indeterminate">Indeterminate</option>
              </select>
            </div>
            <div>
              <label for="reg-nhs" class="block font-medium text-slate-700 mb-1">Synthetic NHS Number (999 prefix)</label>
              <input id="reg-nhs" formControlName="nhsNumber" placeholder="999 000 0000" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm font-mono" />
            </div>
            <div>
              <label for="reg-ver" class="block font-medium text-slate-700 mb-1">Verification Status</label>
              <select id="reg-ver" formControlName="nhsVerificationStatus" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm bg-white">
                <option value="unverified">Unverified Demographic Match</option>
                <option value="trace_pending">PDS Trace Pending</option>
                <option value="verified_pds">Verified PDS (Simulated)</option>
                <option value="not_provided">Not Provided</option>
              </select>
            </div>
            <div>
              <label for="reg-phone" class="block font-medium text-slate-700 mb-1">Telephone</label>
              <input id="reg-phone" formControlName="phone" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm" />
            </div>
            <div>
              <label for="reg-addr" class="block font-medium text-slate-700 mb-1">Address Line 1</label>
              <input id="reg-addr" formControlName="addressLine1" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm" />
            </div>
            <div>
              <label for="reg-gp" class="block font-medium text-slate-700 mb-1">GP Practice Name</label>
              <input id="reg-gp" formControlName="gpPracticeName" class="w-full min-h-[40px] px-3 border border-slate-300 rounded-lg text-sm" />
            </div>
          </div>
          <div class="flex justify-end gap-2">
            <button
              type="submit"
              [disabled]="registerForm.invalid"
              class="min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] disabled:opacity-50 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              Save Synthetic Patient
            </button>
          </div>
        </form>
      }

      <!-- Active Patient Duplicate Merge Panel (when active patient has demographic match) -->
      @if (store.patientOverview(); as ov) {
        @if (ov.duplicateCandidates.length > 0) {
          <section class="bg-white border border-amber-300 rounded-xl p-5 space-y-3">
            <h2 class="font-display text-base font-semibold text-slate-900">
              Authorised Duplicate Merge Workflow for {{ ov.patient.familyName.toUpperCase() }}, {{ ov.patient.givenNames }}
            </h2>
            <p class="text-xs text-slate-600">
              Unverified demographic match(es) found. Merging preserves all external identifiers, clinical notes, provenance, and demographic history.
            </p>
            @for (dup of ov.duplicateCandidates; track dup.candidatePatient.id) {
              <div class="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                <div class="text-xs space-y-1">
                  <div class="font-semibold text-slate-900">
                    Candidate: {{ dup.candidatePatient.familyName.toUpperCase() }}, {{ dup.candidatePatient.givenNames }}
                    ({{ dup.candidatePatient.internalMrn }})
                  </div>
                  <div class="text-slate-600">
                    {{ dup.matchBasis }} · {{ dup.confidenceLabel }} · NHS: {{ dup.candidatePatient.nhsNumber ?? 'Not Provided' }}
                  </div>
                </div>
                <div class="flex items-center gap-2">
                  <button
                    type="button"
                    (click)="onMerge(dup.candidatePatient.id, ov.patient.id)"
                    class="min-h-[38px] px-3.5 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap"
                  >
                    Merge Candidate Into Verified Record
                  </button>
                </div>
              </div>
            }
          </section>
        }
      }

      <!-- Patient Results List -->
      <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <h2 class="font-display text-base font-semibold text-slate-900">
            Patient Directory ({{ store.searchResults().patients.length }})
          </h2>
          @if (store.searchResults().crossOrgCount > 0) {
            <span class="text-xs text-[#B45309] font-medium">
              {{ store.searchResults().crossOrgCount }} external trust record(s) require break-glass or care relationship
            </span>
          }
        </div>

        <div class="divide-y divide-slate-200">
          @for (pat of store.searchResults().patients; track pat.id) {
            <div class="p-4 lg:px-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div class="space-y-1">
                <div class="flex flex-wrap items-baseline gap-2.5">
                  <span class="font-display font-bold text-slate-900 text-sm">
                    {{ pat.familyName.toUpperCase() }}, {{ pat.givenNames }}
                  </span>
                  <span class="text-xs font-mono text-slate-700 tabular-nums">
                    NHS {{ pat.nhsNumber ?? 'Not Provided' }}
                  </span>
                  <span class="text-xs font-medium"
                    [class]="pat.nhsVerificationStatus === 'verified_pds' ? 'text-[#007F3B]' : 'text-[#B45309]'">
                    {{ pat.nhsVerificationStatus }}
                  </span>
                  <span class="text-xs text-slate-400">·</span>
                  <span class="text-xs font-mono text-slate-500 tabular-nums">{{ pat.internalMrn }}</span>
                </div>
                <div class="text-xs text-slate-600 flex flex-wrap gap-x-2.5">
                  <span>DOB {{ pat.dob }}</span>
                  <span aria-hidden="true">·</span>
                  <span>{{ pat.sexAtBirth }}</span>
                  <span aria-hidden="true">·</span>
                  <span>GP: {{ pat.gpPractice.practiceName }}</span>
                  <span aria-hidden="true">·</span>
                  <span>Org: {{ pat.organisationId }}</span>
                </div>
              </div>

              <div class="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  (click)="store.openPatient(pat.id, 'today')"
                  class="min-h-[40px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <mat-icon class="!text-[17px] !w-[17px] !h-[17px]">folder_open</mat-icon>
                  <span>Open Record</span>
                </button>
              </div>
            </div>
          } @empty {
            <div class="p-8 text-center text-sm text-slate-500">
              No matching synthetic patients found. Try searching "Pendelton", "Krishnan", or "Holloway" (external trust test).
            </div>
          }
        </div>
      </section>

      <!-- Break-Glass Emergency Access Modal/Card when 403 Permission Denied occurs -->
      @if (store.errorState(); as err) {
        @if (err.deniedPatientId) {
          <section role="alert" class="bg-red-50 border border-red-300 rounded-xl p-5 space-y-3">
            <div class="flex items-center gap-2 text-red-900">
              <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">lock</mat-icon>
              <h3 class="font-display text-base font-bold">Cross-Organisation Access Denied</h3>
            </div>
            <p class="text-xs text-red-900">{{ err.message }}</p>
            <form [formGroup]="breakGlassForm" (ngSubmit)="onBreakGlass(err.deniedPatientId!)" class="space-y-3 pt-2">
              <label for="bg-reason-input" class="block text-xs font-semibold text-red-950">
                Audited Emergency Break-Glass Justification (minimum 10 characters; reviewed by Information Governance):
              </label>
              <div class="flex flex-col sm:flex-row gap-2">
                <input
                  id="bg-reason-input"
                  formControlName="reason"
                  placeholder="e.g. Emergency acute presentation — unconscious patient requiring allergy check"
                  class="flex-1 min-h-[40px] px-3 border border-red-300 bg-white rounded-lg text-sm"
                />
                <button
                  type="submit"
                  [disabled]="breakGlassForm.invalid"
                  class="min-h-[40px] px-4 py-2 bg-[#B91C1C] hover:bg-red-800 disabled:opacity-50 text-white text-xs font-semibold rounded-lg cursor-pointer whitespace-nowrap"
                >
                  Invoke Emergency Access
                </button>
              </div>
            </form>
          </section>
        }
      }
    </div>
  `,
})
export class PatientsViewComponent implements OnInit {
  store = inject(ClinicalStore);
  showRegisterForm = signal(false);
  registrationWarnings = signal<DuplicateCandidate[]>([]);

  searchForm = new FormGroup({
    query: new FormControl('', { nonNullable: true }),
  });

  registerForm = new FormGroup({
    familyName: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    givenNames: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    dob: new FormControl('1970-01-01', { nonNullable: true, validators: [Validators.required] }),
    sexAtBirth: new FormControl('Female', { nonNullable: true }),
    nhsNumber: new FormControl('', { nonNullable: true }),
    nhsVerificationStatus: new FormControl<Patient['nhsVerificationStatus']>('unverified', { nonNullable: true }),
    phone: new FormControl('07700 900123', { nonNullable: true }),
    email: new FormControl('synthetic@example.org', { nonNullable: true }),
    addressLine1: new FormControl('12 High Street', { nonNullable: true }),
    city: new FormControl('Meadowbank', { nonNullable: true }),
    postcode: new FormControl('MB2 1AA', { nonNullable: true }),
    gpPracticeName: new FormControl('Meadowbank Health Centre', { nonNullable: true }),
    gpOdsCode: new FormControl('G82019', { nonNullable: true }),
  });

  breakGlassForm = new FormGroup({
    reason: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(10)] }),
  });

  ngOnInit(): void {
    void this.store.loadPatients('');
  }

  onSearch(): void {
    void this.store.loadPatients(this.searchForm.controls.query.value);
  }

  async onRegister(): Promise<void> {
    if (this.registerForm.invalid) return;
    const res = await this.store.registerPatient(this.registerForm.getRawValue());
    this.registrationWarnings.set(res.duplicateWarnings);
    this.showRegisterForm.set(false);
    await this.store.openPatient(res.patient.id, 'today');
  }

  async onMerge(sourceId: string, targetId: string): Promise<void> {
    await this.store.mergePatients(
      sourceId,
      targetId,
      'Verified Name, DOB, and local address match with verified PDS record by clinician.'
    );
  }

  async onBreakGlass(patientId: string): Promise<void> {
    if (this.breakGlassForm.invalid) return;
    await this.store.requestBreakGlass(patientId, this.breakGlassForm.controls.reason.value);
    this.breakGlassForm.reset();
  }
}
