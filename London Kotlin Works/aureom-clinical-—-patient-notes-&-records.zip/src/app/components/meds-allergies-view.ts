import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';
import type { Allergy, MedicationConceptType } from '../../shared/clinical-types';

@Component({
  selector: 'app-meds-allergies-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.patientOverview(); as ov) {
      <div class="space-y-6">
        <div>
          <h1 class="font-display text-2xl font-bold text-slate-900">Medications, Reconciliation &amp; Allergies</h1>
          <p class="text-xs text-slate-600 mt-0.5">
            Prescribing, dispensing, administration, and patient-reported use are stored as separate concepts. Prescription requests use a simulated prototype adapter only.
          </p>
        </div>

        <!-- Allergies & Adverse Reactions Section -->
        <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <div>
              <h2 class="font-display text-base font-bold text-slate-900">Allergy &amp; Adverse Reaction Status</h2>
              <p class="text-xs text-slate-600 mt-0.5">
                Current Documented Assertion:
                <strong
                  [class]="ov.patient.allergyAssertionStatus === 'assessed_with_allergies' ? 'text-[#B91C1C]' : ov.patient.allergyAssertionStatus === 'no_known_allergies' ? 'text-[#007F3B]' : 'text-[#B45309]'">
                  {{ ov.patient.allergyAssertionStatus.replaceAll('_', ' ').toUpperCase() }}
                </strong>
              </p>
            </div>
            <div class="flex flex-wrap gap-2">
              <button
                type="button"
                (click)="store.updateAllergyAssertion(ov.patient.id, 'no_known_allergies')"
                class="min-h-[36px] px-3 py-1.5 bg-white border border-emerald-300 hover:bg-emerald-50 text-emerald-900 text-xs font-semibold rounded-lg cursor-pointer"
              >
                Assert No Known Allergies
              </button>
              <button
                type="button"
                (click)="showAllergyForm.set(!showAllergyForm())"
                class="min-h-[36px] px-3 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                Record Allergy
              </button>
            </div>
          </div>

          @if (showAllergyForm()) {
            <form [formGroup]="allergyForm" (ngSubmit)="submitAllergy(ov.patient.id)" class="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-3">
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <input formControlName="substance" placeholder="Substance (e.g. Ramipril)" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg" />
                <input formControlName="reaction" placeholder="Reaction (e.g. Dry cough / Angioedema)" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg" />
                <select formControlName="severity" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg">
                  <option value="mild">Mild</option>
                  <option value="moderate">Moderate</option>
                  <option value="severe">Severe</option>
                  <option value="life_threatening">Life-threatening</option>
                </select>
              </div>
              <div class="flex justify-end gap-2">
                <button type="button" (click)="showAllergyForm.set(false)" class="px-3 py-1.5 border border-slate-300 bg-white rounded-lg text-xs cursor-pointer">Cancel</button>
                <button type="submit" [disabled]="allergyForm.invalid" class="px-3 py-1.5 bg-[#005EB8] text-white rounded-lg text-xs font-semibold cursor-pointer">Save Allergy</button>
              </div>
            </form>
          }

          @if (ov.allergies.length === 0) {
            <div class="text-xs text-slate-600">
              @if (ov.patient.allergyAssertionStatus === 'no_known_allergies') {
                Clinician explicitly documented No Known Drug Allergies.
              } @else {
                No allergy entries recorded. Status remains <strong>{{ ov.patient.allergyAssertionStatus.replaceAll('_', ' ') }}</strong> (not defaulted to No Known Allergies).
              }
            </div>
          } @else {
            <div class="divide-y divide-slate-200">
              @for (alg of ov.allergies; track alg.id) {
                <div class="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div>
                    <span class="font-bold text-slate-900 text-sm">{{ alg.substance }}</span>
                    <span class="text-slate-400 mx-1.5">·</span>
                    <span class="font-semibold text-[#B91C1C]">{{ alg.severity.replace('_', ' ') }}</span>
                    <span class="text-slate-400 mx-1.5">·</span>
                    <span class="text-slate-700">{{ alg.reaction }}</span>
                  </div>
                  <div class="text-slate-500">
                    {{ alg.verificationStatus }} · {{ alg.provenance }}
                  </div>
                </div>
              }
            </div>
          }
        </section>

        <!-- Medications Section -->
        <section class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <div>
              <h2 class="font-display text-base font-bold text-slate-900">Medication History &amp; Reconciliation</h2>
              <p class="text-xs text-slate-600">Distinct concepts: Prescribing, Dispensing, Administration, Patient-Reported.</p>
            </div>
            <button
              type="button"
              (click)="showMedForm.set(!showMedForm())"
              class="min-h-[38px] px-3.5 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer self-start"
            >
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">medication</mat-icon>
              <span>{{ showMedForm() ? 'Close Form' : 'Add Medication / Simulated Rx' }}</span>
            </button>
          </div>

          @if (showMedForm()) {
            <form [formGroup]="medForm" (ngSubmit)="submitMedication(ov.patient.id)" class="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-3 text-xs">
              <div class="p-2.5 bg-amber-50 border border-amber-200 rounded text-amber-950">
                <strong>Prototype Notice:</strong> Prescription requests use a simulated integration adapter only. No live NHS EPS prescribing or automated dosing recommendations are performed.
              </div>
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select formControlName="conceptType" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg">
                  <option value="prescribing">Prescribing Request (Simulated)</option>
                  <option value="patient_reported">Patient-Reported Use</option>
                  <option value="dispensing">Dispensing Record</option>
                  <option value="administration">Administration Record</option>
                </select>
                <input formControlName="drugName" placeholder="Drug Name (e.g. Furosemide)" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg" />
                <input formControlName="strength" placeholder="Strength (e.g. 40 mg)" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg" />
                <input formControlName="dose" placeholder="Dose (e.g. 40 mg)" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg" />
                <input formControlName="route" placeholder="Route (e.g. Oral)" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg" />
                <input formControlName="frequency" placeholder="Frequency (e.g. Once daily morning)" class="min-h-[38px] px-3 border border-slate-300 bg-white rounded-lg" />
              </div>
              <label class="inline-flex items-center gap-2 cursor-pointer">
                <input type="checkbox" formControlName="requestSimulatedPrescription" class="w-4 h-4 accent-[#005EB8]" />
                <span>Queue simulated EPS prescription request to integration outbox</span>
              </label>
              <div class="flex justify-end gap-2">
                <button type="button" (click)="showMedForm.set(false)" class="px-3 py-1.5 border border-slate-300 bg-white rounded-lg cursor-pointer">Cancel</button>
                <button type="submit" [disabled]="medForm.invalid" class="px-4 py-1.5 bg-[#005EB8] text-white font-semibold rounded-lg cursor-pointer">Save Medication Entry</button>
              </div>
            </form>
          }

          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
              <thead>
                <tr class="border-b border-slate-200 bg-slate-50 text-slate-600">
                  <th class="py-3 px-3 font-semibold">Concept</th>
                  <th class="py-3 px-3 font-semibold">Medication &amp; dm+d</th>
                  <th class="py-3 px-3 font-semibold">Dose / Route / Frequency</th>
                  <th class="py-3 px-3 font-semibold">Reconciliation</th>
                  <th class="py-3 px-3 font-semibold">Source &amp; Dates</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-200">
                @for (med of ov.medications; track med.id) {
                  <tr [class]="med.reconciliationStatus === 'discrepancy' ? 'bg-amber-50/50' : 'hover:bg-slate-50'">
                    <td class="py-3 px-3 font-semibold text-[#003087]">{{ med.conceptType.replace('_', ' ') }}</td>
                    <td class="py-3 px-3">
                      <div class="font-semibold text-slate-900">{{ med.drugName }} {{ med.strength }}</div>
                      <div class="font-mono text-slate-500">dm+d {{ med.dmdCode }}</div>
                    </td>
                    <td class="py-3 px-3 text-slate-800">{{ med.dose }} · {{ med.route }} · {{ med.frequency }}</td>
                    <td class="py-3 px-3 font-semibold"
                      [class]="med.reconciliationStatus === 'discrepancy' ? 'text-[#B45309]' : 'text-[#007F3B]'">
                      {{ med.reconciliationStatus }}
                    </td>
                    <td class="py-3 px-3 text-slate-600">
                      <div>{{ med.source }}</div>
                      <div class="tabular-nums">From {{ med.startDate }} · {{ med.status }}</div>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </section>
      </div>
    }
  `,
})
export class MedsAllergiesViewComponent {
  store = inject(ClinicalStore);
  showAllergyForm = signal(false);
  showMedForm = signal(false);

  allergyForm = new FormGroup({
    substance: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    reaction: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    severity: new FormControl<Allergy['severity']>('moderate', { nonNullable: true }),
  });

  medForm = new FormGroup({
    conceptType: new FormControl<MedicationConceptType>('prescribing', { nonNullable: true }),
    drugName: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    strength: new FormControl('40 mg', { nonNullable: true }),
    dose: new FormControl('40 mg', { nonNullable: true, validators: [Validators.required] }),
    route: new FormControl('Oral', { nonNullable: true }),
    frequency: new FormControl('Once daily', { nonNullable: true }),
    requestSimulatedPrescription: new FormControl(false, { nonNullable: true }),
  });

  async submitAllergy(patientId: string): Promise<void> {
    if (this.allergyForm.invalid) return;
    await this.store.updateAllergyAssertion(patientId, 'assessed_with_allergies', {
      substance: this.allergyForm.controls.substance.value,
      code: 'SNOMED-clinical-entry',
      reaction: this.allergyForm.controls.reaction.value,
      severity: this.allergyForm.controls.severity.value,
      verificationStatus: 'confirmed',
      provenance: 'Clinician Assessment',
    });
    this.allergyForm.reset({ severity: 'moderate' });
    this.showAllergyForm.set(false);
  }

  async submitMedication(patientId: string): Promise<void> {
    if (this.medForm.invalid) return;
    const raw = this.medForm.getRawValue();
    await this.store.addMedication(patientId, {
      encounterId: this.store.activeEncounter()?.id ?? null,
      conceptType: raw.conceptType,
      drugName: raw.drugName,
      dmdCode: 'dm+d-prototype',
      strength: raw.strength,
      dose: raw.dose,
      route: raw.route,
      frequency: raw.frequency,
      source: raw.conceptType === 'patient_reported' ? 'Patient Self-Report' : 'Clinic Consultation Record',
      requestSimulatedPrescription: raw.requestSimulatedPrescription,
    });
    this.medForm.reset({ conceptType: 'prescribing', strength: '40 mg', dose: '40 mg', route: 'Oral', frequency: 'Once daily', requestSimulatedPrescription: false });
    this.showMedForm.set(false);
  }
}
