import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';
import type { Encounter, TaskType } from '../../shared/clinical-types';

@Component({
  selector: 'app-tasks-docs-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.patientOverview(); as ov) {
      @if (store.activeNav() === 'consultations') {
        <div class="space-y-6">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 class="font-display text-2xl font-bold text-slate-900">Consultations &amp; Encounters</h1>
              <p class="text-xs text-slate-600 mt-0.5">Encounter type, clinic/ward location, responsible clinician, and occurrence vs documentation timestamps.</p>
            </div>
            <button
              type="button"
              (click)="showEncForm.set(!showEncForm())"
              class="min-h-[40px] px-4 py-2 bg-[#005EB8] text-white text-xs font-semibold rounded-lg cursor-pointer self-start"
            >
              {{ showEncForm() ? 'Close' : 'Start / Confirm New Encounter' }}
            </button>
          </div>

          @if (showEncForm()) {
            <form [formGroup]="encForm" (ngSubmit)="submitEncounter(ov.patient.id)" class="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs">
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select formControlName="encounterType" class="min-h-[38px] px-3 border border-slate-300 rounded-lg bg-white">
                  <option value="outpatient">Outpatient Clinic</option>
                  <option value="inpatient">Inpatient Ward</option>
                  <option value="telehealth">Telehealth</option>
                  <option value="emergency">Acute / Emergency</option>
                </select>
                <input formControlName="location" placeholder="Wing / Department" class="min-h-[38px] px-3 border border-slate-300 rounded-lg" />
                <input formControlName="wardOrClinic" placeholder="Clinic Room / Ward Bay" class="min-h-[38px] px-3 border border-slate-300 rounded-lg" />
              </div>
              <input formControlName="presentingConcern" placeholder="Presenting concern..." class="w-full min-h-[38px] px-3 border border-slate-300 rounded-lg" />
              <div class="flex justify-end">
                <button type="submit" [disabled]="encForm.invalid" class="px-4 py-2 bg-[#005EB8] text-white font-semibold rounded-lg cursor-pointer">Confirm Encounter</button>
              </div>
            </form>
          }

          <div class="divide-y divide-slate-200 bg-white border border-slate-200 rounded-xl">
            @for (enc of ov.encounters; track enc.id) {
              <div class="p-4 space-y-1">
                <div class="flex flex-wrap justify-between gap-2">
                  <span class="font-display font-bold text-slate-900 text-sm">{{ enc.wardOrClinic }}</span>
                  <span class="text-xs font-semibold text-[#005EB8]">{{ enc.status }} ({{ enc.encounterType }})</span>
                </div>
                <p class="text-sm text-slate-800">{{ enc.presentingConcern }}</p>
                <div class="text-xs text-slate-500 tabular-nums">
                  Responsible: {{ enc.responsibleClinicianName }} · Occurred {{ store.formatDateTime(enc.occurredAt) }} · Documented {{ store.formatDateTime(enc.documentedAt) }}
                </div>
              </div>
            }
          </div>
        </div>
      } @else if (store.activeNav() === 'care-plans') {
        <div class="space-y-6">
          <h1 class="font-display text-2xl font-bold text-slate-900">Care Plans</h1>
          @for (cp of ov.carePlans; track cp.id) {
            <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div class="flex flex-wrap justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <h2 class="font-display text-base font-bold text-slate-900">{{ cp.title }}</h2>
                  <p class="text-xs text-slate-600">{{ cp.category }} · Author: {{ cp.authorName }} · Review Date: {{ cp.reviewDate }}</p>
                </div>
                <span class="text-xs font-semibold text-[#007F3B]">{{ cp.status }}</span>
              </div>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div class="space-y-2">
                  <h3 class="font-semibold text-slate-700 uppercase">Clinical Goals</h3>
                  @for (g of cp.goals; track g.description) {
                    <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                      <div class="font-medium text-slate-900">{{ g.description }}</div>
                      <div class="text-slate-500 mt-0.5">Target: {{ g.targetDate }} · {{ g.status }}</div>
                    </div>
                  }
                </div>
                <div class="space-y-2">
                  <h3 class="font-semibold text-slate-700 uppercase">Interventions</h3>
                  @for (iv of cp.interventions; track iv.action) {
                    <div class="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                      <div class="font-medium text-slate-900">{{ iv.action }}</div>
                      <div class="text-slate-500 mt-0.5">{{ iv.frequency }} · Owner: {{ iv.owner }}</div>
                    </div>
                  }
                </div>
              </div>
            </article>
          } @empty {
            <div class="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">No active care plans recorded.</div>
          }
        </div>
      } @else if (store.activeNav() === 'tasks') {
        <div class="space-y-6">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 class="font-display text-2xl font-bold text-slate-900">Tasks, Handovers &amp; Patient Summary</h1>
              <p class="text-xs text-slate-600 mt-0.5">Separates creation, delivery, acceptance, completion evidence, and clinician review of patient-facing summaries.</p>
            </div>
            <button
              type="button"
              (click)="showTaskForm.set(!showTaskForm())"
              class="min-h-[40px] px-4 py-2 bg-[#005EB8] text-white text-xs font-semibold rounded-lg cursor-pointer self-start"
            >
              {{ showTaskForm() ? 'Close' : 'Assign Follow-up / Handover' }}
            </button>
          </div>

          @if (showTaskForm()) {
            <form [formGroup]="taskForm" (ngSubmit)="submitTask(ov.patient.id)" class="bg-white border border-slate-200 rounded-xl p-5 space-y-3 text-xs">
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select formControlName="taskType" class="min-h-[38px] px-3 border border-slate-300 rounded-lg bg-white">
                  <option value="follow_up">Follow-up Appointment</option>
                  <option value="results_review">Results Review</option>
                  <option value="referral_prep">Referral Preparation</option>
                  <option value="handover">Team Handover</option>
                  <option value="discharge_prep">Discharge Preparation</option>
                  <option value="patient_info">Patient-Information Delivery</option>
                </select>
                <select formControlName="priority" class="min-h-[38px] px-3 border border-slate-300 rounded-lg bg-white">
                  <option value="routine">Routine</option>
                  <option value="urgent">Urgent</option>
                  <option value="stat">STAT / Immediate</option>
                </select>
                <input formControlName="assignedTeam" placeholder="Assigned Team" class="min-h-[38px] px-3 border border-slate-300 rounded-lg" />
              </div>
              <input formControlName="title" placeholder="Task title (e.g. Arrange 2-week cardiology follow-up & echo)" class="w-full min-h-[38px] px-3 border border-slate-300 rounded-lg" />
              <textarea rows="2" formControlName="description" placeholder="Task instructions and clinical context..." class="w-full p-2.5 border border-slate-300 rounded-lg"></textarea>
              <div class="flex justify-end">
                <button type="submit" [disabled]="taskForm.invalid" class="px-4 py-2 bg-[#005EB8] text-white font-semibold rounded-lg cursor-pointer">Create Task</button>
              </div>
            </form>
          }

          <div class="space-y-4">
            @for (task of ov.tasks; track task.id) {
              <article class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div class="space-y-1">
                    <div class="flex flex-wrap items-center gap-2 text-xs">
                      <span class="font-bold"
                        [class]="task.priority === 'stat' ? 'text-[#B91C1C]' : task.priority === 'urgent' ? 'text-[#B45309]' : 'text-[#005EB8]'">
                        {{ task.priority.toUpperCase() }}
                      </span>
                      <span class="text-slate-400">·</span>
                      <span class="text-slate-600">{{ task.taskType.replace('_', ' ') }}</span>
                      <span class="text-slate-400">·</span>
                      <span class="font-semibold text-slate-900">Status: {{ task.status }}</span>
                    </div>
                    <h2 class="font-display text-base font-bold text-slate-900">{{ task.title }}</h2>
                    <p class="text-xs text-slate-700">{{ task.description }}</p>
                    <div class="text-xs text-slate-500 tabular-nums">
                      Owner: {{ task.ownerName }} ({{ task.assignedTeam }}) · Due {{ store.formatDateTime(task.dueAt) }}
                    </div>
                  </div>

                  <div class="flex flex-wrap gap-2 shrink-0">
                    @if (task.status === 'created' || task.status === 'delivered') {
                      <button
                        type="button"
                        (click)="store.transitionTask(task.id, 'accepted')"
                        class="min-h-[36px] px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Accept Task
                      </button>
                    }
                    @if (task.status !== 'completed' && task.status !== 'cancelled') {
                      <button
                        type="button"
                        (click)="completeTaskWithEvidence(task.id)"
                        class="min-h-[36px] px-3 py-1.5 bg-[#007F3B] hover:bg-[#00632E] text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Complete with Evidence
                      </button>
                    }
                  </div>
                </div>

                @if (task.completionEvidence) {
                  <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-950">
                    <strong>Completion Evidence:</strong> {{ task.completionEvidence }} ({{ store.formatDateTime(task.completedAt) }})
                  </div>
                }

                @if (task.patientSummaryText !== null) {
                  <div class="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2.5">
                    <div class="flex items-center justify-between text-xs">
                      <strong class="text-[#003087]">Patient-Friendly Consultation Summary (Clinician Review Before Sharing)</strong>
                      @if (task.patientSummaryApprovedAt) {
                        <span class="text-[#007F3B] font-semibold">Approved for Release {{ store.formatDateTime(task.patientSummaryApprovedAt) }}</span>
                      } @else {
                        <span class="text-[#B45309] font-semibold">Pending Clinician Approval</span>
                      }
                    </div>
                    <p class="text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">{{ task.patientSummaryText }}</p>
                    @if (!task.patientSummaryApprovedAt) {
                      <button
                        type="button"
                        (click)="store.transitionTask(task.id, 'completed', 'Patient summary reviewed and approved for release', task.patientSummaryText!)"
                        class="min-h-[36px] px-3.5 py-1.5 bg-[#005EB8] text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        Approve &amp; Release Patient Summary
                      </button>
                    }
                  </div>
                }
              </article>
            }
          </div>
        </div>
      } @else {
        <!-- DOCUMENTS / PROTECTED ATTACHMENTS -->
        <div class="space-y-6">
          <div>
            <h1 class="font-display text-2xl font-bold text-slate-900">Protected Clinical Documents &amp; Attachments</h1>
            <p class="text-xs text-slate-600 mt-0.5">Every attachment read enforces patient-level access checks, verifies SHA-256 integrity, and writes an audit event.</p>
          </div>

          <div class="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
            @for (att of ov.attachments; track att.id) {
              <div class="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div class="space-y-1 text-xs">
                  <div class="font-semibold text-slate-900 text-sm">{{ att.filename }}</div>
                  <div class="text-slate-600">
                    {{ att.classification }} · {{ att.mimeType }} · {{ att.sizeBytes }} bytes · Uploaded by {{ att.uploadedByName }}
                  </div>
                  <div class="font-mono text-[11px] text-slate-500">SHA-256: {{ att.sha256Hex }}</div>
                </div>
                <button
                  type="button"
                  (click)="previewAttachment(att.id)"
                  class="min-h-[38px] px-4 py-1.5 bg-[#005EB8] hover:bg-[#003087] text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">visibility</mat-icon>
                  <span>Inspect Protected Document</span>
                </button>
              </div>
            } @empty {
              <div class="p-8 text-center text-sm text-slate-500">No attachments stored for this patient.</div>
            }
          </div>

          @if (previewedDoc(); as doc) {
            <div class="bg-white border border-slate-300 rounded-xl p-5 space-y-2">
              <div class="flex items-center justify-between">
                <h2 class="font-display text-sm font-bold text-slate-900">{{ doc.filename }}</h2>
                <button type="button" (click)="previewedDoc.set(null)" class="text-xs text-slate-600 hover:underline cursor-pointer">Close</button>
              </div>
              <pre class="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-900 whitespace-pre-wrap">{{ doc.contentText }}</pre>
            </div>
          }
        </div>
      }
    }
  `,
})
export class TasksDocsViewComponent {
  store = inject(ClinicalStore);
  showEncForm = signal(false);
  showTaskForm = signal(false);
  previewedDoc = signal<{ filename: string; contentText: string } | null>(null);

  encForm = new FormGroup({
    encounterType: new FormControl<Encounter['encounterType']>('outpatient', { nonNullable: true }),
    location: new FormControl('Outpatient Wing B', { nonNullable: true, validators: [Validators.required] }),
    wardOrClinic: new FormControl('Cardiology Clinic · Room 4', { nonNullable: true, validators: [Validators.required] }),
    presentingConcern: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });

  taskForm = new FormGroup({
    taskType: new FormControl<TaskType>('follow_up', { nonNullable: true }),
    priority: new FormControl<'routine' | 'urgent' | 'stat'>('urgent', { nonNullable: true }),
    assignedTeam: new FormControl('Cardiology Rapid Access Team', { nonNullable: true }),
    title: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    description: new FormControl('', { nonNullable: true }),
  });

  async submitEncounter(patientId: string): Promise<void> {
    if (this.encForm.invalid) return;
    await this.store.createEncounter(patientId, this.encForm.getRawValue());
    this.showEncForm.set(false);
    this.encForm.controls.presentingConcern.reset('');
  }

  async submitTask(patientId: string): Promise<void> {
    if (this.taskForm.invalid) return;
    const raw = this.taskForm.getRawValue();
    await this.store.createTask(patientId, {
      encounterId: this.store.activeEncounter()?.id ?? null,
      taskType: raw.taskType,
      title: raw.title,
      description: raw.description,
      assignedTeam: raw.assignedTeam,
      priority: raw.priority,
      dueAt: new Date(Date.now() + 7 * 24 * 3600_000).toISOString(),
    });
    this.showTaskForm.set(false);
    this.taskForm.controls.title.reset('');
    this.taskForm.controls.description.reset('');
  }

  async completeTaskWithEvidence(taskId: string): Promise<void> {
    await this.store.transitionTask(
      taskId,
      'completed',
      `Reviewed & completed by ${this.store.session()?.clinician.displayName ?? 'Clinician'} with follow-up plan confirmed.`
    );
  }

  async previewAttachment(attachmentId: string): Promise<void> {
    const res = await this.store.fetchAttachmentContent(attachmentId);
    this.previewedDoc.set({ filename: res.filename, contentText: res.contentText });
  }
}
