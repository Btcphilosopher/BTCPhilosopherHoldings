import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ClinicalStore } from '../services/clinical-store';

@Component({
  selector: 'app-sign-in',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="min-h-screen bg-[#F0F4F5] flex flex-col justify-between p-6 md:p-12">
      <header class="max-w-5xl w-full mx-auto flex flex-wrap items-center justify-between gap-4 border-b border-slate-300/80 pb-5">
        <div class="flex items-baseline gap-3">
          <span class="font-display text-xl font-bold tracking-tight text-[#003087]">AUREOM CLINICAL</span>
          <span class="text-xs font-medium text-slate-600">Patient Notes &amp; Records</span>
        </div>
        <div class="text-xs text-slate-600 tabular-nums">
          Independent Prototype · Synthetic Data Only · Not for Clinical Use
        </div>
      </header>

      <main class="max-w-5xl w-full mx-auto my-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <section class="lg:col-span-5 space-y-5">
          <div class="space-y-3">
            <p class="text-xs font-semibold tracking-wide text-[#005EB8]">
              NHS-Oriented Electronic Patient Records
            </p>
            <h1 class="font-display text-3xl font-bold tracking-tight text-slate-900 leading-tight" style="text-wrap: balance;">
              Sign in via Local OpenID Connect Identity Provider
            </h1>
            <p class="text-sm text-slate-600 leading-relaxed">
              Select a synthetic clinician identity to evaluate worklists, patient identity verification, optimistic concurrency consultation notes, atomic signing, linked amendments, corrected pathology workflows, and hash-chained audit logs.
            </p>
          </div>

          <div class="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <h2 class="font-display text-sm font-semibold text-slate-900">Identity Adapter &amp; Session Controls</h2>
            <dl class="space-y-2 text-xs text-slate-600">
              <div class="flex justify-between gap-4 border-b border-slate-100 pb-2">
                <dt class="font-medium text-slate-700">OIDC Adapter</dt>
                <dd class="text-right font-mono">{{ store.oidcInfo()?.adapter ?? 'Local Dev OIDC Provider' }}</dd>
              </div>
              <div class="flex justify-between gap-4 border-b border-slate-100 pb-2">
                <dt class="font-medium text-slate-700">Token Storage</dt>
                <dd class="text-right">In-memory Bearer (60 min expiry)</dd>
              </div>
              <div class="flex justify-between gap-4">
                <dt class="font-medium text-slate-700">Data Boundary</dt>
                <dd class="text-right">100% Synthetic Clinic Fixtures</dd>
              </div>
            </dl>
          </div>
        </section>

        <section class="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div class="flex items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h2 class="font-display text-lg font-semibold text-slate-900">Select Demonstration Account</h2>
              <p class="text-xs text-slate-600 mt-0.5">
                Each account carries distinct trust, role, and patient-level access permissions.
              </p>
            </div>
          </div>

          @if (store.errorState(); as err) {
            <div role="alert" class="p-3.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-900">
              <strong class="font-semibold">{{ err.code }}:</strong> {{ err.message }}
            </div>
          }

          <div class="divide-y divide-slate-200">
            @for (clinician of store.clinicians(); track clinician.id) {
              <div class="py-3.5 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div class="space-y-1">
                  <div class="flex flex-wrap items-center gap-2">
                    <span class="font-semibold text-slate-900 text-sm">{{ clinician.displayName }}</span>
                    <span class="text-xs text-slate-500">·</span>
                    <span class="text-xs font-medium text-[#005EB8]">{{ clinician.role }}</span>
                  </div>
                  <div class="text-xs text-slate-600 flex flex-wrap items-center gap-x-2 gap-y-0.5">
                    <span>{{ clinician.specialty }}</span>
                    <span aria-hidden="true">·</span>
                    <span>{{ clinician.organisationName }}</span>
                    <span aria-hidden="true">·</span>
                    <span class="font-mono tabular-nums">{{ clinician.gmcOrNmcNumber }}</span>
                  </div>
                </div>

                <button
                  type="button"
                  (click)="store.signIn(clinician.id)"
                  [disabled]="store.loading()"
                  class="min-h-[42px] px-4 py-2 bg-[#005EB8] hover:bg-[#003087] disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">login</mat-icon>
                  <span>Sign In</span>
                </button>
              </div>
            } @empty {
              <div class="py-8 text-center text-sm text-slate-500">
                Loading local OIDC directory...
              </div>
            }
          </div>
        </section>
      </main>

      <footer class="max-w-5xl w-full mx-auto border-t border-slate-300/80 pt-4 text-xs text-slate-600 flex flex-wrap items-center justify-between gap-4">
        <span>Aureom Clinical Prototype · NHS-Inspired Design System · Synthetic Records Only</span>
        <span>All patient identifiers use synthetic 999 test prefixes</span>
      </footer>
    </div>
  `,
})
export class SignInComponent implements OnInit {
  store = inject(ClinicalStore);

  ngOnInit(): void {
    void this.store.loadAuthProviders();
  }
}
