import { DatabaseSync } from 'node:sqlite';
import { sha256Hex, signAttestationPayload, withTransaction } from './db.js';

export function appendAuditEvent(
  db: DatabaseSync,
  params: {
    id: string;
    eventTime: string;
    actorId: string;
    actorName: string;
    actorRole: string;
    organisationId: string;
    action: string;
    resourceType: string;
    resourceId: string;
    patientId: string | null;
    outcome: 'allow' | 'deny';
    reason: string | null;
    metadata: Record<string, unknown>;
  }
): void {
  const lastRow = db
    .prepare('SELECT event_hash FROM audit_events ORDER BY seq_id DESC LIMIT 1')
    .get() as { event_hash: string } | undefined;
  const prevHash = lastRow?.event_hash ?? '0'.repeat(64);
  const metadataJson = JSON.stringify(params.metadata);
  const payload = [
    params.id,
    params.eventTime,
    params.actorId,
    params.actorRole,
    params.organisationId,
    params.action,
    params.resourceType,
    params.resourceId,
    params.patientId ?? '',
    params.outcome,
    params.reason ?? '',
    metadataJson,
    prevHash,
  ].join('|');
  const eventHash = sha256Hex(payload);

  db.prepare(
    `INSERT INTO audit_events (
      id, event_time, actor_id, actor_name, actor_role, organisation_id,
      action, resource_type, resource_id, patient_id, outcome, reason,
      metadata_json, prev_hash, event_hash
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    params.id,
    params.eventTime,
    params.actorId,
    params.actorName,
    params.actorRole,
    params.organisationId,
    params.action,
    params.resourceType,
    params.resourceId,
    params.patientId,
    params.outcome,
    params.reason,
    metadataJson,
    prevHash,
    eventHash
  );
}

export function seedSyntheticClinic(db: DatabaseSync): void {
  const existing = db.prepare('SELECT COUNT(*) as c FROM organisations').get() as { c: number };
  if (existing.c > 0) return;

  withTransaction(db, () => {
    const now = new Date('2026-11-22T09:15:00.000Z');
    const iso = (offsetMinutes: number) =>
      new Date(now.getTime() + offsetMinutes * 60_000).toISOString();

    // Organisations
    const insertOrg = db.prepare(
      'INSERT INTO organisations (id, ods_code, name, trust_type) VALUES (?, ?, ?, ?)'
    );
    insertOrg.run('org-rxx', 'RXX', 'Aureom NHS Foundation Trust (Prototype)', 'Acute & Specialist Trust');
    insertOrg.run('org-ryy', 'RYY', 'Westbridge Community Health Trust (Prototype)', 'Community Trust');

    // Clinicians
    const insertClinician = db.prepare(
      `INSERT INTO clinicians (
        id, oidc_subject, display_name, role, specialty, gmc_or_nmc_number, organisation_id, email
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertClinician.run(
      'clin-vance',
      'oidc|rxx|a.vance',
      'Dr. Alistair Vance',
      'Consultant',
      'Cardiology',
      'GMC-7041928',
      'org-rxx',
      'alistair.vance@prototype.nhs.example'
    );
    insertClinician.run(
      'clin-nair',
      'oidc|rxx|p.nair',
      'Dr. Priya Nair',
      'Registrar',
      'Acute Medicine',
      'GMC-7410883',
      'org-rxx',
      'priya.nair@prototype.nhs.example'
    );
    insertClinician.run(
      'clin-bennett',
      'oidc|rxx|c.bennett',
      'Nurse Claire Bennett',
      'ClinicalNurse',
      'Cardiology Outpatient Clinic',
      'NMC-14H0921E',
      'org-rxx',
      'claire.bennett@prototype.nhs.example'
    );
    insertClinician.run(
      'clin-thorne',
      'oidc|ryy|m.thorne',
      'Dr. Marcus Thorne',
      'Consultant',
      'Community Geriatrics',
      'GMC-6102944',
      'org-ryy',
      'marcus.thorne@westbridge.nhs.example'
    );
    insertClinician.run(
      'clin-rostova',
      'oidc|rxx|e.rostova',
      'Elena Rostova',
      'IGLead',
      'Information Governance & Clinical Safety',
      'IG-CSO-019',
      'org-rxx',
      'elena.rostova@prototype.nhs.example'
    );

    // Synthetic Patients (all clearly synthetic 999-prefixed test NHS numbers)
    const insertPatient = db.prepare(
      `INSERT INTO patients (
        id, internal_mrn, family_name, given_names, preferred_name, dob, sex_at_birth,
        gender_identity, nhs_number, nhs_verification_status, demographic_history_json,
        contact_json, gp_practice_json, allergy_assertion_status, merged_into_patient_id,
        organisation_id, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    insertPatient.run(
      'pat-arthur',
      'MRN-100482',
      'Pendelton',
      'Arthur George',
      'Arthur',
      '1954-04-12',
      'Male',
      'Male',
      '999 412 8831',
      'verified_pds',
      JSON.stringify([
        {
          recordedAt: '2025-06-14T10:20:00Z',
          field: 'addressLine1',
          previousValue: '14 Elm Grove, Meadowbank',
          newValue: '28 Station Road, Meadowbank',
          source: 'PDS Spine Update (Simulated)',
        },
      ]),
      JSON.stringify({
        phone: '07700 900412',
        email: 'arthur.pendelton@synthetic.example',
        addressLine1: '28 Station Road',
        city: 'Meadowbank',
        postcode: 'MB4 2QT',
        preferredMethod: 'Telephone & NHS App Summary',
      }),
      JSON.stringify({
        odsCode: 'G82019',
        practiceName: 'Meadowbank Health Centre',
        gpName: 'Dr. S. Patel',
        phone: '01632 960114',
      }),
      'assessed_with_allergies',
      null,
      'org-rxx',
      iso(-43200),
      iso(-120)
    );

    insertPatient.run(
      'pat-meera',
      'MRN-100519',
      'Krishnan',
      'Meera',
      null,
      '1978-09-23',
      'Female',
      'Female',
      '999 708 1192',
      'verified_pds',
      JSON.stringify([]),
      JSON.stringify({
        phone: '07700 900718',
        email: 'meera.krishnan@synthetic.example',
        addressLine1: '9 Victoria Crescent',
        city: 'Meadowbank',
        postcode: 'MB1 7LP',
        preferredMethod: 'SMS & Patient Portal',
      }),
      JSON.stringify({
        odsCode: 'G82044',
        practiceName: 'Oakwood Surgery',
        gpName: 'Dr. H. Lin',
        phone: '01632 960402',
      }),
      'no_known_allergies',
      null,
      'org-rxx',
      iso(-30000),
      iso(-240)
    );

    insertPatient.run(
      'pat-arthur-dup',
      'MRN-TMP-9041',
      'Pendelton',
      'Arthur J.',
      null,
      '1954-04-12',
      'Male',
      null,
      null,
      'unverified',
      JSON.stringify([]),
      JSON.stringify({
        phone: '07700 900412',
        email: '',
        addressLine1: '28 Station Rd',
        city: 'Meadowbank',
        postcode: 'MB4 2QT',
        preferredMethod: 'Telephone',
      }),
      JSON.stringify({
        odsCode: 'G82019',
        practiceName: 'Meadowbank Health Centre',
        gpName: 'Unknown',
        phone: '01632 960114',
      }),
      'not_assessed',
      null,
      'org-rxx',
      iso(-1440),
      iso(-1440)
    );

    insertPatient.run(
      'pat-liam',
      'MRN-100604',
      "O'Connor",
      'Liam Patrick',
      'Liam',
      '1989-11-02',
      'Male',
      'Male',
      '999 224 5510',
      'verified_pds',
      JSON.stringify([]),
      JSON.stringify({
        phone: '07700 900229',
        email: 'liam.oconnor@synthetic.example',
        addressLine1: '42 Harbour Quay',
        city: 'Meadowbank',
        postcode: 'MB9 1AA',
        preferredMethod: 'Email',
      }),
      JSON.stringify({
        odsCode: 'G82019',
        practiceName: 'Meadowbank Health Centre',
        gpName: 'Dr. S. Patel',
        phone: '01632 960114',
      }),
      'not_assessed',
      null,
      'org-rxx',
      iso(-10000),
      iso(-90)
    );

    insertPatient.run(
      'pat-beatrice',
      'MRN-EXT-3310',
      'Holloway',
      'Beatrice Anne',
      null,
      '1943-01-19',
      'Female',
      'Female',
      '999 881 0043',
      'verified_pds',
      JSON.stringify([]),
      JSON.stringify({
        phone: '07700 900881',
        email: 'beatrice.holloway@synthetic.example',
        addressLine1: '5 St Jude Close',
        city: 'Westbridge',
        postcode: 'WB2 4DD',
        preferredMethod: 'Letter',
      }),
      JSON.stringify({
        odsCode: 'G91008',
        practiceName: 'Westbridge Village Medical',
        gpName: 'Dr. R. Evans',
        phone: '01632 960900',
      }),
      'no_known_allergies',
      null,
      'org-ryy',
      iso(-20000),
      iso(-500)
    );

    // Patient Identifiers
    const insertIdent = db.prepare(
      `INSERT INTO patient_identifiers (
        id, patient_id, system, value, authority, verification_status, provenance, is_primary
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertIdent.run('id-1', 'pat-arthur', 'https://fhir.nhs.uk/Id/nhs-number', '999 412 8831', 'NHS PDS (Simulated)', 'verified_pds', 'Demographic Trace 2026-10-01', 1);
    insertIdent.run('id-2', 'pat-arthur', 'urn:aureom:mrn:rxx', 'MRN-100482', 'Aureom Trust PAS', 'verified_pds', 'Local PAS Registration', 0);
    insertIdent.run('id-3', 'pat-meera', 'https://fhir.nhs.uk/Id/nhs-number', '999 708 1192', 'NHS PDS (Simulated)', 'verified_pds', 'Demographic Trace 2026-09-12', 1);
    insertIdent.run('id-4', 'pat-arthur-dup', 'urn:aureom:mrn:rxx', 'MRN-TMP-9041', 'ED Reception Walk-in', 'unverified', 'Unverified Emergency Registration', 1);
    insertIdent.run('id-5', 'pat-liam', 'https://fhir.nhs.uk/Id/nhs-number', '999 224 5510', 'NHS PDS (Simulated)', 'verified_pds', 'Demographic Trace 2026-11-01', 1);
    insertIdent.run('id-6', 'pat-beatrice', 'https://fhir.nhs.uk/Id/nhs-number', '999 881 0043', 'NHS PDS (Simulated)', 'verified_pds', 'Westbridge Community PAS', 1);

    // Care Team Associations
    const insertCareTeam = db.prepare(
      'INSERT INTO care_team_associations (id, patient_id, clinician_id, role, relationship_type, active) VALUES (?, ?, ?, ?, ?, 1)'
    );
    insertCareTeam.run('ct-1', 'pat-arthur', 'clin-vance', 'Named Cardiology Consultant', 'Direct Care', );
    insertCareTeam.run('ct-2', 'pat-arthur', 'clin-bennett', 'Cardiology Clinic Nurse', 'Direct Care');
    insertCareTeam.run('ct-3', 'pat-meera', 'clin-vance', 'Cardiorenal Review Consultant', 'Direct Care');
    insertCareTeam.run('ct-4', 'pat-liam', 'clin-nair', 'Acute Medical Registrar', 'Direct Care');
    insertCareTeam.run('ct-5', 'pat-beatrice', 'clin-thorne', 'Community Geriatrician', 'Direct Care');

    // Encounters
    const insertEnc = db.prepare(
      `INSERT INTO encounters (
        id, patient_id, organisation_id, encounter_type, location, ward_or_clinic,
        responsible_clinician_id, status, presenting_concern, occurred_at, documented_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertEnc.run(
      'enc-arthur-today',
      'pat-arthur',
      'org-rxx',
      'outpatient',
      'Outpatient Wing B',
      'Cardiology Rapid Access Clinic · Room 4',
      'clin-vance',
      'in_progress',
      'Worsening exertional dyspnoea over 3 weeks and intermittent palpitations on background of AF',
      iso(-30),
      iso(-25)
    );
    insertEnc.run(
      'enc-arthur-prev',
      'pat-arthur',
      'org-rxx',
      'outpatient',
      'Outpatient Wing B',
      'Cardiology Follow-up Clinic',
      'clin-vance',
      'finished',
      '6-month atrial fibrillation rate control review',
      iso(-129600),
      iso(-129580)
    );
    insertEnc.run(
      'enc-meera-today',
      'pat-meera',
      'org-rxx',
      'outpatient',
      'Outpatient Wing A',
      'Cardiorenal Metabolic Clinic · Room 2',
      'clin-vance',
      'arrived',
      'Annual cardiorenal review; elevated HbA1c and microalbuminuria monitoring',
      iso(-15),
      iso(-12)
    );
    insertEnc.run(
      'enc-liam-today',
      'pat-liam',
      'org-rxx',
      'emergency',
      'Acute Assessment Unit',
      'AAU Bay 6',
      'clin-nair',
      'in_progress',
      'Acute wheeze and nocturnal cough following viral URTI',
      iso(-90),
      iso(-80)
    );
    insertEnc.run(
      'enc-beatrice-ext',
      'pat-beatrice',
      'org-ryy',
      'outpatient',
      'Westbridge Community Hub',
      'Frailty & Falls Clinic',
      'clin-thorne',
      'in_progress',
      'Postural dizziness and medication review',
      iso(-180),
      iso(-175)
    );

    // Problems (explicitly includes a conflict pair for Arthur)
    const insertProblem = db.prepare(
      `INSERT INTO problems (
        id, patient_id, encounter_id, code, code_system, display, clinical_status,
        verification_status, onset_at, documented_at, author_id, source_provenance,
        conflict_group_id, conflict_note
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertProblem.run(
      'prob-1', 'pat-arthur', 'enc-arthur-prev', '49436004', 'SNOMED CT',
      'Persistent atrial fibrillation', 'active', 'confirmed', '2022-03-10T00:00:00Z',
      iso(-129580), 'clin-vance', 'Hospital Cardiology Record', null, null
    );
    insertProblem.run(
      'prob-2', 'pat-arthur', 'enc-arthur-prev', '38341003', 'SNOMED CT',
      'Essential hypertension — GP summary states controlled on monotherapy', 'active', 'confirmed',
      '2018-07-01T00:00:00Z', iso(-20000), 'clin-vance', 'GP Connect Summary (Simulated)',
      'conf-prob-htn', 'Conflicts with outpatient clinic serial readings averaging 162/94 mmHg'
    );
    insertProblem.run(
      'prob-3', 'pat-arthur', 'enc-arthur-today', '38341003', 'SNOMED CT',
      'Uncontrolled hypertension in clinic (162/94 mmHg)', 'active', 'provisional',
      '2026-11-22T08:50:00Z', iso(-20), 'clin-bennett', 'Cardiology Clinic Triage',
      'conf-prob-htn', 'Conflicts with GP summary status; requires ambulatory BP check before reconciling'
    );
    insertProblem.run(
      'prob-4', 'pat-meera', 'enc-meera-today', '44054006', 'SNOMED CT',
      'Type 2 diabetes mellitus', 'active', 'confirmed', '2019-05-14T00:00:00Z',
      iso(-30000), 'clin-vance', 'GP Connect Summary (Simulated)', null, null
    );
    insertProblem.run(
      'prob-5', 'pat-meera', 'enc-meera-today', '700378005', 'SNOMED CT',
      'Chronic kidney disease stage 3A', 'active', 'confirmed', '2024-02-01T00:00:00Z',
      iso(-15000), 'clin-vance', 'Nephrology Referral', null, null
    );
    insertProblem.run(
      'prob-6', 'pat-liam', 'enc-liam-today', '195967001', 'SNOMED CT',
      'Asthma — acute exacerbation', 'active', 'confirmed', '2011-04-01T00:00:00Z',
      iso(-80), 'clin-nair', 'AAU Admission Assessment', null, null
    );

    // Allergies
    const insertAllergy = db.prepare(
      `INSERT INTO allergies (
        id, patient_id, substance, code, reaction, severity, verification_status,
        clinical_status, provenance, recorded_at, author_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertAllergy.run(
      'alg-1', 'pat-arthur', 'Phenoxymethylpenicillin (Penicillin V)', '372687004',
      'Anaphylaxis (airway angioedema and hypotension)', 'life_threatening', 'confirmed',
      'active', 'GP Summary + Patient Confirmation 2024', iso(-200000), 'clin-vance'
    );
    insertAllergy.run(
      'alg-2', 'pat-arthur', 'Iodinated contrast media', '385420005',
      'Urticaria (unverified historical report from 2009)', 'moderate', 'unconfirmed',
      'active', 'Patient-reported historical note', iso(-129580), 'clin-bennett'
    );

    // Medications (explicitly distinguishing prescribing, dispensing, administration, patient_reported + discrepancy)
    const insertMed = db.prepare(
      `INSERT INTO medications (
        id, patient_id, encounter_id, concept_type, drug_name, dmd_code, strength,
        dose, route, frequency, start_date, end_date, status, source,
        reconciliation_status, conflict_group_id, author_id, documented_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertMed.run(
      'med-1', 'pat-arthur', 'enc-arthur-prev', 'prescribing', 'Apixaban', '322236009',
      '5 mg', '5 mg', 'Oral', 'Twice daily', '2022-03-12', null, 'active',
      'Hospital Cardiology Outpatient Prescription', 'verified', null, 'clin-vance', iso(-129580)
    );
    insertMed.run(
      'med-2', 'pat-arthur', 'enc-arthur-prev', 'prescribing', 'Bisoprolol fumarate', '322254008',
      '5 mg', '5 mg', 'Oral', 'Once daily (morning)', '2023-01-10', null, 'active',
      'GP Repeat Prescribing Record', 'verified', null, 'clin-vance', iso(-43200)
    );
    insertMed.run(
      'med-3', 'pat-arthur', 'enc-arthur-prev', 'prescribing', 'Atorvastatin', '376197002',
      '40 mg', '40 mg', 'Oral', 'Once daily (night)', '2023-05-01', null, 'active',
      'GP Repeat Prescribing Record', 'discrepancy', 'conf-med-atorva', 'clin-vance', iso(-43200)
    );
    insertMed.run(
      'med-4', 'pat-arthur', 'enc-arthur-today', 'patient_reported', 'Atorvastatin', '376197002',
      '20 mg', '20 mg (patient states halved dose due to myalgia)', 'Oral', 'Once daily (night)',
      '2026-09-15', null, 'active', 'Patient Self-Report at Clinic Triage', 'discrepancy',
      'conf-med-atorva', 'clin-bennett', iso(-20)
    );
    insertMed.run(
      'med-5', 'pat-arthur', 'enc-arthur-today', 'dispensing', 'Apixaban 5mg tablets (56 pack)', '322236009',
      '5 mg', '5 mg', 'Oral', 'Twice daily', '2026-11-01', null, 'completed',
      'Community Pharmacy EPS Dispense Notification (Simulated)', 'verified', null, 'clin-bennett', iso(-20000)
    );
    insertMed.run(
      'med-6', 'pat-meera', 'enc-meera-today', 'prescribing', 'Metformin hydrochloride modified-release', '372567009',
      '1000 mg', '1000 mg', 'Oral', 'Once daily with evening meal', '2021-06-01', null, 'active',
      'GP Repeat Prescribing Record', 'verified', null, 'clin-vance', iso(-15000)
    );
    insertMed.run(
      'med-7', 'pat-meera', 'enc-meera-today', 'prescribing', 'Dapagliflozin', '412518000',
      '10 mg', '10 mg', 'Oral', 'Once daily', '2024-03-01', null, 'active',
      'Cardiorenal Clinic Recommendation', 'verified', null, 'clin-vance', iso(-15000)
    );
    insertMed.run(
      'med-8', 'pat-liam', 'enc-liam-today', 'administration', 'Salbutamol nebuliser solution', '372897005',
      '5 mg/2.5 mL', '5 mg', 'Nebulised inhalation', 'Stat on arrival', '2026-11-22', '2026-11-22', 'completed',
      'AAU ePMA Administration Record', 'verified', null, 'clin-nair', iso(-75)
    );

    // Observations
    const insertObs = db.prepare(
      `INSERT INTO observations (
        id, patient_id, encounter_id, code, terminology_system, display, value_num, value_text,
        unit, reference_low, reference_high, interpretation, observed_at, documented_at,
        recording_source, attribution, verification_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertObs.run('obs-1', 'pat-arthur', 'enc-arthur-today', '8480-6', 'LOINC', 'Systolic Blood Pressure', 162, '162', 'mmHg', 90, 140, 'high', iso(-28), iso(-24), 'Welch Allyn Vital Signs Monitor #B4', 'Nurse Claire Bennett', 'final');
    insertObs.run('obs-2', 'pat-arthur', 'enc-arthur-today', '8462-4', 'LOINC', 'Diastolic Blood Pressure', 94, '94', 'mmHg', 60, 90, 'high', iso(-28), iso(-24), 'Welch Allyn Vital Signs Monitor #B4', 'Nurse Claire Bennett', 'final');
    insertObs.run('obs-3', 'pat-arthur', 'enc-arthur-today', '8867-4', 'LOINC', 'Heart Rate (Irregular pulse)', 98, '98', 'bpm', 60, 100, 'normal', iso(-28), iso(-24), 'Manual Radial + Pulse Oximeter', 'Nurse Claire Bennett', 'final');
    insertObs.run('obs-4', 'pat-arthur', 'enc-arthur-today', '2708-6', 'LOINC', 'Oxygen Saturation (SpO2 on room air)', 95, '95', '%', 94, 100, 'normal', iso(-28), iso(-24), 'Masimo Pulse Oximeter', 'Nurse Claire Bennett', 'final');
    insertObs.run('obs-5', 'pat-arthur', 'enc-arthur-today', '29463-7', 'LOINC', 'Body Weight', 84.6, '84.6', 'kg', null, null, 'normal', iso(-27), iso(-24), 'Clinic Digital Scale', 'Nurse Claire Bennett', 'final');
    insertObs.run('obs-6', 'pat-meera', 'enc-meera-today', '8480-6', 'LOINC', 'Systolic Blood Pressure', 128, '128', 'mmHg', 90, 140, 'normal', iso(-14), iso(-12), 'Clinic Triage', 'Nurse Claire Bennett', 'final');
    insertObs.run('obs-7', 'pat-liam', 'enc-liam-today', '33452-4', 'LOINC', 'Peak Expiratory Flow Rate (Baseline Pre-Exacerbation)', null, 'Unavailable — patient unable to recall prior personal best', 'L/min', null, null, 'unavailable', iso(-85), iso(-80), 'AAU Nursing Assessment', 'Dr. Priya Nair', 'unavailable');

    // Diagnostic Results (includes Corrected Result chain for Arthur!)
    const insertRes = db.prepare(
      `INSERT INTO diagnostic_results (
        id, patient_id, encounter_id, request_id, order_name, code, terminology_system,
        value_text, unit, reference_interval, abnormal_flag, result_status, review_state,
        supersedes_result_id, correction_reason, observed_at, reported_at, performing_lab,
        viewed_by, viewed_at, acknowledged_by, acknowledged_at, follow_up_task_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertRes.run(
      'res-trop-orig', 'pat-arthur', 'enc-arthur-today', 'REQ-88410',
      'High-Sensitivity Troponin T', '67151-1', 'LOINC',
      '12', 'ng/L', '< 14 ng/L (99th percentile URL)', 'normal', 'final', 'acknowledged',
      null, null, iso(-240), iso(-180), 'Aureom Pathology — Automated Biochemistry',
      'clin-vance', iso(-150), 'clin-vance', iso(-145), null
    );
    insertRes.run(
      'res-trop-corr', 'pat-arthur', 'enc-arthur-today', 'REQ-88410',
      'High-Sensitivity Troponin T (CORRECTED)', '67151-1', 'LOINC',
      '58', 'ng/L', '< 14 ng/L (99th percentile URL)', 'critical', 'corrected', 'available',
      'res-trop-orig', 'Corrected due to sample dilution transcription error on analyser channel 2; re-assayed in duplicate.',
      iso(-240), iso(-10), 'Aureom Pathology — Automated Biochemistry',
      null, null, null, null, null
    );
    insertRes.run(
      'res-bnp-arthur', 'pat-arthur', 'enc-arthur-today', 'REQ-88411',
      'NT-proBNP', '33762-6', 'LOINC',
      '1420', 'pg/mL', '< 400 pg/mL (Heart failure unlikely below threshold)', 'high', 'final', 'available',
      null, null, iso(-240), iso(-45), 'Aureom Pathology — Automated Biochemistry',
      null, null, null, null, null
    );
    insertRes.run(
      'res-egfr-arthur', 'pat-arthur', 'enc-arthur-today', 'REQ-88412',
      'eGFR (CKD-EPI Creatinine)', '62238-1', 'LOINC',
      '61', 'mL/min/1.73m2', '> 60 mL/min/1.73m2', 'normal', 'preliminary', 'available',
      null, null, iso(-240), iso(-35), 'Aureom Pathology — Automated Biochemistry',
      null, null, null, null, null
    );
    insertRes.run(
      'res-hba1c-meera', 'pat-meera', 'enc-meera-today', 'REQ-88205',
      'HbA1c (IFCC)', '4548-4', 'LOINC',
      '68', 'mmol/mol', '20 - 41 mmol/mol (Target < 53 in T2DM)', 'high', 'final', 'viewed',
      null, null, iso(-2880), iso(-1440), 'Aureom Pathology — Diabetes Lab',
      'clin-vance', iso(-600), null, null, null
    );

    // Clinical Notes (1 Signed historical note + 1 Draft note ready to edit/sign!)
    const insertNote = db.prepare(
      `INSERT INTO clinical_notes (
        id, patient_id, encounter_id, template_type, title, status, sections_json, free_text,
        copied_citations_json, version, author_id, signed_by, signed_at, attestation_statement,
        cryptographic_signature_hex, entered_in_error_reason, entered_in_error_by, entered_in_error_at,
        idempotency_key, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const signedSections = JSON.stringify([
      { key: 'presenting', label: 'Interval History', content: 'Stable rate-controlled AF on bisoprolol 5 mg OD and apixaban 5 mg BD. No syncope or bleeding.' },
      { key: 'examination', label: 'Examination', content: 'Pulse 76 bpm irregular, BP 138/82 mmHg, chest clear, no peripheral oedema.' },
      { key: 'plan', label: 'Plan', content: 'Continue current anticoagulation and beta-blocker. Repeat U&E and clinic review in 6 months.' },
    ]);
    const signedAttest = 'I attest that I am the author and have reviewed this clinical record prior to signing.';
    const signedSig = signAttestationPayload('note-arthur-signed-1|v2|clin-vance|' + signedSections);

    insertNote.run(
      'note-arthur-signed-1',
      'pat-arthur',
      'enc-arthur-prev',
      'consultation',
      'Cardiology 6-Month Follow-up Consultation',
      'signed',
      signedSections,
      'Discussed adherence to apixaban and bleeding precautions. Patient happy with current regimen.',
      JSON.stringify([]),
      2,
      'clin-vance',
      'clin-vance',
      iso(-129540),
      signedAttest,
      signedSig,
      null,
      null,
      null,
      'seed-sign-arthur-1',
      iso(-129580),
      iso(-129540)
    );

    const draftSections = JSON.stringify([
      { key: 'presenting', label: 'Presenting Concern & History', content: '72yo gentleman presenting with 3-week history of exertional dyspnoea (NYHA II->III) and intermittent palpitations. Reports reducing atorvastatin to 20 mg due to mild thigh discomfort.' },
      { key: 'examination', label: 'Examination & Observations', content: 'BP 162/94 mmHg (elevated compared to GP summary), HR 98 bpm irregularly irregular, SpO2 95% on air, mild bibasal crepitations.' },
      { key: 'assessment', label: 'Clinical Impression', content: 'Decompensated heart failure / worsening AF rate control; awaiting pathology review including NT-proBNP and Troponin.' },
      { key: 'plan', label: 'Management & Follow-up Plan', content: 'Review corrected Troponin T and NT-proBNP urgently; arrange 12-lead ECG and echocardiogram.' },
    ]);

    insertNote.run(
      'note-arthur-draft-1',
      'pat-arthur',
      'enc-arthur-today',
      'consultation',
      'Cardiology Rapid Access Consultation — 22 Nov 2026',
      'draft',
      draftSections,
      'Draft started during outpatient review; verify atorvastatin dose discrepancy with GP.',
      JSON.stringify([
        {
          sourceType: 'Medication Entry',
          sourceId: 'med-4',
          sourceAuthor: 'Nurse Claire Bennett',
          sourceDate: iso(-20),
          excerpt: 'Patient-reported Atorvastatin 20 mg OD (self-halved from 40 mg due to myalgia)',
        },
      ]),
      1,
      'clin-vance',
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      iso(-18),
      iso(-15)
    );

    // Note revisions for signed note and draft note
    const insertRev = db.prepare(
      `INSERT INTO note_revisions (
        id, note_id, version, action, sections_json, free_text, actor_id, reason, content_hash, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertRev.run('rev-1', 'note-arthur-signed-1', 1, 'draft_created', signedSections, '', 'clin-vance', null, sha256Hex(signedSections), iso(-129580));
    insertRev.run('rev-2', 'note-arthur-signed-1', 2, 'signed', signedSections, 'Discussed adherence to apixaban and bleeding precautions.', 'clin-vance', 'Clinician Sign-off', sha256Hex(signedSections), iso(-129540));
    insertRev.run('rev-3', 'note-arthur-draft-1', 1, 'draft_created', draftSections, 'Draft started during outpatient review; verify atorvastatin dose discrepancy with GP.', 'clin-vance', null, sha256Hex(draftSections), iso(-18));

    // Care Plans
    const insertCp = db.prepare(
      `INSERT INTO care_plans (
        id, patient_id, title, category, status, goals_json, interventions_json, review_date, author_id, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertCp.run(
      'cp-arthur-1',
      'pat-arthur',
      'Atrial Fibrillation & Heart Failure Outpatient Management Plan',
      'Cardiology Long-Term Condition',
      'active',
      JSON.stringify([
        { description: 'Maintain resting ventricular rate < 90 bpm', targetDate: '2026-12-20', status: 'In Progress' },
        { description: 'Achieve clinic BP < 140/90 mmHg with home BP diary', targetDate: '2026-12-20', status: 'Needs Review' },
      ]),
      JSON.stringify([
        { action: 'Continue Apixaban 5mg BD with annual renal function monitoring', frequency: 'Ongoing', owner: 'Dr. Alistair Vance' },
        { action: 'Home blood pressure monitoring twice daily for 7 days', frequency: 'Daily x7d', owner: 'Arthur Pendelton / Clinic Nurse' },
      ]),
      '2026-12-20',
      'clin-vance',
      iso(-129540)
    );
    insertCp.run(
      'cp-meera-1',
      'pat-meera',
      'Cardiorenal Protection Plan (T2DM + CKD 3a)',
      'Cardiorenal Metabolic',
      'active',
      JSON.stringify([
        { description: 'HbA1c reduction toward 53 mmol/mol', targetDate: '2027-02-01', status: 'Active' },
      ]),
      JSON.stringify([
        { action: 'Continue Dapagliflozin 10mg OD + Metformin MR 1000mg OD', frequency: 'Daily', owner: 'Dr. Alistair Vance' },
      ]),
      '2027-02-01',
      'clin-vance',
      iso(-15000)
    );

    // Tasks
    const insertTask = db.prepare(
      `INSERT INTO tasks (
        id, patient_id, encounter_id, task_type, title, description, owner_id, assigned_team,
        priority, status, due_at, completion_evidence, created_by, accepted_by, accepted_at,
        completed_by, completed_at, patient_summary_text, patient_summary_approved_by,
        patient_summary_approved_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertTask.run(
      'task-arthur-1',
      'pat-arthur',
      'enc-arthur-today',
      'results_review',
      'Urgent review of corrected Troponin T (58 ng/L) and NT-proBNP (1420 pg/mL)',
      'Corrected Troponin T indicates elevation above 99th percentile URL; correlate with ECG and symptoms immediately.',
      'clin-vance',
      'Cardiology Rapid Access Team',
      'stat',
      'delivered',
      iso(60),
      null,
      'clin-bennett',
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      iso(-9)
    );
    insertTask.run(
      'task-arthur-2',
      'pat-arthur',
      'enc-arthur-today',
      'patient_info',
      'Send post-consultation summary and home BP diary instructions to patient',
      'Review plain-English consultation summary before releasing to patient portal.',
      'clin-bennett',
      'Cardiology Outpatient Nursing',
      'routine',
      'accepted',
      iso(1440),
      null,
      'clin-vance',
      'clin-bennett',
      iso(-5),
      null,
      null,
      'Dear Mr Pendelton, Thank you for attending Cardiology Clinic today. We checked your blood pressure and heart rate and are reviewing your latest blood tests. Please continue your Apixaban and Bisoprolol as prescribed, and record your home blood pressure twice a day for 7 days. Do not change your Atorvastatin further until we confirm your plan with your GP.',
      null,
      null,
      iso(-10)
    );
    insertTask.run(
      'task-meera-1',
      'pat-meera',
      'enc-meera-today',
      'referral_prep',
      'Prepare Diabetes Specialist Dietitian referral',
      'Include latest HbA1c (68 mmol/mol) and CKD Stage 3a eGFR.',
      'clin-vance',
      'Cardiorenal MDT',
      'routine',
      'created',
      iso(4320),
      null,
      'clin-vance',
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      iso(-100)
    );

    // Protected Attachments
    const insertAtt = db.prepare(
      `INSERT INTO attachments (
        id, patient_id, encounter_id, filename, mime_type, size_bytes, sha256_hex,
        classification, storage_key, content_text, uploaded_by, uploaded_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const ecgReportText =
      'SYNTHETIC 12-LEAD ECG REPORT\nPatient: Arthur Pendelton (MRN-100482)\nRhythm: Atrial fibrillation, ventricular rate 96 bpm\nQRS: 92 ms | QTc: 438 ms\nST-T: Mild non-specific lateral T-wave flattening; no acute ST elevation.\nRecorded: 2026-11-22T08:52:00Z';
    insertAtt.run(
      'att-arthur-ecg',
      'pat-arthur',
      'enc-arthur-today',
      'ECG_12Lead_Arthur_Pendelton_20261122.txt',
      'text/plain',
      Buffer.byteLength(ecgReportText, 'utf8'),
      sha256Hex(ecgReportText),
      'ecg_trace',
      'protected/org-rxx/pat-arthur/ecg_20261122.txt',
      ecgReportText,
      'clin-bennett',
      iso(-22)
    );

    // Outbox seed event
    db.prepare(
      `INSERT INTO outbox_events (
        id, aggregate_type, aggregate_id, event_type, payload_json, status, attempts,
        next_retry_at, last_error, created_at, delivered_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'outbox-seed-1',
      'DiagnosticResult',
      'res-trop-corr',
      'fhir.diagnostic_report.correction_received',
      JSON.stringify({ resultId: 'res-trop-corr', patientId: 'pat-arthur', orderName: 'High-Sensitivity Troponin T' }),
      'delivered',
      1,
      null,
      null,
      iso(-10),
      iso(-9)
    );

    // Default system settings (AI drafting DISABLED by default!)
    const insertSetting = db.prepare('INSERT INTO system_settings (key, value_json) VALUES (?, ?)');
    insertSetting.run(
      'ai_drafting_adapter',
      JSON.stringify({
        enabled: false,
        provider: 'Disabled by default (Clinician-Controlled Draft Assist)',
        requireSourceLinks: true,
        allowAutoSign: false,
      })
    );
    insertSetting.run(
      'retention_policy',
      JSON.stringify({
        auditRetentionDays: 2920,
        draftCacheMaxHours: 24,
        sessionTimeoutMinutes: 60,
      })
    );

    // Initial Audit Events (hash-chained)
    appendAuditEvent(db, {
      id: 'aud-seed-1',
      eventTime: iso(-129540),
      actorId: 'clin-vance',
      actorName: 'Dr. Alistair Vance',
      actorRole: 'Consultant',
      organisationId: 'org-rxx',
      action: 'note.sign',
      resourceType: 'ClinicalNote',
      resourceId: 'note-arthur-signed-1',
      patientId: 'pat-arthur',
      outcome: 'allow',
      reason: 'Seeded historical clinic sign-off',
      metadata: { version: 2 },
    });
    appendAuditEvent(db, {
      id: 'aud-seed-2',
      eventTime: iso(-10),
      actorId: 'system-interop',
      actorName: 'FHIR Lab Adapter (Simulated)',
      actorRole: 'System',
      organisationId: 'org-rxx',
      action: 'result.correction_ingested',
      resourceType: 'DiagnosticResult',
      resourceId: 'res-trop-corr',
      patientId: 'pat-arthur',
      outcome: 'allow',
      reason: 'Corrected Troponin T linked to res-trop-orig',
      metadata: { supersedes: 'res-trop-orig' },
    });
  });
}
