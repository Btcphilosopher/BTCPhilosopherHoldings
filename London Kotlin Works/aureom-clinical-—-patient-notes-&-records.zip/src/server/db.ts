import type { DatabaseSync as DatabaseSyncType } from 'node:sqlite';
import { createHash, randomBytes, createHmac } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname } from 'node:path';

const require = createRequire(import.meta.url);
const { DatabaseSync } = require('node:sqlite') as typeof import('node:sqlite');
export type DatabaseSync = DatabaseSyncType;

const SIGNING_SECRET = process.env['SESSION_SIGNING_SECRET'] || randomBytes(32).toString('hex');

export function sha256Hex(input: string | Buffer): string {
  return createHash('sha256').update(input).digest('hex');
}

export function signAttestationPayload(payload: string): string {
  return createHmac('sha256', SIGNING_SECRET).update(payload).digest('hex');
}

export function openDatabase(dbPath: string): DatabaseSync {
  if (dbPath !== ':memory:') {
    mkdirSync(dirname(dbPath), { recursive: true });
  }
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  applyMigrations(db);
  return db;
}

export function applyMigrations(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS organisations (
      id TEXT PRIMARY KEY,
      ods_code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      trust_type TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS clinicians (
      id TEXT PRIMARY KEY,
      oidc_subject TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL,
      specialty TEXT NOT NULL,
      gmc_or_nmc_number TEXT NOT NULL,
      organisation_id TEXT NOT NULL REFERENCES organisations(id),
      email TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      clinician_id TEXT NOT NULL REFERENCES clinicians(id),
      oidc_issuer TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      revoked_at TEXT,
      break_glass_patient_id TEXT,
      break_glass_expires_at TEXT,
      break_glass_reason TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS patients (
      id TEXT PRIMARY KEY,
      internal_mrn TEXT NOT NULL UNIQUE,
      family_name TEXT NOT NULL,
      given_names TEXT NOT NULL,
      preferred_name TEXT,
      dob TEXT NOT NULL,
      sex_at_birth TEXT NOT NULL,
      gender_identity TEXT,
      nhs_number TEXT,
      nhs_verification_status TEXT NOT NULL,
      demographic_history_json TEXT NOT NULL,
      contact_json TEXT NOT NULL,
      gp_practice_json TEXT NOT NULL,
      allergy_assertion_status TEXT NOT NULL,
      merged_into_patient_id TEXT REFERENCES patients(id),
      organisation_id TEXT NOT NULL REFERENCES organisations(id),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS patient_identifiers (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      system TEXT NOT NULL,
      value TEXT NOT NULL,
      authority TEXT NOT NULL,
      verification_status TEXT NOT NULL,
      provenance TEXT NOT NULL,
      is_primary INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS care_team_associations (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      clinician_id TEXT NOT NULL REFERENCES clinicians(id),
      role TEXT NOT NULL,
      relationship_type TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS encounters (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      organisation_id TEXT NOT NULL REFERENCES organisations(id),
      encounter_type TEXT NOT NULL,
      location TEXT NOT NULL,
      ward_or_clinic TEXT NOT NULL,
      responsible_clinician_id TEXT NOT NULL REFERENCES clinicians(id),
      status TEXT NOT NULL,
      presenting_concern TEXT NOT NULL,
      occurred_at TEXT NOT NULL,
      documented_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS problems (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      code TEXT NOT NULL,
      code_system TEXT NOT NULL,
      display TEXT NOT NULL,
      clinical_status TEXT NOT NULL,
      verification_status TEXT NOT NULL,
      onset_at TEXT,
      documented_at TEXT NOT NULL,
      author_id TEXT NOT NULL REFERENCES clinicians(id),
      source_provenance TEXT NOT NULL,
      conflict_group_id TEXT,
      conflict_note TEXT
    );

    CREATE TABLE IF NOT EXISTS allergies (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      substance TEXT NOT NULL,
      code TEXT NOT NULL,
      reaction TEXT NOT NULL,
      severity TEXT NOT NULL,
      verification_status TEXT NOT NULL,
      clinical_status TEXT NOT NULL,
      provenance TEXT NOT NULL,
      recorded_at TEXT NOT NULL,
      author_id TEXT NOT NULL REFERENCES clinicians(id)
    );

    CREATE TABLE IF NOT EXISTS medications (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      concept_type TEXT NOT NULL,
      drug_name TEXT NOT NULL,
      dmd_code TEXT NOT NULL,
      strength TEXT NOT NULL,
      dose TEXT NOT NULL,
      route TEXT NOT NULL,
      frequency TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT,
      status TEXT NOT NULL,
      source TEXT NOT NULL,
      reconciliation_status TEXT NOT NULL,
      conflict_group_id TEXT,
      author_id TEXT NOT NULL REFERENCES clinicians(id),
      documented_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS observations (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      code TEXT NOT NULL,
      terminology_system TEXT NOT NULL,
      display TEXT NOT NULL,
      value_num REAL,
      value_text TEXT NOT NULL,
      unit TEXT NOT NULL,
      reference_low REAL,
      reference_high REAL,
      interpretation TEXT NOT NULL,
      observed_at TEXT NOT NULL,
      documented_at TEXT NOT NULL,
      recording_source TEXT NOT NULL,
      attribution TEXT NOT NULL,
      verification_status TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS diagnostic_results (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      request_id TEXT NOT NULL,
      order_name TEXT NOT NULL,
      code TEXT NOT NULL,
      terminology_system TEXT NOT NULL,
      value_text TEXT NOT NULL,
      unit TEXT NOT NULL,
      reference_interval TEXT NOT NULL,
      abnormal_flag TEXT NOT NULL,
      result_status TEXT NOT NULL,
      review_state TEXT NOT NULL,
      supersedes_result_id TEXT REFERENCES diagnostic_results(id),
      correction_reason TEXT,
      observed_at TEXT NOT NULL,
      reported_at TEXT NOT NULL,
      performing_lab TEXT NOT NULL,
      viewed_by TEXT,
      viewed_at TEXT,
      acknowledged_by TEXT,
      acknowledged_at TEXT,
      follow_up_task_id TEXT
    );

    CREATE TABLE IF NOT EXISTS clinical_notes (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      template_type TEXT NOT NULL,
      title TEXT NOT NULL,
      status TEXT NOT NULL,
      sections_json TEXT NOT NULL,
      free_text TEXT NOT NULL,
      copied_citations_json TEXT NOT NULL,
      version INTEGER NOT NULL,
      author_id TEXT NOT NULL REFERENCES clinicians(id),
      signed_by TEXT REFERENCES clinicians(id),
      signed_at TEXT,
      attestation_statement TEXT,
      cryptographic_signature_hex TEXT,
      entered_in_error_reason TEXT,
      entered_in_error_by TEXT REFERENCES clinicians(id),
      entered_in_error_at TEXT,
      idempotency_key TEXT UNIQUE,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS note_revisions (
      id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL REFERENCES clinical_notes(id),
      version INTEGER NOT NULL,
      action TEXT NOT NULL,
      sections_json TEXT NOT NULL,
      free_text TEXT NOT NULL,
      actor_id TEXT NOT NULL REFERENCES clinicians(id),
      reason TEXT,
      content_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS note_amendments (
      id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL REFERENCES clinical_notes(id),
      addendum_text TEXT NOT NULL,
      reason TEXT NOT NULL,
      author_id TEXT NOT NULL REFERENCES clinicians(id),
      attestation_statement TEXT NOT NULL,
      cryptographic_signature_hex TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS care_plans (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      status TEXT NOT NULL,
      goals_json TEXT NOT NULL,
      interventions_json TEXT NOT NULL,
      review_date TEXT NOT NULL,
      author_id TEXT NOT NULL REFERENCES clinicians(id),
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      task_type TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      owner_id TEXT NOT NULL REFERENCES clinicians(id),
      assigned_team TEXT NOT NULL,
      priority TEXT NOT NULL,
      status TEXT NOT NULL,
      due_at TEXT NOT NULL,
      completion_evidence TEXT,
      created_by TEXT NOT NULL REFERENCES clinicians(id),
      accepted_by TEXT,
      accepted_at TEXT,
      completed_by TEXT,
      completed_at TEXT,
      patient_summary_text TEXT,
      patient_summary_approved_by TEXT,
      patient_summary_approved_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS attachments (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES patients(id),
      encounter_id TEXT REFERENCES encounters(id),
      filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      sha256_hex TEXT NOT NULL,
      classification TEXT NOT NULL,
      storage_key TEXT NOT NULL,
      content_text TEXT NOT NULL,
      uploaded_by TEXT NOT NULL REFERENCES clinicians(id),
      uploaded_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_events (
      seq_id INTEGER PRIMARY KEY AUTOINCREMENT,
      id TEXT NOT NULL UNIQUE,
      event_time TEXT NOT NULL,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      organisation_id TEXT NOT NULL,
      action TEXT NOT NULL,
      resource_type TEXT NOT NULL,
      resource_id TEXT NOT NULL,
      patient_id TEXT,
      outcome TEXT NOT NULL,
      reason TEXT,
      metadata_json TEXT NOT NULL,
      prev_hash TEXT NOT NULL,
      event_hash TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS outbox_events (
      id TEXT PRIMARY KEY,
      aggregate_type TEXT NOT NULL,
      aggregate_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      status TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      next_retry_at TEXT,
      last_error TEXT,
      created_at TEXT NOT NULL,
      delivered_at TEXT
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value_json TEXT NOT NULL
    );
  `);
}

export function withTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE;');
  try {
    const result = fn();
    db.exec('COMMIT;');
    return result;
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }
}
