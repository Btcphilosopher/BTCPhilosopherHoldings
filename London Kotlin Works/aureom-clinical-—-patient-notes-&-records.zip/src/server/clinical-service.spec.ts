import { describe, it, expect, beforeEach } from 'vitest';
import { openDatabase } from './db';
import { seedSyntheticClinic } from './seed';
import { ApiError, ClinicalService } from './clinical-service';

describe('Aureom Clinical — Acceptance & Safety Test Suite', () => {
  let service: ClinicalService;
  let db: ReturnType<typeof openDatabase>;

  beforeEach(() => {
    db = openDatabase(':memory:');
    seedSyntheticClinic(db);
    service = new ClinicalService(db);
  });

  it('enforces note immutability after atomic signing and handles idempotent retries without duplicate signatures', () => {
    const session = service.loginWithLocalOidc('clin-vance');
    const overview = service.getPatientOverview(session, 'pat-arthur');
    const draft = overview.notes.find((n) => n.status === 'draft')!;

    const idemKey = 'idem-sign-test-001';
    const signed1 = service.signNote(session, draft.id, {
      expectedVersion: draft.version,
      patientConfirmed: true,
      idempotencyKey: idemKey,
    });
    expect(signed1.status).toBe('signed');
    expect(signed1.version).toBe(draft.version + 1);
    expect(signed1.attestationStatement).toContain('Dr. Alistair Vance');
    expect(signed1.cryptographicSignatureHex).toBeTruthy();

    // Retry with same idempotencyKey returns signed note without bumping version or duplicating signature
    const signedRetry = service.signNote(session, draft.id, {
      expectedVersion: draft.version,
      patientConfirmed: true,
      idempotencyKey: idemKey,
    });
    expect(signedRetry.version).toBe(signed1.version);
    expect(signedRetry.cryptographicSignatureHex).toBe(signed1.cryptographicSignatureHex);

    // Attempting to overwrite signed note is rejected
    expect(() =>
      service.saveDraftNote(session, draft.id, {
        expectedVersion: signed1.version,
        title: 'Tampered',
        sections: signed1.sections,
        freeText: 'Overwrite attempt',
      })
    ).toThrowError(ApiError);
  });

  it('detects optimistic concurrency draft conflicts without silently overwriting', () => {
    const vance = service.loginWithLocalOidc('clin-vance');
    const bennett = service.loginWithLocalOidc('clin-bennett');

    const draft = service.getPatientOverview(vance, 'pat-arthur').notes.find((n) => n.status === 'draft')!;
    const v1 = draft.version;

    // Clinician A saves v1 -> v2
    const updated = service.saveDraftNote(vance, draft.id, {
      expectedVersion: v1,
      title: draft.title,
      sections: draft.sections,
      freeText: 'Vance updated text',
    });
    expect(updated.version).toBe(v1 + 1);

    // Clinician B still holds v1 and tries to save -> must throw 409 DRAFT_VERSION_CONFLICT
    try {
      service.saveDraftNote(bennett, draft.id, {
        expectedVersion: v1,
        title: draft.title,
        sections: draft.sections,
        freeText: 'Bennett stale text',
      });
      expect.fail('Expected DRAFT_VERSION_CONFLICT');
    } catch (e) {
      const err = e as ApiError;
      expect(err.statusCode).toBe(409);
      expect(err.code).toBe('DRAFT_VERSION_CONFLICT');
      expect(err.details?.['serverNote']).toBeTruthy();
    }
  });

  it('enforces patient isolation across organisations and supports audited break-glass access', () => {
    const vance = service.loginWithLocalOidc('clin-vance'); // org-rxx

    // pat-beatrice belongs to org-ryy -> must deny and record audit deny event
    expect(() => service.getPatientOverview(vance, 'pat-beatrice')).toThrowError(ApiError);

    const auditAfterDeny = service.listAuditEvents(vance, 'pat-beatrice');
    expect(auditAfterDeny.events.some((e) => e.outcome === 'deny')).toBe(true);

    // Break-glass with clinical justification grants temporary access
    const bgSession = service.requestBreakGlass(
      vance,
      'pat-beatrice',
      'Emergency acute presentation requiring immediate allergy verification'
    );
    const ov = service.getPatientOverview(bgSession, 'pat-beatrice');
    expect(ov.patient.id).toBe('pat-beatrice');
  });

  it('blocks IGLead accounts from authoring clinical notes while allowing audit inspection', () => {
    const ig = service.loginWithLocalOidc('clin-rostova');
    expect(() =>
      service.createDraftNote(ig, 'pat-arthur', {
        encounterId: null,
        templateType: 'progress',
        title: 'Should fail',
        sections: [],
        freeText: 'Test',
      })
    ).toThrowError(ApiError);

    const audit = service.listAuditEvents(ig);
    expect(audit.chainVerified).toBe(true);
    expect(audit.verifiedCount).toBeGreaterThan(0);
  });

  it('links corrected results to previous versions and triggers review task workflow', () => {
    const vance = service.loginWithLocalOidc('clin-vance');
    const corrected = service.simulateCorrectedResult(
      vance,
      'res-bnp-arthur',
      '1890',
      'critical',
      'Analyser dilution correction'
    );
    expect(corrected.resultStatus).toBe('corrected');
    expect(corrected.supersedesResultId).toBe('res-bnp-arthur');

    const ov = service.getPatientOverview(vance, 'pat-arthur');
    expect(ov.tasks.some((t) => t.title.includes('Review Corrected Result'))).toBe(true);
  });

  it('handles outbox retries and dead-letter transitions, and verifies audit hash chain tampering detection', () => {
    const vance = service.loginWithLocalOidc('clin-vance');
    const outbox = service.listOutboxEvents();
    expect(outbox.length).toBeGreaterThan(0);

    const firstId = outbox[0].id;
    service.retryOutboxEvent(vance, firstId, true);
    const afterFail = service.retryOutboxEvent(vance, firstId, true);
    expect(afterFail.status).toBe('dead_letter');

    const delivered = service.retryOutboxEvent(vance, firstId, false);
    expect(delivered.status).toBe('delivered');

    // Verify hash chain integrity
    expect(service.listAuditEvents(vance).chainVerified).toBe(true);
  });

  it('does not auto-merge demographic matches and preserves identifiers on authorised merge', () => {
    const vance = service.loginWithLocalOidc('clin-vance');
    const reg = service.registerPatient(vance, {
      familyName: 'Pendelton',
      givenNames: 'Arthur Temp',
      dob: '1954-04-12',
      sexAtBirth: 'Male',
      nhsVerificationStatus: 'unverified',
      phone: '07700 900000',
      email: '',
      addressLine1: '28 Station Rd',
      city: 'Meadowbank',
      postcode: 'MB4 2QT',
      gpPracticeName: 'Meadowbank',
      gpOdsCode: 'G82019',
    });
    expect(reg.duplicateWarnings.length).toBeGreaterThan(0);

    const merged = service.mergePatients(vance, reg.patient.id, 'pat-arthur', 'Confirmed identity match');
    expect(merged.patient.identifiers?.some((i) => i.value === reg.patient.internalMrn)).toBe(true);
  });
});
