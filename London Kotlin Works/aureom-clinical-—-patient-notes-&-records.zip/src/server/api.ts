import express, { type NextFunction, type Request, type Response } from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';
import { openDatabase } from './db.js';
import { seedSyntheticClinic } from './seed.js';
import { ApiError, ClinicalService } from './clinical-service.js';
import type { AuthSession } from '../shared/clinical-types.js';

interface AuthenticatedRequest extends Request {
  authSession?: AuthSession;
}

export function createClinicalApiRouter(dbPath?: string) {
  const resolvedPath = dbPath ?? join(process.cwd(), 'data', 'aureom_clinical.sqlite');
  const db = openDatabase(resolvedPath);
  seedSyntheticClinic(db);
  const service = new ClinicalService(db);

  const router = express.Router();
  router.use(express.json({ limit: '2mb' }));

  // Privacy-safe structured operational logging (zero clinical text or patient identifiers)
  router.use((req: Request, res: Response, next: NextFunction) => {
    const start = Date.now();
    res.on('finish', () => {
      const logEntry = {
        ts: new Date().toISOString(),
        method: req.method,
        path: req.path,
        status: res.statusCode,
        durationMs: Date.now() - start,
      };
      console.info(JSON.stringify(logEntry));
    });
    next();
  });

  const requireAuth = (req: AuthenticatedRequest, _res: Response, next: NextFunction) => {
    try {
      const header = req.headers.authorization;
      const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : undefined;
      req.authSession = service.authenticateToken(token);
      next();
    } catch (err) {
      next(err);
    }
  };

  // Public health & local OIDC provider metadata
  router.get('/health', (_req, res) => {
    res.json({ status: 'ok', service: 'aureom-clinical-prototype', serverTimeUtc: new Date().toISOString() });
  });

  router.get('/auth/providers', (_req, res) => {
    res.json({
      oidcAdapter: 'Local Development OIDC Identity Provider (Replaceable Adapter)',
      issuer: 'https://oidc.local.aureom.prototype',
      clinicians: service.listClinicians(),
    });
  });

  router.post('/auth/login', (req, res, next) => {
    try {
      const { clinicianId } = req.body as { clinicianId?: string };
      if (!clinicianId) {
        throw new ApiError(400, 'MISSING_CLINICIAN_ID', 'clinicianId is required');
      }
      const session = service.loginWithLocalOidc(clinicianId);
      res.json(session);
    } catch (err) {
      next(err);
    }
  });

  router.post('/auth/logout', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      service.logout(req.authSession!.token);
      res.json({ signedOut: true });
    } catch (err) {
      next(err);
    }
  });

  router.get('/auth/session', requireAuth, (req: AuthenticatedRequest, res) => {
    res.json(req.authSession);
  });

  router.post('/auth/break-glass', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { patientId, reason } = req.body as { patientId?: string; reason?: string };
      if (!patientId || !reason) {
        throw new ApiError(400, 'INVALID_REQUEST', 'patientId and clinical reason are required');
      }
      const updated = service.requestBreakGlass(req.authSession!, patientId, reason);
      res.json(updated);
    } catch (err) {
      next(err);
    }
  });

  // Worklist
  router.get('/worklist', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.getWorklist(req.authSession!));
    } catch (err) {
      next(err);
    }
  });

  // Patients
  router.get('/patients', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const q = String(req.query['q'] ?? '');
      res.json(service.searchPatients(req.authSession!, q));
    } catch (err) {
      next(err);
    }
  });

  router.post('/patients', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.status(201).json(service.registerPatient(req.authSession!, req.body));
    } catch (err) {
      next(err);
    }
  });

  router.post('/patients/merge', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { sourcePatientId, targetPatientId, justification } = req.body as {
        sourcePatientId: string;
        targetPatientId: string;
        justification: string;
      };
      res.json(service.mergePatients(req.authSession!, sourcePatientId, targetPatientId, justification));
    } catch (err) {
      next(err);
    }
  });

  router.get('/patients/:id/overview', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.getPatientOverview(req.authSession!, String(req.params['id'])));
    } catch (err) {
      next(err);
    }
  });

  router.post('/patients/:id/encounters', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.status(201).json(service.createEncounter(req.authSession!, String(req.params['id']), req.body));
    } catch (err) {
      next(err);
    }
  });

  // Notes lifecycle
  router.post('/patients/:id/notes', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.status(201).json(service.createDraftNote(req.authSession!, String(req.params['id']), req.body));
    } catch (err) {
      next(err);
    }
  });

  router.put('/notes/:noteId/draft', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.saveDraftNote(req.authSession!, String(req.params['noteId']), req.body));
    } catch (err) {
      next(err);
    }
  });

  router.post('/notes/:noteId/sign', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.signNote(req.authSession!, String(req.params['noteId']), req.body));
    } catch (err) {
      next(err);
    }
  });

  router.post('/notes/:noteId/amendments', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.status(201).json(service.addNoteAmendment(req.authSession!, String(req.params['noteId']), req.body));
    } catch (err) {
      next(err);
    }
  });

  router.post('/notes/:noteId/entered-in-error', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { reason } = req.body as { reason: string };
      res.json(service.markNoteEnteredInError(req.authSession!, String(req.params['noteId']), reason));
    } catch (err) {
      next(err);
    }
  });

  // Observations & Diagnostic Results
  router.post('/patients/:id/observations', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.status(201).json(service.recordObservation(req.authSession!, String(req.params['id']), req.body));
    } catch (err) {
      next(err);
    }
  });

  router.post('/results/:resultId/state', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { nextState, followUpTitle } = req.body as {
        nextState: 'viewed' | 'acknowledged' | 'follow_up_assigned' | 'follow_up_completed';
        followUpTitle?: string;
      };
      res.json(service.transitionResultState(req.authSession!, String(req.params['resultId']), nextState, followUpTitle));
    } catch (err) {
      next(err);
    }
  });

  router.post('/results/:resultId/simulate-correction', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { newValueText, abnormalFlag, correctionReason } = req.body as {
        newValueText: string;
        abnormalFlag: 'normal' | 'high' | 'low' | 'critical' | 'none';
        correctionReason: string;
      };
      res.status(201).json(
        service.simulateCorrectedResult(
          req.authSession!,
          String(req.params['resultId']),
          newValueText,
          abnormalFlag,
          correctionReason
        )
      );
    } catch (err) {
      next(err);
    }
  });

  // Medications & Allergies
  router.post('/patients/:id/medications', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.status(201).json(service.addMedicationEntry(req.authSession!, String(req.params['id']), req.body));
    } catch (err) {
      next(err);
    }
  });

  router.post('/patients/:id/allergy-assertion', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { status, newAllergy } = req.body;
      res.json(service.setAllergyAssertion(req.authSession!, String(req.params['id']), status, newAllergy));
    } catch (err) {
      next(err);
    }
  });

  // Tasks & Patient Summary
  router.post('/patients/:id/tasks', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.status(201).json(service.createTask(req.authSession!, String(req.params['id']), req.body));
    } catch (err) {
      next(err);
    }
  });

  router.post('/tasks/:taskId/transition', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { nextStatus, completionEvidence, approvePatientSummary } = req.body;
      res.json(
        service.transitionTask(
          req.authSession!,
          String(req.params['taskId']),
          nextStatus,
          completionEvidence,
          approvePatientSummary
        )
      );
    } catch (err) {
      next(err);
    }
  });

  // Protected Attachments
  router.get('/attachments/:attachmentId/download', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.getAttachmentContent(req.authSession!, String(req.params['attachmentId'])));
    } catch (err) {
      next(err);
    }
  });

  // Admin, Audit, Outbox, Backup & Interop
  router.get('/admin/audit', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const patientId = req.query['patientId'] ? String(req.query['patientId']) : undefined;
      res.json(service.listAuditEvents(req.authSession!, patientId));
    } catch (err) {
      next(err);
    }
  });

  router.get('/admin/outbox', requireAuth, (_req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.listOutboxEvents());
    } catch (err) {
      next(err);
    }
  });

  router.post('/admin/outbox/:outboxId/retry', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { simulateFailure } = req.body as { simulateFailure?: boolean };
      res.json(service.retryOutboxEvent(req.authSession!, String(req.params['outboxId']), Boolean(simulateFailure)));
    } catch (err) {
      next(err);
    }
  });

  router.get('/admin/settings', requireAuth, (_req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.getSettings());
    } catch (err) {
      next(err);
    }
  });

  router.post('/admin/settings/ai-adapter', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      const { enabled } = req.body as { enabled: boolean };
      res.json(service.updateAiAdapterSetting(req.authSession!, Boolean(enabled)));
    } catch (err) {
      next(err);
    }
  });

  router.get('/admin/backup', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.exportBackupSnapshot(req.authSession!));
    } catch (err) {
      next(err);
    }
  });

  router.get('/interop/fhir/Patient/:id/$everything', requireAuth, (req: AuthenticatedRequest, res, next) => {
    try {
      res.json(service.buildFhirUkCoreBundle(req.authSession!, String(req.params['id'])));
    } catch (err) {
      next(err);
    }
  });

  // Optional AI Drafting Adapter (DISABLED by default!)
  router.post('/ai/draft-summary', requireAuth, async (req: AuthenticatedRequest, res, next) => {
    try {
      const settings = service.getSettings()['ai_drafting_adapter'] as { enabled?: boolean } | undefined;
      if (!settings?.enabled) {
        throw new ApiError(
          403,
          'AI_ADAPTER_DISABLED',
          'Optional AI drafting adapter is disabled by default. Enable it in Administration to generate clinician-reviewed draft suggestions.'
        );
      }
      const { patientId } = req.body as { patientId?: string };
      if (!patientId) throw new ApiError(400, 'MISSING_PATIENT_ID', 'patientId is required');
      const overview = service.getPatientOverview(req.authSession!, patientId);

      const apiKey = process.env['GEMINI_API_KEY'];
      let draftText = '';
      let uncertaintyNotes = [
        'AI-generated draft suggestion only — clinician must verify every statement against source records before accepting into a note.',
        'Does not sign records, prescribe medications, or close clinical review tasks.',
      ];

      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        const ai = new GoogleGenAI({ apiKey });
        const prompt = `Summarise this synthetic clinical record into a concise, cautious clinical draft note with explicit source citations [Source: ID]. Do NOT invent findings. Explicitly note any conflicts or unverified data.\n\nActive Problems: ${JSON.stringify(overview.problems.map((p) => ({ id: p.id, display: p.display, status: p.verificationStatus, conflict: p.conflictNote })))}\nObservations: ${JSON.stringify(overview.observations.slice(0, 5).map((o) => ({ id: o.id, display: o.display, value: o.valueText, unit: o.unit })))}\nResults: ${JSON.stringify(overview.results.map((r) => ({ id: r.id, order: r.orderName, value: r.valueText, unit: r.unit, status: r.resultStatus })))}\nMedications: ${JSON.stringify(overview.medications.map((m) => ({ id: m.id, drug: m.drugName, dose: m.dose, type: m.conceptType, rec: m.reconciliationStatus })))}`;
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });
        draftText = response.text || '';
      } else {
        // Deterministic structured clinical summary from authorised records when GEMINI_API_KEY is not configured
        const topResults = overview.results
          .slice(0, 3)
          .map((r) => `• ${r.orderName}: ${r.valueText} ${r.unit} (${r.resultStatus}, flag: ${r.abnormalFlag}) [Source: Result ${r.id}]`)
          .join('\n');
        const conflicts =
          overview.conflicts.length > 0
            ? overview.conflicts.map((c) => `• Conflict (${c.type}): ${c.summary} [Sources: ${c.recordIds.join(', ')}]`).join('\n')
            : '• No active record conflicts detected.';
        draftText = [
          `Suggested Clinical Summary Draft (Clinician Review Required):`,
          `Presenting Concern: ${overview.activeEncounter?.presentingConcern ?? 'Not documented'} [Source: Encounter ${overview.activeEncounter?.id ?? 'N/A'}]`,
          `Key Diagnostic Results:\n${topResults}`,
          `Recorded Conflicts & Uncertainties:\n${conflicts}`,
        ].join('\n\n');
        uncertaintyNotes = [
          ...uncertaintyNotes,
          'Generated via deterministic local clinical summariser (GEMINI_API_KEY not configured).',
        ];
      }

      res.json({
        draftId: `aidraft-${Date.now()}`,
        requiresClinicianAcceptance: true,
        draftText,
        uncertaintyNotes,
        sourceLinks: [
          ...overview.results.slice(0, 3).map((r) => ({ type: 'DiagnosticResult', id: r.id, label: r.orderName })),
          ...overview.problems.slice(0, 3).map((p) => ({ type: 'Problem', id: p.id, label: p.display })),
        ],
      });
    } catch (err) {
      next(err);
    }
  });

  // Error handler
  router.use((err: unknown, _req: Request, res: Response, next: NextFunction) => {
    void next;
    if (err instanceof ApiError) {
      res.status(err.statusCode).json({
        error: {
          code: err.code,
          message: err.message,
          details: err.details ?? null,
        },
      });
      return;
    }
    console.error(JSON.stringify({ ts: new Date().toISOString(), level: 'error', message: 'Unhandled API error' }));
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'Unexpected server error' } });
  });

  return { router, db, service };
}
