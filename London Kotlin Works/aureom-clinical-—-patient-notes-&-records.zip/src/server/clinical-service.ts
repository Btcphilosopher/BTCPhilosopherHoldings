import { DatabaseSync } from 'node:sqlite';
import { randomUUID, randomBytes } from 'node:crypto';
import { sha256Hex, signAttestationPayload, withTransaction } from './db.js';
import { appendAuditEvent } from './seed.js';
import type {
  Allergy,
  AllergyAssertionStatus,
  AuditEvent,
  AuthSession,
  CarePlan,
  ClinicalAttachment,
  ClinicalNote,
  ClinicalTask,
  Clinician,
  DiagnosticResult,
  DuplicateCandidate,
  Encounter,
  MedicationConceptType,
  MedicationEntry,
  NoteAmendment,
  NoteRevision,
  NoteSection,
  NoteTemplateType,
  Observation,
  OutboxEvent,
  Patient,
  PatientIdentifier,
  PatientOverview,
  Problem,
  ResultReviewState,
  TaskStatus,
  TaskType,
  WorklistResponse,
} from '../shared/clinical-types.js';

export class ApiError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string,
    public details?: Record<string, unknown>
  ) {
    super(message);
  }
}

function nowIso(): string {
  return new Date().toISOString();
}

export function mapClinicianRow(row: Record<string, unknown>): Clinician {
  return {
    id: String(row['id']),
    oidcSubject: String(row['oidc_subject']),
    displayName: String(row['display_name']),
    role: row['role'] as Clinician['role'],
    specialty: String(row['specialty']),
    gmcOrNmcNumber: String(row['gmc_or_nmc_number']),
    organisationId: String(row['organisation_id']),
    organisationName: String(row['organisation_name'] ?? ''),
    email: String(row['email']),
  };
}

export function mapPatientRow(db: DatabaseSync, row: Record<string, unknown>): Patient {
  const id = String(row['id']);
  const identRows = db
    .prepare('SELECT * FROM patient_identifiers WHERE patient_id = ? ORDER BY is_primary DESC')
    .all(id);
  const identifiers: PatientIdentifier[] = identRows.map((r) => ({
    id: String(r['id']),
    patientId: String(r['patient_id']),
    system: String(r['system']),
    value: String(r['value']),
    authority: String(r['authority']),
    verificationStatus: r['verification_status'] as Patient['nhsVerificationStatus'],
    provenance: String(r['provenance']),
    isPrimary: Number(r['is_primary']) === 1,
  }));

  return {
    id,
    internalMrn: String(row['internal_mrn']),
    familyName: String(row['family_name']),
    givenNames: String(row['given_names']),
    preferredName: row['preferred_name'] ? String(row['preferred_name']) : null,
    dob: String(row['dob']),
    sexAtBirth: String(row['sex_at_birth']),
    genderIdentity: row['gender_identity'] ? String(row['gender_identity']) : null,
    nhsNumber: row['nhs_number'] ? String(row['nhs_number']) : null,
    nhsVerificationStatus: row['nhs_verification_status'] as Patient['nhsVerificationStatus'],
    demographicHistory: JSON.parse(String(row['demographic_history_json'])),
    contact: JSON.parse(String(row['contact_json'])),
    gpPractice: JSON.parse(String(row['gp_practice_json'])),
    allergyAssertionStatus: row['allergy_assertion_status'] as AllergyAssertionStatus,
    mergedIntoPatientId: row['merged_into_patient_id'] ? String(row['merged_into_patient_id']) : null,
    organisationId: String(row['organisation_id']),
    createdAt: String(row['created_at']),
    updatedAt: String(row['updated_at']),
    identifiers,
  };
}

export class ClinicalService {
  constructor(private db: DatabaseSync) {}

  listClinicians(): Clinician[] {
    const rows = this.db
      .prepare(
        `SELECT c.*, o.name AS organisation_name
         FROM clinicians c
         JOIN organisations o ON o.id = c.organisation_id
         ORDER BY c.display_name ASC`
      )
      .all();
    return rows.map(mapClinicianRow);
  }

  loginWithLocalOidc(clinicianId: string, issuer = 'https://oidc.local.aureom.prototype'): AuthSession {
    const row = this.db
      .prepare(
        `SELECT c.*, o.name AS organisation_name
         FROM clinicians c
         JOIN organisations o ON o.id = c.organisation_id
         WHERE c.id = ?`
      )
      .get(clinicianId);

    if (!row) {
      throw new ApiError(404, 'CLINICIAN_NOT_FOUND', 'Clinician account not found in local OIDC directory');
    }

    const clinician = mapClinicianRow(row);
    const token = randomBytes(32).toString('base64url');
    const tokenHash = sha256Hex(token);
    const createdAt = nowIso();
    const expiresAt = new Date(Date.now() + 60 * 60_000).toISOString();

    this.db
      .prepare(
        `INSERT INTO sessions (token_hash, clinician_id, oidc_issuer, expires_at, created_at)
         VALUES (?, ?, ?, ?, ?)`
      )
      .run(tokenHash, clinician.id, issuer, expiresAt, createdAt);

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: createdAt,
      actorId: clinician.id,
      actorName: clinician.displayName,
      actorRole: clinician.role,
      organisationId: clinician.organisationId,
      action: 'auth.oidc_login',
      resourceType: 'Session',
      resourceId: tokenHash.slice(0, 12),
      patientId: null,
      outcome: 'allow',
      reason: `Authenticated via ${issuer}`,
      metadata: { oidcSubject: clinician.oidcSubject },
    });

    return {
      token,
      clinician,
      expiresAt,
      breakGlassPatientId: null,
      breakGlassExpiresAt: null,
      breakGlassReason: null,
      oidcIssuer: issuer,
    };
  }

  authenticateToken(token: string | undefined): AuthSession {
    if (!token) {
      throw new ApiError(401, 'UNAUTHENTICATED', 'Authentication bearer token required');
    }
    const tokenHash = sha256Hex(token);
    const row = this.db
      .prepare(
        `SELECT s.*, c.id AS c_id, c.oidc_subject, c.display_name, c.role, c.specialty,
                c.gmc_or_nmc_number, c.organisation_id, c.email, o.name AS organisation_name
         FROM sessions s
         JOIN clinicians c ON c.id = s.clinician_id
         JOIN organisations o ON o.id = c.organisation_id
         WHERE s.token_hash = ?`
      )
      .get(tokenHash);

    if (!row) {
      throw new ApiError(401, 'INVALID_SESSION', 'Session token is invalid');
    }
    if (row['revoked_at']) {
      throw new ApiError(401, 'SESSION_REVOKED', 'Session has been revoked');
    }
    if (Date.parse(String(row['expires_at'])) <= Date.now()) {
      throw new ApiError(401, 'SESSION_EXPIRED', 'Session has expired; please re-authenticate');
    }

    const clinician: Clinician = {
      id: String(row['c_id']),
      oidcSubject: String(row['oidc_subject']),
      displayName: String(row['display_name']),
      role: row['role'] as Clinician['role'],
      specialty: String(row['specialty']),
      gmcOrNmcNumber: String(row['gmc_or_nmc_number']),
      organisationId: String(row['organisation_id']),
      organisationName: String(row['organisation_name']),
      email: String(row['email']),
    };

    const bgExpires = row['break_glass_expires_at'] ? String(row['break_glass_expires_at']) : null;
    const bgValid = bgExpires ? Date.parse(bgExpires) > Date.now() : false;

    return {
      token,
      clinician,
      expiresAt: String(row['expires_at']),
      breakGlassPatientId: bgValid && row['break_glass_patient_id'] ? String(row['break_glass_patient_id']) : null,
      breakGlassExpiresAt: bgValid ? bgExpires : null,
      breakGlassReason: bgValid && row['break_glass_reason'] ? String(row['break_glass_reason']) : null,
      oidcIssuer: String(row['oidc_issuer']),
    };
  }

  logout(token: string): void {
    const session = this.authenticateToken(token);
    const tokenHash = sha256Hex(token);
    const ts = nowIso();
    this.db.prepare('UPDATE sessions SET revoked_at = ? WHERE token_hash = ?').run(ts, tokenHash);
    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: ts,
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'auth.logout',
      resourceType: 'Session',
      resourceId: tokenHash.slice(0, 12),
      patientId: null,
      outcome: 'allow',
      reason: 'User signed out',
      metadata: {},
    });
  }

  requestBreakGlass(session: AuthSession, patientId: string, reason: string): AuthSession {
    if (!reason || reason.trim().length < 10) {
      throw new ApiError(400, 'INVALID_BREAK_GLASS_REASON', 'Emergency break-glass access requires a clinical justification of at least 10 characters');
    }
    const patientRow = this.db.prepare('SELECT id FROM patients WHERE id = ?').get(patientId);
    if (!patientRow) {
      throw new ApiError(404, 'PATIENT_NOT_FOUND', 'Target patient record not found');
    }
    const expiresAt = new Date(Date.now() + 30 * 60_000).toISOString();
    const tokenHash = sha256Hex(session.token);
    this.db
      .prepare(
        `UPDATE sessions
         SET break_glass_patient_id = ?, break_glass_expires_at = ?, break_glass_reason = ?
         WHERE token_hash = ?`
      )
      .run(patientId, expiresAt, reason.trim(), tokenHash);

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: nowIso(),
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'access.break_glass_activated',
      resourceType: 'Patient',
      resourceId: patientId,
      patientId,
      outcome: 'allow',
      reason: reason.trim(),
      metadata: { expiresAt, requiresIgReview: true },
    });

    return this.authenticateToken(session.token);
  }

  assertPatientAccess(
    session: AuthSession,
    patientId: string,
    action: string,
    requireClinicalWrite = false
  ): Patient {
    const row = this.db.prepare('SELECT * FROM patients WHERE id = ?').get(patientId);
    if (!row) {
      throw new ApiError(404, 'PATIENT_NOT_FOUND', 'Patient record not found');
    }
    const patient = mapPatientRow(this.db, row);

    if (requireClinicalWrite && session.clinician.role === 'IGLead') {
      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: nowIso(),
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action,
        resourceType: 'Patient',
        resourceId: patientId,
        patientId,
        outcome: 'deny',
        reason: 'IG Lead role is read-only for clinical charting',
        metadata: {},
      });
      throw new ApiError(403, 'PERMISSION_DENIED', 'Information Governance Lead accounts cannot author clinical records');
    }

    const sameOrg = patient.organisationId === session.clinician.organisationId;
    const careTeam = this.db
      .prepare(
        'SELECT 1 FROM care_team_associations WHERE patient_id = ? AND clinician_id = ? AND active = 1'
      )
      .get(patientId, session.clinician.id);
    const hasBreakGlass = session.breakGlassPatientId === patientId;

    if (!sameOrg && !careTeam && !hasBreakGlass) {
      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: nowIso(),
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action,
        resourceType: 'Patient',
        resourceId: patientId,
        patientId,
        outcome: 'deny',
        reason: `Cross-organisation access blocked (patient org ${patient.organisationId}, actor org ${session.clinician.organisationId})`,
        metadata: {},
      });
      throw new ApiError(
        403,
        'PERMISSION_DENIED',
        'Access denied: patient belongs to another trust and you have no active care relationship or emergency break-glass authorisation.'
      );
    }

    return patient;
  }

  getWorklist(session: AuthSession): WorklistResponse {
    const orgId = session.clinician.organisationId;
    const encRows = this.db
      .prepare(
        `SELECT e.*, p.id AS p_id, c.display_name AS clinician_name
         FROM encounters e
         JOIN patients p ON p.id = e.patient_id
         JOIN clinicians c ON c.id = e.responsible_clinician_id
         WHERE e.organisation_id = ? AND p.merged_into_patient_id IS NULL
           AND e.status IN ('planned', 'arrived', 'in_progress')
         ORDER BY e.occurred_at DESC`
      )
      .all(orgId);

    const scheduledPatients = encRows.map((er) => {
      const pRow = this.db.prepare('SELECT * FROM patients WHERE id = ?').get(String(er['patient_id']))!;
      const patient = mapPatientRow(this.db, pRow);
      const pendingResultsCount = Number(
        (
          this.db
            .prepare(
              `SELECT COUNT(*) AS c FROM diagnostic_results
               WHERE patient_id = ? AND review_state IN ('available', 'viewed')`
            )
            .get(patient.id) as { c: number }
        ).c
      );
      const openTasksCount = Number(
        (
          this.db
            .prepare(
              `SELECT COUNT(*) AS c FROM tasks
               WHERE patient_id = ? AND status NOT IN ('completed', 'cancelled')`
            )
            .get(patient.id) as { c: number }
        ).c
      );
      const draftNotesCount = Number(
        (
          this.db
            .prepare(
              `SELECT COUNT(*) AS c FROM clinical_notes
               WHERE patient_id = ? AND status = 'draft'`
            )
            .get(patient.id) as { c: number }
        ).c
      );

      const encounter: Encounter = {
        id: String(er['id']),
        patientId: String(er['patient_id']),
        organisationId: String(er['organisation_id']),
        encounterType: er['encounter_type'] as Encounter['encounterType'],
        location: String(er['location']),
        wardOrClinic: String(er['ward_or_clinic']),
        responsibleClinicianId: String(er['responsible_clinician_id']),
        responsibleClinicianName: String(er['clinician_name']),
        status: er['status'] as Encounter['status'],
        presentingConcern: String(er['presenting_concern']),
        occurredAt: String(er['occurred_at']),
        documentedAt: String(er['documented_at']),
      };

      return { patient, encounter, pendingResultsCount, openTasksCount, draftNotesCount };
    });

    const pendingResRows = this.db
      .prepare(
        `SELECT r.*, p.family_name, p.given_names, p.nhs_number
         FROM diagnostic_results r
         JOIN patients p ON p.id = r.patient_id
         WHERE p.organisation_id = ? AND p.merged_into_patient_id IS NULL
           AND r.review_state IN ('available', 'viewed')
         ORDER BY r.reported_at DESC`
      )
      .all(orgId);

    const pendingResultsToAcknowledge = pendingResRows.map((r) => ({
      ...this.mapResultRow(r),
      patientName: `${String(r['family_name']).toUpperCase()}, ${String(r['given_names'])}`,
      nhsNumber: r['nhs_number'] ? String(r['nhs_number']) : null,
    }));

    const taskRows = this.db
      .prepare(
        `SELECT t.*, c.display_name AS owner_name, p.family_name, p.given_names
         FROM tasks t
         JOIN clinicians c ON c.id = t.owner_id
         JOIN patients p ON p.id = t.patient_id
         WHERE p.organisation_id = ? AND p.merged_into_patient_id IS NULL
           AND t.status NOT IN ('completed', 'cancelled')
         ORDER BY CASE t.priority WHEN 'stat' THEN 1 WHEN 'urgent' THEN 2 ELSE 3 END, t.due_at ASC`
      )
      .all(orgId);

    const openTasks = taskRows.map((t) => ({
      ...this.mapTaskRow(t),
      patientName: `${String(t['family_name']).toUpperCase()}, ${String(t['given_names'])}`,
    }));

    return {
      clinician: session.clinician,
      serverTimeUtc: nowIso(),
      scheduledPatients,
      pendingResultsToAcknowledge,
      openTasks,
    };
  }

  searchPatients(session: AuthSession, query: string): { patients: Patient[]; crossOrgCount: number } {
    const q = `%${query.trim().toLowerCase()}%`;
    const rows = this.db
      .prepare(
        `SELECT * FROM patients
         WHERE merged_into_patient_id IS NULL
           AND (
             LOWER(family_name || ' ' || given_names) LIKE ?
             OR LOWER(internal_mrn) LIKE ?
             OR REPLACE(COALESCE(nhs_number, ''), ' ', '') LIKE REPLACE(?, ' ', '')
           )
         ORDER BY family_name ASC, given_names ASC`
      )
      .all(q, q, q);

    const accessible: Patient[] = [];
    let crossOrgCount = 0;

    for (const row of rows) {
      const p = mapPatientRow(this.db, row);
      const sameOrg = p.organisationId === session.clinician.organisationId;
      const breakGlass = session.breakGlassPatientId === p.id;
      const careTeam = this.db
        .prepare('SELECT 1 FROM care_team_associations WHERE patient_id = ? AND clinician_id = ? AND active = 1')
        .get(p.id, session.clinician.id);

      if (sameOrg || breakGlass || careTeam) {
        accessible.push(p);
      } else {
        crossOrgCount += 1;
        // Return minimal sealed stub for emergency break-glass discovery?
        // Only if exact search or keep isolated — let's include external ID indicator ONLY when searching explicitly by name/NHS number so break-glass can be demonstrated!
        if (query.trim().length >= 3) {
          accessible.push({
            ...p,
            contact: { phone: 'Restricted', email: 'Restricted', addressLine1: 'Restricted (External Trust)', city: '', postcode: '', preferredMethod: 'Restricted' },
          });
        }
      }
    }

    return { patients: accessible, crossOrgCount };
  }

  registerPatient(
    session: AuthSession,
    input: {
      familyName: string;
      givenNames: string;
      preferredName?: string;
      dob: string;
      sexAtBirth: string;
      nhsNumber?: string;
      nhsVerificationStatus: Patient['nhsVerificationStatus'];
      phone: string;
      email: string;
      addressLine1: string;
      city: string;
      postcode: string;
      gpPracticeName: string;
      gpOdsCode: string;
    }
  ): { patient: Patient; duplicateWarnings: DuplicateCandidate[] } {
    if (session.clinician.role === 'IGLead') {
      throw new ApiError(403, 'PERMISSION_DENIED', 'IG Lead accounts cannot register clinical patients');
    }
    const id = `pat-${randomUUID().slice(0, 8)}`;
    const mrn = `MRN-${Math.floor(200000 + Math.random() * 799999)}`;
    const ts = nowIso();

    const duplicateCandidates = this.findDuplicatesForFields(
      input.familyName,
      input.dob,
      session.clinician.organisationId,
      id
    );

    withTransaction(this.db, () => {
      this.db
        .prepare(
          `INSERT INTO patients (
            id, internal_mrn, family_name, given_names, preferred_name, dob, sex_at_birth,
            gender_identity, nhs_number, nhs_verification_status, demographic_history_json,
            contact_json, gp_practice_json, allergy_assertion_status, merged_into_patient_id,
            organisation_id, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)`
        )
        .run(
          id,
          mrn,
          input.familyName.trim(),
          input.givenNames.trim(),
          input.preferredName?.trim() || null,
          input.dob,
          input.sexAtBirth,
          input.sexAtBirth,
          input.nhsNumber?.trim() || null,
          input.nhsVerificationStatus,
          JSON.stringify([]),
          JSON.stringify({
            phone: input.phone,
            email: input.email,
            addressLine1: input.addressLine1,
            city: input.city,
            postcode: input.postcode,
            preferredMethod: 'Telephone',
          }),
          JSON.stringify({
            odsCode: input.gpOdsCode || 'G00000',
            practiceName: input.gpPracticeName || 'Unassigned Practice',
            gpName: 'To be confirmed',
            phone: '',
          }),
          'not_assessed',
          session.clinician.organisationId,
          ts,
          ts
        );

      this.db
        .prepare(
          `INSERT INTO patient_identifiers (
            id, patient_id, system, value, authority, verification_status, provenance, is_primary
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          randomUUID(),
          id,
          'urn:aureom:mrn',
          mrn,
          'Aureom Local PAS',
          input.nhsVerificationStatus,
          'Manual Clinical Registration',
          input.nhsNumber ? 0 : 1
        );

      if (input.nhsNumber?.trim()) {
        this.db
          .prepare(
            `INSERT INTO patient_identifiers (
              id, patient_id, system, value, authority, verification_status, provenance, is_primary
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 1)`
          )
          .run(
            randomUUID(),
            id,
            'https://fhir.nhs.uk/Id/nhs-number',
            input.nhsNumber.trim(),
            'User Entered (Pending PDS Trace)',
            input.nhsVerificationStatus,
            'Manual Registration',
            1
          );
      }

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'patient.register',
        resourceType: 'Patient',
        resourceId: id,
        patientId: id,
        outcome: 'allow',
        reason: duplicateCandidates.length > 0 ? 'Registered with demographic duplicate warning (not auto-merged)' : 'New synthetic patient registered',
        metadata: { verificationStatus: input.nhsVerificationStatus, duplicateCount: duplicateCandidates.length },
      });
    });

    const row = this.db.prepare('SELECT * FROM patients WHERE id = ?').get(id)!;
    return { patient: mapPatientRow(this.db, row), duplicateWarnings: duplicateCandidates };
  }

  private findDuplicatesForFields(
    familyName: string,
    dob: string,
    orgId: string,
    excludePatientId: string
  ): DuplicateCandidate[] {
    const rows = this.db
      .prepare(
        `SELECT * FROM patients
         WHERE organisation_id = ? AND id != ? AND merged_into_patient_id IS NULL
           AND LOWER(family_name) = LOWER(?) AND dob = ?`
      )
      .all(orgId, excludePatientId, familyName.trim(), dob);

    return rows.map((r) => {
      const candidate = mapPatientRow(this.db, r);
      return {
        candidatePatient: candidate,
        matchBasis: 'Family Name + Date of Birth match',
        confidenceLabel: 'Demographic Match Only — Unverified',
        warningMessage:
          'Demographic match detected. Records are NOT automatically merged; verify NHS Number & provenance before authorised merge.',
      };
    });
  }

  mergePatients(
    session: AuthSession,
    sourcePatientId: string,
    targetPatientId: string,
    justification: string
  ): PatientOverview {
    if (!['Consultant', 'Admin', 'IGLead'].includes(session.clinician.role)) {
      throw new ApiError(403, 'PERMISSION_DENIED', 'Only Consultant, Admin, or IG Lead roles may merge duplicate patient records');
    }
    if (sourcePatientId === targetPatientId) {
      throw new ApiError(400, 'INVALID_MERGE', 'Source and target patient IDs must differ');
    }
    const source = this.assertPatientAccess(session, sourcePatientId, 'patient.merge_source');
    const target = this.assertPatientAccess(session, targetPatientId, 'patient.merge_target');
    if (source.mergedIntoPatientId) {
      throw new ApiError(409, 'ALREADY_MERGED', 'Source patient has already been merged');
    }

    const ts = nowIso();
    withTransaction(this.db, () => {
      // Preserve source identifiers onto target with provenance note
      const idents = this.db
        .prepare('SELECT * FROM patient_identifiers WHERE patient_id = ?')
        .all(sourcePatientId);
      for (const ident of idents) {
        this.db
          .prepare(
            `INSERT INTO patient_identifiers (
              id, patient_id, system, value, authority, verification_status, provenance, is_primary
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 0)`
          )
          .run(
            randomUUID(),
            targetPatientId,
            String(ident['system']),
            String(ident['value']),
            String(ident['authority']),
            String(ident['verification_status']),
            `Preserved from merged record ${source.internalMrn}: ${String(ident['provenance'])}`,
          );
      }

      // Re-link clinical records from source to target
      for (const table of [
        'encounters',
        'problems',
        'allergies',
        'medications',
        'observations',
        'diagnostic_results',
        'clinical_notes',
        'care_plans',
        'tasks',
        'attachments',
      ]) {
        this.db.prepare(`UPDATE ${table} SET patient_id = ? WHERE patient_id = ?`).run(targetPatientId, sourcePatientId);
      }

      // Record demographic history on target
      const updatedHistory = [
        ...target.demographicHistory,
        {
          recordedAt: ts,
          field: 'mergedRecord',
          previousValue: `${source.internalMrn} (${source.givenNames} ${source.familyName})`,
          newValue: `Merged into ${target.internalMrn}`,
          source: `Authorised Merge by ${session.clinician.displayName}: ${justification}`,
        },
      ];

      this.db
        .prepare('UPDATE patients SET demographic_history_json = ?, updated_at = ? WHERE id = ?')
        .run(JSON.stringify(updatedHistory), ts, targetPatientId);

      this.db
        .prepare('UPDATE patients SET merged_into_patient_id = ?, updated_at = ? WHERE id = ?')
        .run(targetPatientId, ts, sourcePatientId);

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'patient.authorised_merge',
        resourceType: 'Patient',
        resourceId: targetPatientId,
        patientId: targetPatientId,
        outcome: 'allow',
        reason: justification,
        metadata: { sourcePatientId, sourceMrn: source.internalMrn, targetMrn: target.internalMrn },
      });
    });

    return this.getPatientOverview(session, targetPatientId);
  }

  getPatientOverview(session: AuthSession, patientId: string): PatientOverview {
    const patient = this.assertPatientAccess(session, patientId, 'patient.view_record');

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: nowIso(),
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'patient.view_overview',
      resourceType: 'Patient',
      resourceId: patientId,
      patientId,
      outcome: 'allow',
      reason: session.breakGlassPatientId === patientId ? `Break-glass: ${session.breakGlassReason}` : 'Direct/Org Care Access',
      metadata: {},
    });

    const encounters = this.db
      .prepare(
        `SELECT e.*, c.display_name AS clinician_name
         FROM encounters e
         JOIN clinicians c ON c.id = e.responsible_clinician_id
         WHERE e.patient_id = ?
         ORDER BY e.occurred_at DESC`
      )
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        organisationId: String(r['organisation_id']),
        encounterType: r['encounter_type'] as Encounter['encounterType'],
        location: String(r['location']),
        wardOrClinic: String(r['ward_or_clinic']),
        responsibleClinicianId: String(r['responsible_clinician_id']),
        responsibleClinicianName: String(r['clinician_name']),
        status: r['status'] as Encounter['status'],
        presentingConcern: String(r['presenting_concern']),
        occurredAt: String(r['occurred_at']),
        documentedAt: String(r['documented_at']),
      }));

    const activeEncounter =
      encounters.find((e) => e.status === 'in_progress' || e.status === 'arrived') ?? encounters[0] ?? null;

    const problems: Problem[] = this.db
      .prepare(
        `SELECT p.*, c.display_name AS author_name
         FROM problems p
         JOIN clinicians c ON c.id = p.author_id
         WHERE p.patient_id = ?
         ORDER BY p.documented_at DESC`
      )
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        encounterId: r['encounter_id'] ? String(r['encounter_id']) : null,
        code: String(r['code']),
        codeSystem: String(r['code_system']),
        display: String(r['display']),
        clinicalStatus: r['clinical_status'] as Problem['clinicalStatus'],
        verificationStatus: r['verification_status'] as Problem['verificationStatus'],
        onsetAt: r['onset_at'] ? String(r['onset_at']) : null,
        documentedAt: String(r['documented_at']),
        authorId: String(r['author_id']),
        authorName: String(r['author_name']),
        sourceProvenance: String(r['source_provenance']),
        conflictGroupId: r['conflict_group_id'] ? String(r['conflict_group_id']) : null,
        conflictNote: r['conflict_note'] ? String(r['conflict_note']) : null,
      }));

    const allergies: Allergy[] = this.db
      .prepare(
        `SELECT a.*, c.display_name AS author_name
         FROM allergies a
         JOIN clinicians c ON c.id = a.author_id
         WHERE a.patient_id = ?
         ORDER BY a.recorded_at DESC`
      )
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        substance: String(r['substance']),
        code: String(r['code']),
        reaction: String(r['reaction']),
        severity: r['severity'] as Allergy['severity'],
        verificationStatus: r['verification_status'] as Allergy['verificationStatus'],
        clinicalStatus: r['clinical_status'] as Allergy['clinicalStatus'],
        provenance: String(r['provenance']),
        recordedAt: String(r['recorded_at']),
        authorId: String(r['author_id']),
        authorName: String(r['author_name']),
      }));

    const medications: MedicationEntry[] = this.db
      .prepare(
        `SELECT m.*, c.display_name AS author_name
         FROM medications m
         JOIN clinicians c ON c.id = m.author_id
         WHERE m.patient_id = ?
         ORDER BY m.documented_at DESC`
      )
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        encounterId: r['encounter_id'] ? String(r['encounter_id']) : null,
        conceptType: r['concept_type'] as MedicationConceptType,
        drugName: String(r['drug_name']),
        dmdCode: String(r['dmd_code']),
        strength: String(r['strength']),
        dose: String(r['dose']),
        route: String(r['route']),
        frequency: String(r['frequency']),
        startDate: String(r['start_date']),
        endDate: r['end_date'] ? String(r['end_date']) : null,
        status: r['status'] as MedicationEntry['status'],
        source: String(r['source']),
        reconciliationStatus: r['reconciliation_status'] as MedicationEntry['reconciliationStatus'],
        conflictGroupId: r['conflict_group_id'] ? String(r['conflict_group_id']) : null,
        authorId: String(r['author_id']),
        authorName: String(r['author_name']),
        documentedAt: String(r['documented_at']),
      }));

    const observations: Observation[] = this.db
      .prepare('SELECT * FROM observations WHERE patient_id = ? ORDER BY observed_at DESC')
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        encounterId: r['encounter_id'] ? String(r['encounter_id']) : null,
        code: String(r['code']),
        terminologySystem: String(r['terminology_system']),
        display: String(r['display']),
        valueNum: r['value_num'] !== null ? Number(r['value_num']) : null,
        valueText: String(r['value_text']),
        unit: String(r['unit']),
        referenceLow: r['reference_low'] !== null ? Number(r['reference_low']) : null,
        referenceHigh: r['reference_high'] !== null ? Number(r['reference_high']) : null,
        interpretation: r['interpretation'] as Observation['interpretation'],
        observedAt: String(r['observed_at']),
        documentedAt: String(r['documented_at']),
        recordingSource: String(r['recording_source']),
        attribution: String(r['attribution']),
        verificationStatus: r['verification_status'] as Observation['verificationStatus'],
      }));

    const results: DiagnosticResult[] = this.db
      .prepare('SELECT * FROM diagnostic_results WHERE patient_id = ? ORDER BY reported_at DESC')
      .all(patientId)
      .map((r) => this.mapResultRow(r));

    const notes: ClinicalNote[] = this.db
      .prepare(
        `SELECT n.*, a.display_name AS author_name, s.display_name AS signed_by_name
         FROM clinical_notes n
         JOIN clinicians a ON a.id = n.author_id
         LEFT JOIN clinicians s ON s.id = n.signed_by
         WHERE n.patient_id = ?
         ORDER BY n.updated_at DESC`
      )
      .all(patientId)
      .map((r) => this.hydrateNote(r));

    const carePlans: CarePlan[] = this.db
      .prepare(
        `SELECT cp.*, c.display_name AS author_name
         FROM care_plans cp
         JOIN clinicians c ON c.id = cp.author_id
         WHERE cp.patient_id = ?
         ORDER BY cp.updated_at DESC`
      )
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        title: String(r['title']),
        category: String(r['category']),
        status: r['status'] as CarePlan['status'],
        goals: JSON.parse(String(r['goals_json'])),
        interventions: JSON.parse(String(r['interventions_json'])),
        reviewDate: String(r['review_date']),
        authorId: String(r['author_id']),
        authorName: String(r['author_name']),
        updatedAt: String(r['updated_at']),
      }));

    const tasks: ClinicalTask[] = this.db
      .prepare(
        `SELECT t.*, c.display_name AS owner_name
         FROM tasks t
         JOIN clinicians c ON c.id = t.owner_id
         WHERE t.patient_id = ?
         ORDER BY t.created_at DESC`
      )
      .all(patientId)
      .map((r) => this.mapTaskRow(r));

    const attachments: ClinicalAttachment[] = this.db
      .prepare(
        `SELECT att.*, c.display_name AS uploaded_by_name
         FROM attachments att
         JOIN clinicians c ON c.id = att.uploaded_by
         WHERE att.patient_id = ?
         ORDER BY att.uploaded_at DESC`
      )
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        encounterId: r['encounter_id'] ? String(r['encounter_id']) : null,
        filename: String(r['filename']),
        mimeType: String(r['mime_type']),
        sizeBytes: Number(r['size_bytes']),
        sha256Hex: String(r['sha256_hex']),
        classification: r['classification'] as ClinicalAttachment['classification'],
        uploadedBy: String(r['uploaded_by']),
        uploadedByName: String(r['uploaded_by_name']),
        uploadedAt: String(r['uploaded_at']),
      }));

    const duplicateCandidates = this.findDuplicatesForFields(
      patient.familyName,
      patient.dob,
      patient.organisationId,
      patient.id
    );

    const conflicts: PatientOverview['conflicts'] = [];
    const probGroups = new Map<string, Problem[]>();
    for (const p of problems) {
      if (p.conflictGroupId) {
        probGroups.set(p.conflictGroupId, [...(probGroups.get(p.conflictGroupId) ?? []), p]);
      }
    }
    for (const [, group] of probGroups) {
      if (group.length > 1) {
        conflicts.push({
          type: 'problem',
          summary: `${group.map((g) => `${g.display} [${g.sourceProvenance}]`).join(' vs. ')}`,
          recordIds: group.map((g) => g.id),
        });
      }
    }

    const medGroups = new Map<string, MedicationEntry[]>();
    for (const m of medications) {
      if (m.conflictGroupId) {
        medGroups.set(m.conflictGroupId, [...(medGroups.get(m.conflictGroupId) ?? []), m]);
      }
    }
    for (const [, group] of medGroups) {
      if (group.length > 1) {
        conflicts.push({
          type: 'medication',
          summary: `${group.map((g) => `${g.drugName} ${g.dose} (${g.conceptType})`).join(' vs. ')}`,
          recordIds: group.map((g) => g.id),
        });
      }
    }
    if (duplicateCandidates.length > 0) {
      conflicts.push({
        type: 'identity',
        summary: `${duplicateCandidates.length} unverified demographic match(es) detected — manual verification required`,
        recordIds: duplicateCandidates.map((d) => d.candidatePatient.id),
      });
    }

    return {
      patient,
      encounters,
      activeEncounter,
      problems,
      allergies,
      medications,
      observations,
      results,
      notes,
      carePlans,
      tasks,
      attachments,
      duplicateCandidates,
      conflicts,
    };
  }

  createEncounter(
    session: AuthSession,
    patientId: string,
    input: {
      encounterType: Encounter['encounterType'];
      location: string;
      wardOrClinic: string;
      presentingConcern: string;
    }
  ): Encounter {
    this.assertPatientAccess(session, patientId, 'encounter.create', true);
    const id = `enc-${randomUUID().slice(0, 8)}`;
    const ts = nowIso();
    this.db
      .prepare(
        `INSERT INTO encounters (
          id, patient_id, organisation_id, encounter_type, location, ward_or_clinic,
          responsible_clinician_id, status, presenting_concern, occurred_at, documented_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'in_progress', ?, ?, ?)`
      )
      .run(
        id,
        patientId,
        session.clinician.organisationId,
        input.encounterType,
        input.location,
        input.wardOrClinic,
        session.clinician.id,
        input.presentingConcern,
        ts,
        ts
      );

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: ts,
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'encounter.create',
      resourceType: 'Encounter',
      resourceId: id,
      patientId,
      outcome: 'allow',
      reason: 'Clinician initiated/confirmed encounter',
      metadata: { encounterType: input.encounterType },
    });

    const r = this.db
      .prepare(
        `SELECT e.*, c.display_name AS clinician_name
         FROM encounters e JOIN clinicians c ON c.id = e.responsible_clinician_id
         WHERE e.id = ?`
      )
      .get(id)!;
    return {
      id: String(r['id']),
      patientId: String(r['patient_id']),
      organisationId: String(r['organisation_id']),
      encounterType: r['encounter_type'] as Encounter['encounterType'],
      location: String(r['location']),
      wardOrClinic: String(r['ward_or_clinic']),
      responsibleClinicianId: String(r['responsible_clinician_id']),
      responsibleClinicianName: String(r['clinician_name']),
      status: r['status'] as Encounter['status'],
      presentingConcern: String(r['presenting_concern']),
      occurredAt: String(r['occurred_at']),
      documentedAt: String(r['documented_at']),
    };
  }

  createDraftNote(
    session: AuthSession,
    patientId: string,
    input: {
      encounterId: string | null;
      templateType: NoteTemplateType;
      title: string;
      sections: NoteSection[];
      freeText: string;
      copiedCitations?: ClinicalNote['copiedCitations'];
    }
  ): ClinicalNote {
    this.assertPatientAccess(session, patientId, 'note.create_draft', true);
    const id = `note-${randomUUID().slice(0, 8)}`;
    const ts = nowIso();
    const sectionsJson = JSON.stringify(input.sections);
    const citationsJson = JSON.stringify(input.copiedCitations ?? []);

    withTransaction(this.db, () => {
      this.db
        .prepare(
          `INSERT INTO clinical_notes (
            id, patient_id, encounter_id, template_type, title, status, sections_json,
            free_text, copied_citations_json, version, author_id, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, 'draft', ?, ?, ?, 1, ?, ?, ?)`
        )
        .run(
          id,
          patientId,
          input.encounterId,
          input.templateType,
          input.title,
          sectionsJson,
          input.freeText,
          citationsJson,
          session.clinician.id,
          ts,
          ts
        );

      this.db
        .prepare(
          `INSERT INTO note_revisions (
            id, note_id, version, action, sections_json, free_text, actor_id, reason, content_hash, created_at
          ) VALUES (?, ?, 1, 'draft_created', ?, ?, ?, NULL, ?, ?)`
        )
        .run(randomUUID(), id, sectionsJson, input.freeText, session.clinician.id, sha256Hex(sectionsJson + input.freeText), ts);

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'note.draft_created',
        resourceType: 'ClinicalNote',
        resourceId: id,
        patientId,
        outcome: 'allow',
        reason: `Template: ${input.templateType}`,
        metadata: { version: 1 },
      });
    });

    return this.getNoteById(session, id);
  }

  saveDraftNote(
    session: AuthSession,
    noteId: string,
    input: {
      expectedVersion: number;
      title: string;
      sections: NoteSection[];
      freeText: string;
      copiedCitations?: ClinicalNote['copiedCitations'];
      forceConflictResolution?: boolean;
    }
  ): ClinicalNote {
    const existingRow = this.db.prepare('SELECT * FROM clinical_notes WHERE id = ?').get(noteId);
    if (!existingRow) {
      throw new ApiError(404, 'NOTE_NOT_FOUND', 'Clinical note not found');
    }
    const patientId = String(existingRow['patient_id']);
    this.assertPatientAccess(session, patientId, 'note.autosave_draft', true);

    if (existingRow['status'] !== 'draft') {
      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: nowIso(),
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'note.mutate_rejected_immutable',
        resourceType: 'ClinicalNote',
        resourceId: noteId,
        patientId,
        outcome: 'deny',
        reason: `Cannot edit note in status ${String(existingRow['status'])}`,
        metadata: {},
      });
      throw new ApiError(
        409,
        'IMMUTABLE_SIGNED_NOTE',
        `Clinical note is ${String(existingRow['status'])} and cannot be directly modified. Use Linked Amendment instead.`
      );
    }

    const currentVersion = Number(existingRow['version']);
    if (input.expectedVersion !== currentVersion && !input.forceConflictResolution) {
      const serverNote = this.getNoteById(session, noteId);
      throw new ApiError(
        409,
        'DRAFT_VERSION_CONFLICT',
        `Concurrent edit conflict: your draft was based on v${input.expectedVersion}, but server is at v${currentVersion}.`,
        { serverNote }
      );
    }

    const newVersion = currentVersion + 1;
    const ts = nowIso();
    const sectionsJson = JSON.stringify(input.sections);
    const citationsJson = JSON.stringify(
      input.copiedCitations ?? JSON.parse(String(existingRow['copied_citations_json']))
    );

    withTransaction(this.db, () => {
      const res = this.db
        .prepare(
          `UPDATE clinical_notes
           SET title = ?, sections_json = ?, free_text = ?, copied_citations_json = ?,
               version = ?, updated_at = ?
           WHERE id = ? AND version = ? AND status = 'draft'`
        )
        .run(
          input.title,
          sectionsJson,
          input.freeText,
          citationsJson,
          newVersion,
          ts,
          noteId,
          currentVersion
        );

      if (Number(res.changes) === 0) {
        throw new ApiError(409, 'DRAFT_VERSION_CONFLICT', 'Concurrent update detected during transaction');
      }

      this.db
        .prepare(
          `INSERT INTO note_revisions (
            id, note_id, version, action, sections_json, free_text, actor_id, reason, content_hash, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          randomUUID(),
          noteId,
          newVersion,
          input.forceConflictResolution ? 'conflict_resolved' : 'autosave',
          sectionsJson,
          input.freeText,
          session.clinician.id,
          input.forceConflictResolution ? `Resolved conflict from client v${input.expectedVersion}` : null,
          sha256Hex(sectionsJson + input.freeText),
          ts
        );

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: input.forceConflictResolution ? 'note.conflict_resolved' : 'note.draft_saved',
        resourceType: 'ClinicalNote',
        resourceId: noteId,
        patientId,
        outcome: 'allow',
        reason: null,
        metadata: { version: newVersion },
      });
    });

    return this.getNoteById(session, noteId);
  }

  signNote(
    session: AuthSession,
    noteId: string,
    input: {
      expectedVersion: number;
      patientConfirmed: boolean;
      idempotencyKey: string;
    }
  ): ClinicalNote {
    if (!['Consultant', 'Registrar', 'ClinicalNurse', 'Pharmacist'].includes(session.clinician.role)) {
      throw new ApiError(403, 'PERMISSION_DENIED', 'Role is not authorised to clinically sign notes');
    }
    if (!input.patientConfirmed) {
      throw new ApiError(400, 'PATIENT_CONFIRMATION_REQUIRED', 'Clinician must explicitly confirm patient identity before signing');
    }
    if (!input.idempotencyKey) {
      throw new ApiError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'Idempotency key required for atomic signing');
    }

    const existingRow = this.db.prepare('SELECT * FROM clinical_notes WHERE id = ?').get(noteId);
    if (!existingRow) {
      throw new ApiError(404, 'NOTE_NOT_FOUND', 'Clinical note not found');
    }
    const patientId = String(existingRow['patient_id']);
    this.assertPatientAccess(session, patientId, 'note.sign', true);

    // Idempotent retry check: if already signed with same idempotencyKey, return without duplicate signature!
    if (
      existingRow['idempotency_key'] === input.idempotencyKey &&
      (existingRow['status'] === 'signed' || existingRow['status'] === 'amended')
    ) {
      return this.getNoteById(session, noteId);
    }

    if (existingRow['status'] !== 'draft') {
      throw new ApiError(409, 'ALREADY_SIGNED', 'Note has already been signed or marked entered-in-error');
    }

    const currentVersion = Number(existingRow['version']);
    if (input.expectedVersion !== currentVersion) {
      throw new ApiError(
        409,
        'SIGN_VERSION_MISMATCH',
        `Cannot sign stale version v${input.expectedVersion}; server is at v${currentVersion}. Refresh preview first.`,
        { serverNote: this.getNoteById(session, noteId) }
      );
    }

    const ts = nowIso();
    const newVersion = currentVersion + 1;
    const attestationStatement = `Clinical Attestation: ${session.clinician.displayName} (${session.clinician.gmcOrNmcNumber}) confirmed patient identity and attested to the clinical accuracy of this record at ${ts}.`;
    const sigPayload = `${noteId}|v${newVersion}|${session.clinician.id}|${String(existingRow['sections_json'])}|${String(existingRow['free_text'])}|${ts}`;
    const cryptoSig = signAttestationPayload(sigPayload);

    withTransaction(this.db, () => {
      const res = this.db
        .prepare(
          `UPDATE clinical_notes
           SET status = 'signed', version = ?, signed_by = ?, signed_at = ?,
               attestation_statement = ?, cryptographic_signature_hex = ?,
               idempotency_key = ?, updated_at = ?
           WHERE id = ? AND version = ? AND status = 'draft'`
        )
        .run(
          newVersion,
          session.clinician.id,
          ts,
          attestationStatement,
          cryptoSig,
          input.idempotencyKey,
          ts,
          noteId,
          currentVersion
        );

      if (Number(res.changes) === 0) {
        throw new ApiError(409, 'SIGN_CONFLICT', 'Concurrent modification prevented signing');
      }

      this.db
        .prepare(
          `INSERT INTO note_revisions (
            id, note_id, version, action, sections_json, free_text, actor_id, reason, content_hash, created_at
          ) VALUES (?, ?, ?, 'signed', ?, ?, ?, 'Atomic clinical attestation & sign-off', ?, ?)`
        )
        .run(
          randomUUID(),
          noteId,
          newVersion,
          String(existingRow['sections_json']),
          String(existingRow['free_text']),
          session.clinician.id,
          sha256Hex(String(existingRow['sections_json']) + String(existingRow['free_text'])),
          ts
        );

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'note.signed',
        resourceType: 'ClinicalNote',
        resourceId: noteId,
        patientId,
        outcome: 'allow',
        reason: 'Atomic clinical attestation completed',
        metadata: { version: newVersion, signaturePrefix: cryptoSig.slice(0, 16) },
      });

      this.enqueueOutboxEvent(
        'ClinicalNote',
        noteId,
        'fhir.document_reference.signed',
        { noteId, patientId, signedBy: session.clinician.id, signedAt: ts }
      );
    });

    return this.getNoteById(session, noteId);
  }

  addNoteAmendment(
    session: AuthSession,
    noteId: string,
    input: { addendumText: string; reason: string }
  ): ClinicalNote {
    if (!input.addendumText.trim() || !input.reason.trim()) {
      throw new ApiError(400, 'INVALID_AMENDMENT', 'Amendment requires both addendum text and clinical reason');
    }
    const existingRow = this.db.prepare('SELECT * FROM clinical_notes WHERE id = ?').get(noteId);
    if (!existingRow) throw new ApiError(404, 'NOTE_NOT_FOUND', 'Clinical note not found');
    const patientId = String(existingRow['patient_id']);
    this.assertPatientAccess(session, patientId, 'note.add_amendment', true);

    if (existingRow['status'] !== 'signed' && existingRow['status'] !== 'amended') {
      throw new ApiError(409, 'NOTE_NOT_SIGNED', 'Amendments can only be linked to signed notes');
    }

    const ts = nowIso();
    const amendmentId = `amend-${randomUUID().slice(0, 8)}`;
    const newVersion = Number(existingRow['version']) + 1;
    const attestation = `Addendum Attestation: ${session.clinician.displayName} (${session.clinician.gmcOrNmcNumber}) added linked addendum at ${ts}.`;
    const sig = signAttestationPayload(`${amendmentId}|${noteId}|${input.addendumText}|${input.reason}|${ts}`);

    withTransaction(this.db, () => {
      this.db
        .prepare(
          `INSERT INTO note_amendments (
            id, note_id, addendum_text, reason, author_id, attestation_statement, cryptographic_signature_hex, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(amendmentId, noteId, input.addendumText.trim(), input.reason.trim(), session.clinician.id, attestation, sig, ts);

      this.db
        .prepare(`UPDATE clinical_notes SET status = 'amended', version = ?, updated_at = ? WHERE id = ?`)
        .run(newVersion, ts, noteId);

      this.db
        .prepare(
          `INSERT INTO note_revisions (
            id, note_id, version, action, sections_json, free_text, actor_id, reason, content_hash, created_at
          ) VALUES (?, ?, ?, 'amended', ?, ?, ?, ?, ?, ?)`
        )
        .run(
          randomUUID(),
          noteId,
          newVersion,
          String(existingRow['sections_json']),
          String(existingRow['free_text']),
          session.clinician.id,
          `Linked addendum (${amendmentId}): ${input.reason.trim()}`,
          sha256Hex(input.addendumText.trim()),
          ts
        );

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'note.amended',
        resourceType: 'ClinicalNote',
        resourceId: noteId,
        patientId,
        outcome: 'allow',
        reason: input.reason.trim(),
        metadata: { amendmentId, version: newVersion },
      });
    });

    return this.getNoteById(session, noteId);
  }

  markNoteEnteredInError(session: AuthSession, noteId: string, reason: string): ClinicalNote {
    if (!['Consultant', 'IGLead'].includes(session.clinician.role)) {
      throw new ApiError(403, 'PERMISSION_DENIED', 'Only a Consultant or IG Lead may mark a note entered-in-error');
    }
    if (!reason || reason.trim().length < 8) {
      throw new ApiError(400, 'INVALID_REASON', 'Entered-in-error workflow requires a detailed reason');
    }
    const existingRow = this.db.prepare('SELECT * FROM clinical_notes WHERE id = ?').get(noteId);
    if (!existingRow) throw new ApiError(404, 'NOTE_NOT_FOUND', 'Clinical note not found');
    const patientId = String(existingRow['patient_id']);
    this.assertPatientAccess(session, patientId, 'note.entered_in_error', false);

    const ts = nowIso();
    const newVersion = Number(existingRow['version']) + 1;
    withTransaction(this.db, () => {
      this.db
        .prepare(
          `UPDATE clinical_notes
           SET status = 'entered_in_error', version = ?, entered_in_error_reason = ?,
               entered_in_error_by = ?, entered_in_error_at = ?, updated_at = ?
           WHERE id = ?`
        )
        .run(newVersion, reason.trim(), session.clinician.id, ts, ts, noteId);

      this.db
        .prepare(
          `INSERT INTO note_revisions (
            id, note_id, version, action, sections_json, free_text, actor_id, reason, content_hash, created_at
          ) VALUES (?, ?, ?, 'entered_in_error', ?, ?, ?, ?, ?, ?)`
        )
        .run(
          randomUUID(),
          noteId,
          newVersion,
          String(existingRow['sections_json']),
          String(existingRow['free_text']),
          session.clinician.id,
          reason.trim(),
          sha256Hex(reason.trim()),
          ts
        );

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'note.entered_in_error',
        resourceType: 'ClinicalNote',
        resourceId: noteId,
        patientId,
        outcome: 'allow',
        reason: reason.trim(),
        metadata: { version: newVersion, originalPreserved: true },
      });
    });

    return this.getNoteById(session, noteId);
  }

  getNoteById(session: AuthSession, noteId: string): ClinicalNote {
    const row = this.db
      .prepare(
        `SELECT n.*, a.display_name AS author_name, s.display_name AS signed_by_name
         FROM clinical_notes n
         JOIN clinicians a ON a.id = n.author_id
         LEFT JOIN clinicians s ON s.id = n.signed_by
         WHERE n.id = ?`
      )
      .get(noteId);
    if (!row) throw new ApiError(404, 'NOTE_NOT_FOUND', 'Clinical note not found');
    this.assertPatientAccess(session, String(row['patient_id']), 'note.view');
    return this.hydrateNote(row);
  }

  private hydrateNote(r: Record<string, unknown>): ClinicalNote {
    const noteId = String(r['id']);
    const amendments: NoteAmendment[] = this.db
      .prepare(
        `SELECT am.*, c.display_name AS author_name
         FROM note_amendments am
         JOIN clinicians c ON c.id = am.author_id
         WHERE am.note_id = ?
         ORDER BY am.created_at ASC`
      )
      .all(noteId)
      .map((a) => ({
        id: String(a['id']),
        noteId: String(a['note_id']),
        addendumText: String(a['addendum_text']),
        reason: String(a['reason']),
        authorId: String(a['author_id']),
        authorName: String(a['author_name']),
        attestationStatement: String(a['attestation_statement']),
        cryptographicSignatureHex: String(a['cryptographic_signature_hex']),
        createdAt: String(a['created_at']),
      }));

    const revisions: NoteRevision[] = this.db
      .prepare(
        `SELECT rv.*, c.display_name AS actor_name
         FROM note_revisions rv
         JOIN clinicians c ON c.id = rv.actor_id
         WHERE rv.note_id = ?
         ORDER BY rv.version DESC`
      )
      .all(noteId)
      .map((rv) => ({
        id: String(rv['id']),
        noteId: String(rv['note_id']),
        version: Number(rv['version']),
        action: rv['action'] as NoteRevision['action'],
        sections: JSON.parse(String(rv['sections_json'])),
        freeText: String(rv['free_text']),
        actorId: String(rv['actor_id']),
        actorName: String(rv['actor_name']),
        reason: rv['reason'] ? String(rv['reason']) : null,
        contentHash: String(rv['content_hash']),
        createdAt: String(rv['created_at']),
      }));

    return {
      id: noteId,
      patientId: String(r['patient_id']),
      encounterId: r['encounter_id'] ? String(r['encounter_id']) : null,
      templateType: r['template_type'] as NoteTemplateType,
      title: String(r['title']),
      status: r['status'] as ClinicalNote['status'],
      sections: JSON.parse(String(r['sections_json'])),
      freeText: String(r['free_text']),
      copiedCitations: JSON.parse(String(r['copied_citations_json'])),
      version: Number(r['version']),
      authorId: String(r['author_id']),
      authorName: String(r['author_name']),
      signedBy: r['signed_by'] ? String(r['signed_by']) : null,
      signedByName: r['signed_by_name'] ? String(r['signed_by_name']) : null,
      signedAt: r['signed_at'] ? String(r['signed_at']) : null,
      attestationStatement: r['attestation_statement'] ? String(r['attestation_statement']) : null,
      cryptographicSignatureHex: r['cryptographic_signature_hex']
        ? String(r['cryptographic_signature_hex'])
        : null,
      enteredInErrorReason: r['entered_in_error_reason'] ? String(r['entered_in_error_reason']) : null,
      enteredInErrorBy: r['entered_in_error_by'] ? String(r['entered_in_error_by']) : null,
      enteredInErrorAt: r['entered_in_error_at'] ? String(r['entered_in_error_at']) : null,
      idempotencyKey: r['idempotency_key'] ? String(r['idempotency_key']) : null,
      createdAt: String(r['created_at']),
      updatedAt: String(r['updated_at']),
      amendments,
      revisions,
    };
  }

  recordObservation(
    session: AuthSession,
    patientId: string,
    input: {
      encounterId: string | null;
      code: string;
      terminologySystem: string;
      display: string;
      valueNum: number | null;
      valueText: string;
      unit: string;
      referenceLow: number | null;
      referenceHigh: number | null;
      interpretation: Observation['interpretation'];
      observedAt: string;
      recordingSource: string;
      verificationStatus: Observation['verificationStatus'];
    }
  ): Observation {
    this.assertPatientAccess(session, patientId, 'observation.record', true);
    const id = `obs-${randomUUID().slice(0, 8)}`;
    const documentedAt = nowIso();
    this.db
      .prepare(
        `INSERT INTO observations (
          id, patient_id, encounter_id, code, terminology_system, display, value_num, value_text,
          unit, reference_low, reference_high, interpretation, observed_at, documented_at,
          recording_source, attribution, verification_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        id,
        patientId,
        input.encounterId,
        input.code,
        input.terminologySystem,
        input.display,
        input.valueNum,
        input.valueText,
        input.unit,
        input.referenceLow,
        input.referenceHigh,
        input.interpretation,
        input.observedAt,
        documentedAt,
        input.recordingSource,
        session.clinician.displayName,
        input.verificationStatus
      );

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: documentedAt,
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'observation.recorded',
      resourceType: 'Observation',
      resourceId: id,
      patientId,
      outcome: 'allow',
      reason: null,
      metadata: { code: input.code },
    });

    const row = this.db.prepare('SELECT * FROM observations WHERE id = ?').get(id)!;
    return {
      id: String(row['id']),
      patientId: String(row['patient_id']),
      encounterId: row['encounter_id'] ? String(row['encounter_id']) : null,
      code: String(row['code']),
      terminologySystem: String(row['terminology_system']),
      display: String(row['display']),
      valueNum: row['value_num'] !== null ? Number(row['value_num']) : null,
      valueText: String(row['value_text']),
      unit: String(row['unit']),
      referenceLow: row['reference_low'] !== null ? Number(row['reference_low']) : null,
      referenceHigh: row['reference_high'] !== null ? Number(row['reference_high']) : null,
      interpretation: row['interpretation'] as Observation['interpretation'],
      observedAt: String(row['observed_at']),
      documentedAt: String(row['documented_at']),
      recordingSource: String(row['recording_source']),
      attribution: String(row['attribution']),
      verificationStatus: row['verification_status'] as Observation['verificationStatus'],
    };
  }

  transitionResultState(
    session: AuthSession,
    resultId: string,
    nextState: ResultReviewState,
    followUpTitle?: string
  ): DiagnosticResult {
    const row = this.db.prepare('SELECT * FROM diagnostic_results WHERE id = ?').get(resultId);
    if (!row) throw new ApiError(404, 'RESULT_NOT_FOUND', 'Diagnostic result not found');
    const patientId = String(row['patient_id']);
    this.assertPatientAccess(session, patientId, `result.${nextState}`, nextState !== 'viewed');

    const ts = nowIso();
    let followUpTaskId = row['follow_up_task_id'] ? String(row['follow_up_task_id']) : null;

    withTransaction(this.db, () => {
      if (nextState === 'viewed') {
        this.db
          .prepare(
            `UPDATE diagnostic_results
             SET review_state = CASE WHEN review_state = 'available' THEN 'viewed' ELSE review_state END,
                 viewed_by = COALESCE(viewed_by, ?), viewed_at = COALESCE(viewed_at, ?)
             WHERE id = ?`
          )
          .run(session.clinician.id, ts, resultId);
      } else if (nextState === 'acknowledged') {
        this.db
          .prepare(
            `UPDATE diagnostic_results
             SET review_state = 'acknowledged',
                 viewed_by = COALESCE(viewed_by, ?), viewed_at = COALESCE(viewed_at, ?),
                 acknowledged_by = ?, acknowledged_at = ?
             WHERE id = ?`
          )
          .run(session.clinician.id, ts, session.clinician.id, ts, resultId);
      } else if (nextState === 'follow_up_assigned') {
        followUpTaskId = `task-${randomUUID().slice(0, 8)}`;
        this.db
          .prepare(
            `INSERT INTO tasks (
              id, patient_id, encounter_id, task_type, title, description, owner_id, assigned_team,
              priority, status, due_at, created_by, created_at
            ) VALUES (?, ?, ?, 'results_review', ?, ?, ?, ?, 'urgent', 'created', ?, ?, ?)`
          )
          .run(
            followUpTaskId,
            patientId,
            row['encounter_id'] ? String(row['encounter_id']) : null,
            followUpTitle || `Follow-up for ${String(row['order_name'])}: ${String(row['value_text'])} ${String(row['unit'])}`,
            `Assigned from diagnostic result ${resultId} (${String(row['result_status'])}).`,
            session.clinician.id,
            session.clinician.specialty,
            new Date(Date.now() + 24 * 3600_000).toISOString(),
            session.clinician.id,
            ts
          );
        this.db
          .prepare(
            `UPDATE diagnostic_results
             SET review_state = 'follow_up_assigned', follow_up_task_id = ?,
                 acknowledged_by = COALESCE(acknowledged_by, ?), acknowledged_at = COALESCE(acknowledged_at, ?)
             WHERE id = ?`
          )
          .run(followUpTaskId, session.clinician.id, ts, resultId);
      } else if (nextState === 'follow_up_completed') {
        this.db
          .prepare(`UPDATE diagnostic_results SET review_state = 'follow_up_completed' WHERE id = ?`)
          .run(resultId);
        if (followUpTaskId) {
          this.db
            .prepare(
              `UPDATE tasks SET status = 'completed', completed_by = ?, completed_at = ?,
               completion_evidence = COALESCE(completion_evidence, 'Marked complete via Diagnostic Result workflow')
               WHERE id = ?`
            )
            .run(session.clinician.id, ts, followUpTaskId);
        }
      }

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: `result.${nextState}`,
        resourceType: 'DiagnosticResult',
        resourceId: resultId,
        patientId,
        outcome: 'allow',
        reason: null,
        metadata: { followUpTaskId },
      });
    });

    const updated = this.db.prepare('SELECT * FROM diagnostic_results WHERE id = ?').get(resultId)!;
    return this.mapResultRow(updated);
  }

  simulateCorrectedResult(
    session: AuthSession,
    supersedesResultId: string,
    newValueText: string,
    abnormalFlag: DiagnosticResult['abnormalFlag'],
    correctionReason: string
  ): DiagnosticResult {
    const orig = this.db.prepare('SELECT * FROM diagnostic_results WHERE id = ?').get(supersedesResultId);
    if (!orig) throw new ApiError(404, 'RESULT_NOT_FOUND', 'Original result to correct not found');
    const patientId = String(orig['patient_id']);
    this.assertPatientAccess(session, patientId, 'result.ingest_correction', true);

    const newId = `res-${randomUUID().slice(0, 8)}`;
    const ts = nowIso();

    withTransaction(this.db, () => {
      this.db
        .prepare(
          `INSERT INTO diagnostic_results (
            id, patient_id, encounter_id, request_id, order_name, code, terminology_system,
            value_text, unit, reference_interval, abnormal_flag, result_status, review_state,
            supersedes_result_id, correction_reason, observed_at, reported_at, performing_lab
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'corrected', 'available', ?, ?, ?, ?, ?)`
        )
        .run(
          newId,
          patientId,
          orig['encounter_id'],
          orig['request_id'],
          `${String(orig['order_name']).replace(' (CORRECTED)', '')} (CORRECTED)`,
          orig['code'],
          orig['terminology_system'],
          newValueText,
          orig['unit'],
          orig['reference_interval'],
          abnormalFlag,
          supersedesResultId,
          correctionReason,
          orig['observed_at'],
          ts,
          orig['performing_lab']
        );

      // Automatically trigger review workflow task
      const taskId = `task-${randomUUID().slice(0, 8)}`;
      this.db
        .prepare(
          `INSERT INTO tasks (
            id, patient_id, encounter_id, task_type, title, description, owner_id, assigned_team,
            priority, status, due_at, created_by, created_at
          ) VALUES (?, ?, ?, 'results_review', ?, ?, ?, ?, 'stat', 'delivered', ?, ?, ?)`
        )
        .run(
          taskId,
          patientId,
          orig['encounter_id'],
          `Review Corrected Result: ${String(orig['order_name'])} (${newValueText} ${String(orig['unit'])})`,
          `Supersedes ${supersedesResultId}. Reason: ${correctionReason}`,
          session.clinician.id,
          session.clinician.specialty,
          new Date(Date.now() + 2 * 3600_000).toISOString(),
          session.clinician.id,
          ts
        );

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'result.correction_received',
        resourceType: 'DiagnosticResult',
        resourceId: newId,
        patientId,
        outcome: 'allow',
        reason: correctionReason,
        metadata: { supersedesResultId, triggeredTaskId: taskId },
      });

      this.enqueueOutboxEvent('DiagnosticResult', newId, 'fhir.diagnostic_report.corrected', {
        newId,
        supersedesResultId,
        patientId,
      });
    });

    return this.mapResultRow(this.db.prepare('SELECT * FROM diagnostic_results WHERE id = ?').get(newId)!);
  }

  addMedicationEntry(
    session: AuthSession,
    patientId: string,
    input: {
      encounterId: string | null;
      conceptType: MedicationConceptType;
      drugName: string;
      dmdCode: string;
      strength: string;
      dose: string;
      route: string;
      frequency: string;
      source: string;
      requestSimulatedPrescription?: boolean;
    }
  ): { medication: MedicationEntry; simulationNotice: string | null } {
    this.assertPatientAccess(session, patientId, 'medication.record', true);
    const id = `med-${randomUUID().slice(0, 8)}`;
    const ts = nowIso();
    let simulationNotice: string | null = null;

    withTransaction(this.db, () => {
      this.db
        .prepare(
          `INSERT INTO medications (
            id, patient_id, encounter_id, concept_type, drug_name, dmd_code, strength,
            dose, route, frequency, start_date, status, source, reconciliation_status,
            author_id, documented_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, 'verified', ?, ?)`
        )
        .run(
          id,
          patientId,
          input.encounterId,
          input.conceptType,
          input.drugName,
          input.dmdCode || 'dm+d-unmapped',
          input.strength,
          input.dose,
          input.route,
          input.frequency,
          ts.slice(0, 10),
          input.source,
          session.clinician.id,
          ts
        );

      if (input.requestSimulatedPrescription) {
        this.enqueueOutboxEvent('MedicationRequest', id, 'eps.simulated_prescription_request', {
          medicationId: id,
          patientId,
          drugName: input.drugName,
          dose: input.dose,
          simulatedOnly: true,
        });
        simulationNotice =
          'Simulated prescription request queued to integration outbox (Prototype only — not connected to live NHS EPS).';
      }

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: input.requestSimulatedPrescription ? 'medication.simulated_prescription' : 'medication.recorded',
        resourceType: 'MedicationEntry',
        resourceId: id,
        patientId,
        outcome: 'allow',
        reason: null,
        metadata: { conceptType: input.conceptType, drugName: input.drugName },
      });
    });

    const r = this.db
      .prepare(
        `SELECT m.*, c.display_name AS author_name FROM medications m JOIN clinicians c ON c.id = m.author_id WHERE m.id = ?`
      )
      .get(id)!;

    return {
      medication: {
        id: String(r['id']),
        patientId: String(r['patient_id']),
        encounterId: r['encounter_id'] ? String(r['encounter_id']) : null,
        conceptType: r['concept_type'] as MedicationConceptType,
        drugName: String(r['drug_name']),
        dmdCode: String(r['dmd_code']),
        strength: String(r['strength']),
        dose: String(r['dose']),
        route: String(r['route']),
        frequency: String(r['frequency']),
        startDate: String(r['start_date']),
        endDate: r['end_date'] ? String(r['end_date']) : null,
        status: r['status'] as MedicationEntry['status'],
        source: String(r['source']),
        reconciliationStatus: r['reconciliation_status'] as MedicationEntry['reconciliationStatus'],
        conflictGroupId: r['conflict_group_id'] ? String(r['conflict_group_id']) : null,
        authorId: String(r['author_id']),
        authorName: String(r['author_name']),
        documentedAt: String(r['documented_at']),
      },
      simulationNotice,
    };
  }

  setAllergyAssertion(
    session: AuthSession,
    patientId: string,
    status: AllergyAssertionStatus,
    newAllergy?: {
      substance: string;
      code: string;
      reaction: string;
      severity: Allergy['severity'];
      verificationStatus: Allergy['verificationStatus'];
      provenance: string;
    }
  ): { allergyAssertionStatus: AllergyAssertionStatus; allergies: Allergy[] } {
    this.assertPatientAccess(session, patientId, 'allergy.update', true);
    const ts = nowIso();

    withTransaction(this.db, () => {
      this.db
        .prepare('UPDATE patients SET allergy_assertion_status = ?, updated_at = ? WHERE id = ?')
        .run(status, ts, patientId);

      if (newAllergy && status === 'assessed_with_allergies') {
        this.db
          .prepare(
            `INSERT INTO allergies (
              id, patient_id, substance, code, reaction, severity, verification_status,
              clinical_status, provenance, recorded_at, author_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?)`
          )
          .run(
            `alg-${randomUUID().slice(0, 8)}`,
            patientId,
            newAllergy.substance,
            newAllergy.code || 'SNOMED-unmapped',
            newAllergy.reaction,
            newAllergy.severity,
            newAllergy.verificationStatus,
            newAllergy.provenance,
            ts,
            session.clinician.id
          );
      }

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: 'allergy.assertion_updated',
        resourceType: 'Patient',
        resourceId: patientId,
        patientId,
        outcome: 'allow',
        reason: `Assertion status set to ${status}`,
        metadata: { status },
      });
    });

    const allergies: Allergy[] = this.db
      .prepare(
        `SELECT a.*, c.display_name AS author_name FROM allergies a JOIN clinicians c ON c.id = a.author_id WHERE a.patient_id = ?`
      )
      .all(patientId)
      .map((r) => ({
        id: String(r['id']),
        patientId: String(r['patient_id']),
        substance: String(r['substance']),
        code: String(r['code']),
        reaction: String(r['reaction']),
        severity: r['severity'] as Allergy['severity'],
        verificationStatus: r['verification_status'] as Allergy['verificationStatus'],
        clinicalStatus: r['clinical_status'] as Allergy['clinicalStatus'],
        provenance: String(r['provenance']),
        recordedAt: String(r['recorded_at']),
        authorId: String(r['author_id']),
        authorName: String(r['author_name']),
      }));

    return { allergyAssertionStatus: status, allergies };
  }

  createTask(
    session: AuthSession,
    patientId: string,
    input: {
      encounterId: string | null;
      taskType: TaskType;
      title: string;
      description: string;
      assignedTeam: string;
      priority: ClinicalTask['priority'];
      dueAt: string;
      patientSummaryText?: string;
    }
  ): ClinicalTask {
    this.assertPatientAccess(session, patientId, 'task.create', true);
    const id = `task-${randomUUID().slice(0, 8)}`;
    const ts = nowIso();
    this.db
      .prepare(
        `INSERT INTO tasks (
          id, patient_id, encounter_id, task_type, title, description, owner_id, assigned_team,
          priority, status, due_at, created_by, patient_summary_text, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'created', ?, ?, ?, ?)`
      )
      .run(
        id,
        patientId,
        input.encounterId,
        input.taskType,
        input.title,
        input.description,
        session.clinician.id,
        input.assignedTeam,
        input.priority,
        input.dueAt,
        session.clinician.id,
        input.patientSummaryText ?? null,
        ts
      );

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: ts,
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'task.created',
      resourceType: 'ClinicalTask',
      resourceId: id,
      patientId,
      outcome: 'allow',
      reason: null,
      metadata: { taskType: input.taskType, priority: input.priority },
    });

    const row = this.db
      .prepare('SELECT t.*, c.display_name AS owner_name FROM tasks t JOIN clinicians c ON c.id = t.owner_id WHERE t.id = ?')
      .get(id)!;
    return this.mapTaskRow(row);
  }

  transitionTask(
    session: AuthSession,
    taskId: string,
    nextStatus: TaskStatus,
    completionEvidence?: string,
    approvePatientSummary?: string
  ): ClinicalTask {
    const row = this.db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!row) throw new ApiError(404, 'TASK_NOT_FOUND', 'Task not found');
    const patientId = String(row['patient_id']);
    this.assertPatientAccess(session, patientId, `task.${nextStatus}`, true);

    if (nextStatus === 'completed' && !completionEvidence?.trim() && !approvePatientSummary) {
      throw new ApiError(400, 'COMPLETION_EVIDENCE_REQUIRED', 'Completing a clinical task requires completion evidence');
    }

    const ts = nowIso();
    withTransaction(this.db, () => {
      if (approvePatientSummary !== undefined) {
        this.db
          .prepare(
            `UPDATE tasks
             SET patient_summary_text = ?, patient_summary_approved_by = ?, patient_summary_approved_at = ?
             WHERE id = ?`
          )
          .run(approvePatientSummary, session.clinician.id, ts, taskId);
      }

      if (nextStatus === 'accepted') {
        this.db
          .prepare(`UPDATE tasks SET status = 'accepted', accepted_by = ?, accepted_at = ? WHERE id = ?`)
          .run(session.clinician.id, ts, taskId);
      } else if (nextStatus === 'completed') {
        this.db
          .prepare(
            `UPDATE tasks SET status = 'completed', completed_by = ?, completed_at = ?, completion_evidence = ? WHERE id = ?`
          )
          .run(
            session.clinician.id,
            ts,
            completionEvidence?.trim() || 'Patient summary reviewed and approved for release',
            taskId
          );
      } else {
        this.db.prepare('UPDATE tasks SET status = ? WHERE id = ?').run(nextStatus, taskId);
      }

      appendAuditEvent(this.db, {
        id: randomUUID(),
        eventTime: ts,
        actorId: session.clinician.id,
        actorName: session.clinician.displayName,
        actorRole: session.clinician.role,
        organisationId: session.clinician.organisationId,
        action: `task.${nextStatus}`,
        resourceType: 'ClinicalTask',
        resourceId: taskId,
        patientId,
        outcome: 'allow',
        reason: completionEvidence ?? null,
        metadata: { approvedSummary: Boolean(approvePatientSummary) },
      });
    });

    const updated = this.db
      .prepare('SELECT t.*, c.display_name AS owner_name FROM tasks t JOIN clinicians c ON c.id = t.owner_id WHERE t.id = ?')
      .get(taskId)!;
    return this.mapTaskRow(updated);
  }

  getAttachmentContent(
    session: AuthSession,
    attachmentId: string
  ): { attachment: ClinicalAttachment; contentText: string } {
    const row = this.db
      .prepare(
        `SELECT att.*, c.display_name AS uploaded_by_name
         FROM attachments att JOIN clinicians c ON c.id = att.uploaded_by
         WHERE att.id = ?`
      )
      .get(attachmentId);
    if (!row) throw new ApiError(404, 'ATTACHMENT_NOT_FOUND', 'Protected attachment not found');
    const patientId = String(row['patient_id']);
    this.assertPatientAccess(session, patientId, 'attachment.download');

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: nowIso(),
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'attachment.downloaded',
      resourceType: 'ClinicalAttachment',
      resourceId: attachmentId,
      patientId,
      outcome: 'allow',
      reason: 'Authorised clinical attachment access',
      metadata: { filename: String(row['filename']), sha256: String(row['sha256_hex']) },
    });

    return {
      attachment: {
        id: String(row['id']),
        patientId,
        encounterId: row['encounter_id'] ? String(row['encounter_id']) : null,
        filename: String(row['filename']),
        mimeType: String(row['mime_type']),
        sizeBytes: Number(row['size_bytes']),
        sha256Hex: String(row['sha256_hex']),
        classification: row['classification'] as ClinicalAttachment['classification'],
        uploadedBy: String(row['uploaded_by']),
        uploadedByName: String(row['uploaded_by_name']),
        uploadedAt: String(row['uploaded_at']),
      },
      contentText: String(row['content_text']),
    };
  }

  listAuditEvents(session: AuthSession, patientId?: string): { events: AuditEvent[]; chainVerified: boolean; verifiedCount: number; brokenAtSeqId: number | null } {
    const rows = patientId
      ? this.db
          .prepare('SELECT * FROM audit_events WHERE patient_id = ? ORDER BY seq_id DESC LIMIT 200')
          .all(patientId)
      : this.db.prepare('SELECT * FROM audit_events ORDER BY seq_id DESC LIMIT 200').all();

    // Verify full chain integrity sequentially
    const allOrdered = this.db.prepare('SELECT * FROM audit_events ORDER BY seq_id ASC').all();
    let expectedPrev = '0'.repeat(64);
    let chainVerified = true;
    let brokenAtSeqId: number | null = null;

    for (const r of allOrdered) {
      const payload = [
        String(r['id']),
        String(r['event_time']),
        String(r['actor_id']),
        String(r['actor_role']),
        String(r['organisation_id']),
        String(r['action']),
        String(r['resource_type']),
        String(r['resource_id']),
        r['patient_id'] ? String(r['patient_id']) : '',
        String(r['outcome']),
        r['reason'] ? String(r['reason']) : '',
        String(r['metadata_json']),
        expectedPrev,
      ].join('|');
      const recomputed = sha256Hex(payload);
      if (String(r['prev_hash']) !== expectedPrev || String(r['event_hash']) !== recomputed) {
        chainVerified = false;
        brokenAtSeqId = Number(r['seq_id']);
        break;
      }
      expectedPrev = String(r['event_hash']);
    }

    const events: AuditEvent[] = rows.map((r) => ({
      seqId: Number(r['seq_id']),
      id: String(r['id']),
      eventTime: String(r['event_time']),
      actorId: String(r['actor_id']),
      actorName: String(r['actor_name']),
      actorRole: String(r['actor_role']),
      organisationId: String(r['organisation_id']),
      action: String(r['action']),
      resourceType: String(r['resource_type']),
      resourceId: String(r['resource_id']),
      patientId: r['patient_id'] ? String(r['patient_id']) : null,
      outcome: r['outcome'] as 'allow' | 'deny',
      reason: r['reason'] ? String(r['reason']) : null,
      metadata: JSON.parse(String(r['metadata_json'])),
      prevHash: String(r['prev_hash']),
      eventHash: String(r['event_hash']),
    }));

    return {
      events,
      chainVerified,
      verifiedCount: allOrdered.length,
      brokenAtSeqId,
    };
  }

  listOutboxEvents(): OutboxEvent[] {
    return this.db
      .prepare('SELECT * FROM outbox_events ORDER BY created_at DESC LIMIT 100')
      .all()
      .map((r) => ({
        id: String(r['id']),
        aggregateType: String(r['aggregate_type']),
        aggregateId: String(r['aggregate_id']),
        eventType: String(r['event_type']),
        payload: JSON.parse(String(r['payload_json'])),
        status: r['status'] as OutboxEvent['status'],
        attempts: Number(r['attempts']),
        nextRetryAt: r['next_retry_at'] ? String(r['next_retry_at']) : null,
        lastError: r['last_error'] ? String(r['last_error']) : null,
        createdAt: String(r['created_at']),
        deliveredAt: r['delivered_at'] ? String(r['delivered_at']) : null,
      }));
  }

  retryOutboxEvent(session: AuthSession, outboxId: string, simulateFailure = false): OutboxEvent {
    const row = this.db.prepare('SELECT * FROM outbox_events WHERE id = ?').get(outboxId);
    if (!row) throw new ApiError(404, 'OUTBOX_NOT_FOUND', 'Outbox event not found');
    const attempts = Number(row['attempts']) + 1;
    const ts = nowIso();

    if (simulateFailure) {
      const nextStatus = attempts >= 3 ? 'dead_letter' : 'failed';
      this.db
        .prepare(
          `UPDATE outbox_events SET status = ?, attempts = ?, last_error = ?, next_retry_at = ? WHERE id = ?`
        )
        .run(
          nextStatus,
          attempts,
          'Simulated upstream FHIR gateway 503 Service Unavailable',
          new Date(Date.now() + 60_000 * attempts).toISOString(),
          outboxId
        );
    } else {
      this.db
        .prepare(
          `UPDATE outbox_events SET status = 'delivered', attempts = ?, last_error = NULL, delivered_at = ? WHERE id = ?`
        )
        .run(attempts, ts, outboxId);
    }

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: ts,
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'outbox.retry_processed',
      resourceType: 'OutboxEvent',
      resourceId: outboxId,
      patientId: null,
      outcome: 'allow',
      reason: simulateFailure ? 'Simulated failure' : 'Delivered to mock FHIR endpoint',
      metadata: { attempts },
    });

    return this.listOutboxEvents().find((o) => o.id === outboxId)!;
  }

  getSettings(): Record<string, unknown> {
    const rows = this.db.prepare('SELECT * FROM system_settings').all();
    const out: Record<string, unknown> = {};
    for (const r of rows) {
      out[String(r['key'])] = JSON.parse(String(r['value_json']));
    }
    return out;
  }

  updateAiAdapterSetting(session: AuthSession, enabled: boolean): Record<string, unknown> {
    if (!['Admin', 'IGLead', 'Consultant'].includes(session.clinician.role)) {
      throw new ApiError(403, 'PERMISSION_DENIED', 'Insufficient permissions to change AI adapter policy');
    }
    const current = (this.getSettings()['ai_drafting_adapter'] as Record<string, unknown>) || {};
    const updated = {
      ...current,
      enabled,
      provider: enabled
        ? 'Optional Draft Assist Active (Requires Source Links & Clinician Review)'
        : 'Disabled by default (Clinician-Controlled Draft Assist)',
      allowAutoSign: false,
    };
    this.db
      .prepare('UPDATE system_settings SET value_json = ? WHERE key = ?')
      .run(JSON.stringify(updated), 'ai_drafting_adapter');

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: nowIso(),
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'admin.ai_adapter_toggled',
      resourceType: 'SystemSetting',
      resourceId: 'ai_drafting_adapter',
      patientId: null,
      outcome: 'allow',
      reason: `AI Draft Adapter set to enabled=${enabled}`,
      metadata: { enabled },
    });

    return this.getSettings();
  }

  buildFhirUkCoreBundle(session: AuthSession, patientId: string): Record<string, unknown> {
    const overview = this.getPatientOverview(session, patientId);
    const p = overview.patient;

    return {
      resourceType: 'Bundle',
      id: `aureom-ukcore-${p.id}`,
      type: 'collection',
      timestamp: nowIso(),
      meta: {
        profile: ['https://fhir.hl7.org.uk/StructureDefinition/UKCore-Bundle'],
        prototypeNotice: 'Independent Prototype Mock Interoperability Output — Not Live NHS Spine Data',
      },
      entry: [
        {
          fullUrl: `urn:uuid:${p.id}`,
          resource: {
            resourceType: 'Patient',
            id: p.id,
            meta: { profile: ['https://fhir.hl7.org.uk/StructureDefinition/UKCore-Patient'] },
            identifier: [
              ...(p.nhsNumber
                ? [
                    {
                      system: 'https://fhir.nhs.uk/Id/nhs-number',
                      value: p.nhsNumber.replace(/\s+/g, ''),
                      extension: [
                        {
                          url: 'https://fhir.hl7.org.uk/StructureDefinition/Extension-UKCore-NHSNumberVerificationStatus',
                          valueCodeableConcept: {
                            coding: [{ code: p.nhsVerificationStatus, display: p.nhsVerificationStatus }],
                          },
                        },
                      ],
                    },
                  ]
                : []),
              { system: 'urn:aureom:mrn', value: p.internalMrn },
            ],
            name: [{ family: p.familyName, given: p.givenNames.split(' ') }],
            birthDate: p.dob,
          },
        },
        ...overview.allergies.map((a) => ({
          fullUrl: `urn:uuid:${a.id}`,
          resource: {
            resourceType: 'AllergyIntolerance',
            id: a.id,
            meta: { profile: ['https://fhir.hl7.org.uk/StructureDefinition/UKCore-AllergyIntolerance'] },
            clinicalStatus: { coding: [{ code: a.clinicalStatus }] },
            verificationStatus: { coding: [{ code: a.verificationStatus }] },
            code: { coding: [{ system: 'http://snomed.info/sct', code: a.code, display: a.substance }] },
            reaction: [{ manifestation: [{ text: a.reaction }], severity: a.severity }],
          },
        })),
        ...overview.results.map((r) => ({
          fullUrl: `urn:uuid:${r.id}`,
          resource: {
            resourceType: 'DiagnosticReport',
            id: r.id,
            meta: { profile: ['https://fhir.hl7.org.uk/StructureDefinition/UKCore-DiagnosticReport'] },
            status: r.resultStatus === 'corrected' ? 'corrected' : r.resultStatus,
            code: { coding: [{ system: r.terminologySystem, code: r.code, display: r.orderName }] },
            effectiveDateTime: r.observedAt,
            issued: r.reportedAt,
            conclusion: `${r.valueText} ${r.unit} (Ref: ${r.referenceInterval})`,
          },
        })),
      ],
    };
  }

  exportBackupSnapshot(session: AuthSession): Record<string, unknown> {
    if (!['Admin', 'IGLead', 'Consultant'].includes(session.clinician.role)) {
      throw new ApiError(403, 'PERMISSION_DENIED', 'Insufficient role to export backup snapshot');
    }
    const ts = nowIso();
    const tables = [
      'organisations',
      'clinicians',
      'patients',
      'patient_identifiers',
      'encounters',
      'problems',
      'allergies',
      'medications',
      'observations',
      'diagnostic_results',
      'clinical_notes',
      'note_revisions',
      'note_amendments',
      'care_plans',
      'tasks',
      'outbox_events',
    ];
    const data: Record<string, unknown[]> = {};
    for (const t of tables) {
      data[t] = this.db.prepare(`SELECT * FROM ${t}`).all();
    }

    appendAuditEvent(this.db, {
      id: randomUUID(),
      eventTime: ts,
      actorId: session.clinician.id,
      actorName: session.clinician.displayName,
      actorRole: session.clinician.role,
      organisationId: session.clinician.organisationId,
      action: 'admin.backup_exported',
      resourceType: 'BackupSnapshot',
      resourceId: ts,
      patientId: null,
      outcome: 'allow',
      reason: 'Protected database backup snapshot exported',
      metadata: { tableCount: tables.length },
    });

    return {
      exportedAt: ts,
      schemaVersion: '1.0.0',
      checksumSha256: sha256Hex(JSON.stringify(data)),
      data,
    };
  }

  private enqueueOutboxEvent(
    aggregateType: string,
    aggregateId: string,
    eventType: string,
    payload: Record<string, unknown>
  ): void {
    this.db
      .prepare(
        `INSERT INTO outbox_events (
          id, aggregate_type, aggregate_id, event_type, payload_json, status, attempts, created_at
        ) VALUES (?, ?, ?, ?, ?, 'pending', 0, ?)`
      )
      .run(randomUUID(), aggregateType, aggregateId, eventType, JSON.stringify(payload), nowIso());
  }

  private mapResultRow(r: Record<string, unknown>): DiagnosticResult {
    return {
      id: String(r['id']),
      patientId: String(r['patient_id']),
      encounterId: r['encounter_id'] ? String(r['encounter_id']) : null,
      requestId: String(r['request_id']),
      orderName: String(r['order_name']),
      code: String(r['code']),
      terminologySystem: String(r['terminology_system']),
      valueText: String(r['value_text']),
      unit: String(r['unit']),
      referenceInterval: String(r['reference_interval']),
      abnormalFlag: r['abnormal_flag'] as DiagnosticResult['abnormalFlag'],
      resultStatus: r['result_status'] as DiagnosticResult['resultStatus'],
      reviewState: r['review_state'] as DiagnosticResult['reviewState'],
      supersedesResultId: r['supersedes_result_id'] ? String(r['supersedes_result_id']) : null,
      correctionReason: r['correction_reason'] ? String(r['correction_reason']) : null,
      observedAt: String(r['observed_at']),
      reportedAt: String(r['reported_at']),
      performingLab: String(r['performing_lab']),
      viewedBy: r['viewed_by'] ? String(r['viewed_by']) : null,
      viewedAt: r['viewed_at'] ? String(r['viewed_at']) : null,
      acknowledgedBy: r['acknowledged_by'] ? String(r['acknowledged_by']) : null,
      acknowledgedAt: r['acknowledged_at'] ? String(r['acknowledged_at']) : null,
      followUpTaskId: r['follow_up_task_id'] ? String(r['follow_up_task_id']) : null,
    };
  }

  private mapTaskRow(t: Record<string, unknown>): ClinicalTask {
    return {
      id: String(t['id']),
      patientId: String(t['patient_id']),
      encounterId: t['encounter_id'] ? String(t['encounter_id']) : null,
      taskType: t['task_type'] as TaskType,
      title: String(t['title']),
      description: String(t['description']),
      ownerId: String(t['owner_id']),
      ownerName: String(t['owner_name'] ?? ''),
      assignedTeam: String(t['assigned_team']),
      priority: t['priority'] as ClinicalTask['priority'],
      status: t['status'] as TaskStatus,
      dueAt: String(t['due_at']),
      completionEvidence: t['completion_evidence'] ? String(t['completion_evidence']) : null,
      createdBy: String(t['created_by']),
      acceptedBy: t['accepted_by'] ? String(t['accepted_by']) : null,
      acceptedAt: t['accepted_at'] ? String(t['accepted_at']) : null,
      completedBy: t['completed_by'] ? String(t['completed_by']) : null,
      completedAt: t['completed_at'] ? String(t['completed_at']) : null,
      patientSummaryText: t['patient_summary_text'] ? String(t['patient_summary_text']) : null,
      patientSummaryApprovedBy: t['patient_summary_approved_by']
        ? String(t['patient_summary_approved_by'])
        : null,
      patientSummaryApprovedAt: t['patient_summary_approved_at']
        ? String(t['patient_summary_approved_at'])
        : null,
      createdAt: String(t['created_at']),
    };
  }
}
