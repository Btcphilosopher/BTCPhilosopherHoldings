# Aureom Clinical — Architecture & Repository Structure

## 1. Runtime & Deliverables Overview

This repository contains:
1. **Live Interactive Web Preview (`/src/server.ts`, `/src/server/*`, `/src/app/*`)**: Runs directly on port 3000 via Angular 21 + Express SSR + Node 22 built-in persistent SQLite (`data/aureom_clinical.sqlite`) so every clinical workflow can be demonstrated and tested live in the browser.
2. **Rust Modular Monolith Reference Workspace (`/rust/`)**:
   - `crates/aureom-domain`: Strongly-typed clinical domain models, state transitions (`Draft -> Signed -> Amended / EnteredInError`), explicit absence/unknown semantics, optimistic concurrency rules, and HMAC-SHA256 signing primitives.
   - `crates/aureom-db`: PostgreSQL SQLx 0.8 repository using `BEGIN ... SELECT ... FOR UPDATE` transactions, idempotent atomic signing, hash-chained audit persistence, and a transactional outbox.
   - `crates/aureom-interop`: FHIR R4 UK Core (`DAPB4020`) mapping layer and authoritative source matrix.
   - `crates/aureom-api`: Axum 0.8 HTTP server with OIDC-compatible authentication middleware, patient-level RBAC + break-glass checks, and privacy-safe structured `tracing` logs (excluding PHI/clinical text).
   - `crates/aureom-web-leptos`: Leptos 0.8 WASM/SSR UI shell and persistent patient banner components.
   - `migrations/`: PostgreSQL SQLx migrations (`0001_initial_schema.sql`, `0002_seed_synthetic.sql`).
   - `docker-compose.yml` & `Dockerfile`: Reproducible local deployment with PostgreSQL 16 + MinIO object storage.

## 2. Build & Test Commands

### Live Web Application (Node 22 + Angular 21 + Persistent SQLite)
- `npm install`
- `npm run dev` (starts SSR + API on `http://0.0.0.0:3000`)
- `npm run build` (AOT production build)
- `npm run lint` (ESLint + Angular template accessibility rules)
- `npm test` (Vitest acceptance & safety test suite)

### Rust Workspace (with Rust 1.83+ and Docker installed locally)
- `cd rust && docker compose up -d postgres minio`
- `cd rust && cargo test --workspace`
- `cd rust && cargo run -p aureom-api`
