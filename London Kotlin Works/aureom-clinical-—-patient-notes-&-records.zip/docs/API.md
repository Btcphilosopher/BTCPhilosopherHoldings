# Aureom Clinical — REST & FHIR Interoperability API Contracts

All `/api/*` endpoints (except `/api/health`, `/api/auth/providers`, and `/api/auth/login`) require an `Authorization: Bearer <token>` header issued by the local OIDC identity adapter and enforce patient-level organisation / care-relationship / break-glass checks.

## Authentication & Break-Glass
- `GET /api/auth/providers` — Lists local development OIDC identity provider metadata and synthetic clinician accounts.
- `POST /api/auth/login` — Body: `{ "clinicianId": "clin-vance" }`. Returns `{ token, clinician, expiresAt, oidcIssuer }`.
- `POST /api/auth/logout` — Revokes current session token and writes an audit event.
- `POST /api/auth/break-glass` — Body: `{ "patientId": "...", "reason": "..." }`. Grants 30-minute audited emergency access and flags for IG review.

## Worklists & Patients
- `GET /api/worklist` — Returns scheduled encounters, unacknowledged diagnostic results, and open tasks for the clinician's trust.
- `GET /api/patients?q=...` — Searches synthetic patients within trust boundaries (external trust records require break-glass).
- `POST /api/patients` — Registers a synthetic patient; returns demographic `duplicateWarnings` without auto-merging.
- `POST /api/patients/merge` — Authorised merge preserving identifiers, provenance, and audit history.
- `GET /api/patients/:id/overview` — Full patient overview with explicit clinical conflicts and source links; records view audit event.

## Clinical Notes Lifecycle
- `POST /api/patients/:id/notes` — Creates a draft note from one of 7 templates (`consultation`, `admission`, `ward_round`, `progress`, `procedure`, `discharge`, `handover`).
- `PUT /api/notes/:noteId/draft` — Saves draft with `expectedVersion`. Returns `409 DRAFT_VERSION_CONFLICT` with `serverNote` if modified concurrently, or `409 IMMUTABLE_SIGNED_NOTE` if already signed.
- `POST /api/notes/:noteId/sign` — Body: `{ "expectedVersion": 1, "patientConfirmed": true, "idempotencyKey": "..." }`. Atomically signs note, stores separate clinical attestation & cryptographic signature, writes audit & outbox events. Retries with the same `idempotencyKey` succeed without duplicate signatures.
- `POST /api/notes/:noteId/amendments` — Links an attributed addendum to an immutable signed note.
- `POST /api/notes/:noteId/entered-in-error` — Marks a note entered-in-error (Consultant/IGLead only) while preserving original content.

## Results, Medications, Tasks, Documents & Admin
- `POST /api/results/:resultId/state` — Transitions `available -> viewed -> acknowledged -> follow_up_assigned -> follow_up_completed`.
- `POST /api/results/:resultId/simulate-correction` — Ingests a corrected result linked via `supersedesResultId` and creates an urgent review task.
- `POST /api/patients/:id/medications` — Records separate `prescribing`, `dispensing`, `administration`, or `patient_reported` entries.
- `POST /api/patients/:id/allergy-assertion` — Sets explicit `no_known_allergies` vs `not_assessed` vs `assessed_with_allergies`.
- `POST /api/tasks/:taskId/transition` — Advances tasks and records completion evidence / patient-friendly summary approval.
- `GET /api/attachments/:attachmentId/download` — Enforces patient access checks and audits download.
- `GET /api/admin/audit` — Returns audit events and verifies SHA-256 hash-chain integrity across all sequential events.
- `GET /api/interop/fhir/Patient/:id/$everything` — Emits a mock FHIR R4 UK Core collection bundle.
- `POST /api/ai/draft-summary` — Disabled by default (`403 AI_ADAPTER_DISABLED`); when explicitly enabled by admin, generates clinician-reviewable summary suggestions with source links and uncertainty notices.
