# Aureom Clinical — NHS Jurisdiction, Clinical Safety, IG & Integration Compliance Research

**Important Prototype Disclaimer:** Aureom Clinical is an **independent software prototype** populated exclusively with **synthetic data**. It is **not** an NHS-accredited product, **not** connected to live NHS Spine/PDS/EPS/GP Connect infrastructure, and **must not** be used for real patient care without completing the statutory governance and assurance activities below.

## 1. Jurisdiction & Statutory Clinical Safety Responsibilities (England / NHS)
Under the **Health and Social Care Act 2012** (Information Standards), two mandatory clinical risk management standards apply:
- **DCB0129 (Clinical Risk Management: its Application in the Manufacture of Health IT Systems)**: Applies to the software manufacturer/supplier. Requires maintaining a formal Clinical Risk Management System, appointing a qualified **Clinical Safety Officer (CSO)** (an actively registered clinician with NHS Digital/NHS England CSO Practitioner training), maintaining a **Hazard Log**, and signing a **Clinical Safety Case Report** prior to release.
- **DCB0160 (Clinical Risk Management: its Application in the Deployment and Use of Health IT Systems)**: Applies to each deploying health/care organisation (NHS Trust, ICB, or GP practice). Requires a local CSO to assess local workflows, population risks, training, and SOPs, producing a **Deployment Clinical Safety Case**.
- **Medical Device Consideration**: Software providing diagnostic scoring, automated dosing, or clinical decision support may fall under **UK MDR 2002** (MHRA Software as a Medical Device). In this prototype, unverified dosing recommendations and automated AI clinical actions are intentionally omitted.

## 2. Information Governance & Assurance Frameworks
- **Data Security and Protection Toolkit (DSPT)**: Annual statutory self-assessment against the National Data Guardian's 10 Data Security Standards (accessible via `dsptoolkit.nhs.uk`).
- **Digital Technology Assessment Criteria (DTAC)**: NHS England procurement baseline covering Clinical Safety (DCB0129), Data Protection (UK GDPR / Data Protection Act 2018 / DPIA), Technical Security (Cyber Essentials Plus, penetration testing), Interoperability, and Usability/Accessibility (WCAG 2.1/2.2 AA).
- **Audit Storage Integrity**: As reflected in code comments and UI disclosures, a database table with a SHA-256 hash chain detects accidental or casual row tampering, **not** privileged DB administrator compromise. Production deployment requires restricted append-only DB roles (`REVOKE UPDATE, DELETE`) plus continuous replication to external immutable **WORM** storage (e.g., AWS S3 Object Lock Compliance mode / Azure Immutable Blob).

## 3. Interoperability & National Integration Approvals
- **FHIR UK Core (Information Standard DAPB4020)**: Jointly maintained by HL7 UK and NHS England on `simplifier.net` / `standards.nhs.uk`. Constrains FHIR R4 for NHS Number identifier extensions, UK Core `Patient`, `Encounter`, `Observation`, `AllergyIntolerance`, `MedicationStatement`, `DiagnosticReport`, and `DocumentReference`.
- **Mandatory Onboarding Gates for Live NHS Connectivity**:
  - **NHS Care Identity Service 2 (CIS2)**: Replace the local development OIDC adapter with CIS2 OIDC authentication and RBAC role profiles (`SDS Role Profiles`).
  - **Personal Demographics Service (PDS) FHIR API**: Requires NHS England Digital Onboarding Service (DOS) assurance, supplier conformance certificate, and mTLS/JWT authentication before performing live NHS Number verification traces.
  - **GP Connect / MESH / EPS**: Each requires separate NHS England integration assurance, SCAL (Supplier Conformance Assessment List), and Data Sharing Agreements.

## 4. Implemented Controls vs. Independently Assessed Compliance

| Capability Area | Implemented in Prototype | Requires Independent Assessment / Live Infrastructure |
| :--- | :--- | :--- |
| **Authentication** | Local OIDC-compatible adapter, 60m session expiry, revocation | NHS CIS2 integration, smartcard/authenticator assurance, MFA |
| **Authorisation** | Patient-level org/care-team checks + audited break-glass | Trust-wide SDS role mapping, formal Caldicott Guardian review |
| **Clinical Notes** | Atomic signing, idempotency, immutable lock, linked amendments, 409 conflict UI | DCB0129/DCB0160 CSO sign-off, Hazard Log, clinical usability study |
| **Audit Trail** | Append-only table with sequential SHA-256 hash-chain verification | External WORM log shipping, SIEM alerting, annual penetration test |
| **Interoperability** | Mock FHIR R4 UK Core bundle & authoritative source matrix | PDS/EPS/GP Connect DOS onboarding, SCAL, live mTLS endpoints |
| **AI Drafting** | Disabled by default; explicit source citations & uncertainty notices | DCB0129 AI hazard evaluation, MHRA SaMD classification check |
