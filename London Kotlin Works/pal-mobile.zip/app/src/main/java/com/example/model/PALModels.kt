package com.example.model

data class Airport(
    val code: String,
    val city: String,
    val country: String,
    val airportName: String,
    val terminal: String
)

data class Flight(
    val id: String,
    val flightNumber: String,
    val origin: Airport,
    val destination: Airport,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val aircraft: String,
    val operatingCarrier: String,
    val marketingCarrier: String,
    val priceEconomy: Double,
    val priceBusiness: Double,
    val stops: Int,
    val stopLocation: String? = null,
    val baggageIncluded: String,
    val mealIncluded: Boolean,
    val isOvernight: Boolean = false
)

data class Passenger(
    val id: String = java.util.UUID.randomUUID().toString(),
    var firstName: String,
    var lastName: String,
    var email: String,
    var phone: String,
    var passportNumber: String,
    var nationality: String,
    var dateOfBirth: String,
    var seatNumber: String? = null,
    var mealPreference: String = "Regular",
    var baggageKg: Int = 23,
    var specialAssistance: String = "None"
)

data class FareOption(
    val id: String,
    val name: String, // e.g. "Economy Saver", "Economy Value", "Economy Flex", "Business Class"
    val cabin: String,
    val price: Double,
    val baggage: String,
    val changeFee: String,
    val refundFee: String,
    val milesAccrual: Int
)

data class Booking(
    val pnr: String,
    val flights: List<Flight>,
    val passengers: List<Passenger>,
    val fareFamily: String,
    val cabin: String,
    val baseFare: Double,
    val taxesAndFees: Double,
    val extrasTotal: Double,
    val totalPrice: Double,
    val currency: String = "PHP",
    var bookingStatus: String, // Confirmed, Pending, Cancelled
    var paymentStatus: String, // Paid, Pending, Failed, TimedOut
    var ticketingStatus: String, // Issued, Processing, Failed, NeedsReconciliation
    var checkedIn: Boolean = false,
    val bookingDate: String = "Nov 23, 2026",
    val ticketNumber: String = "079" + (100000000..999999999).random()
)

data class LoyaltyProfile(
    val memberId: String,
    val fullName: String,
    val tier: String, // Classic, Elite, Premier Elite, Million Miler
    val redeemableMiles: Long,
    val tierMiles: Long,
    val pendingMiles: Long,
    val nextTierRequirement: String,
    val recentActivity: List<ActivityRecord>
)

data class ActivityRecord(
    val id: String,
    val date: String,
    val description: String,
    val route: String,
    val miles: Long,
    val status: String // Posted, Pending
)

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: String,
    val type: String, // Booking, ScheduleChange, Gate, CheckIn, Payment
    var isRead: Boolean = false,
    val pnrRef: String? = null
)

data class Seat(
    val seatId: String, // e.g. "12A"
    val row: Int,
    val letter: Char,
    val cabin: String, // Economy, Business
    val type: SeatType,
    val price: Double,
    var isAvailable: Boolean = true,
    var isSelected: Boolean = false
)

enum class SeatType {
    WINDOW, AISLE, MIDDLE, EXTRA_LEGROOM, EXIT_ROW
}
