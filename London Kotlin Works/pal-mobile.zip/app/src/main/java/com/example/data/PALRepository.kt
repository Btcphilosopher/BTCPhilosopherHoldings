package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object PALRepository {
  val airports = listOf(
      Airport("MNL", "Manila", "Philippines", "Ninoy Aquino International Airport", "Terminal 2"),
      Airport("CEB", "Cebu", "Philippines", "Mactan-Cebu International Airport", "Terminal 1"),
      Airport("DVO", "Davao", "Philippines", "Francisco Bangoy International Airport", "Main Terminal"),
      Airport("NRT", "Tokyo", "Japan", "Narita International Airport", "Terminal 2"),
      Airport("LAX", "Los Angeles", "USA", "Los Angeles International Airport", "Tom Bradley International Terminal")
  )

  val sampleFlights = listOf(
      Flight(
          id = "PR422",
          flightNumber = "PR 422",
          origin = airports[0], // MNL
          destination = airports[3], // NRT
          departureTime = "09:25 AM",
          arrivalTime = "02:45 PM",
          duration = "4h 20m",
          aircraft = "Airbus A321neo",
          operatingCarrier = "Philippine Airlines",
          marketingCarrier = "PR",
          priceEconomy = 14500.0,
          priceBusiness = 42800.0,
          stops = 0,
          baggageIncluded = "30kg Check-in, 7kg Cabin",
          mealIncluded = true,
          isOvernight = false
      ),
      Flight(
          id = "PR102",
          flightNumber = "PR 102",
          origin = airports[0], // MNL
          destination = airports[4], // LAX
          departureTime = "08:15 PM",
          arrivalTime = "08:30 PM",
          duration = "13h 15m",
          aircraft = "Boeing 777-300ER",
          operatingCarrier = "Philippine Airlines",
          marketingCarrier = "PR",
          priceEconomy = 48500.0,
          priceBusiness = 125000.0,
          stops = 0,
          baggageIncluded = "2 x 23kg Check-in, 7kg Cabin",
          mealIncluded = true,
          isOvernight = false
      ),
      Flight(
          id = "PR836",
          flightNumber = "PR 836",
          origin = airports[0], // MNL
          destination = airports[1], // CEB
          departureTime = "06:00 AM",
          arrivalTime = "07:25 AM",
          duration = "1h 25m",
          aircraft = "Airbus A330-300",
          operatingCarrier = "Philippine Airlines",
          marketingCarrier = "PR",
          priceEconomy = 3200.0,
          priceBusiness = 9800.0,
          stops = 0,
          baggageIncluded = "20kg Check-in, 7kg Cabin",
          mealIncluded = true,
          isOvernight = false
      ),
      Flight(
          id = "PR2808",
          flightNumber = "PR 2808",
          origin = airports[0], // MNL
          destination = airports[2], // DVO
          departureTime = "10:30 AM",
          arrivalTime = "12:15 PM",
          duration = "1h 45m",
          aircraft = "Airbus A321",
          operatingCarrier = "Philippine Airlines",
          marketingCarrier = "PR",
          priceEconomy = 3800.0,
          priceBusiness = 11200.0,
          stops = 0,
          baggageIncluded = "20kg Check-in, 7kg Cabin",
          mealIncluded = true,
          isOvernight = false
      )
  )

  private val _bookings = MutableStateFlow<MutableList<Booking>>(
      mutableListOf(
          Booking(
              pnr = "PAL784",
              flights = listOf(sampleFlights[0]), // MNL to NRT
              passengers = listOf(
                  Passenger(
                      firstName = "Juan",
                      lastName = "Dela Cruz",
                      email = "juan.delacruz@example.com",
                      phone = "+63 917 555 1234",
                      passportNumber = "P1234567A",
                      nationality = "Filipino",
                      dateOfBirth = "15-Aug-1988",
                      seatNumber = "14A"
                  )
              ),
              fareFamily = "Economy Value",
              cabin = "Economy",
              baseFare = 14500.0,
              taxesAndFees = 2850.0,
              extrasTotal = 500.0,
              totalPrice = 17850.0,
              bookingStatus = "Confirmed",
              paymentStatus = "Paid",
              ticketingStatus = "Issued",
              checkedIn = false
          )
      )
  )
  val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

  private val _loyalty = MutableStateFlow(
      LoyaltyProfile(
          memberId = "PR-88392011",
          fullName = "Juan Dela Cruz",
          tier = "Premier Elite",
          redeemableMiles = 68450,
          tierMiles = 42100,
          pendingMiles = 2500,
          nextTierRequirement = "7,900 tier miles to Million Miler",
          recentActivity = listOf(
              ActivityRecord("ACT-1", "Nov 15, 2026", "Manila (MNL) to Cebu (CEB)", "PR 836", 1200, "Posted"),
              ActivityRecord("ACT-2", "Oct 28, 2026", "Tokyo (NRT) to Manila (MNL)", "PR 423", 2450, "Posted"),
              ActivityRecord("ACT-3", "Nov 23, 2026", "Manila (MNL) to Tokyo (NRT)", "PR 422", 2500, "Pending")
          )
      )
  )
  val loyalty: StateFlow<LoyaltyProfile> = _loyalty.asStateFlow()

  private val _notifications = MutableStateFlow(
      mutableListOf(
          NotificationItem(
              id = "NOTIF-1",
              title = "Booking Confirmed",
              message = "Your flight PR 422 to Tokyo (NRT) is confirmed. PNR: PAL784",
              timestamp = "2 hours ago",
              type = "Booking",
              isRead = false,
              pnrRef = "PAL784"
          ),
          NotificationItem(
              id = "NOTIF-2",
              title = "Check-in Reminder",
              message = "Online check-in opens 24 hours before departure for PR 422.",
              timestamp = "1 day ago",
              type = "CheckIn",
              isRead = true,
              pnrRef = "PAL784"
          ),
          NotificationItem(
              id = "NOTIF-3",
              title = "Mabuhay Miles Update",
              message = "2,500 miles pending for your upcoming Tokyo flight.",
              timestamp = "2 days ago",
              type = "Loyalty",
              isRead = true
          )
      )
  )
  val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

  fun addBooking(booking: Booking) {
    val list = _bookings.value.toMutableList()
    list.add(0, booking)
    _bookings.value = list

    // Add notification
    val notifList = _notifications.value.toMutableList()
    notifList.add(
        0,
        NotificationItem(
            id = "NOTIF-${System.currentTimeMillis()}",
            title = "New Booking Created",
            message = "Reservation PNR ${booking.pnr} successfully booked and ticketed.",
            timestamp = "Just now",
            type = "Booking",
            isRead = false,
            pnrRef = booking.pnr
        )
    )
    _notifications.value = notifList
  }

  fun getBooking(pnr: String): Booking? {
    return _bookings.value.find { it.pnr.equals(pnr, ignoreCase = true) }
  }

  fun cancelBooking(pnr: String): Boolean {
    val booking = getBooking(pnr) ?: return false
    booking.bookingStatus = "Cancelled"
    booking.ticketingStatus = "Refunded"
    _bookings.value = _bookings.value.toMutableList()
    return true
  }

  fun updateCheckIn(pnr: String, status: Boolean): Boolean {
    val booking = getBooking(pnr) ?: return false
    booking.checkedIn = status
    _bookings.value = _bookings.value.toMutableList()
    return true
  }

  fun simulateScheduleChange(pnr: String) {
    val booking = getBooking(pnr) ?: return
    // update departure time by 2 hours
    val notifList = _notifications.value.toMutableList()
    notifList.add(
        0,
        NotificationItem(
            id = "NOTIF-${System.currentTimeMillis()}",
            title = "Schedule Change Notice",
            message = "Flight ${booking.flights.first().flightNumber} departure time has been updated to 11:30 AM due to operational adjustments. Please review replacement itinerary.",
            timestamp = "Just now",
            type = "ScheduleChange",
            isRead = false,
            pnrRef = pnr
        )
    )
    _notifications.value = notifList
  }

  fun generateSeatMap(flightId: String): List<Seat> {
    val seats = mutableListOf<Seat>()
    val rows = 1 to 25
    val letters = listOf('A', 'B', 'C', 'D', 'E', 'F')
    for (r in rows.first..rows.second) {
      for (l in letters) {
        val seatType = when {
          l == 'A' || l == 'F' -> SeatType.WINDOW
          l == 'C' || l == 'D' -> SeatType.AISLE
          else -> SeatType.MIDDLE
        }
        val price = if (r <= 5) 1200.0 else if (r in 12..14) 800.0 else 0.0
        val isAvail = !(r == 14 && l == 'A') // 14A taken in sample
        seats.add(Seat(seatId = "$r$l", row = r, letter = l, cabin = "Economy", type = seatType, price = price, isAvailable = isAvail))
      }
    }
    return seats
  }
}
