package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PALRepository
import com.example.model.*
import com.example.ui.theme.PalNavy
import com.example.ui.theme.PalRed
import com.example.ui.theme.PalGold

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlightSearchScreen(
    onNavigateBack: () -> Unit,
    onSearchExecuted: (String, String, String) -> Unit
) {
  var tripType by remember { mutableStateOf("Return") }
  var origin by remember { mutableStateOf("MNL") }
  var destination by remember { mutableStateOf("NRT") }
  var adults by remember { mutableStateOf(1) }
  var cabin by remember { mutableStateOf("Economy") }

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Search Flights", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Trip Type Selector
      SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
        SegmentedButton(
            selected = tripType == "Return",
            onClick = { tripType = "Return" },
            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 3)
        ) { Text("Return") }
        SegmentedButton(
            selected = tripType == "One-Way",
            onClick = { tripType = "One-Way" },
            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 3)
        ) { Text("One-Way") }
        SegmentedButton(
            selected = tripType == "Multi-City",
            onClick = { tripType = "Multi-City" },
            shape = SegmentedButtonDefaults.itemShape(index = 2, count = 3)
        ) { Text("Multi-City") }
      }

      Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
          // Origin
          OutlinedTextField(
              value = origin,
              onValueChange = { origin = it },
              label = { Text("From (Origin)") },
              leadingIcon = { Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = PalNavy) },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
          )

          // Destination
          OutlinedTextField(
              value = destination,
              onValueChange = { destination = it },
              label = { Text("To (Destination)") },
              leadingIcon = { Icon(Icons.Default.FlightLand, contentDescription = null, tint = PalRed) },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
          )

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = "$adults Adult",
                onValueChange = {},
                readOnly = true,
                label = { Text("Passengers") },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = cabin,
                onValueChange = { cabin = it },
                label = { Text("Cabin Class") },
                leadingIcon = { Icon(Icons.Default.Class, contentDescription = null) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            )
          }
        }
      }

      Button(
          onClick = { onSearchExecuted(origin, destination, cabin) },
          modifier = Modifier
              .fillMaxWidth()
              .height(50.dp),
          colors = ButtonDefaults.buttonColors(containerColor = PalNavy),
          shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Search, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Search Available Flights", fontWeight = FontWeight.Bold, fontSize = 16.sp)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlightResultsScreen(
    origin: String,
    destination: String,
    cabin: String,
    onNavigateBack: () -> Unit,
    onSelectFlight: (Flight, String) -> Unit
) {
  val flights = PALRepository.sampleFlights

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("$origin → $destination ($cabin)", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      items(flights) { flight ->
        val price = if (cabin == "Business") flight.priceBusiness else flight.priceEconomy
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = PalNavy, shape = RoundedCornerShape(6.dp)) {
                  Text(flight.flightNumber, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text(flight.aircraft, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Text("₱%,.2f".format(price), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PalRed)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(flight.origin.code, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = PalNavy)
                Text(flight.departureTime, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
              }

              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Flight, contentDescription = null, tint = PalNavy, modifier = Modifier.size(20.dp))
                Text(flight.duration, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (flight.stops == 0) "Direct" else "${flight.stops} Stop", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
              }

              Column(horizontalAlignment = Alignment.End) {
                Text(flight.destination.code, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = PalNavy)
                Text(flight.arrivalTime, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
              }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
              Text(flight.baggageIncluded, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Button(
                  onClick = { onSelectFlight(flight, cabin) },
                  colors = ButtonDefaults.buttonColors(containerColor = PalRed),
                  contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
              ) {
                Text("Select Fare", fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingWorkflowScreen(
    flightId: String,
    cabin: String,
    onNavigateBack: () -> Unit,
    onBookingComplete: (String) -> Unit
) {
  val flight = PALRepository.sampleFlights.find { it.id == flightId } ?: PALRepository.sampleFlights.first()
  val basePrice = if (cabin == "Business") flight.priceBusiness else flight.priceEconomy

  var step by remember { mutableStateOf(1) } // 1: Passenger, 2: Extras, 3: Review & Payment
  var firstName by remember { mutableStateOf("Maria") }
  var lastName by remember { mutableStateOf("Santos") }
  var email by remember { mutableStateOf("maria.santos@example.com") }
  var phone by remember { mutableStateOf("+63 918 123 4567") }
  var passport by remember { mutableStateOf("P9876543B") }
  var extraBaggage by remember { mutableStateOf(false) }
  var selectedSeat by remember { mutableStateOf("12C") }
  var paymentMode by remember { mutableStateOf("Credit Card") }
  var paymentOutcome by remember { mutableStateOf("Success") } // Success, Timeout, Failure

  val baggageFee = if (extraBaggage) 1500.0 else 0.0
  val seatFee = 500.0
  val taxes = 2850.0
  val total = basePrice + baggageFee + seatFee + taxes

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Book Flight • Step $step of 3", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = { if (step > 1) step-- else onNavigateBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      LinearProgressIndicator(
          progress = { step / 3f },
          modifier = Modifier.fillMaxWidth(),
          color = PalRed
      )

      when (step) {
        1 -> {
          Text("Passenger Information", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
          OutlinedTextField(value = firstName, onValueChange = { firstName = it }, label = { Text("First Name") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
          OutlinedTextField(value = lastName, onValueChange = { lastName = it }, label = { Text("Last Name") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
          OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
          OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile Phone") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
          OutlinedTextField(value = passport, onValueChange = { passport = it }, label = { Text("Passport Number") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))

          Button(
              onClick = { step = 2 },
              modifier = Modifier.fillMaxWidth().height(50.dp),
              colors = ButtonDefaults.buttonColors(containerColor = PalNavy),
              shape = RoundedCornerShape(12.dp)
          ) {
            Text("Continue to Extras", fontWeight = FontWeight.Bold)
          }
        }
        2 -> {
          Text("Baggage & Seat Selection", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)

          Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Additional Checked Baggage (+23kg)", fontWeight = FontWeight.Bold)
                Text("₱1,500.00", color = PalRed, fontWeight = FontWeight.Bold)
              }
              Checkbox(checked = extraBaggage, onCheckedChange = { extraBaggage = it })
            }
          }

          Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Pre-selected Seat ($selectedSeat)", fontWeight = FontWeight.Bold)
                Text("₱500.00 • Extra Legroom Window", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              TextButton(onClick = { selectedSeat = if (selectedSeat == "12C") "14F" else "12C" }) {
                Text("Change")
              }
            }
          }

          Button(
              onClick = { step = 3 },
              modifier = Modifier.fillMaxWidth().height(50.dp),
              colors = ButtonDefaults.buttonColors(containerColor = PalNavy),
              shape = RoundedCornerShape(12.dp)
          ) {
            Text("Review & Payment", fontWeight = FontWeight.Bold)
          }
        }
        3 -> {
          Text("Price Review & Payment", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)

          Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("Fare Breakdown", fontWeight = FontWeight.Bold, color = PalNavy)
              PriceRow("Base Fare (${flight.flightNumber})", "₱%,.2f".format(basePrice))
              if (extraBaggage) PriceRow("Extra Baggage", "₱1,500.00")
              PriceRow("Seat Selection ($selectedSeat)", "₱500.00")
              PriceRow("Taxes, Fees & Charges", "₱%,.2f".format(taxes))
              Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
              PriceRow("Total Amount", "₱%,.2f".format(total), isBold = true)
            }
          }

          Text("Payment Simulation Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = paymentOutcome == "Success", onClick = { paymentOutcome = "Success" }, label = { Text("Success") })
            FilterChip(selected = paymentOutcome == "Timeout", onClick = { paymentOutcome = "Timeout" }, label = { Text("Timeout") })
            FilterChip(selected = paymentOutcome == "Failure", onClick = { paymentOutcome = "Failure" }, label = { Text("Ticketing Fail") })
          }

          Button(
              onClick = {
                val newPnr = "PAL" + (100..999).random()
                val newBooking = Booking(
                    pnr = newPnr,
                    flights = listOf(flight),
                    passengers = listOf(
                        Passenger(
                            firstName = firstName,
                            lastName = lastName,
                            email = email,
                            phone = phone,
                            passportNumber = passport,
                            nationality = "Filipino",
                            dateOfBirth = "10-Oct-1990",
                            seatNumber = selectedSeat
                        )
                    ),
                    fareFamily = cabin,
                    cabin = cabin,
                    baseFare = basePrice,
                    taxesAndFees = taxes,
                    extrasTotal = baggageFee + seatFee,
                    totalPrice = total,
                    bookingStatus = if (paymentOutcome == "Success") "Confirmed" else "Pending",
                    paymentStatus = if (paymentOutcome == "Success") "Paid" else "Failed",
                    ticketingStatus = if (paymentOutcome == "Success") "Issued" else "NeedsReconciliation",
                    checkedIn = false
                )
                PALRepository.addBooking(newBooking)
                onBookingComplete(newPnr)
              },
              modifier = Modifier.fillMaxWidth().height(50.dp),
              colors = ButtonDefaults.buttonColors(containerColor = PalRed),
              shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Lock, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Complete Secure Payment", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
        }
      }
    }
  }
}

@Composable
fun PriceRow(label: String, amount: String, isBold: Boolean = false) {
  Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, fontSize = if (isBold) 16.sp else 14.sp)
    Text(amount, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, fontSize = if (isBold) 16.sp else 14.sp, color = if (isBold) PalRed else MaterialTheme.colorScheme.onSurface)
  }
}
