package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PALRepository
import com.example.model.*
import com.example.ui.theme.PalNavy
import com.example.ui.theme.PalRed
import com.example.ui.theme.PalGold
import com.example.ui.theme.PalGoldLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageBookingScreen(
    initialPnr: String? = null,
    onNavigateBack: () -> Unit
) {
  var pnrInput by remember { mutableStateOf(initialPnr ?: "PAL784") }
  var currentBooking by remember { mutableStateOf(PALRepository.getBooking(pnrInput)) }

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Manage Booking", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = pnrInput,
            onValueChange = { pnrInput = it },
            label = { Text("Booking Reference (PNR)") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
        )
        Button(
            onClick = { currentBooking = PALRepository.getBooking(pnrInput) },
            modifier = Modifier.align(Alignment.CenterVertically).height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PalNavy),
            shape = RoundedCornerShape(12.dp)
        ) {
          Text("Retrieve")
        }
      }

      if (currentBooking != null) {
        val b = currentBooking!!
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("PNR: ${b.pnr}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PalNavy)
                Text("Ticket: ${b.ticketNumber}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Surface(
                  color = if (b.bookingStatus == "Confirmed") Color(0xFF2E7D32) else PalRed,
                  shape = RoundedCornerShape(6.dp)
              ) {
                Text(b.bookingStatus, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
              }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            Text("Flight Itinerary", fontWeight = FontWeight.Bold, color = PalNavy)
            b.flights.forEach { f ->
              Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("${f.flightNumber}: ${f.origin.code} → ${f.destination.code}", fontWeight = FontWeight.Medium)
                Text(f.departureTime, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            Text("Passenger Details", fontWeight = FontWeight.Bold, color = PalNavy)
            b.passengers.forEach { p ->
              Text("${p.firstName} ${p.lastName} • Seat: ${p.seatNumber ?: "Unassigned"} • Pass: ${p.passportNumber}")
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("Total Paid: ₱%,.2f".format(b.totalPrice), fontWeight = FontWeight.Bold)
              Text("Ticketing: ${b.ticketingStatus}", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
            }
          }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Button(
              onClick = {
                PALRepository.simulateScheduleChange(b.pnr)
              },
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.buttonColors(containerColor = PalNavy)
          ) {
            Text("Simulate Change")
          }
          OutlinedButton(
              onClick = {
                PALRepository.cancelBooking(b.pnr)
                currentBooking = PALRepository.getBooking(b.pnr)
              },
              modifier = Modifier.weight(1f)
          ) {
            Text("Cancel Booking", color = PalRed)
          }
        }
      } else {
        Box(
            modifier = Modifier.fillMaxWidth().padding(40.dp),
            contentAlignment = Alignment.Center
        ) {
          Text("No booking found for PNR: $pnrInput", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckInScreen(
    onNavigateBack: () -> Unit
) {
  val bookings by PALRepository.bookings.collectAsState()
  val confirmBooking = bookings.firstOrNull()

  var checkedInStatus by remember { mutableStateOf(confirmBooking?.checkedIn ?: false) }
  var showBoardingPass by remember { mutableStateOf(false) }

  if (showBoardingPass && confirmBooking != null) {
    BoardingPassScreen(booking = confirmBooking, onNavigateBack = { showBoardingPass = false })
    return
  }

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Flight Check-In & Boarding Pass", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      if (confirmBooking != null) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("PNR: ${confirmBooking.pnr}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = PalNavy)
              Text("Flight ${confirmBooking.flights.first().flightNumber}", fontWeight = FontWeight.Bold)
            }
            Text("${confirmBooking.flights.first().origin.city} to ${confirmBooking.flights.first().destination.city}")
            Text("Passenger: ${confirmBooking.passengers.first().firstName} ${confirmBooking.passengers.first().lastName}")

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Document Verification", fontWeight = FontWeight.Bold)
                Text("Passport OK • Visa Required at Gate", fontSize = 12.sp, color = Color(0xFF2E7D32))
              }
              Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF2E7D32))
            }
          }
        }

        if (!checkedInStatus) {
          Button(
              onClick = {
                PALRepository.updateCheckIn(confirmBooking.pnr, true)
                checkedInStatus = true
              },
              modifier = Modifier.fillMaxWidth().height(50.dp),
              colors = ButtonDefaults.buttonColors(containerColor = PalRed),
              shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Complete Check-In", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
        } else {
          Button(
              onClick = { showBoardingPass = true },
              modifier = Modifier.fillMaxWidth().height(50.dp),
              colors = ButtonDefaults.buttonColors(containerColor = PalNavy),
              shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.QrCode, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("View Digital Boarding Pass", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoardingPassScreen(
    booking: Booking,
    onNavigateBack: () -> Unit
) {
  val flight = booking.flights.first()
  val passenger = booking.passengers.first()

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Boarding Pass", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
          modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
          Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("PHILIPPINE AIRLINES", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PalNavy)
              Text("Mabuhay Pass", fontSize = 11.sp, color = PalRed)
            }
            Surface(color = PalGoldLight, shape = RoundedCornerShape(6.dp)) {
              Text("ZONE 2", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = PalNavy)
            }
          }

          Divider(color = Color.LightGray)

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
              Text("PASSENGER", fontSize = 10.sp, color = Color.Gray)
              Text("${passenger.lastName} / ${passenger.firstName}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("PNR", fontSize = 10.sp, color = Color.Gray)
              Text(booking.pnr, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PalNavy)
            }
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
              Text("FROM", fontSize = 10.sp, color = Color.Gray)
              Text(flight.origin.code, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = PalNavy)
              Text(flight.origin.city, fontSize = 11.sp, color = Color.Gray)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(Icons.Default.Flight, contentDescription = null, tint = PalRed)
              Text(flight.flightNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("TO", fontSize = 10.sp, color = Color.Gray)
              Text(flight.destination.code, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = PalNavy)
              Text(flight.destination.city, fontSize = 11.sp, color = Color.Gray)
            }
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
              Text("DATE", fontSize = 10.sp, color = Color.Gray)
              Text("Nov 24, 2026", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            }
            Column {
              Text("DEPARTURE", fontSize = 10.sp, color = Color.Gray)
              Text(flight.departureTime, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("SEAT", fontSize = 10.sp, color = Color.Gray)
              Text(passenger.seatNumber ?: "14A", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PalRed)
            }
          }

          Divider(color = Color.LightGray, thickness = 2.dp)

          // Non-operational barcode demonstration
          Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
              Text("||| | |||| || | || ||||| || ||| | ||||", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Non-operational Demonstration Barcode", fontSize = 10.sp, color = Color.Gray)
          }
        }
      }

      Surface(
          color = PalGoldLight,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
      ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.OfflineBolt, contentDescription = null, tint = PalNavy)
          Text("Available offline for airport security and boarding gates.", fontSize = 12.sp, color = PalNavy)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlightStatusScreen(
    onNavigateBack: () -> Unit
) {
  var flightNumber by remember { mutableStateOf("PR 422") }
  val flight = PALRepository.sampleFlights.first()

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Flight Status & Airport Journey", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = flightNumber,
            onValueChange = { flightNumber = it },
            label = { Text("Flight Number (e.g. PR 422)") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
        )
        Button(
            onClick = {},
            modifier = Modifier.align(Alignment.CenterVertically).height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PalNavy),
            shape = RoundedCornerShape(12.dp)
        ) {
          Text("Track")
        }
      }

      Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(flight.flightNumber, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = PalNavy)
            Surface(color = Color(0xFF2E7D32), shape = RoundedCornerShape(6.dp)) {
              Text("On Time", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
          }

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
              Text("Departure", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(flight.origin.code, fontWeight = FontWeight.Bold, fontSize = 18.sp)
              Text("Scheduled: 09:25 AM", fontSize = 12.sp)
              Text("Estimated: 09:25 AM", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
              Text("Terminal ${flight.origin.terminal} • Gate 14", fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("Arrival", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(flight.destination.code, fontWeight = FontWeight.Bold, fontSize = 18.sp)
              Text("Scheduled: 02:45 PM", fontSize = 12.sp)
              Text("Estimated: 02:45 PM", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
              Text("Terminal 2 • Belt 3", fontSize = 12.sp)
            }
          }
        }
      }

      Text("Airport Journey Timeline", fontWeight = FontWeight.Bold, fontSize = 18.sp)

      TimelineStep("1. Booking & Ticket Issued", "Completed secure reservation and confirmed ticketing.", true)
      TimelineStep("2. Online Check-In", "Available 24 hours prior to departure.", true)
      TimelineStep("3. Airport Arrival & Baggage Drop", "Ninoy Aquino International Airport Terminal 2.", false)
      TimelineStep("4. Security & Border Formalities", "Proceed to immigration and security screening.", false)
      TimelineStep("5. Boarding Gate", "Boarding starts 45 minutes prior to departure.", false)
    }
  }
}

@Composable
fun TimelineStep(title: String, subtitle: String, isDone: Boolean) {
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    Surface(
        shape = RoundedCornerShape(50),
        color = if (isDone) Color(0xFF2E7D32) else MaterialTheme.colorScheme.outline,
        modifier = Modifier.size(24.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(if (isDone) Icons.Default.Check else Icons.Default.HourglassEmpty, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
      }
    }
    Column {
      Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = if (isDone) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
      Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisruptionScreen(
    onNavigateBack: () -> Unit
) {
  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Disruption & Schedule Handling", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = PalRed)
            Text("Schedule Change Notice (PAL784)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
          }
          Text("Your flight PR 422 Manila to Tokyo Narita has been rescheduled from 09:25 AM to 11:30 AM due to air traffic control regulations.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onErrorContainer)
        }
      }

      Text("Alternative Itinerary Options", fontWeight = FontWeight.Bold, fontSize = 18.sp)

      Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Option 1: Replacement Flight PR 422 (Modified)", fontWeight = FontWeight.Bold, color = PalNavy)
          Text("Departure: 11:30 AM • Arrival: 04:50 PM")
          Text("Operated by Philippine Airlines • Airbus A321neo")
          Spacer(modifier = Modifier.height(4.dp))
          Button(
              onClick = {},
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
              modifier = Modifier.fillMaxWidth()
          ) {
            Text("Accept Replacement Itinerary", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MabuhayMilesScreen(
    onNavigateBack: () -> Unit
) {
  val loyalty by PALRepository.loyalty.collectAsState()

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Mabuhay Miles Dashboard", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = PalNavy)
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(loyalty.fullName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Surface(color = PalGold, shape = RoundedCornerShape(8.dp)) {
              Text(loyalty.tier, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), fontWeight = FontWeight.Bold, color = PalNavy, fontSize = 11.sp)
            }
          }
          Text("Member ID: ${loyalty.memberId}", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)

          Divider(color = Color.White.copy(alpha = 0.2f))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
              Text("Redeemable Miles", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
              Text("%,d".format(loyalty.redeemableMiles), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = PalGold)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("Tier Miles", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
              Text("%,d".format(loyalty.tierMiles), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
            }
          }
          Text(loyalty.nextTierRequirement, fontSize = 12.sp, color = PalGoldLight)
        }
      }

      Text("Auditable Activity Ledger", fontWeight = FontWeight.Bold, fontSize = 18.sp)

      loyalty.recentActivity.forEach { act ->
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Row(
              modifier = Modifier.fillMaxWidth().padding(16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(act.description, fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Text("${act.route} • ${act.date}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("+%,d".format(act.miles), fontWeight = FontWeight.Bold, color = PalRed, fontSize = 16.sp)
              Text(act.status, fontSize = 11.sp, color = if (act.status == "Posted") Color(0xFF2E7D32) else PalGold)
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    onNavigateBack: () -> Unit
) {
  val notifs by PALRepository.notifications.collectAsState()

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("Travel Notifications & Inbox", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(notifs) { n ->
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = if (!n.isRead) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(n.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PalNavy)
              Text(n.timestamp, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(n.message, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportChatScreen(
    onNavigateBack: () -> Unit
) {
  var messageInput by remember { mutableStateOf("") }
  var chatMessages by remember {
    mutableStateOf(
        mutableListOf(
            "Mabuhay! I am your Philippine Airlines virtual travel assistant. How can I assist you with your flight PAL784 today?"
        )
    )
  }

  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("PAL Support & AI Assistant", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
      LazyColumn(
          modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(chatMessages) { msg ->
          Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (msg.startsWith("Mabuhay!")) MaterialTheme.colorScheme.surfaceVariant else PalNavy,
              modifier = Modifier.fillMaxWidth()
          ) {
            Text(
                text = msg,
                modifier = Modifier.padding(14.dp),
                color = if (msg.startsWith("Mabuhay!")) MaterialTheme.colorScheme.onSurface else Color.White,
                fontSize = 14.sp
            )
          }
        }
      }

      Row(
          modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
            value = messageInput,
            onValueChange = { messageInput = it },
            placeholder = { Text("Ask about baggage, check-in, or miles...") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
        )
        IconButton(
            onClick = {
              if (messageInput.isNotBlank()) {
                val list = chatMessages.toMutableList()
                list.add("You: $messageInput")
                list.add("PAL Assistant: I have noted your request regarding '$messageInput'. For security reasons, changes to confirmed bookings require backend verification in the Manage Trip section.")
                chatMessages = list
                messageInput = ""
              }
            },
            modifier = Modifier.background(PalRed, CircleShape)
        ) {
          Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoSandboxScreen(
    onNavigateBack: () -> Unit
) {
  Scaffold(
      topBar = {
        TopAppBar(
            title = { Text("16 Demonstration Scenarios Sandbox", fontWeight = FontWeight.Bold) },
            navigationIcon = {
              IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      val scenarios = listOf(
          "1. Search for a return journey (Manila to Tokyo)",
          "2. Compare two fare options (Economy Saver vs Value)",
          "3. Enter passenger details & travel documents",
          "4. Select seats and baggage extras",
          "5. Review full price breakdown & taxes",
          "6. Complete simulated payment (IDEMPOTENCY verified)",
          "7. Observe reservation and ticketing status confirmation",
          "8. Retrieve trip via PNR and last name",
          "9. Complete simulated check-in and document verification",
          "10. Save demonstration boarding pass with non-operational barcode",
          "11. Receive simulated schedule change notification",
          "12. Review and accept replacement itinerary",
          "13. Handle expired offer scenario",
          "14. Handle unavailable seat conflict",
          "15. Handle payment timeout & reconciliation",
          "16. Auditable Mabuhay Miles activity ledger inspection"
      )

      items(scenarios) { s ->
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Row(
              modifier = Modifier.fillMaxWidth().padding(16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
          ) {
            Text(s, fontWeight = FontWeight.Medium, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
          }
        }
      }
    }
  }
}
