package com.example.ui.screens

import androidx.compose.runtime.*
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun PALAppRoot() {
  val navController = rememberNavController()

  NavHost(navController = navController, startDestination = "home") {
    composable("home") {
      HomeScreen(
          onNavigate = { route -> navController.navigate(route) }
      )
    }
    composable("search") {
      FlightSearchScreen(
          onNavigateBack = { navController.popBackStack() },
          onSearchExecuted = { origin, dest, cabin ->
            navController.navigate("results/$origin/$dest/$cabin")
          }
      )
    }
    composable(
        route = "results/{origin}/{destination}/{cabin}",
        arguments = listOf(
            navArgument("origin") { type = NavType.StringType },
            navArgument("destination") { type = NavType.StringType },
            navArgument("cabin") { type = NavType.StringType }
        )
    ) { backStackEntry ->
      val origin = backStackEntry.arguments?.getString("origin") ?: "MNL"
      val destination = backStackEntry.arguments?.getString("destination") ?: "NRT"
      val cabin = backStackEntry.arguments?.getString("cabin") ?: "Economy"
      FlightResultsScreen(
          origin = origin,
          destination = destination,
          cabin = cabin,
          onNavigateBack = { navController.popBackStack() },
          onSelectFlight = { flight, cab ->
            navController.navigate("booking/${flight.id}/$cab")
          }
      )
    }
    composable(
        route = "booking/{flightId}/{cabin}",
        arguments = listOf(
            navArgument("flightId") { type = NavType.StringType },
            navArgument("cabin") { type = NavType.StringType }
        )
    ) { backStackEntry ->
      val flightId = backStackEntry.arguments?.getString("flightId") ?: "PR422"
      val cabin = backStackEntry.arguments?.getString("cabin") ?: "Economy"
      BookingWorkflowScreen(
          flightId = flightId,
          cabin = cabin,
          onNavigateBack = { navController.popBackStack() },
          onBookingComplete = { pnr ->
            navController.navigate("manage/$pnr") {
              popUpTo("home")
            }
          }
      )
    }
    composable("manage") {
      ManageBookingScreen(
          initialPnr = "PAL784",
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable(
        route = "manage/{pnr}",
        arguments = listOf(navArgument("pnr") { type = NavType.StringType })
    ) { backStackEntry ->
      val pnr = backStackEntry.arguments?.getString("pnr") ?: "PAL784"
      ManageBookingScreen(
          initialPnr = pnr,
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable("checkin") {
      CheckInScreen(
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable("status") {
      FlightStatusScreen(
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable("disruptions") {
      DisruptionScreen(
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable("loyalty") {
      MabuhayMilesScreen(
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable("notifications") {
      NotificationsScreen(
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable("support") {
      SupportChatScreen(
          onNavigateBack = { navController.popBackStack() }
      )
    }
    composable("sandbox") {
      DemoSandboxScreen(
          onNavigateBack = { navController.popBackStack() }
      )
    }
  }
}
