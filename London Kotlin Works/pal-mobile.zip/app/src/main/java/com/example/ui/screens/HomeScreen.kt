package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PALRepository
import com.example.model.Booking
import com.example.ui.theme.PalNavy
import com.example.ui.theme.PalNavyDark
import com.example.ui.theme.PalBlue
import com.example.ui.theme.PalRed
import com.example.ui.theme.PalGold
import com.example.ui.theme.PalGoldLight

data class DestinationItem(val city: String, val country: String, val price: String, val tag: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigate: (String) -> Unit
) {
  val bookings by PALRepository.bookings.collectAsState()
  val loyalty by PALRepository.loyalty.collectAsState()
  val upcomingBooking = bookings.firstOrNull { it.bookingStatus == "Confirmed" }

  val destinations = listOf(
      DestinationItem("Tokyo", "Japan", "₱14,500", "Cherry Blossoms"),
      DestinationItem("Los Angeles", "USA", "₱48,500", "Direct Flight"),
      DestinationItem("Cebu", "Philippines", "₱3,200", "Queen City"),
      DestinationItem("Davao", "Philippines", "₱3,800", "Durian Capital")
  )

  Scaffold(
      topBar = {
        TopAppBar(
            title = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = PalRed,
                    modifier = Modifier.size(32.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Flight, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                  }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text("Philippine Airlines", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                  Text("Mabuhay, ${loyalty.fullName.split(" ").first()}!", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }
              }
            },
            actions = {
              IconButton(onClick = { onNavigate("notifications") }) {
                BadgedBox(
                    badge = { Badge { Text("1") } }
                ) {
                  Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                }
              }
              IconButton(onClick = { onNavigate("loyalty") }) {
                Icon(Icons.Default.CardMembership, contentDescription = "Mabuhay Miles", tint = PalGold)
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )
      }
  ) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      // Hero Banner with SUNBURST Motif feeling
      Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = Color.Transparent),
          modifier = Modifier.fillMaxWidth()
      ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(PalNavy, Color(0xFF0D47A1), Color(0xFF1565C0))
                    )
                )
                .padding(20.dp)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                  color = PalGold,
                  shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                    text = loyalty.tier.uppercase(),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = PalNavyDark
                )
              }
              Text(
                  text = "${loyalty.redeemableMiles} Miles",
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Fly with Filipino Pride",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Experience heart-of-the-filipino hospitality across the globe.",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { onNavigate("search") },
                colors = ButtonDefaults.buttonColors(containerColor = PalRed),
                shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.FlightTakeoff, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Book Your Journey Now", fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // Quick Actions Grid
      Text("Quick Services", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)

      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
      ) {
        QuickActionButton(Icons.Default.Search, "Book Flight", PalNavy) { onNavigate("search") }
        QuickActionButton(Icons.Default.BookOnline, "Manage Trip", PalBlue) { onNavigate("manage") }
        QuickActionButton(Icons.Default.CheckCircle, "Check-In", Color(0xFF2E7D32)) { onNavigate("checkin") }
        QuickActionButton(Icons.Default.Schedule, "Flight Status", Color(0xFFEF6C00)) { onNavigate("status") }
      }

      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
      ) {
        QuickActionButton(Icons.Default.CardMembership, "Mabuhay Miles", PalGold) { onNavigate("loyalty") }
        QuickActionButton(Icons.Default.WarningAmber, "Disruptions", PalRed) { onNavigate("disruptions") }
        QuickActionButton(Icons.Default.SupportAgent, "Support & AI", PalNavy) { onNavigate("support") }
        QuickActionButton(Icons.Default.Science, "Demo Sandbox", Color(0xFF6A1B9A)) { onNavigate("sandbox") }
      }

      // Upcoming Trip Card
      if (upcomingBooking != null) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Upcoming Journey", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
            TextButton(onClick = { onNavigate("manage") }) {
              Text("View PNR: ${upcomingBooking.pnr}")
            }
          }

          Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              modifier = Modifier
                  .fillMaxWidth()
                  .clickable { onNavigate("manage") }
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = PalNavy, modifier = Modifier.size(20.dp))
                  Text(upcomingBooking.flights.first().flightNumber, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Surface(
                    color = if (upcomingBooking.checkedIn) Color(0xFF2E7D32) else PalRed,
                    shape = RoundedCornerShape(6.dp)
                ) {
                  Text(
                      text = if (upcomingBooking.checkedIn) "Checked In" else "Confirmed",
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                      color = Color.White,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold
                  )
                }
              }

              Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(upcomingBooking.flights.first().origin.code, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = PalNavy)
                  Text(upcomingBooking.flights.first().origin.city, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(upcomingBooking.flights.first().departureTime, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Icon(Icons.Default.Flight, contentDescription = null, tint = PalRed, modifier = Modifier.size(24.dp))
                  Text(upcomingBooking.flights.first().duration, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(upcomingBooking.flights.first().destination.code, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = PalNavy)
                  Text(upcomingBooking.flights.first().destination.city, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(upcomingBooking.flights.first().arrivalTime, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
              }

              Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

              Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
              ) {
                Text("Terminal ${upcomingBooking.flights.first().origin.terminal} • Passenger: ${upcomingBooking.passengers.first().firstName}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(
                    onClick = { onNavigate("checkin") },
                    colors = ButtonDefaults.buttonColors(containerColor = PalNavy),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                  Text(if (upcomingBooking.checkedIn) "Boarding Pass" else "Check In Now", fontSize = 12.sp)
                }
              }
            }
          }
        }
      }

      // Destination Discovery
      Text("Destination Discovery", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)

      LazyRow(
          horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(destinations) { dest ->
          Card(
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier
                  .width(160.dp)
                  .height(180.dp)
                  .clickable { onNavigate("search") },
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
              Surface(
                  color = PalGoldLight,
                  shape = RoundedCornerShape(6.dp)
              ) {
                Text(dest.tag, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PalNavy)
              }
              Column {
                Text(dest.city, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(dest.country, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Text("From ${dest.price}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PalRed)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun QuickActionButton(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
  Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier
          .width(76.dp)
          .clickable(onClick = onClick)
  ) {
    Surface(
        shape = CircleShape,
        color = color.copy(alpha = 0.12f),
        modifier = Modifier.size(52.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(24.dp))
      }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
        text = label,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1
    )
  }
}
