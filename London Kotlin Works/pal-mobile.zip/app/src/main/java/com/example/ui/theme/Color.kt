package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PalNavy = Color(0xFF002060)
val PalNavyDark = Color(0xFF0A1530)
val PalBlue = Color(0xFF0D47A1)
val PalRed = Color(0xFFCE1126)
val PalGold = Color(0xFFFFC72C)
val PalGoldLight = Color(0xFFFFF8E1)

val PrimaryLight = Color(0xFF002060)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFD4E3FC)
val OnPrimaryContainerLight = Color(0xFF001B3D)

val SecondaryLight = Color(0xFFCE1126)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFDAD6)
val OnSecondaryContainerLight = Color(0xFF410002)

val TertiaryLight = Color(0xFF755B00)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFFEEBE)
val OnTertiaryContainerLight = Color(0xFF241A00)

val BackgroundLight = Color(0xFFF8F9FC)
val OnBackgroundLight = Color(0xFF1A1C1E)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF1A1C1E)

val PrimaryDark = Color(0xFFA4C2F4)
val OnPrimaryDark = Color(0xFF002F6C)
val PrimaryContainerDark = Color(0xFF00458E)
val OnPrimaryContainerDark = Color(0xFFD4E3FC)

val SecondaryDark = Color(0xFFFFB4AB)
val OnSecondaryDark = Color(0xFF690005)
val SecondaryContainerDark = Color(0xFF93000A)
val OnSecondaryContainerDark = Color(0xFFFFDAD6)

val BackgroundDark = Color(0xFF111318)
val OnBackgroundDark = Color(0xFFE2E2E6)
val SurfaceDark = Color(0xFF111318)
val OnSurfaceDark = Color(0xFFE2E2E6)
