package com.example

import com.example.data.RestaurantRepository
import com.example.engine.WaitTimeIntelligenceEngine
import com.example.model.AppRole
import com.example.model.SeatingPreference
import com.example.model.TableStatus
import com.example.model.WaitlistStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BJsWaitlistPlatformTest {

    @Test
    fun testWaitTimeIntelligenceEngineCalculation() {
        val tables = RestaurantRepository.state.value.tables
        val queue = RestaurantRepository.state.value.waitlist

        val prediction = WaitTimeIntelligenceEngine.calculatePrediction(
            partySize = 4,
            preference = SeatingPreference.BOOTH,
            currentQueue = queue,
            tables = tables,
            servicePeriod = "Dinner Peak"
        )

        assertNotNull(prediction)
        assertTrue("Lower bound must be <= upper bound", prediction.lowerBound <= prediction.upperBound)
        assertTrue("Prediction must be at least 3 minutes", prediction.predictedMinutes >= 3)
        assertTrue("Confidence score must be between 0.70 and 1.0", prediction.confidenceScore in 0.70..1.0)
        assertEquals("WTE-v3.8-Hybrid", prediction.modelVersion)
    }

    @Test
    fun testJoinWaitlistFlow() {
        val initialCount = RestaurantRepository.state.value.waitlist.size

        val entry = RestaurantRepository.joinWaitlist(
            guestName = "Jonathan Davis",
            phone = "(949) 555-4921",
            email = "jdavis@example.com",
            partySize = 4,
            preference = SeatingPreference.BOOTH,
            notes = "Anniversary dessert celebration"
        )

        assertNotNull(entry)
        assertTrue(entry.confirmationCode.startsWith("BJ-"))
        assertEquals("Jonathan Davis", entry.guestName)
        assertEquals(4, entry.partySize)
        assertEquals(SeatingPreference.BOOTH, entry.seatingPreference)
        assertEquals(WaitlistStatus.WAITING, entry.status)
        assertFalse(entry.entirePartyPresent)
        assertTrue("QR token must be non-empty SHA-256 hash", entry.qrSecurityToken.isNotEmpty())
        assertEquals("Waitlist count should increment", initialCount + 1, RestaurantRepository.state.value.waitlist.size)
    }

    @Test
    fun testConfirmPartyArrival() {
        val entry = RestaurantRepository.joinWaitlist(
            guestName = "Taylor Swift",
            phone = "(714) 555-1313",
            email = "tswift@example.com",
            partySize = 2,
            preference = SeatingPreference.STANDARD,
            notes = ""
        )

        assertFalse(entry.entirePartyPresent)
        RestaurantRepository.confirmEntirePartyPresent(entry.id)

        val updated = RestaurantRepository.state.value.waitlist.find { it.id == entry.id }
        assertNotNull(updated)
        assertTrue(updated!!.entirePartyPresent)
    }

    @Test
    fun testUpdatePartySizeRecalculation() {
        val entry = RestaurantRepository.joinWaitlist(
            guestName = "Chris Evans",
            phone = "(949) 555-8822",
            email = "",
            partySize = 2,
            preference = SeatingPreference.STANDARD,
            notes = ""
        )

        RestaurantRepository.updatePartySize(entry.id, 6)

        val updated = RestaurantRepository.state.value.waitlist.find { it.id == entry.id }
        assertNotNull(updated)
        assertEquals(6, updated!!.partySize)
    }

    @Test
    fun testReservationCheckIn() {
        // Valid reservation RES-7102 (Michael Scott)
        val validResult = RestaurantRepository.checkInReservation("RES-7102")
        assertTrue("Valid reservation should succeed", validResult.isSuccess)
        assertEquals("Michael Scott", validResult.getOrNull()?.guestName)
        assertTrue(validResult.getOrNull()?.isCheckedIn == true)

        // Invalid reservation
        val invalidResult = RestaurantRepository.checkInReservation("RES-9999999")
        assertTrue("Invalid reservation should fail", invalidResult.isFailure)
    }

    @Test
    fun testTableAssignmentAndSeatingLifecycle() {
        val entry = RestaurantRepository.joinWaitlist(
            guestName = "Alice Wonderland",
            phone = "(949) 555-1111",
            email = "",
            partySize = 4,
            preference = SeatingPreference.STANDARD,
            notes = ""
        )

        // Find an available table
        val availableTable = RestaurantRepository.state.value.tables.first { it.status == TableStatus.AVAILABLE }

        // Assign table
        RestaurantRepository.assignTable(entry.id, availableTable.id)

        var updatedEntry = RestaurantRepository.state.value.waitlist.find { it.id == entry.id }
        var updatedTable = RestaurantRepository.state.value.tables.find { it.id == availableTable.id }

        assertEquals(WaitlistStatus.READY_TO_BE_SEATED, updatedEntry?.status)
        assertEquals(TableStatus.AWAITING_GUESTS, updatedTable?.status)
        assertEquals(availableTable.tableNumber, updatedEntry?.assignedTableNumber)

        // Complete Seating
        RestaurantRepository.completeSeating(entry.id, availableTable.id)

        updatedEntry = RestaurantRepository.state.value.waitlist.find { it.id == entry.id }
        updatedTable = RestaurantRepository.state.value.tables.find { it.id == availableTable.id }

        assertEquals(WaitlistStatus.SEATED, updatedEntry?.status)
        assertEquals(TableStatus.OCCUPIED, updatedTable?.status)

        // Clean table
        RestaurantRepository.markTableCleaned(availableTable.id)
        updatedTable = RestaurantRepository.state.value.tables.find { it.id == availableTable.id }
        assertEquals(TableStatus.AVAILABLE, updatedTable?.status)
    }

    @Test
    fun testRoleSwitchingAndAuditTrail() {
        RestaurantRepository.switchRole(AppRole.CORPORATE_ADMIN)
        assertEquals(AppRole.CORPORATE_ADMIN, RestaurantRepository.state.value.currentRole)

        val latestAudit = RestaurantRepository.state.value.auditLog.first()
        assertEquals("ROLE_SWITCHED", latestAudit.eventType)

        RestaurantRepository.switchRole(AppRole.GUEST)
        assertEquals(AppRole.GUEST, RestaurantRepository.state.value.currentRole)
    }
}
