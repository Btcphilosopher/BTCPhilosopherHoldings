package com.example.ui.guest

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableRestaurant
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TabRow
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.PlatformState
import com.example.data.RestaurantRepository
import com.example.model.Reservation
import com.example.model.Restaurant
import com.example.model.SeatingPreference
import com.example.model.WaitlistEntry
import com.example.model.WaitlistStatus
import com.example.ui.components.StylizedQRCode
import com.example.ui.components.WaitlistStatusBadge
import com.example.ui.theme.BJsAmberPrimary
import com.example.ui.theme.BJsCharcoalDark
import com.example.ui.theme.BJsCreamBackground
import com.example.ui.theme.BJsRubyRed
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusPreparing
import com.example.ui.theme.StatusWaiting

@Composable
fun GuestScreen(
    state: PlatformState,
    onJoinWaitlist: (String, String, String, Int, SeatingPreference, String) -> WaitlistEntry,
    onConfirmPartyArrival: (String) -> Unit,
    onUpdatePartySize: (String, Int) -> Unit,
    onCancelWaitlist: (String) -> Unit,
    onCheckInReservation: (String) -> Result<Reservation>,
    onSelectRestaurant: (Restaurant) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Live Visit", "Join Waitlist", "Find Locations", "Reservations")

    // If guest has an active entry, default to Tab 0 (Live Visit)
    val activeGuestEntry = state.waitlist.find { it.id == state.activeGuestEntryId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BJsCreamBackground)
            .testTag("guest_screen_root")
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = BJsCharcoalDark,
            contentColor = BJsAmberPrimary
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    modifier = Modifier.testTag("guest_tab_$index"),
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) BJsAmberPrimary else Color.White.copy(alpha = 0.7f)
                        )
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> LiveVisitTab(
                entry = activeGuestEntry,
                allEntries = state.waitlist,
                onSwitchToJoin = { selectedTab = 1 },
                onConfirmArrival = { activeGuestEntry?.id?.let(onConfirmPartyArrival) },
                onUpdatePartySize = { newSize -> activeGuestEntry?.id?.let { onUpdatePartySize(it, newSize) } },
                onCancel = { activeGuestEntry?.id?.let(onCancelWaitlist) }
            )
            1 -> JoinWaitlistWizard(
                selectedRestaurant = state.selectedRestaurant,
                onComplete = { name, phone, email, size, pref, notes ->
                    onJoinWaitlist(name, phone, email, size, pref, notes)
                    selectedTab = 0 // Navigate to live visit
                }
            )
            2 -> RestaurantDiscoveryTab(
                selectedRestaurant = state.selectedRestaurant,
                restaurants = state.restaurants,
                onSelectRestaurant = onSelectRestaurant,
                onProceedToWaitlist = { selectedTab = 1 }
            )
            3 -> ReservationCheckInTab(
                reservations = state.reservations,
                onCheckIn = onCheckInReservation,
                onViewVisit = { selectedTab = 0 }
            )
        }
    }
}

// -------------------------------------------------------------
// TAB 0: LIVE VISIT & WAITLIST PROGRESS SCREEN
// -------------------------------------------------------------

@Composable
fun LiveVisitTab(
    entry: WaitlistEntry?,
    allEntries: List<WaitlistEntry>,
    onSwitchToJoin: () -> Unit,
    onConfirmArrival: () -> Unit,
    onUpdatePartySize: (Int) -> Unit,
    onCancel: () -> Unit
) {
    if (entry == null || entry.status == WaitlistStatus.CANCELLED) {
        // Empty state when guest hasn't joined queue yet
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.bjs_hero),
                            contentDescription = "BJ's Dining Room",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "No Active Waitlist Entry",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = BJsCharcoalDark
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Join our digital waitlist ahead of time or check in for your reservation to skip the line.",
                            fontSize = 14.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onSwitchToJoin,
                            colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                            modifier = Modifier.fillMaxWidth().testTag("join_waitlist_empty_cta")
                        ) {
                            Icon(Icons.Default.HourglassTop, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Join The Waitlist Now", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    var showPartySizeDialog by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Status Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("live_status_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BJsCharcoalDark),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "LIVE QUEUE STATUS",
                                color = BJsAmberPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = entry.guestName,
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        WaitlistStatusBadge(status = entry.status)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress Bar Stepper
                    QueueProgressStepper(currentStatus = entry.status)

                    Spacer(modifier = Modifier.height(18.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(14.dp))

                    // Key Metrics Row: Queue Position, Estimated Wait, Party Size
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Position", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                            Text(
                                text = "#${entry.positionInQueue}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }

                        Column {
                            Text("Estimated Wait", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                            Text(
                                text = "${entry.estimatedWaitMin}–${entry.estimatedWaitMax} min",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = BJsAmberPrimary
                            )
                        }

                        Column {
                            Text("Party Size", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                            Text(
                                text = "${entry.partySize} Guests",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                    }

                    if (entry.assignedTableNumber != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = StatusAvailable.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StatusAvailable)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.TableRestaurant, contentDescription = null, tint = StatusAvailable)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Your table is ready: ${entry.assignedTableNumber}! Please see the host stand.",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action: Arrival confirmation button
        item {
            if (!entry.entirePartyPresent) {
                Button(
                    onClick = onConfirmArrival,
                    colors = ButtonDefaults.buttonColors(containerColor = BJsRubyRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("confirm_arrival_button")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "We've Arrived at the Restaurant",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            } else {
                Surface(
                    color = Color(0xFFDCFCE7),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF15803D))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                "Entire Party Confirmed Present",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF15803D)
                            )
                            Text(
                                "The host stand knows your party is in the lobby or bar area.",
                                fontSize = 12.sp,
                                color = Color(0xFF166534)
                            )
                        }
                    }
                }
            }
        }

        // Digital Visit Pass Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("digital_visit_pass_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(3.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DIGITAL VISIT PASS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BJsAmberPrimary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Ref: ${entry.confirmationCode}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = BJsCharcoalDark
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Preference", fontSize = 11.sp, color = Color.Gray)
                            Text(
                                entry.seatingPreference.displayName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Check-In Time", fontSize = 11.sp, color = Color.Gray)
                            Text(entry.createdTimeString, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Contact SMS", fontSize = 11.sp, color = Color.Gray)
                            Text(entry.phone, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }

                        // QR Code representation
                        StylizedQRCode(
                            token = entry.qrSecurityToken,
                            sizeDp = 110,
                            modifier = Modifier.testTag("visit_qr_code")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Show this QR code at the host stand or self-service tablet to verify your arrival.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Notification History & SMS Audit
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = BJsAmberPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "SMS & Push Notifications",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = BJsCharcoalDark
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (entry.notificationHistory.isEmpty()) {
                        Text("No notifications dispatched yet.", fontSize = 12.sp, color = Color.Gray)
                    } else {
                        entry.notificationHistory.forEach { notif ->
                            Surface(
                                color = Color(0xFFF9F6F0),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(notif.templateTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(notif.timestamp, fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(notif.messageBody, fontSize = 12.sp, color = Color(0xFF333333))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Status: ${notif.status} via ${notif.channel}",
                                        fontSize = 10.sp,
                                        color = Color(0xFF15803D),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Guest Control Actions: Change party size, cancel, help
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showPartySizeDialog = true },
                    modifier = Modifier.weight(1f).testTag("modify_party_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Modify Party", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { showHelpDialog = true },
                    modifier = Modifier.weight(1f).testTag("help_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Assistance", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { showCancelDialog = true },
                    modifier = Modifier.weight(1f).testTag("cancel_waitlist_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BJsRubyRed)
                ) {
                    Icon(Icons.Outlined.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cancel", fontSize = 12.sp)
                }
            }
        }
    }

    // Modify Party Size Dialog
    if (showPartySizeDialog) {
        var newPartySize by remember { mutableIntStateOf(entry.partySize) }
        AlertDialog(
            onDismissRequest = { showPartySizeDialog = false },
            title = { Text("Update Party Size") },
            text = {
                Column {
                    Text("Select your updated guest count. Note: Larger party sizes may adjust your estimated wait time.")
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        (1..8).forEach { size ->
                            Surface(
                                shape = CircleShape,
                                color = if (newPartySize == size) BJsAmberPrimary else Color(0xFFF0EBE1),
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .clickable { newPartySize = size }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "$size",
                                        fontWeight = FontWeight.Bold,
                                        color = if (newPartySize == size) Color.White else Color.Black
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdatePartySize(newPartySize)
                        showPartySizeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary)
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPartySizeDialog = false }) { Text("Close") }
            }
        )
    }

    // Cancel Dialog
    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = { Text("Cancel Waitlist Request?") },
            text = { Text("Are you sure you want to leave the waitlist? You will forfeit your position #${entry.positionInQueue}.") },
            confirmButton = {
                Button(
                    onClick = {
                        onCancel()
                        showCancelDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BJsRubyRed)
                ) {
                    Text("Yes, Cancel")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) { Text("Keep Place") }
            }
        )
    }

    // Assistance Dialog
    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("Host Stand Assistance") },
            text = {
                Column {
                    Text("Need special arrangements, high chairs, or have questions about wait times?")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("• Please step forward to the host stand desk", fontWeight = FontWeight.SemiBold)
                    Text("• Or call the restaurant desk directly at:")
                    Text("(949) 753-8700", fontWeight = FontWeight.Bold, color = BJsAmberPrimary)
                }
            },
            confirmButton = {
                Button(
                    onClick = { showHelpDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary)
                ) {
                    Text("Got It")
                }
            }
        )
    }
}

@Composable
fun QueueProgressStepper(currentStatus: WaitlistStatus) {
    val steps = listOf(
        WaitlistStatus.REQUEST_SUBMITTED,
        WaitlistStatus.WAITING,
        WaitlistStatus.APPROACHING,
        WaitlistStatus.TABLE_PREPARING,
        WaitlistStatus.READY_TO_BE_SEATED
    )

    val currentIndex = when (currentStatus) {
        WaitlistStatus.REQUEST_SUBMITTED, WaitlistStatus.CONFIRMED -> 0
        WaitlistStatus.WAITING -> 1
        WaitlistStatus.APPROACHING -> 2
        WaitlistStatus.TABLE_PREPARING -> 3
        WaitlistStatus.READY_TO_BE_SEATED, WaitlistStatus.SEATED -> 4
        else -> 1
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        steps.forEachIndexed { index, status ->
            val isCompleted = index <= currentIndex
            val isCurrent = index == currentIndex

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isCurrent -> BJsAmberPrimary
                                isCompleted -> Color(0xFF15803D)
                                else -> Color.White.copy(alpha = 0.2f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted && !isCurrent) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    } else {
                        Text(
                            text = "${index + 1}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = when (status) {
                        WaitlistStatus.REQUEST_SUBMITTED -> "Submitted"
                        WaitlistStatus.WAITING -> "Waiting"
                        WaitlistStatus.APPROACHING -> "Near"
                        WaitlistStatus.TABLE_PREPARING -> "Preparing"
                        WaitlistStatus.READY_TO_BE_SEATED -> "Ready!"
                        else -> ""
                    },
                    fontSize = 9.sp,
                    color = if (isCompleted) Color.White else Color.White.copy(alpha = 0.5f),
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .height(2.dp)
                        .weight(0.6f)
                        .background(if (index < currentIndex) Color(0xFF15803D) else Color.White.copy(alpha = 0.2f))
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 1: JOIN WAITLIST 5-STEP WIZARD
// -------------------------------------------------------------

@Composable
fun JoinWaitlistWizard(
    selectedRestaurant: Restaurant,
    onComplete: (String, String, String, Int, SeatingPreference, String) -> Unit
) {
    var step by remember { mutableIntStateOf(1) }

    var partySize by remember { mutableIntStateOf(2) }
    var seatingPreference by remember { mutableStateOf(SeatingPreference.STANDARD) }
    var guestName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var smsConsent by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp).testTag("join_waitlist_wizard"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Step progress header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "STEP $step OF 4",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BJsAmberPrimary
                        )
                        Text(
                            text = when (step) {
                                1 -> "Select Party Size"
                                2 -> "Seating Preferences"
                                3 -> "Guest Contact Information"
                                else -> "Review & Confirmation"
                            },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = BJsCharcoalDark
                        )
                    }

                    Surface(
                        color = Color(0xFFF5EFE6),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = selectedRestaurant.city,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        when (step) {
            1 -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "How many guests in your party?",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = BJsCharcoalDark
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            // Grid of party sizes 1 to 10
                            val sizes = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                sizes.take(5).forEach { size ->
                                    val isSelected = partySize == size
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) BJsAmberPrimary else Color(0xFFF4EFEA),
                                        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDED6CB)),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(50.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { partySize = size }
                                            .testTag("party_size_$size")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "$size",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp,
                                                color = if (isSelected) Color.White else BJsCharcoalDark
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                sizes.drop(5).forEach { size ->
                                    val isSelected = partySize == size
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) BJsAmberPrimary else Color(0xFFF4EFEA),
                                        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDED6CB)),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(50.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { partySize = size }
                                            .testTag("party_size_$size")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "$size",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp,
                                                color = if (isSelected) Color.White else BJsCharcoalDark
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 11+ Guests Option
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (partySize >= 11) BJsAmberPrimary else Color(0xFFF4EFEA),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { partySize = 12 }
                                    .testTag("party_size_large")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "11+ Guests (Large Party Coordinator)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (partySize >= 11) Color.White else BJsCharcoalDark
                                    )
                                }
                            }

                            if (partySize >= 11) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Parties of 11+ are accommodated with combined tables or private event seating. A host will review your request immediately.",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { step = 2 },
                        colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("step_1_next")
                    ) {
                        Text("Next: Seating Preferences", fontWeight = FontWeight.Bold)
                    }
                }
            }

            2 -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "Seating Preferences",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = BJsCharcoalDark
                            )
                            Text(
                                text = "Preferences are treated as requests and accommodated whenever possible, not guaranteed.",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            SeatingPreference.values().forEach { pref ->
                                val isSelected = seatingPreference == pref
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) Color(0xFFFEF3C7) else Color(0xFFFAF7F2),
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) BJsAmberPrimary else Color(0xFFE2DCD5)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { seatingPreference = pref }
                                        .testTag("pref_${pref.name}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { seatingPreference = pref },
                                            colors = RadioButtonDefaults.colors(selectedColor = BJsAmberPrimary)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(pref.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text(pref.iconDescription, fontSize = 11.sp, color = Color.Gray)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { step = 1 },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(50.dp)
                        ) {
                            Text("Back")
                        }
                        Button(
                            onClick = { step = 3 },
                            colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(50.dp).testTag("step_2_next")
                        ) {
                            Text("Next: Contact Info", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            3 -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "Guest Information",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = BJsCharcoalDark
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = guestName,
                                onValueChange = { guestName = it },
                                label = { Text("First & Last Name *") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("guest_name_input"),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BJsAmberPrimary)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("Mobile Phone Number (for SMS notifications) *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("guest_phone_input"),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BJsAmberPrimary)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it },
                                label = { Text("Email Address (Optional)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("guest_email_input"),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BJsAmberPrimary)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = notes,
                                onValueChange = { notes = it },
                                label = { Text("Visit Notes (e.g. High chair, birthday, booster)") },
                                maxLines = 2,
                                modifier = Modifier.fillMaxWidth().testTag("guest_notes_input"),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BJsAmberPrimary)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { smsConsent = !smsConsent }
                            ) {
                                Checkbox(
                                    checked = smsConsent,
                                    onCheckedChange = { smsConsent = it },
                                    colors = CheckboxDefaults.colors(checkedColor = BJsAmberPrimary)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "I agree to receive queue status SMS notifications from BJ's Restaurants. Standard msg & data rates may apply.",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { step = 2 },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(50.dp)
                        ) {
                            Text("Back")
                        }
                        Button(
                            onClick = { step = 4 },
                            enabled = guestName.isNotBlank() && phone.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(50.dp).testTag("step_3_next")
                        ) {
                            Text("Review & Confirm", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            4 -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                "Confirm Waitlist Request",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = BJsCharcoalDark
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            SummaryRow("Location", selectedRestaurant.name)
                            SummaryRow("Party Size", "$partySize Guests")
                            SummaryRow("Seating Request", seatingPreference.displayName)
                            SummaryRow("Guest Name", guestName)
                            SummaryRow("Mobile Phone", phone)
                            if (notes.isNotBlank()) {
                                SummaryRow("Special Notes", notes)
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(14.dp))

                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Alarm, contentDescription = null, tint = BJsAmberPrimary)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            "Estimated Wait: ${selectedRestaurant.estimatedWaitMinutes}–${selectedRestaurant.estimatedWaitMinutes + 10} Minutes",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF78350F)
                                        )
                                        Text(
                                            "Calculated by BJ's Wait-Time Intelligence Engine (WTE-v3.8).",
                                            fontSize = 11.sp,
                                            color = Color(0xFF92400E)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { step = 3 },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(50.dp)
                        ) {
                            Text("Back")
                        }
                        Button(
                            onClick = {
                                onComplete(
                                    guestName.trim(),
                                    phone.trim(),
                                    email.trim(),
                                    partySize,
                                    seatingPreference,
                                    notes.trim()
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BJsRubyRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).height(50.dp).testTag("confirm_join_waitlist")
                        ) {
                            Text("Confirm & Join", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = Color.Gray)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = BJsCharcoalDark)
    }
}

// -------------------------------------------------------------
// TAB 2: RESTAURANT DISCOVERY
// -------------------------------------------------------------

@Composable
fun RestaurantDiscoveryTab(
    selectedRestaurant: Restaurant,
    restaurants: List<Restaurant>,
    onSelectRestaurant: (Restaurant) -> Unit,
    onProceedToWaitlist: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredRestaurants = remember(searchQuery, restaurants) {
        if (searchQuery.isBlank()) restaurants
        else restaurants.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.city.contains(searchQuery, ignoreCase = true) ||
                    it.zip.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp).testTag("restaurant_discovery_tab"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Search bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search by City, Postcode, or Name") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("search_restaurant_field"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )
        }

        items(filteredRestaurants) { restaurant ->
            val isSelected = restaurant.id == selectedRestaurant.id
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectRestaurant(restaurant) }
                    .testTag("restaurant_card_${restaurant.id}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, BJsAmberPrimary) else null,
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = restaurant.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = BJsCharcoalDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${restaurant.address}, ${restaurant.city}, ${restaurant.state} ${restaurant.zip}",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                            Text(
                                text = "${restaurant.distanceMiles} miles away • ${restaurant.hours}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        if (isSelected) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = BJsAmberPrimary
                            ) {
                                Text(
                                    "Selected",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Color(0xFFF0EBE1))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (restaurant.isLiveQueueEnabled) Icons.Default.HourglassTop else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (restaurant.isLiveQueueEnabled) BJsAmberPrimary else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (restaurant.isLiveQueueEnabled)
                                    "Est. Wait: ${restaurant.displayWait} (${restaurant.activeWaitlistCount} parties)"
                                else "Live Wait Times Unavailable",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (restaurant.isLiveQueueEnabled) Color(0xFF78350F) else Color.Gray
                            )
                        }

                        if (isSelected && restaurant.isLiveQueueEnabled) {
                            Button(
                                onClick = onProceedToWaitlist,
                                colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Join Waitlist", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TAB 3: RESERVATION CHECK-IN
// -------------------------------------------------------------

@Composable
fun ReservationCheckInTab(
    reservations: List<Reservation>,
    onCheckIn: (String) -> Result<Reservation>,
    onViewVisit: () -> Unit
) {
    var searchCode by remember { mutableStateOf("") }
    var checkInResult by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp).testTag("reservation_tab"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Check In For Existing Reservation",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = BJsCharcoalDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Enter your reservation confirmation number (e.g. RES-7102) or phone number to announce your arrival.",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = searchCode,
                        onValueChange = { searchCode = it },
                        label = { Text("Reservation Code or Phone") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("reservation_code_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BJsAmberPrimary)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val res = onCheckIn(searchCode)
                            if (res.isSuccess) {
                                isSuccess = true
                                checkInResult = "Checked in! Welcome, ${res.getOrNull()?.guestName}. Host stand has been notified."
                            } else {
                                isSuccess = false
                                checkInResult = res.exceptionOrNull()?.message ?: "Check-in failed"
                            }
                        },
                        enabled = searchCode.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("checkin_reservation_button")
                    ) {
                        Text("Check In Now", fontWeight = FontWeight.Bold)
                    }

                    if (checkInResult != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            color = if (isSuccess) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = checkInResult!!,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSuccess) Color(0xFF15803D) else Color(0xFFB91C1C)
                                )
                                if (isSuccess) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    TextButton(onClick = onViewVisit) {
                                        Text("View Live Visit Status →", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Upcoming Reservations at this restaurant
        item {
            Text(
                "Sample Confirmed Bookings (Demo verification)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
        }

        items(reservations) { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(res.guestName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Code: ${res.confirmationCode} • ${res.partySize} Guests • ${res.reservationTimeString}",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }

                    if (res.isCheckedIn) {
                        Surface(
                            color = Color(0xFFDCFCE7),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                "Checked In",
                                color = Color(0xFF15803D),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                searchCode = res.confirmationCode
                                val result = onCheckIn(res.confirmationCode)
                                isSuccess = result.isSuccess
                                checkInResult = "Checked in ${res.guestName}!"
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Check In", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
