package com.example.data

import com.example.engine.WaitTimeIntelligenceEngine
import com.example.model.AppRole
import com.example.model.AuditEvent
import com.example.model.CorporateMetrics
import com.example.model.NotificationRecord
import com.example.model.Reservation
import com.example.model.Restaurant
import com.example.model.RestaurantTable
import com.example.model.SeatingPreference
import com.example.model.TableStatus
import com.example.model.WaitlistEntry
import com.example.model.WaitlistStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.random.Random

data class PlatformState(
    val currentRole: AppRole = AppRole.GUEST,
    val selectedRestaurant: Restaurant,
    val restaurants: List<Restaurant>,
    val waitlist: List<WaitlistEntry>,
    val tables: List<RestaurantTable>,
    val reservations: List<Reservation>,
    val auditLog: List<AuditEvent>,
    val activeGuestEntryId: String? = null,
    val corporateMetrics: CorporateMetrics = CorporateMetrics(),
    val servicePeriod: String = "Dinner Peak",
    val toastMessage: String? = null
)

object RestaurantRepository {

    private val timeFormat = SimpleDateFormat("h:mm a", Locale.US)
    private val logTimeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    // Initial Restaurant Locations
    private val initialRestaurants = listOf(
        Restaurant(
            id = "bjs-irvine",
            name = "BJ's Restaurant & Brewhouse — Irvine Spectrum",
            address = "71 Fortune Dr, Suite 830",
            city = "Irvine",
            state = "CA",
            zip = "92618",
            phone = "(949) 753-8700",
            hours = "11:00 AM – 12:00 AM Daily",
            distanceMiles = 1.4,
            activeWaitlistCount = 7,
            estimatedWaitMinutes = 18,
            openTablesCount = 4,
            totalTablesCount = 28
        ),
        Restaurant(
            id = "bjs-dallas",
            name = "BJ's Restaurant & Brewhouse — Dallas NorthPark",
            address = "8687 N Central Expy",
            city = "Dallas",
            state = "TX",
            zip = "75225",
            phone = "(214) 363-2424",
            hours = "11:00 AM – 11:00 PM Daily",
            distanceMiles = 4.8,
            activeWaitlistCount = 11,
            estimatedWaitMinutes = 25,
            openTablesCount = 2,
            totalTablesCount = 26
        ),
        Restaurant(
            id = "bjs-orlando",
            name = "BJ's Restaurant & Brewhouse — Orlando Millenia",
            address = "4151 Conroy Rd",
            city = "Orlando",
            state = "FL",
            zip = "32839",
            phone = "(407) 352-0370",
            hours = "11:00 AM – 12:00 AM Daily",
            distanceMiles = 8.2,
            activeWaitlistCount = 5,
            estimatedWaitMinutes = 12,
            openTablesCount = 6,
            totalTablesCount = 30
        ),
        Restaurant(
            id = "bjs-denver",
            name = "BJ's Restaurant & Brewhouse — Denver Park Meadows",
            address = "9651 E County Line Rd",
            city = "Englewood",
            state = "CO",
            zip = "80112",
            phone = "(303) 799-6330",
            hours = "11:00 AM – 11:00 PM Daily",
            distanceMiles = 14.5,
            activeWaitlistCount = 8,
            estimatedWaitMinutes = 20,
            openTablesCount = 3,
            totalTablesCount = 24
        ),
        Restaurant(
            id = "bjs-polaris",
            name = "BJ's Restaurant & Brewhouse — Columbus Polaris",
            address = "1414 Polaris Pkwy",
            city = "Columbus",
            state = "OH",
            zip = "43240",
            phone = "(614) 840-0800",
            hours = "11:00 AM – 11:30 PM Daily",
            distanceMiles = 22.0,
            activeWaitlistCount = 0,
            estimatedWaitMinutes = 0,
            isLiveQueueEnabled = false, // Demonstrates graceful unavailable state handling
            openTablesCount = 8,
            totalTablesCount = 22
        )
    )

    // Initial Floor Plan Tables
    private val initialTables = listOf(
        // Main Dining Section
        RestaurantTable("t1", "T-01", "Main Dining", 4, TableStatus.AVAILABLE),
        RestaurantTable("t2", "T-02", "Main Dining", 4, TableStatus.OCCUPIED, "Smith", 4, 38, 55),
        RestaurantTable("t3", "T-03", "Main Dining", 2, TableStatus.AVAILABLE),
        RestaurantTable("t4", "T-04", "Main Dining", 6, TableStatus.OCCUPIED, "Henderson Party", 6, 52, 70, canCombineWith = "T-05"),
        RestaurantTable("t5", "T-05", "Main Dining", 6, TableStatus.AVAILABLE, canCombineWith = "T-04"),
        RestaurantTable("t6", "T-06", "Main Dining", 2, TableStatus.BEING_CLEANED),
        RestaurantTable("t7", "T-07", "Main Dining", 4, TableStatus.OCCUPIED, "Patel", 3, 20, 50),
        RestaurantTable("t8", "T-08", "Main Dining", 8, TableStatus.RESERVED, "Corporate Dinner", 8, 0, 90),

        // Brewhouse Booths Section
        RestaurantTable("b1", "BTH-01", "Brewhouse Booths", 4, TableStatus.OCCUPIED, "Miller", 4, 44, 60),
        RestaurantTable("b2", "BTH-02", "Brewhouse Booths", 4, TableStatus.AWAITING_GUESTS, "Rodriguez (Notified)", 4, 0, 55),
        RestaurantTable("b3", "BTH-03", "Brewhouse Booths", 6, TableStatus.OCCUPIED, "Gomez Family", 5, 15, 65),
        RestaurantTable("b4", "BTH-04", "Brewhouse Booths", 4, TableStatus.BEING_CLEANED),
        RestaurantTable("b5", "BTH-05", "Brewhouse Booths", 6, TableStatus.AVAILABLE),
        RestaurantTable("b6", "BTH-06", "Brewhouse Booths", 4, TableStatus.OCCUPIED, "Wong", 2, 48, 50),

        // Bar Lounge Section
        RestaurantTable("bar1", "BAR-01", "Bar Lounge", 2, TableStatus.AVAILABLE),
        RestaurantTable("bar2", "BAR-02", "Bar Lounge", 2, TableStatus.OCCUPIED, "Carter", 2, 28, 40),
        RestaurantTable("bar3", "BAR-03", "Bar Lounge", 4, TableStatus.OCCUPIED, "Alvarez", 4, 34, 45),
        RestaurantTable("bar4", "BAR-04", "Bar Lounge", 2, TableStatus.AVAILABLE),

        // Heated Patio Section
        RestaurantTable("p1", "PAT-01", "Heated Patio", 4, TableStatus.AVAILABLE),
        RestaurantTable("p2", "PAT-02", "Heated Patio", 4, TableStatus.OCCUPIED, "Taylor", 4, 22, 50),
        RestaurantTable("p3", "PAT-03", "Heated Patio", 6, TableStatus.OUT_OF_SERVICE),
        RestaurantTable("p4", "PAT-04", "Heated Patio", 4, TableStatus.AVAILABLE)
    )

    // Initial Waitlist Entries
    private val initialWaitlist = listOf(
        WaitlistEntry(
            id = "w-01",
            confirmationCode = "BJ-4819",
            restaurantId = "bjs-irvine",
            guestName = "Marcus Vance",
            phone = "(949) 555-0182",
            notes = "High chair requested for toddler",
            partySize = 4,
            seatingPreference = SeatingPreference.BOOTH,
            status = WaitlistStatus.TABLE_PREPARING,
            createdTimeString = "6:15 PM",
            estimatedWaitMin = 2,
            estimatedWaitMax = 5,
            positionInQueue = 1,
            entirePartyPresent = true,
            assignedTableNumber = "BTH-02",
            qrSecurityToken = generateOpaqueToken("w-01", "BJ-4819")
        ),
        WaitlistEntry(
            id = "w-02",
            confirmationCode = "BJ-4822",
            restaurantId = "bjs-irvine",
            guestName = "Sarah Chen",
            phone = "(714) 555-0931",
            notes = "Celebrating anniversary",
            partySize = 2,
            seatingPreference = SeatingPreference.NO_PREFERENCE,
            status = WaitlistStatus.APPROACHING,
            createdTimeString = "6:22 PM",
            estimatedWaitMin = 6,
            estimatedWaitMax = 10,
            positionInQueue = 2,
            entirePartyPresent = true,
            qrSecurityToken = generateOpaqueToken("w-02", "BJ-4822")
        ),
        WaitlistEntry(
            id = "w-03",
            confirmationCode = "BJ-4825",
            restaurantId = "bjs-irvine",
            guestName = "David Reynolds",
            phone = "(949) 555-8319",
            partySize = 6,
            seatingPreference = SeatingPreference.STANDARD,
            status = WaitlistStatus.WAITING,
            createdTimeString = "6:28 PM",
            estimatedWaitMin = 14,
            estimatedWaitMax = 20,
            positionInQueue = 3,
            entirePartyPresent = false,
            qrSecurityToken = generateOpaqueToken("w-03", "BJ-4825")
        ),
        WaitlistEntry(
            id = "w-04",
            confirmationCode = "BJ-4828",
            restaurantId = "bjs-irvine",
            guestName = "Elena Rostova",
            phone = "(949) 555-7724",
            notes = "Wheelchair accessibility requested",
            partySize = 3,
            seatingPreference = SeatingPreference.ACCESSIBLE,
            status = WaitlistStatus.WAITING,
            createdTimeString = "6:33 PM",
            estimatedWaitMin = 18,
            estimatedWaitMax = 25,
            positionInQueue = 4,
            entirePartyPresent = false,
            qrSecurityToken = generateOpaqueToken("w-04", "BJ-4828")
        )
    )

    // Initial Reservations for Check-in verification
    private val initialReservations = listOf(
        Reservation(
            id = "res-01",
            confirmationCode = "RES-7102",
            restaurantId = "bjs-irvine",
            guestName = "Michael Scott",
            phone = "(949) 555-3211",
            partySize = 6,
            reservationTimeString = "7:00 PM",
            seatingPreference = SeatingPreference.STANDARD,
            isCheckedIn = false
        ),
        Reservation(
            id = "res-02",
            confirmationCode = "RES-7105",
            restaurantId = "bjs-irvine",
            guestName = "Jessica Pearson",
            phone = "(949) 555-4422",
            partySize = 4,
            reservationTimeString = "7:15 PM",
            seatingPreference = SeatingPreference.BOOTH,
            isCheckedIn = false
        ),
        Reservation(
            id = "res-03",
            confirmationCode = "RES-7098",
            restaurantId = "bjs-irvine",
            guestName = "Robert Langdon",
            phone = "(714) 555-9081",
            partySize = 2,
            reservationTimeString = "6:30 PM",
            seatingPreference = SeatingPreference.BAR,
            isCheckedIn = true,
            arrivalTime = "6:25 PM"
        )
    )

    private val initialAudit = listOf(
        AuditEvent(
            timestamp = logTimeFormat.format(Date(System.currentTimeMillis() - 3600000)),
            eventType = "SYSTEM_INITIALIZED",
            actor = "System",
            details = "WTE Engine v3.8 active. Floor synchronizer running.",
            restaurantId = "bjs-irvine"
        ),
        AuditEvent(
            timestamp = logTimeFormat.format(Date(System.currentTimeMillis() - 1800000)),
            eventType = "WAITLIST_CREATED",
            actor = "Guest App",
            details = "Party of 4 (Marcus Vance) joined queue. Wait predicted 15-22 min.",
            restaurantId = "bjs-irvine"
        ),
        AuditEvent(
            timestamp = logTimeFormat.format(Date(System.currentTimeMillis() - 600000)),
            eventType = "GUEST_ARRIVED",
            actor = "Guest Mobile",
            details = "Marcus Vance confirmed entire party arrived at restaurant.",
            restaurantId = "bjs-irvine"
        )
    )

    private val _state = MutableStateFlow(
        PlatformState(
            currentRole = AppRole.GUEST,
            selectedRestaurant = initialRestaurants.first(),
            restaurants = initialRestaurants,
            waitlist = initialWaitlist,
            tables = initialTables,
            reservations = initialReservations,
            auditLog = initialAudit,
            activeGuestEntryId = "w-01" // Defaults to existing guest entry so user immediately sees live tracker
        )
    )

    val state: StateFlow<PlatformState> = _state.asStateFlow()

    // --- Actions ---

    fun switchRole(role: AppRole) {
        _state.update { it.copy(currentRole = role, toastMessage = "Switched to ${role.label}") }
        recordAudit("ROLE_SWITCHED", role.name, "Switched portal view to ${role.label}")
    }

    fun selectRestaurant(restaurant: Restaurant) {
        _state.update { it.copy(selectedRestaurant = restaurant, toastMessage = "Selected ${restaurant.name}") }
        recordAudit("RESTAURANT_SELECTED", "User", "Active restaurant changed to ${restaurant.id}")
    }

    fun clearToast() {
        _state.update { it.copy(toastMessage = null) }
    }

    /**
     * Join waitlist using genuine Wait-Time Intelligence Engine
     */
    fun joinWaitlist(
        guestName: String,
        phone: String,
        email: String,
        partySize: Int,
        preference: SeatingPreference,
        notes: String
    ): WaitlistEntry {
        val current = _state.value
        val prediction = WaitTimeIntelligenceEngine.calculatePrediction(
            partySize = partySize,
            preference = preference,
            currentQueue = current.waitlist,
            tables = current.tables,
            servicePeriod = current.servicePeriod
        )

        val code = "BJ-" + Random.nextInt(1000, 9999)
        val entryId = "w-" + UUID.randomUUID().toString().take(8)
        val qrToken = generateOpaqueToken(entryId, code)

        val newPosition = current.waitlist.count {
            it.status in listOf(WaitlistStatus.WAITING, WaitlistStatus.APPROACHING, WaitlistStatus.TABLE_PREPARING)
        } + 1

        val initialNotification = NotificationRecord(
            timestamp = timeFormat.format(Date()),
            recipient = phone,
            channel = "SMS",
            templateTitle = "Waitlist Confirmation",
            messageBody = "BJ's Restaurants: You're on the waitlist! Ref #$code. Party of $partySize. Est. wait: ${prediction.lowerBound}-${prediction.upperBound} mins. Reply STOP to cancel."
        )

        val entry = WaitlistEntry(
            id = entryId,
            confirmationCode = code,
            restaurantId = current.selectedRestaurant.id,
            guestName = guestName,
            phone = phone,
            email = email,
            notes = notes,
            partySize = partySize,
            seatingPreference = preference,
            status = WaitlistStatus.WAITING,
            createdTimeString = timeFormat.format(Date()),
            estimatedWaitMin = prediction.lowerBound,
            estimatedWaitMax = prediction.upperBound,
            positionInQueue = newPosition,
            entirePartyPresent = false,
            qrSecurityToken = qrToken,
            notificationHistory = listOf(initialNotification)
        )

        _state.update {
            it.copy(
                waitlist = it.waitlist + entry,
                activeGuestEntryId = entry.id,
                toastMessage = "Joined waitlist! Confirmation #$code"
            )
        }

        recordAudit(
            "WAITLIST_CREATED",
            "Guest",
            "Party of $partySize ($guestName) joined queue. Wait: ${prediction.lowerBound}-${prediction.upperBound}m (conf ${prediction.confidenceScore})"
        )

        return entry
    }

    fun setActiveGuestEntry(entryId: String?) {
        _state.update { it.copy(activeGuestEntryId = entryId) }
    }

    /**
     * Mark entire party has arrived at restaurant
     */
    fun confirmEntirePartyPresent(entryId: String) {
        _state.update { state ->
            val updatedList = state.waitlist.map { entry ->
                if (entry.id == entryId) {
                    entry.copy(
                        entirePartyPresent = true,
                        status = if (entry.status == WaitlistStatus.WAITING) WaitlistStatus.APPROACHING else entry.status
                    )
                } else entry
            }
            state.copy(
                waitlist = updatedList,
                toastMessage = "Arrival confirmed! Host stand has been alerted."
            )
        }
        recordAudit("PARTY_CONFIRMED", "Guest Mobile", "Guest $entryId confirmed entire party is present")
    }

    /**
     * Modify Party Size
     */
    fun updatePartySize(entryId: String, newSize: Int) {
        _state.update { state ->
            val updated = state.waitlist.map { entry ->
                if (entry.id == entryId) {
                    val prediction = WaitTimeIntelligenceEngine.calculatePrediction(
                        partySize = newSize,
                        preference = entry.seatingPreference,
                        currentQueue = state.waitlist.filter { it.id != entryId },
                        tables = state.tables
                    )
                    entry.copy(
                        partySize = newSize,
                        estimatedWaitMin = prediction.lowerBound,
                        estimatedWaitMax = prediction.upperBound
                    )
                } else entry
            }
            state.copy(waitlist = updated, toastMessage = "Party size updated to $newSize")
        }
        recordAudit("PARTY_SIZE_CHANGED", "Guest/Host", "Entry $entryId changed party size to $newSize")
    }

    /**
     * Cancel waitlist entry
     */
    fun cancelWaitlist(entryId: String) {
        _state.update { state ->
            val updated = state.waitlist.map {
                if (it.id == entryId) it.copy(status = WaitlistStatus.CANCELLED) else it
            }
            val activeId = if (state.activeGuestEntryId == entryId) null else state.activeGuestEntryId
            state.copy(waitlist = updated, activeGuestEntryId = activeId, toastMessage = "Waitlist request cancelled.")
        }
        recordAudit("WAITLIST_CANCELLED", "Guest", "Entry $entryId cancelled waitlist position")
    }

    /**
     * Reservation check-in
     */
    fun checkInReservation(confirmationCodeOrPhone: String): Result<Reservation> {
        val current = _state.value
        val res = current.reservations.find {
            it.confirmationCode.equals(confirmationCodeOrPhone.trim(), ignoreCase = true) ||
                    it.phone.filter { c -> c.isDigit() } == confirmationCodeOrPhone.filter { c -> c.isDigit() }
        }

        if (res == null) {
            return Result.failure(Exception("No reservation found for '$confirmationCodeOrPhone' at this location."))
        }

        val checkedInRes = res.copy(isCheckedIn = true, arrivalTime = timeFormat.format(Date()))
        val updatedReservations = current.reservations.map {
            if (it.id == res.id) checkedInRes else it
        }

        // Also add or advance into host queue
        val existingWaitEntry = current.waitlist.find { it.confirmationCode == res.confirmationCode }
        val updatedWaitlist = if (existingWaitEntry != null) {
            current.waitlist.map {
                if (it.id == existingWaitEntry.id) it.copy(entirePartyPresent = true, status = WaitlistStatus.TABLE_PREPARING) else it
            }
        } else {
            val entry = WaitlistEntry(
                confirmationCode = res.confirmationCode,
                restaurantId = res.restaurantId,
                guestName = res.guestName,
                phone = res.phone,
                partySize = res.partySize,
                seatingPreference = res.seatingPreference,
                status = WaitlistStatus.TABLE_PREPARING,
                createdTimeString = res.reservationTimeString,
                estimatedWaitMin = 2,
                estimatedWaitMax = 5,
                positionInQueue = 1,
                entirePartyPresent = true,
                qrSecurityToken = generateOpaqueToken(res.id, res.confirmationCode)
            )
            listOf(entry) + current.waitlist
        }

        _state.update {
            it.copy(
                reservations = updatedReservations,
                waitlist = updatedWaitlist,
                toastMessage = "Checked in reservation for ${res.guestName} (${res.partySize} guests)!"
            )
        }

        recordAudit("RESERVATION_CHECKED_IN", "Reservation Flow", "Reservation ${res.confirmationCode} arrived at host stand")
        return Result.success(checkedInRes)
    }

    /**
     * Host action: Assign Table
     */
    fun assignTable(waitlistId: String, tableId: String) {
        val current = _state.value
        val entry = current.waitlist.find { it.id == waitlistId } ?: return
        val table = current.tables.find { it.id == tableId } ?: return

        // Validate capacity
        if (entry.partySize > table.capacity && table.canCombineWith == null) {
            _state.update { it.copy(toastMessage = "Warning: Party of ${entry.partySize} exceeds table capacity (${table.capacity})!") }
        }

        val updatedWaitlist = current.waitlist.map {
            if (it.id == waitlistId) {
                it.copy(
                    status = WaitlistStatus.READY_TO_BE_SEATED,
                    assignedTableNumber = table.tableNumber
                )
            } else it
        }

        val updatedTables = current.tables.map {
            if (it.id == tableId) {
                it.copy(
                    status = TableStatus.AWAITING_GUESTS,
                    currentPartyName = "${entry.guestName} (Party of ${entry.partySize})"
                )
            } else it
        }

        _state.update {
            it.copy(
                waitlist = updatedWaitlist,
                tables = updatedTables,
                toastMessage = "Assigned ${entry.guestName} to ${table.tableNumber}!"
            )
        }

        sendNotificationToGuest(
            entryId = waitlistId,
            templateTitle = "Table Ready!",
            message = "BJ's Restaurants: ${entry.guestName}, your table (${table.tableNumber}) is ready! Please proceed to the host stand. We will hold your table for 5 minutes."
        )

        recordAudit("TABLE_ASSIGNED", "Host Stand", "Assigned ${entry.guestName} to Table ${table.tableNumber}")
    }

    /**
     * Host action: Complete Seating
     */
    fun completeSeating(waitlistId: String, tableId: String) {
        val current = _state.value
        val entry = current.waitlist.find { it.id == waitlistId }
        val table = current.tables.find { it.id == tableId }

        val guestName = entry?.guestName ?: table?.currentPartyName ?: "Guest"
        val partySize = entry?.partySize ?: table?.capacity ?: 4

        val updatedWaitlist = current.waitlist.map {
            if (it.id == waitlistId) it.copy(status = WaitlistStatus.SEATED) else it
        }

        val updatedTables = current.tables.map {
            if (it.id == tableId) {
                it.copy(
                    status = TableStatus.OCCUPIED,
                    currentPartyName = guestName,
                    currentPartySize = partySize,
                    seatedMinutesAgo = 1,
                    estimatedTurnoverMinutes = if (partySize <= 2) 45 else if (partySize <= 4) 55 else 70
                )
            } else it
        }

        _state.update {
            it.copy(
                waitlist = updatedWaitlist,
                tables = updatedTables,
                toastMessage = "Party seated at ${table?.tableNumber ?: "table"}! Enjoy your meal."
            )
        }

        recordAudit("GUEST_SEATED", "Host Stand", "Completed seating $guestName at ${table?.tableNumber ?: tableId}")
    }

    /**
     * Host table management: mark table cleaned / bused
     */
    fun markTableCleaned(tableId: String) {
        _state.update { state ->
            val updated = state.tables.map {
                if (it.id == tableId) it.copy(
                    status = TableStatus.AVAILABLE,
                    currentPartyName = null,
                    currentPartySize = null,
                    seatedMinutesAgo = 0
                ) else it
            }
            state.copy(tables = updated, toastMessage = "Table marked sanitized & ready!")
        }
        recordAudit("TABLE_AVAILABLE", "Host/Busser", "Table $tableId bused and available")
    }

    /**
     * Host table management: toggle out of service
     */
    fun toggleTableService(tableId: String) {
        _state.update { state ->
            val updated = state.tables.map {
                if (it.id == tableId) {
                    val newStatus = if (it.status == TableStatus.OUT_OF_SERVICE) TableStatus.AVAILABLE else TableStatus.OUT_OF_SERVICE
                    it.copy(status = newStatus)
                } else it
            }
            state.copy(tables = updated)
        }
        recordAudit("TABLE_STATUS_CHANGED", "Host Stand", "Table $tableId service status toggled")
    }

    /**
     * Send approved communication message to guest
     */
    fun sendNotificationToGuest(entryId: String, templateTitle: String, message: String) {
        val timestamp = timeFormat.format(Date())
        _state.update { state ->
            val updatedWaitlist = state.waitlist.map { entry ->
                if (entry.id == entryId) {
                    val record = NotificationRecord(
                        timestamp = timestamp,
                        recipient = entry.phone,
                        channel = "SMS",
                        templateTitle = templateTitle,
                        messageBody = message
                    )
                    entry.copy(notificationHistory = entry.notificationHistory + record)
                } else entry
            }
            state.copy(
                waitlist = updatedWaitlist,
                toastMessage = "SMS sent: '$templateTitle'"
            )
        }
        recordAudit("GUEST_NOTIFIED", "Host Stand", "Sent '$templateTitle' to guest $entryId")
    }

    private fun recordAudit(eventType: String, actor: String, details: String) {
        val event = AuditEvent(
            timestamp = logTimeFormat.format(Date()),
            eventType = eventType,
            actor = actor,
            details = details,
            restaurantId = _state.value.selectedRestaurant.id
        )
        _state.update { it.copy(auditLog = listOf(event) + it.auditLog.take(40)) }
    }

    private fun generateOpaqueToken(id: String, code: String): String {
        val raw = "$id:$code:${System.currentTimeMillis()}:bjs-enterprise-salt"
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(raw.toByteArray())
        return bytes.take(12).joinToString("") { "%02x".format(it) }.uppercase()
    }
}
