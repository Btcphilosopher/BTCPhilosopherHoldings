package com.example.model

import java.util.UUID

enum class SeatingPreference(val displayName: String, val iconDescription: String) {
    STANDARD("Standard Table", "Classic dining table"),
    BOOTH("Cozy Booth", "Comfortable booth seating"),
    BAR("Bar Seating", "High-top & bar counter"),
    OUTDOOR("Patio / Outdoor", "Al fresco dining area"),
    ACCESSIBLE("Accessible Seating", "Step-free, wheelchair accessible"),
    NO_PREFERENCE("First Available", "Any available seating area")
}

enum class WaitlistStatus(val label: String) {
    REQUEST_SUBMITTED("Request Submitted"),
    CONFIRMED("Waitlist Confirmed"),
    WAITING("Waiting in Queue"),
    APPROACHING("Approaching Turn"),
    TABLE_PREPARING("Table Being Prepared"),
    READY_TO_BE_SEATED("Ready To Be Seated"),
    SEATED("Party Seated"),
    CANCELLED("Cancelled"),
    EXPIRED("Offer Expired")
}

enum class TableStatus(val label: String) {
    AVAILABLE("Available"),
    RESERVED("Reserved"),
    OCCUPIED("Occupied"),
    AWAITING_GUESTS("Awaiting Guests"),
    BEING_CLEANED("Cleaning / Bus"),
    OUT_OF_SERVICE("Out of Service")
}

enum class AppRole(val label: String, val badge: String) {
    GUEST("Guest Experience", "Mobile"),
    HOST_STAND("Host Stand Operations", "Host Tablet"),
    SHIFT_SUPERVISOR("Shift Supervisor", "Supervisor"),
    RESTAURANT_MANAGER("Restaurant General Manager", "Manager"),
    CORPORATE_ADMIN("Enterprise HQ", "Corporate")
}

data class Restaurant(
    val id: String,
    val name: String,
    val address: String,
    val city: String,
    val state: String,
    val zip: String,
    val phone: String,
    val hours: String,
    val distanceMiles: Double,
    val activeWaitlistCount: Int,
    val estimatedWaitMinutes: Int,
    val isLiveQueueEnabled: Boolean = true,
    val openTablesCount: Int = 4,
    val totalTablesCount: Int = 24
) {
    val displayWait: String
        get() = if (isLiveQueueEnabled) "$estimatedWaitMinutes–${estimatedWaitMinutes + 10} mins" else "Queue Unavailable"
}

data class NotificationRecord(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val recipient: String,
    val channel: String, // SMS, PUSH
    val templateTitle: String,
    val messageBody: String,
    val status: String = "DELIVERED" // DELIVERED, PENDING
)

data class WaitlistEntry(
    val id: String = UUID.randomUUID().toString(),
    val confirmationCode: String,
    val restaurantId: String,
    val guestName: String,
    val phone: String,
    val email: String = "",
    val notes: String = "",
    val partySize: Int,
    val seatingPreference: SeatingPreference,
    val status: WaitlistStatus = WaitlistStatus.WAITING,
    val createdAtEpoch: Long = System.currentTimeMillis(),
    val createdTimeString: String,
    val estimatedWaitMin: Int,
    val estimatedWaitMax: Int,
    val positionInQueue: Int,
    val entirePartyPresent: Boolean = false,
    val assignedTableNumber: String? = null,
    val qrSecurityToken: String,
    val smsConsentGranted: Boolean = true,
    val notificationHistory: List<NotificationRecord> = emptyList()
)

data class Reservation(
    val id: String = UUID.randomUUID().toString(),
    val confirmationCode: String,
    val restaurantId: String,
    val guestName: String,
    val phone: String,
    val partySize: Int,
    val reservationTimeString: String,
    val seatingPreference: SeatingPreference = SeatingPreference.STANDARD,
    val isCheckedIn: Boolean = false,
    val arrivalTime: String? = null
)

data class RestaurantTable(
    val id: String,
    val tableNumber: String,
    val section: String, // "Main Dining", "Brewhouse Booths", "Bar Lounge", "Heated Patio"
    val capacity: Int,
    val status: TableStatus,
    val currentPartyName: String? = null,
    val currentPartySize: Int? = null,
    val seatedMinutesAgo: Int = 0,
    val estimatedTurnoverMinutes: Int = 55,
    val canCombineWith: String? = null
) {
    val remainingDiningMinutes: Int
        get() = (estimatedTurnoverMinutes - seatedMinutesAgo).coerceAtLeast(0)
}

data class WaitTimePrediction(
    val predictedMinutes: Int,
    val lowerBound: Int,
    val upperBound: Int,
    val confidenceScore: Double, // 0.0 - 1.0
    val modelVersion: String = "WTE-v3.8-Hybrid",
    val calculationTimestamp: String,
    val servicePeriod: String, // "Dinner Peak", "Lunch Rush", "Late Night", "Mid-day"
    val queueDepthAhead: Int,
    val matchingTablesOccupied: Int,
    val averageTurnoverVelocityMinutes: Int
)

data class AuditEvent(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val eventType: String,
    val actor: String,
    val details: String,
    val restaurantId: String
)

data class CorporateMetrics(
    val totalRestaurants: Int = 216,
    val activeWaitlistsTotal: Int = 1840,
    val todayGuestsServed: Int = 42890,
    val networkAvgWaitMinutes: Int = 24,
    val networkActualWaitMinutes: Int = 21,
    val reservationCheckinRatePct: Double = 94.6,
    val queueAbandonmentRatePct: Double = 3.2,
    val notificationDeliverySuccessPct: Double = 99.8
)
