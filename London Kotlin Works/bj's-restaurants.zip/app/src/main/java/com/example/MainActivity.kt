package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.RestaurantRepository
import com.example.model.AppRole
import com.example.ui.components.BJsTopAppBar
import com.example.ui.corporate.CorporateScreen
import com.example.ui.guest.GuestScreen
import com.example.ui.host.HostAuditLogStream
import com.example.ui.host.HostScreen
import com.example.ui.theme.BJsAmberPrimary
import com.example.ui.theme.BJsCharcoalDark
import com.example.ui.theme.BJsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BJsTheme {
                BJsWaitlistApp()
            }
        }
    }
}

@Composable
fun BJsWaitlistApp() {
    val state by RestaurantRepository.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showAuditLogModal by remember { mutableStateOf(false) }

    LaunchedEffect(state.toastMessage) {
        state.toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            RestaurantRepository.clearToast()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            BJsTopAppBar(
                currentRole = state.currentRole,
                onRoleSelected = { RestaurantRepository.switchRole(it) },
                selectedRestaurant = state.selectedRestaurant,
                allRestaurants = state.restaurants,
                onRestaurantSelected = { RestaurantRepository.selectRestaurant(it) },
                onOpenAuditLog = { showAuditLogModal = true }
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("app_content_container")
        ) {
            when (state.currentRole) {
                AppRole.GUEST -> {
                    GuestScreen(
                        state = state,
                        onJoinWaitlist = { name, phone, email, size, pref, notes ->
                            RestaurantRepository.joinWaitlist(name, phone, email, size, pref, notes)
                        },
                        onConfirmPartyArrival = { RestaurantRepository.confirmEntirePartyPresent(it) },
                        onUpdatePartySize = { id, size -> RestaurantRepository.updatePartySize(id, size) },
                        onCancelWaitlist = { RestaurantRepository.cancelWaitlist(it) },
                        onCheckInReservation = { RestaurantRepository.checkInReservation(it) },
                        onSelectRestaurant = { RestaurantRepository.selectRestaurant(it) }
                    )
                }

                AppRole.HOST_STAND,
                AppRole.SHIFT_SUPERVISOR,
                AppRole.RESTAURANT_MANAGER -> {
                    HostScreen(
                        state = state,
                        onAssignTable = { waitId, tableId -> RestaurantRepository.assignTable(waitId, tableId) },
                        onCompleteSeating = { waitId, tableId -> RestaurantRepository.completeSeating(waitId, tableId) },
                        onSendNotification = { waitId, title, msg -> RestaurantRepository.sendNotificationToGuest(waitId, title, msg) },
                        onMarkTableCleaned = { tableId -> RestaurantRepository.markTableCleaned(tableId) },
                        onToggleTableService = { tableId -> RestaurantRepository.toggleTableService(tableId) },
                        onConfirmPartyPresent = { waitId -> RestaurantRepository.confirmEntirePartyPresent(waitId) },
                        onCancelWaitlist = { waitId -> RestaurantRepository.cancelWaitlist(waitId) }
                    )
                }

                AppRole.CORPORATE_ADMIN -> {
                    CorporateScreen(
                        state = state,
                        onSelectRestaurant = { RestaurantRepository.selectRestaurant(it) }
                    )
                }
            }
        }
    }

    // Real-Time Audit Log / WebSocket Event Stream Dialog
    if (showAuditLogModal) {
        AlertDialog(
            onDismissRequest = { showAuditLogModal = false },
            title = {
                Text(
                    text = "Real-Time Event Bus & Audit Log",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Box(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    HostAuditLogStream(auditLog = state.auditLog)
                }
            },
            confirmButton = {
                TextButton(onClick = { showAuditLogModal = false }) {
                    Text("Close", fontWeight = FontWeight.Bold, color = BJsAmberPrimary)
                }
            }
        )
    }
}
