package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material.icons.filled.TableBar
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppRole
import com.example.model.Restaurant
import com.example.model.TableStatus
import com.example.model.WaitlistStatus
import com.example.ui.theme.BJsAmberPrimary
import com.example.ui.theme.BJsCharcoalDark
import com.example.ui.theme.BJsRubyRed
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusAvailableBg
import com.example.ui.theme.StatusCleaning
import com.example.ui.theme.StatusCleaningBg
import com.example.ui.theme.StatusOccupied
import com.example.ui.theme.StatusOccupiedBg
import com.example.ui.theme.StatusOutOfService
import com.example.ui.theme.StatusOutOfServiceBg
import com.example.ui.theme.StatusPreparing
import com.example.ui.theme.StatusPreparingBg
import com.example.ui.theme.StatusWaiting
import com.example.ui.theme.StatusWaitingBg

@Composable
fun BJsTopAppBar(
    currentRole: AppRole,
    onRoleSelected: (AppRole) -> Unit,
    selectedRestaurant: Restaurant,
    allRestaurants: List<Restaurant>,
    onRestaurantSelected: (Restaurant) -> Unit,
    onOpenAuditLog: () -> Unit
) {
    var showRoleMenu by remember { mutableStateOf(false) }
    var showRestaurantMenu by remember { mutableStateOf(false) }

    Surface(
        color = BJsCharcoalDark,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth().testTag("bjs_top_app_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // BJ's Logo & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { showRestaurantMenu = true }
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(BJsRubyRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "BJ's",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "RESTAURANT & BREWHOUSE",
                                color = BJsAmberPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                        }
                        Text(
                            text = selectedRestaurant.name.replace("BJ's Restaurant & Brewhouse — ", ""),
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Role selector pill & Audit Log action
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onOpenAuditLog,
                        modifier = Modifier.testTag("audit_log_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Event Bus & Audit Stream",
                            tint = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    Box {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = BJsAmberPrimary.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BJsAmberPrimary),
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { showRoleMenu = true }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("role_switcher_pill")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val roleIcon = when (currentRole) {
                                    AppRole.GUEST -> Icons.Default.Person
                                    AppRole.HOST_STAND -> Icons.Default.TableBar
                                    AppRole.SHIFT_SUPERVISOR -> Icons.Default.SupervisorAccount
                                    AppRole.RESTAURANT_MANAGER -> Icons.Default.Restaurant
                                    AppRole.CORPORATE_ADMIN -> Icons.Default.Business
                                }
                                Icon(
                                    imageVector = roleIcon,
                                    contentDescription = null,
                                    tint = BJsAmberPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = currentRole.badge,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showRoleMenu,
                            onDismissRequest = { showRoleMenu = false }
                        ) {
                            AppRole.values().forEach { role ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = role.label,
                                                fontWeight = if (role == currentRole) FontWeight.Bold else FontWeight.Normal
                                            )
                                            Text(
                                                text = "Role: ${role.badge}",
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    },
                                    onClick = {
                                        onRoleSelected(role)
                                        showRoleMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Dropdown menu for restaurant selection
            DropdownMenu(
                expanded = showRestaurantMenu,
                onDismissRequest = { showRestaurantMenu = false }
            ) {
                Text(
                    text = "Select Restaurant Location",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(12.dp)
                )
                HorizontalDivider()
                allRestaurants.forEach { r ->
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(r.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("${r.city}, ${r.state} • ${r.displayWait}", fontSize = 11.sp, color = Color.Gray)
                            }
                        },
                        onClick = {
                            onRestaurantSelected(r)
                            showRestaurantMenu = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun WaitlistStatusBadge(status: WaitlistStatus) {
    val (bgColor, fgColor) = when (status) {
        WaitlistStatus.REQUEST_SUBMITTED -> StatusWaitingBg to StatusWaiting
        WaitlistStatus.CONFIRMED -> StatusWaitingBg to StatusWaiting
        WaitlistStatus.WAITING -> StatusWaitingBg to StatusWaiting
        WaitlistStatus.APPROACHING -> StatusPreparingBg to StatusPreparing
        WaitlistStatus.TABLE_PREPARING -> StatusPreparingBg to StatusPreparing
        WaitlistStatus.READY_TO_BE_SEATED -> StatusAvailableBg to StatusAvailable
        WaitlistStatus.SEATED -> StatusCleaningBg to StatusCleaning
        WaitlistStatus.CANCELLED -> StatusOccupiedBg to StatusOccupied
        WaitlistStatus.EXPIRED -> StatusOutOfServiceBg to StatusOutOfService
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, fgColor.copy(alpha = 0.5f))
    ) {
        Text(
            text = status.label,
            color = fgColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun TableStatusBadge(status: TableStatus) {
    val (bgColor, fgColor) = when (status) {
        TableStatus.AVAILABLE -> StatusAvailableBg to StatusAvailable
        TableStatus.RESERVED -> StatusWaitingBg to StatusWaiting
        TableStatus.OCCUPIED -> StatusOccupiedBg to StatusOccupied
        TableStatus.AWAITING_GUESTS -> StatusPreparingBg to StatusPreparing
        TableStatus.BEING_CLEANED -> StatusCleaningBg to StatusCleaning
        TableStatus.OUT_OF_SERVICE -> StatusOutOfServiceBg to StatusOutOfService
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, fgColor.copy(alpha = 0.4f))
    ) {
        Text(
            text = status.label,
            color = fgColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

/**
 * High-fidelity QR Code Canvas generator with finder patterns and opaque token representation
 */
@Composable
fun StylizedQRCode(
    token: String,
    modifier: Modifier = Modifier,
    sizeDp: Int = 180
) {
    Surface(
        modifier = modifier
            .size(sizeDp.dp)
            .border(1.dp, Color(0xFFE2DCD5), RoundedCornerShape(8.dp)),
        color = Color.White,
        shape = RoundedCornerShape(8.dp)
    ) {
        Box(modifier = Modifier.padding(12.dp)) {
            Canvas(modifier = Modifier.fillMaxWidth().height(sizeDp.dp)) {
                val gridSize = 21 // standard version 1 QR dimension
                val cellSize = size.width / gridSize
                val hashBytes = token.hashCode()

                fun isFinder(r: Int, c: Int): Boolean {
                    // Top-Left Finder
                    if (r in 0..6 && c in 0..6) return true
                    // Top-Right Finder
                    if (r in 0..6 && c in (gridSize - 7) until gridSize) return true
                    // Bottom-Left Finder
                    if (r in (gridSize - 7) until gridSize && c in 0..6) return true
                    return false
                }

                // Draw modules based on deterministic token hash
                for (r in 0 until gridSize) {
                    for (c in 0 until gridSize) {
                        if (!isFinder(r, c)) {
                            // Pseudo-random deterministic bit
                            val bit = ((r * 31 + c * 17 + hashBytes) % 7) in listOf(0, 2, 4, 5)
                            if (bit) {
                                drawRect(
                                    color = Color(0xFF1E1A17),
                                    topLeft = Offset(c * cellSize, r * cellSize),
                                    size = Size(cellSize * 0.92f, cellSize * 0.92f)
                                )
                            }
                        }
                    }
                }

                // Draw Finder Patterns (Top-Left, Top-Right, Bottom-Left)
                fun drawFinderPattern(startCol: Int, startRow: Int) {
                    val x = startCol * cellSize
                    val y = startRow * cellSize
                    val boxSize = 7 * cellSize

                    // Outer border
                    drawRect(
                        color = Color(0xFF1E1A17),
                        topLeft = Offset(x, y),
                        size = Size(boxSize, boxSize)
                    )
                    // White inner ring
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(x + cellSize, y + cellSize),
                        size = Size(5 * cellSize, 5 * cellSize)
                    )
                    // Center solid block (accent ruby)
                    drawRect(
                        color = Color(0xFFB91C1C),
                        topLeft = Offset(x + 2 * cellSize, y + 2 * cellSize),
                        size = Size(3 * cellSize, 3 * cellSize)
                    )
                }

                drawFinderPattern(0, 0)
                drawFinderPattern(gridSize - 7, 0)
                drawFinderPattern(0, gridSize - 7)
            }
        }
    }
}
