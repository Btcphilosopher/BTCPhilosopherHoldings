package com.example.ui.host

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.EventSeat
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableBar
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PlatformState
import com.example.model.RestaurantTable
import com.example.model.TableStatus
import com.example.model.WaitlistEntry
import com.example.model.WaitlistStatus
import com.example.ui.components.TableStatusBadge
import com.example.ui.components.WaitlistStatusBadge
import com.example.ui.theme.BJsAmberPrimary
import com.example.ui.theme.BJsCharcoalCard
import com.example.ui.theme.BJsCharcoalDark
import com.example.ui.theme.BJsCreamBackground
import com.example.ui.theme.BJsRubyRed
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusCleaning
import com.example.ui.theme.StatusOccupied
import com.example.ui.theme.StatusPreparing
import com.example.ui.theme.StatusWaiting

@Composable
fun HostScreen(
    state: PlatformState,
    onAssignTable: (waitlistId: String, tableId: String) -> Unit,
    onCompleteSeating: (waitlistId: String, tableId: String) -> Unit,
    onSendNotification: (waitlistId: String, templateTitle: String, message: String) -> Unit,
    onMarkTableCleaned: (tableId: String) -> Unit,
    onToggleTableService: (tableId: String) -> Unit,
    onConfirmPartyPresent: (waitlistId: String) -> Unit,
    onCancelWaitlist: (waitlistId: String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Live Queue (${state.waitlist.count { it.status != WaitlistStatus.SEATED && it.status != WaitlistStatus.CANCELLED }})", "Floor Plan (${state.tables.size})", "Audit Stream")

    var selectedEntryForAssign by remember { mutableStateOf<WaitlistEntry?>(null) }
    var selectedEntryForNotify by remember { mutableStateOf<WaitlistEntry?>(null) }
    var selectedTableForAction by remember { mutableStateOf<RestaurantTable?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BJsCreamBackground)
            .testTag("host_screen_root")
    ) {
        // Operational Overview Bar
        HostOperationalHeader(state = state)

        // Sub Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = BJsCharcoalDark,
            contentColor = BJsAmberPrimary
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    modifier = Modifier.testTag("host_tab_$index"),
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) BJsAmberPrimary else Color.White.copy(alpha = 0.7f)
                        )
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> HostLiveQueueView(
                waitlist = state.waitlist.filter { it.status != WaitlistStatus.SEATED && it.status != WaitlistStatus.CANCELLED },
                tables = state.tables,
                onAssignClick = { selectedEntryForAssign = it },
                onNotifyClick = { selectedEntryForNotify = it },
                onSeatClick = { entry ->
                    val matchingTable = state.tables.find { it.tableNumber == entry.assignedTableNumber }
                    if (matchingTable != null) {
                        onCompleteSeating(entry.id, matchingTable.id)
                    } else {
                        selectedEntryForAssign = entry
                    }
                },
                onConfirmArrival = onConfirmPartyPresent,
                onCancel = onCancelWaitlist
            )
            1 -> HostFloorPlanView(
                tables = state.tables,
                waitlist = state.waitlist,
                onTableClick = { selectedTableForAction = it },
                onMarkCleaned = onMarkTableCleaned
            )
            2 -> HostAuditLogStream(auditLog = state.auditLog)
        }
    }

    // Modal: Assign Table Dialog
    if (selectedEntryForAssign != null) {
        val entry = selectedEntryForAssign!!
        val availableTables = state.tables.filter {
            it.status == TableStatus.AVAILABLE || it.status == TableStatus.AWAITING_GUESTS
        }

        AlertDialog(
            onDismissRequest = { selectedEntryForAssign = null },
            title = {
                Text(
                    text = "Assign Table: ${entry.guestName} (${entry.partySize} guests)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        "Preference: ${entry.seatingPreference.displayName}. Select an available table with appropriate capacity:",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (availableTables.isEmpty()) {
                        Text(
                            "No tables are currently available or awaiting guests. Check the floor plan for tables being bused.",
                            color = BJsRubyRed,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    } else {
                        LazyColumn(modifier = Modifier.height(240.dp)) {
                            items(availableTables) { table ->
                                val isCompatible = table.capacity >= entry.partySize
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            onAssignTable(entry.id, table.id)
                                            selectedEntryForAssign = null
                                        },
                                    colors = CardDefaults.cardColors(containerColor = if (isCompatible) Color(0xFFFBF8F4) else Color(0xFFFFF1F1)),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isCompatible) Color(0xFFDCD2C3) else Color(0xFFFCA5A5))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                "${table.tableNumber} • ${table.section}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                "Capacity: ${table.capacity} guests • ${table.status.label}",
                                                fontSize = 12.sp,
                                                color = Color.Gray
                                            )
                                        }
                                        Button(
                                            onClick = {
                                                onAssignTable(entry.id, table.id)
                                                selectedEntryForAssign = null
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text("Assign", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { selectedEntryForAssign = null }) { Text("Cancel") }
            }
        )
    }

    // Modal: Send SMS Notification to Guest
    if (selectedEntryForNotify != null) {
        val entry = selectedEntryForNotify!!
        val templates = listOf(
            "Table Ready (5 min hold)" to "BJ's Restaurants: ${entry.guestName}, your table is ready! Please proceed to the host stand. We will hold your table for 5 minutes.",
            "Table Nearly Ready" to "BJ's Restaurants: ${entry.guestName}, your table will be ready in approximately 5 minutes. Please head toward the host stand.",
            "Confirm Party Presence" to "BJ's Restaurants: Please confirm your entire party has arrived at the host stand so we can prepare your table.",
            "Wait Time Update" to "BJ's Restaurants: An update on your visit — we expect to seat your party within 10-15 minutes. Thank you for your patience!"
        )

        AlertDialog(
            onDismissRequest = { selectedEntryForNotify = null },
            title = { Text("Send Guest SMS Notification") },
            text = {
                Column {
                    Text("Recipient: ${entry.guestName} (${entry.phone})", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Select approved message template:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    templates.forEach { (title, msg) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onSendNotification(entry.id, title, msg)
                                    selectedEntryForNotify = null
                                },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F6F0)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DCD5))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BJsAmberPrimary)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(msg, fontSize = 11.sp, color = Color(0xFF444444))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { selectedEntryForNotify = null }) { Text("Dismiss") }
            }
        )
    }

    // Modal: Table Details & Actions
    if (selectedTableForAction != null) {
        val table = selectedTableForAction!!
        AlertDialog(
            onDismissRequest = { selectedTableForAction = null },
            title = {
                Text(
                    text = "${table.tableNumber} (${table.section})",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text("Capacity: ${table.capacity} guests")
                    Text("Current Status: ${table.status.label}")
                    if (table.currentPartyName != null) {
                        Text("Party: ${table.currentPartyName}")
                        Text("Seated: ${table.seatedMinutesAgo} mins ago (Turnover: ${table.estimatedTurnoverMinutes}m)")
                    }
                    if (table.canCombineWith != null) {
                        Text("Combine Option: Configured to join with ${table.canCombineWith}", color = Color.Gray, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Available Table Actions:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (table.status == TableStatus.BEING_CLEANED) {
                        Button(
                            onClick = {
                                onMarkTableCleaned(table.id)
                                selectedTableForAction = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Mark Cleaned & Available")
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedButton(
                        onClick = {
                            onToggleTableService(table.id)
                            selectedTableForAction = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (table.status == TableStatus.OUT_OF_SERVICE) "Restore to Active Service" else "Mark Out of Service")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedTableForAction = null }) { Text("Close") }
            }
        )
    }
}

// -------------------------------------------------------------
// OPERATIONAL HEADER COMPONENT
// -------------------------------------------------------------

@Composable
fun HostOperationalHeader(state: PlatformState) {
    val totalOccupied = state.tables.count { it.status == TableStatus.OCCUPIED }
    val totalCleaning = state.tables.count { it.status == TableStatus.BEING_CLEANED }
    val totalAvailable = state.tables.count { it.status == TableStatus.AVAILABLE }
    val activeQueueCount = state.waitlist.count {
        it.status in listOf(WaitlistStatus.WAITING, WaitlistStatus.APPROACHING, WaitlistStatus.TABLE_PREPARING)
    }

    Surface(
        color = Color(0xFF1E1A17),
        modifier = Modifier.fillMaxWidth().testTag("host_operational_header")
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusAvailable)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE SERVICE PERIOD: ${state.servicePeriod.uppercase()}",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }

                Text(
                    text = "WTE Engine: Active",
                    color = BJsAmberPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stat Cards Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HostHeaderStatCard("Waitlist", "$activeQueueCount Parties", BJsAmberPrimary, Modifier.weight(1f))
                HostHeaderStatCard("Occupied", "$totalOccupied Tables", StatusOccupied, Modifier.weight(1f))
                HostHeaderStatCard("Cleaning", "$totalCleaning Tables", StatusCleaning, Modifier.weight(1f))
                HostHeaderStatCard("Available", "$totalAvailable Tables", StatusAvailable, Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun HostHeaderStatCard(label: String, value: String, accentColor: Color, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF28231F),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(label, fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = accentColor)
        }
    }
}

// -------------------------------------------------------------
// LIVE QUEUE VIEW
// -------------------------------------------------------------

@Composable
fun HostLiveQueueView(
    waitlist: List<WaitlistEntry>,
    tables: List<RestaurantTable>,
    onAssignClick: (WaitlistEntry) -> Unit,
    onNotifyClick: (WaitlistEntry) -> Unit,
    onSeatClick: (WaitlistEntry) -> Unit,
    onConfirmArrival: (String) -> Unit,
    onCancel: (String) -> Unit
) {
    if (waitlist.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Waitlist is currently clear. Ready for walk-in guests.", color = Color.Gray, fontSize = 14.sp)
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(12.dp).testTag("host_live_queue_list"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(waitlist) { entry ->
            Card(
                modifier = Modifier.fillMaxWidth().testTag("host_queue_item_${entry.id}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Top Row: Position, Guest Name, Party Size, Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BJsCharcoalDark
                            ) {
                                Text(
                                    text = "#${entry.positionInQueue}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = entry.guestName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = BJsCharcoalDark
                                )
                                Text(
                                    text = "${entry.phone} • Ref: ${entry.confirmationCode}",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        WaitlistStatusBadge(status = entry.status)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row: Preference, Check-in Time, Estimated Wait, Arrival State
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Party of ${entry.partySize} • ${entry.seatingPreference.displayName}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Est. ${entry.estimatedWaitMin}–${entry.estimatedWaitMax}m (In at ${entry.createdTimeString})",
                            fontSize = 12.sp,
                            color = BJsAmberPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (entry.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Note: ${entry.notes}",
                            fontSize = 11.sp,
                            color = Color(0xFF666666)
                        )
                    }

                    if (entry.assignedTableNumber != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = Color(0xFFDCFCE7),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Assigned Table: ${entry.assignedTableNumber}",
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Color(0xFFF0EBE1))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Action Buttons Row for Host
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (!entry.entirePartyPresent) {
                            OutlinedButton(
                                onClick = { onConfirmArrival(entry.id) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Mark Arrived", fontSize = 11.sp)
                            }
                        }

                        OutlinedButton(
                            onClick = { onNotifyClick(entry) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Message, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SMS", fontSize = 11.sp)
                        }

                        if (entry.status != WaitlistStatus.READY_TO_BE_SEATED) {
                            Button(
                                onClick = { onAssignClick(entry) },
                                colors = ButtonDefaults.buttonColors(containerColor = BJsAmberPrimary),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1.2f)
                            ) {
                                Text("Assign Table", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = { onSeatClick(entry) },
                                colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1.2f)
                            ) {
                                Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Complete Seat", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        IconButton(
                            onClick = { onCancel(entry.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Outlined.Cancel, contentDescription = "Cancel", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// INTERACTIVE FLOOR PLAN VIEW
// -------------------------------------------------------------

@Composable
fun HostFloorPlanView(
    tables: List<RestaurantTable>,
    waitlist: List<WaitlistEntry>,
    onTableClick: (RestaurantTable) -> Unit,
    onMarkCleaned: (String) -> Unit
) {
    val sections = listOf("Main Dining", "Brewhouse Booths", "Bar Lounge", "Heated Patio")
    var selectedSection by remember { mutableStateOf("All") }

    val filteredTables = if (selectedSection == "All") tables else tables.filter { it.section == selectedSection }

    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp).testTag("host_floor_plan_view")
    ) {
        // Section Filter Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                SectionChip("All", selectedSection == "All") { selectedSection = "All" }
            }
            items(sections) { sec ->
                SectionChip(sec, selectedSection == sec) { selectedSection = sec }
            }
        }

        // Table Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredTables) { table ->
                TableCard(table = table, onClick = { onTableClick(table) })
            }
        }
    }
}

@Composable
fun SectionChip(title: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) BJsAmberPrimary else Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) BJsAmberPrimary else Color(0xFFDED6CB)),
        modifier = Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)
    ) {
        Text(
            text = title,
            color = if (isSelected) Color.White else BJsCharcoalDark,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun TableCard(table: RestaurantTable, onClick: () -> Unit) {
    val borderColor = when (table.status) {
        TableStatus.AVAILABLE -> StatusAvailable
        TableStatus.RESERVED -> StatusWaiting
        TableStatus.OCCUPIED -> StatusOccupied
        TableStatus.AWAITING_GUESTS -> StatusPreparing
        TableStatus.BEING_CLEANED -> StatusCleaning
        TableStatus.OUT_OF_SERVICE -> Color.Gray
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("table_card_${table.tableNumber}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor.copy(alpha = 0.8f)),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = table.tableNumber,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = BJsCharcoalDark
                )
                TableStatusBadge(status = table.status)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${table.section} • Seats ${table.capacity}",
                fontSize = 11.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (table.currentPartyName != null) {
                Text(
                    text = table.currentPartyName,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = BJsCharcoalDark
                )
                Spacer(modifier = Modifier.height(4.dp))

                // Dining duration & Turnover progress
                val progress = (table.seatedMinutesAgo.toFloat() / table.estimatedTurnoverMinutes.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                    color = if (progress > 0.85f) StatusOccupied else BJsAmberPrimary,
                    trackColor = Color(0xFFF0EBE1)
                )

                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("${table.seatedMinutesAgo}m seated", fontSize = 10.sp, color = Color.Gray)
                    Text("~${table.remainingDiningMinutes}m left", fontSize = 10.sp, color = Color.Gray)
                }
            } else {
                Text(
                    text = "No party assigned",
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
                Spacer(modifier = Modifier.height(18.dp))
            }
        }
    }
}

// -------------------------------------------------------------
// REAL-TIME AUDIT LOG / WEBSOCKET EVENT STREAM
// -------------------------------------------------------------

@Composable
fun HostAuditLogStream(auditLog: List<com.example.model.AuditEvent>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp).testTag("host_audit_log_stream"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BJsCharcoalDark),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(StatusAvailable))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Live WebSocket Event Broker: Stream Connected",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        items(auditLog) { event ->
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5DFD6))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = BJsAmberPrimary.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = event.eventType,
                                    color = BJsAmberPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("by ${event.actor}", fontSize = 11.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(event.details, fontSize = 12.sp, color = BJsCharcoalDark)
                    }

                    Text(event.timestamp, fontSize = 11.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
