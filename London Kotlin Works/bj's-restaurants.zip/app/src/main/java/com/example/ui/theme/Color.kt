package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BJ's Brand Color Palette - Warm Hospitality & Crafted Brewing
val BJsAmberPrimary = Color(0xFFD97706) // Rich Warm Amber / Honey Ale
val BJsAmberDark = Color(0xFF92400E)
val BJsAmberLight = Color(0xFFFDE68A)
val BJsGoldAccent = Color(0xFFF59E0B)

val BJsRubyRed = Color(0xFFB91C1C) // Signature BJ's Crimson
val BJsRubyDark = Color(0xFF7F1D1D)

val BJsCharcoalDark = Color(0xFF14110F) // Espresso Bar / Charcoal
val BJsCharcoalSurface = Color(0xFF1E1A17)
val BJsCharcoalCard = Color(0xFF28231F)
val BJsCharcoalBorder = Color(0xFF3E3631)

val BJsCreamBackground = Color(0xFFF8F5F0) // Warm Cream Parchment
val BJsCreamSurface = Color(0xFFFFFFFF)
val BJsCreamSurfaceVariant = Color(0xFFEFE9DF)
val BJsTextPrimaryLight = Color(0xFF1F1B18)
val BJsTextSecondaryLight = Color(0xFF6B635B)

// Operational Status Colors
val StatusAvailable = Color(0xFF16A34A)
val StatusAvailableBg = Color(0xFFDCFCE7)
val StatusWaiting = Color(0xFFD97706)
val StatusWaitingBg = Color(0xFFFEF3C7)
val StatusPreparing = Color(0xFF0284C7)
val StatusPreparingBg = Color(0xFFE0F2FE)
val StatusOccupied = Color(0xFFDC2626)
val StatusOccupiedBg = Color(0xFFFEE2E2)
val StatusCleaning = Color(0xFF7C3AED)
val StatusCleaningBg = Color(0xFFEDE9FE)
val StatusOutOfService = Color(0xFF64748B)
val StatusOutOfServiceBg = Color(0xFFF1F5F9)
