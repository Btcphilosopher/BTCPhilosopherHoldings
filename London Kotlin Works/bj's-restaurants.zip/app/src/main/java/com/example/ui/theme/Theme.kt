package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BJsAmberPrimary,
    onPrimary = Color.White,
    primaryContainer = BJsAmberDark,
    onPrimaryContainer = BJsAmberLight,
    secondary = BJsRubyRed,
    onSecondary = Color.White,
    tertiary = BJsGoldAccent,
    background = BJsCharcoalDark,
    onBackground = Color(0xFFF3ECE4),
    surface = BJsCharcoalSurface,
    onSurface = Color(0xFFF3ECE4),
    surfaceVariant = BJsCharcoalCard,
    onSurfaceVariant = Color(0xFFD4C8BC),
    outline = BJsCharcoalBorder
)

private val LightColorScheme = lightColorScheme(
    primary = BJsAmberPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF78350F),
    secondary = BJsRubyRed,
    onSecondary = Color.White,
    tertiary = BJsGoldAccent,
    background = BJsCreamBackground,
    onBackground = BJsTextPrimaryLight,
    surface = BJsCreamSurface,
    onSurface = BJsTextPrimaryLight,
    surfaceVariant = BJsCreamSurfaceVariant,
    onSurfaceVariant = BJsTextSecondaryLight,
    outline = Color(0xFFDCD2C3)
)

@Composable
fun BJsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
