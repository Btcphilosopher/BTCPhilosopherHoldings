package com.example.engine

import com.example.model.RestaurantTable
import com.example.model.SeatingPreference
import com.example.model.TableStatus
import com.example.model.WaitTimePrediction
import com.example.model.WaitlistEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Enterprise Wait-Time Intelligence Engine (WTE-v3.8)
 *
 * Implements a statistical stochastic queuing model for restaurant seating:
 * - Table matching by party size brackets: 1-2, 3-4, 5-6, 7-10, 11+
 * - Remaining service time distribution across occupied tables
 * - Service period curve (Dinner peak vs lunch vs afternoon lull)
 * - Table turnover velocity & cleaning busing buffer
 * - Seating preference constraints (Booth, Patio, Bar, Accessible)
 * - Dynamic confidence interval generation (Standard error of estimate)
 */
object WaitTimeIntelligenceEngine {

    private val timeFormat = SimpleDateFormat("h:mm:ss a", Locale.US)

    // Baseline historical dining durations in minutes by table size category
    private val baselineDurationsByPartySize = mapOf(
        1 to 42,
        2 to 46,
        3 to 56,
        4 to 62,
        5 to 70,
        6 to 76,
        7 to 88,
        8 to 94,
        10 to 105,
        12 to 120
    )

    fun calculatePrediction(
        partySize: Int,
        preference: SeatingPreference,
        currentQueue: List<WaitlistEntry>,
        tables: List<RestaurantTable>,
        servicePeriod: String = detectCurrentServicePeriod()
    ): WaitTimePrediction {
        // 1. Identify candidate tables that match party size and preference
        val matchingTables = tables.filter { table ->
            val capacityMatches = if (partySize <= 2) {
                table.capacity in 2..4
            } else if (partySize <= 4) {
                table.capacity in 4..6
            } else if (partySize <= 6) {
                table.capacity in 6..8
            } else {
                table.capacity >= partySize || table.canCombineWith != null
            }

            val preferenceMatches = when (preference) {
                SeatingPreference.BOOTH -> table.section.contains("Booth", ignoreCase = true)
                SeatingPreference.BAR -> table.section.contains("Bar", ignoreCase = true)
                SeatingPreference.OUTDOOR -> table.section.contains("Patio", ignoreCase = true)
                SeatingPreference.ACCESSIBLE -> !table.section.contains("Bar", ignoreCase = true) // step free
                else -> true
            }

            capacityMatches && preferenceMatches && table.status != TableStatus.OUT_OF_SERVICE
        }

        val availableImmediately = matchingTables.count { it.status == TableStatus.AVAILABLE }
        val cleaningSoon = matchingTables.count { it.status == TableStatus.BEING_CLEANED }
        val occupiedMatching = matchingTables.filter { it.status == TableStatus.OCCUPIED }

        // 2. Queue depth ahead with competing table needs
        val competingPartiesAhead = currentQueue.count { entry ->
            val sizeClassMatch = when {
                partySize <= 2 -> entry.partySize <= 2
                partySize <= 4 -> entry.partySize in 3..4
                partySize <= 6 -> entry.partySize in 5..6
                else -> entry.partySize >= 7
            }
            sizeClassMatch && entry.status in listOf(
                com.example.model.WaitlistStatus.WAITING,
                com.example.model.WaitlistStatus.APPROACHING,
                com.example.model.WaitlistStatus.TABLE_PREPARING
            )
        }

        // 3. Service Period Rush Factor
        val rushMultiplier = when (servicePeriod) {
            "Dinner Peak" -> 1.25
            "Lunch Rush" -> 1.10
            "Late Night" -> 0.90
            else -> 1.00
        }

        // 4. Seating preference friction (specific requests add 3-8 mins queue variance)
        val preferencePenalty = when (preference) {
            SeatingPreference.BOOTH -> 5
            SeatingPreference.OUTDOOR -> 6
            SeatingPreference.BAR -> -3 // Bar usually turns faster
            SeatingPreference.ACCESSIBLE -> 2
            else -> 0
        }

        // 5. Stochastic wait calculation
        val baseline = baselineDurationsByPartySize[partySize] ?: 60
        val tableTurnoverRate = if (matchingTables.isNotEmpty()) {
            val totalTables = matchingTables.size.toDouble()
            // Estimate average remaining time of currently occupied tables
            val remainingTimes = occupiedMatching.map { it.remainingDiningMinutes }
            val avgRemaining = if (remainingTimes.isNotEmpty()) remainingTimes.average() else 15.0
            (avgRemaining / totalTables).coerceAtLeast(3.5)
        } else {
            12.0
        }

        var estimatedWaitMinutes = 0
        if (competingPartiesAhead == 0 && availableImmediately > 0) {
            estimatedWaitMinutes = 3 // Quick greeting & seating buffer
        } else {
            val rawEstimate = (competingPartiesAhead + 1) * tableTurnoverRate * rushMultiplier + preferencePenalty
            estimatedWaitMinutes = rawEstimate.roundToInt().coerceIn(4, 90)
        }

        // Table busing & sanitization buffer
        val cleaningBuffer = 4
        val predictedMinutes = (estimatedWaitMinutes + if (availableImmediately == 0) cleaningBuffer else 0).coerceAtLeast(3)

        // 6. Confidence range calculation (Poisson queue variance)
        val variance = sqrt(predictedMinutes.toDouble()).coerceAtLeast(2.0)
        val lowerBound = (predictedMinutes - (variance * 1.1).roundToInt()).coerceAtLeast(2)
        val upperBound = (predictedMinutes + (variance * 1.4).roundToInt())

        val confidenceScore = (1.0 - (competingPartiesAhead * 0.03 + (if (preference != SeatingPreference.NO_PREFERENCE) 0.05 else 0.0))).coerceIn(0.78, 0.96)

        return WaitTimePrediction(
            predictedMinutes = predictedMinutes,
            lowerBound = lowerBound,
            upperBound = upperBound,
            confidenceScore = (confidenceScore * 100).roundToInt() / 100.0,
            modelVersion = "WTE-v3.8-Hybrid",
            calculationTimestamp = timeFormat.format(Date()),
            servicePeriod = servicePeriod,
            queueDepthAhead = competingPartiesAhead,
            matchingTablesOccupied = occupiedMatching.size,
            averageTurnoverVelocityMinutes = tableTurnoverRate.roundToInt()
        )
    }

    private fun detectCurrentServicePeriod(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 11..13 -> "Lunch Rush"
            in 14..16 -> "Mid-day Service"
            in 17..20 -> "Dinner Peak"
            in 21..23 -> "Late Night Brewhouse"
            else -> "Off-Peak"
        }
    }
}
