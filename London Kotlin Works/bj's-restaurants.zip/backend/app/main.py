from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum
import uuid
import datetime
import math

app = FastAPI(
    title="BJ's Restaurants — Enterprise Waitlist & Guest Check-In API",
    version="3.8.0",
    description="Mission-critical guest queue management, table floor plan allocation, and wait-time forecasting engine."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class SeatingPreference(str, Enum):
    STANDARD = "STANDARD"
    BOOTH = "BOOTH"
    BAR = "BAR"
    OUTDOOR = "OUTDOOR"
    ACCESSIBLE = "ACCESSIBLE"
    NO_PREFERENCE = "NO_PREFERENCE"

class WaitlistStatus(str, Enum):
    REQUEST_SUBMITTED = "REQUEST_SUBMITTED"
    CONFIRMED = "CONFIRMED"
    WAITING = "WAITING"
    APPROACHING = "APPROACHING"
    TABLE_PREPARING = "TABLE_PREPARING"
    READY_TO_BE_SEATED = "READY_TO_BE_SEATED"
    SEATED = "SEATED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"

class TableStatus(str, Enum):
    AVAILABLE = "AVAILABLE"
    RESERVED = "RESERVED"
    OCCUPIED = "OCCUPIED"
    AWAITING_GUESTS = "AWAITING_GUESTS"
    BEING_CLEANED = "BEING_CLEANED"
    OUT_OF_SERVICE = "OUT_OF_SERVICE"

# --- Pydantic Schemas ---

class WaitlistCreateRequest(BaseModel):
    restaurant_id: str
    guest_name: str
    phone: str
    email: Optional[str] = None
    party_size: int = Field(ge=1, le=25)
    seating_preference: SeatingPreference = SeatingPreference.NO_PREFERENCE
    notes: Optional[str] = None
    sms_consent: bool = True

class WaitlistResponse(BaseModel):
    id: str
    confirmation_code: str
    restaurant_id: str
    guest_name: str
    phone: str
    party_size: int
    seating_preference: SeatingPreference
    status: WaitlistStatus
    position: int
    estimated_wait_min: int
    estimated_wait_max: int
    qr_token: str
    created_at: str

class TableAssignRequest(BaseModel):
    waitlist_id: str
    table_id: str

class NotificationSendRequest(BaseModel):
    waitlist_id: str
    template_key: str
    custom_message: Optional[str] = None

# --- In-Memory State & Event Hub ---

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, restaurant_id: str, websocket: WebSocket):
        await websocket.accept()
        if restaurant_id not in self.active_connections:
            self.active_connections[restaurant_id] = []
        self.active_connections[restaurant_id].append(websocket)

    def disconnect(self, restaurant_id: str, websocket: WebSocket):
        if restaurant_id in self.active_connections:
            if websocket in self.active_connections[restaurant_id]:
                self.active_connections[restaurant_id].remove(websocket)

    async def broadcast(self, restaurant_id: str, event_type: str, payload: Dict[str, Any]):
        message = {
            "event": event_type,
            "restaurant_id": restaurant_id,
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "payload": payload
        }
        if restaurant_id in self.active_connections:
            for connection in self.active_connections[restaurant_id]:
                try:
                    await connection.send_json(message)
                except Exception:
                    pass

manager = ConnectionManager()

# --- Endpoints ---

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "bjs-waitlist-api",
        "version": "3.8.0",
        "engine": "WTE-v3.8-Hybrid",
        "timestamp": datetime.datetime.utcnow().isoformat()
    }

@app.post("/api/v1/waitlist", response_model=WaitlistResponse)
async def create_waitlist_entry(req: WaitlistCreateRequest):
    entry_id = f"w-{uuid.uuid4().hex[:8]}"
    code = f"BJ-{datetime.datetime.now().microsecond % 9000 + 1000}"
    
    # Statistical estimate calculation
    est_min = max(4, req.party_size * 4)
    est_max = est_min + 8
    
    response = WaitlistResponse(
        id=entry_id,
        confirmation_code=code,
        restaurant_id=req.restaurant_id,
        guest_name=req.guest_name,
        phone=req.phone,
        party_size=req.party_size,
        seating_preference=req.seating_preference,
        status=WaitlistStatus.WAITING,
        position=1,
        estimated_wait_min=est_min,
        estimated_wait_max=est_max,
        qr_token=uuid.uuid4().hex.upper(),
        created_at=datetime.datetime.utcnow().isoformat()
    )
    
    await manager.broadcast(req.restaurant_id, "WAITLIST_CREATED", response.dict())
    return response

@app.post("/api/v1/seating/assign")
async def assign_table(req: TableAssignRequest):
    await manager.broadcast("bjs-irvine", "TABLE_ASSIGNED", {"waitlist_id": req.waitlist_id, "table_id": req.table_id})
    return {"status": "success", "message": f"Table {req.table_id} assigned to {req.waitlist_id}"}

@app.post("/api/v1/notifications/send")
async def send_notification(req: NotificationSendRequest):
    await manager.broadcast("bjs-irvine", "GUEST_NOTIFIED", {"waitlist_id": req.waitlist_id, "template": req.template_key})
    return {"status": "delivered", "provider": "Twilio-Enterprise-SMS", "timestamp": datetime.datetime.utcnow().isoformat()}

@app.websocket("/ws/restaurants/{restaurant_id}/events")
async def websocket_events(websocket: WebSocket, restaurant_id: str):
    await manager.connect(restaurant_id, websocket)
    try:
        while True:
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(restaurant_id, websocket)
