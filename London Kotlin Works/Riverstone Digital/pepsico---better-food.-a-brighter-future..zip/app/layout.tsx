import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'PepsiCo - Better Food. A Brighter Future.',
  description: "At PepsiCo, we're bringing together the world's favourite brands and a healthier future — for people, communities and the planet.",
  openGraph: {
    title: 'PepsiCo - Better Food. A Brighter Future.',
    description: "At PepsiCo, we're bringing together the world's favourite brands and a healthier future — for people, communities and the planet.",
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PepsiCo - Better Food. A Brighter Future.',
    description: "At PepsiCo, we're bringing together the world's favourite brands and a healthier future — for people, communities and the planet.",
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
