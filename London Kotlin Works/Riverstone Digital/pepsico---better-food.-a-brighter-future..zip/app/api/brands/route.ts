import { NextRequest, NextResponse } from 'next/server';

export interface BrandProduct {
  id: string;
  name: string;
  tagline: string;
  category: 'beverages' | 'snacks' | 'nutrition';
  heroSlide: number; // 1 to 4
  accentColor: string;
  secondaryColor: string;
  calories: string;
  sugarOrFat: string;
  sodium: string;
  description: string;
  originYear: number;
  sustainabilityHighlight: string;
  flavorNotes: string[];
  keyIngredients: string[];
  badge?: string;
  imageType: 'pepsi' | 'lays' | 'tropicana' | 'quaker' | 'doritos' | 'gatorade' | 'b栄養' | 'sunchips' | 'bubly';
}

export const BRANDS_DATA: BrandProduct[] = [
  {
    id: 'pepsi-original',
    name: 'Pepsi-Cola',
    tagline: 'Bold, refreshing cola taste that brings people together',
    category: 'beverages',
    heroSlide: 1,
    accentColor: '#004B93',
    secondaryColor: '#C8102E',
    calories: '150 kcal (355ml)',
    sugarOrFat: '41g Natural Sweetener',
    sodium: '30mg',
    description: 'Born in 1898 in New Bern, North Carolina by pharmacist Caleb Bradham. Pepsi remains one of the world\'s most celebrated beverages, delivering iconic bold refreshment in 100% recyclable aluminum cans.',
    originYear: 1898,
    sustainabilityHighlight: '100% infinitely recyclable cans; transitioning to 100% rPET bottles across major European and North American markets.',
    flavorNotes: ['Crisp Citrus', 'Warm Spice', 'Effervescent Caramel', 'Bold Vanilla finish'],
    keyIngredients: ['Carbonated Water', 'Cane Sugar', 'Caramel Color', 'Phosphoric Acid', 'Natural Flavors', 'Caffeine'],
    badge: 'Flagship Beverage',
    imageType: 'pepsi',
  },
  {
    id: 'lays-classic',
    name: "Lay's Classic",
    tagline: 'Betcha can\'t eat just one — farm-grown crispy perfection',
    category: 'snacks',
    heroSlide: 1,
    accentColor: '#F5B335',
    secondaryColor: '#C8102E',
    calories: '160 kcal (28g serving)',
    sugarOrFat: '10g Healthy Oils',
    sodium: '170mg',
    description: 'Crafted from specially cultivated farm-grown potatoes cooked to golden crispness and sprinkled with real sea salt. Every potato is sustainably sourced through our global pep+ Positive Agriculture program.',
    originYear: 1932,
    sustainabilityHighlight: '100% of whole potatoes sourced from certified sustainable farms; 30% reduction in water usage across our agricultural fleet.',
    flavorNotes: ['Golden Potato Sweetness', 'Pure Sea Salt', 'Light Crisp Crunch'],
    keyIngredients: ['Specially Grown Farm Potatoes', 'Vegetable Oil (Canola, Corn, or Sunflower)', 'Sea Salt'],
    badge: 'World #1 Snack',
    imageType: 'lays',
  },
  {
    id: 'tropicana-pure-premium',
    name: 'Tropicana Pure Premium',
    tagline: '100% Pure Squeezed Sunshine — Never from concentrate',
    category: 'nutrition',
    heroSlide: 1,
    accentColor: '#E65100',
    secondaryColor: '#2E7D32',
    calories: '110 kcal (240ml)',
    sugarOrFat: '22g Natural Fruit Sugars (No added sugar)',
    sodium: '0mg',
    description: 'Picked at the peak of freshness from sunny orange groves. Packed with 100% daily value of Vitamin C, potassium, and folate with zero added sugar or preservatives.',
    originYear: 1947,
    sustainabilityHighlight: 'Citrus peels converted into organic biofuel and cattle feed; micro-irrigation systems save billions of gallons of water annually.',
    flavorNotes: ['Bright Valencia Orange', 'Sweet Pulp', 'Refreshing Citrus Acidity'],
    keyIngredients: ['100% Pure Squeezed Orange Juice', 'Natural Citrus Pulp'],
    badge: '100% Squeezed',
    imageType: 'tropicana',
  },
  {
    id: 'quaker-oats-classic',
    name: 'Quaker Old Fashioned Oats',
    tagline: 'Wholesome 100% whole grain oats nourishing families since 1877',
    category: 'nutrition',
    heroSlide: 1,
    accentColor: '#002B49',
    secondaryColor: '#D97706',
    calories: '150 kcal (40g dry)',
    sugarOrFat: '3g Fat, 4g Soluble Fiber',
    sodium: '0mg',
    description: '100% whole grain rolled oats that provide heart-healthy beta-glucan fiber. For over 145 years, Quaker has been the trusted breakfast staple providing sustained energy throughout the morning.',
    originYear: 1877,
    sustainabilityHighlight: 'Regenerative oat farming pilots across the Midwest; zero-waste oat hull energy reuse in manufacturing.',
    flavorNotes: ['Nutty Whole Grain', 'Warm Toasted Oat', 'Comforting Earthy Creaminess'],
    keyIngredients: ['100% Whole Grain Rolled Oats'],
    badge: 'Heart Healthy',
    imageType: 'quaker',
  },
  {
    id: 'doritos-nacho-cheese',
    name: 'Doritos Nacho Cheese',
    tagline: 'For the Bold — Unapologetically intense crunch and flavor',
    category: 'snacks',
    heroSlide: 1,
    accentColor: '#D32F2F',
    secondaryColor: '#FFA000',
    calories: '150 kcal (28g serving)',
    sugarOrFat: '8g Fat',
    sodium: '210mg',
    description: 'Triangle tortilla chips blasted with bold real cheddar and romano cheese seasonings, zesty spices, and an unmistakably loud, satisfying crunch for thrill-seekers worldwide.',
    originYear: 1966,
    sustainabilityHighlight: 'Non-GMO corn grown under precision agriculture standards; solar-powered baking lines in modern facilities.',
    flavorNotes: ['Aged Cheddar & Romano', 'Toasted Corn Masa', 'Zesty Onion & Garlic', 'Mild Tangy Heat'],
    keyIngredients: ['Whole Corn', 'Vegetable Oil', 'Cheddar & Romano Cheese', 'Whey', 'Spices'],
    badge: 'Ignite The Crunch',
    imageType: 'doritos',
  },
  {
    id: 'gatorade-thirst-quencher',
    name: 'Gatorade Thirst Quencher',
    tagline: 'The official sports drink tested in the lab, proven on the field',
    category: 'beverages',
    heroSlide: 2,
    accentColor: '#00833E',
    secondaryColor: '#F58220',
    calories: '80 kcal (355ml)',
    sugarOrFat: '21g Carbs for Rapid Hydration',
    sodium: '160mg Electrolytes',
    description: 'Formulated in 1965 by university researchers to replace crucial fluids, sodium, and potassium lost during intense athletic sweat, helping athletes perform at their peak.',
    originYear: 1965,
    sustainabilityHighlight: 'Gatorade Gx personalized hydration platform eliminates single-use plastic through reusable pods and bottles.',
    flavorNotes: ['Cool Blue Raspberry', 'Lemon-Lime Zing', 'Electrolyte Balance'],
    keyIngredients: ['Water', 'Sucrose', 'Dextrose', 'Citric Acid', 'Electrolyte Mineral Blend (Sodium & Potassium)'],
    badge: 'Athletic Hydration',
    imageType: 'gatorade',
  },
  {
    id: 'pepsi-zero-sugar',
    name: 'Pepsi Zero Sugar',
    tagline: 'Maximum taste, zero sugar — taste it to believe it',
    category: 'beverages',
    heroSlide: 2,
    accentColor: '#111827',
    secondaryColor: '#004B93',
    calories: '0 kcal',
    sugarOrFat: '0g Sugar',
    sodium: '35mg',
    description: 'Upgraded proprietary sweetener formula delivering genuine cola depth with zero calories and zero sugar, leading our health-forward beverage transition.',
    originYear: 2007,
    sustainabilityHighlight: 'Key pillar of pep+ Positive Choice goal: 67% of beverage volume will have ≤100 calories from added sugars by 2025.',
    flavorNotes: ['Crisp Cola', 'Smooth Sweetness', 'Zero Calorie Finish'],
    keyIngredients: ['Carbonated Water', 'Caramel Color', 'Aspartame & Acesulfame Potassium', 'Phosphoric Acid', 'Natural Flavor'],
    badge: 'Zero Sugar Pioneer',
    imageType: 'pepsi',
  },
  {
    id: 'sunchips-harvest-cheddar',
    name: 'SunChips Whole Grain',
    tagline: 'Waves of flavor powered by 100% whole grain goodness',
    category: 'snacks',
    heroSlide: 3,
    accentColor: '#E65100',
    secondaryColor: '#F59E0B',
    calories: '140 kcal (28g)',
    sugarOrFat: '6g Fat, 2g Fiber',
    sodium: '140mg',
    description: 'Wavy multigrain snacks made with whole wheat, corn, and oats, delivering hearty texture with 30% less fat than standard potato chips.',
    originYear: 1991,
    sustainabilityHighlight: 'SunChips Modesto facility utilizes state-of-the-art solar thermal concentrators to generate manufacturing steam.',
    flavorNotes: ['Toasted Whole Grain', 'Sharp Cheddar', 'Crisp Wave'],
    keyIngredients: ['Whole Wheat', 'Whole Corn', 'Whole Oat Flour', 'Sunflower Oil', 'Real Cheddar'],
    badge: '100% Whole Grain',
    imageType: 'sunchips',
  },
  {
    id: 'bubly-sparkling-water',
    name: 'bubly Sparkling Water',
    tagline: 'Crisp, refreshing sparkling water with playful natural fruit flavors',
    category: 'beverages',
    heroSlide: 4,
    accentColor: '#06B6D4',
    secondaryColor: '#EC4899',
    calories: '0 kcal',
    sugarOrFat: '0g Sugar / 0 Sweeteners',
    sodium: '0mg',
    description: 'Refreshing carbonated water with genuine fruit essence, zero calories, zero sweeteners, and smile-filled cans designed to brighten every moment.',
    originYear: 2018,
    sustainabilityHighlight: 'Exclusively canned in lightweight aluminum, avoiding millions of single-use PET bottles.',
    flavorNotes: ['Grapefruit Zest', 'Lime Burst', 'Crisp Effervescence'],
    keyIngredients: ['Carbonated Water', 'Natural Flavor'],
    badge: 'Clean Sparkle',
    imageType: 'bubly',
  }
];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get('category');
  const query = searchParams.get('q')?.toLowerCase();

  let filtered = [...BRANDS_DATA];

  if (category && category !== 'all') {
    filtered = filtered.filter((b) => b.category === category);
  }

  if (query) {
    filtered = filtered.filter(
      (b) =>
        b.name.toLowerCase().includes(query) ||
        b.description.toLowerCase().includes(query) ||
        b.tagline.toLowerCase().includes(query)
    );
  }

  return NextResponse.json({
    total: filtered.length,
    brands: filtered,
    categories: ['all', 'beverages', 'snacks', 'nutrition'],
  });
}
