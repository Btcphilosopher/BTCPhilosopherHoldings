import { NextRequest, NextResponse } from 'next/server';

interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  department: string;
  message: string;
  createdAt: string;
}

const contactMessages: ContactMessage[] = [];

export async function POST(req: NextRequest) {
  try {
    const data = await req.json();
    const { name, email, department, subject, message } = data;

    if (!name || !email || !message) {
      return NextResponse.json(
        { error: 'Name, email, and message are required fields.' },
        { status: 400 }
      );
    }

    const newMessage: ContactMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name,
      email,
      department: department || 'Consumer Relations',
      subject: subject || 'General Inquiry',
      message,
      createdAt: new Date().toISOString(),
    };

    contactMessages.push(newMessage);

    return NextResponse.json({
      success: true,
      message: 'Your message has been received by the PepsiCo Global Communications team. We typically respond within 24–48 business hours.',
      referenceId: newMessage.id,
    });
  } catch {
    return NextResponse.json({ error: 'Failed to process inquiry.' }, { status: 500 });
  }
}
