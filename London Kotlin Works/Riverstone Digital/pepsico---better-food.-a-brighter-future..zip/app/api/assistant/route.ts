import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';
import { BRANDS_DATA } from '../brands/route';
import { SUSTAINABILITY_GOALS } from '../sustainability/route';

export async function POST(req: NextRequest) {
  try {
    const { prompt, topic } = await req.json();

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: 'Prompt is required.' }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // High-quality deterministic fallback response if GEMINI_API_KEY is not configured
      return NextResponse.json({
        response: getCuratedAnswer(prompt),
        model: 'pepsico-knowledge-base',
      });
    }

    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `You are the official PepsiCo Corporate & Brand Intelligence specialist.
You represent PepsiCo (NASDAQ: PEP), a global leader in convenient foods and beverages with iconic brands including Pepsi, Lay's, Doritos, Quaker Oats, Tropicana, Gatorade, Cheetos, and bubly.
You guide visitors on:
1. pep+ (PepsiCo Positive) sustainability goals: Positive Agriculture (7M acres regenerative), Positive Value Chain (100% renewable operational electricity, 50% virgin plastic cut by 2030, Net Zero by 2040), Positive Choices (sodium/sugar reduction, whole grains, nuts, legumes).
2. Iconic brands history, nutritional composition, allergens, and flavor profiles.
3. Investor relations and business performance (Dividend King with 52 consecutive years of dividend increases, ~$91B net revenue).
4. Innovation in food science (air-popped technology, sodium crystal reduction, plant-based packaging).
Maintain a warm, forward-looking, inspiring, and transparent tone. Keep answers concise, factual, and formatted with clean paragraphs or bullet points.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `${systemInstruction}\n\nUser Question: ${prompt}\nTopic Focus: ${topic || 'General'}`,
            },
          ],
        },
      ],
    });

    const reply = response.text || getCuratedAnswer(prompt);

    return NextResponse.json({
      response: reply,
      model: 'gemini-2.5-flash',
    });
  } catch (error) {
    console.error('Error generating AI response:', error);
    return NextResponse.json({
      response: getCuratedAnswer('general'),
      model: 'pepsico-knowledge-fallback',
    });
  }
}

function getCuratedAnswer(query: string): string {
  const q = query.toLowerCase();
  if (q.includes('sustain') || q.includes('planet') || q.includes('pep+') || q.includes('carbon') || q.includes('water')) {
    return `PepsiCo Positive (pep+) is our end-to-end strategic transformation putting sustainability and human capital at the center of how we create value. 

Key 2030 Commitments:
• Positive Agriculture: Spreading regenerative farming practices across 7 million acres—roughly equivalent to our entire agricultural footprint.
• 100% Renewable Electricity: Successfully matched across all company-owned global operations in North America and Europe.
• 50% Virgin Plastic Reduction: Per serving across global food and beverage packaging by 2030 through rPET, reuse, and lightweighting.
• Net Water Positive: Replenishing 100% of water used in high-water-risk sites by 2030.`;
  }

  if (q.includes('stock') || q.includes('invest') || q.includes('dividend') || q.includes('financial') || q.includes('pep')) {
    return `PepsiCo, Inc. (NASDAQ: PEP) is recognized as a Dividend King with 52 consecutive annual dividend increases. 

With over $91 billion in net revenue generated across 200+ countries, our balanced portfolio spans convenient foods (58%) and beverages (42%). Our diversified global footprint, continuous operational productivity, and disciplined capital allocation deliver sustainable long-term shareholder returns.`;
  }

  if (q.includes('brand') || q.includes('lay') || q.includes('dorito') || q.includes('quaker') || q.includes('tropicana')) {
    return `PepsiCo's portfolio features 23 iconic billion-dollar brands loved by billions worldwide:
• Beverages: Pepsi, Gatorade, bubly, Mountain Dew, 7UP, Aquafina, Rockstar.
• Foods & Snacks: Lay's, Doritos, Cheetos, Ruffles, Tostitos, Fritos, SunChips, PopCorners.
• Nutrition: Quaker Oats, Tropicana (joint venture), Sabra, and Healthier Choice options.

Each brand is actively innovating to offer lower sodium, reduced saturated fat, and zero-sugar variants while preserving the craveable taste consumers expect.`;
  }

  return `Welcome to PepsiCo. Across more than 200 countries and territories, consumers enjoy PepsiCo products more than one billion times a day. Guided by PepsiCo Positive (pep+), we are transforming our business from how we source ingredients and create our foods and drinks, to how we inspire people through our iconic brands.`;
}
