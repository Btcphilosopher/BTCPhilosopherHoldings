import { NextResponse } from 'next/server';

export interface StockData {
  symbol: string;
  name: string;
  exchange: string;
  currentPrice: number;
  change: number;
  changePercent: number;
  currency: string;
  marketCap: string;
  peRatio: number;
  dividendYield: string;
  fiftyTwoWeekRange: {
    low: number;
    high: number;
  };
  quarterlyRevenue: string;
  netIncome: string;
  lastUpdated: string;
  sparkline: number[];
  intraday: { time: string; price: number }[];
  keyHighlights: string[];
}

export async function GET() {
  // Base realistic PEP stock data with subtle live fluctuation based on time
  const now = new Date();
  const minutes = now.getMinutes() + now.getSeconds() / 60;
  // Natural subtle wave
  const microDelta = Math.sin(minutes * 0.1) * 0.45;
  const currentPrice = Number((168.32 + microDelta).toFixed(2));
  const change = Number((2.07 + microDelta * 0.5).toFixed(2));
  const changePercent = Number(((change / (currentPrice - change)) * 100).toFixed(2));

  // 24-point intraday sparkline curve matching the upbeat trend in screenshot
  const sparkline = [
    166.25, 166.40, 166.10, 166.80, 167.05, 166.90, 
    167.30, 167.55, 167.20, 167.85, 168.10, 167.95, 
    168.15, 168.05, 168.25, 168.10, 168.45, 168.30, 
    168.60, 168.40, 168.55, 168.30, 168.48, currentPrice
  ];

  const intraday = sparkline.map((price, idx) => {
    const hour = 9 + Math.floor(idx * 0.3);
    const minute = Math.floor((idx * 17) % 60);
    const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')} EST`;
    return { time: timeStr, price };
  });

  const response: StockData = {
    symbol: 'PEP',
    name: 'PepsiCo, Inc.',
    exchange: 'NASDAQ',
    currentPrice,
    change,
    changePercent: changePercent > 0 ? changePercent : 1.24,
    currency: 'USD',
    marketCap: '$231.8 Billion',
    peRatio: 23.4,
    dividendYield: '3.12%',
    fiftyTwoWeekRange: {
      low: 155.83,
      high: 183.19,
    },
    quarterlyRevenue: '$28.25 Billion',
    netIncome: '$3.08 Billion',
    lastUpdated: now.toISOString(),
    sparkline,
    intraday,
    keyHighlights: [
      '52 consecutive years of dividend increases (Dividend King status)',
      'Q3 Organic Revenue growth led by International Business (+8%)',
      'Operating cash flow reinvested into pep+ regenerative agriculture',
      'Targeting $100B+ net revenue through sustainable product innovation'
    ]
  };

  return NextResponse.json(response);
}
