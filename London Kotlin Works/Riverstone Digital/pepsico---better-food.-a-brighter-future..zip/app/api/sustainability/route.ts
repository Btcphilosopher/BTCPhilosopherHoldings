import { NextResponse } from 'next/server';

export interface SustainabilityMetric {
  id: string;
  title: string;
  targetYear: number | string;
  targetPercent: number;
  currentPercent: number;
  unit: string;
  status: 'on-track' | 'achieved' | 'accelerating';
  description: string;
  icon: 'leaf' | 'recycle' | 'sprout' | 'water' | 'energy';
}

export const SUSTAINABILITY_GOALS: SustainabilityMetric[] = [
  {
    id: 'renewable-electricity',
    title: 'Renewable Electricity (Global Operations)',
    targetYear: 'Achieved',
    targetPercent: 100,
    currentPercent: 100,
    unit: '% electricity matched',
    status: 'achieved',
    description: '100% of our direct operational electricity in North America, Europe, and Latin America is now matched with renewable energy including wind, solar, and on-site generation.',
    icon: 'energy',
  },
  {
    id: 'plastic-reduction',
    title: 'Virgin Plastic Reduction',
    targetYear: 2030,
    targetPercent: 50,
    currentPercent: 36,
    unit: '% virgin plastic reduced per serving',
    status: 'on-track',
    description: 'Transitioning to 100% recycled PET (rPET), bio-based polymers, reusable packaging models (SodaStream), and packaging weight optimization across our beverage lines.',
    icon: 'recycle',
  },
  {
    id: 'sustainable-sourcing',
    title: 'Sustainable Sourcing (Key Ingredients)',
    targetYear: 2030,
    targetPercent: 100,
    currentPercent: 91,
    unit: '% ingredients verified sustainable',
    status: 'on-track',
    description: 'Working with farmers across 60 countries to source 100% of direct key agricultural crops — potatoes, whole corn, oats, and oranges — under strict regenerative practices.',
    icon: 'sprout',
  },
  {
    id: 'regenerative-agriculture',
    title: 'Positive Agriculture Acres',
    targetYear: 2030,
    targetPercent: 7000000,
    currentPercent: 4200000,
    unit: 'acres restored',
    status: 'accelerating',
    description: 'Deploying cover cropping, reduced tillage, and nutrient management to restore soil health, sequester carbon, and improve farm biodiversity.',
    icon: 'leaf',
  },
  {
    id: 'water-replenishment',
    title: 'Net Water Positive Impact',
    targetYear: 2030,
    targetPercent: 100,
    currentPercent: 78,
    unit: '% water replenished in high-risk basins',
    status: 'on-track',
    description: 'Replenishing more water than we consume in high-risk operational water basins while improving manufacturing operational water-use efficiency by over 25%.',
    icon: 'water',
  }
];

export async function GET() {
  return NextResponse.json({
    framework: 'pep+ (PepsiCo Positive)',
    pillars: [
      { name: 'Positive Agriculture', subtitle: 'Restoring the earth across 7 million acres' },
      { name: 'Positive Value Chain', subtitle: 'Net-zero emissions & circular packaging' },
      { name: 'Positive Choices', subtitle: 'Evolving our portfolio with better nutrition' },
    ],
    goals: SUSTAINABILITY_GOALS,
    impactCounters: {
      solarPanelsInstalled: '1,420,000+',
      acresUnderRegenerativeCare: '4.2 Million',
      litersWaterReplenished: '16.8 Billion',
      metricTonsPlasticAvoided: '340,000',
    }
  });
}
