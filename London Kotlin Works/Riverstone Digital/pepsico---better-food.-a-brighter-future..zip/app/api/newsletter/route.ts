import { NextRequest, NextResponse } from 'next/server';

interface NewsletterSubscription {
  email: string;
  category: 'all' | 'investor' | 'sustainability' | 'careers';
  timestamp: string;
}

// In-memory persistent record
const subscriptions: NewsletterSubscription[] = [
  { email: 'investor.relations@pepsico.com', category: 'investor', timestamp: new Date().toISOString() },
  { email: 'sustainability@pepsico.com', category: 'sustainability', timestamp: new Date().toISOString() },
];

export async function POST(req: NextRequest) {
  try {
    const { email, category = 'all' } = await req.json();

    if (!email || !email.includes('@') || !email.includes('.')) {
      return NextResponse.json(
        { success: false, message: 'Please provide a valid email address.' },
        { status: 400 }
      );
    }

    const cleanEmail = email.trim().toLowerCase();
    const existing = subscriptions.find((s) => s.email === cleanEmail && s.category === category);

    if (existing) {
      return NextResponse.json({
        success: true,
        message: 'You are already subscribed to PepsiCo communications.',
        subscribed: cleanEmail,
      });
    }

    subscriptions.push({
      email: cleanEmail,
      category,
      timestamp: new Date().toISOString(),
    });

    return NextResponse.json({
      success: true,
      message: `Thank you for subscribing to PepsiCo ${category === 'all' ? 'global' : category} updates!`,
      email: cleanEmail,
    });
  } catch {
    return NextResponse.json(
      { success: false, message: 'Invalid subscription request payload.' },
      { status: 400 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    totalSubscribers: subscriptions.length,
    topics: ['all', 'investor', 'sustainability', 'careers'],
  });
}
