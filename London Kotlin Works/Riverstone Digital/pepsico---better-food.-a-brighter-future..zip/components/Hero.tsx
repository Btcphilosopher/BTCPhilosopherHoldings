'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, ChevronLeft, ChevronRight, Sparkles, Info } from 'lucide-react';
import Image from 'next/image';

interface HeroProps {
  onOpenSustainability: () => void;
  onSelectProduct: (productId: string) => void;
}

interface SlideData {
  id: number;
  kicker: string;
  line1: string;
  line2: string;
  line3: string;
  description: string;
  buttonText: string;
  tag: string;
}

const SLIDES: SlideData[] = [
  {
    id: 1,
    kicker: 'BETTER FOOD. A BRIGHTER FUTURE.',
    line1: 'More Smiles.',
    line2: 'A Healthier Planet.',
    line3: 'A Stronger Tomorrow.',
    description:
      "At PepsiCo, we're bringing together the world's favourite brands and a healthier future — for people, communities and the planet.",
    buttonText: 'OUR SUSTAINABILITY JOURNEY',
    tag: 'Global Flagships',
  },
  {
    id: 2,
    kicker: 'PEP+ POSITIVE CHOICES.',
    line1: 'Zero Sugar.',
    line2: 'Uncompromised Taste.',
    line3: 'Guilt-Free Refreshment.',
    description:
      'Expanding our low- and no-sugar beverages and portion-controlled wholesome snacks without sacrificing the craveable flavors you adore.',
    buttonText: 'EXPLORE ZERO SUGAR',
    tag: 'Positive Nutrition',
  },
  {
    id: 3,
    kicker: 'FUELING HUMAN POTENTIAL.',
    line1: 'Electrolyte Science.',
    line2: 'Peak Athletic Flow.',
    line3: 'Built for Champions.',
    description:
      'From Gatorade Sports Science Institute hydration labs to community marathons, delivering scientifically formulated hydration and endurance fuel.',
    buttonText: 'SEE ATHLETIC SCIENCE',
    tag: 'Active Hydration',
  },
  {
    id: 4,
    kicker: 'POSITIVE AGRICULTURE & GRAINS.',
    line1: 'Regenerative Soil.',
    line2: '100% Whole Grains.',
    line3: 'Pure Heart Health.',
    description:
      'Partnering with over 60,000 farmers worldwide to nurture healthy topsoil, conserve billions of liters of water, and nourish families with wholesome oats.',
    buttonText: 'OUR FARMING COMMITMENT',
    tag: 'Farming Future',
  },
];

const HERO_PRODUCTS_SLIDE_1 = [
  {
    id: 'pepsi-original',
    name: 'Pepsi-Cola',
    tagline: 'Iconic Cola Refreshed',
    imgSrc: '/assets/extracted/product_pepsi.png',
    width: 140,
    height: 260,
    bottomOffset: 'bottom-4 sm:bottom-8 lg:bottom-12',
    leftOffset: 'left-[2%] sm:left-[4%]',
    zIndex: 20,
    glow: 'rgba(0, 75, 147, 0.45)',
    animDelay: 0,
  },
  {
    id: 'lays-classic',
    name: "Lay's Classic",
    tagline: 'Farm-Grown Crunch',
    imgSrc: '/assets/extracted/product_lays.png',
    width: 185,
    height: 315,
    bottomOffset: 'bottom-4 sm:bottom-8 lg:bottom-12',
    leftOffset: 'left-[18%] sm:left-[21%]',
    zIndex: 25,
    glow: 'rgba(245, 179, 53, 0.45)',
    animDelay: 0.2,
  },
  {
    id: 'tropicana-pure-premium',
    name: 'Tropicana 100%',
    tagline: 'Pure Squeezed Citrus',
    imgSrc: '/assets/extracted/product_tropicana.png',
    width: 130,
    height: 330,
    bottomOffset: 'bottom-4 sm:bottom-8 lg:bottom-12',
    leftOffset: 'left-[39%] sm:left-[41%]',
    zIndex: 30,
    glow: 'rgba(230, 81, 0, 0.45)',
    animDelay: 0.4,
  },
  {
    id: 'quaker-oats-classic',
    name: 'Quaker Oats',
    tagline: '100% Whole Grain',
    imgSrc: '/assets/extracted/product_quaker.png',
    width: 155,
    height: 255,
    bottomOffset: 'bottom-4 sm:bottom-8 lg:bottom-12',
    leftOffset: 'left-[58%] sm:left-[60%]',
    zIndex: 24,
    glow: 'rgba(0, 43, 73, 0.45)',
    animDelay: 0.6,
  },
  {
    id: 'doritos-nacho-cheese',
    name: 'Doritos Nacho',
    tagline: 'Bold Cheesy Crunch',
    imgSrc: '/assets/extracted/product_doritos.png',
    width: 205,
    height: 270,
    bottomOffset: 'bottom-4 sm:bottom-8 lg:bottom-12',
    leftOffset: 'left-[76%] sm:left-[77%]',
    zIndex: 22,
    glow: 'rgba(211, 47, 47, 0.45)',
    animDelay: 0.8,
  },
];

export default function Hero({ onOpenSustainability, onSelectProduct }: HeroProps) {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [hoveredProduct, setHoveredProduct] = useState<string | null>(null);

  const activeSlide = SLIDES[currentSlideIndex];

  const nextSlide = () => {
    setCurrentSlideIndex((prev) => (prev + 1) % SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlideIndex((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  return (
    <section className="relative w-full overflow-hidden select-none bg-slate-900 min-h-[580px] sm:min-h-[640px] lg:min-h-[680px]">
      {/* Exact Visual Backdrop from the reference design (Modern coastal metropolis with reflection surface) */}
      <div className="absolute inset-0 pointer-events-none">
        <Image
          src="/assets/extracted/hero_full.png"
          alt="PepsiCo Modern Metropolis & Product Showcase Background"
          fill
          priority
          className="object-cover object-center"
          referrerPolicy="no-referrer"
        />
        {/* Subtle gradient vignette to guarantee crisp WCAG text contrast on left while keeping right products sparkling */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/70 via-slate-900/35 to-transparent" />
      </div>

      <div className="relative max-w-[1536px] mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-between py-10 sm:py-14 lg:py-16 min-h-[580px] sm:min-h-[640px] lg:min-h-[680px]">
        {/* Main Hero Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center h-full">
          {/* Left Text Column: Headline, Kicker, Subtitle, and Button */}
          <div className="lg:col-span-6 xl:col-span-5 text-white z-30 pt-2 lg:pt-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSlide.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.4, ease: 'easeOut' }}
              >
                {/* Uppercase Kicker */}
                <p className="text-xs sm:text-sm font-semibold tracking-widest uppercase text-blue-200 mb-3 sm:mb-4">
                  {activeSlide.kicker}
                </p>

                {/* Big Bold Headline matching reference typography */}
                <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-[68px] font-extrabold tracking-tight leading-[1.08] text-white drop-shadow-sm mb-4 sm:mb-6">
                  <span>{activeSlide.line1}</span>
                  <br />
                  <span>{activeSlide.line2}</span>
                  <br />
                  <span className="text-white/95">{activeSlide.line3}</span>
                </h1>

                {/* Subtitle Paragraph */}
                <p className="text-sm sm:text-base text-slate-100 max-w-xl font-normal leading-relaxed mb-6 sm:mb-8 drop-shadow-sm">
                  {activeSlide.description}
                </p>

                {/* Pill Button: "OUR SUSTAINABILITY JOURNEY →" */}
                <div className="flex items-center gap-4">
                  <button
                    onClick={onOpenSustainability}
                    className="inline-flex items-center gap-3 px-6 sm:px-8 py-3 rounded-full border-2 border-white/90 text-white hover:bg-white hover:text-[#002855] text-xs sm:text-sm font-bold tracking-wider uppercase transition-all duration-300 backdrop-blur-xs group shadow-lg active:scale-95"
                  >
                    <span>{activeSlide.buttonText}</span>
                    <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Right Product Showcase Column: Interactive Animated Lineup */}
          <div className="lg:col-span-6 xl:col-span-7 relative h-[360px] sm:h-[420px] lg:h-[480px] w-full flex items-end justify-center">
            {/* The 5 Interactive Products on the reflective surface */}
            <div className="relative w-full h-full max-w-[760px] mx-auto flex items-end">
              {HERO_PRODUCTS_SLIDE_1.map((item, index) => {
                const isHovered = hoveredProduct === item.id;
                const isAnyHovered = hoveredProduct !== null;

                return (
                  <motion.div
                    key={item.id}
                    onClick={() => onSelectProduct(item.id)}
                    onMouseEnter={() => setHoveredProduct(item.id)}
                    onMouseLeave={() => setHoveredProduct(null)}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{
                      opacity: isAnyHovered && !isHovered ? 0.65 : 1,
                      scale: isHovered ? 1.08 : 1,
                      y: isHovered ? -16 : 0,
                    }}
                    transition={{
                      duration: 0.35,
                      ease: 'backOut',
                      delay: index * 0.08,
                    }}
                    className={`absolute ${item.bottomOffset} ${item.leftOffset} cursor-pointer group select-none`}
                    style={{ zIndex: isHovered ? 50 : item.zIndex }}
                  >
                    {/* Glowing Aura on Hover */}
                    <motion.div
                      animate={{
                        opacity: isHovered ? 0.9 : 0,
                        scale: isHovered ? 1.25 : 0.8,
                      }}
                      className="absolute inset-0 blur-2xl rounded-full pointer-events-none transition-all duration-300"
                      style={{ background: item.glow }}
                    />

                    {/* Interactive Floating Product Layer with CSS Float Bobbing */}
                    <div
                      className={`relative transition-transform duration-300 ${
                        index % 2 === 0 ? 'animate-float-slow' : 'animate-float-reverse'
                      }`}
                      style={{ animationDelay: `${item.animDelay}s` }}
                    >
                      <Image
                        src={item.imgSrc}
                        alt={item.name}
                        width={item.width}
                        height={item.height}
                        className="object-contain drop-shadow-2xl transition-all duration-300 group-hover:brightness-105"
                        priority
                        referrerPolicy="no-referrer"
                      />

                      {/* Tooltip hint on hover */}
                      <AnimatePresence>
                        {isHovered && (
                          <motion.div
                            initial={{ opacity: 0, y: 8, scale: 0.9 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 4, scale: 0.9 }}
                            className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white/95 text-slate-900 backdrop-blur-md px-3 py-1.5 rounded-full text-xs font-bold shadow-xl border border-slate-100 flex items-center gap-1.5 whitespace-nowrap pointer-events-none z-50"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                            <span>{item.name}</span>
                            <span className="text-[10px] text-slate-500 font-medium font-mono">
                              Inspect
                            </span>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Reflection effect under product base */}
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4/5 h-2 bg-black/25 blur-sm rounded-full pointer-events-none" />
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Right Carousel Controls: "01 / 04" and Arrows */}
        <div className="relative z-30 flex items-center justify-end pt-4 sm:pt-6">
          <div className="flex items-center space-x-4 bg-slate-950/30 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
            {/* Slide Index Display: "01 / 04" */}
            <span className="text-white text-xs sm:text-sm font-semibold tracking-wider font-mono">
              0{currentSlideIndex + 1} <span className="text-white/60">/ 0{SLIDES.length}</span>
            </span>

            {/* Left Circular Arrow */}
            <button
              onClick={prevSlide}
              aria-label="Previous Slide"
              className="w-8 h-8 rounded-full border border-white/60 flex items-center justify-center text-white hover:bg-white hover:text-slate-900 transition-all duration-200 active:scale-90"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Right Circular Arrow */}
            <button
              onClick={nextSlide}
              aria-label="Next Slide"
              className="w-8 h-8 rounded-full border border-white/60 flex items-center justify-center text-white hover:bg-white hover:text-slate-900 transition-all duration-200 active:scale-90"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
