'use client';

import React from 'react';

interface PepsiCoLogoProps {
  className?: string;
  variant?: 'color' | 'white';
  showText?: boolean;
}

export default function PepsiCoLogo({
  className = 'h-8',
  variant = 'color',
  showText = true,
}: PepsiCoLogoProps) {
  const textColor = variant === 'white' ? '#FFFFFF' : '#004B93';

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* PepsiCo Globe Emblem */}
      <svg
        viewBox="0 0 100 100"
        className="h-full w-auto aspect-square flex-shrink-0"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="50" cy="50" r="48" fill="#F3F4F6" />
        {/* Top Red Curve */}
        <path
          d="M 50 4 
             A 46 46 0 0 1 96 50 
             C 80 48, 65 38, 48 38 
             C 32 38, 18 45, 4 50 
             A 46 46 0 0 1 50 4 Z"
          fill="#D32F2F"
        />
        {/* Middle White Swirl */}
        <path
          d="M 4 50 
             C 18 45, 32 38, 48 38 
             C 65 38, 80 48, 96 50 
             C 80 58, 62 62, 48 62 
             C 30 62, 16 54, 4 50 Z"
          fill="#FFFFFF"
        />
        {/* Bottom Blue Curve */}
        <path
          d="M 4 50 
             C 16 54, 30 62, 48 62 
             C 62 62, 80 58, 96 50 
             A 46 46 0 0 1 50 96 
             A 46 46 0 0 1 4 50 Z"
          fill="#004B93"
        />
      </svg>

      {/* PEPSICO Wordmark */}
      {showText && (
        <span
          className="font-extrabold tracking-tight text-xl sm:text-2xl uppercase transition-colors"
          style={{
            color: textColor,
            fontFamily:
              'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            letterSpacing: '-0.02em',
          }}
        >
          PEPSICO
        </span>
      )}
    </div>
  );
}
