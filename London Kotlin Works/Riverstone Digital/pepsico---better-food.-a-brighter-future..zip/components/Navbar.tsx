'use client';

import React, { useState } from 'react';
import { Search, Globe, ArrowRight, Menu, X, Sparkles } from 'lucide-react';
import PepsiCoLogo from './PepsiCoLogo';

interface NavbarProps {
  onOpenSearch: () => void;
  onOpenBrands: () => void;
  onOpenSustainability: () => void;
  onOpenInnovation: () => void;
  onOpenInvestors: () => void;
  onOpenCareers: () => void;
  onOpenAbout: () => void;
  onOpenAssistant: () => void;
}

export default function Navbar({
  onOpenSearch,
  onOpenBrands,
  onOpenSustainability,
  onOpenInnovation,
  onOpenInvestors,
  onOpenCareers,
  onOpenAbout,
  onOpenAssistant,
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedRegion, setSelectedRegion] = useState('Global (English)');
  const [showRegionDropdown, setShowRegionDropdown] = useState(false);

  const regions = [
    'Global (English)',
    'North America (USA & Canada)',
    'Europe & Sub-Saharan Africa',
    'Latin America',
    'Asia Pacific, Australia & NZ',
    'Middle East & South Asia',
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-100 transition-all">
      <div className="max-w-[1536px] mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between">
        {/* Left: PepsiCo Logo */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded-md transition-transform hover:opacity-95"
          aria-label="PepsiCo Home"
        >
          <PepsiCoLogo className="h-7 sm:h-8" />
        </button>

        {/* Center Navigation Links (Desktop) */}
        <nav className="hidden lg:flex items-center space-x-7 xl:space-x-9" aria-label="Main Navigation">
          <button
            onClick={onOpenBrands}
            className="text-[13px] font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase transition-colors relative py-1 group"
          >
            OUR BRANDS
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-200 group-hover:w-full" />
          </button>

          <button
            onClick={onOpenSustainability}
            className="text-[13px] font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase transition-colors relative py-1 group"
          >
            SUSTAINABILITY
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-emerald-600 transition-all duration-200 group-hover:w-full" />
          </button>

          <button
            onClick={onOpenInnovation}
            className="text-[13px] font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase transition-colors relative py-1 group"
          >
            INNOVATION
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-sky-500 transition-all duration-200 group-hover:w-full" />
          </button>

          <button
            onClick={onOpenInvestors}
            className="text-[13px] font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase transition-colors relative py-1 group"
          >
            INVESTORS
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-200 group-hover:w-full" />
          </button>

          <button
            onClick={onOpenCareers}
            className="text-[13px] font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase transition-colors relative py-1 group"
          >
            CAREERS
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-200 group-hover:w-full" />
          </button>

          <button
            onClick={onOpenAbout}
            className="text-[13px] font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase transition-colors relative py-1 group"
          >
            ABOUT
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 transition-all duration-200 group-hover:w-full" />
          </button>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* AI Assistant button */}
          <button
            onClick={onOpenAssistant}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 rounded-full border border-blue-200 transition-all shadow-xs"
            title="Ask PepsiCo AI Assistant"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
            <span className="hidden xl:inline">Ask AI</span>
          </button>

          {/* Search Button */}
          <button
            onClick={onOpenSearch}
            className="p-2 sm:p-2.5 text-slate-700 hover:text-blue-700 hover:bg-slate-100 rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
            aria-label="Search PepsiCo"
          >
            <Search className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Region / Language Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowRegionDropdown(!showRegionDropdown)}
              className="p-2 sm:p-2.5 text-slate-700 hover:text-blue-700 hover:bg-slate-100 rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
              aria-label="Select Region and Language"
            >
              <Globe className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            {showRegionDropdown && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                  Global Region
                </div>
                {regions.map((region) => (
                  <button
                    key={region}
                    onClick={() => {
                      setSelectedRegion(region);
                      setShowRegionDropdown(false);
                    }}
                    className={`w-full text-left px-4 py-2.5 text-xs font-medium transition-colors flex items-center justify-between ${
                      selectedRegion === region
                        ? 'bg-blue-50 text-blue-700 font-semibold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{region}</span>
                    {selectedRegion === region && (
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Exact Dark Navy Pill Button from Reference Design: "→ OUR BRANDS" */}
          <button
            onClick={onOpenBrands}
            className="inline-flex items-center gap-2.5 bg-[#002855] hover:bg-[#001c3d] text-white px-4 sm:px-6 py-2 sm:py-2.5 rounded-full text-xs sm:text-[13px] font-bold tracking-wider uppercase transition-all shadow-md hover:shadow-lg active:scale-95 group"
          >
            <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5" />
            <span>OUR BRANDS</span>
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-700 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition-colors"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-6 py-5 space-y-3 shadow-lg">
          <div className="flex flex-col space-y-3">
            <button
              onClick={() => {
                onOpenBrands();
                setMobileMenuOpen(false);
              }}
              className="text-left text-sm font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase py-1.5"
            >
              OUR BRANDS
            </button>
            <button
              onClick={() => {
                onOpenSustainability();
                setMobileMenuOpen(false);
              }}
              className="text-left text-sm font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase py-1.5"
            >
              SUSTAINABILITY
            </button>
            <button
              onClick={() => {
                onOpenInnovation();
                setMobileMenuOpen(false);
              }}
              className="text-left text-sm font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase py-1.5"
            >
              INNOVATION
            </button>
            <button
              onClick={() => {
                onOpenInvestors();
                setMobileMenuOpen(false);
              }}
              className="text-left text-sm font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase py-1.5"
            >
              INVESTORS
            </button>
            <button
              onClick={() => {
                onOpenCareers();
                setMobileMenuOpen(false);
              }}
              className="text-left text-sm font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase py-1.5"
            >
              CAREERS
            </button>
            <button
              onClick={() => {
                onOpenAbout();
                setMobileMenuOpen(false);
              }}
              className="text-left text-sm font-semibold text-slate-800 hover:text-blue-700 tracking-wider uppercase py-1.5"
            >
              ABOUT
            </button>
            <button
              onClick={() => {
                onOpenAssistant();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 text-left text-sm font-semibold text-blue-700 py-1.5"
            >
              <Sparkles className="w-4 h-4 text-blue-600" />
              PEPSICO AI ASSISTANT
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
