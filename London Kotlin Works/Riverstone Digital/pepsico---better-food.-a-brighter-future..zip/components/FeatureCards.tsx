'use client';

import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Leaf, RefreshCw, Sprout, TrendingUp } from 'lucide-react';
import { StockData } from '@/app/api/stock/route';

interface FeatureCardsProps {
  onOpenBrands: () => void;
  onOpenSustainability: () => void;
  onOpenInnovation: () => void;
  onOpenInvestors: () => void;
  onSelectBrandItem?: (brandId: string) => void;
}

export default function FeatureCards({
  onOpenBrands,
  onOpenSustainability,
  onOpenInnovation,
  onOpenInvestors,
  onSelectBrandItem,
}: FeatureCardsProps) {
  const [stock, setStock] = useState<StockData | null>(null);

  useEffect(() => {
    fetch('/api/stock')
      .then((res) => res.json())
      .then((data: StockData) => setStock(data))
      .catch((err) => console.error('Failed to fetch stock data:', err));
  }, []);

  const price = stock ? stock.currentPrice.toFixed(2) : '168.32';
  const changePercent = stock ? stock.changePercent.toFixed(2) : '1.24';

  return (
    <section className="w-full bg-[#f8fafc] py-6 sm:py-8 lg:py-10">
      <div className="max-w-[1536px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 lg:gap-6">
          {/* Card 1: OUR BRANDS */}
          <div
            onClick={onOpenBrands}
            className="group relative h-[360px] sm:h-[380px] rounded-2xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col justify-between p-6 sm:p-7 border border-slate-200/60"
          >
            {/* Background image: dark metallic curved surface with Pepsi reflections */}
            <div className="absolute inset-0 z-0">
              <Image
                src="/assets/extracted/card_brands.png"
                alt="Our Brands Background"
                fill
                className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/30" />
            </div>

            {/* Shimmer light bar across card on hover */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none">
              <div className="absolute top-0 left-0 w-1/2 h-full bg-gradient-to-r from-transparent via-white/10 to-transparent transform -skew-x-20 animate-shimmer" />
            </div>

            {/* Top Text Content */}
            <div className="relative z-10 text-white">
              <span className="text-[11px] font-bold tracking-widest uppercase text-blue-200">
                OUR BRANDS
              </span>
              <h2 className="text-2xl sm:text-[26px] font-extrabold tracking-tight leading-snug mt-2 text-white">
                Iconic brands.
                <br />
                Endless possibilities.
              </h2>
              <div className="mt-4 flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-blue-300 group-hover:text-white transition-colors">
                <span>EXPLORE BRANDS</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Bottom Brand Logos Row from reference design */}
            <div className="relative z-10 pt-4 border-t border-white/15">
              <div className="flex items-center justify-between gap-1.5 overflow-x-auto py-1 scrollbar-none">
                {/* Pepsi */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectBrandItem) onSelectBrandItem('pepsi-original');
                  }}
                  className="flex flex-col items-center hover:scale-110 transition-transform"
                  title="Pepsi"
                >
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center p-1 shadow-sm">
                    <div className="w-full h-full rounded-full bg-gradient-to-br from-red-600 via-white to-blue-700" />
                  </div>
                  <span className="text-[9px] text-white/80 font-medium mt-1">pepsi</span>
                </button>

                {/* Lay's */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectBrandItem) onSelectBrandItem('lays-classic');
                  }}
                  className="flex flex-col items-center hover:scale-110 transition-transform"
                  title="Lay's"
                >
                  <div className="w-8 h-8 rounded-full bg-amber-400 border border-red-600 flex items-center justify-center text-[10px] font-extrabold text-red-600 shadow-sm">
                    Lay&apos;s
                  </div>
                  <span className="text-[9px] text-white/80 font-medium mt-1">Lay&apos;s</span>
                </button>

                {/* Tropicana */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectBrandItem) onSelectBrandItem('tropicana-pure-premium');
                  }}
                  className="flex flex-col items-center hover:scale-110 transition-transform"
                  title="Tropicana"
                >
                  <div className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[8px] font-black tracking-tighter shadow-sm">
                    Trop
                  </div>
                  <span className="text-[9px] text-white/80 font-medium mt-1">Tropicana</span>
                </button>

                {/* Quaker */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectBrandItem) onSelectBrandItem('quaker-oats-classic');
                  }}
                  className="flex flex-col items-center hover:scale-110 transition-transform"
                  title="Quaker"
                >
                  <div className="w-8 h-8 rounded-full bg-[#002B49] text-amber-400 border border-amber-400/50 flex items-center justify-center text-[8px] font-bold shadow-sm">
                    Q
                  </div>
                  <span className="text-[9px] text-white/80 font-medium mt-1">QUAKER</span>
                </button>

                {/* Doritos */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectBrandItem) onSelectBrandItem('doritos-nacho-cheese');
                  }}
                  className="flex flex-col items-center hover:scale-110 transition-transform"
                  title="Doritos"
                >
                  <div className="w-8 h-8 rounded-full bg-red-600 text-amber-300 font-extrabold text-[9px] flex items-center justify-center shadow-sm">
                    D
                  </div>
                  <span className="text-[9px] text-white/80 font-medium mt-1">Doritos</span>
                </button>

                {/* Gatorade (G) */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectBrandItem) onSelectBrandItem('gatorade-thirst-quencher');
                  }}
                  className="flex flex-col items-center hover:scale-110 transition-transform"
                  title="Gatorade"
                >
                  <div className="w-8 h-8 rounded-full bg-black text-orange-500 font-black text-xs flex items-center justify-center shadow-sm border border-orange-500">
                    G
                  </div>
                  <span className="text-[9px] text-white/80 font-medium mt-1">Gatorade</span>
                </button>
              </div>
            </div>
          </div>

          {/* Card 2: SUSTAINABILITY */}
          <div
            onClick={onOpenSustainability}
            className="group relative h-[360px] sm:h-[380px] rounded-2xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col justify-between p-6 sm:p-7 border border-slate-200/60"
          >
            {/* Background image: green hills, solar farm, wind turbines */}
            <div className="absolute inset-0 z-0">
              <Image
                src="/assets/extracted/card_sustainability.png"
                alt="PepsiCo Sustainability Solar & Agriculture"
                fill
                className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-900/30 to-black/25" />
            </div>

            {/* Top Text Content */}
            <div className="relative z-10 text-white">
              <span className="text-[11px] font-bold tracking-widest uppercase text-emerald-200">
                SUSTAINABILITY
              </span>
              <h2 className="text-2xl sm:text-[26px] font-extrabold tracking-tight leading-snug mt-2 text-white">
                Good for
                <br />
                people. Good
                <br />
                for the planet.
              </h2>
              <div className="mt-4 flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-emerald-300 group-hover:text-white transition-colors">
                <span>LEARN MORE</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Bottom 3 Sustainability Metrics Row from reference design */}
            <div className="relative z-10 pt-3 border-t border-white/20">
              <div className="grid grid-cols-3 gap-2 text-center text-white">
                <div className="flex flex-col items-center">
                  <Leaf className="w-4 h-4 text-emerald-400 mb-1" />
                  <span className="text-sm font-extrabold text-white">100%</span>
                  <span className="text-[8px] sm:text-[9px] uppercase tracking-wider text-slate-200 leading-tight mt-0.5">
                    RENEWABLE ELECTRICITY
                    <span className="block text-slate-300 text-[7px]">(GLOBAL OPERATIONS)</span>
                  </span>
                </div>

                <div className="flex flex-col items-center border-x border-white/15 px-1">
                  <RefreshCw className="w-4 h-4 text-emerald-400 mb-1 animate-spin-slow" />
                  <span className="text-sm font-extrabold text-white">50%</span>
                  <span className="text-[8px] sm:text-[9px] uppercase tracking-wider text-slate-200 leading-tight mt-0.5">
                    PLASTIC REDUCTION
                    <span className="block text-slate-300 text-[7px]">(BY 2030)</span>
                  </span>
                </div>

                <div className="flex flex-col items-center">
                  <Sprout className="w-4 h-4 text-emerald-400 mb-1" />
                  <span className="text-[11px] font-extrabold text-white">SUSTAINABLE</span>
                  <span className="text-[8px] sm:text-[9px] uppercase tracking-wider text-slate-200 leading-tight mt-0.5">
                    SOURCING
                    <span className="block text-slate-300 text-[7px]">(KEY INGREDIENTS)</span>
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Card 3: INNOVATION */}
          <div
            onClick={onOpenInnovation}
            className="group relative h-[360px] sm:h-[380px] rounded-2xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col justify-between p-6 sm:p-7 border border-slate-200/60"
          >
            {/* Background image: light blue sky with golden chips falling into white bowl */}
            <div className="absolute inset-0 z-0">
              <Image
                src="/assets/extracted/card_innovation.png"
                alt="Innovation Food Science & Crisp Potato Chips"
                fill
                className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-sky-950/70 via-transparent to-sky-900/20" />
            </div>

            {/* Top Text Content */}
            <div className="relative z-10 text-white">
              <span className="text-[11px] font-bold tracking-widest uppercase text-sky-200">
                INNOVATION
              </span>
              <h2 className="text-2xl sm:text-[26px] font-extrabold tracking-tight leading-snug mt-2 text-white drop-shadow-xs">
                Better snacks.
                <br />
                Healthier choices.
              </h2>
              <div className="mt-4 flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-sky-200 group-hover:text-white transition-colors">
                <span>EXPLORE INNOVATION</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Bottom Line matching design: "TASTIER / HEALTHIER / MORE SUSTAINABLE" */}
            <div className="relative z-10 pt-4 border-t border-white/20 text-center">
              <p className="text-[10px] sm:text-[11px] font-bold uppercase tracking-widest text-white/95 drop-shadow-xs">
                TASTIER <span className="text-sky-300 mx-1">/</span> HEALTHIER{' '}
                <span className="text-sky-300 mx-1">/</span> MORE SUSTAINABLE
              </p>
            </div>
          </div>

          {/* Card 4: INVESTORS */}
          <div
            onClick={onOpenInvestors}
            className="group relative h-[360px] sm:h-[380px] rounded-2xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col justify-between p-6 sm:p-7 border border-slate-200/60"
          >
            {/* Background image: PepsiCo headquarters glass corporate building */}
            <div className="absolute inset-0 z-0">
              <Image
                src="/assets/extracted/card_investors.png"
                alt="PepsiCo Global Corporate Headquarters"
                fill
                className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-900/20 to-black/20" />
            </div>

            {/* Top Text Content */}
            <div className="relative z-10 text-white">
              <span className="text-[11px] font-bold tracking-widest uppercase text-blue-200">
                INVESTORS
              </span>
              <h2 className="text-2xl sm:text-[26px] font-extrabold tracking-tight leading-snug mt-2 text-white">
                Creating long-term
                <br />
                value.
              </h2>
              <div className="mt-4 flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-blue-300 group-hover:text-white transition-colors">
                <span>VIEW INVESTOR RELATIONS</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Bottom Stock Ticker Bar matching reference layout: PEP $168.32 +1.24% ↑ Sparkline */}
            <div className="relative z-10 bg-[#0c2340]/90 backdrop-blur-md rounded-xl p-3 border border-white/15">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-bold tracking-wider text-slate-300 uppercase">
                    PEP
                  </div>
                  <div className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                    ${price}
                  </div>
                </div>

                <div className="flex items-center text-emerald-400 text-xs sm:text-sm font-bold gap-1 bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-500/30">
                  <span>+{changePercent}%</span>
                  <TrendingUp className="w-3.5 h-3.5 inline animate-pulse" />
                </div>

                {/* SVG Animated Sparkline Chart */}
                <div className="w-20 sm:w-24 h-8 flex items-center justify-center">
                  <svg viewBox="0 0 100 35" className="w-full h-full overflow-visible">
                    <polyline
                      fill="none"
                      stroke="#38BDF8"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      points="2,26 12,24 22,28 32,20 42,18 52,22 62,14 72,12 82,15 92,8 98,6"
                    />
                    {/* Glowing head dot */}
                    <circle cx="98" cy="6" r="3.5" fill="#38BDF8" className="animate-ping" />
                    <circle cx="98" cy="6" r="2.5" fill="#FFFFFF" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
