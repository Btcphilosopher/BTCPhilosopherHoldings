import { Product, CampaignSlide, Article } from './types';

export const CAMPAIGN_SLIDES: CampaignSlide[] = [
  {
    id: 'campaign-1',
    collectionLabel: 'THE NEW COLLECTION',
    title: 'A DIALOGUE BETWEEN PAST AND FUTURE',
    subtitle: 'Prada reimagines the everyday through a lens of timeless innovation and architectural minimalism.',
    ctaText: 'DISCOVER THE COLLECTION',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1920&auto=format&fit=crop', // Dramatic editorial woman in sunglasses looking over architectural city
    categoryFilter: 'bags',
  },
  {
    id: 'campaign-2',
    collectionLabel: 'RE-NYLON & SAFFIANO',
    title: 'MATERIALITY & REFINED DISRUPTION',
    subtitle: 'Interrogating luxury through regenerated ocean materials and historic Saffiano leather craftsmanship.',
    ctaText: 'EXPLORE RE-NYLON',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1920&auto=format&fit=crop', // Minimalist sleek black outfit fashion model
    categoryFilter: 'women',
  },
  {
    id: 'campaign-3',
    collectionLabel: 'MENSWEAR FALL / WINTER',
    title: 'TAILORING FOR A NEW ERA',
    subtitle: 'Sharp silhouettes, tactile virgin wool, and industrial hardware defining modern masculinity.',
    ctaText: 'SHOP MENSWEAR',
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1920&auto=format&fit=crop', // High fashion tailored suit model in modern structure
    categoryFilter: 'men',
  },
];

export const PRODUCTS: Product[] = [
  {
    id: 'prada-galleria-bag',
    name: 'Prada Galleria Saffiano Leather Bag',
    subtitle: 'Iconic Large Top Handle Bag',
    category: 'bags',
    gender: 'women',
    price: 4600,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1000&auto=format&fit=crop', // Black luxury handbag
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?q=80&w=1000&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'The Prada Galleria bag, named after the historic store opened in Milan in 1913, embodies the perfect synthesis of tradition and modernity. Made of signature Saffiano leather, a calfskin defined by its crosshatch texture and wax finish.',
    material: 'Saffiano Calfskin Leather & Nappa Lining',
    code: '1BA863_NZV_F0002_V_OOO',
    dimensions: 'H 24.5cm x W 13.5cm x L 32cm',
    colors: [
      { name: 'Onyx Black', hex: '#0a0a0a' },
      { name: 'Parchment White', hex: '#f0efe9' },
      { name: 'Prada Red', hex: '#a81c1c' },
    ],
    isNew: true,
    isBestseller: true,
    tag: 'Iconic Saffiano Leather',
  },
  {
    id: 'prada-triangle-shoulder-bag',
    name: 'Prada Symbole Triangle Leather Shoulder Bag',
    subtitle: 'Geometric Crossbody Bag',
    category: 'bags',
    gender: 'unisex',
    price: 3100,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?q=80&w=1000&auto=format&fit=crop', // Geometric black luxury bag
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'Defined by an architectural triangular shape that echoes the historic enamel triangle created by Mario Prada in 1913. Designed with a detachable adjustable shoulder strap and tone-on-tone embossed logo.',
    material: 'Brushed Calfskin Leather',
    code: '1BH190_2BYA_F0002_V_GRO',
    dimensions: 'H 18cm x W 11cm x L 26cm',
    colors: [
      { name: 'Nero Black', hex: '#000000' },
      { name: 'Slate Grey', hex: '#4a4b4d' },
    ],
    isNew: true,
    isBestseller: true,
    tag: 'Architectural Shape',
  },
  {
    id: 'prada-chocolate-loafers',
    name: 'Prada Chocolate Brushed Leather Loafers',
    subtitle: 'Classic Loafers with Enamel Triangle Logo',
    category: 'shoes',
    gender: 'unisex',
    price: 1290,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?q=80&w=1000&auto=format&fit=crop', // Sleek black leather shoe
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'Reinterpreting the classic penny loafer with a chunky rubber block sole and hand-stitched aprons. Finished with the enamelled metal triangle plaque across the leather band.',
    material: '100% Italian Brushed Calfskin Leather',
    code: '1D246M_ULS_F0002_F_B050',
    dimensions: 'Sole height: 50 mm',
    colors: [
      { name: 'Black High-Gloss', hex: '#111111' },
      { name: 'Cordovan Brown', hex: '#3d1c19' },
    ],
    sizes: ['EU 36', 'EU 37', 'EU 38', 'EU 39', 'EU 40', 'EU 41', 'EU 42', 'EU 43', 'EU 44'],
    isBestseller: true,
    tag: 'Hand-Crafted in Italy',
  },
  {
    id: 'prada-symbole-earrings',
    name: 'Prada Symbole Enamel Triangle Drop Earrings',
    subtitle: 'Fine Jewellery in Yellow Gold & Enamel',
    category: 'jewellery',
    gender: 'women',
    price: 790,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1630019852942-f89202989a59?q=80&w=1000&auto=format&fit=crop', // Fine luxury drop earring close up
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'Iconic drop earrings featuring the Prada triangle logo cast in high-polished yellow gold and filled with glossy black enamel. Designed with clip-on back mechanism.',
    material: 'Recycled 750 Yellow Gold (18kt) & Enamel',
    code: '1JO730_2DFP_F0002',
    dimensions: 'Height: 22mm x Width: 18mm',
    colors: [
      { name: 'Gold & Black', hex: '#d4af37' },
      { name: 'Gold & White', hex: '#fdfbf7' },
    ],
    isNew: true,
    tag: 'Fine Jewellery',
  },
  {
    id: 'prada-wool-overcoat',
    name: 'Prada Single-Breasted Virgin Wool Overcoat',
    subtitle: 'Tailored Minimalist Coat',
    category: 'men',
    gender: 'men',
    price: 4800,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1000&auto=format&fit=crop', // Model in high fashion black overcoat
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'An expression of uncompromising architectural precision. Crafted from pure heavyweight Italian virgin wool with concealed button closure, sharp notch lapel, and silk lining.',
    material: '100% Virgin Wool, 100% Cupro Lining',
    code: 'SGC032_1WQ8_F0002_S_222',
    colors: [
      { name: 'Deep Onyx', hex: '#0a0a0b' },
      { name: 'Midnight Navy', hex: '#0d131f' },
    ],
    sizes: ['IT 46', 'IT 48', 'IT 50', 'IT 52', 'IT 54'],
    isNew: true,
    tag: 'Sartorial Tailoring',
  },
  {
    id: 'prada-re-nylon-bomber',
    name: 'Prada Re-Nylon Padded Bomber Jacket',
    subtitle: 'Voluminous Oversized Silhouette',
    category: 'women',
    gender: 'women',
    price: 3200,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=1000&auto=format&fit=crop', // Minimal jacket model
      'https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'A contemporary house icon crafted from sustainable Re-Nylon fabric produced from recycled ocean plastic waste. Features an oversized cocoon shape with utility sleeve pocket accented by the enamelled metal triangle logo.',
    material: '100% Regenerated ECUANIL Nylon',
    code: '291805_1WQ8_F0002_S_212',
    colors: [
      { name: 'Nero Black', hex: '#050505' },
      { name: 'Army Olive', hex: '#2f342b' },
    ],
    sizes: ['XS', 'S', 'M', 'L'],
    isBestseller: true,
    tag: 'Re-Nylon Sustainable',
  },
  {
    id: 'prada-symbole-sunglasses',
    name: 'Prada Symbole Acetate Sunglasses',
    subtitle: 'Angular Geometric Frames',
    category: 'accessories',
    gender: 'unisex',
    price: 580,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1511499767150-a48a237f0083?q=80&w=1000&auto=format&fit=crop', // High fashion sunglasses
      'https://images.unsplash.com/photo-1572635196237-14b3f281503f?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'Bold geometric acetate sunglasses featuring faceted temples adorned with the sharp Prada logo lettering. Category 3 UV protection dark tinted lenses.',
    material: '100% Premium Acetate Frame',
    code: 'PR_17WS_4BW2A1_54',
    colors: [
      { name: 'Gloss Black', hex: '#0a0a0b' },
      { name: 'Dark Tortoise', hex: '#2e1c12' },
    ],
    tag: '100% UV Protection',
  },
  {
    id: 'prada-monolith-derby',
    name: 'Prada Monolith Brushed Leather Derby Shoes',
    subtitle: 'Chunky Lug Sole Derby',
    category: 'shoes',
    gender: 'men',
    price: 1350,
    currency: '$',
    images: [
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=1000&auto=format&fit=crop', // Black shoes
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?q=80&w=1000&auto=format&fit=crop',
    ],
    description: 'The Monolith derby shoes express a hybrid concept between classic formal footwear and industrial utilitarian style. Equipped with an ultra-lightweight oversized rubber tread sole.',
    material: 'Brushed Leather & Extralight Rubber Sole',
    code: '2EE342_3L09_F0002',
    dimensions: 'Sole height: 60 mm',
    colors: [
      { name: 'Onyx Black', hex: '#080808' },
    ],
    sizes: ['UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11'],
    tag: 'Architectural Sole',
  },
];

export const PRADA_WORLD_ARTICLES: Article[] = [
  {
    id: 'prada-frames-2026',
    category: 'EXHIBITION',
    title: 'PRADA FRAMES MILAN: MATERIALS & METAMORPHOSIS',
    description: 'A multidisciplinary symposium curated by Formafantasma exploring the complex relationship between design, ecosystems, and industrial manufacturing.',
    date: 'OCTOBER 2026',
    image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?q=80&w=1000&auto=format&fit=crop', // Modern architecture interior gallery
    location: 'Fondazione Prada, Milan',
    readTime: '4 MIN READ',
  },
  {
    id: 'fondazione-prada-brain',
    category: 'FONDAZIONE PRADA',
    title: 'HUMAN BRAINS: PRESERVING MEMORY IN DIGITAL AGES',
    description: 'The seventh chapter of Fondazione Prada’s neuroscience initiative examining how art, technology, and memory intersect.',
    date: 'SEPTEMBER 2026',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop', // Modern architectural building skyline
    location: 'Largo Isarco 2, Milan',
    readTime: '6 MIN READ',
  },
  {
    id: 'fw26-runway-dialogue',
    category: 'RUNWAY',
    title: 'THE FALL/WINTER SHOW: REDEFINING FORM',
    description: 'Miuccia Prada and Raf Simons present a collection centered on instinctive elegance, raw wool textures, and reductionist tailoring.',
    date: 'AUGUST 2026',
    image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=1000&auto=format&fit=crop', // Runway model editorial fashion
    location: 'Deposito, Fondazione Prada',
    readTime: '5 MIN READ',
  },
];
