export interface Product {
  id: string;
  name: string;
  subtitle: string;
  category: 'bags' | 'shoes' | 'women' | 'men' | 'accessories' | 'jewellery';
  gender: 'women' | 'men' | 'unisex';
  price: number;
  currency: string;
  images: string[];
  description: string;
  material: string;
  code: string;
  dimensions?: string;
  colors: { name: string; hex: string }[];
  sizes?: string[];
  isNew?: boolean;
  isBestseller?: boolean;
  tag: string;
}

export interface CartItem {
  product: Product;
  selectedColor: string;
  selectedSize?: string;
  quantity: number;
}

export interface CampaignSlide {
  id: string;
  collectionLabel: string;
  title: string;
  subtitle: string;
  ctaText: string;
  image: string;
  categoryFilter?: Product['category'];
}

export interface Article {
  id: string;
  category: string;
  title: string;
  description: string;
  date: string;
  image: string;
  location: string;
  readTime: string;
}
