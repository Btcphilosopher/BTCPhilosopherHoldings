'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, ArrowRight, Sparkles } from 'lucide-react';
import { Product } from '@/lib/types';
import { PRODUCTS } from '@/lib/products-data';
import TriangleLogo from './TriangleLogo';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSearchSubmit: (query: string) => void;
  onSelectProduct: (product: Product) => void;
  onOpenConcierge: () => void;
}

export default function SearchModal({
  isOpen,
  onClose,
  onSearchSubmit,
  onSelectProduct,
  onOpenConcierge,
}: SearchModalProps) {
  const [query, setQuery] = useState('');

  const trendingTags = [
    'Galleria Bag',
    'Chocolate Loafers',
    'Re-Nylon Bomber',
    'Triangle Earrings',
    'Symbole Sunglasses',
    'Saffiano Leather',
  ];

  const matchedProducts = query.trim()
    ? PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          p.tag.toLowerCase().includes(query.toLowerCase()) ||
          p.description.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  const handleExecuteSearch = (q: string) => {
    onSearchSubmit(q);
    onClose();
    const catalog = document.getElementById('product-catalog');
    catalog?.scrollIntoView({ behavior: 'smooth' });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/90 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="relative w-full max-w-3xl bg-neutral-950 border border-white/20 p-6 sm:p-8 z-10 shadow-2xl text-white"
        >
          <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
            <div className="flex items-center space-x-3">
              <TriangleLogo size={22} variant="silver" />
              <span className="font-serif-luxury text-base uppercase tracking-widest">
                SEARCH DIGITAL FLAGSHIP
              </span>
            </div>
            <button
              onClick={onClose}
              className="text-neutral-400 hover:text-white p-1.5 border border-white/10 hover:border-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Search Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (query.trim()) handleExecuteSearch(query);
            }}
            className="relative mb-6"
          >
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by piece name, category, or material..."
              className="w-full bg-black border border-white/30 px-12 py-4 text-sm font-serif text-white placeholder-neutral-500 focus:outline-none focus:border-white"
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            {query && (
              <button
                type="submit"
                className="absolute right-3 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-white text-black text-xs font-mono font-bold uppercase hover:bg-neutral-200"
              >
                SEARCH
              </button>
            )}
          </form>

          {/* Trending Searches */}
          {!query && (
            <div>
              <p className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest mb-3">
                TRENDING SELECTIONS
              </p>
              <div className="flex flex-wrap gap-2 mb-8">
                {trendingTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => handleExecuteSearch(tag)}
                    className="text-xs font-mono text-neutral-300 bg-black border border-white/10 hover:border-white px-3 py-1.5 uppercase transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>

              {/* Ask Concierge CTA */}
              <div
                onClick={() => {
                  onClose();
                  onOpenConcierge();
                }}
                className="p-4 border border-amber-400/30 bg-amber-400/10 text-amber-200 cursor-pointer hover:bg-amber-400/20 transition-colors flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <div>
                    <p className="text-xs font-mono font-bold uppercase">NEED PERSONAL STYLING ADVICE?</p>
                    <p className="text-[11px] font-serif text-amber-100/80">Consult our AI Private Concierge for bespoke recommendations.</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          )}

          {/* Matches List */}
          {query.trim() && (
            <div>
              <p className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest mb-3">
                MATCHES ({matchedProducts.length})
              </p>
              {matchedProducts.length === 0 ? (
                <p className="text-xs font-mono text-neutral-500 py-6 text-center">
                  NO MATCHING PRODUCTS FOUND FOR &quot;{query}&quot;.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-72 overflow-y-auto">
                  {matchedProducts.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => {
                        onClose();
                        onSelectProduct(p);
                      }}
                      className="flex items-center space-x-3 p-2 bg-black border border-white/10 hover:border-white cursor-pointer transition-colors"
                    >
                      <img src={p.images[0]} alt={p.name} className="w-12 h-14 object-cover bg-neutral-900" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-serif uppercase truncate text-white">{p.name}</p>
                        <p className="text-[10px] font-mono text-neutral-400">${p.price.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </motion.div>
      </div>
    </AnimatePresence>
  );
}
