'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, ShoppingBag, Heart } from 'lucide-react';
import { Product } from '@/lib/types';
import TriangleLogo from './TriangleLogo';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export default function WishlistDrawer({
  isOpen,
  onClose,
  products,
  onRemoveFromWishlist,
  onAddToCart,
  onSelectProduct,
}: WishlistDrawerProps) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
        />

        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="fixed inset-y-0 right-0 max-w-full flex pl-10"
        >
          <div className="w-screen max-w-md bg-neutral-950 border-l border-white/20 text-white flex flex-col justify-between shadow-2xl">
            
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-black">
              <div className="flex items-center space-x-3">
                <Heart className="w-4 h-4 text-white fill-white" />
                <h2 className="font-serif-luxury text-base font-semibold tracking-widest uppercase">
                  SAVED ITEMS ({products.length})
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-neutral-400 hover:text-white p-1.5 border border-white/10 hover:border-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {products.length === 0 ? (
                <div className="text-center py-20">
                  <TriangleLogo size={36} className="mx-auto mb-4 opacity-40" />
                  <p className="font-serif-luxury text-lg uppercase tracking-wider text-neutral-300 mb-2">
                    YOUR WISHLIST IS EMPTY
                  </p>
                  <p className="text-xs text-neutral-500 max-w-xs mx-auto mb-6">
                    Save your favorite pieces while exploring our flagship collections.
                  </p>
                  <button
                    onClick={onClose}
                    className="px-6 py-2.5 border border-white text-xs font-mono tracking-prada uppercase text-white hover:bg-white hover:text-black transition-colors"
                  >
                    EXPLORE COLLECTION
                  </button>
                </div>
              ) : (
                products.map((product) => (
                  <div
                    key={product.id}
                    className="flex space-x-4 p-3 bg-black border border-white/10 relative group"
                  >
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      onClick={() => {
                        onClose();
                        onSelectProduct(product);
                      }}
                      className="w-20 h-24 object-cover bg-neutral-900 cursor-pointer"
                    />

                    <div className="flex-1 flex flex-col justify-between min-w-0">
                      <div>
                        <div className="flex justify-between items-start">
                          <h3
                            onClick={() => {
                              onClose();
                              onSelectProduct(product);
                            }}
                            className="font-serif text-sm font-medium uppercase truncate pr-2 text-white cursor-pointer hover:text-neutral-300"
                          >
                            {product.name}
                          </h3>
                          <button
                            onClick={() => onRemoveFromWishlist(product)}
                            className="text-neutral-500 hover:text-red-400 p-0.5 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[10px] font-mono text-neutral-400 uppercase mt-0.5">
                          {product.material}
                        </p>
                      </div>

                      <div className="flex items-center justify-between mt-3">
                        <span className="font-mono text-xs font-medium text-white">
                          ${product.price.toLocaleString()}
                        </span>

                        <button
                          onClick={() => {
                            onAddToCart(product);
                            onRemoveFromWishlist(product);
                          }}
                          className="text-[10px] font-mono tracking-prada uppercase px-3 py-1 bg-white text-black font-bold hover:bg-neutral-200"
                        >
                          + MOVE TO BAG
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-4 border-t border-white/10 bg-neutral-950">
              <button
                onClick={onClose}
                className="w-full py-3 bg-neutral-900 border border-white/20 text-xs font-mono uppercase tracking-widest text-white hover:bg-neutral-800"
              >
                BACK TO SELECTION
              </button>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
