'use client';

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Eye, SlidersHorizontal, ArrowUpDown, Check, Sparkles } from 'lucide-react';
import { Product } from '@/lib/types';
import { PRODUCTS } from '@/lib/products-data';
import TriangleLogo from './TriangleLogo';

interface ProductCatalogProps {
  activeCategory: string;
  onSelectCategory: (cat: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: string[];
  searchQuery: string;
  onClearSearch: () => void;
  onOpenConcierge: () => void;
}

export default function ProductCatalog({
  activeCategory,
  onSelectCategory,
  onSelectProduct,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  searchQuery,
  onClearSearch,
  onOpenConcierge,
}: ProductCatalogProps) {
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest'>('featured');
  const [selectedGender, setSelectedGender] = useState<'all' | 'women' | 'men'>('all');
  const [hoveredProduct, setHoveredProduct] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'ALL SELECTIONS' },
    { id: 'bags', label: 'BAGS' },
    { id: 'shoes', label: 'SHOES' },
    { id: 'women', label: 'WOMEN' },
    { id: 'men', label: 'MEN' },
    { id: 'jewellery', label: 'FINE JEWELLERY' },
    { id: 'accessories', label: 'ACCESSORIES' },
  ];

  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS];

    // Filter by category
    if (activeCategory !== 'all' && activeCategory !== 'world') {
      result = result.filter(p => p.category === activeCategory);
    }

    // Filter by gender
    if (selectedGender !== 'all') {
      result = result.filter(p => p.gender === selectedGender || p.gender === 'unisex');
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.subtitle.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tag.toLowerCase().includes(q) ||
          p.material.toLowerCase().includes(q)
      );
    }

    // Sort
    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'newest') {
      result.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    }

    return result;
  }, [activeCategory, selectedGender, searchQuery, sortBy]);

  return (
    <section id="product-catalog" className="w-full bg-black py-16 sm:py-24 px-4 sm:px-6 lg:px-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 border-b border-white/10 pb-8">
          <div>
            <p className="text-[10px] font-mono tracking-prada-wide uppercase text-neutral-400 mb-2">
              AUTUMN / WINTER 2026
            </p>
            <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light tracking-tight text-white uppercase">
              THE SELECTION
            </h2>
          </div>

          <div className="mt-4 md:mt-0 flex items-center space-x-3">
            <button
              onClick={onOpenConcierge}
              className="inline-flex items-center space-x-2 px-4 py-2 border border-amber-400/40 bg-amber-400/10 text-amber-200 text-xs tracking-prada uppercase hover:bg-amber-400/20 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
              <span>CONSULT STYLIST CONCIERGE</span>
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center space-x-2 sm:space-x-6 overflow-x-auto pb-4 mb-8 no-scrollbar scroll-smooth">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`text-[11px] font-medium tracking-prada uppercase whitespace-nowrap px-3 py-1.5 transition-all ${
                activeCategory === cat.id
                  ? 'bg-white text-black font-semibold'
                  : 'text-neutral-400 hover:text-white border border-transparent hover:border-neutral-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Filters & Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-10 py-3 border-y border-white/10 text-xs font-mono text-neutral-400">
          
          {/* Gender Filter */}
          <div className="flex items-center space-x-4">
            <span className="uppercase text-[10px] tracking-widest text-neutral-500">LINE:</span>
            <button
              onClick={() => setSelectedGender('all')}
              className={`hover:text-white ${selectedGender === 'all' ? 'text-white font-bold underline underline-offset-4' : ''}`}
            >
              ALL
            </button>
            <button
              onClick={() => setSelectedGender('women')}
              className={`hover:text-white ${selectedGender === 'women' ? 'text-white font-bold underline underline-offset-4' : ''}`}
            >
              WOMEN
            </button>
            <button
              onClick={() => setSelectedGender('men')}
              className={`hover:text-white ${selectedGender === 'men' ? 'text-white font-bold underline underline-offset-4' : ''}`}
            >
              MEN
            </button>
          </div>

          {/* Results Count & Active Search Banner */}
          <div className="flex items-center space-x-3">
            {searchQuery && (
              <span className="bg-neutral-900 text-neutral-200 px-2.5 py-1 text-[10px] flex items-center space-x-2">
                <span>QUERY: &quot;{searchQuery}&quot;</span>
                <button onClick={onClearSearch} className="text-neutral-400 hover:text-white">✕</button>
              </span>
            )}
            <span className="text-[10px] tracking-widest uppercase">
              {filteredProducts.length} ITEMS FOUND
            </span>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center space-x-2">
            <ArrowUpDown className="w-3 h-3 text-neutral-500" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-black text-neutral-200 text-[11px] font-mono border-none focus:outline-none cursor-pointer uppercase"
            >
              <option value="featured">SORT: FEATURED</option>
              <option value="newest">SORT: NEW ARRIVALS</option>
              <option value="price-asc">PRICE: LOW TO HIGH</option>
              <option value="price-desc">PRICE: HIGH TO LOW</option>
            </select>
          </div>

        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-24 bg-neutral-950 border border-white/5 my-8">
            <TriangleLogo size={40} className="mx-auto mb-4 opacity-50" />
            <p className="font-serif-luxury text-xl text-neutral-300 uppercase tracking-widest mb-2">
              NO PIECES MATCH YOUR CRITERIA
            </p>
            <p className="text-xs text-neutral-500 max-w-md mx-auto mb-6">
              Our digital catalog is updated daily. Try clearing active filters or consult our AI Luxury Concierge for boutique availability.
            </p>
            <button
              onClick={() => {
                onSelectCategory('all');
                setSelectedGender('all');
                onClearSearch();
              }}
              className="px-6 py-2.5 border border-white text-xs tracking-prada uppercase text-white hover:bg-white hover:text-black transition-colors"
            >
              RESET FILTERS
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {filteredProducts.map((product) => {
              const isWishlisted = wishlistIds.includes(product.id);
              const currentImg =
                hoveredProduct === product.id && product.images[1]
                  ? product.images[1]
                  : product.images[0];

              return (
                <motion.div
                  key={product.id}
                  layout
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  onMouseEnter={() => setHoveredProduct(product.id)}
                  onMouseLeave={() => setHoveredProduct(null)}
                  className="group relative flex flex-col justify-between bg-neutral-950 border border-white/5 hover:border-white/20 transition-all duration-300 p-4"
                >
                  {/* Top Badges */}
                  <div className="flex items-center justify-between mb-3 z-10">
                    <span className="text-[9px] font-mono tracking-widest text-neutral-400 bg-neutral-900 px-2 py-0.5 uppercase">
                      {product.tag}
                    </span>

                    {/* Wishlist Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleWishlist(product);
                      }}
                      className="text-neutral-400 hover:text-white p-1 transition-colors"
                      aria-label="Add to wishlist"
                    >
                      <Heart
                        className={`w-4 h-4 transition-colors ${
                          isWishlisted ? 'fill-white text-white' : 'stroke-[1.5]'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Product Image Container */}
                  <div
                    onClick={() => onSelectProduct(product)}
                    className="relative w-full aspect-[4/5] bg-neutral-900 cursor-pointer overflow-hidden mb-4 flex items-center justify-center"
                  >
                    <img
                      src={currentImg}
                      alt={product.name}
                      className="w-full h-full object-cover object-center img-editorial-zoom opacity-90 brightness-95 group-hover:brightness-100"
                    />

                    {/* Prada Small Triangle Overlay Accent */}
                    <div className="absolute bottom-2 left-2 opacity-80 group-hover:opacity-100 transition-opacity">
                      <TriangleLogo size={20} variant="silver" />
                    </div>

                    {/* Hover Quick View Trigger */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectProduct(product);
                        }}
                        className="px-4 py-2 bg-white text-black text-[10px] font-bold tracking-prada uppercase shadow-xl hover:bg-neutral-200 transition-colors flex items-center space-x-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>QUICK VIEW</span>
                      </button>
                    </div>
                  </div>

                  {/* Product Metadata */}
                  <div className="flex flex-col flex-1 justify-between">
                    <div>
                      <h3
                        onClick={() => onSelectProduct(product)}
                        className="font-serif-luxury text-base font-normal uppercase tracking-wide text-white group-hover:text-neutral-300 transition-colors cursor-pointer line-clamp-1 mb-1"
                      >
                        {product.name}
                      </h3>
                      <p className="text-[11px] text-neutral-400 font-serif italic mb-3 line-clamp-1">
                        {product.subtitle}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-white/10 mt-auto">
                      <span className="font-mono text-sm tracking-widest text-white font-medium">
                        {product.currency}{product.price.toLocaleString()}
                      </span>

                      <button
                        onClick={() => onAddToCart(product)}
                        className="text-[10px] tracking-prada uppercase text-neutral-300 hover:text-white font-mono py-1 px-2.5 border border-white/20 hover:border-white hover:bg-white hover:text-black transition-all"
                      >
                        + ADD TO BAG
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
}
