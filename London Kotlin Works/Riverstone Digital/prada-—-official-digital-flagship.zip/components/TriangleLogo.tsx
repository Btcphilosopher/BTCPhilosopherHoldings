'use client';

import React from 'react';

interface TriangleLogoProps {
  className?: string;
  size?: number;
  variant?: 'black' | 'gold' | 'silver';
}

export default function TriangleLogo({
  className = '',
  size = 28,
  variant = 'silver'
}: TriangleLogoProps) {
  const borderColors = {
    silver: '#e2e8f0',
    gold: '#d4af37',
    black: '#1f1f23',
  };

  return (
    <div className={`inline-flex flex-col items-center justify-center ${className}`}>
      <svg
        width={size}
        height={Math.round(size * 0.86)}
        viewBox="0 0 100 86"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-300 hover:scale-105"
      >
        {/* Triangle Outer Frame */}
        <polygon
          points="50,4 96,82 4,82"
          fill="#0a0a0c"
          stroke={borderColors[variant]}
          strokeWidth="3.5"
        />
        {/* Inner Border Line */}
        <polygon
          points="50,11 89,77 11,77"
          fill="none"
          stroke={borderColors[variant]}
          strokeWidth="1.2"
          strokeOpacity="0.6"
        />
        {/* PRADA Text */}
        <text
          x="50"
          y="42"
          fill="#ffffff"
          fontSize="15"
          fontWeight="800"
          fontFamily="serif"
          textAnchor="middle"
          letterSpacing="2.5"
        >
          PRADA
        </text>
        {/* MILANO subtitle */}
        <text
          x="50"
          y="56"
          fill="#d1d5db"
          fontSize="7"
          fontWeight="500"
          fontFamily="sans-serif"
          textAnchor="middle"
          letterSpacing="1.5"
        >
          MILANO
        </text>
        {/* Small coat of arms / star accent */}
        <circle cx="50" cy="65" r="1.5" fill={borderColors[variant]} />
      </svg>
    </div>
  );
}
