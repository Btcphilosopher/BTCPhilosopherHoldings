'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, Plus, Minus, ShieldCheck, Gift, ArrowRight } from 'lucide-react';
import { CartItem } from '@/lib/types';
import TriangleLogo from './TriangleLogo';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}: CartDrawerProps) {
  const [promoCode, setPromoCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [giftWrap, setGiftWrap] = useState(true);

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discount = discountApplied ? subtotal * 0.1 : 0;
  const total = Math.max(0, subtotal - discount);

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'VIP' || promoCode.trim().toUpperCase() === 'PRADA2026') {
      setDiscountApplied(true);
    } else {
      alert('Invalid promotional code. Please check with your client advisor.');
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
        />

        {/* Slide-over Drawer */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="fixed inset-y-0 right-0 max-w-full flex pl-10"
        >
          <div className="w-screen max-w-md bg-neutral-950 border-l border-white/20 text-white flex flex-col justify-between shadow-2xl">
            
            {/* Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-black">
              <div className="flex items-center space-x-3">
                <TriangleLogo size={22} variant="silver" />
                <h2 className="font-serif-luxury text-base font-semibold tracking-widest uppercase">
                  SHOPPING BAG ({items.length})
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-neutral-400 hover:text-white p-1.5 border border-white/10 hover:border-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Bag Items List */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {items.length === 0 ? (
                <div className="text-center py-20">
                  <TriangleLogo size={36} className="mx-auto mb-4 opacity-40" />
                  <p className="font-serif-luxury text-lg uppercase tracking-wider text-neutral-300 mb-2">
                    YOUR SHOPPING BAG IS EMPTY
                  </p>
                  <p className="text-xs text-neutral-500 max-w-xs mx-auto mb-6">
                    Explore our current collection of Saffiano leather bags, Italian wool outerwear, and fine jewellery.
                  </p>
                  <button
                    onClick={onClose}
                    className="px-6 py-2.5 border border-white text-xs font-mono tracking-prada uppercase text-white hover:bg-white hover:text-black transition-colors"
                  >
                    CONTINUE SHOPPING
                  </button>
                </div>
              ) : (
                items.map((item) => (
                  <div
                    key={`${item.product.id}-${item.selectedColor}-${item.selectedSize}`}
                    className="flex space-x-4 p-3 bg-black border border-white/10 relative group"
                  >
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-20 h-24 object-cover bg-neutral-900"
                    />

                    <div className="flex-1 flex flex-col justify-between min-w-0">
                      <div>
                        <div className="flex justify-between items-start">
                          <h3 className="font-serif text-sm font-medium uppercase truncate pr-2 text-white">
                            {item.product.name}
                          </h3>
                          <button
                            onClick={() => onRemoveItem(item.product.id)}
                            className="text-neutral-500 hover:text-red-400 p-0.5 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[10px] font-mono text-neutral-400 uppercase mt-0.5">
                          COLOR: {item.selectedColor} {item.selectedSize ? `| SIZE: ${item.selectedSize}` : ''}
                        </p>
                      </div>

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center border border-white/20 text-xs font-mono">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            className="px-2 py-0.5 text-neutral-400 hover:text-white"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 py-0.5 text-white">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="px-2 py-0.5 text-neutral-400 hover:text-white"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <span className="font-mono text-xs font-medium text-white">
                          ${(item.product.price * item.quantity).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer Summary & Checkout */}
            {items.length > 0 && (
              <div className="p-5 border-t border-white/10 bg-neutral-950 space-y-4">
                
                {/* Gift Wrap Toggle */}
                <div
                  onClick={() => setGiftWrap(!giftWrap)}
                  className="flex items-center justify-between p-3 bg-black border border-white/10 cursor-pointer hover:border-white/30 transition-colors"
                >
                  <div className="flex items-center space-x-2.5">
                    <Gift className="w-4 h-4 text-emerald-400" />
                    <span className="text-[11px] font-mono uppercase text-neutral-200">
                      Signature Prada Packaging & Gift Card
                    </span>
                  </div>
                  <input type="checkbox" checked={giftWrap} readOnly className="accent-white" />
                </div>

                {/* Promo Code Input */}
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="VIP PROMO CODE"
                    className="flex-1 bg-black border border-white/20 px-3 py-2 text-xs font-mono uppercase text-white placeholder-neutral-500 focus:outline-none focus:border-white"
                  />
                  <button
                    onClick={handleApplyPromo}
                    className="px-3 py-2 bg-neutral-800 text-white text-xs font-mono uppercase hover:bg-neutral-700"
                  >
                    APPLY
                  </button>
                </div>

                {/* Price Breakdown */}
                <div className="space-y-1.5 text-xs font-mono text-neutral-400 pt-2 border-t border-white/10">
                  <div className="flex justify-between">
                    <span>SUBTOTAL</span>
                    <span className="text-white">${subtotal.toLocaleString()}</span>
                  </div>
                  {discountApplied && (
                    <div className="flex justify-between text-emerald-400">
                      <span>VIP CLIENT PREFERENCE (10%)</span>
                      <span>-${discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>EXPRESS SHIPPING</span>
                    <span className="text-emerald-400">COMPLIMENTARY</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-white/10">
                    <span>ESTIMATED TOTAL</span>
                    <span>${total.toLocaleString()}</span>
                  </div>
                </div>

                {/* Proceed Button */}
                <button
                  onClick={onProceedToCheckout}
                  className="w-full py-4 bg-white text-black text-xs font-bold tracking-prada uppercase hover:bg-neutral-200 transition-colors flex items-center justify-center space-x-2 shadow-xl"
                >
                  <span>PROCEED TO SECURE CHECKOUT</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

              </div>
            )}

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
