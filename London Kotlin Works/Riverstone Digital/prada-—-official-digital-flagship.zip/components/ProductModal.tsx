'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Heart, ShieldCheck, Truck, Sparkles, MapPin, Check } from 'lucide-react';
import { Product } from '@/lib/types';
import TriangleLogo from './TriangleLogo';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, color: string, size?: string) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  onOpenConciergeWithPrompt: (prompt: string) => void;
}

export default function ProductModal({
  product,
  onClose,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
  onOpenConciergeWithPrompt,
}: ProductModalProps) {
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState(product?.colors[0]?.name || '');
  const [selectedSize, setSelectedSize] = useState(product?.sizes ? product.sizes[0] : undefined);
  const [addedToast, setAddedToast] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, selectedColor, selectedSize);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/90 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          transition={{ duration: 0.3 }}
          className="relative w-full max-w-5xl bg-neutral-950 border border-white/20 shadow-2xl z-10 overflow-hidden my-auto max-h-[92vh] flex flex-col lg:flex-row"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 text-neutral-400 hover:text-white p-2 bg-black/60 border border-white/10 hover:border-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Left Column: Image Gallery */}
          <div className="w-full lg:w-1/2 bg-black p-6 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-white/10">
            {/* Main Image View */}
            <div className="relative w-full aspect-square bg-neutral-900 overflow-hidden flex items-center justify-center mb-4">
              <img
                src={product.images[selectedImgIndex] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute top-4 left-4">
                <TriangleLogo size={28} variant="gold" />
              </div>
            </div>

            {/* Gallery Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex items-center space-x-3 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImgIndex(idx)}
                    className={`relative w-16 h-16 border transition-all ${
                      selectedImgIndex === idx
                        ? 'border-white opacity-100'
                        : 'border-white/10 opacity-50 hover:opacity-80'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Product Details & Purchase Actions */}
          <div className="w-full lg:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto">
            <div>
              {/* Product Category Tag */}
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-mono tracking-prada-wide uppercase text-amber-300">
                  {product.tag}
                </span>
                <span className="text-[10px] font-mono text-neutral-500 uppercase">
                  REF: {product.code}
                </span>
              </div>

              {/* Title & Subtitle */}
              <h1 className="font-serif-luxury text-2xl sm:text-3xl font-light uppercase tracking-wide text-white mb-1">
                {product.name}
              </h1>
              <p className="font-serif italic text-sm text-neutral-400 mb-4">
                {product.subtitle}
              </p>

              {/* Price */}
              <div className="text-xl font-mono text-white tracking-widest font-semibold mb-6 pb-4 border-b border-white/10">
                {product.currency}{product.price.toLocaleString()}
              </div>

              {/* Description */}
              <p className="text-xs text-neutral-300 font-light leading-relaxed mb-6">
                {product.description}
              </p>

              {/* Material Spec */}
              <div className="bg-neutral-900/80 p-3 border border-white/10 mb-6 text-xs font-mono text-neutral-300">
                <div className="text-[10px] text-neutral-500 uppercase mb-1">CRAFTSMANSHIP & MATERIAL</div>
                <p className="text-white font-medium">{product.material}</p>
                {product.dimensions && (
                  <p className="text-neutral-400 text-[11px] mt-1">{product.dimensions}</p>
                )}
              </div>

              {/* Color Swatches */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono tracking-widest uppercase text-neutral-400">
                    COLOR: <span className="text-white">{selectedColor}</span>
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  {product.colors.map((col) => (
                    <button
                      key={col.name}
                      onClick={() => setSelectedColor(col.name)}
                      className={`relative w-7 h-7 rounded-full border-2 transition-all p-0.5 ${
                        selectedColor === col.name ? 'border-white scale-110' : 'border-neutral-700 hover:border-neutral-500'
                      }`}
                      title={col.name}
                    >
                      <span
                        className="block w-full h-full rounded-full"
                        style={{ backgroundColor: col.hex }}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector (If applicable) */}
              {product.sizes && (
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-neutral-400">
                      SELECT SIZE
                    </span>
                    <button className="text-[10px] font-mono text-neutral-400 underline uppercase">
                      SIZE GUIDE
                    </button>
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {product.sizes.map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setSelectedSize(sz)}
                        className={`py-2 text-xs font-mono border transition-all ${
                          selectedSize === sz
                            ? 'bg-white text-black border-white font-bold'
                            : 'border-neutral-800 text-neutral-300 hover:border-neutral-500'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="mt-6 pt-6 border-t border-white/10 space-y-3">
              {/* Add to Bag Button */}
              <button
                onClick={handleAdd}
                className="w-full py-3.5 bg-white text-black text-xs font-bold tracking-prada uppercase hover:bg-neutral-200 transition-colors flex items-center justify-center space-x-2"
              >
                {addedToast ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>ADDED TO SHOPPING BAG</span>
                  </>
                ) : (
                  <span>ADD TO SHOPPING BAG</span>
                )}
              </button>

              <div className="grid grid-cols-2 gap-3">
                {/* Save to Wishlist */}
                <button
                  onClick={() => onToggleWishlist(product)}
                  className="py-2.5 border border-white/20 text-xs tracking-prada uppercase text-neutral-200 hover:border-white transition-colors flex items-center justify-center space-x-2"
                >
                  <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-white text-white' : ''}`} />
                  <span>{isWishlisted ? 'SAVED' : 'SAVE TO WISHLIST'}</span>
                </button>

                {/* Consult AI Stylist about this piece */}
                <button
                  onClick={() => {
                    onClose();
                    onOpenConciergeWithPrompt(
                      `How should I style the ${product.name}? What pieces match well with this item for a luxury event?`
                    );
                  }}
                  className="py-2.5 border border-amber-400/40 bg-amber-400/10 text-amber-200 text-[11px] tracking-prada uppercase hover:bg-amber-400/20 transition-colors flex items-center justify-center space-x-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>STYLE ADVICE</span>
                </button>
              </div>

              {/* Boutique & Delivery Highlights */}
              <div className="pt-4 flex items-center justify-between text-[10px] font-mono text-neutral-400 border-t border-white/5">
                <div className="flex items-center space-x-1">
                  <Truck className="w-3 h-3 text-neutral-500" />
                  <span>Complimentary Express Shipping</span>
                </div>
                <div className="flex items-center space-x-1">
                  <MapPin className="w-3 h-3 text-neutral-500" />
                  <span>Boutique Pickup Available</span>
                </div>
              </div>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
