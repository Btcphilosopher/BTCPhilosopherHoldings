'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { CAMPAIGN_SLIDES } from '@/lib/products-data';

interface HeroCarouselProps {
  onSelectCategory: (category: string) => void;
}

export default function HeroCarousel({ onSelectCategory }: HeroCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % CAMPAIGN_SLIDES.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const slide = CAMPAIGN_SLIDES[currentIndex];

  return (
    <section className="relative w-full min-h-[85vh] lg:min-h-screen bg-black pt-20 flex flex-col justify-between overflow-hidden border-b border-white/10">
      <AnimatePresence mode="wait">
        <motion.div
          key={slide.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0 w-full h-full"
        >
          {/* Background Image Container */}
          <div className="relative w-full h-full">
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover object-center filter brightness-[0.85] contrast-[1.08]"
            />
            {/* Dark gradient overlays to match screenshot lighting */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent lg:w-3/5" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30" />
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Hero Content Overlay (Left Aligned matching screenshot) */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-6 lg:px-12 pt-16 sm:pt-24 lg:pt-32 pb-16 my-auto">
        <div className="max-w-xl">
          {/* Label */}
          <motion.p
            key={`label-${currentIndex}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-[11px] font-mono tracking-prada-wide text-neutral-400 uppercase mb-4"
          >
            {slide.collectionLabel}
          </motion.p>

          {/* Heading */}
          <motion.h1
            key={`title-${currentIndex}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="font-serif-luxury text-3xl sm:text-5xl lg:text-6xl font-normal leading-[1.1] text-white tracking-tight uppercase mb-6"
          >
            {slide.title}
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            key={`sub-${currentIndex}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="font-serif italic text-base sm:text-lg text-neutral-300 font-light mb-8 max-w-md leading-relaxed"
          >
            {slide.subtitle}
          </motion.p>

          {/* CTA Link */}
          <motion.div
            key={`cta-${currentIndex}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
          >
            <button
              onClick={() => {
                if (slide.categoryFilter) {
                  onSelectCategory(slide.categoryFilter);
                }
                const catalog = document.getElementById('product-catalog');
                catalog?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="group inline-flex items-center space-x-3 text-xs tracking-prada uppercase text-white font-medium hover:text-neutral-300 transition-colors py-2 border-b border-white hover:border-neutral-400"
            >
              <span>{slide.ctaText}</span>
              <span className="transform group-hover:translate-x-1.5 transition-transform duration-300">⟶</span>
            </button>
          </motion.div>
        </div>
      </div>

      {/* Bottom Controls / Numbered Pagination matching screenshot (01 02 03) */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-6 lg:px-12 pb-8 flex items-center justify-between">
        {/* Subtle scroll hint */}
        <div className="hidden sm:flex items-center space-x-3 text-[10px] tracking-prada uppercase text-neutral-400">
          <div className="w-8 h-[1px] bg-neutral-600" />
          <span>AUTUMN / WINTER 2026</span>
        </div>

        {/* Slide pagination numbers matching user image */}
        <div className="flex items-center space-x-6 ml-auto">
          {CAMPAIGN_SLIDES.map((item, idx) => (
            <button
              key={item.id}
              onClick={() => setCurrentIndex(idx)}
              className="group relative focus:outline-none py-2"
            >
              <span
                className={`text-xs font-mono tracking-widest transition-colors ${
                  currentIndex === idx ? 'text-white font-bold' : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                0{idx + 1}
              </span>
              {currentIndex === idx && (
                <motion.div
                  layoutId="heroSlideLine"
                  className="absolute bottom-0 left-0 right-0 h-[2px] bg-white"
                />
              )}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
