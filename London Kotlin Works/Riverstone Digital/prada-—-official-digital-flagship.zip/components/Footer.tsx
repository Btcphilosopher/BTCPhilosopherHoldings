'use client';

import React, { useState } from 'react';
import { Instagram, Facebook, Youtube, ChevronDown, Check } from 'lucide-react';
import TriangleLogo from './TriangleLogo';

interface FooterProps {
  onSelectCategory: (cat: string) => void;
}

export default function Footer({ onSelectCategory }: FooterProps) {
  const [region, setRegion] = useState('UNITED STATES ($ USD)');
  const [showRegionMenu, setShowRegionMenu] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const regions = [
    'UNITED STATES ($ USD)',
    'UNITED KINGDOM (£ GBP)',
    'ITALY / EUROPE (€ EUR)',
    'JAPAN (¥ JPY)',
    'INTERNATIONAL ($ USD)',
  ];

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setNewsletterEmail('');
    }
  };

  return (
    <footer className="w-full bg-black text-white border-t border-white/10 pt-16 pb-12 px-6 lg:px-12">
      <div className="max-w-[1920px] mx-auto">
        
        {/* Top Newsletter & Boutique Finder Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-16 border-b border-white/10">
          
          <div className="lg:col-span-5">
            <div className="flex items-center space-x-3 mb-4">
              <TriangleLogo size={24} variant="silver" />
              <span className="font-serif-luxury text-lg tracking-widest uppercase text-white">
                PRADA NEWSLETTER
              </span>
            </div>
            <p className="text-xs font-serif text-neutral-400 mb-4 max-w-md">
              Subscribe to receive private invitations to runway previews, new collection drops, and Fondazione Prada art exhibitions.
            </p>
            <form onSubmit={handleSubscribe} className="flex max-w-md">
              <input
                type="email"
                required
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                placeholder="ENTER YOUR EMAIL ADDRESS"
                className="flex-1 bg-neutral-950 border border-white/20 px-3.5 py-2.5 text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-white uppercase"
              />
              <button
                type="submit"
                className="px-5 py-2.5 bg-white text-black text-xs font-mono font-bold tracking-widest uppercase hover:bg-neutral-200 transition-colors"
              >
                {subscribed ? 'SUBSCRIBED' : 'SUBSCRIBE'}
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-6 text-xs font-mono text-neutral-400 uppercase">
            <div>
              <p className="text-white font-bold tracking-widest mb-3">CLIENT SERVICES</p>
              <ul className="space-y-2 text-[11px]">
                <li><a href="#" className="hover:text-white transition-colors">Contact Client Advisor</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Book Boutique Appointment</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Track Order Status</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Complimentary Returns</a></li>
              </ul>
            </div>

            <div>
              <p className="text-white font-bold tracking-widest mb-3">MAISON PRADA</p>
              <ul className="space-y-2 text-[11px]">
                <li><a href="#" className="hover:text-white transition-colors">Fondazione Prada</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Prada Group Sustainability</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Prada Frames Milan</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers & Heritage</a></li>
              </ul>
            </div>

            <div>
              <p className="text-white font-bold tracking-widest mb-3">LEGAL & PRIVACY</p>
              <ul className="space-y-2 text-[11px]">
                <li><a href="#" className="hover:text-white transition-colors">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Notice</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Cookie Preferences</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Accessibility Statement</a></li>
              </ul>
            </div>
          </div>

        </div>

        {/* Bottom Bar matching screenshot layout */}
        <div className="pt-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          {/* Logo Left */}
          <div className="flex items-center space-x-6">
            <span className="font-serif-luxury text-3xl font-extrabold tracking-widest text-white uppercase">
              PRADA
            </span>
            <span className="text-[10px] font-mono text-neutral-500 uppercase">
              © PRADA 2026 | ALL RIGHTS RESERVED
            </span>
          </div>

          {/* Nav quick links center matching image */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-[10px] font-mono tracking-prada text-neutral-400 uppercase">
            <a href="#" className="hover:text-white">CONTACT</a>
            <a href="#" className="hover:text-white">SHIPPING</a>
            <a href="#" className="hover:text-white">RETURNS</a>
            <a href="#" className="hover:text-white">LEGAL</a>
            <a href="#" className="hover:text-white">PRIVACY</a>
            <a href="#" className="hover:text-white">NEWSLETTER</a>
          </div>

          {/* Socials & Region Right matching image */}
          <div className="flex items-center space-x-6 relative">
            <div className="flex items-center space-x-3 text-neutral-400">
              <a href="#" className="hover:text-white transition-colors"><Instagram className="w-4 h-4" /></a>
              <a href="#" className="hover:text-white transition-colors"><Facebook className="w-4 h-4" /></a>
              <a href="#" className="hover:text-white transition-colors"><Youtube className="w-4 h-4" /></a>
            </div>

            {/* Region Selector dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowRegionMenu(!showRegionMenu)}
                className="flex items-center space-x-1.5 text-[10px] font-mono tracking-prada text-neutral-300 hover:text-white uppercase py-1 border-b border-neutral-700"
              >
                <span>{region}</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {showRegionMenu && (
                <div className="absolute right-0 bottom-8 bg-neutral-950 border border-white/20 p-2 shadow-2xl z-20 min-w-[200px]">
                  {regions.map((r) => (
                    <button
                      key={r}
                      onClick={() => {
                        setRegion(r);
                        setShowRegionMenu(false);
                      }}
                      className="w-full text-left px-3 py-1.5 text-[10px] font-mono text-neutral-300 hover:bg-neutral-900 hover:text-white uppercase block"
                    >
                      {r}
                    </button>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </footer>
  );
}
