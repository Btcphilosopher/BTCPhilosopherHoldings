'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PRADA_WORLD_ARTICLES } from '@/lib/products-data';
import { Article } from '@/lib/types';
import { ArrowRight, Globe, Compass, X } from 'lucide-react';
import TriangleLogo from './TriangleLogo';

export default function PradaWorld() {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  return (
    <section id="prada-world-section" className="w-full bg-black py-16 lg:py-24 border-t border-white/10">
      <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-12">
        
        {/* Section Title Banner matching user image layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 bg-neutral-950 border border-white/10 overflow-hidden">
          
          {/* Left Column: High-fashion architectural photo gallery (7 cols) */}
          <div className="lg:col-span-7 relative min-h-[420px] lg:min-h-[580px] group overflow-hidden bg-neutral-900">
            <img
              src="https://images.unsplash.com/photo-1513694203232-719a280e022f?q=80&w=1600&auto=format&fit=crop"
              alt="Fondazione Prada Gallery"
              className="w-full h-full object-cover object-center img-editorial-zoom opacity-90 brightness-90 group-hover:brightness-100"
            />
            {/* Architectural overlay details */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 p-8 flex flex-col justify-between">
              <div className="flex items-center space-x-2">
                <TriangleLogo size={24} variant="silver" />
                <span className="text-[10px] font-mono tracking-prada-wide uppercase text-neutral-300">
                  FONDAZIONE PRADA — MILANO
                </span>
              </div>
              <div>
                <p className="text-xs font-mono text-neutral-400 uppercase mb-1">CURRENT EXHIBITION</p>
                <p className="font-serif-luxury text-xl text-white uppercase tracking-wider">
                  MATERIAL METAMORPHOSIS & ARCHITECTURAL DISRUPTION
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Text Card matching screenshot (5 cols) */}
          <div className="lg:col-span-5 p-8 sm:p-12 lg:p-16 flex flex-col justify-between bg-black">
            <div>
              <p className="text-[11px] font-mono tracking-prada-wide uppercase text-neutral-400 mb-6">
                PRADA WORLD
              </p>
              
              <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white uppercase tracking-tight leading-[1.1] mb-6">
                ART, CULTURE,<br />STYLE
              </h2>

              <p className="font-serif italic text-base sm:text-lg text-neutral-300 font-light mb-8 leading-relaxed">
                Explore our ongoing projects, exhibitions, sustainability initiatives, and multidisciplinary collaborations defining the global cultural vanguard.
              </p>
            </div>

            {/* Articles List Trigger */}
            <div className="space-y-6 pt-6 border-t border-white/10">
              {PRADA_WORLD_ARTICLES.map((article) => (
                <div
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="group cursor-pointer py-2 border-b border-white/5 hover:border-white/30 transition-colors"
                >
                  <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400 uppercase mb-1">
                    <span>{article.category}</span>
                    <span>{article.readTime}</span>
                  </div>
                  <h3 className="font-serif-luxury text-lg text-neutral-200 group-hover:text-white transition-colors uppercase">
                    {article.title}
                  </h3>
                </div>
              ))}

              <button
                onClick={() => setSelectedArticle(PRADA_WORLD_ARTICLES[0])}
                className="group inline-flex items-center space-x-3 text-xs tracking-prada uppercase text-white font-medium hover:text-neutral-300 transition-colors pt-4"
              >
                <span>DISCOVER MORE</span>
                <span className="transform group-hover:translate-x-2 transition-transform duration-300">⟶</span>
              </button>
            </div>

          </div>

        </div>

      </div>

      {/* Article Reader Modal */}
      <AnimatePresence>
        {selectedArticle && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedArticle(null)}
              className="fixed inset-0 bg-black/90 backdrop-blur-md"
            />

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
              className="relative w-full max-w-3xl bg-neutral-950 border border-white/20 p-8 sm:p-12 z-10 shadow-2xl my-auto"
            >
              <button
                onClick={() => setSelectedArticle(null)}
                className="absolute top-6 right-6 text-neutral-400 hover:text-white p-2 border border-white/10"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center space-x-3 text-xs font-mono text-amber-300 uppercase mb-4">
                <span>{selectedArticle.category}</span>
                <span>•</span>
                <span>{selectedArticle.location}</span>
              </div>

              <h2 className="font-serif-luxury text-3xl sm:text-4xl uppercase text-white mb-4">
                {selectedArticle.title}
              </h2>

              <p className="text-xs font-mono text-neutral-500 mb-6">
                PUBLISHED {selectedArticle.date} | {selectedArticle.readTime}
              </p>

              <div className="relative w-full h-64 sm:h-80 bg-neutral-900 mb-6 overflow-hidden">
                <img
                  src={selectedArticle.image}
                  alt={selectedArticle.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-4 font-serif text-sm sm:text-base text-neutral-300 leading-relaxed">
                <p>{selectedArticle.description}</p>
                <p>
                  At Fondazione Prada, architectural spaces act as active catalysts for cultural dialogue rather than passive display vessels. Curated under the artistic direction of Miuccia Prada, the site presents a rigorous juxtaposition between historic industrial distillery structures and modern glass towers designed by OMA.
                </p>
                <p>
                  Visitors can reserve guided curatorial walks and private evening views by booking through our boutique guest services or consulting the Prada Digital Concierge.
                </p>
              </div>

              <div className="mt-8 pt-6 border-t border-white/10 flex justify-end">
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="px-6 py-2.5 bg-white text-black text-xs tracking-prada font-bold uppercase hover:bg-neutral-200"
                >
                  CLOSE ARTICLE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
