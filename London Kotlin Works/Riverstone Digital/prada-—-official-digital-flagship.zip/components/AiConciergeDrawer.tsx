'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, Send, Bot, User, ArrowRight, RefreshCw, ShoppingBag } from 'lucide-react';
import { Product } from '@/lib/types';
import { PRODUCTS } from '@/lib/products-data';
import TriangleLogo from './TriangleLogo';

interface AiConciergeDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
  onSelectProduct: (product: Product) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'concierge';
  text: string;
  timestamp: string;
}

export default function AiConciergeDrawer({
  isOpen,
  onClose,
  initialPrompt,
  onSelectProduct,
}: AiConciergeDrawerProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-welcome',
      sender: 'concierge',
      text: "Buonasera. I am your Prada Private Stylist & Heritage Concierge. How may I assist you today with seasonal styling, event attire, or craftsmanship insights?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSend(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const starterPrompts = [
    "Curate an outfit for Milan Fashion Week",
    "Compare Saffiano Leather vs Re-Nylon",
    "Suggest a black-tie gift under $3,000",
    "What shoes pair best with tailored virgin wool coats?",
  ];

  const handleSend = async (queryText?: string) => {
    const promptToSubmit = queryText || input;
    if (!promptToSubmit.trim() || isLoading) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: promptToSubmit,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/concierge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: promptToSubmit, history: messages }),
      });

      const data = await res.json();
      const replyText = data.text || "Our digital concierge is currently updating seasonal recommendations.";

      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'concierge',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'concierge',
          text: "Forgive me, our private concierge server is briefly experiencing network latency. Please explore our current collection in the catalog.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Extract products mentioned like [[product-id]]
  const parseProductsInText = (text: string) => {
    const matches = text.match(/\[\[(.*?)\]\]/g);
    if (!matches) return [];
    
    const ids = matches.map(m => m.replace(/\[\[|\]\]/g, ''));
    return PRODUCTS.filter(p => ids.includes(p.id));
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
        />

        {/* Drawer */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="fixed inset-y-0 right-0 max-w-full flex pl-10"
        >
          <div className="w-screen max-w-md bg-neutral-950 border-l border-white/20 text-white flex flex-col justify-between shadow-2xl">
            
            {/* Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-black">
              <div className="flex items-center space-x-3">
                <TriangleLogo size={24} variant="gold" />
                <div>
                  <h2 className="font-serif-luxury text-base font-semibold tracking-widest uppercase">
                    PRADA CONCIERGE
                  </h2>
                  <p className="text-[10px] font-mono text-amber-300 uppercase">
                    PRIVATE AI STYLIST & HERITAGE
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="text-neutral-400 hover:text-white p-1.5 border border-white/10 hover:border-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Conversation Messages */}
            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              {messages.map((msg) => {
                const mentionedProducts = parseProductsInText(msg.text);
                const cleanText = msg.text.replace(/\[\[.*?\]\]/g, '');

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.sender === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[90%] p-4 text-xs font-serif leading-relaxed border ${
                        msg.sender === 'user'
                          ? 'bg-neutral-900 border-white/20 text-white'
                          : 'bg-black border-amber-400/20 text-neutral-200'
                      }`}
                    >
                      {msg.sender === 'concierge' && (
                        <div className="flex items-center space-x-2 text-[9px] font-mono text-amber-300 uppercase mb-2">
                          <Sparkles className="w-3 h-3" />
                          <span>PRADA PRIVATE STYLIST</span>
                        </div>
                      )}
                      
                      <p className="whitespace-pre-wrap">{cleanText}</p>

                      {/* Referenced Product Cards */}
                      {mentionedProducts.length > 0 && (
                        <div className="mt-4 pt-3 border-t border-white/10 space-y-2">
                          <p className="text-[9px] font-mono text-neutral-400 uppercase">RECOMMENDED PIECES:</p>
                          {mentionedProducts.map((p) => (
                            <div
                              key={p.id}
                              onClick={() => {
                                onClose();
                                onSelectProduct(p);
                              }}
                              className="flex items-center space-x-3 p-2 bg-neutral-900 border border-white/10 hover:border-white cursor-pointer transition-colors"
                            >
                              <img src={p.images[0]} alt={p.name} className="w-10 h-10 object-cover" />
                              <div className="flex-1 min-w-0">
                                <p className="text-[11px] font-serif uppercase truncate text-white">{p.name}</p>
                                <p className="text-[10px] font-mono text-neutral-400">{p.currency}{p.price.toLocaleString()}</p>
                              </div>
                              <ArrowRight className="w-3 h-3 text-white" />
                            </div>
                          ))}
                        </div>
                      )}

                      <span className="block text-[9px] font-mono text-neutral-500 mt-2 text-right">
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                );
              })}

              {isLoading && (
                <div className="flex items-center space-x-2 p-4 bg-black border border-amber-400/20 text-xs font-mono text-amber-200">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>CONSULTING PRADA HERITAGE ARCHIVES...</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Starters */}
            <div className="px-5 py-2 border-t border-white/10 bg-black">
              <p className="text-[9px] font-mono text-neutral-500 uppercase mb-2">SUGGESTED ENQUIRIES:</p>
              <div className="flex flex-wrap gap-1.5">
                {starterPrompts.map((st, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(st)}
                    className="text-[10px] font-mono text-neutral-300 bg-neutral-900 hover:bg-neutral-800 border border-white/10 px-2.5 py-1 text-left truncate max-w-full"
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Form */}
            <div className="p-4 border-t border-white/10 bg-neutral-950">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend();
                }}
                className="flex items-center space-x-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask for style recommendations..."
                  className="flex-1 bg-black border border-white/20 px-3 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-white font-serif"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="px-4 py-2.5 bg-white text-black text-xs font-mono font-bold tracking-widest uppercase hover:bg-neutral-200 disabled:opacity-40 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
