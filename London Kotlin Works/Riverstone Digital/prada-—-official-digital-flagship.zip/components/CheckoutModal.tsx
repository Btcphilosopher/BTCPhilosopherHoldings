'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, ShieldCheck, Lock, Printer, Building2, MapPin } from 'lucide-react';
import { CartItem } from '@/lib/types';
import TriangleLogo from './TriangleLogo';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderComplete: () => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  items,
  onOrderComplete,
}: CheckoutModalProps) {
  const [step, setStep] = useState<'form' | 'receipt'>('form');
  const [formData, setFormData] = useState({
    firstName: 'Thomas',
    lastName: 'Vanderbilt',
    email: 'tom@ahyx.org',
    address: 'Via Montenapoleone 8',
    city: 'Milan',
    country: 'Italy',
    zip: '20121',
    paymentMethod: 'card',
  });
  const [orderNumber, setOrderNumber] = useState('');

  const totalAmount = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedOrderNum = `PRD-2026-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderNumber(generatedOrderNum);
    setStep('receipt');
  };

  const handleFinish = () => {
    onOrderComplete();
    setStep('form');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/90 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          className="relative w-full max-w-2xl bg-neutral-950 border border-white/20 p-6 sm:p-10 z-10 shadow-2xl my-auto text-white"
        >
          <button
            onClick={onClose}
            className="absolute top-6 right-6 text-neutral-400 hover:text-white p-2 border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>

          {step === 'form' ? (
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <TriangleLogo size={28} variant="gold" />
                <div>
                  <h2 className="font-serif-luxury text-xl font-bold uppercase tracking-widest">
                    SECURE BOUTIQUE CHECKOUT
                  </h2>
                  <p className="text-[10px] font-mono text-neutral-400 uppercase">
                    ENCRYPTED DIRECT CLIENT ORDER
                  </p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-neutral-400 mb-1">
                      FIRST NAME
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className="w-full bg-black border border-white/20 px-3 py-2 text-xs font-serif text-white focus:outline-none focus:border-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-neutral-400 mb-1">
                      LAST NAME
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      className="w-full bg-black border border-white/20 px-3 py-2 text-xs font-serif text-white focus:outline-none focus:border-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase text-neutral-400 mb-1">
                    EMAIL ADDRESS (FOR INVOICE & TRACKING)
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-black border border-white/20 px-3 py-2 text-xs font-serif text-white focus:outline-none focus:border-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase text-neutral-400 mb-1">
                    SHIPPING ADDRESS
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full bg-black border border-white/20 px-3 py-2 text-xs font-serif text-white focus:outline-none focus:border-white"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-neutral-400 mb-1">CITY</label>
                    <input
                      type="text"
                      required
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full bg-black border border-white/20 px-3 py-2 text-xs font-serif text-white focus:outline-none focus:border-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-neutral-400 mb-1">COUNTRY</label>
                    <input
                      type="text"
                      required
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      className="w-full bg-black border border-white/20 px-3 py-2 text-xs font-serif text-white focus:outline-none focus:border-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-neutral-400 mb-1">POSTAL CODE</label>
                    <input
                      type="text"
                      required
                      value={formData.zip}
                      onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                      className="w-full bg-black border border-white/20 px-3 py-2 text-xs font-serif text-white focus:outline-none focus:border-white"
                    />
                  </div>
                </div>

                {/* Order Summary Box */}
                <div className="p-4 bg-neutral-900 border border-white/10 my-4 text-xs font-mono">
                  <div className="flex justify-between text-neutral-400 mb-2">
                    <span>TOTAL CHARGEABLE AMOUNT:</span>
                    <span className="text-white font-bold text-sm">${totalAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-[10px] text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Includes Prada Authenticity Certificate & Insurance</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-white text-black text-xs font-bold tracking-prada uppercase hover:bg-neutral-200 transition-colors flex items-center justify-center space-x-2"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>AUTHORIZE PAYMENT & PLACE ORDER</span>
                </button>
              </form>
            </div>
          ) : (
            /* Digital Receipt View */
            <div className="text-center py-4 space-y-6">
              <div className="mx-auto w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-emerald-400" />
              </div>

              <div>
                <span className="text-[10px] font-mono text-amber-300 tracking-prada uppercase">
                  ORDER CONFIRMED
                </span>
                <h2 className="font-serif-luxury text-3xl font-light uppercase tracking-wider text-white mt-1">
                  GRAZIE, {formData.firstName.toUpperCase()}
                </h2>
                <p className="text-xs text-neutral-400 mt-2 font-mono">
                  REF NO: <span className="text-white font-bold">{orderNumber}</span>
                </p>
              </div>

              <div className="p-6 bg-black border border-white/15 text-left text-xs font-mono space-y-3">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="text-neutral-400">DELIVERY TO:</span>
                  <span className="text-white">{formData.address}, {formData.city}</span>
                </div>
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="text-neutral-400">METHOD:</span>
                  <span className="text-white">Complimentary Express Air Courier</span>
                </div>
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="text-neutral-400">TOTAL CHARGED:</span>
                  <span className="text-white font-bold">${totalAmount.toLocaleString()}</span>
                </div>
                <p className="text-[10px] text-neutral-500 pt-1">
                  A confirmation email with real-time tracking has been sent to {formData.email}.
                </p>
              </div>

              <div className="flex justify-center space-x-3 pt-2">
                <button
                  onClick={handleFinish}
                  className="px-8 py-3 bg-white text-black text-xs font-bold tracking-prada uppercase hover:bg-neutral-200"
                >
                  RETURN TO DIGITAL FLAGSHIP
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
