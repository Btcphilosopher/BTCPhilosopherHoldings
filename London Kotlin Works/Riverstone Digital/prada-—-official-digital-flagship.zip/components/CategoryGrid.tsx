'use client';

import React from 'react';
import { motion } from 'motion/react';

interface CategoryGridProps {
  onSelectCategory: (category: string) => void;
}

export default function CategoryGrid({ onSelectCategory }: CategoryGridProps) {
  const handleClick = (category: string) => {
    onSelectCategory(category);
    const catalog = document.getElementById('product-catalog');
    catalog?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="w-full bg-black py-2 lg:py-4">
      {/* 4-Tile Grid Container matching reference image */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-2 lg:gap-3 px-2 lg:px-4 max-w-[1920px] mx-auto">
        
        {/* Tile 1: WOMEN - ICONIC BAGS (Large Left, 5 cols in lg) */}
        <div
          onClick={() => handleClick('bags')}
          className="lg:col-span-4 relative group cursor-pointer overflow-hidden min-h-[480px] lg:min-h-[640px] bg-neutral-900 border border-white/5"
        >
          <img
            src="https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1200&auto=format&fit=crop"
            alt="Iconic Bags"
            className="w-full h-full object-cover object-center img-editorial-zoom opacity-90 brightness-90 group-hover:brightness-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-6 sm:p-8">
            <span className="text-[10px] font-mono tracking-prada-wide uppercase text-neutral-400 mb-1">
              WOMEN
            </span>
            <div className="flex items-center justify-between">
              <h2 className="font-serif-luxury text-2xl sm:text-3xl font-medium tracking-tight uppercase text-white">
                ICONIC BAGS
              </h2>
              <span className="text-xl text-white transform group-hover:translate-x-2 transition-transform duration-300">
                ⟶
              </span>
            </div>
          </div>
        </div>

        {/* Tile 2: MEN - TAILORING FOR A NEW ERA (Center, 4 cols in lg) */}
        <div
          onClick={() => handleClick('men')}
          className="lg:col-span-4 relative group cursor-pointer overflow-hidden min-h-[480px] lg:min-h-[640px] bg-neutral-900 border border-white/5"
        >
          <img
            src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop"
            alt="Tailoring for a New Era"
            className="w-full h-full object-cover object-center img-editorial-zoom opacity-90 brightness-90 group-hover:brightness-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-6 sm:p-8">
            <span className="text-[10px] font-mono tracking-prada-wide uppercase text-neutral-400 mb-1">
              MEN
            </span>
            <div className="flex items-center justify-between">
              <h2 className="font-serif-luxury text-2xl sm:text-3xl font-medium tracking-tight uppercase text-white leading-tight">
                TAILORING<br />FOR A NEW ERA
              </h2>
              <span className="text-xl text-white transform group-hover:translate-x-2 transition-transform duration-300">
                ⟶
              </span>
            </div>
          </div>
        </div>

        {/* Tiles 3 & 4: SHOES & FINE JEWELLERY (Right Column Stack, 4 cols in lg) */}
        <div className="lg:col-span-4 flex flex-col gap-2 lg:gap-3">
          
          {/* Tile 3: SHOES - CRAFTED FOR GENERATIONS */}
          <div
            onClick={() => handleClick('shoes')}
            className="relative group cursor-pointer overflow-hidden min-h-[235px] lg:min-h-[314px] bg-neutral-900 border border-white/5 flex-1"
          >
            <img
              src="https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?q=80&w=1000&auto=format&fit=crop"
              alt="Crafted for Generations"
              className="w-full h-full object-cover object-center img-editorial-zoom opacity-90 brightness-90 group-hover:brightness-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent flex flex-col justify-end p-6">
              <span className="text-[10px] font-mono tracking-prada-wide uppercase text-neutral-400 mb-1">
                SHOES
              </span>
              <div className="flex items-center justify-between">
                <h2 className="font-serif-luxury text-xl sm:text-2xl font-medium tracking-tight uppercase text-white">
                  CRAFTED FOR GENERATIONS
                </h2>
                <span className="text-lg text-white transform group-hover:translate-x-2 transition-transform duration-300">
                  ⟶
                </span>
              </div>
            </div>
          </div>

          {/* Tile 4: FINE JEWELLERY - MODERN HERITAGE */}
          <div
            onClick={() => handleClick('jewellery')}
            className="relative group cursor-pointer overflow-hidden min-h-[235px] lg:min-h-[314px] bg-neutral-900 border border-white/5 flex-1"
          >
            <img
              src="https://images.unsplash.com/photo-1630019852942-f89202989a59?q=80&w=1000&auto=format&fit=crop"
              alt="Modern Heritage Fine Jewellery"
              className="w-full h-full object-cover object-center img-editorial-zoom opacity-90 brightness-90 group-hover:brightness-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent flex flex-col justify-end p-6">
              <span className="text-[10px] font-mono tracking-prada-wide uppercase text-neutral-400 mb-1">
                FINE JEWELLERY
              </span>
              <div className="flex items-center justify-between">
                <h2 className="font-serif-luxury text-xl sm:text-2xl font-medium tracking-tight uppercase text-white">
                  MODERN HERITAGE
                </h2>
                <span className="text-lg text-white transform group-hover:translate-x-2 transition-transform duration-300">
                  ⟶
                </span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
