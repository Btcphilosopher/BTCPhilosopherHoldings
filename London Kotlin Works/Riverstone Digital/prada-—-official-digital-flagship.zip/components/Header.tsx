'use client';

import React, { useState, useEffect } from 'react';
import { Search, ShoppingBag, Heart, Sparkles, User, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import TriangleLogo from './TriangleLogo';

interface HeaderProps {
  activeCategory: string;
  onSelectCategory: (category: string) => void;
  onOpenSearch: () => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenConcierge: () => void;
  cartCount: number;
  wishlistCount: number;
}

export default function Header({
  activeCategory,
  onSelectCategory,
  onOpenSearch,
  onOpenCart,
  onOpenWishlist,
  onOpenConcierge,
  cartCount,
  wishlistCount,
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'WOMEN', id: 'women' },
    { label: 'MEN', id: 'men' },
    { label: 'BAGS', id: 'bags' },
    { label: 'SHOES', id: 'shoes' },
    { label: 'ACCESSORIES', id: 'accessories' },
    { label: 'FINE JEWELLERY', id: 'jewellery' },
    { label: 'PRADA WORLD', id: 'world' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-40 transition-all duration-300">
      {/* Top Banner */}
      <div className="bg-neutral-950 text-neutral-400 text-[10px] tracking-prada uppercase text-center py-1.5 border-b border-white/5 font-mono">
        <span>COMPLIMENTARY EXPRESS SHIPPING & SIGNATURE GIFT PACKAGING ON ALL ORDERS</span>
      </div>

      {/* Main Header Bar */}
      <nav
        className={`w-full transition-all duration-300 border-b ${
          isScrolled
            ? 'bg-black/90 backdrop-blur-md border-white/10 py-3'
            : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent border-white/10 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Left: Prada Logo */}
          <div className="flex items-center space-x-3">
            <button
              onClick={() => onSelectCategory('all')}
              className="group flex items-center space-x-2 text-left focus:outline-none"
            >
              <span className="font-serif-luxury text-2xl sm:text-3xl font-extrabold tracking-widest text-white hover:text-neutral-300 transition-colors uppercase">
                PRADA
              </span>
            </button>
          </div>

          {/* Center: Desktop Navigation Links */}
          <div className="hidden lg:flex items-center space-x-7">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onSelectCategory(item.id);
                  if (item.id === 'world') {
                    const el = document.getElementById('prada-world-section');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  } else {
                    const el = document.getElementById('product-catalog');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className={`text-[11px] tracking-prada transition-all duration-200 py-1 relative uppercase font-medium ${
                  activeCategory === item.id
                    ? 'text-white font-semibold'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                {item.label}
                {activeCategory === item.id && (
                  <motion.div
                    layoutId="activeNavIndicator"
                    className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-white"
                  />
                )}
              </button>
            ))}

            {/* AI Stylist Button */}
            <button
              onClick={onOpenConcierge}
              className="flex items-center space-x-1.5 px-2.5 py-1 text-[11px] tracking-prada border border-amber-400/30 bg-amber-400/5 text-amber-200 hover:bg-amber-400/15 hover:border-amber-400/60 transition-all rounded-none uppercase font-medium"
            >
              <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
              <span>AI STYLIST</span>
            </button>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center space-x-4 sm:space-x-5">
            {/* Search */}
            <button
              onClick={onOpenSearch}
              aria-label="Search"
              className="text-neutral-300 hover:text-white p-1 transition-colors focus:outline-none"
            >
              <Search className="w-4 h-4 stroke-[1.75]" />
            </button>

            {/* AI Assistant Mobile / Quick trigger */}
            <button
              onClick={onOpenConcierge}
              aria-label="AI Concierge"
              className="text-amber-300 hover:text-amber-100 p-1 lg:hidden transition-colors"
            >
              <Sparkles className="w-4 h-4" />
            </button>

            {/* Wishlist */}
            <button
              onClick={onOpenWishlist}
              aria-label="Saved items"
              className="text-neutral-300 hover:text-white p-1 transition-colors relative focus:outline-none"
            >
              <Heart className="w-4 h-4 stroke-[1.75]" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-neutral-200 text-black text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Bag */}
            <button
              onClick={onOpenCart}
              aria-label="Shopping bag"
              className="text-neutral-300 hover:text-white p-1 transition-colors relative focus:outline-none flex items-center space-x-1"
            >
              <ShoppingBag className="w-4 h-4 stroke-[1.75]" />
              {cartCount > 0 && (
                <span className="bg-white text-black text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden text-neutral-300 hover:text-white p-1"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="lg:hidden bg-black/95 backdrop-blur-xl border-b border-white/10 px-6 py-6"
          >
            <div className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectCategory(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`text-left text-sm tracking-prada py-2 border-b border-white/5 ${
                    activeCategory === item.id ? 'text-white font-bold' : 'text-neutral-400'
                  }`}
                >
                  {item.label}
                </button>
              ))}

              <button
                onClick={() => {
                  onOpenConcierge();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center justify-between w-full p-3 border border-amber-400/30 bg-amber-400/10 text-amber-200 mt-2 text-xs tracking-prada uppercase"
              >
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>CONSULT PRADA AI CONCIERGE</span>
                </div>
                <span>⟶</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
