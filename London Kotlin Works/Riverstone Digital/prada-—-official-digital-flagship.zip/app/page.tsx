'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import HeroCarousel from '@/components/HeroCarousel';
import CategoryGrid from '@/components/CategoryGrid';
import ProductCatalog from '@/components/ProductCatalog';
import ProductModal from '@/components/ProductModal';
import PradaWorld from '@/components/PradaWorld';
import AiConciergeDrawer from '@/components/AiConciergeDrawer';
import CartDrawer from '@/components/CartDrawer';
import CheckoutModal from '@/components/CheckoutModal';
import WishlistDrawer from '@/components/WishlistDrawer';
import SearchModal from '@/components/SearchModal';
import Footer from '@/components/Footer';

import { Product, CartItem } from '@/lib/types';
import { PRODUCTS } from '@/lib/products-data';

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlistIds, setWishlistIds] = useState<string[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Drawers & Modals
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState<boolean>(false);
  const [conciergeInitialPrompt, setConciergeInitialPrompt] = useState<string | undefined>(undefined);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);

  // Load saved state from localStorage on client mount
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('prada_cart');
      if (savedCart) setCart(JSON.parse(savedCart));

      const savedWish = localStorage.getItem('prada_wishlist');
      if (savedWish) setWishlistIds(JSON.parse(savedWish));
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Save cart changes
  useEffect(() => {
    try {
      localStorage.setItem('prada_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  // Save wishlist changes
  useEffect(() => {
    try {
      localStorage.setItem('prada_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error(e);
    }
  }, [wishlistIds]);

  // Cart Handlers
  const handleAddToCart = (product: Product, color?: string, size?: string) => {
    const targetColor = color || product.colors[0]?.name || 'Nero Black';
    const targetSize = size || (product.sizes ? product.sizes[0] : undefined);

    setCart((prev) => {
      const existingIdx = prev.findIndex(
        (item) =>
          item.product.id === product.id &&
          item.selectedColor === targetColor &&
          item.selectedSize === targetSize
      );

      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += 1;
        return updated;
      } else {
        return [
          ...prev,
          {
            product,
            selectedColor: targetColor,
            selectedSize: targetSize,
            quantity: 1,
          },
        ];
      }
    });

    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity: qty } : item
      )
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Wishlist Handlers
  const handleToggleWishlist = (product: Product) => {
    setWishlistIds((prev) =>
      prev.includes(product.id)
        ? prev.filter((id) => id !== product.id)
        : [...prev, product.id]
    );
  };

  // Open Concierge with custom prompt
  const handleOpenConciergeWithPrompt = (prompt: string) => {
    setConciergeInitialPrompt(prompt);
    setIsConciergeOpen(true);
  };

  const wishlistProducts = PRODUCTS.filter((p) => wishlistIds.includes(p.id));
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <main className="min-h-screen bg-black text-white selection:bg-neutral-800 selection:text-white">
      {/* Header */}
      <Header
        activeCategory={activeCategory}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          setSearchQuery('');
        }}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenConcierge={() => {
          setConciergeInitialPrompt(undefined);
          setIsConciergeOpen(true);
        }}
        cartCount={cartCount}
        wishlistCount={wishlistIds.length}
      />

      {/* Hero Section */}
      <HeroCarousel
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
        }}
      />

      {/* 4-Card Category Banners matching user reference image */}
      <CategoryGrid
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
        }}
      />

      {/* Product Catalog */}
      <ProductCatalog
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onAddToCart={(p) => handleAddToCart(p)}
        onToggleWishlist={handleToggleWishlist}
        wishlistIds={wishlistIds}
        searchQuery={searchQuery}
        onClearSearch={() => setSearchQuery('')}
        onOpenConcierge={() => {
          setConciergeInitialPrompt(undefined);
          setIsConciergeOpen(true);
        }}
      />

      {/* Prada World / Art Culture Editorial Section matching user image */}
      <PradaWorld />

      {/* Footer */}
      <Footer onSelectCategory={setActiveCategory} />

      {/* Product Detail Inspector Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={(p, color, size) => handleAddToCart(p, color, size)}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        onOpenConciergeWithPrompt={handleOpenConciergeWithPrompt}
      />

      {/* AI Private Stylist Drawer */}
      <AiConciergeDrawer
        isOpen={isConciergeOpen}
        onClose={() => setIsConciergeOpen(false)}
        initialPrompt={conciergeInitialPrompt}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      {/* Shopping Bag Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        products={wishlistProducts}
        onRemoveFromWishlist={handleToggleWishlist}
        onAddToCart={(p) => handleAddToCart(p)}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      {/* Live Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSearchSubmit={(q) => {
          setSearchQuery(q);
          setActiveCategory('all');
        }}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onOpenConcierge={() => setIsConciergeOpen(true)}
      />

      {/* Secure Checkout & Digital Receipt Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        onOrderComplete={handleClearCart}
      />
    </main>
  );
}
