import type { Metadata } from 'next';
import { Bodoni_Moda, Inter } from 'next/font/google';
import './globals.css';

const bodoni = Bodoni_Moda({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
  weight: ['400', '500', '600', '700', '800', '900'],
  style: ['normal', 'italic'],
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
  weight: ['300', '400', '500', '600', '700'],
});

export const metadata: Metadata = {
  title: 'PRADA — Official Digital Flagship | Late 2020s Collection',
  description: 'Explore the official Prada digital flagship: luxury leather bags, tailoring, brushed leather shoes, fine jewellery, and Prada World editorial experience.',
  openGraph: {
    title: 'PRADA — Official Digital Flagship',
    description: 'A Dialogue Between Past and Future. Reimagining the everyday through a lens of timeless innovation.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PRADA — Official Digital Flagship',
    description: 'A Dialogue Between Past and Future.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${bodoni.variable} ${inter.variable} bg-black text-white dark`}>
      <body suppressHydrationWarning className="bg-black text-slate-100 min-h-screen antialiased selection:bg-neutral-800 selection:text-white">
        {children}
      </body>
    </html>
  );
}
