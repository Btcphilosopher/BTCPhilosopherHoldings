import { GoogleGenAI } from '@google/genai';
import { NextResponse } from 'next/server';
import { PRODUCTS } from '@/lib/products-data';

export async function POST(req: Request) {
  try {
    const { prompt, history } = await req.json();

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { text: "Prada AI Concierge service is currently operating in offline mode. For custom styling requests, please visit a Prada boutique in Milan, New York, or Paris." },
        { status: 200 }
      );
    }

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    const catalogContext = PRODUCTS.map(p => `- ID: ${p.id} | ${p.name} ($${p.price}) | Category: ${p.category} | Material: ${p.material} | Tag: ${p.tag} | Description: ${p.description}`).join('\n');

    const systemInstruction = `
You are the Senior Private Stylist and Heritage Specialist for PRADA (Digital Flagship).
Your tone is sophisticated, knowledgeable, articulate, refined, and effortlessly polite — reflecting Miuccia Prada and Raf Simons' vision of high fashion, architectural minimalism, and Italian craftsmanship.

Available Catalog Items:
${catalogContext}

Instructions:
1. Provide personalized style advice, outfit curation for events (galas, travel, art gallery openings, everyday luxury), or detailed fabric/craftsmanship insights (e.g. Saffiano leather texture, Re-Nylon ocean conservation, brushed leather hand-finishing).
2. When applicable, recommend specific items from the catalog by exact name and include product reference IDs in double brackets like [[prada-galleria-bag]] or [[prada-chocolate-loafers]].
3. Keep answers concise (under 180 words), polished, and luxurious. Do not use overly enthusiastic sales buzzwords; maintain an understated luxury tone.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [
        { role: 'user', parts: [{ text: `${systemInstruction}\n\nUser Question: ${prompt}` }] }
      ],
    });

    return NextResponse.json({ text: response.text || "Our stylists recommend exploring our signature Saffiano leather and tailored wool collections." });
  } catch (error) {
    console.error('Gemini API Error:', error);
    return NextResponse.json(
      { text: "Our digital concierge is currently updating seasonal recommendations. Please explore our current collection below." },
      { status: 200 }
    );
  }
}
