'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

interface CategoryCardItem {
  id: string;
  name: string;
  category: string;
  image: string;
  alt: string;
}

const CATEGORIES: CategoryCardItem[] = [
  {
    id: 'cat-women',
    name: 'Women',
    category: 'Women',
    image: '/assets/categories/cat_women.png',
    alt: 'Women fashion, checked scarves and winter outerwear',
  },
  {
    id: 'cat-men',
    name: 'Men',
    category: 'Men',
    image: '/assets/categories/cat_men.png',
    alt: 'Men apparel, streetwear hoodies and puffer jackets',
  },
  {
    id: 'cat-kids',
    name: 'Kids',
    category: 'Kids',
    image: '/assets/categories/cat_kids.png',
    alt: 'Kids knitwear, cosy beanies and winter outfits',
  },
  {
    id: 'cat-home',
    name: 'Home',
    category: 'Home',
    image: '/assets/categories/cat_home.png',
    alt: 'Home living, warm bedding, duvet sets and cozy lighting',
  },
  {
    id: 'cat-beauty',
    name: 'Beauty',
    category: 'Beauty',
    image: '/assets/categories/cat_beauty.png',
    alt: 'Beauty skincare mist, cosmetics and makeup brushes',
  },
];

export default function CategoryGrid() {
  const { selectedCategory, setSelectedCategory } = useStore();

  const handleSelectCategory = (category: string) => {
    setSelectedCategory(category);
    const target = document.getElementById('trending');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-6 sm:py-8 bg-white transition-colors dark:bg-slate-950">
      <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8">
        
        {/* 5-Card Responsive Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 sm:gap-4 lg:gap-5">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.category;
            return (
              <button
                key={cat.id}
                onClick={() => handleSelectCategory(cat.category)}
                className={`group relative h-36 sm:h-44 lg:h-48 w-full overflow-hidden rounded-2xl text-left shadow-sm transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00A3E0] ${
                  isSelected
                    ? 'ring-2 ring-[#00A3E0] shadow-md -translate-y-0.5'
                    : 'hover:-translate-y-1 hover:shadow-md'
                }`}
              >
                {/* Image */}
                <div className="absolute inset-0">
                  <Image
                    src={cat.image}
                    alt={cat.alt}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {/* Bottom Vignette for legible text */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent" />
                </div>

                {/* Text and Arrow Label */}
                <div className="absolute bottom-3.5 left-4 right-4 z-10 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-base sm:text-lg font-bold text-white drop-shadow-sm tracking-tight">
                    <span>{cat.name}</span>
                    <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                  </span>
                  
                  {isSelected && (
                    <span className="h-2 w-2 rounded-full bg-[#00A3E0] ring-2 ring-white" />
                  )}
                </div>
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
}
