'use client';

import React from 'react';
import { Package, Clock, MapPin, ArrowRight } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function ClickAndCollectBanner() {
  const { selectedStore, setIsStoreFinderOpen } = useStore();

  return (
    <section className="bg-slate-900 text-white py-10 px-4 sm:px-6 lg:px-8 border-y border-slate-800">
      <div className="mx-auto max-w-[1440px] flex flex-col lg:flex-row items-center justify-between gap-8">
        
        {/* Left: Headline & Description */}
        <div className="max-w-xl text-center lg:text-left">
          <div className="inline-flex items-center gap-2 rounded-full bg-[#00A3E0]/20 px-3 py-1 text-xs font-semibold text-[#00A3E0] mb-3">
            <span className="h-2 w-2 rounded-full bg-[#00A3E0] animate-pulse" />
            Click & Collect Service
          </div>
          <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Shop online, collect in store for free.
          </h3>
          <p className="mt-2 text-sm text-slate-300 leading-relaxed">
            Order your favourites online and pick them up at your chosen Primark store with zero delivery fees on orders over £15.
          </p>
        </div>

        {/* Center: 3 Feature highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center sm:text-left">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#00A3E0]">
              <Package className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold">Free over £15</div>
              <div className="text-xs text-slate-400">Available across 80+ UK stores</div>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#00A3E0]">
              <Clock className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold">Ready in 2-4 Days</div>
              <div className="text-xs text-slate-400">SMS & email notification when ready</div>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#00A3E0]">
              <MapPin className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold">Your Store</div>
              <div className="text-xs text-[#00A3E0] truncate max-w-[130px] font-medium">
                {selectedStore.name.split('-')[1]?.trim() || selectedStore.city}
              </div>
            </div>
          </div>
        </div>

        {/* Right: CTA Button */}
        <div className="shrink-0">
          <button
            onClick={() => setIsStoreFinderOpen(true)}
            className="group flex items-center gap-2 rounded-xl bg-[#00A3E0] px-5 py-3 text-sm font-bold text-white shadow-md hover:bg-[#0090c7] transition-all"
          >
            <span>Change Collection Store</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

      </div>
    </section>
  );
}
