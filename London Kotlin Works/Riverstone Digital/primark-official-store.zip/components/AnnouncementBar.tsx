'use client';

import React, { useState } from 'react';
import { MapPin, ChevronDown, Check } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { CURRENCIES } from '@/lib/data';

export default function AnnouncementBar() {
  const { currency, setCurrency, selectedStore, setIsStoreFinderOpen } = useStore();
  const [isCurrencyDropdownOpen, setIsCurrencyDropdownOpen] = useState(false);

  return (
    <div className="relative z-40 bg-[#f7f7f8] text-xs font-medium text-slate-700 transition-colors dark:bg-slate-900 dark:text-slate-300 border-b border-slate-200 dark:border-slate-800">
      <div className="mx-auto flex h-9 max-w-[1440px] items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Left / Center: Announcement Text */}
        <div className="flex flex-1 items-center justify-start sm:justify-center overflow-hidden">
          <div className="flex items-center gap-2 sm:gap-3 text-center truncate">
            <span className="font-semibold text-slate-900 dark:text-white">Free Click & Collect</span>
            <span className="hidden sm:inline text-slate-500 dark:text-slate-400">to your local Primark store</span>
            <span className="hidden sm:inline text-slate-300 dark:text-slate-600">|</span>
            <span className="hidden md:inline font-medium text-slate-700 dark:text-slate-300">New in weekly</span>
            <span className="hidden md:inline text-slate-300 dark:text-slate-600">|</span>
            <span className="text-slate-600 dark:text-slate-400">Affordable fashion for everyone</span>
          </div>
        </div>

        {/* Right: Store Shortcut + Country/Currency selector */}
        <div className="flex items-center gap-4 shrink-0 pl-3">
          {/* Quick store selector */}
          <button
            onClick={() => setIsStoreFinderOpen(true)}
            className="hidden lg:flex items-center gap-1.5 text-slate-600 hover:text-[#00A3E0] dark:text-slate-400 dark:hover:text-[#00A3E0] transition-colors"
            title="Change nearest store"
          >
            <MapPin className="h-3.5 w-3.5 text-[#00A3E0]" />
            <span className="max-w-[130px] truncate">{selectedStore.name.split('-')[1]?.trim() || selectedStore.city}</span>
          </button>

          {/* Currency / Region dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsCurrencyDropdownOpen(!isCurrencyDropdownOpen)}
              className="flex items-center gap-1.5 py-1 text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white transition-colors"
              aria-expanded={isCurrencyDropdownOpen}
            >
              <span>{currency.flag}</span>
              <span className="font-medium">{currency.code} ({currency.symbol})</span>
              <ChevronDown className="h-3 w-3 text-slate-500" />
            </button>

            {isCurrencyDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsCurrencyDropdownOpen(false)}
                />
                <div className="absolute right-0 top-full mt-1 w-44 rounded-md bg-white py-1.5 shadow-lg ring-1 ring-black/5 dark:bg-slate-900 dark:ring-white/10 z-50">
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Select Region
                  </div>
                  {CURRENCIES.map((c) => (
                    <button
                      key={c.code}
                      onClick={() => {
                        setCurrency(c);
                        setIsCurrencyDropdownOpen(false);
                      }}
                      className="flex w-full items-center justify-between px-3 py-1.5 text-left text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800 transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <span>{c.flag}</span>
                        <span>{c.country} ({c.symbol})</span>
                      </span>
                      {currency.code === c.code && (
                        <Check className="h-3.5 w-3.5 text-[#00A3E0]" />
                      )}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
