'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function HeroBanner() {
  const { setSelectedCategory } = useStore();

  const handleShop = (category: string) => {
    setSelectedCategory(category);
    const target = document.getElementById('trending');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative w-full overflow-hidden bg-slate-900">
      <div className="relative mx-auto max-w-[1440px] h-[480px] sm:h-[520px] lg:h-[560px]">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image
            src="/assets/hero/hero_backdrop.png"
            alt="New Season at Primark Models in Winter Apparel"
            fill
            priority
            referrerPolicy="no-referrer"
            className="object-cover object-right md:object-center"
          />
          {/* Subtle gradient vignette to guarantee 4.5:1 text contrast */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent lg:from-black/75 lg:via-black/30 lg:to-transparent" />
        </div>

        {/* Content Container */}
        <div className="relative z-10 flex h-full flex-col justify-center px-6 sm:px-12 lg:px-16 max-w-2xl">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.08] drop-shadow-sm">
            New <br />
            Season <br />
            at Primark
          </h1>

          <p className="mt-4 sm:mt-5 text-base sm:text-lg text-slate-200 max-w-lg font-normal leading-relaxed">
            Winter styles, everyday essentials and great value for all.
          </p>

          {/* Action CTAs */}
          <div className="mt-7 sm:mt-8 flex flex-wrap items-center gap-3 sm:gap-4">
            {/* Primary Button: Shop Women */}
            <button
              onClick={() => handleShop('Women')}
              className="group inline-flex items-center gap-2 rounded-lg bg-white px-6 py-3 text-sm font-bold text-slate-950 shadow-md hover:bg-slate-100 hover:shadow-lg transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <span>Shop Women</span>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>

            {/* Secondary Button: Shop Men */}
            <button
              onClick={() => handleShop('Men')}
              className="group inline-flex items-center gap-2 rounded-lg bg-black/40 backdrop-blur-md border border-white/40 px-6 py-3 text-sm font-bold text-white hover:bg-black/60 hover:border-white transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              <span>Shop Men</span>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
