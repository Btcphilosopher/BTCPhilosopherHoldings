'use client';

import React, { useState, useMemo } from 'react';
import Image from 'next/image';
import { Heart, ShoppingBag, Eye, Star, ArrowRight, Check } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { PRODUCTS } from '@/lib/data';
import { Product } from '@/lib/types';

export default function TrendingSection() {
  const {
    selectedCategory,
    setSelectedCategory,
    addToCart,
    toggleWishlist,
    isInWishlist,
    setQuickViewProduct,
    formatPrice,
  } = useStore();

  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [selectedProductSizes, setSelectedProductSizes] = useState<Record<string, string>>({});
  const [selectedProductColors, setSelectedProductColors] = useState<Record<string, string>>({});

  const filterTabs = [
    { label: 'All Trending', value: 'all' },
    { label: 'Women', value: 'Women' },
    { label: 'Men', value: 'Men' },
    { label: 'Kids', value: 'Kids' },
    { label: 'Home', value: 'Home' },
    { label: 'Beauty', value: 'Beauty' },
    { label: 'Collaborations', value: 'Collaborations' },
  ];

  const filteredProducts = useMemo(() => {
    let list = PRODUCTS;
    if (selectedCategory !== 'all') {
      list = list.filter((p) => p.category === selectedCategory);
    }

    return [...list].sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [selectedCategory, sortBy]);

  const handleSelectSize = (productId: string, size: string) => {
    setSelectedProductSizes((prev) => ({ ...prev, [productId]: size }));
  };

  const handleSelectColor = (productId: string, color: string) => {
    setSelectedProductColors((prev) => ({ ...prev, [productId]: color }));
  };

  return (
    <section id="trending" className="py-10 sm:py-14 bg-slate-50/60 dark:bg-slate-900/40 border-t border-slate-200/60 dark:border-slate-800/60 transition-colors">
      <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Trending at Primark
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              The most loved winter drops, everyday essentials and must-have styles.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setSelectedCategory('all')}
              className="group inline-flex items-center gap-1.5 text-sm font-semibold text-slate-900 hover:text-[#00A3E0] dark:text-white dark:hover:text-[#00A3E0] transition-colors"
            >
              <span>Shop the trend</span>
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Filter Pills Bar & Sorting */}
        <div className="mt-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {filterTabs.map((tab) => {
              const active = selectedCategory === tab.value;
              return (
                <button
                  key={tab.value}
                  onClick={() => setSelectedCategory(tab.value)}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-full whitespace-nowrap transition-all ${
                    active
                      ? 'bg-slate-900 text-white shadow-sm dark:bg-white dark:text-slate-950'
                      : 'bg-white text-slate-700 border border-slate-200 hover:border-slate-300 hover:bg-slate-100 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-700'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-2 shrink-0 text-xs text-slate-500 dark:text-slate-400">
            <span>Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-800 shadow-sm focus:border-[#00A3E0] focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              <option value="featured">Featured Drops</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Customer Rated</option>
            </select>
          </div>

        </div>

        {/* Products Grid */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const inWish = isInWishlist(product.id);
            const selectedSize = selectedProductSizes[product.id] || product.sizes[0];
            const selectedColor = selectedProductColors[product.id] || product.colors[0]?.name;

            return (
              <div
                key={product.id}
                className="group relative flex flex-col rounded-2xl border border-slate-200/80 bg-white p-3.5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900/90"
              >
                {/* Thumbnail Container */}
                <div className="relative aspect-[4/5] w-full overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800">
                  <Image
                    src={product.image}
                    alt={product.name}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover object-center transition-transform duration-500 group-hover:scale-105"
                  />

                  {/* Fallback gradient if loading */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />

                  {/* Badges on image */}
                  <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
                    {product.badge && (
                      <span className="inline-block rounded-md bg-white/95 px-2 py-0.5 text-[11px] font-bold tracking-tight text-slate-900 shadow-sm backdrop-blur dark:bg-slate-900/95 dark:text-white">
                        {product.badge}
                      </span>
                    )}
                    {product.clickAndCollect && (
                      <span className="inline-block rounded-md bg-[#00A3E0] px-2 py-0.5 text-[10px] font-bold tracking-wide text-white shadow-sm">
                        Click & Collect
                      </span>
                    )}
                  </div>

                  {/* Wishlist Heart Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(product.id);
                    }}
                    className={`absolute top-2.5 right-2.5 z-10 flex h-8 w-8 items-center justify-center rounded-full backdrop-blur-md transition-all ${
                      inWish
                        ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/80 dark:text-rose-400'
                        : 'bg-white/90 text-slate-600 hover:text-rose-600 dark:bg-slate-900/80 dark:text-slate-300 dark:hover:text-rose-400'
                    }`}
                    aria-label="Save to Wishlist"
                  >
                    <Heart className={`h-4 w-4 ${inWish ? 'fill-rose-600 dark:fill-rose-400' : ''}`} />
                  </button>

                  {/* Quick View Hover Button */}
                  <button
                    onClick={() => setQuickViewProduct(product)}
                    className="absolute bottom-2.5 left-2.5 right-2.5 hidden sm:flex items-center justify-center gap-2 rounded-lg bg-white/90 py-2 text-xs font-bold text-slate-900 shadow-sm backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-white dark:bg-slate-900/90 dark:text-white dark:hover:bg-slate-900 z-10"
                  >
                    <Eye className="h-3.5 w-3.5" />
                    <span>Quick View</span>
                  </button>
                </div>

                {/* Content Details */}
                <div className="mt-3.5 flex flex-1 flex-col justify-between">
                  <div>
                    {/* Category & Rating */}
                    <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-medium">{product.subcategory}</span>
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                        <span className="font-semibold text-slate-700 dark:text-slate-300">{product.rating}</span>
                        <span>({product.reviewsCount})</span>
                      </div>
                    </div>

                    {/* Product Name */}
                    <h3
                      onClick={() => setQuickViewProduct(product)}
                      className="mt-1 cursor-pointer text-sm font-bold text-slate-900 line-clamp-2 hover:text-[#00A3E0] dark:text-slate-100 dark:hover:text-[#00A3E0] transition-colors"
                      title={product.name}
                    >
                      {product.name}
                    </h3>

                    {/* Colors & Sizes Preview */}
                    <div className="mt-2.5 flex items-center justify-between gap-2">
                      {/* Color swatches */}
                      <div className="flex items-center gap-1.5">
                        {product.colors.map((c) => (
                          <button
                            key={c.name}
                            onClick={() => handleSelectColor(product.id, c.name)}
                            className={`h-4 w-4 rounded-full border transition-all ${
                              selectedColor === c.name
                                ? 'ring-2 ring-[#00A3E0] ring-offset-1 dark:ring-offset-slate-900 scale-110'
                                : 'border-slate-300 dark:border-slate-600'
                            }`}
                            style={{ backgroundColor: c.hex }}
                            title={c.name}
                          />
                        ))}
                      </div>

                      {/* Sizes dropdown / selector */}
                      <select
                        value={selectedSize}
                        onChange={(e) => handleSelectSize(product.id, e.target.value)}
                        className="rounded border border-slate-200 bg-white px-1.5 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 focus:outline-none"
                      >
                        {product.sizes.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Price & Add to Bag */}
                  <div className="mt-4 flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg font-black text-slate-900 tabular-nums dark:text-white">
                        {formatPrice(product.price)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-xs text-slate-400 line-through tabular-nums">
                          {formatPrice(product.originalPrice)}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => addToCart(product, selectedSize, selectedColor)}
                      className="flex items-center gap-1.5 rounded-lg bg-[#00A3E0] px-3 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-[#0090c7] active:scale-95 transition-all"
                      title="Add to bag"
                    >
                      <ShoppingBag className="h-3.5 w-3.5" />
                      <span>Add</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
