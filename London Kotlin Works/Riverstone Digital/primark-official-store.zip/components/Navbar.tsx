'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Search, Heart, User, ShoppingBag, Sun, Moon, Menu, X, ChevronRight } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { NAVIGATION_ITEMS } from '@/lib/data';

export default function Navbar() {
  const {
    theme,
    toggleTheme,
    cartCount,
    wishlist,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsSearchOpen,
    setIsAuthOpen,
    selectedCategory,
    setSelectedCategory,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const handleNavClick = (cat: string) => {
    setSelectedCategory(cat);
    const element = document.getElementById('trending');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setActiveDropdown(null);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 w-full border-b border-slate-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80 transition-colors dark:border-slate-800 dark:bg-slate-950/95 dark:supports-[backdrop-filter]:bg-slate-950/80">
      <div className="mx-auto flex h-18 max-w-[1440px] items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Left: Mobile hamburger + Primark Wordmark Logo */}
        <div className="flex items-center gap-3 sm:gap-6">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex h-10 w-10 items-center justify-center rounded-md text-slate-700 hover:bg-slate-100 lg:hidden dark:text-slate-200 dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

          {/* Primark Wordmark */}
          <Link
            href="/"
            onClick={() => setSelectedCategory('all')}
            className="group flex items-center gap-0.5 select-none"
          >
            <span className="font-extrabold text-2xl sm:text-3xl tracking-[0.14em] text-[#00A3E0] transition-transform group-hover:scale-[1.01]">
              PRIMARK
            </span>
            <span className="text-xs font-semibold text-[#00A3E0] self-start mt-0.5">®</span>
          </Link>
        </div>

        {/* Center: Desktop Navigation Bar */}
        <nav className="hidden lg:flex items-center gap-7">
          {NAVIGATION_ITEMS.map((item) => {
            const isActive = selectedCategory === item.category;
            return (
              <div
                key={item.name}
                className="relative"
                onMouseEnter={() => setActiveDropdown(item.name)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button
                  onClick={() => handleNavClick(item.category)}
                  className={`text-[15px] font-semibold tracking-normal transition-colors py-5 ${
                    isActive
                      ? 'text-[#00A3E0] dark:text-[#00A3E0]'
                      : 'text-slate-900 hover:text-[#00A3E0] dark:text-slate-100 dark:hover:text-[#00A3E0]'
                  }`}
                >
                  {item.name}
                </button>

                {/* Subcategory dropdown preview */}
                {activeDropdown === item.name && (
                  <div className="absolute left-1/2 -translate-x-1/2 top-full w-60 rounded-xl border border-slate-200 bg-white p-3 shadow-xl ring-1 ring-black/5 dark:border-slate-800 dark:bg-slate-900 z-50">
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2.5 py-1">
                      {item.name} Categories
                    </div>
                    <div className="flex flex-col gap-1 mt-1">
                      {item.subcategories.map((sub) => (
                        <button
                          key={sub}
                          onClick={() => handleNavClick(item.category)}
                          className="flex items-center justify-between rounded-lg px-2.5 py-1.5 text-left text-xs font-medium text-slate-700 hover:bg-slate-100 hover:text-[#00A3E0] dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-[#00A3E0] transition-colors"
                        >
                          <span>{sub}</span>
                          <ChevronRight className="h-3 w-3 text-slate-400" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Right: Actions (Search, Wishlist, Account, Bag, Dark Mode) */}
        <div className="flex items-center gap-1 sm:gap-2">
          
          {/* Dark / Light Mode Toggle */}
          <button
            onClick={toggleTheme}
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-700 hover:bg-slate-100 hover:text-[#00A3E0] dark:text-slate-200 dark:hover:bg-slate-800 dark:hover:text-[#00A3E0] transition-colors"
            aria-label="Toggle dark mode"
            title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
          >
            {theme === 'light' ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5 text-amber-400" />
            )}
          </button>

          {/* Search Button */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-700 hover:bg-slate-100 hover:text-[#00A3E0] dark:text-slate-200 dark:hover:bg-slate-800 dark:hover:text-[#00A3E0] transition-colors"
            aria-label="Search Primark"
            title="Search products"
          >
            <Search className="h-5 w-5" />
          </button>

          {/* Wishlist Button */}
          <button
            onClick={() => setIsWishlistOpen(true)}
            className="relative flex h-10 w-10 items-center justify-center rounded-full text-slate-700 hover:bg-slate-100 hover:text-[#00A3E0] dark:text-slate-200 dark:hover:bg-slate-800 dark:hover:text-[#00A3E0] transition-colors"
            aria-label="View Wishlist"
            title="Saved items"
          >
            <Heart className="h-5 w-5" />
            {wishlist.length > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#00A3E0] text-[10px] font-bold text-white shadow-sm">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Account Button */}
          <button
            onClick={() => setIsAuthOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-700 hover:bg-slate-100 hover:text-[#00A3E0] dark:text-slate-200 dark:hover:bg-slate-800 dark:hover:text-[#00A3E0] transition-colors"
            aria-label="My Account"
            title="Account & Orders"
          >
            <User className="h-5 w-5" />
          </button>

          {/* Shopping Bag Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative flex h-10 w-10 items-center justify-center rounded-full text-slate-700 hover:bg-slate-100 hover:text-[#00A3E0] dark:text-slate-200 dark:hover:bg-slate-800 dark:hover:text-[#00A3E0] transition-colors"
            aria-label="View Shopping Bag"
            title="Shopping bag"
          >
            <ShoppingBag className="h-5 w-5" />
            {cartCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#00A3E0] text-[10px] font-bold text-white shadow-sm animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

        </div>

      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 dark:border-slate-800 dark:bg-slate-950">
          <div className="flex flex-col space-y-1">
            {NAVIGATION_ITEMS.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.category)}
                className="flex items-center justify-between rounded-lg px-3 py-2.5 text-left text-base font-medium text-slate-800 hover:bg-slate-100 hover:text-[#00A3E0] dark:text-slate-200 dark:hover:bg-slate-900"
              >
                <span>{item.name}</span>
                <ChevronRight className="h-4 w-4 text-slate-400" />
              </button>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
            <span>Theme: {theme === 'light' ? 'Light Mode' : 'Dark Mode'}</span>
            <button
              onClick={toggleTheme}
              className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-medium"
            >
              Switch Theme
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
