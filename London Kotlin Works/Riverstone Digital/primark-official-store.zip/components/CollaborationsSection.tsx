'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Sparkles, HeartHandshake, Film } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function CollaborationsSection() {
  const { setSelectedCategory } = useStore();

  const handleCollaborationClick = () => {
    setSelectedCategory('Collaborations');
    const elem = document.getElementById('trending');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="collaborations" className="py-12 sm:py-16 bg-white dark:bg-slate-950 transition-colors">
      <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#00A3E0] uppercase tracking-wider">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Exclusive Partnerships</span>
            </div>
            <h2 className="mt-1 text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Collaborations & Special Edits
            </h2>
          </div>
          <button
            onClick={handleCollaborationClick}
            className="group inline-flex items-center gap-1.5 text-sm font-semibold text-slate-900 hover:text-[#00A3E0] dark:text-white dark:hover:text-[#00A3E0]"
          >
            <span>Explore all edits</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 3 Showcase Banners */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Rita Ora */}
          <div
            onClick={handleCollaborationClick}
            className="group relative h-96 overflow-hidden rounded-2xl cursor-pointer shadow-sm hover:shadow-xl transition-all"
          >
            <Image
              src="/assets/hero/hero_full.png"
              alt="Primark Presents Rita Ora"
              fill
              referrerPolicy="no-referrer"
              className="object-cover object-left transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
            
            <div className="absolute bottom-6 left-6 right-6 z-10 text-white">
              <div className="text-xs font-bold tracking-widest uppercase text-[#00A3E0]">
                Exclusive Drop
              </div>
              <h3 className="mt-1 text-2xl font-black">Primark Presents Rita Ora</h3>
              <p className="mt-2 text-xs text-slate-200 line-clamp-2">
                Effortless tailoring, structured trench coats, and sharp winter silhouettes designed with Rita.
              </p>
              <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold text-white group-hover:text-[#00A3E0] transition-colors">
                <span>Shop the Rita Ora Edit</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>

          {/* Card 2: Disney x Primark */}
          <div
            onClick={handleCollaborationClick}
            className="group relative h-96 overflow-hidden rounded-2xl cursor-pointer shadow-sm hover:shadow-xl transition-all"
          >
            <Image
              src="/assets/categories/cat_kids.png"
              alt="Disney x Primark Collection"
              fill
              referrerPolicy="no-referrer"
              className="object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
            
            <div className="absolute bottom-6 left-6 right-6 z-10 text-white">
              <div className="flex items-center gap-1 text-xs font-bold tracking-widest uppercase text-amber-300">
                <Film className="h-3.5 w-3.5" />
                <span>Family Favourite</span>
              </div>
              <h3 className="mt-1 text-2xl font-black">Disney x Primark</h3>
              <p className="mt-2 text-xs text-slate-200 line-clamp-2">
                Cozy Mickey & Minnie matching pyjamas, festive character knitwear, and holiday bedroom decor.
              </p>
              <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                <span>Shop Disney Edit</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>

          {/* Card 3: Primark Cares */}
          <div
            onClick={handleCollaborationClick}
            className="group relative h-96 overflow-hidden rounded-2xl cursor-pointer shadow-sm hover:shadow-xl transition-all"
          >
            <Image
              src="/assets/categories/cat_home.png"
              alt="Primark Cares Sustainability Initiative"
              fill
              referrerPolicy="no-referrer"
              className="object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
            
            <div className="absolute bottom-6 left-6 right-6 z-10 text-white">
              <div className="flex items-center gap-1 text-xs font-bold tracking-widest uppercase text-emerald-400">
                <HeartHandshake className="h-3.5 w-3.5" />
                <span>Primark Cares</span>
              </div>
              <h3 className="mt-1 text-2xl font-black">Sustainable Cotton Initiative</h3>
              <p className="mt-2 text-xs text-slate-200 line-clamp-2">
                Affordable fashion with a conscience. Over 55% of clothes sold now made from recycled or organic fibers.
              </p>
              <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold text-white group-hover:text-emerald-400 transition-colors">
                <span>Discover Primark Cares</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
