'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, CheckCircle2, Sparkles, Tag } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function CartDrawer() {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartTotal,
    cartCount,
    formatPrice,
    selectedStore,
  } = useStore();

  const [deliveryMethod, setDeliveryMethod] = useState<'click-collect' | 'home'>('click-collect');
  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  if (!isCartOpen) return null;

  const freeThreshold = 15.00;
  const progressPercent = Math.min(100, (cartTotal / freeThreshold) * 100);
  const remainingForFree = Math.max(0, freeThreshold - cartTotal);

  const deliveryCost = deliveryMethod === 'click-collect' ? (cartTotal >= freeThreshold ? 0 : 2.50) : 3.95;
  const discountAmount = (cartTotal * discountPercent) / 100;
  const grandTotal = Math.max(0, cartTotal - discountAmount + deliveryCost);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    setPromoSuccess('');
    const code = promoCode.trim().toUpperCase();

    if (code === 'PRIMARK10') {
      setDiscountPercent(10);
      setPromoSuccess('10% discount applied to your order!');
    } else if (code === 'FREESHIP') {
      setDiscountPercent(5);
      setPromoSuccess('Free shipping perk applied!');
    } else {
      setPromoError('Invalid promo code. Try "PRIMARK10"');
    }
  };

  const handleCheckout = () => {
    const randomOrderNum = 'PRM-' + Math.floor(100000 + Math.random() * 900000);
    setOrderNumber(randomOrderNum);
    setOrderConfirmed(true);
    clearCart();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      {/* Drawer Panel */}
      <div className="relative z-10 flex h-full w-full max-w-md flex-col bg-white shadow-2xl transition-all dark:bg-slate-900">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-[#00A3E0]" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Shopping Bag ({cartCount})
            </h2>
          </div>
          <button
            onClick={() => setIsCartOpen(false)}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
            aria-label="Close cart"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Order Confirmed Screen */}
        {orderConfirmed ? (
          <div className="flex flex-1 flex-col items-center justify-center p-6 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950/80 dark:text-emerald-400">
              <CheckCircle2 className="h-10 w-10" />
            </div>
            <h3 className="mt-4 text-xl font-extrabold text-slate-900 dark:text-white">
              Order Confirmed!
            </h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-mono">
              Reference #{orderNumber}
            </p>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">
              {deliveryMethod === 'click-collect'
                ? `Your order will be ready for Click & Collect at ${selectedStore.name} in 2-4 working days.`
                : 'Your order will be packed and delivered to your doorstep in 3-5 working days.'}
            </p>
            <div className="mt-6 w-full rounded-xl bg-slate-50 p-4 text-left text-xs text-slate-600 dark:bg-slate-800/60 dark:text-slate-300">
              <div className="font-semibold text-slate-900 dark:text-white">What happens next:</div>
              <ul className="mt-2 list-disc pl-4 space-y-1">
                <li>Confirmation email sent with invoice</li>
                <li>SMS update when collection parcel is staged</li>
                <li>Bring your photo ID and confirmation barcode</li>
              </ul>
            </div>
            <button
              onClick={() => {
                setOrderConfirmed(false);
                setIsCartOpen(false);
              }}
              className="mt-6 w-full rounded-xl bg-[#00A3E0] py-3 text-sm font-bold text-white shadow-sm hover:bg-[#0090c7]"
            >
              Continue Shopping
            </button>
          </div>
        ) : cart.length === 0 ? (
          /* Empty Bag */
          <div className="flex flex-1 flex-col items-center justify-center p-6 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-400 dark:bg-slate-800">
              <ShoppingBag className="h-8 w-8" />
            </div>
            <h3 className="mt-4 text-base font-bold text-slate-900 dark:text-white">
              Your bag is empty
            </h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 max-w-xs">
              Check out our new season arrivals and viral beauty picks to start filling it up!
            </p>
            <button
              onClick={() => setIsCartOpen(false)}
              className="mt-5 rounded-xl bg-[#00A3E0] px-6 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#0090c7]"
            >
              Browse New Season
            </button>
          </div>
        ) : (
          /* Cart with items */
          <>
            {/* Free Click & Collect Progress Meter */}
            <div className="bg-slate-50 px-5 py-3 border-b border-slate-200 dark:bg-slate-800/60 dark:border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {cartTotal >= freeThreshold
                    ? '🎉 You qualified for FREE Click & Collect!'
                    : `Add ${formatPrice(remainingForFree)} more for FREE Click & Collect`}
                </span>
                <span className="text-[11px] font-mono font-medium text-slate-500">
                  {formatPrice(cartTotal)} / {formatPrice(freeThreshold)}
                </span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
                <div
                  className="h-full bg-[#00A3E0] transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Items List */}
            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 no-scrollbar">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3.5 rounded-xl border border-slate-100 bg-white p-3 shadow-sm dark:border-slate-800 dark:bg-slate-900/60"
                >
                  <div className="relative h-20 w-16 shrink-0 overflow-hidden rounded-lg bg-slate-100 dark:bg-slate-800">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      referrerPolicy="no-referrer"
                      className="object-cover"
                    />
                  </div>

                  <div className="flex flex-1 flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                          {item.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-slate-400 hover:text-rose-500"
                          aria-label="Remove item"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>

                      <div className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                        Size: <span className="font-medium text-slate-700 dark:text-slate-300">{item.size}</span> · Color: <span className="font-medium text-slate-700 dark:text-slate-300">{item.color}</span>
                      </div>
                    </div>

                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-800">
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                          className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold tabular-nums text-slate-800 dark:text-slate-200">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                          className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                          aria-label="Increase quantity"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>

                      <div className="text-xs font-black text-slate-900 tabular-nums dark:text-white">
                        {formatPrice(item.price * item.quantity)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {/* Promo Code Input */}
              <div className="pt-2">
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Promo code (e.g. PRIMARK10)"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="w-full rounded-lg border border-slate-200 bg-white pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:border-[#00A3E0] focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600"
                  >
                    Apply
                  </button>
                </form>
                {promoError && <p className="mt-1 text-[11px] text-rose-500">{promoError}</p>}
                {promoSuccess && <p className="mt-1 text-[11px] text-emerald-500">{promoSuccess}</p>}
              </div>

              {/* Delivery method selector */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-3 dark:border-slate-800 dark:bg-slate-800/40">
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-2">
                  Collection / Delivery Option:
                </div>
                <div className="space-y-1.5">
                  <label className="flex items-center justify-between text-xs cursor-pointer">
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="delivery"
                        checked={deliveryMethod === 'click-collect'}
                        onChange={() => setDeliveryMethod('click-collect')}
                        className="text-[#00A3E0]"
                      />
                      <span>Click & Collect ({selectedStore.name.split('-')[1]?.trim() || selectedStore.city})</span>
                    </div>
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {cartTotal >= freeThreshold ? 'FREE' : formatPrice(2.50)}
                    </span>
                  </label>

                  <label className="flex items-center justify-between text-xs cursor-pointer">
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="delivery"
                        checked={deliveryMethod === 'home'}
                        onChange={() => setDeliveryMethod('home')}
                        className="text-[#00A3E0]"
                      />
                      <span>Standard Home Delivery</span>
                    </div>
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {formatPrice(3.95)}
                    </span>
                  </label>
                </div>
              </div>
            </div>

            {/* Footer Summary & Checkout */}
            <div className="border-t border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                <div className="flex justify-between">
                  <span>Bag Subtotal</span>
                  <span className="font-medium text-slate-900 dark:text-white tabular-nums">
                    {formatPrice(cartTotal)}
                  </span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                    <span>Discount ({discountPercent}%)</span>
                    <span className="tabular-nums">-{formatPrice(discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Estimated Delivery</span>
                  <span className="font-medium text-slate-900 dark:text-white tabular-nums">
                    {deliveryCost === 0 ? 'FREE' : formatPrice(deliveryCost)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-sm font-black text-slate-900 dark:text-white">
                  <span>Total</span>
                  <span className="text-base tabular-nums text-[#00A3E0]">
                    {formatPrice(grandTotal)}
                  </span>
                </div>
              </div>

              <button
                onClick={handleCheckout}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[#00A3E0] py-3 text-sm font-bold text-white shadow-md hover:bg-[#0090c7] active:scale-[0.99] transition-all"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </>
        )}

      </div>
    </div>
  );
}
