export type ProductCategory = 'Women' | 'Men' | 'Kids' | 'Home' | 'Beauty' | 'Collaborations' | 'Offers';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  subcategory: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  secondaryImage?: string;
  description: string;
  colors: { name: string; hex: string }[];
  sizes: string[];
  inStock: boolean;
  stockCount: number;
  clickAndCollect: boolean;
  isNew?: boolean;
  isTrending?: boolean;
  badge?: string;
  features: string[];
  composition: string;
  care: string;
}

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  price: number;
  image: string;
  size: string;
  color: string;
  quantity: number;
  category: ProductCategory;
}

export interface WishlistItem {
  productId: string;
  addedAt: string;
}

export interface StoreLocation {
  id: string;
  name: string;
  address: string;
  city: string;
  postcode: string;
  distance: string;
  clickAndCollectAvailable: boolean;
  openingHours: string;
  phone: string;
}

export interface CountryCurrency {
  code: string;
  country: string;
  flag: string;
  currency: string;
  symbol: string;
  rate: number;
}
