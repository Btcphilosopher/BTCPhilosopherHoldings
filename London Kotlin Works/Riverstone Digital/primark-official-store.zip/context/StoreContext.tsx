'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, CartItem, StoreLocation, CountryCurrency } from '@/lib/types';
import { CURRENCIES, STORES, PRODUCTS } from '@/lib/data';

interface StoreContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  cart: CartItem[];
  addToCart: (product: Product, size?: string, color?: string, quantity?: number) => void;
  updateCartQuantity: (cartItemId: string, quantity: number) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  selectedStore: StoreLocation;
  setSelectedStore: (store: StoreLocation) => void;
  currency: CountryCurrency;
  setCurrency: (currency: CountryCurrency) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isStoreFinderOpen: boolean;
  setIsStoreFinderOpen: (open: boolean) => void;
  isAuthOpen: boolean;
  setIsAuthOpen: (open: boolean) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (prod: Product | null) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  formatPrice: (gbpAmount: number) => string;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [selectedStore, setSelectedStore] = useState<StoreLocation>(STORES[0]);
  const [currency, setCurrency] = useState<CountryCurrency>(CURRENCIES[0]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isStoreFinderOpen, setIsStoreFinderOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Initialize from localStorage
  useEffect(() => {
    try {
      const storedTheme = localStorage.getItem('primark-theme') as 'light' | 'dark' | null;
      if (storedTheme) {
        setTheme(storedTheme);
        if (storedTheme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        setTheme('dark');
        document.documentElement.classList.add('dark');
      }

      const storedCart = localStorage.getItem('primark-cart');
      if (storedCart) {
        setCart(JSON.parse(storedCart));
      }

      const storedWishlist = localStorage.getItem('primark-wishlist');
      if (storedWishlist) {
        setWishlist(JSON.parse(storedWishlist));
      }

      const storedStoreId = localStorage.getItem('primark-store');
      if (storedStoreId) {
        const found = STORES.find((s) => s.id === storedStoreId);
        if (found) setSelectedStore(found);
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    try {
      localStorage.setItem('primark-theme', next);
      if (next === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } catch (_) {}
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  const addToCart = (product: Product, size?: string, color?: string, quantity: number = 1) => {
    const chosenSize = size || product.sizes[0] || 'One Size';
    const chosenColor = color || (product.colors[0]?.name ?? 'Default');
    const itemId = `${product.id}-${chosenSize}-${chosenColor}`;

    setCart((prev) => {
      const existing = prev.find((item) => item.id === itemId);
      let updated: CartItem[];
      if (existing) {
        updated = prev.map((item) =>
          item.id === itemId ? { ...item, quantity: item.quantity + quantity } : item
        );
      } else {
        const newItem: CartItem = {
          id: itemId,
          productId: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          size: chosenSize,
          color: chosenColor,
          quantity,
          category: product.category,
        };
        updated = [newItem, ...prev];
      }
      try {
        localStorage.setItem('primark-cart', JSON.stringify(updated));
      } catch (_) {}
      return updated;
    });

    showToast(`Added "${product.name}" to your bag`);
  };

  const updateCartQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart((prev) => {
      const updated = prev.map((item) =>
        item.id === cartItemId ? { ...item, quantity } : item
      );
      try {
        localStorage.setItem('primark-cart', JSON.stringify(updated));
      } catch (_) {}
      return updated;
    });
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => {
      const updated = prev.filter((item) => item.id !== cartItemId);
      try {
        localStorage.setItem('primark-cart', JSON.stringify(updated));
      } catch (_) {}
      return updated;
    });
    showToast('Item removed from bag');
  };

  const clearCart = () => {
    setCart([]);
    try {
      localStorage.removeItem('primark-cart');
    } catch (_) {}
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      const updated = exists ? prev.filter((id) => id !== productId) : [...prev, productId];
      try {
        localStorage.setItem('primark-wishlist', JSON.stringify(updated));
      } catch (_) {}
      const prod = PRODUCTS.find((p) => p.id === productId);
      const title = prod ? prod.name : 'Item';
      showToast(exists ? `Removed "${title}" from wishlist` : `Saved "${title}" to wishlist`);
      return updated;
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  const cartTotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const formatPrice = (gbpAmount: number) => {
    const converted = gbpAmount * currency.rate;
    return `${currency.symbol}${converted.toFixed(2)}`;
  };

  return (
    <StoreContext.Provider
      value={{
        theme,
        toggleTheme,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartTotal,
        cartCount,
        wishlist,
        toggleWishlist,
        isInWishlist,
        selectedStore,
        setSelectedStore: (store) => {
          setSelectedStore(store);
          try {
            localStorage.setItem('primark-store', store.id);
          } catch (_) {}
        },
        currency,
        setCurrency,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        isCartOpen,
        setIsCartOpen,
        isWishlistOpen,
        setIsWishlistOpen,
        isSearchOpen,
        setIsSearchOpen,
        isStoreFinderOpen,
        setIsStoreFinderOpen,
        isAuthOpen,
        setIsAuthOpen,
        quickViewProduct,
        setQuickViewProduct,
        toastMessage,
        showToast,
        formatPrice,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
