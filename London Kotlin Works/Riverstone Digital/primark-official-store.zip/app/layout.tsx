import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Primark Official Store | New Season Fashion & Essentials',
  description: 'Discover new season fashion, winter essentials, home living, beauty and trending styles with Click & Collect.',
  openGraph: {
    title: 'Primark Official Store | New Season Fashion & Essentials',
    description: 'Discover new season fashion, winter essentials, home living, beauty and trending styles with Click & Collect.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Primark Official Store | New Season Fashion & Essentials',
    description: 'Discover new season fashion, winter essentials, home living, beauty and trending styles with Click & Collect.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const storedTheme = localStorage.getItem('primark-theme');
                if (storedTheme === 'dark' || (!storedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                  document.documentElement.classList.add('dark');
                } else {
                  document.documentElement.classList.remove('dark');
                }
              } catch (_) {}
            `,
          }}
        />
      </head>
      <body className="min-h-screen bg-white text-slate-900 transition-colors duration-200 dark:bg-slate-950 dark:text-slate-100" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
