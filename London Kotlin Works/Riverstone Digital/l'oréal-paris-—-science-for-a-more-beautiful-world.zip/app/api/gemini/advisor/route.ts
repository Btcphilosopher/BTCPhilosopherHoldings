import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { messages, userContext } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "GEMINI_API_KEY is not configured." },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `
You are the L'Oréal Paris AI Beauty & Skincare Master Consultant.
Your persona is sophisticated, warm, scientific, and authoritative, representing the L'Oréal House of Brands (L'Oréal Paris, Kérastase, La Roche-Posay, Maybelline, Vichy, Redken, Biotherm).

Key Knowledge & Principles:
1. Explain ingredients clearly (e.g. Hyaluronic Acid, Retinol, Niacinamide, Madecassoside, Camellia Oil).
2. Recommend specific products from L'Oréal Paris, Kérastase, La Roche-Posay, Maybelline, Vichy, Redken, or Biotherm.
3. Keep answers elegant, concise, and helpful (2-3 paragraphs max). Use bullet points for routines or shade tips.
`;

    const formattedContents = messages.map((m: any) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return NextResponse.json({ reply: response.text });
  } catch (err: any) {
    console.error("Beauty Advisor API Error:", err);
    return NextResponse.json(
      { error: err.message || "Failed to process beauty advice" },
      { status: 500 }
    );
  }
}
