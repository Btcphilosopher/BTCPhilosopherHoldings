import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { skinType, concerns, ageGroup, sensitivity, dailySun, texturePreference } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "GEMINI_API_KEY is not configured." },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({ apiKey });

    const prompt = `
You are L'Oréal Scientific Dermatological AI Advisor.
Analyze the following patient/client skin profile and generate a hyper-personalized, scientific skin diagnostic report.

Client Profile:
- Skin Type: ${skinType || 'Combination'}
- Primary Concerns: ${Array.isArray(concerns) ? concerns.join(', ') : (concerns || 'Dullness, Fine Lines')}
- Age Group: ${ageGroup || '25-34'}
- Sensitivity Level: ${sensitivity || 'Moderate'}
- Daily Sun Exposure: ${dailySun || 'Moderate (1-2 hours)'}
- Texture Preference: ${texturePreference || 'Lightweight Serum / Gel'}

Please provide a JSON response with the exact structure below (no markdown formatting, raw JSON string only):
{
  "barrierHealthScore": 84,
  "hydrationIndex": "72%",
  "sensitivityRisk": "Low-Moderate",
  "diagnosticSummary": "3-sentence scientific evaluation of the skin barrier and primary needs.",
  "activeIngredients": [
    {
      "name": "Pure Hyaluronic Acid (1.5%)",
      "purpose": "Multi-depth moisture retention and instant epidermal plumping."
    },
    {
      "name": "Niacinamide (Vitamin B3)",
      "purpose": "Soothes redness and evens hyperpigmented tone."
    },
    {
      "name": "Centella Asiatica / Madecassoside",
      "purpose": "Reinforces lipid barrier resilience and reduces inflammation."
    }
  ],
  "amRoutine": [
    {
      "step": 1,
      "category": "Cleanser",
      "action": "Gentle pH-Balanced Hydrating Cleanser",
      "recommendedProduct": "La Roche-Posay Toleriane Gentle Hydrating Cleanser"
    },
    {
      "step": 2,
      "category": "Serum",
      "action": "Intensive Plumping Hyaluronic Acid",
      "recommendedProduct": "L'Oréal Revitalift Pure 1.5% Hyaluronic Acid Serum"
    },
    {
      "step": 3,
      "category": "Moisturizer & SPF",
      "action": "Volcanic Mineral Hydrator with Broad Spectrum SPF 50+",
      "recommendedProduct": "Vichy Minéral 89 Daily Booster & SPF 50"
    }
  ],
  "pmRoutine": [
    {
      "step": 1,
      "category": "Purify",
      "action": "Micellar Cleansing Water & Oil Balm",
      "recommendedProduct": "L'Oréal Revitalift Micellar Cleanser"
    },
    {
      "step": 2,
      "category": "Repair Serum",
      "action": "Dermatological Barrier Repair Treatment",
      "recommendedProduct": "La Roche-Posay Hyalu B5 Serum"
    },
    {
      "step": 3,
      "category": "Night Renewal",
      "action": "Amber Algae Firming Night Cream",
      "recommendedProduct": "Biotherm Blue Therapy Amber Algae Cream"
    }
  ],
  "lorealScienceInsight": "A 2-sentence explanation of L'Oréal's scientific technology (e.g. Micro-molecular HA, Life Plankton, or Pro-Xylane)."
}
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("No response returned from Gemini AI.");
    }

    const parsedData = JSON.parse(resultText);
    return NextResponse.json(parsedData);
  } catch (err: any) {
    console.error("Skin Analysis API Error:", err);
    return NextResponse.json(
      { error: err.message || "Failed to analyze skin profile" },
      { status: 500 }
    );
  }
}
