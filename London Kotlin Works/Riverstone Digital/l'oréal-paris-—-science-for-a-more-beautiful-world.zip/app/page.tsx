'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { BrandsSection } from '@/components/BrandsSection';
import { BestSellersSection } from '@/components/BestSellersSection';
import { AISkinAnalyzerModal } from '@/components/AISkinAnalyzerModal';
import { VirtualTryOnModal } from '@/components/VirtualTryOnModal';
import { ProductQuickViewModal } from '@/components/ProductQuickViewModal';
import { ScienceAndSustainability } from '@/components/ScienceAndSustainability';
import { CartDrawer, CartItem } from '@/components/CartDrawer';
import { AIBeautyChat } from '@/components/AIBeautyChat';
import { Footer } from '@/components/Footer';
import { PRODUCTS, Product, ShadeOption } from '@/lib/products';

export default function HomePage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlistCount, setWishlistCount] = useState<number>(2);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isSkinAnalyzerOpen, setIsSkinAnalyzerOpen] = useState<boolean>(false);
  const [isVirtualTryOnOpen, setIsVirtualTryOnOpen] = useState<boolean>(false);
  const [selectedQuickProduct, setSelectedQuickProduct] = useState<Product | null>(null);
  const [selectedBrandFilter, setSelectedBrandFilter] = useState<string | null>(null);

  // Spotlight product for hero
  const revitaliftProduct = PRODUCTS[0];

  const handleAddToCart = (product: Product, shade?: ShadeOption) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (item) =>
          item.product.id === product.id &&
          item.selectedShade?.id === shade?.id
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += 1;
        return updated;
      }

      return [...prev, { product, quantity: 1, selectedShade: shade }];
    });

    setIsCartOpen(true);
  };

  const handleAddMultipleToCart = (productsToAdd: Product[]) => {
    productsToAdd.forEach((p) => {
      handleAddToCart(p);
    });
  };

  const handleUpdateQuantity = (
    productId: string,
    newQty: number,
    shadeId?: string
  ) => {
    if (newQty <= 0) {
      handleRemoveItem(productId, shadeId);
      return;
    }

    setCartItems((prev) =>
      prev.map((item) => {
        if (
          item.product.id === productId &&
          item.selectedShade?.id === shadeId
        ) {
          return { ...item, quantity: newQty };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (productId: string, shadeId?: string) => {
    setCartItems((prev) =>
      prev.filter(
        (item) =>
          !(
            item.product.id === productId &&
            item.selectedShade?.id === shadeId
          )
      )
    );
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleSelectBrand = (brandName: string | null) => {
    setSelectedBrandFilter(brandName || null);
    const element = document.getElementById('bestsellers');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#111111] font-sans-clean antialiased selection:bg-[#B89768] selection:text-white">
      {/* Navigation Top Bar */}
      <Navbar
        cartCount={totalCartCount}
        wishlistCount={wishlistCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSkinAnalyzer={() => setIsSkinAnalyzerOpen(true)}
        onOpenVirtualTryOn={() => setIsVirtualTryOnOpen(true)}
        onSelectBrand={handleSelectBrand}
        selectedBrand={selectedBrandFilter}
        products={PRODUCTS}
        onSelectProduct={(p) => setSelectedQuickProduct(p)}
      />

      {/* Hero Showcase */}
      <HeroSection
        onShopBestsellers={() => {
          const el = document.getElementById('bestsellers');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onSelectProduct={(p) => setSelectedQuickProduct(p)}
        onAddToCart={handleAddToCart}
        revitaliftProduct={revitaliftProduct}
      />

      {/* House of Brands Grid */}
      <BrandsSection
        onSelectBrand={handleSelectBrand}
        selectedBrand={selectedBrandFilter}
      />

      {/* Best Sellers & Product Catalog */}
      <BestSellersSection
        products={PRODUCTS}
        selectedBrand={selectedBrandFilter}
        onSelectProduct={(p) => setSelectedQuickProduct(p)}
        onAddToCart={handleAddToCart}
        onClearBrandFilter={() => setSelectedBrandFilter(null)}
        onOpenVirtualTryOn={() => setIsVirtualTryOnOpen(true)}
      />

      {/* L'Oréal Science & Sustainability Section */}
      <ScienceAndSustainability />

      {/* Footer */}
      <Footer />

      {/* Interactive AI Skin Diagnostics Suite Modal */}
      <AISkinAnalyzerModal
        isOpen={isSkinAnalyzerOpen}
        onClose={() => setIsSkinAnalyzerOpen(false)}
        onAddMultipleToCart={handleAddMultipleToCart}
        allProducts={PRODUCTS}
      />

      {/* Interactive Virtual Shade Finder Modal */}
      <VirtualTryOnModal
        isOpen={isVirtualTryOnOpen}
        onClose={() => setIsVirtualTryOnOpen(false)}
        onAddToCart={handleAddToCart}
        products={PRODUCTS}
      />

      {/* Product Quick View Detail Modal */}
      <ProductQuickViewModal
        product={selectedQuickProduct}
        onClose={() => setSelectedQuickProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Gemini AI Beauty Advisor Chat */}
      <AIBeautyChat />
    </div>
  );
}
