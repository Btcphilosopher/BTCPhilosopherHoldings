import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: "L'Oréal Paris — Science for a More Beautiful World",
  description: "Luxury beauty, skincare & cosmetics e-commerce portal featuring AI skin analysis, shade finding, interactive brand exploration, and scientific routine customizer.",
  openGraph: {
    title: "L'Oréal Paris — Science for a More Beautiful World",
    description: "Luxury beauty, skincare & cosmetics e-commerce portal featuring AI skin analysis, shade finding, interactive brand exploration, and scientific routine customizer.",
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: "L'Oréal Paris — Science for a More Beautiful World",
    description: "Luxury beauty, skincare & cosmetics e-commerce portal featuring AI skin analysis, shade finding, interactive brand exploration, and scientific routine customizer.",
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
