import heroPortrait from '../src/assets/images/hero_beauty_portrait_1790952478303.jpg';
import kerastaseImg from '../src/assets/images/brand_kerastase_oil_1790952498653.jpg';
import laRocheImg from '../src/assets/images/brand_laroche_serum_1790952509377.jpg';
import maybellineImg from '../src/assets/images/brand_maybelline_lipstick_1790952520081.jpg';

export interface BrandInfo {
  id: string;
  name: string;
  tagline: string;
  categories: string[];
  image: string;
  accentColor: string;
  description: string;
}

export const HOUSE_BRANDS: BrandInfo[] = [
  {
    id: 'loreal-paris',
    name: 'L\'ORÉAL PARIS',
    tagline: 'Because You\'re Worth It',
    categories: ['Skincare', 'Makeup', 'Haircare'],
    image: heroPortrait.src,
    accentColor: '#B89768',
    description: 'Leading global beauty brand offering accessible luxury powered by cutting-edge scientific innovation.'
  },
  {
    id: 'kerastase',
    name: 'KÉRASTASE',
    tagline: 'Luxury Care for Exceptional Hair',
    categories: ['Haircare', 'Scalp Care', 'Treatments'],
    image: kerastaseImg.src,
    accentColor: '#D97706',
    description: 'Bespoke professional hair care formulas crafted with precious oils and hair biotechnology.'
  },
  {
    id: 'la-roche-posay',
    name: 'LA ROCHE-POSAY',
    tagline: 'Dermatological Beauty Partnered with 90,000 Dermatologists',
    categories: ['Skincare', 'Sensitively Care', 'Sun Protection'],
    image: laRocheImg.src,
    accentColor: '#0284C7',
    description: 'Thermal spring water formulas scientifically proven to restore and soothe sensitive skin.'
  },
  {
    id: 'maybelline',
    name: 'MAYBELLINE NEW YORK',
    tagline: 'Make It Happen with High-Performance Color',
    categories: ['Makeup', 'Lips', 'Eyes', 'Face'],
    image: maybellineImg.src,
    accentColor: '#9333EA',
    description: 'Urban-inspired high-impact makeup formulated for long wear and effortless self-expression.'
  },
  {
    id: 'vichy',
    name: 'VICHY LABORATORIES',
    tagline: 'Volcanic Mineralizing Water for Healthy Skin Barrier',
    categories: ['Skincare', 'Anti-Aging', 'Exposome Science'],
    image: laRocheImg.src,
    accentColor: '#059669',
    description: 'Mineral-rich French volcanic water formulations designed to protect skin against exposome stress.'
  },
  {
    id: 'redken',
    name: 'REDKEN 5TH AVENUE NYC',
    tagline: 'Protein Science & Scientific pH for Hair Strength',
    categories: ['Haircare', 'Bond Repair', 'Color Care'],
    image: kerastaseImg.src,
    accentColor: '#DC2626',
    description: 'Salons-first NYC formula pioneer powered by acidic pH science and amino protein bonding.'
  },
  {
    id: 'biotherm',
    name: 'BIOTHERM',
    tagline: 'Healing Powers of Water Biotechnology',
    categories: ['Skincare', 'Hydration', 'Marine Biotechnology'],
    image: laRocheImg.src,
    accentColor: '#475569',
    description: 'Biotech skincare formulas harnessing Life Plankton™ and ocean nutrients for skin renewal.'
  }
];
