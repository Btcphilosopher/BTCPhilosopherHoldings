import heroPortrait from '../src/assets/images/hero_beauty_portrait_1790952478303.jpg';
import revitaliftImg from '../src/assets/images/revitalift_serum_bottle_1790952488522.jpg';
import kerastaseImg from '../src/assets/images/brand_kerastase_oil_1790952498653.jpg';
import laRocheImg from '../src/assets/images/brand_laroche_serum_1790952509377.jpg';
import maybellineImg from '../src/assets/images/brand_maybelline_lipstick_1790952520081.jpg';

export interface ShadeOption {
  id: string;
  name: string;
  hex: string;
  finish?: 'Matte' | 'Satin' | 'Gloss' | 'Dewy';
}

export interface Product {
  id: string;
  name: string;
  brand: 'L\'Oréal Paris' | 'Kérastase' | 'La Roche-Posay' | 'Maybelline' | 'Vichy' | 'Redken' | 'Biotherm';
  category: 'Skincare' | 'Haircare' | 'Makeup' | 'Sun & Body' | 'Anti-Aging';
  subCategory: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  badge?: 'Bestseller' | 'New' | 'Award Winner' | 'Eco-Refill';
  image: string;
  secondaryImage?: string;
  description: string;
  keyIngredients: string[];
  activeBenefits: string[];
  shades?: ShadeOption[];
  instructions: string;
  ecoScore: 'A' | 'B' | 'C';
  size: string;
}

export const PRODUCTS: Product[] = [
  {
    id: 'loreal-revitalift-serum',
    name: 'Revitalift Pure 1.5% Hyaluronic Acid Serum',
    brand: 'L\'Oréal Paris',
    category: 'Skincare',
    subCategory: 'Anti-Aging Serum',
    price: 32.99,
    originalPrice: 38.00,
    rating: 4.9,
    reviewsCount: 1420,
    badge: 'Bestseller',
    image: revitaliftImg.src,
    description: 'Dermatologist-validated intensive hydrating serum with 1.5% Pure Hyaluronic Acid. Visibly plumps skin in 1 hour and reduces wrinkles by up to 47% in 6 weeks.',
    keyIngredients: ['Macro Hyaluronic Acid (0.5%)', 'Micro Hyaluronic Acid (1.0%)', 'Glycerin', 'Vitamin Cg'],
    activeBenefits: ['Deep Multi-Layer Hydration', 'Instant Wrinkle Plumping', 'Skin Barrier Fortification'],
    instructions: 'Apply 2–3 drops morning and evening to cleansed face and neck before moisturizer.',
    ecoScore: 'A',
    size: '30 ml / 1.0 fl. oz'
  },
  {
    id: 'kerastase-elixir-ultime',
    name: 'Elixir Ultime L\'Huile Originale Hair Oil',
    brand: 'Kérastase',
    category: 'Haircare',
    subCategory: 'Nourishing Hair Serum',
    price: 54.00,
    rating: 4.8,
    reviewsCount: 890,
    badge: 'Award Winner',
    image: kerastaseImg.src,
    description: 'Iconic leave-in hair oil with Camellia and Argan oils. Delivers 96-hour anti-frizz protection, intense shine, and heat protection up to 230°C.',
    keyIngredients: ['French Camellia Oil', 'Wild Argan Oil', 'Marula Oil', 'Germ Maize Oil'],
    activeBenefits: ['230°C Heat Protection', '96H Anti-Frizz', 'Instant 6x Luminous Shine'],
    instructions: 'Dispense 1–2 pumps onto palm, apply evenly through mid-lengths and ends of wet or dry hair.',
    ecoScore: 'A',
    size: '100 ml / 3.4 fl. oz'
  },
  {
    id: 'laroche-hyalu-b5',
    name: 'Hyalu B5 Pure Hyaluronic Acid Serum',
    brand: 'La Roche-Posay',
    category: 'Skincare',
    subCategory: 'Dermatological Repair',
    price: 39.50,
    rating: 4.9,
    reviewsCount: 2150,
    badge: 'Bestseller',
    image: laRocheImg.src,
    description: 'Dermatologist-recommended anti-aging repairing serum formulated with pure Hyaluronic Acid, Vitamin B5, and Madecassoside for sensitive skin.',
    keyIngredients: ['Pure Hyaluronic Acid', 'Vitamin B5 (Panthenol)', 'Madecassoside (Centella)', 'Thermal Spring Water'],
    activeBenefits: ['Skin Barrier Repair', 'Soothes Sensitivity', 'Restores Volume & Bounce'],
    instructions: 'Smooth 3–4 drops over face, neck, and décolleté in the AM and PM.',
    ecoScore: 'A',
    size: '30 ml / 1.0 fl. oz'
  },
  {
    id: 'maybelline-superstay-lipstick',
    name: 'SuperStay Matte Ink Liquid Lipstick',
    brand: 'Maybelline',
    category: 'Makeup',
    subCategory: 'Lip Care & Color',
    price: 11.99,
    originalPrice: 13.99,
    rating: 4.7,
    reviewsCount: 3410,
    badge: 'New',
    image: maybellineImg.src,
    description: 'Flawless 16-hour saturated matte liquid lipstick featuring an arrow applicator for precise application with zero transfer.',
    keyIngredients: ['High-Pigment Polymer Matrix', 'Vitamin E derivative', 'Squalane'],
    activeBenefits: ['16-Hour Transfer Proof', 'Full Coverage Matte Finish', 'Non-Drying Comfort'],
    shades: [
      { id: '150-pathfinder', name: '150 Pathfinder', hex: '#B82E46', finish: 'Matte' },
      { id: '80-ruler', name: '80 Ruler', hex: '#A83244', finish: 'Matte' },
      { id: '65-seductress', name: '65 Seductress', hex: '#C48375', finish: 'Matte' },
      { id: '20-pioneer', name: '20 Pioneer', hex: '#9E0B20', finish: 'Matte' },
      { id: '15-lover', name: '15 Lover', hex: '#B25D73', finish: 'Matte' }
    ],
    instructions: 'Apply liquid lipstick in the center of your upper lip and follow the contours of your mouth.',
    ecoScore: 'B',
    size: '5 ml / 0.17 fl. oz'
  },
  {
    id: 'vichy-mineral-89',
    name: 'Minéral 89 Hyaluronic Acid Hydrating Booster',
    brand: 'Vichy',
    category: 'Skincare',
    subCategory: 'Daily Skin Fortifier',
    price: 29.99,
    rating: 4.8,
    reviewsCount: 1780,
    badge: 'Bestseller',
    image: laRocheImg.src,
    description: 'Formulated with 89% Vichy Volcanic Mineralizing Water and Natural Origin Hyaluronic Acid. Strengthens skin moisture barrier against daily exposome factors.',
    keyIngredients: ['89% Vichy Volcanic Mineralizing Water', 'Natural Origin Hyaluronic Acid', '15 Essential Minerals'],
    activeBenefits: ['Skin Barrier Defense', '24H Pure Hydration', 'Fragrance-Free Paraben-Free'],
    instructions: 'Use as the first step of your daily skincare routine. Apply 2 drops to clean skin before moisturization.',
    ecoScore: 'A',
    size: '50 ml / 1.69 fl. oz'
  },
  {
    id: 'loreal-true-match-nude',
    name: 'True Match Nude Plumping Tinted Serum',
    brand: 'L\'Oréal Paris',
    category: 'Makeup',
    subCategory: 'Foundation & Tinted Serum',
    price: 19.99,
    originalPrice: 22.99,
    rating: 4.8,
    reviewsCount: 960,
    badge: 'Award Winner',
    image: heroPortrait.src,
    description: 'The 1st tinted serum with 1% Hyaluronic Acid. Gives skin an instantly radiant finish while plumping skin and evening complexion.',
    keyIngredients: ['1% Pure Hyaluronic Acid', 'Luminous Mineral Pigments', 'Glycerin'],
    activeBenefits: ['Plumps Skin Like Serum', 'Covers Like Lightweight Foundation', 'Natural Luminous Glow'],
    shades: [
      { id: '0.5-2-very-light', name: '0.5 - 2 Very Light', hex: '#F3E0D1', finish: 'Dewy' },
      { id: '2-3-light-medium', name: '2 - 3 Light Medium', hex: '#E8C5AF', finish: 'Dewy' },
      { id: '4-5-medium', name: '4 - 5 Medium', hex: '#D29C7C', finish: 'Dewy' },
      { id: '6-7-medium-deep', name: '6 - 7 Medium Deep', hex: '#A86C4A', finish: 'Dewy' },
      { id: '8-10-deep', name: '8 - 10 Deep', hex: '#633B27', finish: 'Dewy' }
    ],
    instructions: 'Shake well before using. Apply a few drops to face using fingertips or a sponge.',
    ecoScore: 'A',
    size: '30 ml / 1.0 fl. oz'
  },
  {
    id: 'redken-acidic-bonding',
    name: 'Acidic Bonding Concentrate Intensive Treatment',
    brand: 'Redken',
    category: 'Haircare',
    subCategory: 'Bond Repair Mask',
    price: 36.00,
    rating: 4.9,
    reviewsCount: 640,
    badge: 'New',
    image: kerastaseImg.src,
    description: 'Concentrated rinse-off bonding treatment for ultimate strength repair, 14x smoother hair, and 90% less breakage.',
    keyIngredients: ['Citric Acid', 'Bonding Care Complex (14%)', 'Alpha Hydroxy Acids'],
    activeBenefits: ['Reinforces Weakened Bonds', 'pH Balanced Care', '14x Smoother Tresses'],
    instructions: 'Apply to wet hair prior to shampooing. Leave on for 5–10 minutes and rinse thoroughly.',
    ecoScore: 'B',
    size: '150 ml / 5.1 fl. oz'
  },
  {
    id: 'biotherm-blue-therapy',
    name: 'Blue Therapy Amber Algae Revitalize Day Cream',
    brand: 'Biotherm',
    category: 'Skincare',
    subCategory: 'Anti-Aging Cream',
    price: 78.00,
    rating: 4.8,
    reviewsCount: 410,
    badge: 'Eco-Refill',
    image: laRocheImg.src,
    description: 'Revitalizing anti-aging cream enriched with Amber Algae and Life Plankton™. Infuses skin with rosy radiance and firmness.',
    keyIngredients: ['Amber Algae (Laminaria Ochroleuca)', 'Life Plankton™', 'Nutritive Oils Complex'],
    activeBenefits: ['Intense Micro-Nourishment', 'Rosy Glow Enhancement', 'Visible Firmness'],
    instructions: 'Massage gently onto clean face, neck, and décolleté every morning.',
    ecoScore: 'A',
    size: '50 ml / 1.69 fl. oz'
  }
];
