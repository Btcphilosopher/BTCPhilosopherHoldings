'use client';

import React, { useState } from 'react';
import { ArrowRight, Sparkles, Check } from 'lucide-react';
import { Product } from '@/lib/products';

interface HeroSectionProps {
  onShopBestsellers: () => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  revitaliftProduct: Product;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onShopBestsellers,
  onSelectProduct,
  onAddToCart,
  revitaliftProduct,
}) => {
  const [activeSlide, setActiveSlide] = useState(0);
  const [isAdded, setIsAdded] = useState(false);

  const heroSlides = [
    {
      title: 'Science for a more beautiful world',
      subtitle: 'Innovative beauty solutions, powered by science, for every you.',
      spotlightTitle: 'Younger looking skin, for longer',
      badge: 'REVITALIFT',
      cta: 'Shop Bestsellers',
    },
    {
      title: 'Biotechnology & High Performance',
      subtitle: 'Clinical results formulated with dermatologists and ocean biology.',
      spotlightTitle: '96-Hour Frizz Protection',
      badge: 'KÉRASTASE',
      cta: 'Explore Salon Care',
    },
    {
      title: 'Pure Hydration for Sensitive Skin',
      subtitle: 'Thermal Spring Water enriched with pure 1.5% Hyaluronic Acid.',
      spotlightTitle: 'Restores Skin Barrier',
      badge: 'LA ROCHE-POSAY',
      cta: 'Discover Dermatology',
    },
  ];

  const currentSlide = heroSlides[activeSlide];

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(revitaliftProduct);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <section className="relative w-full overflow-hidden bg-[#FAF8F5] border-b border-[#E8E3D9]">
      {/* Hero Backdrop Grid */}
      <div className="max-w-7xl mx-auto min-h-[580px] lg:min-h-[640px] relative flex flex-col justify-between p-6 sm:p-10 lg:p-12">
        
        {/* Background Image Layer with gradient scrim */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <img
            src={revitaliftProduct.image ? '/src/assets/images/hero_beauty_portrait_1790952478303.jpg' : ''}
            alt="L'Oréal Paris Beauty Model"
            className="w-full h-full object-cover object-top opacity-90 transition-opacity duration-700"
          />
          {/* Scrim for contrast */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#FAF8F5] via-[#FAF8F5]/70 to-transparent w-full md:w-3/4" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#FAF8F5] via-transparent to-transparent h-32 bottom-0" />
        </div>

        {/* Hero Content Grid */}
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center my-auto pt-6">
          
          {/* Left Column (Main Copy & CTA) */}
          <div className="lg:col-span-7 space-y-6 max-w-xl">
            <div className="inline-flex items-center gap-2">
              <span className="text-xs font-bold tracking-[0.25em] text-[#111111] uppercase border-b-2 border-[#B89768] pb-0.5">
                L&apos;ORÉAL PARIS
              </span>
            </div>

            <h1 className="font-serif-luxury text-4xl sm:text-5xl lg:text-6xl font-normal leading-[1.1] text-[#111111] tracking-tight">
              {currentSlide.title}
            </h1>

            <p className="text-sm sm:text-base text-[#444444] leading-relaxed max-w-md font-normal">
              {currentSlide.subtitle}
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onShopBestsellers}
                className="bg-[#111111] hover:bg-[#2C2C2C] text-white px-7 py-3.5 rounded-none text-xs font-semibold uppercase tracking-widest flex items-center gap-3 transition-all transform hover:-translate-y-0.5 shadow-md"
              >
                <span>{currentSlide.cta}</span>
                <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
              </button>
            </div>
          </div>

          {/* Right Column (Revitalift Bottle Spotlight Card from Screenshot) */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div
              onClick={() => onSelectProduct(revitaliftProduct)}
              className="group relative bg-[#FAF8F5]/80 backdrop-blur-md border border-[#E2DDD3] p-6 sm:p-8 rounded-2xl shadow-xl max-w-sm w-full cursor-pointer hover:border-[#B89768] transition-all duration-300"
            >
              <div className="flex flex-col h-full justify-between space-y-4">
                <div>
                  <p className="text-[10px] font-bold tracking-[0.25em] text-[#8B6E3F] uppercase mb-1">
                    {currentSlide.badge}
                  </p>
                  <h3 className="font-serif-luxury text-2xl font-normal text-[#111111] leading-snug">
                    {currentSlide.spotlightTitle}
                  </h3>
                  <div className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-[#111111] group-hover:text-[#B89768] transition-colors">
                    <span>Discover More</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>

                {/* Product Image inside Spotlight */}
                <div className="relative h-64 sm:h-72 my-2 overflow-hidden rounded-xl bg-gradient-to-b from-transparent to-[#F2EFE8]/50 flex items-center justify-center">
                  <img
                    src="/src/assets/images/revitalift_serum_bottle_1790952488522.jpg"
                    alt="Revitalift Hyaluronic Acid Serum"
                    className="h-full object-contain filter drop-shadow-lg group-hover:scale-105 transition-transform duration-500"
                  />
                  
                  {/* Subtle Floating Badge */}
                  <div className="absolute top-2 right-2 bg-[#111111] text-white text-[9px] font-bold uppercase tracking-wider px-2 py-1 rounded">
                    1.5% Pure HA
                  </div>
                </div>

                {/* Price & Quick Add */}
                <div className="pt-2 border-t border-[#EAE5DB] flex items-center justify-between">
                  <div>
                    <span className="text-xs text-[#888888] line-through mr-1.5">$38.00</span>
                    <span className="text-base font-bold text-[#111111]">$32.99</span>
                  </div>
                  <button
                    onClick={handleQuickAdd}
                    className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 ${
                      isAdded
                        ? 'bg-emerald-700 text-white'
                        : 'bg-[#B89768] hover:bg-[#A38255] text-white'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Added
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        Add to Bag
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Slide Numbers (01  02  03) */}
        <div className="relative z-10 pt-6 border-t border-[#E8E3D9]/60 flex items-center gap-6 text-xs font-semibold tracking-wider text-[#666666]">
          {[0, 1, 2].map((idx) => {
            const numStr = `0${idx + 1}`;
            const isActive = activeSlide === idx;
            return (
              <button
                key={idx}
                onClick={() => setActiveSlide(idx)}
                className={`flex items-center gap-2 py-1 focus:outline-none transition-colors ${
                  isActive ? 'text-[#111111] font-bold' : 'hover:text-[#111111]'
                }`}
              >
                <span>{numStr}</span>
                {isActive && <span className="w-8 h-0.5 bg-[#B89768]" />}
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
};
