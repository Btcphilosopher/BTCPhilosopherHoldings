'use client';

import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, Gift, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Product, ShadeOption } from '@/lib/products';

export interface CartItem {
  product: Product;
  quantity: number;
  selectedShade?: ShadeOption;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, newQty: number, shadeId?: string) => void;
  onRemoveItem: (productId: string, shadeId?: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [selectedSamples, setSelectedSamples] = useState<string[]>([]);
  const [isCheckoutSuccess, setIsCheckoutSuccess] = useState(false);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const discountAmount = (subtotal * discountPercent) / 100;
  const freeShippingThreshold = 50.0;
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
  const shippingCost = subtotal >= freeShippingThreshold || subtotal === 0 ? 0 : 5.99;
  const grandTotal = Math.max(0, subtotal - discountAmount + shippingCost);

  const sampleOptions = [
    'Revitalift 1.5% HA Serum (5ml)',
    'La Roche-Posay B5 Repair Cream (7ml)',
    'Kérastase Elixir Ultime Hair Oil (10ml)',
  ];

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'SCIENCE2026') {
      setDiscountPercent(20);
    } else {
      alert('Invalid promo code. Try "SCIENCE2026" for 20% off.');
    }
  };

  const toggleSample = (sample: string) => {
    if (selectedSamples.includes(sample)) {
      setSelectedSamples(selectedSamples.filter((s) => s !== sample));
    } else if (selectedSamples.length < 2) {
      setSelectedSamples([...selectedSamples, sample]);
    }
  };

  const handleCheckout = () => {
    setIsCheckoutSuccess(true);
    setTimeout(() => {
      onClearCart();
      setIsCheckoutSuccess(false);
      onClose();
    }, 2800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-end">
      <div className="bg-[#FAF8F5] w-full max-w-md h-full shadow-2xl flex flex-col justify-between border-l border-[#E2DDD3] transition-all">
        
        {/* Drawer Header */}
        <div className="p-6 border-b border-[#E8E3D9] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#B89768]" />
            <span className="font-serif-luxury text-xl font-bold text-[#111111]">
              Your Shopping Bag
            </span>
            <span className="bg-[#EFECE6] text-[#111111] text-xs font-bold px-2 py-0.5 rounded-full">
              {cartItems.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-black rounded-full hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Indicator */}
        <div className="bg-[#EFECE6] px-6 py-2.5 border-b border-[#E8E3D9] text-xs font-medium text-[#444444]">
          {remainingForFreeShipping > 0 ? (
            <p>
              Add <span className="font-bold text-[#111111]">${remainingForFreeShipping.toFixed(2)}</span> more for <span className="font-bold text-emerald-800">FREE Express Shipping</span>!
            </p>
          ) : (
            <p className="text-emerald-800 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              You&apos;ve unlocked Complimentary Express Shipping!
            </p>
          )}
          <div className="w-full bg-[#E2DDD3] h-1.5 rounded-full overflow-hidden mt-1.5">
            <div
              className="bg-[#B89768] h-full transition-all duration-300"
              style={{ width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%` }}
            />
          </div>
        </div>

        {/* Items Scroll List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {isCheckoutSuccess ? (
            <div className="text-center py-16 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto animate-bounce" />
              <h3 className="font-serif-luxury text-2xl font-bold text-[#111111]">
                Order #LOR-10492 Confirmed!
              </h3>
              <p className="text-xs text-[#666666]">
                Thank you for choosing L&apos;Oréal Paris. Your items are being prepared at our beauty fulfillment lab.
              </p>
            </div>
          ) : cartItems.length > 0 ? (
            <>
              {cartItems.map((item, idx) => (
                <div
                  key={`${item.product.id}-${item.selectedShade?.id || idx}`}
                  className="bg-white p-4 rounded-2xl border border-[#E8E3D9] flex items-center gap-4 shadow-sm"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-contain rounded-xl bg-[#FAF8F5] p-1 border border-[#EEE8DE]"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-bold text-[#8B6E3F] uppercase">
                      {item.product.brand}
                    </p>
                    <h4 className="text-xs font-bold text-[#111111] truncate">
                      {item.product.name}
                    </h4>
                    {item.selectedShade && (
                      <p className="text-[10px] text-[#666666] flex items-center gap-1 mt-0.5">
                        <span
                          className="w-2.5 h-2.5 rounded-full inline-block border"
                          style={{ backgroundColor: item.selectedShade.hex }}
                        />
                        Shade: {item.selectedShade.name}
                      </p>
                    )}
                    <p className="text-xs font-bold text-[#111111] mt-1">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </p>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex flex-col items-end gap-2">
                    <button
                      onClick={() => onRemoveItem(item.product.id, item.selectedShade?.id)}
                      className="text-gray-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <div className="flex items-center gap-1.5 bg-[#FAF8F5] border border-[#E2DDD3] rounded-lg px-2 py-0.5">
                      <button
                        onClick={() =>
                          onUpdateQuantity(
                            item.product.id,
                            item.quantity - 1,
                            item.selectedShade?.id
                          )
                        }
                        className="text-[#666666] hover:text-black"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold text-[#111111] min-w-[14px] text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() =>
                          onUpdateQuantity(
                            item.product.id,
                            item.quantity + 1,
                            item.selectedShade?.id
                          )
                        }
                        className="text-[#666666] hover:text-black"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {/* Complimentary Samples Picker */}
              <div className="bg-white p-4 rounded-2xl border border-[#E8E3D9] space-y-2">
                <div className="flex items-center gap-1.5">
                  <Gift className="w-4 h-4 text-[#B89768]" />
                  <span className="text-xs font-bold uppercase tracking-wider text-[#111111]">
                    Select 2 Deluxe Samples
                  </span>
                </div>
                <div className="space-y-1.5">
                  {sampleOptions.map((sample) => {
                    const isSelected = selectedSamples.includes(sample);
                    return (
                      <button
                        key={sample}
                        onClick={() => toggleSample(sample)}
                        className={`w-full text-left p-2 rounded-xl text-xs font-medium border transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#EFECE6] border-[#B89768] text-[#111111] font-bold'
                            : 'bg-white border-[#E8E3D9] text-[#666666] hover:border-[#B89768]'
                        }`}
                      >
                        <span>{sample}</span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-[#B89768]" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-20 text-[#888888] space-y-2">
              <ShoppingBag className="w-10 h-10 mx-auto text-[#CCC8BD]" />
              <p className="text-sm font-semibold text-[#111111]">Your bag is currently empty.</p>
              <p className="text-xs">Explore our best sellers or take the AI Skin Quiz!</p>
            </div>
          )}
        </div>

        {/* Drawer Footer & Checkout */}
        {!isCheckoutSuccess && cartItems.length > 0 && (
          <div className="p-6 border-t border-[#E8E3D9] bg-white space-y-3">
            {/* Promo Code Input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Promo Code (e.g. SCIENCE2026)"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                className="flex-1 bg-[#FAF8F5] border border-[#E2DDD3] px-3 py-2 rounded-xl text-xs font-medium focus:outline-none"
              />
              <button
                onClick={handleApplyPromo}
                className="bg-[#111111] text-white px-3.5 py-2 rounded-xl text-xs font-bold uppercase"
              >
                Apply
              </button>
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-1 text-xs text-[#555555]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-bold text-[#111111]">${subtotal.toFixed(2)}</span>
              </div>
              {discountPercent > 0 && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Discount ({discountPercent}%)</span>
                  <span>-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Estimated Shipping</span>
                <span>{shippingCost === 0 ? 'FREE' : `$${shippingCost.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-[#111111] pt-1 border-t border-[#EEE8DE]">
                <span>Total</span>
                <span>${grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              className="w-full bg-[#111111] hover:bg-[#2C2C2C] text-white py-3.5 rounded-full text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <span>Proceed to Express Checkout</span>
              <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
