'use client';

import React from 'react';
import { ArrowUpRight, Sparkles } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#111111] text-white pt-16 pb-12 border-t border-[#222222]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Top Newsletter & Brand Statement */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pb-12 border-b border-[#222222]">
          <div className="lg:col-span-7 space-y-2">
            <span className="font-serif-luxury text-3xl sm:text-4xl font-bold tracking-widest text-white uppercase block">
              L&apos;ORÉAL PARIS
            </span>
            <p className="text-xs text-gray-400 font-medium">
              BECAUSE YOU&apos;RE WORTH IT · SCIENCE FOR A MORE BEAUTIFUL WORLD
            </p>
          </div>

          <div className="lg:col-span-5 space-y-2">
            <p className="text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
              Join the L&apos;Oréal Beauty Club
            </p>
            <div className="flex items-center gap-2">
              <input
                type="email"
                placeholder="Enter your email address"
                className="bg-[#1A1A1A] border border-[#333333] px-4 py-2.5 rounded-full text-xs text-white placeholder-gray-500 focus:outline-none flex-1"
              />
              <button className="bg-[#D4AF37] hover:bg-[#B89768] text-black px-5 py-2.5 rounded-full text-xs font-bold uppercase transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Footer Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-xs text-gray-400">
          <div className="space-y-3">
            <p className="font-bold text-white uppercase tracking-wider">House of Brands</p>
            <ul className="space-y-2">
              <li><a href="#brands" className="hover:text-white transition-colors">L&apos;Oréal Paris</a></li>
              <li><a href="#brands" className="hover:text-white transition-colors">Kérastase</a></li>
              <li><a href="#brands" className="hover:text-white transition-colors">La Roche-Posay</a></li>
              <li><a href="#brands" className="hover:text-white transition-colors">Maybelline New York</a></li>
              <li><a href="#brands" className="hover:text-white transition-colors">Vichy Laboratories</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <p className="font-bold text-white uppercase tracking-wider">Beauty Tech & AI</p>
            <ul className="space-y-2">
              <li><a href="#bestsellers" className="hover:text-white transition-colors">AI Skin Diagnostics</a></li>
              <li><a href="#bestsellers" className="hover:text-white transition-colors">Virtual Shade Finder</a></li>
              <li><a href="#bestsellers" className="hover:text-white transition-colors">Ingredient Transparency</a></li>
              <li><a href="#sustainability" className="hover:text-white transition-colors">Eco-Refill Calculator</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <p className="font-bold text-white uppercase tracking-wider">Client Care</p>
            <ul className="space-y-2">
              <li><span className="hover:text-white cursor-pointer">Order Status</span></li>
              <li><span className="hover:text-white cursor-pointer">Complimentary Shipping</span></li>
              <li><span className="hover:text-white cursor-pointer">Returns & Exchanges</span></li>
              <li><span className="hover:text-white cursor-pointer">Store Locator</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <p className="font-bold text-white uppercase tracking-wider">L&apos;Oréal Group</p>
            <ul className="space-y-2">
              <li><span className="hover:text-white cursor-pointer">Research & Innovation</span></li>
              <li><span className="hover:text-white cursor-pointer">Careers</span></li>
              <li><span className="hover:text-white cursor-pointer">L&apos;Oréal for the Future</span></li>
              <li><span className="hover:text-white cursor-pointer">Ethics & Compliance</span></li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal Copyright */}
        <div className="pt-8 border-t border-[#222222] flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-500 gap-4">
          <p>© {new Date().getFullYear()} L&apos;Oréal Paris. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-gray-300 cursor-pointer">Privacy Policy</span>
            <span>·</span>
            <span className="hover:text-gray-300 cursor-pointer">Terms of Service</span>
            <span>·</span>
            <span className="hover:text-gray-300 cursor-pointer">Cookie Preferences</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
