'use client';

import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { HOUSE_BRANDS, BrandInfo } from '@/lib/brands';

interface BrandsSectionProps {
  onSelectBrand: (brandName: string) => void;
  selectedBrand: string | null;
}

export const BrandsSection: React.FC<BrandsSectionProps> = ({
  onSelectBrand,
  selectedBrand,
}) => {
  return (
    <section id="brands" className="py-16 sm:py-20 bg-[#FAF8F5] border-b border-[#E8E3D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header matching screenshot */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <p className="text-[10px] font-bold tracking-[0.25em] text-[#8B6E3F] uppercase mb-2">
              EXPLORE OUR BRANDS
            </p>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#111111] font-normal tracking-tight">
              Iconic brands. Endless possibilities.
            </h2>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => onSelectBrand('')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#111111] hover:text-[#B89768] transition-colors"
            >
              <span>View All Brands</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Brands Horizontal Card Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {HOUSE_BRANDS.map((brand: BrandInfo) => {
            const isSelected = selectedBrand === brand.name;
            return (
              <div
                key={brand.id}
                onClick={() => onSelectBrand(brand.name)}
                className={`group relative h-64 sm:h-72 rounded-2xl overflow-hidden cursor-pointer shadow-md transition-all duration-300 border ${
                  isSelected
                    ? 'ring-2 ring-[#B89768] border-transparent scale-[1.02]'
                    : 'border-[#E2DDD3] hover:border-[#B89768] hover:shadow-xl'
                }`}
              >
                {/* Background Image */}
                <img
                  src={brand.image}
                  alt={brand.name}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />

                {/* Dark Gradient Overlay Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent transition-opacity duration-300 group-hover:from-black/90" />

                {/* Card Content */}
                <div className="absolute inset-0 p-5 flex flex-col justify-between text-white z-10">
                  <div className="flex justify-between items-start">
                    <span
                      className="text-[9px] font-bold tracking-widest px-2.5 py-1 rounded bg-white/20 backdrop-blur-md uppercase"
                    >
                      {brand.categories[0]}
                    </span>
                    <ArrowUpRight className="w-4 h-4 text-white/70 group-hover:text-white group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </div>

                  <div>
                    <h3 className="font-serif-luxury text-2xl font-bold tracking-wider uppercase mb-1 drop-shadow-sm">
                      {brand.name}
                    </h3>
                    
                    {/* Categories separator metadata */}
                    <div className="flex items-center gap-1.5 text-[11px] font-medium text-white/80">
                      <span>{brand.categories.join(' · ')}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
