'use client';

import React, { useState, useRef, useEffect } from 'react';
import { X, Sparkles, Camera, ShieldCheck, ArrowRight, CheckCircle2, Loader2, RefreshCw } from 'lucide-react';
import { Product } from '@/lib/products';

interface AISkinAnalyzerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMultipleToCart: (products: Product[]) => void;
  allProducts: Product[];
}

export const AISkinAnalyzerModal: React.FC<AISkinAnalyzerModalProps> = ({
  isOpen,
  onClose,
  onAddMultipleToCart,
  allProducts,
}) => {
  const [step, setStep] = useState<'questionnaire' | 'scanning' | 'results'>('questionnaire');
  const [skinType, setSkinType] = useState('Combination');
  const [selectedConcerns, setSelectedConcerns] = useState<string[]>(['Fine Lines', 'Hydration Loss']);
  const [ageGroup, setAgeGroup] = useState('25-34');
  const [sensitivity, setSensitivity] = useState('Moderate');
  const [isLoading, setIsLoading] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [report, setReport] = useState<any>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const concernsList = [
    'Fine Lines & Wrinkles',
    'Hydration Loss',
    'Uneven Tone & Spots',
    'Barrier Redness',
    'Dullness',
    'Loss of Firmness',
    'Blemishes & Pores',
  ];

  const toggleConcern = (concern: string) => {
    if (selectedConcerns.includes(concern)) {
      setSelectedConcerns(selectedConcerns.filter((c) => c !== concern));
    } else {
      setSelectedConcerns([...selectedConcerns, concern]);
    }
  };

  // Facial Scanner Mesh Simulation Effect
  useEffect(() => {
    if (step === 'scanning') {
      let interval = setInterval(() => {
        setScanProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 5;
        });
      }, 100);

      return () => clearInterval(interval);
    }
  }, [step]);

  // Render animated scanner canvas grid
  useEffect(() => {
    if (step === 'scanning' && canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let animationFrameId: number;
      let angle = 0;

      const render = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Face outline guide
        ctx.strokeStyle = '#D4AF37';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);

        ctx.beginPath();
        ctx.ellipse(
          canvas.width / 2,
          canvas.height / 2,
          canvas.width * 0.3,
          canvas.height * 0.4,
          0,
          0,
          2 * Math.PI
        );
        ctx.stroke();

        // Scanning laser line
        ctx.setLineDash([]);
        ctx.strokeStyle = '#B89768';
        ctx.lineWidth = 2;
        const scanY = (canvas.height / 2) + Math.sin(angle) * (canvas.height * 0.35);

        ctx.beginPath();
        ctx.moveTo(canvas.width * 0.15, scanY);
        ctx.lineTo(canvas.width * 0.85, scanY);
        ctx.stroke();

        angle += 0.05;
        animationFrameId = requestAnimationFrame(render);
      };

      render();

      return () => cancelAnimationFrame(animationFrameId);
    }
  }, [step]);

  const handleStartAnalysis = async () => {
    setStep('scanning');
    setScanProgress(0);
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/skin-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          skinType,
          concerns: selectedConcerns,
          ageGroup,
          sensitivity,
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to run AI skin diagnostic');
      }

      const data = await res.json();
      setReport(data);

      // Wait for scanning progress bar to finish
      setTimeout(() => {
        setIsLoading(false);
        setStep('results');
      }, 2200);
    } catch (err) {
      console.error(err);
      setIsLoading(false);
      setStep('questionnaire');
      alert('Diagnostic analysis error. Please try again.');
    }
  };

  const handleAddRegimenToCart = () => {
    // Match products or add defaults
    const revitalift = allProducts.find((p) => p.id === 'loreal-revitalift-serum');
    const laRoche = allProducts.find((p) => p.id === 'laroche-hyalu-b5');
    const vichy = allProducts.find((p) => p.id === 'vichy-mineral-89');

    const matched = [revitalift, laRoche, vichy].filter(Boolean) as Product[];
    onAddMultipleToCart(matched);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-md flex items-center justify-center p-4 sm:p-6">
      <div className="bg-[#FAF8F5] border border-[#E2DDD3] rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl relative transition-all">
        
        {/* Modal Top Bar */}
        <div className="px-6 py-4 border-b border-[#E8E3D9] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#B89768]" />
            <span className="font-serif-luxury text-xl font-bold text-[#111111]">
              L&apos;Oréal AI Skin Diagnostic Lab
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-black rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step 1: Questionnaire */}
        {step === 'questionnaire' && (
          <div className="p-6 sm:p-8 space-y-6 max-h-[80vh] overflow-y-auto">
            <div>
              <p className="text-[10px] font-bold tracking-[0.2em] text-[#8B6E3F] uppercase mb-1">
                STEP 01 OF 02
              </p>
              <h3 className="font-serif-luxury text-2xl text-[#111111] font-bold">
                Configure Your Skin Profile
              </h3>
              <p className="text-xs text-[#666666]">
                Powered by L&apos;Oréal Dermatological AI to analyze multi-layer epidermal needs.
              </p>
            </div>

            {/* Skin Type Selection */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#111111] block mb-2">
                Primary Skin Type
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['Dry', 'Oily', 'Combination', 'Sensitive'].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setSkinType(type)}
                    className={`py-2.5 px-3 text-xs font-semibold rounded-xl border transition-all ${
                      skinType === type
                        ? 'bg-[#111111] text-white border-[#111111] shadow-sm'
                        : 'bg-white text-[#444444] border-[#E2DDD3] hover:border-[#B89768]'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Primary Concerns Selection */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#111111] block mb-2">
                Skin Concerns (Select up to 3)
              </label>
              <div className="flex flex-wrap gap-2">
                {concernsList.map((concern) => {
                  const isSelected = selectedConcerns.includes(concern);
                  return (
                    <button
                      key={concern}
                      type="button"
                      onClick={() => toggleConcern(concern)}
                      className={`py-2 px-3 text-xs font-medium rounded-full border transition-all ${
                        isSelected
                          ? 'bg-[#B89768] text-white border-[#B89768]'
                          : 'bg-white text-[#555555] border-[#E2DDD3] hover:border-[#B89768]'
                      }`}
                    >
                      {concern}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Age Group */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#111111] block mb-2">
                Age Group
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                {['18-24', '25-34', '35-44', '45-54', '55+'].map((age) => (
                  <button
                    key={age}
                    type="button"
                    onClick={() => setAgeGroup(age)}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border text-center transition-all ${
                      ageGroup === age
                        ? 'bg-[#111111] text-white border-[#111111]'
                        : 'bg-white text-[#444444] border-[#E2DDD3]'
                    }`}
                  >
                    {age}
                  </button>
                ))}
              </div>
            </div>

            {/* CTA Button */}
            <div className="pt-4 border-t border-[#E8E3D9] flex justify-end">
              <button
                onClick={handleStartAnalysis}
                className="bg-[#111111] hover:bg-[#2C2C2C] text-white px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-md"
              >
                <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                <span>Run AI Diagnostic Scan</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Scanning Simulation */}
        {step === 'scanning' && (
          <div className="p-8 text-center space-y-6">
            <div className="relative w-64 h-64 mx-auto rounded-3xl overflow-hidden bg-black flex items-center justify-center border-2 border-[#D4AF37]">
              <canvas ref={canvasRef} width={256} height={256} className="absolute inset-0 z-10" />
              <div className="text-white z-20 space-y-2 p-4">
                <Camera className="w-8 h-8 text-[#D4AF37] mx-auto animate-pulse" />
                <p className="text-xs font-mono text-[#D4AF37] uppercase tracking-widest">
                  Scanning Epidermal Layers...
                </p>
                <p className="text-2xl font-bold font-mono text-white">{scanProgress}%</p>
              </div>
            </div>

            <div className="max-w-md mx-auto space-y-2">
              <p className="text-sm font-semibold text-[#111111]">
                Analyzing skin barrier parameters & active ingredient compatibility...
              </p>
              <div className="w-full bg-[#E2DDD3] h-2 rounded-full overflow-hidden">
                <div
                  className="bg-[#B89768] h-full transition-all duration-200"
                  style={{ width: `${scanProgress}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Diagnostic Results */}
        {step === 'results' && report && (
          <div className="p-6 sm:p-8 space-y-6 max-h-[80vh] overflow-y-auto">
            
            {/* Header Score Cards */}
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-white p-3.5 rounded-2xl border border-[#E8E3D9] shadow-sm">
                <p className="text-[10px] font-bold text-[#8B6E3F] uppercase">Barrier Health</p>
                <p className="text-2xl font-bold text-[#111111] font-mono mt-1">
                  {report.barrierHealthScore}/100
                </p>
              </div>
              <div className="bg-white p-3.5 rounded-2xl border border-[#E8E3D9] shadow-sm">
                <p className="text-[10px] font-bold text-[#8B6E3F] uppercase">Hydration Index</p>
                <p className="text-2xl font-bold text-[#111111] font-mono mt-1">
                  {report.hydrationIndex}
                </p>
              </div>
              <div className="bg-white p-3.5 rounded-2xl border border-[#E8E3D9] shadow-sm">
                <p className="text-[10px] font-bold text-[#8B6E3F] uppercase">Sensitivity</p>
                <p className="text-sm font-bold text-[#111111] mt-2">
                  {report.sensitivityRisk}
                </p>
              </div>
            </div>

            {/* Diagnostic Summary */}
            <div className="bg-white p-4 rounded-2xl border border-[#E8E3D9] space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-[#111111] flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Dermatological Analysis
              </p>
              <p className="text-xs text-[#444444] leading-relaxed">
                {report.diagnosticSummary}
              </p>
            </div>

            {/* Recommended Active Ingredients */}
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#111111] mb-2">
                Priority Active Ingredients
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {report.activeIngredients?.map((ing: any, i: number) => (
                  <div key={i} className="bg-[#EFECE6] p-3 rounded-xl">
                    <p className="text-xs font-bold text-[#111111]">{ing.name}</p>
                    <p className="text-[11px] text-[#666666] mt-0.5">{ing.purpose}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Regimen Steps */}
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#111111] mb-3">
                Custom L&apos;Oréal AM/PM Regimen
              </p>
              <div className="space-y-2">
                {report.amRoutine?.map((item: any, i: number) => (
                  <div
                    key={i}
                    className="bg-white p-3 rounded-xl border border-[#E8E3D9] flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="bg-[#B89768] text-white text-[10px] font-bold px-2 py-0.5 rounded">
                        AM {item.step}
                      </span>
                      <div>
                        <span className="font-bold text-[#111111]">{item.recommendedProduct}</span>
                        <p className="text-[11px] text-[#666666]">{item.action}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* L'Oreal Science Insight */}
            <div className="bg-[#F3EFE8] p-4 rounded-2xl border border-[#E2DDD3] text-xs text-[#444444] italic">
              &quot;{report.lorealScienceInsight}&quot;
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-[#E8E3D9] flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                onClick={() => setStep('questionnaire')}
                className="text-xs font-semibold text-[#666666] hover:text-[#111111] flex items-center gap-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retake Diagnostic Quiz
              </button>

              <button
                onClick={handleAddRegimenToCart}
                className="w-full sm:w-auto bg-[#111111] hover:bg-[#2C2C2C] text-white px-6 py-3 rounded-full text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                <span>Add Full Custom Regimen to Bag</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
