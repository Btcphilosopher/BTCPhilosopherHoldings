'use client';

import React, { useState } from 'react';
import { Search, ShoppingBag, Heart, Sparkles, SlidersHorizontal, X } from 'lucide-react';
import { Product } from '@/lib/products';

interface NavbarProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenSkinAnalyzer: () => void;
  onOpenVirtualTryOn: () => void;
  onSelectBrand: (brandName: string | null) => void;
  selectedBrand: string | null;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenSkinAnalyzer,
  onOpenVirtualTryOn,
  onSelectBrand,
  selectedBrand,
  products,
  onSelectProduct,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const searchResults = searchQuery.trim()
    ? products.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.keyIngredients.some((ing) => ing.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  return (
    <>
      {/* Top Banner */}
      <div className="bg-[#111111] text-white text-xs py-2 px-4 text-center font-medium tracking-wide flex items-center justify-center gap-3">
        <span>Complimentary Express Shipping & 2 Deluxe Samples on all orders over $50</span>
        <span className="hidden md:inline-block text-[#D4AF37] font-semibold">· Code: SCIENCE2026</span>
      </div>

      {/* Main Header conforming to Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#E8E3D9] transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Zone 1: Brand Wordmark (Single text/logo element) */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => onSelectBrand(null)}
              className="text-left group flex flex-col focus:outline-none"
            >
              <span className="font-serif-luxury text-2xl sm:text-3xl font-bold tracking-widest text-[#111111] group-hover:text-[#B89768] transition-colors uppercase">
                L&apos;ORÉAL
              </span>
              <span className="text-[9px] tracking-[0.3em] font-medium text-[#666666] -mt-1 uppercase">
                PARIS
              </span>
            </button>

            {selectedBrand && (
              <div className="hidden lg:flex items-center gap-2 bg-[#EFECE6] px-3 py-1 rounded-full text-xs font-medium text-[#111111]">
                <span>Brand: {selectedBrand}</span>
                <button
                  onClick={() => onSelectBrand(null)}
                  className="hover:text-[#B89768] ml-1"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          {/* Zone 2: 4-6 Clean Nav Links */}
          <nav className="hidden lg:flex items-center gap-8 text-xs font-semibold uppercase tracking-wider text-[#333333]">
            <a
              href="#bestsellers"
              onClick={() => onSelectBrand(null)}
              className="hover:text-[#B89768] transition-colors py-1 relative group"
            >
              Shop
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#B89768] group-hover:w-full transition-all duration-300" />
            </a>
            <a
              href="#brands"
              className="hover:text-[#B89768] transition-colors py-1 relative group"
            >
              Brands
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#B89768] group-hover:w-full transition-all duration-300" />
            </a>
            <button
              onClick={onOpenSkinAnalyzer}
              className="hover:text-[#B89768] transition-colors py-1 relative group flex items-center gap-1.5 text-[#8B6E3F]"
            >
              <Sparkles className="w-3.5 h-3.5" />
              AI Skin Analysis
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#B89768] group-hover:w-full transition-all duration-300" />
            </button>
            <button
              onClick={onOpenVirtualTryOn}
              className="hover:text-[#B89768] transition-colors py-1 relative group flex items-center gap-1.5"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Shade Finder
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#B89768] group-hover:w-full transition-all duration-300" />
            </button>
            <a
              href="#sustainability"
              className="hover:text-[#B89768] transition-colors py-1 relative group"
            >
              Sustainability
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#B89768] group-hover:w-full transition-all duration-300" />
            </a>
          </nav>

          {/* Zone 3: Interactive Actions & Search */}
          <div className="flex items-center gap-3 sm:gap-5">
            {/* Search Input Bar */}
            <div className="relative">
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="flex items-center gap-2 bg-[#EFECE6] hover:bg-[#E5E0D5] text-[#444444] px-3.5 py-2 rounded-full text-xs font-medium transition-colors"
                aria-label="Search products"
              >
                <Search className="w-4 h-4 text-[#666666]" />
                <span className="hidden sm:inline-block">Search products, brands...</span>
              </button>

              {/* Instant Auto-Suggest Dropdown */}
              {isSearchOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white border border-[#E2DDD3] shadow-2xl rounded-2xl p-4 z-50">
                  <div className="flex items-center gap-2 border-b border-[#EEE8DE] pb-2 mb-3">
                    <Search className="w-4 h-4 text-[#888888]" />
                    <input
                      type="text"
                      autoFocus
                      placeholder="Search Hyaluronic Acid, Serum, Lipstick..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full text-xs font-medium focus:outline-none bg-transparent"
                    />
                    {searchQuery && (
                      <button onClick={() => setSearchQuery('')} className="text-gray-400 hover:text-black">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {searchResults.length > 0 ? (
                    <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                      {searchResults.map((product) => (
                        <div
                          key={product.id}
                          onClick={() => {
                            onSelectProduct(product);
                            setIsSearchOpen(false);
                          }}
                          className="flex items-center gap-3 p-2 hover:bg-[#FAF7F2] rounded-xl cursor-pointer transition-colors"
                        >
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-10 h-10 object-cover rounded-lg border border-[#EAE5DB]"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-[10px] font-bold text-[#B89768] uppercase tracking-wider">
                              {product.brand}
                            </p>
                            <p className="text-xs font-semibold text-[#111111] truncate">{product.name}</p>
                            <p className="text-[11px] font-medium text-[#666666]">${product.price.toFixed(2)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : searchQuery ? (
                    <p className="text-xs text-center text-[#888888] py-4">No matching beauty formulas found.</p>
                  ) : (
                    <div className="text-[11px] text-[#666666]">
                      <p className="font-semibold text-[#111111] mb-2">Trending Searches:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {['Revitalift Hyaluronic', 'Kérastase Elixir', 'La Roche-Posay B5', 'Maybelline SuperStay'].map(
                          (term) => (
                            <button
                              key={term}
                              onClick={() => setSearchQuery(term)}
                              className="bg-[#F3EFEA] hover:bg-[#E8E2D8] px-2.5 py-1 rounded-md text-[10px] font-medium transition-colors"
                            >
                              {term}
                            </button>
                          )
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Wishlist Button */}
            <button
              className="relative p-2 text-[#222222] hover:text-[#B89768] transition-colors"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 bg-[#B89768] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Cart Drawer Trigger */}
            <button
              onClick={onOpenCart}
              className="relative bg-[#111111] hover:bg-[#2A2A2A] text-white p-2.5 sm:px-4 sm:py-2.5 rounded-full flex items-center gap-2 transition-colors shadow-sm"
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline-block text-xs font-bold uppercase tracking-wider">
                Bag
              </span>
              <span className="bg-[#B89768] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                {cartCount}
              </span>
            </button>
          </div>
        </div>
      </header>
    </>
  );
};
