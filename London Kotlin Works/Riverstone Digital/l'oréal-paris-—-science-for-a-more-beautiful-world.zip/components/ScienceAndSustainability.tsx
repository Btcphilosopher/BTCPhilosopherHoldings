'use client';

import React, { useState } from 'react';
import { Microscope, Leaf, RefreshCw, Award, CheckCircle } from 'lucide-react';

export const ScienceAndSustainability: React.FC = () => {
  const [refillCount, setRefillCount] = useState(3);

  // Carbon and plastic savings calculation
  const plasticSavedGrams = refillCount * 85; // 85g plastic per bottle
  const co2SavedKg = (refillCount * 0.42).toFixed(1);

  return (
    <section id="sustainability" className="py-20 bg-[#FAF8F5] border-b border-[#E8E3D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Section 1: Science for a More Beautiful World */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2">
              <Microscope className="w-4 h-4 text-[#8B6E3F]" />
              <span className="text-[10px] font-bold tracking-[0.25em] text-[#8B6E3F] uppercase">
                L&apos;ORÉAL RESEARCH & INNOVATION
              </span>
            </div>

            <h2 className="font-serif-luxury text-3xl sm:text-5xl font-normal text-[#111111] leading-tight">
              Science for a more beautiful world.
            </h2>

            <p className="text-sm text-[#444444] leading-relaxed">
              For over 115 years, L&apos;Oréal has pushed the boundaries of dermatological science, green chemistry, and hair biotechnology. With over 4,000 scientists across 21 research centers worldwide, every formula is validated by independent dermatologists.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="bg-white p-4 rounded-2xl border border-[#E8E3D9] shadow-sm">
                <span className="text-2xl font-bold font-mono text-[#111111]">1.5%</span>
                <p className="text-xs font-bold text-[#8B6E3F] uppercase mt-1">Pure Hyaluronic Acid</p>
                <p className="text-[11px] text-[#666666] mt-0.5">Dual molecular weight for deep multi-depth epidermal plumping.</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-[#E8E3D9] shadow-sm">
                <span className="text-2xl font-bold font-mono text-[#111111]">90k+</span>
                <p className="text-xs font-bold text-[#8B6E3F] uppercase mt-1">Partner Dermatologists</p>
                <p className="text-[11px] text-[#666666] mt-0.5">Rigorous clinical validation across sensitive skin profiles.</p>
              </div>
            </div>
          </div>

          {/* Science Illustration / Interactive Molecular Depth Diagram */}
          <div className="lg:col-span-6 bg-white p-8 rounded-3xl border border-[#E8E3D9] shadow-lg space-y-6">
            <div className="border-b border-[#E8E3D9] pb-4">
              <h3 className="font-serif-luxury text-2xl font-bold text-[#111111]">
                Epidermal Depth Penetration Matrix
              </h3>
              <p className="text-xs text-[#666666]">
                How dual-weight Hyaluronic Acid targets skin layers.
              </p>
            </div>

            <div className="space-y-4">
              {/* Layer 1: Macro HA */}
              <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E2DDD3]">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-[#111111]">Macro Hyaluronic Acid (0.5%)</span>
                  <span className="text-[10px] font-mono text-[#8B6E3F]">Surface Layer (Stratum Corneum)</span>
                </div>
                <div className="w-full bg-[#E8E3D9] h-2 rounded-full overflow-hidden my-2">
                  <div className="bg-[#B89768] h-full w-[100%]" />
                </div>
                <p className="text-[11px] text-[#555555]">
                  Locks in surface moisture, creates an invisible barrier against hydration loss, and instantly smoothes fine lines.
                </p>
              </div>

              {/* Layer 2: Micro HA */}
              <div className="bg-[#FAF8F5] p-4 rounded-2xl border border-[#E2DDD3]">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-[#111111]">Micro Hyaluronic Acid (1.0%)</span>
                  <span className="text-[10px] font-mono text-[#8B6E3F]">Deep Epidermis</span>
                </div>
                <div className="w-full bg-[#E8E3D9] h-2 rounded-full overflow-hidden my-2">
                  <div className="bg-[#111111] h-full w-[85%]" />
                </div>
                <p className="text-[11px] text-[#555555]">
                  Penetrates deeper into epidermal layers to restore volume from within and stimulate natural moisture retention.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Section 2: Sustainability & Refill Calculator */}
        <div className="bg-gradient-to-br from-[#111111] via-[#1A1A1A] to-[#252525] text-white rounded-3xl p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 text-[#D4AF37]">
                <Leaf className="w-4 h-4" />
                <span className="text-[10px] font-bold tracking-[0.25em] uppercase">
                  L&apos;ORÉAL FOR THE FUTURE
                </span>
              </div>

              <h2 className="font-serif-luxury text-3xl sm:text-4xl font-normal leading-tight">
                Sustainable Luxury & Eco-Refill Commitment
              </h2>

              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed max-w-xl">
                By 2030, 100% of L&apos;Oréal glass and plastic packaging will be recycled or bio-sourced. Our refillable serum and cream vessels reduce virgin plastic consumption by up to 78%.
              </p>

              {/* Interactive Refill Calculator */}
              <div className="pt-4 space-y-3">
                <label className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] block">
                  Simulate Your Annual Refill Impact
                </label>
                <div className="flex items-center gap-4">
                  <span className="text-xs font-medium text-gray-300">Annual Refills:</span>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={refillCount}
                    onChange={(e) => setRefillCount(Number(e.target.value))}
                    className="w-48 accent-[#D4AF37] cursor-pointer"
                  />
                  <span className="text-lg font-bold font-mono text-[#D4AF37]">{refillCount} refills/yr</span>
                </div>
              </div>
            </div>

            {/* Impact Metric Cards */}
            <div className="lg:col-span-5 grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/15">
                <p className="text-[10px] font-bold text-[#D4AF37] uppercase">Plastic Saved</p>
                <p className="text-3xl font-bold font-mono text-white mt-1">{plasticSavedGrams}g</p>
                <p className="text-[10px] text-gray-300 mt-1">Equivalent to ~17 single-use bottles.</p>
              </div>

              <div className="bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/15">
                <p className="text-[10px] font-bold text-[#D4AF37] uppercase">CO₂ Footprint</p>
                <p className="text-3xl font-bold font-mono text-white mt-1">-{co2SavedKg}kg</p>
                <p className="text-[10px] text-gray-300 mt-1">Avoided transport emissions.</p>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
