'use client';

import React, { useState } from 'react';
import { X, Star, Sparkles, Check, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import { Product, ShadeOption } from '@/lib/products';

interface ProductQuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, shade?: ShadeOption) => void;
}

export const ProductQuickViewModal: React.FC<ProductQuickViewModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  const [selectedShade, setSelectedShade] = useState<ShadeOption | undefined>(
    product?.shades?.[0]
  );
  const [isAdded, setIsAdded] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, selectedShade);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-4 sm:p-6">
      <div className="bg-[#FAF8F5] border border-[#E2DDD3] rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl relative flex flex-col md:flex-row max-h-[90vh]">
        
        {/* Left: Image Banner */}
        <div className="w-full md:w-1/2 bg-white p-8 flex items-center justify-center relative border-b md:border-b-0 md:border-r border-[#E8E3D9]">
          {product.badge && (
            <span className="absolute top-4 left-4 bg-[#111111] text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full z-10">
              {product.badge}
            </span>
          )}
          <img
            src={product.image}
            alt={product.name}
            className="h-72 max-w-full object-contain filter drop-shadow-lg"
          />
        </div>

        {/* Right: Info & Controls */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 overflow-y-auto space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold tracking-[0.2em] text-[#8B6E3F] uppercase">
                {product.brand} · {product.category}
              </span>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-black rounded-full hover:bg-gray-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <h2 className="font-serif-luxury text-2xl font-bold text-[#111111] leading-snug">
              {product.name}
            </h2>

            <div className="flex items-center gap-2 text-xs">
              <div className="flex items-center text-[#D4AF37]">
                <Star className="w-4 h-4 fill-current" />
              </div>
              <span className="font-bold text-[#111111]">{product.rating}</span>
              <span className="text-[#888888]">({product.reviewsCount} reviews)</span>
              <span className="text-[#888888]">· {product.size}</span>
            </div>

            <p className="text-xs text-[#444444] leading-relaxed">{product.description}</p>

            {/* Key Ingredients */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#111111]">
                Key Active Ingredients
              </span>
              <div className="flex flex-wrap gap-1.5">
                {product.keyIngredients.map((ing, i) => (
                  <span
                    key={i}
                    className="bg-[#EFECE6] text-[#444444] text-[10px] font-semibold px-2.5 py-1 rounded-md"
                  >
                    {ing}
                  </span>
                ))}
              </div>
            </div>

            {/* Shades if applicable */}
            {product.shades && product.shades.length > 0 && (
              <div className="space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#111111] block">
                  Selected Shade: {selectedShade?.name || product.shades[0].name}
                </span>
                <div className="flex items-center gap-2">
                  {product.shades.map((shade) => (
                    <button
                      key={shade.id}
                      onClick={() => setSelectedShade(shade)}
                      className={`w-7 h-7 rounded-full border-2 transition-all shadow-inner ${
                        selectedShade?.id === shade.id
                          ? 'border-[#111111] scale-110 ring-2 ring-[#B89768]'
                          : 'border-white hover:scale-105'
                      }`}
                      style={{ backgroundColor: shade.hex }}
                      title={shade.name}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Pricing & Add to Cart */}
          <div className="pt-4 border-t border-[#E8E3D9] space-y-3">
            <div className="flex items-baseline justify-between">
              <div>
                {product.originalPrice && (
                  <span className="text-xs text-[#999999] line-through mr-2">
                    ${product.originalPrice.toFixed(2)}
                  </span>
                )}
                <span className="text-2xl font-bold text-[#111111]">
                  ${product.price.toFixed(2)}
                </span>
              </div>
              <span className="text-[11px] font-semibold text-emerald-700 flex items-center gap-1">
                <Truck className="w-3.5 h-3.5" />
                In Stock · Ready to Ship
              </span>
            </div>

            <button
              onClick={handleAdd}
              className={`w-full py-3.5 rounded-full text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-md ${
                isAdded
                  ? 'bg-emerald-700 text-white'
                  : 'bg-[#111111] hover:bg-[#2C2C2C] text-white'
              }`}
            >
              {isAdded ? (
                <>
                  <Check className="w-4 h-4" />
                  Added to Shopping Bag
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                  Add to Shopping Bag
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
