'use client';

import React, { useState } from 'react';
import { Star, Sparkles, Eye, ArrowUpRight, Check } from 'lucide-react';
import { Product } from '@/lib/products';

interface BestSellersSectionProps {
  products: Product[];
  selectedBrand: string | null;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onClearBrandFilter: () => void;
  onOpenVirtualTryOn: () => void;
}

export const BestSellersSection: React.FC<BestSellersSectionProps> = ({
  products,
  selectedBrand,
  onSelectProduct,
  onAddToCart,
  onClearBrandFilter,
  onOpenVirtualTryOn,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [addedIds, setAddedIds] = useState<Record<string, boolean>>({});

  const categories = ['All', 'Skincare', 'Haircare', 'Makeup', 'Anti-Aging'];

  const filteredProducts = products.filter((p) => {
    const matchesBrand = selectedBrand ? p.brand === selectedBrand : true;
    const matchesCategory =
      activeCategory === 'All' ? true : p.category === activeCategory;
    return matchesBrand && matchesCategory;
  });

  const handleQuickAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
    setAddedIds((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedIds((prev) => ({ ...prev, [product.id]: false }));
    }, 2000);
  };

  return (
    <section id="bestsellers" className="py-16 sm:py-20 bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <p className="text-[10px] font-bold tracking-[0.25em] text-[#8B6E3F] uppercase mb-1">
              MOST LOVED
            </p>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#111111] font-normal tracking-tight">
              {selectedBrand ? `${selectedBrand} Collection` : 'Best Sellers'}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {selectedBrand && (
              <button
                onClick={onClearBrandFilter}
                className="text-xs font-semibold text-[#8B6E3F] underline hover:text-[#111111] transition-colors"
              >
                Clear Brand Filter ({selectedBrand})
              </button>
            )}
            <button
              onClick={onOpenVirtualTryOn}
              className="bg-[#EFECE6] hover:bg-[#E5E0D5] text-[#111111] px-4 py-2 rounded-full text-xs font-semibold transition-colors flex items-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#B89768]" />
              <span>Shade Match & Virtual Try-On</span>
            </button>
          </div>
        </div>

        {/* Segmented Filter Control Bar (Interactive buttons, clean segmented control) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {categories.map((cat) => {
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2.5 text-xs font-semibold uppercase tracking-wider rounded-full transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-[#111111] text-white shadow-sm'
                    : 'bg-[#EFECE6] hover:bg-[#E2DDD3] text-[#444444]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => {
              const isAdded = addedIds[product.id];
              return (
                <div
                  key={product.id}
                  onClick={() => onSelectProduct(product)}
                  className="group bg-white border border-[#E8E3D9] hover:border-[#B89768] rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer"
                >
                  {/* Top Image Container */}
                  <div className="relative h-64 sm:h-72 bg-[#FAF8F5] p-6 flex items-center justify-center overflow-hidden">
                    {/* Badge */}
                    {product.badge && (
                      <span className="absolute top-3 left-3 bg-[#FAF8F5] border border-[#E2DDD3] text-[#8B6E3F] text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md z-10 shadow-sm">
                        {product.badge}
                      </span>
                    )}

                    {/* Quick View Button on Hover */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectProduct(product);
                      }}
                      className="absolute top-3 right-3 bg-white/90 hover:bg-white text-[#111111] p-2 rounded-full shadow z-10 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Quick View"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    <img
                      src={product.image}
                      alt={product.name}
                      className="h-full max-w-full object-contain filter group-hover:scale-105 transition-transform duration-500"
                    />

                    {/* Shade Swatch Preview if Makeup */}
                    {product.shades && product.shades.length > 0 && (
                      <div className="absolute bottom-3 left-3 right-3 bg-white/90 backdrop-blur-md p-1.5 rounded-lg flex items-center justify-center gap-1.5 opacity-90 group-hover:opacity-100 transition-opacity">
                        <span className="text-[9px] font-semibold text-[#666666] mr-1">Shades:</span>
                        {product.shades.slice(0, 4).map((shade) => (
                          <span
                            key={shade.id}
                            className="w-3.5 h-3.5 rounded-full border border-gray-300 inline-block shadow-inner"
                            style={{ backgroundColor: shade.hex }}
                            title={shade.name}
                          />
                        ))}
                        {product.shades.length > 4 && (
                          <span className="text-[9px] font-bold text-[#444444]">
                            +{product.shades.length - 4}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Card Info Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      {/* Quiet Metadata with typographic separators */}
                      <div className="flex items-center gap-2 text-[11px] font-bold text-[#8B6E3F] uppercase tracking-wider mb-1">
                        <span>{product.brand}</span>
                        <span aria-hidden="true">·</span>
                        <span>{product.subCategory}</span>
                      </div>

                      <h3 className="font-serif-luxury text-lg font-bold text-[#111111] group-hover:text-[#B89768] transition-colors line-clamp-2 leading-tight">
                        {product.name}
                      </h3>

                      {/* Rating */}
                      <div className="flex items-center gap-1 mt-2 text-xs text-[#555555]">
                        <div className="flex items-center text-[#D4AF37]">
                          <Star className="w-3.5 h-3.5 fill-current" />
                        </div>
                        <span className="font-bold text-[#111111]">{product.rating}</span>
                        <span className="text-[#888888]">({product.reviewsCount})</span>
                      </div>
                    </div>

                    {/* Price & Add to Bag */}
                    <div className="pt-3 border-t border-[#F0ECE3] flex items-center justify-between">
                      <div>
                        {product.originalPrice && (
                          <span className="text-xs text-[#999999] line-through mr-1.5">
                            ${product.originalPrice.toFixed(2)}
                          </span>
                        )}
                        <span className="text-base font-bold text-[#111111] tabular-nums">
                          ${product.price.toFixed(2)}
                        </span>
                      </div>

                      <button
                        onClick={(e) => handleQuickAdd(product, e)}
                        className={`px-3.5 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 ${
                          isAdded
                            ? 'bg-emerald-700 text-white'
                            : 'bg-[#111111] hover:bg-[#B89768] text-white'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            Added
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-3 h-3" />
                            Add
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-2xl border border-[#E8E3D9]">
            <p className="text-sm font-semibold text-[#666666]">
              No formulas found for this brand & category combination.
            </p>
            <button
              onClick={onClearBrandFilter}
              className="mt-3 text-xs font-bold uppercase tracking-wider text-[#B89768] hover:underline"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
