'use client';

import React, { useState } from 'react';
import { X, Sparkles, Check, Sliders, RefreshCcw } from 'lucide-react';
import { Product, ShadeOption } from '@/lib/products';

interface VirtualTryOnModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, selectedShade?: ShadeOption) => void;
  products: Product[];
}

export const VirtualTryOnModal: React.FC<VirtualTryOnModalProps> = ({
  isOpen,
  onClose,
  onAddToCart,
  products,
}) => {
  // Makeup products with shades
  const makeupProducts = products.filter((p) => p.shades && p.shades.length > 0);
  const [selectedProduct, setSelectedProduct] = useState<Product>(
    makeupProducts[0] || products[3]
  );
  const [selectedShade, setSelectedShade] = useState<ShadeOption>(
    selectedProduct.shades?.[0] || {
      id: '150-pathfinder',
      name: '150 Pathfinder',
      hex: '#B82E46',
      finish: 'Matte',
    }
  );
  const [finishMode, setFinishMode] = useState<'Matte' | 'Glossy' | 'Dewy'>('Matte');
  const [modelType, setModelType] = useState<'Warm' | 'Cool' | 'Neutral'>('Warm');
  const [isAdded, setIsAdded] = useState(false);

  if (!isOpen) return null;

  const handleProductChange = (prod: Product) => {
    setSelectedProduct(prod);
    if (prod.shades && prod.shades.length > 0) {
      setSelectedShade(prod.shades[0]);
    }
  };

  const handleAddToCart = () => {
    onAddToCart(selectedProduct, selectedShade);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-4 sm:p-6">
      <div className="bg-[#FAF8F5] border border-[#E2DDD3] rounded-3xl max-w-4xl w-full overflow-hidden shadow-2xl relative flex flex-col md:flex-row">
        
        {/* Left Side: Live Visual Try-On Canvas Preview */}
        <div className="w-full md:w-1/2 bg-[#111111] p-6 flex flex-col justify-between relative min-h-[360px] md:min-h-[480px]">
          {/* Top Info */}
          <div className="flex items-center justify-between z-10">
            <span className="bg-white/20 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full">
              L&apos;Oréal Virtual Try-On Studio
            </span>
            <span className="text-white/70 text-xs font-mono">
              Finish: {finishMode}
            </span>
          </div>

          {/* Model Face Canvas Simulation with Tint Overlay */}
          <div className="relative my-auto flex items-center justify-center overflow-hidden rounded-2xl border border-white/20">
            <img
              src="/src/assets/images/hero_beauty_portrait_1790952478303.jpg"
              alt="Model Try-On Preview"
              className="w-full h-80 object-cover object-center filter saturate-110"
            />

            {/* Dynamic Lip / Shade Color Overlay Simulation */}
            <div
              className="absolute inset-0 pointer-events-none mix-blend-color transition-colors duration-500 opacity-60"
              style={{ backgroundColor: selectedShade.hex }}
            />

            {/* Finish Glow Overlay */}
            {finishMode === 'Glossy' && (
              <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-white/10 via-transparent to-white/20" />
            )}

            {/* Bottom Shade Label Banner */}
            <div className="absolute bottom-3 left-3 right-3 bg-black/80 backdrop-blur-md p-3 rounded-xl flex items-center justify-between text-white border border-white/10">
              <div className="flex items-center gap-2">
                <span
                  className="w-5 h-5 rounded-full border border-white/50 shadow-inner"
                  style={{ backgroundColor: selectedShade.hex }}
                />
                <div>
                  <p className="text-xs font-bold">{selectedShade.name}</p>
                  <p className="text-[10px] text-white/70">{selectedProduct.name}</p>
                </div>
              </div>
              <span className="text-[10px] font-mono text-[#D4AF37] uppercase">100% Match</span>
            </div>
          </div>

          {/* Undertone Controls */}
          <div className="flex items-center justify-center gap-2 z-10 pt-2">
            <span className="text-[10px] font-bold text-white/60 uppercase">Complexion:</span>
            {(['Warm', 'Cool', 'Neutral'] as const).map((tone) => (
              <button
                key={tone}
                onClick={() => setModelType(tone)}
                className={`px-2.5 py-1 text-[10px] font-semibold rounded-md transition-all ${
                  modelType === tone
                    ? 'bg-[#B89768] text-white font-bold'
                    : 'bg-white/10 text-white/70 hover:bg-white/20'
                }`}
              >
                {tone}
              </button>
            ))}
          </div>
        </div>

        {/* Right Side: Shade Selector & Controls */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="flex items-center justify-between border-b border-[#E8E3D9] pb-4">
            <div>
              <p className="text-[10px] font-bold tracking-[0.2em] text-[#8B6E3F] uppercase">
                SHADE FINDER
              </p>
              <h3 className="font-serif-luxury text-2xl font-bold text-[#111111]">
                Live Color Studio
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-black rounded-full hover:bg-gray-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Product Switcher */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[#111111] block">
              Select Formula
            </label>
            <div className="grid grid-cols-1 gap-2">
              {makeupProducts.map((prod) => (
                <button
                  key={prod.id}
                  onClick={() => handleProductChange(prod)}
                  className={`p-3 text-left rounded-xl border transition-all flex items-center justify-between ${
                    selectedProduct.id === prod.id
                      ? 'bg-white border-[#111111] ring-1 ring-[#111111] shadow-sm'
                      : 'bg-white/60 border-[#E2DDD3] hover:border-[#B89768]'
                  }`}
                >
                  <div>
                    <p className="text-[10px] font-bold text-[#8B6E3F] uppercase">{prod.brand}</p>
                    <p className="text-xs font-semibold text-[#111111]">{prod.name}</p>
                  </div>
                  <span className="text-xs font-bold text-[#111111]">${prod.price.toFixed(2)}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Color Swatches Grid */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-[#111111] block">
              Available Shades ({selectedProduct.shades?.length || 0})
            </label>
            <div className="grid grid-cols-5 gap-3">
              {selectedProduct.shades?.map((shade) => {
                const isSelected = selectedShade.id === shade.id;
                return (
                  <button
                    key={shade.id}
                    onClick={() => setSelectedShade(shade)}
                    className={`group relative flex flex-col items-center gap-1 focus:outline-none`}
                  >
                    <span
                      className={`w-9 h-9 rounded-full border-2 transition-all flex items-center justify-center shadow-md ${
                        isSelected ? 'border-[#111111] scale-110 ring-2 ring-[#B89768]' : 'border-white hover:scale-105'
                      }`}
                      style={{ backgroundColor: shade.hex }}
                    >
                      {isSelected && <Check className="w-4 h-4 text-white drop-shadow-md" />}
                    </span>
                    <span className="text-[9px] font-medium text-[#555555] truncate max-w-[50px] text-center">
                      {shade.name.split(' ')[0]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Finish Mode Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[#111111] block">
              Texture / Finish Effect
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Matte', 'Glossy', 'Dewy'] as const).map((finish) => (
                <button
                  key={finish}
                  onClick={() => setFinishMode(finish)}
                  className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                    finishMode === finish
                      ? 'bg-[#111111] text-white border-[#111111]'
                      : 'bg-white text-[#555555] border-[#E2DDD3]'
                  }`}
                >
                  {finish}
                </button>
              ))}
            </div>
          </div>

          {/* CTA Add to Bag */}
          <div className="pt-4 border-t border-[#E8E3D9] flex items-center justify-between">
            <div>
              <p className="text-[10px] text-[#666666] font-medium">Selected Shade:</p>
              <p className="text-xs font-bold text-[#111111]">{selectedShade.name}</p>
            </div>

            <button
              onClick={handleAddToCart}
              className={`px-6 py-3 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-md ${
                isAdded ? 'bg-emerald-700 text-white' : 'bg-[#111111] hover:bg-[#2C2C2C] text-white'
              }`}
            >
              {isAdded ? (
                <>
                  <Check className="w-4 h-4" />
                  Added to Bag
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                  Add Formula & Shade
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
