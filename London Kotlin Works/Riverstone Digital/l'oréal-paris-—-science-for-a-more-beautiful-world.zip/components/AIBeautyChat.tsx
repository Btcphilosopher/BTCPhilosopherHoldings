'use client';

import React, { useState } from 'react';
import { Sparkles, MessageSquare, X, Send, Bot, User, Loader2 } from 'lucide-react';

export const AIBeautyChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    {
      role: 'assistant',
      content:
        "Bonjour! I am your L'Oréal Paris Beauty & Skincare AI Consultant. How may I assist your beauty routine today?",
    },
  ]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isLoading) return;

    const userMsg = inputMessage.trim();
    setInputMessage('');

    const updatedMessages = [...messages, { role: 'user' as const, content: userMsg }];
    setMessages(updatedMessages);
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: updatedMessages }),
      });

      if (!res.ok) throw new Error('Advisor API request failed');

      const data = await res.json();
      setMessages([
        ...updatedMessages,
        { role: 'assistant', content: data.reply || 'I am happy to guide your beauty journey.' },
      ]);
    } catch (err) {
      console.error(err);
      setMessages([
        ...updatedMessages,
        {
          role: 'assistant',
          content: 'Pardon, I encountered a temporary connection issue. Please try asking again.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Widget Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 bg-[#111111] hover:bg-[#2C2C2C] text-white px-5 py-3.5 rounded-full shadow-2xl flex items-center gap-2.5 transition-all transform hover:scale-105 border border-[#D4AF37]/40"
          aria-label="Open AI Beauty Advisor"
        >
          <Sparkles className="w-4 h-4 text-[#D4AF37] animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wider">AI Beauty Advisor</span>
        </button>
      )}

      {/* Docked Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-80 sm:w-96 bg-[#FAF8F5] border border-[#E2DDD3] rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[500px]">
          {/* Header */}
          <div className="bg-[#111111] text-white p-4 flex items-center justify-between border-b border-[#333333]">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <div>
                <p className="font-serif-luxury text-base font-bold">L&apos;Oréal AI Beauty Advisor</p>
                <p className="text-[9px] text-[#D4AF37] uppercase font-mono">Gemini 2.5 Intelligence</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white p-1 rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex items-start gap-2 ${
                  m.role === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {m.role === 'assistant' && (
                  <div className="w-6 h-6 rounded-full bg-[#B89768] text-white flex items-center justify-center shrink-0 text-[10px]">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}
                <div
                  className={`p-3 rounded-2xl max-w-[80%] leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-[#111111] text-white rounded-br-none'
                      : 'bg-white text-[#222222] border border-[#E8E3D9] rounded-bl-none shadow-sm'
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex items-center gap-2 text-xs text-[#888888] py-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#B89768]" />
                <span>Formulating expert advice...</span>
              </div>
            )}
          </div>

          {/* Form Input */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 bg-white border-t border-[#E8E3D9] flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask about routines, ingredients, shades..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-1 text-xs px-3 py-2 bg-[#FAF8F5] border border-[#E2DDD3] rounded-full focus:outline-none"
            />
            <button
              type="submit"
              disabled={isLoading || !inputMessage.trim()}
              className="bg-[#111111] hover:bg-[#2C2C2C] disabled:opacity-50 text-white p-2 rounded-full"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
