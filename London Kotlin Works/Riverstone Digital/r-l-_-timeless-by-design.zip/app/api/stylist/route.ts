import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function POST(req: NextRequest) {
  try {
    const { prompt, context } = await req.json();

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json({
        text: "I am the R L Heritage Concierge. The key is currently unconfigured, but I can tell you that for a timeless evening look, pair our Grand Manhattan Tote in Obsidian Calfskin with a tailored double-breasted overcoat and gold equestrian cufflinks."
      });
    }

    const systemInstruction = `
You are the Chief Heritage Concierge & Personal Stylist for "R L" (Ralph Lauren style American Heritage luxury brand).
Your style is extremely sophisticated, polite, refined, warm, and expert in luxury leathercraft, equestrian heritage, tailoring, travel gear, and modern style expression.
Always answer questions about styling, product care, outfit pairing, gifting recommendations, or leather craftsmanship with understated elegance. Keep your responses concise yet luxurious (2-3 paragraphs max).
Context about R L collection:
- Handbags: Grand Manhattan Tote ($2,850), Madison Saddle Bag ($1,950), Gotham Crossbody ($1,250), Park Avenue Clutch ($980).
- Luggage: Transatlantic Cabin Trunk ($4,200), Sovereign Duffel ($2,400), Metropolitan Suitcase ($3,800).
- Accessories: Equestrian Brass Belt ($450), Chrono Heritage Gold Watch ($3,200), Aviator Gold Sunglasses ($520), Saddle Cardholder ($280).
- Ready-to-wear: Empire Double-Breasted Overcoat ($3,400), Cashmere Turtleneck ($890), Metropolitan Silk Scarf ($420).
    `;

    const fullPrompt = `${systemInstruction}\n\nUser Question: ${prompt}\n${context ? `User Context: ${context}` : ''}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: fullPrompt,
    });

    return NextResponse.json({ text: response.text || "Our master stylists recommend exploring our signature Grand Manhattan Tote in Equestrian Calfskin." });
  } catch (err: any) {
    console.error("Gemini API Error:", err);
    return NextResponse.json(
      { text: "Our R L Heritage Stylists are currently reviewing your request. Meanwhile, explore our iconic Handbag & Luggage collection." },
      { status: 200 }
    );
  }
}
