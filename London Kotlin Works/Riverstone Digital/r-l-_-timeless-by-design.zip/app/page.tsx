'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { CategoryGrid } from '@/components/CategoryGrid';
import { ProductCatalog } from '@/components/ProductCatalog';
import { HouseCraftsmanshipSection } from '@/components/HouseCraftsmanshipSection';
import { Footer } from '@/components/Footer';
import { ThreeBagStudioModal } from '@/components/ThreeBagStudioModal';
import { ProductDetailModal } from '@/components/ProductDetailModal';
import { CartDrawer, CartItem } from '@/components/CartDrawer';
import { StylistModal } from '@/components/StylistModal';
import { StoreLocatorModal } from '@/components/StoreLocatorModal';
import { SearchModal } from '@/components/SearchModal';
import { Product, PRODUCTS } from '@/lib/products';

export default function HomePage() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isStudioOpen, setIsStudioOpen] = useState<boolean>(false);
  const [isStylistOpen, setIsStylistOpen] = useState<boolean>(false);
  const [isStoresOpen, setIsStoresOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isPixelMode, setIsPixelMode] = useState<boolean>(false);

  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleAddToCart = (product: Product, selectedColor?: string) => {
    setCartItems((prev) => {
      const existingIdx = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedColor === selectedColor
      );
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += 1;
        return updated;
      } else {
        return [
          ...prev,
          {
            id: `${product.id}-${selectedColor || 'default'}-${Date.now()}`,
            product,
            selectedColor,
            quantity: 1,
          },
        ];
      }
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleExplore = () => {
    const catalogEl = document.getElementById('collection');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <main className="min-h-screen bg-[#0B0F17] text-[#E2E8F0] font-sans antialiased selection:bg-[#D4AF37]/30 selection:text-[#F3E5AB]">
      
      {/* Navigation */}
      <Navbar
        activeCategory={activeCategory}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          if (cat !== 'all') {
            handleExplore();
          }
        }}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenStylist={() => setIsStylistOpen(true)}
        onOpenStudio={() => setIsStudioOpen(true)}
        onTogglePixelMode={() => setIsPixelMode(!isPixelMode)}
        isPixelMode={isPixelMode}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenStores={() => setIsStoresOpen(true)}
      />

      {/* Hero Section */}
      <HeroSection
        onExplore={handleExplore}
        onOpenStudio={() => setIsStudioOpen(true)}
        onTogglePixelMode={() => setIsPixelMode(!isPixelMode)}
        isPixelMode={isPixelMode}
      />

      {/* 4 Featured Category Grid Cards */}
      <CategoryGrid
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          handleExplore();
        }}
        isPixelMode={isPixelMode}
      />

      {/* Full Interactive Product Catalog */}
      <ProductCatalog
        selectedCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onQuickAddToCart={(p) => handleAddToCart(p, p.colors[0]?.name)}
        isPixelMode={isPixelMode}
      />

      {/* House & Craftsmanship Story Section */}
      <HouseCraftsmanshipSection
        onOpenStudio={() => setIsStudioOpen(true)}
        isPixelMode={isPixelMode}
      />

      {/* Footer */}
      <Footer
        onOpenStores={() => setIsStoresOpen(true)}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          handleExplore();
        }}
      />

      {/* Modals & Slide-over Drawers */}
      <ThreeBagStudioModal
        isOpen={isStudioOpen}
        onClose={() => setIsStudioOpen(false)}
        onAddToCart={(customizedItem) => {
          handleAddToCart(customizedItem, 'Bespoke Foil');
          setIsStudioOpen(false);
        }}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={(p, col) => {
          handleAddToCart(p, col);
          setSelectedProduct(null);
        }}
        onOpenStudio={() => setIsStudioOpen(true)}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      <StylistModal
        isOpen={isStylistOpen}
        onClose={() => setIsStylistOpen(false)}
      />

      <StoreLocatorModal
        isOpen={isStoresOpen}
        onClose={() => setIsStoresOpen(false)}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

    </main>
  );
}
