import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'R L | Timeless By Design — American Heritage & Modern Expression',
  description: 'Discover luxury leather handbags, luggage, fine accessories, and ready-to-wear crafted with American heritage and modern expression.',
  openGraph: {
    title: 'R L | Timeless By Design',
    description: 'American heritage. Modern expression. Explore luxury leather goods and ready-to-wear.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'R L | Timeless By Design',
    description: 'American heritage. Modern expression.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Press+Start+2P&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#0B0F17] text-[#E2E8F0] font-sans antialiased selection:bg-[#D4AF37]/30 selection:text-[#F3E5AB]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
