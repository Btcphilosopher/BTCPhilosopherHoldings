export interface Product {
  id: string;
  name: string;
  subtitle: string;
  category: 'handbags' | 'luggage' | 'accessories' | 'readywear';
  price: number;
  image: string;
  hoverImage?: string;
  colors: { name: string; hex: string }[];
  materials: string[];
  dimensions: string;
  description: string;
  inStock: boolean;
  featured: boolean;
  pixelArtData?: string; // 8-bit pixel color matrix representation
}

export const PRODUCTS: Product[] = [
  {
    id: 'rl-handbag-01',
    name: 'Grand Manhattan Tote',
    subtitle: 'Iconic equestrian leather structured tote',
    category: 'handbags',
    price: 2850,
    image: '/images/category_handbags_1791012058850.jpg',
    colors: [
      { name: 'Saddle Tan', hex: '#8B4513' },
      { name: 'Obsidian Black', hex: '#1A1A1A' },
      { name: 'Cognac Brown', hex: '#65350F' }
    ],
    materials: ['Full-Grain Equestrian Calfskin', 'Solid Burnished Brass Hardware', 'Hand-Stitched Wax Thread'],
    dimensions: '15.5" W x 11.8" H x 6.2" D (39cm x 30cm x 16cm)',
    description: 'Crafted in upstate New York by master artisans using equestrian saddle-making techniques. Features double top handles, key clochette, and custom RL turnlock clasp.',
    inStock: true,
    featured: true
  },
  {
    id: 'rl-handbag-02',
    name: 'Madison Shoulder Saddle Bag',
    subtitle: 'Curved saddle silhouette with gold hardware',
    category: 'handbags',
    price: 1950,
    image: '/images/category_handbags_1791012058850.jpg',
    colors: [
      { name: 'Heritage Cognac', hex: '#7A3803' },
      { name: 'Deep Burgundy', hex: '#4A0E17' }
    ],
    materials: ['Saffiano Grain Calfskin', 'Hand-Burnished Edges', 'Micro-Suede Lining'],
    dimensions: '10.2" W x 7.5" H x 3.1" D',
    description: 'A timeless homage to American equestrian heritage with adjustable shoulder strap and signature RL brass emblem.',
    inStock: true,
    featured: false
  },
  {
    id: 'rl-luggage-01',
    name: 'Transatlantic Cabin Trunk',
    subtitle: 'Gunmetal aluminum & leather rolling suitcase',
    category: 'luggage',
    price: 4200,
    image: '/images/category_luggage_1791012069775.jpg',
    colors: [
      { name: 'Gunmetal Obsidian', hex: '#2A2E35' },
      { name: 'Brushed Titanium', hex: '#5A626A' }
    ],
    materials: ['Anodized Aircraft Aluminum', 'Full-Grain Leather Corners', 'Silent Japanese Dual-Spin Wheels'],
    dimensions: '21.5" H x 15.0" W x 9.0" D (Carry-On Compliant)',
    description: 'Engineered for seamless intercontinental travel with TSA-approved locks, leather-wrapped grab handles, and custom internal garment divider.',
    inStock: true,
    featured: true
  },
  {
    id: 'rl-luggage-02',
    name: 'Sovereign Weekender Duffel',
    subtitle: 'Heritage leather duffel with shoe compartment',
    category: 'luggage',
    price: 2400,
    image: '/images/category_luggage_1791012069775.jpg',
    colors: [
      { name: 'Obsidian Black', hex: '#111111' },
      { name: 'Vintage Saddle', hex: '#8B4513' }
    ],
    materials: ['Waxed Waterproof Canvas', 'Bridle Leather Trim', 'Solid Brass Rivets'],
    dimensions: '22.0" L x 12.0" W x 11.5" H',
    description: 'Generously proportioned weekend holdall equipped with dedicated ventilated shoe compartment, padded tablet sleeve, and detachable shoulder strap.',
    inStock: true,
    featured: false
  },
  {
    id: 'rl-accessories-01',
    name: 'Chrono Heritage Gold Watch',
    subtitle: 'Swiss chronograph movement with calfskin strap',
    category: 'accessories',
    price: 3200,
    image: '/images/category_accessories_1791012081133.jpg',
    colors: [
      { name: '18k Gold & Black', hex: '#D4AF37' },
      { name: 'Polished Steel', hex: '#C0C0C0' }
    ],
    materials: ['18k Gold Plated 316L Stainless Steel', 'Sapphire Crystal Glass', 'Swiss Quartz Chronograph'],
    dimensions: '41mm Case Diameter, 20mm Lug Width',
    description: 'An enduring timepiece featuring tachymeter bezel, guilloché dial details, and quick-release equestrian leather strap.',
    inStock: true,
    featured: true
  },
  {
    id: 'rl-accessories-02',
    name: 'Equestrian Brass Dress Belt',
    subtitle: 'Hand-burnished bridle leather with RL buckle',
    category: 'accessories',
    price: 450,
    image: '/images/category_accessories_1791012081133.jpg',
    colors: [
      { name: 'Equestrian Brown', hex: '#5C2C16' },
      { name: 'Nero Black', hex: '#0F0F0F' }
    ],
    materials: ['English Bridle Leather', 'Solid Cast Brass Buckle'],
    dimensions: '35mm Width (Sizes 30 - 44)',
    description: 'Handcrafted in limited batches with hand-painted edges and solid brass stirrup-inspired buckle.',
    inStock: true,
    featured: false
  },
  {
    id: 'rl-readywear-01',
    name: 'Empire Double-Breasted Overcoat',
    subtitle: '100% Wool-cashmere double-breasted trench',
    category: 'readywear',
    price: 3400,
    image: '/images/category_readywear_1791012095003.jpg',
    colors: [
      { name: 'Midnight Navy', hex: '#1B263B' },
      { name: 'Charcoal Houndstooth', hex: '#2D3139' }
    ],
    materials: ['90% Virgin Wool, 10% Cashmere', 'Horn Buttons', 'Cupro Bemberg Lining'],
    dimensions: 'Tailored Fit (Sizes 38R - 46R)',
    description: 'A classic double-breasted overcoat tailored in Italy with sharp peak lapels, horn buttons, and deep welt pockets.',
    inStock: true,
    featured: true
  },
  {
    id: 'rl-readywear-02',
    name: 'Metropolitan Cashmere Turtleneck',
    subtitle: 'Ultra-soft 2-ply Mongolian cashmere knit',
    category: 'readywear',
    price: 890,
    image: '/images/category_readywear_1791012095003.jpg',
    colors: [
      { name: 'Obsidian Black', hex: '#121212' },
      { name: 'Ivory Cream', hex: '#F5F5DC' }
    ],
    materials: ['100% Mongolian Cashmere'],
    dimensions: 'Regular Fit (Sizes S - XXL)',
    description: 'Knitted from fine long-staple cashmere yarns providing exceptional warmth, breathable comfort, and timeless elegance.',
    inStock: true,
    featured: false
  }
];

export const GLOBAL_CITIES = [
  { name: 'NEW YORK CITY', coords: '40.7128° N 74.0060° W', tz: 'America/New_York' },
  { name: 'LONDON', coords: '51.5074° N 0.1278° W', tz: 'Europe/London' },
  { name: 'PARIS', coords: '48.8566° N 2.3522° E', tz: 'Europe/Paris' },
  { name: 'TOKYO', coords: '35.6762° N 139.6503° E', tz: 'Asia/Tokyo' },
];
