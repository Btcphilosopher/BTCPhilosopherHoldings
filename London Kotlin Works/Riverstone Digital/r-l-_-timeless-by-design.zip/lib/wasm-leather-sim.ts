/**
 * High-performance Leather Grain & Metallic Monogram Shader / SIMD Math Simulation.
 * Emulates C++ WebAssembly compiled surface normal lighting, foil debossing depth, and micro-grain reflection.
 */

export interface LeatherMaterialParams {
  material: 'calfskin' | 'saffiano' | 'saddle' | 'obsidian' | 'mahogany';
  foilColor: 'gold' | 'silver' | 'deboss';
  monogramText: string;
  lightAngle: number; // 0 to 360 degrees
  lightingIntensity: number; // 0.5 to 1.5
}

export function generateLeatherTextureCanvas(
  canvas: HTMLCanvasElement,
  params: LeatherMaterialParams
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const width = canvas.width;
  const height = canvas.height;

  // Base background color selection
  let baseR = 26, baseG = 26, baseB = 26; // Default Obsidian
  if (params.material === 'calfskin') { baseR = 139; baseG = 69; baseB = 19; } // Saddle Brown
  else if (params.material === 'saffiano') { baseR = 40; baseG = 30; baseB = 25; } // Dark Saffiano
  else if (params.material === 'saddle') { baseR = 180; baseG = 95; baseB = 30; } // Vintage Saddle Tan
  else if (params.material === 'mahogany') { baseR = 80; baseG = 20; baseB = 20; } // Deep Mahogany

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  const rad = (params.lightAngle * Math.PI) / 180;
  const lx = Math.cos(rad);
  const ly = Math.sin(rad);

  // Wasm / High-perf Loop: Simulate leather surface micro-normals and specularity
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;

      // Surface noise for leather grain pattern
      let grain = (Math.sin(x * 0.15) * Math.cos(y * 0.15) + Math.sin(x * 0.4 + y * 0.3)) * 12;
      
      if (params.material === 'saffiano') {
        // Cross-hatch diagonal grain pattern for Saffiano
        const hatch1 = Math.sin((x + y) * 0.3) > 0 ? 15 : -15;
        const hatch2 = Math.sin((x - y) * 0.3) > 0 ? 15 : -15;
        grain += (hatch1 + hatch2) * 0.5;
      }

      // Normal map lighting calculation (Dot product with light direction)
      const nx = (grain * 0.05);
      const ny = (grain * 0.05);
      const diff = Math.max(0.2, lx * nx + ly * ny + 0.8) * params.lightingIntensity;

      // Color assignment
      data[idx] = Math.min(255, Math.max(0, baseR * diff + grain));
      data[idx + 1] = Math.min(255, Math.max(0, baseG * diff + grain * 0.8));
      data[idx + 2] = Math.min(255, Math.max(0, baseB * diff + grain * 0.6));
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  // Draw 3D Leather Bag Contour Overlay
  ctx.save();
  ctx.strokeStyle = 'rgba(212, 175, 55, 0.4)';
  ctx.lineWidth = 3;
  
  // Draw Tote Bag Silhouette
  const cx = width / 2;
  const cy = height / 2;

  ctx.beginPath();
  // Tote handles
  ctx.arc(cx - 50, cy - 80, 45, Math.PI, 0, false);
  ctx.arc(cx + 50, cy - 80, 45, Math.PI, 0, false);
  ctx.stroke();

  // Bag Body
  ctx.beginPath();
  ctx.moveTo(cx - 130, cy - 40);
  ctx.lineTo(cx + 130, cy - 40);
  ctx.lineTo(cx + 110, cy + 120);
  ctx.lineTo(cx - 110, cy + 120);
  ctx.closePath();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Gold Brass Turnlock Clasp
  ctx.fillStyle = 'gold';
  ctx.shadowColor = '#D4AF37';
  ctx.shadowBlur = 10;
  ctx.beginPath();
  ctx.rect(cx - 15, cy - 25, 30, 20);
  ctx.fill();

  // Foil Monogram Embossing Render
  if (params.monogramText) {
    ctx.font = 'bold 32px "Playfair Display", Georgia, serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (params.foilColor === 'gold') {
      const grad = ctx.createLinearGradient(cx - 40, cy + 30, cx + 40, cy + 50);
      grad.addColorStop(0, '#F3E5AB');
      grad.addColorStop(0.5, '#D4AF37');
      grad.addColorStop(1, '#AA7C11');
      ctx.fillStyle = grad;
      ctx.shadowColor = 'rgba(212, 175, 55, 0.8)';
      ctx.shadowBlur = 12;
    } else if (params.foilColor === 'silver') {
      const grad = ctx.createLinearGradient(cx - 40, cy + 30, cx + 40, cy + 50);
      grad.addColorStop(0, '#FFFFFF');
      grad.addColorStop(0.5, '#E0E0E0');
      grad.addColorStop(1, '#9E9E9E');
      ctx.fillStyle = grad;
      ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
      ctx.shadowBlur = 12;
    } else {
      // Blind Deboss (Dark indent)
      ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
      ctx.shadowColor = 'rgba(255, 255, 255, 0.2)';
      ctx.shadowOffsetY = 1;
      ctx.shadowBlur = 2;
    }

    ctx.fillText(params.monogramText.toUpperCase(), cx, cy + 40);
  }

  ctx.restore();
}
