'use client';

import React, { useState, useMemo } from 'react';
import Image from 'next/image';
import { Product, PRODUCTS } from '@/lib/products';
import { Eye, ShoppingBag, Sparkles, SlidersHorizontal, Check } from 'lucide-react';
import { PixelArtCraftsmanshipEngine } from './PixelArtCraftsmanshipEngine';

interface ProductCatalogProps {
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
  isPixelMode: boolean;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  selectedCategory,
  onSelectCategory,
  onSelectProduct,
  onQuickAddToCart,
  isPixelMode
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');
  const [addedMap, setAddedMap] = useState<Record<string, boolean>>({});

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      const matchesCategory =
        selectedCategory === 'all' ||
        selectedCategory === 'women' ||
        selectedCategory === 'men' ||
        p.category === selectedCategory;

      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [selectedCategory, searchQuery, sortBy]);

  const handleQuickAdd = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    onQuickAddToCart(product);
    setAddedMap((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedMap((prev) => ({ ...prev, [product.id]: false }));
    }, 1800);
  };

  return (
    <section id="collection" className="py-16 px-4 md:px-8 bg-[#0B0F17] text-white">
      <div className="max-w-[1440px] mx-auto">
        
        {/* Header Title & Category Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between pb-8 border-b border-[#1E2638] gap-6">
          <div>
            <span className="text-xs font-semibold tracking-[0.25em] text-[#D4AF37] uppercase">
              R L Collection
            </span>
            <h2 className="font-serif-display text-3xl md:text-5xl text-white font-normal mt-1">
              {selectedCategory === 'all'
                ? 'The Complete Collection'
                : selectedCategory.toUpperCase()}
            </h2>
          </div>

          {/* Filter & Sort Bar */}
          <div className="flex flex-wrap items-center gap-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search leather, overcoats..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#111827] border border-[#1E2638] focus:border-[#D4AF37] rounded px-4 py-2 text-xs text-slate-200 placeholder-slate-500 w-48 md:w-64 outline-none"
              />
            </div>

            <div className="flex items-center gap-2 bg-[#111827] border border-[#1E2638] rounded px-3 py-2 text-xs text-slate-300">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#D4AF37]" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-xs text-slate-200 outline-none cursor-pointer"
              >
                <option value="featured" className="bg-[#111827]">Featured Selection</option>
                <option value="price-asc" className="bg-[#111827]">Price: Low to High</option>
                <option value="price-desc" className="bg-[#111827]">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto py-6 text-xs border-b border-[#1E2638] scrollbar-none">
          {[
            { id: 'all', label: 'All Artifacts' },
            { id: 'handbags', label: 'Handbags & Totes' },
            { id: 'luggage', label: 'Luggage & Trunks' },
            { id: 'accessories', label: 'Accessories & Belts' },
            { id: 'readywear', label: 'Ready-To-Wear' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-[#D4AF37] text-black font-semibold shadow-md'
                  : 'bg-[#111827] text-slate-400 border border-[#1E2638] hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mt-10">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              onClick={() => onSelectProduct(product)}
              className="group bg-[#0F172A] border border-[#1E2638] hover:border-[#D4AF37] rounded overflow-hidden transition-all duration-300 flex flex-col justify-between cursor-pointer"
            >
              {/* Image Container */}
              <div className="relative aspect-[4/3] bg-[#05080E] overflow-hidden">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className={`object-cover object-center group-hover:scale-105 transition-transform duration-500 ${
                    isPixelMode ? 'rendering-pixelated scale-105 contrast-125' : ''
                  }`}
                  referrerPolicy="no-referrer"
                />

                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectProduct(product);
                    }}
                    className="p-3 bg-black/80 hover:bg-[#D4AF37] hover:text-black text-white rounded-full transition-colors shadow-lg"
                    title="Quick View Details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  <button
                    onClick={(e) => handleQuickAdd(e, product)}
                    className="p-3 bg-[#D4AF37] text-black hover:bg-white rounded-full transition-colors shadow-lg font-bold"
                    title="Quick Add to Shopping Bag"
                  >
                    {addedMap[product.id] ? <Check className="w-4 h-4 text-emerald-900" /> : <ShoppingBag className="w-4 h-4" />}
                  </button>
                </div>

                {product.featured && (
                  <span className="absolute top-3 left-3 bg-black/70 backdrop-blur-md text-[#D4AF37] text-[10px] font-semibold tracking-widest px-2.5 py-1 uppercase rounded border border-[#D4AF37]/30">
                    Heritage Iconic
                  </span>
                )}
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-[11px] font-medium tracking-widest text-[#D4AF37] uppercase">
                    {product.category}
                  </p>
                  <h3 className="font-serif-display text-xl text-white group-hover:text-[#F3E5AB] transition-colors mt-1">
                    {product.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-1 font-light">
                    {product.subtitle}
                  </p>
                </div>

                <div className="mt-4 pt-4 border-t border-[#1E2638] flex items-center justify-between">
                  <span className="font-mono text-base font-semibold text-white">
                    ${product.price.toLocaleString()}
                  </span>

                  <button
                    onClick={(e) => handleQuickAdd(e, product)}
                    className="text-xs font-semibold tracking-wider text-[#D4AF37] hover:underline uppercase flex items-center gap-1"
                  >
                    {addedMap[product.id] ? 'ADDED' : '+ ADD TO BAG'}
                  </button>
                </div>
              </div>

              {/* Pixel Art Rendering Engine Preview if mode is enabled */}
              {isPixelMode && (
                <div className="px-4 pb-4">
                  <PixelArtCraftsmanshipEngine product={product} isPixelMode={isPixelMode} />
                </div>
              )}

            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="py-20 text-center text-slate-500">
            <p className="text-lg font-serif-display text-slate-400">No artifacts matched your filter criteria.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                onSelectCategory('all');
              }}
              className="mt-4 px-6 py-2 bg-[#D4AF37] text-black font-semibold text-xs tracking-wider rounded uppercase"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
