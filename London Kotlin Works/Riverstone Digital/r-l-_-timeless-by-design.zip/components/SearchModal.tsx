'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Product, PRODUCTS } from '@/lib/products';
import { Search, X, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onSelectProduct }) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const results = PRODUCTS.filter(
    (p) =>
      p.name.toLowerCase().includes(query.toLowerCase()) ||
      p.subtitle.toLowerCase().includes(query.toLowerCase()) ||
      p.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/85 backdrop-blur-md">
      <div className="bg-[#0B0F17] border border-[#1E2638] w-full max-w-2xl rounded-lg shadow-2xl overflow-hidden text-white">
        
        {/* Search Bar Input */}
        <div className="p-4 border-b border-[#1E2638] flex items-center gap-3 bg-[#0F172A]">
          <Search className="w-5 h-5 text-[#D4AF37]" />
          <input
            type="text"
            placeholder="Search handbags, luggage, overcoats, accessories..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 outline-none"
          />
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results */}
        <div className="max-h-[400px] overflow-y-auto p-4 space-y-3">
          {query.trim() === '' ? (
            <div className="py-8 text-center text-xs text-slate-500">
              <p className="font-serif-display text-sm text-slate-400 mb-2">Popular Searches</p>
              <div className="flex flex-wrap justify-center gap-2">
                {['Manhattan Tote', 'Cabin Trunk', 'Gold Watch', 'Cashmere Overcoat'].map((term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    className="px-3 py-1 bg-[#1E293B] hover:bg-[#334155] rounded text-slate-300 text-xs transition-colors"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              No products found for &ldquo;{query}&rdquo;. Try searching for &ldquo;Tote&rdquo;, &ldquo;Trunk&rdquo;, or &ldquo;Watch&rdquo;.
            </div>
          ) : (
            results.map((product) => (
              <div
                key={product.id}
                onClick={() => {
                  onSelectProduct(product);
                  onClose();
                }}
                className="flex items-center gap-4 p-3 bg-[#111827] hover:bg-[#1E293B] border border-[#1E2638] rounded cursor-pointer transition-colors"
              >
                <div className="w-12 h-12 bg-[#05080E] relative shrink-0 rounded overflow-hidden">
                  <Image
                    src={product.image}
                    alt={product.name}
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1">
                  <h4 className="font-serif-display text-sm text-white">{product.name}</h4>
                  <p className="text-[11px] text-slate-400">{product.subtitle}</p>
                </div>

                <div className="text-right">
                  <p className="font-mono text-xs text-[#D4AF37] font-semibold">
                    ${product.price.toLocaleString()}
                  </p>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 ml-auto mt-1" />
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
