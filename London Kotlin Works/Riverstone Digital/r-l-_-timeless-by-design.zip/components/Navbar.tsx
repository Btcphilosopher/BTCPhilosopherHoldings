'use client';

import React, { useState, useEffect } from 'react';
import { Search, ShoppingBag, Sparkles, Box, Grid, ChevronDown, Compass } from 'lucide-react';
import { GLOBAL_CITIES } from '@/lib/products';

interface NavbarProps {
  activeCategory: string;
  onSelectCategory: (cat: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenStylist: () => void;
  onOpenStudio: () => void;
  onTogglePixelMode: () => void;
  isPixelMode: boolean;
  onOpenSearch: () => void;
  onOpenStores: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeCategory,
  onSelectCategory,
  cartCount,
  onOpenCart,
  onOpenStylist,
  onOpenStudio,
  onTogglePixelMode,
  isPixelMode,
  onOpenSearch,
  onOpenStores
}) => {
  const [selectedCity, setSelectedCity] = useState(GLOBAL_CITIES[0]);
  const [currentTime, setCurrentTime] = useState('');
  const [cityDropdownOpen, setCityDropdownOpen] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      try {
        const formatter = new Intl.DateTimeFormat('en-US', {
          timeZone: selectedCity.tz,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false
        });
        setCurrentTime(formatter.format(new Date()));
      } catch {
        setCurrentTime('12:00:00');
      }
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [selectedCity]);

  return (
    <header className="sticky top-0 z-50 bg-[#0B0F17]/95 backdrop-blur-md border-b border-[#1E2638] text-white transition-all duration-300">
      <div className="max-w-[1440px] mx-auto px-4 md:px-8 h-16 md:h-20 flex items-center justify-between">
        
        {/* Zone 1: Single Brand Wordmark */}
        <div className="flex items-center gap-6">
          <button 
            onClick={() => onSelectCategory('all')} 
            className="flex items-center gap-2 group text-left"
          >
            <span className="font-serif-display text-2xl md:text-3xl tracking-[0.2em] font-semibold text-white group-hover:text-[#D4AF37] transition-colors">
              R L
            </span>
          </button>

          {/* City & Live Time Selector */}
          <div className="hidden xl:flex items-center gap-2 text-[11px] tracking-widest text-[#94A3B8] border-l border-[#1E2638] pl-6 relative">
            <button
              onClick={() => setCityDropdownOpen(!cityDropdownOpen)}
              className="flex items-center gap-1.5 hover:text-[#D4AF37] transition-colors uppercase font-medium"
            >
              <span>{selectedCity.name.split(' ')[0]}</span>
              <span className="text-[#D4AF37] font-mono">{currentTime}</span>
              <ChevronDown className="w-3 h-3 text-[#64748B]" />
            </button>

            {cityDropdownOpen && (
              <div className="absolute top-8 left-6 bg-[#0F172A] border border-[#1E2638] rounded shadow-2xl py-2 w-48 z-50">
                {GLOBAL_CITIES.map((city) => (
                  <button
                    key={city.name}
                    onClick={() => {
                      setSelectedCity(city);
                      setCityDropdownOpen(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-xs flex justify-between items-center hover:bg-[#1E293B] ${selectedCity.name === city.name ? 'text-[#D4AF37] font-semibold' : 'text-slate-300'}`}
                  >
                    <span>{city.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{city.coords.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs font-medium tracking-[0.18em] text-[#CBD5E1]">
          {[
            { label: 'WOMEN', id: 'women' },
            { label: 'MEN', id: 'men' },
            { label: 'HANDBAGS', id: 'handbags' },
            { label: 'LUGGAGE', id: 'luggage' },
            { label: 'ACCESSORIES', id: 'accessories' },
            { label: 'THE HOUSE', id: 'readywear' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => onSelectCategory(item.id)}
              className={`hover:text-[#D4AF37] transition-colors py-1 relative uppercase ${
                activeCategory === item.id ? 'text-[#D4AF37] font-semibold' : ''
              }`}
            >
              {item.label}
              {activeCategory === item.id && (
                <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#D4AF37]" />
              )}
            </button>
          ))}
        </nav>

        {/* Zone 3: Interactive Utilities & Actions */}
        <div className="flex items-center gap-3 md:gap-5">
          {/* Search Trigger */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-slate-300 hover:text-[#D4AF37] transition-colors rounded-full hover:bg-white/5"
            title="Search Collection"
            aria-label="Search Collection"
          >
            <Search className="w-4 h-4 md:w-5 md:h-5" />
          </button>

          {/* Gemini AI Stylist Concierge */}
          <button
            onClick={onOpenStylist}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium tracking-wider text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded hover:bg-[#D4AF37]/20 transition-all"
            title="AI Bespoke Stylist"
          >
            <Sparkles className="w-3.5 h-3.5 animate-pulse text-[#D4AF37]" />
            <span>AI STYLIST</span>
          </button>

          {/* 3D Bag Customizer */}
          <button
            onClick={onOpenStudio}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium tracking-wider text-slate-200 bg-[#1E293B] border border-[#334155] rounded hover:border-[#D4AF37] transition-all"
            title="3D Leather Studio"
          >
            <Box className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>3D STUDIO</span>
          </button>

          {/* Pixel Art Heritage Mode Toggle */}
          <button
            onClick={onTogglePixelMode}
            className={`p-2 rounded border transition-all ${
              isPixelMode
                ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-bold shadow-[0_0_15px_rgba(212,175,55,0.5)]'
                : 'text-slate-300 border-[#334155] hover:border-[#D4AF37]'
            }`}
            title="8-Bit Heritage Pixel Mode"
            aria-label="8-Bit Heritage Pixel Mode"
          >
            <Grid className="w-4 h-4 md:w-5 md:h-5" />
          </button>

          {/* Stores Locator */}
          <button
            onClick={onOpenStores}
            className="hidden xl:p-2 text-slate-300 hover:text-[#D4AF37] transition-colors"
            title="Flagship Stores"
            aria-label="Flagship Stores"
          >
            <Compass className="w-5 h-5" />
          </button>

          {/* Shopping Bag Drawer Trigger */}
          <button
            onClick={onOpenCart}
            className="p-2 text-slate-300 hover:text-[#D4AF37] transition-colors relative"
            aria-label="Shopping Bag"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#D4AF37] text-black font-semibold text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-mono">
                {cartCount}
              </span>
            )}
          </button>
        </div>

      </div>
    </header>
  );
};
