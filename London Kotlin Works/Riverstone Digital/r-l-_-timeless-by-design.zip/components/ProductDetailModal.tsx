'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Product } from '@/lib/products';
import { X, ShoppingBag, ShieldCheck, Truck, Sparkles, Check, Box } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, selectedColor: string) => void;
  onOpenStudio: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onOpenStudio
}) => {
  const [selectedColor, setSelectedColor] = useState<string>(
    product?.colors[0]?.name || 'Standard'
  );
  const [added, setAdded] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, selectedColor);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-[#0B0F17] border border-[#1E2638] w-full max-w-4xl rounded-lg shadow-2xl overflow-hidden relative flex flex-col md:flex-row my-8">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-slate-400 hover:text-white bg-black/60 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Product Image Showcase */}
        <div className="w-full md:w-1/2 relative aspect-square bg-[#05080E] p-6 flex items-center justify-center border-b md:border-b-0 md:border-r border-[#1E2638]">
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute bottom-4 left-4 right-4 bg-black/60 backdrop-blur-md p-3 rounded text-center">
            <p className="text-[11px] font-mono text-[#D4AF37] tracking-widest">
              DIMENSIONS: {product.dimensions}
            </p>
          </div>
        </div>

        {/* Right: Contiguous Purchase Module */}
        <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col justify-between">
          <div>
            <div className="inline-block px-2.5 py-1 bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] text-[10px] font-semibold tracking-widest uppercase rounded">
              {product.category}
            </div>

            <h2 className="font-serif-display text-3xl md:text-4xl text-white mt-2">
              {product.name}
            </h2>

            <p className="font-serif-classic italic text-sm text-slate-300 mt-1">
              {product.subtitle}
            </p>

            <div className="font-mono text-2xl font-semibold text-[#D4AF37] mt-4">
              ${product.price.toLocaleString()}
            </div>

            <p className="text-xs text-slate-300 mt-4 leading-relaxed font-light">
              {product.description}
            </p>

            {/* Colors */}
            <div className="mt-6">
              <label className="block text-xs font-semibold tracking-wider text-slate-400 uppercase mb-2">
                Color Finish: <span className="text-white">{selectedColor}</span>
              </label>
              <div className="flex items-center gap-3">
                {product.colors.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => setSelectedColor(c.name)}
                    className={`w-7 h-7 rounded-full border-2 transition-all ${
                      selectedColor === c.name
                        ? 'border-[#D4AF37] scale-110 shadow-[0_0_10px_rgba(212,175,55,0.5)]'
                        : 'border-transparent opacity-80 hover:opacity-100'
                    }`}
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  />
                ))}
              </div>
            </div>

            {/* Material Specifications */}
            <div className="mt-6">
              <label className="block text-xs font-semibold tracking-wider text-slate-400 uppercase mb-2">
                Craftsmanship & Materials
              </label>
              <ul className="space-y-1.5 text-xs text-slate-300 font-light">
                {product.materials.map((m, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
                    <span>{m}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Action Buttons & Trust Markers */}
          <div className="mt-8 pt-6 border-t border-[#1E2638]">
            <div className="flex flex-col gap-3">
              <button
                onClick={handleAdd}
                className={`w-full py-4 text-xs font-semibold tracking-[0.2em] uppercase rounded flex items-center justify-center gap-2 transition-all ${
                  added
                    ? 'bg-emerald-600 text-white'
                    : 'bg-[#D4AF37] text-black hover:bg-[#F3E5AB]'
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>ADDED TO SHOPPING BAG</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>ADD TO SHOPPING BAG — ${product.price.toLocaleString()}</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenStudio();
                }}
                className="w-full py-3 bg-[#1E293B] hover:bg-[#334155] border border-[#334155] text-slate-200 text-xs font-medium tracking-widest uppercase rounded flex items-center justify-center gap-2 transition-colors"
              >
                <Box className="w-4 h-4 text-[#D4AF37]" />
                <span>CUSTOM EMBOSSING IN 3D STUDIO</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-6 text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#D4AF37]" />
                <span>Complimentary Worldwide Express</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                <span>Lifetime Artisanal Authenticity</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
