'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, ShoppingBag, Plus, Minus, Trash2, ArrowRight, CheckCircle2, Shield } from 'lucide-react';

export interface CartItem {
  id: string;
  product: any;
  selectedColor?: string;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [orderId, setOrderId] = useState('');

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = (subtotal * discount) / 100;
  const total = Math.max(0, subtotal - discountAmount);

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'HERITAGE10') {
      setDiscount(10);
    } else {
      alert('Invalid promo code. Try "HERITAGE10" for 10% off.');
    }
  };

  const handleCheckout = () => {
    setIsCheckingOut(true);
    setTimeout(() => {
      setIsCheckingOut(false);
      setOrderId(`RL-${Math.floor(100000 + Math.random() * 900000)}`);
      setOrderConfirmed(true);
      onClearCart();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0B0F17] border-l border-[#1E2638] text-white flex flex-col justify-between shadow-2xl">
          
          {/* Header */}
          <div className="p-6 border-b border-[#1E2638] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
              <h2 className="font-serif-display text-xl font-medium">YOUR SHOPPING BAG</h2>
              <span className="text-xs text-[#D4AF37] font-mono">({items.length})</span>
            </div>
            <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Order Confirmed View */}
          {orderConfirmed ? (
            <div className="p-8 flex-1 flex flex-col items-center justify-center text-center space-y-4">
              <CheckCircle2 className="w-16 h-16 text-emerald-400 animate-bounce" />
              <h3 className="font-serif-display text-2xl text-white">ORDER CONFIRMED</h3>
              <p className="text-xs text-[#D4AF37] font-mono tracking-widest">
                RECEIPT #{orderId}
              </p>
              <p className="text-xs text-slate-300 font-light max-w-xs">
                Thank you for choosing R L Heritage. Your handcrafted leather goods are currently being prepared for express delivery.
              </p>
              <button
                onClick={() => {
                  setOrderConfirmed(false);
                  onClose();
                }}
                className="mt-6 px-8 py-3 bg-[#D4AF37] text-black font-semibold text-xs tracking-widest uppercase rounded"
              >
                Return to Storefront
              </button>
            </div>
          ) : (
            <>
              {/* Cart Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {items.length === 0 ? (
                  <div className="py-20 text-center text-slate-500">
                    <p className="font-serif-display text-lg text-slate-400">Your shopping bag is empty.</p>
                    <p className="text-xs mt-1">Explore our Handbag, Luggage & Accessories collections.</p>
                  </div>
                ) : (
                  items.map((item) => (
                    <div
                      key={item.id}
                      className="flex gap-4 p-3 bg-[#111827] border border-[#1E2638] rounded relative group"
                    >
                      <div className="w-20 h-20 bg-[#05080E] relative shrink-0 rounded overflow-hidden border border-[#1E2638]">
                        <Image
                          src={item.product.image}
                          alt={item.product.name}
                          fill
                          className="object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start">
                            <h4 className="font-serif-display text-base text-white">
                              {item.product.name}
                            </h4>
                            <button
                              onClick={() => onRemoveItem(item.id)}
                              className="text-slate-500 hover:text-red-400 p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          {item.selectedColor && (
                            <p className="text-[11px] text-slate-400">Finish: {item.selectedColor}</p>
                          )}
                          <p className="text-xs font-mono font-semibold text-[#D4AF37] mt-1">
                            ${item.product.price.toLocaleString()}
                          </p>
                        </div>

                        {/* Quantity Stepper */}
                        <div className="flex items-center gap-3 mt-2">
                          <button
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            className="w-6 h-6 rounded bg-[#1E293B] hover:bg-[#334155] flex items-center justify-center text-xs"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            className="w-6 h-6 rounded bg-[#1E293B] hover:bg-[#334155] flex items-center justify-center text-xs"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Checkout Summary Footer */}
              {items.length > 0 && (
                <div className="p-6 border-t border-[#1E2638] bg-[#0F172A]">
                  
                  {/* Promo Input */}
                  <div className="flex gap-2 mb-4">
                    <input
                      type="text"
                      placeholder="Promo Code (HERITAGE10)"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="bg-[#111827] border border-[#1E2638] focus:border-[#D4AF37] rounded px-3 py-1.5 text-xs text-white flex-1 outline-none"
                    />
                    <button
                      onClick={handleApplyPromo}
                      className="px-3 py-1.5 bg-[#1E293B] hover:bg-[#334155] text-xs font-semibold text-[#D4AF37] rounded uppercase"
                    >
                      Apply
                    </button>
                  </div>

                  {/* Totals */}
                  <div className="space-y-1.5 text-xs text-slate-400 mb-4 font-mono">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>${subtotal.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-emerald-400">
                        <span>Heritage Discount ({discount}%)</span>
                        <span>-${discountAmount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-white font-semibold text-sm pt-2 border-t border-[#1E2638]">
                      <span>Total</span>
                      <span className="text-[#D4AF37]">${total.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Checkout Button */}
                  <button
                    onClick={handleCheckout}
                    disabled={isCheckingOut}
                    className="w-full py-4 bg-[#D4AF37] text-black font-semibold text-xs tracking-[0.2em] uppercase rounded hover:bg-[#F3E5AB] transition-all flex items-center justify-center gap-2"
                  >
                    {isCheckingOut ? (
                      <span>PROCESSING ORDER...</span>
                    ) : (
                      <>
                        <span>PROCEED TO EXPRESS CHECKOUT</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="flex items-center justify-center gap-2 text-[10px] text-slate-500 mt-3">
                    <Shield className="w-3 h-3 text-[#D4AF37]" />
                    <span>256-Bit Encrypted Luxury Checkout</span>
                  </div>

                </div>
              )}
            </>
          )}

        </div>
      </div>
    </div>
  );
};
