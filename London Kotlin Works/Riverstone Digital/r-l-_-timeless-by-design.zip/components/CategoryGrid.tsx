'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';

interface CategoryGridProps {
  onSelectCategory: (cat: string) => void;
  isPixelMode?: boolean;
}

const CATEGORY_CARDS = [
  {
    id: 'handbags',
    title: 'HANDBAGS',
    subtitle: 'Iconic styles for every journey',
    image: '/images/category_handbags_1791012058850.jpg',
  },
  {
    id: 'luggage',
    title: 'LUGGAGE',
    subtitle: "Built for what's next",
    image: '/images/category_luggage_1791012069775.jpg',
  },
  {
    id: 'accessories',
    title: 'ACCESSORIES',
    subtitle: 'The details make the difference',
    image: '/images/category_accessories_1791012081133.jpg',
  },
  {
    id: 'readywear',
    title: 'READY-TO-WEAR',
    subtitle: 'Modern classics. Enduring style.',
    image: '/images/category_readywear_1791012095003.jpg',
  },
];

export const CategoryGrid: React.FC<CategoryGridProps> = ({ onSelectCategory, isPixelMode }) => {
  return (
    <section className="bg-[#0B0F17] py-8 md:py-12 px-4 md:px-8 border-b border-[#1E2638]">
      <div className="max-w-[1440px] mx-auto">
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {CATEGORY_CARDS.map((card) => (
            <div
              key={card.id}
              onClick={() => onSelectCategory(card.id)}
              className="group relative h-[380px] md:h-[420px] overflow-hidden bg-[#111827] cursor-pointer border border-[#1E2638] hover:border-[#D4AF37] transition-all duration-500"
            >
              {/* Image background with zoom transition */}
              <Image
                src={card.image}
                alt={card.title}
                fill
                className={`object-cover object-center group-hover:scale-105 transition-transform duration-700 ${
                  isPixelMode ? 'rendering-pixelated scale-105 contrast-125' : ''
                }`}
                referrerPolicy="no-referrer"
              />

              {/* Scrim overlay for contrast */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent group-hover:from-black/95 transition-all" />

              {/* Card Footer Text matching user image */}
              <div className="absolute bottom-0 left-0 right-0 p-6 z-10 flex flex-col justify-end">
                <h3 className="font-serif-display text-2xl md:text-3xl tracking-wider text-white uppercase font-normal group-hover:text-[#F3E5AB] transition-colors">
                  {card.title}
                </h3>
                
                <p className="font-serif-classic italic text-sm text-slate-300 mt-1 font-light">
                  {card.subtitle}
                </p>

                <div className="mt-4 flex items-center text-[#D4AF37] opacity-80 group-hover:opacity-100 group-hover:translate-x-1 transition-all">
                  <ArrowRight className="w-5 h-5" />
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
