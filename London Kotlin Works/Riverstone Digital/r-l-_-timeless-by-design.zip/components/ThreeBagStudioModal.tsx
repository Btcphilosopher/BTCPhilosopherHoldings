'use client';

import React, { useState, useEffect, useRef } from 'react';
import { X, RotateCw, Sparkles, Check, Download, Layers } from 'lucide-react';
import { generateLeatherTextureCanvas, LeatherMaterialParams } from '@/lib/wasm-leather-sim';

interface ThreeBagStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (customizedItem: any) => void;
}

export const ThreeBagStudioModal: React.FC<ThreeBagStudioModalProps> = ({
  isOpen,
  onClose,
  onAddToCart
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [material, setMaterial] = useState<'calfskin' | 'saffiano' | 'saddle' | 'obsidian' | 'mahogany'>('calfskin');
  const [foilColor, setFoilColor] = useState<'gold' | 'silver' | 'deboss'>('gold');
  const [monogramText, setMonogramText] = useState('R.L.');
  const [lightAngle, setLightAngle] = useState(45);
  const [lightingIntensity, setLightingIntensity] = useState(1.0);
  const [isRotating, setIsRotating] = useState(false);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    if (!isOpen || !canvasRef.current) return;

    const params: LeatherMaterialParams = {
      material,
      foilColor,
      monogramText,
      lightAngle,
      lightingIntensity
    };

    generateLeatherTextureCanvas(canvasRef.current, params);
  }, [isOpen, material, foilColor, monogramText, lightAngle, lightingIntensity]);

  // Auto 360 degree rotation animation
  useEffect(() => {
    if (!isRotating) return;
    const interval = setInterval(() => {
      setLightAngle((prev) => (prev + 5) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, [isRotating]);

  if (!isOpen) return null;

  const handleAddCustomToCart = () => {
    const customBag = {
      id: `custom-rl-tote-${Date.now()}`,
      name: `BespoKe Grand Tote (${monogramText})`,
      subtitle: `Customized ${material.toUpperCase()} leather with ${foilColor} foil monogram`,
      category: 'handbags',
      price: 3150,
      image: '/images/category_handbags_1791012058850.jpg',
      colors: [{ name: material, hex: '#D4AF37' }],
      materials: [`Custom ${material} Leather`, `${foilColor.toUpperCase()} Foil Monogram '${monogramText}'`],
      dimensions: '15.5" W x 11.8" H x 6.2" D',
      description: `Bespoke Grand Tote with custom initial embossing '${monogramText}' in ${foilColor} foil.`,
      inStock: true,
      featured: true
    };

    onAddToCart(customBag);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0B0F17] border border-[#1E2638] w-full max-w-4xl rounded-lg shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh]">
        
        {/* Left: 3D Canvas Interactive Viewer */}
        <div className="w-full md:w-3/5 bg-[#05080E] p-6 flex flex-col items-center justify-center relative border-b md:border-b-0 md:border-r border-[#1E2638]">
          
          <div className="absolute top-4 left-4 flex items-center gap-2 text-xs font-mono text-[#D4AF37]">
            <Layers className="w-4 h-4 animate-spin" />
            <span>WASM 3D SHADER ACTIVE</span>
          </div>

          <button
            onClick={() => setIsRotating(!isRotating)}
            className={`absolute top-4 right-4 p-2 rounded text-xs font-mono flex items-center gap-1.5 transition-all ${
              isRotating ? 'bg-[#D4AF37] text-black font-bold' : 'bg-[#1E293B] text-slate-300 hover:text-white'
            }`}
          >
            <RotateCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
            <span>360° LIGHT ROTATE</span>
          </button>

          <canvas
            ref={canvasRef}
            width={440}
            height={400}
            className="w-full max-w-[400px] h-auto rounded border border-[#1E2638] shadow-2xl bg-black"
          />

          <p className="text-[11px] font-mono text-slate-500 mt-3 text-center">
            Lighting Angle: {lightAngle}° | Monogram Foil: {foilColor.toUpperCase()}
          </p>
        </div>

        {/* Right: Customization Controls */}
        <div className="w-full md:w-2/5 p-6 flex flex-col justify-between overflow-y-auto">
          
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-[#1E2638]">
              <div>
                <h3 className="font-serif-display text-xl text-white font-medium">3D EMBOSSING STUDIO</h3>
                <p className="text-xs text-[#D4AF37] mt-0.5 font-mono">Personalized Leather Crafts</p>
              </div>
              <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Monogram Input */}
            <div className="mt-6">
              <label className="block text-xs font-semibold tracking-wider text-slate-300 uppercase mb-2">
                Initials Monogram (Max 4 chars)
              </label>
              <input
                type="text"
                maxLength={4}
                value={monogramText}
                onChange={(e) => setMonogramText(e.target.value.toUpperCase())}
                className="w-full bg-[#111827] border border-[#1E2638] focus:border-[#D4AF37] rounded px-4 py-2 text-lg font-serif-display text-[#D4AF37] text-center tracking-[0.25em] outline-none"
                placeholder="R.L."
              />
            </div>

            {/* Foil Color Selection */}
            <div className="mt-6">
              <label className="block text-xs font-semibold tracking-wider text-slate-300 uppercase mb-2">
                Foil Stamping Color
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'gold', label: '24k Gold', color: '#D4AF37' },
                  { id: 'silver', label: 'Platinum Silver', color: '#E0E0E0' },
                  { id: 'deboss', label: 'Blind Deboss', color: '#333333' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setFoilColor(item.id as any)}
                    className={`px-3 py-2 text-xs font-medium rounded border flex items-center justify-center gap-1.5 transition-all ${
                      foilColor === item.id
                        ? 'border-[#D4AF37] bg-[#D4AF37]/10 text-white font-semibold'
                        : 'border-[#1E2638] text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Leather Material Swatches */}
            <div className="mt-6">
              <label className="block text-xs font-semibold tracking-wider text-slate-300 uppercase mb-2">
                Calfskin Leather Finish
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'calfskin', name: 'Equestrian Saddle', color: '#8B4513' },
                  { id: 'obsidian', name: 'Obsidian Matte', color: '#1A1A1A' },
                  { id: 'saffiano', name: 'Saffiano Grain', color: '#281E19' },
                  { id: 'mahogany', name: 'Deep Mahogany', color: '#501414' },
                ].map((mat) => (
                  <button
                    key={mat.id}
                    onClick={() => setMaterial(mat.id as any)}
                    className={`px-3 py-2 text-xs font-medium rounded border flex items-center gap-2 text-left transition-all ${
                      material === mat.id
                        ? 'border-[#D4AF37] bg-[#D4AF37]/10 text-white font-semibold'
                        : 'border-[#1E2638] text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: mat.color }} />
                    <span className="truncate">{mat.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Light Rotation Slider */}
            <div className="mt-6">
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>Studio Lighting Direction</span>
                <span className="font-mono">{lightAngle}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                value={lightAngle}
                onChange={(e) => setLightAngle(Number(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
              />
            </div>
          </div>

          {/* Bottom Action */}
          <div className="mt-8 pt-4 border-t border-[#1E2638]">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-slate-400">Total Bespoke Price:</span>
              <span className="font-serif-display text-2xl text-[#D4AF37] font-semibold">$3,150</span>
            </div>

            <button
              onClick={handleAddCustomToCart}
              className={`w-full py-3.5 text-xs font-semibold tracking-[0.2em] uppercase rounded flex items-center justify-center gap-2 transition-all ${
                added
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#D4AF37] text-black hover:bg-[#F3E5AB]'
              }`}
            >
              {added ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>BESPOKE TOTE ADDED TO BAG</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>ADD CUSTOMIZED TOTE TO BAG</span>
                </>
              )}
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
