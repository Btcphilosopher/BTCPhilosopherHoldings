'use client';

import React, { useState } from 'react';
import { X, MapPin, Phone, Calendar, Clock, Check } from 'lucide-react';

interface StoreLocatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const STORES = [
  {
    city: 'NEW YORK',
    name: 'Fifth Avenue Flagship',
    address: '720 Fifth Avenue, New York, NY 10019',
    phone: '+1 (212) 555-0192',
    hours: 'Mon-Sat: 10:00 - 19:00 | Sun: 12:00 - 18:00',
    coords: '40.7618° N, 73.9750° W'
  },
  {
    city: 'LONDON',
    name: 'New Bond Street House',
    address: '160 New Bond Street, London W1S 2UE',
    phone: '+44 20 7555 0184',
    hours: 'Mon-Sat: 10:00 - 18:30 | Sun: 12:00 - 18:00',
    coords: '51.5126° N, 0.1442° W'
  },
  {
    city: 'PARIS',
    name: 'Saint-Germain Salon',
    address: '173 Boulevard Saint-Germain, 75006 Paris',
    phone: '+33 1 42 55 01 22',
    hours: 'Mon-Sat: 10:30 - 19:00 | Sun: Closed',
    coords: '48.8539° N, 2.3330° E'
  },
  {
    city: 'TOKYO',
    name: 'Ginza Atelier',
    address: '5-7-15 Ginza, Chuo-ku, Tokyo 104-0061',
    phone: '+81 3 5555 0199',
    hours: 'Mon-Sun: 11:00 - 20:00',
    coords: '35.6712° N, 139.7650° E'
  }
];

export const StoreLocatorModal: React.FC<StoreLocatorModalProps> = ({ isOpen, onClose }) => {
  const [selectedStore, setSelectedStore] = useState(STORES[0]);
  const [bookingDate, setBookingDate] = useState('');
  const [booked, setBooked] = useState(false);

  if (!isOpen) return null;

  const handleBookAppointment = () => {
    if (!bookingDate) {
      alert('Please select an appointment date.');
      return;
    }
    setBooked(true);
    setTimeout(() => {
      setBooked(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0B0F17] border border-[#1E2638] w-full max-w-3xl rounded-lg shadow-2xl overflow-hidden flex flex-col md:flex-row">
        
        {/* Left: Store Selector List */}
        <div className="w-full md:w-1/2 p-6 border-b md:border-b-0 md:border-r border-[#1E2638] bg-[#0F172A]">
          <div className="flex items-center justify-between pb-4 border-b border-[#1E2638]">
            <h3 className="font-serif-display text-xl text-white">GLOBAL FLAGSHIPS</h3>
            <span className="text-xs text-[#D4AF37] font-mono">4 ATELIERS</span>
          </div>

          <div className="mt-4 space-y-3">
            {STORES.map((store) => (
              <button
                key={store.city}
                onClick={() => setSelectedStore(store)}
                className={`w-full text-left p-4 rounded border transition-all ${
                  selectedStore.city === store.city
                    ? 'border-[#D4AF37] bg-[#D4AF37]/10 text-white'
                    : 'border-[#1E2638] text-slate-400 hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold tracking-widest uppercase text-[#D4AF37]">
                    {store.city}
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">{store.coords.split(',')[0]}</span>
                </div>
                <p className="font-serif-display text-base text-white mt-1">{store.name}</p>
                <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{store.address}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Right: Selected Store Detail & Appointment Booking */}
        <div className="w-full md:w-1/2 p-6 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs font-semibold tracking-widest text-[#D4AF37] uppercase">
                  {selectedStore.city}
                </span>
                <h3 className="font-serif-display text-2xl text-white mt-1">{selectedStore.name}</h3>
              </div>
              <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-6 space-y-3 text-xs text-slate-300 font-light">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{selectedStore.address}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>{selectedStore.phone}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>{selectedStore.hours}</span>
              </div>
            </div>

            {/* Private Appointment Form */}
            <div className="mt-8 pt-6 border-t border-[#1E2638]">
              <h4 className="text-xs font-semibold tracking-wider text-slate-300 uppercase mb-3 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#D4AF37]" />
                <span>Book Private VIP Fitting</span>
              </h4>

              <input
                type="date"
                value={bookingDate}
                onChange={(e) => setBookingDate(e.target.value)}
                className="w-full bg-[#111827] border border-[#1E2638] focus:border-[#D4AF37] rounded px-4 py-2 text-xs text-white outline-none"
              />
            </div>
          </div>

          <button
            onClick={handleBookAppointment}
            className={`w-full mt-6 py-3.5 text-xs font-semibold tracking-[0.2em] uppercase rounded flex items-center justify-center gap-2 transition-all ${
              booked ? 'bg-emerald-600 text-white' : 'bg-[#D4AF37] text-black hover:bg-[#F3E5AB]'
            }`}
          >
            {booked ? (
              <>
                <Check className="w-4 h-4" />
                <span>VIP APPOINTMENT CONFIRMED</span>
              </>
            ) : (
              <span>CONFIRM PRIVATE FITTING</span>
            )}
          </button>

        </div>

      </div>
    </div>
  );
};
