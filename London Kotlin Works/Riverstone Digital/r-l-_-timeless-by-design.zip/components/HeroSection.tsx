'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Sparkles, Box, Grid } from 'lucide-react';

interface HeroSectionProps {
  onExplore: () => void;
  onOpenStudio: () => void;
  onTogglePixelMode: () => void;
  isPixelMode: boolean;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExplore,
  onOpenStudio,
  onTogglePixelMode,
  isPixelMode
}) => {
  return (
    <section className="relative w-full h-[85vh] min-h-[620px] max-h-[900px] flex items-center justify-between overflow-hidden bg-[#0B0F17]">
      
      {/* Background Photography with Scrim Gradient Overlay */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero_nyc_skyline_bag_1791012045340.jpg"
          alt="R L Luxury Tote Bag against NYC Sunset Skyline"
          fill
          priority
          className={`object-cover object-center transition-all duration-700 ${
            isPixelMode ? 'rendering-pixelated scale-105 contrast-125 saturate-150' : 'scale-100'
          }`}
          referrerPolicy="no-referrer"
        />
        {/* Soft Vignette and Vignette Scrim for Text Legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B0F17]/95 via-[#0B0F17]/50 to-transparent z-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-transparent to-black/40 z-10" />
      </div>

      {/* Top Right Coordinates Display */}
      <div className="absolute top-8 right-8 z-20 text-right hidden sm:block">
        <p className="text-xs font-semibold tracking-[0.25em] text-[#E2E8F0] uppercase">
          NEW YORK CITY
        </p>
        <p className="text-[11px] font-mono tracking-widest text-[#D4AF37]/90 mt-1">
          40.7128° N 74.0060° W
        </p>
        <div className="w-12 h-[1px] bg-[#D4AF37]/50 ml-auto mt-2" />
      </div>

      {/* Content Overlay */}
      <div className="relative z-20 max-w-[1440px] mx-auto px-6 md:px-12 w-full flex flex-col justify-center h-full pt-12">
        <div className="max-w-xl">
          
          {/* Kicker tag */}
          <div className="inline-flex items-center gap-2 text-xs font-medium tracking-[0.25em] text-[#D4AF37] uppercase mb-4">
            <span className="w-6 h-[1px] bg-[#D4AF37]" />
            <span>Autumn / Winter Collection</span>
          </div>

          {/* Main Display Headline */}
          <h1 className="font-serif-display text-5xl md:text-7xl lg:text-8xl tracking-tight text-white leading-[1.05] font-normal mb-4">
            TIMELESS <br />
            <span className="font-serif-classic italic font-light text-[#F3E5AB]">
              BY DESIGN
            </span>
          </h1>

          {/* Subheading */}
          <p className="text-lg md:text-xl font-serif-classic italic text-slate-300 tracking-wide font-light mb-8 max-w-md">
            American heritage. Modern expression.
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={onExplore}
              className="group inline-flex items-center gap-3 px-8 py-4 bg-white text-black text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#D4AF37] transition-all duration-300 shadow-xl"
            >
              <span>EXPLORE THE COLLECTION</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </button>

            <button
              onClick={onOpenStudio}
              className="inline-flex items-center gap-2 px-6 py-4 bg-black/60 backdrop-blur-md border border-[#334155] hover:border-[#D4AF37] text-slate-200 hover:text-white text-xs font-medium tracking-widest uppercase transition-all"
            >
              <Box className="w-4 h-4 text-[#D4AF37]" />
              <span>3D EMBOSSING STUDIO</span>
            </button>
          </div>

          {/* Heritage Mode Pixel Toggle Callout */}
          <div className="mt-8 pt-6 border-t border-white/10 flex items-center gap-4 text-xs text-slate-400">
            <button
              onClick={onTogglePixelMode}
              className="flex items-center gap-2 hover:text-[#D4AF37] transition-colors"
            >
              <Grid className="w-4 h-4 text-[#D4AF37]" />
              <span className="underline underline-offset-4">
                {isPixelMode ? 'Switch to Standard HD Render' : 'Activate HTML 8-Bit Heritage Pixel Art Mode'}
              </span>
            </button>
          </div>

        </div>
      </div>

    </section>
  );
};
