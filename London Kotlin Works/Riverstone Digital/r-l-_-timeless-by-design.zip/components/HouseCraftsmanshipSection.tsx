'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Award, Hammer, Compass, Feather } from 'lucide-react';

interface HouseCraftsmanshipSectionProps {
  onOpenStudio: () => void;
  isPixelMode?: boolean;
}

const CRAFT_STORIES = [
  {
    id: 'stitching',
    title: 'Saddle Stitching',
    icon: Hammer,
    description: 'Every seam is secured using double-needle saddle stitching—a technique unchanged for centuries that ensures unmatched strength and refined aesthetic.'
  },
  {
    id: 'burnishing',
    title: 'Hand-Burnished Edges',
    icon: Feather,
    description: 'Raw cut leather edges are hand-sanded and coated with beeswax, then burnished with wooden slickers until a glassy smooth sheen is achieved.'
  },
  {
    id: 'hardware',
    title: 'Cast Brass Hardware',
    icon: Award,
    description: 'Custom RL hardware is solid cast brass, finished with hand-brushed patinas that age with rich individual character over decades of use.'
  },
];

export const HouseCraftsmanshipSection: React.FC<HouseCraftsmanshipSectionProps> = ({
  onOpenStudio,
  isPixelMode
}) => {
  const [activeStory, setActiveStory] = useState(CRAFT_STORIES[0]);

  return (
    <section className="py-20 px-4 md:px-8 bg-[#0B0F17] text-white border-b border-[#1E2638]">
      <div className="max-w-[1440px] mx-auto">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          {/* Left: High-contrast Editorial Image */}
          <div className="relative aspect-[16/10] bg-[#05080E] rounded border border-[#1E2638] overflow-hidden shadow-2xl group">
            <Image
              src="/images/craftsmanship_leather_1791012107025.jpg"
              alt="Artisan Hand Stitching Leather"
              fill
              className={`object-cover object-center group-hover:scale-105 transition-transform duration-700 ${
                isPixelMode ? 'rendering-pixelated scale-105 contrast-125' : ''
              }`}
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <span className="text-[10px] font-mono tracking-widest text-[#D4AF37] uppercase">
                NEW YORK ATELIER
              </span>
              <p className="font-serif-display text-xl text-white mt-1">
                &ldquo;True luxury is not made in volume. It is born of patience and mastery.&rdquo;
              </p>
            </div>
          </div>

          {/* Right: Craftsmanship Narrative */}
          <div className="space-y-6">
            <div>
              <span className="text-xs font-semibold tracking-[0.25em] text-[#D4AF37] uppercase">
                THE HOUSE OF R L
              </span>
              <h2 className="font-serif-display text-4xl md:text-5xl text-white font-normal mt-2">
                Uncompromising <br />
                <span className="font-serif-classic italic text-[#F3E5AB]">
                  Heritage Leathercraft
                </span>
              </h2>
            </div>

            <p className="text-sm text-slate-300 font-light leading-relaxed">
              Founded on the enduring principles of American saddlery and equestrian mastery, R L represents a refined synthesis of historical leather craftsmanship and modern design purity. Each piece is constructed to withstand generations of journey and age gracefully.
            </p>

            {/* Interactive Craft Pillar Tabs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4">
              {CRAFT_STORIES.map((story) => {
                const IconComp = story.icon;
                return (
                  <button
                    key={story.id}
                    onClick={() => setActiveStory(story)}
                    className={`p-4 rounded border text-left transition-all ${
                      activeStory.id === story.id
                        ? 'border-[#D4AF37] bg-[#D4AF37]/10 text-white'
                        : 'border-[#1E2638] text-slate-400 hover:text-white'
                    }`}
                  >
                    <IconComp className="w-5 h-5 text-[#D4AF37] mb-2" />
                    <h4 className="font-serif-display text-sm text-white">{story.title}</h4>
                  </button>
                );
              })}
            </div>

            {/* Selected Pillar Detail */}
            <div className="p-5 bg-[#111827] border border-[#1E2638] rounded text-xs text-slate-300 font-light">
              <p>{activeStory.description}</p>
            </div>

            <button
              onClick={onOpenStudio}
              className="inline-flex items-center gap-3 px-8 py-4 bg-[#D4AF37] text-black font-semibold text-xs tracking-[0.2em] uppercase rounded hover:bg-[#F3E5AB] transition-colors"
            >
              <span>EXPERIENCE 3D EMBOSSING STUDIO</span>
            </button>

          </div>

        </div>

      </div>
    </section>
  );
};
