'use client';

import React, { useState } from 'react';
import { X, Sparkles, Send, Bot, User } from 'lucide-react';

interface StylistModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

export const StylistModal: React.FC<StylistModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      text: 'Greetings. I am your personal R L Heritage Concierge. How may I assist with your ensemble, leather selection, or gifting requirements today?'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch('/api/stylist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userMsg })
      });

      const data = await res.json();
      setMessages((prev) => [...prev, { role: 'assistant', text: data.text }]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'Our master stylists suggest pairing our Grand Manhattan Tote in Equestrian Calfskin with an Empire Cashmere Overcoat.'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0B0F17] border border-[#D4AF37]/40 w-full max-w-2xl rounded-lg shadow-2xl flex flex-col h-[600px] overflow-hidden">
        
        {/* Header */}
        <div className="p-4 bg-[#0F172A] border-b border-[#1E2638] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#D4AF37] animate-pulse" />
            <div>
              <h3 className="font-serif-display text-lg text-white">R L HERITAGE CONCIERGE</h3>
              <p className="text-[10px] text-[#D4AF37] font-mono">Gemini AI Bespoke Styling Assistant</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-md p-4 rounded-lg text-xs leading-relaxed font-light ${
                  m.role === 'user'
                    ? 'bg-[#D4AF37] text-black font-medium'
                    : 'bg-[#111827] border border-[#1E2638] text-slate-200'
                }`}
              >
                {m.text}
              </div>

              {m.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-[#1E293B] border border-[#334155] flex items-center justify-center text-slate-300 shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 items-center text-xs text-[#D4AF37] font-mono">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>Consulting R L Master Stylists...</span>
            </div>
          )}
        </div>

        {/* Suggested Prompts */}
        <div className="px-6 py-2 bg-[#0F172A] border-t border-[#1E2638] flex items-center gap-2 overflow-x-auto text-[11px] text-slate-400">
          <span className="shrink-0 text-slate-500">Try:</span>
          {[
            'What bag pairs best with a charcoal trench?',
            'Recommend a leather gift under $2000',
            'How to care for Equestrian Calfskin?'
          ].map((promptText, idx) => (
            <button
              key={idx}
              onClick={() => setInput(promptText)}
              className="px-2.5 py-1 bg-[#1E293B] hover:bg-[#334155] hover:text-[#D4AF37] rounded whitespace-nowrap transition-colors"
            >
              {promptText}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-[#0B0F17] border-t border-[#1E2638] flex gap-2">
          <input
            type="text"
            placeholder="Ask your concierge about outfits, leather, or gifting..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-[#111827] border border-[#1E2638] focus:border-[#D4AF37] rounded px-4 py-2.5 text-xs text-white outline-none"
          />
          <button
            onClick={handleSend}
            disabled={loading}
            className="px-5 py-2.5 bg-[#D4AF37] text-black hover:bg-[#F3E5AB] font-semibold text-xs rounded transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
