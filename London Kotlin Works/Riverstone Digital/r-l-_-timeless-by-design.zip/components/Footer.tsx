'use client';

import React, { useState } from 'react';
import { Instagram, Youtube, ArrowRight, Check } from 'lucide-react';

interface FooterProps {
  onOpenStores: () => void;
  onSelectCategory: (cat: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenStores, onSelectCategory }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <footer className="bg-[#070A10] text-slate-400 py-12 px-6 md:px-12 border-t border-[#1E2638]">
      <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        
        {/* Brand & City */}
        <div className="flex items-center gap-6">
          <span className="font-serif-display text-3xl tracking-[0.2em] font-semibold text-white">
            R L
          </span>
          <span className="text-xs font-mono tracking-widest text-slate-500 uppercase border-l border-[#1E2638] pl-6">
            NEW YORK, NY
          </span>
        </div>

        {/* Center Links */}
        <nav className="flex flex-wrap items-center justify-center gap-6 md:gap-8 text-xs font-medium tracking-[0.18em] uppercase text-slate-300">
          <button onClick={() => onSelectCategory('all')} className="hover:text-[#D4AF37] transition-colors">
            ABOUT
          </button>
          <button onClick={() => onSelectCategory('all')} className="hover:text-[#D4AF37] transition-colors">
            SUSTAINABILITY
          </button>
          <button onClick={onOpenStores} className="hover:text-[#D4AF37] transition-colors">
            STORES
          </button>
          <button onClick={() => onSelectCategory('all')} className="hover:text-[#D4AF37] transition-colors">
            CONTACT
          </button>
        </nav>

        {/* Right Socials & Newsletter */}
        <div className="flex flex-col sm:flex-row items-center gap-6">
          
          {/* Social Icons */}
          <div className="flex items-center gap-4 text-slate-400">
            <a href="#instagram" className="hover:text-[#D4AF37] transition-colors" aria-label="Instagram">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="#pinterest" className="hover:text-[#D4AF37] transition-colors font-serif italic text-sm font-bold" aria-label="Pinterest">
              P
            </a>
            <a href="#youtube" className="hover:text-[#D4AF37] transition-colors" aria-label="YouTube">
              <Youtube className="w-4 h-4" />
            </a>
            <a href="#x" className="hover:text-[#D4AF37] transition-colors font-sans text-xs font-bold" aria-label="X">
              𝕏
            </a>
          </div>

          {/* Newsletter Input */}
          <form onSubmit={handleSubscribe} className="relative flex items-center border-b border-slate-600 focus-within:border-[#D4AF37] pb-1">
            <input
              type="email"
              placeholder="JOIN OUR NEWSLETTER"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-transparent text-xs text-white placeholder-slate-500 font-medium tracking-widest uppercase outline-none w-48 pr-6"
            />
            <button type="submit" className="text-slate-400 hover:text-[#D4AF37] transition-colors" aria-label="Subscribe">
              {subscribed ? <Check className="w-4 h-4 text-emerald-400" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          </form>

        </div>

      </div>

      <div className="max-w-[1440px] mx-auto mt-8 pt-6 border-t border-[#131B2E] flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-600 font-mono">
        <p>© 2026 R L Heritage Inc. All Rights Reserved.</p>
        <div className="flex gap-4 mt-2 sm:mt-0">
          <span>Privacy Policy</span>
          <span>·</span>
          <span>Terms of Heritage</span>
          <span>·</span>
          <span>Cookie Preferences</span>
        </div>
      </div>
    </footer>
  );
};
