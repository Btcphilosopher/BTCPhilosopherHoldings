'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Grid, Sparkles, Download, Layers, Eye } from 'lucide-react';
import { Product } from '@/lib/products';

interface PixelArtCraftsmanshipEngineProps {
  product?: Product;
  isPixelMode: boolean;
  onClose?: () => void;
}

export const PixelArtCraftsmanshipEngine: React.FC<PixelArtCraftsmanshipEngineProps> = ({
  product,
  isPixelMode,
  onClose
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [pixelSize, setPixelSize] = useState<number>(12); // 8, 12, 16, 24
  const [colorPalette, setColorPalette] = useState<'heritage' | 'amber' | 'monochrome'>('heritage');

  useEffect(() => {
    if (!isPixelMode || !canvasRef.current || !product) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = product.image;

    img.onload = () => {
      const w = canvas.width;
      const h = canvas.height;

      // Draw original downscaled image
      const offCanvas = document.createElement('canvas');
      const offCtx = offCanvas.getContext('2d');
      if (!offCtx) return;

      const sw = Math.floor(w / pixelSize);
      const sh = Math.floor(h / pixelSize);

      offCanvas.width = sw;
      offCanvas.height = sh;

      offCtx.drawImage(img, 0, 0, sw, sh);

      const imgData = offCtx.getImageData(0, 0, sw, sh);
      const data = imgData.data;

      ctx.clearRect(0, 0, w, h);
      ctx.imageSmoothingEnabled = false;

      // Render Pixel Grid in HTML Canvas
      for (let y = 0; y < sh; y++) {
        for (let x = 0; x < sw; x++) {
          const idx = (y * sw + x) * 4;
          let r = data[idx];
          let g = data[idx + 1];
          let b = data[idx + 2];

          // Apply Heritage Color Quantization
          if (colorPalette === 'amber') {
            const avg = (r + g + b) / 3;
            r = Math.min(255, avg * 1.2);
            g = Math.min(255, avg * 0.9);
            b = Math.min(255, avg * 0.3);
          } else if (colorPalette === 'monochrome') {
            const avg = (r + g + b) / 3;
            r = avg; g = avg; b = avg;
          }

          ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
          ctx.fillRect(x * pixelSize, y * pixelSize, pixelSize, pixelSize);

          // Draw subtle 1px grid line for HTML pixel matrix style
          ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
          ctx.strokeRect(x * pixelSize, y * pixelSize, pixelSize, pixelSize);
        }
      }

      // Add HTML Pixel Stamp Emblem
      ctx.font = '10px "Press Start 2P", monospace';
      ctx.fillStyle = '#D4AF37';
      ctx.fillText('RL 8-BIT', 10, h - 15);
    };
  }, [product, isPixelMode, pixelSize, colorPalette]);

  if (!isPixelMode || !product) return null;

  const handleDownloadPixelArt = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = `rl-pixel-art-${product.id}.png`;
    link.href = canvasRef.current.toDataURL();
    link.click();
  };

  return (
    <div className="bg-[#0D121F] border border-[#D4AF37]/40 rounded-lg p-4 my-4 font-pixel text-slate-200">
      
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#1E2638] gap-2">
        <div className="flex items-center gap-2 text-xs text-[#D4AF37]">
          <Grid className="w-4 h-4 animate-pulse" />
          <span>HTML 8-BIT HERITAGE PIXEL ENGINE</span>
        </div>

        <div className="flex items-center gap-2 text-[10px]">
          <span className="text-slate-400">PIXEL SIZE:</span>
          {[8, 12, 16].map((size) => (
            <button
              key={size}
              onClick={() => setPixelSize(size)}
              className={`px-2 py-1 rounded border ${
                pixelSize === size ? 'bg-[#D4AF37] text-black border-[#D4AF37] font-bold' : 'border-[#1E2638] hover:border-[#D4AF37]'
              }`}
            >
              {size}PX
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 flex flex-col md:flex-row gap-4 items-center justify-center">
        <canvas
          ref={canvasRef}
          width={320}
          height={240}
          className="rendering-pixelated rounded border-2 border-[#D4AF37] shadow-[0_0_20px_rgba(212,175,55,0.2)] bg-black"
        />

        <div className="text-xs space-y-3 max-w-xs">
          <p className="text-slate-300 font-sans text-xs">
            A retro homage to vintage American craftsmanship. Every pixel represents hand-cut leather grain and burnished wax threading.
          </p>

          <div className="flex flex-wrap gap-2 pt-2">
            <button
              onClick={() => setColorPalette('heritage')}
              className={`px-2 py-1 text-[10px] rounded border ${colorPalette === 'heritage' ? 'bg-[#D4AF37] text-black font-bold' : 'border-[#1E2638]'}`}
            >
              HERITAGE
            </button>
            <button
              onClick={() => setColorPalette('amber')}
              className={`px-2 py-1 text-[10px] rounded border ${colorPalette === 'amber' ? 'bg-[#D4AF37] text-black font-bold' : 'border-[#1E2638]'}`}
            >
              AMBER DITHER
            </button>
            <button
              onClick={() => setColorPalette('monochrome')}
              className={`px-2 py-1 text-[10px] rounded border ${colorPalette === 'monochrome' ? 'bg-[#D4AF37] text-black font-bold' : 'border-[#1E2638]'}`}
            >
              MONO NOIR
            </button>
          </div>

          <button
            onClick={handleDownloadPixelArt}
            className="w-full mt-2 py-2 bg-[#D4AF37]/20 border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition-all text-[10px] font-bold flex items-center justify-center gap-2"
          >
            <Download className="w-3.5 h-3.5" />
            <span>EXPORT 8-BIT PIXEL ART PNG</span>
          </button>
        </div>
      </div>

    </div>
  );
};
