export interface Product {
  id: string;
  name: string;
  category: 'men' | 'women' | 'knitwear' | 'accessories';
  subCategory?: string;
  price: number;
  formattedPrice: string;
  color: string;
  colorHex: string;
  availableColors: { name: string; hex: string }[];
  sizes: string[];
  image: string;
  galleryImages: string[];
  description: string;
  materials: string;
  craftsmanship: string;
  origin: string;
  featured?: boolean;
}

export interface CartItem {
  id: string; // unique item id = `${productId}-${selectedSize}-${selectedColor}`
  product: Product;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
}

export interface StoreLocation {
  id: string;
  city: string;
  country: string;
  name: string;
  address: string;
  postalCode: string;
  phone: string;
  hours: string;
  appointmentAvailable: boolean;
}
