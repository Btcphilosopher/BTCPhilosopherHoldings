import React from 'react';
import Link from 'next/link';

interface CategoryItem {
  id: string;
  name: string;
  image: string;
  href: string;
  alt: string;
}

const CATEGORIES: CategoryItem[] = [
  {
    id: 'men',
    name: 'Men',
    image: '/images/cat_men_tailoring_1792401364296.jpg',
    href: '/men',
    alt: 'Brunello Cucinelli Men Sartorial Tailoring',
  },
  {
    id: 'women',
    name: 'Women',
    image: '/images/cat_women_cashmere_1792401364617.jpg',
    href: '/women',
    alt: 'Brunello Cucinelli Women Collection',
  },
  {
    id: 'knitwear',
    name: 'Knitwear',
    image: '/images/cat_knitwear_detail_1792401365041.jpg',
    href: '/knitwear',
    alt: 'Brunello Cucinelli Fine Cashmere Knitwear Detail',
  },
  {
    id: 'accessories',
    name: 'Accessories',
    image: '/images/cat_accessories_leather_1792401365943.jpg',
    href: '/accessories',
    alt: 'Brunello Cucinelli Leather Goods & Travel Accessories',
  },
  {
    id: 'brand',
    name: 'The Brand',
    image: '/images/cat_brand_solomeo_1792401365673.jpg',
    href: '/brand',
    alt: 'The Historic Medieval Hamlet of Solomeo',
  },
];

export default function CategoryGrid() {
  return (
    <section className="w-full bg-white py-12 sm:py-16 lg:py-20 border-b border-[#D8CCBC]/30">
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12">
        {/* 5-column grid on desktop, 3-col on tablet, 2-col on mobile */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6 lg:gap-7">
          {CATEGORIES.map((cat, index) => (
            <Link
              key={cat.id}
              href={cat.href}
              className={`group flex flex-col items-center text-center focus:outline-none ${
                index === 4 ? 'col-span-2 md:col-span-1' : ''
              }`}
            >
              {/* Image Frame with subtle hover zoom */}
              <div className="w-full aspect-4/3 sm:aspect-[4/3.5] overflow-hidden bg-[#F5F2EC] mb-4 sm:mb-5 relative">
                <img
                  src={cat.image}
                  alt={cat.alt}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
                  loading="lazy"
                />
              </div>

              {/* Category Name */}
              <h2 className="text-[12px] sm:text-[13px] font-medium tracking-[0.24em] uppercase text-[#292723] group-hover:text-[#756656] transition-colors mb-1.5">
                {cat.name}
              </h2>

              {/* Discover Link + Minimal Arrow */}
              <div className="flex items-center gap-1.5 text-[10px] font-medium tracking-[0.22em] uppercase text-[#756656] group-hover:text-[#292723] transition-colors">
                <span>Discover</span>
                <span className="text-xs transition-transform duration-300 group-hover:translate-x-1">
                  →
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
