'use client';

import React, { useEffect } from 'react';
import Link from 'next/link';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { useStore } from '@/lib/store-context';
import { PRODUCTS } from '@/data/products';

export default function WishlistDrawer() {
  const {
    wishlist,
    isWishlistOpen,
    setIsWishlistOpen,
    toggleWishlist,
    addToBag,
  } = useStore();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isWishlistOpen) {
        setIsWishlistOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isWishlistOpen, setIsWishlistOpen]);

  if (!isWishlistOpen) return null;

  const savedProducts = PRODUCTS.filter((p) => wishlist.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true" aria-label="Wishlist">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity duration-300"
        onClick={() => setIsWishlistOpen(false)}
      />

      {/* Drawer */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md sm:max-w-lg bg-[#F5F2EC] text-[#292723] flex flex-col shadow-2xl">
          
          {/* Header */}
          <div className="px-6 py-5 border-b border-[#D8CCBC]/50 flex items-center justify-between bg-white/50">
            <div>
              <h2 className="font-serif-luxury text-xl sm:text-2xl font-normal tracking-wide">
                Saved Pieces
              </h2>
              <p className="text-[11px] font-medium tracking-[0.2em] uppercase text-[#756656] mt-0.5">
                {savedProducts.length} {savedProducts.length === 1 ? 'Creation' : 'Creations'} in Wishlist
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsWishlistOpen(false)}
              className="p-2 text-[#756656] hover:text-[#292723] transition-colors focus:outline-none"
              aria-label="Close wishlist"
            >
              <X size={20} />
            </button>
          </div>

          {/* List Content */}
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
            {savedProducts.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16">
                <div className="w-16 h-16 rounded-full bg-[#EAE4DA] flex items-center justify-center text-[#756656] mb-4">
                  <Heart size={24} strokeWidth={1.5} />
                </div>
                <h3 className="font-serif-luxury text-xl text-[#292723] font-normal mb-2">
                  No saved pieces yet
                </h3>
                <p className="text-xs text-[#756656] max-w-xs mb-6 font-light">
                  Tap the heart icon on any piece to save your favorite garments and accessories to your private list.
                </p>
                <button
                  type="button"
                  onClick={() => setIsWishlistOpen(false)}
                  className="px-6 py-2.5 bg-[#292723] text-white text-[11px] font-medium tracking-[0.22em] uppercase hover:bg-[#756656] transition-colors"
                >
                  Explore Collection
                </button>
              </div>
            ) : (
              <ul className="divide-y divide-[#D8CCBC]/40">
                {savedProducts.map((product) => (
                  <li key={product.id} className="py-5 flex gap-4 first:pt-0 last:pb-0">
                    {/* Image */}
                    <div className="w-20 sm:w-24 aspect-4/3 sm:aspect-square bg-[#EAE4DA] overflow-hidden shrink-0 border border-[#D8CCBC]/50">
                      <img
                        src={product.image}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <h4 className="font-serif-luxury text-base sm:text-lg text-[#292723] leading-snug">
                            <Link
                              href={`/product/${product.id}`}
                              onClick={() => setIsWishlistOpen(false)}
                              className="hover:text-[#756656] transition-colors"
                            >
                              {product.name}
                            </Link>
                          </h4>
                          <span className="font-mono text-sm font-medium text-[#292723] tabular-nums ml-2">
                            {product.formattedPrice}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#756656] mt-0.5">
                          {product.category.toUpperCase()} · {product.color}
                        </p>
                      </div>

                      <div className="flex items-center justify-between mt-4">
                        <button
                          type="button"
                          onClick={() => {
                            addToBag(product, product.sizes[0], product.color, 1);
                          }}
                          className="px-3 py-1.5 bg-[#292723] text-white text-[10px] font-medium tracking-[0.2em] uppercase hover:bg-[#756656] transition-colors flex items-center gap-1.5"
                        >
                          <ShoppingBag size={12} />
                          <span>Move to Bag</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleWishlist(product.id)}
                          className="text-[11px] text-[#756656] hover:text-[#B91C1C] flex items-center gap-1 transition-colors"
                          aria-label={`Remove ${product.name} from wishlist`}
                        >
                          <Trash2 size={13} />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          {savedProducts.length > 0 && (
            <div className="p-6 bg-white border-t border-[#D8CCBC]/60">
              <button
                type="button"
                onClick={() => {
                  savedProducts.forEach((p) => {
                    addToBag(p, p.sizes[0], p.color, 1);
                  });
                }}
                className="w-full py-3 bg-[#EAE4DA] text-[#292723] text-[11px] font-medium tracking-[0.24em] uppercase hover:bg-[#D8CCBC] transition-colors"
              >
                Add All Saved Pieces to Bag
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
