'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { Search, X, ArrowRight } from 'lucide-react';
import { useStore } from '@/lib/store-context';
import { PRODUCTS } from '@/data/products';

export default function SearchOverlay() {
  const { isSearchOpen, setIsSearchOpen } = useStore();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      const timer = setTimeout(() => inputRef.current?.focus(), 100);
      return () => clearTimeout(timer);
    }
  }, [isSearchOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSearchOpen) {
        setIsSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, setIsSearchOpen]);

  if (!isSearchOpen) return null;

  const trimmed = query.trim().toLowerCase();
  const filtered = trimmed
    ? PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(trimmed) ||
          p.category.toLowerCase().includes(trimmed) ||
          p.description.toLowerCase().includes(trimmed) ||
          p.materials.toLowerCase().includes(trimmed)
      )
    : [];

  const quickSearches = [
    'Cashmere Crewneck',
    'Linen Jacket',
    'Leather Weekender',
    'Cashmere Cardigan',
    'Suede Loafers',
  ];

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-[#F5F2EC]/98 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label="Search Collection"
    >
      <div className="max-w-[1200px] mx-auto px-6 sm:px-12 py-10 min-h-screen flex flex-col">
        
        {/* Top Bar with Close */}
        <div className="flex items-center justify-between pb-8 border-b border-[#D8CCBC]/40">
          <span className="font-serif-luxury tracking-[0.24em] text-sm uppercase text-[#756656]">
            Brunello Cucinelli · Search Collection
          </span>
          <button
            type="button"
            onClick={() => setIsSearchOpen(false)}
            className="p-2 text-[#756656] hover:text-[#292723] transition-colors"
            aria-label="Close search"
          >
            <X size={24} strokeWidth={1.5} />
          </button>
        </div>

        {/* Input Bar */}
        <div className="py-12 sm:py-16 max-w-3xl mx-auto w-full">
          <div className="relative border-b-2 border-[#292723] pb-4 flex items-center">
            <Search size={26} className="text-[#756656] mr-4 shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search knitwear, tailoring, leather goods..."
              className="w-full bg-transparent font-serif-luxury text-2xl sm:text-3xl text-[#292723] placeholder-[#A99A87] focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="p-1 text-[#756656] hover:text-[#292723]"
                aria-label="Clear query"
              >
                <X size={18} />
              </button>
            )}
          </div>

          {/* Quick Suggestions */}
          {!query && (
            <div className="mt-8">
              <p className="text-[10px] font-medium tracking-[0.24em] uppercase text-[#756656] mb-3">
                Suggested Searches
              </p>
              <div className="flex flex-wrap gap-2">
                {quickSearches.map((term) => (
                  <button
                    key={term}
                    type="button"
                    onClick={() => setQuery(term)}
                    className="px-3.5 py-1.5 bg-white border border-[#D8CCBC] text-[11px] font-medium tracking-wider text-[#292723] hover:border-[#756656] hover:bg-[#EAE4DA] transition-colors"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Results Area */}
        <div className="flex-1 max-w-4xl mx-auto w-full pb-16">
          {query && filtered.length > 0 && (
            <div>
              <p className="text-[11px] font-medium tracking-[0.22em] uppercase text-[#756656] mb-6">
                Found {filtered.length} {filtered.length === 1 ? 'Creation' : 'Creations'}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {filtered.map((item) => (
                  <Link
                    key={item.id}
                    href={`/product/${item.id}`}
                    onClick={() => setIsSearchOpen(false)}
                    className="group bg-white p-4 border border-[#D8CCBC]/40 hover:border-[#756656] transition-all"
                  >
                    <div className="aspect-4/3 w-full overflow-hidden bg-[#F5F2EC] mb-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <p className="text-[10px] tracking-wider uppercase text-[#756656]">
                      {item.category}
                    </p>
                    <h4 className="font-serif-luxury text-base text-[#292723] group-hover:text-[#756656] transition-colors">
                      {item.name}
                    </h4>
                    <p className="font-mono text-xs text-[#292723] mt-1 tabular-nums">
                      {item.formattedPrice}
                    </p>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {query && filtered.length === 0 && (
            <div className="text-center py-12">
              <p className="font-serif-luxury text-2xl text-[#292723] mb-2">
                No matching creations found for &ldquo;{query}&rdquo;
              </p>
              <p className="text-xs text-[#756656] max-w-sm mx-auto font-light mb-6">
                Please refine your search terms or explore our curated categories below.
              </p>
              <div className="flex justify-center gap-4 text-xs font-medium tracking-widest uppercase">
                <Link
                  href="/knitwear"
                  onClick={() => setIsSearchOpen(false)}
                  className="hover:underline text-[#756656]"
                >
                  Knitwear
                </Link>
                <span>·</span>
                <Link
                  href="/men"
                  onClick={() => setIsSearchOpen(false)}
                  className="hover:underline text-[#756656]"
                >
                  Men
                </Link>
                <span>·</span>
                <Link
                  href="/women"
                  onClick={() => setIsSearchOpen(false)}
                  className="hover:underline text-[#756656]"
                >
                  Women
                </Link>
                <span>·</span>
                <Link
                  href="/accessories"
                  onClick={() => setIsSearchOpen(false)}
                  className="hover:underline text-[#756656]"
                >
                  Accessories
                </Link>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
