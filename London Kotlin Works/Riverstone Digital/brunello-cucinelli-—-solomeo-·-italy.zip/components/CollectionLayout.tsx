'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Heart, SlidersHorizontal } from 'lucide-react';
import { Product } from '@/lib/types';
import { useStore } from '@/lib/store-context';

interface CollectionLayoutProps {
  title: string;
  eyebrow: string;
  description: string;
  heroImage: string;
  products: Product[];
  categories?: string[];
}

export default function CollectionLayout({
  title,
  eyebrow,
  description,
  heroImage,
  products,
  categories = [],
}: CollectionLayoutProps) {
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');
  const { toggleWishlist, isInWishlist } = useStore();

  // Filter products
  const filtered = selectedSubCategory === 'All'
    ? products
    : products.filter((p) => p.subCategory === selectedSubCategory || p.category === selectedSubCategory.toLowerCase());

  // Sort products
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
  });

  return (
    <div className="pt-24 md:pt-28 pb-20 bg-[#F5F2EC]">
      {/* Editorial Collection Hero Banner */}
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 mb-12 sm:mb-16">
        <div className="relative w-full h-[320px] sm:h-[420px] lg:h-[480px] overflow-hidden bg-[#292723]">
          <img
            src={heroImage}
            alt={title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex flex-col justify-end p-8 sm:p-12 lg:p-16 text-white">
            <p className="text-[10px] sm:text-[11px] font-medium tracking-[0.28em] uppercase text-white/80 mb-3">
              {eyebrow}
            </p>
            <h1 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-light tracking-wide mb-3">
              {title}
            </h1>
            <p className="text-xs sm:text-sm text-white/85 max-w-xl font-light leading-relaxed">
              {description}
            </p>
          </div>
        </div>
      </div>

      {/* Filter and Sort Toolbar */}
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 mb-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#D8CCBC]/60">
          
          {/* Subcategory Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1 sm:gap-2 text-[11px] font-medium tracking-[0.2em] uppercase">
            <button
              type="button"
              onClick={() => setSelectedSubCategory('All')}
              className={`px-3 py-1.5 transition-colors ${
                selectedSubCategory === 'All'
                  ? 'bg-[#292723] text-white'
                  : 'text-[#756656] hover:text-[#292723] bg-white/60'
              }`}
            >
              All Pieces ({products.length})
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedSubCategory(cat)}
                className={`px-3 py-1.5 transition-colors ${
                  selectedSubCategory === cat
                    ? 'bg-[#292723] text-white'
                    : 'text-[#756656] hover:text-[#292723] bg-white/60'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-3 self-end md:self-auto text-xs text-[#756656]">
            <span className="flex items-center gap-1.5 tracking-wider uppercase text-[10px]">
              <SlidersHorizontal size={12} />
              Sort By:
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white border border-[#D8CCBC] px-3 py-1.5 text-xs text-[#292723] focus:outline-none"
            >
              <option value="featured">Featured Curations</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>

        </div>
      </div>

      {/* Products Grid */}
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12">
        {sorted.length === 0 ? (
          <div className="text-center py-20 bg-white border border-[#D8CCBC]/40">
            <h3 className="font-serif-luxury text-xl text-[#292723] mb-2">
              No creations available in this category
            </h3>
            <p className="text-xs text-[#756656] mb-4">Please select another subcategory or view all pieces.</p>
            <button
              type="button"
              onClick={() => setSelectedSubCategory('All')}
              className="px-6 py-2 bg-[#292723] text-white text-[11px] tracking-widest uppercase"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
            {sorted.map((product) => {
              const isSaved = isInWishlist(product.id);

              return (
                <div
                  key={product.id}
                  className="group bg-white border border-[#D8CCBC]/40 p-5 flex flex-col justify-between hover:border-[#756656] transition-all duration-300"
                >
                  <div>
                    {/* Thumbnail */}
                    <div className="relative aspect-4/3 w-full overflow-hidden bg-[#F5F2EC] mb-4">
                      <Link href={`/product/${product.id}`} className="block w-full h-full">
                        <img
                          src={product.image}
                          alt={product.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover object-center group-hover:scale-103 transition-transform duration-500"
                          loading="lazy"
                        />
                      </Link>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          toggleWishlist(product.id);
                        }}
                        className="absolute top-2.5 right-2.5 p-1.5 bg-white/90 text-[#292723] rounded-full shadow-xs hover:bg-white transition-colors"
                        aria-label="Save to wishlist"
                      >
                        <Heart
                          size={14}
                          strokeWidth={1.5}
                          className={isSaved ? 'fill-[#756656] text-[#756656]' : 'text-[#292723]'}
                        />
                      </button>
                    </div>

                    {/* Info */}
                    <div className="flex items-center justify-between text-[10px] tracking-wider uppercase text-[#756656] mb-1">
                      <span>{product.subCategory || product.category}</span>
                      <span>{product.color}</span>
                    </div>

                    <h3 className="font-serif-luxury text-base sm:text-lg text-[#292723] group-hover:text-[#756656] transition-colors line-clamp-1 mb-1">
                      <Link href={`/product/${product.id}`}>{product.name}</Link>
                    </h3>

                    <p className="text-xs text-[#756656] line-clamp-2 font-light leading-relaxed mb-4">
                      {product.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#D8CCBC]/30 flex items-center justify-between">
                    <span className="font-mono text-xs sm:text-sm font-medium text-[#292723] tabular-nums">
                      {product.formattedPrice}
                    </span>
                    <Link
                      href={`/product/${product.id}`}
                      className="text-[10px] font-medium tracking-[0.2em] uppercase text-[#756656] hover:text-[#292723] flex items-center gap-1"
                    >
                      <span>Explore</span>
                      <span>→</span>
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
