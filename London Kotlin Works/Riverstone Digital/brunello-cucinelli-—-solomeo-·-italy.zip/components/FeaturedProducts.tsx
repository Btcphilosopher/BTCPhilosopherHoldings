'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Heart, Plus } from 'lucide-react';
import { PRODUCTS } from '@/data/products';
import { Product } from '@/lib/types';
import { useStore } from '@/lib/store-context';

export default function FeaturedProducts() {
  const [activeFilter, setActiveFilter] = useState<'all' | 'men' | 'women' | 'knitwear' | 'accessories'>('all');
  const { toggleWishlist, isInWishlist, addToBag } = useStore();

  const filteredProducts = activeFilter === 'all'
    ? PRODUCTS
    : PRODUCTS.filter((p) => p.category === activeFilter);

  const handleQuickAdd = (e: React.MouseEvent, product: Product) => {
    e.preventDefault();
    e.stopPropagation();
    // Quick add default first size and color
    const defaultSize = product.sizes[0] || 'Standard';
    addToBag(product, defaultSize, product.color, 1);
  };

  return (
    <section className="w-full bg-[#F5F2EC] py-16 sm:py-24 border-b border-[#D8CCBC]/40">
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
          <p className="text-[10px] sm:text-[11px] font-medium tracking-[0.28em] uppercase text-[#756656] mb-3">
            Spring · Summer Collection
          </p>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl text-[#292723] font-light tracking-wide mb-3">
            The New Season
          </h2>
          <p className="text-xs sm:text-sm text-[#756656] font-light max-w-md mx-auto">
            A study in texture, proportion and timeless elegance. Handcrafted with fine natural fibres in Solomeo.
          </p>

          {/* Category Filter Controls */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 mt-8 text-[11px] font-medium tracking-[0.2em] uppercase">
            {(['all', 'men', 'women', 'knitwear', 'accessories'] as const).map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`px-4 py-1.5 transition-all rounded-xs ${
                  activeFilter === filter
                    ? 'bg-[#292723] text-white'
                    : 'text-[#756656] hover:text-[#292723] hover:bg-[#EAE4DA]/50'
                }`}
              >
                {filter === 'all' ? 'All Pieces' : filter}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid: 3 columns on desktop, 2 on tablet, 1-2 on mobile */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10 lg:gap-12">
          {filteredProducts.map((product) => {
            const isSaved = isInWishlist(product.id);

            return (
              <div
                key={product.id}
                className="group flex flex-col bg-white border border-[#D8CCBC]/40 p-5 sm:p-6 transition-all duration-300 hover:shadow-xs hover:border-[#A99A87]"
              >
                {/* Product Image Frame */}
                <div className="relative aspect-4/3 w-full overflow-hidden bg-[#F5F2EC] mb-5">
                  <Link href={`/product/${product.id}`} className="block w-full h-full">
                    <img
                      src={product.image}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-103"
                      loading="lazy"
                    />
                  </Link>

                  {/* Wishlist Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      toggleWishlist(product.id);
                    }}
                    className="absolute top-3 right-3 p-2 bg-white/90 hover:bg-white text-[#292723] rounded-full shadow-xs transition-colors"
                    aria-label={isSaved ? 'Remove from wishlist' : 'Save to wishlist'}
                  >
                    <Heart
                      size={15}
                      strokeWidth={1.5}
                      className={isSaved ? 'fill-[#756656] text-[#756656]' : 'text-[#292723]'}
                    />
                  </button>

                  {/* Quick Add Overlay on Hover */}
                  <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex justify-end">
                    <button
                      type="button"
                      onClick={(e) => handleQuickAdd(e, product)}
                      className="px-3 py-1.5 bg-white text-[#292723] text-[10px] font-medium tracking-[0.2em] uppercase flex items-center gap-1.5 shadow-sm hover:bg-[#F5F2EC]"
                    >
                      <Plus size={12} />
                      <span>Quick Add</span>
                    </button>
                  </div>
                </div>

                {/* Product Metadata */}
                <div className="flex flex-col flex-1 justify-between">
                  <div>
                    {/* Category & Color */}
                    <div className="flex items-center justify-between text-[11px] text-[#756656] font-medium tracking-wider uppercase mb-1">
                      <span>{product.category}</span>
                      <span>{product.color}</span>
                    </div>

                    {/* Product Name */}
                    <h3 className="font-serif-luxury text-[17px] sm:text-[18px] text-[#292723] font-normal leading-snug group-hover:text-[#756656] transition-colors mb-2">
                      <Link href={`/product/${product.id}`}>{product.name}</Link>
                    </h3>

                    {/* Short Description */}
                    <p className="text-xs text-[#756656] line-clamp-2 leading-relaxed font-light mb-4">
                      {product.description}
                    </p>
                  </div>

                  {/* Price & Action Row */}
                  <div className="pt-3 border-t border-[#D8CCBC]/30 flex items-center justify-between">
                    <span className="text-sm font-medium text-[#292723] font-mono tabular-nums">
                      {product.formattedPrice}
                    </span>

                    <Link
                      href={`/product/${product.id}`}
                      className="text-[10px] font-medium tracking-[0.22em] uppercase text-[#756656] hover:text-[#292723] flex items-center gap-1 transition-colors"
                    >
                      <span>View Details</span>
                      <span>→</span>
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Editorial Callout */}
        <div className="mt-16 text-center">
          <p className="text-xs text-[#756656] font-serif-luxury italic mb-4">
            &ldquo;True luxury is about creating timeless harmony between human craftsmanship and nature.&rdquo;
          </p>
          <Link
            href="/men"
            className="inline-flex items-center gap-2 text-[11px] font-medium tracking-[0.22em] uppercase text-[#292723] hover:text-[#756656] border-b border-[#292723] pb-1 hover:border-[#756656] transition-colors"
          >
            <span>Explore All Collections</span>
            <span>→</span>
          </Link>
        </div>

      </div>
    </section>
  );
}
