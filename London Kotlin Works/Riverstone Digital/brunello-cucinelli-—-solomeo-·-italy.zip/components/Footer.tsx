'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import SolomeoCrest from './SolomeoCrest';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setSubscribed(true);
  };

  return (
    <footer className="w-full bg-[#F5F2EC] text-[#292723] pt-16 pb-12 border-t border-[#D8CCBC]/40">
      <div className="max-w-[1520px] mx-auto px-6 sm:px-10 lg:px-16">
        
        {/* Top Newsletter & Solomeo Philosophy Strip */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-14 border-b border-[#D8CCBC]/40">
          
          {/* Solomeo Quote & Mission */}
          <div className="md:col-span-6 lg:col-span-7 pr-0 md:pr-10">
            <div className="flex items-center gap-2 mb-3">
              <SolomeoCrest size={18} className="text-[#756656]" />
              <span className="font-serif-luxury tracking-[0.24em] text-xs uppercase text-[#756656]">
                Solomeo · Umbria · Italy
              </span>
            </div>
            <p className="font-serif-luxury italic text-lg sm:text-xl text-[#292723] font-normal leading-relaxed max-w-xl">
              &ldquo;Work must always have a human dimension, honoring the dignity of those who create it and the land that nourishes it.&rdquo;
            </p>
            <p className="text-[11px] uppercase tracking-[0.2em] text-[#A99A87] mt-3">
              Brunello Cucinelli · Humanistic Capitalism
            </p>
          </div>

          {/* Newsletter Subscription */}
          <div className="md:col-span-6 lg:col-span-5">
            <h4 className="font-serif-luxury text-base text-[#292723] mb-2 font-normal">
              The Solomeo Letters
            </h4>
            <p className="text-xs text-[#756656] leading-relaxed mb-4 font-light">
              Receive periodic private dispatches on new seasonal collections, philosophy, and cultural gatherings in Umbria.
            </p>

            {subscribed ? (
              <div className="p-3 bg-[#EAE4DA] text-xs text-[#292723] border border-[#D8CCBC] font-serif-luxury italic">
                Thank you for subscribing. A welcome correspondence will arrive shortly.
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="flex items-center border-b border-[#292723] pb-1.5">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                    className="w-full bg-transparent text-xs text-[#292723] placeholder-[#A99A87] focus:outline-none"
                    aria-label="Email address for newsletter"
                  />
                  <button
                    type="submit"
                    className="text-[10px] font-medium tracking-[0.22em] uppercase text-[#292723] hover:text-[#756656] transition-colors whitespace-nowrap ml-2"
                  >
                    Subscribe →
                  </button>
                </div>
                {error && <p className="text-[11px] text-[#B91C1C]">{error}</p>}
                <p className="text-[10px] text-[#A99A87] tracking-wider">
                  You may unsubscribe at any time. We respect your confidentiality.
                </p>
              </form>
            )}
          </div>

        </div>

        {/* Middle Footer Navigation Bar matching reference image */}
        <div className="py-8 flex flex-col md:flex-row items-center justify-between gap-6 border-b border-[#D8CCBC]/40">
          
          {/* Brand Wordmark (Left) */}
          <div className="flex items-center">
            <Link
              href="/"
              className="font-serif-luxury tracking-[0.28em] text-base sm:text-lg uppercase text-[#292723] hover:text-[#756656] transition-colors"
            >
              Brunello Cucinelli
            </Link>
          </div>

          {/* Core Footer Links (Center) */}
          <nav className="flex flex-wrap items-center justify-center gap-6 sm:gap-8 text-[11px] font-medium tracking-[0.2em] uppercase text-[#756656]">
            <Link href="/brand" className="hover:text-[#292723] transition-colors">
              Customer Care
            </Link>
            <Link href="/brand" className="hover:text-[#292723] transition-colors">
              Shipping
            </Link>
            <Link href="/brand" className="hover:text-[#292723] transition-colors">
              Returns
            </Link>
            <Link href="/brand" className="hover:text-[#292723] transition-colors">
              Privacy
            </Link>
            <Link href="/brand" className="hover:text-[#292723] transition-colors">
              Legal
            </Link>
          </nav>

          {/* Social Icons (Right) matching reference */}
          <div className="flex items-center gap-5 text-[#756656]">
            {/* Instagram */}
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#292723] transition-colors"
              aria-label="Brunello Cucinelli on Instagram"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </a>

            {/* Facebook */}
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#292723] transition-colors"
              aria-label="Brunello Cucinelli on Facebook"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z" />
              </svg>
            </a>

            {/* YouTube */}
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#292723] transition-colors"
              aria-label="Brunello Cucinelli on YouTube"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136c-1.871-.502-9.376-.502-9.376-.502s-7.504 0-9.377.502a3.016 3.016 0 0 0-2.122 2.136c-.5 1.871-.5 5.814-.5 5.814s0 3.943.5 5.814a3.016 3.016 0 0 0 2.122 2.136c1.873.502 9.377.502 9.377.502s7.505 0 9.377-.502a3.016 3.016 0 0 0 2.122-2.136c.5-1.871.5-5.814.5-5.814s0-3.943-.5-5.814zm-14.498 9.814v-8l6.928 4-6.928 4z" />
              </svg>
            </a>

            {/* Pinterest */}
            <a
              href="https://pinterest.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#292723] transition-colors"
              aria-label="Brunello Cucinelli on Pinterest"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345-.09.375-.291 1.199-.334 1.357-.057.24-.19.291-.439.175-1.644-.766-2.671-3.171-2.671-5.105 0-4.156 3.019-7.973 8.708-7.973 4.572 0 8.125 3.258 8.125 7.612 0 4.543-2.864 8.2-6.839 8.2-1.336 0-2.592-.695-3.022-1.515l-.824 3.143c-.298 1.147-1.106 2.584-1.647 3.456 1.178.363 2.434.562 3.738.562 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z" />
              </svg>
            </a>

            {/* LinkedIn */}
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#292723] transition-colors"
              aria-label="Brunello Cucinelli on LinkedIn"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
              </svg>
            </a>
          </div>

        </div>

        {/* Bottom Copyright & Disclaimer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#A99A87] gap-3">
          <p>© {new Date().getFullYear()} Brunello Cucinelli S.p.A. — All Rights Reserved.</p>
          <p className="tracking-wider uppercase text-[10px]">
            Conceptual Digital Flagship Prototype · Solomeo, Italy
          </p>
        </div>

      </div>
    </footer>
  );
}
