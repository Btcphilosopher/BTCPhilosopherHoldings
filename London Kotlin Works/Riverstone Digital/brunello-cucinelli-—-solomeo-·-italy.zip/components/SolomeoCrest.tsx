import React from 'react';

interface SolomeoCrestProps {
  className?: string;
  size?: number;
}

export default function SolomeoCrest({ className = 'text-current', size = 28 }: SolomeoCrestProps) {
  // Delicate architectural representation of the historic Tower of Solomeo Castle
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* Outer crenellated castle tower */}
      <path
        d="M9 8H23M9 8V27H23V8M9 8L11 5H21L23 8"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Tower battlements */}
      <path
        d="M12 5V7M16 5V7M20 5V7"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      {/* Arched Romanesque doorway */}
      <path
        d="M14 27V21C14 19.8954 14.8954 19 16 19C17.1046 19 18 19.8954 18 21V27"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      {/* Slit lancet windows */}
      <path
        d="M13 13V15M19 13V15"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      {/* Base terrace line */}
      <path
        d="M6 27H26"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
    </svg>
  );
}
