'use client';

import React from 'react';
import { useStore } from '@/lib/store-context';
import { Check } from 'lucide-react';

export default function ToastNotification() {
  const { toast } = useStore();

  if (!toast) return null;

  return (
    <aside
      className="fixed bottom-6 right-6 z-50 max-w-sm bg-[#292723] text-white px-5 py-4 shadow-xl border border-white/10 flex items-start gap-3 animate-fade-in"
      aria-live="polite"
      aria-atomic="true"
    >
      <div className="w-5 h-5 rounded-full bg-white/15 flex items-center justify-center shrink-0 mt-0.5">
        <Check size={12} className="text-white" />
      </div>
      <div>
        <p className="font-serif-luxury text-sm tracking-wide font-normal">
          {toast.message}
        </p>
        {toast.subtext && (
          <p className="text-[11px] text-white/75 font-light mt-0.5">
            {toast.subtext}
          </p>
        )}
      </div>
    </aside>
  );
}
