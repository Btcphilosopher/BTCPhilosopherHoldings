'use client';

import React, { useState, useEffect } from 'react';
import { X, User, MapPin, Calendar, Clock, PackageCheck } from 'lucide-react';
import { useStore } from '@/lib/store-context';
import SolomeoCrest from './SolomeoCrest';

export default function AccountModal() {
  const { isAccountOpen, setIsAccountOpen } = useStore();
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'appointments'>('profile');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isAccountOpen) {
        setIsAccountOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAccountOpen, setIsAccountOpen]);

  if (!isAccountOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Client Account"
    >
      <div className="bg-[#F5F2EC] text-[#292723] w-full max-w-2xl rounded-xs shadow-2xl border border-[#D8CCBC] overflow-hidden my-8">
        
        {/* Header */}
        <div className="px-6 py-5 bg-white border-b border-[#D8CCBC]/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <SolomeoCrest size={20} className="text-[#292723]" />
            <span className="font-serif-luxury tracking-[0.24em] text-lg uppercase font-medium">
              Client Portal
            </span>
            <span className="text-[10px] tracking-wider uppercase bg-[#EAE4DA] px-2 py-0.5 text-[#756656] font-mono">
              Solomeo Club
            </span>
          </div>
          <button
            type="button"
            onClick={() => setIsAccountOpen(false)}
            className="p-1.5 text-[#756656] hover:text-[#292723] transition-colors"
            aria-label="Close client portal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#D8CCBC]/60 bg-[#EAE4DA]/50 px-6 pt-3 gap-6 text-xs font-medium tracking-[0.2em] uppercase">
          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`pb-3 relative transition-colors ${
              activeTab === 'profile'
                ? 'text-[#292723] font-semibold after:content-[\'\'] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#292723]'
                : 'text-[#756656] hover:text-[#292723]'
            }`}
          >
            Profile & Tailoring
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('orders')}
            className={`pb-3 relative transition-colors ${
              activeTab === 'orders'
                ? 'text-[#292723] font-semibold after:content-[\'\'] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#292723]'
                : 'text-[#756656] hover:text-[#292723]'
            }`}
          >
            Orders
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('appointments')}
            className={`pb-3 relative transition-colors ${
              activeTab === 'appointments'
                ? 'text-[#292723] font-semibold after:content-[\'\'] after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#292723]'
                : 'text-[#756656] hover:text-[#292723]'
            }`}
          >
            Bespoke Appointments
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 space-y-6">
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <div className="bg-white p-5 border border-[#D8CCBC]/50 flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-[#EAE4DA] flex items-center justify-center text-[#756656]">
                  <User size={24} strokeWidth={1.5} />
                </div>
                <div>
                  <h4 className="font-serif-luxury text-xl text-[#292723]">Eleanor Vance</h4>
                  <p className="text-xs text-[#756656]">Private Client · Member since 2023</p>
                  <p className="text-[11px] text-[#A99A87] font-mono mt-0.5">ID: BC-77391-LDN</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="bg-white p-4 border border-[#D8CCBC]/50">
                  <p className="font-medium text-[#292723] tracking-wider uppercase text-[10px] mb-2 flex items-center gap-1.5">
                    <MapPin size={13} className="text-[#756656]" />
                    Primary Residence
                  </p>
                  <p className="text-[#292723]">42 Berkeley Square</p>
                  <p className="text-[#756656]">Mayfair, London W1J 5AW</p>
                  <p className="text-[#756656]">United Kingdom</p>
                </div>

                <div className="bg-white p-4 border border-[#D8CCBC]/50">
                  <p className="font-medium text-[#292723] tracking-wider uppercase text-[10px] mb-2">
                    Sartorial Preferences
                  </p>
                  <p className="text-[#756656]">Knitwear Size: <span className="text-[#292723] font-medium">40 IT / S</span></p>
                  <p className="text-[#756656]">Tailoring Size: <span className="text-[#292723] font-medium">40 IT / 8 UK</span></p>
                  <p className="text-[#756656]">Preferred Palette: <span className="text-[#292723] font-medium">Ivory, Sand, Pebble</span></p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="bg-white p-5 border border-[#D8CCBC]/50">
                <div className="flex justify-between items-start border-b border-[#D8CCBC]/30 pb-3 mb-3">
                  <div>
                    <span className="font-mono text-xs font-semibold text-[#292723]">Order #BC-81902</span>
                    <p className="text-[11px] text-[#756656]">Placed on 12 October 2026</p>
                  </div>
                  <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 bg-[#EAE4DA] text-[#292723] font-medium">
                    Delivered
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-[#292723]">
                  <PackageCheck size={16} className="text-[#756656]" />
                  <span>Cashmere Crewneck Sweater · Oatmeal Melange (£1,650)</span>
                </div>
              </div>

              <div className="bg-white p-5 border border-[#D8CCBC]/50">
                <div className="flex justify-between items-start border-b border-[#D8CCBC]/30 pb-3 mb-3">
                  <div>
                    <span className="font-mono text-xs font-semibold text-[#292723]">Order #BC-74198</span>
                    <p className="text-[11px] text-[#756656]">Placed on 28 August 2026</p>
                  </div>
                  <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 bg-[#EAE4DA] text-[#292723] font-medium">
                    Delivered
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-[#292723]">
                  <PackageCheck size={16} className="text-[#756656]" />
                  <span>Soft Leather Weekender · Cognac Brown (£3,450)</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'appointments' && (
            <div className="space-y-4">
              <div className="bg-white p-5 border border-[#D8CCBC]/50">
                <div className="flex justify-between items-start border-b border-[#D8CCBC]/30 pb-3 mb-3">
                  <div>
                    <span className="font-serif-luxury text-base text-[#292723]">Made-to-Measure Consultation</span>
                    <p className="text-[11px] text-[#756656] flex items-center gap-1.5 mt-0.5">
                      <MapPin size={12} />
                      New Bond Street Flagship, London
                    </p>
                  </div>
                  <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 bg-[#292723] text-white font-medium">
                    Confirmed
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs text-[#756656]">
                  <span className="flex items-center gap-1">
                    <Calendar size={13} />
                    Friday, 24 October 2026
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={13} />
                    14:30 GMT
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="pt-2 border-t border-[#D8CCBC]/40 text-center">
            <p className="text-[10px] text-[#A99A87] tracking-wider uppercase">
              Demonstration Client Profile · Solomeo Digital Atelier
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
