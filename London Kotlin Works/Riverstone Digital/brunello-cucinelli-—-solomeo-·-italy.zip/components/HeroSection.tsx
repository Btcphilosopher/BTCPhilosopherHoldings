'use client';

import React from 'react';
import Link from 'next/link';

export default function HeroSection() {
  return (
    <section className="relative w-full h-[75vh] min-h-[580px] max-h-[860px] overflow-hidden bg-[#292723]">
      {/* Background Image: Model on the right, stone parapet, Umbrian hill town & landscape */}
      <div
        className="absolute inset-0 bg-cover bg-no-repeat transition-transform duration-1000 ease-out"
        style={{
          backgroundImage: "url('/images/hero_brunello_solomeo_1792401363673.jpg')",
          backgroundPosition: 'right 30% center',
        }}
        role="img"
        aria-label="Brunello Cucinelli tailored menswear with Solomeo hill town landscape"
      />

      {/* Subtle editorial gradient scrim for text legibility on the left side */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent pointer-events-none"
        aria-hidden="true"
      />

      {/* Content Container aligned approx 1/8 from left */}
      <div className="relative h-full max-w-[1520px] mx-auto px-6 sm:px-10 lg:px-16 flex items-center">
        <div className="w-full max-w-xl lg:max-w-2xl text-white pt-12 md:pt-16">
          
          {/* Eyebrow */}
          <p className="text-[10px] sm:text-[11px] font-medium tracking-[0.28em] uppercase text-white/90 mb-4 sm:mb-5">
            The Art of Italian Style
          </p>

          {/* Main Headline */}
          <h1 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl lg:text-[56px] font-light leading-[1.12] tracking-wide text-white mb-5 sm:mb-6 text-balance drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
            Timeless Elegance.
            <br />
            A Deeper Purpose.
          </h1>

          {/* Supporting Prose */}
          <p className="text-sm sm:text-base text-white/90 font-light leading-relaxed max-w-lg mb-8 sm:mb-10 drop-shadow-[0_1px_2px_rgba(0,0,0,0.4)]">
            Brunello Cucinelli creates refined clothing for a more beautiful world,
            where elegance and humanity go hand in hand.
          </p>

          {/* Primary CTA button with refined border and subtle arrow */}
          <div>
            <Link
              href="/men"
              className="inline-flex items-center gap-3 px-6 py-3 border border-white/85 text-[11px] sm:text-xs font-medium tracking-[0.22em] uppercase text-white hover:bg-white hover:text-[#292723] hover:border-white transition-all duration-300"
            >
              <span>Discover The Collection</span>
              <span className="text-base leading-none transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </Link>
          </div>

        </div>
      </div>
    </section>
  );
}
