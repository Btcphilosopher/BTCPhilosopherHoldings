'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Search, User, Heart, ShoppingBag, Menu, X } from 'lucide-react';
import SolomeoCrest from './SolomeoCrest';
import { useStore } from '@/lib/store-context';

export default function Header() {
  const pathname = usePathname();
  const isHomePage = pathname === '/';
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const {
    totalItemsCount,
    wishlist,
    setIsBagOpen,
    setIsWishlistOpen,
    setIsSearchOpen,
    setIsAccountOpen,
  } = useStore();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Determine appearance
  // On home page, transparent initially then ivory on scroll; on subpages, always solid ivory.
  const isSolid = !isHomePage || isScrolled;

  const headerBgClass = isSolid
    ? 'bg-[#F5F2EC]/95 backdrop-blur-md text-[#292723] border-b border-[#D8CCBC]/40 shadow-xs'
    : 'bg-gradient-to-b from-black/50 via-black/20 to-transparent text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]';

  const linkHoverClass = isSolid
    ? 'hover:text-[#756656] text-[#292723]'
    : 'hover:text-[#EAE4DA] text-white';

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ease-out ${headerBgClass}`}
      >
        <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 h-20 md:h-24 flex items-center justify-between">
          
          {/* Mobile Menu Button (Left on mobile) */}
          <div className="flex items-center lg:hidden">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 -ml-2 text-inherit focus:outline-none focus-visible:ring-1 focus-visible:ring-current"
              aria-label="Open navigation menu"
            >
              <Menu size={22} strokeWidth={1.5} />
            </button>
          </div>

          {/* Desktop Left Navigation */}
          <nav className="hidden lg:flex items-center gap-7 xl:gap-9 text-[11px] font-medium tracking-[0.2em] uppercase">
            <Link
              href="/women"
              className={`transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] hover:after:w-full after:transition-all after:bg-current ${linkHoverClass}`}
            >
              Women
            </Link>
            <Link
              href="/men"
              className={`transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] hover:after:w-full after:transition-all after:bg-current ${linkHoverClass}`}
            >
              Men
            </Link>
            <Link
              href="/brand"
              className={`transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] hover:after:w-full after:transition-all after:bg-current ${linkHoverClass}`}
            >
              The Brand
            </Link>
            <Link
              href="/knitwear"
              className={`transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] hover:after:w-full after:transition-all after:bg-current ${linkHoverClass}`}
            >
              World of Brunello
            </Link>
            <Link
              href="/stores"
              className={`transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] hover:after:w-full after:transition-all after:bg-current ${linkHoverClass}`}
            >
              Stores
            </Link>
          </nav>

          {/* Center Brand Identity (Crest + Brunello Cucinelli + Solomeo) */}
          <div className="flex flex-col items-center justify-center text-center select-none group">
            <Link href="/" className="flex flex-col items-center">
              <SolomeoCrest size={24} className="mb-1 opacity-90 transition-transform duration-300 group-hover:scale-105" />
              <span className="font-serif-luxury tracking-[0.28em] text-[15px] sm:text-[18px] md:text-[20px] uppercase font-light leading-none">
                Brunello Cucinelli
              </span>
              <span className="tracking-[0.32em] text-[8px] sm:text-[9px] uppercase font-medium mt-1 text-inherit opacity-85">
                Solomeo · Italy
              </span>
            </Link>
          </div>

          {/* Right Utilities (Search, Login, Wishlist, Bag) */}
          <div className="flex items-center gap-4 sm:gap-6 text-inherit">
            {/* Search */}
            <button
              type="button"
              onClick={() => setIsSearchOpen(true)}
              className="flex items-center gap-1.5 text-[11px] font-medium tracking-[0.18em] uppercase transition-colors hover:opacity-75 focus:outline-none"
              aria-label="Search collection"
            >
              <Search size={16} strokeWidth={1.5} />
              <span className="hidden sm:inline">Search</span>
            </button>

            {/* Login / Account */}
            <button
              type="button"
              onClick={() => setIsAccountOpen(true)}
              className="flex items-center gap-1.5 text-[11px] font-medium tracking-[0.18em] uppercase transition-colors hover:opacity-75 focus:outline-none"
              aria-label="Client account"
            >
              <User size={16} strokeWidth={1.5} />
              <span className="hidden md:inline">Login</span>
            </button>

            {/* Wishlist */}
            <button
              type="button"
              onClick={() => setIsWishlistOpen(true)}
              className="relative p-1 transition-colors hover:opacity-75 focus:outline-none"
              aria-label={`Wishlist (${wishlist.length} saved)`}
            >
              <Heart
                size={17}
                strokeWidth={1.5}
                className={wishlist.length > 0 ? 'fill-current text-[#756656]' : ''}
              />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#292723] text-white text-[9px] font-mono flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Shopping Bag */}
            <button
              type="button"
              onClick={() => setIsBagOpen(true)}
              className="relative p-1 transition-colors hover:opacity-75 focus:outline-none"
              aria-label={`Shopping bag (${totalItemsCount} items)`}
            >
              <ShoppingBag size={17} strokeWidth={1.5} />
              {totalItemsCount > 0 && (
                <span className="absolute -top-1 -right-1.5 w-4 h-4 rounded-full bg-[#756656] text-white text-[9px] font-mono flex items-center justify-center">
                  {totalItemsCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />
          {/* Drawer content */}
          <div className="fixed inset-y-0 left-0 w-full max-w-xs bg-[#F5F2EC] text-[#292723] p-6 flex flex-col justify-between shadow-2xl overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-[#D8CCBC]/60">
                <div className="flex items-center gap-2">
                  <SolomeoCrest size={20} className="text-[#292723]" />
                  <span className="font-serif-luxury tracking-[0.2em] text-sm uppercase">
                    Brunello Cucinelli
                  </span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 text-[#756656] hover:text-[#292723]"
                  aria-label="Close menu"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="mt-8 flex flex-col gap-5 text-xs font-medium tracking-[0.22em] uppercase">
                <Link
                  href="/women"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 hover:text-[#756656] border-b border-[#D8CCBC]/30 pb-3"
                >
                  Women
                </Link>
                <Link
                  href="/men"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 hover:text-[#756656] border-b border-[#D8CCBC]/30 pb-3"
                >
                  Men
                </Link>
                <Link
                  href="/knitwear"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 hover:text-[#756656] border-b border-[#D8CCBC]/30 pb-3"
                >
                  Knitwear Collection
                </Link>
                <Link
                  href="/accessories"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 hover:text-[#756656] border-b border-[#D8CCBC]/30 pb-3"
                >
                  Leather & Accessories
                </Link>
                <Link
                  href="/brand"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 hover:text-[#756656] border-b border-[#D8CCBC]/30 pb-3"
                >
                  The Brand · Solomeo
                </Link>
                <Link
                  href="/stores"
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 hover:text-[#756656] border-b border-[#D8CCBC]/30 pb-3"
                >
                  Store Locator
                </Link>
              </div>
            </div>

            <div className="pt-8 border-t border-[#D8CCBC]/60 text-[11px] text-[#756656] space-y-3">
              <div className="flex items-center justify-between">
                <span>Region & Currency</span>
                <span className="font-mono text-[#292723]">United Kingdom (GBP £)</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Client Services</span>
                <span className="text-[#292723]">+44 20 7499 6608</span>
              </div>
              <p className="text-[10px] text-[#A99A87] pt-2">
                Solomeo · Italy — Dedicated to Humanistic Capitalism
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
