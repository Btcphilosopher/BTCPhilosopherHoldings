'use client';

import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, Gift, Truck, CreditCard, ArrowRight } from 'lucide-react';
import { useStore } from '@/lib/store-context';

export default function CheckoutModal() {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    subtotalAmount,
    clearBag,
  } = useStore();

  const [step, setStep] = useState<'details' | 'confirmation'>('details');
  const [formData, setFormData] = useState({
    firstName: 'Eleanor',
    lastName: 'Vance',
    email: 'eleanor.vance@example.com',
    phone: '+44 7700 900123',
    address: '42 Berkeley Square, Mayfair',
    city: 'London',
    postalCode: 'W1J 5AW',
    country: 'United Kingdom',
    giftNote: 'With warmest regards from Solomeo.',
    includeGiftWrap: true,
  });

  const [orderNumber, setOrderNumber] = useState('');

  if (!isCheckoutOpen) return null;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    setOrderNumber(`BC-${randomNum}`);
    setStep('confirmation');
    clearBag();
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setStep('details');
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Demonstration Checkout"
    >
      <div className="bg-[#F5F2EC] text-[#292723] w-full max-w-2xl rounded-xs shadow-2xl border border-[#D8CCBC] overflow-hidden my-8">
        
        {/* Header */}
        <div className="px-6 py-5 bg-white border-b border-[#D8CCBC]/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-serif-luxury tracking-[0.24em] text-lg uppercase font-medium">
              Brunello Cucinelli
            </span>
            <span className="text-[10px] tracking-wider uppercase bg-[#EAE4DA] px-2 py-0.5 text-[#756656] font-mono">
              Demo Checkout
            </span>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 text-[#756656] hover:text-[#292723] transition-colors"
            aria-label="Close checkout"
          >
            <X size={20} />
          </button>
        </div>

        {step === 'details' ? (
          <form onSubmit={handleSubmitOrder} className="p-6 sm:p-8 space-y-6">
            <div className="bg-white p-4 border border-[#D8CCBC]/50 text-xs text-[#756656] flex items-start gap-2.5">
              <ShieldCheck size={18} className="text-[#292723] shrink-0 mt-0.5" />
              <p>
                <strong>Demonstration Mode:</strong> This checkout process is a simulated demonstration. No real payment will be charged, and no actual order will be dispatched.
              </p>
            </div>

            {/* Client Contact & Shipping */}
            <div>
              <h3 className="font-serif-luxury text-lg text-[#292723] font-normal mb-3 pb-2 border-b border-[#D8CCBC]/40">
                1. Delivery Address
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-[#756656] tracking-wider uppercase mb-1 text-[10px]">
                    First Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-sm focus:outline-none focus:border-[#292723]"
                  />
                </div>
                <div>
                  <label className="block text-[#756656] tracking-wider uppercase mb-1 text-[10px]">
                    Last Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-sm focus:outline-none focus:border-[#292723]"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[#756656] tracking-wider uppercase mb-1 text-[10px]">
                    Street Address
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-sm focus:outline-none focus:border-[#292723]"
                  />
                </div>
                <div>
                  <label className="block text-[#756656] tracking-wider uppercase mb-1 text-[10px]">
                    City / Town
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-sm focus:outline-none focus:border-[#292723]"
                  />
                </div>
                <div>
                  <label className="block text-[#756656] tracking-wider uppercase mb-1 text-[10px]">
                    Postal Code
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.postalCode}
                    onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-sm focus:outline-none focus:border-[#292723]"
                  />
                </div>
                <div>
                  <label className="block text-[#756656] tracking-wider uppercase mb-1 text-[10px]">
                    Email for Confirmation
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-sm focus:outline-none focus:border-[#292723]"
                  />
                </div>
                <div>
                  <label className="block text-[#756656] tracking-wider uppercase mb-1 text-[10px]">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-sm focus:outline-none focus:border-[#292723]"
                  />
                </div>
              </div>
            </div>

            {/* Packaging & Gift Options */}
            <div>
              <h3 className="font-serif-luxury text-lg text-[#292723] font-normal mb-3 pb-2 border-b border-[#D8CCBC]/40">
                2. Solomeo Packaging & Complimentary Gift Note
              </h3>
              <div className="bg-white p-4 border border-[#D8CCBC] space-y-3">
                <label className="flex items-center gap-2.5 text-xs text-[#292723] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.includeGiftWrap}
                    onChange={(e) => setFormData({ ...formData, includeGiftWrap: e.target.checked })}
                    className="accent-[#292723]"
                  />
                  <span className="font-medium">
                    Signature Solomeo Keepsake Box with embossed raw cotton ribbon
                  </span>
                </label>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-[#756656] mb-1">
                    Personal Gift Message (Optional)
                  </label>
                  <textarea
                    rows={2}
                    value={formData.giftNote}
                    onChange={(e) => setFormData({ ...formData, giftNote: e.target.value })}
                    className="w-full bg-[#F5F2EC] border border-[#D8CCBC] p-2 text-xs focus:outline-none"
                    placeholder="Inscribe a message to be hand-penned on card..."
                  />
                </div>
              </div>
            </div>

            {/* Summary & Place Order */}
            <div className="pt-4 border-t border-[#D8CCBC]/60 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="text-[11px] text-[#756656]">Order Total (All Taxes & Duties Included)</p>
                <p className="font-serif-luxury text-2xl text-[#292723] font-normal">
                  £{subtotalAmount.toLocaleString()}
                </p>
              </div>

              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-3.5 bg-[#292723] text-white text-[11px] font-medium tracking-[0.24em] uppercase hover:bg-[#756656] transition-colors flex items-center justify-center gap-2"
              >
                <span>Confirm Demonstration Order</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </form>
        ) : (
          /* Step: Order Confirmation */
          <div className="p-8 sm:p-12 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-[#EAE4DA] text-[#292723] mx-auto flex items-center justify-center">
              <CheckCircle size={32} strokeWidth={1.5} />
            </div>

            <div>
              <p className="text-[10px] font-medium tracking-[0.28em] uppercase text-[#756656] mb-2">
                Thank You for Visiting Brunello Cucinelli
              </p>
              <h3 className="font-serif-luxury text-3xl text-[#292723] font-normal mb-3">
                Order #{orderNumber} Confirmed
              </h3>
              <p className="text-sm text-[#756656] font-light max-w-md mx-auto">
                A confirmation has been prepared for <span className="font-medium text-[#292723]">{formData.email}</span>. Your garments will be inspected and packaged in Solomeo.
              </p>
            </div>

            <div className="bg-white p-5 border border-[#D8CCBC] max-w-md mx-auto text-left text-xs space-y-2">
              <div className="flex justify-between border-b border-[#D8CCBC]/40 pb-2">
                <span className="text-[#756656]">Recipient</span>
                <span className="font-medium text-[#292723]">{formData.firstName} {formData.lastName}</span>
              </div>
              <div className="flex justify-between border-b border-[#D8CCBC]/40 pb-2">
                <span className="text-[#756656]">Delivery Destination</span>
                <span className="text-right text-[#292723]">{formData.address}, {formData.city}</span>
              </div>
              <div className="flex justify-between border-b border-[#D8CCBC]/40 pb-2">
                <span className="text-[#756656]">Estimated Arrival</span>
                <span className="font-medium text-[#292723]">2–3 Business Days (Express)</span>
              </div>
              <div className="flex justify-between pt-1">
                <span className="text-[#756656]">Total Billed</span>
                <span className="font-mono font-semibold text-[#292723]">£{subtotalAmount.toLocaleString()}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleClose}
              className="px-8 py-3 bg-[#292723] text-white text-[11px] font-medium tracking-[0.22em] uppercase hover:bg-[#756656] transition-colors"
            >
              Return to Solomeo Flagship
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
