'use client';

import React, { useEffect } from 'react';
import Link from 'next/link';
import { X, Minus, Plus, Trash2, ArrowRight, ShieldCheck, Gift } from 'lucide-react';
import { useStore } from '@/lib/store-context';

export default function ShoppingBagDrawer() {
  const {
    cart,
    isBagOpen,
    setIsBagOpen,
    updateQuantity,
    removeFromBag,
    subtotalAmount,
    totalItemsCount,
    setIsCheckoutOpen,
  } = useStore();

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isBagOpen) {
        setIsBagOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isBagOpen, setIsBagOpen]);

  if (!isBagOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true" aria-label="Shopping Bag">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity duration-300"
        onClick={() => setIsBagOpen(false)}
      />

      {/* Drawer */}
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md sm:max-w-lg bg-[#F5F2EC] text-[#292723] flex flex-col shadow-2xl">
          
          {/* Header */}
          <div className="px-6 py-5 border-b border-[#D8CCBC]/50 flex items-center justify-between bg-white/50">
            <div>
              <h2 className="font-serif-luxury text-xl sm:text-2xl font-normal tracking-wide">
                Shopping Bag
              </h2>
              <p className="text-[11px] font-medium tracking-[0.2em] uppercase text-[#756656] mt-0.5">
                {totalItemsCount} {totalItemsCount === 1 ? 'Item' : 'Items'} Selected
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsBagOpen(false)}
              className="p-2 text-[#756656] hover:text-[#292723] transition-colors focus:outline-none"
              aria-label="Close shopping bag"
            >
              <X size={20} />
            </button>
          </div>

          {/* Complimentary Shipping Banner */}
          <div className="px-6 py-2.5 bg-[#EAE4DA] text-[11px] font-medium tracking-wider text-[#756656] flex items-center justify-between border-b border-[#D8CCBC]/40">
            <span className="flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-[#292723]" />
              Complimentary White-Glove Shipping & Returns
            </span>
            <span className="text-[#292723] font-serif-luxury italic">Solomeo</span>
          </div>

          {/* Bag Content */}
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16">
                <div className="w-16 h-16 rounded-full bg-[#EAE4DA] flex items-center justify-center text-[#756656] mb-4">
                  <Gift size={24} strokeWidth={1.5} />
                </div>
                <h3 className="font-serif-luxury text-xl text-[#292723] font-normal mb-2">
                  Your bag is currently empty
                </h3>
                <p className="text-xs text-[#756656] max-w-xs mb-6 font-light">
                  Explore our fine cashmere knitwear, deconstructed tailoring, and handcrafted leather accessories.
                </p>
                <button
                  type="button"
                  onClick={() => setIsBagOpen(false)}
                  className="px-6 py-2.5 bg-[#292723] text-white text-[11px] font-medium tracking-[0.22em] uppercase hover:bg-[#756656] transition-colors"
                >
                  Continue Browsing
                </button>
              </div>
            ) : (
              <ul className="divide-y divide-[#D8CCBC]/40">
                {cart.map((item) => (
                  <li key={item.id} className="py-5 flex gap-4 first:pt-0 last:pb-0">
                    {/* Item Thumbnail */}
                    <div className="w-20 sm:w-24 aspect-4/3 sm:aspect-square bg-[#EAE4DA] overflow-hidden shrink-0 border border-[#D8CCBC]/50">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <h4 className="font-serif-luxury text-base sm:text-lg text-[#292723] leading-snug">
                            <Link
                              href={`/product/${item.product.id}`}
                              onClick={() => setIsBagOpen(false)}
                              className="hover:text-[#756656] transition-colors"
                            >
                              {item.product.name}
                            </Link>
                          </h4>
                          <span className="font-mono text-sm font-medium text-[#292723] tabular-nums ml-2">
                            £{(item.product.price * item.quantity).toLocaleString()}
                          </span>
                        </div>

                        <div className="text-[11px] text-[#756656] mt-1 space-y-0.5">
                          <p>
                            <span className="font-medium">Colour:</span> {item.selectedColor}
                          </p>
                          <p>
                            <span className="font-medium">Size:</span> {item.selectedSize}
                          </p>
                        </div>
                      </div>

                      {/* Quantity Controls & Remove */}
                      <div className="flex items-center justify-between mt-3 pt-2">
                        <div className="inline-flex items-center border border-[#D8CCBC] bg-white">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-1.5 text-[#756656] hover:text-[#292723] transition-colors"
                            aria-label="Decrease quantity"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="px-3 text-xs font-mono font-medium tabular-nums text-[#292723]">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1.5 text-[#756656] hover:text-[#292723] transition-colors"
                            aria-label="Increase quantity"
                          >
                            <Plus size={12} />
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeFromBag(item.id)}
                          className="text-[11px] text-[#756656] hover:text-[#B91C1C] flex items-center gap-1 transition-colors"
                          aria-label={`Remove ${item.product.name} from bag`}
                        >
                          <Trash2 size={13} />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer Summary & Checkout Action */}
          {cart.length > 0 && (
            <div className="px-6 py-5 bg-white border-t border-[#D8CCBC]/60 space-y-4">
              {/* Packaging Promise */}
              <div className="flex items-start gap-2.5 p-3 bg-[#F5F2EC] text-[11px] text-[#756656]">
                <Gift size={16} className="text-[#292723] shrink-0 mt-0.5" />
                <p>
                  Delivered in our signature Solomeo keepsake box with natural cotton garment bag and personalized artisan card.
                </p>
              </div>

              {/* Subtotal & Taxes */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-[#756656]">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums font-medium text-[#292723]">
                    £{subtotalAmount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-[#756656]">
                  <span>Express Delivery</span>
                  <span className="text-[#292723] font-medium">Complimentary</span>
                </div>
                <div className="flex justify-between text-[#756656]">
                  <span>Applicable VAT & Duties</span>
                  <span>Included</span>
                </div>
                <div className="flex justify-between text-sm sm:text-base font-serif-luxury text-[#292723] pt-2 border-t border-[#D8CCBC]/40 font-normal">
                  <span>Estimated Total</span>
                  <span className="font-mono tabular-nums font-semibold">
                    £{subtotalAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                type="button"
                onClick={() => {
                  setIsBagOpen(false);
                  setIsCheckoutOpen(true);
                }}
                className="w-full py-3.5 bg-[#292723] text-white text-[11px] sm:text-xs font-medium tracking-[0.24em] uppercase hover:bg-[#756656] transition-colors flex items-center justify-center gap-2"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight size={14} />
              </button>

              <p className="text-[10px] text-center text-[#A99A87] tracking-wider uppercase">
                Secure Encrypted Checkout · Demonstration Experience
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
