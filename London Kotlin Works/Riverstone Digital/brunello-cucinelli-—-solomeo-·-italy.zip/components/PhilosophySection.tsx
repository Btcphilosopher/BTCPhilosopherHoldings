import React from 'react';
import Link from 'next/link';

export default function PhilosophySection() {
  return (
    <section className="w-full bg-[#F5F2EC] overflow-hidden border-b border-[#D8CCBC]/40">
      {/* 3-part layout: Left landscape (with quote), Center ivory editorial, Right artisan hands */}
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[480px] lg:h-[500px] w-full">
        
        {/* Left: Panoramic hill town with overlaid quote (approx 5 cols) */}
        <div className="relative lg:col-span-5 h-[340px] sm:h-[400px] lg:h-full overflow-hidden bg-[#292723]">
          <img
            src="/images/philo_landscape_sunset_1792401381643.jpg"
            alt="Solomeo Italian hill town at sunset"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-95"
            loading="lazy"
          />
          {/* Subtle vignette scrim */}
          <div
            className="absolute inset-0 bg-black/25 flex items-center justify-center p-8 sm:p-12 text-center"
            aria-hidden="true"
          >
            <blockquote className="font-serif-luxury italic text-white text-2xl sm:text-3xl md:text-[32px] font-normal leading-snug tracking-wide drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
              &ldquo;We believe in a more beautiful world.&rdquo;
            </blockquote>
          </div>
        </div>

        {/* Center: Warm Ivory editorial text panel (approx 4 cols) */}
        <div className="lg:col-span-4 bg-[#F5F2EC] p-8 sm:p-12 lg:p-14 xl:p-16 flex flex-col justify-center items-start border-y lg:border-y-0 lg:border-x border-[#D8CCBC]/40">
          <p className="text-[10px] sm:text-[11px] font-medium tracking-[0.26em] uppercase text-[#756656] mb-4 sm:mb-5">
            The Brunello Cucinelli Philosophy
          </p>

          <p className="text-[#292723] text-sm sm:text-[15px] font-normal leading-relaxed mb-6 sm:mb-8 font-serif-luxury text-pretty">
            For us, true luxury is not a matter of excess, but of harmony — between
            people, nature and beauty. We create timeless pieces, made with the finest
            materials and an unwavering commitment to quality, craftsmanship and respect
            for the world around us.
          </p>

          <Link
            href="/brand"
            className="group inline-flex items-center gap-2 text-[11px] font-medium tracking-[0.24em] uppercase text-[#292723] hover:text-[#756656] transition-colors relative pb-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1px] after:bg-[#292723] group-hover:after:bg-[#756656]"
          >
            <span>Our Story</span>
            <span className="transition-transform duration-300 group-hover:translate-x-1">
              →
            </span>
          </Link>
        </div>

        {/* Right: Master artisan hands close-up (approx 3 cols) */}
        <div className="relative lg:col-span-3 h-[320px] sm:h-[380px] lg:h-full overflow-hidden bg-[#292723]">
          <img
            src="/images/philo_artisan_hands_1792401381559.jpg"
            alt="Master Italian artisan hand-tailoring fine cashmere"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
            loading="lazy"
          />
        </div>

      </div>
    </section>
  );
}
