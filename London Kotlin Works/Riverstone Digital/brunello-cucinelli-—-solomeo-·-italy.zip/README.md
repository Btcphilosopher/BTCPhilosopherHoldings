# Brunello Cucinelli — Digital Flagship

A digital flagship application for Brunello Cucinelli, faithfully translating the attached reference website design into a functioning luxury fashion e-commerce experience.

Inspired by the historic hilltop hamlet of Solomeo in Umbria, Italy, the digital flagship embodies **Humanistic Capitalism**, quiet luxury, timeless tailoring, and exceptional natural materials.

---

## Visual Design & Architecture Highlights

1. **Header & Navigation**:
   - Transparent overlay on the cinematic hero transitioning seamlessly to a solid warm ivory (`#F5F2EC`) background on scroll and across subpages.
   - Restrained uppercase typography with wide letter spacing (`tracking-[0.2em]`).
   - Architectural Solomeo castle emblem with `BRUNELLO CUCINELLI` and `SOLOMEO · ITALY`.
   - Complete navigation: `WOMEN`, `MEN`, `THE BRAND`, `WORLD OF BRUNELLO`, `STORES`.
   - Utility controls: Search overlay, Client Account, Wishlist counter, and Shopping Bag with live item count.
   - Refined mobile navigation drawer.

2. **Cinematic Hero Section**:
   - Recreates the exact composition from the reference image: mature model on the right in tailored beige linen suit and cream cashmere knitwear, resting against a stone parapet overlooking the rolling Umbrian hills and Solomeo medieval hamlet.
   - Left-aligned editorial typography:
     - Eyebrow: `THE ART OF ITALIAN STYLE`
     - Headline: `Timeless Elegance. A Deeper Purpose.`
     - Supporting copy: `Brunello Cucinelli creates refined clothing for a more beautiful world, where elegance and humanity go hand in hand.`
     - Primary CTA: `DISCOVER THE COLLECTION →`

3. **Five-Category Collection Strip**:
   - Five-column grid immediately below the hero with consistent aspect ratios and subtle hover transitions:
     1. **MEN**: Understated Italian tailoring and light knitwear (`/men`)
     2. **WOMEN**: Luxurious neutral-toned cashmere and wool overcoat (`/women`)
     3. **KNITWEAR**: Detail of fine ribbed cashmere knitwear with garment label (`/knitwear`)
     4. **ACCESSORIES**: Handcrafted Florentine leather weekender duffle bag and belt (`/accessories`)
     5. **THE BRAND**: Panoramic view of the medieval fortress hamlet of Solomeo (`/brand`)

4. **Brand Philosophy Section**:
   - Balanced three-part editorial layout:
     - **Left**: Panoramic landscape of ancient hill town at golden hour with quote: *“We believe in a more beautiful world.”*
     - **Center**: Warm ivory editorial panel on *The Brunello Cucinelli Philosophy* with `OUR STORY →`
     - **Right**: Master artisan hands hand-tailoring fine cashmere fabric

5. **The New Season Showcase**:
   - Featured seasonal product grid with category filter controls (`All`, `Men`, `Women`, `Knitwear`, `Accessories`).
   - Product cards with color information, British Pound (GBP £) pricing, wishlist toggles, quick-add capability, and detail page links.

6. **Interactive E-Commerce Features**:
   - **Shopping Bag**: Slide-over drawer with itemized summary, line item quantity steppers, item removal, complimentary white-glove shipping promise, signature Solomeo keepsake packaging notice, and subtotal calculation.
   - **Checkout Experience**: Multi-step demonstration checkout with client address details, complimentary gift message card in Solomeo keepsake box, and order confirmation receipt (#BC-XXXXX).
   - **Wishlist**: Persistent saved items list with 1-click "Move to Bag" and removal.
   - **Search Overlay**: Real-time search across products by keyword, category, description, and fabric with quick trending suggestions.
   - **Client Portal (Account)**: Client profile overview, saved tailoring measurements, past orders, and appointment schedules.
   - **Store Locator**: Boutique locator for London, Milan, Solomeo, Paris, New York, and Tokyo with made-to-measure appointment booking modal.
   - **Product Detail Pages (`/product/:id`)**: Rich photography gallery with thumbnail selector, color swatches, Italian size picker, interactive size & fit modal guide, quantity controls, and related pairings.

---

## Implemented Routes

- `/`: Flagship homepage (Hero, 5-category strip, Philosophy section, Featured New Season grid)
- `/men`: Men's Sartorial Collection with subcategory filters and sorting
- `/women`: Women's Collection with outerwear, cashmere knitwear, and accessories
- `/knitwear`: Fine Cashmere Knitwear Collection spotlighting Mongolian cashmere craftsmanship
- `/accessories`: Leather Goods & Travel Accessories (weekenders, suede loafers, calfskin belts)
- `/brand`: The Solomeo story, Humanistic Capitalism, dignity of work, and School of Arts & Crafts
- `/stores`: International Store Locator with appointment booking modal
- `/product/[id]`: Full-featured product detail page with size guide and craftsmanship details

---

## Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4 with custom luxury ivory/stone palette
- **Typography**: Cormorant Garamond (Editorial Serif) & Plus Jakarta Sans (Restrained Sans)
- **Icons**: Lucide React
- **State Management**: React Context with LocalStorage persistence

---

## Production Integration Notes

For live production deployment, the following backend integrations would replace the demonstration prototypes:
- Real-time ERP / PIM inventory synchronization
- Certified payment gateway (Stripe Elements / Apple Pay / Klarna Luxury)
- Enterprise headless commerce engine (commercelayer / Shopify Plus / Centra)
- CRM & Boutique Appointment calendar synchronization (Salesforce Clienteling / Cegid)
