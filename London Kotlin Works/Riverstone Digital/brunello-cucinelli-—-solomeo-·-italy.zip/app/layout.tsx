import type { Metadata } from 'next';
import './globals.css';
import { StoreProvider } from '@/lib/store-context';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ShoppingBagDrawer from '@/components/ShoppingBagDrawer';
import WishlistDrawer from '@/components/WishlistDrawer';
import SearchOverlay from '@/components/SearchOverlay';
import CheckoutModal from '@/components/CheckoutModal';
import AccountModal from '@/components/AccountModal';
import ToastNotification from '@/components/ToastNotification';

export const metadata: Metadata = {
  title: 'Brunello Cucinelli — Solomeo · Italy',
  description:
    'Italian luxury fashion house founded in Solomeo. Explore fine cashmere knitwear, sartorial tailoring, and artisanal leather goods crafted with quiet elegance and humanistic philosophy.',
  openGraph: {
    title: 'Brunello Cucinelli — Solomeo · Italy',
    description:
      'Italian luxury fashion house founded in Solomeo. Explore fine cashmere knitwear, sartorial tailoring, and artisanal leather goods crafted with quiet elegance and humanistic philosophy.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Brunello Cucinelli — Solomeo · Italy',
    description:
      'Italian luxury fashion house founded in Solomeo. Explore fine cashmere knitwear, sartorial tailoring, and artisanal leather goods.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="bg-[#F5F2EC] text-[#292723] antialiased min-h-screen flex flex-col selection:bg-[#D8CCBC] selection:text-[#292723]">
        <StoreProvider>
          {/* Universal Header with transparent-to-solid scroll transition */}
          <Header />

          {/* Page View Body */}
          <div className="flex-1">
            {children}
          </div>

          {/* Universal Flagship Footer */}
          <Footer />

          {/* Interactive Drawers & Overlays */}
          <ShoppingBagDrawer />
          <WishlistDrawer />
          <SearchOverlay />
          <CheckoutModal />
          <AccountModal />
          <ToastNotification />
        </StoreProvider>
      </body>
    </html>
  );
}
