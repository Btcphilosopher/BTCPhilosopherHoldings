'use client';

import React from 'react';
import CollectionLayout from '@/components/CollectionLayout';
import { PRODUCTS } from '@/data/products';

export default function AccessoriesPage() {
  const accessoriesProducts = PRODUCTS.filter((p) => p.category === 'accessories');

  return (
    <CollectionLayout
      title="Leather Goods & Accessories"
      eyebrow="Artisanal Heritage · Tuscan Craftsmanship"
      description="Handcrafted weekender holdalls, soft water-repellent suede penny loafers, and saddlery-stitched belts sculpted from vegetable-tanned Italian leathers that develop a rich patina over time."
      heroImage="/images/cat_accessories_leather_1792401365943.jpg"
      products={accessoriesProducts}
      categories={['Travel & Luggage', 'Footwear', 'Small Leather Goods']}
    />
  );
}
