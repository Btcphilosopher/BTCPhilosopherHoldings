'use client';

import React from 'react';
import CollectionLayout from '@/components/CollectionLayout';
import { PRODUCTS } from '@/data/products';

export default function WomenPage() {
  const womenProducts = PRODUCTS.filter(
    (p) => p.category === 'women' || p.category === 'knitwear' || p.category === 'accessories'
  );

  return (
    <CollectionLayout
      title="Women's Collection"
      eyebrow="Quiet Elegance · Contemporary Femininity"
      description="Effortless drapery and pure tactile warmth: double-face cashmere coats, enveloping belted cardigans, and luminous natural neutral palettes inspired by the stone alleys of Solomeo."
      heroImage="/images/cat_women_cashmere_1792401364617.jpg"
      products={womenProducts}
      categories={['Outerwear', 'Knitwear', 'Travel & Luggage', 'Small Leather Goods']}
    />
  );
}
