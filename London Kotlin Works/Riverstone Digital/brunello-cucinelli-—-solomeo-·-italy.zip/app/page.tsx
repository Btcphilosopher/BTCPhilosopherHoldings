'use client';

import React from 'react';
import HeroSection from '@/components/HeroSection';
import CategoryGrid from '@/components/CategoryGrid';
import PhilosophySection from '@/components/PhilosophySection';
import FeaturedProducts from '@/components/FeaturedProducts';

export default function HomePage() {
  return (
    <main className="min-h-screen">
      {/* 1. Cinematic Hero Section */}
      <HeroSection />

      {/* 2. Five-Category Collection Strip */}
      <CategoryGrid />

      {/* 3. Three-Part Brand Philosophy Section */}
      <PhilosophySection />

      {/* 4. Seasonal Featured Collection Product Grid */}
      <FeaturedProducts />
    </main>
  );
}
