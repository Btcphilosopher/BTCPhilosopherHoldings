'use client';

import React from 'react';
import CollectionLayout from '@/components/CollectionLayout';
import { PRODUCTS } from '@/data/products';

export default function KnitwearPage() {
  const knitwearProducts = PRODUCTS.filter(
    (p) => p.category === 'knitwear' || p.subCategory === 'Knitwear' || p.subCategory === 'Sweaters'
  );

  return (
    <CollectionLayout
      title="Fine Cashmere Knitwear"
      eyebrow="The Soul of the House · Solomeo"
      description="The cornerstone of Brunello Cucinelli. Spun from long-staple Mongolian cashmere fibres, carefully combed, dyed in soft natural earth tones, and hand-linked on traditional knitting beds in Umbria."
      heroImage="/images/cat_knitwear_detail_1792401365041.jpg"
      products={knitwearProducts}
      categories={['Sweaters', 'Knitwear']}
    />
  );
}
