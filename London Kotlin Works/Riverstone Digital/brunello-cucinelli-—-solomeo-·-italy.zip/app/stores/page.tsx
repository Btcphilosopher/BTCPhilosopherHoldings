'use client';

import React, { useState } from 'react';
import { STORES } from '@/data/stores';
import { StoreLocation } from '@/lib/types';
import { MapPin, Phone, Clock, Calendar, CheckCircle, Search, X } from 'lucide-react';

export default function StoresPage() {
  const [searchCity, setSearchCity] = useState('');
  const [selectedStoreForBooking, setSelectedStoreForBooking] = useState<StoreLocation | null>(null);
  const [bookingSubmitted, setBookingSubmitted] = useState(false);
  const [appointmentData, setAppointmentData] = useState({
    name: 'Eleanor Vance',
    email: 'eleanor.vance@example.com',
    phone: '+44 7700 900123',
    date: '2026-10-24',
    time: '14:30',
    type: 'Made-to-Measure Sartorial Tailoring',
  });

  const filteredStores = searchCity.trim()
    ? STORES.filter(
        (s) =>
          s.city.toLowerCase().includes(searchCity.toLowerCase()) ||
          s.country.toLowerCase().includes(searchCity.toLowerCase()) ||
          s.name.toLowerCase().includes(searchCity.toLowerCase())
      )
    : STORES;

  const handleBookAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingSubmitted(true);
  };

  const closeBookingModal = () => {
    setSelectedStoreForBooking(null);
    setBookingSubmitted(false);
  };

  return (
    <div className="pt-24 md:pt-28 pb-24 bg-[#F5F2EC] text-[#292723]">
      {/* Stores Hero Banner */}
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 mb-12 sm:mb-16">
        <div className="relative w-full h-[280px] sm:h-[380px] overflow-hidden bg-[#292723]">
          <img
            src="/images/cat_brand_solomeo_1792401365673.jpg"
            alt="Solomeo Italian heritage store locator"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent flex flex-col justify-end p-8 sm:p-12 text-white">
            <p className="text-[10px] sm:text-[11px] font-medium tracking-[0.28em] uppercase text-white/80 mb-2">
              Solomeo · Boutiques & Tailoring Ateliers
            </p>
            <h1 className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-light tracking-wide mb-2">
              Store Locator & Private Appointments
            </h1>
            <p className="text-xs sm:text-sm text-white/85 max-w-lg font-light">
              Experience the tactile warmth of pure cashmere and bespoke Italian tailoring at our international flagships.
            </p>
          </div>
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="max-w-[1200px] mx-auto px-5 sm:px-8 mb-12">
        <div className="bg-white p-4 sm:p-6 border border-[#D8CCBC]/60 flex flex-col sm:flex-row items-center gap-4">
          <div className="relative w-full flex-1 flex items-center">
            <Search size={18} className="text-[#756656] mr-3 shrink-0" />
            <input
              type="text"
              value={searchCity}
              onChange={(e) => setSearchCity(e.target.value)}
              placeholder="Filter by city (e.g. London, Milan, Paris, New York, Tokyo, Solomeo)..."
              className="w-full bg-transparent text-xs sm:text-sm text-[#292723] placeholder-[#A99A87] focus:outline-none"
            />
            {searchCity && (
              <button
                type="button"
                onClick={() => setSearchCity('')}
                className="p-1 text-[#756656]"
              >
                <X size={16} />
              </button>
            )}
          </div>
          <span className="text-[11px] uppercase tracking-wider text-[#756656] whitespace-nowrap">
            {filteredStores.length} {filteredStores.length === 1 ? 'Boutique' : 'Boutiques'} Available
          </span>
        </div>
      </div>

      {/* Stores List Grid */}
      <div className="max-w-[1200px] mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {filteredStores.map((store) => (
            <div
              key={store.id}
              className="bg-white p-6 sm:p-8 border border-[#D8CCBC]/50 flex flex-col justify-between hover:border-[#756656] transition-colors"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] font-medium tracking-[0.2em] uppercase text-[#756656] mb-2">
                  <span>{store.country}</span>
                  <span className="text-[#292723] font-serif-luxury font-semibold">{store.city}</span>
                </div>

                <h3 className="font-serif-luxury text-xl sm:text-2xl text-[#292723] font-normal mb-3">
                  {store.name}
                </h3>

                <div className="space-y-2.5 text-xs text-[#756656] mb-6">
                  <p className="flex items-start gap-2 text-[#292723]">
                    <MapPin size={15} className="text-[#756656] shrink-0 mt-0.5" />
                    <span>{store.address}, {store.postalCode}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone size={14} className="text-[#756656] shrink-0" />
                    <span>{store.phone}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Clock size={14} className="text-[#756656] shrink-0" />
                    <span>{store.hours}</span>
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-[#D8CCBC]/40 flex items-center justify-between">
                <span className="text-[10px] tracking-wider uppercase text-[#756656]">
                  Private Suite Available
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedStoreForBooking(store);
                    setBookingSubmitted(false);
                  }}
                  className="px-4 py-2 bg-[#292723] text-white text-[10px] font-medium tracking-[0.22em] uppercase hover:bg-[#756656] transition-colors flex items-center gap-1.5"
                >
                  <Calendar size={12} />
                  <span>Book Appointment</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Appointment Booking Modal */}
      {selectedStoreForBooking && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#F5F2EC] text-[#292723] w-full max-w-lg rounded-xs shadow-2xl border border-[#D8CCBC] overflow-hidden my-8">
            <div className="px-6 py-5 bg-white border-b border-[#D8CCBC]/60 flex items-center justify-between">
              <div>
                <h3 className="font-serif-luxury text-xl text-[#292723]">
                  Book Private Consultation
                </h3>
                <p className="text-[11px] text-[#756656] tracking-wider uppercase">
                  {selectedStoreForBooking.name} · {selectedStoreForBooking.city}
                </p>
              </div>
              <button
                type="button"
                onClick={closeBookingModal}
                className="p-1.5 text-[#756656] hover:text-[#292723]"
              >
                <X size={20} />
              </button>
            </div>

            {bookingSubmitted ? (
              <div className="p-8 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-[#EAE4DA] text-[#292723] mx-auto flex items-center justify-center">
                  <CheckCircle size={28} />
                </div>
                <h4 className="font-serif-luxury text-2xl text-[#292723]">
                  Appointment Requested
                </h4>
                <p className="text-xs text-[#756656] leading-relaxed max-w-sm mx-auto">
                  A private client advisor from our <span className="font-semibold text-[#292723]">{selectedStoreForBooking.city}</span> boutique will contact you at <span className="font-semibold text-[#292723]">{appointmentData.email}</span> to confirm your private salon appointment.
                </p>
                <button
                  type="button"
                  onClick={closeBookingModal}
                  className="px-6 py-2.5 bg-[#292723] text-white text-[11px] tracking-widest uppercase hover:bg-[#756656]"
                >
                  Close
                </button>
              </div>
            ) : (
              <form onSubmit={handleBookAppointment} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block text-[#756656] uppercase tracking-wider mb-1 text-[10px]">
                    Consultation Type
                  </label>
                  <select
                    value={appointmentData.type}
                    onChange={(e) => setAppointmentData({ ...appointmentData, type: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-xs focus:outline-none"
                  >
                    <option>Made-to-Measure Sartorial Tailoring</option>
                    <option>Cashmere Knitwear Styling & Wardrobe</option>
                    <option>Private Boutique Showcase</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#756656] uppercase tracking-wider mb-1 text-[10px]">
                      Preferred Date
                    </label>
                    <input
                      type="date"
                      required
                      value={appointmentData.date}
                      onChange={(e) => setAppointmentData({ ...appointmentData, date: e.target.value })}
                      className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-xs focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[#756656] uppercase tracking-wider mb-1 text-[10px]">
                      Preferred Time
                    </label>
                    <select
                      value={appointmentData.time}
                      onChange={(e) => setAppointmentData({ ...appointmentData, time: e.target.value })}
                      className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-xs focus:outline-none"
                    >
                      <option>11:00 AM</option>
                      <option>14:30 PM</option>
                      <option>16:00 PM</option>
                      <option>17:30 PM</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[#756656] uppercase tracking-wider mb-1 text-[10px]">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={appointmentData.name}
                    onChange={(e) => setAppointmentData({ ...appointmentData, name: e.target.value })}
                    className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-xs focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#756656] uppercase tracking-wider mb-1 text-[10px]">
                      Email
                    </label>
                    <input
                      type="email"
                      required
                      value={appointmentData.email}
                      onChange={(e) => setAppointmentData({ ...appointmentData, email: e.target.value })}
                      className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-xs focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[#756656] uppercase tracking-wider mb-1 text-[10px]">
                      Phone
                    </label>
                    <input
                      type="tel"
                      required
                      value={appointmentData.phone}
                      onChange={(e) => setAppointmentData({ ...appointmentData, phone: e.target.value })}
                      className="w-full bg-white border border-[#D8CCBC] px-3 py-2 text-xs focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full py-3 bg-[#292723] text-white text-[11px] font-medium tracking-[0.22em] uppercase hover:bg-[#756656] transition-colors"
                  >
                    Request Appointment
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
