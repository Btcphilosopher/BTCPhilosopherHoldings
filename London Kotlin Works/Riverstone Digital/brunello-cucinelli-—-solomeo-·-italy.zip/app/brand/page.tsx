'use client';

import React from 'react';
import Link from 'next/link';
import SolomeoCrest from '@/components/SolomeoCrest';

export default function BrandPage() {
  return (
    <div className="pt-24 md:pt-28 pb-24 bg-[#F5F2EC] text-[#292723]">
      {/* Brand Hero Banner */}
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 mb-16 sm:mb-24">
        <div className="relative w-full h-[400px] sm:h-[520px] lg:h-[620px] overflow-hidden bg-[#292723]">
          <img
            src="/images/cat_brand_solomeo_1792401365673.jpg"
            alt="The historic medieval castle of Solomeo in Umbria"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent flex flex-col justify-end p-8 sm:p-14 lg:p-20 text-white">
            <div className="flex items-center gap-2 mb-3">
              <SolomeoCrest size={22} className="text-white/90" />
              <p className="text-[10px] sm:text-[11px] font-medium tracking-[0.28em] uppercase text-white/90">
                Solomeo · Umbria · Italy
              </p>
            </div>
            <h1 className="font-serif-luxury text-3xl sm:text-5xl lg:text-6xl font-light tracking-wide max-w-2xl leading-[1.1] mb-4">
              Humanistic Capitalism & The Pursuit of Harmony
            </h1>
            <p className="text-xs sm:text-sm text-white/85 max-w-xl font-light leading-relaxed">
              Founded in 1978 in the medieval village of Solomeo, Brunello Cucinelli represents an ethical philosophy where craftsmanship, human dignity, and timeless beauty unite.
            </p>
          </div>
        </div>
      </div>

      {/* Chapter 1: The Hamlet of Solomeo */}
      <section className="max-w-[1280px] mx-auto px-6 sm:px-12 mb-20 sm:mb-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          <div className="lg:col-span-5 space-y-5">
            <span className="text-[10px] font-medium tracking-[0.26em] uppercase text-[#756656]">
              Chapter I · The Hamlet
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl font-normal leading-tight">
              A Renaissance Village Restored for the Soul
            </h2>
            <p className="text-xs sm:text-sm text-[#756656] leading-relaxed font-light">
              Solomeo is not merely the headquarters of the brand; it is its heart and conscience. In 1985, Brunello Cucinelli chose to restore the 14th-century castle and medieval alleys of the village to create a sanctuary where artisans could work surrounded by history and silence.
            </p>
            <p className="text-xs sm:text-sm text-[#756656] leading-relaxed font-light">
              Here, workshops open to views of olive groves and cypress valleys, and the ancient bell tower marks the rhythm of purposeful, unhurried creation.
            </p>
          </div>
          <div className="lg:col-span-7 aspect-16/10 overflow-hidden bg-[#EAE4DA] border border-[#D8CCBC]/60">
            <img
              src="/images/philo_landscape_sunset_1792401381643.jpg"
              alt="Solomeo village at sunset"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
          </div>
        </div>
      </section>

      {/* Chapter 2: The Art of Cashmere */}
      <section className="max-w-[1280px] mx-auto px-6 sm:px-12 mb-20 sm:mb-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          <div className="lg:col-span-7 order-2 lg:order-1 aspect-16/10 overflow-hidden bg-[#EAE4DA] border border-[#D8CCBC]/60">
            <img
              src="/images/philo_artisan_hands_1792401381559.jpg"
              alt="Italian artisans hand-linking pure cashmere"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
          </div>
          <div className="lg:col-span-5 order-1 lg:order-2 space-y-5">
            <span className="text-[10px] font-medium tracking-[0.26em] uppercase text-[#756656]">
              Chapter II · The Fleece
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl font-normal leading-tight">
              Pure Cashmere & Tactile Memory
            </h2>
            <p className="text-xs sm:text-sm text-[#756656] leading-relaxed font-light">
              Brunello Cucinelli began by revolutionising cashmere in 1978: dyeing the fleece in soft, sophisticated hues never before seen on the market.
            </p>
            <p className="text-xs sm:text-sm text-[#756656] leading-relaxed font-light">
              Only the longest, finest underfleece fibres from the Capra Hircus are selected, combed humanely during the spring molt. Every garment is designed to last generations, carrying the memory of touch and gentle wear.
            </p>
          </div>
        </div>
      </section>

      {/* Chapter 3: Dignity of Work */}
      <section className="bg-white py-16 sm:py-24 border-y border-[#D8CCBC]/40 mb-20">
        <div className="max-w-3xl mx-auto px-6 text-center space-y-6">
          <SolomeoCrest size={32} className="mx-auto text-[#756656]" />
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-normal text-[#292723]">
            &ldquo;Work as a Noble Act of Creation&rdquo;
          </h2>
          <p className="font-serif-luxury text-lg sm:text-xl text-[#756656] italic leading-relaxed font-light">
            In Solomeo, working hours are strictly respected so that artisans may return home to family and intellectual contemplation. Fair compensation, natural daylight in every atelier, and a communal dining room serving traditional Umbrian meals reflect the belief that profit must always serve humanity.
          </p>
          <div className="pt-4">
            <Link
              href="/knitwear"
              className="inline-flex items-center gap-2 px-6 py-3 border border-[#292723] text-[11px] font-medium tracking-[0.22em] uppercase hover:bg-[#292723] hover:text-white transition-colors"
            >
              <span>Explore The Craftsmanship</span>
              <span>→</span>
            </Link>
          </div>
        </div>
      </section>

      {/* Solomeo School of Arts & Crafts */}
      <div className="max-w-[1280px] mx-auto px-6 sm:px-12 text-center">
        <p className="text-[10px] font-medium tracking-[0.24em] uppercase text-[#756656] mb-3">
          The School of Solomeo
        </p>
        <h3 className="font-serif-luxury text-2xl sm:text-3xl text-[#292723] mb-4">
          Preserving Ancient Italian Manual Traditions
        </h3>
        <p className="text-xs sm:text-sm text-[#756656] max-w-xl mx-auto font-light leading-relaxed mb-8">
          The School of Arts and Crafts in Solomeo trains young generations of tailors, knitwear artisans, stonemasons, and horticulturalists, keeping the intangible heritage of Renaissance craftsmanship vibrant in modern Italy.
        </p>
        <Link
          href="/stores"
          className="text-[11px] font-medium tracking-[0.22em] uppercase text-[#292723] hover:text-[#756656] border-b border-[#292723] pb-1 hover:border-[#756656] transition-colors"
        >
          Locate a Global Boutique or Solomeo Atelier →
        </Link>
      </div>

    </div>
  );
}
