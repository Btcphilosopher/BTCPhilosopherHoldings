'use client';

import React, { useState, use } from 'react';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { PRODUCTS } from '@/data/products';
import { useStore } from '@/lib/store-context';
import {
  Heart,
  Plus,
  Minus,
  ShoppingBag,
  ShieldCheck,
  Gift,
  Ruler,
  Truck,
  RotateCcw,
  Sparkles,
  X,
} from 'lucide-react';
import SolomeoCrest from '@/components/SolomeoCrest';

export default function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = use(params);
  const product = PRODUCTS.find((p) => p.id === resolvedParams.id);

  if (!product) {
    notFound();
  }

  const { addToBag, toggleWishlist, isInWishlist } = useStore();
  const [selectedImage, setSelectedImage] = useState(product.galleryImages[0] || product.image);
  const [selectedColor, setSelectedColor] = useState(product.color);
  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || '');
  const [quantity, setQuantity] = useState(1);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);
  const [accordionOpen, setAccordionOpen] = useState<'craft' | 'materials' | 'shipping'>('craft');

  const isSaved = isInWishlist(product.id);
  const relatedProducts = PRODUCTS.filter((p) => p.id !== product.id).slice(0, 3);

  const handleAdd = () => {
    addToBag(product, selectedSize, selectedColor, quantity);
  };

  return (
    <div className="pt-24 md:pt-28 pb-24 bg-[#F5F2EC] text-[#292723]">
      {/* Breadcrumb Navigation */}
      <nav aria-label="Breadcrumb" className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 py-4 mb-6">
        <div className="flex items-center gap-2 text-[11px] font-medium tracking-[0.2em] uppercase text-[#756656]">
          <Link href="/" className="hover:text-[#292723]">Home</Link>
          <span>/</span>
          <Link href={`/${product.category}`} className="hover:text-[#292723]">
            {product.category}
          </Link>
          <span>/</span>
          <span className="text-[#292723] truncate max-w-xs">{product.name}</span>
        </div>
      </nav>

      {/* Main PDP Grid */}
      <div className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 mb-20 sm:mb-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 xl:gap-16">
          
          {/* Gallery View (Left 7 Columns) */}
          <div className="lg:col-span-7 flex flex-col-reverse md:flex-row gap-4">
            
            {/* Thumbnails (vertical on md+) */}
            <div className="flex md:flex-col gap-3 overflow-x-auto md:overflow-visible shrink-0 pb-2 md:pb-0">
              {product.galleryImages.map((imgUrl, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedImage(imgUrl)}
                  className={`relative w-16 sm:w-20 aspect-4/3 sm:aspect-square overflow-hidden bg-white border transition-all ${
                    selectedImage === imgUrl
                      ? 'border-[#292723] ring-1 ring-[#292723]'
                      : 'border-[#D8CCBC]/60 opacity-70 hover:opacity-100'
                  }`}
                  aria-label={`View image thumbnail ${idx + 1}`}
                >
                  <img
                    src={imgUrl}
                    alt={`${product.name} view ${idx + 1}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center"
                  />
                </button>
              ))}
            </div>

            {/* Large Active Stage */}
            <div className="relative flex-1 aspect-4/3 sm:aspect-[4/3.5] lg:aspect-[4/4.2] overflow-hidden bg-white border border-[#D8CCBC]/50">
              <img
                src={selectedImage}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transition-all duration-500"
              />
              <div className="absolute top-4 left-4 bg-[#F5F2EC]/90 px-3 py-1 border border-[#D8CCBC]/60">
                <span className="text-[10px] font-medium tracking-[0.24em] uppercase text-[#756656]">
                  {product.origin}
                </span>
              </div>
            </div>

          </div>

          {/* Product Purchase Module (Right 5 Columns) */}
          <div className="lg:col-span-5 flex flex-col justify-start">
            
            {/* House Mark & Category */}
            <div className="flex items-center gap-2 mb-2">
              <SolomeoCrest size={18} className="text-[#756656]" />
              <span className="text-[10px] sm:text-[11px] font-medium tracking-[0.24em] uppercase text-[#756656]">
                Brunello Cucinelli · {product.subCategory || product.category}
              </span>
            </div>

            {/* Product Title */}
            <h1 className="font-serif-luxury text-2xl sm:text-3xl md:text-4xl text-[#292723] font-normal leading-snug mb-3">
              {product.name}
            </h1>

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-6 pb-6 border-b border-[#D8CCBC]/60">
              <span className="font-mono text-xl sm:text-2xl font-medium text-[#292723] tabular-nums">
                {product.formattedPrice}
              </span>
              <span className="text-xs text-[#756656]">
                VAT and complimentary shipping included
              </span>
            </div>

            {/* Description */}
            <p className="text-xs sm:text-sm text-[#756656] font-light leading-relaxed mb-6">
              {product.description}
            </p>

            {/* Colour Picker */}
            <div className="mb-6">
              <div className="flex justify-between items-center text-xs mb-2">
                <span className="font-medium tracking-wider uppercase text-[10px] text-[#756656]">
                  Colourway
                </span>
                <span className="text-[#292723] font-medium text-xs">{selectedColor}</span>
              </div>
              <div className="flex items-center gap-2.5">
                {product.availableColors.map((c) => (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => setSelectedColor(c.name)}
                    className={`w-7 h-7 rounded-full border transition-transform flex items-center justify-center ${
                      selectedColor === c.name
                        ? 'border-[#292723] scale-110 shadow-xs'
                        : 'border-[#D8CCBC] hover:scale-105'
                    }`}
                    style={{ backgroundColor: c.hex }}
                    aria-label={`Select colour ${c.name}`}
                  />
                ))}
              </div>
            </div>

            {/* Size Selector + Size Guide */}
            <div className="mb-8">
              <div className="flex justify-between items-center text-xs mb-2">
                <span className="font-medium tracking-wider uppercase text-[10px] text-[#756656]">
                  Select Size
                </span>
                <button
                  type="button"
                  onClick={() => setSizeGuideOpen(true)}
                  className="flex items-center gap-1 text-[11px] text-[#756656] hover:text-[#292723] underline"
                >
                  <Ruler size={13} />
                  <span>Size & Fit Guide</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {product.sizes.map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setSelectedSize(sz)}
                    className={`py-2 px-3 text-xs font-medium tracking-wider uppercase border transition-all text-center ${
                      selectedSize === sz
                        ? 'bg-[#292723] text-white border-[#292723]'
                        : 'bg-white text-[#292723] border-[#D8CCBC] hover:border-[#756656]'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity & CTA Buttons */}
            <div className="space-y-3 mb-8">
              <div className="flex gap-3">
                {/* Quantity */}
                <div className="inline-flex items-center border border-[#D8CCBC] bg-white h-12 px-2">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 text-[#756656] hover:text-[#292723]"
                    aria-label="Decrease quantity"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="px-3 text-xs font-mono font-medium tabular-nums">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2 text-[#756656] hover:text-[#292723]"
                    aria-label="Increase quantity"
                  >
                    <Plus size={14} />
                  </button>
                </div>

                {/* Primary Add to Bag */}
                <button
                  type="button"
                  onClick={handleAdd}
                  className="flex-1 h-12 bg-[#292723] text-white text-[11px] sm:text-xs font-medium tracking-[0.24em] uppercase hover:bg-[#756656] transition-colors flex items-center justify-center gap-2"
                >
                  <ShoppingBag size={15} />
                  <span>Add to Shopping Bag</span>
                </button>
              </div>

              {/* Wishlist Button */}
              <button
                type="button"
                onClick={() => toggleWishlist(product.id)}
                className={`w-full h-11 border text-xs font-medium tracking-[0.2em] uppercase transition-colors flex items-center justify-center gap-2 ${
                  isSaved
                    ? 'bg-[#EAE4DA] border-[#D8CCBC] text-[#292723]'
                    : 'bg-white border-[#D8CCBC] text-[#756656] hover:text-[#292723] hover:border-[#292723]'
                }`}
              >
                <Heart
                  size={14}
                  className={isSaved ? 'fill-[#756656] text-[#756656]' : ''}
                />
                <span>{isSaved ? 'Saved in Wishlist' : 'Add to Wishlist'}</span>
              </button>
            </div>

            {/* Accordion Sections: Craftsmanship, Materials, Complimentary Shipping */}
            <div className="border-t border-[#D8CCBC]/60 divide-y divide-[#D8CCBC]/40 text-xs">
              
              {/* Craftsmanship */}
              <div className="py-3.5">
                <button
                  type="button"
                  onClick={() => setAccordionOpen(accordionOpen === 'craft' ? ('' as any) : 'craft')}
                  className="w-full flex items-center justify-between font-serif-luxury text-base text-[#292723] text-left"
                >
                  <span>Artisanal Craftsmanship</span>
                  <span>{accordionOpen === 'craft' ? '−' : '+'}</span>
                </button>
                {accordionOpen === 'craft' && (
                  <p className="mt-2 text-[#756656] leading-relaxed font-light">
                    {product.craftsmanship} Designed to embody the timeless spirit of Umbrian tailoring, balanced proportions, and human dignity.
                  </p>
                )}
              </div>

              {/* Materials */}
              <div className="py-3.5">
                <button
                  type="button"
                  onClick={() => setAccordionOpen(accordionOpen === 'materials' ? ('' as any) : 'materials')}
                  className="w-full flex items-center justify-between font-serif-luxury text-base text-[#292723] text-left"
                >
                  <span>Composition & Fine Fibres</span>
                  <span>{accordionOpen === 'materials' ? '−' : '+'}</span>
                </button>
                {accordionOpen === 'materials' && (
                  <div className="mt-2 text-[#756656] leading-relaxed font-light space-y-1">
                    <p>{product.materials}</p>
                    <p className="italic text-[11px] text-[#A99A87]">
                      Care: Specialist dry cleaning only. Store folded in breathable cotton bag.
                    </p>
                  </div>
                )}
              </div>

              {/* Shipping & Returns */}
              <div className="py-3.5">
                <button
                  type="button"
                  onClick={() => setAccordionOpen(accordionOpen === 'shipping' ? ('' as any) : 'shipping')}
                  className="w-full flex items-center justify-between font-serif-luxury text-base text-[#292723] text-left"
                >
                  <span>Complimentary Shipping & Returns</span>
                  <span>{accordionOpen === 'shipping' ? '−' : '+'}</span>
                </button>
                {accordionOpen === 'shipping' && (
                  <div className="mt-2 text-[#756656] leading-relaxed font-light space-y-1.5">
                    <p className="flex items-center gap-1.5">
                      <Truck size={14} className="text-[#292723]" />
                      <span>Complimentary express courier delivery (2–3 business days).</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      <RotateCcw size={14} className="text-[#292723]" />
                      <span>Complimentary returns within 30 days of receipt.</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      <Gift size={14} className="text-[#292723]" />
                      <span>Presented in Solomeo keepsake packaging with hand-penned card.</span>
                    </p>
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>
      </div>

      {/* Related Creations Section */}
      <section className="max-w-[1520px] mx-auto px-5 sm:px-8 lg:px-12 border-t border-[#D8CCBC]/50 pt-16">
        <div className="text-center mb-10">
          <p className="text-[10px] font-medium tracking-[0.26em] uppercase text-[#756656] mb-2">
            Harmonious Pairings
          </p>
          <h2 className="font-serif-luxury text-2xl sm:text-3xl text-[#292723]">
            Complete the Solomeo Look
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
          {relatedProducts.map((rel) => (
            <Link
              key={rel.id}
              href={`/product/${rel.id}`}
              className="group bg-white p-5 border border-[#D8CCBC]/40 hover:border-[#756656] transition-colors"
            >
              <div className="aspect-4/3 w-full overflow-hidden bg-[#F5F2EC] mb-4">
                <img
                  src={rel.image}
                  alt={rel.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center group-hover:scale-103 transition-transform duration-500"
                />
              </div>
              <p className="text-[10px] tracking-wider uppercase text-[#756656] mb-1">
                {rel.category}
              </p>
              <h3 className="font-serif-luxury text-base text-[#292723] group-hover:text-[#756656] transition-colors line-clamp-1">
                {rel.name}
              </h3>
              <p className="font-mono text-xs text-[#292723] mt-2 tabular-nums">
                {rel.formattedPrice}
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* Size Guide Modal */}
      {sizeGuideOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-[#F5F2EC] text-[#292723] w-full max-w-xl rounded-xs shadow-2xl border border-[#D8CCBC] overflow-hidden my-8">
            <div className="px-6 py-5 bg-white border-b border-[#D8CCBC]/60 flex items-center justify-between">
              <div>
                <h3 className="font-serif-luxury text-xl text-[#292723]">Size & Fit Guide</h3>
                <p className="text-[11px] text-[#756656] tracking-wider uppercase">
                  Italian Sartorial Measurements
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSizeGuideOpen(false)}
                className="p-1.5 text-[#756656] hover:text-[#292723]"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <p className="text-[#756656] leading-relaxed">
                Brunello Cucinelli garments adhere to Italian sizing standards, designed with relaxed, tailored proportions that drape naturally on the body without constricting.
              </p>

              <div className="overflow-x-auto border border-[#D8CCBC] bg-white">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-[#EAE4DA] text-[10px] uppercase tracking-wider text-[#756656] border-b border-[#D8CCBC]">
                      <th className="p-2.5">IT Size</th>
                      <th className="p-2.5">UK / US</th>
                      <th className="p-2.5">Chest (cm)</th>
                      <th className="p-2.5">Waist (cm)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#D8CCBC]/40 font-mono text-xs">
                    <tr>
                      <td className="p-2.5 font-medium">46 IT</td>
                      <td className="p-2.5">36 / S</td>
                      <td className="p-2.5">92 - 96</td>
                      <td className="p-2.5">78 - 82</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-medium">48 IT</td>
                      <td className="p-2.5">38 / M</td>
                      <td className="p-2.5">96 - 100</td>
                      <td className="p-2.5">82 - 86</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-medium">50 IT</td>
                      <td className="p-2.5">40 / L</td>
                      <td className="p-2.5">100 - 104</td>
                      <td className="p-2.5">86 - 90</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-medium">52 IT</td>
                      <td className="p-2.5">42 / XL</td>
                      <td className="p-2.5">104 - 108</td>
                      <td className="p-2.5">90 - 94</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="p-3 bg-white border border-[#D8CCBC]/50 text-[11px] text-[#756656] space-y-1">
                <p className="font-semibold text-[#292723]">Bespoke Made-to-Measure</p>
                <p>
                  For personalized adjustments, visit any of our global boutiques where a master tailor is available for private appointments.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSizeGuideOpen(false)}
                className="w-full py-2.5 bg-[#292723] text-white text-[11px] tracking-widest uppercase hover:bg-[#756656]"
              >
                Close Guide
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
