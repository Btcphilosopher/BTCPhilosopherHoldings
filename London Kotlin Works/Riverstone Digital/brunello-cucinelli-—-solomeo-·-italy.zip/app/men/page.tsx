'use client';

import React from 'react';
import CollectionLayout from '@/components/CollectionLayout';
import { PRODUCTS } from '@/data/products';

export default function MenPage() {
  const menProducts = PRODUCTS.filter(
    (p) => p.category === 'men' || p.category === 'knitwear' || p.category === 'accessories'
  );

  return (
    <CollectionLayout
      title="Men's Collection"
      eyebrow="Sartorial Excellence · Solomeo"
      description="Refined Italian tailoring and relaxed silhouettes crafted from the purest natural fibres: slub linen, deconstructed soft shoulder blazers, virgin wool flannels, and soft cashmere."
      heroImage="/images/cat_men_tailoring_1792401364296.jpg"
      products={menProducts}
      categories={['Tailoring', 'Sweaters', 'Trousers', 'Footwear']}
    />
  );
}
