'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Compass } from 'lucide-react';

interface HeroProps {
  onExploreCollection: () => void;
  onExploreApproach: () => void;
}

export function Hero({ onExploreCollection, onExploreApproach }: HeroProps) {
  return (
    <section id="hero" className="relative w-full bg-[#28231F] text-[#F5F1E9] overflow-hidden">
      {/* Container with deliberate 16:9 / responsive cinematic ratio */}
      <div className="relative min-h-[580px] sm:min-h-[640px] lg:min-h-[760px] w-full flex items-center">
        {/* Photographic background using supplied user asset */}
        <div className="absolute inset-0 z-0">
          <Image
            src="/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png"
            alt="Architectural living room with walnut-framed Hudson sofa, sculpted Ridge coffee table, Stillwater leather chair, and limestone fireplace"
            fill
            priority
            sizes="100vw"
            referrerPolicy="no-referrer"
            className="object-cover object-center sm:object-[center_35%]"
          />
          {/* Measured editorial contrast scrim: ensures WCAG 4.5:1 text legibility across all screens without washing out warm autumn sunlight */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#28231F]/90 via-[#28231F]/60 to-[#28231F]/20 sm:w-2/3" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#28231F]/80 via-transparent to-black/30" />
        </div>

        {/* Foreground Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32 w-full">
          <div className="max-w-xl lg:max-w-2xl">
            {/* Kicker */}
            <div className="inline-flex items-center gap-2 mb-4 text-xs tracking-[0.2em] uppercase font-sans-clean text-[#D8D0C4]">
              <span className="w-6 h-px bg-[#D8D0C4]/60" />
              <span>The Considered Home</span>
            </div>

            {/* Headline */}
            <h1 className="font-serif-luxury text-4xl sm:text-5xl lg:text-6xl font-light tracking-tight text-[#F5F1E9] leading-[1.08] mb-6 text-balance">
              A quieter kind of extraordinary.
            </h1>

            {/* Supporting Copy */}
            <p className="text-base sm:text-lg text-[#D8D0C4] font-light leading-relaxed mb-8 max-w-lg">
              Considered furniture. Honest materials. Room to live beautifully.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onExploreCollection}
                className="group inline-flex items-center justify-center gap-3 px-6 py-3.5 bg-[#FAF8F5] text-[#28231F] text-xs uppercase tracking-[0.15em] font-medium transition-all duration-200 hover:bg-[#F5F1E9] hover:shadow-md focus-visible:outline-2 focus-visible:outline-white"
              >
                <span>Explore the Collection</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <button
                onClick={onExploreApproach}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 border border-[#F5F1E9]/40 text-[#F5F1E9] text-xs uppercase tracking-[0.15em] font-medium transition-colors hover:bg-[#F5F1E9]/10 hover:border-[#F5F1E9] focus-visible:outline-2 focus-visible:outline-white"
              >
                <span>Our Approach</span>
              </button>
            </div>

            {/* Subtle Context Tagline */}
            <div className="mt-12 pt-6 border-t border-[#F5F1E9]/20 flex items-center gap-6 text-[11px] text-[#D8D0C4]/80 tracking-wide font-sans-clean">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#A36D47]" />
                <span>Solid American Walnut</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#D8D0C4]" />
                <span>Belgian Flax Linen</span>
              </div>
              <div className="hidden sm:flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#A36D47]" />
                <span>Vegetable-Tanned Steerhide</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
