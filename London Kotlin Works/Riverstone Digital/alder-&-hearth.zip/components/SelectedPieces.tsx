'use client';

import React, { useState, useMemo } from 'react';
import Image from 'next/image';
import { Bookmark, ArrowRight, SlidersHorizontal, Check, Info } from 'lucide-react';
import { PRODUCTS, Product } from '@/lib/data';

interface SelectedPiecesProps {
  activeRoomFilter: 'all' | 'living' | 'dining' | 'bedroom' | 'workspace';
  onFilterChange: (room: 'all' | 'living' | 'dining' | 'bedroom' | 'workspace') => void;
  onSelectProduct: (product: Product) => void;
  isSaved: (productId: string) => boolean;
  onToggleSave: (productId: string) => void;
}

export function SelectedPieces({
  activeRoomFilter,
  onFilterChange,
  onSelectProduct,
  isSaved,
  onToggleSave,
}: SelectedPiecesProps) {
  const [sortOption, setSortOption] = useState<'curated' | 'price-asc' | 'price-desc' | 'name'>('curated');
  const [materialFilter, setMaterialFilter] = useState<string>('all');

  const filteredProducts = useMemo(() => {
    let list = [...PRODUCTS];

    if (activeRoomFilter !== 'all') {
      list = list.filter((p) => p.room === activeRoomFilter);
    }

    if (materialFilter !== 'all') {
      list = list.filter((p) =>
        p.materials.some((m) => m.toLowerCase().includes(materialFilter.toLowerCase()))
      );
    }

    switch (sortOption) {
      case 'price-asc':
        return list.sort((a, b) => a.priceUSD - b.priceUSD);
      case 'price-desc':
        return list.sort((a, b) => b.priceUSD - a.priceUSD);
      case 'name':
        return list.sort((a, b) => a.name.localeCompare(b.name));
      case 'curated':
      default:
        return list;
    }
  }, [activeRoomFilter, materialFilter, sortOption]);

  const categories = [
    { id: 'all', label: 'All Pieces', count: PRODUCTS.length },
    { id: 'living', label: 'Living', count: PRODUCTS.filter((p) => p.room === 'living').length },
    { id: 'dining', label: 'Dining', count: PRODUCTS.filter((p) => p.room === 'dining').length },
    { id: 'bedroom', label: 'Bedroom', count: PRODUCTS.filter((p) => p.room === 'bedroom').length },
    { id: 'workspace', label: 'Workspace', count: PRODUCTS.filter((p) => p.room === 'workspace').length },
  ] as const;

  return (
    <section id="collection" className="py-20 lg:py-28 bg-[#F5F1E9] border-b border-[#D8D0C4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-sans-clean text-[#757969] mb-3">
            <span className="w-6 h-px bg-[#757969]" />
            <span>Designed for Living</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-[#D8D0C4]">
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-light text-[#28231F] text-balance">
              Pieces to come home to.
            </h2>
            <div className="flex items-center gap-4 text-xs text-[#757969] uppercase tracking-wider font-sans-clean">
              <span>{filteredProducts.length} of {PRODUCTS.length} Concept Pieces</span>
              <span aria-hidden="true">·</span>
              <span className="text-[#A36D47]">Hudson Valley Workshop</span>
            </div>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-10 pb-4 border-b border-[#D8D0C4]/60">
          {/* Room Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((cat) => {
              const active = activeRoomFilter === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => onFilterChange(cat.id)}
                  className={`px-3.5 py-2 text-xs tracking-wider uppercase whitespace-nowrap transition-all duration-200 border rounded-xs ${
                    active
                      ? 'bg-[#49372B] text-[#F5F1E9] border-[#49372B] font-medium shadow-xs'
                      : 'bg-transparent text-[#49372B] border-transparent hover:border-[#D8D0C4] hover:bg-[#FAF8F5]'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className={`ml-1.5 text-[10px] ${active ? 'text-[#D8D0C4]' : 'text-[#757969]'}`}>
                    ({cat.count})
                  </span>
                </button>
              );
            })}
          </div>

          {/* Secondary Sorting & Material Filter */}
          <div className="flex items-center gap-3">
            {/* Material Quick Filter */}
            <div className="flex items-center gap-2">
              <label htmlFor="material-select" className="text-xs uppercase tracking-wider text-[#757969] hidden sm:inline">
                Material:
              </label>
              <select
                id="material-select"
                value={materialFilter}
                onChange={(e) => setMaterialFilter(e.target.value)}
                className="bg-[#FAF8F5] border border-[#D8D0C4] text-[#28231F] text-xs py-1.5 px-2.5 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B]"
              >
                <option value="all">All Materials</option>
                <option value="walnut">American Walnut</option>
                <option value="oak">White Oak</option>
                <option value="linen">Belgian Linen</option>
                <option value="leather">Cognac Leather</option>
                <option value="limestone">Limestone</option>
              </select>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-2">
              <label htmlFor="sort-select" className="text-xs uppercase tracking-wider text-[#757969] hidden sm:inline">
                Sort:
              </label>
              <select
                id="sort-select"
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value as any)}
                className="bg-[#FAF8F5] border border-[#D8D0C4] text-[#28231F] text-xs py-1.5 px-2.5 rounded-xs focus-visible:outline-2 focus-visible:outline-[#49372B]"
              >
                <option value="curated">Curated Order</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="name">Name (A–Z)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center bg-[#FAF8F5] border border-[#D8D0C4] px-6">
            <Info className="w-8 h-8 text-[#757969] mx-auto mb-3 stroke-1" />
            <h3 className="font-serif-luxury text-2xl text-[#28231F] mb-2">No pieces found in this view</h3>
            <p className="text-sm text-[#757969] max-w-md mx-auto mb-6">
              We could not find any concept pieces matching your current filters. Try resetting the room or material selection.
            </p>
            <button
              onClick={() => {
                onFilterChange('all');
                setMaterialFilter('all');
              }}
              className="px-5 py-2.5 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider font-medium hover:bg-[#28231F] transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => {
              const saved = isSaved(product.id);
              return (
                <div
                  key={product.id}
                  className="group flex flex-col bg-[#FAF8F5] border border-[#D8D0C4] transition-all duration-300 hover:border-[#A36D47]/60 hover:shadow-xs"
                >
                  {/* Image Presentation */}
                  <div className="relative aspect-[16/10] bg-[#ECE6DC]/60 overflow-hidden border-b border-[#D8D0C4]">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      referrerPolicy="no-referrer"
                      className="object-contain p-4 group-hover:scale-103 transition-transform duration-500"
                    />

                    {/* Bookmark / Save Action */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleSave(product.id);
                      }}
                      aria-label={saved ? `Remove ${product.name} from saved shortlist` : `Save ${product.name} to shortlist`}
                      className={`absolute top-3 right-3 p-2.5 rounded-full backdrop-blur-xs transition-all duration-200 z-10 ${
                        saved
                          ? 'bg-[#49372B] text-[#F5F1E9]'
                          : 'bg-[#F5F1E9]/80 text-[#49372B] hover:bg-[#F5F1E9] hover:text-[#A36D47]'
                      }`}
                      title={saved ? 'In your shortlist' : 'Save piece'}
                    >
                      <Bookmark className="w-4 h-4" fill={saved ? '#F5F1E9' : 'none'} strokeWidth={1.5} />
                    </button>

                    {/* Subtle Room Badge */}
                    <div className="absolute bottom-3 left-3 bg-[#FAF8F5]/90 backdrop-blur-xs px-2.5 py-1 text-[10px] uppercase tracking-widest text-[#757969] border border-[#D8D0C4]/70">
                      {product.roomLabel}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Title & Price Baseline */}
                      <div className="flex items-baseline justify-between gap-4 mb-2">
                        <h3 className="font-serif-luxury text-2xl font-normal text-[#28231F] group-hover:text-[#49372B] transition-colors">
                          {product.name}
                        </h3>
                        <span className="font-sans-clean font-medium text-sm text-[#49372B] tabular-nums whitespace-nowrap">
                          ${product.priceUSD.toLocaleString()}
                        </span>
                      </div>

                      {/* Dimensions & Material Preview */}
                      <p className="text-xs text-[#757969] mb-3 font-light leading-relaxed">
                        {product.dimensions.imperial}
                      </p>

                      <p className="text-sm text-[#49372B]/90 font-light line-clamp-2 mb-4 leading-relaxed">
                        {product.description}
                      </p>
                    </div>

                    {/* Footer Actions */}
                    <div className="pt-4 border-t border-[#D8D0C4]/60 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        {product.finishes.slice(0, 3).map((f) => (
                          <span
                            key={f.id}
                            className="w-3.5 h-3.5 rounded-full border border-black/15"
                            style={{ backgroundColor: f.swatchHex }}
                            title={f.name}
                          />
                        ))}
                        {product.finishes.length > 3 && (
                          <span className="text-[10px] text-[#757969]">
                            +{product.finishes.length - 3}
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => onSelectProduct(product)}
                        className="inline-flex items-center gap-1.5 text-xs uppercase tracking-wider font-medium text-[#49372B] hover:text-[#A36D47] group-hover:translate-x-0.5 transition-all"
                      >
                        <span>Specifications</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Concept Catalogue Notice */}
        <div className="mt-16 p-6 bg-[#FAF8F5] border border-[#D8D0C4] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#49372B] block">
              Studio Catalogue Note
            </span>
            <p className="text-xs text-[#757969] leading-relaxed max-w-2xl">
              All pieces in this collection are conceptual American luxury works created to demonstrate
              architectural furniture design, authentic material specifications, and editorial commerce.
              Prices shown in USD reflect estimated bespoke workshop fabrication.
            </p>
          </div>
          <span className="text-[11px] uppercase tracking-wider text-[#A36D47] whitespace-nowrap font-medium">
            Handcrafted in New York
          </span>
        </div>
      </div>
    </section>
  );
}
