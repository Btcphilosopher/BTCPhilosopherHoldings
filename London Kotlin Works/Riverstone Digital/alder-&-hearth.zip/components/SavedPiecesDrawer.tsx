'use client';

import React, { useEffect } from 'react';
import Image from 'next/image';
import { X, Trash2, ArrowRight, Bookmark, Sparkles, FolderDown } from 'lucide-react';
import { Product } from '@/lib/data';

interface SavedPiecesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedProducts: Product[];
  totalInvestment: number;
  onRemovePiece: (productId: string) => void;
  onClearAll: () => void;
  onInspectProduct: (product: Product) => void;
  onStartConsultationWithShortlist: () => void;
}

export function SavedPiecesDrawer({
  isOpen,
  onClose,
  savedProducts,
  totalInvestment,
  onRemovePiece,
  onClearAll,
  onInspectProduct,
  onStartConsultationWithShortlist,
}: SavedPiecesDrawerProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="drawer-title"
      className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end animate-fadeIn"
    >
      <div className="relative w-full max-w-md bg-[#FAF8F5] border-l border-[#D8D0C4] shadow-2xl flex flex-col h-full animate-slideLeft">
        {/* Drawer Header */}
        <div className="px-6 py-5 bg-[#F5F1E9] border-b border-[#D8D0C4] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <Bookmark className="w-5 h-5 text-[#A36D47]" strokeWidth={1.5} />
            <h2 id="drawer-title" className="font-serif-luxury text-xl font-medium text-[#28231F]">
              Saved Pieces Shortlist
            </h2>
            <span className="text-xs text-[#757969] font-mono tabular-nums">
              ({savedProducts.length})
            </span>
          </div>

          <button
            onClick={onClose}
            aria-label="Close saved pieces shortlist"
            className="p-1.5 text-[#49372B] hover:text-[#28231F] hover:bg-[#D8D0C4]/40 rounded-xs transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {savedProducts.length === 0 ? (
            <div className="py-20 text-center space-y-4">
              <Bookmark className="w-10 h-10 text-[#D8D0C4] mx-auto stroke-1" />
              <div className="space-y-1">
                <h3 className="font-serif-luxury text-xl text-[#28231F]">Your Shortlist is Empty</h3>
                <p className="text-xs text-[#757969] max-w-xs mx-auto leading-relaxed">
                  Click the bookmark icon on any piece to save it for consultation planning or architectural review.
                </p>
              </div>
              <button
                onClick={onClose}
                className="mt-2 px-4 py-2 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider font-medium hover:bg-[#28231F] transition-colors"
              >
                Browse Collection
              </button>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between text-xs text-[#757969] pb-2 border-b border-[#D8D0C4]/60">
                <span>Selected Works</span>
                <button
                  onClick={onClearAll}
                  className="text-red-700 hover:underline"
                >
                  Clear All
                </button>
              </div>

              {savedProducts.map((product) => (
                <div
                  key={product.id}
                  className="p-3 bg-[#F5F1E9] border border-[#D8D0C4] flex items-center gap-4 transition-colors hover:border-[#A36D47]/60"
                >
                  <div
                    onClick={() => {
                      onClose();
                      onInspectProduct(product);
                    }}
                    className="relative w-20 h-16 bg-[#ECE6DC] shrink-0 overflow-hidden cursor-pointer border border-[#D8D0C4]"
                  >
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      sizes="80px"
                      referrerPolicy="no-referrer"
                      className="object-contain p-1"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between gap-2">
                      <h4
                        onClick={() => {
                          onClose();
                          onInspectProduct(product);
                        }}
                        className="font-serif-luxury text-base font-normal text-[#28231F] truncate hover:text-[#A36D47] cursor-pointer"
                      >
                        {product.name}
                      </h4>
                      <span className="text-xs font-medium text-[#49372B] tabular-nums whitespace-nowrap">
                        ${product.priceUSD.toLocaleString()}
                      </span>
                    </div>

                    <p className="text-[11px] text-[#757969] truncate mb-1">
                      {product.dimensions.imperial}
                    </p>

                    <div className="flex items-center justify-between text-[11px] pt-1">
                      <button
                        onClick={() => {
                          onClose();
                          onInspectProduct(product);
                        }}
                        className="text-[#A36D47] hover:underline"
                      >
                        Specifications &rarr;
                      </button>

                      <button
                        onClick={() => onRemovePiece(product.id)}
                        className="text-[#757969] hover:text-red-700 p-1"
                        aria-label={`Remove ${product.name} from shortlist`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        {/* Drawer Footer */}
        {savedProducts.length > 0 && (
          <div className="p-6 bg-[#F5F1E9] border-t border-[#D8D0C4] shrink-0 space-y-4">
            <div className="flex items-baseline justify-between">
              <span className="text-xs uppercase tracking-wider font-semibold text-[#49372B]">
                Estimated Shortlist Total:
              </span>
              <span className="font-sans-clean text-lg font-medium text-[#28231F] tabular-nums">
                ${totalInvestment.toLocaleString()} USD
              </span>
            </div>

            <p className="text-[11px] text-[#757969] leading-relaxed">
              Illustrative workshop fabrication pricing. Does not include bespoke dimensional adjustments or architectural delivery.
            </p>

            <button
              onClick={() => {
                onClose();
                onStartConsultationWithShortlist();
              }}
              className="w-full py-3.5 px-4 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider font-medium hover:bg-[#28231F] transition-colors flex items-center justify-center gap-2"
            >
              <span>Transfer to Consultation Brief</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
