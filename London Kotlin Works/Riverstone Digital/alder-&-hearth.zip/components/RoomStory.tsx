'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Bookmark, Eye, Plus, X } from 'lucide-react';
import { PRODUCTS, Product } from '@/lib/data';

interface RoomStoryProps {
  onSelectProduct: (product: Product) => void;
  isSaved: (productId: string) => boolean;
  onToggleSave: (productId: string) => void;
}

interface HotspotItem {
  id: string;
  productId: string;
  title: string;
  subtitle: string;
  xPercent: number; // percentage from left
  yPercent: number; // percentage from top
  priceUSD: number;
}

const STORY_HOTSPOTS: HotspotItem[] = [
  {
    id: 'hs-sofa',
    productId: 'p-1',
    title: 'Hudson Sofa',
    subtitle: 'Solid Walnut & Oatmeal Flax Linen',
    xPercent: 70,
    yPercent: 55,
    priceUSD: 5850,
  },
  {
    id: 'hs-chair',
    productId: 'p-2',
    title: 'Stillwater Lounge Chair',
    subtitle: 'Saddle Cognac Leather & Walnut',
    xPercent: 23,
    yPercent: 62,
    priceUSD: 3200,
  },
  {
    id: 'hs-table',
    productId: 'p-3',
    title: 'Ridge Coffee Table',
    subtitle: 'Solid Sculpted American Walnut',
    xPercent: 54,
    yPercent: 68,
    priceUSD: 4100,
  },
  {
    id: 'hs-hearth',
    productId: 'p-4',
    title: 'Champlain Limestone Hearth',
    subtitle: 'Honed Vermont Sedimentary Stone',
    xPercent: 7,
    yPercent: 48,
    priceUSD: 6400,
  },
];

export function RoomStory({ onSelectProduct, isSaved, onToggleSave }: RoomStoryProps) {
  const [activeHotspotId, setActiveHotspotId] = useState<string | null>('hs-chair');
  const [showHotspots, setShowHotspots] = useState<boolean>(true);

  const activeHotspot = STORY_HOTSPOTS.find((h) => h.id === activeHotspotId);
  const activeProduct = activeHotspot
    ? PRODUCTS.find((p) => p.id === activeHotspot.productId)
    : null;

  return (
    <section id="room-story" className="py-20 lg:py-28 bg-[#F5F1E9] border-b border-[#D8D0C4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Story Header */}
        <div className="mb-10">
          <div className="flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-sans-clean text-[#757969] mb-3">
            <span className="w-6 h-px bg-[#757969]" />
            <span>Room Story · Edition No. 04</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-[#D8D0C4]">
            <div>
              <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-light text-[#28231F] text-balance">
                A Sunday in the Hudson Valley.
              </h2>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowHotspots(!showHotspots)}
                className="text-xs uppercase tracking-wider text-[#49372B] hover:text-[#A36D47] underline underline-offset-4"
              >
                {showHotspots ? 'Hide Interactive Markers' : 'Show Interactive Markers'}
              </button>
            </div>
          </div>
        </div>

        {/* Narrative Passage */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-10 text-[#49372B]/90 font-light text-base sm:text-lg leading-relaxed">
          <div className="md:col-span-8">
            <p>
              Afternoon sunlight filters through floor-to-ceiling blackened steel windows, casting warm
              geometric shadows across vertical walnut paneling. The fireplace breathes gentle heat into the
              room as Belgian linen and vegetable-tanned steerhide invite hours of quiet reading and unhurried
              conversation.
            </p>
          </div>
          <div className="md:col-span-4 flex flex-col justify-end text-xs uppercase tracking-wider text-[#757969] space-y-1">
            <span>Location: Columbia County, New York</span>
            <span>Season: Mid-Autumn</span>
            <span>Curated pieces: 4 visible elements</span>
          </div>
        </div>

        {/* Large Interactive Interior Photograph */}
        <div className="relative aspect-[16/9] w-full bg-[#28231F] overflow-hidden border border-[#D8D0C4] shadow-sm">
          <Image
            src="/assets/aistudio/3c1ab4c4-9e05-4cad-9308-58b5bb60597f_95822a6b.png"
            alt="A Sunday in the Hudson Valley: Living room with Hudson sofa, Ridge coffee table, and Stillwater chair"
            fill
            sizes="100vw"
            referrerPolicy="no-referrer"
            className="object-cover object-center"
          />

          {/* Interactive Hotspot Pins */}
          {showHotspots &&
            STORY_HOTSPOTS.map((hs, index) => {
              const isSelected = activeHotspotId === hs.id;
              return (
                <div
                  key={hs.id}
                  className="absolute z-20"
                  style={{
                    left: `${hs.xPercent}%`,
                    top: `${hs.yPercent}%`,
                    transform: 'translate(-50%, -50%)',
                  }}
                >
                  <button
                    onClick={() => setActiveHotspotId(isSelected ? null : hs.id)}
                    aria-label={`Inspect ${hs.title}`}
                    className={`group relative flex items-center justify-center transition-transform ${
                      isSelected ? 'scale-125' : 'hover:scale-110'
                    }`}
                  >
                    <span className="absolute w-8 h-8 rounded-full bg-[#F5F1E9]/40 animate-ping opacity-75" />
                    <span
                      className={`relative w-7 h-7 rounded-full flex items-center justify-center text-xs font-serif-luxury font-bold border transition-colors shadow-md ${
                        isSelected
                          ? 'bg-[#49372B] text-[#F5F1E9] border-white'
                          : 'bg-[#F5F1E9] text-[#28231F] border-[#49372B]'
                      }`}
                    >
                      {index + 1}
                    </span>
                  </button>
                </div>
              );
            })}

          {/* Active Hotspot Detail Card Overlay */}
          {showHotspots && activeHotspot && activeProduct && (
            <div className="absolute bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:bottom-6 z-30 max-w-sm bg-[#FAF8F5] p-5 border border-[#49372B] shadow-xl text-[#28231F] animate-fadeIn">
              <div className="flex items-start justify-between gap-4 mb-2">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-[#757969] block mb-0.5">
                    Visible In Scene
                  </span>
                  <h4 className="font-serif-luxury text-xl font-normal text-[#28231F]">
                    {activeProduct.name}
                  </h4>
                </div>
                <button
                  onClick={() => setActiveHotspotId(null)}
                  className="p-1 text-[#757969] hover:text-[#28231F]"
                  aria-label="Close detail card"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-[#757969] mb-3 leading-relaxed">
                {activeProduct.subtitle}
              </p>

              <div className="flex items-baseline justify-between mb-4 pt-2 border-t border-[#D8D0C4]">
                <span className="text-xs uppercase tracking-wider text-[#757969]">Investment</span>
                <span className="font-sans-clean font-medium text-sm text-[#49372B] tabular-nums">
                  ${activeProduct.priceUSD.toLocaleString()} USD
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onSelectProduct(activeProduct)}
                  className="flex-1 py-2 px-3 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider font-medium hover:bg-[#28231F] transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>View Specifications</span>
                  <ArrowRight className="w-3 h-3" />
                </button>

                <button
                  onClick={() => onToggleSave(activeProduct.id)}
                  aria-label="Save piece"
                  className={`p-2 border transition-colors ${
                    isSaved(activeProduct.id)
                      ? 'bg-[#49372B] text-[#F5F1E9] border-[#49372B]'
                      : 'bg-white text-[#49372B] border-[#D8D0C4] hover:bg-[#F5F1E9]'
                  }`}
                  title={isSaved(activeProduct.id) ? 'Saved in shortlist' : 'Save piece'}
                >
                  <Bookmark className="w-4 h-4" fill={isSaved(activeProduct.id) ? '#F5F1E9' : 'none'} />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Piece Link Strip below the photograph */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {STORY_HOTSPOTS.map((hs, index) => {
            const product = PRODUCTS.find((p) => p.id === hs.productId);
            if (!product) return null;
            const isSelected = activeHotspotId === hs.id;

            return (
              <button
                key={hs.id}
                onClick={() => {
                  setActiveHotspotId(hs.id);
                  onSelectProduct(product);
                }}
                className={`text-left p-4 bg-[#FAF8F5] border transition-all duration-200 flex flex-col justify-between ${
                  isSelected
                    ? 'border-[#49372B] shadow-xs bg-[#FAF8F5]'
                    : 'border-[#D8D0C4] hover:border-[#A36D47]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] uppercase tracking-widest text-[#757969]">
                      Piece 0{index + 1}
                    </span>
                    <span className="text-xs font-medium text-[#49372B] tabular-nums">
                      ${product.priceUSD.toLocaleString()}
                    </span>
                  </div>
                  <h4 className="font-serif-luxury text-lg font-normal text-[#28231F] mb-1">
                    {product.name}
                  </h4>
                  <p className="text-xs text-[#757969] line-clamp-1">
                    {product.primaryMaterial}
                  </p>
                </div>
                <div className="mt-3 pt-3 border-t border-[#D8D0C4]/60 flex items-center justify-between text-xs text-[#A36D47]">
                  <span>Explore piece</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
