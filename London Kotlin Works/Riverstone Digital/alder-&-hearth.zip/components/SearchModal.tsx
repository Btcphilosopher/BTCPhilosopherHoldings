'use client';

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import Image from 'next/image';
import { Search, X, ArrowRight, CornerDownLeft, Sparkles } from 'lucide-react';
import { PRODUCTS, Product } from '@/lib/data';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
}

export function SearchModal({ isOpen, onClose, onSelectProduct }: SearchModalProps) {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleClose = useCallback(() => {
    setQuery('');
    onClose();
  }, [onClose]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleClose]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return PRODUCTS.slice(0, 4); // show 4 featured pieces if empty

    return PRODUCTS.filter((p) => {
      return (
        p.name.toLowerCase().includes(q) ||
        p.room.toLowerCase().includes(q) ||
        p.roomLabel.toLowerCase().includes(q) ||
        p.subtitle.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.materials.some((m) => m.toLowerCase().includes(q))
      );
    });
  }, [query]);

  const quickSearches = ['Walnut', 'Cognac Leather', 'Belgian Linen', 'Dining', 'Limestone', 'Sofa'];

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Search furniture collection"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-start justify-center p-4 sm:p-6 lg:p-10 pt-16 sm:pt-24 animate-fadeIn"
    >
      <div className="relative w-full max-w-2xl bg-[#FAF8F5] border border-[#49372B]/30 shadow-2xl overflow-hidden flex flex-col">
        {/* Search Input Bar */}
        <div className="p-4 sm:p-6 bg-[#F5F1E9] border-b border-[#D8D0C4] flex items-center gap-3 shrink-0">
          <Search className="w-5 h-5 text-[#49372B] shrink-0" strokeWidth={1.5} />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by piece name, room, or material (e.g., walnut, dining, linen)..."
            className="flex-1 bg-transparent text-[#28231F] text-base placeholder-[#757969] focus:outline-none font-sans-clean"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-[#757969] hover:text-[#28231F]"
              aria-label="Clear search query"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={handleClose}
            className="text-xs uppercase tracking-wider text-[#49372B] hover:text-[#A36D47] px-2 py-1 border border-[#D8D0C4]"
          >
            Esc
          </button>
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-6 py-3 bg-[#FAF8F5] border-b border-[#D8D0C4]/60 flex items-center gap-2 overflow-x-auto text-xs text-[#757969]">
          <span className="shrink-0 text-[11px] uppercase tracking-wider">Suggested:</span>
          {quickSearches.map((term) => (
            <button
              key={term}
              onClick={() => setQuery(term)}
              className="px-2.5 py-1 bg-[#F5F1E9] hover:bg-[#49372B] hover:text-[#F5F1E9] border border-[#D8D0C4] rounded-xs text-[11px] transition-colors whitespace-nowrap shrink-0"
            >
              {term}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-4 sm:p-6 space-y-3">
          <div className="flex items-center justify-between text-xs text-[#757969] mb-2 px-1">
            <span>
              {query.trim()
                ? `Results for "${query}" (${results.length})`
                : 'Featured Collection Pieces'}
            </span>
            <span className="text-[11px]">Click piece to inspect</span>
          </div>

          {results.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <p className="font-serif-luxury text-xl text-[#28231F]">No pieces found</p>
              <p className="text-xs text-[#757969] max-w-sm mx-auto leading-relaxed">
                We couldn&apos;t find any concept furniture matching &quot;{query}&quot;. Try exploring &apos;walnut&apos;, &apos;sofa&apos;, &apos;leather&apos;, &apos;dining&apos;, or &apos;table&apos;.
              </p>
              <button
                onClick={() => setQuery('')}
                className="mt-2 px-4 py-2 bg-[#49372B] text-[#F5F1E9] text-xs uppercase tracking-wider hover:bg-[#28231F]"
              >
                Clear Search
              </button>
            </div>
          ) : (
            results.map((product) => (
              <button
                key={product.id}
                onClick={() => {
                  handleClose();
                  onSelectProduct(product);
                }}
                className="w-full text-left p-3.5 bg-[#F5F1E9] hover:bg-[#FAF8F5] border border-[#D8D0C4] hover:border-[#49372B] transition-colors flex items-center gap-4 group"
              >
                <div className="relative w-16 h-14 bg-[#ECE6DC] shrink-0 overflow-hidden border border-[#D8D0C4]">
                  <Image
                    src={product.image}
                    alt={product.name}
                    fill
                    sizes="64px"
                    referrerPolicy="no-referrer"
                    className="object-contain p-1"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between gap-2">
                    <h4 className="font-serif-luxury text-lg font-normal text-[#28231F] group-hover:text-[#49372B] truncate">
                      {product.name}
                    </h4>
                    <span className="text-xs font-medium text-[#49372B] tabular-nums whitespace-nowrap">
                      ${product.priceUSD.toLocaleString()} USD
                    </span>
                  </div>

                  <p className="text-xs text-[#757969] truncate mb-1">
                    {product.roomLabel} · {product.primaryMaterial}
                  </p>
                  <p className="text-[11px] text-[#49372B]/80 truncate">
                    {product.dimensions.imperial}
                  </p>
                </div>

                <ArrowRight className="w-4 h-4 text-[#757969] group-hover:text-[#49372B] group-hover:translate-x-1 transition-all shrink-0" />
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
