'use client';

import React, { useState, useEffect } from 'react';
import { Search, Bookmark, Menu, X, ArrowRight, Compass } from 'lucide-react';

interface HeaderProps {
  savedCount: number;
  onOpenSavedDrawer: () => void;
  onOpenSearch: () => void;
  onOpenConsultation: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export function Header({
  savedCount,
  onOpenSavedDrawer,
  onOpenSearch,
  onOpenConsultation,
  onNavigateSection,
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    onNavigateSection(sectionId);
  };

  return (
    <>
      {/* Top Editorial Announcement */}
      <div className="bg-[#49372B] text-[#F5F1E9] text-[11px] sm:text-xs tracking-wider uppercase py-2 px-4 text-center border-b border-[#3b2d23] transition-colors">
        <div className="max-w-7xl mx-auto flex items-center justify-between sm:justify-center gap-4">
          <span className="hidden sm:inline italic font-serif-luxury lowercase text-sm tracking-normal text-[#D8D0C4]">
            Considered design. Beautifully made.
          </span>
          <span className="hidden sm:inline text-[#757969]">·</span>
          <span className="tracking-widest">Handcrafted in the Hudson Valley tradition</span>
          <span className="hidden md:inline text-[#757969]">·</span>
          <span className="hidden md:inline text-[#D8D0C4]">Concept Studio Portfolio</span>
        </div>
      </div>

      {/* Main Sticky Header */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#F5F1E9]/95 backdrop-blur-md shadow-xs border-b border-[#D8D0C4]/70'
            : 'bg-[#F5F1E9] border-b border-[#D8D0C4]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Top Bar Contract: 3 zones (Brand - Nav Links - Primary Actions) */}
          <div className="h-20 flex items-center justify-between gap-8">
            {/* Zone 1: Brand Wordmark */}
            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => handleNavClick('hero')}
                className="text-left group focus-visible:outline-2 focus-visible:outline-[#49372B] rounded-xs"
                aria-label="Alder & Hearth home"
              >
                <div className="flex items-baseline gap-2">
                  <span className="font-serif-luxury text-2xl sm:text-3xl font-medium tracking-[0.12em] uppercase text-[#28231F] group-hover:text-[#49372B] transition-colors">
                    Alder &amp; Hearth
                  </span>
                  <span className="text-[10px] tracking-widest text-[#757969] uppercase font-sans-clean font-medium hidden sm:inline">
                    New York
                  </span>
                </div>
              </button>
            </div>

            {/* Zone 2: Nav Links (Desktop) */}
            <nav className="hidden lg:flex items-center gap-8 text-xs uppercase tracking-[0.15em] font-medium text-[#49372B]">
              <button
                onClick={() => handleNavClick('collection')}
                className="hover:text-[#A36D47] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#A36D47]"
              >
                Collections
              </button>
              <button
                onClick={() => handleNavClick('approach')}
                className="hover:text-[#A36D47] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#A36D47]"
              >
                Our Approach
              </button>
              <button
                onClick={() => handleNavClick('materials')}
                className="hover:text-[#A36D47] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#A36D47]"
              >
                Materials
              </button>
              <button
                onClick={() => handleNavClick('room-story')}
                className="hover:text-[#A36D47] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#A36D47]"
              >
                Room Story
              </button>
              <button
                onClick={() => handleNavClick('design-services')}
                className="hover:text-[#A36D47] transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#A36D47]"
              >
                Design Services
              </button>
            </nav>

            {/* Zone 3: Interactive Affordances & Primary Action */}
            <div className="flex items-center gap-3 sm:gap-4 shrink-0">
              {/* Search Button */}
              <button
                onClick={onOpenSearch}
                aria-label="Search furniture collection"
                className="p-2 text-[#49372B] hover:text-[#A36D47] hover:bg-[#D8D0C4]/30 rounded-xs transition-colors focus-visible:outline-2 focus-visible:outline-[#49372B]"
                title="Search (Cmd+K)"
              >
                <Search className="w-5 h-5" strokeWidth={1.5} />
              </button>

              {/* Saved Pieces Button */}
              <button
                onClick={onOpenSavedDrawer}
                aria-label={`View saved pieces (${savedCount} items)`}
                className="relative p-2 text-[#49372B] hover:text-[#A36D47] hover:bg-[#D8D0C4]/30 rounded-xs transition-colors focus-visible:outline-2 focus-visible:outline-[#49372B]"
                title="Saved Shortlist"
              >
                <Bookmark className="w-5 h-5" strokeWidth={1.5} />
                {savedCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-[#A36D47] text-[#F5F1E9] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center font-mono tabular-nums leading-none">
                    {savedCount}
                  </span>
                )}
              </button>

              {/* Primary Consultation Action (Desktop) */}
              <button
                onClick={onOpenConsultation}
                className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-xs uppercase tracking-wider font-medium text-[#F5F1E9] bg-[#49372B] hover:bg-[#28231F] transition-colors whitespace-nowrap rounded-xs border border-[#49372B] focus-visible:outline-2 focus-visible:outline-[#49372B]"
              >
                <span>Plan a Room</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              {/* Mobile Menu Toggle Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
                className="lg:hidden p-2 text-[#49372B] hover:text-[#A36D47] hover:bg-[#D8D0C4]/30 rounded-xs transition-colors focus-visible:outline-2 focus-visible:outline-[#49372B]"
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6" strokeWidth={1.5} />
                ) : (
                  <Menu className="w-6 h-6" strokeWidth={1.5} />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#F5F1E9] border-t border-[#D8D0C4] px-6 py-6 shadow-xl animate-fadeIn">
            <nav className="flex flex-col gap-4 text-sm font-medium tracking-wider uppercase text-[#49372B]">
              <button
                onClick={() => handleNavClick('collection')}
                className="text-left py-2 border-b border-[#D8D0C4]/50 flex items-center justify-between hover:text-[#A36D47]"
              >
                <span>Collections</span>
                <span className="text-xs text-[#757969] lowercase font-serif-luxury italic">8 concept pieces</span>
              </button>
              <button
                onClick={() => handleNavClick('approach')}
                className="text-left py-2 border-b border-[#D8D0C4]/50 flex items-center justify-between hover:text-[#A36D47]"
              >
                <span>Our Approach</span>
                <span className="text-xs text-[#757969] lowercase font-serif-luxury italic">philosophy &amp; craft</span>
              </button>
              <button
                onClick={() => handleNavClick('materials')}
                className="text-left py-2 border-b border-[#D8D0C4]/50 flex items-center justify-between hover:text-[#A36D47]"
              >
                <span>Materials</span>
                <span className="text-xs text-[#757969] lowercase font-serif-luxury italic">walnut, oak, linen, leather</span>
              </button>
              <button
                onClick={() => handleNavClick('room-story')}
                className="text-left py-2 border-b border-[#D8D0C4]/50 flex items-center justify-between hover:text-[#A36D47]"
              >
                <span>Room Story</span>
                <span className="text-xs text-[#757969] lowercase font-serif-luxury italic">Hudson Valley interior</span>
              </button>
              <button
                onClick={() => handleNavClick('design-services')}
                className="text-left py-2 border-b border-[#D8D0C4]/50 flex items-center justify-between hover:text-[#A36D47]"
              >
                <span>Design Services</span>
                <span className="text-xs text-[#757969] lowercase font-serif-luxury italic">bespoke planning</span>
              </button>

              <div className="pt-4 flex flex-col gap-3">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenConsultation();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs uppercase tracking-wider font-medium text-[#F5F1E9] bg-[#49372B] hover:bg-[#28231F] transition-colors rounded-xs"
                >
                  <span>Plan a Room &amp; Enquire</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <div className="flex items-center justify-between text-xs text-[#757969] pt-2">
                  <span>Saved Pieces: {savedCount}</span>
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onOpenSavedDrawer();
                    }}
                    className="underline text-[#49372B]"
                  >
                    Open Shortlist
                  </button>
                </div>
              </div>
            </nav>
          </div>
        )}
      </header>
    </>
  );
}
